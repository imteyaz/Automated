package com.minapro.util.exception;

import org.codecompany.jeha.core.Handler;
import org.codecompany.jeha.populator.Populator;

/**
 * The common exception handler where the application level decisions can be taken based on the Exception errorCode
 * 
 * @author Rosemary George
 *
 */
public class MinaProExceptionHandler implements Handler {

    public Populator getPopulator() {
        return null;
    }

    @Override
    public Throwable handle(Throwable arg, Object... arg1) {
        return arg;
    }

}
