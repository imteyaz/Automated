package com.minapro.util.exception;

/**
 * ErrorCode contains all possible kind of exceptions to be handled in the application.
 * 
 * @author Rosemary George
 *
 */
public enum ErrorCode {

    DATABASE_CONNECTION_FAIL("100", "Database connection failed"), DATABASE_AUTHENTICATION_FAIL("101",
            "Database authentication failed"), DATABASE_TABLE_NOT_EXISTS("102", "Table does not exist"), CACHE_INITIALIZATION_FAIL(
            "103", "Cache initialization failed"), CACHE_NOT_FOUND("104", "Cache not found"), QUEUE_INITIALIZATION_FAIL(
            "105", "Queue not initialized"), QUEUE_NOT_ALLIVE("106", "Queue not alive"), QUEUE_NOT_LISTENING("107",
            "Queue not listening"), SOCKET_EXCEPTION("108", "Broken socket"), EOF_EXCEPTION("109", "Recieved EOF"), ILLEGAL_STATE_EXCEPTION(
            "110", "Illegal state"), ACTOR_INITIALIZATION_FAIL("111", "Actor initialization failed"), ACTOR_EXCEPTION(
            "112", "Actor not alive"), ESPER_EXCEPTION("113", "CEP Engine not working");

    private String code;
    private String errorMessage;

    private ErrorCode(String errorCode, String errorMessage) {
        this.code = errorCode;
        this.errorMessage = errorMessage;

    }

    public String getCode() {
        return code;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

}
