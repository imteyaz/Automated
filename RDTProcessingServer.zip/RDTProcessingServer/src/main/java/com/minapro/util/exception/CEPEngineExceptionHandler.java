package com.minapro.util.exception;

import org.codecompany.jeha.core.HandlerUtil;

import com.espertech.esper.client.hook.ExceptionHandler;
import com.espertech.esper.client.hook.ExceptionHandlerContext;
import com.espertech.esper.client.hook.ExceptionHandlerFactory;
import com.espertech.esper.client.hook.ExceptionHandlerFactoryContext;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * The Exception handler for esper engine related errors.
 * 
 * @author Rosemary George
 *
 */
public class CEPEngineExceptionHandler implements ExceptionHandler, ExceptionHandlerFactory {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CEPEngineExceptionHandler.class);

    public void handle(ExceptionHandlerContext context) {
        String statement = context.getStatementName();
        logger.logMsg(LOG_LEVEL.WARN, "", "Caught exception" + context.getThrowable().getLocalizedMessage()
                + " while processing the statement" + statement);

        MinaProAppException appEx = new MinaProAppException(ErrorCode.ESPER_EXCEPTION, context.getThrowable()
                .getLocalizedMessage());
        HandlerUtil.handle(appEx);
    }

    @Override
    public ExceptionHandler getHandler(ExceptionHandlerFactoryContext arg0) {
        return this;
    }

}
