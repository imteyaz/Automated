package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


@Embeddable
public class QcJobListPK implements Serializable{
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MOVE_KIND")
	private String moveKind;

	@Column(name="CONTAINER_ID")
	private String containerId;

	public QcJobListPK() {
	}
	public String getMoveKind() {
		return this.moveKind;
	}
	public void setMoveKind(String moveKind) {
		this.moveKind = moveKind;
	}
	public String getContainerId() {
		return this.containerId;
	}
	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof QcJobListPK)) {
			return false;
		}
		QcJobListPK castOther = (QcJobListPK)other;
		return 
			this.moveKind.equals(castOther.moveKind)
			&& this.containerId.equals(castOther.containerId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.moveKind.hashCode();
		hash = hash * prime + this.containerId.hashCode();
		
		return hash;
	}
}
