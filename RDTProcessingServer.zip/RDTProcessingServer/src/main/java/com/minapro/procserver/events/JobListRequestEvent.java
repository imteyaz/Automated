package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the job list request event originated from device or used by server to initiate job list updates
 * for the logged in users
 * 
 * @author Rosemary George
 *
 */
public class JobListRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -5510733174809973457L;

    private String location;

    /**
     * Indicates whether the request is initiated from the scheduler or not
     */
    private boolean isScheduled;

    private String rotationId;

    private String password;
    
    //indicates the QC ID  HC is mapped to
    private String qcId;

    public String getQcId() {
        return qcId;
    }

    public void setQcId(String qcId) {
        this.qcId = qcId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "JobListRequestEvent [location=" + location + ", isScheduled=" + isScheduled + ", rotationId="
                + rotationId + ", qcId=" + qcId + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }
}
