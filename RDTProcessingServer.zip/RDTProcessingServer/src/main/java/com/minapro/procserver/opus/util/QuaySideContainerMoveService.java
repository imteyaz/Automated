package com.minapro.procserver.opus.util;

import static com.minapro.procserver.util.QCPLCConstants.GANTRY_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.SINGLE;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER1_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.T1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.T2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.TANDEM;
import static com.minapro.procserver.util.QCPLCConstants.TWIN;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GROUND;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.CellGrid;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ContainerMoveResponseEvent;
import com.minapro.procserver.events.ExchangeContainerRequestEvent;
import com.minapro.procserver.events.ExchangeDetails;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.UpdateContainerLocationEvent;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.hc.SwapContainerPosition;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class responsible for handling all the container confirmations happens at the Quay side, either by QC or HC operator.
 * 
 * @author Rosemary George
 *
 */
public class QuaySideContainerMoveService {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QuaySideContainerMoveService.class);

	private static final QuaySideContainerMoveService INSTANCE = new QuaySideContainerMoveService();

	private static final ContainerMoveUtil CONTAINER_MOVE_UTIL = ContainerMoveUtil.getInstance();
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
	private static final String HATCHCOVER = "HATCHCOVER";
	private static final String MANCAGE = "MANCAGE";
	private static final String BREAKBULK = "BREAKBULK";
	private static final String BACKREACH = "BACKREACH";

	private static final String INVALID_TO_LOCATION_ERR = "InValidToLocationError";
	private static final String ALREADY_CONFIRMED_ERR = "AlreadyConfirmedWithITVError";

	private QuaySideContainerMoveService() {
	}

	public static QuaySideContainerMoveService getInstance() {
		return INSTANCE;
	}

	/**
	 * <p>Handles the container movement that happens at the Quay side. The operation can be Loading container to vessel
	 * or discharging from the vessel. Either QC or HC operator will be invoking these operation or it is detected
	 * through PLC automatically.</p>
	 * 
	 * <p> While discharging the container, it may be put into the BACK REACH area. This case is also handled. In such
	 * cases, the container is removed from the users job list and put it into the back reach cache. </p>
	 * 
	 * <p>The corresponding bay is updated with the container details. And in case of discharge, ITV drive instruction
	 * is generated. </p>
	 * 
	 * @param moveEvent
	 * @param user
	 * @param operatorRole
	 * @return true if the job confirmation is correction on an already completed move, else false
	 */
	public void handleQuaySideContainerMoveOperation(ContainerMoveEvent moveEvent, User user, OPERATOR operatorRole) {
		logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "handleQuaySideContainerMoveOperation - started");

		if (OPERATOR.HC.equals(operatorRole)) {
			moveEvent.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(moveEvent.getUserID()));
		}

		String jobType = moveEvent.getContainerIDs().get(0);
		if (jobType.startsWith(HATCHCOVER) || jobType.startsWith(MANCAGE) || jobType.startsWith(BREAKBULK)) {
			CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);

			logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Deleting " + jobType + " job from joblist cache");
			RDTCacheManager.getInstance().deleteFromJobList(moveEvent.getUserID(), jobType, moveEvent.getEquipmentID(),
					moveEvent.getMoveType());
			updateCompletedJobsWithGeneralLiftOperation(user, moveEvent, moveEvent.getEquipmentID());
			if(!OPERATOR.HC.equals(operatorRole)){
				sendContainerConfirmationMessageToQuaySideOperators(moveEvent);
			}
			return;
		}

		/*
		 * Following Code is added to handle S1 jobs.
		 */
		String categeory  =  getCategeoryFromJobList(moveEvent);
		boolean correctionOnCompletedJob = isCorrectionOnCompletedMove(moveEvent, categeory);

		logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), moveEvent.getMoveType() + " operation - performed by "
				+ operatorRole);		
		
		if (LOAD.equalsIgnoreCase(moveEvent.getMoveType()) || ("S1".equalsIgnoreCase(categeory))) {			
			handleLoadOperation(moveEvent, operatorRole, correctionOnCompletedJob, user,categeory);
		} else {
			handleDischargeOperation(operatorRole, moveEvent, correctionOnCompletedJob, user);
		}
	}

	/**
	 * Verifies all the DSCH operation related conditions and performs the discharge job confirmation.
	 * 
	 * 1. If the discharge is performed by QC (either manually or PLC), confirmation happens only in Atom. No message is
	 * forwarded to ESB.
	 * 
	 * 2. Verifies whether the toLocation is a valid ITV / GROUND/ BACKREACH if not, sends failure response to UI
	 * 
	 * 3. Next verifies whether the confirmation is for an already confirmed job. If yes, and the completed move don't
	 * indicate exception while confirming and the toLocation contains an ITV, sends a failure message to UI indicating
	 * that additional confirmation is not allowed.
	 * 
	 * @param operatorRole
	 * @param moveEvent
	 * @param correctionOnCompletedJob
	 * @param user
	 */
	private void handleDischargeOperation(OPERATOR operatorRole, ContainerMoveEvent moveEvent,
			boolean correctionOnCompletedJob, User user) {
		try {
			if (operatorRole.equals(OPERATOR.QC)) {
				logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Discharge performed by QC. Only Atom updates");
				if(!moveEvent.isAutomaticFlag()){
					CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);
				}
				performContainerConfirmation(moveEvent, correctionOnCompletedJob, operatorRole, user,null);
			} else {
				if (checkValidMessage(moveEvent, operatorRole,null)) {
					if (correctionOnCompletedJob) {
						CompletedContainerMoves completedMove = CONTAINER_MOVE_UTIL.getCompletedContainer(moveEvent.getContainerIDs()
								.get(0), moveEvent.getUserID(), moveEvent.getEquipmentID(),moveEvent.getMoveType());
						logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Completed Move -->" + completedMove);
						
						if (completedMove != null
								&& ("N".equalsIgnoreCase(completedMove.getExceptionOccured()) || "Y"
										.equals(completedMove.getExceptionResolved())) 
								&&	completedMove.getToLocation() != null 
								&& RDTCacheManager.getInstance().getEquipmentDetails(completedMove.getToLocation()) != null
								&& completedMove.getUser().getUserID().equalsIgnoreCase(moveEvent.getUserID())) {
							logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
									"Job is already confirmed successfully to TOS with ITV "
											+ completedMove.getToLocation());
							
							boolean isITVSwapDone = CONTAINER_MOVE_UTIL.checkAndInitiateITVSwap(moveEvent);
							if(isITVSwapDone){
								CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);
								logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "ITV swap detected and send");
							} else {
								boolean isSwapDone = sendPositionUpdate(moveEvent, true);
								if(isSwapDone){
									logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),"Swap detected. Sending validation success");
									CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);								
								}else{
									logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),"No Swap detected. Sending ALREADY_CONFIRMED_ERR");
									CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(false, ALREADY_CONFIRMED_ERR, moveEvent,
										operatorRole);
								}
							}
							return;
						}
					}
					CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);
					validateAndUpdateContainerPosition(moveEvent);	
					sendPositionUpdate(moveEvent, correctionOnCompletedJob);
					performContainerConfirmation(moveEvent, correctionOnCompletedJob, operatorRole, user,"");						
					ESBQueueManager.getInstance().postMessage(moveEvent, operatorRole, moveEvent.getTerminalID());
				} else {
					CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(false, INVALID_TO_LOCATION_ERR, moveEvent,
							operatorRole);
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while performing Discharge Operation", ex);
		}
	}	

	/**
	 * Identifies whether the position of the container has been changed..If so, sends swap request to ESB.
	 *  
	 * @param moveEvent
	 * @param isCompleted
	 */
	private boolean sendPositionUpdate(ContainerMoveEvent moveEvent, boolean isCompleted) {
		boolean status = false;
		logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Entering sendPositionUpdate method with isCompleted="+isCompleted);
		
		if(moveEvent.getPosition() != null && !moveEvent.getPosition().isEmpty()){
		
			ListOrderedMap<String, JobListContainer> jobsInCache =RDTCacheManager.getInstance().getJobList(
	                moveEvent.getUserID(), moveEvent.getEquipmentID());
			
			if(jobsInCache == null && !isCompleted){
				logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Not completed job confirmation and No jobs present in cache");
			}
			
			SwapContainerPosition swapContainer;
			String containerId;
			boolean isPositionChanged = false;
			String jobKey =  null;
			List<SwapContainerPosition> swapList = new ArrayList<SwapContainerPosition>();
			try{	
				for(int index=0; index<moveEvent.getContainerIDs().size(); index++){
					containerId = moveEvent.getContainerIDs().get(index);
					
					if(isCompleted){
						CompletedContainerMoves completedMove = CONTAINER_MOVE_UTIL.getCompletedContainer(containerId, 
								moveEvent.getUserID(), moveEvent.getEquipmentID(),moveEvent.getMoveType());
						logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Completed job:" + completedMove ); 
						
						if (completedMove != null && !moveEvent.getPosition().get(index).equalsIgnoreCase(completedMove.getPosition())){
							logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Completed job and position changed");
							isPositionChanged = true;
							jobKey = completedMove.getJobKey();
						}else {
							logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "No change in position");
						}
					}else if(jobsInCache.get(containerId+moveEvent.getMoveType())!= null && 
							!moveEvent.getPosition().get(index).equalsIgnoreCase(jobsInCache.get(containerId+moveEvent.getMoveType()).getPosition())){
						logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "current job first confirmation with position change");
						isPositionChanged = true;
						jobKey = jobsInCache.get(containerId+moveEvent.getMoveType()).getJobKey();
					}else {
						logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "No position change detected either from completed/current job for container"
								+ containerId); 
					}
					
					if(isPositionChanged){					
						swapContainer = new SwapContainerPosition();
						swapContainer.setContainerId(containerId);
						swapContainer.setItvId(moveEvent.getToLocations().get(index));
						swapContainer.setJobKey(jobKey);
						swapContainer.setPositionOnChassis(moveEvent.getPosition().get(index));
						swapList.add(swapContainer);
					}
					
					isPositionChanged = false;
				}
				
				if(!swapList.isEmpty()){
					SwapRequestEvent swapEvent = new SwapRequestEvent();
					swapEvent.setUserID(moveEvent.getUserID());
					swapEvent.setEventID(UUID.randomUUID().toString());
					swapEvent.setSwapContainers(swapList);
					swapEvent.setEquipmentID(moveEvent.getEquipmentID());
					swapEvent.setTerminalID(moveEvent.getTerminalID());
					
					logger.logMsg(LOG_LEVEL.INFO, swapEvent.getUserID(), "Sending position update to ESB");
					ESBQueueManager.getInstance().postMessage(swapEvent, OPERATOR.COMMON, swapEvent.getTerminalID());
					status = true;
				}
			}catch(Exception ex){
				logger.logException("Caught exception while sendPositionUpdate-", ex);
			}
		}
		
		return status;
	}

	/**
	 * Validates whether the container position on chasis is already filled. If not, retrieves it from the
	 * job list data and fill.
	 * 
	 * @param moveEvent
	 */
	private void validateAndUpdateContainerPosition(ContainerMoveEvent moveEvent) {
		if(moveEvent.getPosition() == null || moveEvent.getPosition().isEmpty()){
			
			ListOrderedMap<String, JobListContainer> jobsInCache =RDTCacheManager.getInstance().getJobList(
	                moveEvent.getUserID(), moveEvent.getEquipmentID());
			
			if(jobsInCache == null){
				logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "No jobs present in cache");
				return;
			}
			
			List<String> positions = new ArrayList<String>();
			for(String containerId: moveEvent.getContainerIDs()){
				positions.add(jobsInCache.get(containerId+moveEvent.getMoveType())!= null ? jobsInCache.get(containerId+moveEvent.getMoveType()).getPosition(): "");
			}
			moveEvent.setPosition(positions);
			logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Container positions - " + moveEvent.getPosition());
		}		
	}

	/**
	 * Verifies all the LOAD operation related conditions and performs the load job confirmation.
	 * 
	 * 1. If it is PLC confirmed job, PLC derived position and job location are different, adjusts the cell locations
	 * for other containers(in twin/tandem case)
	 * 
	 * 2. Verifies whether the toLocation is a valid cell Location / GROUND/ BACKREACH if not, sends failure response to
	 * UI
	 * 
	 * 3. Next verifies whether the confirmation is for an already confirmed job. Then sends UpdateJobLocation message
	 * to ESB
	 * 
	 * 4. If it is fresh job confirmation, verifies whether the toLocation is updated to a different one from job list.
	 * 
	 * 5. ToLocation different and the job is PLC confirmed one, check for pre-job confirm failures. if there is no
	 * pre-confirmation failure, sends UpdateJobLocation message to ESB
	 * 
	 * 6. In Manual case, if toLocation different, sends ExchangeContainer request to ESB and keeps the container
	 * confirmation in cache till the response is received.
	 * 
	 * @param moveEvent
	 * @param operatorRole
	 * @param correctionOnCompletedJob
	 * @param user
	 */
	private void handleLoadOperation(ContainerMoveEvent moveEvent, OPERATOR operatorRole,
			boolean correctionOnCompletedJob, User user,String categeory) {

		try {
			// in case of QC PLC confirmed load job, updates the toLocation to the derived location if both are not
			// matching.
			boolean positionMatched = true;
			if (moveEvent.isAutomaticFlag() && operatorRole.equals(OPERATOR.QC)) {
				positionMatched = verifyDetectedPositionMatchesWithJob(moveEvent);
				if (!positionMatched) {
					StringBuilder updatedToLocation = updateTolLocationAsSpreaderRef(moveEvent.getPlcDerivedLocation(),
							moveEvent);
					logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
							"Postion didn't match, updated toLocations in order is " + updatedToLocation);
					moveEvent.setToLocations(updatedToLocation.toString());
				}
			}
			boolean status = checkValidMessage(moveEvent, operatorRole,categeory);
			/*
			 *Following condition is added in order to validate the to location of the S1 job.
			 *S1 means vessel to vessel movement , other than vessel location is invalid.
			 *To validate this added following extra condition 
			 *!moveEvent.getToLocations().get(0).matches(".*[a-zA-Z]+.*")  --
			 * If to location has alphabets it is invalid to location. 
			 */
			status = (status == true ? 
					"S1".equalsIgnoreCase(categeory) ?(!moveEvent.getToLocations().get(0).matches(".*[a-zA-Z]+.*")) :status :status);
			
			logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID()," To Location Status::"+status);
	
			
			if (status) {
				
				if (correctionOnCompletedJob) {
					CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);
					updateJobPositionToESB(moveEvent);
					performContainerConfirmation(moveEvent, correctionOnCompletedJob, operatorRole, user,categeory);					
				} else {
					boolean isLocationUpdated = verifyToLocationWithPlannedLocation(moveEvent);
					
					if (isLocationUpdated) {
						if (moveEvent.isAutomaticFlag()) {
							if (!checkPreJobConfirmFailure(moveEvent)) {
								updateJobPositionToESB(moveEvent);
								performContainerConfirmation(moveEvent, correctionOnCompletedJob, operatorRole, user,categeory);								
							}
						} else {
							logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Planned Location and "
									+ "the actual toLocation differs. Waiting for TOS update result");
							RDTVesselProfileCacheManager.getInstance().addContainerMoveEvent(moveEvent);
							return;
						}						
					} else {
						if (!moveEvent.isAutomaticFlag()) {
							CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(true, "", moveEvent, operatorRole);
						}
						boolean result = checkPreJobConfirmFailure(moveEvent);
						if(!result){
							performContainerConfirmation(moveEvent, correctionOnCompletedJob, operatorRole, user,categeory);
							ESBQueueManager.getInstance().postMessage(moveEvent, operatorRole, moveEvent.getTerminalID());
						}
					}
				}				
			} else {
				if (!moveEvent.isAutomaticFlag()) {
					CONTAINER_MOVE_UTIL.sendValidationResponseToDevice(false, INVALID_TO_LOCATION_ERR, moveEvent,
						operatorRole);
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while handling LOAD operation", ex);
		}
	}

	/**
	 * Verifies whether any pre-job confirmation failure response exists for the containers. 
	 * If yes, initiate the containerMoveResponseEvent.
	 * 
	 * @param moveEvent
	 * @return
	 */
	//TODO :: Here needs to check the impact of the Move Type.
	
	private boolean checkPreJobConfirmFailure(ContainerMoveEvent moveEvent) {
		List<ContainerMoveResponseEvent> failureRespList = RDTPLCCacheManager.getInstance()
				.getPreJobConfirmFailureMessage(moveEvent.getEquipmentID());
		logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Failure pre-job confirm messages avaibale---"
				+ failureRespList);
		if (failureRespList != null) {
			for (ContainerMoveResponseEvent failureResp : failureRespList) {
				if (moveEvent.getContainerIDs().contains(failureResp.getContainerId())) {
					failureResp.setPreJobConfirmation(false);
					logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Initiating failure alert--" + failureResp);
					RDTProcessingServer.getInstance().getMasterActor().tell(failureResp, null);
					RDTPLCCacheManager.getInstance().removePreJobConfirmFailureMessage(moveEvent.getEquipmentID(),
							failureResp);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Verifies whether the toLocation coming from user/auto confirmation is same as the planned toLocation from job
	 * list. If it is different, sends ExchangeContainer request to ESB (Only in the case of manual job confirmation, as
	 * automatic PLC case will pre-confirm the job at lock time itself)
	 * 
	 * @param moveEvent
	 * @param jobList
	 * @return true if the toLocation differs from the planned location, else false
	 */
	private boolean verifyToLocationWithPlannedLocation(ContainerMoveEvent moveEvent) {
		boolean isToLocationUpdated = false;

		ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
				moveEvent.getUserID(), moveEvent.getEquipmentID());
		
		if (!moveEvent.isAutomaticFlag()) {
			String containerId, toLocation;
			JobListContainer job = null;

			List<ExchangeDetails> exchangeDetails = new ArrayList<ExchangeDetails>();
			ExchangeDetails exchange;
			for (int i = 0; i < moveEvent.getContainerIDs().size(); i++) {
				containerId = moveEvent.getContainerIDs().get(i);
				toLocation = moveEvent.getToLocations().get(i);
				
				if (GROUND.equals(toLocation)){
					continue;
				}

				exchange = new ExchangeDetails();
				exchange.setContainerId(containerId);
				exchange.setTargetLocation(toLocation);
				job = jobList.get(containerId + moveEvent.getMoveType());
				if (job != null && toLocation != null && !toLocation.equals(job.getToLocation())) {
					isToLocationUpdated = true;
					exchange.setSourceLocation(job.getToLocation());
					
					PLCEventUtil.getInstance().sendWrongLocationDetected(moveEvent.getUserID(),
                            job, toLocation, moveEvent.getEquipmentID());
				}

				exchangeDetails.add(exchange);
			}

			if (isToLocationUpdated) {
				logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
						"Detected toLocation change from the job list. Initiating exchange");
				ExchangeContainerRequestEvent requestEvent = new ExchangeContainerRequestEvent();
				requestEvent.setEquipmentID(moveEvent.getEquipmentID());
				requestEvent.setUserID(moveEvent.getUserID());
				requestEvent.setTerminalID(moveEvent.getTerminalID());
				requestEvent.setEventID(moveEvent.getEventID());
				requestEvent.setExchangeDetails(exchangeDetails);
				requestEvent.setMoveType(moveEvent.getMoveType());
				if (job != null) {
					requestEvent.setVessel(job.getVesselName());
					requestEvent.setVoyage(job.getVoyage());
				}

				String twinTandemIndicator = "S";
				if (job.getTandemContainerIDs() != null && job.getTandemContainerIDs().length > 0) {
					twinTandemIndicator = "M";
				} else if (job.getTwinContainerId() != null && !job.getTwinContainerId().isEmpty()) {
					twinTandemIndicator = "W";
				}
				requestEvent.setSingleTwinFlag(twinTandemIndicator);
				ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.COMMON, moveEvent.getTerminalID());
			}
		}
		return isToLocationUpdated;
	}

	/**
	 * Performs the LOAD/DSCH related RDT cache updates (PLC values, bay profile modification), triggering the
	 * performance event, generating container placed/picked message to ITV
	 * 
	 * @param moveEvent
	 * @param correctionOnCompletedJob
	 * @param operatorRole
	 * @param user
	 * @param categeory 
	 */
	public void performContainerConfirmation(ContainerMoveEvent moveEvent, boolean correctionOnCompletedJob,
			OPERATOR operatorRole, User user, String categeory ) {
		
		if (operatorRole.equals(OPERATOR.QC)) {
			boolean firstTimeflag = RDTPLCCacheManager.getInstance().getFirstTimeMapping(moveEvent.getUserID());
			RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(moveEvent.getUserID(), false);

			if (firstTimeflag) {
				// Storing PLC positions as reference for automatic detection
				preservePLCPositionsForNextMove(moveEvent);
			} else {
				preserverBayDetailsForPLC(moveEvent);
			}
		}

		try {
			String toLocation = null;
			if (moveEvent.getToLocations() != null && !moveEvent.getToLocations().isEmpty()){
				toLocation = moveEvent.getToLocations().get(0);
			}
			
			String fromLocation = null;
			if (moveEvent.getFromLocations() != null && !moveEvent.getFromLocations().isEmpty()){
				fromLocation = moveEvent.getFromLocations().get(0);
			}
			
			if(BACKREACH.equalsIgnoreCase(toLocation)) {
				handleBackReachDischargeOperation(moveEvent, user, operatorRole);
			} else if (BACKREACH.equalsIgnoreCase(fromLocation)) {
				handleBackReachLoadOperation(moveEvent, user, operatorRole);
			} else {

				// Add to completed moves
				CONTAINER_MOVE_UTIL.updateCompletedMoves(user, moveEvent, moveEvent.getEquipmentID(), operatorRole);
				
				// check if this is correction of a completed move. or a general lift operation. In such case, no need to
				// update performance
				String container = moveEvent.getContainerIDs().get(0);
				if (!correctionOnCompletedJob && !container.startsWith(HATCHCOVER) && !container.startsWith(MANCAGE)
						&& !container.startsWith(BREAKBULK)) {
					// even if the move is confirmed by HC, it needs to be updated in QC performance
					updatePerformanceParameters(moveEvent);
				}

				// get the allocation details to get the rotation ID
				ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
						.getAllocationDetails(user.getUserID());

				// normal container move, check the move type and get cell location
				List<String> cellLocations;
				if (LOAD.equals(moveEvent.getMoveType()) || "S1".equalsIgnoreCase(categeory)) {
					cellLocations = moveEvent.getToLocations();
					//For S1 jobs there is no ITV concept, No need to send any instruction to itv.
					if(LOAD.equals(moveEvent.getMoveType())){
						CONTAINER_MOVE_UTIL.generateContainerPickedMessageToITV(moveEvent);
					}
				} else {
					cellLocations = moveEvent.getFromLocations();
					if(moveEvent.getToLocations() != null){
						int index = 0;
						for (String location : cellLocations) {
							String key = allocation.getRotationID() + "-" + location;
							RDTCacheManager.getInstance()
									.addVesselLocationToItv(key, moveEvent.getToLocations().get(index));
							index = index + 1;
						}
					}
					
					CONTAINER_MOVE_UTIL.generateContainerPlacedMessageToITV(moveEvent, operatorRole);					
				}

				if (allocation != null) {
					for (int i = 0; i < cellLocations.size(); i++) {
						//in case of S1, remove the container from the current location and load to new location
						if("S1".equalsIgnoreCase(categeory)){
							RDTVesselProfileCacheManager.getInstance().updateBayProfile(moveEvent.getFromLocations().get(i),
									moveEvent.getContainerIDs().get(i),	allocation.getRotationID(), DSCH);
							RDTVesselProfileCacheManager.getInstance().updateBayProfile(moveEvent.getToLocations().get(i),
									moveEvent.getContainerIDs().get(i),	allocation.getRotationID(), LOAD);
						}else if(!GROUND.equals(cellLocations.get(i))){
							RDTVesselProfileCacheManager.getInstance().updateBayProfile(cellLocations.get(i),
								moveEvent.getContainerIDs().get(i),	allocation.getRotationID(), moveEvent.getMoveType());
						}
					}
				}

				List<String> containerIds = moveEvent.getContainerIDs();
				// remove the containers form job list
				for (String containerId : containerIds) {
					RDTCacheManager.getInstance().deleteFromJobList(moveEvent.getUserID(), containerId,
							moveEvent.getEquipmentID(), moveEvent.getMoveType());

					// remove the container from central cache as it is LOADed onto vessel and left the port
					if (LOAD.equalsIgnoreCase(moveEvent.getMoveType()) || "S1".equalsIgnoreCase(categeory)) {
						RDTCacheManager.getInstance().deleteContainer(containerId);
					}
				}
			}
		} catch (Exception e) {
			logger.logException("Caught Exception while processing Quay side containerMove Event - ", e);
		}

		sendContainerConfirmationMessageToQuaySideOperators(moveEvent);

		if (moveEvent.isAutomaticFlag()) {
			PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(moveEvent.getEquipmentID());
		}

		RDTPLCCacheManager.getInstance().jobTypeCacheAssigment(
				RDTPLCCacheManager.getInstance().getCurrentJobTypeCache());
		RDTPLCCacheManager.getInstance().addSameLocationDetectedCache(user.getUserID(), false);
		
		checkHangingContainerCondition(moveEvent);
	}

	private void checkHangingContainerCondition(ContainerMoveEvent moveEvent) {
		if(LOAD.equalsIgnoreCase(moveEvent.getMoveType())){
			logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Checking Hanging container scenario for LOAD job");
			
			String containerId = null;
			String toLocation = null;
			String bottomCellLocation = null;
			MinaProAlertEvent alertEvent =  null;
			for (int i = 0; i < moveEvent.getContainerIDs().size(); i++) {
				try {
					containerId = moveEvent.getContainerIDs().get(i);
					toLocation = moveEvent.getToLocations().get(i);
					
					Integer tierNo = Integer.parseInt(toLocation.substring(toLocation.length()-2));
					bottomCellLocation = toLocation.substring(0, toLocation.length()-2) + conformToStandard(tierNo -2 );
					CellGrid cell = RDTVesselProfileCacheManager.getInstance().getCellDetails(bottomCellLocation, moveEvent.getUserID());
					if(cell != null){
						logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Verifying whether the bottom cell - " 
								+ bottomCellLocation + " has container");	
						String[] cellDetails = bottomCellLocation.split("\\.");
						Container container = RDTVesselProfileCacheManager.getInstance()
								.getContainerFromCell(moveEvent.getUserID(), cellDetails[0], cellDetails[1], cellDetails[2], DSCH);
						if(container == null){
							logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Failed to get container for the bottom cell. "
									+ "Raising hanging container alert");
							alertEvent = new MinaProAlertEvent();
							alertEvent.setContainerId(containerId);
							alertEvent.setActualLocation(toLocation);
							alertEvent.setUserID(moveEvent.getUserID());
							alertEvent.setOperatorId(moveEvent.getUserID());
							alertEvent.setEquipmentID(moveEvent.getEquipmentID());
							alertEvent.setAlertCode(ALERTCODE.QC_LOAD_JOB_HANGING_ALERT);
							
							RDTProcessingServer.getInstance().getMasterActor().tell(alertEvent, null);
						}
					}
				}catch(Exception ex){
					logger.logException("Caught exception while checking hanging container condition for container " + containerId, ex);
				}
			}
		}		
	}

	/**
	 * Verifies whether the container move operation received from UI is correction on already completed operation
	 * 
	 * @param moveEvent
	 * @return true if the operation is a correction job else false
	 */
	private boolean isCorrectionOnCompletedMove(ContainerMoveEvent moveEvent, String categeory) {

		try {
			
			CompletedContainerMoves cont = CONTAINER_MOVE_UTIL.getCompletedContainer(moveEvent.getContainerIDs().get(0), moveEvent.getUserID(),
					moveEvent.getEquipmentID(),moveEvent.getMoveType());
			/*
			 * Added By UmaMahesh
			 * When load job is confirmed first time to TOS , TOS send failure message to RDT .
			 * User try to confirm the second time same container
			 * at that time RDT has to send the Job Confirmation request instead of Update Container event to ESB.
			 * To handle this issue , Checking first whether it is completed into 
			 * completed jobs with exception or not.
			 * If yes send normal job confirmation request to ESB.
			 * Added Code :: && !cont.getExceptionOccured().equalsIgnoreCase("Y")
			 */
			
			if (cont != null && (!"Y".equalsIgnoreCase(cont.getExceptionOccured()) 
					||"Y".equalsIgnoreCase(cont.getExceptionResolved()))) {
			
				logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID(),new StringBuilder(" Current Container ::").append(moveEvent.getContainerIDs()).
						append(" Exception Occured::").append(cont.getExceptionOccured()).append(" Exception Reason::").
						append(cont.getExceptionReason()).toString());
				
				logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Container present in the Completed Jobs List - "
						+ "This is Correction container move event - Updating bay view");
				
				if (LOAD.equals(cont.getMoveType()) || "S1".equalsIgnoreCase(categeory)) {
					ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
							.getAllocationDetails(moveEvent.getUserID());
					RDTVesselProfileCacheManager.getInstance().updateBayProfile(cont.getToLocation(),
							cont.getContainerId(), allocationEvent.getRotationID(), DSCH);
				}
				return true;
			} else {
				logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Container not present in the Completed Jobs List"
						+ "/ No Exception Occured In Previous Confirmation");
				
			}
		} catch (Exception ex) {
			logger.logException(" Exception Occured In isCorrectionOnCompletedMove Reason-", ex);
		}
		return false;
	}
	
	/**
	 * 
	 * @param vslLocation
	 *            - BB.RR.TT format {not null}
	 * @param containers
	 *            - 1,2 or 4 container in order
	 * @return Array of JobListContainer
	 * 
	 * 
	 *         spreaderRef is read from property file, if we visualize as spreader is divided into below 4 parts- <br>
	 * 
	 *         <pre> [ 1 ][ 2 ] 
	 *         		 [ 3 ][ 4 ] </pre>
	 * 
	 *         Then the number indicates which portion of spreader will be taken as reference point of vslLocation
	 */

	private StringBuilder updateTolLocationAsSpreaderRef(String vslLocation, ContainerMoveEvent moveEvent) {

		StringBuilder toLocations = new StringBuilder();
		try {
			int bay = Integer.valueOf(vslLocation.split("\\.")[0]);
			int row = Integer.valueOf(vslLocation.split("\\.")[1]);
			final int tier = Integer.valueOf(vslLocation.split("\\.")[2]);

			int spreaderRef = 0; // this can not be other than 0,1,2,3
			// TODO: Read this value from property file

			int[][] bayOffsetArr = { { 0, 2, 0, 2 }, { -2, 0, -2, 0 }, { 0, 2, 0, 2 }, { -2, 0, -2, 0 } };
			int[][] rowOffsetArr = { { 0, 0, -2, -2 }, { 0, 0, -2, -2 }, { 2, 2, 0, 0 }, { 2, 2, 0, 0 } };

			int incrementVal = 1;
			if (bay % 2 == 0) {
				incrementVal = 2;
			}

			int newBay, newRow;
			for (int ind = 0; ind < bayOffsetArr.length; ind = ind + incrementVal) {
				newBay = bay + bayOffsetArr[spreaderRef][ind];
				newRow = row + rowOffsetArr[spreaderRef][ind];
				if(ind < moveEvent.getContainerIDs().size()){
					toLocations.append(
						conformToStandard(newBay) + "." + conformToStandard(newRow) + "." + conformToStandard(tier))
						.append(ROW_SEPARATOR);
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while updateTolLocationAsSpreaderRef ", ex);
			for (int ind = 0; ind < moveEvent.getToLocations().size(); ind++) {
				toLocations.append(moveEvent.getToLocations().get(ind)).append(ROW_SEPARATOR);
			}
		}

		return toLocations;
	}

	/**
	 * Conforms the specified value to two digit format. if the value is single digit, prefix with 0
	 * 
	 * @param value
	 * @return
	 */
	private String conformToStandard(int value) {
		return (value < 10) ? "0" + value : String.valueOf(value);
	}

	/**
	 * Verifies whether the PLC detected cell location is matching with any of the container toLocations. This gets
	 * invoked only in automatic job confirmation from QC for the LOAD job
	 * 
	 * @param moveEvent
	 * @return false if no match found
	 */
	private boolean verifyDetectedPositionMatchesWithJob(ContainerMoveEvent moveEvent) {
		boolean positionMatched = true;

		try {
			if (moveEvent.getPlcDerivedJobType().equals(SINGLE)
					&& !moveEvent.getToLocations().get(0).equals(moveEvent.getPlcDerivedLocation())) {
				positionMatched = false;
			} else if (moveEvent.getPlcDerivedJobType().equals(TWIN)
					&& (!moveEvent.getToLocations().get(0).equals(moveEvent.getPlcDerivedLocation()) || !moveEvent
							.getToLocations().get(1).equals(moveEvent.getPlcDerivedLocation()))) {
				positionMatched = false;
			} else if (moveEvent.getPlcDerivedJobType().equals(TANDEM)) {
				positionMatched = false;
				for (String location : moveEvent.getToLocations()) {
					if (location.equals(moveEvent.getPlcDerivedLocation())) {
						positionMatched = true;
						break;
					}
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while verifyDetectedPositionMatchesWithJob", ex);
		}

		logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "verifyDetectedPositionMatchesWithJob exit with "
				+ positionMatched);
		return positionMatched;
	}

	/**
	 * Handles the back reach load operation. This can be done by either QC or HC
	 * 
	 * The container can be moved back to Vessel or to an ITV. In case the container is placed back on the vessel, the
	 * bay profile is updated. The job is deleted from the backReachJobs cache.
	 * 
	 * @param moveEvent
	 * @param user
	 * @param operatorRole
	 */
	private void handleBackReachLoadOperation(ContainerMoveEvent moveEvent, User user, OPERATOR operatorRole) {
		logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "handleBackReachLoadOperation - started");

		// get the QC user who has performed the actual operation.
		String qcUserId = moveEvent.getUserID();
		if (!OPERATOR.QC.equals(operatorRole)) {
			qcUserId = EventUtil.getInstance().getQcUserId(moveEvent.getUserID());
		}

		List<String> containerIds = moveEvent.getContainerIDs();
		for (String containerId : containerIds) {
			RDTPLCCacheManager.getInstance().deleteFromBackReachJobList(qcUserId, containerId);
		}

		// check whether the container has been put back to vessel or to ITV
		Equipment toItv = RDTCacheManager.getInstance().getEquipmentDetails(moveEvent.getToLocations().get(0));
		if (toItv == null) {
			logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "BackReach job placed back in vessel");
			if (!containerIds.get(0).startsWith(HATCHCOVER) && !containerIds.get(0).startsWith(MANCAGE)
					&& !containerIds.get(0).startsWith(BREAKBULK)) {
				ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
						.getAllocationDetails(user.getUserID());
				if (allocation != null) {
					String cellLocation;
					for (int i = 0; i < moveEvent.getToLocations().size(); i++) {
						cellLocation = moveEvent.getToLocations().get(i);
						RDTVesselProfileCacheManager.getInstance()
								.updateBayProfile(cellLocation, moveEvent.getContainerIDs().get(i),
										allocation.getRotationID(), moveEvent.getMoveType());
					}
				}
			} else {
				updateCompletedJobsWithGeneralLiftOperation(user, moveEvent, moveEvent.getEquipmentID());
			}

			// Setting again if UI forget to modify the moveType
			moveEvent.setMoveType(LOAD);
			preservePLCPositionsForNextMove(moveEvent);
		} else {
			logger.logMsg(LOG_LEVEL.DEBUG, qcUserId, "BackReach to ITV has done, next job should be Manual");
			CONTAINER_MOVE_UTIL.generateContainerPlacedMessageToITV(moveEvent, operatorRole);
		}
	}

	/**
	 * Handles the Back reach discharge operation. The container is moved from the users job list to back reach cache.
	 * And the associated bay profile is updated. The PLC positions are updated in the cache.
	 * 
	 * @param moveEvent
	 * @param user
	 * @param operatorRole
	 */
	private void handleBackReachDischargeOperation(ContainerMoveEvent moveEvent, User user, OPERATOR operatorRole) {
		logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "handleBackReachDischargeOperation - started");

		// get the QC user who has performed the actual operation.
		String qcUserId = moveEvent.getUserID();
		if (!OPERATOR.QC.equals(operatorRole)) {
			qcUserId = EventUtil.getInstance().getQcUserId(moveEvent.getUserID());
		}

		ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
				moveEvent.getUserID(), moveEvent.getEquipmentID());
		JobListContainer joblistContainer = (new ArrayList<JobListContainer>(jobList.values())).get(0);

		// Add the entry into the BackReach job list
		RDTPLCCacheManager.getInstance().updateBackReachJobList(qcUserId, joblistContainer);

		if (!joblistContainer.getContainerId().startsWith(HATCHCOVER)
				&& !joblistContainer.getContainerId().startsWith(MANCAGE)
				&& !joblistContainer.getContainerId().startsWith(BREAKBULK)) {
			ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
					.getAllocationDetails(user.getUserID());
			if (allocation != null) {
				String cellLocation;
				for (int i = 0; i < moveEvent.getFromLocations().size(); i++) {
					cellLocation = moveEvent.getFromLocations().get(i);
					RDTVesselProfileCacheManager.getInstance().updateBayProfile(cellLocation,
							moveEvent.getContainerIDs().get(i), allocation.getRotationID(), moveEvent.getMoveType());
				}
			}
		} else {
			updateCompletedJobsWithGeneralLiftOperation(user, moveEvent, moveEvent.getEquipmentID());
		}

		// remove the containers from job list since top job in Cache should be the next job
		List<String> containerIds = moveEvent.getContainerIDs();
		for (String containerId : containerIds) {
			RDTCacheManager.getInstance().deleteFromJobList(moveEvent.getUserID(), containerId,
					moveEvent.getEquipmentID(), moveEvent.getMoveType());
		}

		// Setting again if UI forget to modify the moveType
		moveEvent.setMoveType(DSCH);
		preservePLCPositionsForNextMove(moveEvent);
	}

	/**
	 * Saves the Quay Crane's gantry, hoist and trolley positions in cache. This values are used to identify the current
	 * vessel position(bay.row.tier) the QC is working on.
	 * 
	 * @param moveEvent
	 */
	private void preservePLCPositionsForNextMove(ContainerMoveEvent moveEvent) {
		preserverBayDetailsForPLC(moveEvent);

		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + T1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, false);
		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + T2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, false);
		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + H1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, false);
		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + H2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, false);
		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + GANTRY_UNLOCK + SPREADER1_LOCKEDUP, false);
		RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(
				moveEvent.getUserID() + GANTRY_UNLOCK + SPREADER2_LOCKEDUP, false);

		PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(moveEvent.getEquipmentID());
		logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "PLC Status :"
				+ RDTPLCCacheManager.getInstance().getPlcIgnoreEntry(moveEvent.getUserID()));
	}

	/**
	 * <p> Method Is responsible for sending Job confirmation message for container movement event to all operators
	 * based on following condition. </p> <p> If move type is Automatic,need to send container confirmation message to
	 * all operators,if move type is manual send confirmation message to other than current logged in user </p>
	 * 
	 * @author UMAMAHESH M
	 */
	private void sendContainerConfirmationMessageToQuaySideOperators(ContainerMoveEvent moveEvent) {
		RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
		OPERATOR loggedInOperator = rdtCacheMgr.getUserLoggedInRole(moveEvent.getUserID());

		String terminalId = moveEvent.getTerminalID();
		boolean automaticFlag = moveEvent.isAutomaticFlag();

		Set<String> allocatedUsers = null;

		logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Sending Job done confirmation to QC users ");
		if (loggedInOperator.equals(OPERATOR.QC)) {
			logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "QC Operator is logged in ");
			allocatedUsers = rdtCacheMgr.getAllUsersAtLocation(moveEvent.getEquipmentID());
			if (allocatedUsers != null) {
				allocatedUsers.add(moveEvent.getUserID());
			}
		} else {
			String qcEqupmntId = rdtCacheMgr.getQCEquipmentAllocatedForHC(moveEvent.getUserID());
			String qcUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcEqupmntId);
			allocatedUsers = rdtCacheMgr.getAllUsersAtLocation(qcEqupmntId);
			if (allocatedUsers != null && qcUserId != null) {
				allocatedUsers.add(qcUserId);
			}
		}

		if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {
			boolean inspectionStatus;
			OPERATOR currentOperatorRole;
			StringBuilder responseToDevice;

			for (String currentUser : allocatedUsers) {
				inspectionStatus = EventUtil.getInstance().getInspectionStatus(currentUser);
				currentOperatorRole = rdtCacheMgr.getUserLoggedInRole(currentUser);
				responseToDevice = CONTAINER_MOVE_UTIL.generateRemoveJobMessage(moveEvent, currentUser);

				if (automaticFlag) {
					// Automatic operation.. sending to all operators
					if (inspectionStatus) {

						logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(),
								"Sending Auto Job confirmation to QC User ");
						CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
								currentOperatorRole, terminalId);
					}
				} else if (!moveEvent.getUserID().equals(currentUser) && inspectionStatus) {
					// Manual operation sending confirmation to all users other than logged in user
					CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
							currentOperatorRole, terminalId);
				}
			}
		}
	}

	/**
	 * Sends the updated performance parameters to the Performance calculating Actor
	 * 
	 * @param moveEvent
	 */
	public void updatePerformanceParameters(ContainerMoveEvent moveEvent) {
		try {
			logger.logMsg(LOG_LEVEL.INFO, "",
					" Started UpdatePerformanceParameters() With Input Value " + moveEvent.toString());
			EsperPLCEvent plc1 = new EsperPLCEvent();
			plc1.setNode(moveEvent.getEquipmentID());
			plc1.setNoOfContainers(moveEvent.getContainerIDs().size());
			RDTProcessingServer.getInstance().getMasterActor().tell(plc1, null);
		} catch (Exception ex) {
			logger.logException("Caught exception while performing updatePerformanceParameters ", ex);
		}
	}

	/**
	 * Preserve current bay and cell position details for PLC
	 * 
	 * @param moveEvent
	 */
	private void preserverBayDetailsForPLC(ContainerMoveEvent moveEvent) {

		String containerLocation1 = null;
		String containerLocation2 = null;
		String containerLocation = null;
		String preservedBayIdStr = "Preserved BayID's :";
		String[] locationTokens;

		String containerTierId = null;
		String containerRowId = null;
		String containerBayId = null;
		try {
			if (DSCH.equalsIgnoreCase(moveEvent.getMoveType())) {
				int noOfFromLocations = moveEvent.getFromLocations().size();

				if (noOfFromLocations == 2) {
					containerLocation1 = moveEvent.getFromLocations().get(0);
					containerLocation2 = moveEvent.getFromLocations().get(1);

					locationTokens = containerLocation1.split("\\.");
					containerTierId = locationTokens[locationTokens.length - 1];
					containerRowId = locationTokens[locationTokens.length - 2];
					containerBayId = locationTokens[locationTokens.length - 3];

					String[] locationTokens2 = containerLocation2.split("\\.");
					String container2BayId = locationTokens2[locationTokens2.length - 3];

					String[] tierIds = new String[2];
					tierIds[0] = containerBayId;
					tierIds[1] = container2BayId;

					logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), preservedBayIdStr + Arrays.asList(tierIds));
					RDTPLCCacheManager.getInstance().addTwinIdsOfUser(moveEvent.getUserID(), tierIds);
				} else {
					containerLocation = moveEvent.getFromLocations().get(0);

					locationTokens = containerLocation.split("\\.");
					containerTierId = locationTokens[locationTokens.length - 1];
					containerRowId = locationTokens[locationTokens.length - 2];
					containerBayId = locationTokens[locationTokens.length - 3];
				}
			} else if (LOAD.equalsIgnoreCase(moveEvent.getMoveType())) {
				int noOfToLocations = moveEvent.getToLocations().size();
				if (noOfToLocations == 2) {
					containerLocation1 = moveEvent.getToLocations().get(0);
					containerLocation2 = moveEvent.getToLocations().get(1);

					locationTokens = containerLocation1.split("\\.");
					containerTierId = locationTokens[locationTokens.length - 1];
					containerRowId = locationTokens[locationTokens.length - 2];
					containerBayId = locationTokens[locationTokens.length - 3];

					String[] locationTokens2 = containerLocation2.split("\\.");
					String container2BayId = locationTokens2[locationTokens2.length - 3];

					String[] tierIds = new String[2];
					tierIds[0] = containerBayId;
					tierIds[1] = container2BayId;

					logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), preservedBayIdStr + Arrays.asList(tierIds));
					RDTPLCCacheManager.getInstance().addTwinIdsOfUser(moveEvent.getUserID(), tierIds);
				} else {
					containerLocation = moveEvent.getToLocations().get(0);

					locationTokens = containerLocation.split("\\.");
					containerTierId = locationTokens[locationTokens.length - 1];
					containerRowId = locationTokens[locationTokens.length - 2];
					containerBayId = locationTokens[locationTokens.length - 3];
				}
			}

			String location = containerBayId + "." + containerRowId + "." + containerTierId;

			RDTPLCCacheManager.getInstance().addCurrentCellLocationOfUser(moveEvent.getUserID(), location);

			String[] arrayOfRows = RDTVesselProfileCacheManager.getInstance().getBayRows(moveEvent.getUserID(),
					containerBayId, containerTierId);
			int indexOfRow = Arrays.asList(arrayOfRows).indexOf(containerRowId);

			RDTPLCCacheManager.getInstance().addUsersBaytoRowsMapping(moveEvent.getUserID(), arrayOfRows);
			RDTPLCCacheManager.getInstance().addQCUserstoPrevIndex(moveEvent.getUserID(), indexOfRow);

			String[] arrayOfTiers = RDTVesselProfileCacheManager.getInstance().getBayTiers(moveEvent.getUserID(),
					containerBayId);
			int indexOfTier = Arrays.asList(arrayOfTiers).indexOf(containerTierId);

			RDTPLCCacheManager.getInstance().addUsersBaytoTiersMapping(moveEvent.getUserID(), arrayOfTiers);
			RDTPLCCacheManager.getInstance().addQCUserstoPrevTierIndex(moveEvent.getUserID(), indexOfTier);

			RDTPLCCacheManager.getInstance().addQCUserstoPrevBay(moveEvent.getUserID(), containerBayId);

			RDTPLCCacheManager.getInstance().addUsertoFirstTimeMapping(moveEvent.getUserID(), false);
			RDTPLCCacheManager.getInstance().addMoveTypeOfUser(moveEvent.getUserID(), moveEvent.getMoveType());

			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved values After confirmation");
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "================================================");
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved Location :" + location);
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved Bay :"
					+ RDTPLCCacheManager.getInstance().getQCUserstoPrevBay(moveEvent.getUserID()));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved RowId's :" + Arrays.asList(arrayOfRows));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved Row Index :"
					+ RDTPLCCacheManager.getInstance().getQCUserstoPrevIndex(moveEvent.getUserID()));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved TierId's :" + Arrays.asList(arrayOfTiers));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved Tier Index :"
					+ RDTPLCCacheManager.getInstance().getQCUserstoPrevTierIndex(moveEvent.getUserID()));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "FirstTime flag After confirmation  :"
					+ RDTPLCCacheManager.getInstance().getFirstTimeMapping(moveEvent.getUserID()));
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Preserved Move Type :"
					+ RDTPLCCacheManager.getInstance().getMoveTypeOfUser(moveEvent.getUserID()));

		} catch (Exception ex) {
			logger.logException("Caught exception preservePLCPositionsForNextMove-", ex);
		}
	}

	/**
	 * Adds the General lift operations (Man cage/ Hatch cover/ Break bulk) to the completed moves
	 * 
	 * @param user
	 * @param moveEvent
	 * @param equipmentId
	 */
	private void updateCompletedJobsWithGeneralLiftOperation(User user, ContainerMoveEvent moveEvent, String equipmentId) {
		ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
				.getAllocationDetails(user.getUserID());

		Map<String, CompletedContainerMoves> completedMoves = RDTCacheManager.getInstance().getCompletedJobs(
				allocationEvent.getRotationID(), equipmentId);

		CompletedContainerMoves completedContainer = null;
		if (completedMoves != null) {
			completedContainer = completedMoves.get(moveEvent.getContainerIDs().get(0).concat(moveEvent.getMoveType()));
		}

		if (completedContainer == null) {
			completedContainer = new CompletedContainerMoves();
			completedContainer.setContainerId(moveEvent.getContainerIDs().get(0));
			completedContainer.setMoveType(moveEvent.getMoveType());
			completedContainer.setFromLocation(moveEvent.getFromLocations().get(0));
			completedContainer.setToLocation(moveEvent.getToLocations().get(0));
			completedContainer.setExceptionOccured("N");
			completedContainer.setIsAutomaticConfirmation(moveEvent.isAutomaticFlag() ? "Y" : "N");
			CONTAINER_MOVE_UTIL.saveToDatabase(user, allocationEvent.getRotationID(), completedContainer, equipmentId);
		} else {
			completedContainer.setToLocation(moveEvent.getToLocations().get(0));
			completedContainer.setFromLocation(moveEvent.getFromLocations().get(0));
			completedContainer.setIsAutomaticConfirmation("N");
			completedContainer.setIsSealOk(CONTAINER_MOVE_UTIL.getSealInfo(moveEvent.getSealOk(), 0,
					completedContainer.getContainerId(), moveEvent.getMoveType()));
			JournalEvent journal = new JournalEvent(completedContainer, UPDATETYPE.UPDATE);
			RDTProcessingServer.getInstance().getMasterActor().tell(journal, null);
		}

		RDTCacheManager.getInstance().addToCompletedJobs(completedContainer, user.getUserID(),
				allocationEvent.getRotationID(), equipmentId);
	}

	/**
	 * Constructs and sends the UpdateContainerLocationEvent to ESB
	 * 
	 * @param moveEvent
	 */
	private void updateJobPositionToESB(ContainerMoveEvent moveEvent) {
		UpdateContainerLocationEvent updateLocationEvent;
		String rotationId = null;
		ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
				.getAllocationDetails(moveEvent.getUserID());
		if (allocationDetails != null) {
			rotationId = allocationDetails.getRotationID();
		}

		CompletedContainerMoves completedMove;
		for (int index = 0; index < moveEvent.getContainerIDs().size(); index++) {
			updateLocationEvent = new UpdateContainerLocationEvent();
			updateLocationEvent.setContainerId(moveEvent.getContainerIDs().get(index));
			updateLocationEvent.setEquipmentID(moveEvent.getEquipmentID());
			updateLocationEvent.setEventID(UUID.randomUUID().toString());
			updateLocationEvent.setLocation(moveEvent.getToLocations().get(index));
			updateLocationEvent.setRotationId(rotationId);
			updateLocationEvent.setTerminalID(moveEvent.getTerminalID());
			updateLocationEvent.setUserID(moveEvent.getUserID());
			updateLocationEvent.setMoveType(moveEvent.getMoveType());
			
			completedMove = CONTAINER_MOVE_UTIL.getCompletedContainer(moveEvent.getContainerIDs().get(index), moveEvent.getUserID(),
					moveEvent.getEquipmentID(),moveEvent.getMoveType());
			if (completedMove != null) {
				updateLocationEvent.setSourceLocation(completedMove.getToLocation());
				updateLocationEvent.setVessel(completedMove.getVesselName());
				updateLocationEvent.setVoyage(completedMove.getVoyage());
			}

			ESBQueueManager.getInstance().postMessage(updateLocationEvent, OPERATOR.COMMON, moveEvent.getTerminalID());
		}
	}

	/*
	 * The method is responsible for validating the vessel location and yard location and send the response to UI
	 */
	private boolean checkValidMessage(ContainerMoveEvent moveEvent, OPERATOR operatorRole , String categeory) {
		boolean isValid = true;
		String toLocation;
		if (!moveEvent.isAutomaticFlag()) {
			try {
				String jobType = moveEvent.getContainerIDs().get(0);
				if (jobType.startsWith(HATCHCOVER) || jobType.startsWith(MANCAGE) || jobType.startsWith(BREAKBULK)) {
					logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "BACK REACH JOBS - skipping validation");
				} else {
					for (int i = 0; i < moveEvent.getToLocations().size(); i++) {

						toLocation = moveEvent.getToLocations().get(i);
						logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Validating the To  Location" + toLocation);
						if (LOAD.equalsIgnoreCase(moveEvent.getMoveType()) || ("S1".equalsIgnoreCase(categeory)) ) {

							if (GROUND.equals(toLocation) || BACKREACH.equalsIgnoreCase(toLocation)) {
								isValid = true;
							} else {
								String bayNo = toLocation.substring(0, 2);
								String rowNo = toLocation.substring(3, 5);
								String tierNo = toLocation.substring(toLocation.length() - 2);

								logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), " ToLocation:" + toLocation
										+ " bayNumber:" + bayNo + "RowNumber::" + rowNo + " Tier Number::" + tierNo);
								isValid = RDTVesselProfileCacheManager.getInstance().validateCell(
										moveEvent.getUserID(), bayNo, rowNo, tierNo);
							}
						} else if (DSCH.equals(moveEvent.getMoveType())) {
							if (GROUND.equals(toLocation) || BACKREACH.equalsIgnoreCase(toLocation)) {
								isValid = true;
							} else {
								String eqmtId = moveEvent.getEquipmentID();
								if (operatorRole.equals(OPERATOR.HC)) {
									eqmtId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
											moveEvent.getUserID());
								}
								isValid = CONTAINER_MOVE_UTIL.getValidITVLocation(toLocation, eqmtId);
							}
						}

						if (!isValid) {
							logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
									"Not the valid Cell / ITV /GROUND/ BACKREACH Locations.. Breaking");
							break;
						}
					}
				}
			} catch (Exception ex) {
				logger.logException("Caught exceptionw hile validating the toLocation", ex);
			}
		}
		return isValid;
	}
	
	public String getCategeoryFromJobList(ContainerMoveEvent moveEvent) {
		try {

			final String logId = moveEvent.getUserID().concat("-").concat(moveEvent.getEquipmentID());

			ListOrderedMap<String, JobListContainer> jobsListFromCache = RDTCacheManager.getInstance().getJobList(
					moveEvent.getUserID(), moveEvent.getEquipmentID());

			if (jobsListFromCache != null) {
				JobListContainer jobListCntr = jobsListFromCache.get(moveEvent.getContainerIDs().get(0)
						.concat(moveEvent.getMoveType()));

				if (jobListCntr != null) {
					logger.logMsg(LOG_LEVEL.INFO, logId, " Categeory Is::" + jobListCntr.getContainer().getCategory());
					return jobListCntr.getContainer().getCategory();
				} else {
					logger.logMsg(LOG_LEVEL.INFO, logId,
							" Current Container Not Available In JobList Cache,Returning Null");
				}
			} else {
				logger.logMsg(LOG_LEVEL.INFO, logId, " JobList Is Not Available For Current Logged In User...");
			}

		} catch (Exception e) {
			logger.logException("Caught exceprtion while retrieving categeory--", e);
		}
		
		return null;
	}
}
