package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details of the accident incident request from device
 * @author Rosemary George
 *
 */
public class AccidentIncidentRequestEvent extends Event implements Serializable {
	private static final long serialVersionUID = 5235388851919626268L;

	@Override
	public String toString() {
		return "AccidentIncidentRequestEvent [getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}	
}
