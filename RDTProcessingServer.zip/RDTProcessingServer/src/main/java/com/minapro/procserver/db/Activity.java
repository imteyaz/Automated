package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * <p> ValueObject holding the activity details. </p>
 * 
 * <p> The activity details are defined per terminal and can fall under operation or non-operational categories </p>
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_ACTIVITY_MASTER")
public class Activity extends Audit implements Serializable {

    private static final long serialVersionUID = -3095072587543376244L;

    @Id
    @Column(name = "ACTIVITY_ID", nullable = false)
    private String activityId;

    @Column(name = "DESCRIPTION")
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ACTIVITY_TYPE_ID", referencedColumnName = "ACTIVITY_TYPE_ID")
    private ActivityCategory activityType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TERMINAL_ID", referencedColumnName = "TERMINAL_ID")
    private Terminal terminalId;

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ActivityCategory getActivityType() {
        return activityType;
    }

    public void setActivityType(ActivityCategory activityType) {
        this.activityType = activityType;
    }

    public Terminal getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Terminal terminalId) {
        this.terminalId = terminalId;
    }
}
