package com.minapro.procserver.actors.common;

import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.events.common.VesselBerthSideResponseEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import akka.actor.UntypedActor;

/**
 * Actor class responsible for handling the VesselBerthSideResponseEvent coming from ESB. The berthing side of the
 * vessel is essential for QC PLC detection and hence it is stored into Cache.
 * 
 * @author Rosemary George
 *
 */
public class VesselBerthSideActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselBerthSideActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof VesselBerthSideResponseEvent) {
            VesselBerthSideResponseEvent vesselBerthSideResponse = (VesselBerthSideResponseEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, vesselBerthSideResponse.getUserID(), "Received VesselBerthSideEvent = "
                    + vesselBerthSideResponse);

            try {
                RDTVesselProfileCacheManager.getInstance().saveVesselBerthSide(vesselBerthSideResponse.getRotationId(),
                        vesselBerthSideResponse.getBerthSide());
            } catch (Exception ex) {
                logger.logException("Caught exception while handling the vesselBerthSideResponse", ex);
            }
        }
    }
}
