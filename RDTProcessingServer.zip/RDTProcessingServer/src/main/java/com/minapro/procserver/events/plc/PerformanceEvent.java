package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the QC Performance event details
 * 
 * @author Venkataramana.ch
 * 
 */

public class PerformanceEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8297353555323650681L;

    private int totalMoves;

    private double grossMovesPerHour;

    private int movesToGo;

    private int movesBehind;

    private double targetCompletionTime;

    private double targetMovesperHour;

    public int getTotalMoves() {
        return totalMoves;
    }

    public void setTotalMoves(int totalMoves) {
        this.totalMoves = totalMoves;
    }

    public double getGrossMovesPerHour() {
        return grossMovesPerHour;
    }

    public void setGrossMovesPerHour(double grossMovesPerHour) {
        this.grossMovesPerHour = grossMovesPerHour;
    }

    public int getMovesToGo() {
        return movesToGo;
    }

    public void setMovesToGo(int movesToGo) {
        this.movesToGo = movesToGo;
    }

    public int getMovesBehind() {
        return movesBehind;
    }

    public void setMovesBehind(int movesBehind) {
        this.movesBehind = movesBehind;
    }

    public double getTargetCompletionTime() {
        return targetCompletionTime;
    }

    public void setTargetCompletionTime(double targetCompletionTime) {
        this.targetCompletionTime = targetCompletionTime;
    }

    public double getTargetMovesperHour() {
        return targetMovesperHour;
    }

    public void setTargetMovesperHour(double targetMovesperHour) {
        this.targetMovesperHour = targetMovesperHour;
    }

    @Override
    public String toString() {
        return "PerformanceEvent [totalMoves=" + totalMoves + ", grossMovesPerHour=" + grossMovesPerHour
                + ", movesToGo=" + movesToGo + ", movesBehind=" + movesBehind + ", targetCompletionTime="
                + targetCompletionTime + ", targetMovesperHour=" + targetMovesperHour + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + "]";
    }
}
