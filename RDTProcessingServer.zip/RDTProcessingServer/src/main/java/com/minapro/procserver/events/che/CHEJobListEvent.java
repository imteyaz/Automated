package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;

public class CHEJobListEvent extends Event implements Serializable{
    private static final long serialVersionUID = 5488653592556588619L;

    /**
     * List of <Container> details fetched from DPW IT System
     */
    private List<JobListContainer> jobList;

    /**
     * Planned moves fetched from DPW IT System
     */
    private String plannedMoves;

    /**
     * Indicates whether the response is for the scheduled request
     */
    private boolean isScheduled;

    public List<JobListContainer> getJobList() {
        return jobList;
    }

    public void setJobList(List<JobListContainer> jobList) {
        this.jobList = jobList;
    }

    public String getPlannedMoves() {
        return plannedMoves;
    }

    public void setPlannedMoves(String plannedMoves) {
        this.plannedMoves = plannedMoves;
    }

    public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

    @Override
    public String toString() {
        return "CHEJobListEvent [jobList=" + jobList + ", plannedMoves=" + plannedMoves + ", isScheduled=" + isScheduled
                + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()="
                + getEventID() + "]";
    }
}
