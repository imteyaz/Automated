package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class LanguageChangeReqEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7226744844452186026L;

    private String modifiedLang;

    public String getModifiedLang() {
        return modifiedLang;
    }

    public void setModifiedLang(String modifiedLang) {
        this.modifiedLang = modifiedLang;
    }

    @Override
    public String toString() {
        return "LanguageChangeReqEvent [modifiedLang=" + modifiedLang + ", User Id=" + getUserID() + ", EquipmentID="
                + getEquipmentID() + ", TerminalID=" + getTerminalID() + "]";
    }
}
