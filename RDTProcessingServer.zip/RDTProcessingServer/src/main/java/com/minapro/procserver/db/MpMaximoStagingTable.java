package com.minapro.procserver.db;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * MpMaximoStagingTable entity. @author MyEclipse Persistence Tools
 */
/**
 * @author 3131663
 *
 */
@Entity
@Table(name = "MP_MAXIMO_STAGING_TABLE")
public class MpMaximoStagingTable implements java.io.Serializable {

    private static final long serialVersionUID = 4001868717187973376L;

    /*
     * Uniquely Identify each message/record in staging table
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "msg_id_sequnce")
    @SequenceGenerator(name = "msg_id_sequnce", sequenceName = "MP_MAXIMO_MESSAGE_ID_SEQ", allocationSize = 1)
    @Column(name = "MESSAGE_ID", nullable = false)
    private long messageId;

    // MAXIMO Error Code

    @Column(name = "PROBLEM_CODE", nullable = false)
    private String problemCode;

    // description of the problem
    @Column(name = "FAULT_DESCRIPTION", nullable = false)
    private String faultDescription;
    /*
     * ID of the source system which has created the record, this will help in future when multiple systems will start
     * interacting using this staging table.
     */
    @Column(name = "SOURCESYSTEM_ID", nullable = false)
    private String sourcesystemId;

    // Location where this break down has occurred Like Yard Location 16A or QC27
    @Column(name = "LOCATION_DESCRIPTION", nullable = false)
    private String locationDescription;

    // Asset ID to Uniquely Identify the equipment
    @Column(name = "ASSET_NUMBER", nullable = false)
    private String assetNumber;

    // Employee ID of the operator/ requester
    @Column(name = "OPERATOR_ID", nullable = false)
    private String operatorId;

    // Always should be EM – Emergency Maintenance as it is created by operational team
    @Column(name = "WORK_TYPE", nullable = false)
    private String workType;

    // Terminal for which breakdown has happened
    @Column(name = "TERMINAL_ID", nullable = false)
    private String terminalId;

    /*
     * While creating Work Order this field will be null, once record is picked from staging table by MAXIMO then
     * corresponding Work Order ID will be populated in this column
     */
    @Column(name = "WORKORDER_ID")
    private String workorderId;

    // Current status of Work Order
    @Column(name = "WORKORDER_STATUS")
    private String workorderStatus;

    // If the latest entry is to update the existing message then this field will be populated
    @Column(name = "REFERENCE_MESSAGE_ID")
    private String referenceMessageId;

    // Planned activity or Emergency
    @Column(name = "ACTIVITY_TYPE", nullable = false)
    private String activityType;

    //
    @Column(name = "CREATED_DTTM", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDttm;

    // NEW,READ,FAIL – status of the message
    @Column(name = "MESSAGE_STATUS", nullable = false)
    private String messageStatus;

    @Column(name = "LAST_UPDATED_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDttm;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    public long getMessageId() {
        return this.messageId;
    }

    public void setMessageId(long messageId) {
        this.messageId = messageId;
    }

    public String getProblemCode() {
        return this.problemCode;
    }

    public void setProblemCode(String problemCode) {
        this.problemCode = problemCode;
    }

    public String getFaultDescription() {
        return this.faultDescription;
    }

    public void setFaultDescription(String faultDescription) {
        this.faultDescription = faultDescription;
    }

    public String getSourcesystemId() {
        return this.sourcesystemId;
    }

    public void setSourcesystemId(String sourcesystemId) {
        this.sourcesystemId = sourcesystemId;
    }

    public String getLocationDescription() {
        return this.locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public String getAssetNumber() {
        return this.assetNumber;
    }

    public void setAssetNumber(String assetNumber) {
        this.assetNumber = assetNumber;
    }

    public String getOperatorId() {
        return this.operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getWorkType() {
        return this.workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public String getTerminalId() {
        return this.terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getWorkorderId() {
        return this.workorderId;
    }

    public void setWorkorderId(String workorderId) {
        this.workorderId = workorderId;
    }

    public String getWorkorderStatus() {
        return this.workorderStatus;
    }

    public void setWorkorderStatus(String workorderStatus) {
        this.workorderStatus = workorderStatus;
    }

    public String getReferenceMessageId() {
        return this.referenceMessageId;
    }

    public void setReferenceMessageId(String referenceMessageId) {
        this.referenceMessageId = referenceMessageId;
    }

    public String getActivityType() {
        return this.activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getMessageStatus() {
        return this.messageStatus;
    }

    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }

    public Date getCreatedDttm() {
        return createdDttm;
    }

    public void setCreatedDttm(Date createdDttm) {
        this.createdDttm = createdDttm;
    }

    public Date getLastUpdatedDttm() {
        return lastUpdatedDttm;
    }

    public void setLastUpdatedDttm(Date lastUpdatedDttm) {
        this.lastUpdatedDttm = lastUpdatedDttm;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @Override
    public String toString() {
        return "MpMaximoStagingTable [messageId=" + messageId + ", problemCode=" + problemCode + ", faultDescription="
                + faultDescription + ", sourcesystemId=" + sourcesystemId + ", locationDescription="
                + locationDescription + ", assetNumber=" + assetNumber + ", operatorId=" + operatorId + ", workType="
                + workType + ", terminalId=" + terminalId + ", workorderId=" + workorderId + ", workorderStatus="
                + workorderStatus + ", referenceMessageId=" + referenceMessageId + ", activityType=" + activityType
                + ", createdDttm=" + createdDttm + ", messageStatus=" + messageStatus + ", lastUpdatedDttm="
                + lastUpdatedDttm + ", lastUpdatedBy=" + lastUpdatedBy + "]";
    }
}