package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * 
 * @author Prasad.Tallapally
 *
 */
public class BayRowChangeNotifEvent extends Event implements Serializable {

    private static final long serialVersionUID = -2456243293596480271L;
    private String bayNo;
    private String rowNo;

    public String getBayNo() {
        return bayNo;
    }

    public void setBayNo(String bayNo) {
        this.bayNo = bayNo;
    }

    public String getRowNo() {
        return rowNo;
    }

    public void setRowNo(String rowNo) {
        this.rowNo = rowNo;
    }

}
