package com.minapro.procserver.queue;

import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQObjectMessage;

import akka.actor.ActorRef;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Terminal and operator specific EventListener for messages from communication server and ESB. </p>
 * 
 * <p> The message from communication server will be TextMessage and the message from ESB will be ObjectMessage. The
 * messages will be passed to the terminal specific actor system. </p>
 * 
 * @author Rosemary George
 *
 */
public class QueueEventListener implements MessageListener {
    private static final String LOG_PREFIX = "Received Message-";

    // Reference to the masterActor
    private ActorRef masterActor;
    private String terminal;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QueueEventListener.class);

    /**
     * Constructs the Operator specific EventListener and sets the actorSystem to the specified terminal.
     * 
     * @param terminal
     */

    public QueueEventListener() {
        this.terminal = DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY);
        masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    @Override
    /**
     * Receives messages from specified queue and pass the message to the specific actor system
     */
    public void onMessage(Message message) {
        try {
            // message is coming from Communication Server
            if (message instanceof TextMessage) {
                String event = ((TextMessage) message).getText();
                logger.logMsg(LOG_LEVEL.INFO, "", LOG_PREFIX + event);

                masterActor.tell(event, null);
            } else if (message instanceof ActiveMQObjectMessage) {
                // Message is coming from ESB
                ActiveMQObjectMessage objMessage = (ActiveMQObjectMessage) message;
                Event event = (Event) objMessage.getObject();

                if (event instanceof JobListEvent) {
                    logger.logMsg(LOG_LEVEL.TRACE, event.getUserID(), LOG_PREFIX + event);
                } else {
                    logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), LOG_PREFIX + event);
                }

                // set the terminal in case ESB didn't fill it - to be on the
                // safe side
                event.setTerminalID(terminal);

                masterActor.tell(event, null);
            } else {
                logger.logMsg(LOG_LEVEL.WARN, "", LOG_PREFIX + message);
            }
        } catch (JMSException e) {
            logger.logException("Caught exception while configuring Listeners - ", e);
        }
    }

}
