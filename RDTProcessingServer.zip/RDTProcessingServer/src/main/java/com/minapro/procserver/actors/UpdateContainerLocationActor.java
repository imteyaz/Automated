package com.minapro.procserver.actors;

import java.util.Map;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.events.UpdateContainerLocationResponseEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the updateContainerLocationResponseEvent coming from ESB.
 * If the update container location failed, the same is alerted to the operator through notification
 * 
 * @author Rosemary George
 *
 */
public class UpdateContainerLocationActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(UpdateContainerLocationActor.class);

	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof UpdateContainerLocationResponseEvent){
			UpdateContainerLocationResponseEvent responseEvent = (UpdateContainerLocationResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(),
					"Receieved update container location response -" + responseEvent);
			
			handleUpdateLocationResponse(responseEvent);
		}else {
			unhandled(message);
		}
	}

	/**
	 * Checks the response event status. If success, then the completed job is updated as no exception.
	 * Else, updates the completed job as exception job with error message received from the end system.
	 * 
	 * @param responseEvent
	 */
	private void handleUpdateLocationResponse(UpdateContainerLocationResponseEvent responseEvent) {
		try{
			
			ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(responseEvent.getUserID());

            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());
            // in case of HC, even though HC has confirmed the container move, use QC equipment ID as the completed
            // moves are recorded on QC equipment
            if (OPERATOR.HC.equals(role)) {
                responseEvent.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                        responseEvent.getUserID()));
            }
            
			 Map<String, CompletedContainerMoves> completedJobs = RDTCacheManager.getInstance().getCompletedJobs(
	                    allocationDetails.getRotationID(), responseEvent.getEquipmentID());

	            if (completedJobs != null) {
	                CompletedContainerMoves container = completedJobs.
	                		get(responseEvent.getContainerId().concat(responseEvent.getMoveType()));
	                if (container != null) {
	                    if (responseEvent.isStatus()) {
	                        logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Received success response for "
	                                + responseEvent.getContainerId());

	                        if ("Y".equals(container.getExceptionOccured())) {
	                            logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(),
	                                    "Correction on earlier exception job- marking it as resolved");
	                            container.setExceptionResolved("Y");

	                            JournalEvent journal = new JournalEvent(container, UPDATETYPE.UPDATE);
	                            getSender().tell(journal, null);
	                        }
	                    } else {
	                        logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Received failure response for "
	                                + responseEvent.getContainerId());

	                        sendAlertToDevice(responseEvent, responseEvent.getUserID(), role);

	                        if (role.equals(OPERATOR.QC)) {
	                            informCorrespondingHC(responseEvent);  
	                        } else if (role.equals(OPERATOR.HC)) {
	                            informCorrespondingQC(responseEvent);
	                        }

	                        container.setExceptionOccured("Y");
	                        container.setExceptionReason(responseEvent.getErrorMessage());
	                        JournalEvent journal = new JournalEvent(container, UPDATETYPE.UPDATE);
	                        getSender().tell(journal, null);
	                    }
	                }
	            }
		}catch(Exception ex){
			logger.logException("Caught exception while performing handleUpdateLocationResponse ", ex);
		}
		
	}

	  /**
     * Find the QC user signed in for the equipment, and sends the alert.
     * 
     * @param responseEvent
     */
    private void informCorrespondingQC(UpdateContainerLocationResponseEvent responseEvent) {
        String qcUserId = EventUtil.getInstance().getQcUserId(responseEvent.getUserID());
        if (qcUserId != null) {
            boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(qcUserId);
            if (inspectionStatus) {
                sendAlertToDevice(responseEvent, qcUserId, OPERATOR.QC);
            }
        }
    }

    /**
     * Finds the HC user signed in for the equipment and sends the alert
     * 
     * @param responseEvent
     */
    private void informCorrespondingHC(UpdateContainerLocationResponseEvent responseEvent) {
        String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(responseEvent.getEquipmentID());
        if (hcUser != null) {
            boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
            if (inspectionStatus) {
                sendAlertToDevice(responseEvent, hcUser, OPERATOR.HC);
            }
        }
    }

    /**
     * Construct the alert message and sends to the user specified.
     * 
     * @param responseEvent
     * @param userId
     * @param role
     */
    private void sendAlertToDevice(UpdateContainerLocationResponseEvent responseEvent, String userId, OPERATOR role) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.CONTAINER_MOVE_RESPONSE);
        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.NOTIF).append(VALUE_SEPARATOR)
                .append(eventTypeID);
        responseToDevice.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
                .append(responseEvent.getContainerId()).append(VALUE_SEPARATOR).append(responseEvent.getErrorMessage())
                .append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR).append(responseEvent.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                responseEvent.getTerminalID());
    }
}
