package com.minapro.procserver;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.concurrent.TimeUnit;

import com.minapro.procserver.queue.OPERATOR;

/**
 * Public interface exposed to slave nodes to check the health of the master node
 * 
 * @author Rosemary George
 *
 */
public interface ReceiveMessageInterface extends Remote {
    /**
     * Starts the PLC scheduler for the specified operator role. It can be either QC or RMG
     * 
     * @param role
     *            - QC/RMG
     * @return true/false indicating whether the operation is succeeded
     * @throws RemoteException
     */
    boolean startPLC(String role) throws RemoteException;

    /**
     * Stops the PLC scheduler for the specified operator role. It can be either QC or RMG
     * 
     * @param role
     *            - QC/RMG
     * @return true/false indicating whether the operation is succeeded
     * @throws RemoteException
     */
    boolean stopPLC(String role) throws RemoteException;

    /**
     * Heart beat message to check the status of the master node
     * 
     * @return
     * @throws RemoteException
     */
    boolean checkMasterStatus() throws RemoteException;

    /**
     * Restarts the job list scheduler with the mentioned frequency
     * 
     * @param initialDelay
     * @param frequencyInterval
     * @param unit
     * @return
     * @throws RemoteException
     */
    boolean restartJobListScheduler(int initialDelay, int frequencyInterval, TimeUnit unit, OPERATOR role) throws RemoteException;

    /**
     * Restarts the planned moves scheduler with the mentioned frequency
     * 
     * @param initialDelay
     * @param frequencyInterval
     * @param unit
     * @return
     * @throws RemoteException
     */
    boolean restartPlannedMovesScheduler(int initialDelay, int frequencyInterval, TimeUnit unit) throws RemoteException;   
}