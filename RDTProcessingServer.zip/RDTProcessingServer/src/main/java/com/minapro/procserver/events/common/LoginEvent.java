package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding all information related to Login Event
 * 
 * @author Rosemary George
 *
 */
public class LoginEvent extends Event implements Serializable {
    private static final long serialVersionUID = -2057316544537187204L;

    /**
     * Encrypted password received from the device
     */
    private String password;
    /**
     * The ID of the device which sent the request
     */
    private String deviceID;

    /**
     * Indicates the role which the user is logging in as
     */
    private String role;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "LoginEvent [deviceID=" + deviceID + ", UserID=" + getUserID()
                + ", TerminalID=" + getTerminalID() + "]";
    }
}
