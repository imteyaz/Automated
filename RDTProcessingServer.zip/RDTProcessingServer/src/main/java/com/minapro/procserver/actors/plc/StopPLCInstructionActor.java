package com.minapro.procserver.actors.plc;

import java.util.Date;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.plc.StopPLCInstructionEvent;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class StopPLCInstructionActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(StopPLCInstructionActor.class);

    @Override
    /**
     * Handles General Lift Operation event
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof StopPLCInstructionEvent) {
        	StopPLCInstructionEvent plcSubscription = (StopPLCInstructionEvent) message;

            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(plcSubscription.getUserID());
            PLCEventUtil.getInstance().initializePlcData(plcSubscription.getUserID(), plcSubscription.getEquipmentID(), new Date(), role);
            
            if ("true".equalsIgnoreCase(plcSubscription.getSubscribe())) {
                logger.logMsg(LOG_LEVEL.DEBUG, "",
                        "adding user entry to PLC unsubscription list :" + plcSubscription.getUserID());
                RDTPLCCacheManager.getInstance().addStopPLCCacheDetails(plcSubscription.getUserID(), true);                
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, "",
                        "removing user entry to PLC unsubscription list :" + plcSubscription.getUserID());
                RDTPLCCacheManager.getInstance().removeStopPLCCacheDetails(plcSubscription.getUserID());
            }            
        }
    }
}
