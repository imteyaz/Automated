package com.minapro.procserver.actors;

import java.util.List;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TroubleShootRecord;
import com.minapro.procserver.db.UserActivityRecord;
import com.minapro.procserver.db.bayprofile.BerthedVessel;
import com.minapro.procserver.events.KeepAliveRequestEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.queue.AdminNotificationListener;
import com.minapro.procserver.util.TroubleShootStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Singlton actor which is executed at the start up of the master node to load all the master data from the database and
 * also all the berthed vessels in database.
 * 
 * @author Rosemary George
 *
 */
public class InitSingletonActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(InitSingletonActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof String) {
            String event = (String) message;

            if ("init".equalsIgnoreCase(event)) {
            	getKeepAliveStatus();
                loadMasterDataToCache();
                loadBerthedVesselDetails();
                //loadTroubleshootRecords();
                sendForceLogoutToExistingUsers();                
            }
        }
    }

    /**
     * Construct keep alive request event and send to ESB to get the TOS heart beat status
     */
    private void getKeepAliveStatus() {
    	KeepAliveRequestEvent requestEvent = new KeepAliveRequestEvent();
    	requestEvent.setEventID(UUID.randomUUID().toString());
    	RDTProcessingServer.getInstance().getMasterActor().tell(requestEvent, null);
				
	}

	/**
     * Load the troubleshoot records which are pending/in progress state or it was completed the current day and updates
     * the cache
     */
    private void loadTroubleshootRecords() {
        List<TroubleShootRecord> troubleshootRecords = (List<TroubleShootRecord>) HibernateUtil
                .retrieveTroubleShootRecords();
        if (troubleshootRecords != null) {
            for (TroubleShootRecord record : troubleshootRecords) {
                if (record.getStatus().equalsIgnoreCase(TroubleShootStatus.PENDING.toString())
                        || record.getStatus().equalsIgnoreCase(TroubleShootStatus.IN_PROGRESS.toString())) {
                    RDTCacheManager.getInstance().addTroubleshootRequests(record);
                } else {
                    RDTCacheManager.getInstance().addToCompletedTroubleShootRecords(record);
                }
            }
        }
    }

    /**
     * Retrieves all berthed vessels from the database and forwards to the master actor.
     */
    @SuppressWarnings("unchecked")
    private void loadBerthedVesselDetails() {
        List<BerthedVessel> berthedVesselList = (List<BerthedVessel>) HibernateUtil.loadMasterData(BerthedVessel.class,
                null, false);
        if (berthedVesselList != null) {
            for (BerthedVessel vesselInfo : berthedVesselList) {
                logger.logMsg(LOG_LEVEL.INFO, "", "Loading the vessel berth details for vessel:" + vesselInfo);
                RDTProcessingServer.getInstance().getMasterActor().tell(vesselInfo, null);
            }
        }
    }

    /**
     * <p>Loads all the master data present in MinaPro DB to the cache.</p>
     * 
     * <p>Master data involves </p> <p>- User </p> <p>- Device</p> <p>- Equipment</p> <p>- Activity</p> <p>- Pinning
     * Station</p> <p>- Delay Reason Code</p> <p>- QC Lane</p> <p>- CheckList</p> <p>- ColourCode</p>
     */
    private boolean loadMasterDataToCache() {
        try {
            AdminNotificationListener.reloadPinningStationDetails();
            AdminNotificationListener.reloadQCLaneDetails();
            AdminNotificationListener.reloadUsers();
            AdminNotificationListener.reloadCheckLists();
            AdminNotificationListener.reloadColourCodes();
            AdminNotificationListener.reloadDeviceDetails();
            AdminNotificationListener.reloadEquipmentDetails();
            AdminNotificationListener.reloadDelayReasonCodes();
            AdminNotificationListener.reloadActivityDetails();
            AdminNotificationListener.reloadApplicationParameter();
            AdminNotificationListener.reloadTroubleShootAreaDetails();
            AdminNotificationListener.reloadShiftDetails();
            AdminNotificationListener.reloadCHEWeightageFactorDetails();
            AdminNotificationListener.reloadISOCodesDetails();

            // Fetching records from MP_USER_ACTIVITY table to avoid issues in case of Server restart
            HibernateUtil.populateUserActivityCache();
        } catch (Exception ex) {
            logger.logException("Failed to load Master data - Caught exception:", ex);
            return false;
        }

        return true;
    }

    private void sendForceLogoutToExistingUsers() {

        List<UserActivityRecord> listOfLoggedInUsers = HibernateUtil.currenlyLoggedInUsers();

        logger.logMsg(LOG_LEVEL.WARN, "", "List of Users Logged in before Restart : - " + listOfLoggedInUsers);

        for (UserActivityRecord entry : listOfLoggedInUsers) {

            try {
                LogoutEvent logoutEvent = new LogoutEvent();
                String userId = entry.getUser().getUserID();

                logoutEvent.setUserID(userId);
                logoutEvent.setEquipmentID(entry.getEquipmentID());
                RDTCacheManager.getInstance().setUserLoggedInRole(userId, entry.getRole());
                RDTPLCCacheManager.getInstance().addLoginTimeforUser(userId, entry.getLoginDatetime());

                AdminNotificationListener.handleAdminForceLogOut(logoutEvent);

            } catch (Exception ex) {
                logger.logException("Caught exception while handling the serverRestart Logout -", ex);
            }

        }

    }
}
