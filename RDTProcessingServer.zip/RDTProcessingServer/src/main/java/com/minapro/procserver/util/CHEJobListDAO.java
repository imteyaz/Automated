package com.minapro.procserver.util;

import static com.minapro.procserver.db.opus.queries.OPUSJobListQueries.OPUS_CHE_JOBS_RETRIEVAL_QUERY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.opus.queries.OPUSJobListQueries;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class CHEJobListDAO {

	private MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobListDAO.class);

	private static final CHEJobListDAO INSTANCE = new CHEJobListDAO(); 
	
	private static final String IGNORE_MOVE_TYPES="IGNORE_MOVE_TYPES";
	
	private CHEJobListDAO(){

	}

	public static CHEJobListDAO getInstance(){
		return INSTANCE;
	}

	@SuppressWarnings("unchecked")
	public List<TwinTandemContainerList> getTwinTandemContainerList(Class<?> className){
		List<TwinTandemContainerList> twinTandemContainerList = null;
		try{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = session.beginTransaction();
			twinTandemContainerList = session.createCriteria(className.getName()).list();
			tx.commit();
		}catch(Exception ex){
			logger.logException(" Exception Occured While Retrieving TwinTandemContainerList Values Reason::", ex);
		}
		return twinTandemContainerList;
	}

	
	@SuppressWarnings("unchecked")
	public List<Object[]> getCHEJobListFromDatabase(String equipmentId,int completedJobsRetrievalTime) throws SQLException , NullPointerException{

		logger.logMsg(LOG_LEVEL.TRACE, equipmentId, " Started getCHEJobListFromDatabase To Get Records From MP_CHE_JOB_LIST table"); 

		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createSQLQuery(OPUS_CHE_JOBS_RETRIEVAL_QUERY);
		
		String ignorableMoveTypes = DeviceCommParameters.getInstance().getCommParameter(IGNORE_MOVE_TYPES);
		 
		 logger.logMsg(LOG_LEVEL.INFO,equipmentId," Ignorable Move Types:::"+ignorableMoveTypes);
		
		 List<String> ignorableCompletedJobMoveTypes  = new ArrayList<String>(Arrays.asList(ignorableMoveTypes.split(",")));
		
		query.setParameter("equipmentId",equipmentId);
		query.setParameterList("ignorableMoveTypes", ignorableCompletedJobMoveTypes).list();
		List<Object[]> finalData = query.list();
		tx.commit();
		return finalData;
	}
	
	@SuppressWarnings("unchecked")
	public List<TwinTandemJobs> getTwinTandemJobs(Class<?> className , String minaproTwinSplit){
		List<TwinTandemJobs> twinTandemJobs = null;
		try{
			Session session = HibernateUtil.getSessionFactory().getCurrentSession();
			Transaction tx = session.beginTransaction();
			Criteria cr = session.createCriteria(className.getName());
			cr.add(Restrictions.eq("twinSplit", minaproTwinSplit));
			twinTandemJobs =  cr.list();
			logger.logMsg(LOG_LEVEL.TRACE, "", "Twin Tandem Jobs::"+twinTandemJobs);
			tx.commit();
		}catch(Exception ex){
			logger.logException(" Exception Occured While Retrieving TwinTandemContainerList Values Reason::", ex);
		}
		return twinTandemJobs;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object[]> getArrivedITVSDetailsAtBlock(String isJobCompleted){

		List<Object[]> arrivedITVS = null;
		Session session=null;
		Transaction tx = null;

		try {
			session = HibernateUtil.getSessionFactory().getCurrentSession();
			if(session!=null) {
				tx = session.beginTransaction();
				arrivedITVS = session.createSQLQuery(OPUSJobListQueries.GET_ARRIVED_ITVS_DETAILS_AT_BLOCK).
						setParameter("isJobCompleted",isJobCompleted).list();
				logger.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Arrived ITVS Count Is::").append(arrivedITVS!=null ? arrivedITVS.size() : 0).toString());
				tx.commit();
			}
		} catch (Exception e) {
			if(session!=null && session.isOpen()) {
				session.getTransaction().rollback();
				session.close();
			}
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Retrieving Arrived ITVS Details From DB.")
					.append(REASON).toString(), e);
		} 
		return arrivedITVS;
	}
	
}
