package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the cancel job selection request from UI. 
 * In case of Twin/Tandem containers, the first container will be sent as cancelled. 
 * But all the containers part of the TWIN/TANDEM is considered as cancelled.
 * 
 * @author Rosemary George
 *
 */
public class CancelJobSelectionEvent extends Event implements Serializable{

	private static final long serialVersionUID = 6645300432055106594L;

	private String containerId;
	
	private String moveType;

	private List<String> jobKey;
	
	public List<String> getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		List<String> jobKeys = new ArrayList<String>();
		jobKeys.add(jobKey);
		this.jobKey =jobKeys;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	@Override
	public String toString() {
		return "CancelJobSelectionEvent [containerId=" + containerId + ", moveType=" + moveType + ", getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + " , jobKey = "+jobKey + "]";
	}
}
