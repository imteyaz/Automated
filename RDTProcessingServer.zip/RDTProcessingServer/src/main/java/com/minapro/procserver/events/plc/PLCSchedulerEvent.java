package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class PLCSchedulerEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3290479474887805211L;

    private String instruction;

    private String operator;

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    @Override
    public String toString() {
        return "PLCSchedulerEvent [instruction=" + instruction + ", operator=" + operator + "]";
    }

}
