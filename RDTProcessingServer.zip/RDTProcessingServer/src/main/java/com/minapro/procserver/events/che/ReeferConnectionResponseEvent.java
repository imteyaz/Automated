package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

public class ReeferConnectionResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 3118823267310432551L;

    private List<ReeferWithStatusEvent> reeferContainersList;

    public List<ReeferWithStatusEvent> getReeferContainersList() {
        return reeferContainersList;
    }

    public void setReeferContainersList(List<ReeferWithStatusEvent> reeferContainersList) {
        this.reeferContainersList = reeferContainersList;
    }

    @Override
    public String toString() {
        return "ReeferConnectionResponseEvent [reeferContainersList=" + reeferContainersList + "]";
    }

}
