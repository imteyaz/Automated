package com.minapro.procserver.events.common;

import java.io.Serializable;
import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the log out response status from TOS
 * @author Rosemary George
 *
 */
public class LogoutResponseEvent extends Event implements Serializable{
	
	private static final long serialVersionUID = -657085060492802440L;
	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "LogoutResponseEvent [status=" + status + ", getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getTerminalID()=" + getTerminalID() + ", getEventID()="
				+ getEventID() + "]";
	}
}
