package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.OPERATOR_IN_BREAK;

import java.util.Set;
import java.util.UUID;

import scala.collection.mutable.StringBuilder;
import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS;
/**
 * <p>Actor responsible for sending JobListRequest for all logged in users to the ESB.</p>
 * 
 * <p>The Actor will be invoked by a scheduler every few seconds. When invoked, the actor will identify all the logged
 * in users and sends job list request for each user to ESB for retrieving the job list updates for the users.</p>
 *
 * @author Rosemary George
 *
 */
public class JobListPollingActor extends UntypedActor {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(JobListPollingActor.class);
	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.TERMINAL_KEY);

	@Override
	public void onReceive(Object message) throws Exception {

		if(RDTCacheManager.getInstance().getKeepAliveStatus()){
			try {
				// look for all users who have confirmed allocations
				RDTCacheManager rdtCacheManager = RDTCacheManager.getInstance();
				Set<String> userList = rdtCacheManager.getAllocatedUsers();
	
				logger.logMsg(LOG_LEVEL.INFO, " ", "List of Users Logged In : " + userList);
	
				String deviceId;
				User user;
				if (userList != null && !userList.isEmpty()) {	
					for (String userId : userList) {	
						if (!rdtCacheManager.isOperatorAvailable(userId)) {
							logger.logMsg(LOG_LEVEL.INFO, userId, OPERATOR_IN_BREAK);
							continue;
						}
	
						OPERATOR operator = rdtCacheManager.getUserLoggedInRole(userId);	
						if (operator.equals(OPERATOR.QC) || operator.equals(OPERATOR.HC)) {	
							deviceId = rdtCacheManager.getDeviceMapping(userId);
	
							if (deviceId != null) {
								Device device = rdtCacheManager.getDeviceDetails(deviceId);
								user = rdtCacheManager.getUserDetails(userId);
								if (operator.equals(OPERATOR.QC)) {
									logger.logMsg(LOG_LEVEL.INFO, userId, "Current Opertaor Is " + operator);
									if (device != null) {
										sendJobListRequest(device, user);
									}
								} else if (operator.equals(OPERATOR.HC)) {
									logger.logMsg(LOG_LEVEL.INFO, userId,
											"Current Opertaor Is HC, checking the corresponding QC status");
									checkQCStatusAndSendJobListRequest(device, user);
								} 
							}	
						} 
					}
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, "", "Currently there is no logged in users");
				}
			} catch (Exception ex) {
				logger.logException("Caught exception while polling :", ex);
			}
		} else {
			logger.logMsg(LOG_LEVEL.WARN, "", "Keep alive status is DOWN. Not sending job list polling request");
		}
	}

	/**
	 * Checks the associated QC login status and if the QC is not logged in, sends the job list request from HC
	 * 
	 * @param device
	 * @param user
	 */
	private void checkQCStatusAndSendJobListRequest(Device device, User user) {
		if (device != null) {
			String qcUserId = EventUtil.getInstance().getQcUserId(user.getUserID());
			if (qcUserId != null) {
				boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(qcUserId);
				if (inspectionStatus) {
					logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Associated QC " + qcUserId
							+ " is logged in, no need to send joblist");
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Associated QC " + qcUserId
							+ " is logged in, but not yet completed ispection, Sending joblist request for HC");
					sendJobListRequest(device, user);
				}
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Associated QC " + qcUserId
						+ " is not logged in, Sending joblist request for HC");
				sendJobListRequest(device, user);
			}
		} else {
			logger.logMsg(LOG_LEVEL.INFO,user.getUserID()," Device Is Null,Check User Device Mapping;");
		}
	}

	/**
	 * Constructs the JobListRequestEvent and sends it to ESB
	 * 
	 * @param device
	 * @param user
	 */
	private void sendJobListRequest(Device device, User user) {

		Equipment equipment = device.getEquipment();

		if (equipment != null) {
			String userId = user.getUserID();
			String equipmentId = equipment.getEquipmentID();

			String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(userId);
			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);

			if (inspectionStatus != null) {

				/*
				 * Condition added to check whether current equipment job list request is in progress stage or not. If
				 * it is in progress stage Ignore current refresh for current equipment.
				 */
				
				if (EventUtil.isEquipmentJobListReqInProgress(operatorRole.equals(OPERATOR.HC) ? RDTCacheManager.getInstance().
						getQCEquipmentAllocatedForHC(userId):equipmentId)) {
					logger.logMsg(LOG_LEVEL.WARN, userId,new StringBuilder(equipmentId).append(
									EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS).toString());
					return;
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, userId,new StringBuilder(equipmentId).append(EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS).toString());
					/*
					 * If Current Operator role is HC , Retrieve corresponding QC Equipment Id.
					 */
					RDTCacheManager.getInstance().setEqJobListReqStatus(operatorRole.equals(OPERATOR.HC) ? RDTCacheManager.getInstance().
							getQCEquipmentAllocatedForHC(userId):equipmentId,EquipmentJobListRequestStatus.IN_PROGRESS);
				}
				logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Sending joblist request");

				JobListRequestEvent requestEvent = new JobListRequestEvent();
				requestEvent.setEquipmentID(equipment.getEquipmentID());
				requestEvent.setUserID(userId);
				requestEvent.setTerminalID(TERMINAL_ID);
				requestEvent.setEventID(UUID.randomUUID().toString());
				requestEvent.setScheduled(true);

				ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
						.getAllocationDetails(userId);
				requestEvent.setLocation(allocationDetails.getLocation());

				requestEvent.setRotationId(allocationDetails.getRotationID());
				requestEvent.setPassword(user.getPassword());

				if (operatorRole.equals(OPERATOR.HC)) {
					requestEvent.setQcId(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(userId));
				}
				ESBQueueManager.getInstance().postMessage(requestEvent, operatorRole, TERMINAL_ID);
				
				//request for ITV pool for the equipment along with job list as the assigned ITV pool can be changed any time for an equipment
				EventUtil.getInstance().requestITVpool(requestEvent, operatorRole);
			}
		} else {
			logger.logMsg(LOG_LEVEL.INFO, user.getUserID(),
					"Skipping JobList poll as pre-operational inspection is not completed.");
		}
	}
}
