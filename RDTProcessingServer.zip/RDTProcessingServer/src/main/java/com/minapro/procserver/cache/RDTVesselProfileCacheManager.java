package com.minapro.procserver.cache;

import static com.minapro.procserver.util.QCPLCConstants.STAR_BORD_SIDE;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.infinispan.Cache;

import com.minapro.procserver.cache.CellGrid.MOVE_TYPE;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.bayprofile.ColourCode;
import com.minapro.procserver.db.bayprofile.TemplateHeader;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.common.BayProfileContainer;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Singleton class containing all the cache related to the vessel profile. </p>
 * 
 * @author Rosemary George
 *
 */
public class RDTVesselProfileCacheManager {

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTVesselProfileCacheManager.class);
    /**
     * <p>Bay to section Mapping. A section can contain more than one bay. </p> VesselCode.BayId.deckIndication is the
     * key and provides sectionId
     */
    private Cache<String, String> baySectionMapping = RDTCacheContainer.getCache("BaySectionMapppingCache");

    /**
     * <p> Set of BayProfiles associated with section. A section can contain more than one bay. </p> Stores
     * VesselCode:sectionID as the key and Set of BayProfile Objects as value
     */
    private Cache<String, Map<String, BayProfile>> sectBayProfile = RDTCacheContainer
            .getCache("SectionBayProfileCache");

    /**
     * List of vessels currently berthed on the terminal - vesselId is the key
     */
    private Cache<Integer, Vessel> berthedVesselList = RDTCacheContainer.getCache("BerthedVesselList");

    /**
     * Maps the Vessel Rotation to the vessel No - rotationId is the key
     */
    private Cache<String, String> rotationToVesselCodeMapping = RDTCacheContainer
            .getCache("RotationToVesselCodeMappingCache");

    /**
     * Holds the colour codes available in the master DB. - ItemName is the key
     */
    private Cache<String, ColourCode> colourCodeMap = RDTCacheContainer.getCache("ColourCodeCache");

    /**
     * Holds the vessel berthing side information - rotation ID is the key
     */
    private Cache<String, String> vesselBerthSideMap = RDTCacheContainer.getCache("VesselBerthSideCache");

    /**
     * Holds the QCs allocated for the rotation - rotationId is the key
     */
    private Cache<String, List<String>> rotationToQcMapping = RDTCacheContainer.getCache("RotationToQCCache");

    /**
     * Holds the list of rotations allocated for a QC- QC equipmentId is the key
     */
    private Cache<String, List<String>> qcToRotationMapping = RDTCacheContainer.getCache("QCToRotationCache");

    /**
     * Holds the list of templates available for defining vessel profile - TemplateHeader Id is the key
     */
    private Cache<String, TemplateHeader> templateMap = RDTCacheContainer.getCache("VesselTemplateCache");

    /**
     * Holds the list of ROB containers per rotation - RotationID is the key
     */
    private Cache<String, List<String>> robContainerMap = RDTCacheContainer.getCache("RobContainerListCache");
    
    /**
     * Holds the containerMoveEvents waiting for the toLocation update status from TOS - eventId is the key
     */
    private Cache<String, ContainerMoveEvent> pendingContainerMoveMap = RDTCacheContainer.getCache("PendingContainerMoveCache");
    
    /**
     * Holds the heavy hook users per rotation - rotationId is the key
     */
    private Cache<String, String> heavyHookUsersMap = RDTCacheContainer.getCache("PendingContainerMoveCache");

    private static final RDTVesselProfileCacheManager INSTANCE = new RDTVesselProfileCacheManager();

    private RDTVesselProfileCacheManager() {
    }

    /**
     * Gives the instance of RDTVesselProfileCacheManager
     * 
     * @return
     */
    public static RDTVesselProfileCacheManager getInstance() {
        return INSTANCE;
    }

    /**
     * Gives the vessel berth side (P for PortSide, S for starboard side) for the specified rotation ID
     * 
     * @param rotationId
     * @return
     */
    public String getVesselBerthSide(String rotationId) {
        return vesselBerthSideMap.get(rotationId);
    }

    /**
     * Saves the vessel berthing side details to the cache
     * 
     * @param rotationId
     * @param berthSide
     */
    public void saveVesselBerthSide(String rotationId, String berthSide) {
        vesselBerthSideMap.put(rotationId, berthSide);
    }

    /**
     * Removes the vessel berthing side details from the cache
     * 
     * @param rotationId
     */
    public void removeVesselBerthSide(String rotationId) {
        vesselBerthSideMap.remove(rotationId);
    }

    /**
     * Saves the berthed vessel to the cache
     * 
     * @param vessel
     */
    public void addVesselToBerthedList(Vessel vessel) {
        logger.logMsg(LOG_LEVEL.DEBUG, "", "Adding vessel to cache-" + vessel);
        berthedVesselList.put(vessel.getVesselNo(), vessel);
    }

    /**
     * Retrieves the list of vessels currently berthed on the port
     * 
     * @return
     */
    public Set<Vessel> getBerthedVesselList() {
        Set<Vessel> berthedList = new HashSet<Vessel>();

        for (Integer vesselNo : berthedVesselList.keySet()) {
            berthedList.add(berthedVesselList.get(vesselNo));
        }

        return berthedList;
    }

    /**
     * Removes the specified vessel from the berthed vessel list in Cache.
     * 
     * @param vessel
     */
    public void removeVesselFromBerthedList(Vessel vessel) {
        berthedVesselList.remove(vessel.getVesselNo());
    }

    /**
     * Returns the Vessel information for the specified vesselCode
     * 
     * @param vesselCode
     * @return
     */
    public Vessel getVesselFromBerthedList(String vesselCode) {
    	Integer vesselNo = Integer.valueOf(vesselCode);
    	logger.logMsg(LOG_LEVEL.DEBUG, vesselNo.toString(), "Current BerthedVessels - " + berthedVesselList.keySet().toString());
        return berthedVesselList.get(vesselNo);
    }

    /**
     * Adds the bay profiles associated with a particular section to the SectionBayProfile Cache.
     * 
     * @param vesselCode
     * @param sectionNo
     * @param bayProfiles
     */
    public void addSectionDetails(String vesselCode, int sectionNo, Map<String, BayProfile> bayProfiles) {
        this.sectBayProfile.put(vesselCode + ":" + sectionNo, bayProfiles);
    }

    /**
     * Retrieves all the baySection mapping keys available in the cache
     * 
     * @return baySectionMap key set
     */
    public Set<String> getBaySectionMapKeySet() {
        return this.baySectionMapping.keySet();
    }

    /**
     * Removes the bay to section mapping for the specififed bayId from the cache
     * 
     * @param bayId
     */
    public void removeBaySectionMapping(String bayId) {
        this.baySectionMapping.remove(bayId);
    }

    /**
     * Retrieves all the section to bay profile mapping keys available in cache
     * 
     * @return sectionToBayProfile key set
     */
    public Set<String> getSectionBayProfileKeySet() {
        return this.sectBayProfile.keySet();
    }

    /**
     * Removes the bay profile to section mapping from the cache for the specified section id
     * 
     * @param sectionId
     */
    public void removeSectionBayProfileMapping(String sectionId) {
        this.sectBayProfile.remove(sectionId);
    }

    /**
     * <p>Maps the specified bay to a particular section of the vessel.</p>
     * 
     * <p>The key is formed with the 3 attributes - vessel code, bay no and under deck indication. This is necessary
     * because same bay can be present in two different section based on the deck/under deck.</p>
     * 
     * @param vesselCode
     * @param bayId
     * @param deckIndication
     * @param sectionNo
     */
    public void mapBayToSection(String vesselCode, String bayId, String deckIndication, int sectionNo) {
        this.baySectionMapping.put(vesselCode + ":" + bayId + ":" + deckIndication, vesselCode + ":" + sectionNo);
    }

    /**
     * <p> Retrieves the section code associated with the bayNo. </p>
     * 
     * <p>The key is formed with the 3 attributes - vessel code, bay no and under deck indication. This is necessary
     * because same bay can be present in two different section based on the deck/under deck.</p>
     * 
     * <p> If the bayId is even number, it is a logical bay and the physical bay will be bayId-1 and bayId+1. The
     * physical bay (bayId-1) is used to identify the section. </p>
     * 
     * @param vesselCode
     * @param bayId
     * @param deckIndication
     * @return SectionID
     */
    public String getAssociatedSection(String vesselCode, String bayId, String deckIndication) {
        String sectNo = this.baySectionMapping.get(vesselCode + ":" + bayId + ":" + deckIndication);
        String physicalBay;
        if (sectNo == null) {
            physicalBay = getPhysicalBayNo(bayId);
            sectNo = this.baySectionMapping.get(vesselCode + ":" + physicalBay + ":" + deckIndication);
        }

        return sectNo;
    }

    /**
     * Retrieves the bay profiles associated with specified sectionNo. Can have more than one or more bays per section.
     * 
     * @param sectionNo
     * @return Map<bayNo,BayProfile>
     */
    public Map<String, BayProfile> getBayProfiles(String sectionNo) {
        return this.sectBayProfile.get(sectionNo);
    }

    /**
     * <p>Retrieves the container present on the specified bayNo.rowNo.tierNo.</p>
     * 
     * <p> The vessel rotation ID is retrieved from the cache by checking the allocation details for the specified user.
     * Then the corresponding bay profile is retrieved from the Vessel Profile. And if the bay.row.tier combination
     * contains Container details, the same is returned. Else null value is returned.</p.>
     * 
     * @param userId
     * @param bayNo
     * @param rowNo
     * @param tierNo
     * @param moveType
     *            - can be either LOAD or DSCH
     * @return Container
     */
    public Container getContainerFromCell(String userId, String bayNo, String rowNo, String tierNo, String moveType) {
        Container container = null;
        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);

            String vesselCode = getVesselCode(allocation.getRotationID());
            if (vesselCode != null) {
                String physicalBay = getPhysicalBayNo(bayNo);
                String deck = EventUtil.getInstance().findDeckType(tierNo, vesselCode, physicalBay);

                String sectionNo = getAssociatedSection(vesselCode, physicalBay, deck);

                BayProfile bayProfile = getBayProfiles(sectionNo).get(physicalBay);

                if (bayProfile != null) {
                    int rowOffset = bayProfile.getRowOffset(rowNo);
                    int tierOffset = bayProfile.getTierOffset(tierNo);

                    CellGrid cell = bayProfile.getCellGrid(rowOffset, tierOffset);
                    if (cell != null) {
                        BayProfileContainer bayContainer = null;
                        if (moveType.equals(MOVE_TYPE.LOAD.toString())) {
                            bayContainer = cell.getPlannedContainer();
                        } else {
                            bayContainer = cell.getCurrentContainer();
                        }

                        if (bayContainer != null) {
                            container = bayContainer.getContainer();
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to get the container information from cell - " + bayNo
                    + ":" + rowNo + ":" + tierNo + " - ", ex);
        }
        return container;
    }

    /**
     * Retrieves the CellGrid object with the specified cellLocation. The vessel details are extracted using the
     * specified user's allocation details.
     * 
     * @param cellLocation
     * @param userId
     * @return
     */
    public CellGrid getCellDetails(String cellLocation, String userId) {
        CellGrid cell = null;
        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);

            String[] bayRowTiers = cellLocation.split("\\.");
            if (bayRowTiers.length != 3) {
                logger.logMsg(LOG_LEVEL.WARN, userId, "Cell Location is not proper-" + cellLocation + " Exiting");
                return cell;
            }

            String vesselCode = getVesselCode(allocation.getRotationID());
            if (vesselCode != null) {
                String bayNo = getPhysicalBayNo(bayRowTiers[0]);
                String deck = EventUtil.getInstance().findDeckType(bayRowTiers[2], vesselCode, bayNo);

                String sectionNo = getAssociatedSection(vesselCode, bayNo, deck);

                BayProfile bayProfile = getBayProfiles(sectionNo).get(bayNo);

                if (bayProfile != null) {
                    int rowOffset = bayProfile.getRowOffset(bayRowTiers[1]);
                    int tierOffset = bayProfile.getTierOffset(bayRowTiers[2]);

                    cell = bayProfile.getCellGrid(rowOffset, tierOffset);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to get the cell details -", ex);
        }

        return cell;
    }

    /**
     * Returns the physical bay no if the specified bayNo is a logical one
     * 
     * @param bayNo
     * @return
     */
    private String getPhysicalBayNo(String bayNo) {
        // check whether it is logical bay, then get one of the physical one
        Integer bay = Integer.parseInt(bayNo);
        String physicalBay = bayNo;
        if (bay % 2 == 0) {
            bay--;
            if (bay < 10) {
                physicalBay = "0" + bay;
            } else {
                physicalBay = bay.toString();
            }
        }
        return physicalBay;
    }

    /**
     * <p> Provides the row numbers present in the bay. User ID is required to get the vessel details for which the user
     * is working on. </p>
     *
     * @param userId
     * @param bayNo
     * @param tierNo
     * @return String[] rowHeaders
     */
    public String[] getBayRows(String userId, String bayNo, String tierNo) {
        String[] rowNos = null;
        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);

            String vesselCode = getVesselCode(allocation.getRotationID());
            String berthSide = getVesselBerthSide(allocation.getRotationID());
            		
            if (vesselCode != null) {
                String physicalBay = getPhysicalBayNo(bayNo);
                String deck = EventUtil.getInstance().findDeckType(tierNo, vesselCode, physicalBay);

                String sectionNo = getAssociatedSection(vesselCode, physicalBay, deck);

                BayProfile bayProfile = getBayProfiles(sectionNo).get(physicalBay);

                if (bayProfile != null) {
                    rowNos = bayProfile.generateRowHeaders().toString().split("\\" + ITEM_SEPERATOR);
                    
                    if(STAR_BORD_SIDE.equalsIgnoreCase(berthSide)){
                    	logger.logMsg(LOG_LEVEL.DEBUG, bayNo, "Vessel is berthed in starboard. Reversing the rows");
                    	ArrayUtils.reverse(rowNos);
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to build the row numbers for bay - " + bayNo + " - ", ex);
        }
        return rowNos;
    }

    /**
     * <p> Provides the tier numbers present in the bay. User ID is required to get the vessel details for which the
     * user is working on. </p>
     *
     * @param userId
     * @param bayNo
     * @param tierNo
     * @return String[] tierHeaders
     */
    public String[] getBayTiers(String userId, String bayNo) {
        String[] tierNosUD = null;
        String[] tierNosD = null;
        String[] tierNos = null;

        String sectionNo = null;

        BayProfile bayProfile = null;

        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);

            String vesselCode = getVesselCode(allocation.getRotationID());

            if (vesselCode != null) {
                String physicalBay = getPhysicalBayNo(bayNo);
                sectionNo = getAssociatedSection(vesselCode, physicalBay, "U");
                if (sectionNo != null) {
                    bayProfile = getBayProfiles(sectionNo).get(physicalBay);

                    if (bayProfile != null) {
                        tierNosUD = bayProfile.tempGenerateTierHeaders().toString().split("\\" + ITEM_SEPERATOR);
                    }
                }

                sectionNo = getAssociatedSection(vesselCode, physicalBay, "D");
                if (sectionNo != null) {
                    bayProfile = getBayProfiles(sectionNo).get(physicalBay);

                    if (bayProfile != null) {
                        tierNosD = bayProfile.tempGenerateTierHeaders().toString().split("\\" + ITEM_SEPERATOR);
                    }
                }

                if (tierNosUD != null && tierNosD != null) {
                    tierNos = new String[tierNosUD.length + tierNosD.length];
                    System.arraycopy(tierNosUD, 0, tierNos, 0, tierNosUD.length);
                    System.arraycopy(tierNosD, 0, tierNos, tierNosUD.length, tierNosD.length);
                } else if (tierNosUD != null) {
                    tierNos = new String[tierNosUD.length];
                    System.arraycopy(tierNosUD, 0, tierNos, 0, tierNosUD.length);
                } else if (tierNosD != null) {
                    tierNos = new String[tierNosD.length];
                    System.arraycopy(tierNosD, 0, tierNos, 0, tierNosD.length);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to build the tier numbers for bay - " + bayNo + " - ",
                    ex);
        }
        return tierNos;
    }

    /**
     * Adds the mapping between Vessel rotation ID and vessel code
     * 
     * @param rotationId
     * @param vesselCode
     */
    public void addVesselMapping(String rotationId, String vesselNo) {
        this.rotationToVesselCodeMapping.put(rotationId, vesselNo);
    }

    /**
     * Retrieves the vessel code related to the rotation id
     * 
     * @param rotationID
     * @return
     */
    public String getVesselCode(String rotationID) {
        return this.rotationToVesselCodeMapping.get(rotationID);
    }

    /**
     * Removes the vessel rotation to vessel code mapping from the cache.
     * 
     * @param rotationId
     */
    public void removeVesselMapping(String rotationId) {
        this.rotationToVesselCodeMapping.remove(rotationId);
    }

    /**
     * Retrieves the colour mapped with the specified POD(Port Of Destination)
     * 
     * @param pod
     * @return hexaCode of the colour
     */
    public String getColourCodeForPOD(String pod) {
        ColourCode code = this.colourCodeMap.get(pod);
        if (code != null) {
            return code.getHexaCode();
        } else {
            return "";
        }
    }

    /**
     * Retrieves the colour mapped with the specified ItemName
     * 
     * @param ItemName
     * @return hexaCode of the colour
     */
    public String getColourCode(String itemName) {
        ColourCode code = this.colourCodeMap.get(itemName);
        if (code != null) {
            return code.getHexaCode();
        } else {
            return "";
        }
    }

    /**
     * Adds the colour code to the cache
     * 
     * @param code
     */
    public void addColourCode(ColourCode code) {
        this.colourCodeMap.put(code.getItemName(), code);
    }

    public int getMaxRowForVessel(String vesselCode) {
        if (!vesselCode.isEmpty()) {
            return 20; 
        } else {
            return 0;
        }
    }

    /**
     * <p> In case of discharge operation, the bay profile needs to be updated. The container is removed from the
     * specified cellLocation in the bayProfile CellGrid. Further views of bayProfile will show the cell as
     * unoccupied.</p>
     * 
     * <p>In case of Load operation, the planned container of the cell location is moved as the current location.
     * Further bay profile will show the cell occupied with the loaded container.</p>
     * 
     * <p>Also in case of 40" containers, the two cell locations needs updates.</p>
     * 
     * @param cellLocation
     * @param containerId
     * @param userId
     */
    public void updateBayProfile(String cellLocation, String containerId, String rotationId, String moveType) {
        logger.logMsg(LOG_LEVEL.DEBUG, rotationId, "updateBayProfile started(cellLocation, containerId) - "
                + cellLocation + "," + containerId);

        String bayNo = cellLocation.substring(0, 2);
        String rowNo = cellLocation.substring(3, 5);
        String tierNo = cellLocation.substring(cellLocation.length() - 2);

        boolean isLogicalBay = false;
        try {
            Integer bay = Integer.parseInt(bayNo);
            if (bay % 2 == 0) {
                isLogicalBay = true;
                bay--;
                if (bay < 10) {
                    bayNo = "0" + bay;
                } else {
                    bayNo = bay.toString();
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while checking whether the bay is Logical one -", ex);
        }

        try {
            String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(rotationId);

            String deckIndication = EventUtil.getInstance().findDeckType(tierNo, vesselCode, bayNo);

            String sectionNo = RDTVesselProfileCacheManager.getInstance().getAssociatedSection(vesselCode, bayNo,
                    deckIndication);

            if (sectionNo != null) {
                if (isLogicalBay) {
                    logger.logMsg(LOG_LEVEL.DEBUG, "", "Removing the container details for LOGICAL bay");
                    for (BayProfile bayProfile : RDTVesselProfileCacheManager.getInstance().getBayProfiles(sectionNo)
                            .values()) {
                        updateCell(rotationId, bayProfile, rowNo, tierNo, containerId, moveType);
                    }
                } else {
                    BayProfile bayProfile = RDTVesselProfileCacheManager.getInstance().getBayProfiles(sectionNo)
                            .get(bayNo);
                    updateCell(rotationId, bayProfile, rowNo, tierNo, containerId, moveType);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while updating the bay profile", ex);
        }
    }

    /**
     * Updates the container details on the cell location specified by rowNo and tierNo for the bayProfile.
     * 
     * @param bayProfile
     * @param rowNo
     * @param tierNo
     * @param containerId
     */
    private void updateCell(String rotationId, BayProfile bayProfile, String rowNo, String tierNo, String containerId,
            String moveType) {
        int rowOffset = bayProfile.getRowOffset(rowNo);
        int tierOffset = bayProfile.getTierOffset(tierNo);
        CellGrid cell = bayProfile.getCellGrid(rowOffset, tierOffset);

        if (moveType.equals(MOVE_TYPE.DSCH.toString())) {
            if (cell.getCurrentContainer() != null
                    && cell.getCurrentContainer().getContainer().getContainerID().equals(containerId)) {
                logger.logMsg(LOG_LEVEL.INFO, rotationId, " Discharge operation, removing  " + containerId
                        + " from the cell location - " + cell.getVesselRowNo() + "." + cell.getVesselTierNo());
            } else {
                logger.logMsg(LOG_LEVEL.INFO, rotationId,
                        " Discharge operation, The container present is  " + cell.getCurrentContainer()
                                + " at the cell location - " + cell.getVesselRowNo() + "." + cell.getVesselTierNo()
                                + " but discharging " + containerId);
            }
            cell.setCurrentContainer(null);
        } else {
            if (cell.getPlannedContainer() != null
                    && containerId.equalsIgnoreCase(cell.getPlannedContainer().getContainer().getContainerID())) {
                logger.logMsg(LOG_LEVEL.INFO, rotationId,
                        " Load operation, Moving from planned to current :  " + containerId
                                + " in the cell location - " + cell.getVesselRowNo() + "." + cell.getVesselTierNo());
                cell.setCurrentContainer(cell.getPlannedContainer());
            } else {
                logger.logMsg(LOG_LEVEL.WARN, rotationId, "Updating Load operation, but the container " + containerId
                        + " is not planned for this location.");
                Container cntr = RDTCacheManager.getInstance().getContainerDetails(containerId, moveType);
                // There can be chances that the container is not part of the bay profile, due to stowage position null.
                if (cntr == null) {
                    cntr = new Container();
                    cntr.setContainerID(containerId);
                }
                BayProfileContainer bayContainer = new BayProfileContainer();
                bayContainer.setContainer(cntr);
                bayContainer.setROB(false);
                bayContainer.setMoveType(moveType);
                bayContainer.setStowagePosition(bayProfile.getVesselBayId() + rowNo + tierNo);
                cell.setCurrentContainer(bayContainer);
            }
        }
    }

    public void flushColourCodes() {
        colourCodeMap.clear();
    }

    /**
     * Links the specified QC equipment to the specified rotation ID
     * 
     * @param rotationId
     * @param qcEquipmentId
     */
    public void linkQCToRotation(String rotationId, String qcEquipmentId) {
        List<String> qcs = rotationToQcMapping.get(rotationId);
        if (qcs == null) {
            qcs = new ArrayList<String>();
            rotationToQcMapping.put(rotationId, qcs);
        }
        qcs.add(qcEquipmentId);

        List<String> rotations = qcToRotationMapping.get(qcEquipmentId);
        if (rotations == null) {
            rotations = new ArrayList<String>();
            qcToRotationMapping.put(qcEquipmentId, rotations);
        }
        rotations.add(rotationId);
    }

    /**
     * Retrieves the list of QCs linked to the specified rotation Id
     * 
     * @param rotationId
     * @return
     */
    public List<String> getQCsAllocatedForRotation(String rotationId) {
        return rotationToQcMapping.get(rotationId);
    }
    
    /**
     * Returns the set of rotations currently berthed 
     * @return
     */
    public Set<String> getBerthedRotationList(){
    	return rotationToQcMapping.keySet();
    }

    /**
     * Retrieves the list of rotations allocated for the specified QC
     * 
     * @param qcEquipmentId
     * @return
     */
    public List<String> getRotationDetailsForQC(String qcEquipmentId) {
        return qcToRotationMapping.get(qcEquipmentId);
    }

    /**
     * Removes the mapping between the QC and specified rotation.
     * 
     * @param rotationId
     * @param qcEquipmentId
     */
    public void flushQCToRotationMapping() {
        qcToRotationMapping.clear();
        rotationToQcMapping.clear();
    }

    /**
     * Removes all the qc mappings for the specified rotation
     * 
     * @param rotationId
     */
    public void clearQCToRotationMapiing(String rotationId) {
        rotationToQcMapping.remove(rotationId);

        try {
            Set<String> qcKeys = qcToRotationMapping.keySet();
            for (String qcId : qcKeys) {
                List<String> rotations = qcToRotationMapping.get(qcId);
                if (rotations != null) {
                    rotations.remove(rotationId);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to remove the rotation from the qc -", ex);
        }
    }

    /**
     * Retrieves the Template defined with the specified headerId from the cache. If failed to get it from cache,
     * retrieves it from DB and updates the cache, so that future calls will avaoid hitting DB.
     * 
     * @param headerId
     * @return
     */
    public TemplateHeader getTemplateHeader(String headerId) {
        TemplateHeader header = templateMap.get(headerId);

        if (header == null) {
            logger.logMsg(LOG_LEVEL.INFO, headerId, "Failed to get the template from cache, going to retrieve from DB");
            header = HibernateUtil.getTemplate(headerId);

            if (header != null) {
                logger.logMsg(LOG_LEVEL.INFO, headerId, "Successfully retrieved from DB, adding to cache");
                templateMap.put(headerId, header);
            }
        }

        return header;
    }

    /**
     * Adds the specified container to the ROB cache of the specified rotation
     * 
     * @param rotationId
     * @param containerId
     */
    public void addToROBList(String rotationId, String containerId) {
        List<String> robContainers = robContainerMap.get(rotationId);

        if (robContainers == null) {
            synchronized (robContainerMap) {
                if (robContainers == null) {
                    robContainers = new ArrayList<String>();
                    robContainerMap.put(rotationId, robContainers);
                }
            }
        }

        robContainers.add(containerId);
    }

    /**
     * Removes the ROB container list for the specified rotation from Cache
     * 
     * @param rotationId
     */
    public void clearROBList(String rotationId) {
        robContainerMap.remove(rotationId);
    }

    /**
     * Retrieves the list of ROB containers for the specified rotation
     * 
     * @param rotationId
     * @return
     */
    public List<String> getROBList(String rotationId) {
        return robContainerMap.get(rotationId);
    }
    
    /**
     * <p>Validates whether the specified bayNo.rowNo.tierNo is a valid cell Location in the Vessel.</p>
     * 
     * <p> The vessel rotation ID is retrieved from the cache by checking the allocation details for the specified user.
     * Then the corresponding bay profile is retrieved from the Vessel Profile. And if the bay.row.tier combination
     * is present, returns true. Else false.</p.>
     * 
     * @param userId
     * @param bayNo
     * @param rowNo
     * @param tierNo
     */
    public boolean validateCell(String userId, String bayNo, String rowNo, String tierNo) {
        
        logger.logMsg(LOG_LEVEL.INFO, userId, " BayNumber:" +bayNo  
                + "RowNumber:" + rowNo + " Tier Number::" +tierNo);
        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);

            String vesselCode = getVesselCode(allocation.getRotationID());
            if (vesselCode != null) {
                String physicalBay = getPhysicalBayNo(bayNo);
                String deck = EventUtil.getInstance().findDeckType(tierNo, vesselCode, physicalBay);

                String sectionNo = getAssociatedSection(vesselCode, physicalBay, deck);
                
                //in logical bay, first validate whether the logical bay number belongs to the section.
                if(Integer.parseInt(bayNo) % 2 == 0){
                	Set<String> baysInSection = getBayProfiles(sectionNo).keySet();
                	logger.logMsg(LOG_LEVEL.DEBUG, userId, "logical bay - associated twin bays " + baysInSection);
                	Integer median = 0;
                	for(String bay : baysInSection){
                		median += Integer.parseInt(bay);
                	}
                	if(median/baysInSection.size() != Integer.parseInt(bayNo)){
                		logger.logMsg(LOG_LEVEL.DEBUG, userId, "logical bayNo for the associated section is not matching -" + median/baysInSection.size());
                		return false;
                	}
                }

                BayProfile bayProfile = getBayProfiles(sectionNo).get(physicalBay);

                if (bayProfile != null) {
                    int rowOffset = bayProfile.getRowOffset(rowNo);
                    int tierOffset = bayProfile.getTierOffset(tierNo);

                    CellGrid cell = bayProfile.getCellGrid(rowOffset, tierOffset);
                    if (cell != null) {
                        return true;
                    } 
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while validating cell - " + bayNo
                    + ":" + rowNo + ":" + tierNo + " - ", ex);
        }
        return false;
    }
    
    /**
     * Retrieves the containerMoveEvent associated with the eventId and deletes the entry from cache
     * @param eventId
     * @return
     */
    public ContainerMoveEvent getContainerMoveEvent(String eventId){
    	return pendingContainerMoveMap.remove(eventId);
    }
    
    /**
     * Adds the containerMoveEvent associated with the eventId to the cache
     * @param ContainerMoveEvent
     * @return
     */
    public void addContainerMoveEvent(ContainerMoveEvent moveEvent){
    	pendingContainerMoveMap.put(moveEvent.getEventID(), moveEvent);
    }
    
    /**
     * Deletes the containerMoveEvent associated with the eventId from cache
     * @param eventId
     * @return
     */
    public void deleteContainerMoveEvent(String eventId){
    	pendingContainerMoveMap.remove(eventId);
    }
    
    /**
     * Adds the specified QC as heavy hook user for the rotation.
     * @param rotation
     * @param heavyHookUser
     */
    public void addHeavyHookUser(String rotation, String heavyHookQcId){
    	heavyHookUsersMap.put(rotation, heavyHookQcId);
    }
    
    /**
     * Retrieves the heavy hook QC for the specified rotation
     * @param rotation
     * @return
     */
    public String getHeavyHookUser(String rotation){
    	return heavyHookUsersMap.get(rotation);
    }
    
    /**
     * Removes the heavy hook QC for the rotation specified
     * @param rotation
     */
    public void removeHeavyHookUser(String rotation){
    	heavyHookUsersMap.remove(rotation);
    }   
}
