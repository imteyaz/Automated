package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Class is responsible for holding DelayRecording event done by logged in user.
 * 
 * @author UMAMAHESH M
 *
 */
public class DelayRecordingByOperatorEvent extends Event implements Serializable {
    private static final long serialVersionUID = -4641275075992880135L;
}
