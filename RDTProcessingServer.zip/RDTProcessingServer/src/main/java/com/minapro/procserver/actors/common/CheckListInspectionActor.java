package com.minapro.procserver.actors.common;

import java.util.Date;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CheckListHeader;
import com.minapro.procserver.db.InspectionCheckListMapping;
import com.minapro.procserver.db.InspectionRecord;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserViolationAndDelay;
import com.minapro.procserver.db.UserViolationAndDelay.VIOLATION_DELAY_CATEGORY;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.common.CancelInspectionEvent;
import com.minapro.procserver.events.common.CheckListInspectionEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.tsc.TSCJobListRequestEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.CheckListHeaderType;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

/**
 * <p>Actor responsible for handling the pre-operational checklist inspection activity.</p>
 * 
 * <p>If the user performs the inspection, the generated event is CheckListInspectionEvent. If the user opts to skip the
 * inspection, the generated event is CancelInspectionEvent. </p>
 * 
 * <p> In both the cases, the status is updated in Cache for the user. </p>
 * 
 * <p> In case of CheckListInspectionEvent and the user is an ITV operator, Retrieves the drive instructions from the
 * cache (if any) and sends to the user. </p>
 * 
 * @author Rosemary George
 *
 */
public class CheckListInspectionActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CheckListInspectionActor.class);

    private static final String MANDATORY_CHECKLIST_FAILED = "MANDATORY CHECKLIST ITEM FAILED IN INSPECTION";

    @Override
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof CheckListInspectionEvent) {
                CheckListInspectionEvent inspectionRecord = (CheckListInspectionEvent) message;

                User user = RDTCacheManager.getInstance().getUserDetails(inspectionRecord.getUserID());
                if (user != null) {
                    checkAndSendPendingInstructions(inspectionRecord, "performed");
                    saveInspectionRecord(inspectionRecord, user);
                }
            } else if (message instanceof CancelInspectionEvent) {
                CancelInspectionEvent cancelInspection = (CancelInspectionEvent) message;
                checkAndSendPendingInstructions(cancelInspection, "cancelled");
            } else {
                unhandled(message);
            }
        } catch (Exception e) {
            logger.logException("Caught Exception while processing CheckListInspection -", e);
        }

    }

    /**
     * <p>Saves the inspection record in the database with the operators markings against each check list item. </p>
     * 
     * <p> In case if any of the mandatory checklist item is marked as failed, a user violation record is created and
     * saved in Database.</p>
     * 
     * @param inspectionRecord
     * @param user
     */
    private void saveInspectionRecord(CheckListInspectionEvent inspectionRecord, User user) {
        InspectionRecord record = new InspectionRecord();
        record.setStatus(inspectionRecord.getStatus());
        record.setInspectionTime(new Date());
        record.setUser(user);

        OPERATOR roleName = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
        CheckListHeader header = RDTCacheManager.getInstance().getCheckListForRole(roleName.toString(),
                CheckListHeaderType.PRE_OP.getName());
        record.setCheckListHeader(header);

        // While Vessel Foreman is updating Any Equipment CheckList,
        // Remarks columns has to be updated with Foreman User Name
        if ("q".equals(inspectionRecord.getCheckListType())) {
            record.setRemarks("QC ID " + inspectionRecord.getEquipmentID());
        }

        boolean mandatoryFailed = false;
        List<InspectionCheckListMapping> items = inspectionRecord.getCheckListItems();
        if (items != null) {
            for (InspectionCheckListMapping mapping : items) {
                mapping.setInspectionRecord(record);
                record.getCheckListItems().add(mapping);

                if ("Y".equalsIgnoreCase(mapping.getCheckListItem().getMandatory()) && "f".equals(mapping.getStatus())) {
                    mandatoryFailed = true;
                }
            }
        }

        logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending the Inspection record to save in DB - " + record);
        JournalEvent journal = new JournalEvent(record, UPDATETYPE.ADD);
        getSender().tell(journal, null);

        if (mandatoryFailed) {
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Mandatory checklist item failed, logging a violation");
            createUserViolation(user);
        }
    }

    /**
     * Records a violation entry into the database if any of the mandatory checklist item is marked as unchecked.
     * 
     * @param user
     */
    private void createUserViolation(User user) {
        UserViolationAndDelay violation = new UserViolationAndDelay(MANDATORY_CHECKLIST_FAILED, user,
                VIOLATION_DELAY_CATEGORY.VIOLATION);
        JournalEvent journalEvent = new JournalEvent(violation, UPDATETYPE.ADD);
        getSender().tell(journalEvent, null);
    }

    /**
     * <p>Checks for any pending instructions for the specified user. If found, sends the message to the user.</p>
     * 
     * <p>Pending instructions are checked as per the user Role. For ITV operator, it will be drive instructions. For
     * QC,CHE,HC operators it will be job lists. </p>
     * 
     * @param user
     * @param equipmentID
     * @param status
     *            - performed/cancelled
     */
    private void checkAndSendPendingInstructions(Event inspectionEvent, String status) {
        String userId = inspectionEvent.getUserID();

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);

        if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)
                || operatorRole.equals(OPERATOR.ITV)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Checking and sending available JobList");

            // send jobList request to ESB
            JobListRequestEvent requestEvent = new JobListRequestEvent();
            requestEvent.setUserID(userId);
            requestEvent.setTerminalID(inspectionEvent.getTerminalID());
            requestEvent.setEventID(inspectionEvent.getEventID());
            requestEvent.setScheduled(false);

            ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);
            requestEvent.setEquipmentID(allocationDetails.getEquipmentID());
            requestEvent.setLocation(allocationDetails.getLocation());
            requestEvent.setRotationId(allocationDetails.getRotationID());

            User user = RDTCacheManager.getInstance().getUserDetails(userId);
            if (user != null) {
                requestEvent.setPassword(user.getPassword());
            }
            
            if(operatorRole.equals(OPERATOR.HC)){
                requestEvent.setQcId(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(userId));
            }

            // set it back to the original equipmentId
            requestEvent.setEquipmentID(allocationDetails.getEquipmentID());
            ESBQueueManager.getInstance().postMessage(requestEvent, operatorRole, requestEvent.getTerminalID());
        } else if (operatorRole.equals(OPERATOR.TSC)) {
            initiateJobListRequestForTSC(inspectionEvent);
        }
        if(operatorRole.equals(OPERATOR.CHE)) {
        	logger.logMsg(LOG_LEVEL.DEBUG, userId, "Checking and sending JobList request for CHE Operator");
        	CHEJobListRequestEvent requestEvent = new CHEJobListRequestEvent();
            requestEvent.setUserID(userId);
            requestEvent.setTerminalID(inspectionEvent.getTerminalID());
            requestEvent.setEventID(inspectionEvent.getEventID());
            requestEvent.setScheduled(false);

            ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);
            requestEvent.setEquipmentID(allocationDetails.getEquipmentID());
            requestEvent.setLocation(allocationDetails.getLocation());
         
            User user = RDTCacheManager.getInstance().getUserDetails(userId);
            if (user != null) {
                requestEvent.setPassword(user.getPassword());
            }

            // set it back to the original equipmentId
            requestEvent.setEquipmentID(allocationDetails.getEquipmentID());
            ESBQueueManager.getInstance().postMessage(requestEvent, operatorRole, requestEvent.getTerminalID());
        }
    
        // update the inspection status in the cache.
        RDTCacheManager.getInstance().addInspectionRecord(userId, status);
    }

    /**
     * Construct and sends the TSCJobListRequestEvent to master actor for further processing
     * 
     * @param inspectionEvent
     */
    private void initiateJobListRequestForTSC(Event inspectionEvent) {
        TSCJobListRequestEvent jobListRequest = new TSCJobListRequestEvent();
        jobListRequest.setEventID(inspectionEvent.getEventID());
        jobListRequest.setTerminalID(inspectionEvent.getTerminalID());
        jobListRequest.setUserID(inspectionEvent.getUserID());
        jobListRequest.setRequestType(RESP);

        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(inspectionEvent.getUserID());
        jobListRequest.setTsArea(allocationDetails.getLocation());

        getSender().tell(jobListRequest, null);
    }
}
