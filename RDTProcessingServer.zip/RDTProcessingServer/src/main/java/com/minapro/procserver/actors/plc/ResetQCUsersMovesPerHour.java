package com.minapro.procserver.actors.plc;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTPLCCacheManager;

public class ResetQCUsersMovesPerHour extends UntypedActor {
    @Override
    public void onReceive(Object message) throws Exception {
        String userId = (String) message;
        RDTPLCCacheManager.getInstance().addMovesperHourOfUser(userId, 0);
    }
}
