package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.Arrays;

/**
 * ValueObject holding the troubleshoot details recorded for a particular container from the UI
 * 
 * @author Rosemary George
 *
 */
public class TroubleShootDetails implements Serializable {
    private static final long serialVersionUID = -4831464035284108011L;

    /**
     * ID of the damaged container
     */
    private String containerID;

    /**
     * The ID of the ITV which is carrying the damaged container.
     */
    private String itvId;

    /**
     * TS area selected for the troubleshoot
     */
    private String tsAreaId;

    /**
     * List of selected troubleshoot codes for the container
     */
    private String[] troubleShootCodes;

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public String getItvId() {
        return itvId;
    }

    public void setItvId(String itvId) {
        this.itvId = itvId;
    }

    public String getTsAreaId() {
        return tsAreaId;
    }

    public void setTsAreaId(String tsAreaId) {
        this.tsAreaId = tsAreaId;
    }

    public String[] getTroubleShootCodes() {
        return troubleShootCodes;
    }

    public void setTroubleShootCodes(String[] troubleShootCodes) {
        this.troubleShootCodes = troubleShootCodes;
    }

    @Override
    public String toString() {
        return "TroubleShootDetails [containerID=" + containerID + ", itvId=" + itvId + ", tsAreaId=" + tsAreaId
                + ", troubleShootCodes=" + Arrays.toString(troubleShootCodes) + "]";
    }
}
