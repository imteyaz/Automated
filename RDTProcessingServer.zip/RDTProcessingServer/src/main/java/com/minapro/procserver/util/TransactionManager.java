package com.minapro.procserver.util;
import java.util.Hashtable;
import java.util.Map;

import org.hibernate.Session;

import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
/**
 * A Class Is Designed to Manage The Database transactions by holding database sessions into ThreadLocal.
 * 
 * @author UmaMahesh
 *
 */
public class TransactionManager{

	
	/**
	 * HashTable is used to Maintain the Synchronization.
	 */
	public static final Map<Long,ThreadLocal<Session>> SESSION_HASH_TABLE   = new Hashtable<Long,ThreadLocal<Session>>();
		
	private static  MinaProApplicationLogger logger = new MinaProApplicationLogger(TransactionManager.class);
	
	public static void setSession(Session session){

		ThreadLocal<Session> threadLocal = new ThreadLocal<Session>();
		threadLocal.set(session);
		SESSION_HASH_TABLE.put(Thread.currentThread().getId(),threadLocal);
	}
	
	public static Session getSession() throws NullPointerException{
		
		ThreadLocal<Session> threadLocal = SESSION_HASH_TABLE.get(Thread.currentThread().getId());
		 return threadLocal.get();
	}
	
	public static void closeSession() throws NullPointerException , InterruptedException{
		
		SESSION_HASH_TABLE.remove(Thread.currentThread().getId());
			
		logger.logMsg(LOG_LEVEL.INFO,Thread.currentThread().getName(),new StringBuilder(" After Current Thread Local Removal Available Thread Locals Are").
					append(SESSION_HASH_TABLE).toString());
	}
}
