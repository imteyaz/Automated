package com.minapro.procserver.actors;

import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.shf.QcLanesProcessingActor;
import com.minapro.procserver.actors.shf.SHFPinningStationAllocationsActor;
import com.minapro.procserver.events.shf.QCLanesRequestEvent;
import com.minapro.procserver.events.shf.QcLanesChangeRequestEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationChangeEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationReqEvent;

public class SHFOperationsSupervisorActor extends UntypedActor {

    /**
     * Following actor is responsible for handling SHFPinningStation View/Edit Operations.
     */
    private ActorRef shfPinningAllocaitonActor = getContext()
            .actorOf(Props.create(SHFPinningStationAllocationsActor.class).withRouter(new FromConfig()),
                    "shfPinningAllocations");

    /**
     * Following Actor is Responsible for handling QcLanes View/Edit Operations
     */

    private ActorRef qcLaneActor = getContext().actorOf(
            Props.create(QcLanesProcessingActor.class).withRouter(new FromConfig()), "qcLaneAllocations");

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof SHFPinningStationAllocationReqEvent) {
            shfPinningAllocaitonActor.tell(message, getSelf());
        } else if (message instanceof SHFPinningStationAllocationChangeEvent) {
            shfPinningAllocaitonActor.tell(message, getSelf());
        } else if (message instanceof QCLanesRequestEvent) {
            qcLaneActor.tell(message, getSelf());
        } else if (message instanceof QcLanesChangeRequestEvent) {
            qcLaneActor.tell(message, getSelf());
        } else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, null);
        }
    }
}
