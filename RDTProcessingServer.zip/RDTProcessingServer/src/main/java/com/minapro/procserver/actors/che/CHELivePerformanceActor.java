package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RMG;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ShiftDetails;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class CHELivePerformanceActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHELivePerformanceActor.class);

    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd.MM.yyyy HH:mm");

    private static final String TARGET_MPH = "_TARGET_MPH";
    static final long ONE_MINUTE_IN_MILLIS = 60000;

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof EsperRMGPLCEvent) {
            EsperRMGPLCEvent plcEvent = (EsperRMGPLCEvent) message;
            String node = plcEvent.getNode();
            String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

            if (userId != null) {
                PerformanceEvent performanceEvent = measureCHEPerformance(userId, node);
                EventUtil.getInstance().sendPerformanceEvent(performanceEvent, OPERATOR.CHE);
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * <p> Measures the live performance of the specified QC operator based on the following formula </p>
     * 
     * <p> Moves to Go = (Planned Moves – Completed moves ) for the QC </p> <p> Total moves = Moves completed by the
     * User for current Rotation and QC </p> <p> Moves Behind = Target Moves per hour * Total hours worked – Completed
     * moves </p> <p> Moves per hour = Total completed moves / number of hours worked </p>
     * 
     */
	private PerformanceEvent measureCHEPerformance(String userId, String cheEquipmentId) {

		PerformanceEvent performanceEvent = null;
		int targetMph = 0;
		double cheDiffInMillies;

		ApplicationParameter targetMovesPerHour = RDTPLCCacheManager.getInstance().getApplicationParamter(
				cheEquipmentId + TARGET_MPH);
		try {
			if (targetMovesPerHour == null) {
				targetMovesPerHour = RDTPLCCacheManager.getInstance().getApplicationParamter(RMG + TARGET_MPH);
			}
			targetMph = (targetMovesPerHour==null ?  32  : Integer.parseInt(targetMovesPerHour.getParameterValue()));
		} catch (Exception ex) {
			logger.logException("Caught exception while fetching CHE target mph", ex);
		}

		try {
			
			int plannedMoves = RDTPLCCacheManager.getInstance().getPlannedMovesCount(cheEquipmentId);
			User user = RDTCacheManager.getInstance().getUserDetails(userId);
			
			long completedUserJobs;	
			
			Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);
			Date shiftStartDate, shiftEndDate;
			ShiftDetails shiftData = HibernateUtil.getShiftDataforLoggedInuser(loginTime, new Date(), userId);
			if (shiftData != null) {
				shiftStartDate = shiftData.getShiftStartDate();
				shiftEndDate = shiftData.getShiftEndDate();
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, userId, "Not able to retrieve shift details for user. Using login Time");
				shiftStartDate = loginTime;	
				// round to the next minute so that the current job completed will be retrieved by the query
				shiftEndDate = new Date(Calendar.getInstance().getTimeInMillis()+ ONE_MINUTE_IN_MILLIS);
			}

			String shifStartTime = DATE_FORMATTER.format(shiftStartDate);
			String shifEndTime = DATE_FORMATTER.format(shiftEndDate);

			logger.logMsg(LOG_LEVEL.INFO, userId, "Shift Start Time :" + shifStartTime);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Shift End Time :" + shifEndTime);
			
			List<CompletedContainerMoves> cheUserCompletedJobs =  HibernateUtil.getCompletedJobsByUserforThisShift(user, cheEquipmentId,
					shifStartTime, shifEndTime);
					
					//RDTCacheManager.getInstance().getCompletedJobs("", cheEquipmentId);
			completedUserJobs = (cheUserCompletedJobs!=null && !cheUserCompletedJobs.isEmpty()) ? cheUserCompletedJobs.size() : 0;
			
			// Moves to Go = (Planned Moves – Completed moves ) for the QC
			long movesToGo = plannedMoves - completedUserJobs;
			if (movesToGo < 0) {
				movesToGo = 0;
			}

			logger.logMsg(LOG_LEVEL.INFO, userId, "CompletedJobs by user :" + completedUserJobs);
			
			//Calculating the current login worked time in hours
			cheDiffInMillies = System.currentTimeMillis() - loginTime.getTime();
			Double hoursWorkedByCHE = cheDiffInMillies / (1000 * 60 * 60);
			logger.logMsg(LOG_LEVEL.INFO, cheEquipmentId, "TimeWorkedInHours by user for this login session:" + hoursWorkedByCHE);
			
			Double hoursWorkedByUser = HibernateUtil.getTotalHoursWorkedByCHEUser(user, shifStartTime, shifEndTime);
			logger.logMsg(LOG_LEVEL.INFO, userId, "TotalTimeWorkedInHours previously by CHE user for the shift:" + hoursWorkedByUser);
			
			hoursWorkedByUser = hoursWorkedByUser==null ? hoursWorkedByCHE : hoursWorkedByUser+hoursWorkedByCHE;
          
			
            logger.logMsg(LOG_LEVEL.INFO, userId, "TotalTimeWorkedInHours by user :" + hoursWorkedByUser);

			// Moves per hour : Total completed moves / number of hours worked
			// @UmaMahesh added
			double grossMovesPerHour = hoursWorkedByUser > 0.0 ? completedUserJobs / hoursWorkedByUser : 0.0;

			double targetCompletionTime = 0;
			if (targetMph > 0) {
				targetCompletionTime = plannedMoves / targetMph;
			}

			// Moves Behind = Target Moves per hour * Total hours worked – Completed moves by the crane
			long movesBehind = (int) (targetMph * hoursWorkedByUser) - completedUserJobs;
			if (movesBehind < 0) {
				logger.logMsg(LOG_LEVEL.INFO, userId, "MovesBehind in Negative  :" + movesBehind);
				movesBehind = 0;
			}

			logger.logMsg(LOG_LEVEL.INFO, userId, "Target Moves per Hour :" + targetMph);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Gross Moves per Hour :" + grossMovesPerHour);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Moves Behind  :" + movesBehind);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Moves To Go  :" + movesToGo);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Target Completion Time :" + targetCompletionTime);
			logger.logMsg(LOG_LEVEL.INFO, userId, "Planned Moves :" + plannedMoves);

			performanceEvent = EventUtil.getInstance().constructPerformanceEvent(userId, grossMovesPerHour,
					targetCompletionTime, (int) movesToGo, (int) movesBehind, (int) completedUserJobs, cheEquipmentId,
					targetMph);

		} catch (Exception ex) {
			logger.logException("Caught exception in measureCHEPerformance() Reason::", ex);
		}
		return performanceEvent;
	}

}
