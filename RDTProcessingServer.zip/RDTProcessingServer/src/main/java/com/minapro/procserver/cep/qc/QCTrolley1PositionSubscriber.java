package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.STATE_LOCK;
import static com.minapro.procserver.util.QCPLCConstants.TROLLEY1_POSITION;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

/*
 * 
 * <p> Class responsible for detecting Trolley1Position during the container
 * locking time  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCTrolley1PositionSubscriber implements StatementSubscriber {

    public QCTrolley1PositionSubscriber() {
    }

    @Override
    public String getStatement() {
        return "context EachQC select a,b from pattern [ every a=EsperPLCEvent(tagName = 'Trolley1Position') ->"
                + " (((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue=lockedUpTagValue))) and not EsperPLCEvent(tagName = 'Trolley1Position'))]";

    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateCraneMoveStatus(TROLLEY1_POSITION, STATE_LOCK, eventMap);
    }
}
