package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class NewLocationResponseEvent extends Event implements Serializable {
    /**
     * ValueObject holding the new location response from ESB
     */
    private static final long serialVersionUID = -5803020399021709840L;
    /**
     * Indicates the container to which new location is modified
     */
    private String containerID;
    /**
     * In case the new location status is fail, holds the reason for failure
     */
    private String errorReason;
    /**
     * container new location
     */
    private String newLocation;
    /**
     * Indicates whether the new location of the container is successful or not
     */
    private boolean status;

    public String getContainerID() {
        return containerID;

    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public String getErrorReason() {
        return errorReason;
    }

    public void setErrorReason(String errorReason) {
        this.errorReason = errorReason;
    }

    public String getNewLocation() {
        return newLocation;
    }

    public void setNewLocation(String newLocation) {
        this.newLocation = newLocation;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "NewLocationResponseEvent [containerID=" + containerID + ", errorReason=" + errorReason
                + ", newLocation=" + newLocation + ", status=" + status + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }

}
