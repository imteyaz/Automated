package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * NumsrsdtlsYpmId entity.
 * 
 * @author CMC.UMAMAHESH
 */
@Embeddable
public class NumsrsdtlsYpmId implements java.io.Serializable {

    // Fields
    private static final long serialVersionUID = 87846284605724255L;

    @Column(name = "NUMSRS_ID")
    private String numsrsId;

    @Column(name = "SEQ_NO")
    private Integer seqNo;

    public String getNumsrsId() {
        return this.numsrsId;
    }

    public void setNumsrsId(String numsrsId) {
        this.numsrsId = numsrsId;
    }

    public Integer getSeqNo() {
        return this.seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (!(other instanceof NumsrsdtlsYpmId)) {
            return false;
        }
        NumsrsdtlsYpmId castOther = (NumsrsdtlsYpmId) other;

        return this.getNumsrsId() == castOther.getNumsrsId() || (this.getNumsrsId() != null
                && castOther.getNumsrsId() != null && this.getNumsrsId().equals(castOther.getNumsrsId()));
    }

    @Override
    public int hashCode() {
        int result = 17;

        result = 37 * result + (getNumsrsId() == null ? 0 : this.getNumsrsId().hashCode());
        result = 37 * result + (getSeqNo() == null ? 0 : this.getSeqNo().hashCode());
        return result;
    }
}