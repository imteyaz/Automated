package com.minapro.procserver.events;

import java.io.Serializable;

public class BackReachEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3203985117324491644L;
    private String backReachType;

    public String getBackReachType() {
        return backReachType;
    }

    public void setBackReachType(String backReachType) {
        this.backReachType = backReachType;
    }

    @Override
    public String toString() {
        return "BackReachEvent [backReachType=" + backReachType + "]";
    }

}
