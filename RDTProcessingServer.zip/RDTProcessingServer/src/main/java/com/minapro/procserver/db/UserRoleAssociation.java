package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the User to Role association. A User to role association is many-to-many.
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_USERGRP_A")
public class UserRoleAssociation implements Serializable {

    private static final long serialVersionUID = -6949883307579389708L;
    private UserRoleId userRoleId;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String adtInsUserName;
    private String adtUpdUserName;
    private Date adtInsDatTime;
    private Date adtUpdDatTime;

    @EmbeddedId
    public UserRoleId getUserRoleId() {
        return userRoleId;
    }

    public void setUserRoleId(UserRoleId userRoleId) {
        this.userRoleId = userRoleId;
    }

    @Column(name = "ADT_INS_FUNCTION_CD")
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }

    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }

    @Column(name = "ADT_UPD_FUNCTION_CD")
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }

    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }

    @Column(name = "ADT_INS_USER_NM")
    public String getAdtInsUserName() {
        return adtInsUserName;
    }

    public void setAdtInsUserName(String adtInsUserName) {
        this.adtInsUserName = adtInsUserName;
    }

    @Column(name = "ADT_UPD_USER_NM")
    public String getAdtUpdUserName() {
        return adtUpdUserName;
    }

    public void setAdtUpdUserName(String adtUpdUserName) {
        this.adtUpdUserName = adtUpdUserName;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getAdtInsDatTime() {
        return adtInsDatTime;
    }

    public void setAdtInsDatTime(Date adtInsDatTime) {
        this.adtInsDatTime = adtInsDatTime;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getAdtUpdDatTime() {
        return adtUpdDatTime;
    }

    public void setAdtUpdDatTime(Date adtUpdDatTime) {
        this.adtUpdDatTime = adtUpdDatTime;
    }

}
