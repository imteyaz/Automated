package com.minapro.procserver.actors.plc;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.RmiClient;
import com.minapro.procserver.events.plc.PLCSchedulerEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for Starting and Stoping PLC Scheduler Actor. </p>
 * 
 * @author Venkataramana.ch
 *
 */

public class PLCSchedulerStartStopActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(PLCSchedulerStartStopActor.class);

    @Override
    /**
     * Handles  PLC Scheduler Start/Stop
     */
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof PLCSchedulerEvent) {

                PLCSchedulerEvent plcscheduler = (PLCSchedulerEvent) message;
                String plcInstruction = plcscheduler.getInstruction();
                logger.logMsg(LOG_LEVEL.DEBUG, " ", "Received PLC Scheduler Instruction");
                if ("start".equalsIgnoreCase(plcInstruction)) {
                    if (RDTProcessingServer.getInstance().checkIfMasterNode()) {
                        RDTProcessingServer.getInstance().startPLCScheduler(plcscheduler.getOperator());
                    } else {
                        RmiClient.getInstance().startPlc(plcscheduler.getOperator());
                    }
                } else if ("stop".equalsIgnoreCase(plcInstruction)) {
                    if (RDTProcessingServer.getInstance().checkIfMasterNode()) {
                        RDTProcessingServer.getInstance().stopPLCScheduler(plcscheduler.getOperator());
                    } else {
                        RmiClient.getInstance().stopPlc(plcscheduler.getOperator());
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while processing PLCSchedulerStartStopActor -", ex);
        }
    }
}
