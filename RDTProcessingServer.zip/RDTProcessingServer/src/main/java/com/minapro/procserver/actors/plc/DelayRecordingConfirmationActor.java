package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.AUTO_DELAY_CONFIRM_VALIDATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_RECORD_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_DELAY_RECORDING_INTERVAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Calendar;
import java.util.Date;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserDelay;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.ManualDelayRecordingConfirmationEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.AutoDelayReconfirmEvent;
import com.minapro.procserver.events.plc.DelayRecordingConfirmationEvent;
import com.minapro.procserver.events.plc.EndDelayTriggerEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class DelayRecordingConfirmationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DelayRecordingConfirmationActor.class);

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    private static final String ALREADY_OPEN_DELAY = "Already an open delay exists for the selected delay code";
    private static final String ALREADY_OVERLAP_DELAY = "Already an overlap delay exists for the selected delay code";
    private static final String END_DATE_EARLY = "Delay End time can not be less than Delay Start time";
    
    private static final String CLOSE_DELAY_YES = "yes";
    
    @Override
    /**
     * Handles the <DelayRecordingConfirmationEvent> messages from devices
     */
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass().getSimpleName())
                .append(ON_RECEIVE).toString());
        if (message instanceof DelayRecordingConfirmationEvent) {
            DelayRecordingConfirmationEvent delayConfirmEvent = (DelayRecordingConfirmationEvent) message;
            handleAutoDelayConfirmation(delayConfirmEvent);
        } else if (message instanceof ManualDelayRecordingConfirmationEvent) {
            ManualDelayRecordingConfirmationEvent manualdelayConfirmEvent = (ManualDelayRecordingConfirmationEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, manualdelayConfirmEvent.getUserID(), "Received Manual Delay Confirmation -"
                    + manualdelayConfirmEvent);
            generateUserDelayRecords(manualdelayConfirmEvent);
        } else if(message instanceof EndDelayTriggerEvent){
            EndDelayTriggerEvent endDelayTriggerEvent = (EndDelayTriggerEvent)message;
            logger.logMsg(LOG_LEVEL.INFO, endDelayTriggerEvent.getUserID(), "Received End Delay Trigger -"
                    + endDelayTriggerEvent);
            handleEndOpenDelayTrigger(endDelayTriggerEvent);
        } else if(message instanceof AutoDelayReconfirmEvent){
        	AutoDelayReconfirmEvent reconfirmEvent = (AutoDelayReconfirmEvent) message;
        	logger.logMsg(LOG_LEVEL.INFO, reconfirmEvent.getUserID(), "Received Auto delay reconfirmation -"
                    + reconfirmEvent);
        	handleAutoDelayReconfirmation(reconfirmEvent);
    	}else {
            unhandled(message);
        }
    }

    /**
     * Handles the auto delay re-confirmation from user. Depending on the user choice, closes the existing open delay 
     * and create the new one. else keep the existing open delay and ignores the new delay.
     * 
     * @param reconfirmEvent
     */
    private void handleAutoDelayReconfirmation(AutoDelayReconfirmEvent reconfirmEvent) {
    	try{
	    	if(CLOSE_DELAY_YES.equalsIgnoreCase(reconfirmEvent.getCloseDelay())){
	    		logger.logMsg(LOG_LEVEL.INFO, reconfirmEvent.getUserID(), "User opted to close previous delay");
	    		
	    		ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
						.getAllocationDetails(reconfirmEvent.getUserID());

				String rotationId = "";
				if (allocation != null) {
					rotationId = allocation.getRotationID();
				}
				
	    		UserDelay delay = HibernateUtil.getOpenDelay(reconfirmEvent.getEquipmentID(), rotationId);
				if(delay != null){
					logger.logMsg(LOG_LEVEL.INFO, reconfirmEvent.getUserID(), "Open Delay exists - " + delay + ".Closing it");
					EventUtil.getInstance().closeDelay(delay, reconfirmEvent.getUserID());	                
					EventUtil.getInstance().checkAndInformESBOnDelay(reconfirmEvent.getEquipmentID(), 
							delay.getDealyCode(), false, reconfirmEvent.getUserID());
				}
				
				EventUtil.getInstance().createDelay(reconfirmEvent, rotationId, reconfirmEvent.getDelayCode(), 
						reconfirmEvent.getEquipmentID(), true);	
				EventUtil.getInstance().checkAndInformESBOnDelay(reconfirmEvent.getEquipmentID(), 
						reconfirmEvent.getDelayCode(), true, reconfirmEvent.getUserID());
				RDTPLCCacheManager.getInstance().addOpenDelayForEquipment(reconfirmEvent.getEquipmentID()); 
	    	}else {
	    		logger.logMsg(LOG_LEVEL.INFO, reconfirmEvent.getUserID(), "User opted not to keep old delay");
	    	}	
    	}catch(Exception ex){
    		logger.logException("Caught exception on handleAutoDelayReconfirmation" , ex);
    	}
	}

	/**
     * Retrieves the open delay for the specified rotation and equipment logged in, and closes the delay.
     * Also removes the open delay marking from the cache.
     * 
     * @param endDelayTriggerEvent
     */
    private void handleEndOpenDelayTrigger(EndDelayTriggerEvent endDelayTriggerEvent) {
        try{
            User user = RDTCacheManager.getInstance().getUserDetails(endDelayTriggerEvent.getUserID());
            String rotationId = "";
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                    .getAllocationDetails(endDelayTriggerEvent.getUserID());
            if(allocation != null){
                rotationId = allocation.getRotationID();
            }
            
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Retrieving the end open delay for equip+rotation=" 
                    + endDelayTriggerEvent.getEquipmentID() + "-" + rotationId); 
            UserDelay delay = HibernateUtil.getOpenDelay(endDelayTriggerEvent.getEquipmentID(), rotationId);
            if(delay != null){
                logger.logMsg(LOG_LEVEL.INFO, user.getUserID(),"Existing open delay is " + delay);
                delay.setdelayEndTime(new Date());
                delay.setdelayEndUser(user);
                delay.setmodifyBy(user);
                delay.setmodifyDateTime(new Date());
                JournalEvent journalEvent = new JournalEvent(delay, UPDATETYPE.UPDATE);
                getSender().tell(journalEvent, null);
                
                EventUtil.getInstance().checkAndInformESBOnDelay(endDelayTriggerEvent.getEquipmentID(), 
                		delay.getDealyCode(), false, endDelayTriggerEvent.getUserID());
                RDTPLCCacheManager.getInstance().removeOpenDelayForEquipment(endDelayTriggerEvent.getEquipmentID());    
            } else {
            	logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "No open delay exists");
            }
        }catch(Exception ex){
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("In handleEndAutoDelayTrigger ")
                    .append(REASON).toString(), ex); 
        }
    }

    /**
     * Handles the delay confirmation message from user which was triggered from system.
     * 
     * @param delayConfirmEvent
     * @author UMAMAHESH M
     */
    private void handleAutoDelayConfirmation(DelayRecordingConfirmationEvent delayConfirmEvent) {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append("handleAutoDelayConfirmation method")
                .append(INPUT).append(delayConfirmEvent.toString()).toString());

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        String loggedInUserID = delayConfirmEvent.getUserID();

        try {
            User user = rdtCacheMgr.getUserDetails(loggedInUserID);
            if (user != null) {
                OPERATOR operatorRole = rdtCacheMgr.getUserLoggedInRole(loggedInUserID);
                logger.logMsg(LOG_LEVEL.INFO, loggedInUserID, "Current Operator Role Is " + operatorRole);
                
                String rotationId = "";
                ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                        .getAllocationDetails(user.getUserID());
                if(allocation != null){
                    rotationId = allocation.getRotationID();
                }
                
                UserDelay openDelay = HibernateUtil.getOpenDelay(delayConfirmEvent.getEquipmentID(), rotationId);                
                if(openDelay != null){
                	logger.logMsg(LOG_LEVEL.WARN, user.getUserID(), "Already an open delay exists for the equipment - "
                            + openDelay);
                	sendAutoDelayConfirmValidationResponse(delayConfirmEvent, openDelay.getDealyCode(), false);
                	return;
                }
                logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending the delay details to the database - "
                        + delayConfirmEvent);

                UserDelay userDelay = constructUserDelay(delayConfirmEvent, user, delayConfirmEvent.getReasonCode(),
                        "A", delayConfirmEvent.getEquipmentID());
                userDelay.setdelayStartUser(user);
                userDelay.setdelayStartTime(calculateDelayStartTime(delayConfirmEvent.getEquipmentID()));

                JournalEvent journalEvent = new JournalEvent(userDelay, UPDATETYPE.ADD);
                getSender().tell(journalEvent, null);
                
                logger.logMsg(LOG_LEVEL.INFO, loggedInUserID, "Inserting open auto delay. ");
            	EventUtil.getInstance().checkAndInformESBOnDelay(delayConfirmEvent.getEquipmentID(), 
            			delayConfirmEvent.getReasonCode(), true, loggedInUserID);
                RDTPLCCacheManager.getInstance().addOpenDelayForEquipment(delayConfirmEvent.getEquipmentID()); 
                checkWhetherBreakDownOrUnplannedContainer(delayConfirmEvent, operatorRole);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, loggedInUserID,
                        "User Object Is Not Available In Cache For Current Logged In User");
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("In sendDataToESBAndInsertDataToDB method")
                    .append(REASON).toString(), ex);
        }finally{
        	sendAutoDelayConfirmValidationResponse(delayConfirmEvent, "", true);
        }
    }

    /**
     * Informs the user whether the auto delay created or already an open delay exists for the equipment.
     * @param delayConfirmEvent
     * @param openDelayCode
     * @param isConfirmed
     */
    private void sendAutoDelayConfirmValidationResponse(DelayRecordingConfirmationEvent delayConfirmEvent, 
    		String openDelayCode, boolean isConfirmed) {
    	logger.logMsg(LOG_LEVEL.INFO, delayConfirmEvent.getUserID(), "sendAutoDelayConfirmValidationResponse with openDelayCode=" 
    			+ openDelayCode + ", isConfirmed=" + isConfirmed);
		try {			
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(AUTO_DELAY_CONFIRM_VALIDATION);
	
			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RESP);
			responseToDevice.append(VALUE_SEPERATOR).append(eventTypeID)
							.append(VALUE_SEPERATOR).append(delayConfirmEvent.getEventID())
							.append(VALUE_SEPERATOR).append(new Date())
							.append(VALUE_SEPERATOR).append(isConfirmed)
							.append(VALUE_SEPERATOR).append(openDelayCode)
							.append(VALUE_SEPERATOR).append(delayConfirmEvent.getUserID())
							.append(VALUE_SEPERATOR).append(delayConfirmEvent.getTerminalID());			

			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(delayConfirmEvent.getUserID());
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
					delayConfirmEvent.getTerminalID());
		} catch (Exception e) {
			logger.logException("Caught exception while processing certificateValidationDetails -", e);
		}		
	}

	/**
     * Verifies whether the delay reason selected is tied to breakdown alert code or unplanned container detected. 
     * if yes, construct the breakdown/unplanned container located alert
     * and passes to supervisor actor for further processing.
     * 
     * @param delayConfirmEvent
     * @param role
     */
    private void checkWhetherBreakDownOrUnplannedContainer(DelayRecordingConfirmationEvent delayConfirmEvent, OPERATOR role) {
    	DelayReasonCode reasonCode =  HibernateUtil.getDelayReasonByCode(delayConfirmEvent.getReasonCode());
    	if(reasonCode != null) {
    		ALERTCODE code =  null;
    		boolean isAlertToBeRaised = true;
    		if(ALERTCODE.QC_BREAKDOWN_ALERT.toString().equalsIgnoreCase(reasonCode.getAlertCode())){
    			logger.logMsg(LOG_LEVEL.INFO, delayConfirmEvent.getUserID(), reasonCode.getAlertCode() 
        				+ " -Detected BREAKDOWN as delay reason code, raising alert");
    			code = ALERTCODE.QC_BREAKDOWN_ALERT;
    		}else if(ALERTCODE.QC_UNPLAN_CONTAINER_ALERT.toString().equalsIgnoreCase(reasonCode.getAlertCode())){
    			logger.logMsg(LOG_LEVEL.INFO, delayConfirmEvent.getUserID(), reasonCode.getAlertCode() 
        				+ " -Detected Unplanned Container as delay reason code, raising alert");
    			code = ALERTCODE.QC_UNPLAN_CONTAINER_ALERT;
    		}else {
    			isAlertToBeRaised = false;
    			logger.logMsg(LOG_LEVEL.INFO, delayConfirmEvent.getUserID(), "Delay is Not related to brekdown/unplanned container.");
    		}
    		
    		if(isAlertToBeRaised){
	    		MinaProAlertEvent alert = new MinaProAlertEvent();
	    		alert.setEquipmentID(delayConfirmEvent.getEquipmentID());
	    		alert.setUserID(delayConfirmEvent.getUserID());
	    		alert.setOperatorId(delayConfirmEvent.getUserID());
	    		alert.setAlertCode(code);
	    		getSender().tell(alert, null); 
    		}
    	}		
	}

	/**
     * Calculates the delay start time based on the equipment type
     * 
     * @param equipmentID
     * @return
     */
    private Date calculateDelayStartTime(String equipmentID) {
        String delayInterval = "0";
        Equipment eq = RDTCacheManager.getInstance().getEquipmentDetails(equipmentID);
        if (eq != null) {
            if ("ITV".equals(eq.getEquipmentType().getEquipmentTypeId())) {
                delayInterval = DeviceCommParameters.getInstance().getCommParameter(ITV_DELAY_RECORDING_INTERVAL);
            } else {
                delayInterval = DeviceCommParameters.getInstance().getCommParameter(QC_DELAY_RECORDING);
            }
        }

        int delayTime = Integer.parseInt(delayInterval);

        Calendar delayStartTime = Calendar.getInstance();
        delayStartTime.add(Calendar.SECOND, -delayTime);
        return delayStartTime.getTime();
    }

    /**
     * Method is responsible for inserting the userDelay record in to the DB if there is no open record exists for that
     * user
     * 
     * @param delayConfirmEvent
     * @author Kalyani
     */

    private void generateUserDelayRecords(ManualDelayRecordingConfirmationEvent manualDelay) {

        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(manualDelay.getUserID());
        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        User user = rdtCacheMgr.getUserDetails(manualDelay.getUserID());

        String rotationId = "";
        if (allocation != null) {
            rotationId = allocation.getRotationID();
        }
        // Carries all the records which failed in validations
        StringBuilder errorData = new StringBuilder();
        
        handleUpdateDelayRecords(manualDelay, user, errorData);
        handleNewDelays(rotationId, manualDelay, errorData);        

        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(DELAY_RECORD_RESPONSE);
            StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP).append( VALUE_SEPERATOR
                   ).append( eventTypeID).append( VALUE_SEPERATOR).append( manualDelay.getEventID()).append( VALUE_SEPERATOR);

            if (errorData != null && errorData.length() > 0) {
                responseToDevice.append("N");
            } else {
                responseToDevice.append("Y");
            }
            responseToDevice.append(VALUE_SEPERATOR).append(errorData).append(VALUE_SEPERATOR).append(manualDelay.getUserID())
                    .append(VALUE_SEPERATOR).append(manualDelay.getTerminalID());

            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
                    rdtCacheMgr.getUserLoggedInRole(manualDelay.getUserID()), manualDelay.getTerminalID());
        } catch (Exception ex) {
            logger.logException("Caught exception while sendingresponseToDevice- ", ex);
        }
        
        
    }

    /**
     * Iterate through the new dalays recorded by the user, validates and insert into DB
     * 
     * @param rotationId
     * @param manualDelay
     * @param errorData
     */
    private void handleNewDelays(String rotationId, ManualDelayRecordingConfirmationEvent manualDelay,
            StringBuilder errorData) {

        String[] newDelayRecords = null;
        if (manualDelay.getNewDelayDetails() != null && !manualDelay.getNewDelayDetails().isEmpty()) {
            newDelayRecords = manualDelay.getNewDelayDetails().split("\\" + ROW_SEPARATOR);
        }

        String[] data;
        try {
            if (newDelayRecords != null) {
                for (String newRecord : newDelayRecords) {
                    data = newRecord.split("\\" + ITEM_SEPERATOR);
                    if (data != null && data.length > 2) {
                        UserDelay delayCodeList = HibernateUtil.getOpenDelay(data[1], rotationId);
                        if (delayCodeList != null) {
                            // already open delay exists
                            errorData.append(data[0]).append(ITEM_SEPERATOR).append(data[1]).append(ITEM_SEPERATOR)
                                    .append(ALREADY_OPEN_DELAY).append(ROW_SEPARATOR);
                        } else {

                            Date startTime = null;
                            if (data[2] != null) {
                                startTime = EventUtil.getInstance().convertToDate(data[2]);
                            }
                            Date endTime = null;
                            if (data.length >= 4 && data[3] != null) {
                                endTime = EventUtil.getInstance().convertToDate(data[3]);
                            }
                            
                            if(startTime != null && endTime != null){
                            	long timeDiff = endTime.getTime() - startTime.getTime();
                            	if(timeDiff < 0){
                            		 errorData.append(data[0]).append(ITEM_SEPERATOR).append(data[1]).append(ITEM_SEPERATOR)
                                     	.append(END_DATE_EARLY).append(ROW_SEPARATOR);
                            		 continue;
                            	}
                            }                           
                            long overlapdelayCount = HibernateUtil.checkforOverlapDelays(data[1], rotationId, data[0],
                                    startTime, endTime);
                            if (overlapdelayCount > 0) {
                                // already an overlap delay exists
                                errorData.append(data[0]).append(ITEM_SEPERATOR).append(data[1]).append(ITEM_SEPERATOR)
                                        .append(ALREADY_OVERLAP_DELAY).append(ROW_SEPARATOR);
                            } else {
                                insertDelayRecordToDB(data, errorData, manualDelay);
                            }
                            
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while handleNewDelays- ", ex);
        }
    }

    /**
     * Updates the open delay and mark it as Ended with details in DB
     * 
     * @param manualDelay
     * @param user
     */
    private void handleUpdateDelayRecords(ManualDelayRecordingConfirmationEvent manualDelay, User user, 
    		StringBuilder errorData) {
        String[] updatDelayRecords = null;
        if (manualDelay.getUpdateDelayDetails() != null && !manualDelay.getUpdateDelayDetails().isEmpty()) {
            updatDelayRecords = manualDelay.getUpdateDelayDetails().split("\\" + ROW_SEPARATOR);
        }
        
        String qcId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(user.getUserID());
       
        String[] data;
        Date endTime = null;
        long timeDiff = 0;
        try {
            if (updatDelayRecords != null) {
                for (String updatenewRecord : updatDelayRecords) {
                    data = updatenewRecord.split("\\" + ITEM_SEPERATOR);
                    if (data != null && data.length == 2) {
                        UserDelay userDelay = HibernateUtil.getManualDelayById(Integer.parseInt(data[0]));
                        if (userDelay != null) {
                        	endTime = EventUtil.getInstance().convertToDate(data[1]);
                        	
                        	timeDiff = endTime.getTime() - userDelay.getdelayStartTime().getTime();
                        	if(timeDiff < 0){
                        		 errorData.append(data[0]).append(ITEM_SEPERATOR).append(data[1]).append(ITEM_SEPERATOR)
                              		.append(END_DATE_EARLY).append(ROW_SEPARATOR);
                        		 continue;
                        	}
                        	
                            userDelay.setdelayEndTime(endTime);
                            userDelay.setdelayEndUser(user);
                            userDelay.setmodifyBy(user);
                            userDelay.setmodifyDateTime(manualDelay.getTimeStamp());
                            JournalEvent journalEvent = new JournalEvent(userDelay, UPDATETYPE.UPDATE);
                            getSender().tell(journalEvent, null);
                            
                            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "closing the delay-" + userDelay);
                        	EventUtil.getInstance().checkAndInformESBOnDelay(qcId, userDelay.getDealyCode(), false, user.getUserID());
                        	RDTPLCCacheManager.getInstance().removeOpenDelayForEquipment(qcId);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while handleUpdateDelayRecords- ", ex);
        }
    }

    private void insertDelayRecordToDB(String[] record, StringBuilder errorRecord, Event delayConfirmEvent) {
        RDTCacheManager cacheManager = RDTCacheManager.getInstance();
        String loggedInUserID = delayConfirmEvent.getUserID();
        User user = cacheManager.getUserDetails(loggedInUserID);

        UserDelay userDelay = constructUserDelay(delayConfirmEvent, user, record[0], "M", record[1]);

        // checking if the start time is filled
        if (record.length >= 3 && record[2] != null) {
            userDelay.setdelayStartUser(user);
            userDelay.setdelayStartTime(EventUtil.getInstance().convertToDate(record[2]));
        }

        // Checking if the end time is filled
        if (record.length >= 4 && record[3] != null) {
            userDelay.setdelayEndUser(user);
            userDelay.setdelayEndTime(EventUtil.getInstance().convertToDate(record[3]));
        }else {
        	logger.logMsg(LOG_LEVEL.INFO, loggedInUserID, "Inserting open delay. ");
        	EventUtil.getInstance().checkAndInformESBOnDelay(record[1], record[0], true, loggedInUserID);
        	RDTPLCCacheManager.getInstance().addOpenDelayForEquipment(record[1]);
        }

        JournalEvent journalEvent = new JournalEvent(userDelay, UPDATETYPE.ADD);
        getSender().tell(journalEvent, null);
    }

    /**
     * Constructs the userDelay object
     * 
     * @param delayConfirmEvent
     * @param user
     * @author kalyani
     */

    private UserDelay constructUserDelay(Event delayConfirmEvent, User user, String delayCode, String isAutomatic,
            String equipmentId) {

        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(delayConfirmEvent.getUserID());

        UserDelay userDelay = new UserDelay();
        userDelay.setDealyCode(delayCode);
        userDelay.setTerminalId(delayConfirmEvent.getTerminalID());
        userDelay.setRotationId(allocation.getRotationID());
        userDelay.setEquipmentID(equipmentId);
        userDelay.setIsDeleted("N");
        userDelay.setCreatedDatetime(delayConfirmEvent.getTimeStamp());
        userDelay.setCreatedBy(user);
        userDelay.setIsAutomated(isAutomatic);

        return userDelay;
    }
}