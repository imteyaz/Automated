package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.UserDelay;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.AccidentIncidentConfirmEvent;
import com.minapro.procserver.events.common.AccidentIncidentRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the accident/Incident related requests from the devices.
 * 
 * Accident/Incident can be reported from users with different roles who work at Quay side. Report contains which QC is
 * affected. And if the QC operator itself is reporting, then it also mentions whether the QC can continue work or not.
 * 
 * When the accident/Incident is reported, an alert is generated for the same. Also if QC can not work, a manual open
 * delay is created.
 * 
 * @author Rosemary George
 *
 */
public class AccidentIncidentActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(AccidentIncidentActor.class);

	private static final String QC = "QC";
	private static final String SUCCESS = "Success";
	private static final String FAILURE = "Failure";

	private static final String NO_EQUIPMENT_SELECTED = "Request failed - NO Equipment selected.";
	private static final String EXCEPTION_OCCURED = "Request failed with Error. Please try again";
	
	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd/MM/yyyy HH:mm");

	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			ROW_SEPERATOR_KEY);
	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			ITEM_SEPERATOR_KEY);

	@Override
	public void onReceive(Object message) throws Exception {
		if (message instanceof AccidentIncidentRequestEvent) {
			AccidentIncidentRequestEvent requestEvent = (AccidentIncidentRequestEvent) message;
			handleAccidentIncidentRequest(requestEvent);
		} else if (message instanceof AccidentIncidentConfirmEvent) {
			AccidentIncidentConfirmEvent confirmEvent = (AccidentIncidentConfirmEvent) message;
			handleAccidentIncidentConfirmation(confirmEvent);
		} else {
			getSender().forward(message, null);
		}
	}

	/**
	 * Handles the Accident/Incident confirmation from the user.
	 * 
	 * @param confirmEvent
	 */
	private void handleAccidentIncidentConfirmation(AccidentIncidentConfirmEvent confirmEvent) {
		String status = SUCCESS;
		String errorMessage = "";

		try {
			logger.logMsg(LOG_LEVEL.INFO, confirmEvent.getUserID(), "Receieved accident incident confirmation-"
					+ confirmEvent);

			ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
					.getAllocationDetails(confirmEvent.getUserID());

			String rotationId = "";
			if (allocation != null) {
				rotationId = allocation.getRotationID();
			}
			
			if (confirmEvent.getQcId() != null && !confirmEvent.getQcId().isEmpty()) {
				if (!confirmEvent.canContinueWork() && confirmEvent.isCreateDelay()) {
					logger.logMsg(LOG_LEVEL.DEBUG, confirmEvent.getUserID(),
							"Raising Delay- canContinueWork=" + confirmEvent.canContinueWork() 
							+ " and opted for createDelay=" + confirmEvent.isCreateDelay());
					UserDelay delay = HibernateUtil.getOpenDelay(confirmEvent.getQcId(), rotationId);
					if(delay != null){
						logger.logMsg(LOG_LEVEL.INFO, confirmEvent.getUserID(), "Open Delay exists - " + delay + ".Closing it");
						EventUtil.getInstance().closeDelay(delay, confirmEvent.getUserID());	                
						EventUtil.getInstance().checkAndInformESBOnDelay(confirmEvent.getQcId(), 
								delay.getDealyCode(), false, confirmEvent.getUserID());
					}else {
						logger.logMsg(LOG_LEVEL.INFO, confirmEvent.getUserID(), "No Open Delay exists");
						RDTPLCCacheManager.getInstance().addOpenDelayForEquipment(confirmEvent.getQcId());
					}
					EventUtil.getInstance().createDelay(confirmEvent, rotationId, confirmEvent.getDelayCode(), confirmEvent.getQcId(), false);	
					EventUtil.getInstance().checkAndInformESBOnDelay(confirmEvent.getQcId(), 
							confirmEvent.getDelayCode(), true, confirmEvent.getUserID());
				}
				createAccidentAlert(confirmEvent, rotationId);
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, confirmEvent.getUserID(), "QC ID is empty or null.");
				status = FAILURE;
				errorMessage = NO_EQUIPMENT_SELECTED;
			}
		} catch (Exception ex) {
			logger.logException("Caught Exception while handleAccidentIncidentConfirmation", ex);
			status = FAILURE;
			errorMessage = EXCEPTION_OCCURED;
		}

		sendAccidentIncidentConfirmResponse(status, errorMessage, confirmEvent);
	}

	/**
	 * Constructs and send the accident/Incident confirmation response back to the device.
	 * 
	 * @param status
	 * @param errorMessage
	 * @param confirmEvent
	 */
	private void sendAccidentIncidentConfirmResponse(String status, String errorMessage,
			AccidentIncidentConfirmEvent confirmEvent) {
		try {

			String eventTypeID = DeviceEventTypes.getInstance().getEventType(
					RDTProcessingServerConstants.ACCIDENT_INCIDENT_CONFIRM_STATUS);

			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP).
					append(VALUE_SEPARATOR).append(eventTypeID);
					
			responseToDevice.append(VALUE_SEPARATOR).append(confirmEvent.getEventID()).append(VALUE_SEPARATOR)
					.append(status).append(VALUE_SEPARATOR).append(errorMessage).append(VALUE_SEPARATOR)
					.append(confirmEvent.getUserID()).append(VALUE_SEPARATOR).append(confirmEvent.getTerminalID());

			OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(confirmEvent.getUserID());
		
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
					confirmEvent.getTerminalID());

		} catch (Exception ex) {
			logger.logException("Caught Exception while handleAccidentIncidentRequest", ex);
		}
	}

	/**
	 * Creates Accident/Incident alert and pass to MasterActor for further processing
	 * 
	 * @param confirmEvent
	 * @param rotationId
	 */
	private void createAccidentAlert(AccidentIncidentConfirmEvent confirmEvent, String rotationId) {
		MinaProAlertEvent alert = new MinaProAlertEvent();
		alert.setAlertCode(ALERTCODE.QC_ACCIDENT_INCIDENT_ALERT);
		alert.setEquipmentID(confirmEvent.getQcId());
		alert.setOperatorId(confirmEvent.getUserID());
		alert.setUserID(confirmEvent.getUserID());
		alert.setRotationId(rotationId);
		
		//DPW provided date format -  DD/MM/YYYY HH:MM
		String reportedTime = DATE_FORMATTER.format(confirmEvent.getTimeStamp());
		alert.setReportedTime(reportedTime);

		logger.logMsg(LOG_LEVEL.DEBUG, confirmEvent.getUserID(), "Generating alert : Accident/Incident reported for "
				+ confirmEvent.getQcId());

		RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
	}	

	/**
	 * Handles the Accident/Incident request event from device. Sends the list of QCs available as response
	 * 
	 * @param requestEvent
	 */
	private void handleAccidentIncidentRequest(AccidentIncidentRequestEvent requestEvent) {
		try {

			logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Receieved accident incident request event-"
					+ requestEvent);

			String eventTypeID = DeviceEventTypes.getInstance().getEventType(
					RDTProcessingServerConstants.ACCIDENT_INCIDENT_RESPONSE);
			
			Map<String, UserDelay> qcDelays = HibernateUtil.getOpenDelayForAllQCs();
			OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(requestEvent.getUserID());
			
			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP + VALUE_SEPARATOR
					+ eventTypeID);
			responseToDevice.append(VALUE_SEPARATOR).append(requestEvent.getEventID()).append(VALUE_SEPARATOR);

			List<String> qcIds = RDTCacheManager.getInstance().getEquipmentDetailsOfType(QC);
			for (String qc : qcIds) {
				responseToDevice.append(qc).append(ITEM_SEPARATOR);
				responseToDevice.append(qcDelays.get(qc) != null ? qcDelays.get(qc).getDealyCode() : "");
				responseToDevice.append(ROW_SEPARATOR);
			}
			EventUtil.getInstance().removeTrailingSeparator(ROW_SEPARATOR, responseToDevice);

			responseToDevice.append(VALUE_SEPARATOR);
			
			List<DelayReasonCode> reasonCodes = (List<DelayReasonCode>) HibernateUtil.getReasonCodes();

            logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Size of List : " + reasonCodes.size());
            for (DelayReasonCode delayReason : reasonCodes) {
            	if(role.toString().equalsIgnoreCase(delayReason.getSubType())){
            		responseToDevice.append(delayReason.getDelaypk().getDelayReasonCodeID()).append(ITEM_SEPARATOR)
                        .append(delayReason.getDelayReasonDescription()).append(ROW_SEPARATOR);
            	}
            }
            EventUtil.getInstance().removeTrailingSeparator(ROW_SEPARATOR, responseToDevice);
            
			responseToDevice.append(VALUE_SEPARATOR).append(requestEvent.getUserID()).append(VALUE_SEPARATOR)
					.append(requestEvent.getTerminalID());
			
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
					requestEvent.getTerminalID());

		} catch (Exception ex) {
			logger.logException("Caught Exception while handleAccidentIncidentRequest", ex);
		}
	}
}
