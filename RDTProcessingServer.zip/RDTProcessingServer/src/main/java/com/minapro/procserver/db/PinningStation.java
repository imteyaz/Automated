package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding the pinning station details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_PINNINGSTATION_MASTER")
public class PinningStation extends Audit implements Serializable {

    private static final long serialVersionUID = 705303780513279929L;

    @Id
    @Column(name = "pinning_station_id", nullable = false)
    private String pinningStationID;

    @Column(name = "description")
    private String description;

    @Column(name = "availability")
    private String availabilityStatus;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "terminal_id", referencedColumnName = "terminal_id")
    private Terminal terminal;

    public Terminal getTerminal() {
        return terminal;
    }

    public void setTerminal(Terminal terminal) {
        this.terminal = terminal;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPinningStationID() {
        return pinningStationID;
    }

    public void setPinningStationID(String pinningStationID) {
        this.pinningStationID = pinningStationID;
    }

    public String getAvailabilityStatus() {
        return availabilityStatus;
    }

    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }
}
