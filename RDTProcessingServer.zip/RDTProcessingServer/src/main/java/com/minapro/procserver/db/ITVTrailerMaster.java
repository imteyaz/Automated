package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Value object holding the ITV trailer master details
 * 
 * @author 1201257
 * 
 */
@Entity
@Table(name = "MP_TRAILER_MASTER")
public class ITVTrailerMaster implements Serializable {

    private static final long serialVersionUID = 2761203890600793597L;

    @Id
    @SequenceGenerator(name = "seq_gen", sequenceName = "MP_TRAILER_MASTER_ID", allocationSize = 1)
    @GeneratedValue(generator = "seq_gen")
    @Column(name = "TRAILER_ID")
    private Integer trailerId;

    @Column(name = "TRAILER_NO")
    private String trailerNo;

    public Integer getTrailerId() {
        return trailerId;
    }

    public void setTrailerId(Integer trailerId) {
        this.trailerId = trailerId;
    }

    public String getTrailerNo() {
        return trailerNo;
    }

    public void setTrailerNo(String trailerNo) {
        this.trailerNo = trailerNo;
    }

    @Override
    public String toString() {
        return "ITVTrailerMaster [trailerId=" + trailerId + ", trailerNo=" + trailerNo + "]";
    }
}
