package com.minapro.procserver.events.hc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Class is responsible to hold the response from OPUS system related to Orphan/OutOfList Container request. If result is true
 * means success from the OPUS else failed at OPUS,Same will be communicated to Tally UI Application.
 * 
 * @author Umamahesh M
 *
 */
public class OrphanContainerResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -7722563437365624455L;
    /**
     * Holds True or False(T/F).
     */
    private boolean containerCreationStatus;

    /**
     * Indicates the container which has been moved
     */
    private String containerId;

    /**
     * Indicates the error message received from TOS
     */
    private String errorMessage;
    
    /**
     * Orphan/Out Of List Container ITV Number.
     * Which is used to persist into Completed Moves Table.
     */
    private String itvNo;
    
    /**
     * From location of the container
     */
    private String fromLocation;
    
    /**
     * ISO code of the container
     */
    private String isoCode;

    public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

    public String getItvNo() {
		return itvNo;
	}

	public void setItvNo(String itvNo) {
		this.itvNo = itvNo;
	}

	public boolean getContainerCreationStatus() {
        return containerCreationStatus;
    }

    public void setContainerCreationStatus(boolean containerCreationStatus) {
        this.containerCreationStatus = containerCreationStatus;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

	@Override
	public String toString() {
		return "OrphanContainerResponseEvent [containerCreationStatus=" + containerCreationStatus + ", containerId="
				+ containerId + ", errorMessage=" + errorMessage + ", itvNo=" + itvNo + ", fromLocation="
				+ fromLocation + ", isoCode=" + isoCode + ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}	
}
