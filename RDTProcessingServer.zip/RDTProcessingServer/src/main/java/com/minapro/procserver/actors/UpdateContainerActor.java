package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ESB_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_OBJECT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.UPDATED_CONTAINER_STATUS_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.UPDATE_CONTAINER_INQUIRY_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Collection;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.ISOCodesMaster;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerInquiryRequestEvent;
import com.minapro.procserver.events.UpdateContainerInquiryResponseEvent;
import com.minapro.procserver.events.UpdateContainerResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the Update container attribute event from the devices
 * 
 * @author ROSEMARY GEORGE
 * @author UMAMAHESH M
 */
public class UpdateContainerActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(UpdateContainerActor.class);
	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);

	@Override
	public void onReceive(Object message) throws Exception {

		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(ON_RECEIVE).toString());

		if (message instanceof UpdateContainerEvent) {
			postUpdatedCntrDetailsToESB((UpdateContainerEvent) message);
		} else if (message instanceof UpdateContainerResponseEvent) {
			sendUpdatedCntrStatusToUI((UpdateContainerResponseEvent) message);
		} else if (message instanceof UpdateContainerInquiryRequestEvent) {
			postUpdateCntrDtlsGetReqToESB((UpdateContainerInquiryRequestEvent) message);
		} else if (message instanceof UpdateContainerInquiryResponseEvent) {
			logger.logMsg(LOG_LEVEL.INFO, "", " Update Required Container Details Received." + message);
			sendUpdateCntrDetailsToUI((UpdateContainerInquiryResponseEvent) message);
		} else {
			unhandled(message);
		}
	}

	private void sendUpdateCntrDetailsToUI(UpdateContainerInquiryResponseEvent event) {

		try {

			StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR)
					.append(DeviceEventTypes.getInstance().getEventType(UPDATE_CONTAINER_INQUIRY_RESPONSE))
					.append(VALUE_SEPERATOR).append(event.getEventID() == null ? UUID.randomUUID().toString() : event.getEventID())
					.append(VALUE_SEPERATOR);

			preapreUpdateCntrDetails(event, responseToDevice);
	
			responseToDevice.append(event.getUserID()).append(VALUE_SEPERATOR).append(event.getTerminalID());

			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
					RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID()), event.getTerminalID());

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" sendUpdateCntrDetailsToUI ").append(REASON)
							.toString(), ex);
		}
	}

	private void postUpdateCntrDtlsGetReqToESB(UpdateContainerInquiryRequestEvent message) {
		ESBQueueManager.getInstance().postMessage(message, OPERATOR.COMMON, message.getTerminalID());
	}

	private void sendUpdatedCntrStatusToUI(UpdateContainerResponseEvent message) {

		logger.logMsg(LOG_LEVEL.INFO, message.getUserID(),
				new StringBuilder(" Current Container::").append(message.getContainerID())
						.append(" Data Updation Status TO OPUS Is::").append(message.isSuccess()).toString());

		StringBuilder responseToDevice = new StringBuilder(RESP);		
		try {
			String cntrUpdatedStsMsg = "Container::".concat(message.getContainerID()).concat(" Details ");
			boolean status = message.isSuccess();
			
			cntrUpdatedStsMsg = status ? cntrUpdatedStsMsg.concat(" Updated Successfully") 
					: cntrUpdatedStsMsg.concat(" Not Updated To TOS ");
			
			responseToDevice.append(VALUE_SEPERATOR)
					.append(DeviceEventTypes.getInstance().getEventType(UPDATED_CONTAINER_STATUS_RESPONSE))
					.append(VALUE_SEPERATOR).append(message.getEventID()).append(VALUE_SEPERATOR)
					.append(status?"true" :"false").append(VALUE_SEPERATOR).append(cntrUpdatedStsMsg).append(VALUE_SEPERATOR).append(message.getUserID())
					.append(VALUE_SEPERATOR).append(message.getTerminalID());

			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
					RDTCacheManager.getInstance().getUserLoggedInRole(message.getUserID()), message.getTerminalID());

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" sendUpdatedCntrStatusToUI ").append(REASON)
							.toString(), ex);
		}
	}

	/**
	 * <p> Method is responsible for handling all Update and View Container Attributes Request. Based on the Operator
	 * role sending message to ESB server. If operator role is QC and HC send UpdateContainerEvet to the ESB server with
	 * same logged in userId. If operator role is ForeMan change user id to the qcUserId. </p> <p> While updating
	 * JobList, If operator role is HC and ForeMan get QC user related JobList. </p>
	 */
	private void postUpdatedCntrDetailsToESB(UpdateContainerEvent updateContainer) {

		logger.logMsg(LOG_LEVEL.INFO, updateContainer.getUserID(), new StringBuilder(
				"Received Updated container attributes request from the device - ").append(updateContainer.toString())
				.toString());

		try {

			final String loggedInUserID = updateContainer.getUserID();
			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(loggedInUserID);
			logger.logMsg(LOG_LEVEL.INFO, loggedInUserID, "Current Operator Role Is " + operatorRole);

			if (RDTCacheManager.getInstance().getUserDetails(loggedInUserID) != null) {
				if (operatorRole.equals(OPERATOR.HC)) {
					updateContainer.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
							loggedInUserID));
				}

				logger.logMsg(LOG_LEVEL.INFO, loggedInUserID,
						new StringBuilder(POST_DATA).append(ESB_QUEUE_MGR).append(FINAL_CREATED_OBJECT)
								.append(" Queue ::").append(OPERATOR.COMMON).append(updateContainer.toString())
								.toString());
				// Send UpdateContainer to ESB Server
				ESBQueueManager.getInstance().postMessage(updateContainer, OPERATOR.COMMON,
						updateContainer.getTerminalID());
			}
		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("In sendContainerUpdateToESBAndUpdateJobList method")
							.append(REASON).toString(), ex);
		}
	}

	/**
	 * Method is used to prepare Container Update Details InTo Sepearate String.
	 * 1~1~4001~806929846~ContainerID~Line~Category~False~IsoCode1|IsoCode2|IsoCode3|IsoCode4|IsoCode5~POD~
	 * NPOD~FPOD~20~
	 * Weight~11|12|13|14|15~PlugCode~Vessel~OutVessel~Voyage~OutVoyage~Seal1~Seal2~Seal3~Seal4~Seal5~user1~2
	 */

	public void preapreUpdateCntrDetails(UpdateContainerInquiryResponseEvent event, StringBuilder responseToDevice) {

		if(event.getUpdateContainerEvent()!= null && event.isInquiryStatus()) {
			String isoCode = event.getUpdateContainerEvent().getIsoCode();

			responseToDevice.append(event.getUpdateContainerEvent().getContainerID()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getLineCode()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getCategory()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().isEmpty() ? "True" : "False").append(VALUE_SEPERATOR)
			.append(JobListUtil.prepareIsoCodes()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getPod()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getNpod()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getFpod()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSize()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getWeight()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getOogDimensions()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getPlugCode()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getVessel()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getOutVessel()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getVoyage()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getOutVoyage()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSeal1()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSeal2()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSeal3()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSeal4()).append(VALUE_SEPERATOR)
			.append(event.getUpdateContainerEvent().getSeal5()).append(VALUE_SEPERATOR)
			.append(isoCode!=null && !isoCode.isEmpty() ? 
					prepareISOCOdeDesc(isoCode) : isoCode).append(VALUE_SEPERATOR);
		} else {
			responseToDevice.append(VALUE_SEPERATOR);
		}
	}
	
	
	public String prepareISOCOdeDesc(String isoCode) {
		
		Collection<ISOCodesMaster> isoCodes = RDTCacheManager.getInstance().getISOCodes();		
		
		if(isoCodes!=null && !isoCodes.isEmpty()){			
			
			for(ISOCodesMaster isoCodeData :isoCodes){
				if(isoCodeData.getIsoCode().equalsIgnoreCase(isoCode)){
					logger.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" ISo Codes Matched").append(" ISO Code::").append(isoCode)
							.append(" Descritpion Is::").append(isoCodeData.getCodeDescription()).toString());
					return isoCode.concat("-").concat(isoCodeData.getCodeDescription());
				}
			}
			
		} 
		return null;
	}
}
