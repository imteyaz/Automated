package com.minapro.procserver.events.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the current position of a particular ITV
 * 
 * @author Rosemary George
 *
 */
public class ITVArrivalEvent extends Event implements Serializable {
    private static final long serialVersionUID = -6264609993108163156L;

    private static String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVArrivalEvent.class);

    /**
     * The location where the ITV has arrived - can be QC, Pinning station or Yard Block
     */
    private String locationID;
    /**
     * The Container ID which the ITV is carrying (if any)
     */
    private List<String> containerIDs;
    
    /**
     * will be filled when ITV arrives at QC location
     */
    private String laneId;
    
    /**
     * will be filled when ITV arrives at yard location
     */
    private String blockId;

    public String getLaneId() {
		return laneId;
	}

	public void setLaneId(String laneId) {
		this.laneId = laneId;
	}

	public String getBlockId() {
		return blockId;
	}

	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}

	public List<String> getContainerIDs() {
        return containerIDs;
    }

    public void setContainerIDs(String containerIDs) {
        try {
            String[] containers = containerIDs.split("\\" + rowSeparator);
            this.containerIDs = new ArrayList<String>(Arrays.asList(containers));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting container IDs:", ex);
            this.containerIDs = new ArrayList<String>();
        }
    }

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

	@Override
	public String toString() {
		return "ITVArrivalEvent [locationID=" + locationID + ", containerIDs=" + containerIDs + ", laneId=" + laneId
				+ ", blockId=" + blockId + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}
}
