package com.minapro.procserver.util;

import java.util.Collection;
import java.util.Set;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is designed to prepare the all blocks skeleton which are available in corresponding terminal
 * @author Uma
 *
 */
public class YardSkeletonConstructor implements Runnable{
    
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(YardSkeletonConstructor.class);
	
	@Override
	public void run() {
		
		logger.logMsg(LOG_LEVEL.INFO,""," YardSkeletonConstructor Run() Started.");
		CHEJobListService.getInstance().loadBlockDetailsToCache();
		prepareBlocksSkeleton();
		
	}

	private void prepareBlocksSkeleton() {

	
		Set<String> availableBlocksList = RDTYardProfileCacheManager.getInstance().getBlockIdsAvailableInATOM();

		logger.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Blocks Defined In Atom::").append(availableBlocksList).toString());

		if(availableBlocksList!=null && !availableBlocksList.isEmpty()) {

			prepareBlockSkeleton(availableBlocksList);
		
		} else {
			logger.logMsg(LOG_LEVEL.WARN,""," Zero Blocks Are Defined In ATOM Database");
		}

	}
	
	public static void prepareBlockSkeleton(Collection<String> availableBlocksList){
		
		for(String blockNumber : availableBlocksList) {

			BlockProfile.prepareRowData(blockNumber,true);

			BlockProfile.prepareStackData(blockNumber,true);

			BlockProfile.prepareBlockCellDataSkeleton(blockNumber);
		}
	}
	

}
