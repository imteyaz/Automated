package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TECHINCAL_SUPPORT_FILEDS_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Date;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.MpMaximoStagingTable;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.TechSupportRequestEvent;
import com.minapro.procserver.events.common.TechSupportValuesEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class TechnicalSupportActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(TechnicalSupportActor.class);
	private static final String DEFAULT_MESSAGE_STATUS = "New";
	// Always should be EM – Emergency Maintenance as it is created by operational team
	private static final String DEFAULT_WORK_TYPE = "EM";

	private static final String DEFAULT_ACTIVITY_TYPE = "Emergency";

	@Override
	public void onReceive(Object object) throws Exception {
		if (object instanceof TechSupportRequestEvent) {
			sendTechSupportValues((TechSupportRequestEvent) object);
		} else if (object instanceof TechSupportValuesEvent) {
			handleTechSupportValues((TechSupportValuesEvent) object);
		} else {
			unhandled(object);
		}

	}

	/**
	 * Method is responsible for sending the Logged in user current location and equipment, PROBLEM_CODE - Free text
	 * (max 50 character) FAULT_DESCRIPTION - Text Area (max 1000 chars, optional) LOCATION_DESCRIPTION - (max 100
	 * character, Mandatory) ASSET_NUMBER(Equipment) - (max 50 character, Mandatory)
	 * 
	 * @param techReqEvent
	 *            . Final Sample response message:RESP~3101~234566~gc01~QC61~(as of now empty string sending but in
	 *            future it is like problem|problem2)~user1~Terminal-2
	 * 
	 */

	private void sendTechSupportValues(TechSupportRequestEvent techReqEvent) {

		logger.logMsg(LOG_LEVEL.INFO, techReqEvent.getUserID(), new StringBuilder(ENTRY).append(" sendTechSupportValues() ").append(INPUT)
				.append(techReqEvent.toString()).toString());

		String equipmentId = null;
		String location = null;
		String problemCodes = "";

		String userId = techReqEvent.getUserID();


		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
		String terminalId = techReqEvent.getTerminalID();
		String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
		String eventTypeID = DeviceEventTypes.getInstance().getEventType(TECHINCAL_SUPPORT_FILEDS_RESPONSE);

		RDTCacheManager rdtCache = RDTCacheManager.getInstance();

		ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) rdtCache.getAllocationDetails(userId);

		if (null != allocationDetails) {
			// TODO:Multiple Equipment Id's will get If operator role is other than Equipment Operators like OBF and
			// Supervisor
			equipmentId = allocationDetails.getEquipmentID();
			location = allocationDetails.getLocation();
			// TODO::We have to get problem codes from minapro database or ESB..Depending on availability need to
			// implement in future

		} else {
			logger.logMsg(LOG_LEVEL.INFO, userId, " Allocation details Are Not Available for current user");
		}

		StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID).
				append(valueSeperator).append(techReqEvent.getEventID()).append(valueSeperator);

		responseToDevice.append(location).append(valueSeperator).append(equipmentId).append(valueSeperator)
		.append(problemCodes).append(valueSeperator).append(userId).append(valueSeperator).append(terminalId);

		logger.logMsg(LOG_LEVEL.INFO, userId,
				new StringBuffer(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG).append(responseToDevice)
				.toString());
		CommunicationServerQueueManager.getInstance()
		.postMessage(responseToDevice.toString(), operatorRole, terminalId);

	}

	/**
	 * Method is responsible for insert the user entered data into the staging table. In future need to send same data
	 * to ESB also for interacting with MAXIMO system.
	 * 
	 * @param techSupportValues
	 */

	private void handleTechSupportValues(TechSupportValuesEvent techSupportValues) {
		
		logger.logMsg(LOG_LEVEL.INFO,techSupportValues.getUserID(),new StringBuilder(ENTRY).append(" sendTechSupportValues() ").append(INPUT)
				.append(techSupportValues.toString()).toString());
		
		// TODO::When ever Staging table available,Insert this pojo related data into the database

		String userId = techSupportValues.getUserID();

		String terminal = techSupportValues.getTerminalID();

		String equipmentId = techSupportValues.getEquipmentID();

		MpMaximoStagingTable mpStagingTable = new MpMaximoStagingTable();
		
		// Either Planned activity or Emergency
		mpStagingTable.setActivityType(DEFAULT_ACTIVITY_TYPE);
		mpStagingTable.setAssetNumber(techSupportValues.getAssetNumber());
		mpStagingTable.setCreatedDttm(new Date());
		mpStagingTable.setFaultDescription(techSupportValues.getProblemDescription());
		mpStagingTable.setLocationDescription(techSupportValues.getLocationDescription());
	
		// NEW,READ,FAIL – status of the message
		mpStagingTable.setMessageStatus(DEFAULT_MESSAGE_STATUS);
		mpStagingTable.setOperatorId(userId);
		mpStagingTable.setProblemCode(techSupportValues.getProblemCodes());
	
		// ID of the source system which has created the record,
		mpStagingTable.setSourcesystemId(equipmentId);
		mpStagingTable.setTerminalId(terminal);
		// Current status of Work Order
		mpStagingTable.setWorkorderStatus(DEFAULT_MESSAGE_STATUS);
		mpStagingTable.setWorkType(DEFAULT_WORK_TYPE);
	
		logger.logMsg(LOG_LEVEL.INFO, userId, "Before Inserting Data Into Staging Table MpStagingTableEntity Value Is "
				+ mpStagingTable.toString());
		
		try {
			HibernateUtil.saveData(mpStagingTable);
		} catch (Exception ex) {
			logger.logException("Exception Occured In handleTechSupportValues While Inserting Data", ex);
		}
		// //TODO:Send POJO to ESB for further operations..
	}

}
