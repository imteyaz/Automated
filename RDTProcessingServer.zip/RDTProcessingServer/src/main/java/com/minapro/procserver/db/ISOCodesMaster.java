package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_ISO_CODES_MASTER")
public class ISOCodesMaster implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ISO_CODE")
	private String isoCode;

	@Column(name = "CODE_DESCRIPTION")
	private String codeDescription;

	@Column(name = "ISO_TYPE")
	private String isoType;

	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public String getCodeDescription() {
		return codeDescription;
	}

	public void setCodeDescription(String codeDescription) {
		this.codeDescription = codeDescription;
	}

	public String getIsoType() {
		return isoType;
	}

	@Override
	public String toString() {
		return "ISOCodesMaster [isoCode=" + isoCode + ", codeDescription=" + codeDescription + ", isoType=" + isoType
				+ "]";
	}

	public void setIsoType(String isoType) {
		this.isoType = isoType;
	}

}
