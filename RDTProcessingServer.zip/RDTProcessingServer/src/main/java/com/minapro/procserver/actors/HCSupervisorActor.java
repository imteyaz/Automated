package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.hc.OrphanContainerActor;
import com.minapro.procserver.actors.hc.SwapActor;
import com.minapro.procserver.actors.hc.TroubleshootActor;
import com.minapro.procserver.events.hc.ITVSwapResponseEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OrphanContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.hc.SwapResponseEvent;
import com.minapro.procserver.events.hc.TroubleshootAreasGetRequestEvent;
import com.minapro.procserver.events.hc.TroubleshootConfirmRequestEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Following Class Is a supervisor actor for handling all HC Operator operations.
 * 
 * @author Umamahesh M
 *
 */
public class HCSupervisorActor extends UntypedActor {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(HCSupervisorActor.class);
    /**
     * 
     * Following actor is responsible for handling OrphanContainer event related messages
     * 
     */
    private ActorRef orphanContainerActor = getContext().actorOf(
            Props.create(OrphanContainerActor.class).withRouter(new FromConfig()), "orphanContainer");
    /**
     * Following Actor Is Responsible For Handling TroubleShoot related requests and responses.
     * 
     */
    private ActorRef troubleShootActor = getContext().actorOf(
            Props.create(TroubleshootActor.class).withRouter(new FromConfig()), "troubleShoot");

    /**
     * Actor handling the swap requests and responses
     */
    private ActorRef swapActor = getContext().actorOf(Props.create(SwapActor.class).withRouter(new FromConfig()),
            "Swap");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {
                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    public void onReceive(Object message) throws Exception {
    	logger.logMsg(LOG_LEVEL.DEBUG, message.getClass().getSimpleName(), "Received at HCSupervisorActor");
    	
    	if (message instanceof OrphanContainerEvent || message instanceof OrphanContainerResponseEvent || 
        		message instanceof OutOfListContainersRequestEvent || message instanceof OutOfListContainerResponseEvent) {
            orphanContainerActor.tell(message, getSelf());
        } else if (message instanceof TroubleshootConfirmRequestEvent) {
            troubleShootActor.tell(message, getSelf());
        } else if (message instanceof TroubleshootAreasGetRequestEvent) {
            troubleShootActor.tell(message, getSelf());
        } else if (message instanceof SwapRequestEvent || 
        		message instanceof SwapResponseEvent ||
        		message instanceof ITVSwapResponseEvent) {
            swapActor.tell(message, getSelf());
        } else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, null);
        }
    }
}
