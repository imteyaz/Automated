package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * BlkrowYpmId entity.
 * 
 * @author UMAMAHESH
 */
@Embeddable
public class BlkrowYpmId implements java.io.Serializable {

    private static final long serialVersionUID = -8848975572604923362L;

    @Column(name = "INT_BLK_NO")
    private Integer intBlkNo;

    @Column(name = "ROW_SEQ_NO")
    private Short rowSeqNo;

    public Integer getIntBlkNo() {
        return this.intBlkNo;
    }

    public void setIntBlkNo(Integer intBlkNo) {
        this.intBlkNo = intBlkNo;
    }

    public Short getRowSeqNo() {
        return this.rowSeqNo;
    }

    public void setRowSeqNo(Short rowSeqNo) {
        this.rowSeqNo = rowSeqNo;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (!(other instanceof BlkrowYpmId)) {
            return false;
        }
        BlkrowYpmId castOther = (BlkrowYpmId) other;

        return this.getIntBlkNo() == castOther.getIntBlkNo() || (this.getIntBlkNo() != null
                && castOther.getIntBlkNo() != null && this.getIntBlkNo().equals(castOther.getIntBlkNo()));
    }

    @Override
    public int hashCode() {
        int result = 17;

        result = 37 * result + (getIntBlkNo() == null ? 0 : this.getIntBlkNo().hashCode());
        result = 37 * result + (getRowSeqNo() == null ? 0 : this.getRowSeqNo().hashCode());
        return result;
    }

}