package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the completed joblist request initiated from UI
 * 
 * @author Rosemary George
 *
 */
public class CompletedJobListRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7889441214557938708L;

    @Override
    public String toString() {
        return "CompletedJobListRequestEvent [getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
