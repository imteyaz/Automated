package com.minapro.procserver.actors.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TANDEM_JOB_TYPE;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_COMPLETED;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.ITVJobListEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the driving instructions job lists for ITV.</p>
 * 
 * <p>The drive instruction can be to the Quay area/pinning station/yard area.</p>
 * 
 * @author Rosemary George
 *
 */
public class ITVJobListActor extends UntypedActor {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVJobListActor.class);

	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

	public static final String FORWARDPOSITION = "FORWARD";
	public static final String AFTPOSITION = "AFT";
	public static final String CENTERPOSITION = "CENTER";
	public static final String EMPTY = "Empty";
	public static final String FULL =  "Full";
	public static final String FETCH = "fetch";
	public static final String CARRY = "carry";
	
	public static final String SINGLE = "SINGLE";
	public static final String TWIN = "TWIN";
	public static final String TANDEM = "TANDEM";

	@Override
	/**
	 * Handles only the messages of type DriveInstructionEvent and ITVJobListEvent
	 */
	public void onReceive(Object message) throws Exception {
		if (message instanceof ITVJobListEvent) {
			ITVJobListEvent jobListEvent = (ITVJobListEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getEquipmentID(), "Received job list event " + jobListEvent);

			String itvUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(jobListEvent.getEquipmentID());
			logger.logMsg(LOG_LEVEL.INFO, "", "Mapping user for Equipment:" + jobListEvent.getEquipmentID() + " is"
					+ itvUserId);

			if (itvUserId != null) {
				// Checking if the ITV User logs in or not
				boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(itvUserId);
				if (inspectionStatus) {
					//Setting current equipment Job List request process as completed , to make available for other equipments 
					logger.logMsg(LOG_LEVEL.INFO,itvUserId,EQUIPMENT_JOB_LIST_REQUEST_COMPLETED);
					RDTCacheManager.getInstance().setEqJobListReqStatus(jobListEvent.getEquipmentID(),EquipmentJobListRequestStatus.COMPLETED);
					
					int noOfJobs = cleanUpCacheBeforeProcessing(jobListEvent,jobListEvent.getEquipmentID(), itvUserId);					
					handleJobListEventForITV(jobListEvent, noOfJobs);
					
				}else {
					logger.logMsg(LOG_LEVEL.INFO, itvUserId, "Checklist inspection is not yet completed for the user. Skipping");
				}
			}
		}
	}	

	/**
	 * Cleans up the existing cache for Containers on ITV. If the same list of containers are not present in cache, then
	 * removes those entries from cache
	 * @param jobListEvent
	 * @param itvId
	 * @param itvUser
	 */
	private int cleanUpCacheBeforeProcessing(ITVJobListEvent jobListEvent, String itvId, String itvUser){
		int jobsToConsider = 0;
		try{
			List<DriveInstructionEvent> jobList = jobListEvent.getJobList();
			if (jobList != null && jobList.size() >= 2) {
				logger.logMsg(LOG_LEVEL.INFO, itvUser, "Received More than or equal two Jobs, but can process only two jobs");
				jobsToConsider = 2;
			}else if(jobList != null && !jobList.isEmpty()){
				jobsToConsider = 1;
			}
	
			// Extracting the containers Id's coming as part of Job list
			List<String> containerIDs = new ArrayList<String>();
			for (int iteration = 0; iteration <= (jobsToConsider - 1); iteration++) {
				if (jobList.get(iteration).getContainerID() != null
						&& !jobList.get(iteration).getContainerID().isEmpty()) {
					containerIDs.add(jobList.get(iteration).getContainerID());
				}
			}
			logger.logMsg(LOG_LEVEL.INFO, itvUser, "Incoming List of containers " + containerIDs);
	
			// Removing entry from cache, if those entries does not exist in incoming job list
			List<String> currentContainerSet = RDTCacheManager.getInstance().getItvToCntrDetails(itvId);	
			logger.logMsg(LOG_LEVEL.INFO, itvUser, "Existing entries in Cache : " + currentContainerSet);
						
			if(currentContainerSet != null && !currentContainerSet.isEmpty()){
				Collection<String> deletedList = CollectionUtils.subtract(currentContainerSet, containerIDs);
			
				if (deletedList != null && !deletedList.isEmpty()) {
					for (String entry : deletedList) {
						RDTCacheManager.getInstance().removeItvToCntrDetails(itvId, entry);
					}
				}
			}
	
			logger.logMsg(LOG_LEVEL.INFO, itvUser, "Entries in Cache after update : " 
					+ RDTCacheManager.getInstance().getItvToCntrDetails(itvId));
		}catch(Exception ex){
			logger.logException("Caught exception while cleanUpCacheBeforeProcessing ", ex);
		}
		return jobsToConsider;
	}

	/**
	 * <p> Handles the ITVJobListEvent message from ESB. The first driveInstruction is extracted from the list and send
	 * to the ITV operator. The remaining driveInstructions are cached. </p>
	 * 
	 * @param jobListEvent
	 */
	private void handleJobListEventForITV(ITVJobListEvent jobListEvent, int noOfJobs) {
		try {
			List<DriveInstructionEvent> jobList = jobListEvent.getJobList();			
			boolean onTheWayToFetch = false;
			String messageType;
			
			String itvArrivedLocation = null;
			StringBuilder containerIdOnArrived = new StringBuilder();
			
			int noOfIterations = 1;
			if(noOfJobs > 0){
				noOfIterations = noOfJobs;
			}
			
			// ITV cannot carry more than two containers
			if (jobList != null) {
						
				StringBuilder cntrDetails = new StringBuilder();
				StringBuilder cntrLocation = new StringBuilder();
				Set<String> failedToDeckContainers = new HashSet<String>();
				
				DriveInstructionEvent referenceDriveInstruction = null;
				
				for (int iteration = 0; iteration <= (noOfIterations - 1); iteration++) {
					DriveInstructionEvent driveInstruction = jobList.get(iteration);
					if (jobListEvent.getUserID() == null) {
						// In case of AutoPush, ESB is sending only EquipmentID
						driveInstruction.setUserID(RDTPLCCacheManager.getInstance().getUserfromtheEquipment(
								driveInstruction.getEquipmentID()));
						logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "ITV Equipment Id : -"
								+ driveInstruction.getEquipmentID());
					} else {
						driveInstruction.setUserID(jobListEvent.getUserID());
					}
					
					EventUtil.getInstance().setDriveTypeForInstruction(driveInstruction);
					if (driveInstruction.getGeneralInstruction() == null) {

						driveInstruction.setTerminalID(jobListEvent.getTerminalID());
						driveInstruction.setEventID(jobListEvent.getEventID());

						logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
								"Go to :-" + driveInstruction.getLocationID());

						if (driveInstruction.getContainerID() != null && !driveInstruction.getContainerID().isEmpty()) {

							if(driveInstruction.isArrived()){
								logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getUserID(), "ITV arrived at location " + driveInstruction.getLocationID());								
								itvArrivedLocation = driveInstruction.getLocationID();
								containerIdOnArrived.append(ROW_SEPARATOR).append(driveInstruction.getContainerID());
							}
							
							if (CARRY.equalsIgnoreCase(driveInstruction.getAction())) {

								if ("40".equalsIgnoreCase(driveInstruction.getLength()) || "45".equalsIgnoreCase(driveInstruction.getLength())) {
									if (RDTCacheManager.getInstance().getNumberOfCntrsOnITV(
											driveInstruction.getEquipmentID()) > 0
											&& iteration == 0) {
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
												"ITV already holding Container but recieved 40'| 45' as first DI -");
										RDTCacheManager.getInstance().clearItvToCntrDetails(
												driveInstruction.getEquipmentID());
										referenceDriveInstruction = driveInstruction;
										cntrDetails.append(getContainerDetails(driveInstruction, iteration));
										cntrLocation.append(driveInstruction.getLocationID());
										if("WT".equalsIgnoreCase(driveInstruction.getLocationID())){
											failedToDeckContainers.add(driveInstruction.getContainerID());
										}
										break;
									} else if (RDTCacheManager.getInstance().getNumberOfCntrsOnITV(
											driveInstruction.getEquipmentID()) > 0) {
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
												"ITV already holding Container -");
										break;
									} else {
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
												"ITV not holding any container -");
										cntrDetails.append(getContainerDetails(driveInstruction, iteration));
										cntrLocation.append(driveInstruction.getLocationID());
										referenceDriveInstruction = driveInstruction;
										if("WT".equalsIgnoreCase(driveInstruction.getLocationID())){
											failedToDeckContainers.add(driveInstruction.getContainerID());
										}
										break;
									}
								} else { //if ("20".equalsIgnoreCase(driveInstruction.getLength())) {
									// commented out till opus data set up is proper, treating as 20 if length is null
									
									logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Placing 20' On ITV -");
									cntrDetails.append(getContainerDetails(driveInstruction, iteration)).append(
											ROW_SEPARATOR);
									cntrLocation.append(driveInstruction.getLocationID()).append(ROW_SEPARATOR);
									referenceDriveInstruction = driveInstruction;
									if("WT".equalsIgnoreCase(driveInstruction.getLocationID())){
										failedToDeckContainers.add(driveInstruction.getContainerID());
									}
								}
							} else {

								if ("40".equalsIgnoreCase(driveInstruction.getLength()) || "45".equalsIgnoreCase(driveInstruction.getLength())) {

									if (onTheWayToFetch || RDTCacheManager.getInstance().getNumberOfCntrsOnITV(
													driveInstruction.getEquipmentID()) > 0) {
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
												"ITV already on the way to Fetch Container or Carrying Container -");
										break;
									} else {
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Fetching 40' | 45'  -");
										cntrDetails.append(getContainerDetails(driveInstruction, iteration));
										cntrLocation.append(driveInstruction.getLocationID());
										referenceDriveInstruction = driveInstruction;
										
										logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), 
												"Adding to Fetch Cache - " + driveInstruction.getContainerID()+driveInstruction.getMoveType());
										RDTCacheManager.getInstance().addFetchContainerToItv(
												driveInstruction.getContainerID()+driveInstruction.getMoveType(), driveInstruction.getEquipmentID());
										
										break;
									}
								} else {

									logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Fetching 20'  -");
									cntrDetails.append(getContainerDetails(driveInstruction, iteration)).append(
											ROW_SEPARATOR);
									cntrLocation.append(driveInstruction.getLocationID()).append(ROW_SEPARATOR);
									referenceDriveInstruction = driveInstruction;
									
									logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), 
											"Adding to Fetch Cache - " + driveInstruction.getContainerID()+driveInstruction.getMoveType());
									RDTCacheManager.getInstance().addFetchContainerToItv(
											driveInstruction.getContainerID()+driveInstruction.getMoveType(), driveInstruction.getEquipmentID());
									
									onTheWayToFetch = true;
								}
							}
						} else {

							String itvCurrentLocation = RDTCacheManager.getInstance().getITVCurrentLocation(driveInstruction.getEquipmentID());
							logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), 
									"Initial GO TO Instruction -ITV current location is " + itvCurrentLocation);

							messageType = getMessageType(driveInstruction);	
							EventUtil.getInstance().sendDriveInstruction(driveInstruction, messageType);
							
							RDTCacheManager.getInstance().removeItvMapping(driveInstruction.getEquipmentID());
							
							if (!driveInstruction.getLocationID().equalsIgnoreCase(itvCurrentLocation)) {
								logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
										"ITV current location is not same as Drive Direction Location -" + driveInstruction.getLocationID());
								EventUtil.getInstance().sendDispatchedToStakeHolders(driveInstruction);
								RDTCacheManager.getInstance().clearItvToCntrDetails(driveInstruction.getEquipmentID());
							} else {
								logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
										"ITV current location is same as Drive Direction Location -" + driveInstruction.getLocationID());
								if (RDTCacheManager.getInstance().getNumberOfCntrsOnITV(
										driveInstruction.getEquipmentID()) > 0) {
									logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Jobs might be removed or confirmed in TOS -");
									// This means ITV jobs are Confirmed/Removed from SPARCS
									EventUtil.getInstance().sendDispatchedToStakeHolders(driveInstruction);
									RDTCacheManager.getInstance().clearItvToCntrDetails(driveInstruction.getEquipmentID());
								}
							}							
							return;
						}
					} else {

						logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
								"Sending General Instruction to ITV -");

						driveInstruction.setUserID(jobListEvent.getUserID());
						driveInstruction.setTerminalID(jobListEvent.getTerminalID());
						driveInstruction.setEventID(jobListEvent.getEventID());
						driveInstruction.setEquipmentID(jobListEvent.getEquipmentID());

						messageType = getMessageType(driveInstruction);
						EventUtil.getInstance().setDriveTypeForInstruction(driveInstruction);
						EventUtil.getInstance().sendDriveInstruction(driveInstruction, messageType);
						RDTCacheManager.getInstance().clearItvToCntrDetails(driveInstruction.getEquipmentID());
						RDTCacheManager.getInstance().removeItvMapping(driveInstruction.getEquipmentID());				
						
						return;
					}
				}

				logger.logMsg(LOG_LEVEL.INFO, referenceDriveInstruction.getUserID(),
						"Sending DriveDirection with Container :" + cntrDetails.toString());
				messageType = getMessageType(referenceDriveInstruction);
				
				EventUtil.getInstance().removeTrailingSeparator(ROW_SEPARATOR, cntrDetails);
				referenceDriveInstruction.setContainerID(cntrDetails.toString());

				EventUtil.getInstance().removeTrailingSeparator(ROW_SEPARATOR, cntrLocation);
				referenceDriveInstruction.setLocationID(cntrLocation.toString());
				referenceDriveInstruction.setFailedToDeckContainers(failedToDeckContainers);
				
				EventUtil.getInstance().sendDriveInstruction(referenceDriveInstruction, messageType);
				EventUtil.getInstance().sendDispatchedToStakeHolders(referenceDriveInstruction);
				if(itvArrivedLocation != null){
					verifyAndSendITVArrivedEvent(referenceDriveInstruction, itvArrivedLocation, containerIdOnArrived);
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught Exception while processing ITVJoblistEvent : ", ex);
		}
	}

	/**
	 * Verifies whether the current location of the ITV is different from the arrivedLocation received from ESB.
	 * If yes, constructs and send ITVArrivalEvent to master actor for further processing.
	 * 
	 * @param driveInstruction
	 * @param itvArrivedLocation
	 * @param containerIdOnArrived
	 */
	private void verifyAndSendITVArrivedEvent(DriveInstructionEvent driveInstruction, String itvArrivedLocation, 
			StringBuilder containerIdOnArrived) {		
		String itvCurrentLocation = RDTCacheManager.getInstance().getITVCurrentLocation(driveInstruction.getEquipmentID());
		logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "ITV current location-" + itvCurrentLocation 
				+ ", ITV Arrived location-" + itvArrivedLocation);
		
		if(!itvArrivedLocation.equalsIgnoreCase(itvCurrentLocation)){
			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), 
					"ITV arrived location different from current location. Sending ITV arrived event");
			ITVArrivalEvent arrivalEvent = new ITVArrivalEvent();
			arrivalEvent.setContainerIDs(containerIdOnArrived.toString());
			arrivalEvent.setEquipmentID(driveInstruction.getEquipmentID());
			arrivalEvent.setEventID(UUID.randomUUID().toString());
			arrivalEvent.setLocationID(itvArrivedLocation);
			arrivalEvent.setTerminalID(driveInstruction.getTerminalID());
			arrivalEvent.setUserID(driveInstruction.getUserID());
			
			RDTProcessingServer.getInstance().getMasterActor().tell(arrivalEvent, null);
		}
	}

	/**
	 * <p> Responsible for building the container details for the ITV </p>
	 * 
	 * @param driveInstruction
	 */
	public StringBuilder getContainerDetails(DriveInstructionEvent driveInstruction, int currentIteration) {

		StringBuilder result = new StringBuilder();

		Container container = RDTCacheManager.getInstance().getContainerDetails(driveInstruction.getContainerID(), driveInstruction.getMoveType());
		if (container == null) {
			logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getUserID(), "Failed to get the container from cache");
			container = new Container();
			container.setContainerID(driveInstruction.getContainerID());
		}

		int containerPositionOnITV = currentIteration;
		boolean isContainerInCache = false;
		if (RDTCacheManager.getInstance().isContainItv(driveInstruction.getEquipmentID(), 
				driveInstruction.getContainerID(), driveInstruction.getJobKey())) {
			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "ITV know about this container -"
					+ driveInstruction.getContainerID());
			isContainerInCache = true;
			
			List<String> containerDetails = RDTCacheManager.getInstance().getItvToCntrDetails(driveInstruction.getEquipmentID());
			containerPositionOnITV = containerDetails.indexOf(driveInstruction.getContainerID());
			if( containerPositionOnITV < 0  && containerPositionOnITV > 1){
				containerPositionOnITV = currentIteration;
			}
		}		

		StringBuilder cntrDetails = new StringBuilder();
		cntrDetails.append(driveInstruction.getContainerID()).append(ITEM_SEPARATOR)
				.append((container.getIsoCode() == null) ? "" : container.getIsoCode()).append(ITEM_SEPARATOR)
				.append((container.getPod() == null) ? "" : container.getPod()).append(ITEM_SEPARATOR)
				.append((container.getWeight() == null) ? "" : container.getWeight()).append(ITEM_SEPARATOR).append("")
				.append(ITEM_SEPARATOR).append("").append(ITEM_SEPARATOR)
				.append(EventUtil.getInstance().getContainerIcon(container)).append(ITEM_SEPARATOR)
				.append((container.getCategory() == null) ? "" : container.getCategory()).append(ITEM_SEPARATOR)
				.append(container.getIsEmpty() ? EMPTY : FULL).append(ITEM_SEPARATOR);

		// Checking if 20 footer or 40 footer
		String contrLength = container.getSize();
		if(driveInstruction.getLength() != null && !driveInstruction.getLength().isEmpty()){
			contrLength = driveInstruction.getLength();
		}
		if ("20".equalsIgnoreCase(contrLength)) {
			cntrDetails.append("T");
		} else  if("40".equalsIgnoreCase(contrLength) || "45".equalsIgnoreCase(contrLength)){
			cntrDetails.append("F");
		}
		
		cntrDetails.append(ITEM_SEPARATOR);

		if(driveInstruction.getPosition() != null  && !driveInstruction.getPosition().isEmpty()){
			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "TOS mentioned position as :" + driveInstruction.getPosition());
    		if("F".equalsIgnoreCase(driveInstruction.getPosition())){    		    
    		    cntrDetails.append(FORWARDPOSITION);
    		}else if("A".equalsIgnoreCase(driveInstruction.getPosition())) {
    		    cntrDetails.append(AFTPOSITION);
    		}else  if("C".equalsIgnoreCase(driveInstruction.getPosition())){
    			cntrDetails.append(CENTERPOSITION);
    		}    		
		}else {					
		    if (containerPositionOnITV == 0) {
    			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Placing Container  at position :FORWARD");
    			cntrDetails.append(FORWARDPOSITION);    
    		} else {
    			cntrDetails.append(AFTPOSITION);
    			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),	"Placing Container  at position :AFT ");
    		}
		}
		cntrDetails.append(ITEM_SEPARATOR);
		if (CARRY.equalsIgnoreCase(driveInstruction.getAction())) {
			if(!isContainerInCache){
				RDTCacheManager.getInstance().addItvToCntrDetails(
					driveInstruction.getEquipmentID(), driveInstruction.getContainerID(), driveInstruction.getJobKey());
			}
			cntrDetails.append(CARRY);
		} else {
			cntrDetails.append(FETCH);
		}
		
		result.append(cntrDetails).append(fillDoorDirectionAndLiftType(container));		
		return result;
	}
	
	/**
	 * Fills the additional details such as Door direction, reefer point and lift type
	 * @param container
	 * @return
	 */
	private StringBuilder fillDoorDirectionAndLiftType(Container container){
		StringBuilder additionalDetails =  new StringBuilder();
		
		String doorDirection = container.getDoorDirection();
		if(doorDirection == null){
			doorDirection = AFTPOSITION;
		}
		String reeferPoint = "";
		if(container.isReefer() && doorDirection != null){
			if(doorDirection.startsWith(AFTPOSITION)){
				reeferPoint = FORWARDPOSITION;
			}else{
				reeferPoint = AFTPOSITION;
			}
		}
		
		additionalDetails.append(ITEM_SEPARATOR).append(doorDirection)
			.append(ITEM_SEPARATOR).append(reeferPoint).append(ITEM_SEPARATOR).append(getLiftType(container));
		
		return additionalDetails;
	}

	/**
	 * Derives the lift type of the specified container.
	 * 
	 * Checks whether any twin tandem job exists in the table. If it is present, this means the job is
	 * marked for TWIN/TANDEM lifting at QC side. 
	 * 
	 * @param container
	 * @return SINGLE/TWIN/TANDEM
	 */
	private String getLiftType(Container container) {
		String liftType = SINGLE;
		
		TwinTandemJobs job = HibernateUtil.getTwinTandemJobByContainerId(container.getContainerID());
		logger.logMsg(LOG_LEVEL.DEBUG, container.getContainerID(), "Query returned twin tandem job as " + job);
		if(job	!= null){
			if(job.getJobType().equals(TANDEM_JOB_TYPE) && !"Y".equals(job.getTwinSplit())){
				liftType = TANDEM;
			}else {	
				if( "N".equals(job.getTwinSplit())){
					liftType = TWIN;
				}
			}
		}
		return liftType;
	}

	/**
	 * <p> Responsible for sending first DriveInstruction on Listening port after the login </p>
	 * 
	 * @param driveInstruction
	 */

	public String getMessageType(DriveInstructionEvent driveInstruction) {

		String messageType;
		if (driveInstruction.getUserID() == null) {
			// Incase of AutoPush, ESB is sending only EquipmentID
			driveInstruction.setUserID(RDTPLCCacheManager.getInstance().getUserfromtheEquipment(
					driveInstruction.getEquipmentID()));
			logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
					"ITV Equipment Id : -" + driveInstruction.getEquipmentID());
		} else {
			driveInstruction.setUserID(driveInstruction.getUserID());
		}

		boolean firstTimeflag = RDTPLCCacheManager.getInstance().getFirstTimeMapping(driveInstruction.getUserID());
		if (firstTimeflag) {
			messageType = RDTProcessingServerConstants.RESP;
			RDTPLCCacheManager.getInstance().addUsertoFirstTimeMapping(driveInstruction.getUserID(), false);
		} else {
			messageType = RDTProcessingServerConstants.NOTIF;
		}

		return messageType;
	}	
}
