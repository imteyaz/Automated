package com.minapro.procserver.queue;

import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.YARD_INVENTORY_UPDATE_POLL_TIME;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.RmiClient;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.Activity;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.CheWeightageFactorEntity;
import com.minapro.procserver.db.CheckList;
import com.minapro.procserver.db.CheckListHeader;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ISOCodesMaster;
import com.minapro.procserver.db.PinningStation;
import com.minapro.procserver.db.QCLane;
import com.minapro.procserver.db.ShiftDetails;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.Unit;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserRole;
import com.minapro.procserver.db.bayprofile.ColourCode;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.che.YardBlockUpdateEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.procserver.util.CHEJobListService;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTQueryStatements;
import com.minapro.procserver.util.YardSkeletonConstructor;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Listener class for handling the Master Table update notifications coming from Admin Application. The Notification
 * will just contain the Master Table name which has been updated. When the notification is received, the entire master
 * data is flushed from the cache and reload from database.
 * 
 * @author Rosemary George
 *
 */
public class AdminNotificationListener implements MessageListener {
    private static final String LOG_PREFIX = "Received Message-";

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(AdminNotificationListener.class);

    private static final String APPLICATION_PARAMETER_TABLE = "MP_APPLICATIONPARAMETER_MASTER";
    private static final String CHECKLIST_TABLE = "MP_CHECKLIST_MASTER";
    private static final String COLOUR_CODE_TABLE = "MP_COLOUR_CODE_MASTER";
    private static final String DELAY_REASON_CODE_TABLE = "MP_DELAYREASONCODE_MASTER";
    private static final String DEVICE_TABLE = "MP_DEVICE_MASTER";
    private static final String EQUIPMENT_TABLE = "MP_EQUIPMENT_MASTER";
    private static final String USER_ROLE_TABLE = "MP_GRPDTLS_AM";
    private static final String USER_TABLE = "MP_USERDTLS_AM";
    private static final String ACTIVITY_TABLE = "MP_ACTIVITY_MASTER";
    private static final String PINNING_STATION_TABLE = "MP_PINNINGSTATION_MASTER";
    private static final String QC_LANE_TABLE = "MP_QC_LANE_MASTER";
    private static final String TROUBLE_SHOOT_AREA_TABLE = "MP_TROUBLESHOOTAREA_MASTER";
    private static final String ROTATION_QC_MAPPING_TABLE = "MP_ROTATION_QC_MAPPING";
    private static final String CHECKLIST_HEADER_TABLE = "MP_CHECKLIST_HEADER_MASTER";
    private static final String SHIFT_MASTER_TABLE = "MP_SHIFT_MASTER";
    private static final String CHE_WEIGHTAGE_FACTOR = "MP_CHE_WEIGHTAGE_FACTOR";
    private static final String ISO_CODES_TABLE = "MP_ISO_CODES_MASTER";
    
    private static final String RMG = "RMG";
    private static final String RTG = "RTG";
    private static final String FORCE_LOG_OUT_ALL = "#All#";

    private static final String JOB_LIST_FREQUENCY = "JOB_LIST_REFRESH_FREQUENCY";
    private static final String CHE_JOB_LIST_FREQUENCY = "CHE_JOB_LIST_REFRESH_FREQUENCY";
    private static final String ITV_JOB_LIST_FREQUENCY = "ITV_JOB_LIST_REFRESH_FREQUENCY";
    
    private static final String PLANNED_MOVES_FREQUENCY = "PLANNED_MOVES_FREQUENCY";   

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

    @Override
    public void onMessage(Message message) {
        try {
            // message is coming from Admin application
            if (message instanceof TextMessage) {
                String notification = ((TextMessage) message).getText();
                logger.logMsg(LOG_LEVEL.INFO, "", LOG_PREFIX + notification);
                handleAdminNotification(notification);
            } else if (message instanceof ObjectMessage) {
                ObjectMessage notif = (ObjectMessage) message;
                Event event = (Event) notif.getObject();
                logger.logMsg(LOG_LEVEL.INFO, "", LOG_PREFIX + event);
                if (event instanceof LogoutEvent) {
                    handleAdminForceLogOut(event);
                } else if(event instanceof YardBlockUpdateEvent){
                	handleBlockStructureChangeEvent(event);
                }
            } else {
                logger.logMsg(LOG_LEVEL.WARN, "", "Received Unhandled message type- Discarding - " + message);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while handling the message -", ex);
        }
    }

    /**
     * Handles the force log out message from the Admin application. The specified user will be logged out from the
     * server, clears all the cache related to the user, posts a message to ESB to log out the user from SPARCS, also
     * posts message to communication server to clear the caches and sends messages to the device
     * 
     * @param event
     */
    public static void handleAdminForceLogOut(Event event) {
        if(event.getUserID().equalsIgnoreCase(FORCE_LOG_OUT_ALL)){
        	Set<String> loggedInUsers = RDTPLCCacheManager.getInstance().getLoggedInUsers();
        	logger.logMsg(LOG_LEVEL.INFO, "FORCE_LOGOUT_ALL", "users to be logged out -" + loggedInUsers);
        	if(loggedInUsers != null){
        		LogoutEvent logOutEvent;
        		for(String userId : loggedInUsers){
        			logOutEvent = new LogoutEvent();
        			logOutEvent.setUserID(userId);
        			forceLogOutUser(logOutEvent);
        		}
        	}
        }else {
        	forceLogOutUser(event);
        }
    }
    
    private static void forceLogOutUser(Event event){
    	logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "Force Logging out the user");

        String deviceId = RDTCacheManager.getInstance().getDeviceMapping(event.getUserID());
        if (deviceId != null) {
            Device device = RDTCacheManager.getInstance().getDeviceDetails(deviceId);
            if (device != null) {
                Equipment equipment = device.getEquipment();
                if (equipment != null) {
                    event.setEquipmentID(equipment.getEquipmentID());
                }
                logger.logMsg(LOG_LEVEL.INFO, "************** EquipmentID", event.getEquipmentID());
            }
        }

        OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID());
        event.setTimeStamp((new Date()).toString());
        event.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
        RDTProcessingServer.getInstance().getMasterActor().tell(event, null);

        StringBuilder messageToDevice = new StringBuilder();
        messageToDevice.append(NOTIF).append(VALUE_SEPERATOR).append("9999").append(VALUE_SEPERATOR)
                .append(UUID.randomUUID().toString()).append(VALUE_SEPERATOR).append(event.getUserID())
                .append(VALUE_SEPERATOR).append(event.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(messageToDevice.toString(), role,
                event.getTerminalID());
    }

    /**
     * Based on the notification, the corresponding master data is flushed from cache and reloaded
     * 
     * @param notification
     */
    private void handleAdminNotification(String notification) {

        switch (notification) {

        case APPLICATION_PARAMETER_TABLE:
            reloadApplicationParameter();
            break;
        case CHECKLIST_TABLE:
        case CHECKLIST_HEADER_TABLE:
            reloadCheckLists();
            break;
        case USER_ROLE_TABLE:
            reloadUserRoles();
            break;
        case USER_TABLE:
            reloadUsers();
            break;
        case DEVICE_TABLE:
            reloadDeviceDetails();
            break;
        case EQUIPMENT_TABLE:
            reloadEquipmentDetails();
            break;
        case DELAY_REASON_CODE_TABLE:
            reloadDelayReasonCodes();
            break;
        case COLOUR_CODE_TABLE:
            reloadColourCodes();
            break;
        case ACTIVITY_TABLE:
            reloadActivityDetails();
            break;
        case PINNING_STATION_TABLE:
            reloadPinningStationDetails();
            break;
        case QC_LANE_TABLE:
            reloadQCLaneDetails();
            break;
        case TROUBLE_SHOOT_AREA_TABLE:
            reloadTroubleShootAreaDetails();
            break;
        case ROTATION_QC_MAPPING_TABLE:
            reloadQCToRotationMapping();
            break;

        case SHIFT_MASTER_TABLE:
            reloadShiftDetails();
            break;
        case CHE_WEIGHTAGE_FACTOR:
        	reloadCHEWeightageFactorDetails();
        	break;
        case ISO_CODES_TABLE:
        	reloadISOCodesDetails();
        	break;
        default:
            logger.logMsg(LOG_LEVEL.INFO, "", LOG_PREFIX + "Not Applicable at server - Ignore");
        }
    }

    /**
     * Retrieves the latest list of QC mappings to the berthed vessel rotations
     */
    public static void reloadQCToRotationMapping() {
        RDTVesselProfileCacheManager.getInstance().flushQCToRotationMapping();

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction txn = session.beginTransaction();
        try {
            @SuppressWarnings("unchecked")
            List<Object[]> resultSet = session.createQuery(RDTQueryStatements.BERTHED_VESSEL_QC_MAPPING_QUERY).list();
            txn.commit();

            if (!resultSet.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, "",
                        "Reloading the QC to rotation mapping details with size" + resultSet.size());

                String rotationNo, equipmentId;
                for (Object[] row : resultSet) {
                    equipmentId = row[0].toString();
                    rotationNo = row[1].toString();

                    logger.logMsg(LOG_LEVEL.DEBUG, "", "Linking " + equipmentId + "-" + rotationNo);
                    RDTVesselProfileCacheManager.getInstance().linkQCToRotation(rotationNo, equipmentId);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while retrieving the latest QC rotation mapping ", ex);
            txn.rollback();
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Trouble shoot area cache and reloads it with the latest records from database
     */
    public static void reloadTroubleShootAreaDetails() {
        List<TroubleshootAreaMaster> troubleShootAreaData = (List<TroubleshootAreaMaster>) HibernateUtil
                .loadMasterData(TroubleshootAreaMaster.class, null, true);
        if (troubleShootAreaData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "",
                    "Reloading the TroubleshootArea details with size" + troubleShootAreaData.size());
            RDTCacheManager.getInstance().flushTroubleshootAreaDetails();
            for (TroubleshootAreaMaster troubleShootMaster : troubleShootAreaData) {
                RDTCacheManager.getInstance().addTroubleshootAreaDetails(troubleShootMaster);
            }
        } else {
            logger.logMsg(LOG_LEVEL.INFO, "", "Trouble Shoot Areas Are Not Defined");
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the QC lane cache and reloads it with the latest records from database
     */
    public static void reloadQCLaneDetails() {
        List<QCLane> qcLaneData = (List<QCLane>) HibernateUtil.loadMasterData(QCLane.class, null, true);
        if (qcLaneData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the QCLane details with size" + qcLaneData.size());
            RDTCacheManager.getInstance().flushQCLaneDetails();
            for (QCLane qcLane : qcLaneData) {
                RDTCacheManager.getInstance().addQCLaneDetails(qcLane);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Pinning station cache and reloads it with the latest records from database
     */
    public static void reloadPinningStationDetails() {
        List<PinningStation> pinningStationData = (List<PinningStation>) HibernateUtil.loadMasterData(
                PinningStation.class, null, true);
        if (pinningStationData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "",
                    "Reloading the PinningStation details with size" + pinningStationData.size());
            RDTCacheManager.getInstance().flushPinningStationDetails();
            for (PinningStation pinningStation : pinningStationData) {
                RDTCacheManager.getInstance().addPinningStationDetails(pinningStation);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Activity cache and reloads it with the latest records from database
     */
    public static void reloadActivityDetails() {
        List<Activity> activityData = (List<Activity>) HibernateUtil.loadMasterData(Activity.class, "activityId", true);
        if (activityData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the Activity details with size" + activityData.size());
            RDTCacheManager.getInstance().flushActivityCodes();
            for (Activity activity : activityData) {
                RDTCacheManager.getInstance().addActivity(activity);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Colour codes cache and reloads it with the latest records from database
     */
    public static void reloadColourCodes() {
        List<ColourCode> colourCodeData = (List<ColourCode>) HibernateUtil.loadMasterData(ColourCode.class, null, true);
        if (colourCodeData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the ColourCode details with size" + colourCodeData.size());
            RDTVesselProfileCacheManager.getInstance().flushColourCodes();
            for (ColourCode code : colourCodeData) {
                RDTVesselProfileCacheManager.getInstance().addColourCode(code);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Delay reason codes cache and reloads it with the latest records from database
     */
    public static void reloadDelayReasonCodes() {
        List<DelayReasonCode> delayCodeData = (List<DelayReasonCode>) HibernateUtil.loadMasterData(
                DelayReasonCode.class, null, true);
        if (delayCodeData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the Delay Reason details with size" + delayCodeData.size());
            RDTCacheManager.getInstance().flushDelayReasonCodes();
            for (DelayReasonCode delayCode : delayCodeData) {
                RDTCacheManager.getInstance().addDelayReasonCodeDetails(delayCode);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Equipment cache and reloads it with the latest records from database
     */
    public static void reloadEquipmentDetails() {
        List<Equipment> equipmentData = (List<Equipment>) HibernateUtil.loadMasterData(Equipment.class, null, true);
        if (equipmentData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the Equipment details with size" + equipmentData.size());
            RDTCacheManager.getInstance().flushEquipmentDetails();
            for (Equipment equipment : equipmentData) {
                RDTCacheManager.getInstance().addEquipmentDetails(equipment);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Device cache and reloads it with the latest records from database
     */
    public static void reloadDeviceDetails() {
        List<Device> deviceData = (List<Device>) HibernateUtil.loadMasterData(Device.class, null, true);
        if (deviceData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the device details with size" + deviceData.size());
            RDTCacheManager.getInstance().flushDeviceDetails();
            for (Device device : deviceData) {
                RDTCacheManager.getInstance().addDeviceDetails(device);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the User cache and reloads it with the latest records from database
     */
    public static void reloadUsers() {
        List<User> userData = (List<User>) HibernateUtil.loadMasterData(User.class, null, true);
        if (userData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the User details with size" + userData.size());
            RDTCacheManager.getInstance().flushUsers();
            for (User user : userData) {
                RDTCacheManager.getInstance().addUserDetails(user);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the User roles cache and reloads it with the latest records from database
     */
    public static void reloadUserRoles() {
        List<UserRole> userRoles = (List<UserRole>) HibernateUtil.loadMasterData(UserRole.class, null, true);
        if (userRoles != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the UserRole details with size" + userRoles.size());
            RDTCacheManager.getInstance().flushUserRoleChecklist();
            RDTCacheManager.getInstance().flushUserRoles();
            Set<CheckListHeader> checkLists;
            String roleName;
            for (UserRole role : userRoles) {
                RDTCacheManager.getInstance().addRoleToCache(role);
                checkLists = role.getCheckListHeaderSet();
                if (!checkLists.isEmpty()) {
                    roleName = role.getRoleName();
                    if (role.getRoleName().startsWith(RMG) || role.getRoleName().startsWith(RTG)) {
                        roleName = OPERATOR.CHE.toString();
                        role.setRoleName(roleName);
                    }
                    RDTCacheManager.getInstance().addCheckListForRole(roleName, checkLists);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Check List cache and reloads it with the latest records from database
     */
    public static void reloadCheckLists() {
        List<CheckListHeader> checkListHeaders = (List<CheckListHeader>) HibernateUtil.loadMasterData(
                CheckListHeader.class, null, true);
        if (checkListHeaders != null) {
            logger.logMsg(LOG_LEVEL.INFO, "",
                    "Reloading the CheckListHeader details with size" + checkListHeaders.size());
            RDTCacheManager.getInstance().flushCheckList();
            for (CheckListHeader header : checkListHeaders) {
                logger.logMsg(LOG_LEVEL.INFO, header.getName(), "Reloading the CheckListItems details with size"
                        + header.getCheckList().size());
                for (CheckList checkList : header.getCheckList()) {
                    RDTCacheManager.getInstance().addCheckListItem(header.getCheckListHeaderId(), checkList);
                }
            }
        }

        reloadUserRoles();
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the User cache and reloads it with the latest records from database
     */
    public static void reloadShiftDetails() {
        List<ShiftDetails> shiftData = (List<ShiftDetails>) HibernateUtil
                .loadMasterData(ShiftDetails.class, null, true);
        if (shiftData != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the Shift details with size" + shiftData.size());
            for (ShiftDetails shift : shiftData) {

                RDTCacheManager.getInstance().addShiftDetails(shift);
            }
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * Clears the Application parameter cache and reloads it with the latest records from database
     */
    public static void reloadApplicationParameter() {
    	
        logger.logMsg(LOG_LEVEL.INFO, "", " Application Parameter Table Change Event Occured");
      
        List<ApplicationParameter> applicationParameters = (List<ApplicationParameter>) HibernateUtil.loadMasterData(
                ApplicationParameter.class, null, true);

        ApplicationParameter previousjobListRefreshFrequency = RDTPLCCacheManager.getInstance().getApplicationParamter(
                JOB_LIST_FREQUENCY);

        ApplicationParameter previousPlannedMovesFrequency = RDTPLCCacheManager.getInstance().getApplicationParamter(
                PLANNED_MOVES_FREQUENCY);
        
        ApplicationParameter previousCHEJobListFrequency = RDTPLCCacheManager.getInstance()
                .getApplicationParamter(CHE_JOB_LIST_FREQUENCY);
        
        ApplicationParameter previousITVJobListFrequency = RDTPLCCacheManager.getInstance()
                .getApplicationParamter(ITV_JOB_LIST_FREQUENCY);
        
        ApplicationParameter previousYardInventoryUpdateFrequency = RDTPLCCacheManager.getInstance()
                .getApplicationParamter(YARD_INVENTORY_UPDATE_POLL_TIME);

        if (applicationParameters != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the Application Parameter details with size"
                    + applicationParameters.size());
            RDTPLCCacheManager.getInstance().flushApplicationParameters();
            for (ApplicationParameter parameter : applicationParameters) {
                RDTPLCCacheManager.getInstance().addApplicationParamters(parameter);
            }
            // check the job list refresh frequency changed or not
            ApplicationParameter currentjobListRefreshFrequency = RDTPLCCacheManager.getInstance()
                    .getApplicationParamter(JOB_LIST_FREQUENCY);

            // check the Planned Moves frequency value
            ApplicationParameter currentPlannedMovesFrequency = RDTPLCCacheManager.getInstance()
                    .getApplicationParamter(PLANNED_MOVES_FREQUENCY);
            
            //check the CHE Job list refresh frequency changed or not
            ApplicationParameter currentCHEJobListFrequency = RDTPLCCacheManager.getInstance()
                    .getApplicationParamter(CHE_JOB_LIST_FREQUENCY);
            
            //check the ITV Job list refresh frequency changed or not
            ApplicationParameter currentITVJobListFrequency = RDTPLCCacheManager.getInstance()
                    .getApplicationParamter(ITV_JOB_LIST_FREQUENCY);
            
            ApplicationParameter currentYardInventoryUpdateFrequency = RDTPLCCacheManager.getInstance()
                    .getApplicationParamter(YARD_INVENTORY_UPDATE_POLL_TIME);
            try {
            	updateJobListRefreshFrequncy(previousjobListRefreshFrequency, currentjobListRefreshFrequency, OPERATOR.QC);
            	updateJobListRefreshFrequncy(previousCHEJobListFrequency, currentCHEJobListFrequency, OPERATOR.CHE);
            	updateJobListRefreshFrequncy(previousITVJobListFrequency, currentITVJobListFrequency, OPERATOR.ITV);
            	updateJobListRefreshFrequncy(previousYardInventoryUpdateFrequency, currentYardInventoryUpdateFrequency, OPERATOR.CHE_COMMON);
                updatePlannedMovesRefreshFrequency(previousPlannedMovesFrequency, currentPlannedMovesFrequency);
                
            } catch (Exception ex) {
                logger.logException(" Failed To Update Application Parameters", ex);
            }
        } else {
            logger.logMsg(LOG_LEVEL.INFO, "", " No Data Is Available in Application_Parameter Table");
        }
    }
    /**
     * CHE Weighatge Factor Details Are Caching to cheWeightageDetailsCache.
     */
    @SuppressWarnings("unchecked")
	public static void reloadCHEWeightageFactorDetails(){    	
    	logger.logMsg(LOG_LEVEL.INFO,""," reloadCHEWeightageFactorDetails() change event occured");
    	
    	List<CheWeightageFactorEntity> weightageEntityList = (List<CheWeightageFactorEntity>) HibernateUtil
                .loadMasterData(CheWeightageFactorEntity.class, null, true);
        
    	if (weightageEntityList != null) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the CHE Weightage Factor details with size" + weightageEntityList.size());
            for (CheWeightageFactorEntity cheWeightageEntity : weightageEntityList) {
            	RDTCacheManager.getInstance().setCheWeightageDetailsToCache(cheWeightageEntity);               
            }
        }
    }
    
    /**
     * Following method is responsible for retrieving PLANNED_MOVES_FREQUENCY from the admin application as a
     * notification.
     * 
     * @param previousPlannedMovesFrequency
     * @param currentPlannedMovesFrequency
     * @throws Exception
     */
    public static void updatePlannedMovesRefreshFrequency(ApplicationParameter previousPlannedMovesFrequency,
            ApplicationParameter currentPlannedMovesFrequency) {

        boolean isMasterNode = RDTProcessingServer.getInstance().checkIfMasterNode();

        if (previousPlannedMovesFrequency != null && currentPlannedMovesFrequency != null) {
            if (previousPlannedMovesFrequency.getParameterValue().equals(
                    currentPlannedMovesFrequency.getParameterValue())
                    && previousPlannedMovesFrequency.getUnit().getUnitName()
                            .equals(currentPlannedMovesFrequency.getUnit().getUnitName())) {
                logger.logMsg(LOG_LEVEL.DEBUG, "", "No change detected for the Planned Moves frequency");
            } else {

                logger.logMsg(LOG_LEVEL.DEBUG, "",
                        "Detected frequency change for Planned Moves refresh - Restarting the scheduler");

                TimeUnit unitValue = getTimeUnit(currentPlannedMovesFrequency.getUnit());
                int frequency = Integer.parseInt(currentPlannedMovesFrequency.getParameterValue());
                if (isMasterNode) {
                    RDTProcessingServer.getInstance().restartPlannedMovesScheduler(0, frequency, unitValue);
                } else {
                    RmiClient.getInstance().restartPlannedMovesScheduler(0, frequency, unitValue);
                }
            }

        } else if (previousPlannedMovesFrequency == null && currentPlannedMovesFrequency != null) {

            logger.logMsg(LOG_LEVEL.DEBUG, "", "Restarting the Planned Moves refresh poller "
                    + "with no initial delay and run scheduler after every one hour");

            TimeUnit unitValue = getTimeUnit(currentPlannedMovesFrequency.getUnit());
            int frequency = Integer.parseInt(currentPlannedMovesFrequency.getParameterValue());

            if (isMasterNode) {
                RDTProcessingServer.getInstance().restartPlannedMovesScheduler(0, frequency, unitValue);
            } else {
                RmiClient.getInstance().restartPlannedMovesScheduler(0, frequency, unitValue);
            }

        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, "", "Starting the Planned Moves refresh poller with 1 "
                    + "minute initial delay and run scheduler after every one hour ");
            if (isMasterNode) {
                RDTProcessingServer.getInstance().restartPlannedMovesScheduler(1, 1, TimeUnit.HOURS);
            } else {
                RmiClient.getInstance().restartPlannedMovesScheduler(1, 1, TimeUnit.HOURS);
            }
        }
    }    
    
    /**
     * Identifies whether the job list poller frequency has been changed for specified role. If so, the scheduler is restarted with the
     * latest frequency.
     * 
     * Based on the role, invokes the corresponding scheduler restart.
     * If the current node is not a master node, invokes the scheduler restart using RMI.
     * 
     * @param previousJobListFrequency
     * @param currentJobListFrequency
     * @param role
     */
    public static void updateJobListRefreshFrequncy(ApplicationParameter previousJobListFrequency,
    		ApplicationParameter currentJobListFrequency, OPERATOR role){

    	int intitialDelay 			= 0;
    	int currentFrequencyValue	= 0;
    	TimeUnit currentUnitValue 	= TimeUnit.SECONDS;
    	boolean isJobListRestartRequired = true;       	
    	try{
    		if(currentJobListFrequency != null){
    			currentUnitValue = getTimeUnit(currentJobListFrequency.getUnit());
    			currentFrequencyValue = Integer.parseInt(currentJobListFrequency.getParameterValue());
    		}

    		if (previousJobListFrequency != null && currentJobListFrequency != null) {
    			if (previousJobListFrequency.getParameterValue().equals(currentJobListFrequency.getParameterValue())
    					&& previousJobListFrequency.getUnit().getUnitName() .equals(currentJobListFrequency.getUnit().getUnitName())) {
    				logger.logMsg(LOG_LEVEL.DEBUG, role.toString(), "No change detected for job list refresh frequency");
    				isJobListRestartRequired = false;
    			} else {
    				logger.logMsg(LOG_LEVEL.DEBUG, role.toString(),"Detected job list refresh frequency change - Restarting the job list scheduler");
    			}
    		} else if(previousJobListFrequency == null && currentJobListFrequency == null){
    			logger.logMsg(LOG_LEVEL.DEBUG, role.toString(), "No Params Defined In ApplicationParms,Setting Poller For 45 Seconds");
    			intitialDelay = 2;
    			currentFrequencyValue = 45;
    		}

    		if(isJobListRestartRequired){
    			boolean isMasterNode = RDTProcessingServer.getInstance().checkIfMasterNode();
    	    	if (isMasterNode) {    				
    				RDTProcessingServer.getInstance().restartJobListScheduler(intitialDelay, currentFrequencyValue, currentUnitValue, role);		
    			} else {
    				RmiClient.getInstance().restartJobListScheduler(intitialDelay, currentFrequencyValue, currentUnitValue, role);			
    			}
    		}
    	}catch(Exception ex){
    		logger.logException(" Exception Occured In updateCHEJobListRefreshFrequncy Reason::", ex);
    	}
    }
       
    /**
     * Finds out the time unit associated with
     * 
     * @param unit
     * @return
     */
    private static TimeUnit getTimeUnit(Unit unit) {
        String unitValue = unit.getUnitName();
        if ("minutes".equalsIgnoreCase(unitValue) || unitValue.startsWith("Minute")) {
            return TimeUnit.MINUTES;
        } else if ("hours".equalsIgnoreCase(unitValue) || unitValue.startsWith("Hour")) {
            return TimeUnit.HOURS;
        } else {
            return TimeUnit.SECONDS;
        }
    }
    
    public static void reloadISOCodesDetails() {
        @SuppressWarnings("unchecked")
		List<ISOCodesMaster> isoCodes = (List<ISOCodesMaster>) HibernateUtil.loadMasterData(ISOCodesMaster.class, null,false);
        if (isoCodes != null && !isoCodes.isEmpty()) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Reloading the ISO Codes details with size::" + isoCodes.size());
            RDTCacheManager.getInstance().flushISOCodes();
            for (ISOCodesMaster code : isoCodes) {
                RDTCacheManager.getInstance().addIsoCode(code.getIsoCode(),code);
            }
        }		
	}
    
    public static void handleBlockStructureChangeEvent(Event event){
    	
    	YardBlockUpdateEvent yardEvent = (YardBlockUpdateEvent)event;
    	
    	Collection<String> updateRequiredBlocks = (yardEvent==null) ? null : yardEvent.getUpdatedBlocks();
    	
    	if(updateRequiredBlocks!=null && !updateRequiredBlocks.isEmpty()) {
    		
    		logger.logMsg(LOG_LEVEL.DEBUG,"",new StringBuilder(" Block Structure Change Event Received From Admin App, Modified Block Details Are::").append(updateRequiredBlocks).toString());
    		
    		CHEJobListService.getInstance().loadBlockDetailsToCache();
    		YardSkeletonConstructor.prepareBlockSkeleton(updateRequiredBlocks);
    		BlockProfileUtil.sendBlockViewRequestToESB(updateRequiredBlocks);
    		
    	} else {
    		logger.logMsg(LOG_LEVEL.INFO,""," Updated Blocks Details Are Empty--No Need to Proceed Further");
    	}
    }
}
