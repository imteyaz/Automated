package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * Many-to-One mapping ID between inspection record and the associated checkList items
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class InspectionCheckListMappingId implements Serializable {
    private static final long serialVersionUID = 2699774928486360163L;

    @ManyToOne
    @JoinColumn(name = "INSPECTION_ID")
    private InspectionRecord inspectionRecord;

    @ManyToOne
    private CheckList checkListItem;

    public InspectionRecord getInspectionRecord() {
        return inspectionRecord;
    }

    public void setInspectionRecord(InspectionRecord inspectionRecord) {
        this.inspectionRecord = inspectionRecord;
    }

    public CheckList getCheckListItem() {
        return checkListItem;
    }

    public void setCheckListItem(CheckList checkListItem) {
        this.checkListItem = checkListItem;
    }

}
