package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Value object holding the inventory update request details from UI
 * @author 1201257
 *
 */
public class InventoryUpdateRequestEvent extends Event implements Serializable {
        
    private static final long serialVersionUID = -1990587986681617164L;
    
    private String containerId;
    
    private String fromLocation;
    
    private String toLocation;
    
    private String moveType;

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "InventoryUpdateRequestEvent [containerId=" + containerId
				+ ", fromLocation=" + fromLocation + ", toLocation="
				+ toLocation + ", moveType=" + moveType + "]";
	}
    
    

}
