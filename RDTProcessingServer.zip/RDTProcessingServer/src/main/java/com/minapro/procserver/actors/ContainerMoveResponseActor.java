package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;

import java.util.Map;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.events.ContainerMoveResponseEvent;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the container response event from the ESB. In case the container move operation is
 * failed at TOS, the same is updated to UI as an alert message. Also the container in the completed job list is updated
 * as exception.</p>
 * 
 * <p>In case if a success response is received, the completed job list is compared to see if this was a correction on a
 * previously failed operation. In such cases, the completed job is marked as exception resolved. </p>
 * 
 * @author Rosemary George
 *
 */
public class ContainerMoveResponseActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerMoveResponseActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
    
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);
    
    private static final String FAILED_TO_DECK = "failed to deck";

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof ContainerMoveResponseEvent) {
            ContainerMoveResponseEvent responseEvent = (ContainerMoveResponseEvent) message;
            logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Recieved container move response event -" + responseEvent);
            handleContainerMoveResponse(responseEvent);
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the container response event from ESB.
     * 
     * @param responseEvent
     */
    private void handleContainerMoveResponse(ContainerMoveResponseEvent responseEvent) {
        try {
            ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(responseEvent.getUserID());

            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());
            // in case of HC, even though HC has confirmed the container move, use QC equipment ID as the completed
            // moves are recorded on QC equipment
            if (OPERATOR.HC.equals(role)) {
                responseEvent.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                        responseEvent.getUserID()));
            }
            
            if(!responseEvent.isStatus() && responseEvent.getErrorMessage() != null 
            		&& responseEvent.getErrorMessage().contains(FAILED_TO_DECK)){
            	logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "failure response with Failed to Deck error. Raising Alert for "
                        + responseEvent.getContainerId());
            	generateFLDAlert(responseEvent);
            }
            
            if(responseEvent.isPreJobConfirmation() && !responseEvent.isStatus()){
            	logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "failure response for pre-job confirmation "
                        + responseEvent.getContainerId());
            	RDTPLCCacheManager.getInstance().addPreJobConfirmFailure(responseEvent.getEquipmentID(), responseEvent);
            	return;
            }

            Map<String, CompletedContainerMoves> completedJobs = RDTCacheManager.getInstance().getCompletedJobs(
                    allocationDetails.getRotationID(), responseEvent.getEquipmentID());

            if (completedJobs != null) {
                CompletedContainerMoves container = completedJobs.get(responseEvent.getContainerId().concat(responseEvent.getMoveType()));
                logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Completed container - " + container);
                if (container != null) {
                    if (responseEvent.isStatus()) {
                        logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Received success response for "
                                + responseEvent.getContainerId());

                        if ("Y".equals(container.getExceptionOccured())) {
                            logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(),
                                    "Correction on earlier exception job- marking it as resolved");
                            container.setExceptionResolved("Y");

                            JournalEvent journal = new JournalEvent(container, UPDATETYPE.UPDATE);
                            getSender().tell(journal, null);
                        }
                    } else {
                        logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Received failure response for "
                                + responseEvent.getContainerId());

                        sendAlertToDevice(responseEvent, responseEvent.getUserID(), role);

                        if (role.equals(OPERATOR.QC)) {
                            informCorrespondingHC(responseEvent);  
                        } else if (role.equals(OPERATOR.HC)) {
                            informCorrespondingQC(responseEvent);
                        }

                        container.setExceptionOccured("Y");
                        container.setExceptionReason(responseEvent.getErrorMessage());
                        JournalEvent journal = new JournalEvent(container, UPDATETYPE.UPDATE);
                        getSender().tell(journal, null);
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while handling the container response event-", ex);
        }
    }

    /**
     * Generates the FLD alert event and forwards to master actor for further processing
     * @param responseEvent
     */
    private void generateFLDAlert(ContainerMoveResponseEvent responseEvent) {
    	MinaProAlertEvent alert = new MinaProAlertEvent();
		alert.setAlertCode(ALERTCODE.FLD_CONTAINER_ALERT);
		alert.setContainerId(responseEvent.getContainerId());
		alert.setEquipmentID(responseEvent.getEquipmentID());
		alert.setOperatorId(responseEvent.getUserID());
		alert.setUserID(responseEvent.getUserID());
		RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);		
	}

	/**
     * Find the QC user signed in for the equipment, and sends the alert.
     * 
     * @param responseEvent
     */
    private void informCorrespondingQC(ContainerMoveResponseEvent responseEvent) {
        String qcUserId = EventUtil.getInstance().getQcUserId(responseEvent.getUserID());
        if (qcUserId != null) {
            boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(qcUserId);
            if (inspectionStatus) {
                sendAlertToDevice(responseEvent, qcUserId, OPERATOR.QC);
            }
        }
    }

    /**
     * Finds the HC user signed in for the equipment and sends the alert
     * 
     * @param responseEvent
     */
    private void informCorrespondingHC(ContainerMoveResponseEvent responseEvent) {
        String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(responseEvent.getEquipmentID());
        if (hcUser != null) {
            boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
            if (inspectionStatus) {
                sendAlertToDevice(responseEvent, hcUser, OPERATOR.HC);
            }
        }
    }

    /**
     * Construct the alert message and sends to the user specified.
     * 
     * @param responseEvent
     * @param userId
     * @param role
     */
    private void sendAlertToDevice(ContainerMoveResponseEvent responseEvent, String userId, OPERATOR role) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.CONTAINER_MOVE_RESPONSE);
        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.NOTIF).append(VALUE_SEPARATOR)
                .append(eventTypeID);
        //TODO::Added Move Type , Needs to cross check with UI Once.
        
        responseToDevice.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
                .append(responseEvent.getContainerId()).append(ITEM_SEPERATOR).append(responseEvent.getMoveType()).
                append(VALUE_SEPARATOR).append(responseEvent.getErrorMessage()).append(VALUE_SEPARATOR).
                append(userId).append(VALUE_SEPARATOR).append(responseEvent.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                responseEvent.getTerminalID());
    }
}
