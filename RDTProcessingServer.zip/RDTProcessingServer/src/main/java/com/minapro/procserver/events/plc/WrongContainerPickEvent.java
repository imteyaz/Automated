package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the Wrong Container pick event details
 * 
 * @author Venkataramana.ch
 *
 */

public class WrongContainerPickEvent extends Event implements Serializable {

    private static final long serialVersionUID = 1230278500086253024L;

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "WrongContainerPickEvent [message=" + message + "]";
    }
}
