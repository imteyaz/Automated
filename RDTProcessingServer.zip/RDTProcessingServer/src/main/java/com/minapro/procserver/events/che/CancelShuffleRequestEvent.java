package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class CancelShuffleRequestEvent extends Event implements Serializable {

	private static final long serialVersionUID = -1652060390180929314L;
	private String jobListContainerId;

	public String getJobListContainerId() {
		return jobListContainerId;
	}

	public void setJobListContainerId(String jobListContainerId) {
		this.jobListContainerId = jobListContainerId;
	}

	@Override
	public String toString() {
		return "CancelShuffleRequestEvent [jobListContainerId="
				+ jobListContainerId + "]";
	}
	
	

}
