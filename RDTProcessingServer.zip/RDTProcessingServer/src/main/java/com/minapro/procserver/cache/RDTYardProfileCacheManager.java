package com.minapro.procserver.cache;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.infinispan.Cache;

import com.minapro.procserver.db.yardview.BlkareaYpm;
import com.minapro.procserver.events.che.YardProfileContainer;

/**
 * Class is responsible for holding YardProfile rows,stacks,block skeleton, block containers data into the cache.
 * 
 * @author CMC.UmaMahesh
 *
 */
public class RDTYardProfileCacheManager {

    private static final RDTYardProfileCacheManager INSTANCE = new RDTYardProfileCacheManager();
    
    /**
     * Block Id is the key and and stack numbers are the values. In stack values key is the sequence number value is the
     * combination of 20ft and 40ft values with Pipe separator(|). Sample message is:70A is the key,value
     * is(seqno(1),20ft and 40ft container(01|00)).
     */
    private Cache<String, Map<String, String>> blockIdToStacksCache = RDTCacheContainer
            .getCache("BlockIdToStacksCache");

    /**
     * Block Id is the key and and Row numbers are the values. In Row numbers SeqNo is the key and value is RowNumber.
     * Sample Message:70A is the key,Value Is(1,A)
     */
    private Cache<String, Map<String, String>> blockIdToRowsCache = RDTCacheContainer.getCache("BlockIdToRowsCache");

    /**
     * Cache holds the blocks skeleton with CellData objects. Key is the block number and value is the BlockProfile.
     */
    private Cache<String, BlockProfile> blockToYardProfileCache = RDTCacheContainer.getCache("BlockIdToYardProfile");

    /**
     * Cache holds the ListOfContainers from PROMIS database related to blocks. key is block number and values are list
     * of containers from PROMIS.
     */
    private Cache<String, List<YardProfileContainer>> blockToContainersCache = RDTCacheContainer
            .getCache("BlockToContainersCache");
    /**
     * Cache is responsible for holding the row wise maximum working stacking height.
     * 
     */
    private Cache<String,Map<String, Integer>> blockToRowMaxWrkStkCache = RDTCacheContainer.getCache("BlockToRowMaxWrkStkCache");
    
    /**
     * Cache is responsible for holding the current block stk_no40 values and that stack corresponding stkno20.
     */
    private Cache<String,Map<String, String>> blockToStack40ftValuesCache = RDTCacheContainer.getCache("BlockToStack40ftValuesCache");
    /**
     * Cache is used to store the Block Definition Object (BlkAreaYpam table).
     * Key -- BlockName(71A,70A...)
     * Value - BlkAreaYpm(Object)
     */
    private Cache<String,BlkareaYpm> blockDetails = RDTCacheContainer.getCache("YardBlockDetails");
    
    
    

    private RDTYardProfileCacheManager() {
    }

    public static RDTYardProfileCacheManager getInstance() {
        return INSTANCE;
    }

    // Setting data to the named caches

    /**
     * Method is responsible for setting stacks information into cache. One block consists of maximum of 50 stacks.each
     * stack is the combination of seqNo(Number) and stackValue(Number).
     * 
     * @param blockId
     * @param stackSeqNo
     * @param stackVal
     */
    public void setStacksDataToBlock(String blockId, String stackSeqNo, String stackVal) {
        Map<String, String> stackDataMap = blockIdToStacksCache.get(blockId);
        if (stackDataMap == null) {
            stackDataMap = new LinkedHashMap<String, String>();
            blockIdToStacksCache.put(blockId, stackDataMap);
        }
        stackDataMap.put(stackSeqNo, stackVal);
    }

    /**
     * Method is responsible for setting rows information into cache. row is the combination of seqNo(Number) and
     * rowValue(Alphabet).
     * 
     * @param blockId
     * @param rowData
     *            (seqNo and 20ft Container)
     */
    public void setRowsToBlock(String blockId, String rowSeqNo, String rowVal) {

        Map<String, String> rowDataMap = blockIdToRowsCache.get(blockId);
        if (rowDataMap == null) {
            rowDataMap = new LinkedHashMap<String, String>();
            blockIdToRowsCache.put(blockId, rowDataMap);
        }
        rowDataMap.put(rowSeqNo, rowVal);
    }

    /**
     * Method is responsible for setting blockProfile skeleton to the blockToYardProfileCache.
     * 
     * @param blockId
     *            (key)
     * @param yardProfile
     *            (skeleton of the block.)
     */
    public void setBlockToYardProfile(String blockId, BlockProfile yardProfile) {
        blockToYardProfileCache.put(blockId, yardProfile);
    }

    /**
     * Method is responsible for setting block with available containers to the blockToContainersCache.
     * 
     * @param blockId
     *            (key)
     * @param containers
     *            (List of containers for the blockId)
     */

    public void setBlockToContainersCache(String blockId, List<YardProfileContainer> containers) {
        blockToContainersCache.put(blockId, containers);
    }
    
    
    /**
     * Key is the Block Id and Value is Linked Hash Map(Key is the seqNumber and value is the maximum woking stack height)
     * For Example:73A block had 10 rows and each row had maximum working stk height is 3 cache will store like {0,3}
     */
    public void setMaxWorkStkForRows(String blockId, String rowSeqNo, int maximumWrkStkHt){
    	
    	Map<String, Integer> rowsMaxStkDataMap = blockToRowMaxWrkStkCache.get(blockId);
    	
    	 if (rowsMaxStkDataMap == null) {
    		 rowsMaxStkDataMap = new LinkedHashMap<String, Integer>();
    		 blockToRowMaxWrkStkCache.put(blockId, rowsMaxStkDataMap);
         }
    	 rowsMaxStkDataMap.put(rowSeqNo, maximumWrkStkHt);
    }
    
    public void setBlockTo40ftStkValues(String blockId,String stkNo40,String seqNumber){
    	
    	Map<String,String> blockToStk40Map = blockToStack40ftValuesCache.get(blockId);
    	
    	if(blockToStk40Map==null){
    		blockToStk40Map = new LinkedHashMap<String,String>();
    		blockToStack40ftValuesCache.put(blockId, blockToStk40Map);
    	}
    	blockToStk40Map.put(stkNo40,seqNumber);
    }
    
    public void setBlockObject(BlkareaYpm blockObject) {
    		blockDetails.put(blockObject.getBlkId(),blockObject);	
    }
    
    // Getting values from Cache.

    public BlkareaYpm getBlockObject(String blockId) {
    		return blockDetails.get(blockId);
    }
    
    public Set<String> getBlockIdsAvailableInATOM(){
    	return blockDetails.keySet();
    }
    /**
     * Get stacks information related to block Id.
     * 
     * @param blockId
     * @return Map(SeqNo,stack number)
     */
    public Map<String, String> getBlockRelatedStockData(String blockId) {
        return blockIdToStacksCache.get(blockId);
    }

    /**
     * Get rows information related to blockId
     * 
     * @param blockId
     * @return
     */
    public Map<String, String> getBlockRelatedRowData(String blockId) {

        return blockIdToRowsCache.get(blockId);
    }

    public List<YardProfileContainer> getBlockToContainersCache(String blockId) {
        return blockToContainersCache.get(blockId);
    }

    public BlockProfile getBlockToYardProfile(String blockId) {
        return blockToYardProfileCache.get(blockId);
    }
    /**
     * Method is responsible for retrieving the block row related maximum working stack height. 
     * @param blockId
     * @return
     */
      public Map<String, Integer> getBlockRelatedRowMaxStkHt(String blockId) {

          return blockToRowMaxWrkStkCache.get(blockId);
      }
      
      public Map<String,String> getBlockTo40ftStkValues(String blockId){
      		return blockToStack40ftValuesCache.get(blockId);
      }
      
      /*
       * Following Method is used to retrieve the Maximum Working Tier Number for Block.
       * 
       */
      public int getMaxWorkingTierForBLock(String blockId) {
    	 
    	  Map<String, Integer> data = blockToRowMaxWrkStkCache.get(blockId);
    	  
    	  return data!=null && !data.isEmpty() && data.values()!=null && !data.values().isEmpty() ? 
    			  getMaximumNumberFromList(new ArrayList<Integer>(data.values())) : 0;
    	  
      }
    	  
      
      private int getMaximumNumberFromList(List<Integer> tierNumberList){
    	 
    	  int maxTier = tierNumberList.get(0);
    	  
    	  for(int curTier : tierNumberList) {
    		  if(maxTier<curTier){
    			  maxTier = curTier;
    		  }
    	  }
    	  return maxTier;
      }
}
