package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.QCPLCConstants.TWIN;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SPACE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.che.BlockCellGrid;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.CHEContainerDetectionEvent;
import com.minapro.procserver.events.plc.ContainerHandleEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for Container Handling. </p>
 * 
 * @author Kumaraswamy
 *
 */

public class CHEContainerHandlingActor extends UntypedActor {
   
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEContainerHandlingActor.class);
   
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    
	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
    
    private static final String TERMINAL = DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY);
    
    private String node         = null;
	private String userId       = null;
	private String logId        = null;
	private String parsedYardLocation = null;
    
	public void onReceive(Object message) throws Exception {
		
		if (message instanceof CHEContainerDetectionEvent) {

			CHEContainerDetectionEvent cntrDetectionEvent = (CHEContainerDetectionEvent) message;

			node   = cntrDetectionEvent.getNode();
			userId = cntrDetectionEvent.getUserId();
			logId  = node.concat("-").concat(userId);

			handlePLCLockEvent(cntrDetectionEvent);

		} else {
        	unhandled(message);
        }
		
    }

    /**
     * Method is used to handle PLC Lock event at either yard or Lane.
     * when plc lock is happened at Yard side.lock location value consists of String value  "Yard"(LOAD,MO,GO,AH,RH move types).	
     * In this scenario PLC knows the container Locked Position.Lane case PLC does not the Yard Location until PLC unlocks at Yard Side.
     *  Added by @UmaMahesh
	 */ 
    public void handlePLCLockEvent(CHEContainerDetectionEvent cntrDetectionEvent ){

    	logger.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Started handle PLC Lock Event() ").append(" CHE Container Detection Event::")
    			.append(cntrDetectionEvent).toString());
    	
    	final String lockLocation = cntrDetectionEvent.getLaneId();


    	try {

    		ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId,
    				node);

    		JobListContainer plcContainer = null;

    		if (lockLocation != null && lockLocation.contains("Yard")) {

    			logInfoMessage(" Lock Happened At Yard Side::"+lockLocation);

    			plcContainer = (jobList==null || jobList.isEmpty()) ? null : lookForContainerInJobList(logId, cntrDetectionEvent.getYardPosition(), jobList);

    			if (plcContainer!=null){

    				Container container =  RDTCacheManager.getInstance().getContainerDetails(plcContainer.getContainerId());
    			
    				if(container != null){
	    				// Checking the spreader weight mismatch.
	    				if (container.getWeight()!=null){
	    					checkContainerWeightMissmatch(plcContainer.getContainerId(),container.getWeight(),cntrDetectionEvent.getWeight());
	    				}
	
	    				// Checking the Spreader position mismatch.
	    				if (container.getSize()!=null){
	    					checkSpreaderPositionMissmatch(plcContainer.getContainerId(),container.getSize(),cntrDetectionEvent.getSize());  
	    				}
    				}

    				logInfoMessage( new StringBuilder(userId).append(" Parsed Yard Location for the Lock Event :").
    						append(parsedYardLocation).toString());

    				addDetailsToUserToFromLocationCache(userId,plcContainer.getContainerId(),parsedYardLocation);

    				sendJobSelectionAndCntrHanldingRequest(plcContainer,plcContainer.getFromLocation(),userId,node);

    			} else {
    				handleLockEventFromStackCache(cntrDetectionEvent);
    			}

    		} else {

    			plcContainer = handlePLCLockAtLaneSide(jobList);

    			if (plcContainer!=null){
    				addDetailsToUserToFromLocationCache(userId,plcContainer.getContainerId(),plcContainer.getToLocation());
    				sendJobSelectionAndCntrHanldingRequest(plcContainer,plcContainer.getToLocation(),userId,node);
    			}

    		}


    	} catch (Exception e) {
    		logger.logException("Caught exception while processing CHEContainerHandlingActor - ", e);
    	}


    }
   
  
    /*  
     * As Suggested by Sanjay on 29-July-2017 If PLC is unable to fetch the Container from JobList In case of lock location value is Yard , then
  	 *  We need to get the container id from the Yard Structure(BlockProfile Cache).If we found the Container 
  	 *  from Yard Structure then RDT Needs to Send the JobSelection Request to ESB.
  	 *  Step 1 : Get the Container Corresponding to PLC Located Yard Location  from the Block Cache.
     *  Step 2 : Create JobSelection Request with Move Type AH(ESB needs to send TPW as move type to OPUS)
     *  */
    
    private void handleLockEventFromStackCache(CHEContainerDetectionEvent cntrDetectionEvent) {
    	
    	String yardLocation   = prepareYardLocationWithDot(cntrDetectionEvent.getYardPosition());


		logInfoMessage(new StringBuilder(" Lock Location From PLC ::").append(cntrDetectionEvent.getYardPosition())
				.append(" After Formated Location  Value Is::").append(yardLocation).toString());

		if(yardLocation!=null){
			
			YardProfileContainer yardCntr = getCntrDtlsFromBlockProfileCache(yardLocation);
			
			logInfoMessage(new StringBuilder(" PLC Locked Location Corresponding Container Details From Block Profile Is::").
					append(yardCntr).toString());
			
			if(yardCntr!=null && yardCntr.getContainer()!=null && yardCntr.getContainer().getContainerID()!=null){
				
				RDTPLCCacheManager.getInstance().addUserToContainerDetails(userId,yardCntr.getContainer().getContainerID());
				
				addDetailsToUserToFromLocationCache(userId, yardCntr.getContainer().getContainerID(), yardLocation.replaceAll("[\\s.]", ""));
				
				sendJobSelectionRequestToESB(yardCntr.getContainer().getContainerID(),yardLocation,"AH",true);
			}
		}
		
	}

	private void sendJobSelectionRequestToESB(String containerId,String yardLocation,String moveType,boolean isJobListRefreshRequired) {
    	
    	JobSelectionEvent jobSelectionEvent = new JobSelectionEvent();
    	
		jobSelectionEvent.setUserID(userId);
		jobSelectionEvent.setEventID(UUID.randomUUID().toString());
		jobSelectionEvent.setEquipmentID(node);
		jobSelectionEvent.setTerminalID(TERMINAL);
		jobSelectionEvent.setLocation(yardLocation);
		jobSelectionEvent.setContainerId(containerId);
		jobSelectionEvent.setMoveType(moveType);
		jobSelectionEvent.setJobListRefreshRequired(isJobListRefreshRequired);
		ESBQueueManager.getInstance().postMessage(jobSelectionEvent, OPERATOR.CHE, TERMINAL);
		
	}

	/*
     * Method is responsible for performing business operations when plc lock is happened at Lane side.
     * Lane side means it will handle DSCH,MI,GI move types.
     * In this scenario PLC does not know where to keep the Container in the Yard Location.
     * After PLC unlocks the Container In Yard then We can able to get the location.
     * 	
     */
    public JobListContainer handlePLCLockAtLaneSide(ListOrderedMap<String, JobListContainer> jobList){

    	// In case of DSCH or RECV, always highlight the first container from Joblist
    	logInfoMessage(" DSCH or MI or GI Job , HIGHLIGHTING FIRST CONTAINER FROM JOBLIST");

    	// Retrieving current job details from Joblist
    	Collection<JobListContainer> jobListContainers = jobList.values();

    	int jobsCount  = jobListContainers==null || jobListContainers.isEmpty() ? 0 : jobListContainers.size() ;

    	if (jobsCount>0){
    		
    		for(JobListContainer cntr : jobListContainers) {
    				return cntr;
    		}
    		
    	} else {
    		logInfoMessage(" NO JOBS ARE PRESENT IN JOB LIST");
    	}

    	return null;

    }

    /**
     * 
     * <p> Search for container in Joblist </p>
     * 
     * @param jobList
     * @return Container
     */
    private JobListContainer lookForContainerInJobList(String logId, String lockYardLocation,ListOrderedMap<String, JobListContainer> jobList) {
    	
        
    	logInfoMessage(new StringBuilder(ENTRY).append(" lookForContainerInJobList()").append(" PLC Container Locked Location ::")
    			.append(lockYardLocation).toString());
    	
   
    	final String expressionStr = "[\\.]";
        
    	String fromLocation   =  null;
       
    	String lockedPosition = null;        
    	
    	for (String containerIDWithMoveType : jobList.keySet()) {
           
        	JobListContainer jobListCntr = jobList.get(containerIDWithMoveType);
            
            fromLocation = jobListCntr.getFromLocation().replaceAll(expressionStr, "");
            
            lockedPosition = getParsedYardLocation(lockYardLocation, fromLocation);
            
            if (lockedPosition.equalsIgnoreCase(fromLocation)) {
            	
            	logInfoMessage("PLC Locked Location Corresponding  Job Details From Cache Is:" + jobListCntr);
            	return jobListCntr;
            	
            }
            
        }
        
        return null;
    }

    /**
     * 
     * <p> Responsible to Parse the yardLocation which is provided by RMG PLC when lock time </p>
     * 
     * @param lockYardLocation
     * 
     */
    private String getParsedYardLocation(String lockYardLocation, String locationFromJobList) {
        String parsedLocation = lockYardLocation.replaceAll("[\\s.]", "");
        if (parsedLocation.length() > locationFromJobList.length() && parsedLocation.length() > 7) {
            parsedLocation = parsedLocation.substring(0, 3) + parsedLocation.substring(4, parsedLocation.length());
        }
        parsedYardLocation = parsedLocation;
        return parsedLocation;
    }

    
	/**
     * 
     * <p> Responsible for sending container weight missmatch event to Master Actor then alert will be sent to CHE UI
     * </p>
     * 
     * @param userId
     * @param containerId
     * @param plannedWeight
     * @param weightFromPLC
     * @param equipmentId
     */
    public void checkContainerWeightMissmatch(String containerId,String plannedWeight,double weightFromPLC) {
        ApplicationParameter weightObjectFromDB = RDTPLCCacheManager.getInstance().getApplicationParamter(
                "CONTAINER_WEIGHT");
        double configuredWeight = Double.parseDouble(weightObjectFromDB.getParameterValue());

        double sixtyPercentOfWeight = (configuredWeight * 60) / 100;
        double maxWeight = configuredWeight + sixtyPercentOfWeight;
        double minWeight = configuredWeight - sixtyPercentOfWeight;
        
        // Sending Container Weight Miss-match Event to Device
        if ((weightFromPLC <= minWeight) || (weightFromPLC >= maxWeight)) {
            logger.logMsg(LOG_LEVEL.DEBUG, logId, "Sending Container weight Miss match Event of User :" + userId);
            MinaProAlertEvent alert = new MinaProAlertEvent();
            alert.setAlertCode(ALERTCODE.CHE_WEIGHT_MISMATCH_ALERT);
            alert.setUserID(userId);
            alert.setOperatorId(userId);
            alert.setContainerId(containerId);
            alert.setActualWeight(String.valueOf(weightFromPLC));
            alert.setPlannedWeight(plannedWeight);
            alert.setEquipmentID(node);
            getSender().tell(alert, null);
        }
    }
    
    
    /**
     * 
     * <p> Responsible for sending Spreader position mismatch event to Master Actor then alert will be sent to CHE UI
     * </p>
     * 
     * @param userId
     * @param containerId
     * @param containerSize
     * @param speaderPositionFromPLC
     * @param equipmentId
     */
    public void checkSpreaderPositionMissmatch(String containerId, String containerSize , int speaderPositionFromPLC) {
    	
    	// Checking the Spreader Position mismatch for 20 & 40 feet containers.
    	if (Integer.valueOf(containerSize).intValue() != speaderPositionFromPLC){
    		logger.logMsg(LOG_LEVEL.DEBUG, logId, "Sending Spreader position mis match Event of User :" + userId);
            MinaProAlertEvent alert = new MinaProAlertEvent();
            alert.setAlertCode(ALERTCODE.CHE_SPRDR_POS_MSMTCH_ALERT);
            alert.setUserID(userId);
            alert.setOperatorId(userId);
            alert.setContainerId(containerId);
            alert.setContainerSize(containerSize);
            alert.setSpreaderSize(String.valueOf(speaderPositionFromPLC));
            alert.setEquipmentID(node);
            getSender().tell(alert, null);
    	}
    	 
    }
     
    public void sendJobSelectionAndCntrHanldingRequest(JobListContainer plcContainer,String yardLocation , String userId , String equipmentId){

    	ContainerHandleEvent cntrHandlingEvnt = new ContainerHandleEvent();
    	
    	cntrHandlingEvnt.setEventType(DeviceEventTypes.getInstance().getEventType(CONTAINER_HANDLING));
    	
    	cntrHandlingEvnt.setEventID(UUID.randomUUID().toString());
    	
    	cntrHandlingEvnt.setContainerIDs(TWIN.equals(RDTPLCCacheManager.getInstance().getCurrentJobType(userId)) ? 
    			plcContainer.getContainerId().concat(ROW_SEPARATOR).concat(plcContainer.getTwinContainerId())
    			:plcContainer.getContainerId());
    	
    	cntrHandlingEvnt.setMoveType(plcContainer.getMoveType());
    	
    	cntrHandlingEvnt.setEquipmentID(equipmentId);
		cntrHandlingEvnt.setUserID(userId);
		cntrHandlingEvnt.setTimeStamp(DATE_FORMATTER.format(new Date()));
		cntrHandlingEvnt.setTerminalID(TERMINAL);
		
		RDTProcessingServer.getInstance().getMasterActor().tell(cntrHandlingEvnt, null);
		
		sendJobSelectionRequestToESB(plcContainer.getContainerId(), yardLocation, plcContainer.getMoveType(),false);
		
		
    }
    
    private  String prepareYardLocationWithDot(String stowagePosition){

    	stowagePosition = stowagePosition.replaceAll("[\\s.]", "");
    	
    	String[] arr = stowagePosition.split("[a-zA-Z]");
	 
		if(arr.length==3) {
			
			String row=null;
		
			String block = arr[0];
			
			int count=0;
			
			for(int i=0 ; i<stowagePosition.length();i++){
				
				if(Character.isLetter(stowagePosition.charAt(i))){
					
					if(count==0){
						block = block.concat(String.valueOf(stowagePosition.charAt(i)));
					} else {
						row = String.valueOf(stowagePosition.charAt(i));
					}
					count++;
				}
			}
			
			String stackNumber = arr[1];
			
			if(stackNumber.length() > 2) {
				
				String firstNumber = stackNumber.substring(0,1);
				
				if(firstNumber.equals("0")){
					stackNumber = stackNumber.substring(1,stackNumber.length());
				}
			}
			return new StringBuilder(block).append(".").append(stackNumber).append(".").append(row).append(".").append(arr[2]).toString();
		
		} else {
			logger.logMsg(LOG_LEVEL.WARN,logId," Un Handled Format Of Yard Location...Needs to Handle This Format Yard Location::"+stowagePosition);
			return null;
		}
		
		
		
    }
  
    
    private YardProfileContainer getCntrDtlsFromBlockProfileCache(String yardLocation){

    	
    	String[] splittedLocation = yardLocation.split("\\.");

        String blockNumber = splittedLocation[0];

        BlockProfile blockProfile = RDTYardProfileCacheManager.getInstance().getBlockToYardProfile(blockNumber);

        try {

        	if (blockProfile != null) {

        		String[] blockStackRowTierSeqs = BlockProfileUtil.getInstance().
        				getStackRowTierSequncesFromLocation(blockNumber, yardLocation);

        		logInfoMessage(new StringBuilder(" Yard Location::").append(yardLocation).append("Corresponding Seq Numbers Is::").
        				append(blockStackRowTierSeqs!=null ? Arrays.toString(blockStackRowTierSeqs) : null).toString());

        		if(blockStackRowTierSeqs!=null && blockStackRowTierSeqs[1]!=null && 
        				blockStackRowTierSeqs[2]!=null && blockStackRowTierSeqs[3]!=null){

        			for (String seqNos : blockStackRowTierSeqs[1].split("\\" + ROW_SEPARATOR)) {

        				if (seqNos != null && seqNos != SPACE && !(seqNos.isEmpty())) {

        					int stackSeqNo = Integer.parseInt(seqNos);
        					int rowSeqNo = Integer.parseInt(blockStackRowTierSeqs[2]);
        					int tierNo = Integer.parseInt(blockStackRowTierSeqs[3]);

        					BlockCellGrid cell = blockProfile.getCellGrid(rowSeqNo - 1, stackSeqNo - 1);

        					if (cell != null) {
        						return cell.getCurrentYardContainer(tierNo-1);
        					}
        				}
        			}
        		}
        	}
        }catch(Exception ex) {
        	logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Retrieving YardContainer From Cache..")
                    .toString(), ex);
        }
        return null;
    }
    
    public void addDetailsToUserToFromLocationCache(String userId , String containerId , String plcLockLocation){
    	
    	if (RDTPLCCacheManager.getInstance().getUserToFromLocationAndContainerDetails(userId)==null){
    		
    		String value =  containerId.concat("-").concat(plcLockLocation);
    		
    		logInfoMessage(new StringBuilder(" Adding Details to addUserToFromLocationAndContainerDetails cache ")
    		.append(" Key Is::").append(userId).append(" Value Is::").append(value).toString());
    		
			RDTPLCCacheManager.getInstance().addUserToFromLocationAndContainerDetails(userId,value);
			
		}
    }
    
    public void logInfoMessage(String message){
    		logger.logMsg(LOG_LEVEL.INFO,logId,message);
    }
    
}
