package com.minapro.procserver.db.opus.joblist;

import static com.minapro.procserver.db.opus.queries.OPUSJobListQueries.GET_TWIN_TANDEM_JOBS_BY_REF_CNTR;
import static com.minapro.procserver.db.opus.queries.OPUSJobListQueries.GET_TWIN_TANDEM_JOBS_FROM_JOB_LIST;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTQueryStatements.GET_EXISISTING_TWIN_JOBS_QUERY;
import static com.minapro.procserver.util.RDTQueryStatements.GET_TWIN_JOBS_BY_ROTATION;
import static com.minapro.procserver.util.RDTQueryStatements.UPDATE_TWIN_TANDEM_CONTAIERS;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;

import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.opus.queries.OPUSJobListQueries;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.procserver.opus.util.OpusQcJobListService;
import com.minapro.procserver.util.TransactionManager;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class OpusQCJobListDAO {

    private static final OpusQCJobListDAO INSTNACE = new OpusQCJobListDAO();

    private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(OpusQCJobListDAO.class);

    private static final List<String> TWIN_TANDEM_CODES = Arrays.asList("M", "W");

    public static final String TRANSACTION_EXCEPTION = "Transaction Manager Returned Empty Session";

    public static final String CURRENT_SESSION_HASHCODE = " Current Session Hash Code::";
    public static final String ROTATION_ID = "rotationId";
    public static final String TERMINAL_ID = "terminalId";
    public static final String EQUIPMENT_ID = "equipmentId";
    public static final String VESSEL_CODE = "vesselName";
    public static final String VOYAGE = "voyage";
    public static final String IS_JOB_COMPLETED = "isJobCompleted";

    private OpusQCJobListDAO() {
    }

    public static OpusQCJobListDAO getInstnace() {
        return INSTNACE;
    }

    /**
     * Step 1:
     * 
     * Method is used to get the current snap shot sparks job list twin jobs based on the following three parameters.
     * using join query on MP_OPUS_QC_JOB_LIST table and retrieving the current twin jobs. In order to avoid duplicate
     * data overridden the equals() and hash code() methods.
     * 
     * @param terminalId
     * @param rotationId
     * @param equipmentId
     * @return
     * @throws SQLException
     */

    @SuppressWarnings("unchecked")
    public Set<OPUSTwinTandemJobsPOJO> getCurrentSnapShotTwinJobs(String terminalId, String rotationId,
            String equipmentId, String[] vesselVoyage) throws SQLException {

        LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(equipmentId),
                new StringBuilder(" Started getCurrentSnapShotTwinJobs() To Get Twin/Tandem Containers From JobList")
                        .append(" Table With Ref Containers ").append(" Terminal Id:: ").append(terminalId)
                        .append(" Rotation Id::").append(rotationId).append(" Equipment Id::").append(equipmentId)
                        .toString());

        Set<OPUSTwinTandemJobsPOJO> jobListPOJOList = null;

        Session session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, rotationId.concat("-").concat(equipmentId), new StringBuilder(
                    CURRENT_SESSION_HASHCODE).append(session.hashCode()).toString());

            Query query = session.createSQLQuery(GET_TWIN_TANDEM_JOBS_BY_REF_CNTR);

            List<Object[]> twinJobsFromDB = query.setParameter(TERMINAL_ID, terminalId)
                    .setParameter(ROTATION_ID, rotationId).setParameter(EQUIPMENT_ID, equipmentId)
                    .setParameter(VESSEL_CODE, vesselVoyage[0]).setParameter(VOYAGE, vesselVoyage[1]).list();

            jobListPOJOList = prepareOPUSTwinTandemJob(twinJobsFromDB);
        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }

        LOGGER.logMsg(LOG_LEVEL.TRACE, rotationId.concat("-").concat(equipmentId), new StringBuilder(
                "Current Snap Shot Twin Job From Sparcs ").append(jobListPOJOList.toString()).toString());

        session.flush();
        session.clear();

        return jobListPOJOList;
    }

    @SuppressWarnings("unchecked")
    public List<OPUSQCJobListEntity> getTwinAndTandemFromJobList(final String terminalId, final String rotationId,
            final String equipmentId, final String[] vesselVoyage) throws SQLException, NullPointerException {

        Session session = null;
        List<OPUSQCJobListEntity> existedTwinJobs = null;
        session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, rotationId.concat("-").concat(equipmentId), new StringBuilder(
                    CURRENT_SESSION_HASHCODE).append(session.hashCode()).toString());

            existedTwinJobs = session.createQuery(GET_TWIN_TANDEM_JOBS_FROM_JOB_LIST)
                    .setParameterList("codes", TWIN_TANDEM_CODES).setParameter(ROTATION_ID, rotationId)
                    .setParameter(EQUIPMENT_ID, equipmentId).setParameter(TERMINAL_ID, terminalId)
                    .setParameter(VESSEL_CODE, vesselVoyage[0]).setParameter(VOYAGE, vesselVoyage[1]).list();

            session.flush();
            session.clear();

        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }

        return existedTwinJobs;
    }

    public void updateOPUSQcJobList(List<OPUSQCJobListEntity> currentRefreshTwinTandemJobs)
            throws NullPointerException, SQLException {

        LOGGER.logMsg(LOG_LEVEL.TRACE, "", "Started updateOPUSQcJobList() ".concat("To Update OPUSQcJobList table"));
        Session session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, "", new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode())
                    .toString());
            for (OPUSQCJobListEntity data : currentRefreshTwinTandemJobs) {
                session.update(data);
            }

            session.flush();
            session.clear();
        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }
    }

    /*
     * Delete Twin Tandem Id's frm MP_TWINTANDEM_JOB_LIST , MP_TWINTANDEM_CONTAINER_LIST
     */

    public void deleteBulkTwinTandemJobs(List<TwinTandemJobs> deletableTwinTandemList) throws SQLException,
            NullPointerException {

        LOGGER.logMsg(LOG_LEVEL.INFO, "", " Started deleteBulkTwinTandemJobs() To delete twin tandem Id's - ");
        Session session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, "", new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode())
                    .toString());

            for (TwinTandemJobs twinTandemJob : deletableTwinTandemList) {
                LOGGER.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(" Deleting TwinTandem Id::")
                    .append(twinTandemJob.getTwinTandemId()).toString());
                session.delete(twinTandemJob);
            }
            session.flush();
            session.clear();

        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }
    }

    /**
     * Step 2: Retrieve existed sparks created Twin And Tandem Jobs From MP_TWINTANDEM_CONTAINER_LIST and
     * MP_TWINTANDEM_JOBS
     * 
     * @param terminalID
     * @param rotationId
     * @param equipmentId
     * @return TwinTandemJobs existed twin tandem jobs list
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public Set<TwinTandemJobs> getExistedTwinJobs(String terminalID, String rotationId, String equipmentId)
            throws SQLException {

        LOGGER.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(
                " Started getExistedTwinJobs() To Retrive Already Existed Twin/Tandem Jobs").toString());

        Session session = null;
        List<TwinTandemJobs> existedTwinJobs = null;
        session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, rotationId.concat("-").concat(equipmentId), new StringBuilder(
                    CURRENT_SESSION_HASHCODE).append(session.hashCode()).toString());

            existedTwinJobs = session.createQuery(GET_EXISISTING_TWIN_JOBS_QUERY).setParameter(ROTATION_ID, rotationId)
                    .setParameter(EQUIPMENT_ID, equipmentId).setParameter("terminalID", terminalID)
                    .setParameter(IS_JOB_COMPLETED, OpusQcJobListService.NO).list();
        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }

        session.flush();
        session.clear();

        LOGGER.logMsg(LOG_LEVEL.TRACE, "", new StringBuilder("Existed Twin Jobs::").append(
                        existedTwinJobs != null ? existedTwinJobs.toString() : null).toString());

        return existedTwinJobs != null ? new HashSet<TwinTandemJobs>(existedTwinJobs) : null;
    }

    @SuppressWarnings("unchecked")
    public List<TwinTandemJobs> getExistedTwinJobsByRotation(String rotationId) throws SQLException {

        LOGGER.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(" Started getExistedTwinJobsByRotation():")
            .append(ROTATION_ID).append("::")
                        .append(rotationId).toString());

        List<TwinTandemJobs> existedTwinJobs = null;

        Session session = TransactionManager.getSession();

        if (session != null) {
            LOGGER.logMsg(LOG_LEVEL.DEBUG, rotationId,
                    new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode()).toString());
            existedTwinJobs = session.createQuery(GET_TWIN_JOBS_BY_ROTATION).setParameter(ROTATION_ID, rotationId)
                    .list();
        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);
        }

        LOGGER.logMsg(
                LOG_LEVEL.TRACE,
                rotationId,
                new StringBuilder("Existed Sparcs Created Twin Jobs::").append(
                        existedTwinJobs != null ? existedTwinJobs.toString() : null).toString());

        session.flush();
        session.clear();

        return existedTwinJobs;

    }

    /**
     * Saves the data to the database
     * 
     * @param data
     *            - the data to be persisted
     * @throws SQLException
     */
    public void saveMultipleObjects(List<?> objects) throws SQLException {

        LOGGER.logMsg(LOG_LEVEL.TRACE, "", "Started saveMultipleObjects() To save new Twin Jobs into two tables");

        Session session = TransactionManager.getSession();

        if (session != null) {

            LOGGER.logMsg(LOG_LEVEL.DEBUG, "", new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode())
                    .toString());

            for (Object data : objects) {
                session.save(data);
            }

            session.flush();
            session.clear();

        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);

        }

    }

    // Updating Job List Containers
    public void updateTwinTandemContainerList(List<OPUSTwinTandemJobsPOJO> jobListContainers) throws SQLException,
            NullPointerException {

        LOGGER.logMsg(LOG_LEVEL.TRACE, "",
                " Started updateTwinTandemContainers() To Update Multiple TwinTandem Container List");

        Session session = TransactionManager.getSession();

        if (session != null) {

            LOGGER.logMsg(LOG_LEVEL.DEBUG, "", new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode())
                    .toString());

            for (OPUSTwinTandemJobsPOJO jobList : jobListContainers) {

                Query query = session.createSQLQuery(UPDATE_TWIN_TANDEM_CONTAIERS);

                query.setParameter("containerId", jobList.getContainerID()).setParameter("fromLocation",
                        jobList.getFromLocation());
                query.setParameter("toLocation", jobList.getToLocation())
                        .setParameter("refContainerId", jobList.getRefContainerID())
                        .setParameter("refFromLocation", jobList.getRefFromLocation())
                        .setParameter("refToLocation", jobList.getRefToLocation())
                        .setParameter("twinTandemId", jobList.getTwinTandemId());

                query.executeUpdate();
            }

            session.flush();
            session.clear();

        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);

        }

    }

    /**
     * Retrieves the master data from the database for the specified Master table.
     * 
     * @param masterDataName
     * @return List of data
     */
    public List<?> loadOPUSJobList(Class<?> masterDataName) throws SQLException, NullPointerException {

        List<?> masterDataList = null;
        Session session = TransactionManager.getSession();

        if (session != null) {
            Criteria cr = session.createCriteria(masterDataName.getName());
            cr.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            masterDataList = cr.list();
            session.flush();
            session.clear();

        } else {
            throw new SQLException(TRANSACTION_EXCEPTION);

        }
        return masterDataList;
    }

	@SuppressWarnings("unchecked")
	public List<TwinTandemJobs> loadExistedTwinTandemJobs(String rotationId, String equipmentId, String terminalId)
			throws SQLException {

		List<TwinTandemJobs> availableTwinTandemJobs = null;
		Session session = TransactionManager.getSession();

		if (session != null) {
			LOGGER.logMsg(LOG_LEVEL.DEBUG, "", new StringBuilder(CURRENT_SESSION_HASHCODE).append(session.hashCode())
					.toString());
			availableTwinTandemJobs = session.createCriteria(TwinTandemJobs.class)
					.add(Restrictions.eq(ROTATION_ID, rotationId)).add(Restrictions.eq(EQUIPMENT_ID, equipmentId))
					.add(Restrictions.eq(TERMINAL_ID, terminalId)).list();

			session.flush();
			session.clear();
		} else {
			throw new SQLException(TRANSACTION_EXCEPTION);
		}

		return availableTwinTandemJobs;
	}
  
    @SuppressWarnings("unchecked")
    public List<Object[]> getOPUSQCJobListFromDatabase(String terminalId, String rotationID, String equipmentId,
            String[] vesselVoyage) {

        LOGGER.logMsg(LOG_LEVEL.INFO,rotationID.concat("-").concat(equipmentId),
                new StringBuilder(" Started getJobListDataFromDatabase() Parameters::").append(" Terminal::")
                        .append(terminalId).append(" Rotation::").append(rotationID).append(" Equipment Id::")
                        .append(equipmentId).append(" Vessel Voyage::").append(Arrays.toString(vesselVoyage))
                        .toString());

        Session session = null;
        Transaction transaction = null;

        List<Object[]> jobListObjectArrayList = null;

        try {

            session = HibernateUtil.getSessionFactory().getCurrentSession();

            transaction = session.beginTransaction();
            SQLQuery sqlQuery = session.createSQLQuery(OPUSJobListQueries.RETRIEVE_QC_JOB_LIST_QUERY);

            sqlQuery.setParameter("equipmentID", equipmentId).setParameter("rotationID", rotationID)
                    .setParameter("terminalID", terminalId).setParameter("twinSplit", OpusQcJobListService.NO)
                    .setParameter("vesselCode", vesselVoyage[0]).setParameter(VOYAGE, vesselVoyage[1])
                    .setParameter(IS_JOB_COMPLETED, OpusQcJobListService.NO);

            jobListObjectArrayList = sqlQuery.list();
            transaction.commit();

            int noOfJobListRecords = jobListObjectArrayList != null && !jobListObjectArrayList.isEmpty() ? jobListObjectArrayList
                    .size() : 0;
            LOGGER.logMsg(LOG_LEVEL.INFO, rotationID + "-" + equipmentId,
                    "No Of Jobs Received From Database For JobList::" + noOfJobListRecords);

        } catch (Exception ex) {
            LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append("  In getJobListDataFromDatabase()")
                    .append(REASON).toString(), ex);
            session.getTransaction().rollback();
        }

        return jobListObjectArrayList;
    }

    private Set<OPUSTwinTandemJobsPOJO> prepareOPUSTwinTandemJob(List<Object[]> twinJobsFromDB) {

        Set<OPUSTwinTandemJobsPOJO> jobListPOJOList = new HashSet<OPUSTwinTandemJobsPOJO>();

        for (Object[] twinJobsData : twinJobsFromDB) {
            // a.TWIN_TANDEM_CD as twinCd , b.TWIN_TANDEM_CD as refTwinCd
            OPUSTwinTandemJobsPOJO jobListPOJO = new OPUSTwinTandemJobsPOJO();
            jobListPOJO.setContainerID(twinJobsData[0] != null ? twinJobsData[0].toString() : null);
            jobListPOJO.setMoveKind(twinJobsData[1] != null ? twinJobsData[1].toString() : null);
            jobListPOJO.setFromLocation(twinJobsData[2] != null ? twinJobsData[2].toString() : null);
            jobListPOJO.setToLocation(twinJobsData[3] != null ? twinJobsData[3].toString() : null);
            jobListPOJO.setSeqNo(twinJobsData[4] != null ? Double.valueOf(twinJobsData[4].toString()) : null);
            jobListPOJO.setRefContainerID(twinJobsData[5] != null ? twinJobsData[5].toString() : null);
            jobListPOJO.setRefMoveKind(twinJobsData[6] != null ? twinJobsData[6].toString() : null);
            jobListPOJO.setRefFromLocation(twinJobsData[7] != null ? twinJobsData[7].toString() : null);
            jobListPOJO.setRefToLocation(twinJobsData[8] != null ? twinJobsData[8].toString() : null);
            jobListPOJO.setRefSeqNo(twinJobsData[9] != null ? Double.valueOf(twinJobsData[9].toString()) : null);
            jobListPOJO.setTwinTandemCode(twinJobsData[10] != null ? twinJobsData[10].toString() : null);
            jobListPOJO.setRefTwinTandemCode(twinJobsData[11] != null ? twinJobsData[11].toString() : null);
            jobListPOJO.setTwinTandemCodeId(twinJobsData[12] != null ? twinJobsData[12].toString() : null);
            jobListPOJO.setRefCntrtwinTandemCodeId(twinJobsData[13] != null ? twinJobsData[13].toString() : null);
            jobListPOJO.setOperationCode("I");
            jobListPOJO.setTwinTandemId("0");
            jobListPOJO.setMinaproTwinSplit(OpusQcJobListService.NO);
            jobListPOJOList.add(jobListPOJO);
        }
        return jobListPOJOList;
    }

    /**
     * 
     * @param terminalId
     * @param rotationId
     * @param equipmentId
     * @return no of jobs available for above three inputs criteria.
     * @throws SQLException
     */
    @SuppressWarnings("unchecked")
    public List<OPUSQCJobListEntity> getQCJobListByRotationAndEquipment(JobListEvent jobList, String rotationId) {

        LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(jobList.getEquipmentID()), new StringBuilder(
                " Started getJobListByRotationAndEquipment()").toString());

        Session session = null;
        Transaction tx = null;
        List<OPUSQCJobListEntity> resultSet = null;
        session = HibernateUtil.getSessionFactory().getCurrentSession();
        tx = session.beginTransaction();

        try {

            String[] vesselVoyage = JobListUtil.getVesselAndVoyageDetails(jobList.getUserID());

            LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(jobList.getEquipmentID()), new StringBuilder(
                    " Vessel Voyage Details Are::").append(vesselVoyage != null ? Arrays.toString(vesselVoyage) : null)
                    .toString());

            resultSet = session.createQuery(OPUSJobListQueries.GET_QC_JOB_LIST_ENTITY)
                    .setParameter(EQUIPMENT_ID, jobList.getEquipmentID()).setParameter(ROTATION_ID, rotationId)
                    .setParameter(TERMINAL_ID, jobList.getTerminalID()).setParameter(VESSEL_CODE, vesselVoyage[0])
                    .setParameter(VOYAGE, vesselVoyage[1]).list();
            tx.commit();

        } catch (Exception ex) {

            LOGGER.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append("  While Retrieving Job List Jobs From Database ")
                            .append(REASON).toString(), ex);

            if (session != null && session.isOpen()) {
                session.getTransaction().rollback();
            }

        }

        LOGGER.logMsg(LOG_LEVEL.TRACE, "", " Current Jobs ::::" + (resultSet != null ? resultSet.toString() : null));
        return resultSet;
    }

    /**
     * Which used to delete twin tandem Id when user split tandem job from UI
     * 
     * @param deletableTwinTandemList
     */

    public void deleteTwinJobsForTandemSplit(List<TwinTandemJobs> deletableTwinTandemList) {
        LOGGER.logMsg(LOG_LEVEL.INFO, "", " Started deleteBulkTwinTandemJobs() To delete twin tandem Id's - ");
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            transaction = session.beginTransaction();
            for (TwinTandemJobs twinTandemJob : deletableTwinTandemList) {
                LOGGER.logMsg(LOG_LEVEL.INFO, "",
                        new StringBuilder(" Deleting TwinTandem Id::").append(twinTandemJob.getTwinTandemId())
                                .toString());
                session.delete(twinTandemJob);
            }
            transaction.commit();
        } catch (Exception ex) {

            if (session != null && session.isOpen()) {
                session.getTransaction().rollback();
            }
            LOGGER.logException(
                    new StringBuilder(EXCEPTION_OCCURED)
                            .append("   While Deleting Twin Tandem Contaier List From Database  ").append(REASON)
                            .toString(), ex);

        }

    }

    @SuppressWarnings("unchecked")
    public void deleteDeActivatedJobs(JobListEvent jobList, final String rotationId) {

        LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(jobList.getEquipmentID()),
                " Strated De Acticated Jobs Delete Method.");

        Session currentSession = null;
        Transaction transaction = null;

        try {

            currentSession = HibernateUtil.getSessionFactory().getCurrentSession();
            transaction = currentSession.beginTransaction();

            List<TwinTandemJobs> existedTwinJobs = currentSession.createQuery(GET_EXISISTING_TWIN_JOBS_QUERY)
                    .setParameter(ROTATION_ID, rotationId).setParameter(EQUIPMENT_ID, jobList.getEquipmentID())
                    .setParameter("terminalID", jobList.getTerminalID())
                    .setParameter(IS_JOB_COMPLETED, OpusQcJobListService.NO).list();

            LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(jobList.getEquipmentID()), new StringBuilder(
                    " Retrieved Records Size Is::").append(existedTwinJobs != null ? existedTwinJobs.size() : 0)
                    .toString());

            for (TwinTandemJobs twinTandemJob : existedTwinJobs) {
                currentSession.delete(twinTandemJob);
            }

            transaction.commit();

        } catch (Exception ex) {
            LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
            if (currentSession != null && currentSession.isOpen()) {
                transaction.rollback();
            }
        }

    }

    @SuppressWarnings("unchecked")
    public static void retrieveTwinTandemJobAndUpdateStatus(String containerId, String rotationId, String terminalId,
            String equipmentId) {

        LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(equipmentId), new StringBuilder(
                " Strated Job Completed Status Update Method ").append(" Parameters::").append(" Conainer Id::")
                .append(containerId).toString());

        if (containerId == null || containerId.isEmpty() || rotationId == null || rotationId.isEmpty()
                || equipmentId == null || equipmentId.isEmpty()) {
            LOGGER.logMsg(LOG_LEVEL.ERROR, rotationId.concat("-").concat(equipmentId),
                    "Container/Equipment/Rotation Is Null , Unable To Continue Further Steps..");
            return;
        }
        Session currentSession = null;
        Transaction transaction = null;

        try {

            currentSession = HibernateUtil.getSessionFactory().getCurrentSession();
            transaction = currentSession.beginTransaction();

            List<TwinTandemJobs> existedTwinTandemjobs = currentSession
                    .createQuery(OPUSJobListQueries.GET_TWIN_TANDEM_RECORD).setParameter(ROTATION_ID, rotationId)
                    .setParameter(EQUIPMENT_ID, equipmentId).setParameter("containerId", containerId)
                    .setParameter(IS_JOB_COMPLETED, OpusQcJobListService.NO).list();

            LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(equipmentId), " Existed Twin Tandem jobs:::"
                    + existedTwinTandemjobs);

            if (existedTwinTandemjobs != null && !existedTwinTandemjobs.isEmpty()) {
                for (TwinTandemJobs twinTandemJob : existedTwinTandemjobs) {
                    twinTandemJob.setIsJobCompleted(OpusQcJobListService.YES);
                    currentSession.update(twinTandemJob);
                }
            } else {
                LOGGER.logMsg(LOG_LEVEL.INFO, rotationId.concat("-").concat(equipmentId),
                        " No Twin/Tandem Jobs Avaialble");
            }

            transaction.commit();

        } catch (Exception ex) {

            LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);

            if (currentSession != null && currentSession.isOpen() && transaction != null) {
                transaction.rollback();
            }
        }
    }
    
}
