package com.minapro.procserver.events.plc;

import java.sql.Timestamp;

/**
 * ValueObject holding the data received from PLC after parsing.
 * 
 * @author Kumaraswamy
 *
 */
public class EsperRMGPLCEvent {

    private String node;
    private Timestamp tagTime;
    private int noOfContainers;
    private int spreader1Size;
    private String yardPos;
    private double trolleyPos;
    private String terminalId;
    private String controlSystemType;
    private int spreader1TwistLock;
    private double spreaderLsWeight;
    private String laneId;
    
	public String getLaneId() {
		return laneId;
	}

	public void setLaneId(String laneId) {
		this.laneId = laneId;
	}
	
    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public Timestamp getTagTime() {
        return tagTime;
    }

    public void setTagTime(Timestamp tagTime) {
        this.tagTime = tagTime;
    }

    public int getNoOfContainers() {
        return noOfContainers;
    }

    public void setNoOfContainers(int noOfContainers) {
        this.noOfContainers = noOfContainers;
    }

    public int getSpreader1Size() {
        return spreader1Size;
    }

    public void setSpreader1Size(int spreader1Size) {
        this.spreader1Size = spreader1Size;
    }

    public String getYardPos() {
        return yardPos;
    }

    public void setYardPos(String yardPos) {
        this.yardPos = yardPos;
    }

    public double getTrolleyPos() {
        return trolleyPos;
    }

    public void setTrolleyPos(double trolleyPos) {
        this.trolleyPos = trolleyPos;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getControlSystemType() {
        return controlSystemType;
    }

    public void setControlSystemType(String controlSystemType) {
        this.controlSystemType = controlSystemType;
    }

    public int getSpreader1TwistLock() {
        return spreader1TwistLock;
    }

    public void setSpreader1TwistLock(int spreader1TwistLock) {
        this.spreader1TwistLock = spreader1TwistLock;
    }

    public double getSpreaderLsWeight() {
        return spreaderLsWeight;
    }

    public void setSpreaderLsWeight(double spreaderLsWeight) {
        this.spreaderLsWeight = spreaderLsWeight;
    }

    @Override
   	public String toString() {
   		return "EsperRMGPLCEvent [node=" + node + ", tagTime=" + tagTime
   				+ ", noOfContainers=" + noOfContainers + ", spreader1Size="
   				+ spreader1Size + ", yardPos=" + yardPos + ", trolleyPos="
   				+ trolleyPos + ", terminalId=" + terminalId
   				+ ", controlSystemType=" + controlSystemType
   				+ ", spreader1TwistLock=" + spreader1TwistLock
   				+ ", spreaderLsWeight=" + spreaderLsWeight + ", laneId="
   				+ laneId + "]";
   	}
    
}
