package com.minapro.procserver.actors.obf;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.obf.VesselDocumentEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * 
 * 
 * @author Prasad.Tallapally
 *
 */
public class VesselDocumentActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselDocumentActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof VesselDocumentEvent) {
            VesselDocumentEvent vesselDocumentEvent = (VesselDocumentEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, vesselDocumentEvent.getUserID(), "Received VesselDocument request"
                    + vesselDocumentEvent);
        } else {
            unhandled(message);
        }

    }

}
