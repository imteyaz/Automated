package com.minapro.procserver.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.che.BlockCellGrid;
import com.minapro.procserver.events.che.CHEJobListEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersRequestEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersResponseEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Which is a utility class for Block Related Operations.
 * 
 * @author 1103222
 *
 */
public class BlockCotainersUpdateUtil implements Serializable {

	private static final long serialVersionUID = 3081266414534040084L;

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockProfileUtil.class);

	RDTYardProfileCacheManager blockCache = RDTYardProfileCacheManager.getInstance();

	private BlockCotainersUpdateUtil() {

	}

	public static BlockCotainersUpdateUtil getInstance() {
		return new BlockCotainersUpdateUtil();
	}

	/**
	 * Sending Container Attributes Details required Container list to ESB.
	 * 
	 * @param updateRequiredContainerList
	 *            -- List of containers which does not have ISO,POD,WT attribute values.
	 * @param Event
	 *            --JobListEvent.
	 */
	public void sendUpdateRequiredBlockContainersToESB(List<String> updateRequiredContainerList, Event jobEvent) {

		logger.logMsg(LOG_LEVEL.INFO, "", " Received UpdateRequiredContainerList From JobList::"
				+ updateRequiredContainerList);

		try {

			CHEJobListEvent jobListEvent = (CHEJobListEvent) jobEvent;

			UpdateBlockContainersRequestEvent updateBlockCntrsReqEvnt = new UpdateBlockContainersRequestEvent();

			updateBlockCntrsReqEvnt.setEquipmentID(jobListEvent.getEquipmentID());
			updateBlockCntrsReqEvnt.setUserID(jobListEvent.getUserID());
			updateBlockCntrsReqEvnt.setEventID(UUID.randomUUID().toString());
			updateBlockCntrsReqEvnt.setTerminalID(jobListEvent.getTerminalID());
			updateBlockCntrsReqEvnt.setUpdateRequiredContainerList(updateRequiredContainerList);

			OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(jobListEvent.getUserID());

			ESBQueueManager.getInstance().postMessage(updateBlockCntrsReqEvnt, operator, jobListEvent.getTerminalID());

			logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getEquipmentID(), new StringBuilder(
					" Setting Current Equipment Job Completion Status to Completed Into Cache").toString());

			RDTCacheManager.getInstance().setEqJobListReqStatus(jobListEvent.getEquipmentID(),
					EquipmentJobListRequestStatus.COMPLETED);

		} catch (Exception ex) {
			logger.logException(new StringBuffer("Exception Occured In sendUpdateRequiredBlockContainersToESB()")
					.append("::").toString(), ex);
		}
	}

	/**
	 * Method is used to Update the block profile and Central cache with container attributes like ISO,POD,WT.
	 * 
	 * @param UpdateBlockContainersResponseEvent
	 */
	public void updateBlockProfileWithListOfContainers(UpdateBlockContainersResponseEvent updatedResponse) {

		int sizeOfUpdatedCotainersList = updatedResponse.getUpdatedContainerList() != null ? updatedResponse
				.getUpdatedContainerList().size() : 0;

		logger.logMsg(LOG_LEVEL.INFO, updatedResponse.getUserID(), " Received UpdatedContainers Info From "
				+ "ESB With Size-" + sizeOfUpdatedCotainersList);

		String currentYardLocation;
		List<YardProfileContainer> listOfUpdatedContainers = updatedResponse.getUpdatedContainerList();
		BlockProfileUtil blockUtil = BlockProfileUtil.getInstance();

		try {

			for (YardProfileContainer yardContainer : listOfUpdatedContainers) {

				currentYardLocation = yardContainer.getYardPosition();
				logger.logMsg(LOG_LEVEL.INFO,	currentYardLocation,
						new StringBuilder(" Contaier Details::").append(yardContainer.toString())
								.append(" Adding To Central Cache").toString());

				blockUtil.addYardContainerToCentralCache(yardContainer);
				/*
				 * Current Release ATOM application is not maintaining the block detais.No need of following code.
				 * 
				 * 
				 * if(currentYardLocation==null || currentYardLocation.isEmpty()){
				 * 
				 * logger.logMsg(LOG_LEVEL.ERROR,updatedResponse.getUserID(),MinaproLoggerConstants.YARD_LOCATION_IS_EMPTY
				 * ); continue;
				 * 
				 * } else {
				 * 
				 * blockNumber = currentYardLocation.substring(0,3); blockProfile =
				 * blockCache.getBlockToYardProfile(blockNumber);
				 * 
				 * if(blockProfile!=null){
				 * 
				 * Map<String,String> rowData = blockCache.getBlockRelatedRowData(blockNumber); Map<String,String>
				 * stackData = blockCache.getBlockRelatedStockData(blockNumber);
				 * 
				 * if(rowData!=null && stackData!=null){ logger.logMsg(LOG_LEVEL.INFO,blockNumber,
				 * " Calling prepareBlockCellWithContainer() To Update Block Profile");
				 * blockUtil.prepareBlockCellWithContainer(blockNumber, yardContainer, rowData, stackData, blockProfile,
				 * currentYardLocation); } else {
				 * logger.logMsg(LOG_LEVEL.INFO,blockNumber," Row/Stack Data Not Prepared,Ignore Update");
				 * 
				 * }
				 * 
				 * } }
				 */

			}
		} catch (Exception ex) {
			logger.logException(" Exceptin Occured In processReceivedBlockContaiersFromPromis -", ex);
		}
	}

	/**
	 * Method is used to retrieve the list of available containers in Tier section.
	 * 
	 * @param blockNumber
	 * @param rowNumber
	 * @param stackNumber
	 * @return
	 */

	public List<YardProfileContainer> getContainersFromBlockCell(String blockNumber, String rowNumber,
			String stackNumber) {

		List<YardProfileContainer> listOfContainersInBlockCell = null;

		int rowMaxwrkgStkgHt = 0;
		BlockProfileUtil blockUtil = BlockProfileUtil.getInstance();
		BlockProfile blockProfile = blockCache.getBlockToYardProfile(blockNumber);
		String rowSeqNo = blockUtil.getRowSeqNumber(blockNumber, rowNumber);
		String stackSeqNumber = blockUtil.getStackSeqNumber(blockNumber, stackNumber);
		rowMaxwrkgStkgHt = blockUtil.getRowMaxWorkingStkHeight(blockNumber, rowNumber);

		if (blockProfile == null || rowSeqNo == null || stackSeqNumber == null || rowMaxwrkgStkgHt == 0) {
			logger.logMsg(LOG_LEVEL.INFO, blockNumber, " Block Profile Is Not Created ");
			return listOfContainersInBlockCell;
		} else {

			YardProfileContainer yardContainer;
			BlockCellGrid blockCellGrid = blockProfile.getCellGrid(Integer.parseInt(rowSeqNo) - 1,
					Integer.parseInt(stackSeqNumber) - 1);

			listOfContainersInBlockCell = new ArrayList<YardProfileContainer>(rowMaxwrkgStkgHt);

			for (int startTierNum = 0; startTierNum < rowMaxwrkgStkgHt; startTierNum++) {
				yardContainer = blockCellGrid.getCurrentYardContainer(startTierNum);
				listOfContainersInBlockCell.add(yardContainer);
			}
			return listOfContainersInBlockCell;
		}
	}
}
