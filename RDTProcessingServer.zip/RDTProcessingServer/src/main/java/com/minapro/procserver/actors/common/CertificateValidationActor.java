package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserViolationAndDelay;
import com.minapro.procserver.db.UserViolationAndDelay.VIOLATION_DELAY_CATEGORY;
import com.minapro.procserver.events.common.CertificateValidateEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the certificate validation event.</p>
 * 
 * <p>If the certificate validation is failed, an alert is generated to the device and the validation failure is passed
 * to ESB. </p>
 * 
 * @author Rosemary George
 *
 */
public class CertificateValidationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CertificateValidationActor.class);

    @Override
    /**
     * Handles the CertificateValidateEvent
     */
    public void onReceive(Object message) throws Exception {
        if (message instanceof CertificateValidateEvent) {
            CertificateValidateEvent certificateValidationDetails = (CertificateValidateEvent) message;
            logger.logMsg(LOG_LEVEL.DEBUG, certificateValidationDetails.getUserID(),
                    "Received certificate validation event-" + certificateValidationDetails);
            if (RDTProcessingServerConstants.STATUS_FAILURE.equalsIgnoreCase(certificateValidationDetails.getStatus())) {
                sendValidationError(certificateValidationDetails);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, certificateValidationDetails.getUserID(), "User certification is valid");
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * Construct the certificate validation alert to the device as well as to the ESB
     * 
     * @param certificateValidationDetails
     */
    private void sendValidationError(CertificateValidateEvent certificateValidationDetails) {
        logger.logMsg(LOG_LEVEL.WARN, certificateValidationDetails.getUserID(),
                "Certificate validation failed with message -" + certificateValidationDetails.getReason());

        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(ALERT_MESSAGE);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append(valueSeperator).append(eventTypeID);
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                EventUtil.getInstance().getEventParameter(certificateValidationDetails, msgFields.get(i),
                        responseToDevice);
            }

            User user = RDTCacheManager.getInstance().getUserDetails(certificateValidationDetails.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(
                        certificateValidationDetails.getUserID());
                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        certificateValidationDetails.getTerminalID());

                ESBQueueManager.getInstance().postMessage(certificateValidationDetails, operatorRole,
                        certificateValidationDetails.getTerminalID());

                saveAlert(certificateValidationDetails, user);
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing certificateValidationDetails -", e);
        }

    }

    /**
     * Creates the UserViolation and passes the event to masterActor for further processing
     * 
     * @param certificateValidationDetails
     *            - the certificate validation result received from ESB
     * @param user
     *            - user on whom the violation is raised
     */
    private void saveAlert(CertificateValidateEvent certificateValidationDetails, User user) {
        logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending the violation details to the database - "
                + certificateValidationDetails);
        UserViolationAndDelay violation = new UserViolationAndDelay(certificateValidationDetails.getReason(), user,
                VIOLATION_DELAY_CATEGORY.VIOLATION);
        JournalEvent journalEvent = new JournalEvent(violation, UPDATETYPE.ADD);
        getSender().tell(journalEvent, null);
    }
}
