package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the DLM Request event details
 * 
 * @author Venkataramana.ch
 *
 */

public class DLMEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3441643875287673976L;

    @Override
    public String toString() {
        return "DLMEvent [UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID() + ", TerminalID="
                + getTerminalID() + "]";
    }

}
