package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class FollowITVEvent extends Event  implements Serializable{

	private static final long serialVersionUID = -7096668532698806647L;
	
	private String carryingContainerId;
	
	private String qcId;

	public String getCarryingContainerId() {
		return carryingContainerId;
	}

	public void setCarryingContainerId(String carryingContainerId) {
		this.carryingContainerId = carryingContainerId;
	}

	public String getQcId() {
		return qcId;
	}

	public void setQcId(String qcId) {
		this.qcId = qcId;
	}

	@Override
	public String toString() {
		return "FollowITVEvent [carryingContainerId=" + carryingContainerId + ", qcId=" + qcId + ", getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}
}
