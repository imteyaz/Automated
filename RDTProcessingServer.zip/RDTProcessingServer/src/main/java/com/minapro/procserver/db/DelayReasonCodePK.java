package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class DelayReasonCodePK implements Serializable {

    private static final long serialVersionUID = 5896784598074254281L;

    @Column(name = "DELAY_REASON_ID")
    private String delayReasonCodeID;

    @Column(name = "DELAY_TYPE")
    private String delayType;

    public String getDelayReasonCodeID() {
        return delayReasonCodeID;
    }

    public void setDelayReasonCodeID(String delayReasonCodeID) {
        this.delayReasonCodeID = delayReasonCodeID;
    }

    public String getDelayType() {
        return delayType;
    }

    public void setDelayType(String delayType) {
        this.delayType = delayType;
    }

}
