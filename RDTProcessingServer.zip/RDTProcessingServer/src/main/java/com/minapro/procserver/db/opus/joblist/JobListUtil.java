package com.minapro.procserver.db.opus.joblist;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REFERENCE_CONTAINER_SEPERATOR;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.ISOCodesMaster;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.CHEJobListUtil;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;




public class JobListUtil {

	private static final JobListUtil INSTNACE = new JobListUtil();

	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(JobListUtil.class);
	
	private static final String MOVE_TYPE_NOT_HANDLED = "** Current Move Type Is Not Handled **";
	
	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
	            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
	            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
	            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
	    
	private static final String REMARKS = "Remarks";
	private static final String COLOUR_CODE = "ColourCode";
	private static final String MOVE_TYPE = "MoveType";
	private static final String FROM_LOC =  "FromLocation";
	private static final String TO_LOC = "ToLocation";
	private static final String CONTAINER_ID = "ContainerID";
	private static final String TWIN_CONTAINER_ID = "TwinContainerId";
	private static final String PRIORITY = "Priority";
	private static final String PRIORITY_COLOUR = "PriorityColour";
	private static final String SEAL_STATUS = "SealStatus";
	private static final String HAZ_CODE = "HazardousCode";
	private static final String SEQ_NO = "SequenceNumber";
	private static final String POSITION = "Position";
	private static final String STATUS   ="Status";
	private JobListUtil(){

	}

	public static JobListUtil getInstnace(){
		return INSTNACE;
	}
	
	public static int getBayNumber(final String vesselLocation){
		return Integer.parseInt(getBayRowTier(vesselLocation)[0]);
	}
	
	public static boolean isItTwoFortyTandem(final String location){
		
		return location!=null && !location.isEmpty() ? (getBayNumber(location) & 1)==0 ? true :false :false; 
	}
	
	public static String[] getBayRowTier(final String location) {
		return location.split("\\.");
	}
	
	public static double getUpdatedSeqNumber(final double seqNo , final double refSeqNo){
		
		return seqNo> refSeqNo ? refSeqNo + 0.1 : seqNo+ 0.1;
		
	}
	
	/*
	 * Method is responsible for sending JobLey from Database.
	 * @param cntrNo
	 * @param moveType
	 * @param userId
	 * @param equipmentId
	 * @return JobKey
	 */
	public String getJobKeyForJobListCntr(final String cntrNo , final String moveType , final String userId , final String equipmentId){

	    	final String logId = userId.concat("-").concat(equipmentId);
	    	
	    	LOGGER.logMsg(LOG_LEVEL.INFO,logId,new StringBuilder("Started getJobKeyForJobListCntr()").append(" Container No:")
	    			.append(cntrNo).append(" Move Type:").append(moveType).append(" User - EquipmentId").append(logId).toString());
	    	
	    	ListOrderedMap<String, JobListContainer> jobsListFromCache = RDTCacheManager.getInstance().getJobList(userId, equipmentId);

	    	if(jobsListFromCache!=null) {

	    		JobListContainer jobListCntr = jobsListFromCache.get(cntrNo.concat(moveType));

	    		if(jobListCntr!=null) {
	    			LOGGER.logMsg(LOG_LEVEL.INFO, logId," Job Key Is::"+jobListCntr.getJobKey());
	    			return jobListCntr.getJobKey();
	    		} else {
	    			LOGGER.logMsg(LOG_LEVEL.INFO,logId," Current Container Not Available In Cache,Returning Null");
	    		}
	    	} else {

	    		LOGGER.logMsg(LOG_LEVEL.INFO,logId," JobList Is Not Available For Current Logged In User...");
	    	}
	    	return null;
	    }
	
	public static String getCHEJobYardLocationBasedOnMoveType(final JobListContainer container) {

		final String moveType = container.getMoveType();

		if (LOAD.equals(moveType) || GO.equals(moveType) || MO.equals(moveType) || RH.equalsIgnoreCase(moveType)) {
			return  container.getFromLocation(); 
		} else if (DSCH.equals(moveType) || GI.equals(moveType) || MI.equals(moveType)) {
			return container.getToLocation();
		} else {
			LOGGER.logMsg(LOG_LEVEL.WARN,moveType,MOVE_TYPE_NOT_HANDLED);
			return null;
		}

	}

	/**
	 * Method is responsible to send the ITV Number from CHE job list based on the Move Type.
	 * @param container -- JobListContainer
	 * @return -- ITV Nubmer.
	 */
	public static String getITVNoFromCHEJobListBasedOnMoveType(JobListContainer container){

		final String moveType = container.getMoveType();

		if (LOAD.equals(moveType) || GO.equals(moveType) || MO.equals(moveType) || RH.equalsIgnoreCase(moveType)) {
			return  container.getToLocation(); 
		} else if (DSCH.equals(moveType) || GI.equals(moveType) || MI.equals(moveType)) {
			return container.getFromLocation();
		} else {
			LOGGER.logMsg(LOG_LEVEL.WARN,moveType,MOVE_TYPE_NOT_HANDLED);
			return null;
		}

	}
	/**
	 * 
	 * @param itvNumber
	 * @return true or false
	 */
	public static boolean isCurrentToLocationITVNumber(String itvNumber){
		
		return (itvNumber!=null && !itvNumber.isEmpty()) ? 
				RDTCacheManager.getInstance().getEquipmentDetails(itvNumber)==null ? false : true : false ;
	}
	
	
	public void sendJobListToDevice(List<JobListContainer> jobs, Event event, String userId, String messageModifier,
            OPERATOR role){
       
    	// get the job list message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(RDTProcessingServerConstants.JOB_LIST);

        // get the container message format
        List<String> containerFields = EventFormats.getInstance().getEventFields("CONTAINER");

        String msgField;
      
        String explosiveCodes = EventUtil.getInstance().getExplosiveCodes();        
       
		final int noOfJobs = jobs.size();
        String moveType;
		if (noOfJobs > 0) {
          
			StringBuilder responseToDevice = new StringBuilder(messageModifier).append(VALUE_SEPARATOR).
					append(DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST));

            // iterate through the jobList message formats
            for (int i = 1; i < msgFields.size(); i++) {
             
            	responseToDevice.append(VALUE_SEPARATOR);
                msgField = msgFields.get(i);

                // in case of Jobs fields, its time to iterate through the containers
                if ("Jobs".equalsIgnoreCase(msgField)) {
                    // Iterate till the size of the container list
                    for (int j = 0; j < noOfJobs; j++) {
                       
                    	JobListContainer job = jobs.get(j);
                        
                    	moveType = job.getMoveType();
                    	if(GI.equalsIgnoreCase(job.getMoveType())){
                    		moveType = LOAD;
                    	}else if(GO.equalsIgnoreCase(job.getMoveType())){
                    		moveType = DSCH;
                    	}
                    	Container container = RDTCacheManager.getInstance().getContainerDetails(job.getContainerId(), moveType);

                        // For each container, iterate through the Container message format
                        for (int conCounter = 0; conCounter < containerFields.size(); conCounter++) {

                        	switch(containerFields.get(conCounter)) {
                        	
                        	case REMARKS 			:   responseToDevice.append(container != null ? EventUtil.getInstance().getContainerIcon(container) : "");
                        								break;
                        						
                        	case COLOUR_CODE		:   responseToDevice.append(container != null && container.getPod() != null ? 
                        								RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(container.getPod()) : "");
                        								break;
                        						
                        	case MOVE_TYPE 			:   EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter),responseToDevice);
                        								break;
                        								
                        	case FROM_LOC   		:   EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter),responseToDevice);
                        								break;
                        								
                        	case TO_LOC				:   EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter),responseToDevice);
                        								break;
                        								
                        	case CONTAINER_ID	 	:   responseToDevice.append(job.getContainerId());
                        								break;

                        	case TWIN_CONTAINER_ID	:   if (job.getTandemContainerIDs() != null && job.getTandemContainerIDs().length > 0) {
                        											for (String tandem : job.getTandemContainerIDs()) {
                        													responseToDevice.append(tandem).append(REFERENCE_CONTAINER_SEPERATOR);
                        												}
                        								responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
                        								} else {
                        										responseToDevice.append(job.getTwinContainerId());
                        								}
                        								break;
                        								
                        	case PRIORITY	 		: 	responseToDevice.append(0);
                        								break;

                        	case PRIORITY_COLOUR	: 	responseToDevice.append("");
                        								break;
                        								
                        	case SEAL_STATUS	 	: 	responseToDevice.append(container!= null ? container.isSealOn()?"Y":"N" : "Y");
                        								break;
                        								
                        	case HAZ_CODE  			: 	responseToDevice.append((container!= null && explosiveCodes != null && container.getHazardousCode()!= null) 
                        										? EventUtil.getInstance().isExplosiveContainer(explosiveCodes, container.getHazardousCode()) : false);
                        								break;	
                        								
                        	case SEQ_NO				:  responseToDevice.append(job.getSeqNumber());
                        								break;
                        								
                        	case POSITION	 		:   EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter),responseToDevice);
														break;
														
														
            				case STATUS             :  responseToDevice.append(job.getJobStatus());
            											break;

                        								
                        	default					: 	EventUtil.getInstance().getEventParameter(container, containerFields.get(conCounter),responseToDevice);
                        	
                        	}
                        	responseToDevice.append(ITEM_SEPARATOR);
                        }
                        responseToDevice.append(ROW_SEPARATOR);
                        }
                        
                  
                } else if ("UserID".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(userId);
                } else {
                    EventUtil.getInstance().getEventParameter(event, msgField, responseToDevice);
                }
            }

            // send the batch message
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                    event.getTerminalID());
            
            if(role.equals(OPERATOR.CHE)) {
            	CHEJobListUtil.getInstance().addPlannedMoves(userId, event.getEquipmentID(), noOfJobs);
            }
        }
    }
	
	public static String prepareIsoCodes() {		
		Collection<ISOCodesMaster> isoCodes = RDTCacheManager.getInstance().getISOCodes();		
		if(isoCodes!=null && !isoCodes.isEmpty()){			
			StringBuilder isoCodesData = new StringBuilder();			
			for(ISOCodesMaster isoCode :isoCodes){
				isoCodesData.append(isoCode.getIsoCode()).append("-").append(isoCode.getCodeDescription()).
					append(DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY));
			}
			return isoCodesData.delete(isoCodesData.length()-1,isoCodesData.length()).toString();
		} 
		return null;
	}
	
	public static String[]  getVesselAndVoyageDetails(String userId){
		String[] vesselVoyage = null;
		try {
			ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
					.getAllocationDetails(userId);
			String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(
					allocationDetails.getRotationID());
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG, userId, "vesselCode associated with rotation : " + allocationDetails.getRotationID() 
						+ ":" + vesselCode);
			if (vesselCode != null) {
				Vessel vessel = RDTVesselProfileCacheManager.getInstance().getVesselFromBerthedList(vesselCode);
				LOGGER.logMsg(LOG_LEVEL.DEBUG, userId, "Vessel associated with Code : " + vessel);
				if (vessel != null) {
					vesselVoyage = new String[2];
					LOGGER.logMsg(LOG_LEVEL.DEBUG, allocationDetails.getRotationID(), "Got the aasociated vessel -"
							+ vessel.getVesselName() + vessel.getVoyageNo());
					vesselVoyage[0] = vessel.getVesselCode();
					vesselVoyage[1] = vessel.getVoyageNo();
				}
			}
		} catch (Exception ex) {
			LOGGER.logException("Caught exception while retrieving vesselVoyage details: ", ex);
		}

		return vesselVoyage;
	}
	
	public void prepareJobListCntrsMessage(StringBuilder responseToDevice, List<JobListContainer> jobs, int noOfJobs) {

		// get the container message format
		List<String> containerFields = EventFormats.getInstance().getEventFields("CONTAINER");
		String explosiveCodes = EventUtil.getInstance().getExplosiveCodes();
		final int containerFieldsCount = containerFields.size();

		// Iterate till the size of the container list
		for (int j = 0; j < noOfJobs; j++) {

			JobListContainer job = jobs.get(j);
			Container container = job.getContainer();
				
			if(container == null){
				container = RDTCacheManager.getInstance().getContainerDetails(job.getContainerId(), job.getMoveType());
			}			
			
			
			// For each container, iterate through the Container message format
			for (int conCounter = 0; conCounter < containerFieldsCount; conCounter++) {

				switch (containerFields.get(conCounter)) {

				case REMARKS:
					responseToDevice.append(container != null ? EventUtil.getInstance().getContainerIcon(container)
							: "");
					break;

				case COLOUR_CODE:
					responseToDevice
							.append(container != null && container.getPod() != null ? RDTVesselProfileCacheManager
									.getInstance().getColourCodeForPOD(container.getPod()) : "");
					break;

				case MOVE_TYPE:
					EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter), responseToDevice);
					break;

				case FROM_LOC:
					EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter), responseToDevice);
					break;

				case TO_LOC:
					EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter), responseToDevice);
					break;

				case CONTAINER_ID:
					responseToDevice.append(job.getContainerId());
					break;

				case TWIN_CONTAINER_ID:
					if (job.getTandemContainerIDs() != null && job.getTandemContainerIDs().length > 0) {
						for (String tandem : job.getTandemContainerIDs()) {
							responseToDevice.append(tandem).append(REFERENCE_CONTAINER_SEPERATOR);
						}
						responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
					} else {
						responseToDevice.append(job.getTwinContainerId());
					}
					break;

				case PRIORITY:
					responseToDevice.append(0);
					break;

				case PRIORITY_COLOUR:
					responseToDevice.append("");
					break;

				case SEAL_STATUS:
					responseToDevice.append(container != null ? container.isSealOn() ? "Y" : "N" : "Y");
					break;

				case HAZ_CODE:
					responseToDevice.append((container != null && explosiveCodes != null && container
							.getHazardousCode() != null) ? EventUtil.getInstance().isExplosiveContainer(explosiveCodes,
							container.getHazardousCode()) : false);
					break;

				case SEQ_NO:
					responseToDevice.append(job.getSeqNumber());
					break;

				case POSITION:
					EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter), responseToDevice);
					break;
			
				default:
					EventUtil.getInstance().getEventParameter(container, containerFields.get(conCounter),
							responseToDevice);
				}
				responseToDevice.append(ITEM_SEPARATOR);
			}
			responseToDevice.append(ROW_SEPARATOR);
		}
	}
	
	 /**
     * Rearrange the job list cache based on the ascending order of sequence number
     * @param userID
     * @param equipmentId
     */
	public void reorderJobsInCacheAsPerSequence(String userID, String equipmentId) {
		ListOrderedMap<String, JobListContainer> jobsInCache = RDTCacheManager.getInstance().getJobList(userID,
				equipmentId);
		try{
			if (jobsInCache != null) {
				List<JobListContainer> jobs = jobsInCache.valueList();
				LOGGER.logMsg(LOG_LEVEL.INFO, equipmentId, "CACHE CONTENT BEFORE SORT -" + jobs);
				Collections.sort(jobs, new Comparator<JobListContainer>() {
					@Override
					public int compare(JobListContainer o1, JobListContainer o2) {
						return new Double(o1.getSeqNumber()).compareTo(new Double(o2.getSeqNumber()));
					}
				});
				
				RDTCacheManager.getInstance().flushJobList(userID, equipmentId);
				for(JobListContainer job:jobs){
					RDTCacheManager.getInstance().updateJobList(userID, job,equipmentId, job.getMoveType());
				}
				LOGGER.logMsg(LOG_LEVEL.INFO, equipmentId, "CACHE CONTENT AFTER SORT -" + jobs);
			}
		}catch(Exception ex){
			LOGGER.logException("Caught exception in reorderJobsInCacheAsPerSequence -", ex);
		}
	}
}
