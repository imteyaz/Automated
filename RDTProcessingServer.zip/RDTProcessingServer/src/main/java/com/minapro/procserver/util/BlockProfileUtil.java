package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.PREVIOUS_STACK_SEQ_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.MinaproLoggerConstants.STACK_NUMBER_CHECK_IN_DATABASE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SPACE;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.db.yardview.BlockViewDao;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.che.BlockCellGrid;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.StackViewRequestEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for handling all block and stack related business manipulations. <h3>Business Logic Involved In
 * this class::</h3> <ul><li> In Entire Application,If stack number is even , we have to retrieve or update information
 * in two stacks Even stack means we have to consider it as a 2*20ft means 2 stacks. For example If it is :06 ,
 * Physically it will present in 05 and 07 stacks . We have to perform retrieve or update in these two stacks. </li><li>
 * We are getting first stack number for the forty stack from blockToStack40ftValuesCache cache . While filling the
 * block structure,adding data into this cache. </li><li></ul>
 * 
 * @author Uma
 *
 */
public class BlockProfileUtil implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7706998658982702734L;

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockProfileUtil.class);

	private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);

	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

	private static final BlockProfileUtil BLOCK_UTIL_INSTANCE = new BlockProfileUtil();

	private static final String REQ_STK_NUM = " Requested Stack Number:::";

	private static final String EVEN_STK_NULL = "Even Stack Key is Null";

	private static final String BLK_STK40FT_NULL = " Block To Stack 40ft  Map Is Null , Check prepareStackData() ";

	private static final String BLOCK_STRUCTURE_NOT_CREATED = " Block Cell Structured Is Not Defined For Current Location";
	private static final String CHECK_IN_DB = "Check In Database";

	private static final String DOT = ".";
	private RDTYardProfileCacheManager blockCache = RDTYardProfileCacheManager.getInstance();

	private BlockProfileUtil() {

	}

	public static BlockProfileUtil getInstance() {
		return BLOCK_UTIL_INSTANCE;
	}

	/*
	 * Method is responsible for Preparing BlockCellGrid with the current container. <h5>Logic Involved In this
	 * Method.</h5> <ul><li>First Get the Stack,Row,Tier sequence to get the Current BlockCellGrid.</li> <li>After
	 * BlockCellGrid get the YardProfileContainer from Tier and fill that YardProfileContainer based on following
	 * condition.</li> <ul><li>If the Current stack number is even number,Fill first stack with 40ft as true , Fill
	 * second stack with 40ft as false and previous stack number as first stack . if odd stack number fill that stack as
	 * 40ft false.</li></ul>
	 * 
	 * @param container
	 * 
	 * @param rowDataMap
	 * 
	 * @param stackDataMap
	 * 
	 * @param blockProfile
	 */
	public void prepareBlockCellWithContainer(String blockNumber, YardProfileContainer yardcontainer,
			Map<String, String> rowDataMap, Map<String, String> stackDataMap, BlockProfile blockProfile,
			String yardPosition) {

		BlockCellGrid blockCellData;
		String[] stackRowTierSeq;
		String current40FtStackFirst20ftStackNum = null;
		String yardContainerCurrentLocation = null;
		String moveType = yardcontainer.getMoveType();

		try {

			/*
			 * Re-using same method in ContainerMoveActor to update the particular cell location , At that time we know
			 * the exact location . If YardPosition!=null means request came from ContainerMoveActor or
			 * BlockCotainersUpdateUtil else request from BlockViewResponseActor(Filling Strucutre Very First Time).
			 */
			logger.logMsg(LOG_LEVEL.INFO, blockNumber,
					new StringBuilder(" Container :").append(yardcontainer.getContainer().getContainerID())
							.append(" Yard Location Is::").append(yardcontainer.getYardPosition())
							.append(" Move Type ::").append(moveType).append(" Old Location Is::")
							.append(yardcontainer.getOldPosition()).toString());

			yardContainerCurrentLocation = yardPosition != null ? yardPosition : prepareYardLocationWithDotValue(
					blockNumber, yardcontainer.getYardPosition());

			if (yardContainerCurrentLocation == null || yardContainerCurrentLocation.isEmpty()) {
				logger.logMsg(LOG_LEVEL.INFO, blockNumber, MinaproLoggerConstants.YARD_LOCATION_IS_EMPTY);
				return;
			}

			if (yardcontainer.getOldPosition() != null && !yardcontainer.getOldPosition().isEmpty()) {

				String oldLocation = prepareYardLocationWithDotValue(blockNumber, yardcontainer.getOldPosition());
				logger.logMsg(LOG_LEVEL.INFO, blockNumber, " After Dot Preparation Old Location Is:::" + oldLocation);

				if (oldLocation != null) {
					Container container = BlockProfileUtil.getInstance().removeContainerFromBlockCell(oldLocation,
							yardcontainer.getContainer().getContainerID());

					if (container != null) {
						yardcontainer.setContainer(container);
					}
				}
			}

			stackRowTierSeq = BlockProfileUtil.getInstance().getStackRowTierSequncesFromLocation(blockNumber,
					yardContainerCurrentLocation);

			if (stackRowTierSeq[1] != null && !stackRowTierSeq[1].isEmpty() && stackRowTierSeq[2] != null
					&& stackRowTierSeq[3] != null) {

				String[] stackSeqNumbers = stackRowTierSeq[1].split("\\" + ROW_SEPARATOR);

				int rowseqNo = Integer.parseInt(stackRowTierSeq[2]);
				rowseqNo = rowseqNo - 1;

				int tierNum = Integer.parseInt(stackRowTierSeq[3]);
				tierNum = tierNum - 1;

				int stackSeqCount = stackSeqNumbers.length;
				int stackSeqNumber1;
				int stackSeqNumber2;

				if (stackSeqCount == 2) {

					for (int i = 0; i < stackSeqCount; i++) {

						if (i == 0) {

							stackSeqNumber1 = Integer.parseInt(stackSeqNumbers[0]) - 1;

							blockCellData = blockProfile.getCellGrid(rowseqNo, stackSeqNumber1);

							if (blockCellData != null) {
								current40FtStackFirst20ftStackNum = null;
								updateYardCell(blockCellData, yardcontainer, true, current40FtStackFirst20ftStackNum,
										tierNum, moveType);
							}

						} else {
							String stackSeqRelatedStackValue = stackDataMap.get(stackSeqNumbers[1]);

							stackSeqNumber2 = Integer.parseInt(stackSeqNumbers[1]) - 1;

							blockCellData = stackSeqRelatedStackValue != null ? blockProfile.getCellGrid(rowseqNo,
									stackSeqNumber2) : null;

							if (blockCellData != null) {
								current40FtStackFirst20ftStackNum = stackDataMap.get(stackSeqNumbers[0]);
								updateYardCell(blockCellData, yardcontainer, false, current40FtStackFirst20ftStackNum,
										tierNum, moveType);
							}
						}
					}
				} else {

					stackSeqNumber1 = Integer.parseInt(stackSeqNumbers[0]) - 1;
					blockCellData = blockProfile.getCellGrid(rowseqNo, stackSeqNumber1);

					if (blockCellData != null) {
						current40FtStackFirst20ftStackNum = null;
						updateYardCell(blockCellData, yardcontainer, false, current40FtStackFirst20ftStackNum, tierNum,
								moveType);
					}
				}

			} else {
				logger.logMsg(LOG_LEVEL.ERROR, blockNumber,
						new StringBuilder(" Current Location::").append(yardContainerCurrentLocation)
								.append(" Stack  Is Not Defined In Atom Database..").toString());
			}

		} catch (Exception ex) {
			logger.logException(
					new StringBuilder(EXCEPTION_OCCURED).append("prepareCellDataWithContainer()").append(REASON)
							.toString(), ex);
		}
	}

	/*
	 * Method is responsible for Preparing List Of Stack Sequence Numbers Based on the requested stack number.<pre><p>
	 * have a look into the class level comments to understand business logic</p> <p>Retrieve stack sequence number for
	 * requested stack number</p> <h4>Conditions Involved In this Method </h4><ul> <li>We have to prepare +5 and -5
	 * Stacks for requested stack number </li> <li>This logic is handled in two for loops and adding sequence numbers to
	 * list and returning this list at the end of method</li> </ul>
	 * 
	 * @param blockNumber
	 * 
	 * @param stackNumberFromClient
	 * 
	 * @return
	 */
	public List<String> prepareStacksSeqNumbersForBlockView(String blockNumber, String stackNumberFromClient) {

		logger.logMsg(LOG_LEVEL.INFO, blockNumber, " Started prepareStacksNumbersForBlockView() For Block Number"
				+ REQ_STK_NUM + stackNumberFromClient);

		Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockNumber);
		Map<String, String> stck40FtValues = blockCache.getBlockTo40ftStkValues(blockNumber);

		List<String> stackSeqNubersToDisplayList = null;

		String requstedStackSeqNo;

		try {

			requstedStackSeqNo = ((Integer.parseInt(stackNumberFromClient) & 1) == 0) ? stck40FtValues
					.get(stackNumberFromClient) : BlockProfileUtil.getInstance().getKeyFromValue(stackDataMap,
					stackNumberFromClient);

			logger.logMsg(LOG_LEVEL.INFO, stackNumberFromClient, "Requestd Stack Sequnce Number::" + requstedStackSeqNo);

			if (requstedStackSeqNo != null && !(requstedStackSeqNo.isEmpty())) {

				stackSeqNubersToDisplayList = new ArrayList<String>();

				for (int i = 5; i >= 1; i--) {

					int previousStackSeq = (Integer.parseInt(requstedStackSeqNo)) - i;

					if (previousStackSeq > 0) {
						stackSeqNubersToDisplayList.add(String.valueOf(previousStackSeq));
					} else {
						logger.logMsg(LOG_LEVEL.INFO, stackNumberFromClient, PREVIOUS_STACK_SEQ_MSG + previousStackSeq
								+ STACK_NUMBER_CHECK_IN_DATABASE);
					}
				}

				stackSeqNubersToDisplayList.add(requstedStackSeqNo);

				int maximumStackSeqNumber = stackDataMap.size();

				logger.logMsg(LOG_LEVEL.INFO, stackNumberFromClient, " Maximum Stack Sequence Number:::"
						+ maximumStackSeqNumber);

				for (int j = 1; j <= 5; j++) {

					int nextStackSeq = (Integer.parseInt(requstedStackSeqNo)) + j;

					if (nextStackSeq <= maximumStackSeqNumber) {
						stackSeqNubersToDisplayList.add(String.valueOf(nextStackSeq));
					} else {
						logger.logMsg(LOG_LEVEL.INFO, stackNumberFromClient, " Seems To Be nextStackSeq::"
								+ nextStackSeq + STACK_NUMBER_CHECK_IN_DATABASE);
						break;
					}
				}

			} else {
				logger.logMsg(LOG_LEVEL.INFO, "", REQ_STK_NUM + stackNumberFromClient + STACK_NUMBER_CHECK_IN_DATABASE);
				return stackSeqNubersToDisplayList;
			}

		} catch (Exception ex) {
			logger.logException(" Exception Occured In prepareStacksNumbersForBlockView ", ex);
			return stackSeqNubersToDisplayList;
		}

		logger.logMsg(LOG_LEVEL.INFO, "", " Displayable Stack Sequnce List::::" + stackSeqNubersToDisplayList);

		return stackSeqNubersToDisplayList;
	}

	/*
	 * Method is responsible for preparing stack numbers for the requested list of stack sequence numbers.
	 * 
	 * @param stackSeqValues
	 * 
	 * @param stackCompleteData
	 * 
	 * @return
	 */

	public StringBuilder getStackValuesBasedOnInput(List<String> stackSeqValues, Map<String, String> stackCompleteData) {

		StringBuilder stackDataForInput = new StringBuilder();
		try {
			int sizeOfStackSeqValues = stackSeqValues.size();
			for (int i = 0; i < sizeOfStackSeqValues; i++) {
				stackDataForInput.append(stackCompleteData.get(stackSeqValues.get(i))).append(ITEM_SEPERATOR);
			}
			if (stackDataForInput.length() > 0) {
				return stackDataForInput.delete(stackDataForInput.length() - 1, stackDataForInput.length());
			}
			logger.logMsg(LOG_LEVEL.INFO, "", " Final Prepared Stack Numbers For Display:::" + stackDataForInput);

		} catch (Exception ex) {
			logger.logException(
					new StringBuilder(EXCEPTION_OCCURED).append(" getStackValuesBasedOnInput").append(REASON)
							.toString(), ex);
			return null;
		}
		return null;
	}

	/*
	 * Method is responsible for getting key to the given value from the map. If stack number is more than 100,In
	 * database stack values are three digits like 001,002,003..100+. To achieve this requirement added one more
	 * condition for checking stack value with addition of 0 to the existed stack value.
	 * 
	 * @param map (Stack/Row Data)
	 * 
	 * @param mapValue (Stack/Row Number)
	 * 
	 * @return seqVal(Stack/Row seq no.)
	 * 
	 * @author UMAMAHESH M
	 */
	public String getKeyFromValue(Map<String, String> map, String value) {

		for (Entry<String, String> entry : map.entrySet()) {
			String valueFromMap = entry.getValue();
			if (valueFromMap.equals(value)) {
				return entry.getKey();
			}
		}
		return null;
	}

	/*
	 * Method is responsible for returning Block,Row,Stack,Tier sequence values from the yard location. Which is related
	 * to Yard side position
	 * 
	 * @param stowagePosition
	 * 
	 * @return Block,Stack,Row,Tier sequence numbers as String[]. 70A,6,7,1(First one is Stack Sequence No,Second One is
	 * Row Sequence No(In this case row value is G),Last one is tier num)
	 * 
	 * @author UMAMAHESH M
	 */
	public String[] getStackRowTierSequncesFromLocation(String blockId, String yardPosition) {

		String[] stackRowTierSeq = new String[4];

		String stackNum = "";
		String rowNum = null;

		try {

			String[] tierRowsAndStacks = blkStackRowTierSplitter(blockId, yardPosition);
			String blockNumber = tierRowsAndStacks[0];
			stackNum = tierRowsAndStacks[1];
			rowNum = tierRowsAndStacks[2];

			Map<String, String> rowDataMap = blockCache.getBlockRelatedRowData(blockId);
			Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockId);
			Map<String, String> blockToStk40ftValues = blockCache.getBlockTo40ftStkValues(blockId);

			if (rowDataMap == null) {
				logger.logMsg(LOG_LEVEL.INFO, SPACE, " Row Sequence Is Null");
				BlockProfile.prepareRowData(blockId, true);
				rowDataMap = blockCache.getBlockRelatedRowData(blockId);
			}
			if (stackDataMap == null) {

				BlockProfile.prepareStackData(blockId, true);
				stackDataMap = blockCache.getBlockRelatedStockData(blockId);
			}

			stackRowTierSeq[0] = blockNumber;

			if (((Integer.parseInt(stackNum)) & 1) == 0) {

				String previousStackKey;
				String nextStackKey;
				if (blockToStk40ftValues != null) {

					previousStackKey = blockToStk40ftValues.get(stackNum);

					if (previousStackKey != null) {
						nextStackKey = String.valueOf(Integer.parseInt(previousStackKey) + 1);
						stackRowTierSeq[1] = previousStackKey.concat(ROW_SEPARATOR).concat(nextStackKey);
					} else {
						logger.logMsg(LOG_LEVEL.INFO, stackNum, EVEN_STK_NULL);
					}

				} else {
					logger.logMsg(LOG_LEVEL.INFO, stackNum, BLK_STK40FT_NULL);
				}

			} else {

				String stackKey = getKeyFromValue(stackDataMap, stackNum);
				stackRowTierSeq[1] = stackKey;
			}

			stackRowTierSeq[2] = getKeyFromValue(rowDataMap, rowNum);
			stackRowTierSeq[3] = tierRowsAndStacks[3];

		} catch (NumberFormatException ex) {

			logger.logException(
					blockId
							+ new StringBuilder(EXCEPTION_OCCURED).append(" getStackRowTierFromStowagePosition() ")
									.append(REASON).append(" Unable to get key for the Stack value ").append(stackNum)
									.toString(), ex);

		} catch (Exception ex) {
			logger.logException(EXCEPTION_OCCURED + " getStackRowTierFromStowagePosition()", ex);
		}
		return stackRowTierSeq;

	}

	public String[] blkStackRowTierSplitter(String blockNumber, String stowagePosition) {

		String[] splittedLocations = new String[4];
		String rowNumber = null;
		String stack = null;
		/*
		 * while confirming the job from JobList,Yard Location is coming like 76D.46.D.2..other than job confirmations
		 * Yard position is coming like 70a80A1 or 100a80A1,To satisfy this condition following
		 * tierRowsAndStacks.length>2 condition added
		 */
		try {
			String[] tierRowsAndStacks = stowagePosition.split("\\.");

			if (tierRowsAndStacks.length > 2) {
				splittedLocations[0] = tierRowsAndStacks[0];
				splittedLocations[1] = tierRowsAndStacks[1];
				splittedLocations[2] = tierRowsAndStacks[2];
				splittedLocations[3] = tierRowsAndStacks[3];

				// logger.logMsg(LOG_LEVEL.INFO, blockNumber, " Splitted StowagePosition  :" + splittedLocations[0] +
				// "."
				// + splittedLocations[1] + "." + splittedLocations[2] + "." + splittedLocations[3]);
				return splittedLocations;

			} else {

				// Separating numeric parts from alphabets---Ex: 72G80A11 ---> 72 80 11
				String[] arr = stowagePosition.trim().split("[a-zA-Z]+");

				// If length is 2, that means only two numeric parts. Ex: 7280A11 ---> 7280 11
				if (arr.length == 2) {

					// Traversing through the stowagePosition to get the Row Number
					for (int i = 0; i < stowagePosition.length(); i++) {
						char c = stowagePosition.charAt(i);

						if (Character.isLetter(c)) {
							rowNumber = String.valueOf(c);
						}
					}
					/*
					 * If block number is 2nd digit then extract the stack from 3rd digit onwards If block number is 3rd
					 * digit then extract the stack from 4th digit onwards
					 */
					stack = ((Integer.parseInt(blockNumber) >= 100) ? stowagePosition.substring(3,
							stowagePosition.indexOf(rowNumber.charAt(0))) : stowagePosition.substring(2,
							stowagePosition.indexOf(rowNumber.charAt(0))));

					splittedLocations[0] = blockNumber;
					splittedLocations[1] = stack;
					splittedLocations[2] = rowNumber;
					splittedLocations[3] = arr[1];

					// If length is 3, that means 3 numeric parts. Ex: 72G80A11 ---> 72 80 11
				} else if (arr.length == 3) {

					// Ex: 72G80A11 -----> stackPart is 80A11
					String stackPart = stowagePosition.substring(3, stowagePosition.length());

					// Traversing through the stackPart to get the Row Number
					for (int i = 0; i < stackPart.length(); i++) {
						char c = stackPart.charAt(i);

						if (Character.isLetter(c)) {
							rowNumber = String.valueOf(c);
						}
					}

					splittedLocations[0] = blockNumber;
					splittedLocations[1] = arr[1];
					splittedLocations[2] = rowNumber;
					splittedLocations[3] = arr[2];

				}
				// logger.logMsg(LOG_LEVEL.TRACE,blockNumber," After Split Stowage Position::"+(splittedLocations!=null
				// ? Arrays.toString(splittedLocations):splittedLocations));
				return splittedLocations;
			}
		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" blkStackRowTierSplitter()")
					.append(REASON).toString(), ex);

		}
		return splittedLocations;
	}

	public String doProcessForRequestedStackNumber(StackViewRequestEvent stackRequest) {

		logger.logMsg(LOG_LEVEL.INFO, "", " Started doProcessForRequestedStackNumber() to get next stack sequnces");

		String blockNumber = stackRequest.getBlockNumber();
		String stackNumber = stackRequest.getStackNumber();

		String requstedStackSeqNo = null;
		logger.logMsg(LOG_LEVEL.INFO, stackRequest.getUserID(), " Block Number:::" + blockNumber + " Stack Number:::"
				+ stackNumber);

		Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockNumber);
		Map<String, String> blockToStk40ftValues = blockCache.getBlockTo40ftStkValues(blockNumber);

		requstedStackSeqNo = ((Integer.parseInt(stackNumber) & 1) == 0) ? blockToStk40ftValues.get(stackNumber)
				: BlockProfileUtil.getInstance().getKeyFromValue(stackDataMap, stackNumber);

		String navigationType = stackRequest.getNavigationType();
		logger.logMsg(LOG_LEVEL.INFO, stackNumber, " Requested Stack Number Navigation Type::" + navigationType);

		try {
			if (null != requstedStackSeqNo) {
				if (navigationType != null) {

					String nextOrPrevStackSeqNumber = getNextOrPreviousStackNumber(stackRequest, requstedStackSeqNo);
					logger.logMsg(LOG_LEVEL.INFO, nextOrPrevStackSeqNumber,
							" doProcessForRequestedStackNumber() Next or Previous" + "Stack Seq Value");
					if (nextOrPrevStackSeqNumber != null) {
						requstedStackSeqNo = nextOrPrevStackSeqNumber;
						return requstedStackSeqNo;
					} else {
						return null;
					}
				} else {
					return requstedStackSeqNo;
				}
			} else {
				logger.logMsg(LOG_LEVEL.INFO, stackNumber, " Stack Not Present In MP_BLKSTK_YPM Table.Null Returning");
				return null;
			}
		} catch (ArrayIndexOutOfBoundsException aoe) {
			logger.logException(new StringBuilder(BLOCK_STRUCTURE_NOT_CREATED).append(CHECK_IN_DB).toString(), aoe);
			return null;
		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" In doProcessForRequestedStackNumber ")
					.append(REASON).toString(), ex);
			return null;
		}
	}

	/**
	 * 
	 * @param stowagePosition
	 * @param moveType
	 * @param containerId
	 * @return
	 */
	public YardProfileContainer createYardProfileContainer(String stowagePosition, String moveType, String containerId) {
		logger.logMsg(LOG_LEVEL.INFO, stowagePosition, " Preparing Yard Profile Container For the Container::"
				+ containerId);
		YardProfileContainer yardContainer = new YardProfileContainer();
		Container container = RDTCacheManager.getInstance().getContainerDetails(containerId, moveType);
		if (container == null) {
			container = new Container();
			container.setContainerID(containerId);
		}
		yardContainer.setContainer(container);
		yardContainer.setYardPosition(stowagePosition);
		yardContainer.setMoveType(moveType);
		logger.logMsg(LOG_LEVEL.INFO, containerId, " YardProfileContainer Is::" + yardContainer);
		return yardContainer;
	}

	public String createYardLocation(String location) {
		String[] locations = location.split("\\.");
		String yardLocation = "";
		for (int i = 0; i < locations.length; i++) {
			yardLocation = yardLocation.concat(locations[i]);
		}
		return yardLocation;
	}

	/*
	 * Method is responsible for adding new container to the BlockCellGrid object as well as adding to cache. If current
	 * container already present in cache,just ignoring/skipping the current container,Else adding current container to
	 * central cache.
	 * 
	 * @param blockCell
	 * 
	 * @param yardContainer
	 * 
	 * @param is40FtStk
	 * 
	 * @param nextStackValue
	 * 
	 * @param tierNum
	 */
	public void updateYardCell(BlockCellGrid blockCell, YardProfileContainer yardContainer, boolean is40FtStk,
			String nextStackValue, int tierNum, String moveType) {

		try {
			// logger.logMsg(LOG_LEVEL.INFO,yardContainer.getContainer().getContainerID()," Started updateYardCell() With Yard Container Move Type:::"+yardContainer.getMoveType());
			Container existedContainerAtYardPosition = blockCell.getCurrentYardContainer(tierNum).getContainer();
			Container newContainerForYardPosition = yardContainer.getContainer();

			if (existedContainerAtYardPosition == null
					|| (existedContainerAtYardPosition.getPod() == null || existedContainerAtYardPosition.getWeight() == null)) {

				YardProfileContainer presentYardContainer = blockCell.getCurrentYardContainer(tierNum);
				presentYardContainer.setContainer(yardContainer.getContainer());
				presentYardContainer.setYardPosition(yardContainer.getYardPosition());
				presentYardContainer.setIs40FtCntrStkNo(is40FtStk);
				presentYardContainer.setNext40ftCntrStkNo(nextStackValue);
				presentYardContainer.setMoveType(moveType);
			} else if (!existedContainerAtYardPosition.getContainerID().equalsIgnoreCase(
					newContainerForYardPosition.getContainerID())) {

				/*
				 * logger.logMsg(LOG_LEVEL.INFO, yardContainer.getYardPosition(), " New Container:" +
				 * newContainerForYardPosition.getContainerID() +
				 * " Came To Current YardPoistion , Previous Container Also Available In Same Location:" +
				 * existedContainerAtYardPosition.getContainerID() + " Adding New Container");
				 */

				YardProfileContainer presentYardContainer = blockCell.getCurrentYardContainer(tierNum);
				presentYardContainer.setContainer(yardContainer.getContainer());
				presentYardContainer.setYardPosition(yardContainer.getYardPosition());
				presentYardContainer.setIs40FtCntrStkNo(is40FtStk);
				presentYardContainer.setNext40ftCntrStkNo(nextStackValue);
				presentYardContainer.setMoveType(moveType);
			}
			addYardContainerToCentralCache(yardContainer);
		} catch (Exception ex) {
			logger.logException(new StringBuffer(EXCEPTION_OCCURED).append("In updateYardCell()").append(REASON)
					.toString(), ex);
		}
	}

	/*
	 * Method is responsible for updating the BlockCellGrid . If MoveType is Load,Delivery,Yard Removing Container from
	 * that BlockCellGrid Position.
	 * 
	 * @param location
	 */
	public Container removeContainerFromBlockCell(String oldLocation, String currentContainerId) {

		logger.logMsg(LOG_LEVEL.INFO, oldLocation, "Started removeContainerFromBlockCell()");

		String[] splittedLocation = oldLocation.split("\\.");
		String blockNumber = splittedLocation[0];

		BlockProfile blockProfile = blockCache.getBlockToYardProfile(blockNumber);
		Container yardContainer = null;
		try {
			if (blockProfile != null) {

				String[] blockStackRowTierSeqs = BlockProfileUtil.getInstance().getStackRowTierSequncesFromLocation(
						blockNumber, oldLocation);

				logger.logMsg(LOG_LEVEL.INFO, oldLocation,
						" After Splitting BlockStackRowTiers Array values:" + Arrays.toString(blockStackRowTierSeqs));
				logger.logMsg(LOG_LEVEL.INFO, oldLocation,
						" Seq Numbers:::" + blockStackRowTierSeqs[1].split("\\" + ROW_SEPARATOR));

				for (String seqNos : blockStackRowTierSeqs[1].split("\\" + ROW_SEPARATOR)) {

					if (seqNos != null && seqNos != SPACE && !(seqNos.isEmpty())) {

						int stackSeqNo = Integer.parseInt(seqNos);
						int rowSeqNo = Integer.parseInt(blockStackRowTierSeqs[2]);
						int tierNo = Integer.parseInt(blockStackRowTierSeqs[3]);

						BlockCellGrid cell = blockProfile.getCellGrid(rowSeqNo - 1, stackSeqNo - 1);
						if (cell != null) {

							YardProfileContainer existedContainer = cell.getCurrentYardContainer(tierNo - 1);
							if (existedContainer != null) {
								logger.logMsg(LOG_LEVEL.INFO, oldLocation, new StringBuilder(
										" Old Location Corresponsind Container Is Setting As NUll").append("::")
										.append(existedContainer).toString());

								if (existedContainer.getContainer() != null
										&& currentContainerId.equalsIgnoreCase(existedContainer.getContainer()
												.getContainerID())) {
									yardContainer = existedContainer.getContainer();
								}
								existedContainer.setContainer(null);
							}
						}
					}
				}
			} else {
				logger.logMsg(LOG_LEVEL.INFO, blockNumber,new StringBuffer(BLOCK_STRUCTURE_NOT_CREATED)
					.append(CHECK_IN_DB).append(" Location::").append(oldLocation).toString());
			}
		} catch (ArrayIndexOutOfBoundsException aob) {
			logger.logException(oldLocation	+ new StringBuilder(BLOCK_STRUCTURE_NOT_CREATED)
				.append(" UnAble To Remove Container IN Current Loc::").append(oldLocation)
				.append(" Exception Is::").append(aob.getMessage()).toString(), aob);

		} catch (Exception e) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in removeContainerFromBlockCell-")
					.toString(), e);
		}
		return yardContainer;
	}

	/*
	 * Method is responsible for Updating the Container in BlockCellGrid. If Move Type is DSCH,Receive,Yard adding new
	 * container for BlockCellGrid.
	 * 
	 * @param location
	 * 
	 * @param yardContainer
	 */
	public void updateBlockProfileWithContainer(String location, YardProfileContainer yardContainer) {

		logger.logMsg(LOG_LEVEL.INFO, location, " Started updateBlockProfileWithContainer()");

		String[] splittedLocation = location.split("\\.");
		String blockNumber = splittedLocation[0].trim();

		logger.logMsg(LOG_LEVEL.INFO, blockNumber, " Block Number Length Is::" + blockNumber.length());
		BlockProfile blockProfile = blockCache.getBlockToYardProfile(blockNumber);

		if (blockProfile != null) {

			Map<String, String> rowDataMap = blockCache.getBlockRelatedRowData(blockNumber);
			Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockNumber);

			if (rowDataMap != null && stackDataMap != null) {
				prepareBlockCellWithContainer(blockNumber, yardContainer, rowDataMap, stackDataMap, blockProfile,
						location);
			} else {
				logger.logMsg(LOG_LEVEL.INFO, blockNumber, new StringBuilder(BLOCK_STRUCTURE_NOT_CREATED).append(
								" Unable To Update Container In BlockProfile").toString());
			}
		} else {
			logger.logMsg(LOG_LEVEL.INFO, blockNumber, new StringBuilder(BLOCK_STRUCTURE_NOT_CREATED)
							.append(" Unable To Update Container In BlockProfile").toString());
		}
	}

	/*
	 * Method is responsible for adding yard container to central cache . First checking in cache whether available or
	 * notIf available checking POD,Weight because While filling the BLock Profile we don't have these informations.For
	 * POD,WT we are doing separate request to PROMIS at that time to update the central cache with POD,WT added extra
	 * condition.
	 * 
	 * @param yardContainer
	 */
	public void addYardContainerToCentralCache(YardProfileContainer yardContainer) {

		Container containerFromCache = RDTCacheManager.getInstance().getContainerDetails(
				yardContainer.getContainer().getContainerID(), yardContainer.getMoveType());

		if (containerFromCache == null
				|| (containerFromCache.getPod() == null || containerFromCache.getWeight() == null
						|| containerFromCache.getPod().isEmpty() || !containerFromCache.getWeight().isEmpty())) {
			Container container = yardContainer.getContainer();
			if (container != null && container.getIsoCode() != null && !container.getIsoCode().isEmpty()
					&& container.getPod() != null && !container.getPod().isEmpty() && container.getWeight() != null
					&& !container.getWeight().isEmpty()) {
				RDTCacheManager.getInstance().addContainer(yardContainer.getContainer(), yardContainer.getMoveType());
			}
		}
	}

	/*
	 * Method is responsible for giving row seq number.
	 */
	public String getRowSeqNumber(String blockNumber, String rowNum) {

		String rowSeqNumber = null;
		Map<String, String> rowDataMap = blockCache.getBlockRelatedRowData(blockNumber);
		rowSeqNumber = rowDataMap != null ? getKeyFromValue(rowDataMap, rowNum) : rowSeqNumber;
		return rowSeqNumber;
	}

	public int getRowMaxWorkingStkHeight(String blockNumber, String rowNumber) {

		Integer rowMaximumStkHeight = 0;
		Map<String, Integer> rowWiseMaxStkHtMap = blockCache.getBlockRelatedRowMaxStkHt(blockNumber);
		rowMaximumStkHeight = rowWiseMaxStkHtMap != null ? rowWiseMaxStkHtMap.get(getRowSeqNumber(blockNumber,
				rowNumber)) : rowMaximumStkHeight;

		return rowMaximumStkHeight;
	}

	public String getStackSeqNumber(String blockNumber, String stackNumber) {

		String stackSeqNumber = null;
		Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockNumber);
		Map<String, String> blockToStk40ftValues = blockCache.getBlockTo40ftStkValues(blockNumber);

		if (null != stackDataMap) {
			stackSeqNumber = ((Integer.parseInt(stackNumber)) & 1) == 0 ? blockToStk40ftValues.get(stackNumber)
					: getKeyFromValue(stackDataMap, stackNumber);
			return stackSeqNumber;

		} else {
			return stackSeqNumber;
		}
	}

	/*
	 * Method is responsible for Getting previous or next stack numbers based on the Navigation Move type. P means need
	 * to get previous stack numbers , N means need to get next stack numbers. Empty means it is JobList time stack view
	 * request.
	 */
	public String getNextOrPreviousStackNumber(StackViewRequestEvent stackReqEvent, String requestedStackSeq) {
		logger.logMsg(LOG_LEVEL.INFO, requestedStackSeq, " Started getNextOrPreviousStackNumber()");

		String nextOrPreviousStackSeqNumber = null;
		String blockNumber = stackReqEvent.getBlockNumber();
		String navigationType = stackReqEvent.getNavigationType();

		try {
			Map<String, String> blockStackData = blockCache.getBlockRelatedStockData(blockNumber);

			int requestedStackSeqNumber = Integer.parseInt(requestedStackSeq);

			if ("P".equalsIgnoreCase(navigationType)) {
				nextOrPreviousStackSeqNumber = String.valueOf(requestedStackSeqNumber - 1);
			} else if ("N".equalsIgnoreCase(navigationType)) {
				nextOrPreviousStackSeqNumber = String.valueOf(requestedStackSeqNumber + 1);
			}

			nextOrPreviousStackSeqNumber = (blockStackData.get(nextOrPreviousStackSeqNumber) != null ? nextOrPreviousStackSeqNumber
					: null);

			logger.logMsg(LOG_LEVEL.INFO, requestedStackSeq, " Next/Previous Stack Seq Numeber Is:"
					+ nextOrPreviousStackSeqNumber);

			return nextOrPreviousStackSeqNumber;

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" getNextOrPreviousStackNumber").toString(), ex);
			return nextOrPreviousStackSeqNumber;
		}
	}

	/**
	 * Method is responsible for validating the current yard location with respect to the defined structure in database.
	 * Checking in Cache , If not requesting to database for position validation.
	 * 
	 * @param position
	 * @return YardValidationStatus status , If it returns NO_ERROR means requested position is valid one else not
	 *         valid.
	 */
	public YardValidationStatus doYardLocationValidation(String position) {

		logger.logMsg(LOG_LEVEL.INFO, "", " Started doYardLocationValidation With Position::" + position);

		final String[] blkRowStkTierNumbers = position.split("\\.");
		if (blkRowStkTierNumbers.length < 4) {
			return YardValidationStatus.INVALID_LOCATION;
		}

		final String blockNumber = blkRowStkTierNumbers[0];
		final String stackNumber = blkRowStkTierNumbers[1];
		final String rowNumber = blkRowStkTierNumbers[2];
		final int tierNumber = Integer.parseInt(blkRowStkTierNumbers[3]);

		logger.logMsg(LOG_LEVEL.INFO, position, " BlockNumber:" + blockNumber + " StackNumber:" + stackNumber
				+ "RowNumber::" + rowNumber + " Tier Number::" + tierNumber);

		if (tierNumber <= 0) {
			return YardValidationStatus.TIER_NUMBER_INVALID;
		}
		BlockProfile blockProfile = blockCache.getBlockToYardProfile(blockNumber);

		if (blockProfile == null) {
			logger.logMsg(LOG_LEVEL.DEBUG, blockNumber, " Current Block Number Not Available in Cache,Requesting To DB");
			
			int maximumWorkingStkHt = BlockViewDao.getBlockMaxWrnkgStkHt(blockNumber, rowNumber, stackNumber);
			if (maximumWorkingStkHt == 0) {
				return YardValidationStatus.BLOCK_NUMBER_INVALID;
			}

			return tierNumber <= maximumWorkingStkHt ? YardValidationStatus.NO_ERROR
					: YardValidationStatus.TIER_NUMBER_INVALID;
		} else {

			String stackSeqNumber = getStackSeqNumber(blockNumber, stackNumber);
			if (stackSeqNumber != null) {
				String rowSeqNumber = getRowSeqNumber(blockNumber, rowNumber);

				if (rowSeqNumber != null) {
					int rowMaxWrkgHeight = getRowMaxWorkingStkHeight(blockNumber, rowNumber);

					return tierNumber > rowMaxWrkgHeight ? YardValidationStatus.MAX_WORK_TIER_LIMIT_EXCEEDED
							: YardValidationStatus.NO_ERROR;
				} else {
					return YardValidationStatus.ROW_NAME_INVALID;
				}
			} else {
				return YardValidationStatus.STACK_NUMBER_INVALID;
			}
		}
	}

	public enum YardValidationStatus {
		NO_ERROR, BLOCK_NUMBER_INVALID, STACK_NUMBER_INVALID, 
		ROW_NAME_INVALID, MAX_WORK_TIER_LIMIT_EXCEEDED, 
		TIER_NUMBER_INVALID, INVALID_LOCATION
	}

	public String prepareYardLocationWithDotValue(String blockId, String yardLocation) {

		if (yardLocation != null && !yardLocation.isEmpty()) {
			String[] tierRowsAndStacks = blkStackRowTierSplitter(blockId, yardLocation);
			if (tierRowsAndStacks != null && tierRowsAndStacks.length > 3) {
				return new StringBuilder(tierRowsAndStacks[0]).append(DOT).append(tierRowsAndStacks[1]).append(DOT)
						.append(tierRowsAndStacks[2]).append(DOT).append(tierRowsAndStacks[3]).toString();
			}
		}
		return null;
	}

	public static void sendBlockViewRequestToESB(Collection<String> availableBlocksList) {

		final String terminalId = DeviceCommParameters.getInstance().getCommParameter(
				RDTProcessingServerConstants.TERMINAL_KEY);

		for (String blockId : availableBlocksList) {
			RDTYardProfileCacheManager.getInstance().setBlockToYardProfile(blockId, null);

			BlockViewRequestEvent blockViewReqEvnt = new BlockViewRequestEvent();
			blockViewReqEvnt.setBlockNumber(blockId);
			blockViewReqEvnt.setTerminalID(terminalId);
			blockViewReqEvnt.setEventID(UUID.randomUUID().toString());
			blockViewReqEvnt.setPollingTimeReq(false);
			ESBQueueManager.getInstance().postMessage(blockViewReqEvnt, OPERATOR.CHE_COMMON, terminalId);
		}
	}

	public String prepareProperYardFormat(String stowagePosition, String logId) {

		if (stowagePosition == null || stowagePosition.isEmpty()) {
			return null;
		}

		stowagePosition = stowagePosition.replaceAll("[\\s.]", "");
		String[] arr = stowagePosition.split("[a-zA-Z]");

		if (arr.length == 3) {
			String row = null;
			String block = arr[0];
			int count = 0;

			for (int i = 0; i < stowagePosition.length(); i++) {
				if (Character.isLetter(stowagePosition.charAt(i))) {

					if (count == 0) {
						block = block.concat(String.valueOf(stowagePosition.charAt(i)));
					} else {
						row = String.valueOf(stowagePosition.charAt(i));
					}
					count++;
				}
			}

			String stackNumber = arr[1];
			if (stackNumber.length() > 2) {
				String firstNumber = stackNumber.substring(0, 1);

				if (firstNumber.equals("0")) {
					stackNumber = stackNumber.substring(1, stackNumber.length());
				}
			}
			return new StringBuilder(block).append(".").append(stackNumber).append(".").append(row).append(".")
					.append(arr[2]).toString();

		} else {
			logger.logMsg(LOG_LEVEL.WARN, logId,
					" Un Handled Format Of Yard Location...Needs to Handle This Format Yard Location::"
							+ stowagePosition);
			return null;
		}
	}
}
