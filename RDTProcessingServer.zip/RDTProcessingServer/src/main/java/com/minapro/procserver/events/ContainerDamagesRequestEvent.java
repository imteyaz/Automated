package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject requesting for the recorded damages for a particular container
 * 
 * @author Rosemary George
 *
 */
public class ContainerDamagesRequestEvent extends Event implements Serializable{
    
    private static final long serialVersionUID = 7031913983111766113L;
    
    /**
     * Container for which the damage records are requested
     */
    private String containerId;
    
    private String moveType;

    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    @Override
    public String toString() {
        return "ContainerDamagesRequestEvent [containerId=" + containerId + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }    
}
