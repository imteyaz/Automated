package com.minapro.procserver.actors.shf;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_LANE_VIEW_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.shf.QCLanesRequestEvent;
import com.minapro.procserver.events.shf.QcLanesChangeRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for Performing All Operations related to QC Lanes such as view/edit QC related Lanes and edit.
 * 
 * @author UMAMAHESH M
 *
 */
public class QcLanesProcessingActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QcLanesProcessingActor.class);

    private static final String PIPE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass()).append(ON_RECEIVE).toString());
        if (message instanceof QCLanesRequestEvent) {
            prepareQcLanesResponseMessage((QCLanesRequestEvent) message);
        } else if (message instanceof QcLanesChangeRequestEvent) {
            handleQcLanesChangeRequest((QcLanesChangeRequestEvent) message);
        } else {
            unhandled(message);
        }
    }

    /**
     * Method is responsible for Changing the QC related qcLanes. qcToLaneMapping Cache holds the QC and Its related
     * qcLanes with Direction. Calling Cache method with qcId.
     * 
     * @param QcLanesChangeRequestEvent
     *            object. Sample Input message
     *            like:"2802~783511536~user1~2~Friday 18-May-2015 09:55:18~QC1^LANE1^LR|QC2^LANE2^RL";
     * 
     */

    private void handleQcLanesChangeRequest(QcLanesChangeRequestEvent qcLanesChangeReq) {

        logger.logMsg(
                LOG_LEVEL.INFO,
                "",
                new StringBuilder(ENTRY).append(" handleQcLanesChangeRequest() ").append(INPUT)
                        .append(qcLanesChangeReq.toString()).toString());

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

        try {
            String[] qcLaneStations = qcLanesChangeReq.getQcChangedLaneStations().split("\\" + PIPE_SEPARATOR);
            for (String qcLane : qcLaneStations) {
                String[] qcAndQcLane = qcLane.split("\\" + ITEM_SEPERATOR);
                String qcId = qcAndQcLane[0];
                String qcWithqcLane = qcAndQcLane[1];
                String direction = qcAndQcLane[2];
                String qcLaneWithDirection = qcWithqcLane.concat(ITEM_SEPERATOR).concat(direction);
                // calling QC qcToLaneMapping cache in Cache manager
                rdtCacheMgr.saveAllocatedQCLane(qcId, qcLaneWithDirection);
            }
        } catch (ArrayIndexOutOfBoundsException aie) {
            logger.logException("Error Occured During Message Spliting In handleQcLanesChangeRequest()", aie);
        } catch (Exception ex) {

            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in handleQcLanesChangeRequest() ")
                    .append(REASON).toString(), ex);
        }
    }

    /**
     * <p> Method is responsible for Preparing qC related qcLane stations+ individual qcLanes and sending response
     * message to COMM server </p> <p> checking QC is assigned to any qcLane or not. checking this condition in
     * qcToLaneMapping cache,If qcLane is available it maps like QC1^LANE1^LR else QC1^. LANE1^LR Means QClANE With
     * Direction(LR or RL). </p> <p> Checking whether any qcLane allocated to QC or not. if any qcLane is allocated to
     * QC,removing that qcLane from the qcLanes Set which is getting from the qcLanes cache as KeySet. First time
     * request response message like.None of the QC is associated with qcLane station.
     * RESP~2501~QC1^|QC2^|QC3^LANE1|LANE2|LANE3|LANE4~user1~2 Second request onwards constructed message like
     * RESP~2501~QC1^LANE1^RL|QC2^LANE2^LR|QC3^~LANE1|LANE2|LANE3|LANE4~user1~2
     * 
     */

    private void prepareQcLanesResponseMessage(QCLanesRequestEvent qcLanesChangeReq) {
        logger.logMsg(LOG_LEVEL.INFO, "",
                new StringBuilder(ENTRY).append(getClass().getName()).append(" prepareQcLanesResponseMessage() ")
                        .append(qcLanesChangeReq.toString()).toString());

        String currentUserId = qcLanesChangeReq.getUserID();
        String terminalId = qcLanesChangeReq.getTerminalID();
        String eventType = QC_LANE_VIEW_RESPONSE;
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

        StringBuilder qcLanesResponseMessage = new StringBuilder(RESP).append( VALUE_SEPARATOR).append( eventTypeID).append( VALUE_SEPARATOR);

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        ConcurrentSkipListSet<String> qcLanes = null;
        try {
            // Calling Master Cache QcLanes for getting list of available qcLanes.QcLanes LANE1|LANE2|LANE3 like =
            Set<String> listOfQcLanes = rdtCacheMgr.getQCLanes();
            if (listOfQcLanes.isEmpty() || listOfQcLanes == null) {
                logger.logMsg(LOG_LEVEL.INFO, "", "List Of QC's Are Empty");
            } else {
                qcLanes = new ConcurrentSkipListSet<String>(listOfQcLanes);
            }

            ConfirmAllocationEvent event = (ConfirmAllocationEvent) rdtCacheMgr.getAllocationDetails(currentUserId);
            String qcs = "";
            if (event == null) {
                logger.logMsg(LOG_LEVEL.DEBUG, currentUserId,
                        "Unable TO Retrieve ListOfQC's From ConfirmAllocationEvent.");
            } else {
                qcs = event.getLocation();
            }

            String[] listOfQcs = qcs.split("\\" + PIPE_SEPARATOR);
            // Preparing QC related qcLanes.
            for (String qcId : listOfQcs) {
                // Sample qcLane message is LANE1^LR or LANE1^RL (qcLane with Direction)
                String qcLane = rdtCacheMgr.getAllocatedQCLane(qcId);

                if (qcLane != null) {
                    qcLanesResponseMessage.append(qcId).append(ITEM_SEPERATOR).append(qcLane);
                    // removing qcLane from list of qcLanes,if it is already allocated to QC.
                    String currentQcLane = qcLane.split("\\" + ITEM_SEPERATOR)[0];
                    if (qcLanes.contains(currentQcLane)) {
                        qcLanes.remove(currentQcLane);
                    }
                } else {
                    qcLanesResponseMessage.append(qcId).append(ITEM_SEPERATOR);
                }
                qcLanesResponseMessage.append(PIPE_SEPARATOR);
            }

            qcLanesResponseMessage.delete(qcLanesResponseMessage.length() - 1, qcLanesResponseMessage.length()).append(
                    VALUE_SEPARATOR);

            // adding un allocated qcLanes to response message
            for (String qcLane : qcLanes) {
                qcLanesResponseMessage.append(qcLane).append(PIPE_SEPARATOR);
            }

            qcLanesResponseMessage.delete(qcLanesResponseMessage.length() - 1, qcLanesResponseMessage.length());
            qcLanesResponseMessage.append(VALUE_SEPARATOR).append(currentUserId).append(VALUE_SEPARATOR)
                    .append(terminalId);

            logger.logMsg(
                    LOG_LEVEL.INFO,
                    currentUserId,
                    new StringBuilder(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
                            .append(qcLanesResponseMessage.toString()).toString());

            CommunicationServerQueueManager.getInstance().postMessage(qcLanesResponseMessage.toString(),
                    OPERATOR.FOREMAN, terminalId);
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in prepareQcLanesResponseMessage() ")
                    .append(REASON).toString(), ex);
        }
    }
}
