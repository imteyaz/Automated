package com.minapro.procserver.actors.obf;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CHECKLIST;
import static com.minapro.procserver.util.RDTProcessingServerConstants.INSPECTION_CHECKLIST;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.obf.VesselForemanCheckListEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class VesselForemanCheckListActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselForemanCheckListActor.class);
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof VesselForemanCheckListEvent) {
            VesselForemanCheckListEvent vesselForemanCheckListEvent = (VesselForemanCheckListEvent) message;
            postCheckListForVesselForeman(vesselForemanCheckListEvent);

        } else {
            unhandled(message);
        }
    }

    private void postCheckListForVesselForeman(VesselForemanCheckListEvent vesselForemanCheckListEvent) {
        try {

            // CheckList indication qc == q, vessel == v , Need to move to Consts
            if ("q".equals(vesselForemanCheckListEvent.getCheckListType())) {
                // for QC checkListType Indication
                String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(
                        vesselForemanCheckListEvent.getEquipmentID());
                // Assigned QC user
                User user = RDTCacheManager.getInstance().getUserDetails(userId);
                List<Object[]> checkList = (List<Object[]>) HibernateUtil.getInspectionRecordByUserIdAndCurDate(userId);
                if (checkList == null) {
                    EventUtil.getInstance().sendInspectionCheckList(user, vesselForemanCheckListEvent,
                            INSPECTION_CHECKLIST);
                } else {
                    sendAssociatedInspectionCheckList(checkList, vesselForemanCheckListEvent);
                }

            } else if ("v".equals(vesselForemanCheckListEvent.getCheckListType())) {
                // // for Vessel checkListType Indication
                // TODO
            } else {
                // remaining
            }
        } catch (Exception ex) {
            logger.logException("Caught Exception while preparing Response of Vessel Foreman CheckList : ", ex);
        }
    }

    /**
     * <p>Retrieves the check list associated with the user role and Assigned to user and sends the check lists to the
     * communication layer.</p>
     * 
     * @param user
     *            - the user to whom the checklist need to be sent
     * @param event
     *            - the allocation Details received from the user
     */
    public void sendAssociatedInspectionCheckList(List<Object[]> checkList,
            VesselForemanCheckListEvent vesselForemanCheckListEvent) {
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(
                vesselForemanCheckListEvent.getUserID());

        logger.logMsg(LOG_LEVEL.INFO, vesselForemanCheckListEvent.getUserID(),
                "Sending the pre-operational check list for the role -" + operatorRole);

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(INSPECTION_CHECKLIST);

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(INSPECTION_CHECKLIST);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPARATOR ).append(eventTypeID);

        String msgField;
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            msgField = msgFields.get(i);

            if (msgField.equalsIgnoreCase(CHECKLIST)) {
                if (checkList != null) {
                    /*
                     * Sending the checklist items in the format
                     * checklistItem-icon-category-mandatory^p|checklistItem-icon-category-mandatory
                     */
                    for (Object[] checkListItem : checkList) {
                        for (int j = 0; j < checkListItem.length; j++) {
                            responseToDevice.append(checkListItem[j]).append(ITEM_SEPARATOR);
                        }
                    }
                }
            } else {
                EventUtil.getInstance().getEventParameter(vesselForemanCheckListEvent, msgFields.get(i),
                        responseToDevice);
            }
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                vesselForemanCheckListEvent.getTerminalID());
    }

}
