package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;

import java.util.Date;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.che.NewLocationResponseEvent;
import com.minapro.procserver.events.common.AlertEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * This actor class is responsible for sending the job list update notification to UI based on status.If status is
 * success send the update notification otherwise send the alert message to the user.
 * 
 * @author 1201257
 * 
 */
public class NewLocationResponseActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(NewLocationResponseActor.class);

    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass().getSimpleName())
                .append(ON_RECEIVE).toString());

        if (message instanceof NewLocationResponseEvent) {

            NewLocationResponseEvent newLocationResponseEvent = (NewLocationResponseEvent) message;
            if ("success".equals(newLocationResponseEvent.isStatus())) {
                sendUpdateJobListNotification(newLocationResponseEvent);
            } else {
                sendAlertMessageToUser(newLocationResponseEvent);
            }
        }
    }

    /**
     * Construct the new location response notification to the device
     * 
     * @param NewLocationResponseEvent
     */
    private void sendUpdateJobListNotification(NewLocationResponseEvent newLocationResponseEvent) {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendUpdateJobListNotification() ")
                .toString());
        JobListRequestEvent requestEvent = new JobListRequestEvent();
        requestEvent.setEquipmentID(newLocationResponseEvent.getEquipmentID());
        requestEvent.setUserID(newLocationResponseEvent.getUserID());
        requestEvent.setTerminalID(newLocationResponseEvent.getTerminalID());
        requestEvent.setEventID(UUID.randomUUID().toString());
        // since the UI expects only notifications
        requestEvent.setScheduled(false);

        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(newLocationResponseEvent.getUserID());
        requestEvent.setLocation(allocationDetails.getLocation());

        ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.CHE, newLocationResponseEvent.getTerminalID());
    }

    /**
     * Construct the new location response failure alert to the device
     * 
     * @param NewLocationResponseEvent
     */
    private void sendAlertMessageToUser(NewLocationResponseEvent newLocationResponseEvent) {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendAlertMessageToUser() ").toString());
        AlertEvent event = new AlertEvent();
        event.setEventID(newLocationResponseEvent.getEventID());
        event.setUserID(newLocationResponseEvent.getUserID());
        event.setEquipmentID(newLocationResponseEvent.getEquipmentID());
        event.setTerminalID(newLocationResponseEvent.getTerminalID());
        event.setTimeStamp(new Date().toString());
        event.setReason("New Location request failed at SPARCS");
        event.setBeepRequired(false);
        
        EventUtil.getInstance().sendAlertMessageToUser(event);
    }

}
