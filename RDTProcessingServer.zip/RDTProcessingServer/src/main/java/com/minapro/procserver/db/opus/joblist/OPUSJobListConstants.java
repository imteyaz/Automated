package com.minapro.procserver.db.opus.joblist;

public final class OPUSJobListConstants {

	
	public static final String OPUS 		= "OPUS";
	
	public static final String TWIN 		= "TWIN";
	
	public static final String TANDEM 		= "TANDEM";
	//public static final String
	public static final String JOB_LIST 	= "JobList";
	
	public static final String RETRIEVED 	= "Retrieved";
	
	public static final String CURRENT 		= "Current";
	
	public static final String REFRESH 		= "Refresh";

	public static final String EXISTED      = "Existed";
	
	public static final String TWIN_TANDEM  = TWIN.concat("/").concat(TANDEM);
	
	/*public static final String 
	
	public static final String*/
	
	private OPUSJobListConstants() {
		
	}
}
