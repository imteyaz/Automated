package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.common.RefreshVesselEvent.REFRESH_TYPE;

/**
 * ValueObject used by server to get the bay wise container details from the ESB.
 * 
 * @author Rosemary George
 *
 */
public class BaywiseContainerDetailsRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = 4067103732187788404L;
    /**
     * Indicates the vessel code
     */
    private String vesselCode;

    /**
     * Indicates the current rotation ID
     */
    private String rotationID;

    /**
     * Indicates the bayNo for which the container details are requested
     */
    private String bayNo;

    /**
     * Indicates whether the bay is on deck or under deck. Set to D if it is deck, else set to U
     */
    private String underDeckIndication;

    /**
     * Indicates the refresh type, default will be ALL
     */
    private REFRESH_TYPE refreshType;

    /**
     * Indicates the starting tier number for the deck
     */
    private String deckStartTierNo;

    public String getDeckStartTierNo() {
        return deckStartTierNo;
    }

    public void setDeckStartTierNo(String deckStartTierNo) {
        this.deckStartTierNo = deckStartTierNo;
    }

    public REFRESH_TYPE getRefreshType() {
        return refreshType;
    }

    public void setRefreshType(REFRESH_TYPE refreshType) {
        this.refreshType = refreshType;
    }

    public String getUnderDeckIndication() {
        return underDeckIndication;
    }

    public void setUnderDeckIndication(String underDeckIndication) {
        this.underDeckIndication = underDeckIndication;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getBayNo() {
        return bayNo;
    }

    public void setBayNo(String bayNo) {
        this.bayNo = bayNo;
    }

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    @Override
    public String toString() {
        return "BaywiseContainerDetailsRequestEvent [vesselCode=" + vesselCode + ", rotationID=" + rotationID
                + ", bayNo=" + bayNo + ", underDeckIndication=" + underDeckIndication + ", refreshType=" + refreshType
                + ", deckStartTierNo=" + deckStartTierNo + "]";
    }
}
