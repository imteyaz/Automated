package com.minapro.procserver.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;

import org.infinispan.Cache;

import com.minapro.procserver.cache.RDTCacheContainer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Singleton class holding all the configurable parameters related to devices.<p>
 * 
 * <p>Loads the configurable items from the DeviceCommunicationParameters.properties.</p>
 * 
 * @author Rosemary George
 *
 */
public class DeviceCommParameters {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DeviceCommParameters.class);

	private static DeviceCommParameters instance;

	/**
	 * Map containing the communication parameters read from the properties file.
	 */
	private Cache<String, String> commParams;

	private DeviceCommParameters() {
		commParams = RDTCacheContainer.getCache("DeviceCommParameterCache");
		loadProperties();
	}

	/**
	 * Reads the Communication property file and places the entries into the commParams map.
	 */
	private void loadProperties() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(RDTProcessingServerConstants.DEVIVE_COMM_PARAMETER_FILE_PATH));
			for (Entry<Object, Object> element : prop.entrySet()) {
				commParams.put(element.getKey().toString(), element.getValue().toString());

				if ("NODE_CRANES".equalsIgnoreCase(element.getKey().toString())) {
					logger.logMsg(LOG_LEVEL.INFO, element.getKey().toString(), "List of Cranes configured are : "
							+ element.getValue().toString());					
					RDTCacheManager.getInstance().addListOfCranesToCache(element.getKey().toString(), element.getValue().toString());
				}
			}

		} catch (IOException ex) {
			logger.logException("Caught Exception while loading the properties : ", ex);
		}
	}

	public static DeviceCommParameters getInstance() {
		if (instance == null) {
			synchronized (DeviceCommParameters.class) {
				if (instance == null) {
					instance = new DeviceCommParameters();
				}
			}
		}

		return instance;
	}

	/**
	 * Returns the value of the specified KEY from the DeviceCommunicationParameters.properties file.
	 * 
	 * @param code
	 *            - Properties KEY
	 * @return - Value of the specified KEY
	 */
	public String getCommParameter(String code) {
		return commParams.get(code);
	}

}
