package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ITVGoToEvent extends Event implements Serializable {

    private static final long serialVersionUID = -6949502123674052265L;

    String locationID;

	public String getLocationID() {
		return locationID;
	}

	public void setLocationID(String locationID) {
		this.locationID = locationID;
	}
    
    
}
