package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_WAITING_DEFAULT_COLOR_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_WAITING_HIGH_BLINK_PARAM;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_WAITING_NORMAL_BLINK_PARAM;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_WAITING_SLOW_BLINK_PARAM;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_WAITING_TIME_PARAMS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.ITVWaitingTimeEntity;
import com.minapro.procserver.db.Unit;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.che.ReeferConnectionRequestEvent;
import com.minapro.procserver.events.che.ReeferWithStatusEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersResponseEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class CHEJobListUtil {

	private static final CHEJobListUtil INSTANCE = new CHEJobListUtil();

	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

	private MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobListUtil.class);

	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);

	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.TERMINAL_KEY);

	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

	private CHEJobListUtil() {

	}

	public static CHEJobListUtil getInstance() {
		return INSTANCE;
	}

	/**
	 * 
	 * Method takes care for processing job list sequence calculation and finding difference between cache and database
	 * jobs. Finally send response to the logged in CHE operator. If current refresh containers not found in cache or
	 * any modification between existed cache and database both the cases sending notification.Sample(NOTIF~1405~..) .
	 * Job is present in cache and not present in current refresh job list table then sending Deleted messages
	 * Notification to UI like (1602~...)
	 *
	 * @param messageType
	 *            It is either Resp or Notif or Null
	 * @param event
	 *            Event may be CHEJobListEvent or UpdateBlockContainersResponseEvent
	 * @param cheJobsFromDB
	 *            Current JobList From Database.
	 */
	public void doCHEJobListProcessing(String messageType, Event event, List<JobListContainer> cheJobsFromDB)
			throws NullPointerException {

		final String userId = event.getUserID();
		final String equipmentId = event.getEquipmentID();
		final String logId = userId.concat("-").concat(equipmentId);

		logger.logMsg(LOG_LEVEL.INFO, logId,
				new StringBuilder("Started doCHEJobListProcessing()").append(" Message Type ::").append(messageType)
						.toString());

		/*
		 * When RDT Get CHE JobList request from User or Server polling time we know the message type. In Case
		 * UpdateBlockContainersResponseEvent we won't get message type value from ESB. If message type is null means
		 * response came from ESB with UpdateRequiredContainers list. At that time needs to send response as
		 * Notification type to UI with latest container attributes details.
		 */

		String msgType = messageType != null ? messageType : NOTIF;
		
		/*
		 * According DPW Latest Decision , Sequence Number Will be considered from OPUS Only no need to Derive from ATOM
		 * application.
		 * // Calculating CHE Job Weightage Factor Value
		 * if(cheJobsFromDB!=null && !cheJobsFromDB.isEmpty()) {
		 * CHEJobListService.getInstance().calculateSeqNumber(cheJobsFromDB, equipmentId, userId); } else {
		 * logger.logMsg(LOG_LEVEL.INFO,logId,"No Jobs Retrieved From DB,No Need To Calculate Sequence"); }
		 */

		ListOrderedMap<String, JobListContainer> jobsInCache = RDTCacheManager.getInstance().getJobList(userId,
				equipmentId);

		// jobsInCache - jobsFromDB. Jobs which are not available in new refresh but present in cache.
		StringBuilder deletedJobs = jobsInCache != null ? identifyDeletedJobs(userId, equipmentId, cheJobsFromDB,
				jobsInCache) : null;

		logger.logMsg(LOG_LEVEL.INFO, logId,
				new StringBuilder(" Deleted Jobs(Jobs Not Present In Current Refresh) Are::").append(
						deletedJobs != null ? deletedJobs.toString() : null).toString());

	/*	if(event instanceof UpdateBlockContainersResponseEvent){
			RDTCacheManager.getInstance().flushJobList(event.getUserID(), event.getEquipmentID());
		}*/
		
		/*
		 * Jobs which are present in cache and jobs from db i.e..no change in the both the places.Just to maintain
		 * proper sequencing order in cache adding common jobs to list
		 */

		List<JobListContainer> commonJobs = new LinkedList<JobListContainer>();

		/*
		 * Bug:: Currently, Job list re-fresh based on the manual / auto refresh and re-sequencing the Twin and tandem
		 * icon Change required Job must be re-fresh display twin / tandem indicator as per connection. Ie. Override the
		 * rules of sequencing logic. To Fix Above issue following method is implemented.
		 */

		/*
		 * According DPW Latest Decision , Sequence Number Will be considered from OPUS Only no need to Derive from ATOM
		 * application.
		 */
		// updateSequnceNumberForRefCntrs(cheJobsFromDB);

		/*
		 * Jobs which are not present in cache and jobs which are modified in cache with jobs from database
		 * (i.e,,checking based on few parameters like container number,from location,to Location and sequence number)
		 */

		List<JobListContainer> modifiedJobs = identifyAndSaveDeltaOfJobs(event, jobsInCache, cheJobsFromDB, commonJobs);
		
		if(event instanceof UpdateBlockContainersResponseEvent){
			modifiedJobs = (modifiedJobs==null || modifiedJobs.isEmpty()) ? new ArrayList<JobListContainer>() : modifiedJobs;
			prepareModifiedJobsFromUpdateBlockCntrsResponse((UpdateBlockContainersResponseEvent)event,modifiedJobs);
		}
	
		logger.logMsg(LOG_LEVEL.INFO, logId, "Modifed Jobs Count After Comparision are::"
				+ (modifiedJobs != null ? modifiedJobs.size() : 0));

		// Sorting Jobs based on seq number
		if ((modifiedJobs != null && !modifiedJobs.isEmpty()) || (deletedJobs != null && deletedJobs.length() > 0)) {
			JobListUtil.getInstnace().reorderJobsInCacheAsPerSequence(userId, equipmentId);
		}

		if (msgType.equals(RESP)) {
			handleJobListRequestEventFromUser(event);
		} else {
			operatorsJobListView(modifiedJobs, event, deletedJobs, msgType);
		}

		if (modifiedJobs != null) {
			EventUtil.getInstance().checkForFLDContainers(modifiedJobs, equipmentId, userId);
		}

		try {
			Thread.sleep(1000);
			CHEJobListUtil.getInstance().sendITVWaitingTimeToCHEUsers();
		} catch (InterruptedException ex) {
			logger.logException(" Exception Occured While Sleeping Thread", ex);
		}
	}	
	
	/**
	 * Verifies and identifies the jobs which are present in the cache, but not there in the jobList event. These are
	 * considered as no longer valid, and removed from the cache.
	 * 
	 * @param jobListEvent
	 * @param jobsInCache
	 */
	private StringBuilder identifyDeletedJobs(String userId, String equipmentId, List<JobListContainer> cheJobsFromDB,
			ListOrderedMap<String, JobListContainer> jobsInCache) {

		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(" Started identifyDeletedJobs()").toString());

		StringBuilder containerIds = new StringBuilder();

		Collection<JobListContainer> deletedContainers = CollectionUtils.subtract(jobsInCache.values(), cheJobsFromDB);

		if (deletedContainers != null && !deletedContainers.isEmpty()) {
			logger.logMsg(LOG_LEVEL.INFO, userId, "Identified JOBS to be deleted from CACHE- " + deletedContainers);

			for (JobListContainer container : deletedContainers) {
				// delete from the job list
				if (container != null) {
					RDTCacheManager.getInstance().deleteFromJobList(userId, container.getContainerId(), equipmentId,
							container.getMoveType());
					containerIds.append(container.getContainerId()).append(ITEM_SEPARATOR)
							.append(container.getMoveType()).append(ROW_SEPARATOR);
				}

			}
		}

		return containerIds;
	}

	/**
	 * Compares and identifies the new and modified jobs from the list of Jobs coming from ESB.
	 * 
	 * @param userId
	 * @param jobsFromESB
	 * @return ModifiedJobs
	 */
	private List<JobListContainer> identifyAndSaveDeltaOfJobs(Event event, Map<String, JobListContainer> jobsFromCache,
			List<JobListContainer> cheJobsFromDB, List<JobListContainer> commonJobs) {

		logger.logMsg(LOG_LEVEL.INFO, "Started identifyAndSaveDeltaOfJobs()", new StringBuilder().toString());

		String userId = event.getUserID();
		String equipmentId = event.getEquipmentID();

		logger.logMsg(LOG_LEVEL.TRACE, userId, "identifyAndSaveDeltaOfJobs - jobsFrom ESB -" + cheJobsFromDB);

		logger.logMsg(LOG_LEVEL.TRACE, userId, "identifyAndSaveDeltaOfJobs - jobsFrom Cache -" + jobsFromCache);

		List<JobListContainer> modifiedJobs = new ArrayList<JobListContainer>();

		Map<String, ReeferWithStatusEvent> reeferContainerList = new HashMap<String, ReeferWithStatusEvent>();

		JobListContainer containerFromJobListCache;

		Container containerFromCentralCache;

		// String itvId;
		// iterate each job from Databse
		for (JobListContainer currentCHEJob : cheJobsFromDB) {

			containerFromJobListCache = jobsFromCache != null ? jobsFromCache.get(currentCHEJob.getContainerId()
					+ currentCHEJob.getMoveType()) : null;

			// get the container from central cache
			containerFromCentralCache = RDTCacheManager.getInstance().getContainerDetails(
					currentCHEJob.getContainerId(), currentCHEJob.getMoveType());

			// the job is not present in our job list cache for this operator
			
			if (containerFromJobListCache == null) {
				logger.logMsg(LOG_LEVEL.INFO, userId,
						new StringBuilder("Current Job Is New Job From TOS..Adding To Modified List::").append(
								currentCHEJob.getContainerId()).toString());
				modifiedJobs.add(currentCHEJob);
				RDTCacheManager.getInstance().updateJobList(userId, currentCHEJob, equipmentId, currentCHEJob.getMoveType());
			
			} else {

				boolean isModified = false;
				double existedJobSeqNumber = containerFromJobListCache.getSeqNumber();
				double newJobSeqNumber = currentCHEJob.getSeqNumber();

				// existing jobs are different.
				if (containerFromJobListCache.compareTo(currentCHEJob) > 0
						|| (containerFromJobListCache.getPosition() != null && !containerFromJobListCache.getPosition()
								.equals(currentCHEJob.getPosition()))) {
					isModified = true;
					logger.logMsg(LOG_LEVEL.DEBUG, userId,
							new StringBuilder(" Current Job Is Modified:::").append(currentCHEJob.toString())
									.append(" Older Job (Cache Job Is)::").append(containerFromJobListCache).toString());
					containerFromJobListCache.setFromLocation(currentCHEJob.getFromLocation());
					containerFromJobListCache.setToLocation(currentCHEJob.getToLocation());
					containerFromJobListCache.setTwinContainerId(currentCHEJob.getTwinContainerId());
					containerFromJobListCache.setSeqNumber(currentCHEJob.getSeqNumber());
				} else if (new Double(existedJobSeqNumber).compareTo(new Double(newJobSeqNumber)) != 0) {
					isModified = true;
					containerFromJobListCache.setSeqNumber(currentCHEJob.getSeqNumber());
				} else {
					// no change happened jobs are adding into the common list
					commonJobs.add(containerFromJobListCache);
				}

				/*
				 * Deleting current job from central cache Because To maintain weightage factor value in sequencing
				 * order in central cache.
				 */

				/*RDTCacheManager.getInstance().deleteFromJobList(userId, containerFromJobListCache.getContainerId(),
						equipmentId, containerFromJobListCache.getMoveType());*/

				if (isModified) {
					modifiedJobs.add(containerFromJobListCache);
				}
			}

			if (containerFromCentralCache != null && containerFromCentralCache.isReefer()) {
				ReeferWithStatusEvent reeferEvent = new ReeferWithStatusEvent();
				reeferEvent.setContainerId(currentCHEJob.getContainerId());
				reeferEvent.setMoveType(currentCHEJob.getMoveType());
				reeferContainerList.put(currentCHEJob.getContainerId(), reeferEvent);
			}
		}

		if (!reeferContainerList.isEmpty()) {
			sendReeferStatusRequest(reeferContainerList, event);
		} else if (reeferContainerList.isEmpty() || reeferContainerList == null) {
			logger.logMsg(LOG_LEVEL.DEBUG, userId, "Reefer List is Empty");
		}

		return modifiedJobs;
	}

	private void updateJobList(final List<JobListContainer> modifiedJobs, String userId, String equipmentId) {
		logger.logMsg(LOG_LEVEL.INFO, userId, " Started updateJobList() to update modified job in cache");

		for (JobListContainer modifiedJob : modifiedJobs) {

			RDTCacheManager.getInstance().updateJobList(userId, modifiedJob, equipmentId, modifiedJob.getMoveType());
		}
	}

	/**
	 * Method Is Responsible For Providing JobList Synchronization among the users.
	 * 
	 * @param ModifiedJobs
	 *            from identifyAndSaveDeltaOfJobs method return jobList
	 * @param JobListEvent
	 *            from ESB Queue
	 */
	public void operatorsJobListView(List<JobListContainer> modifiedJobs, Event event, StringBuilder deletedJobs,
			String messageType) {

		try {

			RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

			// send to the user form whom the job list is received
			boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(event.getUserID());

			if (inspectionStatus) {
				if (deletedJobs != null && deletedJobs.length() > 0) {
					sendDeletedNotificationToDevice(event.getUserID(), event.getTerminalID(), deletedJobs);
				}

				if (!modifiedJobs.isEmpty()) {
					JobListUtil.getInstnace().sendJobListToDevice(modifiedJobs, event, event.getUserID(), messageType,
							rdtCacheMgr.getUserLoggedInRole(event.getUserID()));
				}
			} else {
				logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
						"Adding the JobList to Cache as pre-operational inspection is not completed.");
			}

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Sending JobList Response To UI ")
					.append(REASON).toString(), ex);
		}
	}

	/**
	 * Handles the job list request initiated from the operator. In case of Foreman, the associated QC's job list is
	 * retrieved.
	 * 
	 * If no jobs are present, and empty response is sent back to the operator.
	 * 
	 * @param jobRequest
	 */
	public void handleJobListRequestEventFromUser(Event event) {

		String requestInitatedUser = event.getUserID();

		logger.logMsg(LOG_LEVEL.INFO, requestInitatedUser,
				" Started handleJobListRequestEventFromUser() To send Job List As Response To User");

		String equipmentId = event.getEquipmentID();

		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(requestInitatedUser);

		try {

			logger.logMsg(LOG_LEVEL.INFO, requestInitatedUser, " jobList has been requested for " + equipmentId);

			ListOrderedMap<String, JobListContainer> pendingJobs = RDTCacheManager.getInstance().getJobList(
					requestInitatedUser, equipmentId);
			if (pendingJobs != null && !pendingJobs.isEmpty()) {
				logger.logMsg(LOG_LEVEL.INFO, requestInitatedUser,
						"Received jobList request from device and pending jobs are " + pendingJobs.size());
				List<JobListContainer> jobs = new ArrayList<JobListContainer>(pendingJobs.values());
				JobListUtil.getInstnace().sendJobListToDevice(jobs, event, event.getUserID(), RESP, operatorRole);
			} else {
				sendEmptyResponse(event, operatorRole);
			}
		} catch (Exception e) {
			logger.logException("Caught exception while processing jobListRequestEvent -", e);
		}
	}

	/**
	 * Construct and sends an empty job list response to the user
	 * 
	 * @param event
	 * @param userId
	 * @param operatorRole
	 */
	public void sendEmptyResponse(Event event, OPERATOR operatorRole) {

		String userId = event.getUserID();

		logger.logMsg(LOG_LEVEL.INFO, userId, "No jobs to send to device");

		String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);

		StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPARATOR).append(eventTypeID);

		responseToDevice.append(VALUE_SEPARATOR).append(event.getEventID()).append(VALUE_SEPARATOR)
				.append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR).append(event.getTerminalID());

		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
				event.getTerminalID());
	}

	/**
	 * <p> Sends the Delete JOB message to the operator. The message format is below </p>
	 * 
	 * <p> 1602~eventId~timestamp~container1|container2|container3~Type~userId~TerminalId </p>
	 * 
	 * @param userID
	 * @param terminalID
	 * @param containerIds
	 */
	private void sendDeletedNotificationToDevice(String userID, String terminalID, StringBuilder containerIds) {

		String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.REMOVE_JOB);
		// build the response to the device
		StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);

		responseToDevice.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
				.append(FORMATTER.format(new Date())).append(VALUE_SEPARATOR).append(containerIds)
				.append(VALUE_SEPARATOR).append("DELETE").append(VALUE_SEPARATOR).append(userID)
				.append(VALUE_SEPARATOR).append(terminalID);

		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userID);
		CommunicationServerQueueManager.getInstance()
				.postMessage(responseToDevice.toString(), operatorRole, terminalID);

	}

	/**
	 * Construct and send Reefer connection Status request event to ESB
	 * 
	 * @param reeferContainers
	 * @param event
	 */
	private void sendReeferStatusRequest(Map<String, ReeferWithStatusEvent> reeferContainers, Event event) {

		logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
				"Sending List of Reefer Containers which requires connection Status.");

		logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "List of Reefers :" + reeferContainers);
		ReeferConnectionRequestEvent reeferStatusRequest = new ReeferConnectionRequestEvent();
		reeferStatusRequest.setReeferContainerList(reeferContainers);
		reeferStatusRequest.setEquipmentID(event.getEquipmentID());
		reeferStatusRequest.setEventID(UUID.randomUUID().toString());
		reeferStatusRequest.setUserID(event.getUserID());
		reeferStatusRequest.setTerminalID(event.getTerminalID());

		OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID());
		ESBQueueManager.getInstance().postMessage(reeferStatusRequest, operator, event.getTerminalID());
	}

	/**
	 * Adds the current job count as the planned moves value for the CHE
	 * 
	 * @param userId
	 * @param equipmentId
	 * @param jobCount
	 */
	public void addPlannedMoves(String userId, String equipmentId, int jobCount) {

		PlannedMovesEvent plannedMove = new PlannedMovesEvent();
		plannedMove.setEquipmentID(equipmentId);
		plannedMove.setPlannedMoves(jobCount);
		plannedMove.setUserID(userId);

		RDTPLCCacheManager.getInstance().addPlannedMoves(equipmentId, plannedMove);
		logger.logMsg(LOG_LEVEL.INFO, userId, "Planned Moves received from SPARCS for CHE - "
				+ RDTPLCCacheManager.getInstance().getPlannedMovesCount(equipmentId));
	}

	/*
	 * Following Method is used to find out the reference container and update sequence for both Primary and Reference
	 * containers
	 */
	public void updateSequnceNumberForRefCntrs(List<JobListContainer> cheJobs) {

		double seqTempCount = 0.01;

		try {

			for (JobListContainer mainJobList : cheJobs) {

				for (JobListContainer subJobList : cheJobs) {
					/*
					 * setManuallyOverridden is used to identify current job is modified with sequence number.By Default
					 * value is False. If job is already modified no need to proceed further steps.
					 */
					if (mainJobList.getContainerId().equalsIgnoreCase(subJobList.getContainerId())
							|| subJobList.isManuallyOverridden() || mainJobList.isManuallyOverridden()) {
						continue;
					}

					if (mainJobList.getContainerId().equalsIgnoreCase(subJobList.getTwinContainerId())
							&& subJobList.getContainerId().equalsIgnoreCase(mainJobList.getTwinContainerId())) {

						double primaryCntrSeqNo = mainJobList.getSeqNumber();
						double refCntrSeqNo = subJobList.getSeqNumber();

						if (primaryCntrSeqNo >= refCntrSeqNo) {
							seqTempCount = (primaryCntrSeqNo == refCntrSeqNo) ? seqTempCount + 0.01 : seqTempCount;
							subJobList.setSeqNumber(primaryCntrSeqNo + seqTempCount);
							seqTempCount = seqTempCount + 0.01;
							mainJobList.setSeqNumber(primaryCntrSeqNo + seqTempCount);
						} else {
							subJobList.setSeqNumber(refCntrSeqNo + seqTempCount);
							seqTempCount = seqTempCount + 0.01;
							mainJobList.setSeqNumber(refCntrSeqNo + seqTempCount);
						}

						mainJobList.setManuallyOverridden(true);
						subJobList.setManuallyOverridden(true);

						break;
					}
				}
			}
		} catch (Exception e) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Updating Twin Seq Numbers ")
					.append(REASON).toString(), e);
		}

		logger.logMsg(LOG_LEVEL.TRACE, "", new StringBuilder(
				" After Ref Cntrs Sequnce Update JobList Containers List Is..").append(cheJobs).toString());
	}

	public ApplicationParameter getCurrentITVWaitTimeCategeory(long currentWaitingTime) {

		logger.logMsg(LOG_LEVEL.INFO, "", "Waiting ITV Time In Seconds::" + currentWaitingTime);

		long definedSlowWaitTime;
		long definedNormalWaitTime;
		long definedHighWaitTime;

		ApplicationParameter currentSlowBlinkParam = RDTPLCCacheManager.getInstance().getApplicationParamter(
				ITV_WAITING_SLOW_BLINK_PARAM);

		ApplicationParameter currentNormalBlinkParam = RDTPLCCacheManager.getInstance().getApplicationParamter(
				ITV_WAITING_NORMAL_BLINK_PARAM);

		ApplicationParameter currentHighBlinkParam = RDTPLCCacheManager.getInstance().getApplicationParamter(
				ITV_WAITING_HIGH_BLINK_PARAM);

		try {

			definedSlowWaitTime = (currentSlowBlinkParam == null) ? 60 : getUnitValueInSeconds(
					currentSlowBlinkParam.getUnit(), currentSlowBlinkParam.getParameterValue());

			definedNormalWaitTime = (currentNormalBlinkParam == null) ? 120 : getUnitValueInSeconds(
					currentNormalBlinkParam.getUnit(), currentNormalBlinkParam.getParameterValue());

			definedHighWaitTime = (currentHighBlinkParam == null) ? 180 : getUnitValueInSeconds(
					currentHighBlinkParam.getUnit(), currentHighBlinkParam.getParameterValue());

			if (currentWaitingTime >= definedSlowWaitTime && currentWaitingTime <= definedNormalWaitTime) {
				return currentSlowBlinkParam == null ? createApplicationParamObj(ITV_WAITING_SLOW_BLINK_PARAM,
						definedSlowWaitTime) : currentSlowBlinkParam;

			} else if (currentWaitingTime >= definedNormalWaitTime && currentWaitingTime <= definedHighWaitTime) {
				return currentNormalBlinkParam == null ? createApplicationParamObj(ITV_WAITING_NORMAL_BLINK_PARAM,
						definedNormalWaitTime) : currentNormalBlinkParam;

			} else if (currentWaitingTime > definedHighWaitTime) {
				return currentHighBlinkParam == null ? createApplicationParamObj(ITV_WAITING_HIGH_BLINK_PARAM,
						definedHighWaitTime) : currentHighBlinkParam;
			}

		} catch (Exception ex) {
			logger.logException("Exception Occured While Retrieving ITVWaitTimeCategeory Reason-", ex);

		}
		return null;

	}

	/**
	 * Finds out the time unit associated with
	 * 
	 * @param unit
	 * @return
	 */
	public long getUnitValueInSeconds(Unit unit, String appParamValue) {

		String unitName = unit.getUnitName();

		int definedTime = Integer.parseInt(appParamValue);

		if ("minutes".equalsIgnoreCase(unitName) || unitName.startsWith("Minute")) {

			return definedTime * 60;

		} else if ("hours".equalsIgnoreCase(unitName) || unitName.startsWith("Hour")) {
			return definedTime * 60 * 60;
		} else {
			return definedTime;
		}
	}

	public long getTimeDiff(Date definedDate, TimeType timeType) {

		Date sysdate = new Date();

		long timeDiffInMillis = 0;

		if (definedDate.compareTo(sysdate) > 0) {
			timeDiffInMillis = definedDate.getTime() - sysdate.getTime();
		} else if (definedDate.compareTo(sysdate) < 0) {
			timeDiffInMillis = sysdate.getTime() - definedDate.getTime();
		} else {
			return timeDiffInMillis;
		}

		logger.logMsg(
				LOG_LEVEL.INFO,
				"",
				new StringBuilder(" Defined Data::").append(definedDate).append(" Time Diff In Millis::")
						.append(timeDiffInMillis).toString());

		switch (timeType) {

		case MILLISECONDS:
			return timeDiffInMillis;
		case SECONDS:
			return timeDiffInMillis / 1000;
		case MINIUTES:
			return timeDiffInMillis / (60 * 1000);
		case HOURS:
			return timeDiffInMillis / (60 * 60 * 1000);
		case DAYS:
			return timeDiffInMillis / (24 * 60 * 60 * 1000);
		default:
			return timeDiffInMillis;

		}

	}

	/*
	 * Method is used to retrieve the current ITV waiting comes under which range. return 0 : current waiting ITV
	 * blinking has to happen as Slow Blinking 1 : current waiting ITV blinking has to happen as Normal Blinking 2 :
	 * current waiting ITV blinking has to happen as High Blinking
	 */
	public int getITVWaitingRangeValue(ApplicationParameter param) {

		if (param.getParameterCode().equalsIgnoreCase(ITV_WAITING_SLOW_BLINK_PARAM)) {
			return 0;
		} else if (param.getParameterCode().equalsIgnoreCase(ITV_WAITING_NORMAL_BLINK_PARAM)) {
			return 1;
		} else {
			return 2;
		}
	}

	/*
	 * Method is used to retrieve the current waiting ITV range related color code which is reading from Color Code
	 * Master.
	 */
	public String getITVWaitingColorCode(ApplicationParameter param) {

		String colorCode = RDTVesselProfileCacheManager.getInstance().getColourCode(param.getParameterCode());

		return colorCode != null && !colorCode.isEmpty() ? colorCode : ITV_WAITING_DEFAULT_COLOR_CODE;
	}

	/**
	 	     * 
	 	     * 
	 	     *
	 	     */
	public void sendITVWaitParamsNotifToUI(String userId, String itvWaitingParams, String eventType) {

		logger.logMsg(LOG_LEVEL.INFO, userId, new StringBuilder(
				" Started ITV Waiting Time Parameters Notification send method.").toString());

		StringBuilder message = new StringBuilder(NOTIF);

		message.append(VALUE_SEPARATOR).append(DeviceEventTypes.getInstance().getEventType(eventType))
				.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
				.append(DATE_FORMATTER.format(new Date())).append(VALUE_SEPARATOR)
				.append(itvWaitingParams != null ? itvWaitingParams.toString() : itvWaitingParams)
				.append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR).append(TERMINAL_ID);

		CommunicationServerQueueManager.getInstance().postMessage(message.toString(),
				RDTCacheManager.getInstance().getUserLoggedInRole(userId), TERMINAL_ID);

	}

	/*
	 * Step 1 : Retrieve Waiting ITVS List From Database. Step 2 :Iterate over list and Map And Send Notification To
	 * Corresponding Users.
	 */
	public void sendITVWaitingTimeToCHEUsers() {

		logger.logMsg(LOG_LEVEL.INFO, "", " Started sendITVWaitingTimeToCHEUsers()");

		try {

			Map<String, List<ITVWaitingTimeEntity>> userWiseArrivedITVSList = ITVWaitingTimeCalculatorService
					.getUserWiseArrivedITVS();

			if (userWiseArrivedITVSList != null && !userWiseArrivedITVSList.isEmpty()) {
				checkUserAndSendNotification(userWiseArrivedITVSList);
			} else {
				logger.logMsg(LOG_LEVEL.INFO, "", " Data Is Not Available, Ignore Current Polling");
			}
		} catch (Exception ex) {
			logger.logException(" Exception Occured While Sending ITVWaitingTimeToCHEUsers Reason-", ex);
		}
	}

	public ApplicationParameter createApplicationParamObj(String paramCode, long paramValue) {
		ApplicationParameter applicationParamObj = new ApplicationParameter();
		applicationParamObj.setParameterCode(paramCode);
		applicationParamObj.setParameterValue(String.valueOf(paramValue));
		return applicationParamObj;
	}

	public enum TimeType {
		DAYS, HOURS, MINIUTES, SECONDS, MILLISECONDS;
	}

	public void checkUsersAndSendNotification(Set<String> usersAtCurLocation, ITVWaitingTimeEntity entity) {

		ApplicationParameter param = getCurrentITVWaitTimeCategeory(getTimeDiff(entity.getArrivalTime(),
				TimeType.SECONDS));

		logger.logMsg(LOG_LEVEL.INFO, entity.getprimaryKey().getITVNo(), " Current Waiting ITV Categeory::"
				+ (param != null ? param.toString() : null));

		for (String userId : usersAtCurLocation) {

			OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);

			if (role.equals(OPERATOR.CHE)) {
				if (param != null) {
					String iTVWaitTimeMessage = new StringBuilder(entity.getprimaryKey().getContainerId())
							.append(ITEM_SEPARATOR).append(getITVWaitingRangeValue(param)).append(ITEM_SEPARATOR)
							.append(getITVWaitingColorCode(param)).toString();
					sendITVWaitParamsNotifToUI(userId, iTVWaitTimeMessage, ITV_WAITING_TIME_PARAMS);
				} else {
					logger.logMsg(LOG_LEVEL.INFO,
							entity.getprimaryKey().getBlockId().concat(entity.getprimaryKey().getITVNo()),
							" Current ITV Waiting Time Is Less Than Configured Time,");
				}

			}
		}
	}

	public void checkUserAndSendNotification(Map<String, List<ITVWaitingTimeEntity>> userWiseArrivedITVSList) {

		try {
			for (Entry<String, List<ITVWaitingTimeEntity>> entry : userWiseArrivedITVSList.entrySet()) {

				if (entry == null) {
					return;
				}

				logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(
						" Current User Working Location Arrived ITV List Is::").append(entry).toString());

				if (EventUtil.getInstance().getInspectionStatus(entry.getKey())) {

					StringBuilder iTVWaitTimeMessage = new StringBuilder();

					for (ITVWaitingTimeEntity entity : entry.getValue()) {

						ApplicationParameter param = getCurrentITVWaitTimeCategeory(getTimeDiff(
								entity.getArrivalTime(), TimeType.SECONDS));

						if (param == null) {
							continue;
						}
						logger.logMsg(LOG_LEVEL.INFO, entity.getprimaryKey().getITVNo(),
								" Current Waiting ITV Categeory::" + (param != null ? param.toString() : null));

						iTVWaitTimeMessage.append(entity.getprimaryKey().getContainerId()).append(ITEM_SEPARATOR)
								.append(getITVWaitingRangeValue(param)).append(ITEM_SEPARATOR)
								.append(getITVWaitingColorCode(param)).append(ROW_SEPARATOR);
					}

					if (iTVWaitTimeMessage.length() > 0) {
						iTVWaitTimeMessage.delete(iTVWaitTimeMessage.length() - 1, iTVWaitTimeMessage.length());
						sendITVWaitParamsNotifToUI(entry.getKey(), iTVWaitTimeMessage.toString(),
								ITV_WAITING_TIME_PARAMS);
					}

				} else {
					logger.logMsg(LOG_LEVEL.INFO, entry.getKey(), " Current User Inspection Status Is False..");
					continue;
				}
			}
		} catch (Exception ex) {
			logger.logException(
					new StringBuilder(EXCEPTION_OCCURED).append(" While Sending Arrived ITVs Details To UI ")
							.append(REASON).toString(), ex);
		}
	}

	public void prepareModifiedJobsFromUpdateBlockCntrsResponse(UpdateBlockContainersResponseEvent event,
			List<JobListContainer> modifiedJobs){

		ListOrderedMap<String, JobListContainer> jobsFrmCache = RDTCacheManager.getInstance().
				getJobList(event.getUserID(),event.getEquipmentID());

		List<YardProfileContainer> updatedContainersList = event.getUpdatedContainerList();

		Collection<JobListContainer> jobListCntrsList = jobsFrmCache.values();

		logger.logMsg(LOG_LEVEL.INFO,event.getUserID()," Started prepareModifiedJobsFromUpdateBlockCntrsResponse()");
		
		for(YardProfileContainer yardCntr : updatedContainersList) {

			for(JobListContainer jobListCntr :jobListCntrsList) {

				if(yardCntr.getContainer()!=null &&
						yardCntr.getContainer().getContainerID().equalsIgnoreCase(jobListCntr.getContainerId())) {

					if(!modifiedJobs.contains(jobListCntr)){
						logger.logMsg(LOG_LEVEL.DEBUG,event.getUserID(),new StringBuilder(" Modified Job From Update Container Details Response Event::").
								append(jobListCntr).toString());
						modifiedJobs.add(jobListCntr);
						break;
					} else {
						logger.logMsg(LOG_LEVEL.INFO,event.getUserID()," Current Job Already Available In Modified Jobs,Ignore Current Job::"
								+jobListCntr);
					}

				}
			}
		}

		updatedContainersList =null;
		jobListCntrsList      =null;

	}
}
