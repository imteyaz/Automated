package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

public class QCSpreader2Subscriber implements StatementSubscriber {

    public QCSpreader2Subscriber() {
    }

    @Override
    public String getStatement() {
        // QC Container Handling EPL Statement
        return "context EachQC select event1 from pattern[every ((EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue))) "
                + "-> ((event1=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = unLockedUpTagValue)) and not EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue)) ]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().peformSpreaderChangeAction(eventMap, SPREADER2_LOCKEDUP, 2);
    }
}
