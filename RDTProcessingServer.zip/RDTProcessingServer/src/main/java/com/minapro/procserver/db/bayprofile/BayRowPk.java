package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key to identify the rows defined for each bay in a vessel
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class BayRowPk implements Serializable {
    private static final long serialVersionUID = 5455254517990236020L;

    @Column(name = "INT_VSL_NO")
    private int vesselNo;

    @Column(name = "DK_UNDK_IND")
    private String deckUnderDeck;

    @Column(name = "BAY_OFFSET")
    private int bayOffset;

    @Column(name = "INT_SECT_NO")
    private int sectionNo;

    @Column(name = "ROW_OFFSET")
    private int rowOffset;

    public int getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(int vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getDeckUnderDeck() {
        return deckUnderDeck;
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        this.deckUnderDeck = deckUnderDeck;
    }

    public int getBayOffset() {
        return bayOffset;
    }

    public void setBayOffset(int bayOffset) {
        this.bayOffset = bayOffset;
    }

    public int getSectionNo() {
        return sectionNo;
    }

    public void setSectionNo(int sectionNo) {
        this.sectionNo = sectionNo;
    }

    public int getRowOffset() {
        return rowOffset;
    }

    public void setRowOffset(int rowOffset) {
        this.rowOffset = rowOffset;
    }
}
