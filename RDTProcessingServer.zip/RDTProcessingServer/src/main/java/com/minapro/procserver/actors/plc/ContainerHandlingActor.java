package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.plc.ContainerHandleEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for Container Handling. </p>
 * 
 * @author Venkataramana.ch
 *
 */
public class ContainerHandlingActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerHandlingActor.class);

    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ITEM_SEPERATOR_KEY);

    @Override
    /**
     * Handles ContainerHandling event
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof ContainerHandleEvent) {

            ContainerHandleEvent containerHandle = (ContainerHandleEvent) message;

            logger.logMsg(LOG_LEVEL.DEBUG, containerHandle.getUserID(), "Received Container Handling event-"
                    + containerHandle);

            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(containerHandle.getUserID());

            sendContainerHandlingEvent(containerHandle, operatorRole);
        } else {
            unhandled(message);
        }

    }

    private void sendContainerHandlingEvent(ContainerHandleEvent containerHandle, OPERATOR operator) {

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(CONTAINER_HANDLING);

        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(NOTIF).append( valueSeperator).append( containerHandle.geEventType());

        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(valueSeperator);
            if ("containerIDs".equalsIgnoreCase(msgFields.get(i))) {
                List<String> containerIds = containerHandle.getContainerIDs();
                for (String container : containerIds) {
                    responseToDevice.append(container).append(ITEM_SEPARATOR).append(containerHandle.getMoveType()).append(ROW_SEPARATOR);
                }
            } else {
                EventUtil.getInstance().getEventParameter(containerHandle, msgFields.get(i), responseToDevice);
            }
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                containerHandle.getTerminalID());

    }

}
