package com.minapro.procserver.cache;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_DATA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.STACK_DATA;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.db.yardview.BlockViewDao;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.che.BlockCellGrid;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.BlockWiseContainersResponseEvent;
import com.minapro.procserver.events.che.StackViewRequestEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class BlockProfile implements Serializable {

    private static final long serialVersionUID = -8944462989017474786L;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockProfile.class);

    private static final String NO_CELL_DEFAULT_VAL = "0";

    private static final String DEFAULT_MOVETYPE = "DEFAULT";

    private static final String NULL_VALUE = "null";

    private static final String EMPTY_MOVETYPE = "EMPTY_CONTAINER";
    
    private static final char TRUE = 'T';
    
    private static final char FALSE = 'F';
    
    private static final char FULL = 'F';
    private static final char EMPTY = 'E';
    

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    private static final String COLUMN_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            COLUMN_SEPERATOR_KEY);

    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    /**
     * The actual blockId
     */
    private String blockId;

    /**
     * Actual block representation in [stack][row] manner
     */
    private BlockCellGrid[][] cellGrid;

    /**
     * No Of Levels presented for corresponding block is
     * 
     * @return
     */
    private int rowMaxwrkgStkgHt;

    private int noOfStacks;

    private int noOfRows;

    /**
     * Parameterized constructor initiating at the time of BlockView Request Event block skeleton preparation Creating
     * New YardCell grid object with No Of rows and No Of tiers.
     * 
     * @param blockId
     * @param noOfStacks
     * @param noOfRows
     * @param total
     *            no of tiers-1.
     */
    public BlockProfile(String blockId, int noOfStacks, int noOfRows) {

        this.blockId = blockId;
        this.noOfStacks = noOfStacks;
        this.noOfRows = noOfRows;
        this.cellGrid = new BlockCellGrid[noOfRows][noOfStacks];
        initializeCellGrid();
    }

    public BlockProfile() {

    }

    public int getWrkgStkgHt() {
        return rowMaxwrkgStkgHt;
    }

    public void setWrkgStkgHt(int wrkgStkgHt) {
        this.rowMaxwrkgStkgHt = wrkgStkgHt;
    }

    public BlockCellGrid[][] getCellGrid() {
        return cellGrid;
    }

    public void setCellGrid(BlockCellGrid[][] cellGrid) {
        this.cellGrid = cellGrid;
    }

    public static MinaProApplicationLogger getLogger() {
        return logger;
    }

    public static void setLogger(MinaProApplicationLogger logger) {
        BlockProfile.logger = logger;
    }

    public String getBlockId() {
        return blockId;
    }

    public void setBlockId(String blockId) {
        this.blockId = blockId;
    }

    public int getRowMaxwrkgStkgHt() {
        return rowMaxwrkgStkgHt;
    }

    public void setRowMaxwrkgStkgHt(int rowMaxwrkgStkgHt) {
        this.rowMaxwrkgStkgHt = rowMaxwrkgStkgHt;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public static String getNoCellDefaultVal() {
        return NO_CELL_DEFAULT_VAL;
    }

    public static String getDefaultMovetype() {
        return DEFAULT_MOVETYPE;
    }

    public static String getNullValue() {
        return NULL_VALUE;
    }

    public static String getItemSeperator() {
        return ITEM_SEPERATOR;
    }

    public static String getColumnSeperator() {
        return COLUMN_SEPERATOR;
    }

    public static String getRowSeperator() {
        return ROW_SEPERATOR;
    }

    public int getNoOfStacks() {
        return noOfStacks;
    }

    public void setNoOfStacks(int noOfStacks) {
        this.noOfStacks = noOfStacks;
    }

    public int getNoOfRows() {
        return noOfRows;
    }

    public void setNoOfRows(int noOfRows) {
        this.noOfRows = noOfRows;
    }

    @Override
    public String toString() {
        return "YardProfile [blockId=" + blockId + ", cellGrid=" + Arrays.toString(cellGrid) + ", noOfStacks="
                + noOfStacks + ", noOfRows=" + noOfRows + "]";
    }

    /**
     * Method is responsible for preparing block rows,stacks,tiers logical representation.Creating new object for each
     * cell.
     */
    public void initializeCellGrid() {

        int blockCellsCount = 0;

        logger.logMsg(LOG_LEVEL.INFO,blockId,new StringBuilder(" Started initializeCellGrid() Cell Grid Lenght(Row Count) Is :")
                        .append(this.cellGrid.length).append(" No Of Stacks Are : ").append(noOfStacks).toString());

        int rowIndex = 1;

        try {

        	Map<String, Integer> rowWiseMaxStkHtMap = RDTYardProfileCacheManager.getInstance()
        			.getBlockRelatedRowMaxStkHt(blockId);
        	
           
        	for (; rowIndex <= this.cellGrid.length; rowIndex++) {
        		
        		rowMaxwrkgStkgHt = rowWiseMaxStkHtMap.get(String.valueOf(rowIndex));

        		for (int stackIndex = 1; stackIndex <= (noOfStacks); stackIndex++) {

                    this.cellGrid[rowIndex - 1][stackIndex - 1] = new BlockCellGrid(rowMaxwrkgStkgHt);
                    blockCellsCount = blockCellsCount + rowMaxwrkgStkgHt;
                }
            }

        } catch (Exception ex) {
            logger.logException(" Exception Occured in initializeCellGrid() with following reason", ex);
        }
        logger.logMsg(LOG_LEVEL.INFO, blockId, " Block Cells Skeleton Final Count:::" + blockCellsCount);

    }

    /**
     * Getting the current cellData in the yard
     */

    public BlockCellGrid getCellGrid(int rowOffset, int stackOffset) {
        return this.cellGrid[rowOffset][stackOffset];
    }

    /*
     * Method is responsible for preparing row data for requested block id. Business Logic:If Block related row data
     * available in cache preparing message from cache else requesting database and getting information from database
     * and setting data to the cache. Preparing final message with item separator ^.
     * 
     * @param blockNumber (like 70A)
     * 
     * @return Sample Output Message:K^J^H^G^F^E^D^C^B^A.
     */
    public static StringBuilder prepareRowData(String blockNumber,boolean isItAdminNotification) {

        StringBuilder rowCompleteData = new StringBuilder();

        try {

            RDTYardProfileCacheManager yardCache = RDTYardProfileCacheManager.getInstance();

            Map<String, String> rowDataFromCache = yardCache.getBlockRelatedRowData(blockNumber);

            if (rowDataFromCache == null || isItAdminNotification) {

                List<Object[]> rowsDataFromDb = BlockViewDao.getStackOrRowData(blockNumber, ROW_DATA);

                if (rowsDataFromDb == null || rowsDataFromDb.isEmpty()) {
                    return null;
                } else {
                	for (Object[] row : rowsDataFromDb) {
                        rowCompleteData.append(row[1].toString()).append(ITEM_SEPERATOR);
                        yardCache.setRowsToBlock(blockNumber, row[0].toString(), row[1].toString());
                        yardCache.setMaxWorkStkForRows(blockNumber, row[0].toString(),
                                Integer.parseInt(row[2].toString()));
                    }
                }
            } else {
            	
                logger.logMsg(LOG_LEVEL.INFO, blockNumber, "Row Data Info  Available In Cache For Block Number ");

                for (Entry<String, String> entry : rowDataFromCache.entrySet()) {
                    rowCompleteData.append(entry.getValue()).append(ITEM_SEPERATOR);
                }
            }

            return rowCompleteData.delete(rowCompleteData.length() - 1, rowCompleteData.length());

        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" prepareRowData() ").append(REASON)
                    .toString(), ex);
        }
        return null;
    }

    /*
     * Method is responsible for preparing stack data for requested block id. Business Logic:If Block related stack data
     * available in cache preparing message from cache else requesting database and getting information from database
     * and setting data to the cache. Preparing final message with item separator ^.
     * 
     * @param blockNumber (like 70A) //@return Sample Output Message:01^03^05^07^09^11^13^15^17^19^21^23^25^27^29
     * ^31^33^35^37^39^41^43^45^47^49^51.
     */
    public static boolean prepareStackData(String blockNumber,boolean isItAdminNotification) {

        RDTYardProfileCacheManager yardCache = RDTYardProfileCacheManager.getInstance();

        boolean blockRelatedStackDataAvailable = false;

        try {

            Map<String, String> stacksDataFromCache = yardCache.getBlockRelatedStockData(blockNumber);

            if (stacksDataFromCache == null || stacksDataFromCache.isEmpty() || isItAdminNotification) {

                logger.logMsg(LOG_LEVEL.INFO, blockNumber, "Stack Info Not Available In Cache For Block Number "
                        + blockNumber);

                List<Object[]> stacksDataFromDb = BlockViewDao.getStackOrRowData(blockNumber, STACK_DATA);

                if (stacksDataFromDb == null || stacksDataFromDb.isEmpty()) {
                    logger.logMsg(LOG_LEVEL.INFO, blockNumber, "Stack Info Not Available In DataBase For Block Number "
                            + blockNumber);
                } else {

                    int stackDataSize = stacksDataFromDb.size();

                    logger.logMsg(LOG_LEVEL.INFO, blockNumber, " Stack Size Is::" + stackDataSize);

                    blockRelatedStackDataAvailable = stackDataSize > 0;

                    for (Object[] stack : stacksDataFromDb) {

                        String seqNo = stack[0].toString();
                        String stackValue = stack[1].toString();
                        String stackNo40Value = stack[2].toString();
                        if (Integer.parseInt(stackValue) < 10) {
                            stackValue = stackValue.length() < 2 ? "0" + stackValue : stackValue;
                        }
                        if (Integer.parseInt(stackNo40Value) < 10) {
                            stackNo40Value = stackNo40Value.length() < 2 ? "0" + stackNo40Value : stackNo40Value;
                        }
                        logger.logMsg(LOG_LEVEL.INFO, blockNumber, "Stack Seq No :" + seqNo + " Stack 20ft Value: "
                                + stackValue + " Stack 40Ft Value::" + stackNo40Value);
                        yardCache.setStacksDataToBlock(blockNumber, seqNo, stackValue);
                        yardCache.setBlockTo40ftStkValues(blockNumber, stackNo40Value, seqNo);
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" prepareStackData() ").append(REASON)
                    .toString(), ex);
        }
        return blockRelatedStackDataAvailable;
    }

    /*
     * Method is responsible for preparing CellData skeleton with Stacks and Rows and Tiers. To represent each cell
     * creating one BlockCellData object with stack and row number and tier number. For Example Rows 10,Stacks 50,Tiers
     * 3.Creating 1500 BlockCellData Objects and Storing into the Cache.
     * 
     * @param blockId
     */
    public static void prepareBlockCellDataSkeleton(String blockId) {

        logger.logMsg(LOG_LEVEL.INFO, "",
                new StringBuilder(ENTRY).append(" prepareBlockCellDataSkeleton()").append(INPUT).append(blockId)
                        .toString());

        try {

            Map<String, String> rowData   = RDTYardProfileCacheManager.getInstance().getBlockRelatedRowData(blockId);
            Map<String, String> stackData = RDTYardProfileCacheManager.getInstance().getBlockRelatedStockData(blockId);

            int noOfRows = null != rowData ? rowData.size() : 0;
            int noOfStacks = null != stackData ? stackData.size() : 0;
           
            logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(" No Of Rows::").append(noOfRows).append(" No Of Stacks ::").append(noOfStacks)
                    .append(" Before Calling Block Profile Skeleton Creation").toString());

            if (noOfRows != 0 && noOfStacks != 0) {
                BlockProfile blockProfile = new BlockProfile(blockId, noOfStacks, noOfRows);
                RDTYardProfileCacheManager.getInstance().setBlockToYardProfile(blockId, blockProfile);
            } else {
            	 logger.logMsg(LOG_LEVEL.INFO,blockId," Zero Rows/Stacks In Database,Set BlockProfile Value As Null..");
            	 RDTYardProfileCacheManager.getInstance().setBlockToYardProfile(blockId, null);
            }
        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" prepareBlockCellDataSkeleton() ").append(REASON)
                            .toString(), ex);
        }
    }

    /*
     * Method is responsible for Preparing the Block View . Simply It is a TopView of a block. Business Logic:Checking
     * from the Top of the tier whether container available in current tier,If container found in the current tier
     * preparing that cell data and adding to CellDetails object and coming out of tier loop for that stack. Filling the
     * cell color code based on the container move type which is available in Job list.If current container is not
     * present in Job list adding default color code,this color supposed to be configure at MinaPro Admin color code
     * master.
     */
    public StringBuilder prepareBlockViewWithLimitedStackNumbers(Object blockViewEvent,
            List<String> displayableStackSequenceList) {

        logger.logMsg(LOG_LEVEL.INFO, "", " Started prepareBlockViewWithLimitedStackNumbers()");

        String userId = null;
        String equipmentId = null;
        YardProfileContainer yardContainer = null;

        if (blockViewEvent instanceof BlockWiseContainersResponseEvent) {
            BlockWiseContainersResponseEvent blockResponseEvnt = (BlockWiseContainersResponseEvent) blockViewEvent;
            userId = blockResponseEvnt.getUserID();
            equipmentId = blockResponseEvnt.getEquipmentID();
        } else if (blockViewEvent instanceof BlockViewRequestEvent) {
            BlockViewRequestEvent blkReqEvnt = (BlockViewRequestEvent) blockViewEvent;
            userId = blkReqEvnt.getUserID();
            equipmentId = blkReqEvnt.getEquipmentID();
        }

        StringBuilder cellDetails = null;
        BlockCellGrid cell = null;

        Map<String, Integer> rowWiseMaxStkHtMap = RDTYardProfileCacheManager.getInstance().getBlockRelatedRowMaxStkHt(
                blockId);

        ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance()
                .getJobList(userId, equipmentId);

        logger.logMsg(LOG_LEVEL.INFO, "", " Before Final Block View Preparation No Of Rows::" + noOfRows
                + " no stacks::" + displayableStackSequenceList + " Row Wise Stack map" + rowWiseMaxStkHtMap);

        try {

            if (displayableStackSequenceList != null && !displayableStackSequenceList.isEmpty()) {

                cellDetails = new StringBuilder();

                int lastStakNumber = displayableStackSequenceList.size();

                for (int rowIndex = 0; rowIndex < noOfRows; rowIndex++) {

                    rowMaxwrkgStkgHt = rowWiseMaxStkHtMap.get(String.valueOf(rowIndex + 1));

                    for (int stackIndex = 0; stackIndex < lastStakNumber; stackIndex++) {

                        Container container = null;
                        int currentStackIndex = Integer.parseInt(displayableStackSequenceList.get(stackIndex));
                        currentStackIndex = currentStackIndex - 1;
                        cell = this.cellGrid[rowIndex][currentStackIndex];

                        if (cell != null) {
                            int tierCount = 0;

                            for (int tierIndex = rowMaxwrkgStkgHt; tierIndex > 0; tierIndex--) {
                                int cellStatus = cell.getStatus().ordinal();
                                yardContainer = cell.getCurrentYardContainer(tierIndex - 1);

                                if (yardContainer != null) {
                                    container = yardContainer.getContainer();

                                    if (container != null && cellStatus == 1 && container.getContainerID() != null) {
                                        logger.logMsg(
                                                LOG_LEVEL.TRACE,
                                                yardContainer.getYardPosition(),
                                                new StringBuilder("::Location").append(" Yard Container ::")
                                                        .append(yardContainer.toString()).append("Move Type::")
                                                        .append(yardContainer.getMoveType()).toString());

                                        cellDetails.append(cellStatus).append(ITEM_SEPERATOR)
                                                .append(container.getContainerID()).append(ITEM_SEPERATOR);
                                        String moveType;

                                        if (jobList.containsKey(container.getContainerID()
                                                + yardContainer.getMoveType())) {
                                            JobListContainer jobCntr = jobList.get(container.getContainerID()
                                                    + yardContainer.getMoveType());
                                            moveType = jobCntr.getMoveType();
                                            logger.logMsg(LOG_LEVEL.INFO, container.getContainerID(),
                                                    " Current Container Present In JobList ,"
                                                            + " Move Type Of JobList Container Is::" + moveType);
                                        } else {
                                            moveType = DEFAULT_MOVETYPE;
                                        }

                                        cellDetails.append(getColorCodeByMoveType(moveType)).append(ITEM_SEPERATOR);
                                        char is40ftContainerStack = yardContainer.getIs40FtCntrStkNo() ? TRUE : FALSE;
                                        cellDetails.append(is40ftContainerStack).append(ITEM_SEPERATOR)
                                                .append(yardContainer.getNext40ftCntrStkNo()).append(ITEM_SEPERATOR);

                                        break;

                                    } else {
                                        tierCount++;
                                    }
                                } else {
                                    tierCount++;
                                }

                                if (tierCount == rowMaxwrkgStkgHt) {
                                    if (cellStatus == 1) {
                                        cellDetails.append(cellStatus).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR);
                                        String colorCode = RDTVesselProfileCacheManager.getInstance().getColourCode(
                                                EMPTY_MOVETYPE);
                                        cellDetails.append(colorCode).append(ITEM_SEPERATOR);
                                        cellDetails.append(FALSE).append(ITEM_SEPERATOR).append(NULL_VALUE)
                                                .append(ITEM_SEPERATOR);
                                    } else {
                                        cellDetails.append(NO_CELL_DEFAULT_VAL).append(ITEM_SEPERATOR);
                                    }
                                }
                            }
                        } else {
                            cellDetails.append(NO_CELL_DEFAULT_VAL).append(ITEM_SEPERATOR);
                        }

                        if (cellDetails.length() != 0) {
                            cellDetails.delete(cellDetails.length() - 1, cellDetails.length()).append(COLUMN_SEPERATOR);
                        } else {
                            cellDetails.append(COLUMN_SEPERATOR);
                        }
                    }

                    if (cellDetails.length() != 0) {
                        cellDetails.delete(cellDetails.length() - 1, cellDetails.length()).append(ROW_SEPERATOR);
                    } else {
                        cellDetails.append(ROW_SEPERATOR);
                    }
                }

                if (cellDetails.length() != 0) {
                    return cellDetails.delete(cellDetails.length() - 1, cellDetails.length());
                }

            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId,
                        " StackNumbersToDisplayList is null/size<0 , Unable To Prepare BlockView");
                return cellDetails;
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" prepareYardView() ").append(REASON)
                    .toString(), ex);
            return null;
        }
        return cellDetails;

    }

    /**
     * Method is responsible for Preparing the One Stack Complete View From front. If current stack is 40ft containers
     * stack,need to show two stacks information else need to show single stack complete view.
     * 
     * @param currentStackPosition
     *            : Indicating whether the requesting stack is 20ft container stack or 40ft container stack. 1 means
     *            20ft , 2 means 40ft container stack. Showing plus symbol based on following conditions: if
     *            stackSeqNumber yard container is40FtCntrStkNo property is true and next40ftCntrStkNo property null
     *            means it is a 40ft stack container first 20ft stack. is40FtCntrStkNo property is false and
     *            next40ftCntrStkNo property not null(first stack number) means it is a 40ft stack second 20ft stack.
     *            is40FtCntrStkNo property is false and next40ftCntrStkNo property null means it is a direct 20ft
     *            container stack.
     */
    public static StringBuilder prepareStackView(StackViewRequestEvent stackReq, int stackSeqNumber,
            int blockMaxWorkingTier) {

        logger.logMsg(LOG_LEVEL.INFO, "", " Started prepareStackView current stack seq Number::" + stackSeqNumber);

        StringBuilder cellDetails = new StringBuilder();
        BlockCellGrid cell = null;
        String equipmentId = stackReq.getEquipmentID();
        String userId = stackReq.getUserID();
        BlockProfile blockProfile = RDTYardProfileCacheManager.getInstance().getBlockToYardProfile(
                stackReq.getBlockNumber());

        try {
            if (blockProfile != null) {

                Map<String, String> rowData = RDTYardProfileCacheManager.getInstance().getBlockRelatedRowData(
                        stackReq.getBlockNumber());
                Map<String, Integer> rowWiseMaxStkHtMap = RDTYardProfileCacheManager.getInstance()
                        .getBlockRelatedRowMaxStkHt(stackReq.getBlockNumber());

                int rowWiseMaxStkgHt = 0;
                for (int tierIndex = blockMaxWorkingTier; tierIndex >= 1; tierIndex--) {

                    for (int rowIndex = 0; rowIndex < rowData.size(); rowIndex++) {

                        Container container = null;
                        rowWiseMaxStkgHt = rowWiseMaxStkHtMap.get(String.valueOf(rowIndex + 1));
                        cell = blockProfile.cellGrid[rowIndex][stackSeqNumber];

                        if (tierIndex <= rowWiseMaxStkgHt) {

                            if (cell != null) {
                                int cellStatus = cell.getStatus().ordinal();

                                YardProfileContainer yardContainer = cell.getCurrentYardContainer(tierIndex - 1);
                                String cellLocation = "";

                                if (yardContainer != null) {
                                    cellLocation = yardContainer.getYardPosition();
                                    container = yardContainer.getContainer();

                                    /*
                                     * Checking Current container present in JobList or not . If it presents retrieving
                                     * the current container move type and based on that move type retrieving color code
                                     * from color code master . Sending same to UI.
                                     */
                                    if (container != null && cellStatus == 1) {
                                    	String moveType = getMoveTypeFromCHEJobListKeySet(container.getContainerID(),
                                                getContainersFromCHEJobList(userId, equipmentId));

                                        prepareCellDetailsWithCntrDetails(cellStatus, container, moveType,
                                                yardContainer, cellDetails);                                    	
                                    } else {
                                        prepareCellDetailsWithEmptyCntrDtls(cellStatus, cellDetails);
                                    }
                                    cellLocation = BlockProfileUtil.getInstance().prepareYardLocationWithDotValue(
                                            stackReq.getBlockNumber(), cellLocation);

                                } else if (cellStatus == 1) {
                                    prepareCellDetailsWithEmptyCntrDtls(cellStatus, cellDetails);
                                }

                                /* Adding Location To Current Cell Information.* */
                                cellDetails.append(cellLocation).append(ITEM_SEPERATOR);
                            } else {
                                logger.logMsg(LOG_LEVEL.ERROR, userId, "Cell Grid Is Empty");
                                cellDetails.append(NO_CELL_DEFAULT_VAL).append(ITEM_SEPERATOR);
                            }

                        } else {

                            cellDetails.append(NO_CELL_DEFAULT_VAL).append(ITEM_SEPERATOR);

                        }
                        if (cellDetails.length() != 0) {
                            cellDetails.delete(cellDetails.length() - 1, cellDetails.length()).append(COLUMN_SEPERATOR);
                        }
                    } // Row Iteration Loop Ended
                    if (cellDetails.length() != 0) {
                        cellDetails.delete(cellDetails.length() - 1, cellDetails.length()).append(ROW_SEPERATOR);
                    }
                } // Tier Loop Iteration ended
                return cellDetails.delete(cellDetails.length() - 1, cellDetails.length());

            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId,
                        " Block Profile Object Is Empty::::Returning Empty Value From this method");
                return null;
            }
        } catch (ArrayIndexOutOfBoundsException aoe) {
            logger.logException(" CellGrid Retrieving OutOf Structured Limit--", aoe);
            return null;
        } catch (Exception ex) {

            logger.logException(" Exception Occured While Preparing Stack View Data With Following Error", ex);
            return null;
        }
    }

    public static String getPlusSymbol(YardProfileContainer yardContainer) {
    	
        String defaultSymbol = "";
        boolean is40FtStackFirst20ftCell = yardContainer.getIs40FtCntrStkNo();
        String fortyStkFirst20ftCellNumber = yardContainer.getNext40ftCntrStkNo();
        return !is40FtStackFirst20ftCell && fortyStkFirst20ftCellNumber != null ? "+" : defaultSymbol;
        
    }

    public static String getColorCodeByMoveType(String moveType) {
        return RDTVesselProfileCacheManager.getInstance().getColourCode(moveType);
    }

    /**
     * 1^MSCU7906499^#FACB73^+^T^T^F^F^77C.83.F.6
     * 
     * 0 = Cell Status , It may be 1 or 0 1 = Container Id (MSCU7906499) 2 =Color Code of the Container (#FACB73) 3=
     * Plus Symbol (Which indicates current container is 40ft or not) , Possible Values (+ or Empty) 4=Reefer or not ,
     * Possible values T or F 5=Hazardous or not , Possible values T or F 6=OOG or not , Possible values T or F 7=Damage
     * Or not , Possible values T or F 8=Current Location of the cell(77C.83.F.6)
     */

    public static void prepareCellDetailsWithCntrDetails(final int cellStatus, Container container,
            final String moveType, final YardProfileContainer yardContainer, StringBuilder cellDetails) {

    	
    	Container containerDetails = RDTCacheManager.getInstance().getContainerDetails(container.getContainerID());
    	if(container.getIsoCode() == null && container.getCategory() == null && containerDetails != null){
    		container = containerDetails;
    	}
    	
        char isReefer = container.isReefer() ? TRUE : FALSE;
        char isHazardous = container.isHazardous() ? TRUE : FALSE;
        char isOOG = container.isOOG() ? TRUE : FALSE;
        char isDamaged = container.getIsDamaged() ? TRUE : FALSE;
        char containerType = container.getIsEmpty() ? EMPTY : FULL;
        
        cellDetails.append(cellStatus).append(ITEM_SEPERATOR).append(container.getContainerID()).append(ITEM_SEPERATOR)
                .append(getColorCodeByMoveType(moveType)).append(ITEM_SEPERATOR).append(getPlusSymbol(yardContainer))
                .append(ITEM_SEPERATOR).append(isReefer).append(ITEM_SEPERATOR).append(isHazardous)
                .append(ITEM_SEPERATOR).append(isOOG).append(ITEM_SEPERATOR).append(isDamaged).append(ITEM_SEPERATOR)
                .append(container.getIsoCode()).append(ITEM_SEPERATOR).append(containerType).append(ITEM_SEPERATOR)
                .append(container.getCategory()).append(ITEM_SEPERATOR);
    }

    public static void prepareCellDetailsWithEmptyCntrDtls(final int cellStatus, StringBuilder cellDetails) {
        cellDetails.append(cellStatus).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR)
                .append(getColorCodeByMoveType(EMPTY_MOVETYPE)).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR)
                .append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR)
                .append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR);
    }

    public static Set<String> getContainersFromCHEJobList(final String userId, final String equipmentId) {

        ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance()
                .getJobList(userId, equipmentId);

        return jobList != null && !jobList.isEmpty() ? jobList.keySet() : null;

    }

    public static String getMoveTypeFromCHEJobListKeySet(final String containerId,
            Set<String> containersAvailableInJobList) {

        String moveType = DEFAULT_MOVETYPE;

        if (containersAvailableInJobList != null) {
            for (String containerWithKey : containersAvailableInJobList) {
                if (containerWithKey.length() > 12) {
                    String containerFromJobList = containerWithKey.substring(0, 11);
                    if (containerFromJobList.equalsIgnoreCase(containerId)) {
                        moveType = containerWithKey.substring(11, containerWithKey.length());
                        logger.logMsg(LOG_LEVEL.INFO, "", " Move Type From For Loop Is::" + moveType);
                        break;
                    }
                }
            }
        }
        return moveType;
    }
}
