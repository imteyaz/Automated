package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * CtrblkYpm entity. @author CMC.UmaMahesh
 */
@Entity
@Table(name = "MP_CTRBLK_YPM")
public class CtrblkYpm implements java.io.Serializable {

    private static final long serialVersionUID = -8604040592242465574L;

    @Id
    @Column(name = "INT_CTR_BLK_NO")
    private Integer intCtrBlkNo;

    @Column(name = "INTER_ROW_DIST")
    private Double interRowDist;

    @Column(name = "INTER_STK_DIST")
    private Double interStkDist;

    @Column(name = "WRKG_STKG_HT")
    private Short wrkgStkgHt;

    @Column(name = "ABS_STKG_HT")
    private Double absStkgHt;

    @Column(name = "MAX_STKG_HT")
    private Short maxStkgHt;

    @Column(name = "ROW_ORNTN_IND")
    private String rowOrntnInd;

    @Column(name = "ROW_COUNT")
    private Short rowCount;

    @Column(name = "STK_COUNT")
    private Short stkCount;

    @Column(name = "ROW_START_NO")
    private Short rowStartNo;

    @Column(name = "STK_START_NO")
    private Short stkStartNo;

    @Column(name = "TIER_START_NO")
    private Short tierStartNo;

    @Column(name = "BLK_OPRN_TYPE")
    private String blkOprnType;

    @Column(name = "SLOT_LEN")
    private Double slotLen;

    @Column(name = "SLOT_WD")
    private Double slotWd;

    @Column(name = "STK_NUMSRS_ID")
    private String stkNumsrsId;

    @Column(name = "ROW_NUMSRS_ID")
    private String rowNumsrsId;

    @Column(name = "TIER_NUMSRS_ID")
    private String tierNumsrsId;

    @Column(name = "RMG_TRACK_NO")
    private String rmgTrackNo;

    @Column(name = "RMG_FLG")
    private String rmgFlg;

    public Integer getIntCtrBlkNo() {
        return this.intCtrBlkNo;
    }

    public void setIntCtrBlkNo(Integer intCtrBlkNo) {
        this.intCtrBlkNo = intCtrBlkNo;
    }

    public Double getInterRowDist() {
        return this.interRowDist;
    }

    public void setInterRowDist(Double interRowDist) {
        this.interRowDist = interRowDist;
    }

    public Double getInterStkDist() {
        return this.interStkDist;
    }

    public void setInterStkDist(Double interStkDist) {
        this.interStkDist = interStkDist;
    }

    public Short getWrkgStkgHt() {
        return this.wrkgStkgHt;
    }

    public void setWrkgStkgHt(Short wrkgStkgHt) {
        this.wrkgStkgHt = wrkgStkgHt;
    }

    public Double getAbsStkgHt() {
        return this.absStkgHt;
    }

    public void setAbsStkgHt(Double absStkgHt) {
        this.absStkgHt = absStkgHt;
    }

    public Short getMaxStkgHt() {
        return this.maxStkgHt;
    }

    public void setMaxStkgHt(Short maxStkgHt) {
        this.maxStkgHt = maxStkgHt;
    }

    public String getRowOrntnInd() {
        return this.rowOrntnInd;
    }

    public void setRowOrntnInd(String rowOrntnInd) {
        this.rowOrntnInd = rowOrntnInd;
    }

    public Short getRowCount() {
        return this.rowCount;
    }

    public void setRowCount(Short rowCount) {
        this.rowCount = rowCount;
    }

    public Short getStkCount() {
        return this.stkCount;
    }

    public void setStkCount(Short stkCount) {
        this.stkCount = stkCount;
    }

    public Short getRowStartNo() {
        return this.rowStartNo;
    }

    public void setRowStartNo(Short rowStartNo) {
        this.rowStartNo = rowStartNo;
    }

    public Short getStkStartNo() {
        return this.stkStartNo;
    }

    public void setStkStartNo(Short stkStartNo) {
        this.stkStartNo = stkStartNo;
    }

    public Short getTierStartNo() {
        return this.tierStartNo;
    }

    public void setTierStartNo(Short tierStartNo) {
        this.tierStartNo = tierStartNo;
    }

    public String getBlkOprnType() {
        return this.blkOprnType;
    }

    public void setBlkOprnType(String blkOprnType) {
        this.blkOprnType = blkOprnType;
    }

    public Double getSlotLen() {
        return this.slotLen;
    }

    public void setSlotLen(Double slotLen) {
        this.slotLen = slotLen;
    }

    public Double getSlotWd() {
        return this.slotWd;
    }

    public void setSlotWd(Double slotWd) {
        this.slotWd = slotWd;
    }

    public String getStkNumsrsId() {
        return this.stkNumsrsId;
    }

    public void setStkNumsrsId(String stkNumsrsId) {
        this.stkNumsrsId = stkNumsrsId;
    }

    public String getRowNumsrsId() {
        return this.rowNumsrsId;
    }

    public void setRowNumsrsId(String rowNumsrsId) {
        this.rowNumsrsId = rowNumsrsId;
    }

    public String getTierNumsrsId() {
        return this.tierNumsrsId;
    }

    public void setTierNumsrsId(String tierNumsrsId) {
        this.tierNumsrsId = tierNumsrsId;
    }

    public String getRmgTrackNo() {
        return this.rmgTrackNo;
    }

    public void setRmgTrackNo(String rmgTrackNo) {
        this.rmgTrackNo = rmgTrackNo;
    }

    public String getRmgFlg() {
        return this.rmgFlg;
    }

    public void setRmgFlg(String rmgFlg) {
        this.rmgFlg = rmgFlg;
    }
}