package com.minapro.procserver.cache;

/**
 * Possible kinds of pinning
 * 
 * @author Rosemary George
 *
 */
public enum PINNING_TYPE {
    TWIST_LOCK, CONE
}
