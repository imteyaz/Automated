package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * BlkstkYpmId entity. @author CMC.UMAMAHESH
 */
@Embeddable
public class BlkstkYpmId implements java.io.Serializable {

    private static final long serialVersionUID = 643457431343846303L;

    @Column(name = "INT_BLK_NO")
    private Integer intBlkNo;

    @Column(name = "STK_SEQ_NO")
    private Short stkSeqNo;

    public Integer getIntBlkNo() {
        return this.intBlkNo;
    }

    public void setIntBlkNo(Integer intBlkNo) {
        this.intBlkNo = intBlkNo;
    }

    public Short getStkSeqNo() {
        return this.stkSeqNo;
    }

    public void setStkSeqNo(Short stkSeqNo) {
        this.stkSeqNo = stkSeqNo;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (!(other instanceof BlkstkYpmId)) {
            return false;
        }
        BlkstkYpmId castOther = (BlkstkYpmId) other;

        return ((this.getIntBlkNo() == castOther.getIntBlkNo()) || (this.getIntBlkNo() != null
                && castOther.getIntBlkNo() != null && this.getIntBlkNo().equals(castOther.getIntBlkNo())))
                && ((this.getStkSeqNo() == castOther.getStkSeqNo()) || (this.getStkSeqNo() != null
                        && castOther.getStkSeqNo() != null && this.getStkSeqNo().equals(castOther.getStkSeqNo())));
    }

    @Override
    public int hashCode() {
        int result = 17;

        result = 37 * result + (getIntBlkNo() == null ? 0 : this.getIntBlkNo().hashCode());
        result = 37 * result + (getStkSeqNo() == null ? 0 : this.getStkSeqNo().hashCode());
        return result;
    }
}