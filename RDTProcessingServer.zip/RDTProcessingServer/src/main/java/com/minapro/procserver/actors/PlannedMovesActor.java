package com.minapro.procserver.actors;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.PlannedMovesResponseEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import akka.actor.UntypedActor;

public class PlannedMovesActor extends UntypedActor {

    MinaProApplicationLogger logger = new MinaProApplicationLogger(PlannedMovesActor.class);

    @Override
    public void onReceive(Object msg) throws Exception {
        if (msg instanceof PlannedMovesResponseEvent) {
        	PlannedMovesResponseEvent plannedMovesResponse = (PlannedMovesResponseEvent) msg;
            logger.logMsg(LOG_LEVEL.INFO, plannedMovesResponse.getEquipmentID(), 
            		"Received Planned moves Response From ESB-");
            setPlannedMoves(plannedMovesResponse);
        }else {
        	getSender().tell(msg, null);
        }
    }

    public void setPlannedMoves(PlannedMovesResponseEvent plannedMovesResEvent) {

        logger.logMsg(LOG_LEVEL.INFO, plannedMovesResEvent.getEquipmentID(), "Started setPlannedMoves() " + plannedMovesResEvent);
        RDTPLCCacheManager plcCacheMgr = RDTPLCCacheManager.getInstance();

        try {
            for (PlannedMovesEvent plannedMovesEvent : plannedMovesResEvent.getPlannedMovesResponseList()) {

                String equipmentId = plannedMovesEvent.getEquipmentID();
                int plannedMoves = plannedMovesEvent.getPlannedMoves();

                logger.logMsg(LOG_LEVEL.INFO, " ", " Equipment Id " + equipmentId + " Planned Moves " + plannedMoves
                        + " Before Putting Into The Cache");

                if (equipmentId != null && !equipmentId.isEmpty()) {
                    plcCacheMgr.addPlannedMoves(equipmentId, plannedMovesEvent);
                } else {
                    logger.logMsg(LOG_LEVEL.ERROR, "",
                            " Planned Moves Response Event Equipment Id is Null,Need to check Planned Moves Request Event/Esb Response Event");
                }
            }
        } catch (Exception ex) {
            logger.logException(" Exception Occured While Setting Planned Moves Values to Cache", ex);
        }
    }
}
