package com.minapro.procserver;

import java.rmi.RemoteException;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.queue.AdminNotificationListener;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor which act as a heart beat monitor for the master node. It sends a ping message to the master node every 5
 * seconds. </p>
 * 
 * <p>In the event where master node doesn't reply back, the actor marks this node as master and starts up all the
 * schedulers and the RMI server.</p>
 *
 * @author Rosemary George
 *
 */
public class MasterNodeHealthCheckActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(MasterNodeHealthCheckActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.INFO, "", "Checking MASTER NODE health");

        try {
            RmiClient.getInstance().checkMasterNodeHealth();
        } catch (RemoteException e) {
            logger.logException("----------------NOT ABLE TO CONTACT MASTER NODE------------- ", e);
            setUpAsMaster();
        }
    }

    /**
     * Starts up all the schedulers and the RMI server
     */
    private void setUpAsMaster() {
        logger.logMsg(LOG_LEVEL.WARN, "", "Master node seems to be down, marking this master.");

        RDTProcessingServer.getInstance().markAsMasterNode();

        logger.logMsg(LOG_LEVEL.INFO, "", "Stopping the Master Node Health check scheduler");
        RDTProcessingServer.getInstance().stopMasterNodeHealthCheckScheduler();

        logger.logMsg(LOG_LEVEL.INFO, "", "Starting the schedulers");
        RDTProcessingServer.getInstance().startSchedulers();
        AdminNotificationListener.reloadApplicationParameter();
        
        // For QC PLC
        if (RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache() > 0) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Logged in user size is > 0, starting QC PLC scheduler");
            RDTProcessingServer.getInstance().startPLCScheduler("QC");
        } else {
            logger.logMsg(LOG_LEVEL.INFO, "", "No logged in QC users in cache, checking in DB");
            long loggedInUsers = HibernateUtil.loggedInUserSize("QC");
            if (loggedInUsers > 0) {
                logger.logMsg(LOG_LEVEL.INFO, "", "Found Logged in users, starting QC PLC");
                RDTProcessingServer.getInstance().startPLCScheduler("QC");
            }
        }

        // For CHE PLC
        if (RDTPLCCacheManager.getInstance().sizeOfCHELoggedInCache() > 0) {
            logger.logMsg(LOG_LEVEL.INFO, "", "Logged in user size is > 0, starting CHE PLC scheduler");
            RDTProcessingServer.getInstance().startPLCScheduler("CHE");
        } else {
            logger.logMsg(LOG_LEVEL.INFO, "", "No logged in CHE users in cache, checking in DB");
            long loggedInUsers = HibernateUtil.loggedInUserSize("CHE");
            if (loggedInUsers > 0) {
                logger.logMsg(LOG_LEVEL.INFO, "", "Found Logged in users, starting CHE PLC");
                RDTProcessingServer.getInstance().startPLCScheduler("CHE");
            }
        }

        logger.logMsg(LOG_LEVEL.INFO, "", "Starting the RMI server");
        try {
            new RmiServer();
        } catch (Exception e) {
            logger.logException("Caught exception while trying to start the RMI server", e);
        }
    }
}
