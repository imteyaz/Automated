package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.HOIST2_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.STATE_LOCK;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

/*
 * 
 * <p> Class responsible for detecting Hoist2Postition during the container
 * locking time  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCHoist2PositionSubscriber implements StatementSubscriber {

    public QCHoist2PositionSubscriber() {
    }

    @Override
    public String getStatement() {

        return "context EachQC select a,b from pattern [ every a=EsperPLCEvent(tagName = 'Hoist2Position') -> (((b=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue))) and not EsperPLCEvent(tagName = 'Hoist2Position'))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateCraneMoveStatus(HOIST2_POSITION, STATE_LOCK, eventMap);
    }
}
