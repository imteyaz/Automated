package com.minapro.procserver.util;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.infinispan.Cache;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.minapro.procserver.cache.RDTCacheContainer;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * <p>Singleton class holding all the message formats available in the system.</p>
 * 
 * <p>The message from device will be just values separated by comma or any such separator. This eventFormats helps to
 * describe the fields that will be present in the particular event message coming from the device and also the order in
 * which the fields appear in the message.</p>
 * 
 * <p> Loads the formats from the EventFormats.xml which can be retrieved using messageType.</p>
 * 
 * @author Rosemary George
 *
 */
public class EventFormats {
    private static EventFormats instance;

    /**
     * Holds the event formats. Key is eventTypeID and arrayList contains the fields in the order.
     */
    private Cache<String, List<String>> eventFormatMap;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(EventFormats.class);

    private EventFormats() {
        eventFormatMap = RDTCacheContainer.getCache("EventFormatCache");
        setEventFormats();
    }

    public static EventFormats getInstance() {
        if (instance == null) {
            synchronized (EventFormats.class) {
                if (instance == null) {
                    instance = new EventFormats();
                }
            }
        }

        return instance;
    }

    /**
     * Reads the EventFormats.xml file and loads the formats to memory.
     */
    private void setEventFormats() {
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document document = docBuilder.parse(new FileInputStream(
                    RDTProcessingServerConstants.EVENT_FORMAT_FILE_PATH));
            NodeList messageList = document.getChildNodes().item(0).getChildNodes();
            Node message = null;
            String messageType = null;

            for (int i = 0; i < messageList.getLength(); i++) {
                message = messageList.item(i);
                if ("message".equalsIgnoreCase(message.getNodeName())) {
                    messageType = message.getAttributes().item(0).getNodeValue();
                    if (!eventFormatMap.containsKey(messageType)) {
                        List<String> fields = processEventFields(message.getChildNodes());
                        eventFormatMap.put(messageType, fields);
                    }
                }

            }

        } catch (Exception ex) {
            logger.logException("Caught Exception while setting the EventFormats : ", ex);
        }
    }

    /**
     * Finds and populates the field names of each event
     * 
     * @param fields
     *            - fields under each event
     * @return ArrayList<String> - List of field names for each event
     */
    private List<String> processEventFields(NodeList fields) {
        List<String> fieldList = new ArrayList<String>();

        Node field = null;

        for (int i = 0; i < fields.getLength(); i++) {
            field = fields.item(i);
            if ("field".equalsIgnoreCase(field.getNodeName())) {
                fieldList.add(field.getAttributes().item(0).getNodeValue());
            }
        }

        return fieldList;
    }

    /**
     * Retrieves the fields present for the specified event type.
     * 
     * @param messageID
     *            - eventType
     * @return ArrayList<String> - all the fields available for that particular eventType.
     */
    public List<String> getEventFields(String eventID) {
        return eventFormatMap.get(eventID);
    }
}
