package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.SPREADER1_LOCKEDUP;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

public class QCSpreader1Subscriber implements StatementSubscriber {

    public QCSpreader1Subscriber() {
    }

    @Override
    public String getStatement() {
        // QC Container Handling EPL Statement
        return "context EachQC select event1 from pattern[every ((EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = lockedUpTagValue))) "
                + "-> ((event1=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = unLockedUpTagValue)) and not EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = lockedUpTagValue)) ]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().peformSpreaderChangeAction(eventMap, SPREADER1_LOCKEDUP, 1);
    }
}
