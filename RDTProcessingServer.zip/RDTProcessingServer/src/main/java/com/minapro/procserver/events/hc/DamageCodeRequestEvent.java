package com.minapro.procserver.events.hc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the damage code request details from the device
 * 
 * @author Rosemary George
 *
 */
public class DamageCodeRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8059786933871210647L;

}
