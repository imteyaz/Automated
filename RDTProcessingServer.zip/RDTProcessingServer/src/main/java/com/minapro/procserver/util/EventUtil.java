package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CHECKLIST;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DRIVE_INSTRUCTION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_DISPATCHED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_LEFT;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.PERFORMANCE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REFRESH_JOB_LIST_REQUEST;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.CheckList;
import com.minapro.procserver.db.CheckListHeader;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.QCLane;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserDelay;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.RefreshJobListRequestEvent;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.AlertEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.DriveType;
import com.minapro.procserver.events.itv.FollowITVEvent;
import com.minapro.procserver.events.itv.ITVLeftEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;
import com.minapro.procserver.events.plc.EndDelayTriggerEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Common utility class for all device related messages.
 * 
 * @author Rosemary George
 *
 */
public class EventUtil {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(EventUtil.class);
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);
    private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.TERMINAL_KEY);

    private static final EventUtil INSTANCE = new EventUtil();
	private static final String EXPLOSIVE_CODES = "IMDG_Explosive";
	private static final String FLD = "FLD";
	
	public static final String FETCH = "fetch";
	public static final String CARRY = "carry";

    private EventUtil() {
    }

    public static EventUtil getInstance() {
        return INSTANCE;
    }

    /**
     * Sets the values to the specified POJO using reflection.
     * 
     * @param className
     *            - the POJO to be filled
     * @param methodName
     *            - a particular parameter of the POJO
     * @param argument
     *            - the value needed for the setMethod for the parameter
     */
    public boolean setEventParameters(Object className, List<String> fields, String[] arguments) {
        Class<?>[] parameterTypes = new Class[1];
        parameterTypes[0] = String.class;
        Object[] args = new Object[1];
        Method method = null;

        String setMethodName;

        for (int i = 0; i < fields.size(); i++) {
            setMethodName = "set" + fields.get(i);
            try {
                method = className.getClass().getMethod(setMethodName, parameterTypes);
                args[0] = arguments[i];
                method.invoke(className, args);
                logger.logMsg(LOG_LEVEL.INFO, "**************", setMethodName + " : " + arguments[i]);

            } catch (Exception ex) {
                logger.logMsg(LOG_LEVEL.ERROR, setMethodName,
                        "setEventParameters::Caught exception - " + ex.getLocalizedMessage());
            }
        }
        return true;
    }

    /**
     * Gets values from the specified POJO using reflection and append to the message
     * 
     * @param className
     * @param methodName
     * @param message
     * @return
     */
    public boolean getEventParameter(Object className, String methodName, StringBuilder message) {
        String value = "";

        Method method;
        try {
            method = className.getClass().getMethod("get" + methodName, null);
            value = String.valueOf(method.invoke(className, null));
            if (!"".equals(value)) {
                message.append(value);
            }
        } catch (NoSuchMethodException ex) {
            logger.logException("Caught Exception :", ex);
            return false;
        } catch (Exception e) {
           // logger.logMsg(LOG_LEVEL.ERROR, "",
             //       "getEventParameter::Caught exception for " + methodName + "- " + e.getLocalizedMessage());
            return false;
        }

        return true;
    }

    /**
     * Splits the message using the configured separator
     * 
     * @param message
     *            - values with a separator in between
     * @return - String[]
     */
    public String[] tokenize(String message) {
        String separator = DeviceCommParameters.getInstance().getCommParameter(
                RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
        return message.split(separator);
    }

    /**
     * Requesting for the the next pending instruction(if any) for the specified ITV and sends to the user
     * 
     * @param itvId
     * @param itvUser
     * @param TerminalId
     */
    public void sendITVJoblistRequestToESB(String itvId, String itvUser, String terminalId) {
        logger.logMsg(LOG_LEVEL.DEBUG, itvUser, "Sending Joblist request for ITV  :" + itvId);
        JobListRequestEvent requestEvent = new JobListRequestEvent();
        requestEvent.setEquipmentID(itvId);
        requestEvent.setUserID(itvUser);
        requestEvent.setTerminalID(terminalId);
        requestEvent.setEventID(UUID.randomUUID().toString());
        requestEvent.setScheduled(true);

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(itvUser);

        ESBQueueManager.getInstance().postMessage(requestEvent, operatorRole, terminalId);
    }

    /**
     * Construct the drive instruction message and post it to the communication layer queue
     * 
     * @param driveInstruction
     * @param messageType
     *            - indicates whether to send it as Response or Notification
     */
    public void sendDriveInstruction(DriveInstructionEvent driveInstruction, String messageType) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(DRIVE_INSTRUCTION);

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(DRIVE_INSTRUCTION);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(messageType ).append( VALUE_SEPARATOR ).append( eventTypeID);

        String msgField;
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            msgField = msgFields.get(i);
            getEventParameter(driveInstruction, msgField, responseToDevice);
        }

        String[] splitted = responseToDevice.toString().split("\\" + VALUE_SEPARATOR);
        String notifWithoutEventId = responseToDevice.substring(responseToDevice.indexOf(splitted[2])+splitted[2].length());
        logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getEquipmentID(), "NotifWithout eventId - " + notifWithoutEventId);
        
        if(isITVJobsDifferFromCache(notifWithoutEventId, driveInstruction)){
        	CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.ITV,
                driveInstruction.getTerminalID());
        	
        	RDTCacheManager.getInstance().addDriveInstructionstoItv(driveInstruction.getEquipmentID(), notifWithoutEventId);
        	
        	//FLD alert generation
        	if(driveInstruction.getFailedToDeckContainers() != null && !driveInstruction.getFailedToDeckContainers().isEmpty()){
        		for(String containerId : driveInstruction.getFailedToDeckContainers()){
        			generateFLDAlert(containerId, driveInstruction.getEquipmentID());
        		}
        	}
        	
        	//Follow ITV
        	if(LOAD.equalsIgnoreCase(driveInstruction.getMoveType()) && CARRY.equals(driveInstruction.getAction())){
        		createFollowITVEvent(driveInstruction);        		
        	}
        }

        // Send to ESPER for ITV delay detection
        if (!DriveType.GEN.name().equals(driveInstruction.getDriveType())) {
            RDTProcessingServer.getInstance().getEsperActor().tell(driveInstruction, null);
        }
    }
    
    /**
     * Creates the follow ITV event and passes to Master Actor for further processing
     * @param driveInstruction
     */
    public static void createFollowITVEvent(DriveInstructionEvent driveInstruction) {
		FollowITVEvent followEvent = new FollowITVEvent();
		followEvent.setCarryingContainerId(driveInstruction.getContainerID());
		followEvent.setQcId(driveInstruction.getLocationID());
		followEvent.setEquipmentID(driveInstruction.getEquipmentID());
		followEvent.setUserID(driveInstruction.getUserID());
		followEvent.setTerminalID(driveInstruction.getTerminalID());
		
    	RDTProcessingServer.getInstance().getMasterActor().tell(followEvent, null);
	}

	/**
     * Checks the drive instruction created is same as the one present in cache.
     * @param messageToDevice
     * @param itvId
     * @return
     */
    public boolean isITVJobsDifferFromCache(String messageToDevice, DriveInstructionEvent driveEvent) {
		boolean jobsDifferent = true;
		
		String currentInstructions = RDTCacheManager.getInstance().getCurrentITVInstructions(driveEvent.getEquipmentID());		
		if(currentInstructions != null && currentInstructions.length() > 0 && currentInstructions.equalsIgnoreCase(messageToDevice)){
			logger.logMsg(LOG_LEVEL.DEBUG, driveEvent.getEquipmentID(), "Same instructions as the current instruction to ITV.");
			jobsDifferent = false;
		}else {
			logger.logMsg(LOG_LEVEL.DEBUG, driveEvent.getEquipmentID(), "Current Instructions are either empty or null or different.");
			jobsDifferent = true;
		}
		
		if(jobsDifferent) {		
			RDTCacheManager.getInstance().clearItvInstructions(driveEvent.getEquipmentID());
		}
		return jobsDifferent;
	}

    /**
     * Construct the ITV Dispatched Message and sends to QC,HC and RMG
     * 
     * @param driveInstruction
     */

    public void sendDispatchedToStakeHolders(DriveInstructionEvent driveInstruction) {

        String location = null;

        if (driveInstruction.getLocationID() != null && !driveInstruction.getLocationID().isEmpty() 
        		&& !"WT".equalsIgnoreCase(driveInstruction.getLocationID())) {

            if ("YARD".equals(driveInstruction.getDriveType())) {
                location = driveInstruction.getLocationID().substring(0, 3);
            } else {
                location = driveInstruction.getLocationID();
            }

            logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getUserID(), "Location Extracted from Drive Direction is:"
                    + location);
            Set<String> operators = RDTCacheManager.getInstance().getAllUsersAtLocation(location);

            if (operators != null && !operators.isEmpty()) {

                int noOfCntrs = 0;

                logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getUserID(), "Sending ITV Dispatched to Operators :"
                        + operators);
                String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                        RDTProcessingServerConstants.ITV_DISPATCHED);

                String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

                // get the message format
                List<String> msgFields = EventFormats.getInstance().getEventFields(
                        RDTProcessingServerConstants.ITV_DISPATCHED);

                noOfCntrs = RDTCacheManager.getInstance().getNumberOfCntrsOnITV(driveInstruction.getEquipmentID());

                StringBuilder responseToDevice;
                for (String operatorId : operators) {
                    User user = RDTCacheManager.getInstance().getUserDetails(operatorId);

                    // ignore the ITV user
                    if (user.getUserID().equals(driveInstruction.getUserID())) {
                        continue;
                    }

                    // build the response to the device
                    responseToDevice = new StringBuilder(NOTIF ).append( valueSeperator ).append( eventTypeID);
                    for (int i = 1; i < msgFields.size(); i++) {
                        responseToDevice.append(valueSeperator);

                        if ("ItvID".equalsIgnoreCase(msgFields.get(i))) {
                            responseToDevice.append(driveInstruction.getEquipmentID());
                            logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
                                    "ITV ID : -" + driveInstruction.getEquipmentID());
                        } else if ("TrailerID".equalsIgnoreCase(msgFields.get(i))) {
                            String trailerNo = RDTCacheManager.getInstance().getTrailerNo(
                                    driveInstruction.getEquipmentID());
                            logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
                                    "Corresponding Trailer ID is : -" + trailerNo);
                            responseToDevice.append(trailerNo);
                        } else if ("NumberOfCntrs".equalsIgnoreCase(msgFields.get(i))) {
                            responseToDevice.append(Integer.toString(noOfCntrs));
                        } else if ("UserID".equalsIgnoreCase(msgFields.get(i))) {
                            responseToDevice.append(operatorId);
                        } else if ("Color".equalsIgnoreCase(msgFields.get(i))) {
                            // Yellow - Incase of ITV Dispatched
                            responseToDevice.append(RDTVesselProfileCacheManager.getInstance().getColourCode(
                                    ITV_DISPATCHED));
                        } else {
                            EventUtil.getInstance().getEventParameter(driveInstruction, msgFields.get(i),
                                    responseToDevice);
                        }
                    }

                    OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
                    String cntrLocation = location;                    
                    logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), "Location before split :"+ cntrLocation.toString());

                    String currentLocation = null;
                    if (cntrLocation.indexOf(ROW_SEPARATOR) > 0) {
                        String[] locationTokens = cntrLocation.toString().split("\\" + ROW_SEPARATOR);
                        currentLocation = locationTokens[0];                        
                        logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), "Location after split :"+ cntrLocation.toString());                        
                    } else {                        
                        logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), "Location from EVENT :"+ cntrLocation.toString());
                        currentLocation = cntrLocation.toString();
                    }

                    if (!currentLocation.equalsIgnoreCase(RDTCacheManager.getInstance().getITVCurrentLocation(
                            driveInstruction.getEquipmentID()))) {

                        logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), "ITV Location from DI :"
                                + currentLocation  + " ITV Arrived at :"
                                + RDTCacheManager.getInstance().getITVCurrentLocation(driveInstruction.getEquipmentID()));
                        logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(),
                                "ITV arrived no need to send Dispatch :" + user.getUserID() + " Role :" + operatorRole);
                        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
                                operatorRole, driveInstruction.getTerminalID());
                    }

                    if(operatorRole.equals(OPERATOR.HC)){
                    	String qcUserId = getQcUserId(user.getUserID());
                    	if(qcUserId != null && getInspectionStatus(qcUserId)){
                    		logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Associated QC USer is logged in. No need to refresh from HC");
                    		continue;
                    	}
                    }
                    logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getEquipmentID(), "Sending Refresh Joblist request to "
                    		+ "update ITV ID in From or ToLocation of CHE or QC" + user.getUserID() + " Role :" + operatorRole);
                    initiateRefreshJobList(user.getUserID());
                }
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, driveInstruction.getUserID(),
                        "No QC, HC , RMG users are logged in to send Dispatched ITV");
            }
        }
    }
    
    /**
     * Initiates the refresh job list request and pass to Master Actor for further processing
     */
    public void initiateRefreshJobList(String userId){
    	try {
	    	 RefreshJobListRequestEvent jobListRefreshRequest = new RefreshJobListRequestEvent();
	
	         SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm");
	         String dateString = formatter.format(new Date());
	
	         jobListRefreshRequest.setEquipmentID(RDTPLCCacheManager.getInstance()
	                 .getSignedInEquipmentIdForUser(userId));
	         jobListRefreshRequest.setUserID(userId);
	         jobListRefreshRequest.setEventID(UUID.randomUUID().toString());
	         jobListRefreshRequest.setEventType(DeviceEventTypes.getInstance().getEventType(
	                 REFRESH_JOB_LIST_REQUEST));
	         jobListRefreshRequest.setTerminalID(TERMINAL_ID);
	         jobListRefreshRequest.setTimeStamp(dateString);
	
	         RDTProcessingServer.getInstance().getMasterActor().tell(jobListRefreshRequest, null);
    	}catch(Exception ex){
    		logger.logException("Caught exception while initiating the Refresh Job List request-", ex);
    	}
    }

    /**
     * Construct the ITV Left Message and sends to QC,HC and RMG
     * 
     * @param itvLeft
     */
    public void sendITVLeftMessageToCranes(ITVLeftEvent itvLeft) {

        String itvUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(itvLeft.getItvID());
        String itvLocation = RDTCacheManager.getInstance().getITVCurrentLocation(itvLeft.getItvID());
        logger.logMsg(LOG_LEVEL.INFO, itvUserId, "Location of ITV -" + itvLeft.getItvID() + itvLocation);
        
        if (itvLocation != null) {
            Set<String> operators = RDTCacheManager.getInstance().getAllUsersAtLocation(itvLocation);
            logger.logMsg(LOG_LEVEL.INFO, itvUserId, "Sending ITV Left Message to QC/HC or RMG -");

            String eventTypeID = DeviceEventTypes.getInstance().getEventType(ITV_LEFT);
            itvLeft.setEventID(UUID.randomUUID().toString());
            itvLeft.setEventType(eventTypeID);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(ITV_LEFT);
            if (operators != null) {
                for (String operatorId : operators) {
                    User user = RDTCacheManager.getInstance().getUserDetails(operatorId);
                    itvLeft.setUserID(operatorId);

                    // ignore the ITV user
                    if (user.getUserID().equals(itvUserId)) {
                        continue;
                    }
                    // build the response to the device
                    StringBuilder responseToDevice = new StringBuilder(NOTIF ).append( VALUE_SEPARATOR ).append( eventTypeID);
                    String msgField;
                    for (int i = 1; i < msgFields.size(); i++) {
                        responseToDevice.append(VALUE_SEPARATOR);
                        msgField = msgFields.get(i);
                        getEventParameter(itvLeft, msgField, responseToDevice);
                    }

                    OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
                    CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
                            operatorRole, itvLeft.getTerminalID());
                }
            }
        }
    }

    /**
     * <p> Determines the drive type for the instruction. It can be either to QC or Yard side or a general Instruction.
     * </p>
     * 
     * @param driveInstruction
     */
    public void setDriveTypeForInstruction(DriveInstructionEvent driveInstruction) {
        Equipment qcEquipment = null;

        // indicates that it is either to QC, YARD
        if (driveInstruction.getLocationID() != null) {
            // In case of QC, we always get POW from ESB as a Location ID
            List<Equipment> listofEqpts = RDTCacheManager.getInstance().getAllEquipmentDetails();

            logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(),
                    "LocationID is -" + driveInstruction.getLocationID());

            for (Equipment eqpt : listofEqpts) {
                if ("QC".equals(eqpt.getEquipmentType().getEquipmentTypeId())
                        && eqpt.getEquipmentID().equalsIgnoreCase(driveInstruction.getLocationID())) {
                    qcEquipment = eqpt;
                    break;
                }
            }

            // if the instruction location is present in the equipment cache, it indicates drive instruction to QC side
            if (qcEquipment != null) {
                logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "Mapped EquipmentID of POW is -"
                        + qcEquipment.getEquipmentID());
                String laneId = driveInstruction.getLaneID();
                
                if(laneId == null){
                	laneId = RDTCacheManager.getInstance().getAllocatedQCLane(qcEquipment.getEquipmentID());
                	driveInstruction.setLaneID(laneId);
                }

                // add the drive direction
                if (laneId != null) {
                    QCLane lane = RDTCacheManager.getInstance().getQcLane(laneId);
                    if (lane != null) {
                        driveInstruction.setDriveDirection(lane.getDrivingDirection());
                    }
                }

                driveInstruction.setDriveType(DriveType.QC);
                driveInstruction.setLocationID(qcEquipment.getEquipmentID());
                
                if(DSCH.equalsIgnoreCase(driveInstruction.getMoveType())){
                	driveInstruction.setAction(FETCH);
                }else {
                	driveInstruction.setAction(CARRY);
                }
                
            } else {
                driveInstruction.setDriveType(DriveType.YARD);

               // will be receiving it as 76A.89.F.4, should display as 76A89F
                String yardLocation = driveInstruction.getLocationID().replaceAll("\\.", "");
                String blockId = yardLocation;
                if (yardLocation != null && yardLocation.length() >= 6) {
                    blockId = yardLocation.substring(0, 6);
                }
                logger.logMsg(LOG_LEVEL.INFO, driveInstruction.getUserID(), "BlockID is :" + blockId);

                if (blockId != null) {
                    driveInstruction.setLocationID(blockId);
                }
                
                if(LOAD.equalsIgnoreCase(driveInstruction.getMoveType())){
                	driveInstruction.setAction(FETCH);
                }else if(DSCH.equalsIgnoreCase(driveInstruction.getMoveType())){
                	driveInstruction.setAction(CARRY);                	
                }
            }
        } else if (driveInstruction.getGeneralInstruction() != null) {
            driveInstruction.setDriveType(DriveType.GEN);
        }
    }

    /**
     * for Calculating Max Moves Per Hour
     * 
     * @param userId
     * @param movesToGo
     * @param initianJobsCount
     * @return grossMovesperHour
     */
    public double getGrossMoveperHour(String userId, int completedJobs) {
        double grossMovesperHour = 0;
        
        Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);
        double diffInMillies = System.currentTimeMillis() - loginTime.getTime();
        double totalTimeWorkedInHours = diffInMillies / (1000 * 60 * 60);
        grossMovesperHour = completedJobs / totalTimeWorkedInHours;

        return grossMovesperHour;
    }

    /**
     * @author Prasad.Tallapally tierNo belongs Upper Deck or Lower Deck of Vessel
     * @param tierNo
     * @return deckIndication
     */
    public String findDeckType(String tierNo, String vesselNo, String bayNo) {
        String deckIndication = null;
        if (Integer.parseInt(tierNo) >= 80) {
            deckIndication = "D";
        } else if (Integer.parseInt(tierNo) <= 18) {
            deckIndication = "U";
        } else {
            deckIndication = HibernateUtil.getDeckValueForBayTier(vesselNo, bayNo, tierNo);
        }
        return deckIndication;
    }

    /**
     * <p>Retrieves the check list associated with the user role and sends the check lists to the communication
     * layer.</p>
     * 
     * @param user
     *            - the user to whom the checklist need to be sent
     * @param event
     *            - the allocation Details received from the user
     */
    public void sendInspectionCheckList(User user, Event event, String eventType) {
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID());

        logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending the pre-operational check list for the role -"
                + operatorRole);

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RESP ).append( VALUE_SEPARATOR ).append( eventTypeID);

        String msgField;
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            msgField = msgFields.get(i);

            if (msgField.equalsIgnoreCase(CHECKLIST)) {
                OPERATOR roleName = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
                /*
                 * Build 2 UAT issue - do not mirror QC check lists to HC, send HC defined check lists if
                 * (roleName.equals(OPERATOR.HC)) { roleName = OPERATOR.QC; }
                 */
                CheckListHeader header = RDTCacheManager.getInstance().getCheckListForRole(roleName.toString(),
                        CheckListHeaderType.PRE_OP.getName());
                if (header != null) {
                    List<CheckList> checkLists = HibernateUtil.getCheckListForHeader(header);
                    /*
                     * Sending the checklist items in the format
                     * headerId:checklitsId-checklistItem-icon-category-mandatory
                     * ^p|headerId:checklitsId-checklistItem-icon-category-mandatory
                     */
                    for (CheckList checkListItem : checkLists) {
                        responseToDevice.append(header.getCheckListHeaderId() + ":" + checkListItem.getChecklistId())
                                .append(ITEM_SEPARATOR).append(checkListItem.getChecklistName()).append(ITEM_SEPARATOR)
                                .append(checkListItem.getIcon()).append(ITEM_SEPARATOR)
                                .append(checkListItem.getCategory()).append(ITEM_SEPARATOR)
                                .append(checkListItem.getMandatory()).append(ROW_SEPARATOR);
                    }
                }
            } else {
                EventUtil.getInstance().getEventParameter(event, msgFields.get(i), responseToDevice);
            }
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                event.getTerminalID());
    }

    /**
     * Method is responsible for Retrieves the inspection status for the specified user ID
     * 
     * @param userId
     *            current allocated user
     * @return inspection status true or false
     */
    public boolean getInspectionStatus(String userId) {
        boolean inspectionResult = false;

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        String inspectionStatus = rdtCacheMgr.getInspectionStatus(userId);
        if (inspectionStatus != null && inspectionStatus.length() > 0) {
            inspectionResult = true;
        }

        return inspectionResult;
    }

    /**
     * Retrieves the current User who is operating the QC which the HC operator is associated with
     * 
     * @param currentUserId
     * @return
     */
    public String getQcUserId(String hcUserId) {
        String qcUserId = null;
        try {
            String qcEqupmntId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(hcUserId);
            if (qcEqupmntId != null) {
                qcUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcEqupmntId);
            }
        } catch (NullPointerException ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" getQcUserId").append(REASON).toString(),
                    ex);
        }
        return qcUserId;
    }

    // TODO - modify as per PROMISE data
    /**
     * Identifies if any icon is applicable to the container based on the reefer, hazardous and out-of-gauge status.
     * 
     * @param container
     * @return iconNumber if applicable, else empty string
     */
    public String getContainerIcon(Container container) {
        if (container.isReefer() && container.isHazardous()) {
            return "1";
        } else if (container.isReefer()) {
            return "3";
        } else if (container.isHazardous()) {
            return "2";
        } else if (container.isOOG()) {
            return "7";
        } else if (container.getIsDamaged()) {
            return "13";
        } else {
            return "";
        }
    }

    public static double getTimeDuration(Date startDate) {

        logger.logMsg(LOG_LEVEL.INFO, "", " Started getTimeDuration() with Operator Break Start Time " + startDate);

        Date currentDate = new Date();

        long timeDiffInMillis = currentDate.getTime() - startDate.getTime();

        double timeDiffInMins = timeDiffInMillis / (1000 * 60);

        double timeDiffInHours = timeDiffInMins / (60);

        logger.logMsg(LOG_LEVEL.INFO, "", " Returning From getTimeDuration() Operator BreakDuration Is "
                + timeDiffInHours);
        return timeDiffInHours;

    }

    /**
     * Constructs the performance statistics alert and sends to the device.
     * 
     * @param qcPerformance
     * @param operator
     */
    public void sendPerformanceEvent(PerformanceEvent qcPerformance, OPERATOR operator) {

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(PERFORMANCE);

        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(NOTIF ).append( valueSeperator ).append( qcPerformance.geEventType());

        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(valueSeperator);
            EventUtil.getInstance().getEventParameter(qcPerformance, msgFields.get(i), responseToDevice);
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                qcPerformance.getTerminalID());
    }

    /**
     * Constructs the performance event for the operator with all the performance variables
     * 
     * @param userId
     * @param grossMovesperHour
     * @param targetCompletionTime
     * @param movesToGo
     * @param movesBehind
     * @param targetMph
     * @param qcEquipmentId
     * @return
     */
    public PerformanceEvent constructPerformanceEvent(String userId, double grossMovesperHour,
            double targetCompletionTime, int movesToGo, int movesBehind, int completedJobsByUser,
            String cheEquipmentId, double targetMph) {
        PerformanceEvent performanceEvent = new PerformanceEvent();

        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(PERFORMANCE);
        performanceEvent.setEventType(eventTypeID);
        performanceEvent.setUserID(userId);
        performanceEvent.setEquipmentID(cheEquipmentId);
        performanceEvent.setTerminalID(TERMINAL_ID);

        String dateString = formatter.format(new Date());
        performanceEvent.setTimeStamp(dateString);

        String uuid = UUID.randomUUID().toString();
        performanceEvent.setEventID(uuid);

        performanceEvent.setTotalMoves(completedJobsByUser);
        performanceEvent.setGrossMovesPerHour(Math.round(grossMovesperHour));
        performanceEvent.setMovesBehind(movesBehind);
        performanceEvent.setMovesToGo(movesToGo);
        performanceEvent.setTargetCompletionTime(Math.round(targetCompletionTime));
        performanceEvent.setTargetMovesperHour(targetMph);

        return performanceEvent;
    }

    /**
     * Constructs the date out of hours and minutes
     * 
     * @param hours
     * @param minutes
     * @return
     */
    public Date convertShiftTimeToDateFormat(int hours, int minutes) {
        Calendar cal = new GregorianCalendar();
        cal.set(Calendar.HOUR_OF_DAY, hours);
        cal.set(Calendar.MINUTE, minutes);
        cal.set(Calendar.SECOND, 0);

        return cal.getTime();
    }

    /**
     * Construct the Confirm allocation failure alert to the device
     * 
     * @param Event
     */
    public void sendAlertMessageToUser(AlertEvent alertEvent) {
        logger.logMsg(LOG_LEVEL.WARN, alertEvent.getUserID(), "Confirm allocation failed with message -" + alertEvent);

        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(ALERT_MESSAGE);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(RESP ).append( valueSeperator ).append( eventTypeID);
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                EventUtil.getInstance().getEventParameter(alertEvent, msgFields.get(i), responseToDevice);
            }

            User user = RDTCacheManager.getInstance().getUserDetails(alertEvent.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(alertEvent.getUserID());

                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        alertEvent.getTerminalID());
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing sendAlertMessageToUser -", e);
        }
    }

    /**
     * Converts the String to Date
     * 
     * @param dateString
     * @return
     */
    public Date convertToDate(String dateString) {
        Date date;
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");

        try {
            date = dateFormat.parse(dateString);
        } catch (ParseException e) {
            date = new Date();
        }

        return date;
    }

    /**
     * Converts the Date into a date string
     * 
     * @param date
     * @return
     */
    public String convertDateToString(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        return dateFormat.format(date);
    }

    /**
     * Verifies whether an automatic open delay exists for the specified user. If yes, triggers end delay.
     * 
     * @param userId
     * @param equipmentId
     */
    public void checkAndTriggerOpenEndDelay(String userId, String equipmentId) {
    	if (RDTPLCCacheManager.getInstance().isOpenDelayExists(equipmentId)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Trigger end delay event");
            EndDelayTriggerEvent endDelayEvent = new EndDelayTriggerEvent();
            endDelayEvent.setUserID(userId);
            endDelayEvent.setEquipmentID(equipmentId);
            RDTProcessingServer.getInstance().getMasterActor().tell(endDelayEvent, null);
        }else {
        	logger.logMsg(LOG_LEVEL.DEBUG, userId, "No open delay exists");
        }
    }
    
    /**
     * Checks whether the machine stoppage property is set to true for the delay code and 
     * informs ESB about the delay status. 
     * 
     * @param equipmentId
     * @param delayCode
     * @param isStartingDelay
     * @param userId
     */
    public void checkAndInformESBOnDelay(String equipmentId, String delayCode, boolean isStartingDelay, String userId){
    	DelayReasonCode delayReason = HibernateUtil.getDelayReasonByCode(delayCode);
    	if(delayReason != null && "Y".equalsIgnoreCase(delayReason.getMachineStoppage())){
    		logger.logMsg(LOG_LEVEL.INFO, equipmentId, "Delay code associated is not null and machinestoppage value is Y");
    		
    		OperatorAvailabilityEvent availabilityEvent =  new OperatorAvailabilityEvent();
        	availabilityEvent.setEquipmentID(equipmentId);
        	availabilityEvent.setEventID(UUID.randomUUID().toString());
        	if(isStartingDelay){
        		availabilityEvent.setIsAvailable("U");
        	}else{
        		availabilityEvent.setIsAvailable("A");
        	}
        	availabilityEvent.setOperatorInitiated(false);
        	availabilityEvent.setUnavailableReason(delayCode);
        	availabilityEvent.setUserID(userId);
        	availabilityEvent.setUserName(userId);
        	availabilityEvent.setCallItv(false);
        	
        	String[] vesselVoyage = JobListUtil.getVesselAndVoyageDetails(userId);
        	if(vesselVoyage != null){
        		availabilityEvent.setVessel(vesselVoyage[0]);
        		availabilityEvent.setVoyage(vesselVoyage[1]);
        	}
        	
        	OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
        	ESBQueueManager.getInstance().postMessage(availabilityEvent, role, "T2");
    	}else{
    		logger.logMsg(LOG_LEVEL.INFO, equipmentId, "Delay code associated is null or machinestoppage value is N");
    	}    	
    }

    /**
     * Removes the empty trailing separator from the message if the message is CODE1^CODE2^, then the method will return
     * the message as CODE1^CODE2, removing ^ from the end
     * 
     * @param separator
     * @param message
     */
    public void removeTrailingSeparator(String separator, StringBuilder message) {
        if (message.lastIndexOf(separator) == message.length() - 1) {
            message.delete(message.length() - 1, message.length());
        }
    }
    
    /**
     * Get the Explosive IMDG Codes defined in the system(From application parameter).
     *  If no value is defined, null is returned
     * 
     * @return
     */
    public String getExplosiveCodes() {
        ApplicationParameter imdgCodesParam = RDTPLCCacheManager.getInstance().getApplicationParamter(EXPLOSIVE_CODES);
        String explosiveCodes = null;
        if (imdgCodesParam != null) {
            try {
            	explosiveCodes = imdgCodesParam.getParameterValue();
            } catch (Exception ex) {
                logger.logException("Caught exception while getExplosiveCodes", ex);
            }
        }
        return explosiveCodes;
    }
    
    /**
	 * <p> Calculate the priority of the job based on the below 3 rules.</p>
	 * 
	 * <p> LOAD and DSCH job gets more than DLVR/RECV/YARD jobs </p> <p> LOAD job gets more priority that DSCH </p> <p>
	 * In LOAD jobs, mainline vessel gets priority than feeder </p>
	 * 
	 * @param job
	 * @param berthedVessels
	 * @return
	 */
	public int getPriorityScore(JobListContainer job, Set<Vessel> berthedVessels) {
		int score = 0;

		String vesselCode;
		Vessel vessel;
		if (job.getMoveType().equals(LOAD)) {
			if (job.getRotationId() != null) {
				vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(job.getRotationId());
				if (vesselCode != null) {
					vessel = RDTVesselProfileCacheManager.getInstance().getVesselFromBerthedList(vesselCode);
					if (vessel != null && (vessel.getMotherFeeder() == 'M' ? true : false)) {
						return 3;
					}
				}
			}
			score = 2;
		} else if (job.getMoveType().equals(DSCH)) {
			score = 1;
		}

		return score;
	}

	/**
	 * Verifies whether any container in the delta jobs have FLD as toLocation. If so, construct the FLD_CONTAINER_ALERT
	 * 
	 * @param modifiedJobs
	 * @param equipmentId
	 */
	public void checkForFLDContainers(List<JobListContainer> modifiedJobs, String equipmentId, String userId) {
		MinaProAlertEvent alert;
		for(JobListContainer container : modifiedJobs)	{
			if(container.getToLocation().contains(FLD)){
				alert = new MinaProAlertEvent();
				alert.setAlertCode(ALERTCODE.FLD_CONTAINER_ALERT);
				alert.setContainerId(container.getContainerId());
				alert.setEquipmentID(equipmentId);
				alert.setOperatorId(userId);
				alert.setUserID(userId);
				
				logger.logMsg(LOG_LEVEL.DEBUG, equipmentId, "Generating alert : Detected FLD for container " + container.getContainerId());
				
				RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
			}
		}
	}
	
	 /**
     * Checks whether the specified bay is a logical one or physical one. If the bay number is even, it means it is a
     * logical bay.
     * 
     * @param bayNo
     * @return
     */
    public boolean isLogicalBay(String bayNo) {
        try {
            Integer bay = Integer.parseInt(bayNo);
            return (bay % 2 == 0) ? true : false;

        } catch (Exception ex) {
            logger.logException("Caught exception while checking whether the bay is Logical one -", ex);
            return false;
        }
    }
    
    /**
     * Method is useful for checking the current equipment job list request is in progress or completed.
     * If request is in progress return true , If not return false.
     */
    public static boolean isEquipmentJobListReqInProgress(final String equipmentId){    
    	EquipmentJobListRequestStatus eqJobStatus= RDTCacheManager.getInstance().getEqJobListReqStatus(equipmentId);    	
    	return eqJobStatus!=null ? eqJobStatus.equals(EquipmentJobListRequestStatus.IN_PROGRESS) ? true : false  : false;    
    }
    
    public enum EquipmentJobListRequestStatus {    	
    	IN_PROGRESS,COMPLETED
    }
    
    /**
     * Checks whether the container IMDG code falls under the explosive category(defined in the system parameter)
     * @param definedExplosiveCodes
     * @param containerIMDGCodes
     * @return
     */
    public boolean isExplosiveContainer(String definedExplosiveCodes, String containerIMDGCodes){
    	String[] imdgCodes = containerIMDGCodes.split("\\,");
    	String[] systemCodes = definedExplosiveCodes.split("\\,");
    	
    	for(String code: imdgCodes){
    		for(String sysCode:systemCodes){
    			if(sysCode.equals(code)){
    				return true;
    			}
    		}
    	}    		
    	return false;
    } 
    
    /**
     * Retrieves the language preference set for the specified user. If no language is set, returns en as default language
     * @param userId
     * @return
     */
    public String getUserLanguage(String userId){
    	String langKey = "en";
        User user = RDTCacheManager.getInstance().getUserDetails(userId);
        if(user != null && user.getDeafultLanguage() != null && !user.getDeafultLanguage().isEmpty()){
            langKey = user.getDeafultLanguage();
        }
        return langKey;
    }
    
    /**
     * 
     * Constructs and ITV event request to ESB
     * 
     * @param allocationDetails
     * @param role
     */
    public void requestITVpool(Event responseEvent, OPERATOR role) {
    	logger.logMsg(LOG_LEVEL.INFO,responseEvent.getUserID()," Sending ITV Pool Request TO ESB For Equipment::"+responseEvent.getEquipmentID());
        
    	ITVPoolRequestEvent poolEvent = new ITVPoolRequestEvent();
        poolEvent.setEventID(UUID.randomUUID().toString());
        
        if(role.equals(OPERATOR.HC)){
        	String qcId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(responseEvent.getUserID());
        	poolEvent.setEquipmentID(qcId);
        }else {
        	poolEvent.setEquipmentID(responseEvent.getEquipmentID());
        }
        poolEvent.setUserID(responseEvent.getUserID());
        poolEvent.setTerminalID(responseEvent.getTerminalID());
        
        ESBQueueManager.getInstance().postMessage(poolEvent, role, poolEvent.getTerminalID());
    }
    /**
     * Following Utility Method Is Used To Set PLC Equipment Event Status To Cache.
     * When User Initial Login Setting Status As False.At the Time LogOut Removing Details From Cache.
     * @param event
     * @param status
     */
	public static void setCurrentEquipmentPLCWorkingStatus(Event event, boolean status) {
		final OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID());

		String equipmentId = event.getEquipmentID();
		if (operatorRole.equals(OPERATOR.CHE) || operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)) {
			equipmentId = operatorRole.equals(OPERATOR.HC) ? RDTCacheManager.getInstance()
					.getQCEquipmentAllocatedForHC(event.getUserID()) : equipmentId;

			if (equipmentId != null) {
				if (event instanceof LogoutEvent) {
					RDTCacheManager.getInstance().removeEquipmentPLCStatus(event.getUserID(), equipmentId);
				} else {
					logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
							new StringBuilder(" Setting Current User Equipment::").append(event.getEquipmentID())
									.append(" PLC Event Status::").append(status).append(" To Cache").toString());
					RDTCacheManager.getInstance().setEquipmentPLCEventStatus(event.getUserID(), equipmentId, status);
				}
			} else {
				logger.logMsg(LOG_LEVEL.ERROR, "", new StringBuilder(" Equipment Is Null..").append(" User Id::")
						.append(event.getUserID()).toString());
			}
		}
	}
    
    
    /**
     * Generates the FLD alert event and forwards to master actor for further processing
     * @param responseEvent
     */
    public static void generateFLDAlert(String containerId, String itvId) {    	
    	List<CompletedContainerMoves> completedMoveList = HibernateUtil.getCompletedMoves(containerId, itvId);
    	
    	try {
	    	if(completedMoveList != null && !completedMoveList.isEmpty()){
	    		CompletedContainerMoves completedMove = completedMoveList.get(0);
	    		
		    	logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Raising FLD alert for the container - " + containerId);
		    	MinaProAlertEvent alert = new MinaProAlertEvent();
				alert.setAlertCode(ALERTCODE.FLD_CONTAINER_ALERT);
				alert.setContainerId(containerId);
				alert.setEquipmentID(completedMove.getEquipment());
				alert.setOperatorId(completedMove.getUser().getUserID());
				alert.setUserID(completedMove.getUser().getUserID());
				RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);  
	    	}
    	}catch(Exception ex){
    		logger.logException("Caught exception while raising FLD alert", ex);
    	}
	}
    
    /**
     * Closes the specified delay in the system.
     * 
     * @param delay
     * @param userId
     */
    public void closeDelay(UserDelay delay, String userId){
    	User user = RDTCacheManager.getInstance().getUserDetails(userId);
    	if(user != null){    	
    		delay.setdelayEndUser(user);
    		delay.setmodifyBy(user);
    	}
    	delay.setdelayEndTime(new Date());
        delay.setmodifyDateTime(new Date());
        JournalEvent journalEvent = new JournalEvent(delay, UPDATETYPE.UPDATE);
        RDTProcessingServer.getInstance().getMasterActor().tell(journalEvent, null);
    }
    
    /**
	 * Creates the manual delay for the Accident/Incident
	 * 
	 * @param confirmEvent
	 * @param rotationId
	 */
	public void createDelay(Event event, String rotationId, String delayCode, String equipmentId, boolean isAutomatic) {
		UserDelay userDelay = new UserDelay();
		userDelay.setDealyCode(delayCode);
		userDelay.setTerminalId(event.getTerminalID());
		userDelay.setRotationId(rotationId);
		userDelay.setEquipmentID(equipmentId);
		userDelay.setIsDeleted("N");
		if(isAutomatic){
			userDelay.setIsAutomated("A");
		}else {
			userDelay.setIsAutomated("M");
		}
		userDelay.setCreatedDatetime(event.getTimeStamp());

		User user = RDTCacheManager.getInstance().getUserDetails(event.getUserID());
		userDelay.setCreatedBy(user);
		userDelay.setdelayStartUser(user);
		userDelay.setdelayStartTime(event.getTimeStamp());

		JournalEvent journalEvent = new JournalEvent(userDelay, UPDATETYPE.ADD);
		RDTProcessingServer.getInstance().getMasterActor().tell(journalEvent, null);		
	}
}