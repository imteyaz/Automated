package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TANDEM_JOB_TYPE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TWIN_JOB_TYPE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.UPDATE_JOB;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.opus.joblist.OpusQCJobListDAO;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.UpdateJobRequestEvent;
import com.minapro.procserver.events.UpdateJobRequestEvent.JOB_UPDATE_TYPE;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the update job requests from device
 * 
 * @author Rosemary George
 *
 */
public class UpdateJobListActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(UpdateJobListActor.class);
    
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    
    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof UpdateJobRequestEvent) {
            UpdateJobRequestEvent updateJobEvent = (UpdateJobRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, updateJobEvent.getUserID(), "Received joblist update request from device - "
                    + updateJobEvent);

            if (OPERATOR.HC.equals(RDTCacheManager.getInstance().getUserLoggedInRole(updateJobEvent.getUserID()))) {
                updateJobEvent.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                        updateJobEvent.getUserID()));
            }
            updateJobs(updateJobEvent);
        } else {
            unhandled(message);
        }
    }

    /**
     * Constructs and sends delete job operation performed by one operator to all other users who are working on the
     * same location.
     * 
     * @param manualDeleteOperation
     */
    private void sendUpdateJobMessageToOtherUsers(UpdateJobRequestEvent updateJobEvent) {
        
    	try {
        	
            Set<String> allocatedUsers = RDTCacheManager.getInstance().getAllUsersAtLocation(
                    updateJobEvent.getEquipmentID());
            
            String performedUser = updateJobEvent.getUserID();
            
            logger.logMsg(LOG_LEVEL.INFO,performedUser, new StringBuilder(" Users Working At Current Equipment").append(updateJobEvent.getEquipmentID())
            		.append(" Are::").append(allocatedUsers).toString());

            if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {                

                StringBuilder responseToDevice;
                for (String currentUser : allocatedUsers) {
                    if (!currentUser.equals(performedUser)) {
                        String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(currentUser);
                        if (inspectionStatus != null) {
                            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(currentUser);

                            // build the response to the device
                            responseToDevice = generateUpdateJobMessage(updateJobEvent, currentUser);

                            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
                                    operatorRole, updateJobEvent.getTerminalID());
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in sendResponseToAllUsers")
                    .append(REASON).toString(), ex);
        }
    }
    
    /**
     * Generates the update job notification message for the specified user
     * @param updateJobEvent
     * @param userId
     * @return
     */
    private StringBuilder generateUpdateJobMessage(UpdateJobRequestEvent updateJobEvent, String userId){
        StringBuilder responseToDevice;
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(UPDATE_JOB);
        
        // build the response to the device
        responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
        responseToDevice.append(VALUE_SEPARATOR).append(updateJobEvent.getEventID())
                .append(VALUE_SEPARATOR).append(updateJobEvent.getUpdateType())
                .append(VALUE_SEPARATOR);
        for (String container : updateJobEvent.getContainerIDs()) {
            responseToDevice.append(container).append(ROW_SEPARATOR);
        }
        responseToDevice.append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR)
                .append(updateJobEvent.getTerminalID());
        
        return responseToDevice;
    }

    /**
     * <p>Updates the specified jobs for the operator based on the update type. Possible updates are splitting a twin
     * job, joining two jobs to mark it as twin or joining 2 or more jobs to mark it as Tandem.</p>
     * 
     * <p>The operator modified jobs are marked as manually overridden in order to avoid ESB updates about this jobs
     * </p>
     * 
     * @param updateJobEvent
     */
    private void updateJobs(UpdateJobRequestEvent updateJobEvent) {
        try {
            ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
                    updateJobEvent.getUserID(), updateJobEvent.getEquipmentID());

            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(updateJobEvent.getUserID());
            JOB_UPDATE_TYPE jobListUpdateType = updateJobEvent.getUpdateType();

            if (jobListUpdateType.equals(JOB_UPDATE_TYPE.SPLIT)) {
                logger.logMsg(LOG_LEVEL.DEBUG, updateJobEvent.getUserID(), "Splitting the twin job to single jobs");
                JobListContainer container;
                for (String containerId : updateJobEvent.getContainerIDs()) {
                    if(role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC)){
                        container = jobList.get(containerId+updateJobEvent.getMoveType());
                    }else{
                        container = jobList.get(containerId); 
                    }
                    if (container != null) {
                        container.setTwinContainerId(null);
                        container.setManuallyOverridden(true);
                    }
                }
                
                updateTwinTandemRecord(updateJobEvent);
            } else if (jobListUpdateType.equals(JOB_UPDATE_TYPE.TWIN) && updateJobEvent.getContainerIDs().length >= 2) {
                logger.logMsg(LOG_LEVEL.DEBUG, updateJobEvent.getUserID(), "Making the jobs as twin job");
                Set<TwinTandemContainerList> containerDetails =  performTwinUpdate(jobList, updateJobEvent.getContainerIDs(), 
                        updateJobEvent.getUserID(), role, updateJobEvent.getMoveType());
                 
                String twinTandemType = TWIN_JOB_TYPE;
                JobListContainer container = jobList.get(updateJobEvent.getContainerIDs()[0]+updateJobEvent.getMoveType());
                if(container != null){
                	String bayNo =container.getFromLocation();
                	if(LOAD.equals(container.getMoveType())){
                		bayNo = container.getToLocation();
                	}
                	
                	bayNo = bayNo.split("\\.")[0];
                	if(EventUtil.getInstance().isLogicalBay(bayNo)){
                		logger.logMsg(LOG_LEVEL.DEBUG, updateJobEvent.getUserID(), "Bay No is even, treat as TANDEM job");
                		twinTandemType = TANDEM_JOB_TYPE;
                	}
                }
                
                if(containerDetails != null){
                    saveTwinTandemJobInDB(containerDetails, updateJobEvent, twinTandemType);
                }  
            } else if (jobListUpdateType.equals(JOB_UPDATE_TYPE.TANDEM) && updateJobEvent.getContainerIDs().length >= 2) {
                logger.logMsg(LOG_LEVEL.DEBUG, updateJobEvent.getUserID(), "Making the jobs as TANDEM job");
                Set<TwinTandemContainerList> containerDetails =  performTandemUpdate(jobList, updateJobEvent.getContainerIDs(), 
                        updateJobEvent.getUserID(), updateJobEvent.getMoveType());
                
                if(containerDetails != null){
                    saveTwinTandemJobInDB(containerDetails, updateJobEvent, TANDEM_JOB_TYPE);
                }

            } else if (jobListUpdateType.equals(JOB_UPDATE_TYPE.TANDEM_SPLIT)) {
                logger.logMsg(LOG_LEVEL.DEBUG, updateJobEvent.getUserID(), "Splitting the TANDEM job to single jobs");
                performTandemSplit(jobList, updateJobEvent);
            }

            sendUpdateJobMessageToOtherUsers(updateJobEvent);
        } catch (Exception ex) {
            logger.logException("Caught exception while updating the joblist for user: " + updateJobEvent.getUserID(),
                    ex);
        }
    }

    private void saveTwinTandemJobInDB(Set<TwinTandemContainerList> containerDetails, UpdateJobRequestEvent updateJobEvent, 
    		String twinTandemJobType) {
        TwinTandemJobs jobs = new TwinTandemJobs();
        jobs.setEquipmentId(updateJobEvent.getEquipmentID());
        
        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                .getAllocationDetails(updateJobEvent.getUserID()); 
        
        jobs.setJobType(twinTandemJobType);
        if(TANDEM_JOB_TYPE.equals(twinTandemJobType)){
            TwinTandemJobs twinTandemJob = HibernateUtil.getTwinTandemJob(updateJobEvent.getContainerIDs()[0], 
                    allocation.getRotationID(), updateJobEvent.getEquipmentID(), TWIN_JOB_TYPE);
            if(twinTandemJob != null){
            	logger.logMsg(LOG_LEVEL.INFO, updateJobEvent.getUserID(), 
            			"Performing Tandem on already twinned jobs, removing the previous record -" + twinTandemJob);
            	JournalEvent journal = new JournalEvent(twinTandemJob, UPDATETYPE.DELETE);
                getSender().tell(journal, null);
            }
            
            if(updateJobEvent.getContainerIDs().length == 4){
            	TwinTandemJobs nextTwinTandemJob = HibernateUtil.getTwinTandemJob(updateJobEvent.getContainerIDs()[2], 
                        allocation.getRotationID(), updateJobEvent.getEquipmentID(), TWIN_JOB_TYPE);
                if(nextTwinTandemJob != null){
                	logger.logMsg(LOG_LEVEL.INFO, updateJobEvent.getUserID(), 
                			"Performing Tandem on already twinned jobs, removing the previous record -" + nextTwinTandemJob);
                	JournalEvent journal = new JournalEvent(nextTwinTandemJob, UPDATETYPE.DELETE);
                    getSender().tell(journal, null);
                }
            }
        }        
              
        jobs.setRotationId(allocation.getRotationID());
        
        jobs.setSparcsTwinIndicator("N");
        jobs.setTerminalId(updateJobEvent.getTerminalID());
        jobs.setTwinSplit("N");
        
        for(TwinTandemContainerList twinTandemContainer:containerDetails){
            twinTandemContainer.setTwinTandemId(jobs);
            jobs.getTwinTandemDetails().add(twinTandemContainer);
        }        
        
        JournalEvent journal = new JournalEvent(jobs, UPDATETYPE.ADD);
        getSender().tell(journal, null);
    }

    /**
     * Splits the containers which are marked as Tandem to single. Even if it was two 20" twins marked as tandem, all
     * the four containers will be marked as single after the tandem split.
     * 
     * @param jobList
     * @param containerIDs
     */
    private void performTandemSplit(ListOrderedMap<String, JobListContainer> jobList, 
            UpdateJobRequestEvent updateJobEvent) {
        JobListContainer container;
        for (String containerId : updateJobEvent.getContainerIDs()) {
            containerId = containerId.replace("#", "");
            
            container = jobList.get(containerId+updateJobEvent.getMoveType());            
            if (container != null) {
                container.setTandemContainerIDs(null);
                container.setTwinContainerId(null);
                container.setManuallyOverridden(false);
            }
        } 
        
        updateTwinTandemRecord(updateJobEvent);
        EventUtil.getInstance().initiateRefreshJobList(updateJobEvent.getUserID());        
    }
    
    /**
     * Updates/Deletes the twin tandem record stored in Database. If user is performing Twin Split, then verifies whether
     * the twin was done by SPARCS. In such case, the Record is updated to indicate that the twin is split by user.
     * All other cases, the record is deleted from DB.
     * @param updateJobEvent
     */
    private void updateTwinTandemRecord(UpdateJobRequestEvent updateJobEvent){
        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                .getAllocationDetails(updateJobEvent.getUserID());  
        String jobType = TWIN_JOB_TYPE;
        if(JOB_UPDATE_TYPE.TANDEM.equals(updateJobEvent.getUpdateType()) || JOB_UPDATE_TYPE.TANDEM_SPLIT.equals(updateJobEvent.getUpdateType())){
        	jobType = TANDEM_JOB_TYPE;
        }
        TwinTandemJobs twinTandemJob = HibernateUtil.getTwinTandemJob(updateJobEvent.getContainerIDs()[0], 
                allocation.getRotationID(), updateJobEvent.getEquipmentID(), jobType);
                
        if(twinTandemJob != null){
           if("Y".equals(twinTandemJob.getSparcsTwinIndicator())){
               twinTandemJob.setTwinSplit("Y");
               JournalEvent journal = new JournalEvent(twinTandemJob, UPDATETYPE.UPDATE);
               getSender().tell(journal, null);
           } else {
        	   List<TwinTandemJobs> jobs = new ArrayList<TwinTandemJobs>();
        	   jobs.add(twinTandemJob);
        	   OpusQCJobListDAO.getInstnace().deleteTwinJobsForTandemSplit(jobs);
           }                      
        }
    }

    /**
     * Marks the specified containers as Twin on the job list. Also if the order of the containers are not in sequence
     * in the job list, reorder the containers position in the job list to make it sequential. Also mark the containers
     * as manually overridden to exclude from the periodic job list update comparison
     * 
     * @param jobList
     * @param containerIDs
     * @param userId
     */
    private Set<TwinTandemContainerList> performTwinUpdate(ListOrderedMap<String, JobListContainer> jobList, String[] containerIDs,
            String userId, OPERATOR role, String moveType) {
        
        JobListContainer container1;
        JobListContainer container2;
        container1 = jobList.get(containerIDs[0]+moveType);
            container2 = jobList.get(containerIDs[1]+moveType);
        
        Set<TwinTandemContainerList> containerDetails = null;
        
        if(container1 != null){
            container1.setTwinContainerId(containerIDs[1]);
            container1.setManuallyOverridden(true);
        }
        if(container2 != null){
            container2.setTwinContainerId(containerIDs[0]);
            container2.setManuallyOverridden(true);
        }

        if(container1 != null && container2 != null){
            int container1Index;
            int container2Index;
            container1Index = jobList.indexOf(container1.getContainerId()+moveType);
            container2Index = jobList.indexOf(container2.getContainerId()+moveType);
           
            if (container1Index == (container2Index - 1)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "The Jobs are already in sequence");
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        "The Jobs are not in sequence, moving " + container2.getContainerId());
                jobList.remove(container2.getContainerId()+moveType);
                jobList.put(container1Index + 1, container2.getContainerId()+moveType, container2);
            }
            
            containerDetails = new HashSet<TwinTandemContainerList>(1);
            containerDetails.add(new TwinTandemContainerList(container1.getContainerId(), 
                    container1.getToLocation(), container1.getFromLocation(), container2.getContainerId(),
                    container2.getFromLocation(), container2.getToLocation()));
        } 
        
        return containerDetails;
    }

    /**
     * performs the tandem update on the job list. All the specified containers are bind together as Tandem in the job
     * list, also if the order of the containers are not in sequence in the job list, reorder the containers position in
     * the job list to make it sequential. Also mark the containers as manually overridden to exclude from the periodic
     * job list update comparison
     * 
     * @param jobList
     * @param containerIDs
     * @param userId
     */
    private Set<TwinTandemContainerList> performTandemUpdate(ListOrderedMap<String, JobListContainer> jobList, 
            String[] containerIDs, String userId, String moveType) {
        String[] tandems;
        int container1Index = jobList.indexOf(containerIDs[0]+moveType);
        int counter = 0;
        int nextContainerIndex;

        Set<TwinTandemContainerList> containerDetails = new HashSet<TwinTandemContainerList>();
        for (String containerId : containerIDs) {
            JobListContainer container = jobList.get(containerId+moveType);
            container.setManuallyOverridden(true);

            int tandemIndex = 0;
            tandems = new String[containerIDs.length - 1];
            for (int count = 0; count < containerIDs.length; count++) {
                if (containerId.equals(containerIDs[count])) {
                    continue;
                } else {
                    tandems[tandemIndex] = containerIDs[count];
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "Marking " + tandems[tandemIndex]
                            + "as TANDEM reference containers for " + containerId);
                    tandemIndex++;
                }
            }

            container.setTandemContainerIDs(tandems);

            nextContainerIndex = jobList.indexOf(container.getContainerId()+moveType);                       
            if (counter != 0 && (container1Index + counter) != nextContainerIndex) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        "The Jobs are not in sequence, moving " + container.getContainerId());

                jobList.remove(container.getContainerId()+moveType);
                jobList.put(container1Index + counter, container.getContainerId()+moveType, container);
            }
            counter++;
            
            JobListContainer refContainer = jobList.get(container.getTwinContainerId()+moveType);
            if(refContainer != null){
                if(!isMentionedAsReferenceContainer(containerDetails, refContainer.getContainerId())){
                    containerDetails.add(new TwinTandemContainerList(container.getContainerId(), 
                            container.getToLocation(), container.getFromLocation(), refContainer.getContainerId(),
                            refContainer.getFromLocation(), refContainer.getToLocation()));
                }
            }else {
            	if(counter == 1){
            		refContainer = jobList.get(containerIDs[counter]+moveType);
            		containerDetails.add(new TwinTandemContainerList(container.getContainerId(), 
                        container.getToLocation(), container.getFromLocation(), refContainer.getContainerId(),
                        refContainer.getFromLocation(), refContainer.getToLocation()));
            	}
            }
        }
        return  containerDetails;
    }

    /**
     * Checks whether the specified container is already mentioned as Reference container to a record. If so, return false
     * @param containerDetails
     * @param containerId
     * @return
     */
    private boolean isMentionedAsReferenceContainer(Set<TwinTandemContainerList> containerDetails, String containerId) {
        boolean status = false;
        
        for (TwinTandemContainerList twinTandemContainer : containerDetails){
            if(twinTandemContainer.getRefContainerId().equals(containerId) || twinTandemContainer.getContainerId().equals(containerId)){
                return true;
            }
        }
        return status;
    }
}
