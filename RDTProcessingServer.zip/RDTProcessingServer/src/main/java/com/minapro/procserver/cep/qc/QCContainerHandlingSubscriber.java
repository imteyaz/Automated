package com.minapro.procserver.cep.qc;

import java.util.Map;

import akka.actor.ActorRef;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.ContainerDetectionEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/*
 * 
 * <p> Class responsible for detecting the Container handling  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCContainerHandlingSubscriber implements StatementSubscriber {

    private ActorRef masterActor;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QCContainerHandlingSubscriber.class);

    public QCContainerHandlingSubscriber() {
        this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    @Override
    public String getStatement() {

        // QC Container Handling EPL Statement

        return "context EachQC select event1, event2 from pattern[every (((event1=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = lockedUpTagValue)) or "
                + "(event1=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue)) or "
                + "(EsperPLCEvent(tagName = 'SpreaderTwinLock1' and tagValue=lockedUpTagValue)) or "
                + "(EsperPLCEvent(tagName = 'SpreaderTwinLock2' and tagValue=lockedUpTagValue))) "
                + "-> ((event2=EsperPLCEvent(tagName = 'NettoLoad_WS' and tagValue > weight_threshold)) or "
                + "(event2=EsperPLCEvent(tagName = 'NettoLoad_LS' and tagValue > ls_weight_threshold))))]";

    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {

        EsperPLCEvent plc1 = eventMap.get("event1");
        EsperPLCEvent plc2 = eventMap.get("event2");
        String node = plc1.getNode();

        double weight = plc2.getTagValue();
        String containerWeight = Double.toString(weight);

        String spreaderId = plc1.getTagName();

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        if (userId != null) {

            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Container Lifted event Detected");

            boolean isLifted = RDTPLCCacheManager.getInstance().getContainerLiftedDetails(userId);

            // Check if this event is already captured because event comes on every 5 sec
            if (!isLifted) {

                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);
                sb.append("\n* CONTAINER LIFTED BY USER " + userId + " ON " + node + " With " + spreaderId);
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "Received plc1 event :" + plc1);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "Received plc2 event :" + plc2);
                
                EventUtil.getInstance().checkAndTriggerOpenEndDelay(userId, node); 

                RDTPLCCacheManager.getInstance().addLiftedContainerWeight(userId, containerWeight);

                // Capturing with which spreader container is lifted
                RDTPLCCacheManager.getInstance().addworkingSpreaderMaping(userId, spreaderId);

                // setting flag to ignore lock event once the handling is captured
                RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, true);

                ContainerDetectionEvent detectionEvent = new ContainerDetectionEvent();

                detectionEvent.setNode(node);
                detectionEvent.setUserId(userId);
                detectionEvent.setSpreaderId(plc1.getTagName());

                boolean firstTimeflag = RDTPLCCacheManager.getInstance().getFirstTimeMapping(userId);

                if (!firstTimeflag) {

                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "SENDING DETECTION TO CONTAINER ACTOR");
                    masterActor.tell(detectionEvent, null);

                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "First Time Job Needs to be confirmed manually :");

                    // Resetting number of locks to zero because automation not started yet
                    RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
                }

            }

        }
    }
}
