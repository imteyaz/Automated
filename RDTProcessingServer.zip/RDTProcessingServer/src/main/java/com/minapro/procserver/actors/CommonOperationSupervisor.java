package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.common.AccidentIncidentActor;
import com.minapro.procserver.actors.common.AllocationActor;
import com.minapro.procserver.actors.common.BaywiseContainersActor;
import com.minapro.procserver.actors.common.CertificateValidationActor;
import com.minapro.procserver.actors.common.CheckListInspectionActor;
import com.minapro.procserver.actors.common.ConfirmAllocationResponseActor;
import com.minapro.procserver.actors.common.DLMActor;
import com.minapro.procserver.actors.common.DelayConfirmationActor;
import com.minapro.procserver.actors.common.JobSelectionActor;
import com.minapro.procserver.actors.common.JournalActor;
import com.minapro.procserver.actors.common.LanguageActor;
import com.minapro.procserver.actors.common.LoginActor;
import com.minapro.procserver.actors.common.MovesToGoActor;
import com.minapro.procserver.actors.common.OperatorAvailabilityActor;
import com.minapro.procserver.actors.common.OperatorMessageActor;
import com.minapro.procserver.actors.common.RefreshCacheActor;
import com.minapro.procserver.actors.common.TechnicalSupportActor;
import com.minapro.procserver.actors.common.VesselBerthActor;
import com.minapro.procserver.actors.common.VesselBerthSideActor;
import com.minapro.procserver.actors.common.VesselSailActor;
import com.minapro.procserver.db.bayprofile.BerthedVessel;
import com.minapro.procserver.events.common.AccidentIncidentConfirmEvent;
import com.minapro.procserver.events.common.AccidentIncidentRequestEvent;
import com.minapro.procserver.events.common.AlertEvent;
import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.BaywiseContainerDetailsResponseEvent;
import com.minapro.procserver.events.common.CancelInspectionEvent;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.CancelJobSelectionResponseEvent;
import com.minapro.procserver.events.common.CertificateValidateEvent;
import com.minapro.procserver.events.common.CheckListInspectionEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.ConfirmAllocationResponseEvent;
import com.minapro.procserver.events.common.DLMEvent;
import com.minapro.procserver.events.common.DLMResponseEvent;
import com.minapro.procserver.events.common.DelayConfirmationEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.JobSelectionResponseEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.LanguageChangeReqEvent;
import com.minapro.procserver.events.common.LanguagesGetRequestEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LoginResponseEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.LogoutResponseEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.common.MovesToGoRequestEvent;
import com.minapro.procserver.events.common.MovesToGoResponseEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityResponseEvent;
import com.minapro.procserver.events.common.OperatorBreakReasonsEvent;
import com.minapro.procserver.events.common.OperatorMessageResponseEvent;
import com.minapro.procserver.events.common.RefreshVesselEvent;
import com.minapro.procserver.events.common.SealBrokenActor;
import com.minapro.procserver.events.common.SealBrokenRequestEvent;
import com.minapro.procserver.events.common.TechSupportRequestEvent;
import com.minapro.procserver.events.common.TechSupportValuesEvent;
import com.minapro.procserver.events.common.UpdateBayViewResponseEvent;
import com.minapro.procserver.events.common.VesselBerthEvent;
import com.minapro.procserver.events.common.VesselBerthSideResponseEvent;
import com.minapro.procserver.events.common.VesselSailEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for supervising the common operations irrespective of the operator role.
 * 
 * @author Rosemary George
 *
 */
public class CommonOperationSupervisor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CommonOperationSupervisor.class);
	
    /**
     * Actor responsible for handling all login and logout related requests
     */
    private ActorRef loginActor = getContext().actorOf(Props.create(LoginActor.class), "login");

    /**
     * Actor responsible for handling DLM request and response
     */
    private ActorRef dlmActor = getContext().actorOf(Props.create(DLMActor.class).withRouter(new FromConfig()), "dlm");

    /**
     * Actor responsible for handling the allocation event
     */
    private ActorRef allocationActor = getContext().actorOf(
            Props.create(AllocationActor.class).withRouter(new FromConfig()), "allocation");

    /**
     * Actor responsible for certificate validation events
     */
    private ActorRef certificateValidateActor = getContext().actorOf(
            Props.create(CertificateValidationActor.class).withRouter(new FromConfig()), "certificateValidate");

    private ActorRef confirmDelayActor = getContext().actorOf(
            Props.create(DelayConfirmationActor.class).withRouter(new FromConfig()), "delayConfirmation");

    private ActorRef checklistInspectActor = getContext().actorOf(
            Props.create(CheckListInspectionActor.class).withRouter(new FromConfig()), "checklistInspect");

    /**
     * All data which needs to be persisted in Database are forwarded to this actor
     */
    private ActorRef journalActor = getContext().actorOf(Props.create(JournalActor.class).withRouter(new FromConfig()),
            "journal");

    private ActorRef vesselBerthActor = getContext().actorOf(
            Props.create(VesselBerthActor.class).withRouter(new FromConfig()), "vesselBerth");

    private ActorRef bayWiseContainerActor = getContext().actorOf(
            Props.create(BaywiseContainersActor.class).withRouter(new FromConfig()), "bayWiseContainers");

    private ActorRef confirmAllocationResponseActor = getContext().actorOf(
            Props.create(ConfirmAllocationResponseActor.class).withRouter(new FromConfig()),
            "confirmAllocationResponse");

    private ActorRef vesselSailActor = getContext().actorOf(
            Props.create(VesselSailActor.class).withRouter(new FromConfig()), "vesselSail");
    /**
     * Following Actor defined to handle all operations related to OperatorAvailabilityEvent(Operator Break
     * Reasons,Available,Non Available) Added by Umamahesh M
     */
    private ActorRef operatorAvailability = getContext().actorOf(
            Props.create(OperatorAvailabilityActor.class).withRouter(new FromConfig()), "operatorAvailability");
    /**
     * Following Actor Definition For TechnicalSupport
     */
    private ActorRef technicalSupport = getContext().actorOf(
            Props.create(TechnicalSupportActor.class).withRouter(new FromConfig()), "technicalSupport");

    private ActorRef vesselBerthSideActor = getContext().actorOf(
            Props.create(VesselBerthSideActor.class).withRouter(new FromConfig()), "vesselBerthSide");

    private ActorRef languageActor = getContext().actorOf(
            Props.create(LanguageActor.class).withRouter(new FromConfig()), "languageActor");

    private ActorRef refreshCacheActor = getContext().actorOf(
            Props.create(RefreshCacheActor.class).withRouter(new FromConfig()), "RefreshCache");

    private ActorRef alertActor = getContext().actorOf(Props.create(AlertActor.class).withRouter(new FromConfig()),
            "Alert");

    private ActorRef sealBrokenActor = getContext().actorOf(
            Props.create(SealBrokenActor.class).withRouter(new FromConfig()), "SealBroken");
    
    private ActorRef jobSelectionActor = getContext().actorOf(
            Props.create(JobSelectionActor.class).withRouter(new FromConfig()), "JobSelection");
    
    private ActorRef accidentIncidentActor = getContext().actorOf(
            Props.create(AccidentIncidentActor.class).withRouter(new FromConfig()), "AccidentIncident");
    
    private ActorRef movesToGoActor = getContext().actorOf(
            Props.create(MovesToGoActor.class).withRouter(new FromConfig()), "MovesToGo");
    
    private ActorRef operatorMessageActor = getContext().actorOf(
            Props.create(OperatorMessageActor.class).withRouter(new FromConfig()), "OperatorMessage");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {

                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    public void onReceive(Object message) throws Exception {
    	
    	logger.logMsg(LOG_LEVEL.DEBUG, message.getClass().getSimpleName(), "Received at CommonOperationSupervisor");
        /*
         * Received the input message from devices, send it to parseActor to convert to POJO
         */
        if (message instanceof LoginEvent || message instanceof LoginResponseEvent 
        		|| message instanceof LogoutEvent || message instanceof LogoutResponseEvent) {
            loginActor.tell(message, getSelf());
        } else if (message instanceof DLMEvent || message instanceof DLMResponseEvent) {
            dlmActor.tell(message, getSelf());
        } else if (message instanceof AllocationEvent || message instanceof ConfirmAllocationEvent) {
            allocationActor.tell(message, getSelf());
        } else if (message instanceof CertificateValidateEvent) {
            certificateValidateActor.tell(message, getSelf());
        } else if (message instanceof DelayConfirmationEvent) {
            confirmDelayActor.tell(message, getSelf());
        } else if (message instanceof JournalEvent) {
            journalActor.tell(message, getSelf());
        } else if (message instanceof CheckListInspectionEvent || message instanceof CancelInspectionEvent) {
            checklistInspectActor.tell(message, getSelf());
        } else if (message instanceof VesselBerthEvent || message instanceof BerthedVessel) {
            vesselBerthActor.tell(message, getSelf());
        } else if (message instanceof BaywiseContainerDetailsResponseEvent
                || message instanceof UpdateBayViewResponseEvent) {
            bayWiseContainerActor.tell(message, getSelf());
        } else if (message instanceof ConfirmAllocationResponseEvent) {
            confirmAllocationResponseActor.tell(message, getSelf());
        } else if (message instanceof VesselSailEvent) {
            vesselSailActor.tell(message, getSelf());
        } else if (message instanceof OperatorBreakReasonsEvent || message instanceof OperatorAvailabilityEvent
                || message instanceof OperatorAvailabilityResponseEvent) {
            operatorAvailability.tell(message, getSelf());
        } else if (message instanceof VesselBerthSideResponseEvent) {
            vesselBerthSideActor.tell(message, getSelf());
        } else if (message instanceof LanguagesGetRequestEvent || message instanceof LanguageChangeReqEvent) {
            languageActor.tell(message, getSelf());
        } else if (message instanceof RefreshVesselEvent) {
            refreshCacheActor.tell(message, getSelf());
        } else if (message instanceof AlertEvent || message instanceof MinaProAlertEvent) {
            alertActor.tell(message, getSelf());
        } else if (message instanceof TechSupportRequestEvent || message instanceof TechSupportValuesEvent) {
            technicalSupport.tell(message, getSelf());
        } else if (message instanceof SealBrokenRequestEvent) {
            sealBrokenActor.tell(message, getSelf());
        } else if (message instanceof JobSelectionEvent || message instanceof CancelJobSelectionEvent 
        		|| message instanceof JobSelectionResponseEvent || message instanceof CancelJobSelectionResponseEvent) {
            jobSelectionActor.tell(message, getSelf());
        } else if (message instanceof AccidentIncidentRequestEvent || message instanceof AccidentIncidentConfirmEvent) {
        	accidentIncidentActor.tell(message, getSelf());
        } else if (message instanceof MovesToGoRequestEvent || message instanceof MovesToGoResponseEvent) {
        	movesToGoActor.tell(message, getSelf());
        } else if (message instanceof OperatorMessageResponseEvent) {
        	operatorMessageActor.tell(message, getSelf());
        }else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, null);
        }
    }
}
