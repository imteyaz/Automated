package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details about the login delay confirmation event from the device
 * 
 * @author kalyani
 * 
 */
public class ManualDelayRecordingConfirmationEvent extends Event implements Serializable {
   
    private static final long serialVersionUID = 4833808663307974728L;

    /**
     * The new delay records created by the user
     * 
     * will be in the format - delayCode^equipmentId^startTime^endTime|delayCode^equipmentId^startTime^endTime
     */
    private String newDelayDetails;

    /**
     * The delay records closed by the user
     * 
     * will be in the format - delayId1^endTime|delayId^endTime
     */
    private String updateDelayDetails;

    public String getNewDelayDetails() {
        return newDelayDetails;
    }

    public void setNewDelayDetails(String newDelayDetails) {
        this.newDelayDetails = newDelayDetails;
    }

    public String getUpdateDelayDetails() {
        return updateDelayDetails;
    }

    public void setUpdateDelayDetails(String updateDelayDetails) {
        this.updateDelayDetails = updateDelayDetails;
    }

    @Override
    public String toString() {
        return "ManualDelayRecordingConfirmationEvent [newDelayDetails=" + newDelayDetails + ", updateDelayDetails="
                + updateDelayDetails + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
