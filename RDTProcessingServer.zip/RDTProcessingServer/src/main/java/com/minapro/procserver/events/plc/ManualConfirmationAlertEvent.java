package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ManualConfirmationAlertEvent extends Event implements Serializable {

    private static final long serialVersionUID = -2845186745360466085L;

    private String reason;
    
    private String beepRequired = "true";

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "ManualConfirmationAlertEvent [reason=" + reason + ", getReason()=" + getReason() + "]";
    }

	public String getBeepRequired() {
		return beepRequired;
	}

	public void setBeepRequired(String beepRequired) {
		this.beepRequired = beepRequired;
	}

}
