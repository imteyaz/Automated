package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * ValueObject holding the role details.
 * 
 * @author 3123248
 *
 */
@Entity
@Table(name = "MP_GRPDTLS_AM")
public class UserRole implements Serializable {

    private static final long serialVersionUID = -8129649637268439863L;
    private int roleId;
    private String roleName;
    private String description;

    /**
     * The Checklist headers associated with the user role
     */
    private Set<CheckListHeader> checkListHeaderSet = new HashSet<CheckListHeader>();

    private String userGroupCd;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String adtInsUserName;
    private String adtUpdUserName;
    private Date adtInsDatTime;
    private Date adtUpdDatTime;
    private String srvTypeGroupCd;
    private String isDeleted;

    @Column(name = "USER_GRP_CD")
    public String getUserGroupCd() {
        return userGroupCd;
    }

    public void setUserGroupCd(String userGroupCd) {
        this.userGroupCd = userGroupCd;
    }

    @Column(name = "ADT_INS_FUNCTION_CD")
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }

    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }

    @Column(name = "ADT_UPD_FUNCTION_CD")
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }

    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }

    @Column(name = "ADT_INS_USER_NM")
    public String getAdtInsUserName() {
        return adtInsUserName;
    }

    public void setAdtInsUserName(String adtInsUserName) {
        this.adtInsUserName = adtInsUserName;
    }

    @Column(name = "ADT_UPD_USER_NM")
    public String getAdtUpdUserName() {
        return adtUpdUserName;
    }

    public void setAdtUpdUserName(String adtUpdUserName) {
        this.adtUpdUserName = adtUpdUserName;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getAdtInsDatTime() {
        return adtInsDatTime;
    }

    public void setAdtInsDatTime(Date adtInsDatTime) {
        this.adtInsDatTime = adtInsDatTime;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getAdtUpdDatTime() {
        return adtUpdDatTime;
    }

    public void setAdtUpdDatTime(Date adtUpdDatTime) {
        this.adtUpdDatTime = adtUpdDatTime;
    }

    @Column(name = "SRV_TYPE_GRP_CD")
    public String getSrvTypeGroupCd() {
        return srvTypeGroupCd;
    }

    public void setSrvTypeGroupCd(String srvTypeGroupCd) {
        this.srvTypeGroupCd = srvTypeGroupCd;
    }

    @Id
    @Column(name = "INT_USER_GRP_ID", nullable = false)
    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    @Column(name = "USER_GRP_NM", nullable = false)
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Column(name = "S_DESCR")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MP_CHECKLIST_ROLE_MAP", joinColumns = { @JoinColumn(name = "INT_USER_GRP_ID") }, inverseJoinColumns = { @JoinColumn(name = "CHECKLIST_HDR_ID") })
    public Set<CheckListHeader> getCheckListHeaderSet() {
        return checkListHeaderSet;
    }

    public void setCheckListHeaderSet(Set<CheckListHeader> checkListHeaderSet) {
        this.checkListHeaderSet = checkListHeaderSet;
    }

    @Column(name = "ISDELETED")
    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
