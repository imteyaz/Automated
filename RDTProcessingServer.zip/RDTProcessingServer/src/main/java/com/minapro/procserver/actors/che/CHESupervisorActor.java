package com.minapro.procserver.actors.che;

import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.routing.FromConfig;

import com.minapro.procserver.actors.CHEJobListActor;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.BlockWiseContainersResponseEvent;
import com.minapro.procserver.events.che.CHEJobListEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateResponseEvent;
import com.minapro.procserver.events.che.NewLocationRequestEvent;
import com.minapro.procserver.events.che.NewLocationResponseEvent;
import com.minapro.procserver.events.che.ReeferConnectionResponseEvent;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.che.ShuffleResponseEvent;
import com.minapro.procserver.events.che.StackViewRequestEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersResponseEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for handling CHE related all operations.
 * 
 * @author Umamahesh M
 */
public class CHESupervisorActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHESupervisorActor.class);
	
    /**
     * 
     * Following actor is responsible for handling OrphanContainer event related messages
     * 
     */
	
	private ActorRef cheJobListActor = getContext().actorOf(Props.create(CHEJobListActor.class).withRouter(new FromConfig()),
	            "cheJobList");
	
    private ActorRef yardViewActor = getContext().actorOf(
            Props.create(BlockViewRequestActor.class).withRouter(new FromConfig()), "yardView");

    private ActorRef blockWiseContainerActor = getContext().actorOf(
            Props.create(BlockViewResponseActor.class).withRouter(new FromConfig()), "blockWiseContainer");

    private ActorRef stackViewActor = getContext().actorOf(
            Props.create(StackViewRequestActor.class).withRouter(new FromConfig()), "stackViewActor");

    private ActorRef cheLivePerformanceActor = getContext().actorOf(
            Props.create(CHELivePerformanceActor.class).withRouter(new FromConfig()), "chePerformanceActor");

    private ActorRef reeferStatusActor = getContext().actorOf(
            Props.create(ReeferStatusResponseActor.class).withRouter(new FromConfig()), "reeferStatusActor");

    private ActorRef newLocationActor = getContext().actorOf(
            Props.create(NewLocationRequestActor.class).withRouter(new FromConfig()), "newLocationActor");

    private ActorRef newLocationResponseActor = getContext().actorOf(
            Props.create(NewLocationResponseActor.class).withRouter(new FromConfig()), "newLocationResponseActor");

   private ActorRef inventoryUpdateActor = getContext().actorOf(
           Props.create(InventoryUpdateRequestActor.class).withRouter(new FromConfig()), "inventoryUpdateActor");

   private ActorRef shuffleActor  = getContext().actorOf(Props.create(ShuffleJoblistRequestActor.class).withRouter(new FromConfig()),
		   "shuffleActor");
   
    @Override
    public void onReceive(Object message) throws Exception {
    	logger.logMsg(LOG_LEVEL.DEBUG, message.getClass().getSimpleName(), "Received at CHESupervisorActor");
        if (message instanceof BlockViewRequestEvent) {
            yardViewActor.tell(message, getSelf());
        } else if (message instanceof BlockWiseContainersResponseEvent) {
            blockWiseContainerActor.tell(message, getSelf());
        } else if (message instanceof StackViewRequestEvent) {
            stackViewActor.tell(message, getSelf());
        } else if (message instanceof EsperRMGPLCEvent) {
            cheLivePerformanceActor.tell(message, getSelf());

        } else if (message instanceof ReeferConnectionResponseEvent) {
            reeferStatusActor.tell(message, getSelf());
        } else if (message instanceof NewLocationRequestEvent) {
            newLocationActor.tell(message, getSelf());
        } else if (message instanceof NewLocationResponseEvent) {
            newLocationResponseActor.tell(message, getSelf());
        } else if (message instanceof CHEJobListEvent || message instanceof CHEJobListRequestEvent || message instanceof UpdateBlockContainersResponseEvent) {
            cheJobListActor.tell(message, getSelf());
        } else if(message instanceof InventoryUpdateRequestEvent || message instanceof InventoryUpdateResponseEvent) {
        	inventoryUpdateActor.tell(message,getSelf());
        } else if(message instanceof ShuffleRequestEvent || message instanceof ShuffleResponseEvent){
        	shuffleActor.tell(message,getSelf());
        }else {
            unhandled(message);
        }
    }

}
