package com.minapro.procserver.util;

public interface CHEJobListSequenceCalulatorInterface {

	public double getMoveKindComputedValue(WeightageCriteria weightageCriteria) ;
	
	public double getContainerTypeComputedValue(WeightageCriteria weightageCriteria);
	
	public double getContainerSizeComputedValue(WeightageCriteria weightageCriteria);

	public double getContaierStatusComputedValue(WeightageCriteria weightageCriteria);

	public double getVesselTypeComuptedValue(WeightageCriteria weightageCriteria);
	
	public double getVesselLocationComputedValue(WeightageCriteria weightageCriteria);
	
}
