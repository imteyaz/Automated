package com.minapro.procserver.db.alert;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding the Alert Parameter mappings
 * 
 * @author Rosemary George
 */
@Entity
@Table(name = "MP_ALERT_PARAMETER_MAPPING")
public class AlertParameterAssociation implements Serializable {

	private static final long serialVersionUID = 8838710641773671727L;

	@Id
	@Column(name = "ALERT_PARAM_MAP_ID", nullable = false)
	private Integer alertParamId;

	@Column(name = "ALERT_CODE", nullable = false)
	private String alertCode;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PARAMETER_ID", referencedColumnName = "PARAMETER_ID")
	private AlertParameterKey paramter;

	public Integer getAlertParamId() {
		return alertParamId;
	}

	public void setAlertParamId(Integer alertParamId) {
		this.alertParamId = alertParamId;
	}

	public String getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(String alertCode) {
		this.alertCode = alertCode;
	}

	public AlertParameterKey getParamter() {
		return paramter;
	}

	public void setParamter(AlertParameterKey paramter) {
		this.paramter = paramter;
	}

	@Override
	public String toString() {
		return "AlertParameterAssociation [alertCode=" + alertCode + ", paramter=" + paramter.getParamName() + "]";
	}

}
