package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.MovesToGoContainers;
import com.minapro.procserver.events.common.MovesToGoRequestEvent;
import com.minapro.procserver.events.common.MovesToGoResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor Responsible for handling the moves to go request from devices.
 * 
 * Moves to go can be 
 * 
 * @author Rosemary George
 *
 */
public class MovesToGoActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(MovesToGoActor.class);
	
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);
	private static final String COLUMN_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY);

	private static final String CONTAINER_20_SIZE = "20";
	private static final String CONTAINER_40_SIZE = "40";
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof MovesToGoRequestEvent){
			MovesToGoRequestEvent requestEvent = (MovesToGoRequestEvent)message;
			handleMovesToGoRequest(requestEvent);
		}else if(message instanceof MovesToGoResponseEvent){
			MovesToGoResponseEvent responseEvent = (MovesToGoResponseEvent)message;
			handleMovesToGoResponseFromESB(responseEvent);
		}else {
			getSender().tell(message, null);
		}
	}

	/**
	 * Handles the MovesToGo Response event from ESB and constructs the response back to the UI.
	 * 
	 * MovesToGoDetails will be filled in the below format
	 * DSCH^20|full_general_cnt|full_oog_cnt|empty_gnr_cnt|empty_oog_count^40|full_general_cnt|full_oog_cnt|empty_gnr_cnt|empty_oog_count$
	 * LOAD^20|full_general_cnt|full_oog_cnt|empty_gnr_cnt|empty_oog_count^40|full_general_cnt|full_oog_cnt|empty_gnr_cnt|empty_oog_count
	 * 
	 * @param responseEvent
	 */
	private void handleMovesToGoResponseFromESB(MovesToGoResponseEvent responseEvent) {
		logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(), "Received MovesToGo request event " + responseEvent);
		StringBuilder movesToGoDetails = new StringBuilder();
		
		try {
			if(responseEvent.getMovesToGoList() != null && !responseEvent.getMovesToGoList().isEmpty()){
				int currentSize = 0;
				String currentMoveType = "";
				
				/**
				 * two dimensional array will be filled as 
				 * [0][] = 20 feet container counts(full_general_cnt,full_oog_cnt,empty_gnr_cnt,empty_oog_count)
				 * [1][] = 40 feet container counts(full_general_cnt,full_oog_cnt,empty_gnr_cnt,empty_oog_count)
				 */
				Integer[][] dischargeContainerCounts = new Integer[2][4];
				Integer[][] loadContainerCounts = new Integer[2][4];
				Integer[] tempArray = new Integer[4];
				MovesToGoContainers movesToGOCount;
				for(int itr=0; itr<responseEvent.getMovesToGoList().size(); itr++){
					movesToGOCount = responseEvent.getMovesToGoList().get(itr);
					if(currentSize != 0 && currentSize != movesToGOCount.getContainerSize()){
						fillContainerCounts(currentMoveType, currentSize, dischargeContainerCounts, loadContainerCounts, tempArray);
						tempArray = new Integer[4];
					}
					
					if(movesToGOCount.isEmpty()){
						if(movesToGOCount.isOog()){
							tempArray[3] = movesToGOCount.getContainerCount();
						}else {
							tempArray[2] = movesToGOCount.getContainerCount();
						}
					}else {
						if(movesToGOCount.isOog()){
							tempArray[1] = movesToGOCount.getContainerCount();
						}else {
							tempArray[0] = movesToGOCount.getContainerCount();
						}
					}				
					
					currentSize = movesToGOCount.getContainerSize();
					currentMoveType = movesToGOCount.getMoveType();	
					
					//in the last iteration, fill directly
					if(itr == responseEvent.getMovesToGoList().size()-1){
						fillContainerCounts(currentMoveType, currentSize, dischargeContainerCounts, loadContainerCounts, tempArray);						
					}
				}
				
				constructMovesToGoDetails(dischargeContainerCounts, DSCH, movesToGoDetails);
				movesToGoDetails.append(COLUMN_SEPARATOR);
				constructMovesToGoDetails(loadContainerCounts, LOAD, movesToGoDetails);
			}else {
				logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(), "Received empty movesToGoList");
			}
			
			sendResponseToDevice(responseEvent, movesToGoDetails.toString());
		}catch(Exception ex){
			logger.logException("Caught exception while handling the handleMovesToGoRequest", ex);
			sendResponseToDevice(responseEvent, "");
		}	
	}
	
	/**
	 * Fills the container count details from the array to the movesToGoDetails in the UI expected message format
	 * 
	 * @param containerCounts
	 * @param moveType
	 * @param movesToGoDetails
	 */
	private void constructMovesToGoDetails(Integer[][] containerCounts, String moveType, StringBuilder movesToGoDetails) {
		
		movesToGoDetails.append(moveType).append(ITEM_SEPARATOR).append(CONTAINER_20_SIZE);
		
		for(int i=0; i<containerCounts.length; i++){
			if(i==1){
				movesToGoDetails.append(ITEM_SEPARATOR).append(CONTAINER_40_SIZE);
			}
			for(int j=0; j<containerCounts[i].length; j++){
				movesToGoDetails.append(ROW_SEPARATOR).append(containerCounts[i][j]);
			}					
		}		
	}

	/**
	 * Fill the container counts from filledArray to the dschArray or loadArray based on the current size and moveType.	 * 
	 * 
	 * @param currentMoveType
	 * @param currentSize
	 * @param dschArray
	 * @param loadArray
	 * @param filledArray
	 */
	private void fillContainerCounts(String currentMoveType, int currentSize, 
			Integer[][] dschArray, Integer[][] loadArray, Integer[] filledArray){
		if(currentSize == 20){
			if(currentMoveType.equals(DSCH)){
				dschArray[0] = filledArray;
			}else {
				loadArray[0] = filledArray;
			}
		}else {
			if(currentMoveType.equals(DSCH)){
				dschArray[1] = filledArray;
			}else {
				loadArray[1] = filledArray;
			}
		}
	}

	/**
	 * Handles the moves to go request from device. 
	 * If there are plannedContainers present for the logged in rotation, 
	 * 
	 * @param requestEvent
	 */
	private void handleMovesToGoRequest(MovesToGoRequestEvent requestEvent) {
		logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Received MovesToGo request event " + requestEvent);
		
		try {
			String rotationId = "";
			ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
					.getAllocationDetails(requestEvent.getUserID());
			if(allocationDetails != null){
				rotationId = allocationDetails.getRotationID();
			}
			
			Map<String, CompletedContainerMoves> completedJobs = RDTCacheManager.getInstance().getCompletedJobs(rotationId, requestEvent.getQcId());
			PlannedMovesEvent plannedMoves = RDTPLCCacheManager.getInstance().getPlannedMoves(requestEvent.getQcId());

			Collection<String> movesToGoContainers = null;
			if(plannedMoves != null && plannedMoves.getPlannedContainerIds() != null 
					&& !plannedMoves.getPlannedContainerIds().isEmpty()){
				movesToGoContainers = plannedMoves.getPlannedContainerIds();
				logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Planned moves size is " + movesToGoContainers.size());	
				
				if(completedJobs != null && !completedJobs.isEmpty()){
					logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Completed jobs size is " + completedJobs.size());	
					//TODO::Instead Of KeySet Different Logic Needs to apply
					movesToGoContainers = CollectionUtils.subtract(plannedMoves.getPlannedContainerIds(), 
							completedJobs.keySet());					
				}

				logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Final size of querying containers is " + movesToGoContainers.size());	
				requestEvent.setMovesToGoContainerIds((List<String>) movesToGoContainers);
				requestEvent.setRotationId(rotationId);
				ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.COMMON, requestEvent.getTerminalID());
			}else {
				logger.logMsg(LOG_LEVEL.DEBUG, requestEvent.getUserID(), "No planned moves containers found. Sending empty response");
				sendResponseToDevice(requestEvent, "");
			}			
		}catch(Exception ex){
			logger.logException("Caught exception while handling the handleMovesToGoRequest", ex);
			sendResponseToDevice(requestEvent, "");
		}		
	}

	/**
	 * Constructs and sends the moves to go details to the requested user
	 * @param requestEvent
	 * @param movesToGoDetails
	 */
	private void sendResponseToDevice(Event requestEvent, String movesToGoDetails) {

		try {
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(
					RDTProcessingServerConstants.MOVES_TO_GO_RESPONSE);

			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP).append(VALUE_SEPARATOR).append(eventTypeID);

			responseToDevice.append(VALUE_SEPARATOR).append(requestEvent.getEventID()).append(VALUE_SEPARATOR)
			.append(movesToGoDetails).append(VALUE_SEPARATOR).append(requestEvent.getUserID())
			.append(VALUE_SEPARATOR).append(requestEvent.getTerminalID());


			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), 
					RDTCacheManager.getInstance().getUserLoggedInRole(requestEvent.getUserID()),requestEvent.getTerminalID());

		} catch (Exception ex) {
			logger.logException("Caught Exception while sendResponseToDevice", ex);
		}
	}	
}
