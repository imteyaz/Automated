package com.minapro.procserver.db.bayprofile;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

/**
 * ValueObject holding the Tier details of a bay of the vessel
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_BAYTIER_SPM")
public class BayTier {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset + tierOffset
     */
    @EmbeddedId
    private BayTierPk pk;

    @Column(name = "VSL_TIER_NO")
    private String vesselTierNo;

    @Column(name = "SECDY_TIER_NO")
    private String secondaryTierNo;

    @Column(name = "TWEENDK_FLG")
    @Type(type = "yes_no")
    private boolean tweenDeckFlag;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false) })
    private VesselSection section;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false)
    private Vessel vessel;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false),
            @JoinColumn(name = "DK_UNDK_IND", referencedColumnName = "DK_UNDK_IND", insertable = false, updatable = false),
            @JoinColumn(name = "BAY_OFFSET", referencedColumnName = "BAY_OFFSET", insertable = false, updatable = false) })
    private Bay bay;

    public BayTierPk getPk() {
        return pk;
    }

    public void setPk(BayTierPk pk) {
        this.pk = pk;
    }

    public String getVesselTierNo() {
        return vesselTierNo;
    }

    public void setVesselTierNo(String vesselTierNo) {
        this.vesselTierNo = vesselTierNo;
    }

    public String getSecondaryTierNo() {
        return secondaryTierNo;
    }

    public void setSecondaryTierNo(String secondaryTierNo) {
        this.secondaryTierNo = secondaryTierNo;
    }

    public boolean isTweenDeckFlag() {
        return tweenDeckFlag;
    }

    public void setTweenDeckFlag(boolean tweenDeckFlag) {
        this.tweenDeckFlag = tweenDeckFlag;
    }

    public VesselSection getSection() {
        return section;
    }

    public void setSection(VesselSection section) {
        this.section = section;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public void setVessel(Vessel vessel) {
        this.vessel = vessel;
    }

    public Bay getBay() {
        return bay;
    }

    public void setBay(Bay bay) {
        this.bay = bay;
    }

    @Transient
    public int getTierOffset() {
        return pk.getTierOffset();
    }

    public void setTierOffset(int tierOffset) {
        pk.setTierOffset(tierOffset);
    }

    @Transient
    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }
}
