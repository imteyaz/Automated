package com.minapro.procserver.db.yardview;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_DATA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.STACK_DATA;
import static com.minapro.procserver.util.BlockViewQueryStatements.GET_BLOCK_CELL_POSITION;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.util.BlockViewQueryStatements;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible to perform all CRUD operations related to yard view
 * 
 * @author UMAMAHESH M
 */
public class BlockViewDao {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockViewDao.class);

    private static final String BLOCK_ID = "blockId";
    private BlockViewDao() {
    }

    /**
     * Method is responsible for retrieving stk_numsrs_id,row_numsrs_id,tier_numsrs_id From database to create stacks
     * and rows message structure.
     * 
     * @return List<Object[]> which consists of stk_numsrs_id ,row_numsrs_id,tier_numsrs_id
     */
    @SuppressWarnings("unchecked")
    public static List<Object[]> getRowAndStackCount(final String blockId) {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" getRowAndStackCount()").append(INPUT)
                .append(blockId).toString());

        Session session = null;
        List<Object[]> result = null;
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            final Transaction tx = session.beginTransaction();
            final String sql = BlockViewQueryStatements.YARD_ROWS_STACKS;

            result = session.createQuery(sql).setParameter(BLOCK_ID, blockId).list();
            tx.commit();

        } catch (final Exception ex) {

            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" getRowAndStackCount() ").append(REASON)
                    .toString(), ex);

        }
        return result;
    }

    /**
     * Method is responsible for getting either list of stacks or list rows depending on rowOrStack input value. If
     * rowOrStack value is RowData get list of available row numbers with sequences else get list of available stacks
     * number along with sequence number.
     * 
     * @param blockId
     *            ,rowOrStack
     * @return List of rows are stacks depending on RowData value.
     */
    @SuppressWarnings("unchecked")
    public static List<Object[]> getStackOrRowData(String blockId, String rowOrStack) {
        logger.logMsg(LOG_LEVEL.INFO, "",
                new StringBuilder(ENTRY).append(" getStackOrRowData()").append(INPUT).append(blockId).append(" ")
                        .append(rowOrStack).toString());

        Session session = null;
        List<Object[]> result = null;
        String sql = "";

        if (ROW_DATA.equals(rowOrStack)) {

            sql = BlockViewQueryStatements.YARD_ROW_DATA;

        } else if (STACK_DATA.equals(rowOrStack)) {

            sql = BlockViewQueryStatements.YARD_STACK_DATA;
        }
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();

            result = session.createQuery(sql).setParameter(BLOCK_ID, blockId).list();
            tx.commit();

        } catch (Exception ex) {

            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" getRowAndStackNo() ").append(REASON)
                    .toString(), ex);
            session.getTransaction().rollback();
        }
        return result;

    }

    /**
     * Method is responsible for retrieving all cell data related to the given block Id.
     * 
     * @param blockId
     * @return List of available containers.
     */
    @SuppressWarnings("unchecked")
    public static List<Object[]> getCellDataForBlockId(String blockId) {
        logger.logMsg(
                LOG_LEVEL.INFO,
                "",
                new StringBuilder(ENTRY).append(" getCellDataForBlockId() to retrive block ground slots Info")
                        .append(INPUT).append(blockId).toString());

        Session session = null;

        List<Object[]> cellData = null;
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction tx = session.beginTransaction();
            String sql = BlockViewQueryStatements.YARD_BLOCK_CELL_DATA;

            cellData = session.createQuery(sql).setParameter(BLOCK_ID, blockId).list();
            tx.commit();

        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("getCellDataForBlockId() ").append(REASON)
                    .toString(), ex);
        }

        return cellData;
    }
    
    /**
     * Method is responsible for retrieving maximum working stack number based on Block Number and Stack Number And Row Name.
     * @param blockNumber
     * @param rowName
     * @param stkNumber
     * @return maximum working stack height of the requested block number.
     */
    @SuppressWarnings("unchecked")
    public static int getBlockMaxWrnkgStkHt(String blockNumber , String rowName , String stkNumber){

    	Session session =null;
    	Transaction transaction =null;
    	int maxWrkngStackNumber = 0;
    	
    	try{
    		session = HibernateUtil.getSessionFactory().getCurrentSession();
    		transaction = session.beginTransaction();
    		
    		List<Object> maxWrkngStack = session.createSQLQuery(GET_BLOCK_CELL_POSITION).setParameter("blockNumber", blockNumber.toUpperCase()).
    				setParameter("rowName", rowName.toUpperCase()).setParameter("stkNumber", Integer.parseInt(stkNumber)).list();
    		
    		maxWrkngStackNumber = maxWrkngStack!=null && !maxWrkngStack.isEmpty() ? maxWrkngStack.get(0)!=null 
    				? Integer.valueOf(maxWrkngStack.get(0).toString()) : 0 : 0;
    		
    		logger.logMsg(LOG_LEVEL.INFO,blockNumber,new StringBuilder(" Maximum Working Stack Height For Current Block Number")
    		.append(blockNumber).append(" Is::").append(maxWrkngStackNumber).toString());
    		
    		transaction.commit();
    		
    	}catch(Exception ex){
    		  logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("getBlockMaxWrnkgStkHt() ").append(REASON)
                      .toString(), ex);
    	}
    	return maxWrkngStackNumber;
    }
    
}
