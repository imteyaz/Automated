package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class ITVWaitingTimePK implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name="ITV_NO")
	private String itvNo;
	
	@Column(name="BLOCK_NO")
	private String blockId;
	
	@Column(name="CONTAINER_NO")
	private String containerId;
	
	public String getITVNo() {
		return itvNo;
	}

	public void setITVNo(String iTVNo) {
		itvNo = iTVNo;
	}

	public String getBlockId() {
		return blockId;
	}

	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

}
