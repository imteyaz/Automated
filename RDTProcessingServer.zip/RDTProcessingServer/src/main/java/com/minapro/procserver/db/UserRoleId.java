package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UserRoleId implements Serializable {
    private static final long serialVersionUID = 1781409215410933313L;

    private int intUserId;
    private int intUserRoleId;

    public UserRoleId() {
    }

    @Column(name = "INT_USER_ID")
    public int getIntUserId() {
        return intUserId;
    }

    public void setIntUserId(int intUserId) {
        this.intUserId = intUserId;
    }

    @Column(name = "INT_USER_GRP_ID")
    public int getIntUserRoleId() {
        return intUserRoleId;
    }

    public void setIntUserRoleId(int intUserRoleId) {
        this.intUserRoleId = intUserRoleId;
    }
}
