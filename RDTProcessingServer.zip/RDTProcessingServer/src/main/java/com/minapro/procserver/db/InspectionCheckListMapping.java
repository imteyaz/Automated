package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * ValueObject holding the many-to-many relationship data for a pre-operational inspection
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_INSPECTION_CHECKLIST_MAP")
@AssociationOverrides({
        @AssociationOverride(name = "pk.inspectionRecord", joinColumns = @JoinColumn(name = "INSPECTION_ID")),
        @AssociationOverride(name = "pk.checkListItem", joinColumns = @JoinColumn(name = "CHECKLIST_ID")) })
public class InspectionCheckListMapping implements Serializable {

    private static final long serialVersionUID = -2190274408185121976L;

    /**
     * Composite Primary key - inspection_id + checklist_id
     */
    @EmbeddedId
    private InspectionCheckListMappingId pk = new InspectionCheckListMappingId();

    @Column(name = "STATUS")
    private String status;

    @Column(name = "REMARKS")
    private String remarks;

    public InspectionCheckListMappingId getPk() {
        return pk;
    }

    public void setPk(InspectionCheckListMappingId pk) {
        this.pk = pk;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Transient
    public InspectionRecord getInspectionRecord() {
        return pk.getInspectionRecord();
    }

    public void setInspectionRecord(InspectionRecord inspectionRecord) {
        pk.setInspectionRecord(inspectionRecord);
    }

    @Transient
    public CheckList getCheckListItem() {
        return pk.getCheckListItem();
    }

    public void setCheckListItem(CheckList item) {
        pk.setCheckListItem(item);
    }
}
