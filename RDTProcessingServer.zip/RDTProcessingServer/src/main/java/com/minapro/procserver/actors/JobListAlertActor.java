package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.util.List;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListAlertEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the alert message coming from ESB. This needs to be sent to the UI
 * 
 * @author Rosemary George
 *
 */
public class JobListAlertActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(JobListAlertActor.class);

    private static final String VLAUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof JobListAlertEvent) {
            
        	JobListAlertEvent alert = (JobListAlertEvent) message;
            alert.setBeepRequired("false");
            
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(alert.getUserID());
          
            logger.logMsg(LOG_LEVEL.INFO,alert.getUserID(),new StringBuilder(alert.getEquipmentID()).
            		append(" Equipment Job Status Is Setting To Completed").toString());
			
			//Setting current equipment Job List request process as completed , to make available for other equipments 
			RDTCacheManager.getInstance().setEqJobListReqStatus(alert.getEquipmentID(),EquipmentJobListRequestStatus.COMPLETED);
            
            logger.logMsg(LOG_LEVEL.WARN, alert.getUserID(), "Received alert message from ESB, sending it to UI -"
                    + alert);

            ListOrderedMap<String, JobListContainer> jobsInCache = RDTCacheManager.getInstance().getJobList(
                    alert.getUserID(), alert.getEquipmentID());

            String messageType = RESP;
            if (alert.isScheduled() || (jobsInCache != null && !jobsInCache.isEmpty())) {
                messageType = NOTIF;
            }

            try {
                String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);

                // get the message format
                List<String> msgFields = EventFormats.getInstance().getEventFields(ALERT_MESSAGE);

                StringBuilder responseToDevice = new StringBuilder(messageType).append(VLAUE_SEPARATOR).append(eventTypeID);
                
                for (int i = 1; i < msgFields.size(); i++) {
                    responseToDevice.append(VLAUE_SEPARATOR);
                    EventUtil.getInstance().getEventParameter(alert, msgFields.get(i), responseToDevice);
                }

                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        alert.getTerminalID());
            } catch (Exception ex) {
                logger.logException("Caught exception while handling the joblist alert-", ex);
                if (!alert.isScheduled()) {
                    sendEmptyJobListResponse(alert, operatorRole);
                }
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * Construct and sends an empty job list response to the user
     * 
     * @param event
     * @param operatorRole
     */
    private void sendEmptyJobListResponse(Event event, OPERATOR operatorRole) {
        logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "Sending empty joblist response as UI expect a response");

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VLAUE_SEPARATOR).append(eventTypeID);

        responseToDevice.append(VLAUE_SEPARATOR).append(event.getEventID()).append(VLAUE_SEPARATOR)
                .append(VLAUE_SEPARATOR).append(event.getUserID()).append(VLAUE_SEPARATOR)
                .append(event.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                event.getTerminalID());
    }
}
