package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the container details for the specified veseel and bay
 * 
 * @author Rosemary George
 *
 */
public class BaywiseContainerDetailsResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = 737669340915630186L;
    /**
     * Indicates the vessel number for which the response is sent from ESB
     */
    private String vesselCode;
    /**
     * Indicates the BayNo queried
     */
    private String bayNo;
    /**
     * Indicates whether the bay is on deck or under deck. Set to D if it is deck, else set to U
     */
    private String underDeckIndication;
    /**
     * For the specified bay, gives the List of all containers present on the vessel or planned for.
     */
    private List<BayProfileContainer> containerList;

    /**
     * Indicates the rotationID for which the response is coming from ESB
     */
    private String rotationID;

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getBayNo() {
        return bayNo;
    }

    public void setBayNo(String bayNo) {
        this.bayNo = bayNo;
    }

    public List<BayProfileContainer> getContainerList() {
        return containerList;
    }

    public void setContainerList(List<BayProfileContainer> containerList) {
        this.containerList = containerList;
    }

    public String getUnderDeckIndication() {
        return underDeckIndication;
    }

    public void setUnderDeckIndication(String underDeckIndication) {
        this.underDeckIndication = underDeckIndication;
    }

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    @Override
    public String toString() {
        return "BaywiseContainerDetailsResponseEvent [vesselCode=" + vesselCode + ", bayNo=" + bayNo
                + ", underDeckIndication=" + underDeckIndication + ", containerList=" + containerList + ", rotationID="
                + rotationID + "]";
    }
}
