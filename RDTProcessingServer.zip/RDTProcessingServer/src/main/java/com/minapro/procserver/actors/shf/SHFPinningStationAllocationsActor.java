package com.minapro.procserver.actors.shf;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SHF_PINNINGSTATION_VIEW_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.PinningStation;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationChangeEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationReqEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for holding all Shore Foreman Pinning station related allocations such as view allocated qc's
 * and pinning stations and change/edit the pinning stations corresponding qc's.
 * 
 * @author UMAMAHESH M
 *
 */
public class SHFPinningStationAllocationsActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(
            SHFPinningStationAllocationsActor.class);

    private static final String PIPE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass()).append(ON_RECEIVE).toString());

        if (message instanceof SHFPinningStationAllocationReqEvent) {
            handleRequestMessage((SHFPinningStationAllocationReqEvent) message);
        } else if (message instanceof SHFPinningStationAllocationChangeEvent) {
            handleAllocationChangeReq((SHFPinningStationAllocationChangeEvent) message);
        } else {
            unhandled(message);
        }

    }

    /**
     * Method is responsible for Changing the QC related Pinning station. QcToPinningStation Cache holds the QC and Its
     * related PinningStation. Calling Cache method with QC and PinningStation Id .
     * 
     * @param AllocationChangeRequestEvent
     *            object. Sample Input message like:2303~783511536~user1~2~Friday 07-aPR-2015
     *            10:44:18~QC1^PS123|QC2^PS234
     * 
     */
    private void handleAllocationChangeReq(SHFPinningStationAllocationChangeEvent message) {

        logger.logMsg(
                LOG_LEVEL.INFO,
                message.getUserID(),
                new StringBuilder(ENTRY).append(" handleAllocationChangeReq() ").append(INPUT)
                        .append(message.toString()).toString());

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

        try {
            String[] qcPinningStations = message.getQcChangedPinningStations().split("\\" + PIPE_SEPARATOR);
            for (String qcWithPinningStn : qcPinningStations) {
                String[] qcAndPinningStn = qcWithPinningStn.split("\\" + ITEM_SEPERATOR);
                String qc = qcAndPinningStn[0];
                String pinningStation = qcAndPinningStn[1];
                // calling QC pinning station change method in Cache manager

                rdtCacheMgr.changeQCPinningStation(qc, pinningStation);
            }

        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in handleAllocationChangeReq() ").append(REASON)
                            .toString(), ex);
        }
    }

    /**
     * Method is responsible to prepare final response message for the requested user. Calling two methods those two
     * methods will create final response message and send prepared message to the communication server
     * 
     * @param SHFPinningStationAllocationReqEvent
     *            POJO
     */
    private void handleRequestMessage(SHFPinningStationAllocationReqEvent shfPinningAlloation) {
        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

        String currentLoggedInUserId = shfPinningAlloation.getUserID();
        logger.logMsg(LOG_LEVEL.INFO, currentLoggedInUserId, new StringBuilder(ENTRY)
                .append(" handleRequestMessage() ").append(INPUT).append(shfPinningAlloation.toString()).toString());
        try {
            ConfirmAllocationEvent event = (ConfirmAllocationEvent) rdtCacheMgr
                    .getAllocationDetails(currentLoggedInUserId);
            String listOfQcs = "";
            if (event == null) {
                logger.logMsg(LOG_LEVEL.DEBUG, currentLoggedInUserId,
                        "Unable TO Retrieve ListOfQC's From ConfirmAllocationEvent.");
            } else {
                // Getting List Of QCs from
                listOfQcs = event.getLocation();
            }
            // calling pinningStation cache to get listOfPinning stations.
            Set<String> listOfPinningStations = rdtCacheMgr.getAllPinningStations();

            // calling message creation method
            String responseMessage = prepareQcWithPinningStationMessage(listOfQcs, listOfPinningStations);
            // calling response message sending to COMM server method
            sendResponseToServer(shfPinningAlloation, responseMessage);

        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in handleRequestMessage() ").append(REASON)
                            .toString(), ex);
        }
    }

    /**
     * <p> Method is responsible for Preparing qC related pinning stations+ individual pinning stations response message
     * to the calling method. </p> <p> checking QC is assigned to any Pinning station or not. checking this condition in
     * QcToPinningStation cache,If pinning station is available it maps like QC1^PS else QC1^. </p> <p> Checking whether
     * any pinning station allocated to QC or not. if any pinning station is allocated to QC,removing that pinning
     * station from the listOfPinning stations which is getting from the PinnningStation cache. </p>
     * 
     * @param listOfQcs
     *            and setOfPinningStations
     * 
     * @return Constructed message like
     * 
     *         First time request response message like.None of the QC is associated with pinning station.
     *         RESP~2301~QC1^|QC2^|QC3^~1614lo|1625ki|asfsa|T1|T3|T6|1617lo|1613lo|1624ki|
     *         167lo|1616lo|1612lo|164lo|1615lo|161lo|1611lo~user1~2
     * 
     *         Second request onwards constructed message like
     *         RESP~2301~QC1^1614lo|QC2^1625ki|QC3^asfsa~T1|T3|T6|1617lo|1613lo|1624ki|
     *         167lo|1616lo|1612lo|164lo|1615lo|161lo|1611lo~user1~2
     * 
     */
    private String prepareQcWithPinningStationMessage(String qcs, Set<String> setOfPinningStations) {
        logger.logMsg(LOG_LEVEL.INFO, "",
                new StringBuilder(ENTRY).append(getClass().getName()).append(" prepareQcWithPinningStationMessage() ")
                        .append(INPUT).append(qcs).append(setOfPinningStations.toString()).toString());

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        ConcurrentSkipListSet<String> pinningStations = new ConcurrentSkipListSet<String>(setOfPinningStations);
        StringBuilder qcsWithPinningStationsMessage = new StringBuilder();

        try {
            String[] listOfQcs = qcs.split("\\" + PIPE_SEPARATOR);
            // Preparing QC related Pinning station message format
            for (String qc : listOfQcs) {
                PinningStation pinningStation = rdtCacheMgr.getQCPinningStation(qc);
                if (pinningStation != null) {
                    String pinningStationId = pinningStation.getPinningStationID();
                    qcsWithPinningStationsMessage.append(qc).append(ITEM_SEPERATOR).append(pinningStationId);
                } else {
                    qcsWithPinningStationsMessage.append(qc).append(ITEM_SEPERATOR);
                }
                qcsWithPinningStationsMessage.append(PIPE_SEPARATOR);
            }

            qcsWithPinningStationsMessage.delete(qcsWithPinningStationsMessage.length() - 1,
                    qcsWithPinningStationsMessage.length()).append(VALUE_SEPARATOR);

            // preparing pinning stations and adding to SB.
            for (String pinningStation : pinningStations) {
                qcsWithPinningStationsMessage.append(pinningStation).append(PIPE_SEPARATOR);
            }
        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in handleRequestMessage() ").append(REASON)
                            .toString(), ex);
        }

        return qcsWithPinningStationsMessage.substring(0, qcsWithPinningStationsMessage.length() - 1);
    }

    /**
     * Method is responsible for send the response message to the COMM server with final response message like
     * RESP~2301~QC1^|QC1^|QC1^|QC1^~PS1|PS2|PS3|PS4|PS5~user1~2(First Request)
     * RESP~2301~QC1^PS1|QC2^PS2|QC3^PS3|QC4~PS1|PS2~user1~2(Second Request Onwards)
     */
    private void sendResponseToServer(SHFPinningStationAllocationReqEvent pinningStation, String responseMessage) {

        String userId = pinningStation.getUserID();

        logger.logMsg(LOG_LEVEL.INFO, userId,
                new StringBuilder(ENTRY).append(getClass().getName()).append(" sendResponseToServer() ").append(INPUT)
                        .append(responseMessage).toString());

        String eventType = SHF_PINNINGSTATION_VIEW_RESPONSE;
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
        String terminalId = pinningStation.getTerminalID();
        String eventId = pinningStation.getEventID();

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RESP).append( VALUE_SEPARATOR).append( eventTypeID).append( VALUE_SEPARATOR
               ).append( eventId).append( VALUE_SEPARATOR);

        responseToDevice.append(responseMessage).append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR)
                .append(terminalId);

        logger.logMsg(
                LOG_LEVEL.INFO,
                userId,
                new StringBuilder(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
                        .append(responseToDevice.toString()).toString());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.FOREMAN,
                terminalId);
    }
}
