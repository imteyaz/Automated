package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;
/**
 * Event consists of List of ContainerId's which doesn't have ISO,POD,WT attributes.
 * @author Uma.
 */
public class UpdateBlockContainersRequestEvent extends Event implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4305411133290385291L;

	private List<String> updateRequiredContainerList;

	public List<String> getUpdateRequiredContainerList() {
		return updateRequiredContainerList;
	}
	
	public void setUpdateRequiredContainerList(List<String> updateRequiredContainerList) {
		
		this.updateRequiredContainerList = updateRequiredContainerList;
	}
	
	@Override
	public String toString() {
		return "UpdateBlockContainersRequestEvent [listOfContainers="
				+ updateRequiredContainerList + "]";
	}
	
}
