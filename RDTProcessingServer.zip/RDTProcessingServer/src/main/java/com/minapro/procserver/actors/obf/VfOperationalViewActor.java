package com.minapro.procserver.actors.obf;

import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.FOREMAN_OPT_VIEW;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BayProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.obf.VfOperatoinalViewEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * 
 * Vessel Foreman Operational View. and Allocated QCs,Bays and Lines
 * 
 * @author 3129977
 *
 */
public class VfOperationalViewActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VfOperationalViewActor.class);

    @Override
    public void onReceive(Object event) throws Exception {
        if (event instanceof VfOperatoinalViewEvent) {

            VfOperatoinalViewEvent vfOperatoinalViewEvent = (VfOperatoinalViewEvent) event;
            /*
             * VALUE_SEPERATOR=~ ITEM_SEPERATOR=^ ROW_SEPERATOR=| COLUMN_SEPERATOR=$
             */
            String eventType = FOREMAN_OPT_VIEW;
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
            String itemSeperator = DeviceCommParameters.getInstance().getCommParameter(ITEM_SEPERATOR_KEY);
            String rowSeperator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
            SimpleDateFormat formatter = new SimpleDateFormat("d.MMM.yyyy");
            String currDate = formatter.format(new Date());
            String userId = vfOperatoinalViewEvent.getUserID();
            String terminalId = vfOperatoinalViewEvent.getTerminalID();

            String equipmentId = vfOperatoinalViewEvent.getEquipmentID();

            logger.logMsg(LOG_LEVEL.INFO, userId, "Requested for Vessel Foreman Operation View");
            StringBuilder qcDetails = new StringBuilder();
            // for Multiple Qcdetails

            try {
                // All the available QC Lanes
                StringBuilder lanesAvail = new StringBuilder();

                prepareAvailableQClanes(lanesAvail);

                ConfirmAllocationEvent confirmAllocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                        .getAllocationDetails(userId);
                String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(
                        confirmAllocationEvent.getRotationID());

                // Vessel Max Rows
                int maxRowsInVessel = RDTVesselProfileCacheManager.getInstance().getMaxRowForVessel(vesselCode);

                // multiple QCs with | as separator
                String location = confirmAllocationEvent.getLocation();
                // LIST OF QCs assigned to User.
                String[] qcs = location.split("\\|");
                for (String qc : qcs) {

                    qcDetails.append(qc).append(itemSeperator);
                    // BAY.ROW.TIER as string literal
                    String cellLocation = RDTPLCCacheManager.getInstance().getCurrentCellLocationOfUser(qc);

                    if (cellLocation != null) {
                        // If cellLocation is Not null = BAY1$BAY2^RowNo1$RowNo2^CurrRow
                        prepareQcBayInfo(qcDetails, cellLocation, vesselCode);
                    } else {
                        // If cellLocation is null = ^^^
                        qcDetails.append(itemSeperator).append(itemSeperator).append(itemSeperator);
                    }

                    // Getting Associated lane for passing qc
                    String qcLane = RDTCacheManager.getInstance().getAllocatedQCLane(qc);
                    qcDetails.append(qcLane).append(itemSeperator);

                    int completedQCJobs = 1;
                    Map<String, CompletedContainerMoves> completedJobsListForQc = RDTCacheManager.getInstance()
                            .getCompletedJobs(confirmAllocationEvent.getRotationID(), qc);
                    if (completedJobsListForQc != null) {
                        completedQCJobs += completedJobsListForQc.size();
                    }

                    // movesToGo
                    Integer initialJobsCount = RDTPLCCacheManager.getInstance().getPlannedMovesCount(equipmentId);
                    Integer movesToGo = initialJobsCount - completedQCJobs;
                    qcDetails.append(movesToGo).append(itemSeperator);

                    // MPH = Gross Move Hour
                    int completedUserJobs = 0;
                    Map<String, CompletedContainerMoves> completedJobsListForUser = RDTCacheManager.getInstance()
                            .getCompletedJobsForUser(userId, confirmAllocationEvent.getRotationID(), qc);
                    if (completedJobsListForUser != null) {
                        completedUserJobs += completedJobsListForUser.size();
                    }

                    double movesPerHour = EventUtil.getInstance().getGrossMoveperHour(userId, completedUserJobs);
                    qcDetails.append(movesPerHour).append(rowSeperator);
                }
                // End of QC details

                // Constructing Complete Message
                // build the response to the device
                StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventType).append(valueSeperator).append(eventTypeID ).append(valueSeperator ).
                		append(currDate).append(valueSeperator).append(maxRowsInVessel).append(valueSeperator).append(lanesAvail ).append(valueSeperator ).append(qcDetails ).
                		append(valueSeperator ).append(userId ).append(valueSeperator).append(terminalId);
                
                postVesselForemanOperantionalViewToCommunicationServerQueue(responseToDevice, userId, terminalId);
            
            } catch (Exception exception) {
                logger.logException("Caught exception while creating the Vessel Foreman Operational Area View ",
                        exception);
            }
        } else {
            unhandled(event);
        }
    }

    private void prepareQcBayInfo(StringBuilder qcDetails, String cellLocation, String vesselCode) {
        String columnSeperator = DeviceCommParameters.getInstance().getCommParameter(COLUMN_SEPERATOR_KEY);
        String itemSeperator = DeviceCommParameters.getInstance().getCommParameter(ITEM_SEPERATOR_KEY);
        // Iterate Through cellLocation and Split with .
        String[] bayDetails = cellLocation.split(".");

        String deckIndication = EventUtil.getInstance().findDeckType(bayDetails[2], vesselCode, bayDetails[0]);
        // bayDetails[0] == BAY , bayDetails[1] == ROW , bayDetails[2] == TIER ,

        String sectionNo = RDTVesselProfileCacheManager.getInstance().getAssociatedSection(vesselCode, bayDetails[0],
                deckIndication);

        StringBuilder bayInfo = new StringBuilder();

        StringBuilder bayNos = new StringBuilder();
        StringBuilder rowCounts = new StringBuilder();

        if (sectionNo != null) {
            Map<String, BayProfile> bayProfiles = RDTVesselProfileCacheManager.getInstance().getBayProfiles(sectionNo);
            // Iterate Map Multiple Bays
            for (Map.Entry<String, BayProfile> entry : bayProfiles.entrySet()) {
                bayNos.append(entry.getKey()).append(columnSeperator);
                BayProfile bayProfile = entry.getValue();
                Integer rowCount = bayProfile.getMaxRowOffset() - bayProfile.getMinRowOffset();
                // 00 row is missing or not available
                if (!bayProfile.isZeroRowPresent()) {
                    rowCount--;
                }
                rowCounts.append(entry.getKey()).append(columnSeperator);
            }
        }
        bayInfo.append(bayNos.deleteCharAt(bayNos.length() - 1)).append(itemSeperator)
                .append(rowCounts.deleteCharAt(rowCounts.length() - 1));
        qcDetails.append(bayInfo).append(itemSeperator);

        // Current QC working Row is BAY.ROW
        String curWorkingRow = cellLocation.substring(0, cellLocation.lastIndexOf("."));
        qcDetails.append(curWorkingRow).append(itemSeperator);

        // Mentioning baywise Indication i.e deck or underdeck
        qcDetails.append(deckIndication).append(itemSeperator);
    }

    private void postVesselForemanOperantionalViewToCommunicationServerQueue(StringBuilder responseToDevice,
            String userId, String terminalId) {

        User user = RDTCacheManager.getInstance().getUserDetails(userId);
        if (user != null) {
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                    terminalId);
        }
    }

    private void prepareAvailableQClanes(StringBuilder lanesAvail) {
        String rowSeperator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
        Set<String> lanes = RDTCacheManager.getInstance().getQCLanes();
        Iterator<String> iterator = lanes.iterator();
        while (iterator.hasNext()) {
            lanesAvail.append(iterator.next()).append(rowSeperator);
        }
        // lane1|lane2|lane3
        lanesAvail.deleteCharAt(lanesAvail.length() - 1);

    }

}
