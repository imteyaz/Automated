package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the messages from TOS for operators
 * 
 * @author Rosemary George
 *
 */
public class OperatorMessageResponseEvent extends Event implements Serializable {

	private static final long serialVersionUID = 8159671896546444640L;
	
	private List<OperatorMessage> operatorMessages;

	public List<OperatorMessage> getOperatorMessages() {
		return operatorMessages;
	}

	public void setOperatorMessages(List<OperatorMessage> operatorMessages) {
		this.operatorMessages = operatorMessages;
	}

	@Override
	public String toString() {
		return "OperatorMessageResponseEvent [operatorMessages=" + operatorMessages + ", getEventID()=" + getEventID()
				+ "]";
	}	
}
