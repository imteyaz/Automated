package com.minapro.procserver.cache;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

import org.apache.commons.collections4.map.ListOrderedMap;
import org.infinispan.Cache;

import com.minapro.procserver.db.Activity;
import com.minapro.procserver.db.CheWeightageFactorEntity;
import com.minapro.procserver.db.CheckList;
import com.minapro.procserver.db.CheckListHeader;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.ISOCodesMaster;
import com.minapro.procserver.db.PinningStation;
import com.minapro.procserver.db.QCLane;
import com.minapro.procserver.db.ShiftDetails;
import com.minapro.procserver.db.TroubleShootRecord;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserRole;
import com.minapro.procserver.db.UserViolationAndDelay;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.che.ShuffleResponseEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITV;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.procserver.util.WeightageCriteria;
import com.minapro.procserver.util.WeightageType;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Singleton Class responsible to all cache related operations </p>
 * 
 * <p> All the caches are defined here and exposes API to manipulate the caches. </p>
 * 
 * @author Rosemary George
 * 
 */
public class RDTCacheManager {
	
	public static final String FETCH = "fetch";

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTCacheManager.class);
	
	/**
	 * holds the status of the TOS health. 
	 */
	private static boolean keepAliveStatus =  true;
	

	/**
	 * user wise job list - userId is the key
	 */
	private Cache<String, ListOrderedMap<String, JobListContainer>> jobList = RDTCacheContainer
			.getCache("JobListCache");

	/**
	 * All completed jobs done by the user - rotationId+equipmentId is the key
	 */
	private Cache<String, ListOrderedMap<String, CompletedContainerMoves>> completedJobList = RDTCacheContainer
			.getCache("CompletedJobListCache");

	/**
	 * Assigned ITV pool list - equipment ID is the key
	 */
	private Cache<String, Set<ITV>> itvPool = RDTCacheContainer.getCache("ItvPoolCache");

	/**
	 * equipment details - EquipmentID is the key
	 */
	private Cache<String, Equipment> equipmentMap = RDTCacheContainer.getCache("EquipmentCache");

	/**
	 * User details - userID is the key
	 */
	private Cache<String, User> userMap = RDTCacheContainer.getCache("UserCache");

	/**
	 * pinning station details - pinning station ID is the key
	 */
	private Cache<String, PinningStation> pinningStationMap = RDTCacheContainer.getCache("PinningStationCache");

	/**
	 * QC related pinning station mapping.-QC is the key and PinningStation is the value
	 */
	private Cache<String, PinningStation> qcToPinningStationMap = RDTCacheContainer.getCache("QCToPinningStationMap");

	/**
	 * pinning station details - terminal ID is the key. Using this cache at SHFPinningAllocation actor to get list of
	 * pinning stations based on terminal id as key.
	 */
	private Cache<String, Set<String>> pinningStationWithTerminalKey = RDTCacheContainer
			.getCache("PinningStationCache");
	/**
	 * All pending instructions which needs to be sent to the ITV - equipmentID is the Key
	 */
	private Cache<String, List<DriveInstructionEvent>> pendingITVInstructions = RDTCacheContainer
			.getCache("PendingItvInstructionCache");

	/**
	 * Delay reason code details - Delay_Type is the key
	 */
	private Cache<String, Set<DelayReasonCode>> delayReasonCodes = RDTCacheContainer.getCache("DelayReasonCache");

	/**
	 * Troubleshoot Area Details - terminalId is the key
	 */
	private Cache<String, Set<TroubleshootAreaMaster>> troubleshootAreaCache = RDTCacheContainer
			.getCache("TroubleshootAreaCache");

	/**
	 * TroubleshootObject Details for troubleshootAreaId - troubleshootArea ID is the key
	 */

	private Cache<String, Boolean> operatorWorkingStatus = RDTCacheContainer.getCache("OperatorWorkingStatus");
	/**
	 * Following cache is used to store/retrieve operator break start and end time.
	 */

	private Cache<String, Date> operatorBreakTimings = RDTCacheContainer.getCache("OperatorBreakTimings");

	/**
	 * Following cache is used to store the operator overall break time for the current rotation
	 */
	private Cache<String, Double> operatorOverAllBreakTime = RDTCacheContainer.getCache("OperatorOverAllBreakTime");

	/**
	 * Contains all the current troubleshoot requests, grouped by TS area - TSArea is the key
	 */
	private Cache<String, List<TroubleShootRecord>> troubleshootRequestsCache = RDTCacheContainer
			.getCache("TroubleshootRequestsCache");

	/**
	 * Contains the completed troubleshoot records for the last 24 hours - TSArea is the key
	 */
	private Cache<String, List<TroubleShootRecord>> completedTroubleShootRecordsCache = RDTCacheContainer
			.getCache("CompletedTroubleShootRecordCache");

	/**
	 * QC Lane details - LaneID is the key
	 */
	private Cache<String, QCLane> qcLanes = RDTCacheContainer.getCache("QCLaneCache");

	/**
	 * Allocation details of users - userID is the key
	 */
	private Cache<String, Event> userAllocationMap = RDTCacheContainer.getCache("UserAllocationCache");

	/**
	 * Mapping QC to the allocated Lane - QC ID is the key
	 */
	private Cache<String, String> qcToLaneMapping = RDTCacheContainer.getCache("QcToLaneMappingCache");

	/**
	 * Mapping Vessel to pinning station - rotationID is the key
	 */
	private Cache<String, String> vesselToPinningStationMapping = RDTCacheContainer
			.getCache("VesselToPinningStationMappingCache");

	/**
	 * ITV current location details - ITV ID is the key
	 */
	private Cache<String, String> currentItvLocationMap = RDTCacheContainer.getCache("ItvCurrentLocationCache");

	/**
	 * Location to user mapping - location Id is the key - location can be quay side or yard side
	 */
	private Cache<String, Set<String>> locationToUserMapping = RDTCacheContainer.getCache("locationToUserMappingCache");

	/**
	 * Device Details - device ID is the key
	 */
	private Cache<String, Device> deviceDetails = RDTCacheContainer.getCache("DeviceCache");

	/**
	 * User to Device mapping - userID is the key
	 */
	private Cache<String, String> deviceToUserMapping = RDTCacheContainer.getCache("DeviceToUserMappingCache");

	/**
	 * Activity Code details - activityCode is key
	 */
	private Cache<String, Activity> activityDetails = RDTCacheContainer.getCache("ActivityCache");

	/**
	 * User violations and delay details - user ID is the key
	 */
	private Cache<String, List<UserViolationAndDelay>> userViolations = RDTCacheContainer
			.getCache("UserViolationCache");

	/**
	 * CheckList items per user role - role name is the key
	 */
	private Cache<String, Set<CheckListHeader>> checkListPerRole = RDTCacheContainer.getCache("checkListPerRoleCache");

	/**
	 * CheckList items - checkListHeader Id + checkList ID is the key
	 */
	private Cache<String, CheckList> checkLists = RDTCacheContainer.getCache("checkListCache");

	/**
	 * Inspection status for logged in users - user ID is the key
	 */
	private Cache<String, String> inspectionRecords = RDTCacheContainer.getCache("inspectionRecordCache");

	/**
	 * Container details - container ID is the key
	 */
	private Cache<String, Container> containerDetails = RDTCacheContainer.getCache("ContainerCache");

	/**
	 * Indicates the user's logged in role - userId is the key
	 */
	private Cache<String, String> loggedInUserRoleMap = RDTCacheContainer.getCache("LoggedInUserRoleMap");

	/**
	 * Indicates the QC equipment assigned for the HC user - userId is the key
	 */
	private Cache<String, String> hcToQcMapping = RDTCacheContainer.getCache("HcToQcMap");

	/**
	 * Indicates the HS user signed in for the QC equipment - EquipmentId is the key
	 */
	private Cache<String, String> qcToHcMapping = RDTCacheContainer.getCache("QcToHcMap");

	/**
	 * Container Details of Each ITV User - ITV Id the key
	 */
	private Cache<String, List<String>> itvToCntrDetails = RDTCacheContainer.getCache("ItvToCntrMap");
	
	/**
	 * Current drive instructions running for the ITV - ItvId is the key
	 */
	private Cache<String, String> currentItvInstructions = RDTCacheContainer.getCache("ItvCurrentInstructionsMap");

	/**
	 * Indicates pinning required or not- user ID is the key
	 */

	private Cache<String, Boolean> pinningRequiredStatus = RDTCacheContainer.getCache("ItvToPinningMap");

	/**
	 * Shift details - terminalID is the key
	 */
	private Cache<String, ShiftDetails> terminalToShiftMap = RDTCacheContainer.getCache("TerminalToShiftMAp");

	private Cache<String, String> vesselLocationToItvDetails = RDTCacheContainer.getCache("VesselLocationToItvMap");
	/**
	 * User role master details - roleName is the key
	 */
	private Cache<String, UserRole> roleDetails = RDTCacheContainer.getCache("UserRoleMap");
	/**
	 * ITV to Trailer mapping - itvId is the key
	 */
	private Cache<String, String> itvTrailerMapping = RDTCacheContainer.getCache("ITVTrailerMap");

	/**
	 * All shuffle jobs - Cache key is userId, HashMap key is requestedContainer+rehandleContainer.
	 */
	private Cache<String, Map<String, ShuffleResponseEvent>> shuffledJobList = RDTCacheContainer
			.getCache("shuffleJobListCache");


	private Cache<String, String> nodeToCranesMapping = RDTCacheContainer.getCache("NodeToCranesMap");

	/**
	 * Selected job map - equipmentId is the key and value will be containerId+moveType
	 */
	private Cache<String,String> selectedJobMap = RDTCacheContainer.getCache("SelectedJobCache");

	/**
	 * Storing CHE Weightage Related Parameters. Weightage type and Weightage Criteria are key 
	 * Weightage Score and Weightage Factor Combination is Value.
	 * Sample : (MoveKind+LOAD,Weightage Score * Weightage Factor) MoveKind+LOAD is the Key and 10|1 is the value.
	 */
	private Cache<String, CheWeightageFactorEntity> cheWeightageDetailsCache = RDTCacheContainer.getCache("CheWeightageDetailsCache");
	
	/**
	 * ITV fetch container details - container ID +movetype is the key - fetching itv equipmentId is the value
	 */
	private Cache<String, String> itvFetchContainerDetails = RDTCacheContainer.getCache("ITVFetchContainerCache");
	/**
	 * Cache used to maintain the current equipment job list request status.
	 */
	private Cache<String, EquipmentJobListRequestStatus> eqJobListReqStatus = RDTCacheContainer.getCache("EquipmentJobListReqStatusCache");
	
	/**
	 * Cache Is Used to check the Current Equipment Getting PLC Events From Database Or Not..
	 */
	private Cache<String, Boolean> equipmentPLCEventStatus = RDTCacheContainer.getCache("EquipmentPLCEventStatus");
			
	/**
	 * Cache Is Used To Store the Iso Codes Details.
	 */
	private Cache<String, ISOCodesMaster> isoCodesCache = RDTCacheContainer.getCache("ISOCodesCache");

	private static final RDTCacheManager INSTANCE = new RDTCacheManager();

	private RDTCacheManager() {
	}
	

	/**
	 * Gives the instance of RDTCacheManager
	 * 
	 * @return
	 */
	public static RDTCacheManager getInstance() {
		return INSTANCE;
	}
	
	public CheWeightageFactorEntity getCheWeightageDetailsFromCache(WeightageType weightageType,WeightageCriteria weightageCriteria) {
		try{
			String key = weightageType.toString().concat(weightageCriteria.toString());
			return cheWeightageDetailsCache.get(key);
		}catch(Exception ex){
			logger.logException(" Exception Occured While Retrieving CheWeightageDetailsFromCache Reason:", ex);
			return null;
		}
	}

	public void setCheWeightageDetailsToCache(CheWeightageFactorEntity cheWeightageEntity) {
		try {

			String key = cheWeightageEntity.getId().getWeightageType().toString()
					.concat(cheWeightageEntity.getId().getWeightageCritaria().toString());
			// double value = (cheWeightageEntity.getWeightageScore()) * (cheWeightageEntity.getWeightageFactor());
			cheWeightageDetailsCache.put(key, cheWeightageEntity);
		} catch (Exception ex) {
			logger.logException(" Exception Occured While Seting Values To CheWeightageDetailsToCache Reason::", ex);
		}
	}

	
	public void setEquipmentPLCEventStatus(String userId , String equipmentId , Boolean status) {
		equipmentPLCEventStatus.put(userId.concat(equipmentId),status);
	}
	
	public Boolean getEquipmentPLCEventStatus(String userId , String equipmentId){
		return equipmentPLCEventStatus.get(userId.concat(equipmentId));
	}
	
	public void removeEquipmentPLCStatus(String userId , String equipmentId){
		equipmentPLCEventStatus.remove(userId.concat(equipmentId));
	}
	/**
	 * Retrieves the role the user has logged in as
	 * 
	 * @param userId
	 * @return OPERATOR
	 */
	public OPERATOR getUserLoggedInRole(String userId) {
		String operator = loggedInUserRoleMap.get(userId);

		if (operator == null) {
			return OPERATOR.COMMON;
		}
		if ("QC".equalsIgnoreCase(operator)) {
			return OPERATOR.QC;
		} else if ("ITV".equalsIgnoreCase(operator)) {
			return OPERATOR.ITV;
		} else if (operator.startsWith("RMG") || operator.startsWith("RTG") || "CHE".equalsIgnoreCase(operator)) {
			return OPERATOR.CHE;
		} else if ("FOREMAN".equalsIgnoreCase(operator)) {
			return OPERATOR.FOREMAN;
		} else if ("HC".equalsIgnoreCase(operator)) {
			return OPERATOR.HC;
		} else if ("VSUP".equalsIgnoreCase(operator)) {
			return OPERATOR.VSUP;
		} else if ("GSUP".equalsIgnoreCase(operator)) {
			return OPERATOR.GSUP;
		} else if ("YSUP".equalsIgnoreCase(operator)) {
			return OPERATOR.YSUP;
		} else if ("TSC".equalsIgnoreCase(operator)) {
			return OPERATOR.TSC;
		} else {
			return OPERATOR.COMMON;
		}
	}

	public String getCurrentRoleForUser(String userId) {
		return loggedInUserRoleMap.get(userId);
	}

	/**
	 * Saves the users currenlt logged in role
	 * 
	 * @param userId
	 * @param role
	 */
	public void setUserLoggedInRole(String userId, String role) {
		loggedInUserRoleMap.put(userId, role);
	}

	/**
	 * Method is responsible for setting the operator current status(true or false)
	 * 
	 * @param userId
	 * @param availability
	 *            (true or false)
	 */
	public void setOperatorAvailability(String userId, Boolean availability) {
		operatorWorkingStatus.put(userId + (getCurrentRoleForUser(userId)), availability);
	}

	/**
	 * Method is responsible for getting the operator current status(true or false) based on userId.
	 * 
	 * @param userId
	 * @return true or false
	 */
	public Boolean isOperatorAvailable(String userId) {
		
		Boolean status = operatorWorkingStatus.get(userId + (getCurrentRoleForUser(userId)));
		
		return status!=null ? status : true;
	}

	/**
	 * Retrieves the job list for particular Equipment
	 * 
	 * @param equipmentId
	 * @return ArrayList<Container> - current job list
	 */

	public void setOperatorBreakTimings(String userId, Date breakStartTime) {
		operatorBreakTimings.put(userId, breakStartTime);
	}

	public Date getOperatorBreakTimings(String userId) {
		return operatorBreakTimings.get(userId);
	}

	public void setOperatorOverAllBreakTime(String userWithRotation, double breakTime) {
		operatorOverAllBreakTime.put(userWithRotation, breakTime);
	}

	public double getOperatorOverAllBreakTime(String userWithRotation) {
		return operatorOverAllBreakTime.get(userWithRotation);
	}

	public ListOrderedMap<String, JobListContainer> getJobList(String userId, String equipmentId) {
		String rotationId = "";
		ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) getAllocationDetails(userId);
		if(allocationDetails != null){
			rotationId = allocationDetails.getRotationID();
		}
		return jobList.get(equipmentId + rotationId);
	}

	/**
	 * Removes the specified container from the job list of the equipment
	 * 
	 * @param equipmentId
	 * @param containerId
	 *            - ID of the container to be removed
	 * @param moveType - will be empty for CHE operator case
	 */
	public void deleteFromJobList(String userId, String containerId, String equipmentId, String moveType) {
		String rotationId = ((ConfirmAllocationEvent) getAllocationDetails(userId)).getRotationID();
		ListOrderedMap<String, JobListContainer> jobs = jobList.get(equipmentId + rotationId);
		if (jobs != null) {
			jobs.remove(containerId+moveType);
		}
	}

	/**
	 * <p> Updates the job list of a particular equipment with the specified container details. </p>
	 * 
	 * @param equipmentId
	 *            - whose job list needs update
	 * @param container
	 *            - Container details which needs to be updated
	 * @param moveType - will be empty for CHE operator case
	 */
	public void updateJobList(String userId, JobListContainer container, String equipmentId, String moveType) {
		String rotationId = ((ConfirmAllocationEvent) getAllocationDetails(userId)).getRotationID();
		ListOrderedMap<String, JobListContainer> jobs = jobList.get(equipmentId + rotationId);

		if (jobs == null) {
			jobs = new ListOrderedMap<String, JobListContainer>();
			jobList.put(equipmentId + rotationId, jobs);
		}
		jobs.put(container.getContainerId()+moveType, container);
	}
	
	/**
	 * <p> Updates the job list of a particular user with the specified job as a first job in the list. </p>
	 * 
	 * @param equipmentId
	 *            - whose job list needs update
	 * @param container
	 *            - Container details which needs to be updated
	 * @param moveType - will be empty for CHE operator case
	 */
	public void updateFirstEntryInJobList(String userId, JobListContainer container, String equipmentId, String moveType) {
		String rotationId = ((ConfirmAllocationEvent) getAllocationDetails(userId)).getRotationID();
		ListOrderedMap<String, JobListContainer> jobs = jobList.get(equipmentId + rotationId);

		if (jobs == null) {
			jobs = new ListOrderedMap<String, JobListContainer>();
			jobList.put(equipmentId + rotationId, jobs);
		}

		jobs.put(0, container.getContainerId()+moveType, container);
	}

	/**
	 * <p> Updates the job list of a particular user with the specified job, job order in the job list is based on the
	 * position. </p>
	 * 
	 * @param equipmentId
	 *            - whose job list needs update
	 * @param container
	 *            - Container details which needs to be updated
	 * @param currentLiftOperation
	 * 
	 * @param equipmentId
	 * 
	 * @param position
	 * 
	 * @param moveType - will be empty for CHE operator case
	 */
	public void updateselectedPositionEntryInJobList(String userId, JobListContainer container, String equipmentId,
			String position, String moveType) {
		String rotationId = ((ConfirmAllocationEvent) getAllocationDetails(userId)).getRotationID();
		ListOrderedMap<String, JobListContainer> jobs = jobList.get(equipmentId + rotationId);
		if (jobs == null) {
			jobs = new ListOrderedMap<String, JobListContainer>();
			jobList.put(equipmentId + rotationId, jobs);
			position = "0";
		}
		jobs.put(Integer.valueOf(position), container.getContainerId()+moveType, container);
	}

	/**
	 * Removes the current job list(if any) for the specified equipment id if the rotationId is different
	 * 
	 * @param rotationId
	 * @param equipmentId
	 */
	public void flushJobListForEquipment(String rotationId, String equipmentId) {
		ListOrderedMap<String, JobListContainer> jobs = jobList.get(equipmentId + rotationId);
		if (jobs == null) {
			// Couldn't find any jobs with the current rotationId and equipment, so flush the previous jobs if any
			for (String key : jobList.keySet()) {
				if (key.startsWith(equipmentId)) {
					jobList.remove(key);
				}
			}
		}
	}
	
	/**
	 * Removes the current job list(if any) for the specified equipment id and the rotationId
	 * 
	 * @param userId
	 * @param equipmentId
	 */
	public void flushJobList(String userId, String equipmentId) {
		String rotationId = ((ConfirmAllocationEvent) getAllocationDetails(userId)).getRotationID();
		jobList.remove(equipmentId + rotationId);
	}

	/**
	 * Returns the Equipment details for the given equipmentID
	 * 
	 * @param equipmentID
	 * @return <Equipment>
	 */
	public Equipment getEquipmentDetails(String equipmentID) {
		return equipmentMap.get(equipmentID);
	}

	/**
	 * Retrieves the IDs of all the equipment which falls under the specified type.
	 * 
	 * @param equipmentType
	 * @return ArrayList<EquipmentIDs>
	 */
	public List<String> getEquipmentDetailsOfType(String equipmentType) {
		List<String> equipmentIDs = new ArrayList<String>();
		for (Equipment equipment : equipmentMap.values()) {
			if (equipmentType.equalsIgnoreCase(equipment.getEquipmentType().getEquipmentTypeId())) {
				equipmentIDs.add(equipment.getEquipmentID());
			}
		}
		return equipmentIDs;
	}

	/**
	 * Retrieves the all the equipments.
	 * 
	 * @return List<Equipment>
	 */
	public List<Equipment> getAllEquipmentDetails() {

		return new ArrayList<Equipment>(equipmentMap.values());
	}

	/**
	 * Returns the Pinning station details for the given pinning station ID
	 * 
	 * @param pinningStationID
	 * @return PinningStation
	 */
	public PinningStation getPinningStationDetails(String pinningStationID) {
		return pinningStationMap.get(pinningStationID);
	}

	/**
	 * Retrieves all the pending instructions for an ITV
	 * 
	 * @param itvID
	 * @return ArrayList<DriveInstructionEvent>
	 */
	public List<DriveInstructionEvent> getPendingITVInstructions(String itvID) {
		return pendingITVInstructions.get(itvID);
	}

	/**
	 * Adds the driving instruction to the pendingITVInstruction list.
	 * 
	 * @param driveInstruction
	 */
	public void addToPendingITVInstructions(DriveInstructionEvent driveInstruction) {
		List<DriveInstructionEvent> pendingInstruction = pendingITVInstructions.get(driveInstruction.getEquipmentID());
		if (pendingInstruction == null) {
			pendingInstruction = new ArrayList<DriveInstructionEvent>();
			pendingITVInstructions.put(driveInstruction.getEquipmentID(), pendingInstruction);
		}

		pendingInstruction.add(driveInstruction);
	}

	/**
	 * Adds the driving instruction to the first position in the pendingITVInstruction list.
	 * 
	 * @param driveInstruction
	 */
	public void addToPendingITVInstructionsInFirstPlace(DriveInstructionEvent driveInstruction) {
		List<DriveInstructionEvent> pendingInstruction = pendingITVInstructions.get(driveInstruction.getEquipmentID());
		if (pendingInstruction == null) {
			pendingInstruction = new ArrayList<DriveInstructionEvent>();
			pendingITVInstructions.put(driveInstruction.getEquipmentID(), pendingInstruction);
		}

		pendingInstruction.add(0, driveInstruction);
	}

	/**
	 * Adds the driving instruction list to the end of pendingITVInstruction list.
	 * 
	 * @param itvId
	 * @param driveInstruction
	 */
	public void addToPendingITVInstructions(String itvId, List<DriveInstructionEvent> driveInstructions) {
		List<DriveInstructionEvent> pendingInstruction = pendingITVInstructions.get(itvId);
		if (pendingInstruction == null) {
			pendingInstruction = new ArrayList<DriveInstructionEvent>();
			pendingITVInstructions.put(itvId, pendingInstruction);
		}

		pendingInstruction.addAll(driveInstructions);
	}

	/**
	 * Removes the driving instruction from the pending list of an ITV
	 * 
	 * @param instruction
	 */
	public void removeFromPendingITVInstructions(DriveInstructionEvent instruction) {
		List<DriveInstructionEvent> pendingInstruction = pendingITVInstructions.get(instruction.getEquipmentID());
		if (pendingInstruction != null) {
			pendingInstruction.remove(instruction);
		}
	}

	/**
	 * Retrieves the user details for the specified userID
	 * 
	 * @param userID
	 * @return <User>
	 */
	public User getUserDetails(String userID) {
		return userMap.get(userID);
	}

	/**
	 * Add user details to the Cache
	 * 
	 * @param user
	 */
	public void addUserDetails(User user) {
		userMap.put(user.getUserID(), user);
	}

	public Set<String> getAllUsers() {
		return userMap.keySet();
	}

	/**
	 * Retrieves all the QC lane IDs available in the cache.
	 * 
	 * @return
	 */
	public Set<String> getQCLanes() {
		return qcLanes.keySet();
	}

	/**
	 * Retrieves the lane allocated for the specified QC from cache
	 * 
	 * @param qcID
	 *            - ID of the QC which needs the lane details
	 * @return - Lane ID
	 */
	public String getAllocatedQCLane(String qcID) {
		return qcToLaneMapping.get(qcID);
	}

	/**
	 * Saves the allocated lane details for a particular QC
	 * 
	 * @param qcId
	 * @param laneId
	 *            - the allocated lane id for QC
	 */
	public void saveAllocatedQCLane(String qcId, String laneId) {
		qcToLaneMapping.put(qcId, laneId);
	}

	/**
	 * Adds the allocation details for the specified user to the cache
	 * 
	 * @param allocationEvent
	 */
	public void addAllocationDetails(Event allocationEvent) {
		userAllocationMap.put(allocationEvent.getUserID(), allocationEvent);
	}

	/**
	 * Retrieves all the users who have confirmed allocations
	 * 
	 * @return Set<String>
	 */
	public Set<String> getAllocatedUsers() {
		return this.userAllocationMap.keySet();
	}

	/**
	 * Retrieves the allocation details for the specified user from the cache
	 * 
	 * @param userID
	 * @return
	 */
	public Event getAllocationDetails(String userID) {
		return userAllocationMap.get(userID);
	}

	/**
	 * Clears the information stored in all caches for the specified user
	 * 
	 * @param userId
	 * @param equipmentId
	 */
	public void clearAllCacheForUser(String userId, String equipmentId) {
		if (equipmentId != null) {
			pendingITVInstructions.remove(equipmentId);
		}
		userAllocationMap.remove(userId);
		deviceToUserMapping.remove(userId);
		inspectionRecords.remove(userId);

		// Remove the QC-HC mapping only when HC logs out
		OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
		if (OPERATOR.HC.equals(role)) {
			String qcEqptId = hcToQcMapping.remove(userId);
			if (qcEqptId != null) {
				qcToHcMapping.remove(qcEqptId);
			}
			logger.logMsg(LOG_LEVEL.DEBUG, qcEqptId, "Current QC-HC Mapping Keys - " + qcToHcMapping.keySet()
					+ ", Values-" + qcToHcMapping.values());

		}
		loggedInUserRoleMap.remove(userId);

		Set<String> locationKeySet = locationToUserMapping.keySet();
		for (String location : locationKeySet) {
			RDTCacheManager.getInstance().getAllUsersAtLocation(location).remove(userId);
		}

	}

	/**
	 * Retrieves the pinning station allocated for the specified rotation id
	 * 
	 * @param rotationId
	 * @return pinning station id
	 */
	public String getAllocatedPinningStation(String rotationId) {
		return vesselToPinningStationMapping.get(rotationId);
	}

	/**
	 * Saves the pinning station id allocated for the specified vessel
	 * 
	 * @param rotationId
	 * @param pinningStationId
	 */
	public void saveAllocatedPinningStation(String rotationId, String pinningStationId) {
		vesselToPinningStationMapping.put(rotationId, pinningStationId);
	}

	/**
	 * Retrieves the current location of the specified ITV
	 * 
	 * @param itvId
	 * @return location id
	 */
	public String getITVCurrentLocation(String itvId) {
		return currentItvLocationMap.get(itvId);
	}

	/**
	 * Saves the current location of the specified ITV
	 * 
	 * @param itvId
	 * @param locationId
	 */
	public void setITVCurrentLocation(String itvId, String locationId) {
		currentItvLocationMap.put(itvId, locationId);
	}

	/**
	 * Retrieves all the users who are allocated to the specified location
	 * 
	 * @param locationId
	 * @return ArrayList<userId>
	 */
	public Set<String> getAllUsersAtLocation(String locationId) {
		return locationToUserMapping.get(locationId);
	}

	/**
	 * Adds the specified user to the specified location
	 * 
	 * @param userId
	 * @param locationId
	 */
	public void addUserToLocation(String userId, String locationId) {
		Set<String> users = locationToUserMapping.get(locationId);
		if (users == null) {
			users = new HashSet<String>();
			locationToUserMapping.put(locationId, users);
		}
		
		if(userId != null){
			users.add(userId);
		}
	}

	/**
	 * Retrieves the <Device> details for the specified device ID
	 * 
	 * @param deviceId
	 * @return
	 */
	public Device getDeviceDetails(String deviceId) {
		return deviceDetails.get(deviceId);
	}

	/**
	 * Adds the device details to the cache
	 * 
	 * @param device
	 */
	public void addDeviceDetails(Device device) {
		deviceDetails.put(device.getDeviceId(), device);
	}

	/**
	 * Retrieves the list of devices available in Cache
	 * 
	 * @return
	 */
	public Collection<Device> getDeviceList() {
		return deviceDetails.values();
	}

	/**
	 * Retrieves all the activity codes present in the cache
	 * 
	 * @return
	 */
	public Set<String> getActivityCodes() {
		return activityDetails.keySet();
	}

	/**
	 * Retrieves the Activity from cache for the specified Activity Code
	 * 
	 * @param activityCode
	 * @return Activity
	 */
	public Activity getActivity(String activityCode) {
		return activityDetails.get(activityCode);
	}

	/**
	 * Adds the activity to the cache
	 * 
	 * @param activity
	 */
	public void addActivity(Activity activity) {
		activityDetails.put(activity.getActivityId(), activity);
	}

	/**
	 * Adds the user to device mapping into the cache. user id is the key
	 * 
	 * @param userId
	 * @param deviceId
	 */
	public void addUserToDeviceMapping(String userId, String deviceId) {
		deviceToUserMapping.put(userId, deviceId);
	}

	/**
	 * Retrieves the device ID which the user has logged into
	 * 
	 * @param userId
	 * @return
	 */
	public String getDeviceMapping(String userId) {
		return deviceToUserMapping.get(userId);
	}

	/**
	 * Retrieves the user associated with the specified device_id; else returns null
	 * 
	 * @param device_id
	 * @return
	 */
	public String getDeviceToUserMapping(String deviceId) {
		Set<String> users = deviceToUserMapping.keySet();
		for (String user : users) {
			if (deviceId.equalsIgnoreCase(deviceToUserMapping.get(user))) {
				return user;
			}
		}
		return null;
	}

	/**
	 * Adds the Equipment details into the cache. Equipment ID is the key
	 * 
	 * @param equipment
	 */
	public void addEquipmentDetails(Equipment equipment) {
		equipmentMap.put(equipment.getEquipmentID(), equipment);
	}

	/**
	 * Adds the Pinning station details into the cache. Pinning station ID is the key
	 * 
	 * @param pinningStation
	 */
	public void addPinningStationDetails(PinningStation pinningStation) {
		pinningStationMap.put(pinningStation.getPinningStationID(), pinningStation);
	}

	/**
	 * Adds the delay reason code ID to the cache. Delay_type is the key
	 * 
	 * @param delayCode
	 */
	public void addDelayReasonCodeDetails(DelayReasonCode delayCode) {
		Set<DelayReasonCode> delayCodes = delayReasonCodes.get(delayCode.getDelaypk().getDelayType());
		if (delayCodes == null) {
			delayCodes = new HashSet<DelayReasonCode>();
			delayReasonCodes.put(delayCode.getDelaypk().getDelayType(), delayCodes);
		}
		delayCodes.add(delayCode);
	}

	/**
	 * <p> Method is responsible for adding TroubleShootMaster Object to the cache.Key is the terminal id and value is
	 * TroubleshootAreaMaster POJO </p>
	 * 
	 * @param TroubleshootAreaMaster
	 *            object
	 */
	public void addTroubleshootAreaDetails(TroubleshootAreaMaster troubleshootArea) {
		String terminalId = troubleshootArea.getTermianlId();
		Set<TroubleshootAreaMaster> troubleshootAreas = troubleshootAreaCache.get(terminalId);
		if (troubleshootAreas == null) {
			troubleshootAreas = new HashSet<TroubleshootAreaMaster>();
			troubleshootAreaCache.put(terminalId, troubleshootAreas);
		}
		troubleshootAreas.add(troubleshootArea);
	}

	/**
	 * <p> Adds the newly created troubleshoot record to the cache. The record will be added to the cache based on the
	 * troubleshoot area Id specified. </p>
	 */

	public void addTroubleshootRequests(TroubleShootRecord record) {

		logger.logMsg(LOG_LEVEL.INFO, record.getContainerId(), "Adding Troubleshoot record to cache -->" + record);

		String troubleshootAreaId = record.getTroubleshootArea();

		List<TroubleShootRecord> troubleshootRecords = troubleshootRequestsCache.get(troubleshootAreaId);

		if (troubleshootRecords == null) {
			troubleshootRecords = new ArrayList<TroubleShootRecord>();
			troubleshootRequestsCache.put(troubleshootAreaId, troubleshootRecords);
		}
		troubleshootRecords.add(record);
	}

	/**
	 * Returns the list of troubleshoot jobs for the specified tsArea
	 * 
	 * @param tsArea
	 * @return
	 */
	public List<TroubleShootRecord> getTroubleShootJobs(String tsArea) {
		return troubleshootRequestsCache.get(tsArea);
	}

	/**
	 * <p> Method is responsible for setting list of pinning stations to the corresponding terminal Id. </p>
	 * 
	 * @param PinningStation
	 *            object.
	 */

	public void addPinningStationsToTerminal(PinningStation pinningStation) {

		String terminalId = pinningStation.getTerminal().getTerminalId();
		Set<String> pinningStations = pinningStationWithTerminalKey.get(terminalId);
		if (pinningStations == null) {
			pinningStations = new ConcurrentSkipListSet<String>();
			pinningStationWithTerminalKey.put(terminalId, pinningStations);
		}
		pinningStations.add(pinningStation.getPinningStationID());
	}

	/**
	 * Method is used to retrieve the list of available pinning stations.Getting Pinning stations id's.
	 * 
	 * @return list of pinning stations.
	 */
	public Set<String> getAllPinningStations() {
		return pinningStationMap.keySet();

	}

	/**
	 * Return QC related pinning station
	 * 
	 * @param key
	 *            i.e.qc
	 */
	public PinningStation getQCPinningStation(String qcId) {
		return qcToPinningStationMap.get(qcId);
	}

	/**
	 * Method is responsible to change the QC related pinning station. Replacing previous pinning station with current
	 * one if previous one is available.
	 */

	public void changeQCPinningStation(String qcId, String pinningStationId) {

		qcToPinningStationMap.put(qcId, getPinningStationDetails(pinningStationId));

	}

	/**
	 * Adds the qcLane details to the cache. QC Lane ID is the key
	 * 
	 * @param qcLane
	 */
	public void addQCLaneDetails(QCLane qcLane) {
		qcLanes.put(qcLane.getLaneID(), qcLane);
	}

	/**
	 * Saves the user violation to the cache.
	 * 
	 * @param violation
	 */
	public void addUserViolation(UserViolationAndDelay violation) {
		List<UserViolationAndDelay> violations = userViolations.get(violation.getUser().getUserID());

		if (violations == null) {
			violations = new ArrayList<UserViolationAndDelay>();
			userViolations.put(violation.getUser().getUserID(), violations);
		}

		violations.add(violation);
	}

	/**
	 * Retrieves the violations recorded for the specified user from the cache.
	 * 
	 * @param userId
	 * @return
	 */
	public List<UserViolationAndDelay> getUserViolations(String userId) {
		return userViolations.get(userId);
	}

	/**
	 * Adds the check lists associated with the specified role to the cache
	 * 
	 * @param role_id
	 *            - the role for which the checklist is being added
	 * @param checkList
	 *            - the details of checklist
	 */
	public void addCheckListForRole(String roleName, Set<CheckListHeader> checkListHeaders) {
		checkListPerRole.put(roleName, checkListHeaders);
	}

	/**
	 * Adds the check list header to the specified role.
	 * 
	 * @param roleName
	 * @param header
	 */
	public void addToExistsingRole(String roleName, CheckListHeader header) {
		Set<CheckListHeader> headers = checkListPerRole.get(roleName);
		if (headers == null) {
			headers = new HashSet<CheckListHeader>();
			checkListPerRole.put(roleName, headers);
		}

		headers.add(header);
	}

	/**
	 * Retrieves the checklist header details for the specified role
	 * 
	 * @param role_id
	 * @return CheckList Header
	 */
	public CheckListHeader getCheckListForRole(String roleName, String checkListHeaderType) {
		Set<CheckListHeader> availbaleHeaders = checkListPerRole.get(roleName);
		if (availbaleHeaders != null) {
			for (CheckListHeader header : availbaleHeaders) {
				if (header.getType().equals(checkListHeaderType)) {
					return header;
				}
			}
		}
		return null;
	}

	/**
	 * Retrieves the checkList item for the specified name
	 * 
	 * @param checkListName
	 * @return
	 */
	public CheckList getCheckList(String checkListId) {
		return checkLists.get(checkListId);
	}

	/**
	 * Adds the checkList to the cache with the headerID
	 * 
	 * @param checkList
	 */
	public void addCheckListItem(Integer headerId, CheckList checkList) {
		checkLists.put(headerId + ":" + checkList.getChecklistId(), checkList);
	}

	/**
	 * Adds the inspection status for the specified user to the Cache
	 * 
	 * @param userId
	 * @param status
	 *            - performed/cancelled
	 */
	public void addInspectionRecord(String userId, String status) {
		inspectionRecords.put(userId, status);
	}

	/**
	 * Retrieves the inspection status for the specified user ID
	 * 
	 * @param userId
	 * @return - inspection status of the user, null if not present
	 */
	public String getInspectionStatus(String userId) {
		return inspectionRecords.get(userId);
	}

	/**
	 * Retrieves the assigned ITVs for the specified equipment
	 * 
	 * @param equipmentId
	 *            - equipment which is having assigned ITV list
	 * @return set of ITVs
	 */
	public Set<ITV> getAssignedITVs(String equipmentId) {
		return itvPool.get(equipmentId);
	}

	/**
	 * Saves the list of ITVs assigned to the specified equipment in the cache
	 * 
	 * @param equipmentId
	 * @param itvList
	 */
	public void addAssignedITVs(String equipmentId, Set<ITV> itvList) {
		itvPool.put(equipmentId, itvList);
	}

	/**
	 * Retrieves the container details from the cache.
	 * 
	 * @param containerId
	 * @return Container
	 */
	public Container getContainerDetails(String containerId, String moveType) {
		Container container = containerDetails.get(containerId+moveType);
		if(container == null){
			container = getContainerDetails(containerId);
		}		
		return container;				
	}
	
	/**
	 * Retrieves the container details from the cache.
	 * 
	 * @param containerId
	 * @return Container
	 */
	public Container getContainerDetails(String containerId) {
		Container container = null;
		container = containerDetails.get(containerId+LOAD);
		if(container != null){
			return container;
		}else {
			container = containerDetails.get(containerId+DSCH);
			if(container != null){
				return container;
			}else {
				container = containerDetails.get(containerId);
				if(container != null){
					return container;
				}
			}
		}
		return container;
	}

	/**
	 * Saves the container details to the cache
	 * 
	 * @param container
	 */
	public void addContainer(Container container, String moveType) {
		if (container.getIsEmpty()) {
			container.setSealOn(false);
		} else {
			container.setSealOn(true);
		}
		
		if(moveType == null){
			moveType = "";
		}
		containerDetails.put(container.getContainerID()+moveType, container);
	}

	/**
	 * Deletes the container from the cache
	 * 
	 * @param container
	 */
	public void deleteContainer(String containerId) {
		containerDetails.remove(containerId+LOAD);
		containerDetails.remove(containerId+DSCH);
		containerDetails.remove(containerId+MI);
		containerDetails.remove(containerId+MO);
		containerDetails.remove(containerId+GI);
		containerDetails.remove(containerId+GO);
		containerDetails.remove(containerId);
	}

	/**
	 * Retrieves all the delay reason codes available in the cache with the specified delayType
	 * 
	 * @return
	 */
	public Set<DelayReasonCode> getDelayReasonCodes(String delayType) {
		return delayReasonCodes.get(delayType);
	}

	/**
	 * Retrieves all the trouble shoot areas available in the cache with the specified terminalId
	 * 
	 * @param terminalId
	 * @return set of available trouble shoot areas
	 */
	public Set<TroubleshootAreaMaster> getTroubleShootAreas(String terminalId) {
		return troubleshootAreaCache.get(terminalId);
	}

	/**
	 * Retrieves the TroubleshootArea based on the specified troubleShootAreaID
	 * 
	 * @param tsAreaId
	 * @param terminalId
	 * @return
	 */
	public TroubleshootAreaMaster getTroubleShootAreaById(String tsAreaId, String terminalId) {
		Set<TroubleshootAreaMaster> tsAreas = troubleshootAreaCache.get(terminalId);
		for (TroubleshootAreaMaster troubleshootArea : tsAreas) {
			if (troubleshootArea.getTroubleshootAreaId().equalsIgnoreCase(tsAreaId)) {
				return troubleshootArea;
			}
		}

		return null;
	}

	/**
	 * Retrieves the QCLane with the specified LaneId
	 * 
	 * @param laneId
	 * @return QCLane
	 */
	public QCLane getQcLane(String laneId) {
		return qcLanes.get(laneId);
	}

	/**
	 * Adds the specified container to the completed job list.
	 * 
	 * @param container
	 * @param userId
	 * @param rotationId
	 */
	public void addToCompletedJobs(CompletedContainerMoves container, String userId, String rotationId,String equipmentId) {
		
		String key = rotationId + equipmentId;
		
		ListOrderedMap<String, CompletedContainerMoves> completedJobs = completedJobList.get(key);
		if (completedJobs == null) {
			completedJobs = new ListOrderedMap<String, CompletedContainerMoves>();
			completedJobList.put(key, completedJobs);
		}

		synchronized (completedJobs) {
			completedJobs.put(0, container.getContainerId().concat(container.getMoveType()), container);
		}
	}

	/**
	 * Returns all the completed jobs performed by the specified user for the rotation id.
	 * 
	 * @param userId
	 * @param rotationId
	 * @return
	 */
	public Map<String, CompletedContainerMoves> getCompletedJobsForUser(String userId, String rotationId,
			String equipmentId) {
		Map<String, CompletedContainerMoves> userCompletedJobs = new LinkedHashMap<String, CompletedContainerMoves>();

		Map<String, CompletedContainerMoves> completedJobs = completedJobList.get(rotationId + equipmentId);
		if (completedJobs != null) {
			synchronized (completedJobs) {
				for (CompletedContainerMoves completedJob : completedJobs.values()) {
					if (completedJob.getUser() != null && completedJob.getUser().getUserID().equals(userId)) {
						userCompletedJobs.put(completedJob.getContainerId()+completedJob.getMoveType(), completedJob);
					}
				}
			}
		}
		return userCompletedJobs;
	}

	/**
	 * Retrieves the completed jobs for the specified equipment and rotation
	 * 
	 * @param rotationId
	 * @param equipmentId
	 * @return
	 */
	public Map<String, CompletedContainerMoves> getCompletedJobs(String rotationId, String equipmentId) {
		return completedJobList.get(rotationId + equipmentId);
	}

	/**
	 * Removes all the cache entries for the specified rotation
	 * 
	 * @param rotationId
	 */
	public void clearCompletedJobsForRotation(String rotationId) {
		for (String key : completedJobList.keySet()) {
			if (key.startsWith(rotationId)) {
				logger.logMsg(LOG_LEVEL.INFO, rotationId, "Removing completed jobs for: " + key);
				completedJobList.remove(key);
			}
		}
	}

	/**
	 * Assigns the specified HC user to the specified QC equipment
	 * 
	 * @param hcUserId
	 * @param qcEquipmentId
	 */
	public void assignHcToQcEquipment(String hcUserId, String qcEquipmentId) {
		hcToQcMapping.put(hcUserId, qcEquipmentId);
		qcToHcMapping.put(qcEquipmentId, hcUserId);
		logger.logMsg(LOG_LEVEL.DEBUG, qcEquipmentId, "Current QC-HC Mapping Keys - " + qcToHcMapping.keySet()
				+ ", Values-" + qcToHcMapping.values());
	}

	/**
	 * Retrieves the QC equipment allocated for the specified HC user
	 * 
	 * @param hcUserId
	 * @return
	 */
	public String getQCEquipmentAllocatedForHC(String hcUserId) {
		return hcToQcMapping.get(hcUserId);
	}

	/**
	 * Retrieves the HC user allocated for the specified QC equipment
	 * 
	 * @param qcEquipmentId
	 * @return
	 */
	public String getHCUserAllocatedForQC(String qcEquipmentId) {
		logger.logMsg(LOG_LEVEL.DEBUG, qcEquipmentId, "Current QC-HC Mapping Keys - " + qcToHcMapping.keySet()
				+ ", Values-" + qcToHcMapping.values());
		return qcToHcMapping.get(qcEquipmentId);
	}

	/**
	 * Adds container to the specified ITV equipment
	 * @param itvId
	 * @param containerId
	 */
	public void addItvToCntrDetails(String itvId, String containerId, String jobKey) {
		logger.logMsg(LOG_LEVEL.INFO, itvId, "Adding to ITV Container cache = " + containerId + jobKey);
		List<String> containerSet = itvToCntrDetails.get(itvId);
		
		if(containerSet == null){
			containerSet = new ArrayList<String>();
			itvToCntrDetails.put(itvId, containerSet);
		}
		containerSet.add(containerId+"_"+jobKey);
	}

	/**
	 * Retrieves the containers currently present on the ITV
	 * @param itvId
	 * @return
	 */
	public List<String> getItvToCntrDetails(String itvId) {
		List<String> contrDetails = itvToCntrDetails.get(itvId);
		logger.logMsg(LOG_LEVEL.INFO, itvId, "Got from ITV Container cache = " + contrDetails);
		
		List<String> conatinerIds = null;
		if(contrDetails != null){
			conatinerIds = new ArrayList<String>();
			for(String container:contrDetails){
				conatinerIds.add(container.substring(0, container.indexOf("_")));
			}
		}
		return conatinerIds;
	}
	
	/**
	 * Retrieves the job key from ITV job list
	 * 
	 * @param itvId
	 * @param containerId
	 * @return jobKey
	 */
	public String getjobKeyFromITVJobList(String itvId, String containerId) {
		List<String> contrDetails = itvToCntrDetails.get(itvId);
		logger.logMsg(LOG_LEVEL.INFO, itvId, "Got from ITV Container cache = " + contrDetails);
		
		if(contrDetails != null){
			for(String container:contrDetails){
				if(container.startsWith(containerId)){
					return container.substring(container.indexOf("_")+1);
				}
			}
		}
		return null;
	}

	/**
	 * Clears all the container details for the specified ITV id from the cache
	 * 
	 * @param equipmentID
	 */
	public void clearItvToCntrDetails(String equipmentID) {
		logger.logMsg(LOG_LEVEL.INFO, equipmentID, "Clearing the cache ");
		itvToCntrDetails.remove(equipmentID);
	}

	/**
	 * Returns the number of containers present on the specified ITV. If no container are present, returns 0
	 * 
	 * @param equipmentID
	 * @return
	 */
	public int getNumberOfCntrsOnITV(String equipmentID) {
		int noOfCntrs = 0;
		List<String> containersOnITV = itvToCntrDetails.get(equipmentID);
		if(containersOnITV != null){
			noOfCntrs = containersOnITV.size();
		}
		logger.logMsg(LOG_LEVEL.INFO, equipmentID, "The number of containers on ITV is " + noOfCntrs);
		return noOfCntrs;
	}

	public String getListOfCranesConfigured(String nodeID) {
		return nodeToCranesMapping.get(nodeID);
	}

	public void addListOfCranesToCache(String nodeID , String cranesList ) {
		nodeToCranesMapping.put(nodeID, cranesList);
	}


	/**
	 * Checks if ITV Equipment has the specified container details
	 * 
	 * @param itvId
	 * @param containerId
	 * @return
	 */
	public boolean isContainItv(String itvId, String containerId, String jobKey) {
		List<String> containersOnITV = itvToCntrDetails.get(itvId);
		boolean contains = false;
		if(containersOnITV != null && containersOnITV.contains(containerId+"_"+jobKey)){
			contains = true;
		}
		logger.logMsg(LOG_LEVEL.INFO, itvId, "the particular container" + containerId + jobKey + " is present in ITV = " + contains);
		return contains;
	}

	/**
	 * Method is responsible for setting the pinning required or not(true or false)
	 * 
	 * @param userId
	 * @param isRequired
	 *            (true or false)
	 */
	public void setPinningRequiredStatus(String userId, Boolean isRequired) {
		pinningRequiredStatus.put(userId, isRequired);
	}

	/**
	 * Method is responsible for getting the pinning status(true or false) based on userId.
	 * 
	 * @param userId
	 * @return true or false
	 */
	public Boolean getPinningRequiredStatus(String userId) {
		return pinningRequiredStatus.get(userId);
	}

	/**
	 * Retrieves the user details for the specified TerminalID
	 * 
	 * @param userID
	 * @return <User>
	 */
	public ShiftDetails getShiftDetails(String shiftKey) {
		return terminalToShiftMap.get(shiftKey);
	}

	public void addVesselLocationToItv(String cellLocation, String itvId) {
		logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Adding Location mappings as " +cellLocation + "->" + itvId);
		vesselLocationToItvDetails.put(cellLocation, itvId);
	}

	public String getItvFromVesselLocation(String cellLocation) {
		return vesselLocationToItvDetails.get(cellLocation);
	}

	public void removeItvFromVesselLocation(String cellLocation) {

		vesselLocationToItvDetails.remove(cellLocation);
	}

	/**
	 * Add user details to the Cache
	 * 
	 * @param user
	 */
	public void addShiftDetails(ShiftDetails shiftData) {
		terminalToShiftMap.put(shiftData.getTerminal().getTerminalId() + shiftData.getShiftType(), shiftData);
	}


    /**
    * Checks and removes the container details from cache if ITV equipment exists with the specified container Id
    * 
     * @param itvId
    * @return
    */
    public void removeItvToCntrDetails(String itvId, String containerId) {
    	List<String> containers =   itvToCntrDetails.get(itvId);
           if(containers != null){
                  logger.logMsg(LOG_LEVEL.INFO, itvId, "Clearing the container from cache  " + containerId);   
                  Iterator<String> iterator = containers.iterator();
                  while(iterator.hasNext()){
                        String element = iterator.next();
                        if(element.startsWith(containerId)){
                        	iterator.remove();
                        }
                  }                    
           }
    }

	public void flushITVCurrentLocation(String userId) {
		currentItvLocationMap.clear();
	}

	public void flushPinningStationDetails() {
		pinningStationMap.clear();
	}

	public void flushQCLaneDetails() {
		qcLanes.clear();
	}

	public void flushTroubleshootAreaDetails() {
		troubleshootAreaCache.clear();
	}

	public void flushCheckList() {
		checkLists.clear();
	}

	public void flushUserRoleChecklist() {
		checkListPerRole.clear();
	}

	public void flushUsers() {
		userMap.clear();
	}

	public void flushDeviceDetails() {
		deviceDetails.clear();
	}

	public void flushEquipmentDetails() {
		equipmentMap.clear();
	}

	public void flushDelayReasonCodes() {
		delayReasonCodes.clear();
	}

	public void flushActivityCodes() {
		activityDetails.clear();
	}

	/**
	 * Adds the specified record to the completed troubleshoot records cache
	 * 
	 * @param record
	 */
	public void addToCompletedTroubleShootRecords(TroubleShootRecord record) {
		if (record.getTroubleshootArea() != null) {
			List<TroubleShootRecord> completedRecords = completedTroubleShootRecordsCache.get(record
					.getTroubleshootArea());

			if (completedRecords == null) {
				completedRecords = new ArrayList<TroubleShootRecord>();
				completedTroubleShootRecordsCache.put(record.getTroubleshootArea(), completedRecords);
			}

			completedRecords.add(record);
		}
	}

	/**
	 * Returns the list of completed Trouble shoot records for the specified troubleshoot area
	 * 
	 * @param tsArea
	 * @return
	 */
	public List<TroubleShootRecord> getCompletedTroubleShootRecords(String tsArea) {
		return completedTroubleShootRecordsCache.get(tsArea);
	}

	/**
	 * Adds the role to the USer role cache
	 * 
	 * @param role
	 */
	public void addRoleToCache(UserRole role) {
		logger.logMsg(LOG_LEVEL.DEBUG, "", "Adding role - " + role.getRoleName());
		roleDetails.put(role.getRoleName(), role);
	}

	public void flushUserRoles() {
		roleDetails.clear();
	}

	/**
	 * Retrieves the User Role specified for the roleName
	 * 
	 * @param roleName
	 * @return
	 */
	public UserRole getRole(String roleName) {
		logger.logMsg(LOG_LEVEL.DEBUG, "", "retrieving role - " + roleName);
		return roleDetails.get(roleName);
	}

	/**
	 * Retrieves the trailerID based on itvID
	 * 
	 * @param itvID
	 * @return trailerID
	 */

	public String getTrailerNo(String itvID) {
		logger.logMsg(LOG_LEVEL.DEBUG, "", "retrieving itvID - " + itvID);
		return itvTrailerMapping.get(itvID);
	}

	/**
	 * add the specified itvID to the specified trailer number
	 * 
	 * @param itvID
	 * @param trailerNo
	 */
	public void addITVTrailer(String itvID, String trailerNo) {
		itvTrailerMapping.put(itvID, trailerNo);
	}

	/**
	 * remove the trailer number from ITV
	 * 
	 * @param itvID
	 */
	public void removeTrailerNoFromITV(String itvID) {
		itvTrailerMapping.remove(itvID);

	}

	/**
	 * retrieves the all used trailer numbers
	 * 
	 * @return
	 */
	public Collection<String> getUsedTrailerNos() {
		return itvTrailerMapping.values();
	}

	/**
	 * Removes the shuffled jobs
	 * 
	 * @param userId
	 */
	public void deleteFromshuffledJobList(String userId, String containerId, boolean startKey) {

        Map<String, ShuffleResponseEvent> shuffledJobs = shuffledJobList.get(userId);
		if (shuffledJobs != null) {
			for (String key :  shuffledJobs.keySet()) {
				if((startKey && key.startsWith(containerId)) || key.endsWith(containerId)){
					shuffledJobs.remove(key);
				}
			}
		}
	}


	/**
	 * Returns all the shuffled jobs performed by the specified user.
	 * 
	 * @param userId
	 * @param requestedContainer
	 * @param shuffuledContainer
	 * @return
	 */
	public Map<String, ShuffleResponseEvent> getShuffledJobsForUser(String userId) {
        return shuffledJobList.get(userId);
	}

	/**
	 * Retrieves the TroubleshootArea based on the specified troubleShootAreaID
	 * 
	 * @param tsAreaId
	 * @param terminalId
	 * @return
	 */
	/*  public ShuffleResponseEvent getShuffleJobs(String userId) {
        ConcurrentHashMap<String, ShuffleResponseEvent> usershuffledJobs = shuffledJobList.get(userId);
        for (ShuffleResponseEvent shuffleResponse :usershuffledJobs.values()) {

                return shuffleResponse;
            }
        }
	 */

	/**
	 * Retrieves the container which has been marked as selected job for the specified equipment.
	 * If no jobs are mapped as selected, returns null.
	 * 
	 * @param equipmentId
	 * @return containerId_MoveType or null
	 */
	public String getSelectedJob(String equipmentId){
		return selectedJobMap.get(equipmentId);
	}

	/**
	 * Adds the specified container as the selected job for the equipment
	 * @param equipmentId
	 * @param containerIdWithMoveType
	 */
	public void addJobSelection(String equipmentId, String containerIdWithMoveType){
		selectedJobMap.put(equipmentId, containerIdWithMoveType);
	}

	/**
	 * Removes the job selection marked for the specified equipment
	 * @param equipmentId
	 */
	public void removeJobSelection(String equipmentId){
		selectedJobMap.remove(equipmentId);
	}  
	
	/**
	 * Maps the container to ITV indicating that ITV is arriving to fetch this container
	 * 
	 * @param containerWithMoveType
	 * @param itvId
	 */
	public void addFetchContainerToItv(String containerWithMoveType, String itvId){
		itvFetchContainerDetails.put(containerWithMoveType, itvId);
	}
	
	/**
	 * Retrieves the ITV coming to fetch the container mentioned. 
	 * 
	 * @param containerWithMoveType
	 * @return null if no itv is found mapped to fetch the container
	 */
	public String getFetchingITVForContainer(String containerWithMoveType){
		return itvFetchContainerDetails.get(containerWithMoveType);
	}
	
	/**
	 * Removes the container to fetch ITV mapping from cache
	 * @param containerWithMoveType
	 */
	public void removeFetchContainerMappingToITV(String containerWithMoveType){
		itvFetchContainerDetails.remove(containerWithMoveType);
	}
	
	
	public  EquipmentJobListRequestStatus getEqJobListReqStatus(String equipmentId){
		return eqJobListReqStatus.get(equipmentId);
		
	}

	public void setEqJobListReqStatus(String equipmentId , EquipmentJobListRequestStatus eqJobStatus) {
		eqJobListReqStatus.put(equipmentId, eqJobStatus);
	}
	/**
	 * Method is used to remove the user completed jobs from completedJobList map
	 * @param key (UserId+Rotation+Equipment)
	 */
	public void removeUserCompletedJobs(String key) {
		completedJobList.remove(key);
	}
	
	/**
	 * Retrieves the TOS keep alive status
	 * @return
	 */
	public boolean getKeepAliveStatus(){
		return keepAliveStatus;
	}
	
	/**
	 * Sets the TOS keep alive status
	 * @param status
	 */
	public void updateKeepAliveStatus(boolean status){
		keepAliveStatus = status;
	}
	
	/**
	 * Removing the container mappings with the specified ITV id from the cache
	 * @param itvId
	 */
	public void removeItvMapping(String itvId){
		for (String key : vesselLocationToItvDetails.keySet()) {
			if (itvId.equalsIgnoreCase(vesselLocationToItvDetails.get(key))) {
				logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Removing the mapping for " +  key);
				vesselLocationToItvDetails.remove(key);
			}
		}
		
		for (String key : itvFetchContainerDetails.keySet()) {
			if (itvId.equalsIgnoreCase(itvFetchContainerDetails.get(key))) {
				logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Removing the mapping for " +  key);
				itvFetchContainerDetails.remove(key);
			}
		}
	}
	
	public void addDriveInstructionstoItv(String itvId, String driveEvents){
		currentItvInstructions.put(itvId, driveEvents);	
		logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Current ITV instructions " +  currentItvInstructions.get(itvId));
	}
	
	public String getCurrentITVInstructions(String itvId){
		logger.logMsg(LOG_LEVEL.DEBUG, itvId, "Existing Current ITV instructions " +  currentItvInstructions.get(itvId));
		return currentItvInstructions.get(itvId);
	}
	
	public void clearItvInstructions(String itvId){
		String valueSeparator = DeviceCommParameters.getInstance().getCommParameter(
	            VALUE_SEPERATOR_KEY);
	    String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(
	            ROW_SEPERATOR_KEY);
	    String itemSeparator = DeviceCommParameters.getInstance().getCommParameter(
	            ITEM_SEPERATOR_KEY);
		String currentInstructions = RDTCacheManager.getInstance().getCurrentITVInstructions(itvId);
		try {
			if(currentInstructions != null && currentInstructions.contains(FETCH)){
				String[] splitted = currentInstructions.toString().split("\\" + valueSeparator);
				String[] fetchContainers = splitted[3].split("\\"+ rowSeparator);
				for(String fetchContr : fetchContainers){
					removeFetchContainerMappingToITV(fetchContr.split("\\"+itemSeparator)[0]+splitted[6]);
				}
			}
		}catch(Exception ex){
			logger.logException("Caught exception while trying to remove fetch containers", ex);
		}
		
		currentItvInstructions.remove(itvId);
		logger.logMsg(LOG_LEVEL.DEBUG, itvId, "ITV instructions after clearing" +  currentItvInstructions.get(itvId));
	}
	
	public Collection<Set<ITV>> getCachedITVSFromITVPoolCache(){
		return itvPool!=null ? itvPool.values() : null;
	}	

	public void addIsoCode(String isoCode, ISOCodesMaster isoCodeDetails){
		isoCodesCache.put(isoCode, isoCodeDetails);
	}


	public void flushISOCodes() {
		isoCodesCache.clear();
	}
	
	public Collection<ISOCodesMaster> getISOCodes(){
		return isoCodesCache.values();
	}
}
