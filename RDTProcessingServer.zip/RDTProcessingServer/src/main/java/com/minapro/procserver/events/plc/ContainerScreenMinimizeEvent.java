package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ContainerScreenMinimizeEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3578028610178845551L;
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ContainerScreenMinimizeEvent [message=" + message + "]";
    }

}
