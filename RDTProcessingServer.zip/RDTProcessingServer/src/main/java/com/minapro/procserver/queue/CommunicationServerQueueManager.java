package com.minapro.procserver.queue;

import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Singleton Class which handles the configurations for the queue which will be consumed by RDT Communication Layer
 * 
 * @author Rosemary George
 *
 */
public class CommunicationServerQueueManager {
    private static final Boolean NON_TRANSACTED = false;
    /**
     * Connection factory name specified in the jndi properties
     */
    private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";
    /**
     * Terminal specific out queue which will be read by the communication server
     */
    private static final String DESTINATION_NAME_TERMINAL_INQ = "queue/rdt_inQ";
    
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);

    private MessageProducer producer;
    private Session session;
    private Connection connection;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CommunicationServerQueueManager.class);

    private static CommunicationServerQueueManager instance = new CommunicationServerQueueManager();

    private CommunicationServerQueueManager() {
    }

    /**
     * Configures the queue w.r.t the terminal
     * 
     * @return
     */
    public boolean configureQueue() {
        logger.logMsg(LOG_LEVEL.DEBUG, "", "Configuring the CommunicationServer Producer");

        try {

            Context context = new InitialContext();
            ConnectionFactory factory = (ConnectionFactory) context.lookup(CONNECTION_FACTORY_NAME);

            Destination destination = (Destination) context.lookup(DESTINATION_NAME_TERMINAL_INQ);

            connection = factory.createConnection();
            connection.start();

            session = connection.createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);
            producer = session.createProducer(destination);

        } catch (Exception ex) {
            logger.logException("Failed to configure Queue - Caught exception - ", ex);
            return false;
        }

        return true;
    }

    public static CommunicationServerQueueManager getInstance() {
        return instance;
    }

    /**
     * Posts the message to the RDT_INQ
     * 
     * @param event
     *            - the message to be posted to the communication server
     * @param operator
     *            - to identify operator specific queue on to which the message needs to be posted
     * @param terminal
     *            - to identify the terminal specific queue
     * @return boolean - true if the message is posted successfully, else false
     */
    public boolean postMessage(String messageToDevice, OPERATOR operator, String terminal) {
        try {
        	//Keep the eventID unique in case of notifications to avoid mixing up immediate acknowledgement
        	//(where same notification is sent to multiple users)
        	if(messageToDevice.startsWith(NOTIF)){
    			String[] msg = messageToDevice.split(VALUE_SEPARATOR);
    			messageToDevice = messageToDevice.replaceFirst(msg[2], UUID.randomUUID().toString());    			
    		}
        	
            TextMessage message = session.createTextMessage();
            message.setText(messageToDevice);

            message.setStringProperty("eventGenerator", operator.toString());
            producer.send(message);
            logger.logMsg(LOG_LEVEL.DEBUG, operator.toString(), "Posted message- " + messageToDevice + " Terminal -" + terminal);
        } catch (Exception ex) {
            logger.logException("Caught exception while trying to post the message - ", ex);
            return false;
        }

        return true;
    }

    /**
     * Closes all Queue related connections
     */
    public void closeConnection() {
        try {
            producer.close();
            session.close();
            connection.close();
        } catch (Exception e) {
            logger.logException("Caught exception while closing the connection, ignore - ", e);
        }
    }
}
