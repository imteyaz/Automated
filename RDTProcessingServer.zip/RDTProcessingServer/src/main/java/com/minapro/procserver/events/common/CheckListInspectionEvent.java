package com.minapro.procserver.events.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.CheckList;
import com.minapro.procserver.db.InspectionCheckListMapping;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the details of the pre-operational checklist inspection performed by an user.
 * 
 * @author Rosemary George
 *
 */
public class CheckListInspectionEvent extends Event implements Serializable {
    private static final long serialVersionUID = -8074637057436393316L;
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CheckListInspectionEvent.class);

    private static String itemSeparator = DeviceCommParameters.getInstance().getCommParameter(ITEM_SEPERATOR_KEY);
    private static String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    /**
     * List containing the checklistItems
     */
    private List<InspectionCheckListMapping> checkListItems;

    /**
     * Overall status of the inspection
     */
    private String status;

    private String checkListType;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<InspectionCheckListMapping> getCheckListItems() {
        return checkListItems;
    }

    /**
     * CheckList items will be of format itemId1-status|itemId2-status|itemId3-status This will be parsed and put into
     * the hash map
     * 
     * @param checkListItems
     */
    public void setCheckListItems(String checkListItems) {
        this.checkListItems = new ArrayList<InspectionCheckListMapping>();
        try {
            String[] items = checkListItems.split("\\" + rowSeparator);
            String[] itemValue;
            InspectionCheckListMapping mapping;
            for (String item : items) {
                itemValue = item.split("\\" + itemSeparator);
                CheckList checkList = RDTCacheManager.getInstance().getCheckList(itemValue[0]);
                if (checkList != null) {
                    mapping = new InspectionCheckListMapping();
                    mapping.getPk().setCheckListItem(checkList);
                    mapping.setStatus(itemValue[1]);

                    this.checkListItems.add(mapping);
                }
            }
        } catch (Exception ex) {
            logger.logException("Caught exception ", ex);
        }
    }

    @Override
    public String toString() {
        return "CheckListInspectionEvent [status=" + status + ", UserID=" + getUserID() + ", EquipmentID="
                + getEquipmentID() + ", TerminalID=" + getTerminalID() + "]";
    }

    public String getCheckListType() {
        return checkListType;
    }

    public void setCheckListType(String checkListType) {
        this.checkListType = checkListType;
    }

}
