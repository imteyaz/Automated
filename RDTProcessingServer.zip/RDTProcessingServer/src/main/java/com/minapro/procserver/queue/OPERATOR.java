package com.minapro.procserver.queue;

import java.io.Serializable;

/**
 * Possible list of operators for MinaPro
 * 
 * @author Rosemary George
 *
 */
public enum OPERATOR implements Serializable {
    ITV, QC, HC, CHE, FOREMAN, VSUP, GSUP, YSUP, COMMON, TSC,CHE_COMMON

}
