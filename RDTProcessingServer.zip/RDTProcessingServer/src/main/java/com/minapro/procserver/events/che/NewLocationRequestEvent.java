package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the new container request details from the UI
 * 
 * @author 1201257
 * 
 */
public class NewLocationRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3752416667469284618L;
    /**
     * ID of the new location container
     */
    private String containerID;

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    @Override
    public String toString() {
        return "NewLocationRequestEvent [containerID=" + containerID + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }

}
