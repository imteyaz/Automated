package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding the application parameter details
 * 
 * @author Venkataramana.ch
 *
 */
@Entity
@Table(name = "MP_APPLICATIONPARAMETER_MASTER")
public class ApplicationParameter extends Audit implements Serializable {

    private static final long serialVersionUID = 4873099979245157444L;

    @Id
    @Column(name = "PARAMETER_CODE", nullable = false)
    private String parameterCode;

    @Column(name = "PARAMETER_VALUE", nullable = false)
    private String parameterValue;

	@Column(name = "DESCRIPTION")
    private String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "UNIT", referencedColumnName = "UNIT_ID")
    private Unit unit;

    public String getParameterCode() {
        return parameterCode;
    }

    public void setParameterCode(String parameterCode) {
        this.parameterCode = parameterCode;
    }

    public String getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }
    

    @Override
    public String toString() {
        return "ApplicationParameter [parameterCode=" + parameterCode
                + ", parameterValue=" + parameterValue + ", description="
                + description + ", unit=" + unit + "]";
    }
}
