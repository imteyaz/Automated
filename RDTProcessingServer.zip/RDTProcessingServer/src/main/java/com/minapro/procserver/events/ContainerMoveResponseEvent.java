package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the status of the container confirmation. In case of commit failure at TOS, the errorMessage will
 * hold the reason received from TOS
 * 
 * @author Rosemary George
 *
 */
public class ContainerMoveResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = -5002605606102101556L;

    /**
     * Indicates the container which has been moved
     */
    private String containerId;

    /**
     * Indicates the error message received from TOS
     */
    private String errorMessage;

    /**
     * Indicates the status of the container move event - true if it is successfully committed in TOS, else false.
     */
    private boolean status;
    
    /**
     * If true  -Indicates that the event is raised as pre job confirmation. 
     */
    private boolean preJobConfirmation;
    
    private String moveType;
    
    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public boolean isPreJobConfirmation() {
		return preJobConfirmation;
	}

	public void setPreJobConfirmation(boolean preJobConfirmation) {
		this.preJobConfirmation = preJobConfirmation;
	}

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

	@Override
	public String toString() {
		return "ContainerMoveResponseEvent [containerId=" + containerId + ", errorMessage=" + errorMessage
				+ ", status=" + status + ", preJobConfirmation=" + preJobConfirmation + ", moveType=" + moveType
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()="
				+ getEventID() + "]";
	}
}
