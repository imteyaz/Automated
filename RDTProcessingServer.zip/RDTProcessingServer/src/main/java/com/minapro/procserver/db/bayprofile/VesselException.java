package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the vessel exception details
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_VESSEL_EXCEPTIONS")
public class VesselException implements Serializable {
    private static final long serialVersionUID = -7685072034871568800L;
    
    @Id
    @SequenceGenerator(name = "id_gen", sequenceName = "MP_VESSEL_EXCEPTIONS_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "id_gen")
    @Column(name = "VLS_EXCEPTION_ID", nullable = false)
    private Integer vesselExceptionId;
    
    @Column(name = "INT_VSL_NO", nullable = false)
    private Integer vesselNo;
    
    @Column(name = "ROTATION_NO", nullable = false)
    private Integer rotation;
    
    @Column(name = "EXCEPTION_TYPE", nullable = false)
    private String exceptionType;
    
    @Column(name = "EXCEPTION_DESC")
    private String description;
    
    @Column(name = "BAY_NO")
    private String bay;
    
    @Column(name = "ROW_NO")
    private String row;
    
    @Column(name = "TIER_NO")
    private String tier;
    
    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDateTime;
    
    @Column(name = "CREATED_BY", nullable = false)
    private String createdBy;
    
    
    public Integer getVesselExceptionId() {
        return vesselExceptionId;
    }

    public void setVesselExceptionId(Integer vesselExceptionId) {
        this.vesselExceptionId = vesselExceptionId;
    }
    
    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }
    
    public Integer getRotation() {
        return rotation;
    }

    public void setRotation(Integer rotation) {
        this.rotation = rotation;
    }
    
    public String getExceptionType() {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getBay() {
        return bay;
    }

    public void setBay(String bay) {
        this.bay = bay;
    }
    
    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }
    
    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }
       
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public String toString() {
        return "VesselException [vesselExceptionId=" + vesselExceptionId + ", vesselNo=" + vesselNo + ", rotation="
                + rotation + ", exceptionType=" + exceptionType + ", description=" + description + ", bay=" + bay
                + ", row=" + row + ", tier=" + tier + ", createdDateTime=" + createdDateTime + ", createdBy="
                + createdBy + "]";
    } 

    public enum exceptionType{
        BAY_MISSING,
        CELL_MISSING
    }
}
