package com.minapro.procserver;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CHE_PLC_READ_INTERVAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.PLC_READ_INTERVAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.WORKING_EQUIPMENTS_READ_INTERVAL;

import java.io.File;
import java.util.concurrent.TimeUnit;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Cancellable;
import akka.actor.Props;

import com.minapro.procserver.actors.CHEJobListPollingActor;
import com.minapro.procserver.actors.CHEPLCReaderActor;
import com.minapro.procserver.actors.EsperActor;
import com.minapro.procserver.actors.HeavyHookActor;
import com.minapro.procserver.actors.ITVJobListPollingActor;
import com.minapro.procserver.actors.InitSingletonActor;
import com.minapro.procserver.actors.JobListPollingActor;
import com.minapro.procserver.actors.OperatorMessagePollerActor;
import com.minapro.procserver.actors.PLCReaderActor;
import com.minapro.procserver.actors.PlannedMovesPollingActor;
import com.minapro.procserver.actors.RDTProcessServerMasterActor;
import com.minapro.procserver.actors.WorkingEquipmentsPLCStatusPollingActor;
import com.minapro.procserver.actors.common.ITVWaitingTimePollingActor;
import com.minapro.procserver.actors.common.YardInventoryUpdatePollingActor;
import com.minapro.procserver.actors.plc.ResetQCUsersMovesPerHour;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.queue.CommunicationServerListener;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBListener;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.YardSkeletonConstructor;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

/**
 * Singleton main class of the RDT Processing server
 * 
 * @author Rosemary George
 *
 */
public class RDTProcessingServer {
	/**
	 * Terminal Actor system - all the events related to Terminal are routed to this actor system
	 */
	private ActorSystem terminalActorSystem;
	/**
	 * Terminal Master Actor - Handles all the events related to this terminal
	 */
	private ActorRef terminalMasterActor;

	/**
	 * Terminal Esper Actor - Handles all the PLC events related to terminal
	 */
	private ActorRef terminalEsperActor;

	// Background actor to poll for joblist updates for all logged in users.
	private ActorRef terminalJobListPollActor;
	private ActorRef terminal2PlannedMovesPollActor;
	private ActorRef movesPerHourResetActor;
	private ActorRef terminalPLCActor;
	private ActorRef terminalCHEPLCActor;
	private ActorRef terminalCHEJobListPollActor;
	private ActorRef terminalITVJobListPollActor;
	private ActorRef terminalITVWaitingTimePollActor;
	private ActorRef terminalWorkingEquipmentsPollingActor;
	private ActorRef terminalYardInventoryUpdatePollActor;
	private Cancellable masterNodeHealthCheck = null;

	private Cancellable jobListScheduler = null;
	private Cancellable plannedMovesScheduler = null;
	private Cancellable plcScheduler = null;
	private Cancellable chePlcScheduler = null;
	private Cancellable cheJobListScheduler = null;
	private Cancellable itvJobListScheduler = null;
	private Cancellable yardInventoryScheduler = null;
	/**
	 * Indicates whether this acts as the master node or not
	 */
	private boolean isMasterNode = false;

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTProcessingServer.class);

	/**
	 * singleton instance of the ProcessingServer
	 */
	private static final RDTProcessingServer INSTANCE = new RDTProcessingServer();

	private RDTProcessingServer() {
	}

	/**
	 * Provides the RDTProcessingServer instance
	 * 
	 * @return RDTProcessingServer
	 */
	public static RDTProcessingServer getInstance() {
		return INSTANCE;
	}

	/**
	 * Creates and initializes terminal specific actor systems, queues and its listeners
	 */
	public void init(boolean isMaster) {
		logger.logMsg(LOG_LEVEL.INFO, "", "Initializing RDTProcessingSerevr as MasterNode " + isMaster);

		try {
			Config config = ConfigFactory.parseFile(new File(RDTProcessingServerConstants.CONFIG_DIRECTORY
					+ "application.conf"));
			terminalActorSystem = ActorSystem.create("RDTProcessAppT2",
					ConfigFactory.load(config).getConfig("minaProConf"));
			terminalMasterActor = terminalActorSystem.actorOf(Props.create(RDTProcessServerMasterActor.class),
					"masterT2");

			movesPerHourResetActor = terminalActorSystem.actorOf(Props.create(ResetQCUsersMovesPerHour.class), "MPH");
			terminalJobListPollActor = terminalActorSystem.actorOf(Props.create(JobListPollingActor.class),
					"jobListPoll");
			terminal2PlannedMovesPollActor = terminalActorSystem.actorOf(Props.create(PlannedMovesPollingActor.class),
					"plannedMovesPollar");
			terminalCHEJobListPollActor = terminalActorSystem.actorOf(Props.create(CHEJobListPollingActor.class),
					"cheJobListPoll");
			terminalITVJobListPollActor = terminalActorSystem.actorOf(Props.create(ITVJobListPollingActor.class),
					"itvJobListPoll");
			terminalITVWaitingTimePollActor = terminalActorSystem.actorOf(Props.create(ITVWaitingTimePollingActor.class),
				"itvWaitingTimePoll"); 
			terminalWorkingEquipmentsPollingActor = terminalActorSystem.actorOf(Props.create(WorkingEquipmentsPLCStatusPollingActor.class),
					"workingEqpmtPLCPoll"); 
			terminalYardInventoryUpdatePollActor = terminalActorSystem.actorOf(Props.create(YardInventoryUpdatePollingActor.class),"yardInventoryUpdatePollar");
			
			boolean queueInitializationStatus = ESBQueueManager.getInstance().configureQueue();
			if (!queueInitializationStatus) {
				shutDown();
			}

			// Thread listening for the events from ESB Server
			Thread esbListener = new Thread(new ESBListener());
			esbListener.start();

			if (isMaster) {

				ActorRef ref = terminalActorSystem.actorOf(Props.create(InitSingletonActor.class), "initActor");
				terminalActorSystem.scheduler().scheduleOnce(Duration.create(0, TimeUnit.SECONDS), ref, "init",
						terminalActorSystem.dispatcher(), ref);
				//A New Thread Is Added to prepare block related skeleton at the time server start up time.
				new Thread(new YardSkeletonConstructor()).start();
				startSchedulers();
				isMasterNode = true;
				//startRMIServer();			

			} else {
				/*ActorRef ref = terminalActorSystem.actorOf(Props.create(MasterNodeHealthCheckActor.class),
						"masterHealthCheckActor");
				masterNodeHealthCheck = terminalActorSystem.scheduler().schedule(Duration.create(0, TimeUnit.SECONDS),
						Duration.create(5, TimeUnit.SECONDS), ref, "HEARTBEAT", terminalActorSystem.dispatcher(), ref);*/
			}

			terminalEsperActor = terminalActorSystem.actorOf(Props.create(EsperActor.class), "esperT2");
			logger.logMsg(LOG_LEVEL.INFO, "***********************", "STARTED ESPER - " + terminalEsperActor);

			terminalPLCActor = RDTProcessingServer.getInstance().getActorSystem()
					.actorOf(Props.create(PLCReaderActor.class), "PLCT2");

			terminalCHEPLCActor = RDTProcessingServer.getInstance().getActorSystem()
					.actorOf(Props.create(CHEPLCReaderActor.class), "CHEPLCT2");

			queueInitializationStatus = CommunicationServerQueueManager.getInstance().configureQueue();
			if (!queueInitializationStatus) {
				shutDown();
			}

			// Thread listening for the events from Communication Server
			Thread commServerListener = new Thread(new CommunicationServerListener());
			commServerListener.start();

		} catch (Exception ex) {
			logger.logException("RDTProcessingServer initialization caught exception - ", ex);
			shutDown();
		}

		logger.logMsg(LOG_LEVEL.INFO, "", "RDTProcessingSerevr - Initialization complete");

	}
	
	/**
	 * Starts the RMI server. If not able to start, shutdown the system
	 */
	private void startRMIServer(){
		try {
			new RmiServer();
		} catch (Exception e) {
			logger.logException("Caught exception while trying to start the RMI server", e);
			shutDown();
		}
	}

	/**
	 * Starts the PLC scheduler in case it is not already started
	 */
	public void startPLCScheduler(String string) {
		logger.logMsg(LOG_LEVEL.DEBUG, " ", "Received PLC Start Instruction");
		if ((plcScheduler == null) || plcScheduler.isCancelled()) {
			logger.logMsg(LOG_LEVEL.DEBUG, " ", "Starting QC  PLC Scheduler for the first time ");
			int frequency = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(PLC_READ_INTERVAL));
			if ("QC".equals(string)) {
				// AKKA Scheduler to read the PLC data from DB for every 5 Sec
				plcScheduler = terminalActorSystem.scheduler().schedule(Duration.create(0, TimeUnit.SECONDS),
						Duration.create(frequency, TimeUnit.SECONDS), terminalPLCActor, "READ",
						terminalActorSystem.dispatcher(), terminalPLCActor);
			}
		} else {
			logger.logMsg(LOG_LEVEL.DEBUG, " ", "QC PLC Scheduler is already Started ");
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Current Logged in Users in cache"
					+ RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache());
		}

		if ((chePlcScheduler == null) || chePlcScheduler.isCancelled()) {
			logger.logMsg(LOG_LEVEL.DEBUG, " ", "Starting CHE PLC Scheduler for the first time ");
			int frequency = Integer
					.parseInt(DeviceCommParameters.getInstance().getCommParameter(CHE_PLC_READ_INTERVAL));
			if ("CHE".equals(string)) {
				// AKKA Scheduler to read the CHE PLC data from DB for every 5 Sec
				chePlcScheduler = terminalActorSystem.scheduler().schedule(Duration.create(0, TimeUnit.SECONDS),
						Duration.create(frequency, TimeUnit.SECONDS), terminalCHEPLCActor, "READ",
						terminalActorSystem.dispatcher(), terminalCHEPLCActor);
			}
		} else {
			logger.logMsg(LOG_LEVEL.DEBUG, " ", "CHE PLC Scheduler is already Started ");
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Current Logged in Users in cache"
					+ RDTPLCCacheManager.getInstance().sizeOfCHELoggedInCache());
		}
	}

	/**
	 * Stops the PLC scheduler
	 */
	public void stopPLCScheduler(String operator) {

		if (RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache() == 0) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Current Logged in QC Users in cache"
					+ RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache());
			if ("QC".equals(operator)) {
				logger.logMsg(LOG_LEVEL.DEBUG, " ", "Stopped QC PLC Polling");
				if (plcScheduler != null) {
					plcScheduler.cancel();
					logger.logMsg(LOG_LEVEL.DEBUG, " ", "Cancelled :" + plcScheduler.isCancelled());
				}
			}
		}

		if (RDTPLCCacheManager.getInstance().sizeOfCHELoggedInCache() == 0) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Current Logged in CHE Users in cache"
					+ RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache());
			if ("CHE".equals(operator)) {
				logger.logMsg(LOG_LEVEL.DEBUG, " ", "Stopped CHE/RMG PLC Polling");
				if (chePlcScheduler != null) {
					chePlcScheduler.cancel();
					logger.logMsg(LOG_LEVEL.DEBUG, " ", "Cancelled :" + chePlcScheduler.isCancelled());
				}
			}
		}
	}

	/**
	 * Stops the master node health check scheduler
	 */
	public void stopMasterNodeHealthCheckScheduler() {
		masterNodeHealthCheck.cancel();
		logger.logMsg(LOG_LEVEL.DEBUG, " ", "Stopped master node Health check - " + masterNodeHealthCheck.isCancelled());
	}

	/**
	 * <p>Starts all the scheduler tasks needed for the server.</p>
	 * 
	 * <p> Background schedulers running are </p> <p> - PLCReader </p> <p> - HeavyHook </p> <p> - JobListPoll </p>
	 */
	public void startSchedulers() {
		// Background actor to determine the heavy hook QC operator
		ActorRef terminal2HeavyHookActor = terminalActorSystem.actorOf(Props.create(HeavyHookActor.class), "heavyHook");
		terminalActorSystem.scheduler().schedule(Duration.create(10, TimeUnit.MINUTES),
				Duration.create(5, TimeUnit.MINUTES), terminal2HeavyHookActor, "READ",
				terminalActorSystem.dispatcher(), terminal2HeavyHookActor);
		
		//First Param is initial delay,Second param is the repeating interval of the scheduler
		terminalActorSystem.scheduler().schedule(Duration.create(5, TimeUnit.MINUTES),
				Duration.create(30, TimeUnit.SECONDS), terminalITVWaitingTimePollActor, "ITV_WAITING_POLL",
				terminalActorSystem.dispatcher(), terminalITVWaitingTimePollActor);
		
		final int workingEquipmentsPollTime = Integer.parseInt(DeviceCommParameters.getInstance().
				getCommParameter(WORKING_EQUIPMENTS_READ_INTERVAL));
		
		terminalActorSystem.scheduler().schedule(Duration.create(3, TimeUnit.MINUTES),
				Duration.create(workingEquipmentsPollTime, TimeUnit.SECONDS), terminalWorkingEquipmentsPollingActor, "PLC_EQUIPMENTS_DATA",
				terminalActorSystem.dispatcher(), terminalWorkingEquipmentsPollingActor);
		
		// Background actor to determine the heavy hook QC operator
		ActorRef operatorMsgPollerActor = terminalActorSystem.actorOf(Props.create(OperatorMessagePollerActor.class), "OperatorMessagePoller");
		terminalActorSystem.scheduler().schedule(Duration.create(10, TimeUnit.MINUTES),
				Duration.create(3, TimeUnit.MINUTES), operatorMsgPollerActor, "READ",
				terminalActorSystem.dispatcher(), operatorMsgPollerActor);
		
	}
	
	/**
	 * Following method is responsible for calling Planned Moves Scheduler. First if condition checking whether
	 * scheduler is running with default values or not and input values are equal to default values in that case no need
	 * to restart the scheduler.In this case simply ignoring the request.
	 * 
	 * If plannedMovesScheduler is already running and not satisfying the above condition then stop the current
	 * scheduler and restarting scheduler with new values.
	 * 
	 * @param initialDelay
	 *            default value
	 * @param frequencyInterval
	 *            (1,2,..etc)
	 * @param unit
	 *            (Seconds,Minutes,Hours)
	 */

	public void restartPlannedMovesScheduler(int initialDelay, int frequencyInterval, TimeUnit unit) {
	
		logger.logMsg(LOG_LEVEL.INFO, "", " Started restartPlannedMovesScheduler() with Input Values  Initial Delay "
				+ initialDelay + "  Frequency Interval " + frequencyInterval + " Time Unit " + unit);

		if (initialDelay == 1 && plannedMovesScheduler != null) {
			logger.logMsg(LOG_LEVEL.DEBUG, "",
					"Already Planned Moves Scheduler started with initail delay 1 minutes, ignore ");
			return;
		}

		if (plannedMovesScheduler != null) {
			logger.logMsg(LOG_LEVEL.INFO, "", "Stopping the Planned Moves Scheduler " + plannedMovesScheduler.cancel());
		}

		plannedMovesScheduler = terminalActorSystem.scheduler().schedule(
				Duration.create(initialDelay, TimeUnit.MINUTES), Duration.create(frequencyInterval, unit),
				terminal2PlannedMovesPollActor, "Planned Moves Scheduler Calling", terminalActorSystem.dispatcher(),
				terminal2PlannedMovesPollActor);
	}
	
	/**
	 * Restarts the job list polling scheduler with the new frequency interval for the specified role(QC/CHE/ITV)
	 * 
	 * @param initialDelay
	 * @param frequencyInterval
	 * @param unit
	 * @param role
	 */
	public void restartJobListScheduler(int initialDelay, int frequencyInterval, TimeUnit unit, OPERATOR role) {
		
		logger.logMsg(LOG_LEVEL.INFO, role.toString(), " Started restartJobListScheduler() with Initial Delay "
				+ initialDelay + "  Frequency Interval " + frequencyInterval + " Time Unit " + unit);

		String message = "JobList Read";
		TimeUnit defaultTimeUnit = TimeUnit.MINUTES;
		
		switch (role) {
		case CHE :
			if (cheJobListScheduler != null) {
				logger.logMsg(LOG_LEVEL.INFO, role.toString(), "Stopping the job list scheduler :  " + cheJobListScheduler.cancel());
			}

			cheJobListScheduler = terminalActorSystem.scheduler().schedule(Duration.create(initialDelay,defaultTimeUnit),
					Duration.create(frequencyInterval, unit), terminalCHEJobListPollActor, message, 
					terminalActorSystem.dispatcher(), terminalCHEJobListPollActor);
			
			break;
		case QC :
			if (jobListScheduler != null) {
				logger.logMsg(LOG_LEVEL.INFO, role.toString(), "Stopping the job list scheduler :  " + jobListScheduler.cancel());
			}

			jobListScheduler = terminalActorSystem.scheduler().schedule(Duration.create(initialDelay,defaultTimeUnit),
					Duration.create(frequencyInterval, unit), terminalJobListPollActor, message, 
					terminalActorSystem.dispatcher(), terminalJobListPollActor);
			
			break;
		case ITV :
			if (itvJobListScheduler != null) {
				logger.logMsg(LOG_LEVEL.INFO, role.toString(), "Stopping the job list scheduler :  " + itvJobListScheduler.cancel());
			}

			itvJobListScheduler = terminalActorSystem.scheduler().schedule(Duration.create(initialDelay,defaultTimeUnit),
					Duration.create(frequencyInterval, unit), terminalITVJobListPollActor, message, 
					terminalActorSystem.dispatcher(), terminalITVJobListPollActor);
			break;
		case CHE_COMMON :
			initialDelay =10;
			defaultTimeUnit = TimeUnit.SECONDS;
			
			if (yardInventoryScheduler != null) {
				logger.logMsg(LOG_LEVEL.INFO, role.toString(), "Stopping the job list scheduler :  " + yardInventoryScheduler.cancel());
			}

			yardInventoryScheduler = terminalActorSystem.scheduler().schedule(Duration.create(initialDelay,defaultTimeUnit),
					Duration.create(frequencyInterval, unit), terminalYardInventoryUpdatePollActor, message, 
					terminalActorSystem.dispatcher(), terminalYardInventoryUpdatePollActor);
			
			break;
		default :
			logger.logMsg(LOG_LEVEL.INFO, role.toString(), "No job list scheduler planned for the role");	
			return;
		}  		
	}	
	
	/**
	 * Retrieves the terminal specific Master actor instance
	 * 
	 * @return ActorRef
	 */
	public ActorRef getMasterActor() {
		return terminalMasterActor;
	}

	/**
	 * Retrieves the ESPER actor instance
	 * 
	 * @param terminal
	 * @return ActorRef
	 */
	public ActorRef getEsperActor() {
		return terminalEsperActor;
	}

	/**
	 * Retrieves the Terminal ActorSystem actor instance
	 * 
	 * @param terminal
	 * @return ActorSystem
	 */
	public ActorSystem getActorSystem() {
		return terminalActorSystem;
	}

	/**
	 * Retrieves the Moves per Hour Reset actor instance
	 * 
	 * @param terminal
	 * @return ActorRef
	 */
	public ActorRef getResetMovesPerHourActor() {
		return movesPerHourResetActor;
	}

	/**
	 * Shuts down actor system, queues and stops the application
	 */
	public void shutDown() {
		terminalActorSystem.shutdown();

		ESBQueueManager.getInstance().closeConnection();
		CommunicationServerQueueManager.getInstance().closeConnection();

		logger.logMsg(LOG_LEVEL.FATAL, "", "Recieved shutdown instruction - Application going down");
	}

	/**
	 * Returns true if this process has started as master node
	 * 
	 * @return
	 */
	public boolean checkIfMasterNode() {
		return isMasterNode;
	}

	/**
	 * Marks this instance of RDT processing server as the master node
	 */
	public void markAsMasterNode() {
		isMasterNode = true;
	}

	/**
	 * Possible Terminal options.
	 * 
	 * @author 3123248
	 *
	 */
	public enum TERMINAL {
		ONE(1), TWO(2);

		private int value;

		private TERMINAL(int value) {
			this.value = value;
		}

		public int getTerminalID() {
			return value;
		}
	}

	public static void main(String[] args) {
		boolean isMaster = false;
		if (args != null && args.length > 0) {
			isMaster = Boolean.parseBoolean(args[0]);
		}
		RDTProcessingServer.getInstance().init(isMaster);
	}
}
