package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * ValueObject holding the container details for a particular twin/tandem job
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_TWINTANDEM_CONTAINER_LIST")
@AssociationOverrides({@AssociationOverride(name = "pk.twinTandemId", joinColumns = @JoinColumn(name = "TWINTANDEM_ID")) })
public class TwinTandemContainerList implements Serializable{
   
    private static final long serialVersionUID = -6328589554088371588L;

    @EmbeddedId
    private TwinTandemContainerListPK pk = new TwinTandemContainerListPK();
    
    @Column(name="FROM_LOCATION")
    private String fromLocation;
    
    @Column(name="TO_LOCATION" )
    private String toLocation;
    
    @Column(name="REFCONTAINER_ID")
    private String refContainerId;
    
    @Column(name="REFFROM_LOCATION")
    private String refContrFromLocation;
    
    @Column(name="REFTO_LOCATION")
    private String refContrToLocation;
    
    public TwinTandemContainerList() {        
    }
    
    public TwinTandemContainerList(String containerId, String toLocation, String fromLocation, String refContainerId,
            String refFromLocation, String refToLocation){
        pk.setContainerId(containerId);
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.refContainerId = refContainerId;
        this.refContrFromLocation = refFromLocation;
        this.refContrToLocation = refToLocation;
    }
    //Added By UmaMahesh
    public TwinTandemContainerList(String containerId, String toLocation, String fromLocation, String refContainerId,
            String refFromLocation, String refToLocation,Integer twinTandemId){
    	this(containerId,toLocation,fromLocation,refContainerId,refFromLocation,refToLocation);
        TwinTandemJobs twinJob = new TwinTandemJobs();
        twinJob.setTwinTandemId(twinTandemId);
        pk.setTwinTandemId(twinJob);
    }
    @Transient
    public TwinTandemJobs getTwinTandemId() {
        return pk.getTwinTandemId();
    }

    public void setTwinTandemId(TwinTandemJobs twinTandemId) {
        pk.setTwinTandemId(twinTandemId);
    }

    @Transient
    public String getContainerId() {
        return pk.getContainerId();
    }

    public void setContainerId(String containerId) {
        pk.setContainerId(containerId);
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getRefContainerId() {
        return refContainerId;
    }

    public void setRefContainerId(String refContainerId) {
        this.refContainerId = refContainerId;
    }

    public String getRefContrFromLocation() {
        return refContrFromLocation;
    }

    public void setRefContrFromLocation(String refContrFromLocation) {
        this.refContrFromLocation = refContrFromLocation;
    }

    public String getRefContrToLocation() {
        return refContrToLocation;
    }

    public void setRefContrToLocation(String refContrToLocation) {
        this.refContrToLocation = refContrToLocation;
    }
    
    @Override
  	public String toString() {
  		return "TwinTandemContainerList [pk=" + pk.getContainerId() + ", fromLocation="
  				+ fromLocation + ", toLocation=" + toLocation
  				+ ", refContainerId=" + refContainerId
  				+ ", refContrFromLocation=" + refContrFromLocation
  				+ ", refContrToLocation=" + refContrToLocation + "]";
  	}
}
