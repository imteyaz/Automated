package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_BERTHED_VESSEL")
public class BerthedVessel implements Serializable {

    private static final long serialVersionUID = -1154687145133540969L;
    @Id
    @Column(name = "VESSEL_CODE", nullable = false)
    private String vesselCode;
    
    @Column(name = "ROTATION_ID")
    private String rotationId;
    
    @Column(name = "BERTH_ID")
    private String berthId;
    
    @Column(name = "BERTH_DATETIME")
    private Date berthedDate;
    
    @Column(name = "VOYAGE")
    private String voyage;
    
    @Column(name="VESSEL_NM_TOS")
    private String vesselNameFromTos;
    
    @Column(name="BERTH_SIDE")
    private String berthSide;
    
    public String getBerthSide() {
		return berthSide;
	}

	public void setBerthSide(String berthSide) {
		this.berthSide = berthSide;
	}

	public String getVoyage() {
		return voyage;
	}

	public void setVoyage(String voyage) {
		this.voyage = voyage;
	}

	public String getVesselNameFromTos() {
		return vesselNameFromTos;
	}

	public void setVesselNameFromTos(String vesselNameFromTos) {
		this.vesselNameFromTos = vesselNameFromTos;
	}

	public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getBerthId() {
        return berthId;
    }

    public void setBerthId(String berthId) {
        this.berthId = berthId;
    }

    public Date getBerthedDate() {
        return berthedDate;
    }

    public void setBerthedDate(Date berthedDate) {
        this.berthedDate = berthedDate;
    }

	@Override
	public String toString() {
		return "BerthedVessel [vesselCode=" + vesselCode + ", rotationId=" + rotationId + ", berthId=" + berthId
				+ ", berthedDate=" + berthedDate + ", voyage=" + voyage + ", vesselNameFromTos=" + vesselNameFromTos
				+ ", berthSide=" + berthSide + "]";
	}
}
