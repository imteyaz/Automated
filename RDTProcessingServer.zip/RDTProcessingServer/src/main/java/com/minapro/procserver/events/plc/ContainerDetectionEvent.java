package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ContainerDetectionEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6886259447423103109L;

    private String node;
    private String userId;
    private String spreaderId;

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSpreaderId() {
        return spreaderId;
    }

    public void setSpreaderId(String spreaderId) {
        this.spreaderId = spreaderId;
    }

    @Override
    public String toString() {
        return "ContainerDetectionEvent [node=" + node + ", userId=" + userId + ", spreaderId=" + spreaderId + "]";
    }

}
