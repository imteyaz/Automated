package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Container;

/**
 * ValueObject holding the container details related to Yard
 * 
 * @author Rosemary George
 *
 */
public class YardProfileContainer implements Serializable {
   

	private static final long serialVersionUID = 6390969748078395712L;

    private Container container;
    
    /**
     * Indicates the actual position of the container in yard as per the planning
     */
    private String yardPosition;

    /**
     * Indicates whether it is LOAD/DSCH/DLVR/RECV/YARD/SHFT operation.
     */
    private String moveType;
    
    /**
     * Indicates the actual position of the container in yard as per the
     * planning
     */
    private String oldPosition;
    
    private boolean is40FtCntrStkNo;
	
   	private String next40ftCntrStkNo;
    
    public String getOldPosition() {
		return oldPosition;
	}

	public void setOldPosition(String oldPosition) {
		this.oldPosition = oldPosition;
	}
    	
    public String getNext40ftCntrStkNo() {
		return this.next40ftCntrStkNo;
	}

	public void setNext40ftCntrStkNo(String next40ftCntrStkNo) {
		this.next40ftCntrStkNo = next40ftCntrStkNo;
	}

	public boolean getIs40FtCntrStkNo() {
		return this.is40FtCntrStkNo;
	}

	public void setIs40FtCntrStkNo(boolean is40FtCntrStkNo) {
		this.is40FtCntrStkNo = is40FtCntrStkNo;
	}

	public String getYardPosition() {
        return yardPosition;
    }

    public void setYardPosition(String yardPosition) {
        this.yardPosition = yardPosition;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }
    @Override
	public String toString() {
		return "YardProfileContainer [container=" + container
				+ ", yardPosition=" + yardPosition + ", moveType=" + moveType
				+ ", is40FtCntrStkNo=" + getIs40FtCntrStkNo()
				+ ", next40ftCntrStkNo=" + getNext40ftCntrStkNo() + ""
				+ ", Old Position ="+oldPosition +"]";
	}
   
}
