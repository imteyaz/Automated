package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ESB_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.BREAK_END_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.BREAK_START_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OPERATOR_AVAILABILITY_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OPERATOR_BREAK_REASONS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserDelay;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityResponseEvent;
import com.minapro.procserver.events.common.OperatorBreakReasonsEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for getting Operator Break reasons from cache and send those reasons to the current logged in
 * user. Handle operator availability and un availability events.
 * 
 * @author UMAMAHESH M
 *
 */
public class OperatorAvailabilityActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(OperatorAvailabilityActor.class);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);
    
    private static final String ITV_CARRYING_CNTR= "ITV is carrying container, break is not allowed.";
    
    /**
     * Handles Operator Availability Event Messages Like Operator Break Reasons And Available And UnAvailable Events
     */
    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass().getSimpleName())
                .append(ON_RECEIVE).toString());
        if (message instanceof OperatorBreakReasonsEvent) {
            sendBreakReasonsToDevice((OperatorBreakReasonsEvent) message);
        } else if (message instanceof OperatorAvailabilityEvent) {
            sendOperatorStatusToESB((OperatorAvailabilityEvent) message);
        } else if (message instanceof OperatorAvailabilityResponseEvent) {
            handleOperatorAvailabilityResponse((OperatorAvailabilityResponseEvent) message);
        } else {
            unhandled(message);
        }
    }

    /**
     * Method Is Responsible For Sending Operator Break Reasons To Communication Server
     * 
     * @param OperatorBreakReasonsEvent
     *            POJO with Break Reasons List
     */
    private void sendBreakReasonsToDevice(OperatorBreakReasonsEvent message) {
       
    	try {

    		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendBreakReasonsToDevice method")
    				.append(INPUT).append(message.toString()).toString());
    		
    		final String userId = message.getUserID();
    		final String terminalId = message.getTerminalID();
    		final String eventType = OPERATOR_BREAK_REASONS;
    		final String eventId = message.getEventID();

    		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
    		Set<DelayReasonCode> breakReasonsSet = RDTCacheManager.getInstance().getDelayReasonCodes(eventType);
    		String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
    		String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

    		// Get Break Reason Code,And Get Data From Cache,Sending Response To CommServer
    		StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID)
    				.append(valueSeperator).append(eventId);

    		String breakReasonsWithPipeSeperator = breakReasonsMessage(breakReasonsSet, operatorRole);

    		responseToDevice = responseToDevice.append(valueSeperator).append(breakReasonsWithPipeSeperator).append(valueSeperator);
    		
    		ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance().getAllocationDetails(userId);
            String rotationId = "";
            if (allocation != null) {
                rotationId = allocation.getRotationID();
            }
    		UserDelay delay = HibernateUtil.getOpenDelay(message.getEquipmentID(), rotationId);
    		if(delay != null){
    			logger.logMsg(LOG_LEVEL.INFO, userId, "Open delay Exists -" + delay);
    			responseToDevice.append(delay.getDealyCode());
    		}

    		responseToDevice.append(valueSeperator).append(userId).append(valueSeperator).append(terminalId);

    		logger.logMsg(LOG_LEVEL.INFO, userId,new StringBuffer(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
    				.append(responseToDevice.toString()).toString());

    		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
    				terminalId);
    	} catch (Exception e) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), e);
        }
    }

    /**
     * Method is responsible for preparing operatorBreakReasons. Iterating operatorBreakReasons set and adding reasons
     * to string with Row Separator |
     * 
     * @param breakReasonsSet
     * @return operatorBreakReasons prepared String
     */
    private String breakReasonsMessage(Set<DelayReasonCode> breakReasonsSet, OPERATOR role) {
        String breakReasonsWithPipeSeperator = "";
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" breakReasons construct message method")
                .append(INPUT).append(breakReasonsSet).toString());
        try {
            String pipeSeperator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
            for (DelayReasonCode reason : breakReasonsSet) {
            	if(role.toString().equalsIgnoreCase(reason.getSubType())){
            		breakReasonsWithPipeSeperator = breakReasonsWithPipeSeperator.concat(
                        reason.getDelaypk().getDelayReasonCodeID()).concat(ITEM_SEPERATOR).concat(reason.getDelayReasonDescription()).concat(pipeSeperator);
            	}
            }

            breakReasonsWithPipeSeperator = breakReasonsWithPipeSeperator.substring(0,
                    breakReasonsWithPipeSeperator.length() - 1);
            logger.logMsg(LOG_LEVEL.INFO, "", "breakReasons message is ".concat(breakReasonsWithPipeSeperator));

        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("breakReasonsMessage()").append(REASON)
                    .toString(), ex);
        }
        return breakReasonsWithPipeSeperator;
    }

    /**
     * Method is responsible for sending response to the Communication server with Operator availability status(true(t)
     * or false(f)), Response comes from ESR server.
     * 
     * @param OperatorAvailabilityResponseEvent
     *            is the response object from ESB server.
     */
    private void handleOperatorAvailabilityResponse(OperatorAvailabilityResponseEvent message) {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append("handleOperatorAvailabilityResponse()")
                .append(INPUT).append(message.toString()).toString());

        try {

            String userId = message.getUserID();
            
            RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
            
            if(message.isOperatorInitiated()){
	
	            String terminalID = message.getTerminalID();
	            String eventType = OPERATOR_AVAILABILITY_RESPONSE;
	            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
	            // get the message format
	            List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);
	            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
	            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
	
	            // build the response to the device
	            StringBuilder responseToDevice = new StringBuilder(RESP + valueSeperator + eventTypeID);
	            
	            String operatorAvailabilityStatus = "U".equalsIgnoreCase(message.getIsAvailable()) ? "F" : "T";
	       
	            message.setIsAvailable(operatorAvailabilityStatus);
	            
	            int noOfMsgFields = msgFields.size();
	            
	            EventUtil eventUtil = EventUtil.getInstance();
	           
	            for (int i = 1; i < noOfMsgFields; i++) {
	                // Setting Data to Response POJO using Reflection
	                responseToDevice = responseToDevice.append(valueSeperator);
	                eventUtil.getEventParameter(message, msgFields.get(i), responseToDevice);
	            }
	
	            if ("F".equalsIgnoreCase(message.getIsAvailable()) && (null == message.getErrorMsg() || message.getErrorMsg().isEmpty())) {
	               
	            	logger.logMsg(LOG_LEVEL.INFO, "", "Setting Operator Is Not Available(False) To Cache ");
	                rdtCacheMgr.setOperatorAvailability(userId, false);
	                HibernateUtil.updateUserBreakTime(RDTCacheManager.getInstance().getUserDetails(userId),BREAK_START_TIME);
	            }
	           
	            if ("T".equalsIgnoreCase(message.getIsAvailable()) && (null == message.getErrorMsg() || message.getErrorMsg().isEmpty())) {
	              
	            	logger.logMsg(LOG_LEVEL.INFO, "", "Setting Operator Is Available(True) To Cache ");
	                rdtCacheMgr.setOperatorAvailability(userId, true);
	                HibernateUtil.updateUserBreakTime(RDTCacheManager.getInstance().getUserDetails(userId), BREAK_END_TIME);
	            }
	            
	           CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole, terminalID);
           }else {
        	   logger.logMsg(LOG_LEVEL.INFO, userId, "Not initiated by operator. System initiated as part of Delay.");
           }
           
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" handleOperatorAvailabilityResponse()")
                    .append(REASON).toString(), ex);
        }

    }    

    public void sendOperatorStatusToESB(OperatorAvailabilityEvent operatorAvailability) {

        RDTCacheManager rdtCache = RDTCacheManager.getInstance();
        try{
	        String userId = operatorAvailability.getUserID();
	        User user = rdtCache.getUserDetails(userId);	
	        String terminalId  = operatorAvailability.getTerminalID();
	        String equipmentId = null;
	        
	        ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) rdtCache.getAllocationDetails(userId);
	        if (allocationEvent != null) {
	        	equipmentId= allocationEvent.getEquipmentID();
	            operatorAvailability.setRotationID(allocationEvent.getRotationID());
	            operatorAvailability.setLocation(allocationEvent.getLocation());
	            operatorAvailability.setEquipmentID(equipmentId);
	        } else {
	            logger.logMsg(LOG_LEVEL.INFO, userId, "ConfirmAllocationEvent Is Null Unable To "
	                    + "Set RotationId and Location to OperatorAvailability");
	        }
	        
	        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);	        
	        logger.logMsg(LOG_LEVEL.INFO,userId," Current Operator Role:"+operatorRole);
	        
	        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Operator marked available=" + operatorAvailability.getIsAvailable()
	        		+" opted delay= " + operatorAvailability.getUnavailableReason());
	        
	        boolean itvContainersCarryingStatus = rdtCache.getNumberOfCntrsOnITV(equipmentId)!=0 ? true : false;
	     /*   if(operatorRole.equals(OPERATOR.ITV) && itvContainersCarryingStatus){	        	
	            logger.logMsg(LOG_LEVEL.INFO, userId, ITV_CARRYING_CNTR);
	            
	            OperatorAvailabilityResponseEvent operatorAvailableResponse = new OperatorAvailabilityResponseEvent();
	            operatorAvailableResponse.setUserID(userId);
	            operatorAvailableResponse.setIsAvailable(operatorAvailability.getIsAvailable());
	            operatorAvailableResponse.setTerminalID(terminalId);
	            operatorAvailableResponse.setEventID(operatorAvailability.getEventID());
	            operatorAvailableResponse.setErrorMsg(ITV_CARRYING_CNTR);
	            operatorAvailableResponse.setEquipmentID(equipmentId);
	            operatorAvailableResponse.setOperatorInitiated(true);
	            handleOperatorAvailabilityResponse(operatorAvailableResponse);
	            return;
	        } 	*/        
	        
	        if("T".equalsIgnoreCase(operatorAvailability.getIsAvailable())){	        	
	        	operatorAvailability.setIsAvailable("A");
	        	closeDelayIfExists(operatorAvailability, allocationEvent, true);	    			
	        }else {
	        	operatorAvailability.setIsAvailable("U");
	        	
	        	if (operatorAvailability.isCreateDelay()) {
					logger.logMsg(LOG_LEVEL.DEBUG, operatorAvailability.getUserID(),
							"Raising Delay, operator opted for createDelay=" + operatorAvailability.isCreateDelay());
					closeDelayIfExists(operatorAvailability, allocationEvent, false);
					RDTPLCCacheManager.getInstance().addOpenDelayForEquipment(operatorAvailability.getEquipmentID());
					EventUtil.getInstance().createDelay(operatorAvailability, allocationEvent.getRotationID(), 
							operatorAvailability.getUnavailableReason(), operatorAvailability.getEquipmentID(), false);	
	        	}
	        }        
	       
	        operatorAvailability.setOperatorInitiated(true);
	        
	        if (user != null) {
	            operatorAvailability.setPassword(user.getPassword());
	            operatorAvailability.setUserName(user.getFirstName());
	        } else {
	            logger.logMsg(LOG_LEVEL.INFO, userId,
	                    "User Object Is Null Unable To Set Password/Name To Operator Availability Pojo");
	        }
	
	       
	        String[] vesselVoyage = JobListUtil.getVesselAndVoyageDetails(userId);
        	if(vesselVoyage != null){
        		operatorAvailability.setVessel(vesselVoyage[0]);
        		operatorAvailability.setVoyage(vesselVoyage[1]);
        	}
        	
        	operatorAvailability.setCallItv(false);
        	
	        logger.logMsg( LOG_LEVEL.INFO, userId,new StringBuilder(POST_DATA).append(ESB_QUEUE_MGR).append(FINAL_CREATED_MSG)
	                   .append(operatorAvailability.toString()).toString());
	
            ESBQueueManager.getInstance().postMessage(operatorAvailability, operatorRole, terminalId);
	
    	}catch(Exception ex){
        	logger.logException("Caught exception on sendOperatorStatusToESB-" , ex);
        }
    }
    
    /**
     * Checks whether any open delay exists with the same delay reason selected by the user for marking unavailable. 
     * In such case, closes the delay and inform ESB
     * 
     * @param event
     * @param allocationEvent
     * @param checkSameDelayCode
     */
    private void closeDelayIfExists(OperatorAvailabilityEvent event, ConfirmAllocationEvent allocationEvent, boolean checkSameDelayCode){
    	//if the same delay exists as open delay, close it.
    	String rotationId = "";
        if (allocationEvent != null) {
            rotationId = allocationEvent.getRotationID();
        }
    	UserDelay delay = HibernateUtil.getOpenDelay(event.getEquipmentID(), rotationId);
		if(delay != null){			
			boolean canClose = true;
			if(checkSameDelayCode){
				canClose =  delay.getDealyCode().equalsIgnoreCase(event.getUnavailableReason())? true:false;
			}
		
			if(canClose){
				logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "Open delay Exists .Closing it -" + delay);
				EventUtil.getInstance().closeDelay(delay, event.getUserID());
				RDTPLCCacheManager.getInstance().removeOpenDelayForEquipment(event.getEquipmentID());   
			}
		}else{
			logger.logMsg(LOG_LEVEL.DEBUG, event.getUserID(), "No open delay exists or the delay code doesn not match");
		}
    }
}
