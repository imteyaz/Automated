package com.minapro.procserver.events.common;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the refresh vessel request.
 * 
 * @author Rosemary George
 *
 */
public class RefreshVesselEvent extends Event {

    private static final long serialVersionUID = 303664809708194921L;

    /**
     * The rotation ID of the vessel which has berthed in the port
     */
    private String rotationID;

    /**
     * Vessel code of the berthed vessel
     */
    private String vesselCode;

    /**
     * Indicates the bayNo which needs refreshing
     */
    private String bayNo;

    /**
     * Indicates the type of refresh needed
     */
    private REFRESH_TYPE refreshType;

    /**
     * Indicates whether it is deck(D) or under deck(U)
     */
    private String deckIndicator;

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getBayNo() {
        return bayNo;
    }

    public void setBayNo(String bayNo) {
        this.bayNo = bayNo;
    }

    public REFRESH_TYPE getRefreshType() {
        return refreshType;
    }

    public void setRefreshType(REFRESH_TYPE refreshType) {
        this.refreshType = refreshType;
    }

    @Override
    public String toString() {
        return "RefreshVesselEvent [rotationID=" + rotationID + ", vesselCode=" + vesselCode + ", bayNo=" + bayNo
                + ", refreshType=" + refreshType + ", deckIndicator=" + deckIndicator + "]";
    }

    public String getDeckIndicator() {
        return deckIndicator;
    }

    public void setDeckIndicator(String deckIndicator) {
        this.deckIndicator = deckIndicator;
    }

    /**
     * Possible types for bay refresh
     */
    public static enum REFRESH_TYPE {
        DSCH, LOAD, ROB, ALL
    }
}
