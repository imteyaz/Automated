package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the Delay Recording event details
 * 
 * @author Venkataramana.ch
 *
 */

public class DelayRecordingEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8733747014649267666L;

    @Override
    public String toString() {
        return "DelayRecordingEvent [UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID() + ", TerminalID="
                + getTerminalID() + "]";
    }

}
