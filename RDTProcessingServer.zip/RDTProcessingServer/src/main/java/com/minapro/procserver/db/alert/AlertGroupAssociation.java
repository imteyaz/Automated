package com.minapro.procserver.db.alert;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.minapro.procserver.db.UserRole;

/**
 * ValueObject holding the Alert to User role mapping
 * 
 * @author Rosemary George
 */
@Entity
@Table(name = "MP_ALERT_ROLE_MAP")
public class AlertGroupAssociation implements Serializable {

	private static final long serialVersionUID = 5951167574415263466L;

	@Id
	@Column(name = "ALERT_ROLE_ID", nullable = false)
	private Integer alertRoleId;

	@Column(name = "ALERT_CODE", nullable = false)
	private String alertCode;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GROUP_ID", referencedColumnName = "INT_USER_GRP_ID")
	private UserRole userRole;

	@Column(name = "IS_ACTIVE", nullable = false)
	private String isActive;

	public Integer getAlertRoleId() {
		return alertRoleId;
	}

	public void setAlertRoleId(Integer alertRoleId) {
		this.alertRoleId = alertRoleId;
	}

	public String getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(String alertCode) {
		this.alertCode = alertCode;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
}
