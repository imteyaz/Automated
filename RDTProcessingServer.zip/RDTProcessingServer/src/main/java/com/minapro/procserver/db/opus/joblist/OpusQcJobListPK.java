package com.minapro.procserver.db.opus.joblist;

import java.io.Serializable;

import javax.persistence.Column;

public class OpusQcJobListPK implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name="MOVE_KIND")
	private String moveKind;

	@Column(name="CONTAINER_ID")
	private String containerId;

	@Column(name="ROTATION_ID")
	private String rotationId;

	@Column(name="EQUIPMENT_ID")
	private String equipmentId;
	
	public OpusQcJobListPK() {
    }
	
	public String getEquipmentId() {
		return this.equipmentId;
	}

	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}	
	
	public String getMoveKind() {
		return this.moveKind;
	}
	public void setMoveKind(String moveKind) {
		this.moveKind = moveKind;
	}
	public String getContainerId() {
		return this.containerId;
	}
	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}
	public String getRotationId() {
		return this.rotationId;
	}
	public void setRotationId(String rotationId) {
		this.rotationId = rotationId;
	}

	@Override
	public String toString() {
		return "OpusQcJobListPK [moveKind=" + moveKind + ", containerId="
				+ containerId + ", rotationId=" + rotationId + ", equipmentId="
				+ equipmentId + "]";
	}
}
