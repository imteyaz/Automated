package com.minapro.procserver.db;

import static com.minapro.procserver.util.RDTProcessingServerConstants.BREAK_END_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.BREAK_START_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CHE_PLC_READ_INTERVAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONFIG_DIRECTORY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.PLC_READ_INTERVAL;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.ParameterMode;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.procedure.ProcedureCall;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.alert.AlertConfiguration;
import com.minapro.procserver.db.bayprofile.TemplateHeader;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.db.damage.DamageRecording;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTQueryStatements;
import com.minapro.procserver.util.TroubleShootStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Utility class providing all database related operations
 * 
 * @author Rosemary George
 * 
 */
public class HibernateUtil {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(HibernateUtil.class);

	private static final SessionFactory SESSION_FACTORY = buildSessionFactory();

	private static final String EXCEPTION_IS = ". Exception is ";

	private HibernateUtil() {
	}

	private static SessionFactory buildSessionFactory() {
		try {
			logger.logMsg(LOG_LEVEL.INFO, "", "Building the session factory");

			Configuration configuration = new Configuration()
					.configure(new File(CONFIG_DIRECTORY + "hibernate.cfg.xml"));
			StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration
					.getProperties());

			return configuration.buildSessionFactory(builder.build());
		} catch (Exception ex) {
			logger.logMsg(LOG_LEVEL.FATAL, "", "Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	/**
	 * Gets the session factory
	 * 
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory() {
		return SESSION_FACTORY;
	}

	/**
	 * Retrieves the master data from the database for the specified Master table.
	 * 
	 * @param masterDataName
	 * @return List of data
	 */
	public static List<?> loadMasterData(Class<?> masterDataName, String orderByProperty, boolean isSoftDelete) {

		Session session = null;
		Transaction tx = null;
		List<?> masterDataList = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(masterDataName.getName());
			cr.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

			if (orderByProperty != null) {
				cr.addOrder(Order.asc(orderByProperty));
			}
			if (isSoftDelete) {
				cr.add(Restrictions.eqOrIsNull("isDeleted", "N"));
			}

			masterDataList = cr.list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Master data for " + masterDataName + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}

		return masterDataList;
	}

	/**
	 * Retrieves the number of logged in users who are logged in as the specified roleName.
	 * 
	 * @param roleName
	 *            - can be either QC or CHE
	 * @return either 0 or the number of logged in users
	 */
	@SuppressWarnings("unchecked")
	public static long loggedInUserSize(String roleName) {
		Session session = null;
		Transaction tx = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			List<Long> resultSet = session.createQuery(RDTQueryStatements.LOGGED_IN_USER_COUNT_QUERY)
					.setParameter("roleName", roleName).list();
			tx.commit();

			if (resultSet != null && !resultSet.isEmpty()) {
				return resultSet.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the logged in users size -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return 0;
	}

	/**
	 * Retrieves the number of logged in users who are not logged out
	 * 
	 * @param roleName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<UserActivityRecord> currenlyLoggedInUsers() {
		Session session = null;
		Transaction tx = null;
		List<UserActivityRecord> resultSet = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.LOGGED_IN_USERS_RECORD_QUERY).list();
			tx.commit();

		} catch (Exception ex) {
			logger.logException("Failed to get the logged in users records -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return resultSet;
	}

	/**
	 * Retrieves the PLC data from the database for the specified PLCData table.
	 * 
	 * @param
	 * @return List of PLCData
	 */

	@SuppressWarnings("unchecked")
	public static List<PLCData> loadPLCData() {
		Session session = null;
		Transaction tx = null;
		List<PLCData> plcDataList = null;
		int frequency = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(PLC_READ_INTERVAL));

		try {
			String cranes = RDTCacheManager.getInstance().getListOfCranesConfigured("NODE_CRANES");
			List<String> cranesList  = new ArrayList<String>(Arrays.asList(cranes.split(",")));
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			plcDataList = session.createQuery(RDTQueryStatements.QC_PLC_QUERY).setParameter("period", frequency)
					.setParameterList("cranes", cranesList).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the PLC data ".concat(EXCEPTION_IS), ex);
			session.getTransaction().rollback();
		}
		return plcDataList;
	}
	
	@SuppressWarnings("unchecked")
	public static List<List<String>> getWorkingEquipmentsFromDB(int frequency) {
		Session session = null;
		Transaction tx = null;
		List<List<String>> workingEquipments = new ArrayList<List<String>>();
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			workingEquipments.add(session.createQuery(RDTQueryStatements.GET_QC_WORKING_EQUIPMENTS).setParameter("period", frequency).list());
			workingEquipments.add(session.createQuery(RDTQueryStatements.GET_CHE_WORKING_EQUIPMENTS).setParameter("period", frequency).list());		
			
			logger.logMsg(LOG_LEVEL.INFO,""," Working PLC Equipments::"+workingEquipments);
			
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Working Equipments Data".concat(EXCEPTION_IS), ex);
			session.getTransaction().rollback();
		}
		return workingEquipments;
	}

	/**
	 * Saves the data to the database
	 * 
	 * @param data
	 *            - the data to be persisted
	 */
	public static void saveData(Object data) {
		Session session = null;
		Transaction tx = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			session.save(data);
			tx.commit();
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Saved successfully - " + data);
		} catch (Exception ex) {
			logger.logException("Failed to save the data  " + data + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Deletes the specified data from the database
	 * 
	 * @param data
	 *            - the data which needs to be deleted from the database
	 */
	public static void deleteData(Object data) {
		Session session = null;
		Transaction tx = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			session.delete(data);
			tx.commit();
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Deleted successfully - " + data);
		} catch (Exception ex) {
			logger.logException("Failed to delete the data  " + data + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Updates the specified data in the database
	 * 
	 * @param data
	 *            - the data which needs to be updated in the database
	 */
	public static void updateData(Object data) {
		Session session = null;
		Transaction tx = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			session.update(data);
			tx.commit();
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Updated successfully - " + data);
		} catch (Exception ex) {
			logger.logException("Failed to update the data  " + data + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * <p> Updates the latest user activity record for the mentioned user. </p>
	 * 
	 * <p> Retrieves the record which has the latest login time for the user and the logout time is not marked. And
	 * updates it with the parameters values if passed. </p>
	 * 
	 * @param user
	 * @param activity
	 * @param remarks
	 * @param logOutTime
	 */
	@SuppressWarnings("rawtypes")
	public static void updateUserActivity(User user, String activity, String remarks, Date logOutTime, int rotationId,
			double totalHoursWorked) {
		UserActivityRecord activityRecord = null;

		Session session = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			Transaction tx = session.beginTransaction();
			List resultSet = session.createQuery(RDTQueryStatements.CURRENT_USER_ACTIVITY_RECORD_QUERY)
					.setParameter("userName", user).list();
			tx.commit();

			if (!resultSet.isEmpty()) {
				activityRecord = (UserActivityRecord) resultSet.get(0);
				logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Retrieved the latest user activity record to update -"
						+ activityRecord);

				if (activity != null) {
					activityRecord.setActivity(activity);
				}

				if (remarks != null) {
					activityRecord.setRemarks(remarks);
				}

				if (logOutTime != null) {
					activityRecord.setLogoutDatetime(logOutTime);
				}

				if (rotationId != 0) {
					activityRecord.setRotationId(rotationId);
				}

				if (totalHoursWorked != 0) {
					activityRecord.setTotalHoursWorked(totalHoursWorked);
				}

				session = HibernateUtil.getSessionFactory().getCurrentSession();
				tx = session.beginTransaction();
				session.update(activityRecord);
				tx.commit();
			}
		} catch (Exception ex) {
			logger.logException("Failed to update the user activity record -", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Method is responsible for updating the user break end time and start time.
	 */
	@SuppressWarnings("unchecked")
	public static void updateUserBreakTime(User user, String breakTime) {

		Transaction transaction = null;

		try {
			if (null != user) {

				Session session = HibernateUtil.getSessionFactory().getCurrentSession();
				transaction = session.beginTransaction();

				if (null != session && null != transaction) {

					List<UserActivityRecord> listOfUserActivityRecords = session
							.createQuery(RDTQueryStatements.CURRENT_USER_ACTIVITY_RECORD_QUERY)
							.setParameter("userName", user).list();
					transaction.commit();

					if (null != listOfUserActivityRecords && !listOfUserActivityRecords.isEmpty()) {

						UserActivityRecord userActivityFirstRecord = listOfUserActivityRecords.get(0);
						logger.logMsg(LOG_LEVEL.INFO, user.getUserID(),
								"Retrieved the latest user activity record to update -" + userActivityFirstRecord);

						if (breakTime.equals(BREAK_START_TIME)) {
							userActivityFirstRecord.setBreakStartTime(new Date());
							userActivityFirstRecord.setBreakEndTIme(null);
						} else if (breakTime.equals(BREAK_END_TIME)) {
							double previousBreakDuration = userActivityFirstRecord.getTotalBreakDuration();

							double currentBreakDuration = EventUtil.getTimeDuration(RDTCacheManager.getInstance()
									.getOperatorBreakTimings(user.getUserID()));
							double overAllBreakDuration = previousBreakDuration + currentBreakDuration;

							logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Operator Previous Break Duration :::"
									+ previousBreakDuration);
							logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Operator Current Break Duration  :::"
									+ currentBreakDuration);
							logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Operator OverAll Break Duration  :::"
									+ overAllBreakDuration);
							userActivityFirstRecord.setBreakEndTIme(new Date());
							userActivityFirstRecord.setTotalBreakDuration(overAllBreakDuration);
						}

						session = HibernateUtil.getSessionFactory().getCurrentSession();
						transaction = session.beginTransaction();
						session.update(userActivityFirstRecord);
						transaction.commit();
					} else {
						logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), " No Records Found");
					}
				} else {
					logger.logMsg(LOG_LEVEL.ERROR, user.getUserID(), " Session/Transaction/User Is Null");
				}
			} else {
				logger.logMsg(LOG_LEVEL.INFO, " ", " User Object Is Null--Un able to update user break end time--");
			}
		} catch (Exception ex) {
			logger.logException(" Exception Occured While Updating The User Break Time ", ex);

		}

	}

	/**
	 * INSPECTION_CHECKLIST_MAPPING INSPECTION_RECORD CHECKLIST_MASTER Get UserId based on equipementId for QC Get
	 * InspectionId based on userId and Latest Timestamp of current date from INSPECTION_RECORD table Get STATUS,
	 * CHECKLIST_ID for INSPECTION_ID. Get all table details for CHECKLIST_ID from CHECKLIST_MASTER
	 * 
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static List<Object[]> getInspectionRecordByUserIdAndCurDate(String userID) {
		Session session = null;
		Transaction tx = null;
		List<Object[]> checkList = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			checkList = session.createQuery(RDTQueryStatements.VESSEL_FOREMAN_CHECKLIST_QUERY)
					.setParameter("userID", userID).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the CheckList for Vessel Foreman Exception is ", ex);
			tx.rollback();
		}

		return checkList;
	}

	/**
	 * 
	 * Used for Checking Access Privileges for View Plans based on Role.
	 * 
	 * @param groupName
	 * @param functionCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Object[]> getAccessPrivilegeByViewPlanAndRole(String groupName, String functionCode) {
		Session session = null;
		Transaction tx = null;
		List<Object[]> checkList = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			checkList = session.createSQLQuery(RDTQueryStatements.CHECK_PRIVILAGE_AND_ACCESS_QUERY)
					.setParameter("groupName", groupName).setParameter("functionCode", functionCode).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Access Privileges for View Plans of Vessel Foreman Exception is ",
					ex);
			tx.rollback();
		}

		return checkList;
	}

	@SuppressWarnings("unchecked")
	public static List<CompletedContainerMoves> getCompletedMoves(String rotationId) {
		Session session = null;
		Transaction tx = null;
		List<CompletedContainerMoves> completedMoves = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			completedMoves = session.createCriteria(CompletedContainerMoves.class).addOrder(Order.desc("moveId"))
					.add(Restrictions.eq("rotationId", rotationId))
					.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY).list();

			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to load the completed moves from database -", ex);
			tx.rollback();
		}

		return completedMoves;
	}

	/**
	 * Method to populate the LoggedinUserRoleCache<User,Role> from MP_USER_ACTIVITY Master table
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */

	@SuppressWarnings("unchecked")
	public static void populateUserActivityCache() {
		logger.logMsg(LOG_LEVEL.DEBUG, "", "=========Logged in Users from MP_USER_ACTIVITY Table===========");

		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Date time = new Date(new Date().getTime() - (1000 * 60 * 60 * 24));
			List<UserActivityRecord> list = session
					.createQuery(RDTQueryStatements.NO_LOGGED_OUT_USER_ACTIVITY_RECORD_QUERY)
					.setParameter("loginTime", time).list();
			tx.commit();

			if (!list.isEmpty()) {
				for (int i = 0; i < list.size(); i++) {
					UserActivityRecord user = list.get(i);

					logger.logMsg(LOG_LEVEL.DEBUG, "", "User ID  :" + user.getUser().getUserID() + "\t" + "ROLE : "
							+ user.getRole() + "\t" + "EQUIPMENT_ID :" + user.getEquipmentID());
					if (user.getRole() != null) {
						RDTCacheManager.getInstance().setUserLoggedInRole(user.getUser().getUserID(), user.getRole());
					}
				}
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the User activity Records. Exception is ", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Method is responsible for Updating the existed user entity with new Language.
	 * 
	 * @param langCode
	 *            newLanguageCode
	 * @param Id
	 *            userId
	 */
	public static void updateUserLangCode(String langCode, Integer id) {

		logger.logMsg(LOG_LEVEL.INFO, "", " started updateUserLangCode() with lang code is-->" + langCode
				+ " user id is " + id);

		Session session = null;
		Transaction tx = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			User user = (User) session.get(User.class, id);
			user.setDeafultLanguage(langCode);
			session.update(user);
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to update the user language code In Database-", ex);
			tx.rollback();
		}
	}

	/**
	 * Retrieves the vessel object from database for the specified vesselCode
	 * 
	 * @param vesselCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Vessel getVessel(String vesselCode) {
		Vessel vessel = null;
		Session session = null;
		Transaction tx = null;
		List<Vessel> vesselList = null;
		try {
			int vesselNo = Integer.parseInt(vesselCode);
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			Criteria cr = session.createCriteria(Vessel.class);
			cr.add(Restrictions.eqOrIsNull("vesselNo", vesselNo));
			vesselList = cr.list();
			tx.commit();

			if (vesselList != null) {
				logger.logMsg(LOG_LEVEL.INFO, vesselCode, "Retrieved vessel data - " + vesselList.size());
				vessel = vesselList.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the Vessel for " + vesselCode, ex);
			tx.rollback();
		}

		return vessel;
	}

	/**
	 * Retrieves the QC mappings available for the specified rotation
	 * 
	 * @param rotationId
	 * @return null if no mappings are found
	 */
	@SuppressWarnings("unchecked")
	public static Collection<Equipment> getRotationToQCMappingForVessel(String rotationId) {
		Session session = null;
		Transaction tx = null;
		List<RotationControl> rotationList = null;
		RotationControl rotationMapping;
		try {
			int rotation = Integer.parseInt(rotationId);
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Criteria cr = session.createCriteria(RotationControl.class);
			cr.add(Restrictions.eqOrIsNull("rotationNumber", rotation));
			rotationList = cr.list();
			tx.commit();

			if (rotationList != null && !rotationList.isEmpty()) {
				rotationMapping = rotationList.get(0);
				return rotationMapping.getActualEquipments();
			}

		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the QC rotation mapping for " + rotationId, ex);
			tx.rollback();
		}
		return new ArrayList<Equipment>();
	}

	/**
	 * Retrieves the sum of total hours worked by the specified operator on the equipment and rotation combination. If
	 * no records are present, returns 0
	 * 
	 * @param user
	 * @param rotationID
	 * @param equipmentID
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Double getPrviousHoursWorkedByUser(User user, String rotationID, String equipmentID) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Integer rotation = null;
			if (rotationID != null && !rotationID.isEmpty()) {
				rotation = Integer.parseInt(rotationID);
			}

			List<Double> list = session.createQuery(RDTQueryStatements.TOTAL_HOURS_USER_WORKED_QUERY)
					.setParameter("rotationNo", rotation).setParameter("userId", user)
					.setParameter("equipmentId", equipmentID).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0.0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException(
					"Caught exception while retrieving the total hours worked for user " + user.getUserID(), ex);
			tx.rollback();
		}

		return 0.0;
	}

	/**
	 * Retrieves the sum of total hours worked by the specified equipment for the rotation. If no records are present,
	 * returns 0
	 * 
	 * @param rotationID
	 * @param equipmentID
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Double getPrviousHoursWorkedByEquipment(String rotationID, String equipmentID) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Integer rotation = null;
			if (rotationID != null && !rotationID.isEmpty()) {
				rotation = Integer.parseInt(rotationID);
			}
			List<Double> list = session.createQuery(RDTQueryStatements.TOTAL_HOURS_EQUIPMENT_WORKED_QUERY)
					.setParameter("rotationNo", rotation).setParameter("equipmentId", equipmentID).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0.0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException(
					"Caught exception while retrieving the total hours worked for equipment " + equipmentID, ex);
			tx.rollback();
		}

		return 0.0;
	}

	/**
	 * Retrieves the maximum number of rows present in the vessel. This doesn't mean the total number of rows, but the
	 * largest row number present on the vessel.
	 * 
	 * @param vesselNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Integer getMaxRowsForVessel(String vesselNo) {
		Session session = null;
		Transaction tx = null;

		int maxRows = 21;
		List<Vessel> maxRowList = null;
		try {
			int vesselId = Integer.parseInt(vesselNo);
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Criteria cr = session.createCriteria(Vessel.class);
			cr.add(Restrictions.eq("vesselNo", vesselId));
			maxRowList = cr.list();
			tx.commit();

			if (maxRowList != null && !maxRowList.isEmpty()) {
				maxRows = maxRowList.get(0).getMaxNoOfRows();
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the max rows for the vessel " + vesselNo, ex);
			tx.rollback();
		}

		return maxRows;
	}

	/**
	 * Retrieves the Template header details from database for the specified header id
	 * 
	 * @param tierHeader
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static TemplateHeader getTemplate(String headerId) {
		Session session = null;
		Transaction tx = null;

		TemplateHeader header = null;

		List<TemplateHeader> headerList = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			Criteria cr = session.createCriteria(TemplateHeader.class);
			cr.add(Restrictions.eq("headerId", headerId.trim()));
			cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			headerList = cr.list();
			tx.commit();

			if (headerList != null && !headerList.isEmpty()) {
				return headerList.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the details of template header " + headerId, ex);
			tx.rollback();
		}

		return header;
	}

	/**
	 * Retrieves whether the bayNo and TierNo combination belongs to deck or under deck for the specified vessel
	 * 
	 * @param vesselNo
	 * @param bayNo
	 * @param tierNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getDeckValueForBayTier(String vesselNo, String bayNo, String tierNo) {
		Session session = null;
		Transaction tx = null;
		List<Object> deckDetails = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			deckDetails = session.createQuery(RDTQueryStatements.VESSEL_PROFILE_DECK_DETAILS_QUERY)
					.setParameter("vesselNo", Integer.parseInt(vesselNo)).setParameter("bayNo", bayNo)
					.setParameter("tierNo", tierNo).list();
			tx.commit();

			if (!deckDetails.isEmpty()) {
				return deckDetails.get(0).toString();
			}

		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the details of deck/underdeck for  " + bayNo, ex);
			tx.rollback();
		}

		return "";
	}

	/**
	 * Retrieves the RMG PLC data from the database for the specified PLCData table.
	 * 
	 * @param
	 * @return List of RMGPLCData
	 */

	@SuppressWarnings("unchecked")
	public static List<CHEPLCData> loadRMGPLCData() {
		Session session = null;
		Transaction tx = null;
		List<CHEPLCData> rmgPlcDataList = null;
		int frequency = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(CHE_PLC_READ_INTERVAL));

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			rmgPlcDataList = session.createQuery(RDTQueryStatements.CHE_PLC_QUERY).setParameter("period", frequency)
					.list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the RMG PLC data. Exception is ", ex);
			session.getTransaction().rollback();
		}

		return rmgPlcDataList;
	}

	/**
	 * Following Method is used to get the ExceptionCodeMaster record for exception code.
	 */
	public static ExceptionCodeMaster getExceptionCodeById(String exceptionCode) {
		logger.logMsg(LOG_LEVEL.INFO, "", " Started getExceptionCodeById() Input value is " + exceptionCode);
		ExceptionCodeMaster data = null;

		Session session = null;
		Transaction tx = null;
		try {

			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			data = (ExceptionCodeMaster) session.get(ExceptionCodeMaster.class, exceptionCode);
			if (null != tx) {
				tx.commit();
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the Exception for Exception code. Exception is ", ex);
			if (null != tx) {
				tx.rollback();
			}
		}
		logger.logMsg(LOG_LEVEL.INFO, "", " Returning Value From getExceptionCodeById() Is " + data);
		return data;
	}

	/**
	 * Retrieves the current troubleshoot jobs along with the completed jobs for today
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<TroubleShootRecord> retrieveTroubleShootRecords() {
		List<TroubleShootRecord> tsRecords = null;

		Session session = null;
		Transaction tx = null;
		try {

			Calendar c = new GregorianCalendar();
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			Date date = c.getTime();

			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			tsRecords = session.createQuery(RDTQueryStatements.GET_TROUBLESHOOT_RECORDS_QUERY)
					.setParameter("status1", TroubleShootStatus.PENDING.toString())
					.setParameter("status2", TroubleShootStatus.IN_PROGRESS.toString()).setParameter("today", date)
					.list();
			tx.commit();
			return tsRecords;
		} catch (Exception ex) {
			logger.logException("Failed to get the ExceptionDescription for Exception code. Exception is ", ex);
			if (null != tx) {
				tx.rollback();
			}
		}

		return tsRecords;
	}

	/**
	 * Retrieves the sum of total completed jobs of the specified CHE equipment per one shift. If no records are
	 * present, returns 0
	 * 
	 * @param equipmentID
	 * @param shift_start_time
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static long getCompletedJobsByCHEforThisShift(String equipmentID, String shiftStartTime, String shiftEndTime) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Long> list = session.createQuery(RDTQueryStatements.TOTAL_COMPLETED_JOBS_CHE_EQUIPMENT_PER_SHIFT)
					.setParameter("shiftStartTime", shiftStartTime).setParameter("shiftEndTime", shiftEndTime)
					.setParameter("equipmentId", equipmentID).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the total completedjobs for cheEquipment "
					+ equipmentID, ex);
			tx.rollback();
		}

		return 0;
	}

	/**
	 * Retrieves the sum of total completed jobs of the specified CHE user per one shift. If no records are present,
	 * returns 0
	 * 
	 * @param userId
	 * @param shift_start_time
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<CompletedContainerMoves> getCompletedJobsByUserforThisShift(User userObj, String equipmentID, String shiftStartTime,
			String shiftEndTime) {
		Session session = null;
		Transaction tx = null;
		List<CompletedContainerMoves> list = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			list  = session.createQuery(RDTQueryStatements.TOTAL_COMPLETED_JOBS_CHE_USER_PER_SHIFT)
					.setParameter("shiftStartTime", shiftStartTime).setParameter("shiftEndTime", shiftEndTime)
					.setParameter("equipmentId", equipmentID).setParameter("userObj", userObj).list();
			tx.commit();

		} catch (Exception ex) {
			logger.logException(
					"Caught exception while retrieving the total completedjobs for che User " + userObj.getUserID(), ex);
			tx.rollback();
		}

		return list;
	}

	/**
	 * Retrieves the sum of total hours worked by the specified operator on the equipment per shift. If no records are
	 * present, returns 0
	 * 
	 * @param user
	 * @param shift_start_time
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Double getTotalHoursWorkedByCHEUser(User userObj, String shiftStartTime, String shiftEndTime) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Double> list = session.createQuery(RDTQueryStatements.TOTAL_HOURS_CHE_USER_WORKED_QUERY)
					.setParameter("shiftStartTime", shiftStartTime).setParameter("shiftEndTime", shiftEndTime)
					.setParameter("userObj", userObj).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0.0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException(
					"Caught exception while retrieving the total hours worked for user " + userObj.getUserID(), ex);
			tx.rollback();
		}

		return 0.0;
	}

	/**
	 * Retrieves the current max index for the backreach job specified for the rotation,moveType.
	 * 
	 * @param rotationId
	 * @param backReachType
	 * @param moveType
	 * @return the max index for the back reach job
	 */
	@SuppressWarnings("unchecked")
	public static int getBackReachUniqueIndex(String rotationId, String backReachType, String moveType) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Integer> curIndex = session.createQuery(RDTQueryStatements.BACKREACH_MAX_INDEX_BY_ROTATION)
					.setParameter("rotationId", rotationId).setParameter("jobType", backReachType)
					.setParameter("moveType", moveType).list();
			tx.commit();

			int index = 0;
			if (curIndex != null && !curIndex.isEmpty()) {
				logger.logMsg(LOG_LEVEL.DEBUG, rotationId + backReachType + moveType, "Max index is " + curIndex.get(0));
				if (curIndex.get(0) != null) {
					index = curIndex.get(0);
				}
				return index;
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while retrieving the Next Unique Index for the back reach Job "
					+ rotationId, ex);
			tx.rollback();
		}

		return 0;
	}

	/**
	 * Retrieves the open delay for the specified rotation and equipment
	 * 
	 * 
	 * @param user
	 * @param equipmentID
	 * @param rotationId
	 * @return UserDelay 
	 */
	@SuppressWarnings("unchecked")
	public static UserDelay getOpenDelay(String equipmentID, String rotationId) {

		Session session = null;
		Transaction tx = null;
		List<UserDelay> resultSet = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			if(rotationId == null || rotationId.isEmpty()){
				resultSet = session.createQuery(RDTQueryStatements.GET_OPEN_DELAY_FOR_CHE)
						.setParameter("equipmentId", equipmentID).list();
			}else {
				resultSet = session.createQuery(RDTQueryStatements.GET_OPEN_DELAY_FOR_QC)
					.setParameter("equipmentId", equipmentID).setParameter("rotationId", rotationId)
					.list();
			}

			tx.commit();
			
			if(resultSet != null && !resultSet.isEmpty()){
				return resultSet.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the open Dealy users records -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return null;
	}

	/**
	 * Getting the delay reason codes from DB assigned to the specified role
	 * 
	 * @param roleId
	 * @author kalyani
	 */
	@SuppressWarnings("unchecked")
	public static List<DelayReasonCode> getReasonCodes() {

		Session session = null;
		Transaction tx = null;
		List<DelayReasonCode> resultSet = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.GET_DELAY_CODE).list();
			tx.commit();

		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy reason codes -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return resultSet;
	}

	/**
	 * Retrieves the open delay from DB
	 * 
	 * @param equipmentID
	 * @param rotationId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<UserDelay> checkforOpenDelays(String equipmentID, String rotationId) {
		Session session = null;
		Transaction tx = null;
		List<UserDelay> resultSet = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.CHECK_OPEN_DELAY_RECORD_QUERY)
					.setParameter("equipmentId", equipmentID).setParameter("rotationId", rotationId)
					.list();

			tx.commit();

		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy users records -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return resultSet;

	}

	/**
	 * Getting any overlapping delay from DB assigned to the specified role
	 * 
	 * @param equipmentID
	 * @param rotationId
	 * @param delayCode
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static long checkforOverlapDelays(String equipmentID, String rotationId, String delayCode,
			Date delayStartTime, Date delayEndTime) {

		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			List<Long> resultSet = session.createQuery(RDTQueryStatements.CHECK_OVERLAP_DELAY_RECORD_QUERY)
					.setParameter("equipmentID", equipmentID).setParameter("rotationId", rotationId)
					.setParameter("delayCode", delayCode).setParameter("delayStartTime", delayStartTime)
					.setParameter("delayEndTime", delayEndTime).list();

			tx.commit();

			if (resultSet != null && !resultSet.isEmpty()) {
				return resultSet.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy users records -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return 0;

	}

	/**
	 * Getting the damage location codes from DB assigned to the specified damage
	 * 
	 * @param damageCode
	 * @author kalyani
	 */

	@SuppressWarnings("unchecked")
	public static List<String> getDamageLocationCodes(String damageCode) {
		List<String> data = null;

		Session session = null;
		Transaction tx = null;
		try {

			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			data = session.createQuery(RDTQueryStatements.GET_DAMAGE_LOCATION_CODE_BY_DAMAGECODE)
					.setParameter("damageCode", damageCode).list();
			if (null != tx) {
				tx.commit();
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the DamageLocation code for the Damage code. Exception is ", ex);
			if (null != tx) {
				tx.rollback();
			}
		}
		return data;
	}

	/**
	 * Retrieves the open delay by the specified Id
	 * 
	 * @param delayId
	 * @return
	 */
	public static UserDelay getManualDelayById(Integer delayId) {
		Transaction tx = null;
		UserDelay delay = null;
		try {
			Session session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			delay = (UserDelay) session.get(UserDelay.class, delayId);
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the getManualDelayById. Exception is ", ex);
			if (tx != null) {
				tx.rollback();
			}
		}
		return delay;
	}

	/**
	 * Retrieves the list of open damage records for the specified container
	 * 
	 * @param containerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Object[]> getOpenDamagesForContainer(String containerId) {
		Transaction tx = null;
		List<Object[]> openDamages = null;
		try {
			Session session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			openDamages = session.createQuery(RDTQueryStatements.GET_OPEN_DAMAGE_FOR_CONTAINER)
					.setParameter("containerId", containerId).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Open Damages For Container. Exception is ", ex);
			if (tx != null) {
				tx.rollback();
			}
		}
		return openDamages;
	}

	/**
	 * Retrieves the list of damage codes with type and locations
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Object[]> getDamageCodesWithTypeAndLocation() {
		Transaction tx = null;
		List<Object[]> damageCodes = null;
		try {
			Session session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			damageCodes = session.createSQLQuery(RDTQueryStatements.GET_DAMAGE_TYPES_WITH_CODES_LOCATION).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Damage Codes With Type And Location. Exception is ", ex);
			if (tx != null) {
				tx.rollback();
			}
		}
		return damageCodes;
	}

	/**
	 * Retrieves the list of open damage records for the specified container
	 * 
	 * @param containerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, DamageRecording> getDamagesForContainer(String containerId) {
		Transaction tx = null;
		Map<String, DamageRecording> openDamages = new HashMap<String, DamageRecording>();
		try {
			Session session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			List<DamageRecording> openRecords = session.createQuery(RDTQueryStatements.GET_DAMAGE_FOR_CONTAINER)
					.setParameter("containerId", containerId).list();
			tx.commit();

			if (openRecords != null && !openRecords.isEmpty()) {
				for (DamageRecording record : openRecords) {
					openDamages.put(record.getDamageId().toString(), record);
				}
			}
		} catch (Exception ex) {
			logger.logException("Failed to get the DamagesForContainer. Exception is ", ex);
			if (tx != null) {
				tx.rollback();
			}
		}
		return openDamages;
	}

	/**
	 * Retrieves the shift data for the ITV logged in User
	 * 
	 * @param equipmentID
	 * @param shiftStartTime
	 * @param sysDateTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static long getCompletedJobsByITVforThisShift(User user, String equipmentID, String shiftStartTime,
			String sysDateTime) {
		Session session = null;

		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Long> list = session.createQuery(RDTQueryStatements.TOTAL_COMPLETED_JOBS_ITV_EQUIPMENT_PER_SHIFT)
					.setParameter("user", user).setParameter("equipmentID", equipmentID)
					.setParameter("shiftStartTime", shiftStartTime).setParameter("sysDateTime", sysDateTime).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the ITV completed jobs -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return 0;

	}

	/**
	 * Retrieves the shift data for the ITV logged in User
	 * 
	 * @param shiftLoginTime
	 * @param sysDateTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static ShiftDetails getShiftDataforLoggedInuser(Date shiftLoginTime, Date sysDateTime, String userId) {
		Session session = null;
		Transaction tx = null;
		ShiftDetails details = null;
		List<ShiftDetails> shiftDetails = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			shiftDetails = session.createQuery(RDTQueryStatements.SHIFTDATA_FORITV_LOGGEDINUSERS)
					.setParameter("loginTime", shiftLoginTime).setParameter("systemTime", sysDateTime)
					.setParameter("userId", userId).list();
			tx.commit();
			if (shiftDetails != null && !shiftDetails.isEmpty()) {
				details = shiftDetails.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Failed to get the ShiftDetails. Exception is ", ex);
			if (tx != null) {
				tx.rollback();
			}
		}
		return details;

	}

	/* *//**
	 * Retrieves the sum of total hours worked by the specified operator on the equipment and rotation combination.
	 * If no records are present, returns 0
	 * 
	 * @param user
	 * @param rotationID
	 * @param equipmentID
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Double getPreviousHoursWorkedByITVUser(User userId, String equipmentId, String shiftStartTime,
			String sysDateTime) {
		Session session = null;
		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Double> list = session.createQuery(RDTQueryStatements.TOTAL_HOURS_ITV_USER_WORKED_QUERY)
					.setParameter("userId", userId).setParameter("equipmentId", equipmentId)
					.setParameter("shiftStartTime", shiftStartTime).setParameter("sysDateTime", sysDateTime).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0.0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException(
					"Caught exception while retrieving the total hours worked for ITV user " + userId.getUserID(), ex);
			tx.rollback();
		}

		return 0.0;
	}

	/**
	 * Retrieves the list of ITV trailerID's
	 * 
	 * @return resultList
	 */

	@SuppressWarnings("unchecked")
	public static List<String> itvTrailerIDsList() {
		Session session = null;
		Transaction tx = null;
		List<String> resultList = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultList = session.createQuery(RDTQueryStatements.GET_TRAILER_ID).list();
			tx.commit();
		} catch (Exception ex) {
            logger.logException("Failed to get the List of ITV trailer IDs -" + EXCEPTION_IS, ex);
            session.getTransaction().rollback();
        }
        return resultList;
    }   
    
    public static void executeJobListProcedure(String terminalId,String rotation,String equipmentId){
        logger.logMsg(LOG_LEVEL.INFO, " ", new StringBuilder(" Started executeJobListProcedure() Parameters::").append("Terminal::" + terminalId)
                        .append(" Rotation::" + rotation).append(" Equipment Id::" + equipmentId).toString());

        Session session = null;
        Transaction transaction = null;
        try {
            session = SESSION_FACTORY.getCurrentSession();
            transaction = session.beginTransaction();

            ProcedureCall procedureCall = session.createStoredProcedureCall("PROCESS_SPARC_JOB_LIST");

            procedureCall.registerParameter("PTERMINAL_ID", String.class, ParameterMode.IN).bindValue(terminalId);
            procedureCall.registerParameter("PROTATION_ID", String.class, ParameterMode.IN).bindValue(rotation);
            procedureCall.registerParameter("PEQUIPMENT_ID", String.class, ParameterMode.IN).bindValue(equipmentId);
            procedureCall.getOutputs();

            transaction.commit();

        } catch (Exception ex) {
            if (null != session && session.isConnected()) {
                session.getTransaction().rollback();
            }
            logger.logException("Exception Occured In executeJobListProcedure() Reason::", ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    public static List<Object[]> getJobListFromDatabase(String terminalId,String rotationID,String equipmentId){
        logger.logMsg(LOG_LEVEL.INFO, " ",
                new StringBuilder(" Started getJobListDataFromDatabase() Parameters::")
                        .append("Terminal::" + terminalId).append(" Rotation::" + rotationID)
                        .append(" Equipment Id::" + equipmentId).toString());

        Session session = null;
        Transaction transaction = null;

        List<Object[]> jobListObjectArrayList = null;
        try {

            session = SESSION_FACTORY.getCurrentSession();
            transaction = session.beginTransaction();
            SQLQuery sqlQuery = session.createSQLQuery(RDTQueryStatements.RETRIEVE_JOB_LIST_QUERY);

            sqlQuery.setParameter("equipmentID", equipmentId).setParameter("rotationID", rotationID)
                    .setParameter("terminalID", terminalId).setParameter("twinSplit", "N");

            jobListObjectArrayList = sqlQuery.list();
            transaction.commit();

            int noOfJobListRecords = jobListObjectArrayList != null && !jobListObjectArrayList.isEmpty() ? jobListObjectArrayList
                    .size() : 0;
            logger.logMsg(LOG_LEVEL.INFO, rotationID+":"+equipmentId, "No Of Jobs Received From Database For JobList::" + noOfJobListRecords);

        } catch (Exception ex) {
            logger.logException("Exception Occured In getJobListDataFromDatabase() Reason::", ex);
            session.getTransaction().rollback();
        }

        return jobListObjectArrayList;
    }

    /**
     * Retrieves the twin tandem recorded for the specified rotation, equipment and container
     * 
     * @param containerId
     * @param rotationID
     * @param equipmentID
     * @return
     */
    @SuppressWarnings("unchecked")
    public static TwinTandemJobs getTwinTandemJob(String containerId, String rotationID, 
    		String equipmentID, String jobType) {
        Session session = null;
        Transaction transaction = null;
        
        List<TwinTandemJobs> jobs = null;
        TwinTandemJobs twinTandemJob = null;
        try {
            session = SESSION_FACTORY.getCurrentSession();
            transaction = session.beginTransaction();
            
            jobs = session.createQuery(RDTQueryStatements.GET_TWIN_TANDEM_RECORD)
                    .setParameter("rotationId", rotationID)
                    .setParameter("equipmentId", equipmentID)
                    .setParameter("containerId", containerId)
                    .setParameter("jobType", jobType).list();
           
            
            logger.logMsg(LOG_LEVEL.INFO, equipmentID, "Trying to get the TWIN Tandem Jobs with "
                    + " rotationId="+rotationID + ",equipmentId=" + equipmentID + 
                    ", containerId=" +containerId + ",jobType=" + jobType);
            
            if(jobs != null && !jobs.isEmpty()){
                logger.logMsg(LOG_LEVEL.DEBUG, equipmentID, "Retrieved jobs=" + jobs.size());
                twinTandemJob = jobs.get(0);
            }
            
            transaction.commit();
            
        } catch (Exception ex) {
            logger.logException("Exception Occured In getTwinTandemJob() Reason::", ex);
            session.getTransaction().rollback();
        }
        return twinTandemJob;
    }
    
    /**
     * Retrieves the twin tandem recorded for the specified containerId
     * @param containerId
     * @return null if no records found
     */
    @SuppressWarnings("unchecked")
    public static TwinTandemJobs getTwinTandemJobByContainerId(String containerId) {
        Session session = null;
        Transaction transaction = null;
        
        List<TwinTandemJobs> jobs = null;
        TwinTandemJobs twinTandemJob = null;
        try {
            session = SESSION_FACTORY.getCurrentSession();
            transaction = session.beginTransaction();
            
            jobs = session.createQuery(RDTQueryStatements.GET_TWIN_TANDEM_RECORD_BY_CONTAINER)
                    .setParameter("containerId", containerId).list();
           
            
            logger.logMsg(LOG_LEVEL.INFO, containerId, "Trying to get the TWIN Tandem Jobs for "
                    + " containerId=" +containerId);
            
            if(jobs != null && !jobs.isEmpty()){
                logger.logMsg(LOG_LEVEL.DEBUG, containerId, "Retrieved jobs=" + jobs.size());
                twinTandemJob = jobs.get(0);
            }
            
            transaction.commit();
            
        } catch (Exception ex) {
            logger.logException("Exception Occured In getTwinTandemJobByContainerId() Reason::", ex);
            session.getTransaction().rollback();
        }
        return twinTandemJob;
    }

    /**
     * Retrieves the specified alert configuration by alertCode
     * 
     * @param alertCode
     * @return null if no record found for the specified alert code
     */
	public static AlertConfiguration getAlertConfiguration(String alertCode) {
		Session session = null;
		Transaction tx = null;
		AlertConfiguration alertConfig = null;
		
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			alertConfig = (AlertConfiguration) session.get(AlertConfiguration.class, alertCode);
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to getAlertConfiguration- alertCode=" + alertCode, ex);
			tx.rollback();
		}
		
		return alertConfig;
	}

	/**
	 * Retrieves the DelayReasonCode by the specified reasonCode
	 * @param reasonCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static DelayReasonCode getDelayReasonByCode(String reasonCode) {
		Session session = null;
		Transaction tx = null;
		List<DelayReasonCode> resultSet = null;
		DelayReasonCode delayCode = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.GET_DELAY_BY_CODE).setParameter("reasonCode", reasonCode)
					.list();
			tx.commit();

			if(resultSet != null && !resultSet.isEmpty()){
				delayCode = resultSet.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy reason codes -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
				
		return delayCode;
	}
	
	/**
	 * Retrieves the DelayReasonCode by the specified reasonCode
	 * @param reasonCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static DelayReasonCode getDelayReasonByAlertCode(String alertCode) {
		Session session = null;
		Transaction tx = null;
		List<DelayReasonCode> resultSet = null;
		DelayReasonCode delayCode = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.GET_DELAY_BY_ALERT_CODE).setParameter("alertCode", alertCode)
					.list();
			tx.commit();

			if(resultSet != null && !resultSet.isEmpty()){
				delayCode = resultSet.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy reason codes -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
				
		return delayCode;
	}

	/**
	 * Retrieves the list of equipments which is assigned to work for the specified containerId
	 * @param containerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<String> getEquipmentsWorkingOnContainer(String containerId) {		
		Session session = null;
		Transaction tx = null;
		List<String> resultSet = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createSQLQuery(RDTQueryStatements.GET_EQUIPMENTS_WORKING_ON_CONTAINER)
					.setParameter("containerId", containerId).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the Dealy reason codes -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		
		return resultSet;
	}
	
	/**
	 * Retrieves the completed move record for the specified container where the equipment is not the specified itv Id
	 * @param containerId
	 * @param itvId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<CompletedContainerMoves> getCompletedMoves(String containerId, String itvId) {
		Session session = null;
		Transaction tx = null;
		List<CompletedContainerMoves> completedMoves = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			completedMoves = session.createCriteria(CompletedContainerMoves.class)
					.add(Restrictions.eq("containerId", containerId))
					.add(Restrictions.neOrIsNotNull("equipment", itvId))
					.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY).list();

			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to load the completed moves from database -", ex);
			tx.rollback();
		}

		return completedMoves;
	}
	
	/**
	 * Retrieves the check lists associated with the specified header sorted in order of category and checklist name 
	 * 
	 * @param user
	 * @param equipmentID
	 * @param rotationId
	 * @return UserDelay 
	 */
	@SuppressWarnings("unchecked")
	public static List<CheckList> getCheckListForHeader(CheckListHeader header) {

		Session session = null;
		Transaction tx = null;
		List<CheckList> resultSet = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			
			Criteria cr = session.createCriteria(CheckList.class);
			cr.add(Restrictions.eq("checkListHeader", header));
			cr.addOrder(Order.asc("category"));
			cr.addOrder(Order.asc("checklistName"));
			
			resultSet = cr.list();
			tx.commit();

		} catch (Exception ex) {
			logger.logException("Failed to get the check list for the header -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		
		return resultSet;
	}
	
	/**
	 * Retrieves the open delays available in the system
	 * @param containerId
	 * @param itvId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, UserDelay> getOpenDelayForAllQCs() {
		Session session = null;
		Transaction tx = null;
		List<UserDelay> resultSet = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.GET_OPEN_DELAY_FOR_EQPMNTS).list();
			tx.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get the open Dealy users records -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		
		logger.logMsg(LOG_LEVEL.DEBUG, "getOpenDelayForAllQCs", "Open delays = " + resultSet);
		Map<String, UserDelay> openDelays = new HashMap<String, UserDelay>();
		if(resultSet != null){
			for(UserDelay delay: resultSet){
				openDelays.put(delay.getEquipmentID(), delay);
			}
		}
		return openDelays;
	}
	
	/**
	 * Retrieves completed jobs by QC equipment for the specified time - This includes the jobs confirmed by 
	 * QC operator and HC operator
	 * 
	 * @param equipmentID
	 * @param loginTime
	 * @param sysDateTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Long getCompletedJobsByQC(String equipmentID, String loginTime, String rotationId) {
		Session session = null;

		Transaction tx = null;

		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();

			List<Long> list = session.createQuery(RDTQueryStatements.TOTAL_COMPLETED_JOBS_QC_EQUIPMENT)
					.setParameter("equipmentID", equipmentID)
					.setParameter("loginTime", loginTime).setParameter("rotationId", rotationId).list();
			tx.commit();

			if (list != null && !list.isEmpty()) {
				return list.get(0) == null ? 0 : list.get(0);
			}

		} catch (Exception ex) {
			logger.logException("Failed to get the QC completed jobs -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
		return null;
	}
	
	/**
	 * Retrieves the DelayReasonCode by the specified reasonCode
	 * @param reasonCode
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static CompletedContainerMoves getCompletedJobByContainerId(String containerId, String itvId) {
		Session session = null;
		Transaction tx = null;
		
		List<CompletedContainerMoves> resultSet = null;
		CompletedContainerMoves completedJob = null;
		try {
			session = SESSION_FACTORY.getCurrentSession();
			tx = session.beginTransaction();
			resultSet = session.createQuery(RDTQueryStatements.GET_COMPLETED_JOB_BY_CONTAINER)
					.setParameter("containerId", containerId)
					.setParameter("equipment", itvId)
					.list();
			tx.commit();

			if(resultSet != null && !resultSet.isEmpty()){
				completedJob = resultSet.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Failed to get the Completed job -" + EXCEPTION_IS, ex);
			session.getTransaction().rollback();
		}
				
		return completedJob;
	}
	
	public static void updateMultipleObjects(List<?> listOfObjects) {
		Session session  = null;
		Transaction transaction  = null;
		
		try{
		
			session = getSessionFactory().getCurrentSession();
			transaction = session.beginTransaction();
			int i=1;
			for(Object obj : listOfObjects) {
				i++;
				session.update(obj);
				//TODO:This value should be same as JDBC Batch Size in Hibernate Config
				if(i%25==0){
					session.flush();
					session.clear();

				}
			}
			transaction.commit();
			
		}catch(Exception ex) {
			logger.logException("Unable to update mulitple objects --",ex);
			if(transaction!=null && transaction.isActive()) {
				transaction.rollback();
			}
		} finally {
			if(session!=null && session.isOpen()) {
				session.close();
			}
		}
	}
}
