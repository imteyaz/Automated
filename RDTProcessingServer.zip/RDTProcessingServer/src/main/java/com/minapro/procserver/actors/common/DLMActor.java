package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DLM_RESPONSE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.common.Break;
import com.minapro.procserver.events.common.DLMEvent;
import com.minapro.procserver.events.common.DLMResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for handling the DLM events. </p>
 * 
 * @author Venkataramana.ch
 *
 */
public class DLMActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DLMActor.class);

    @Override
    /**
     * Handles the DLMEvents
     */
    public void onReceive(Object message) throws Exception {
        if (message instanceof DLMResponseEvent) {
            DLMResponseEvent dlmResponse = (DLMResponseEvent) message;
            logger.logMsg(LOG_LEVEL.DEBUG, dlmResponse.getUserID(), "Received DLM Response event-" + dlmResponse);
            sendDLMResponse(dlmResponse);
        } else if (message instanceof DLMEvent) {

            DLMEvent dlmEvent = (DLMEvent) message;
            logger.logMsg(LOG_LEVEL.DEBUG, dlmEvent.getUserID(), "Received DLM Request event-" + dlmEvent);
            sendDLMRequest(dlmEvent);
        } else {
            unhandled(message);
        }
    }

    /**
     * Sending DLM request received from Device to ESB
     * 
     * @param dlmEvent
     */
    private void sendDLMRequest(DLMEvent dlmEvent) {

        try {
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(dlmEvent.getUserID());

            ESBQueueManager.getInstance().postMessage(dlmEvent, operatorRole, dlmEvent.getTerminalID());

        } catch (Exception e) {
            logger.logException("Caught exception while processing DLMEvent -", e);
        }
    }

    /**
     * Construct the DLM Response message to the device
     * 
     * @param dlmDetails
     */
    private void sendDLMResponse(DLMResponseEvent dlmDetails) {

        long hour = 3600 * 1000;

        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(DLM_RESPONSE);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(DLM_RESPONSE);

            // get the message format
            List<String> breakFields = EventFormats.getInstance().getEventFields("BREAK");

            List<Break> breakTime = dlmDetails.getbreakTime();

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(
                    RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);

            String itemSeperator = DeviceCommParameters.getInstance().getCommParameter(
                    RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

            String rowSeperator = DeviceCommParameters.getInstance().getCommParameter(
                    RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = null;
            String msgField;

            responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP).append(valueSeperator).append(eventTypeID);

            for (int i = 1; i < msgFields.size(); i++) {

                responseToDevice.append(valueSeperator);
                msgField = msgFields.get(i);

                if ("Break".equalsIgnoreCase(msgField)) {

                    if (breakTime == null) {

                        List<Break> breakTime1 = new ArrayList<Break>();

                        String breakHour1 = DeviceCommParameters.getInstance().getCommParameter(
                                RDTProcessingServerConstants.BREAK1_AFTERLOGIN_HOURS);
                        String breakHour2 = DeviceCommParameters.getInstance().getCommParameter(
                                RDTProcessingServerConstants.BREAK2_AFTERLOGIN_HOURS);

                        String breakDuration1 = DeviceCommParameters.getInstance().getCommParameter(
                                RDTProcessingServerConstants.BREAK1_DURATION);
                        String breakDuration2 = DeviceCommParameters.getInstance().getCommParameter(
                                RDTProcessingServerConstants.BREAK2_DURATION);

                        logger.logMsg(LOG_LEVEL.DEBUG, "", "No BreakTime Received from DPW IT Systems");

                        Break brkMsg1 = new Break();
                        Break brkMsg2 = new Break();

                        Date brkDate1 = new Date(dlmDetails.getshiftStartTime().getTime()
                                + Integer.parseInt(breakHour1) * hour);
                        Date brkDate2 = new Date(dlmDetails.getshiftStartTime().getTime()
                                + Integer.parseInt(breakHour2) * hour);

                        brkMsg1.setBreakStartTime(brkDate1);
                        brkMsg1.setBreakDuration(breakDuration1);

                        brkMsg2.setBreakStartTime(brkDate2);
                        brkMsg2.setBreakDuration(breakDuration2);
                        breakTime1.add(brkMsg1);
                        breakTime1.add(brkMsg2);

                        breakTime = breakTime1;

                    }

                    for (int k = 0; k < breakTime.size(); k++) {

                        for (int j = 0; j < breakFields.size(); j++) {

                            Break breakObj = breakTime.get(k);
                            EventUtil.getInstance().getEventParameter(breakObj, breakFields.get(j), responseToDevice);
                            if ((j + 1) == breakFields.size()) {
                                break;
                            }
                            responseToDevice.append(itemSeperator);
                        }
                        if ((k + 1) == breakTime.size()) {
                            break;
                        }
                        responseToDevice.append(rowSeperator);
                    }

                } else {
                    EventUtil.getInstance().getEventParameter(dlmDetails, msgFields.get(i), responseToDevice);
                }
            }

            User user = RDTCacheManager.getInstance().getUserDetails(dlmDetails.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(dlmDetails.getUserID());
                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        dlmDetails.getTerminalID());
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing DLMDetails -", e);
        }
    }
}