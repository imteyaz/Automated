package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

public class PlannedMovesRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2265505405754712696L;

    private List<PlannedMovesEvent> plannedMovesRequest;

    public List<PlannedMovesEvent> getPlannedMovesRequest() {
        return plannedMovesRequest;
    }

    public void setPlannedMovesRequest(List<PlannedMovesEvent> plannedMovesRequest) {
        this.plannedMovesRequest = plannedMovesRequest;
    }

    @Override
    public String toString() {
        return "PlannedMovesRequestEvent [plannedMovesRequest=" + plannedMovesRequest + "]";
    }
}
