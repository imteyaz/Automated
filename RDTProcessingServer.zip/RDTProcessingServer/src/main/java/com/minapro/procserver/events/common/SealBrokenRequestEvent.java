package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the seal broken request details for a container
 * @author Rosemary George
 *
 */
public class SealBrokenRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8555564239595289060L;
   
    /**
     * The container which has seal issue
     */
    private String containerId;
    
    /**
     * The ITV which is carrying the seal issue container
     */
    private String itvId;
    
    /**
     * The selected troubleshoot area where the container needs to be sent
     */
    private String tsAreaId;
    
    /**
     * Indicates the moveType
     */
    private String moveType = "LOAD";

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getItvId() {
        return itvId;
    }

    public void setItvId(String itvId) {
        this.itvId = itvId;
    }

    public String getTsAreaId() {
        return tsAreaId;
    }

    public void setTsAreaId(String tsAreaId) {
        this.tsAreaId = tsAreaId;
    }

    @Override
    public String toString() {
        return "SealBrokenRequestEvent [containerId=" + containerId + ", itvId=" + itvId + ", tsAreaId=" + tsAreaId
                + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()="
                + getEventID() + "]";
    }   
}
