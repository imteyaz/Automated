package com.minapro.procserver.events.common;

import java.io.Serializable;

/**
 * ValueObject holding the container count based on the moveType, size and full/empty attributes.
 * 
 * @author Rosemary George
 *
 */
public class MovesToGoContainers implements Serializable {

	private static final long serialVersionUID = -3403498400945069843L;

	/**
	 * Indicates whether it is LOAD or DSCH case
	 */
	private String moveType; 
	
	/**
	 * Indicates whether it is for the 20 or 40 container size
	 */
	private int containerSize; 
	
	/**
	 * Count of the oog containers for the specified moveType+size+isEmpty combination
	 */
	private boolean isOog;
	
	/**
	 * Count of the normal containers for the specified moveType+size+isEmpty combination
	 */
	private int containerCount;

	/**
	 * Indicates whether it for Empty or Full condition
	 */
	private boolean isEmpty;
	
	 /**
     * In case the damage recording fails, holds the reason for failure
     */
    private String reason;

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public int getContainerSize() {
		return containerSize;
	}

	public void setContainerSize(int containerSize) {
		this.containerSize = containerSize;
	}
	public boolean isOog() {
		return isOog;
	}

	public void setOog(boolean isOog) {
		this.isOog = isOog;
	}

	public int getContainerCount() {
		return containerCount;
	}

	public void setContainerCount(int containerCount) {
		this.containerCount = containerCount;
	}

	public boolean isEmpty() {
		return isEmpty;
	}

	public void setEmpty(boolean isEmpty) {
		this.isEmpty = isEmpty;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
	@Override
	public String toString() {
		return "MovesToGoContainers [moveType=" + moveType + ", containerSize="
				+ containerSize + ", isOog=" + isOog + ", containerCount="
				+ containerCount + ", isEmpty=" + isEmpty + ", reason="
				+ reason + "]";
	}
	
}
