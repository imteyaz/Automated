package com.minapro.procserver.actors;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ExchangeContainerResponseEvent;
import com.minapro.procserver.events.ExchangeStatus;
import com.minapro.procserver.opus.util.ContainerMoveUtil;
import com.minapro.procserver.opus.util.QuaySideContainerMoveService;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the exchange container response from ESB.
 * @author Rosemary George
 *
 */
public class ExchangeContainerActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ExchangeContainerActor.class);
	
	private static final String INTERNAL_ERR = "InternalJobConfirmationError";
	private static final String TO_LOCATION_UPDATE_ERR = "ToLocationUpdateError";
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof ExchangeContainerResponseEvent){
			ExchangeContainerResponseEvent responseEvent = (ExchangeContainerResponseEvent)message;
			logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(), "Received exchange response event from ESB " + responseEvent);
			
			handleExchangeResponse(responseEvent);
		}else {
			getSender().tell(message, null);
		}
	}

	/**
	 * Handles the exchange response from ESB. Verifies whether the update was success for all the containers.
	 * If any one of the container status is false, sends failure response to UI and cancels the job confirmation.
	 * If all are successful, retrieves the container confirmation associated with the eventID 
	 * and processes it in Atom and forwards to ESB
	 * 
	 * @param responseEvent
	 */
	private void handleExchangeResponse(ExchangeContainerResponseEvent responseEvent) {
		try {
			boolean status = true;
			StringBuilder failedContainers = new StringBuilder();
			
			OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());			
			for(ExchangeStatus exchange : responseEvent.getExchangeStatus()){
				if(!exchange.isStatus()){
					logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getUserID(), "Exchange failed for container " + exchange.getContainerId());
					status = false;
					failedContainers.append(exchange.getContainerId() + ",");
				}
			}
			
			ContainerMoveEvent moveEvent = RDTVesselProfileCacheManager.getInstance().getContainerMoveEvent(responseEvent.getEventID());
			if(moveEvent != null){
				if(status){
					ContainerMoveUtil.getInstance().sendValidationResponseToDevice(true, "", responseEvent, role);
					User user = RDTCacheManager.getInstance().getUserDetails(moveEvent.getUserID());
					QuaySideContainerMoveService.getInstance().performContainerConfirmation(moveEvent, false, role, user,null);
					
					ESBQueueManager.getInstance().postMessage(moveEvent, role, moveEvent.getTerminalID());
				}else {
					ContainerMoveUtil.getInstance().sendValidationResponseToDevice(false, TO_LOCATION_UPDATE_ERR, responseEvent, role);
				}
			}else {
				logger.logMsg(LOG_LEVEL.WARN, responseEvent.getUserID(), "Unable to retrieve containerMove associated with eventId-" 
						+ responseEvent.getEventID());
				ContainerMoveUtil.getInstance().sendValidationResponseToDevice(false, INTERNAL_ERR, responseEvent, role);
			}
		}catch(Exception ex){
			logger.logException("Caught exception while handleExchangeResponse", ex);
		}		
	}
}
