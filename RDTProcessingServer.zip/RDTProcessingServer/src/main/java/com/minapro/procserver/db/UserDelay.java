package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * ValueObject holding the violation details
 * 
 * @author kalyani
 *
 */
@Entity
@Table(name = "MP_DELAY_RECORDING")
public class UserDelay implements Serializable {

    private static final long serialVersionUID = -902967598250209660L;

    @Id
    @SequenceGenerator(name = "seq1_gen", sequenceName = "MP_DELAY_ID_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "seq1_gen")
    @Column(name = "DELAY_ID")
    private int delayId;

    @Column(name = "DELAY_CODE")
    private String delayCode;

    @Column(name = "TERMINAL_ID")
    private String terminalId;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    @Column(name = "EQUIPMENT_ID")
    private String equipmentID;
    
    @Column(name = "REMARKS")
    private String remarks;       

    @Column(name = "CREATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_NM")
    private User createdBy;    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MODIFY_BY", referencedColumnName = "USER_NM")
    private User modifyBy;
    
    @Column(name = "MODIFY_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifyDateTime;        
    
    @Column(name = "ISDELETED")
    private String isDeleted;        
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DELAY_START_USER", referencedColumnName = "USER_NM")
    private User delayStartUser;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DELAY_END_USER", referencedColumnName = "USER_NM")
    private User delayEndUser;
         
       
    @Column(name = "DELAY_START_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date delayStartTime;
            
    @Column(name = "DELAY_END_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date delayEndTime;
    
    @Column(name = "IS_AUTOMATIC")
    private String isAutomated;
        
    public UserDelay() {
    }
    
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    
    

    public Date getmodifyDateTime() {
        return modifyDateTime;
    }

    public void setmodifyDateTime(Date modifyDateTime) {
        this.modifyDateTime = modifyDateTime;
    }
    
       
    
    public int getdelayId() {
        return delayId;
    }

    public void setdelayId(int delayId) {
        this.delayId = delayId;
    }
    
    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }    
    
    
       
    public String getDealyCode() {
        return delayCode;
    }

    public void setDealyCode(String delayCode) {
        this.delayCode = delayCode;
    }

    
    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }
    
    
    public User getmodifyBy() {
        return modifyBy;
    }

    public void setmodifyBy(User modifyBy) {
        this.modifyBy = modifyBy;
    }
    
    
    
    public User getdelayStartUser() {
        return delayStartUser;
    }

    public void setdelayStartUser(User delayStartUser) {
        this.delayStartUser = delayStartUser ;
    }
        
    
    public User getdelayEndUser() {
        return delayEndUser;
    }

    public void setdelayEndUser(User delayEndUser) {
        this.delayEndUser = delayEndUser ;
    }
        
     
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getdelayStartTime() {
        return delayStartTime;
    }

    public void setdelayStartTime(Date startTime) {
        this.delayStartTime =startTime;
    }
    
    public Date getdelayEndTime() {
        return delayEndTime;
    }

    public void setdelayEndTime(Date endTime) {
        this.delayEndTime =endTime;
    } 
     
   
    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }
    
    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }
    
   
    public String getIsAutomated() {
        return isAutomated;
    }

    public void setIsAutomated(String isAutomated) {
        this.isAutomated = isAutomated;
    }
    
    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    @Override
    public String toString() {
        return "UserDelay [delayId=" + delayId + ", delayCode=" + delayCode + ", terminalId=" + terminalId
                + ", rotationId=" + rotationId + ", equipmentID=" + equipmentID + ", remarks=" + remarks
                + ", createdDatetime=" + createdDatetime + ", createdBy=" + createdBy + ", modifyBy=" + modifyBy
                + ", modifyDateTime=" + modifyDateTime + ", isDeleted=" + isDeleted + ", delayStartUser="
                + delayStartUser + ", delayEndUser=" + delayEndUser + ", delayStartTime=" + delayStartTime
                + ", dealyEndTime=" + delayEndTime + ", isAutomated=" + isAutomated + "]";
    }

   
}

