package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import com.minapro.procserver.events.che.NewLocationRequestEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import akka.actor.UntypedActor;

/**
 * 
 * This actor class is responsible sending the container information into the ESB.
 * 
 * @author 1201257
 * 
 */
public class NewLocationRequestActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(NewLocationRequestActor.class);

    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass().getSimpleName())
                .append(ON_RECEIVE).toString());

        if (message instanceof NewLocationRequestEvent) {
            sendContainerIdToESB((NewLocationRequestEvent) message);
        } else {
            unhandled(message);
        }
    }

    private void sendContainerIdToESB(NewLocationRequestEvent newLocationRequestEvent) {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendContainerIdToESB() ").toString());
        ESBQueueManager.getInstance().postMessage(newLocationRequestEvent, OPERATOR.CHE,
                newLocationRequestEvent.getTerminalID());
    }

}
