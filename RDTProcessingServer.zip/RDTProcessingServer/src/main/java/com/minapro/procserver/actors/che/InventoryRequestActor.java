package com.minapro.procserver.actors.che;

import com.minapro.procserver.events.che.InventoryRequestEvent;

import akka.actor.UntypedActor;

public class InventoryRequestActor extends UntypedActor {

    @Override
    public void onReceive(Object message) throws Exception {
      
        
        if(message instanceof InventoryRequestEvent){
            InventoryRequestEvent inventoryRequestEvent=(InventoryRequestEvent) message;
            sendInventoryResponseToUI(inventoryRequestEvent);
        }
        
    }

    private void sendInventoryResponseToUI(InventoryRequestEvent inventoryRequestEvent) {
      //TODO - added code
        
    }

}
