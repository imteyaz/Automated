package com.minapro.procserver.cep;

/**
 * Interface for CEP listeners
 * 
 * @author Rosemary George
 *
 */
public interface StatementSubscriber {
    public String getStatement();

}