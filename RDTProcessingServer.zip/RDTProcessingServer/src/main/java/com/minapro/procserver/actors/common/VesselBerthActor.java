package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.QCPLCConstants.PORT_SIDE;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BayProfile;
import com.minapro.procserver.cache.CellGrid;
import com.minapro.procserver.cache.CellGrid.CELL_STATUS;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.bayprofile.BerthedVessel;
import com.minapro.procserver.db.bayprofile.TemplateDetails;
import com.minapro.procserver.db.bayprofile.TemplateHeader;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.common.BaywiseContainerDetailsRequestEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.RefreshVesselEvent.REFRESH_TYPE;
import com.minapro.procserver.events.common.VesselBerthEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.RDTQueryStatements;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the VesselBerthEvent coming from ESB</p>
 * 
 * <p> When the VesselBerth event is received for a particular vessel, the corresponding vessel profile related data is
 * fetched from the database and Cache will be populated with section wise bay profiles for the vessel.</p>
 * 
 * <p> As each section of the vessel is filled with cell data, a call is made to the ESB to fetch the container details
 * belonging to the that particular section.</p>
 * 
 * @author Rosemary George
 *
 */
public class VesselBerthActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselBerthActor.class);

    @Override
    public void onReceive(Object message) throws Exception {

        String rotationId = null;
        if (message instanceof VesselBerthEvent) {
            VesselBerthEvent berthEvent = (VesselBerthEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, "",
                    "Received Vessel Berthed event from ESB for the vessel " + berthEvent.getVesselCode());

            rotationId = berthEvent.getRotationID();
            clearVesselExceptions(rotationId, berthEvent.getVesselCode());

            if (RDTVesselProfileCacheManager.getInstance().getVesselCode(berthEvent.getRotationID()) == null) {
                createVesselProfileSkeleton(berthEvent.getVesselCode(), berthEvent.getRotationID());

                Vessel vessel = HibernateUtil.getVessel(berthEvent.getVesselCode());
                if (vessel == null) {
                    vessel = new Vessel();
                    vessel.setVesselCode(berthEvent.getVesselCode());
                }
                vessel.setRotationId(berthEvent.getRotationID());
                vessel.setVoyageNo(berthEvent.getVoyage());
                vessel.setVesselNameFromTos(berthEvent.getVesselName());

                RDTVesselProfileCacheManager.getInstance().addVesselToBerthedList(vessel);
                
                if(berthEvent.getBerthSide() == null){
                	berthEvent.setBerthSide(PORT_SIDE);
                }
                RDTVesselProfileCacheManager.getInstance().saveVesselBerthSide(berthEvent.getRotationID(), berthEvent.getBerthSide());

                RDTVesselProfileCacheManager.getInstance().addVesselMapping(berthEvent.getRotationID(),
                        vessel.getVesselNo().toString());

                linkQCsToRotation(berthEvent.getRotationID());

                saveVesselDetails(berthEvent);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, "vesselCode" + berthEvent.getVesselCode(),
                        "The vessel details are already present in cache and it is not refresh request. Ignore this event ");
            }

        } else if (message instanceof BerthedVessel) {
            // indicates that server start up and loading data from DB
            BerthedVessel vesselInfo = (BerthedVessel) message;
            rotationId = vesselInfo.getRotationId();

            clearVesselExceptions(rotationId, vesselInfo.getVesselCode());
            
            createVesselProfileSkeleton(vesselInfo.getVesselCode(), vesselInfo.getRotationId());

            Vessel vessel = HibernateUtil.getVessel(vesselInfo.getVesselCode());
            if (vessel == null) {
                vessel = new Vessel();                
            }
            vessel.setRotationId(vesselInfo.getRotationId());
            vessel.setVoyageNo(vesselInfo.getVoyage());
            vessel.setVesselNameFromTos(vesselInfo.getVesselNameFromTos());

            RDTVesselProfileCacheManager.getInstance().addVesselToBerthedList(vessel);
            RDTVesselProfileCacheManager.getInstance().saveVesselBerthSide(vesselInfo.getRotationId(), vesselInfo.getBerthSide());
            
            RDTVesselProfileCacheManager.getInstance().addVesselMapping(vesselInfo.getRotationId(),
            		vessel.getVesselNo().toString());

            linkQCsToRotation(vesselInfo.getRotationId());
        } else {
            unhandled(message);
        }

        // Wait for some time to get the vessel profile filled with container details.
        try {
            Thread.sleep(40000);
        } catch (InterruptedException e) {
            logger.logException("Caught exception while sleeping the thread, ignore - ", e);
        }
        loadCompletedJobs(rotationId);
    }

    /**
     * Deletes all the exceptions logged for the specified vesselCode from the database
     * @param rotationId
     * @param vesselCode
     */
    private void clearVesselExceptions(String rotationId, String vesselCode) {
        logger.logMsg(LOG_LEVEL.INFO, vesselCode + ":" + rotationId, "Clearing the vessel exceptions");
        try{
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction txn = session.beginTransaction();
    
            Query query = session.createQuery(RDTQueryStatements.CLEAR_VESSEL_EXCEPTION_QUERY);
            query.setParameter("vesselCode", Integer.parseInt(vesselCode));
            
            int result = query.executeUpdate();
            txn.commit();
            
            logger.logMsg(LOG_LEVEL.INFO, vesselCode + ":" + rotationId, "No of Deleted exceptions=" + result);
        }catch(Exception ex){
            logger.logException("Caught Exception while clearing the vessel exception", ex);
        }
    }

    /**
     * Retrieves the completed container moves performed for the specified rotation ID and populates the completed Jobs
     * cache. Also updates the bay profile with these containers as discharged or loaded
     * 
     * @param rotationId
     */
    private void loadCompletedJobs(String rotationId) {
        List<CompletedContainerMoves> completedMoves = HibernateUtil.getCompletedMoves(rotationId);

        if (completedMoves != null) {
            logger.logMsg(LOG_LEVEL.INFO, rotationId,
                    "Start to load the completed container moves for the rotation - Available Moves Count "
                            + completedMoves.size());

            String cellLocation;
            for (CompletedContainerMoves containerMove : completedMoves) {
                try {
                    RDTCacheManager.getInstance().addToCompletedJobs(containerMove,
                            containerMove.getUser().getUserID(), rotationId, containerMove.getEquipment());

                    // No need to update bay profile in general lift operations
                    if (!containerMove.getContainerId().startsWith("HATCHCOVER")
                            && !containerMove.getContainerId().startsWith("MANCAGE")
                            && !containerMove.getContainerId().startsWith("BREAKBULK")) {
                        if ("DSCH".equals(containerMove.getMoveType())) {
                            cellLocation = containerMove.getFromLocation();
                        } else {
                            cellLocation = containerMove.getToLocation();
                        }

                        RDTVesselProfileCacheManager.getInstance().updateBayProfile(cellLocation,
                                containerMove.getContainerId(), rotationId, containerMove.getMoveType());
                    }
                } catch (Exception e) {
                    logger.logException("Caught exception while loading the completed moves, ignore - ", e);
                }
            }
        }
    }

    /**
     * Retrieves the QC mappings available for the specified rotation from the database and link it in the cache.
     * 
     * @param rotationId
     */
    private void linkQCsToRotation(String rotationId) {
        logger.logMsg(LOG_LEVEL.INFO, rotationId, "Start to link the QCs to the rotation ID");

        Collection<Equipment> qcMappings = HibernateUtil.getRotationToQCMappingForVessel(rotationId);
        if (qcMappings != null && !qcMappings.isEmpty()) {
            logger.logMsg(LOG_LEVEL.DEBUG, rotationId, "Received qcMappings for the rotation -" + qcMappings);
            for (Equipment qc : qcMappings) {
                RDTVesselProfileCacheManager.getInstance().linkQCToRotation(rotationId, qc.getEquipmentID());
            }
        }
    }

    /**
     * Saves the vessel berth details in Database
     * 
     * @param berthEvent
     */
    private void saveVesselDetails(VesselBerthEvent berthEvent) {
        BerthedVessel vesselInfo = new BerthedVessel();
        vesselInfo.setBerthedDate(new Date());
        if (berthEvent.getBerthID() != null) {
            vesselInfo.setBerthId(berthEvent.getBerthID());
        } else {
            vesselInfo.setBerthId("B");
        }
        vesselInfo.setRotationId(berthEvent.getRotationID());
        vesselInfo.setVesselCode(berthEvent.getVesselCode());
        vesselInfo.setVoyage(berthEvent.getVoyage());
        vesselInfo.setVesselNameFromTos(berthEvent.getVesselName());
        vesselInfo.setBerthSide(berthEvent.getBerthSide());

        logger.logMsg(LOG_LEVEL.INFO, "", "Saving the vessel berth event in Database " + vesselInfo);

        JournalEvent journal = new JournalEvent(vesselInfo, UPDATETYPE.ADD);
        getSender().tell(journal, null);
    }

    /**
     * Retrieves only the bays which has the 00 rows present for the specified vessel
     * 
     * @param vesselCode
     *            - vessel which needs to be queried
     * @return ArrayList<sectionNo:bayNo>
     */
    private List<String> getZeroOffsetBays(String vesselCode) {
        List<String> zeroOffsetBays = null;

        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction txn = session.beginTransaction();

            @SuppressWarnings("unchecked")
            List<Object[]> resultSet = session.createQuery(RDTQueryStatements.VESSEL_PROFILE_ZERO_ROW_QUERY)
                    .setParameter("vesselNo", Integer.parseInt(vesselCode)).list();
            txn.commit();

            String sectNo, bayNo;
            if (!resultSet.isEmpty()) {
                zeroOffsetBays = new ArrayList<String>();
                for (Object[] row : resultSet) {
                    sectNo = row[0].toString();
                    bayNo = row[1].toString();

                    zeroOffsetBays.add(sectNo + ":" + bayNo);
                }

                logger.logMsg(LOG_LEVEL.INFO, "VesselCode:" + vesselCode,
                        "00 Rows are present for the following section:bays- " + zeroOffsetBays);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, "VesselCode:" + vesselCode, "NO 00 Row bays are present for this vessel");
            }

        } catch (Exception ex) {
            logger.logException("VesselCode:" + vesselCode
                    + "Caught exception while trying to retrieve the zero row bays - ", ex);
        }

        return zeroOffsetBays;
    }

    /**
     * <p>Creates the first level skeleton profile for the vessel.</p>
     * 
     * <p>The details are fetched from master database and populates the bayProfiles for each bays present in the vessel
     * and adds to the VesselProfile Cache</p>
     * 
     * @param vesselCode
     * @param rotationId
     */
    private void createVesselProfileSkeleton(String vesselCode, String rotationId) {
        try {
            List<String> zeroOffsetBays = getZeroOffsetBays(vesselCode);

            int maxRowsOnTheVessel = HibernateUtil.getMaxRowsForVessel(vesselCode);
            int offsetFor00Row = maxRowsOnTheVessel / 2;

            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction txn = session.beginTransaction();

            @SuppressWarnings("unchecked")
            List<Object[]> resultSet = session
                    .createQuery(RDTQueryStatements.VESSEL_PROFILE_MIN_MAX_OFFSET_BAYWISE_QUERY)
                    .setParameter("vesselNo", Integer.parseInt(vesselCode)).list();
            txn.commit();

            if (!resultSet.isEmpty()) {
                int minRowOffset = 0;
                int maxRowOffset = 0;
                int minTierOffset = 0;
                int maxTierOffset = 0;
                boolean zeroOffset = false;
                String tierTemplate = "";
                boolean isDefaultTierTemplate = true;

                int sectionNo, prevSectNo = Integer.parseInt(resultSet.get(0)[0].toString());
                String bayNo;
                boolean underDeck;

                Map<String, BayProfile> bayProfiles = null;
                BayProfile bayProfile = null;

                for (Object[] row : resultSet) {
                    sectionNo = Integer.parseInt(row[0].toString());
                    underDeck = "U".equals(row[1].toString()) ? true : false;
                    bayNo = row[2].toString();
                    minRowOffset = Integer.parseInt(row[3].toString());
                    maxRowOffset = Integer.parseInt(row[4].toString());
                    minTierOffset = Integer.parseInt(row[5].toString());
                    maxTierOffset = Integer.parseInt(row[6].toString());
                    tierTemplate = row[7].toString();
                    isDefaultTierTemplate = "Y".equals(row[8].toString()) ? true : false;
                    zeroOffset = false;

                    if (sectionNo != prevSectNo) {
                        RDTVesselProfileCacheManager.getInstance().addSectionDetails(vesselCode, prevSectNo,
                                bayProfiles);
                        logger.logMsg(LOG_LEVEL.INFO, "VesselCode:" + vesselCode,
                                "Adding Skeleton Bay profile for section " + prevSectNo + " " + bayProfiles);

                        fillCellDetails(vesselCode, prevSectNo, bayProfiles, offsetFor00Row);

                        // sent message to ESB for container details
                        sendMessageToFetchContainers(vesselCode, rotationId, bayProfiles);

                        prevSectNo = sectionNo;
                        bayProfiles = null;
                    }

                    if (zeroOffsetBays != null) {
                        zeroOffset = zeroOffsetBays.contains(sectionNo + ":" + bayNo);
                    }

                    bayProfile = new BayProfile(bayNo, underDeck, minRowOffset, maxRowOffset, minTierOffset,
                            maxTierOffset, zeroOffset);
                    bayProfile.setOffsetFor00Row(maxRowsOnTheVessel);
                    bayProfile.setTierHeader(tierTemplate);
                    bayProfile.setStdTierTemplate(isDefaultTierTemplate);
                    if (bayProfiles == null) {
                        bayProfiles = new LinkedHashMap<String, BayProfile>();
                    }

                    bayProfiles.put(bayNo, bayProfile);
                    RDTVesselProfileCacheManager.getInstance().mapBayToSection(vesselCode, bayNo, row[1].toString(),
                            sectionNo);

                }

                // save the last section details
                RDTVesselProfileCacheManager.getInstance().addSectionDetails(vesselCode, prevSectNo, bayProfiles);
                fillCellDetails(vesselCode, prevSectNo, bayProfiles, offsetFor00Row);
                sendMessageToFetchContainers(vesselCode, rotationId, bayProfiles);
            }
        } catch (Exception ex) {
            logger.logException("VesselCode:" + vesselCode
                    + " Caught exception while trying to create the vesselProfileSkeleton - ", ex);
        }
    }

    /**
     * <p>Fills the actual cell details for the bays present in the specified section.</p>
     * 
     * <p> All the cells corresponding to the selected vessel and section is retrieved from the database and updates the
     * corresponding CellGrid Object from the BayProfile CellGrid[tier][row] array.</p>
     * 
     * @param vesselCode
     *            - Code of the berthed vessel
     * @param sectionNo
     *            - a particular section of the vessel
     * @param bayProfiles
     *            - BayProfiles corresponding to the section specified
     * @param offsetFor00Row
     *            - The off set value for the 00 row for this particular vessel
     */
    private void fillCellDetails(String vesselCode, int sectionNo, Map<String, BayProfile> bayProfiles,
            int offsetFor00Row) {

        logger.logMsg(LOG_LEVEL.INFO, "VesselCode:" + vesselCode, "Start to fill the cell details for section "
                + sectionNo);

        Map<String, TemplateHeader> tierTemplates = new HashMap<String, TemplateHeader>();
        for (String bayId : bayProfiles.keySet()) {
            BayProfile bay = bayProfiles.get(bayId);
            if (!bay.isStdTierTemplate()) {
                logger.logMsg(LOG_LEVEL.INFO, "VesselCode:" + vesselCode, bayId
                        + " Bay doesn't have standard tier template, loading from database");
                TemplateHeader templateHeader = RDTVesselProfileCacheManager.getInstance().getTemplateHeader(
                        bay.getTierHeader());
                tierTemplates.put(bayId, templateHeader);
            }
        }

        try {
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            Transaction txn = session.beginTransaction();

            @SuppressWarnings("unchecked")
            List<Object[]> resultSet = session.createQuery(RDTQueryStatements.VESSEL_PROFILE_CELL_SECTION_WISE_QUERY)
                    .setParameter("vesselNo", Integer.parseInt(vesselCode)).setParameter("sectionNo", sectionNo).list();
            txn.commit();

            String bayNo;
            int rowOffset, tierOffset;
            boolean underDeckIndicator = false, allowed45 = false, unAvailable = true, onlyEmptyContainer = false, reeferFlag = false, hotSpotFlag = false;
            BayProfile bayProfile;
            String tierNo;
            CellGrid cell;
            if (!resultSet.isEmpty()) {
                for (Object[] row : resultSet) {
                    bayNo = row[0].toString();
                    underDeckIndicator = "U".equals(row[1].toString()) ? true : false;
                    rowOffset = Integer.parseInt(row[2].toString());
                    tierOffset = Integer.parseInt(row[3].toString());
                    unAvailable = Boolean.parseBoolean(row[4].toString());
                    onlyEmptyContainer = Boolean.parseBoolean(row[5].toString());
                    hotSpotFlag = Boolean.parseBoolean(row[6].toString());
                    reeferFlag = Boolean.parseBoolean(row[7].toString());
                    allowed45 = Boolean.parseBoolean(row[8].toString());

                    bayProfile = bayProfiles.get(bayNo);
                    if (bayProfile != null) {
                        cell = bayProfile.getCellGrid(rowOffset, tierOffset);
                        cell.setVesselRowNo(getVesselRowNoFromOffset(rowOffset, offsetFor00Row));
                        if (bayProfile.isStdTierTemplate()) {
                            tierNo = getVesselTierNoFromOffset(underDeckIndicator, tierOffset);
                        } else {
                            tierNo = getVesselTierNoFromTemplate(tierTemplates.get(bayNo), tierOffset);
                        }
                        cell.setVesselTierNo(tierNo);
                        cell.setStatus(mapCellStatus(unAvailable, reeferFlag, hotSpotFlag, onlyEmptyContainer,
                                allowed45));
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException("VesselCode:" + vesselCode
                    + " Caught exception while trying to fill the vesselProfileSkeleton with cell details- ", ex);
        }
    }

    /**
     * Retrieves the tier number from the template by providing the offset value.
     * 
     * @param templateHeader
     * @param tierOffset
     * @return null if the specified tierOffset not present in the template
     */
    private String getVesselTierNoFromTemplate(TemplateHeader templateHeader, int tierOffset) {
        if (templateHeader != null) {
            for (TemplateDetails details : templateHeader.getTemplateDetails()) {
                if (tierOffset == details.getPk().getOffset()) {
                    return details.getVesselLabel();
                }
            }
        }

        return null;
    }

    /**
     * Sends message to the ESB for getting the container details for the specified bays.
     * 
     * @param vesselCode
     * @param rotationId
     * @param bayProfiles
     */
    private void sendMessageToFetchContainers(String vesselCode, String rotationId, Map<String, BayProfile> bayProfiles) {
        BayProfile bayProfile = null;
        Integer largestBayId = 0;
        int currentBay;
        for (String bayId : bayProfiles.keySet()) {
            bayProfile = bayProfiles.get(bayId);
            constructAndSendMessage(bayId, vesselCode, bayProfile.isUnderDeckIndicator(), rotationId,
                    bayProfile.getTierHeader());
            currentBay = Integer.parseInt(bayProfile.getVesselBayId());
            if (currentBay > largestBayId) {
                largestBayId = currentBay;
            }
        }

        // check for logical bay - if any 40" containers are planned
        if (largestBayId != 0) {
            Integer logicalBayId = largestBayId - 1;

            String bayNo;
            if (logicalBayId < 10) {
                bayNo = "0" + logicalBayId;
            } else {
                bayNo = logicalBayId.toString();
            }

            constructAndSendMessage(bayNo, vesselCode, bayProfile.isUnderDeckIndicator(), rotationId,
                    bayProfile.getTierHeader());
        }
    }

    /**
     * Construct the Bay wise container request message and sends to the ESB for fetching the containers present on the
     * specified bay.
     * 
     * @param bayId
     * @param vesselCode
     * @param deckIndicator
     * @param rotationId
     */
    private void constructAndSendMessage(String bayId, String vesselCode, boolean deckIndicator, String rotationId,
            String tierTemplate) {

        BaywiseContainerDetailsRequestEvent containerDetailsRequest = new BaywiseContainerDetailsRequestEvent();
        containerDetailsRequest.setVesselCode(vesselCode);
        containerDetailsRequest.setRotationID(rotationId);
        containerDetailsRequest.setBayNo(bayId);
        containerDetailsRequest.setRefreshType(REFRESH_TYPE.ALL);

        String deckStartTierNo = "80";
        TemplateHeader template = RDTVesselProfileCacheManager.getInstance().getTemplateHeader(tierTemplate);
        TreeSet<TemplateDetails> details = null;
        if (template != null) {
            details = new TreeSet<TemplateDetails>(template.getTemplateDetails());
        }

        if (deckIndicator) {
            containerDetailsRequest.setUnderDeckIndication("U");
            if (details != null) {
                deckStartTierNo = details.descendingIterator().next().getVesselLabel();
            }
        } else {
            containerDetailsRequest.setUnderDeckIndication("D");
            if (details != null) {
                deckStartTierNo = details.iterator().next().getVesselLabel();
            }
        }
        containerDetailsRequest.setDeckStartTierNo(deckStartTierNo);

        String terminalId = DeviceCommParameters.getInstance().getCommParameter(
                RDTProcessingServerConstants.TERMINAL_KEY);
        ESBQueueManager.getInstance().postMessage(containerDetailsRequest, OPERATOR.COMMON, terminalId);
    }

    /**
     * Maps the cell status to an appropriate value based on the specified parameters.
     * 
     * @param unavailable
     * @param reeferFlag
     * @param hotSpotFlag
     * @param onlyEmptyContainers
     * @param allowed45
     * @return {@link CELL_STATUS}
     */
    private CELL_STATUS mapCellStatus(boolean unavailable, boolean reeferFlag, boolean hotSpotFlag,
            boolean onlyEmptyContainers, boolean allowed45) {
        CELL_STATUS cellStatus;

        if (unavailable) {
            cellStatus = CELL_STATUS.NOTINUSE;
        } else if (reeferFlag) {
            cellStatus = CELL_STATUS.REEFER;
        } else if (hotSpotFlag) {
            cellStatus = CELL_STATUS.HOT_SPOT;
        } else if (onlyEmptyContainers) {
            cellStatus = CELL_STATUS.ONLY_EMPTY_CONTAINER;
        } else if (allowed45) {
            cellStatus = CELL_STATUS.ALLOWED_45;
        } else {
            cellStatus = CELL_STATUS.AVAILABLE;
        }

        return cellStatus;
    }

    /**
     * <p>Get the actual vessel tier number using the specified tier offset value.</p>
     * 
     * <p> If the tier template is the default tier template, the following logic is used.</p> <p> If the underDeck flag
     * is true, the vessel tier numbers starts from 02 and in case of deck, the tier numbers starts from 80.</p>
     * 
     * @param underDeckFlag
     * @param tierOffset
     * @param isDefaultTierTemplate
     * @param templateId
     * @return String - vesselTierNumber(if the tier number is single digit, 0 is prefixed.
     */
    private String getVesselTierNoFromOffset(boolean underDeckFlag, int tierOffset) {
        String vesselTierNo;

        int tierNo;

        if (underDeckFlag) {
            tierNo = (tierOffset * 2) + 2;
        } else {
            tierNo = (tierOffset * 2) + 80;
        }

        if (tierNo < 10) {
            vesselTierNo = "0" + tierNo;
        } else {
            vesselTierNo = Integer.toString(tierNo);
        }

        return vesselTierNo;
    }

    /**
     * <p> Get the actual vessel row number using the specified row offset value. </p>
     * 
     * @param rowOffset
     * @return String - vessel row Number (if the row number is single digit, 0 is prefixed.
     */
    private String getVesselRowNoFromOffset(int rowOffset, int offsetFor00Row) {
        String vesselRowNo;

        int rowNo;
        if (rowOffset <= offsetFor00Row) {
            rowNo = (offsetFor00Row - rowOffset) * 2;
        } else {
            rowNo = ((rowOffset - offsetFor00Row) * 2) - 1;
        }

        if (rowNo >= 10) {
            vesselRowNo = Integer.toString(rowNo);
        } else {
            vesselRowNo = "0" + rowNo;
        }

        return vesselRowNo;
    }
}
