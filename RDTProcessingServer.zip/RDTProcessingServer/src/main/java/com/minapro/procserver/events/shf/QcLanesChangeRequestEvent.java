package com.minapro.procserver.events.shf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Holds QcLanes Change Request event.
 *
 * @author UMAMAHESH M
 */
public class QcLanesChangeRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -5499461741804587331L;
    private String qcChangedLaneStations;

    /**
     * @return the qcChangedLaneStations
     */
    public String getQcChangedLaneStations() {
        return qcChangedLaneStations;
    }

    /**
     * @param qcChangedLaneStations
     *            the qcChangedLaneStations to set
     */
    public void setQcChangedLaneStations(String qcChangedLaneStations) {
        this.qcChangedLaneStations = qcChangedLaneStations;
    }

    @Override
    public String toString() {
        return "QcLanesChangeRequest [qcChangedLaneStations=" + qcChangedLaneStations + ", User Id=" + getUserID()
                + ",TerminalID=" + getTerminalID() + "]";
    }
}
