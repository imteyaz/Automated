package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.OPERATOR_IN_BREAK;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.EQUIPMENT_PLC_EVENTS_STATUS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.WORKING_EQUIPMENTS_READ_INTERVAL;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class WorkingEquipmentsPLCStatusPollingActor extends UntypedActor{
	
	MinaProApplicationLogger logger = new MinaProApplicationLogger(WorkingEquipmentsPLCStatusPollingActor.class);
	
	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
	            RDTProcessingServerConstants.TERMINAL_KEY);
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
	private static final String EQUIPMENT = " Equipment::";
	
	@Override
	public void onReceive(Object arg0) throws Exception {
		
		workingUsersPLCEventStatus();
		
	}
	
	
	public void workingUsersPLCEventStatus() {

		logger.logMsg(LOG_LEVEL.INFO, "", " Started workingUsersPLCEventStatus()");

		RDTCacheManager rdtCache = RDTCacheManager.getInstance();

		Set<String> allocatedUsers = rdtCache.getAllocatedUsers();

		try {

			if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {

				int frequency = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(WORKING_EQUIPMENTS_READ_INTERVAL));

				List<List<String>> workingEqpmntsFromDB = HibernateUtil.getWorkingEquipmentsFromDB(frequency);

				Equipment equipment = null;

				logger.logMsg(LOG_LEVEL.INFO, " ", " Logged In Users  " + allocatedUsers);

				for (String currentUser : allocatedUsers) {

					if(!rdtCache.isOperatorAvailable(currentUser)){
						logger.logMsg(LOG_LEVEL.INFO,currentUser,OPERATOR_IN_BREAK);
						continue;
					}
					OPERATOR operatorRole = rdtCache.getUserLoggedInRole(currentUser);

					if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.CHE)) {

						Device device = rdtCache.getDeviceDetails(rdtCache.getDeviceMapping(currentUser));

						if (device != null && device.getEquipment().getEquipmentID() != null) {

							equipment = device.getEquipment();
						}

					} else if (operatorRole.equals(OPERATOR.HC)) {

						equipment = rdtCache.getEquipmentDetails(rdtCache.getQCEquipmentAllocatedForHC(currentUser));
					} 

					if(equipment!=null) {

						logger.logMsg(LOG_LEVEL.INFO, " ", new StringBuilder(" Current user ").append(currentUser).
								append(" Role Is:: ").append(operatorRole).append(EQUIPMENT).append(equipment.getEquipmentID()).toString());
						checkEquipmentStatusSendNotifToUI(workingEqpmntsFromDB,equipment,currentUser,operatorRole);
					}

				}

			} else {
				logger.logMsg(LOG_LEVEL.INFO, " ", " Zero Users Are Allocated Now.");
			}

		}catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" In workingUsersPLCEventStatus ").
					append(REASON).toString(), ex);

		}
	}

	private void checkEquipmentStatusSendNotifToUI(List<List<String>> workingEqpmntsFromDB,Equipment equipment,
			String currentUser, OPERATOR operatorRole) {

		Boolean equipmentPLCEventStatusFromCache = RDTCacheManager.getInstance().getEquipmentPLCEventStatus(currentUser,equipment.getEquipmentID());
		equipmentPLCEventStatusFromCache = equipmentPLCEventStatusFromCache == null ? false : equipmentPLCEventStatusFromCache;
		boolean equipmentPLCEventStatusFromDB = checkEquipmentStatus(workingEqpmntsFromDB,equipment.getEquipmentID());

		if(equipmentPLCEventStatusFromCache==equipmentPLCEventStatusFromDB) {

			logger.logMsg(LOG_LEVEL.INFO,currentUser,new StringBuilder(" No Change Happend ").append(EQUIPMENT).
					append(equipment.getEquipmentName()).append(" Status::").append(equipmentPLCEventStatusFromDB).toString());

		} else {
			logger.logMsg(LOG_LEVEL.INFO,currentUser,new StringBuilder(" Change Happend ").append(EQUIPMENT).
					append(equipment.getEquipmentName()).append(" Status From Cache::").append(equipmentPLCEventStatusFromCache).
					append(" Current Status::").append(equipmentPLCEventStatusFromDB).toString()); 
			//setting status to cache
			RDTCacheManager.getInstance().setEquipmentPLCEventStatus(currentUser, equipment.getEquipmentID(), equipmentPLCEventStatusFromDB);
			//Sending Notification To Corresponding User.
			sendNotificationToUI(currentUser,operatorRole,equipmentPLCEventStatusFromDB);
		}

	}


	private void sendNotificationToUI(String currentUser,OPERATOR operatorRole, boolean equipmentStatus) {

		logger.logMsg(LOG_LEVEL.INFO,currentUser,new StringBuilder(" Started Sending PLC Event Status To UI..") .toString());

		String eventTypeID	 			= DeviceEventTypes.getInstance().getEventType(EQUIPMENT_PLC_EVENTS_STATUS);

		eventTypeID = eventTypeID==null ? "9101" : eventTypeID;

		StringBuilder notificationToDevice = new StringBuilder(NOTIF);

		notificationToDevice.append(VALUE_SEPARATOR).append(eventTypeID).append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR).
		append(DATE_FORMATTER.format(new Date())).append(VALUE_SEPARATOR).
		append(equipmentStatus).append(VALUE_SEPARATOR).append(currentUser).append(VALUE_SEPARATOR).append(TERMINAL_ID);

		CommunicationServerQueueManager.getInstance().postMessage(notificationToDevice.toString(),
				operatorRole, TERMINAL_ID);

	}
	
	private boolean checkEquipmentStatus(List<List<String>> workingEqpmntsFromDB,String  equipmentIdFromCache){
		
		for(List<String> data : workingEqpmntsFromDB) {

			for(String equipmentIdFromDB : data) {
				if(equipmentIdFromCache.equalsIgnoreCase(equipmentIdFromDB)) {
					return true;

				}
			}
		}
		return false;

	}

}
