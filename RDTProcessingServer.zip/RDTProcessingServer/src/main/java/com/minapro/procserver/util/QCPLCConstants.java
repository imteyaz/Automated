package com.minapro.procserver.util;

/**
 * Interface containing all the constants related to QC PLC events
 * 
 * @author VenkataRamana CH
 *
 */
public interface QCPLCConstants {

    public static final String SPREADER1_LOCKEDUP = "Spreader1Lockedup";
    public static final String SPREADER2_LOCKEDUP = "Spreader2Lockedup";

    public static final String TROLLEY1_POSITION = "Trolley1Position";
    public static final String TROLLEY2_POSITION = "Trolley2Position";

    public static final String HOIST1_POSITION = "Hoist1Position";
    public static final String HOIST2_POSITION = "Hoist2Position";

    public static final String GANTRY_POSITION = "GantryPosition";
    public static final String STATE_L = "L";
    public static final String STATE_U = "U";
    public static final String STATE_LOCK = "LOCK";
    public static final String STATE_UNLOCK = "UNLOCK";

    public static final String T1_POSITION_UNLOCK = "T1PositionUnlock";
    public static final String T2_POSITION_UNLOCK = "T2PositionUnlock";

    public static final String H1_POSITION_UNLOCK = "H1PositionUnlock";
    public static final String H2_POSITION_UNLOCK = "H2PositionUnlock";

    public static final String GANTRY_UNLOCK = "GantryUnlock";

    public static final String TWENTYSINGLE = "TWENTYSINGLE";
    public static final String FORTYSINGLE = "FORTYSINGLE";
    public static final String TWIN = "TWIN";
    public static final String TANDEM = "TANDEM";
    public static final String SINGLE = "SINGLE";

    public static final String DSCH = "DSCH";
    public static final String LOAD = "LOAD";

    public static final String LOCK = "L";
    public static final String UNLOCK = "U";

    public static final String PORT_SIDE = "P";
    public static final String STAR_BORD_SIDE = "S";
}
