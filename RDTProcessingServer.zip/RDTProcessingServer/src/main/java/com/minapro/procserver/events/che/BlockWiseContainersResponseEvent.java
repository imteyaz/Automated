package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * Holds the block wise container details.
 * 
 * @author UmaMahesh M
 *
 */
public class BlockWiseContainersResponseEvent extends Event implements Serializable {

	private static final long serialVersionUID = -6722346518397228078L;

	private String blockID;

	private String stackNumber;

	private List<YardProfileContainer> containers;




	/*
	 * Parameter is used to distinguish the difference between which data source ESB needs to connect.
	 * isPollingTimeReq =true means , second request on words ESB has to connect OPUS database to get the updated containers information. 
	 * False means ,it is a first time request posting to ESB, in this case ESB has to connect PROMIS Database.
	 */
	private boolean isPollingTimeReq;

	public boolean isPollingTimeReq() {
		return isPollingTimeReq;
	}


	public void setPollingTimeReq(boolean isPollingTimeReq) {
		this.isPollingTimeReq = isPollingTimeReq;
	}

	public String getBlockID() {
		return blockID;
	}

	public void setBlockID(String blockID) {
		this.blockID = blockID;
	}

	public String getStackNumber() {
		return stackNumber;
	}

	public void setStackNumber(String stackNumber) {
		this.stackNumber = stackNumber;
	}

	public List<YardProfileContainer> getContainers() {
		return containers;
	}

	public void setContainers(List<YardProfileContainer> containers) {
		this.containers = containers;
	}   

	
	@Override
	public String toString() {
		return "BlockWiseContainersResponseEvent [blockID=" + blockID
				+ ", stackNumber=" + stackNumber + ", isPollingTimeReq="
				+ isPollingTimeReq +  "]";
	}
}
