package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;
/**
 * 
 * @author 1103222
 *
 */
public class ShuffleResponseEvent extends Event implements Serializable {

	private static final long serialVersionUID = 5465914561298282957L;
	
	private String containerId;
	
	private String location;
	
	private String moveType;
	
    private boolean isJobListRefreshRequired;
    /**
	 * Indicates whether the request was successful or not
	 */
	private boolean isSuccess;

	/**
	 * Will be filled with the error message in case failure
	 */
	private String errorMessage;

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public String getLocation() {
		return location;
	}

	public boolean isJobListRefreshRequired() {
		return isJobListRefreshRequired;
	}

	public void setJobListRefreshRequired(boolean isJobListRefreshRequired) {
		this.isJobListRefreshRequired = isJobListRefreshRequired;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "ShuffleResponseEvent [containerId=" + containerId
				+ ", location=" + location + ", moveType=" + moveType
				+ ", isJobListRefreshRequired=" + isJobListRefreshRequired
				+ ", isSuccess=" + isSuccess + ", errorMessage=" + errorMessage
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getTerminalID()=" + getTerminalID()
				+ ", getEventID()=" + getEventID() + ", geEventType()="
				+ geEventType() + "]";
	}



	

   
}
