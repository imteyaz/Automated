package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ITVWaitingTimeEntity;
import com.minapro.procserver.db.ITVWaitingTimePK;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
/**
 * Class is responsible for calculating the ITV waiting time at che equipment.
 * Which is used to calculate the che sequence number.
 * @author UmaMahesh
 *
 */
public class ITVWaitingTimeCalculatorService implements Serializable{

	private static final long serialVersionUID = 1L;
	private static final ITVWaitingTimeCalculatorService INSTANCE = new ITVWaitingTimeCalculatorService();
	private static final MinaProApplicationLogger LOGGER  = new MinaProApplicationLogger(ITVWaitingTimeCalculatorService.class);
	
	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.TERMINAL_KEY);
	
	private ITVWaitingTimeCalculatorService(){		
	}	
	
	public static ITVWaitingTimeCalculatorService getInstance(){
		return INSTANCE;
	}	
	
	/**
	 * Method is responsible for Persist the current ITV arrived time in database.
	 * Business Logic::Main Idea behind storing ITV Arrived time at CHE Equipment is to calculate the ITV Waiting time at CHE Equipment.
	 * Retrieving This information at the time of CHE Job Sequnce Calculation.
	 * @param itvArrivalEvent
	 * logger.logMsg(LOG_LEVEL.INFO,itvArrivalEvent.getUserID(),new StringBuilder().toString());
	 */
	public static void persistITVArrivedTime(ITVArrivalEvent itvArrivalEvent){
		
		LOGGER.logMsg(LOG_LEVEL.INFO,itvArrivalEvent.getUserID(),new StringBuilder("Stared persistITVArrivedTime()").
				append(" Event:").append(itvArrivalEvent.toString()).toString());
		
		List<String> containerIds = itvArrivalEvent.getContainerIDs();
	
	try{
		
		for(String containerId : containerIds) {

			if(itvArrivalEvent.getEquipmentID()!=null && itvArrivalEvent.getBlockId()!=null && (containerId!=null && !containerId.isEmpty())) {

				ITVWaitingTimeEntity itvEntity  = new ITVWaitingTimeEntity() ; 
				ITVWaitingTimePK itvPrimaryKey = new ITVWaitingTimePK();

				itvEntity.setArrivalTime(new Date());
				itvEntity.setIsJobCompleted("N");


				itvPrimaryKey.setITVNo(itvArrivalEvent.getEquipmentID());
				itvPrimaryKey.setBlockId(itvArrivalEvent.getBlockId());
				itvPrimaryKey.setContainerId(containerId.split("\\^")[0]);

				itvEntity.setprimaryKey(itvPrimaryKey);

				HibernateUtil.saveData(itvEntity);
			} else {
				LOGGER.logMsg(LOG_LEVEL.ERROR,itvArrivalEvent.getUserID()," One Of The Primary Keys Value Is Null..Ignore Insert");
			}

		} 
	}catch(RuntimeException ex){
		LOGGER.logException(" Exception Occured While Persisting Records Into The ITV_waiting_time table::",ex);
	}
	}
	/**
	 * Method is used to update the ITV arrived time record with JobCCompleted = 'Y' and Job Completion time for further reference.
	 * @param containerId
	 * @param itvNo
	 * @param blockNumber
	 */
	public static void updateArrivedITVSRecord(List<String> containerList , String itvNo , String blockLocation){

		LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("Started updateArrivedITVSRecord() Parms").append(" Container Id:::").
				append(containerList).append("ITV Number::").append(itvNo).append("CHE Block Location::").
				append(blockLocation).toString());
		try{
			
			String blockNumber  = 	blockLocation.split("\\.")[0];

			for(String containerId : containerList){

				List<ITVWaitingTimeEntity> existedITVArrivedEntityList = 
						retrieveArrivedITVSRecords(containerId,itvNo,blockNumber,"N");

				for(ITVWaitingTimeEntity existedEntity : existedITVArrivedEntityList){

					existedEntity.setIsJobCompleted("Y");
					existedEntity.setJobCompletedTime(new Date());
					HibernateUtil.updateData(existedEntity);
				}

			}
		}catch(RuntimeException ex){
			LOGGER.logException(" Exception Occured While Updating Records Into The ITV_waiting_time table::",ex);
		}

	}
	/*
	 * retrieve existed record for the current itv with status isJobCompleted = 'N' in case  of retrieving all latest records.
	 * Method is useful at the time of sequence calculation.Retrieving all records with status N  
	 */
	@SuppressWarnings("unchecked")
	public static List<ITVWaitingTimeEntity> retrieveArrivedITVSRecords(String containerId , String itvNo,
			String blockId,String isJobCompleted){
		
		LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Started retriveArrivedITVSRecords()").append(" Container Id:::").
				append(containerId).append("ITV Number::").append(itvNo).append("CHE Block Id").append(blockId).toString());
		
		Session session  = null ;
		Transaction tx = null;
		List<ITVWaitingTimeEntity> waitingItvs = null;
		
		try{
			session = HibernateUtil.getSessionFactory().getCurrentSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(ITVWaitingTimeEntity.class.getName());
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			
			if(containerId!=null && itvNo!=null && blockId!=null){
				criteria.add(Restrictions.eq("primaryKey.containerId", containerId))
				.add(Restrictions.eq("primaryKey.itvNo", itvNo))
				.add(Restrictions.eq("primaryKey.blockId",blockId));
				
			} 
			
			criteria.add(Restrictions.eq("isJobCompleted", isJobCompleted))
			.add(Restrictions.gt("arrivalTime",new Date(System.currentTimeMillis()-(1*60*60*1000))));
			
			waitingItvs = criteria.list();
			tx.commit();
		
			
		}catch(Exception ex){
			LOGGER.logException(" Exception Occured While Retrieving Records From ITVWaitingTimeEntity Reasn::",ex);
		}
		return waitingItvs;
	}
	
	public static Map<String,List<ITVWaitingTimeEntity>> separateArrivedITVSUserWise(List<Object[]> arrivedITVSList){
		
		Map<String, List<ITVWaitingTimeEntity>> userWiseArrivedITVSMap = new HashMap<String,List<ITVWaitingTimeEntity>>();
		
		try {
			for(Object[] arrivedITV : arrivedITVSList) {

				List<ITVWaitingTimeEntity> itvEntityList = userWiseArrivedITVSMap.get(arrivedITV[0].toString());

				if(itvEntityList==null) {
					itvEntityList = new ArrayList<ITVWaitingTimeEntity>();
				}
				ITVWaitingTimeEntity itvObj = prepareITVWaitingEntity(arrivedITV);
				
				if(itvObj==null){
					continue;
				} else {
					itvEntityList.add(prepareITVWaitingEntity(arrivedITV));
					userWiseArrivedITVSMap.put(arrivedITV[0].toString(), itvEntityList);
				}
			}
			LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" User Wise Seperated Arrived ITVS Map Data ::").append(userWiseArrivedITVSMap).toString());
		} catch (Exception ex) {
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Seperating ITVS User Wise")
					.append(REASON).toString(), ex);
		}
		return userWiseArrivedITVSMap;
}

	public static ITVWaitingTimeEntity prepareITVWaitingEntity(Object[] arrivedITV){
		
		ITVWaitingTimeEntity itvEntity  = new ITVWaitingTimeEntity() ; 
		ITVWaitingTimePK itvPrimaryKey = new ITVWaitingTimePK();
		
		Date arrivedDate;
		
		try {
			
			arrivedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(arrivedITV[2].toString());
			itvEntity.setArrivalTime(arrivedDate);
			itvEntity.setIsJobCompleted("N");

			itvPrimaryKey.setITVNo(arrivedITV[4].toString());
			itvPrimaryKey.setBlockId(arrivedITV[3].toString());
			itvPrimaryKey.setContainerId(arrivedITV[1].toString());

			itvEntity.setprimaryKey(itvPrimaryKey);
			
			if(isCurrentITVHoldingSameCntr(itvEntity)){
				return itvEntity;
			}else {
				/*
				 * Current ITV Is Not Holding The Earlier Container,Remove Entry From DB And Send Notification To Corresponding user.
				 */
				LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("Current ITV Entity::").append(itvEntity).
						append(" Remove From DB And Send Notif To user").toString());
				removeAndSendNotifToUI(itvEntity,arrivedITV[0].toString());
				return null;
			}
		} catch (Exception ex) {
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Preparing ITV Entity ")
					.append(REASON).toString(), ex);
			return null;
		}
	
}

	
	private static void removeAndSendNotifToUI(ITVWaitingTimeEntity itvEntity,String userId) {
	
		//Step 1 : Remove Record From Database
		HibernateUtil.deleteData(itvEntity);
		
		//Step 2 : Job Sequence Number Will Be Changed Due To Above Step , Needs To Update Corresponding User JobList.
		LOGGER.logMsg(LOG_LEVEL.INFO,userId," Initiating JobList Request Event Manually For User:::".concat(userId));
		
		CHEJobListRequestEvent requestEvent = new CHEJobListRequestEvent();
        requestEvent.setUserID(userId);
        requestEvent.setTerminalID(TERMINAL_ID);
        requestEvent.setEventID(UUID.randomUUID().toString());
        requestEvent.setScheduled(true);

        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(userId);
        requestEvent.setEquipmentID(allocationDetails.getEquipmentID());
        requestEvent.setLocation(allocationDetails.getLocation());
     
        User user = RDTCacheManager.getInstance().getUserDetails(userId);
        
        if (user != null) {
            requestEvent.setPassword(user.getPassword());
        }

        ESBQueueManager.getInstance().postMessage(requestEvent,RDTCacheManager.getInstance().getUserLoggedInRole(userId), requestEvent.getTerminalID());
    
		
         
		
	}

	private static boolean isCurrentITVHoldingSameCntr(ITVWaitingTimeEntity itvEntity) {

		String itemSeparator = DeviceCommParameters.getInstance().getCommParameter(
				ITEM_SEPERATOR_KEY);

		String currentInstructions = RDTCacheManager.getInstance().getCurrentITVInstructions(itvEntity.getprimaryKey().getITVNo());
		
		try {
			
			if(currentInstructions != null){
				
				LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Current ITV::").append(itvEntity.getprimaryKey().getITVNo()).
						append(" Conrainer Details In Cache Is::").append(currentInstructions).append(" Current ITV Holding Container No Is:::").
						append(itvEntity.getprimaryKey().getContainerId()).toString());

				String[] splitted = currentInstructions.toString().split("\\" + DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY));
				String[] fetchContainers = splitted[3].split("\\"+ DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY));

				for(String fetchContr : fetchContainers) {
					
					LOGGER.logMsg(LOG_LEVEL.INFO,""," Current Fetch Container From Cache Is::"+fetchContr.split("\\"+itemSeparator)[0]);
					
					if(fetchContr.split("\\"+itemSeparator)[0].equalsIgnoreCase(itvEntity.getprimaryKey().getContainerId())) {
						return true;
					}
				}
			} 
		} catch(Exception ex){
			LOGGER.logException("Caught exception while trying to remove fetch containers", ex);
		}

		return false;
	}

	public static Map<String, List<ITVWaitingTimeEntity>> getUserWiseArrivedITVS(){
		List<Object[]> arrivedITVSList = CHEJobListDAO.getInstance().getArrivedITVSDetailsAtBlock("N");
		return (arrivedITVSList!=null && !arrivedITVSList.isEmpty()) ?  separateArrivedITVSUserWise(arrivedITVSList) 
				: null ; 
		
	}
	
	
	
	
}
