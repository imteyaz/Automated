package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ShiftDetails;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.CompletedJobListRequestEvent;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor class responsible for handling the completed job list request from UI. All the jobs which has been performed by
 * the operator for the logged in equipment and rotation will be sent back as the response.
 * 
 * @author Rosemary George
 *
 */
public class CompletedJobListActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CompletedJobListActor.class);
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd.MM.yyyy HH:mm");
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);

    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof CompletedJobListRequestEvent) {
            CompletedJobListRequestEvent completedJobRequest = (CompletedJobListRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, completedJobRequest.getUserID(),
                    "Received completed job list request event -" + completedJobRequest);

            try {
                String rotationId  = "";
                String userId      = completedJobRequest.getUserID();
                String equipmentId =completedJobRequest.getEquipmentID();
                ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                        .getAllocationDetails(userId);
                if (allocation != null) {
                    rotationId = allocation.getRotationID();
                }

                /*
                 * Bug 125970 - Send only the user's completed job in case of equipment operator, all other roles, send
                 * the equipments completed jobs.
                 */
                Map<String, CompletedContainerMoves> completedJobs;
                OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
                if (role.equals(OPERATOR.QC)) {
                    completedJobs = RDTCacheManager.getInstance().getCompletedJobsForUser(
                            userId, rotationId, equipmentId);
                } else if(role.equals(OPERATOR.CHE)) {
                	/*Following Condition is added by UmaMahesh.To Maintain Synch between Completed Jobs Filter data and CompletedJobs
                	 Count When sending Performance Parameters. */
                	completedJobs = setCompletedJobsForCHEUser(rotationId,userId,equipmentId);
            	}else {                   
                    if (role.equals(OPERATOR.HC)) {
                        equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                                userId);
                    }
                    completedJobs = RDTCacheManager.getInstance().getCompletedJobs(rotationId, equipmentId);
                }

                if (completedJobs != null) {
                    sendCompletedJobsToDevice(completedJobRequest,
                            new ArrayList<CompletedContainerMoves>(completedJobs.values()));
                } else {
                    sendEmptyResponse(completedJobRequest);
                }
            } catch (Exception ex) {
                logger.logException("Caught exception while handling completed job list request", ex);
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * Sends an empty response back to device as there is no completed jobs for the user with the current logged in
     * equipment and rotation.
     * 
     * @param completedJobRequest
     */
    private void sendEmptyResponse(CompletedJobListRequestEvent completedJobRequest) {
        logger.logMsg(LOG_LEVEL.INFO, completedJobRequest.getUserID(), "No completed jobs to send to device");

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.COMPLETED_JOB_LIST_RESP);
        
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPARATOR).append(eventTypeID);
        
        responseToDevice.append(VALUE_SEPARATOR).append(completedJobRequest.getEventID()).append(VALUE_SEPARATOR)
                .append(VALUE_SEPARATOR).append(completedJobRequest.getUserID()).append(VALUE_SEPARATOR)
                .append(completedJobRequest.getTerminalID());

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(completedJobRequest.getUserID());
        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                completedJobRequest.getTerminalID());
    }

    /**
     * Construct and sends the completed jobs to device
     * 
     * @param completedJobRequest
     * @param completedJobs
     */
    private void sendCompletedJobsToDevice(CompletedJobListRequestEvent completedJobRequest,
            List<CompletedContainerMoves> completedJobs) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.COMPLETED_JOB_LIST_RESP);

        // get the job list message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(
                RDTProcessingServerConstants.COMPLETED_JOB_LIST_RESP);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP).append(VALUE_SEPARATOR).append(eventTypeID);
       
        String msgField;

        String explosiveCodes = EventUtil.getInstance().getExplosiveCodes();
        
        // iterate through the jobList message formats
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            msgField = msgFields.get(i);

            // in case of Jobs fields, its time to iterate through the containers
            if ("Jobs".equalsIgnoreCase(msgField)) {
                // Iterate till the size of the container list
                for (int j = 0; j < completedJobs.size(); j++) {
                    CompletedContainerMoves completedMove = completedJobs.get(j);

                    responseToDevice.append(completedMove.getMoveType()).append(ITEM_SEPARATOR)
                            .append(completedMove.getContainerId()).append(ITEM_SEPARATOR)
                            .append(completedMove.getIsoCode()).append(ITEM_SEPARATOR).append(completedMove.getPod())
                            .append(ITEM_SEPARATOR).append(completedMove.getWeight()).append(ITEM_SEPARATOR)
                            .append(completedMove.getFromLocation()).append(ITEM_SEPARATOR)
                            .append(completedMove.getToLocation()).append(ITEM_SEPARATOR)
                            .append(completedMove.getRemarks()).append(ITEM_SEPARATOR)
                            .append(completedMove.getReferenceContainers()).append(ITEM_SEPARATOR);
                    if (completedMove.getPod() != null) {
                        responseToDevice.append(RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
                                completedMove.getPod()));
                    } else {
                        responseToDevice.append("");
                    }
                    responseToDevice.append(ITEM_SEPARATOR).append(completedMove.getCategory()).append(ITEM_SEPARATOR)
                            .append(completedMove.getIsEmpty()).append(ITEM_SEPARATOR);

                    // If the exception is cleared, don't send it as exception
                    if ("Y".equals(completedMove.getExceptionResolved())) {
                        responseToDevice.append("N").append(ITEM_SEPARATOR);
                    } else {
                        responseToDevice.append(completedMove.getExceptionOccured()).append(ITEM_SEPARATOR);
                        if (completedMove.getExceptionReason() != null && !completedMove.getExceptionReason().isEmpty()) {
                            responseToDevice.append(completedMove.getExceptionReason());
                        }
                    }

                    responseToDevice.append(ITEM_SEPARATOR).append(completedMove.getIsSealOk()).append(ITEM_SEPARATOR);
                    
                    Container container = RDTCacheManager.getInstance().getContainerDetails(completedMove.getContainerId(), completedMove.getContainerId());
                    if(container != null){
                        responseToDevice.append(container.getIsDamaged());
                    }else{
                    	responseToDevice.append(completedMove.isDamaged());
                    }
                    responseToDevice.append(ITEM_SEPARATOR).append(completedMove.getDoorDirection()).append(ITEM_SEPARATOR);
                    
                    if(explosiveCodes != null && completedMove.getHazardousCode()!= null){
                        responseToDevice.append(EventUtil.getInstance()
								.isExplosiveContainer(explosiveCodes, completedMove.getHazardousCode()));
                    }else {
                        responseToDevice.append(false); 
                    }
                    responseToDevice.append(ITEM_SEPARATOR).append(completedMove.getPosition()).append(ROW_SEPARATOR);
                }
            } else {
                EventUtil.getInstance().getEventParameter(completedJobRequest, msgField, responseToDevice);
            }
        }

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(completedJobRequest.getUserID());
        // send the batch message
        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                completedJobRequest.getTerminalID());
    }
    /**
     * Method is responsible for retrieving CHE Equipment Logged in User Completed Jobs Based On Shift Start Time And ShiftEndTime,
     * UserId and EquipmentId And Setting data into cache.
     * 
     * @param rotationId
     * @param userId
     * @param equipmentId
     * @throws SQLException
     * @throws NullPointerException
     */
    
    public Map<String, CompletedContainerMoves> setCompletedJobsForCHEUser(final String rotationId , final String userId, 
            final String equipmentId){
    	
    /*
     * Step 1: Retrieve shift data for the current logged in user . If shift data not available in database then 
     * ShiftStart time as user logged in time and Shift End Time As The Current time(sysdate)
     */
    	logger.logMsg(LOG_LEVEL.INFO,userId," Started setCompletedJobsForCHEUser()");
    	
    	Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);    	
    	Map<String, CompletedContainerMoves> completedJobs = null;
		Date shiftStartDate, shiftEndDate;
		
		ShiftDetails shiftData = HibernateUtil.getShiftDataforLoggedInuser(loginTime, new Date(), userId);		
		if (shiftData != null) {			
			logger.logMsg(LOG_LEVEL.INFO, userId,new StringBuilder(" Shift Details For Current User::").
					append(shiftData.toString()).toString());
			
			shiftStartDate = shiftData.getShiftStartDate();
			shiftEndDate = shiftData.getShiftEndDate();
		} else {			
			logger.logMsg(LOG_LEVEL.INFO,userId," Shift details not available , Considering Login Time As ShifStart Time..");
			shiftStartDate = loginTime;
			shiftEndDate = new Date();
		}

		String shifStartTime = DATE_FORMATTER.format(shiftStartDate);
		String shifEndTime = DATE_FORMATTER.format(shiftEndDate);

		logger.logMsg(LOG_LEVEL.INFO, userId, "Shift Start Time :" + shifStartTime);
		logger.logMsg(LOG_LEVEL.INFO, userId, "Shift End Time :" + shifEndTime);
		
		//Step 2 : Retrieve Completed Jobs For Logged in user based on Shift start time ,end time, equipmentId,User Id.
		
		User user = RDTCacheManager.getInstance().getUserDetails(userId);		
		List<CompletedContainerMoves> cheUserCompletedJobs = HibernateUtil.getCompletedJobsByUserforThisShift(user, equipmentId,
				shifStartTime, shifEndTime);
		
		//Step 3 : Flush Out Previously completed jobs from Cache	
		RDTCacheManager.getInstance().removeUserCompletedJobs(rotationId.concat(equipmentId));
	
		//Step 4: Add Completed Jobs To Cache for Current User And Equipment.		
		if(cheUserCompletedJobs!=null && !cheUserCompletedJobs.isEmpty()) {
			completedJobs = new HashMap<String, CompletedContainerMoves>();
			for(CompletedContainerMoves container : cheUserCompletedJobs) {
				RDTCacheManager.getInstance().addToCompletedJobs(container, userId, rotationId, equipmentId);
				completedJobs.put(container.getContainerId(), container);
			}			
		} else {
			logger.logMsg(LOG_LEVEL.INFO,userId," Completed Jobs Are Not Available In DataBase For Current Shift Time");
		}
		
		return completedJobs;
    }
}
