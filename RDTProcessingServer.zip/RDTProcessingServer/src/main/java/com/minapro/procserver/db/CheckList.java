package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding the check list items
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_CHECKLIST_MASTER")
public class CheckList extends Audit implements Serializable {

    private static final long serialVersionUID = -6545070980022061109L;

    @Id
    @GeneratedValue
    @Column(name = "CHECKLIST_ID", nullable = false)
    private int checklistId;

    @Column(name = "CHECKLIST_NAME")
    private String checklistName;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "ICON")
    private String icon;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "MANDATORY")
    private String mandatory;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CHECKLIST_HDR_ID", nullable = false)
    private CheckListHeader checkListHeader;

    public CheckListHeader getCheckListHeader() {
        return checkListHeader;
    }

    public void setCheckListHeader(CheckListHeader checkListHeader) {
        this.checkListHeader = checkListHeader;
    }

    public String getMandatory() {
        return mandatory;
    }

    public void setMandatory(String mandatory) {
        this.mandatory = mandatory;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getChecklistId() {
        return checklistId;
    }

    public void setChecklistId(int checklistId) {
        this.checklistId = checklistId;
    }

    public String getChecklistName() {
        return checklistName;
    }

    public void setChecklistName(String checklistName) {
        this.checklistName = checklistName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
