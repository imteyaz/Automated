package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the CHEContainer Detection event details
 * 
 * @author Kumaraswamy
 *
 */

public class CHEContainerDetectionEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6886259447423103109L;

    private String node;
    private String userId;
    private String spreaderId;
    private String yardPosition;
    private String laneId;
	private float weight;
	private int size;
	
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	
    public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

    
    
    public String getLaneId() {
		return laneId;
	}

	public void setLaneId(String laneId) {
		this.laneId = laneId;
	}

	public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSpreaderId() {
        return spreaderId;
    }

    public void setSpreaderId(String spreaderId) {
        this.spreaderId = spreaderId;
    }

    public String getYardPosition() {
        return yardPosition;
    }

    public void setYardPosition(String yardPosition) {
        this.yardPosition = yardPosition;
    }

	@Override
	public String toString() {
		return "CHEContainerDetectionEvent [node=" + node + ", userId="
				+ userId + ", spreaderId=" + spreaderId + ", yardPosition="
				+ yardPosition + ", laneId=" + laneId + "]";
	}
   
}
