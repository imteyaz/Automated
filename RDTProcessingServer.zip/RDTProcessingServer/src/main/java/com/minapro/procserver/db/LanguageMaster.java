package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_LANGUAGES_MASTER")
public class LanguageMaster implements Serializable {

    private static final long serialVersionUID = 6604872489736638391L;

    @Id
    @Column(name = "LANGUAGE_NAME", unique = true, nullable = false, length = 25)
    private String languageName;

    @Column(name = "LANGUAGE_CODE", length = 20)
    private String languageCode;

    public String getLanguageName() {
        return this.languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }

    public void setLanguageCode(String langiageCode) {
        this.languageCode = langiageCode;
    }
}
