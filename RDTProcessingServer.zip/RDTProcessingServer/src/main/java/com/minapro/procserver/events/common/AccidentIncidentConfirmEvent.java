package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details of Accident/Incident reported by the device
 * @author Rosemary George
 *
 */
public class AccidentIncidentConfirmEvent extends Event implements Serializable{

	private static final long serialVersionUID = -1918637174253340142L;

	/**
	 * Indicates the QC for which the accident/Incident has been reported
	 */
	private String qcId;
	
	/**
	 * Indicates whether the QC can continue work or not. If not, a manual open delay will be created for the QC.
	 */
	private boolean canContinueWork;
	
	private boolean createDelay;
	
	private String delayCode;
	
	public boolean isCreateDelay() {
		return createDelay;
	}

	public void setCreateDelay(String createDelay) {
		this.createDelay = "T".equalsIgnoreCase(createDelay)? true :false;
	}

	public String getDelayCode() {
		return delayCode;
	}

	public void setDelayCode(String delayCode) {
		this.delayCode = delayCode;
	}

	public String getQcId() {
		return qcId;
	}

	public void setQcId(String qcId) {
		this.qcId = qcId;
	}

	public boolean canContinueWork() {
		return canContinueWork;
	}

	public void setCanContinueWork(String canContinueWork) {
		this.canContinueWork = (canContinueWork!=null && "true".equals(canContinueWork))?true:false;
	}

	@Override
	public String toString() {
		return "AccidentIncidentConfirmEvent [qcId=" + qcId + ", canContinueWork=" + canContinueWork + ", createDelay="
				+ createDelay + ", delayCode=" + delayCode + ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}	
}
