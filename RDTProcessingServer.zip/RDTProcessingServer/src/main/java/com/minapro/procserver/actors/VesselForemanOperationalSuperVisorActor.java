package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.obf.LashersActor;
import com.minapro.procserver.actors.obf.VesselDocumentActor;
import com.minapro.procserver.actors.obf.VesselForemanCheckListActor;
import com.minapro.procserver.actors.obf.VesselForemanNotifActor;
import com.minapro.procserver.actors.obf.VfOperationalViewActor;
import com.minapro.procserver.actors.obf.ViewPlanActor;
import com.minapro.procserver.events.obf.BayRowChangeNotifEvent;
import com.minapro.procserver.events.obf.LashersRequestEvent;
import com.minapro.procserver.events.obf.VesselForemanCheckListEvent;
import com.minapro.procserver.events.obf.VfOperatoinalViewEvent;
import com.minapro.procserver.events.obf.ViewPlanEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;

/**
 * 
 * Actor responsible for supervising the Vessel Foreman operations.
 * 
 * @author Prasad.Tallapally
 *
 */
public class VesselForemanOperationalSuperVisorActor extends UntypedActor {

    private ActorRef vfOperationalViewActor = getContext().actorOf(
            Props.create(VfOperationalViewActor.class).withRouter(new FromConfig()), "vfOperationalview");
    private ActorRef vesselForemanNotifActor = getContext().actorOf(
            Props.create(VesselForemanNotifActor.class).withRouter(new FromConfig()), "vesselForemanNotifOperation");
    private ActorRef vesselForemanCheckListActor = getContext().actorOf(
            Props.create(VesselForemanCheckListActor.class).withRouter(new FromConfig()),
            "vesselForemanCheckListOperation");
    private ActorRef viewPlanActor = getContext().actorOf(
            Props.create(ViewPlanActor.class).withRouter(new FromConfig()), "viewPlanOperation");
    private ActorRef lashersActor = getContext().actorOf(Props.create(LashersActor.class).withRouter(new FromConfig()),
            "getLashersRequest");
    private ActorRef vesselDocumentActor = getContext().actorOf(
            Props.create(VesselDocumentActor.class).withRouter(new FromConfig()), "vesselDocumentOperation");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {
                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    // LASHERS_REQUEST
    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof VfOperatoinalViewEvent) {
            vfOperationalViewActor.tell(message, getSelf());
        } else if (message instanceof PerformanceEvent) {
            vesselForemanNotifActor.tell(message, getSelf());
        } else if (message instanceof BayRowChangeNotifEvent) {
            vesselForemanNotifActor.tell(message, getSelf());
        } else if (message instanceof VesselForemanCheckListEvent) {
            vesselForemanCheckListActor.tell(message, getSelf());
        } else if (message instanceof ViewPlanEvent) {
            viewPlanActor.tell(message, getSelf());
        } else if (message instanceof LashersRequestEvent) {
            lashersActor.tell(message, getSelf());
        } else if (message instanceof VesselDocumentActor) {
            vesselDocumentActor.tell(message, getSelf());
        } else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, null);
        }
    }
}
