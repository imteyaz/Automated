package com.minapro.procserver.events;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p> Base class for all messages/events that will be processed in MinaPro. </p> <p> Contains all the common
 * parameters. </p>
 * 
 * @author Rosemary George
 *
 */
public class Event implements Serializable {
    private static final long serialVersionUID = 3911560932305541737L;

    /**
     * format from Device is - Tuesday 25-Nov-2014 17:47:27
     */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

    /**
     * Specifies the terminal ID - can be 1, 2 or 3.
     */
    private String terminalID;

    /**
     * Indicates the time the request originated at device
     */
    private Date timeStamp;
    /**
     * Unique identifier for each request, same will be provided back in the response
     */
    private String eventID;
    /**
     * Identifier for the different kinds of request or response type.
     */
    private String eventType;
    /**
     * Equipment where the event originated in case of request or to be sent in case of response
     */
    private String equipmentID;
    /**
     * The user who generated this event in case of request Or to whom the event needs to be sent in case of response
     */
    private String userID;

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public String getTerminalID() {
        return terminalID;
    }

    public void setTerminalID(String terminalID) {
        this.terminalID = terminalID;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        try {
            this.timeStamp = DATE_FORMAT.parse(timeStamp);
        } catch (ParseException e) {
            this.timeStamp = new Date();
        }
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String geEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return "Event [terminalID=" + terminalID + ", timeStamp=" + timeStamp + ", eventID=" + eventID + ", eventType="
                + eventType + ", equipmentID=" + equipmentID + ", userID=" + userID + "]";
    }

}
