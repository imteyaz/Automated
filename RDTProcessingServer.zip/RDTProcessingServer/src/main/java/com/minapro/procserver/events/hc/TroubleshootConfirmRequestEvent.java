package com.minapro.procserver.events.hc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * Class responsible for holding TroubleShootRequest fields from User side
 * 
 * @author Umamahesh M
 *
 */
public class TroubleshootConfirmRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8022074172101274221L;

    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);
    private static final String COLOUMN_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            COLUMN_SEPERATOR_KEY);
    
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(TroubleshootConfirmRequestEvent.class);

    private List<TroubleShootDetails> tsDetails;

    private String moveType;

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public List<TroubleShootDetails> getTsDetails() {
        return tsDetails;
    }

    /**
     * Parses the tsDetails to extract each container troubleshoot details
     * containerId^tsCode1|tsCode2|tsCode3^TSArea^ITVId$containerId^tsCode1|tsCode2|tsCode3^TSArea^ITVId
     * 
     * @param tsDetails
     */
    public void setTsDetails(String tsDetails) {
        List<TroubleShootDetails> details = new ArrayList<TroubleShootDetails>();

        try {
            String[] tsList = tsDetails.split("\\" + COLOUMN_SEPERATOR);

            String[] eachTsDetails;
            TroubleShootDetails eachDetail;
            for (String tsRecord : tsList) {
                eachTsDetails = tsRecord.split("\\" + ITEM_SEPERATOR);
                eachDetail = new TroubleShootDetails();
                eachDetail.setContainerID(eachTsDetails[0]);
                eachDetail.setTroubleShootCodes(eachTsDetails[1].split("\\" + ROW_SEPERATOR));
                eachDetail.setItvId(eachTsDetails[2]);
                eachDetail.setTsAreaId(eachTsDetails[3]);

                details.add(eachDetail);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while setting Troubleshoot details Information:", ex);
        }

        this.tsDetails = details;
    }

    public void setTroubleShootDetails(List<TroubleShootDetails> tsDetails) {
        this.tsDetails = tsDetails;
    }

    @Override
    public String toString() {
        return "TroubleshootConfirmRequestEvent [tsDetails=" + tsDetails + ", moveType=" + moveType + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }
}
