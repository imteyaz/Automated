package com.minapro.procserver.actors.obf;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.obf.LashersRequestEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for getting lashers information based on following condition. Vessel Foreman should be able to
 * view all the Lashers allocated and their Login Status. If a Lashers is not marked as logged in, Vessel Foreman should
 * have an option to mark Login on behalf of a selected Lashing team member
 * 
 * @author UMAMAHESH M
 *
 */
public class LashersActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(LashersActor.class);

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof LashersRequestEvent) {
            LashersRequestEvent lasherReqEvent = new LashersRequestEvent();
            logger.logMsg(LOG_LEVEL.INFO, lasherReqEvent.getUserID(), "Received lashing request event:"
                    + lasherReqEvent);
        } else {
            unhandled(message);
        }

    }
}
