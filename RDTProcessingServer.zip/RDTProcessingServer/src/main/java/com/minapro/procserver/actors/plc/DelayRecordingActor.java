package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_RECORDING_BY_OPERATOR_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REASON_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.UserDelay;
import com.minapro.procserver.db.UserRole;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.plc.DelayRecordingByOperatorEvent;
import com.minapro.procserver.events.plc.DelayRecordingEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class DelayRecordingActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DelayRecordingActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    @Override
    /**
     * Handles Delay Recording event
     */
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass()).append(ON_RECEIVE).toString());

        if (message instanceof DelayRecordingEvent) {
            DelayRecordingEvent delayRecording = (DelayRecordingEvent) message;
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(delayRecording.getUserID());

            logger.logMsg(LOG_LEVEL.DEBUG, delayRecording.getUserID(), "Received Auto Delay Recoding event-"
                    + delayRecording + " for role =" + operatorRole);
            if(operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.CHE)){
            	
            	String rotationId = "";
                ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                        .getAllocationDetails(delayRecording.getUserID());
                if(allocation != null && allocation.getRotationID() != null){
                    rotationId = allocation.getRotationID();
                }
                
                //if open delay already exists, don't trigger auto delay
            	UserDelay openDelay = HibernateUtil.getOpenDelay(delayRecording.getEquipmentID(), rotationId);                
                if(openDelay != null){
                	logger.logMsg(LOG_LEVEL.WARN, delayRecording.getUserID(), "Already an open delay exists for the equipment - "
                            + openDelay);
                }else {
                	sendDelayRecordingEvent(delayRecording, operatorRole);
                }
            }
        } else if (message instanceof DelayRecordingByOperatorEvent) {
            DelayRecordingByOperatorEvent delayRecordByOprtr = (DelayRecordingByOperatorEvent) message;
            String eventType = DELAY_RECORDING_BY_OPERATOR_RESPONSE;
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
            StringBuilder qcsAndDelayReasonsMessage = new StringBuilder(RESP).append( VALUE_SEPARATOR).append( eventTypeID
                   ).append( VALUE_SEPARATOR);
            getQCsAndDelayReasonCodesAndSendResp(delayRecordByOprtr, qcsAndDelayReasonsMessage);
        } else {
            unhandled(message);
        }
    }

    /**
     * Sends auto delay prompt to the device with delay codes defined in the system with delay type as OPERATIONAL_DELAY.
     * If already an open delay exists for the equipment, ignores this auto delay prompt.
     * 
     * @param delayRecording
     * @param operator
     */
    private void sendDelayRecordingEvent(DelayRecordingEvent delayRecording, OPERATOR operator) {
        try {        	
            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(DELAY_RECORDING);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append( VALUE_SEPARATOR).append( delayRecording.geEventType());

            String field;
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(VALUE_SEPARATOR);
                field = msgFields.get(i);
                if (field.equals(REASON_CODE)) {
                    fillDelayReasonCodes(responseToDevice, operator);
                } else {
                    EventUtil.getInstance().getEventParameter(delayRecording, msgFields.get(i), responseToDevice);
                }
            }

            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                    delayRecording.getTerminalID());
        } catch (Exception ex) {
            logger.logException("CaughtException while sendingDelayRecordingEvent", ex);
        }
    }

    /**
     * <p>Retrieves the delay reason codes from cache and fills in the response to the device</p>
     * 
     * @param responseToDevice
     */
    private List<DelayReasonCode> fillDelayReasonCodes(StringBuilder responseToDevice, OPERATOR role) {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" fillDelayReasonCodes() ").append(INPUT)
                .append(responseToDevice).toString());
        
        List<DelayReasonCode> reasonCodes = null;
        try {
            if (role != null) {
                logger.logMsg(LOG_LEVEL.INFO, role.toString(), "The associated role id - " + role.toString());
                role = role.equals(OPERATOR.HC) ? OPERATOR.QC: role;
                reasonCodes = (List<DelayReasonCode>) HibernateUtil.getReasonCodes();

                logger.logMsg(LOG_LEVEL.INFO, "", "Size of List : " + reasonCodes.size());
                for (DelayReasonCode delayReason : reasonCodes) {
                	if(role.toString().equalsIgnoreCase(delayReason.getSubType())){
                		responseToDevice.append(delayReason.getDelaypk().getDelayReasonCodeID()).append(ITEM_SEPARATOR)
                            .append(delayReason.getDelayReasonDescription()).append(ROW_SEPARATOR);
                	}
                }
            }

            responseToDevice.append(VALUE_SEPARATOR);
            logger.logMsg(LOG_LEVEL.INFO, "", "After Delay Reason Codes Resp Msg " + responseToDevice.toString());

        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in fillDelayReasonCodes()")
                    .append(REASON).toString(), ex);
        }
        return reasonCodes;
    }

    /**
     * Method is responsible for getting Delay Reason Codes and QC operators based on logged in user,If current user is
     * HC,retrieve QC user id , If Logged in user is Foreman get all allocated four QCS. Send Final response to COMM
     * server with QCs and DelayCodes.
     * 
     * @param delayRecordOperator
     * @param responseToDevice
     */
    private void getQCsAndDelayReasonCodesAndSendResp(DelayRecordingByOperatorEvent delayRecordOperator,
            StringBuilder responseToDevice) {
        logger.logMsg(LOG_LEVEL.INFO, delayRecordOperator.getUserID(),
                new StringBuilder(ENTRY).append(" getQCsAndDelayReasonCodesAndSendResp() ").append(INPUT)
                        .append(responseToDevice).toString());

        RDTCacheManager cacheManager = RDTCacheManager.getInstance();

        String currentUserId = delayRecordOperator.getUserID();

        responseToDevice.append(delayRecordOperator.getEventID()).append(VALUE_SEPARATOR);

        String terminalId = delayRecordOperator.getTerminalID();
        try {
            OPERATOR operator = cacheManager.getUserLoggedInRole(currentUserId);
            UserRole role = RDTCacheManager.getInstance().getRole(operator.toString());

            String listOfQcs = delayRecordOperator.getEquipmentID();
            if (operator.equals(OPERATOR.HC)) {
                listOfQcs = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(currentUserId);
                responseToDevice.append(listOfQcs).append(VALUE_SEPARATOR);
            } else if (operator.equals(OPERATOR.FOREMAN)) {
                ConfirmAllocationEvent event = (ConfirmAllocationEvent) cacheManager
                        .getAllocationDetails(currentUserId);

                if (event == null) {
                    logger.logMsg(LOG_LEVEL.DEBUG, currentUserId,
                            "Unable TO Retrieve ListOfQC's From ConfirmAllocationEvent.");
                } else {
                    // Getting List Of QCs from ConfirmAllocationEvent POJO
                    listOfQcs = event.getLocation();
                }

                responseToDevice.append(listOfQcs).append(VALUE_SEPARATOR);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, currentUserId, "Current Logged In User Is Not Related To HC or Foreman");
            }

            List<DelayReasonCode> reasonCodes = fillDelayReasonCodes(responseToDevice, operator);

            logger.logMsg(LOG_LEVEL.INFO, currentUserId, "List of QCs -" + listOfQcs);
            StringBuilder openDelays = getOpenDelays(currentUserId, listOfQcs, role, reasonCodes);

            responseToDevice.append(openDelays.toString()).append(VALUE_SEPARATOR);
            responseToDevice.append(currentUserId).append(VALUE_SEPARATOR).append(terminalId);

            logger.logMsg(LOG_LEVEL.INFO, currentUserId,
                    new StringBuilder(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
                            .append(responseToDevice.toString()).toString());

            CommunicationServerQueueManager.getInstance()
                    .postMessage(responseToDevice.toString(), operator, terminalId);
        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in getQCsAndDelayReasonCodesAndSendResp()")
                            .append(REASON).toString(), ex);
        }
    }

    /**
     * Method is responsible for getting the open Delay Records for the current logged in equipment
     * 
     * @param userId
     * @author kalyani
     */
    private StringBuilder getOpenDelays(String userId, String listofQCs, UserRole role,  List<DelayReasonCode> reasonCodes) {
        StringBuilder delayCodes = new StringBuilder();

        RDTCacheManager cacheManager = RDTCacheManager.getInstance();
        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) cacheManager.getAllocationDetails(userId);

        String rotationId = "";
        if (allocation != null) {
            rotationId = allocation.getRotationID();
        }

        try {
            String[] qcList = listofQCs.split("\\" + ROW_SEPARATOR);
            logger.logMsg(LOG_LEVEL.INFO, listofQCs, "After splitting -" + qcList.length);
            for (String qc : qcList) {
                UserDelay delayCode = HibernateUtil.getOpenDelay(qc, rotationId);
                if (delayCode != null) {
                    logger.logMsg(LOG_LEVEL.INFO, rotationId + qc, "Available delay code is +" + delayCode); // rotation+eq
                    delayCodes.append(delayCode.getDealyCode()).append(ITEM_SEPARATOR)
                    	.append(EventUtil.getInstance().convertDateToString(delayCode.getdelayStartTime()))
                        .append(ITEM_SEPARATOR).append(delayCode.getEquipmentID()).append(ITEM_SEPARATOR)
                        .append(delayCode.getdelayId()).append(ITEM_SEPARATOR);
                        
                    if(reasonCodes != null){
                        for (DelayReasonCode delayReason : reasonCodes) {
                            if(delayCode.getDealyCode().equals(delayReason.getDelaypk().getDelayReasonCodeID())){
                                delayCodes.append(delayReason.getDelayReasonDescription());
                                break;
                            }
                        }
                    }
                } else {
                    logger.logMsg(LOG_LEVEL.INFO, userId, "No delay codes are present in the system ");
                }
                
                delayCodes.append(ROW_SEPARATOR);
            }
    
            if (delayCodes.length() > 2) {
                delayCodes.delete(delayCodes.length() - 1, delayCodes.length());
            }
        }catch(Exception ex){
            logger.logException("Caught exception while getting openDelays -", ex);
        }
        
        return delayCodes;
    }
}
