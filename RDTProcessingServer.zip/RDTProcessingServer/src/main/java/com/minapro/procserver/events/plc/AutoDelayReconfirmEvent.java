package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the auto delay re-confirmation message
 * 
 * @author Rosemary George
 *
 */
public class AutoDelayReconfirmEvent extends Event implements Serializable{

	private static final long serialVersionUID = 3295375656683484929L;

	/**
	 * Indicates whether existing delay needs to be closed or not
	 */
	private String closeDelay;
	
	/**
	 * holds the delay code selected by the user
	 */
	private String delayCode;

	public String getCloseDelay() {
		return closeDelay;
	}

	public void setCloseDelay(String closeDelay) {
		this.closeDelay = closeDelay;
	}

	public String getDelayCode() {
		return delayCode;
	}

	public void setDelayCode(String delayCode) {
		this.delayCode = delayCode;
	}

	@Override
	public String toString() {
		return "AutoDelayReconfirmEvent [closeDelay=" + closeDelay + ", delayCode=" + delayCode + ", getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}	
}
