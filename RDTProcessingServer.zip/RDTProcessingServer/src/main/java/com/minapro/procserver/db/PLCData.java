package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the PLC details
 * 
 * @author 3128828
 *
 */
@Entity
@Table(name = "MINAPRO_PLC_QC")
public class PLCData implements Serializable {

    private static final long serialVersionUID = -3148137700759150610L;

    @EmbeddedId
    private PlcPK plcpk;

    @Column(name = "TAG_VALUE")
    private double tagValue;

    public double getTagValue() {
        return tagValue;
    }

    public void setTagValue(double tagValue) {
        this.tagValue = tagValue;
    }

    public PlcPK getPlcpk() {
        return plcpk;
    }

    public void setPlcpk(PlcPK plcpk) {
        this.plcpk = plcpk;
    }

    @Override
    public String toString() {
        return "PLCData [plcpk=" + plcpk + ", tagValue=" + tagValue + "]";
    }

}
