package com.minapro.procserver.queue;

import java.util.concurrent.CountDownLatch;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Thread which configures the listeners for all the communicationServer related queues. </p>
 * 
 * <p> The queues are defined per terminal and operator role wise. For example, there will be one queue specifically
 * created for Terminal 1 ITV operator. All the requests coming from every ITV operator working in Terminal 1 will be
 * forwarded to this particular queue. </p>
 * 
 * @author Rosemary George
 *
 */
public class CommunicationServerListener implements Runnable {
    private static final Boolean NON_TRANSACTED = false;
    private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";

    private static final String DESTINATION_TERMINAL_ITV_OUT = "destination/itv_outQ";

    private static final String DESTINATION_TERMINAL_QC_OUT = "destination/qc_outQ";

    private static final String DESTINATION_TERMINAL_HC_OUT = "destination/hc_outQ";

    private static final String DESTINATION_TERMINAL_CHE_OUT = "destination/che_outQ";

    private static final String DESTINATION_TERMINAL_OBF_OUT = "destination/obf_outQ";

    private static final String DESTINATION_TERMINAL_TSC_OUT = "destination/tsc_outQ";

    private static final String DESTINATION_TERMINAL_ADMIN_NOTIF = "destination/admin_notif";

    private final CountDownLatch done = new CountDownLatch(1000);

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CommunicationServerListener.class);

    @Override
    /**
     * Configures the operator and terminal wise listeners for the communication server side queues
     */
    public void run() {
        Connection connection = null;
        Session session = null;
        try {
            logger.logMsg(LOG_LEVEL.INFO, "", "Configuring the Communication Server queue listeners");
            Context context = new InitialContext();
            ConnectionFactory factory = (ConnectionFactory) context.lookup(CONNECTION_FACTORY_NAME);

            connection = factory.createConnection();
            connection.start();

            session = connection.createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);

            // ITV Queue Listener
            Destination destination = (Destination) context.lookup(DESTINATION_TERMINAL_ITV_OUT);
            MessageConsumer consumer = session.createConsumer(destination);
            QueueEventListener qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            // QC Queue Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_QC_OUT);
            consumer = session.createConsumer(destination);
            qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            // HC Queue Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_HC_OUT);
            consumer = session.createConsumer(destination);
            qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            // CHE Queue Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_CHE_OUT);
            consumer = session.createConsumer(destination);
            qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            // OBF Queue Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_OBF_OUT);
            consumer = session.createConsumer(destination);
            qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            // Admin notification Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_ADMIN_NOTIF);
            consumer = session.createConsumer(destination);
            AdminNotificationListener listener = new AdminNotificationListener();
            consumer.setMessageListener(listener);

            // TSC Queue Listener
            destination = (Destination) context.lookup(DESTINATION_TERMINAL_TSC_OUT);
            consumer = session.createConsumer(destination);
            qListener = new QueueEventListener();
            consumer.setMessageListener(qListener);

            logger.logMsg(LOG_LEVEL.INFO, "", "Configuring the communication server queue listeners is complete");

            done.await();

        } catch (Exception e) {
            logger.logException("Caught exception while configuring Listeners - ", e);
        } finally {
            // got to clean up the connections and other resources!
            if (connection != null) {
                try {
                    if (session != null) {
                        session.close();
                    }
                    connection.close();
                } catch (JMSException e) {
                    logger.logException("Caught exception while closing the connection -", e);
                }
            }
        }
    }
}
