package com.minapro.procserver.actors.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_ARRIVED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.ITVWaitingTimeCalculatorService;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the ITV arrival event.</p>
 * 
 * <p>ITV arrival is forwarded to the ESB to inform respective DPW IT systems. Also other operators working on the
 * location specified in the ITVArrivalEvent are notified about the event.</p>
 * 
 * @author Rosemary George
 *
 */
public class ITVArrivalActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVArrivalActor.class);

	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

	@Override
	/**
	 * Handles only the messages of type ITVArrivalEvent
	 */
	public void onReceive(Object message) throws Exception {
		if (message instanceof ITVArrivalEvent) {
			ITVArrivalEvent event = (ITVArrivalEvent) message;

			// feed to ESPER --- For the time-being this feature is disabled
			RDTProcessingServer.getInstance().getEsperActor().tell(event, null);

			try {

				// In case of QC, we always get POW from ESB as a Location ID
				logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "LocationID is -" + event.getLocationID());

				// check if locationID is present in EquipmentList, it means QC
				if (RDTCacheManager.getInstance().getEquipmentDetails(event.getLocationID()) != null) {
					logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
							"ITV " + event.getEquipmentID() + " arrived at Quay side " + event.getLocationID()
									+ " with Container " + event.getContainerIDs());
					ESBQueueManager.getInstance().postMessage(event, OPERATOR.ITV, event.getTerminalID());
					sendMessageToStakeHolders(event);
				} else if (RDTCacheManager.getInstance().getPinningStationDetails(event.getLocationID()) != null) {
					// check if the locationID is matching with pinning station
					logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
							"ITV " + event.getEquipmentID() + " arrived at PinningStation " + event.getLocationID()
									+ " with Container " + event.getContainerIDs());
				} else {
					logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
							"ITV " + event.getEquipmentID() + " arrived at Yard " + event.getLocationID()
									+ " with Container " + event.getContainerIDs());

					if(event.getLocationID() != null && event.getLocationID().length() > 3){
						event.setBlockId(event.getLocationID().substring(0, 3));
					}
					logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
							"BlockID retrieved from Location :" + event.getBlockId());

					ESBQueueManager.getInstance().postMessage(event, OPERATOR.ITV, event.getTerminalID());					
					sendMessageToStakeHolders(event);
					
					/*
					 * Added by UmaMahesh For ITV Waiting Time Calculation.
					 */
					List<String> containerIds = event.getContainerIDs();
					
					if(containerIds!=null && !containerIds.isEmpty()) {
						
						if(!event.getLocationID().contains("FLD")) {
						logger.logMsg(LOG_LEVEL.INFO,event.getUserID(),new StringBuilder(" Container Ids are  present ").
								append("Calling DB Insert For ITV Waiting Time").toString());
						
						ITVWaitingTimeCalculatorService.persistITVArrivedTime(event);
						} 
					
					} else {
						logger.logMsg(LOG_LEVEL.INFO,event.getUserID(),new StringBuilder(" Container Ids are not present ").
								append("Ignore DB Insert For ITV Waiting Time").toString());
					}
					//Ended UmaMahesh code
				}

				// Add to ITV current location map
				RDTCacheManager.getInstance().setITVCurrentLocation(event.getEquipmentID(), event.getLocationID());
			} catch (Exception e) {
				logger.logException("Caught exception while processing ITVArrival -", e);
			}
		}
	}

	/**
	 * <p>Sends messages to the yard side/Quay side operators who are interested to know about the ITV arrival.</p>
	 * 
	 * <p>The ITVArrivalEvent contains the ID of the location where that particular ITV has reached. All users who are
	 * allocated to work on that particular location is retrieved from the cache and an ITV arrived event is sent to
	 * them with the ITV ID & Trailer ID.</p>
	 * 
	 * @param event
	 */
	private void sendMessageToStakeHolders(ITVArrivalEvent event) {

		Set<String> operators = RDTCacheManager.getInstance().getAllUsersAtLocation(event.getLocationID());

		List<String> containers = null;
		int noOfCntrs = 0;

		if (operators != null) {
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.ITV_ARRIVED);

			// get the message format
			List<String> msgFields = EventFormats.getInstance()
					.getEventFields(RDTProcessingServerConstants.ITV_ARRIVED);

			if (event.getContainerIDs() != null) {
				containers = event.getContainerIDs();
				noOfCntrs = containers.size();
			}

			StringBuilder responseToDevice;
			for (String operatorId : operators) {
				User user = RDTCacheManager.getInstance().getUserDetails(operatorId);

				// ignore the ITV user
				if (user.getUserID().equals(event.getUserID())) {
					continue;
				}

				// build the response to the device
				responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
				for (int i = 1; i < msgFields.size(); i++) {
					responseToDevice.append(VALUE_SEPARATOR);

					if ("ItvID".equalsIgnoreCase(msgFields.get(i))) {
						responseToDevice.append(event.getEquipmentID());
						logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "ITV ID : -" + event.getEquipmentID());
					} else if ("TrailerID".equalsIgnoreCase(msgFields.get(i))) {

						String trailerNo = RDTCacheManager.getInstance().getTrailerNo(event.getEquipmentID());

						logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "Corresponding Trailer ID is : -" + trailerNo);
						responseToDevice.append(trailerNo);

					} else if ("ContainerIDs".equalsIgnoreCase(msgFields.get(i))) {

						if (event.getContainerIDs() != null && containers.size() > 1) {
							responseToDevice.append(containers.get(0)).append(ROW_SEPARATOR).append(containers.get(1));
						}

					} else if ("NumberOfCntrs".equalsIgnoreCase(msgFields.get(i))) {

						responseToDevice.append(Integer.toString(noOfCntrs));
					} else if ("UserID".equalsIgnoreCase(msgFields.get(i))) {
						responseToDevice.append(operatorId);
					} else if ("Color".equalsIgnoreCase(msgFields.get(i))) {

						// Red - Incase of ITV arrived
						responseToDevice.append(RDTVesselProfileCacheManager.getInstance().getColourCode(ITV_ARRIVED));
					} else {
						EventUtil.getInstance().getEventParameter(event, msgFields.get(i), responseToDevice);
					}
				}

				OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
				CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
						event.getTerminalID());
			}
		}
	}
}
