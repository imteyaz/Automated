package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class TechSupportRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = 4723704418387318222L;

    public String toString() {
        return "TechSupportRequestEvent [UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID() + ", TerminalID="
                + getTerminalID() + "]";
    }
}
