package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the business exception details
 * @author Rosemary George
 *
 */
@Entity
@Table(name="MP_BUSINESS_EXCEPTION_DETAIL") 
public class BusinessExceptionDetails implements Serializable{

    private static final long serialVersionUID = -1427275763592689322L;

    @EmbeddedId
    private BusinessExceptionDetailsPk pk;
    
    @Column(name="EXCEPTION_VALUE")
    private String exceptionValue;
    
    @Column(name="EXCEPTION_DESC")
    private String exceptionDesc;

    public BusinessExceptionDetailsPk getPk() {
        return pk;
    }

    public void setPk(BusinessExceptionDetailsPk pk) {
        this.pk = pk;
    }

    public String getExceptionId() {
        return this.pk.getExceptionId();
    }

    public void setExceptionId(String exceptionId) {
        this.pk.setExceptionId(exceptionId);
    }
    
    public String getExceptionValue() {
        return exceptionValue;
    }

    public void setExceptionValue(String exceptionValue) {
        this.exceptionValue = exceptionValue;
    }

    public String getExceptionDesc() {
        return exceptionDesc;
    }

    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    @Override
    public String toString() {
        return "BusinessExceptionDetails [pk=" + pk + ", exceptionValue=" + exceptionValue + ", exceptionDesc="
                + exceptionDesc + "]";
    }  
}