package com.minapro.procserver.events.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.Arrays;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

public class UpdateJobDetectedEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7114976409284716406L;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(UpdateJobDetectedEvent.class);

    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    /**
     * Indicates what kind of update is performed by the operator. Can be splitting a twin job, or adding twin or
     * tandem.
     */
    private JOB_UPDATE_TYPE updateType;

    /**
     * Contains the containers involved in the update job operation.
     */
    private String[] containerIDs;

    public JOB_UPDATE_TYPE getUpdateType() {
        return updateType;
    }

    /**
     * Sets the updateType
     * 
     * @param updateType
     */
    public void setUpdateType(String updateType) {
        if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.SPLIT.toString())) {
            this.updateType = JOB_UPDATE_TYPE.SPLIT;
        } else if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.TWIN.toString())) {
            this.updateType = JOB_UPDATE_TYPE.TWIN;
        } else if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.TANDEM.toString())) {
            this.updateType = JOB_UPDATE_TYPE.TANDEM;
        } else {
            this.updateType = JOB_UPDATE_TYPE.TANDEM_SPLIT;
        }
    }

    public String[] getContainerIDs() {
        return containerIDs;
    }

    /**
     * Parses the string of containers IDs to Array
     * 
     * @param containerIDs
     */
    public void setContainerIDs(String containerIDs) {
        try {
            this.containerIDs = containerIDs.split("\\" + ROW_SEPARATOR);
        } catch (Exception ex) {
            this.containerIDs = null;
            logger.logException("Caught Exception ", ex);
        }
    }

    @Override
    public String toString() {
        return "UpdateJobDetectedEvent [updateType=" + updateType + ", containerIDs=" + Arrays.toString(containerIDs)
                + "]";
    }

    public enum JOB_UPDATE_TYPE {
        SPLIT, TWIN, TANDEM, TANDEM_SPLIT
    }
}
