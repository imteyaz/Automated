package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite Primary Key for Back Reach Jobs
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class BackReachPK implements Serializable {

    private static final long serialVersionUID = 7105026307757463665L;

    @Column(name = "BACKREACH_ID")
    private String id;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    @Override
    public String toString() {
        return "BackReachPK [id=" + id + ", rotationId=" + rotationId + "]";
    }
}
