package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * ValueObject holding the mapping between Delay Type and Role
 * 
 * @author kalyani
 *
 */

@Entity
@Table( name = "MP_DLY_TYP_GRP_MAP")
public class DelayGroupMapping implements Serializable{

    private static final long serialVersionUID = -354437177282708198L;
   
    @EmbeddedId
    private DelayGroupMappingPK pk;
    
    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;

    public DelayGroupMappingPK getPk() {
        return pk;
    }

    public void setPk(DelayGroupMappingPK pk) {
        this.pk = pk;
    }

    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public String toString() {
        return "DelayGroupMapping [pk=" + pk + ", createdBy=" + createdBy + ", createdDatetime=" + createdDatetime
                + "]";
    }    
}
