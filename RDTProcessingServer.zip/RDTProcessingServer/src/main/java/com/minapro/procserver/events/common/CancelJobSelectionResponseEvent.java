package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the cancel job selection response
 * @author Rosemary George
 *
 */
public class CancelJobSelectionResponseEvent extends Event implements Serializable{

	private static final long serialVersionUID = -6761036011078120676L;

	private String containerId;

	private String moveType;

	/**
	 * Indicates whether the request was successful or not
	 */
	private boolean isSuccess;

	/**
	 * Will be filled with the error message in case failure
	 */
	private String errorMessage;

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	@Override
	public String toString() {
		return "CancelJobSelectionRespEvent [containerId=" + containerId + ", moveType=" + moveType + ", isSuccess="
				+ isSuccess + ", errorMessage=" + errorMessage + ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}	
}
