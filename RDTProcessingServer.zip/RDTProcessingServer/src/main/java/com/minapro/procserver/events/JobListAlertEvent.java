package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the failure alert from ESB. The alert event will be generated when ESB is unable to retrieve the
 * job list from SPARCS after repeated login attempt.
 * 
 * @author Rosemary George
 *
 */
public class JobListAlertEvent extends Event implements Serializable {
    private static final long serialVersionUID = 6304205202942299886L;

    /**
     * Indicates the error reason received from SPARCS
     */
    private String reason;

    private boolean isScheduled;
    
    private String beepRequired;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

    @Override
    public String toString() {
        return "JobListAlertEvent [errorReason=" + reason + ", isScheduled=" + isScheduled + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }

	public String getBeepRequired() {
		return beepRequired;
	}

	public void setBeepRequired(String beepRequired) {
		this.beepRequired = beepRequired;
	}
}
