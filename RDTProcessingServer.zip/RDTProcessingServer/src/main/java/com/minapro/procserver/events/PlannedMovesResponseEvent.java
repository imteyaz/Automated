package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

public class PlannedMovesResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 1733212656284156430L;

    private List<PlannedMovesEvent> plannedMovesResponseList;

    public List<PlannedMovesEvent> getPlannedMovesResponseList() {
        return plannedMovesResponseList;
    }

    public void setPlannedMovesResponseList(List<PlannedMovesEvent> plannedMovesResponseList) {
        this.plannedMovesResponseList = plannedMovesResponseList;
    }

    @Override
    public String toString() {
        return "PlannedMovesResponseEvent [plannedMovesResponseList=" + plannedMovesResponseList + ", EquipmentID="
                + getEquipmentID() + ", TerminalID=" + getTerminalID() + "]";
    }
}
