package com.minapro.procserver.actors.hc;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.METHOD;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ORPHAN_CONTAINER_STATUS_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OUT_OF_LIST_CNTRS_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Arrays;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OrphanContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.opus.util.ContainerMoveUtil;
import com.minapro.procserver.opus.util.QuaySideContainerMoveService;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Following class is responsible for creating Orphan Container and holding OrphanContainer related events. Sending
 * OrphanContainerEvent POJO to the SPARCS. SPARCS gives status response like whether the request is processed or not.
 * i.e.Whether new container created or not.
 * 
 * @author UMAMAHESH M
 *
 */
public class OrphanContainerActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(OrphanContainerActor.class);

	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);

	@Override
	public void onReceive(Object message) throws Exception {
		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass()).append(ON_RECEIVE).append(METHOD)
				.toString());

		if (message instanceof OrphanContainerEvent) {
			sendOrphanCntrCreationReqToESB((OrphanContainerEvent) message);
		} else if (message instanceof OrphanContainerResponseEvent) {
			sendOrphanCntrCreationStatusToUI((OrphanContainerResponseEvent) message);
		} else if (message instanceof OutOfListContainersRequestEvent) {
			OutOfListContainersRequestEvent event = (OutOfListContainersRequestEvent) message;
			
			ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
	                .getAllocationDetails(event.getUserID());
	        if (allocation != null) {
	            event.setRotationId(allocation.getRotationID());
	        }
	        logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
					" Posting OutOfListContainersRequestEvent To ESB.".concat(event.toString()));
			ESBQueueManager.getInstance().postMessage(event,
					RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID()), event.getTerminalID());
		} else if (message instanceof OutOfListContainerResponseEvent) {
			sendOutOfListCntrDtlsToUI((OutOfListContainerResponseEvent) message);
		} else {
			unhandled(message);
		}
	}
	
	private void sendOutOfListCntrDtlsToUI(OutOfListContainerResponseEvent event) {

		try {
			logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
					" Received OutOfListContainerResponseEvent".concat(event.toString()));
	
			List<JobListContainer> outOfListCntrs = event.getOutOfListContainers();
	
			int outofCntrsSize = outOfListCntrs == null || outOfListCntrs.isEmpty() ? 0 : outOfListCntrs.size();
	
			StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR)
					.append(DeviceEventTypes.getInstance().getEventType(OUT_OF_LIST_CNTRS_RESPONSE))
					.append(VALUE_SEPERATOR).append(event.getEventID()).append(VALUE_SEPERATOR);
	
			if (outofCntrsSize == 0) {
				responseToDevice.append("").append(VALUE_SEPERATOR).append(JobListUtil.prepareIsoCodes());
			} else {
				JobListUtil.getInstnace().prepareJobListCntrsMessage(responseToDevice, outOfListCntrs, outofCntrsSize);
				responseToDevice.append(VALUE_SEPERATOR).append("");
			}
	
			responseToDevice.append(VALUE_SEPERATOR)
					.append(event.getUserID()).append(VALUE_SEPERATOR).append(event.getTerminalID());
	
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
					RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID()), event.getTerminalID());
		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("in sendOutOfListCntrDtlsToUI()").append(REASON)
					.toString(), ex);
		}
	}

	/**
	 * Method is responsible for sending response which is coming from SPARCS system to the communication server. If
	 * orphan container created successfully success message comes from the SPARCS else failed at SPARCS then show error
	 * message to user in UI side.
	 * 
	 * @param OrphanContainerResponseEvent
	 *            POJO.Which comes from ESB
	 */
	private void sendOrphanCntrCreationStatusToUI(OrphanContainerResponseEvent message) {

		try {

			logger.logMsg(LOG_LEVEL.INFO, message.getUserID(), new StringBuilder(ENTRY).append(" sendResponseToUI()")
					.toString());

			// get the message format
			List<String> msgFields = EventFormats.getInstance().getEventFields(ORPHAN_CONTAINER_STATUS_RESPONSE);

			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(
					DeviceEventTypes.getInstance().getEventType(ORPHAN_CONTAINER_STATUS_RESPONSE));

			final int noOfMsgFields = msgFields.size();

			for (int i = 1; i < noOfMsgFields; i++) {
				responseToDevice.append(VALUE_SEPERATOR);
				EventUtil.getInstance().getEventParameter(message, msgFields.get(i), responseToDevice);
			}

			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
					RDTCacheManager.getInstance().getUserLoggedInRole(message.getUserID()), message.getTerminalID());

			// Orphan/OutOf List Created Successfully, Then Needs to Insert Into Database as Completed Job.
			if (message.getContainerCreationStatus()) {
				// Insert Orphan Container Into ATOM database
				ContainerMoveEvent cntrMoveEvnt = prepareContainerMoveEvent(message);
				ContainerMoveUtil.getInstance().updateCompletedMoves(
						RDTCacheManager.getInstance().getUserDetails(message.getUserID()), cntrMoveEvnt,
						cntrMoveEvnt.getEquipmentID(),
						RDTCacheManager.getInstance().getUserLoggedInRole(message.getUserID()));
				// Update User Performance Parameters.
				QuaySideContainerMoveService.getInstance().updatePerformanceParameters(cntrMoveEvnt);
			}
		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("in sendResponseToUI()").append(REASON)
					.toString(), ex);
		}
	}

	/**
	 * Method is responsible for posting OrphanContainerCreation POJO to the SPARCS system.
	 * 
	 * @param OrphanContainerEvent
	 *            POJO
	 */
	private void sendOrphanCntrCreationReqToESB(OrphanContainerEvent orphanCntrEvnt) {

		try {
			logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendOrphanCntrCreationReqToESB()")
					.append(INPUT).append(orphanCntrEvnt.toString()).toString());

			String[] vesselVoyage = JobListUtil.getVesselAndVoyageDetails(orphanCntrEvnt.getUserID());
			if (vesselVoyage != null) {
				logger.logMsg(LOG_LEVEL.INFO, orphanCntrEvnt.getUserID(),
						" Vessel Voyage Details Are:::" + Arrays.toString(vesselVoyage));
				orphanCntrEvnt.setVessel(vesselVoyage[0]);
				orphanCntrEvnt.setVoyage(vesselVoyage[1]);
			} else {
				logger.logMsg(LOG_LEVEL.ERROR, "", " UnAble To Retrieve Vessel And Voyage Details..");
			}

			if (RDTCacheManager.getInstance().getUserLoggedInRole(orphanCntrEvnt.getUserID()).equals(OPERATOR.HC)) {
				orphanCntrEvnt.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
						orphanCntrEvnt.getUserID()));
			}
			ESBQueueManager.getInstance().postMessage(orphanCntrEvnt,
					RDTCacheManager.getInstance().getUserLoggedInRole(orphanCntrEvnt.getUserID()),
					orphanCntrEvnt.getTerminalID());

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in sendOrphanCntrCreationReqToESB()")
					.append(REASON).toString(), ex);
		}
	}

	public ContainerMoveEvent prepareContainerMoveEvent(OrphanContainerResponseEvent event) {
		ContainerMoveEvent containerMoveEvnt = new ContainerMoveEvent();
		containerMoveEvnt.setUserID(event.getUserID());
		containerMoveEvnt.setEventID(event.getEventID());
		containerMoveEvnt.setContainerIDs(event.getContainerId());
		if(event.getFromLocation() == null){
			containerMoveEvnt.setFromLocations("VESSEL");
		}else {
			containerMoveEvnt.setFromLocations(event.getFromLocation());
		}
		
		containerMoveEvnt.setToLocations(event.getItvNo());
		containerMoveEvnt.setTerminalID(event.getTerminalID());
		containerMoveEvnt.setMoveType("DSCH");
		containerMoveEvnt.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(event.getUserID()));
		return containerMoveEvnt;
	}
}
