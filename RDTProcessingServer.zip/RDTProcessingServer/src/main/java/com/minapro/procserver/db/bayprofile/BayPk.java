package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key to identify the bays defined under sections for a vessel
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class BayPk implements Serializable {
    private static final long serialVersionUID = 5119931525214764973L;

    @Column(name = "INT_VSL_NO")
    private int vesselNo;

    @Column(name = "INT_SECT_NO")
    private int sectNo;

    @Column(name = "DK_UNDK_IND")
    private String deckUnderDeck;

    @Column(name = "BAY_OFFSET")
    private int bayOffset;

    public int getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(int vesselNo) {
        this.vesselNo = vesselNo;
    }

    public int getSectNo() {
        return sectNo;
    }

    public void setSectNo(int sectNo) {
        this.sectNo = sectNo;
    }

    public String getDeckUnderDeck() {
        return deckUnderDeck;
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        this.deckUnderDeck = deckUnderDeck;
    }

    public int getBayOffset() {
        return bayOffset;
    }

    public void setBayOffset(int bayOffset) {
        this.bayOffset = bayOffset;
    }
}
