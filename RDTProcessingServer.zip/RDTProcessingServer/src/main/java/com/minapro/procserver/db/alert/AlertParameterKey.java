package com.minapro.procserver.db.alert;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ValueObject holding the possible parameters available for Alerts
 * 
 * @author Rosemary George
 */

@Entity
@Table(name = "MP_ALERT_PARAMETER_KEY_MASTER")
public class AlertParameterKey implements Serializable {

	private static final long serialVersionUID = -745260516970173811L;

	@Id
	@Column(name = "PARAMETER_ID", nullable = false)
	private Integer paramId;

	@Column(name = "PARAMETER_NAME", nullable = false)
	private String paramName;

	public Integer getParamId() {
		return paramId;
	}

	public void setParamId(Integer paramId) {
		this.paramId = paramId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
}
