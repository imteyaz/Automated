package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ValueObject containing the equipment type details. Equipment type refers to QC, ITV, CHE etc
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_EQUIPMENT_TYPE_MASTER")
public class EquipmentType extends Audit implements Serializable {

    private static final long serialVersionUID = 9102551971036096752L;

    @Id
    @Column(name = "EQUIPMENT_TYPE_ID", nullable = false)
    private String equipmentTypeId;

    @Column(name = "DESCRIPTION")
    private String description;

    public String getEquipmentTypeId() {
        return equipmentTypeId;
    }

    public void setEquipmentTypeId(String equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
