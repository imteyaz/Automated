package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the QC to rotation mapping
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_ROTATION_QC_MAPPING")
public class RotationQCMapping extends Audit implements Serializable {

    private static final long serialVersionUID = 2255648832149770767L;

    @EmbeddedId
    private RotationQCPk rotationQcId;

    public RotationQCPk getRotationQcId() {
        return rotationQcId;
    }

    public void setRotationQcId(RotationQCPk rotationQcId) {
        this.rotationQcId = rotationQcId;
    }
}
