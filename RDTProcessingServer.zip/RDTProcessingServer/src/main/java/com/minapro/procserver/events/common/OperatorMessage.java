package com.minapro.procserver.events.common;

import java.io.Serializable;

/**
 * Value object holding the message for an equipment from TOS
 * @author Rosemary George
 *
 */
public class OperatorMessage implements Serializable {

	private static final long serialVersionUID = -1961656039619476815L;

	private String equipmentId;
	
	private String message;

	public String getEquipmentId() {
		return equipmentId;
	}

	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "OperatorMessage [equipmentId=" + equipmentId + ", message=" + message + "]";
	}	
}
