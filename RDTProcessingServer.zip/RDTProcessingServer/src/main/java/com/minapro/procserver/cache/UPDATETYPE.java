package com.minapro.procserver.cache;

/**
 * Possible values for cache update operations
 * 
 * @author Rosemary George
 *
 */
public enum UPDATETYPE {
    ADD, DELETE, UPDATE
}
