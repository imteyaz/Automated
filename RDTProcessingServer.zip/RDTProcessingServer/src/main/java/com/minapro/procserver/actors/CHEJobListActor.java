package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_COMPLETED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.util.ArrayList;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.che.CHEJobListEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersResponseEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.util.BlockCotainersUpdateUtil;
import com.minapro.procserver.util.CHEJobListService;
import com.minapro.procserver.util.CHEJobListUtil;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * CHE Job List Actor Which will handle All CHE JobList related activities.
 * 
 * @author UmaMahesh
 *
 */
public class CHEJobListActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobListActor.class);

    CHEJobListService cheJobsServiceObj = CHEJobListService.getInstance();

    @Override
    /**
     * Handles CHEJobListEvent(comes from ESB) and JobListRequestEvent(server initiated internally or from operator)
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof CHEJobListEvent) {
            CHEJobListEvent jobList = (CHEJobListEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, jobList.getUserID(), "Received CHE jobList event from ESB");
            logger.logMsg(LOG_LEVEL.INFO, jobList.getEquipmentID(), new StringBuilder(
            		EQUIPMENT_JOB_LIST_REQUEST_COMPLETED).toString());

            RDTCacheManager.getInstance().setEqJobListReqStatus(jobList.getEquipmentID(),
                    EquipmentJobListRequestStatus.COMPLETED);

            handleJobListEventFromESB(jobList);
        } else if (message instanceof UpdateBlockContainersResponseEvent) {
            UpdateBlockContainersResponseEvent event = (UpdateBlockContainersResponseEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
                    "Received CHE UpdateBlockContainersResponseEvent  from ESB");
            handleUpdateBlockContainersResponseEvent(event);
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the job list event from ESB.While retrieving records from database at that time Checking the current
     * container Available in cache or not.If not adding all those containers to update required containers list And
     * sending request to ESB for container attributes update. If message type is Request(RESP) means we have to send
     * response back to UI.At that time sending response immediately even though UpdateRequiredContainer List(Containers
     * which does not have iso,pod,weight) is not empty.
     * 
     * @param jobListEvent
     *            CHEJobListEvent
     */
    private void handleJobListEventFromESB(CHEJobListEvent jobListEvent) {

        logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getUserID(), " Started handleJobListEventFromESB () ");
        final String logId = jobListEvent.getUserID().concat("-").concat(jobListEvent.getEquipmentID());

        String messageType = RESP;
        if (jobListEvent.isScheduled()) {
            messageType = NOTIF;
        }

        try {

            // Construct Update Required Containers.
            List<String> updateRequiredContainerList = new ArrayList<String>();

            // TODO:Need to read from Properties file or from application parameters...
            int jobCompletionDays = 1;

            // Return available jobs from database,If no jobs available it will return empty object.
            List<JobListContainer> cheJobsFromDB = cheJobsServiceObj.getCHEJobListFromDatabase(jobListEvent,
                    jobCompletionDays, updateRequiredContainerList);

            logger.logMsg(LOG_LEVEL.INFO, logId, new StringBuilder(" Current Equipment Jobs Count Is::").append(
                            cheJobsFromDB != null ? cheJobsFromDB.size() : 0).toString());
            /*
             * updateRequiredContainerList is a collection of Container objects which are not having container attribute
             * details like ISO,POD,WT If it is null means all Container related attributes are available in Cache and
             * We can continue further Steps. Else sending request to ESB to get those containers details and waiting
             * for ESB response if message type is NOTIF else Proceeding to next steps.
             */
            if (updateRequiredContainerList.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, logId, new StringBuilder(
                        "Update Required List Is Empty--Calling CHEJobListProcessing() ").toString());
                CHEJobListUtil.getInstance().doCHEJobListProcessing(messageType, jobListEvent, cheJobsFromDB);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, logId, new StringBuilder(
                        "Update Required List Is Not Empty Requesting ESB For Cntr Attributes Update").toString());

                BlockCotainersUpdateUtil.getInstance().sendUpdateRequiredBlockContainersToESB(
                        updateRequiredContainerList, jobListEvent);

                if (RESP.equalsIgnoreCase(messageType)) {
                    logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getUserID(),
                            new StringBuilder(" Current Message Type Is Resp").append(
                                    " Update required for Jobs.Sending Empty Response").toString());
                   CHEJobListUtil.getInstance().doCHEJobListProcessing(messageType, jobListEvent, cheJobsFromDB);                    
                }
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing jobListEvent -", e);
            logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getEquipmentID(), new StringBuilder(
                    " Setting Current Equipment Job Completion Status to Completed Into Cache").toString());
            RDTCacheManager.getInstance().setEqJobListReqStatus(jobListEvent.getEquipmentID(),
                    EquipmentJobListRequestStatus.COMPLETED);
        }
    }

    private void handleUpdateBlockContainersResponseEvent(UpdateBlockContainersResponseEvent event) {
        try {

            // TODO::Need To Include Notification Type Property in Both The UpdateBlockContainersResponseEvent and
            // Request Event.
            logger.logMsg(LOG_LEVEL.INFO, event.getEquipmentID() + event.getUserID(), new StringBuilder(
                    " Updated Required Container List Values Are::").append(event).toString());
            String messageType = null;

            // reteive jobs from db with refContainerId and SeqNumber
            List<YardProfileContainer> updateRequiredContainerList = event.getUpdatedContainerList();
            int jobCompletionDays = 1;
            List<JobListContainer> cheJobsFromDB = cheJobsServiceObj.getCHEJobListFromDatabase(event,
                    jobCompletionDays, null);

            if (updateRequiredContainerList != null && !updateRequiredContainerList.isEmpty()) {
                BlockCotainersUpdateUtil.getInstance().updateBlockProfileWithListOfContainers(event);
            }
            
            CHEJobListUtil.getInstance().doCHEJobListProcessing(messageType, event, cheJobsFromDB);
                        
        } catch (Exception e) {
            logger.logException("Caught exception while processing jobListEvent -", e);
        }
    }
   
}
