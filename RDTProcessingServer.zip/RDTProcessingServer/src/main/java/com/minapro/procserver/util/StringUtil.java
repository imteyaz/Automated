package com.minapro.procserver.util;

/**
 * 
 * Common Utility methods for all String Manipulations and Verifications.
 * 
 * @author Prasad Tallapally
 *
 */
public class StringUtil {
    private static final StringUtil INSTANCE = new StringUtil();

    private StringUtil() {
    }

    public static StringUtil getInstance() {
        return INSTANCE;
    }

    /**
     * 
     * Confirms passing string value is whether Null/Empty or not
     * 
     * @param val
     * @return boolean
     */
    public boolean isEmptyOrNull(String val) {
        if (val == null || val.isEmpty()) {
            return true;
        }
        return false;

    }

}
