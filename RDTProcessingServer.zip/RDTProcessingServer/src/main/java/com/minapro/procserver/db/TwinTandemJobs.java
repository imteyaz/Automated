package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Value Object which holds the twin /tandem job details
 * @author Rosemary George
 *
 */
@Entity
@Table(name="MP_TWINTANDEM_JOB_LIST")
public class TwinTandemJobs implements Serializable{
  
	private static final long serialVersionUID = 1327060135526523492L;

    @Id
    @SequenceGenerator(name = "seq_gen", sequenceName = "MP_TWINTANDEM_JOB", allocationSize = 1)
    @GeneratedValue(generator = "seq_gen")
    @Column(name="TWINTANDEM_ID", nullable=false)
    private Integer twinTandemId;
    
   	@Column(name="TERMINAL_ID")
    private String terminalId;
    
    @Column(name="ROTATION_ID")
    private String rotationId;
    
    @Column(name="EQUIPMENT_ID")
    private String equipmentId;
    
    @Column(name="SPARCS_TWIN_IND")
    private String sparcsTwinIndicator;
    
    @Column(name="MINAPRO_TWIN_SPLIT")
    private String twinSplit;
    
    @Column(name="TWIN_TANDEM_TYPE")
    private String jobType;
    
    @OneToMany(fetch = FetchType.EAGER, mappedBy = "pk.twinTandemId", cascade = CascadeType.ALL)
    private Set<TwinTandemContainerList> twinTandemDetails = new HashSet<TwinTandemContainerList>();

    @Column(name="JOB_COMPLETED")
    private String isJobCompleted;
    
    public String getIsJobCompleted() {
        return isJobCompleted;
    }

    public void setIsJobCompleted(String isJobCompleted) {
        this.isJobCompleted = isJobCompleted;
    }
    
    public Integer getTwinTandemId() {
        return twinTandemId;
    }

    public void setTwinTandemId(Integer twinTandemId) {
        this.twinTandemId = twinTandemId;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getSparcsTwinIndicator() {
        return sparcsTwinIndicator;
    }

    public void setSparcsTwinIndicator(String sparcsTwinIndicator) {
        this.sparcsTwinIndicator = sparcsTwinIndicator;
    }

    public String getTwinSplit() {
        return twinSplit;
    }

    public void setTwinSplit(String twinSplit) {
        this.twinSplit = twinSplit;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Set<TwinTandemContainerList> getTwinTandemDetails() {
        return twinTandemDetails;
    }

    public void setTwinTandemDetails(Set<TwinTandemContainerList> twinTandemDetails) {
        this.twinTandemDetails = twinTandemDetails;
    }

  
    @Override
	public int hashCode() {
    	
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((twinTandemId == null) ? 0 : twinTandemId.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		TwinTandemJobs other = (TwinTandemJobs) obj;
		if (twinTandemId == null) {
			if (other.twinTandemId != null){
				return false;
			}
		} else if (!twinTandemId.equals(other.twinTandemId)){
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "TwinTandemJobs [twinTandemId=" + twinTandemId
				+ ", equipmentId=" + equipmentId + ", sparcsTwinIndicator="
				+ sparcsTwinIndicator + ", twinSplit=" + twinSplit
				+ ", twinTandemDetails=" + twinTandemDetails + "]";
	}    
}
