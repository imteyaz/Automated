package com.minapro.procserver.db.alert;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

/**
 * ValueObject holding the configuration details for a particular Alert
 * 
 * @author Rosemary George
 */
@Entity
@Table(name = "MP_ALERT_CONFIGURATION_MASTER")
public class AlertConfiguration implements Serializable {

	private static final long serialVersionUID = -4833484241104057672L;

	@Id
	@Column(name = "ALERT_CODE", nullable = false)
	private String alertCode;

	@Column(name = "ALERT_TEXT", nullable = false)
	private String alertText;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "SEVERITY", nullable = false)
	private String severity;

	@Column(name = "SOUND_REQUIRED", nullable = false)
	private String soundRequired;
	
	@Column(name = "EXPIRY_TIME")
	private Integer expiryTime;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "ALERT_CODE", referencedColumnName = "ALERT_CODE")
	private Set<AlertGroupAssociation> alertsubscribersMap = new HashSet<AlertGroupAssociation>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "ALERT_CODE", referencedColumnName = "ALERT_CODE")
	@LazyCollection(LazyCollectionOption.FALSE)
	private Collection<AlertParameterAssociation> alertKeysMap = new HashSet<AlertParameterAssociation>();

	public Set<AlertGroupAssociation> getAlertsubscribersMap() {
		return alertsubscribersMap;
	}

	public void setAlertsubscribersMap(Collection<AlertGroupAssociation> alertsubscribersMap) {
		if(alertsubscribersMap != null){
			for(AlertGroupAssociation groupAssoc : alertsubscribersMap){
				this.alertsubscribersMap.add(groupAssoc);
			}
		}
	}

	public Integer getExpiryTime() {
		return expiryTime;
	}

	public void setExpiryTime(Integer expiryTime) {
		this.expiryTime = expiryTime;
	}

	public Collection<AlertParameterAssociation> getAlertKeysMap() {
		return alertKeysMap;
	}

	public void setAlertKeysMap(Collection<AlertParameterAssociation> alertKeysMap) {
		this.alertKeysMap = alertKeysMap;
	}

	public String getAlertCode() {
		return alertCode;
	}

	public void setAlertCode(String alertCode) {
		this.alertCode = alertCode;
	}

	public String getAlertText() {
		return alertText;
	}

	public void setAlertText(String alertText) {
		this.alertText = alertText;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getSoundRequired() {
		return soundRequired;
	}

	public void setSoundRequired(String soundRequired) {
		this.soundRequired = soundRequired;
	}

	@Override
	public String toString() {
		return "AlertConfiguration [alertCode=" + alertCode + ", severity=" + severity + ", soundRequired="
				+ soundRequired +  ", alertKeysMap=" + alertKeysMap	+ "]";
	}
	
	
}
