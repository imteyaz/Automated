package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * Serves ViewDocument for Damage Reports Inspection Report Short Land/Over Land Report
 * 
 * @author Prasad.Tallapally
 *
 */
public class VesselDocumentEvent extends Event implements Serializable {

    private static final long serialVersionUID = 842092780319917917L;
    private String documentName;
    private String rotationId;

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

}
