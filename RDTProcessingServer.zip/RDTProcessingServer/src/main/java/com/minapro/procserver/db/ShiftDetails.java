package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "MP_SHIFT_MASTER")
public class ShiftDetails extends Audit implements Serializable {

	private static final long serialVersionUID = -6320801709182778468L;

	@Id
	@SequenceGenerator(name = "shift_record_gen", sequenceName = "MP_SHIFT_MASTER_RECORD_ID_SEQ", allocationSize = 1)
	@GeneratedValue(generator = "shift_record_gen")
	@Column(name = "RECORD_ID", nullable = false)
	private Integer shiftMasterRecordId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "TERMINAL_ID", referencedColumnName = "TERMINAL_ID")
	private Terminal terminal;

	@Column(name = "SHIFT_TYPE")
	private String shiftType;

	@Column(name = "START_DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date shiftStartDate;

	@Column(name = "END_DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date shiftEndDate;

	@Column(name = "USER_ID")
	private String userId;

	public Date getShiftStartDate() {
		return shiftStartDate;
	}

	public void setShiftStartDate(Date shiftStartDate) {
		this.shiftStartDate = shiftStartDate;
	}

	public Date getShiftEndDate() {
		return shiftEndDate;
	}

	public void setShiftEndDate(Date shiftEndDate) {
		this.shiftEndDate = shiftEndDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Terminal getTerminal() {
		return terminal;
	}

	public void setTerminal(Terminal terminal) {
		this.terminal = terminal;
	}

	public String getShiftType() {
		return shiftType;
	}

	public void setShiftType(String shiftType) {
		this.shiftType = shiftType;
	}

	public Integer getShiftMasterRecordId() {
		return shiftMasterRecordId;
	}

	public void setShiftMasterRecordId(Integer shiftMasterRecordId) {
		this.shiftMasterRecordId = shiftMasterRecordId;
	}

}
