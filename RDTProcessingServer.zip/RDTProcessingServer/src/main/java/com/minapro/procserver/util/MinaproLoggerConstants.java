package com.minapro.procserver.util;

public interface MinaproLoggerConstants {
    /**
     * Following are the constant messages useful at loggers
     */
    public static final String ENTRY = "Started ";

    public static final String END = "Completed Current Operations";

    public static final String CURRENT_RESULT = "Current Result Is";

    public static final String FINAL_CREATED_MSG = "Final Generated Message Is ";

    public static final String FINAL_CREATED_OBJECT = "Final Created Object Data Is";

    public static final String OPERATOR_ROLE = "Operator Role Is";

    public static final String POST_DATA = "Posting Data Into ";

    public static final String ESB_QUEUE_MGR = "ESB Queue Manager ";

    public static final String COMM_QUEUE_MGR = "Communication Server Queue Manager ";

    public static final String EXCEPTION_OCCURED = "Exception Occured In";

    public static final String ON_RECEIVE = " OnReceive";

    public static final String METHOD = " Method";

    public static final String SPACE = " ";

    public static final String REASON = " With Following Reason ";

    public static final String CURRENT_METHOD = " Current Method";

    public static final String INPUT = "Input Value Is  ";
    //Following are used in BLock Preparation
    public static final String ROW_SEQUNCE_MESSAGE = "Seems To Be Current Row Sequnce::";
    
    public static final String PREVIOUS_STACK_SEQ_MSG = " Previous Stack Seq Number ";
    
    public static final String STACK_NUMBER_CHECK_IN_DATABASE = " Is Not Present In Database ";
    
    public static final String TIER_NUMBER = " Tier Number::";
    
    public static final String CONTNR_PRESENT_LOCATION = "Container Current location" ; 
    
    public static final String LINE_FORMATTER = "\n**************************************************************";
    
    public static final String  OPERATOR_IN_BREAK = "Operator Is In Break,No Need To Send JobList Request For Sparcs";
    
    public static final String MODIFYING = "Modifying ";
    
    public static final String POSITION_OF_CONTAINER = " Position of Container : - ";
    public static final String YARD_LOCATION_IS_EMPTY = " Yard Location Is Null Unable To Continue Further..";
    
    public static final String EQUIPMENT_JOB_LIST_REQUEST_COMPLETED = "Setting Current Equipment Job Completion Status to Completed Into Cache";
    
    public static final String EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS  =" JobList Request Already In  IN_PROGRESS state ,Ignore Current Refresh";
    
    public static final String EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS = " Equipment Earlier JobList Request Is Completed ,"
    		.concat(" Setting Current JobList  Status As IN_PROGRESS Into Cache");
    
}
