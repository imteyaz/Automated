package com.minapro.procserver.actors.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.FOLLOW_ITV;

import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.itv.FollowITVEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for checking if the ITV needs to follow any other ITV for LOAD sequence. 
 * 
 * This is determined based on the QC job list sequence for the container. 
 * If the container carrying by this ITV is not the first job in the QC job list, then should follow the ITV 
 * which carries the predecessor container in sequence.
 * 
 * @author Rosemary George
 *
 */
public class FollowITVActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(FollowITVActor.class);
	
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            ROW_SEPERATOR_KEY);
	
	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            ITEM_SEPERATOR_KEY);
	
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
	
	private static final String FOLLOWING_ITV = "Follow the ITV ";
	private static final String CARRY_CONTAINER = " carrying the container ";
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof FollowITVEvent){
			FollowITVEvent followEvent = (FollowITVEvent) message;
			logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "Recieved follow ITV event " + followEvent);
			handleFollowITV(followEvent);
		}else{
			unhandled(message);
		}
	}
	
	/**
	 * Handles the follow ITV logic. Retrieves the job list related to the QC and 
	 * finds the sequence of the container. If it is not at the first position, gets the container in the previous position and
	 * initiate the follow ITV message
	 * @param followEvent
	 */
	private void handleFollowITV(FollowITVEvent followEvent){
		try{
			String[] qcIds = followEvent.getQcId().split("\\"+ROW_SEPARATOR);
			logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "QC Ids = " + qcIds);
			String itvContainer = followEvent.getCarryingContainerId().substring(0,followEvent.getCarryingContainerId().indexOf(ITEM_SEPARATOR));
			logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "itvContaienr = " + itvContainer);
			
			if(qcIds.length > 0){
				String qcUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcIds[0]);
				if(qcUser != null){
					ListOrderedMap<String, JobListContainer> qcJobs = RDTCacheManager.getInstance().getJobList(
							qcUser, qcIds[0]);
					logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "QC user " + qcUser + " jobs=" + qcJobs.keyList());
					if(qcJobs != null && !qcJobs.isEmpty()){
						int containerPosInQcJobs = qcJobs.indexOf(itvContainer+LOAD);
						logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "ITV container position in QC job list " + containerPosInQcJobs);
						if(containerPosInQcJobs <= 0){
							logger.logMsg(LOG_LEVEL.INFO, followEvent.getEquipmentID(), "ITV carrying container "
									+ "is either at first position in job list or not present");
						}else {
							String followContainerKey = qcJobs.get(containerPosInQcJobs -1);
							JobListContainer followContainer = qcJobs.get(followContainerKey);
							logger.logMsg(LOG_LEVEL.INFO, followEvent.getEquipmentID(), "Follow container for the ITV is " + followContainer);
							
							if(followContainer != null && LOAD.equalsIgnoreCase(followContainer.getMoveType())){
								sendFollowITVMessage(followEvent, followContainer);
							}							
						}							
					}					
				}
			}
		}catch(Exception ex){
			logger.logException("Caught exception while handling Follow ITV ", ex);
		}
	}

	/**
	 * Constructs and sends the follow ITV message to the UI
	 * @param followEvent
	 * @param followContainer
	 */
	private void sendFollowITVMessage(FollowITVEvent followEvent, JobListContainer followContainer) {
		StringBuilder followItvMessage = new StringBuilder(FOLLOWING_ITV);
		
		String followItvId = followContainer.getFromLocation();
		if(RDTCacheManager.getInstance().getEquipmentDetails(followItvId) != null){
			followItvMessage.append(followItvId);
		}
		
		followItvMessage.append(CARRY_CONTAINER).append(followContainer.getContainerId());
		logger.logMsg(LOG_LEVEL.DEBUG, followEvent.getUserID(), "Follow ITV message --" + followItvMessage);
		
		// build the response to the device
		StringBuilder responseToDevice = new StringBuilder(NOTIF)
			.append(VALUE_SEPARATOR).append(DeviceEventTypes.getInstance().getEventType(FOLLOW_ITV))
			.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString())
			.append(VALUE_SEPARATOR).append(followItvMessage)
			.append(VALUE_SEPARATOR).append(followEvent.getUserID())
			.append(VALUE_SEPARATOR).append(followEvent.getTerminalID());
		
		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.ITV, followEvent.getTerminalID());
	}
}
