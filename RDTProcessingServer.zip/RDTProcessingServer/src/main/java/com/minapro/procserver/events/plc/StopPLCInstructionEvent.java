package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class StopPLCInstructionEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2642920171933968455L;

    private String subscribe;

    public String getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(String subscribe) {
        this.subscribe = subscribe;
    }

    @Override
    public String toString() {
        return "StopPLCInstructionEvent [subscribe=" + subscribe + "]";
    }

}
