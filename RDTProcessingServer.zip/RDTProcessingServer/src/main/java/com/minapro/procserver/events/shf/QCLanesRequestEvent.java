package com.minapro.procserver.events.shf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class QCLanesRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = 411484002068666880L;

    @Override
    public String toString() {
        return "QCLanesRequestEvent [User Id=" + getUserID() + ",TerminalId=" + getTerminalID() + "]";
    }
}
