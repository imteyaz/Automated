package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.cache.UPDATETYPE;

/**
 * Wrapper ValueObject holding the data which needs to be persisted in database.
 * 
 * @author Rosemary George
 *
 */
public class JournalEvent implements Serializable {

    private static final long serialVersionUID = -4974161618319671387L;

    /**
     * The POJO object which needs to be written to the database
     */
    private Object journalData;

    /**
     * Indicates the mode of operation - Possible values ADD/DELETE/UPDATE
     */
    private UPDATETYPE operationType;

    public JournalEvent(Object journalData, UPDATETYPE operationType) {
        this.journalData = journalData;
        this.operationType = operationType;
    }

    public UPDATETYPE getOperationType() {
        return operationType;
    }

    public void setOperationType(UPDATETYPE operationType) {
        this.operationType = operationType;
    }

    public Object getJournalData() {
        return journalData;
    }

    public void setJournalData(Object journalData) {
        this.journalData = journalData;
    }

    @Override
    public String toString() {
        return "JournalEvent [journalData=" + journalData + ", operationType=" + operationType + "]";
    }
}
