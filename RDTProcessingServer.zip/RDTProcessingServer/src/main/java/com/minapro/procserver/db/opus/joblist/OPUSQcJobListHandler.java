package com.minapro.procserver.db.opus.joblist;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.procserver.opus.util.OpusQcJobListService;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for execute the Chain of responsibilities to update the JobList Related Tables Based on Some Business Requirement. 
 * Business Requirement : Update the Sequence Numbers For Twin/Tandem Jobs Either Created by OPUS Or Minapro And 
 * Hold the MinaPro Created Twin/Tandem Jobs Along With OPUS Twin/Tandem Jobs Split like Splitting OPUS CReated Twin Or Tandem  In Database.
 * 
 * @author UmaMahesh
 *
 */
public class OPUSQcJobListHandler {

	private static final OPUSQcJobListHandler INSTNACE = new OPUSQcJobListHandler();

	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(OPUSQcJobListHandler.class);

	private static final OpusQcJobListService SERVICE = OpusQcJobListService.getInstnace();

	private static final OpusQCJobListDAO DAO = OpusQCJobListDAO.getInstnace();
	
	private static final String NO_TWIN_TANDEM_JOBS = " No Twin/Tandem Jobs Are Available In OPUS For Current Refresh,".concat(
			" Check And Remove Previous Twin/Tandem Jobs");

	private OPUSQcJobListHandler(){

	}

	public static OPUSQcJobListHandler getInstance(){
		return INSTNACE;
	}
	
	@SuppressWarnings("unchecked")
	public  void doJobListRestructure(JobListEvent jobList,final String rotationId) {

		final String equipmentId 		= jobList.getEquipmentID();
		final String terminalId  		= jobList.getTerminalID();
		final String[] vesselVoyage     = JobListUtil.getVesselAndVoyageDetails(jobList.getUserID());
		
		final String logTransactionId = rotationId.concat("-").concat(equipmentId) ;
		
		LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId," Java Procedure Execution Logic Started...");

		List<TwinTandemJobs> deletableTwinTandemIdList 				 = new ArrayList<TwinTandemJobs>();
		Set<TwinTandemJobs> availableTwinTandemJobs 				 = null;

		List<TwinTandemJobs> existedOpusCreatedTwinTandemJobs        = new ArrayList<TwinTandemJobs>();
		List<TwinTandemJobs> existedMinaProCreatedTwinJobs     		 = new ArrayList<TwinTandemJobs>();


		/**
		 * Step 1 : Retrieve Twin And Tandem Jobs Created By OPUS And Update Reference Container In OPUS JobList Table.
		 * And Also Updating the Sequence Number for Twin/Tandem Jobs.
		 */

		List<OPUSQCJobListEntity> currentRefreshTwinTandemJobs;
        try {
                currentRefreshTwinTandemJobs = SERVICE.getTwinAndTandemJobsWithOutRefCntrs(terminalId, rotationId, equipmentId,vesselVoyage);
            
    
    		int curRefreshTwinTandemJobsCount = currentRefreshTwinTandemJobs!=null ? currentRefreshTwinTandemJobs.size() : 0;
    
    		LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId, new StringBuilder("Current Refresh OPUS Created TwinTandem Jobs Size  Before Ref Container Update Is:::").
    				append(curRefreshTwinTandemJobsCount).toString());
    		/**
    		 * Step 1.1 : Retrieve OPUS And Minapro Created Twin And Tandem Jobs In Earlier Refreshes. 
    		 */
    
    		availableTwinTandemJobs = DAO.getExistedTwinJobs(terminalId,rotationId,equipmentId);
    
    		int availableTwinJobsCount = availableTwinTandemJobs!=null ? availableTwinTandemJobs.size() : 0;
    
    		LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,new StringBuilder("Existed All Twin Jobs Size From DB Is::").
    				append(availableTwinJobsCount).toString());
    
    		/*
    		 * Separating MinaPro Created Twin jobs And OPUS Created Twin Jobs.
    		 */
    		if(availableTwinJobsCount>0){
    
    			SERVICE.seperateMinaProAndSparcsCreatedTwinJobs(availableTwinTandemJobs,existedOpusCreatedTwinTandemJobs, existedMinaProCreatedTwinJobs);
    
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,new StringBuilder("Existed OPUSCreatedTwinJobs Size()::").
    					append(existedOpusCreatedTwinTandemJobs!=null ? existedOpusCreatedTwinTandemJobs.size() : 0).toString());
    
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,new StringBuilder("Existed MinaPro Created TwinJobs Size::").
    					append(existedMinaProCreatedTwinJobs!=null ? existedMinaProCreatedTwinJobs.size() : 0).
    					append(" Jobs::").append(existedMinaProCreatedTwinJobs!=null ? existedMinaProCreatedTwinJobs.toString() : 0).toString());
    		}
    
    
    		/**
    		 *  Step 2::
    		 * 	If Twin And Tandem Available Then Only Update Reference Container Otherwise No Need to execute following steps.
    		  	Retrieve Twin And Tandem Jobs With Reference Containers From Database Table mp_opus_qc_job_list.
    		  	Else Case Remove the already existed twin or tandem jobs for the current rotation,equipment,terminal.
    		 */
    
    		if(currentRefreshTwinTandemJobs!=null && !currentRefreshTwinTandemJobs.isEmpty()) {	
    			
    			SERVICE.setReferenceContainer(currentRefreshTwinTandemJobs);
    			
    			DAO.updateOPUSQcJobList(currentRefreshTwinTandemJobs);
    
    			Set<OPUSTwinTandemJobsPOJO>   curRefreshTwinTandemWithRefCntrsList = DAO.getCurrentSnapShotTwinJobs(terminalId,rotationId,equipmentId,vesselVoyage);
    
    
    			int curRefreshTwinTandemWithRefCntrsListCount = (curRefreshTwinTandemWithRefCntrsList!=null &&  !curRefreshTwinTandemWithRefCntrsList.isEmpty())
    					? curRefreshTwinTandemWithRefCntrsList.size() : 0 ; 
    
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId, new StringBuilder("Current Refresh OPUS Created Twin Jobs Size Is:::").
    					append(curRefreshTwinTandemWithRefCntrsListCount).toString());
    					//Step 3:
    			if(curRefreshTwinTandemWithRefCntrsListCount > 0){
    
    				for(TwinTandemJobs twinJobs : existedOpusCreatedTwinTandemJobs){
    
    					Set<TwinTandemContainerList> twinTadenContainerList = twinJobs.getTwinTandemDetails();
    					String twinTandeemId    = twinJobs.getTwinTandemId().toString();	
    					
    					LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,"Existed Twin Job Twin Tandem Id::"+twinTandeemId);
    					
    					for(TwinTandemContainerList twinTandemContainer : twinTadenContainerList){
    						SERVICE.checkCurrentTwinTandemJobsWithExisted
    						(curRefreshTwinTandemWithRefCntrsList, twinTandemContainer,twinJobs.getTwinSplit(),twinTandeemId);
    					}
    				}
    
    			//Step 4:
    
    			deletableTwinTandemIdList = SERVICE.prepareDeletableJobsListFromCurrentJobs(
    					curRefreshTwinTandemWithRefCntrsList,existedOpusCreatedTwinTandemJobs);
    
    			LOGGER.logMsg(LOG_LEVEL.INFO, logTransactionId,new StringBuilder("Deletable TwinTandem List For Existed Sparcs Created Twin Jobs::").
    						append(deletableTwinTandemIdList.size()).toString());
    
    			/*
    			 * Comparison and DB operations will be complete(wrt to OPUS created Twin/Tandem Jobs.) with following step
    			 */
    			SERVICE.prepareInsertOrUpdateRequiredList(curRefreshTwinTandemWithRefCntrsList, rotationId, terminalId , equipmentId);
    
    			} else {
    				LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,NO_TWIN_TANDEM_JOBS);
    				checkAndAddToDeletableList(existedOpusCreatedTwinTandemJobs,deletableTwinTandemIdList);
    			}
    
    		} else {
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,NO_TWIN_TANDEM_JOBS);
    			checkAndAddToDeletableList(existedOpusCreatedTwinTandemJobs,deletableTwinTandemIdList);
    			
    		}
    
    		if(existedMinaProCreatedTwinJobs!=null && !existedMinaProCreatedTwinJobs.isEmpty()) {
    			
    			List<OPUSQCJobListEntity> currentJobs = (List<OPUSQCJobListEntity>) DAO.loadOPUSJobList(OPUSQCJobListEntity.class);
    			
    			SERVICE.processNonOPUSTwinTandemJobs(existedMinaProCreatedTwinJobs,deletableTwinTandemIdList, currentJobs);
    		
    		} else {
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId," Minapro Created Twin/Tandem Jobs Are Not Available Till Current Refresh");
    			
    		}
    
    		//Final Step Deleting Objects From TwinTandemContainer List table
    
    		if(deletableTwinTandemIdList!=null && !deletableTwinTandemIdList.isEmpty()){ 
    
    			LOGGER.logMsg(LOG_LEVEL.INFO,logTransactionId,new StringBuilder(" Final Step In Procudere Logic To Delete Twin Jobs ")
    			.append(" Which Are Not Available In Current Refresh JobList Table::").append(deletableTwinTandemIdList.toString()).toString());
    			
    			DAO.deleteBulkTwinTandemJobs(deletableTwinTandemIdList);
    
    		}
        } catch (Exception ex){
            LOGGER.logException("Caught exception in doJobListRestructure-:", ex);
        }

	} //method
	
	/**
	 * Method is responsible to check , Earlier OPUS Created Twin/Tandem jobs  came as Twin Tandem Jobs in current refresh or not.
	 * These Twin/Tandem Jobs are adding to DeletableTwinTanDemList.
	 * Here Checking MinaTwinSplit='N' or not , which means checking earlier Twin/Tandem job is splitted by ATOM or not in current refresh.
	 * MinaTwinSplit='N' means job is not splitted in ATOM Now we can remove these jobs from TwinTandem_Jobs and TwinTandemContainer_List tables.
	 * 
	 * @param existedOpusCreatedTwinTandemJobs -- Earlier refresh opus created twin/tandem jobs list.
	 * @param deletableTwinTandemIdList       -- Deletable twin/tandem jobs list in current refresh.
	 */
	public void checkAndAddToDeletableList(List<TwinTandemJobs> existedOpusCreatedTwinTandemJobs,List<TwinTandemJobs> deletableTwinTandemIdList){
		
		for(TwinTandemJobs twinTandemJobs : existedOpusCreatedTwinTandemJobs) {
			
			if("N".equalsIgnoreCase(twinTandemJobs.getTwinSplit())){
				deletableTwinTandemIdList.add(twinTandemJobs);
			}
			
		}
		LOGGER.logMsg(LOG_LEVEL.TRACE,"",new StringBuilder(" Deletable TwinTandem Jobs Is::").
				append(deletableTwinTandemIdList).toString());
	}


}//class
