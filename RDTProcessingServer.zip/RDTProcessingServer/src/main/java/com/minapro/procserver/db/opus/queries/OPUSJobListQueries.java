package com.minapro.procserver.db.opus.queries;

public final class OPUSJobListQueries {

    public static final String GET_QC_JOB_LIST_ENTITY = "SELECT jobs FROM OPUSQCJobListEntity jobs"
            + " WHERE id.equipmentId=:equipmentId  AND  id.rotationId=:rotationId AND terminalId=:terminalId "
            + " and jobs.vesselName = :vesselName and jobs.voyage=:voyage order by jobWorkQueueSeqNo,seqNo asc";

    public static final String GET_TWIN_TANDEM_JOBS_FROM_JOB_LIST = " select entity from OPUSQCJobListEntity entity where entity.twinTandemCd in(:codes)"
            + " and entity.id.rotationId = :rotationId and entity.id.equipmentId = :equipmentId "
            + " and entity.terminalId = :terminalId and entity.vesselName = :vesselName and entity.voyage=:voyage";

    public static final String GET_TWIN_TANDEM_JOBS_BY_REF_CNTR = "Select a.container_id as c, a.move_kind as m, a.from_location as f, a.to_location as t, "
            + " a.seq_no as s, b.container_id as rc, b.move_kind as rm, b.from_location as rf, b.to_location as rt ,"
            + " b.seq_no as rs , a.TWIN_TANDEM_CD as twinCd , b.TWIN_TANDEM_CD as refTwinCd , a.TWIN_TANDEM_ID as twnCodeId , b.TWIN_TANDEM_ID as refTwnCodeId "
            + " from MP_OPUS_QC_JOB_LIST a, MP_OPUS_QC_JOB_LIST b"
            + " where a.terminal_id=:terminalId and (a.rotation_id=:rotationId) and (a.equipment_id=:equipmentId)"
            + " and (a.container_id = b.reference_container_id) and a.vessel_name=:vesselName and a.voyage=:voyage";

    // Retrieves the QC/HC job list
    public static final String RETRIEVE_QC_JOB_LIST_QUERY = "Select MP_OPUS_QC_JOB_LIST.SEQ_NO, MP_OPUS_QC_JOB_LIST.CONTAINER_ID,"
			+ " MP_OPUS_QC_JOB_LIST.MOVE_KIND, MP_OPUS_QC_JOB_LIST.FROM_LOCATION, MP_OPUS_QC_JOB_LIST.TO_LOCATION,"
			+ "MP_OPUS_QC_JOB_LIST.TANDEM_CONTAINERS,MP_OPUS_QC_JOB_LIST.ISO,MP_OPUS_QC_JOB_LIST.POD,MP_OPUS_QC_JOB_LIST.WT,"
			+ "MP_OPUS_QC_JOB_LIST.VOYAGE,MP_OPUS_QC_JOB_LIST.VESSEL_NAME,MP_OPUS_QC_JOB_LIST.JOB_KEY,"
			+ "MP_OPUS_QC_JOB_LIST.CATEGEORY,MP_OPUS_QC_JOB_LIST.STATUS,MP_OPUS_QC_JOB_LIST.POC," +
			" MP_OPUS_QC_JOB_LIST.JOB_QUEUE_NAME,MP_OPUS_QC_JOB_LIST.JOB_QUEUE_SEQUENCE, " +
			"(Select CASE WHEN MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID=MP_OPUS_QC_JOB_LIST.CONTAINER_ID THEN MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID " +
			"ELSE MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID END " +
			"FROM MP_TWINTANDEM_CONTAINER_LIST, MP_TWINTANDEM_JOB_LIST  " +
			"where MP_TWINTANDEM_CONTAINER_LIST.TWINTANDEM_ID=MP_TWINTANDEM_JOB_LIST.TWINTANDEM_ID and " +
			"(MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID= MP_OPUS_QC_JOB_LIST.CONTAINER_ID or " +
			"MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID= MP_OPUS_QC_JOB_LIST.CONTAINER_ID) " +
			"and MP_TWINTANDEM_JOB_LIST.MINAPRO_TWIN_SPLIT=:twinSplit " +
			"and MP_TWINTANDEM_JOB_LIST.EQUIPMENT_ID=:equipmentID and  " +
			"MP_TWINTANDEM_JOB_LIST.ROTATION_ID=:rotationID and " +
			"MP_TWINTANDEM_JOB_LIST.TERMINAL_ID=:terminalID and MP_TWINTANDEM_JOB_LIST.JOB_COMPLETED=:isJobCompleted) REFCONTAINER " +
			"from MP_OPUS_QC_JOB_LIST  where " +
			"MP_OPUS_QC_JOB_LIST.EQUIPMENT_ID=:equipmentID and MP_OPUS_QC_JOB_LIST.ROTATION_ID=:rotationID and MP_OPUS_QC_JOB_LIST.TERMINAL_ID=:terminalID "+
			"and MP_OPUS_QC_JOB_LIST.VESSEL_NAME=:vesselCode and MP_OPUS_QC_JOB_LIST.VOYAGE=:voyage "+
			"and MP_OPUS_QC_JOB_LIST.CONTAINER_ID not in ( select MP_COMPLETED_MOVES.CONTAINER_ID from MP_COMPLETED_MOVES where  " +
			"MP_COMPLETED_MOVES.CONTAINER_ID= MP_OPUS_QC_JOB_LIST.container_id AND "
			+ "MP_COMPLETED_MOVES.EQUIPMENT_ID=:equipmentID AND  MP_COMPLETED_MOVES.ROTATION_ID=:rotationID " +
			" and MP_COMPLETED_MOVES.MOVE_TYPE=MP_OPUS_QC_JOB_LIST.MOVE_KIND) order by MP_OPUS_QC_JOB_LIST.SEQ_NO" ;

    public static final String GET_TWIN_TANDEM_RECORD = "SELECT tj FROM TwinTandemJobs tj, TwinTandemContainerList tc "
            + "WHERE tj.twinTandemId=tc.pk.twinTandemId AND tj.rotationId=:rotationId AND tj.equipmentId=:equipmentId "
            + " AND tj.isJobCompleted=:isJobCompleted AND (tc.pk.containerId=:containerId OR tc.refContainerId=:containerId)";

    // che jobs retrieval query

    // Following Are Used to retrieve CHE JobList

    public static final String OPUS_CHE_JOBS_RETRIEVAL_QUERY = "SELECT ch.MOVE_KIND,ch.CONTAINER_ID,ch.FROM_LOCATION,ch.TO_LOCATION,ch.EQUIPMENT_ID,ch.ROTATION_ID,"
    		+ " ch.VOYAGE,ch.VESSEL_NAME,ch.JOB_KEY , ch.POC ,ch.SEQ_NO,ch.JOB_STATUS "
			+ " FROM MP_OPUS_CHE_JOB_LIST ch WHERE ch.equipment_id =:equipmentId and "
			+ "ch.CONTAINER_ID NOT IN(select cm.CONTAINER_ID from MP_COMPLETED_MOVES cm,MP_OPUS_CHE_JOB_LIST chj where "
			+ "cm.CONTAINER_ID = chj.CONTAINER_ID AND "
			+ "cm.EQUIPMENT_ID=:equipmentId and cm.MOVE_TYPE=ch.MOVE_KIND and cm.MOVE_TYPE not in(:ignorableMoveTypes)) "
			+ "ORDER BY DECODE(ch.JOB_STATUS, 'P',1 ,'A', 2, 'Q', 3, 'B', 4), ch.PRIORITY, ch.ETW";

    public static final String GET_ARRIVED_ITVS_DETAILS_AT_BLOCK = "select ch.last_updated_by as user_nm , ch.container_id , it.arrived_time ,it.block_no ,it.itv_no"
            + " from mp_itv_waiting_time it , mp_opus_che_job_list ch "
            + " where it.container_no = ch.container_id and it.is_job_completed=:isJobCompleted";

    /**
     * Following Queries are used to process the QC JobList
     * 
     * @UmaMahesh
     */

    private OPUSJobListQueries() {

    }
}
