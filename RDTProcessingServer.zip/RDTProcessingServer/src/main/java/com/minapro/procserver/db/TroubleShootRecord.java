package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * ValueObject holding the troubleshoot record details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_TROUBLESHOOT_RECORD")
public class TroubleShootRecord implements Serializable {

    private static final long serialVersionUID = 457283063540996499L;

    @Id
    @SequenceGenerator(name = "record_gen", sequenceName = "MP_TROUBLESHOOT_RECORD_ID_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "record_gen")
    @Column(name = "RECORD_ID", nullable = false)
    private Integer troubleShootRecordId;

    @Column(name = "CONTAINER_ID")
    private String containerId;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    @Column(name = "MOVE_TYPE")
    private String moveType;

    /*
     * @ManyToOne(fetch = FetchType.EAGER)
     * 
     * @JoinColumn(name = "ITV_ID", referencedColumnName = "EQUIPMENT_ID")
     */
    @Column(name = "ITV_ID")
    private String itvId;

    @Column(name = "CREATED_DATETIME")
    private Date createdDateTime;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_NM")
    private User createdBy;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "RESOLVED_DATETIME")
    private Date resolvedDateTime;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RESOLVED_BY", referencedColumnName = "USER_NM")
    private User resolvedBy;

    @Column(name = "RESOLUTION")
    private String resolution;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TROUBLESHOOT_CODE", referencedColumnName = "EXCEPTION_CODE")
    private ExceptionCodeMaster toubleShootCode;

    @Column(name = "TROUBLESHOOT_DESC")
    private String toubleShootDescription;

   /* TODO - need to check whether any chance of getting troubleshoot request with no trouble shoot area. 
    * If no, uncomment and use the relation
    * 
    * @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TROUBLESHOOT_AREA", referencedColumnName = "TROUBLESHOOT_AREA_ID")*/
    
    @Column(name="TROUBLESHOOT_AREA")
    private String troubleshootArea;

    public Integer getTroubleShootRecordId() {
        return troubleShootRecordId;
    }

    public void setTroubleShootRecordId(Integer troubleShootRecordId) {
        this.troubleShootRecordId = troubleShootRecordId;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getItvId() {
        return itvId;
    }

    public void setItvId(String itvId) {
        this.itvId = itvId;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getResolvedDateTime() {
        return resolvedDateTime;
    }

    public void setResolvedDateTime(Date resolvedDateTime) {
        this.resolvedDateTime = resolvedDateTime;
    }

    public User getResolvedBy() {
        return resolvedBy;
    }

    public void setResolvedBy(User resolvedBy) {
        this.resolvedBy = resolvedBy;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public ExceptionCodeMaster getDamageCode() {
        return toubleShootCode;
    }

    public void setDamageCode(ExceptionCodeMaster damageCode) {
        this.toubleShootCode = damageCode;
    }

    public String getDamageDescription() {
        return toubleShootDescription;
    }

    public void setDamageDescription(String damageDescription) {
        this.toubleShootDescription = damageDescription;
    }

    public String getTroubleshootArea() {
        return troubleshootArea;
    }

    public void setTroubleshootArea(String troubleshootArea) {
        this.troubleshootArea = troubleshootArea;
    }

    @Override
    public String toString() {
        return "TroubleShootRecord [troubleShootRecordId=" + troubleShootRecordId + ", containerId=" + containerId
                + ", rotationId=" + rotationId + ", moveType=" + moveType + ", itvId=" + itvId + ", createdDateTime="
                + createdDateTime + ", createdBy=" + createdBy + ", status=" + status + ", resolvedDateTime="
                + resolvedDateTime + ", resolvedBy=" + resolvedBy + ", resolution=" + resolution + ", damageCode="
                + toubleShootCode + ", damageDescription=" + toubleShootDescription + ", troubleshootArea="
                + troubleshootArea + "]";
    }
}
