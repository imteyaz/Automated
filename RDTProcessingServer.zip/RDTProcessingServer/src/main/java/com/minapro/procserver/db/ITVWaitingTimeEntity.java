package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="MP_ITV_WAITING_TIME")
public class ITVWaitingTimeEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	@EmbeddedId
	ITVWaitingTimePK primaryKey;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ARRIVED_TIME")
	private Date arrivalTime;
	
	@Column(name="IS_JOB_COMPLETED")
	private String isJobCompleted;
	
	@Column(name="JOB_COMPLETED_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date jobCompletedTime;
	
	public ITVWaitingTimePK getprimaryKey() {
		return primaryKey;
	}

	@Override
	public String toString() {
		return "ITVWaitingTimeEntity [arrivalTime=" + arrivalTime
				+ ", isJobCompleted=" + isJobCompleted + ", jobCompletedTime="
				+ jobCompletedTime + ", itvno=" +primaryKey.getITVNo()
				+" Container No:"+primaryKey.getContainerId() +" Block No::"+primaryKey.getBlockId()
				+ "]";
	}

	public void setprimaryKey(ITVWaitingTimePK pk) {
		this.primaryKey = pk;
	}
	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getIsJobCompleted() {
		return isJobCompleted;
	}

	public void setIsJobCompleted(String isJobCompleted) {
		this.isJobCompleted = isJobCompleted;
	}
	public Date getJobCompletedTime() {
		return jobCompletedTime;
	}

	public void setJobCompletedTime(Date jobCompletedTime) {
		this.jobCompletedTime = jobCompletedTime;
	}

	
}
