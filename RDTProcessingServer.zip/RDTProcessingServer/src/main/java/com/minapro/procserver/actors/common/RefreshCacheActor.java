package com.minapro.procserver.actors.common;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.common.BaywiseContainerDetailsRequestEvent;
import com.minapro.procserver.events.common.RefreshVesselEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor class responsible for handling the refresh cache requests from Admin app.
 * 
 * Refreshes the container details for vessel, sends BaywiseContainerDetailsRequestEvent to ESB to fetch the container
 * details for the specified bay. Once the containers are refreshed, the updates done to the bay profile as per
 * container confirmations will be reversed and the bay profile will go back to the original state similar to the vessel
 * operation starting time.
 * 
 * @author Rosemary George
 *
 */
public class RefreshCacheActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RefreshCacheActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof RefreshVesselEvent) {
            RefreshVesselEvent refreshEvent = (RefreshVesselEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, refreshEvent.getRotationID(), "Received refresh vessel event - "
                    + refreshEvent);
            try {
                constructAndSendMessage(refreshEvent);
            } catch (Exception ex) {
                logger.logException("Caught exception while refreshing the vessel ", ex);
            }
        }
    }

    /**
     * Construct the Bay wise container request message and sends to the ESB for fetching the containers present on the
     * specified bay.
     * 
     * @param bayId
     * @param vesselCode
     * @param deckIndicator
     * @param rotationId
     */
    private void constructAndSendMessage(RefreshVesselEvent refreshEvent) {
        BaywiseContainerDetailsRequestEvent containerDetailsRequest = new BaywiseContainerDetailsRequestEvent();
        containerDetailsRequest.setVesselCode(refreshEvent.getVesselCode());
        containerDetailsRequest.setRotationID(refreshEvent.getRotationID());
        containerDetailsRequest.setBayNo(refreshEvent.getBayNo());
        containerDetailsRequest.setRefreshType(refreshEvent.getRefreshType());
        containerDetailsRequest.setUnderDeckIndication(refreshEvent.getDeckIndicator());

        String terminalId = DeviceCommParameters.getInstance().getCommParameter(
                RDTProcessingServerConstants.TERMINAL_KEY);
        ESBQueueManager.getInstance().postMessage(containerDetailsRequest, OPERATOR.COMMON, terminalId);
    }
}
