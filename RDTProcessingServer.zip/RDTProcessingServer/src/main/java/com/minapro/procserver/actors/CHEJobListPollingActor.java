package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.OPERATOR_IN_BREAK;

import java.util.Set;
import java.util.UUID;

import scala.collection.mutable.StringBuilder;
import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.procserver.util.ITVPoolUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS;
public class CHEJobListPollingActor extends UntypedActor {

	private MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobListPollingActor.class);

	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.TERMINAL_KEY);

	@Override
	public void onReceive(Object object) throws Exception {

		logger.logMsg(LOG_LEVEL.INFO, "", "Started OnReceive() Of CHE JobList Polling Actor");

		if(RDTCacheManager.getInstance().getKeepAliveStatus()){
			RDTCacheManager rdtCacheManager = RDTCacheManager.getInstance();
			Set<String> currentLoggedInUsers = rdtCacheManager.getAllocatedUsers();
	
			int loggedInUsers = currentLoggedInUsers != null ? currentLoggedInUsers.size() : 0;
			logger.logMsg(LOG_LEVEL.INFO, "", " No Of Logged In Users:::" + loggedInUsers);
	
			for (String currentUser : currentLoggedInUsers) {
				OPERATOR operator = rdtCacheManager.getUserLoggedInRole(currentUser);
	
				if (operator.equals(OPERATOR.CHE)) {
					String deviceId;
					User user;
	
					if (!rdtCacheManager.isOperatorAvailable(currentUser)) {
						logger.logMsg(LOG_LEVEL.INFO, currentUser, OPERATOR_IN_BREAK);
						continue;
					}
					deviceId = rdtCacheManager.getDeviceMapping(currentUser);
					if (deviceId != null) {
						Device device = rdtCacheManager.getDeviceDetails(deviceId);
						user = rdtCacheManager.getUserDetails(currentUser);
						sendCHEJobListRequest(device, user);
					}
				} else {
					continue;
				}
			}
		} else {
			logger.logMsg(LOG_LEVEL.WARN, "", "Keep alive status is DOWN. Not sending job list polling request");
		}
	}

	private void sendCHEJobListRequest(Device device, User user) {

		logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "started sendCHEJobListRequest(Device device,User user)");

		try {

			Equipment equipment = device.getEquipment();

			if (equipment != null) {
				String userId = user.getUserID();
				String equipmentId = equipment.getEquipmentID();

				String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(userId);
				if (inspectionStatus != null) {

					/*
					 * Condition added to check whether current equipment job list request is in progress stage or not.
					 * If it is in progress stage Ignore current refresh for current equipment.
					 */
					if (EventUtil.isEquipmentJobListReqInProgress(equipmentId)) {
						logger.logMsg(LOG_LEVEL.WARN,userId,
								new StringBuilder(equipmentId).append(EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS)
										.toString());
						return;
					} else {
						logger.logMsg(LOG_LEVEL.INFO, userId,
								new StringBuilder(equipmentId).append(EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS)
										.toString());
						RDTCacheManager.getInstance().setEqJobListReqStatus(equipmentId,
								EquipmentJobListRequestStatus.IN_PROGRESS);
					}

					OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);

					logger.logMsg(LOG_LEVEL.DEBUG, userId, "JobList request(Polling Time Req) for CHE Operator");

					CHEJobListRequestEvent cheJobListRequestEvent = new CHEJobListRequestEvent();
					cheJobListRequestEvent.setUserID(userId);
					cheJobListRequestEvent.setTerminalID(TERMINAL_ID);
					cheJobListRequestEvent.setEventID(UUID.randomUUID().toString());
					cheJobListRequestEvent.setScheduled(true);

					ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
							.getAllocationDetails(userId);

					cheJobListRequestEvent.setEquipmentID(equipment.getEquipmentID());
					cheJobListRequestEvent.setLocation(allocationDetails.getLocation());
					cheJobListRequestEvent.setPassword(user.getPassword());

					// set it back to the original equipmentId
					cheJobListRequestEvent.setEquipmentID(allocationDetails.getEquipmentID());
					ESBQueueManager.getInstance().postMessage(cheJobListRequestEvent, operatorRole,
							cheJobListRequestEvent.getTerminalID());
					ITVPoolUtil.getInstance().createITVPoolRequest(cheJobListRequestEvent);
					/*request for ITV pool for the equipment along with job list as the assigned ITV pool can be changed any time for an equipment
					che case no need to send itv pool request.
					EventUtil.getInstance().requestITVpool(cheJobListRequestEvent, operatorRole);
					ITVPoolUtil.getInstance().createITVPoolRequest(cheJobListRequestEvent);
					*/

				} else {
					logger.logMsg(LOG_LEVEL.INFO, userId,
							" Inspection Status is null,Not sending Joblist request at polling time");
				}
			}
		} catch (Exception ex) {
			logger.logException("Exception Occured In sendCHEJobListRequest(Device device,User user) Reason::", ex);
		}
	}
}
