package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding PLCJobdoneEvent event details
 * 
 * @author Venkataramana.ch
 *
 */

public class PLCJobdoneEvent extends Event implements Serializable {

    private static final long serialVersionUID = -4588735982368072816L;

    private String node;
    private String userId;
    private String spreaderId;

    private String containerWeight;

    public String getUserId() {
        return userId;
    }

    public String getContainerWeight() {
        return containerWeight;
    }

    public void setContainerWeight(String containerWeight) {
        this.containerWeight = containerWeight;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getSpreaderId() {
        return spreaderId;
    }

    public void setSpreaderId(String spreaderId) {
        this.spreaderId = spreaderId;
    }

    @Override
    public String toString() {
        return "PLCJobdoneEvent [node=" + node + ", userId=" + userId + ", spreaderId=" + spreaderId
                + ", containerWeight=" + containerWeight + "]";
    }

}
