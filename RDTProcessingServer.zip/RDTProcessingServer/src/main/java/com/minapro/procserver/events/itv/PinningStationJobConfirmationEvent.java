package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details about pinning station job status.
 * 
 * @author Rosemary George
 *
 */
public class PinningStationJobConfirmationEvent extends Event implements Serializable {
    private static final long serialVersionUID = -8262688296712200072L;

    /**
     * The container ID which has been completed pinning or unpinning
     */
    private String containerID;

    /**
     * Indicates the pinning operation type, whether it was coning/de-coning
     */
    private String pinningType;

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public String getPinningType() {
        return pinningType;
    }

    public void setPinningType(String pinningType) {
        this.pinningType = pinningType;
    }

    @Override
    public String toString() {
        return "PinningStationJobConfirmationEvent [containerID=" + containerID + ", pinningType=" + pinningType
                + ", UserID=" + getUserID() + ", TerminalID=" + getTerminalID() + "]";
    }

}
