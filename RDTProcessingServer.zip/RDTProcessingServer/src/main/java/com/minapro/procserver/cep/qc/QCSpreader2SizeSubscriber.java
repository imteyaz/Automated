package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

public class QCSpreader2SizeSubscriber implements StatementSubscriber {

    public QCSpreader2SizeSubscriber() {
    }

    @Override
    public String getStatement() {
        // QC Container Handling EPL Statement
        return "context EachQC select event1,event2 from pattern[ every event2=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue) "
                + "-> ((event1=EsperPLCEvent(tagName = 'Spreader2Size')) and not (event2=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue=lockedUpTagValue)))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateSpreaderSize(SPREADER2_LOCKEDUP, 2, eventMap);
    }
}
