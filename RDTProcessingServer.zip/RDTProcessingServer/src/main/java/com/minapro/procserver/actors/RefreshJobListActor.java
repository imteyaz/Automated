package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;

import java.util.UUID;

import scala.collection.mutable.StringBuilder;
import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.RefreshJobListRequestEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.tsc.TSCJobListRequestEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor class responsible for handling the refresh job list request from the device
 * 
 * @author Rosemary George
 *
 */
public class RefreshJobListActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RefreshJobListActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof RefreshJobListRequestEvent) {
            RefreshJobListRequestEvent refreshRequestEvent = (RefreshJobListRequestEvent) message;

           final String userId        =  refreshRequestEvent.getUserID();
           String equipmentId   =  refreshRequestEvent.getEquipmentID();
           
            try {
               
            	OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
                
            	logger.logMsg(LOG_LEVEL.INFO, userId,new StringBuilder("Received refresh job list request from device -" ).append(refreshRequestEvent )
            			.append( " for role-" ) .append(operatorRole) .toString() );
                               
            	if (operatorRole.equals(OPERATOR.HC)) {
                    // in case of HC, check for the QC equipment
                     equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(userId);
            	}
                if(EventUtil.isEquipmentJobListReqInProgress(equipmentId)) {
                	logger.logMsg(LOG_LEVEL.WARN,userId,new StringBuilder(equipmentId).
                			append(" Equipment JobList Request Already In  IN_PROGRESS state ,Ignore Current Refresh Request").toString());
                	return;
                } else {
                	logger.logMsg(LOG_LEVEL.INFO,userId,new StringBuilder(equipmentId).
                		append(" Equipment Earlier JobList Request Is Completed ,") .append(" Setting Current JobList  Status As IN_PROGRESS Into Cache").toString());
                	RDTCacheManager.getInstance().setEqJobListReqStatus(equipmentId, EquipmentJobListRequestStatus.IN_PROGRESS);
                }
                
                if (operatorRole.equals(OPERATOR.HC)
                        || operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.ITV)) {
                    sendJobListRequestToESB(refreshRequestEvent, operatorRole);
                }  else if(operatorRole.equals(OPERATOR.CHE)){
                	sendJobListRefreshRequestToESBForCHE(refreshRequestEvent,operatorRole);
                } else if (operatorRole.equals(OPERATOR.TSC)) {
                    generateJobListRequestForTSC(refreshRequestEvent);
                }
            } catch (Exception ex) {
                logger.logException("Caught exception while handling the request: ", ex);
                logger.logMsg(LOG_LEVEL.INFO,userId,new StringBuilder(equipmentId).
                		append(" Exception Raised ,") .append(" Setting Current JobList  Status As Completed To Cache").toString());
                	RDTCacheManager.getInstance().setEqJobListReqStatus(equipmentId, EquipmentJobListRequestStatus.COMPLETED);
            }
        }
    }

    /**
     * Constructs and sends the job list request to master actor for further processing
     * 
     * @param refreshRequestEvent
     */
    private void generateJobListRequestForTSC(RefreshJobListRequestEvent refreshRequestEvent) {
        TSCJobListRequestEvent jobListRequest = new TSCJobListRequestEvent();
        jobListRequest.setEventID(refreshRequestEvent.getEventID());
        jobListRequest.setTerminalID(refreshRequestEvent.getTerminalID());
        jobListRequest.setUserID(refreshRequestEvent.getUserID());
        jobListRequest.setRequestType(NOTIF);

        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(refreshRequestEvent.getUserID());
        jobListRequest.setTsArea(allocationDetails.getLocation());

        getSender().tell(jobListRequest, null);
    }

    /**
     * Construct and post the job list request message to the ESB(other than CHE Operator) 
     * 
     * @param refreshRequestEvent
     * @param role
     */
    private void sendJobListRequestToESB(RefreshJobListRequestEvent refreshRequestEvent, OPERATOR role) {
        JobListRequestEvent requestEvent = new JobListRequestEvent();
        requestEvent.setEquipmentID(refreshRequestEvent.getEquipmentID());
        requestEvent.setUserID(refreshRequestEvent.getUserID());
        requestEvent.setTerminalID(refreshRequestEvent.getTerminalID());
        requestEvent.setEventID(UUID.randomUUID().toString());
        // since the UI expects only notifications
        requestEvent.setScheduled(true);

        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(refreshRequestEvent.getUserID());
        requestEvent.setLocation(allocationDetails.getLocation());
        requestEvent.setRotationId(allocationDetails.getRotationID());

        User user = RDTCacheManager.getInstance().getUserDetails(refreshRequestEvent.getUserID());
        if (user != null) {
            requestEvent.setPassword(user.getPassword());
        }

        if (role.equals(OPERATOR.HC)) {
            // in case of HC, check for the QC equipment
            String qcEquipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                    refreshRequestEvent.getUserID());      
            
            if (qcEquipmentId != null) {
            	String qcUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcEquipmentId);
            	requestEvent.setQcId(qcEquipmentId); 
            	if(qcUser != null){
            		requestEvent.setEquipmentID(qcEquipmentId);             		
            		requestEvent.setUserID(qcUser);
            		role = OPERATOR.QC;
            	}
            }
        }

        ESBQueueManager.getInstance().postMessage(requestEvent, role, refreshRequestEvent.getTerminalID());
    }
    /**
     * Following method is responsible for sending job list refresh request for CHE Operator to ESB.  
     * @param refreshRequestEvent
     * @param role
     */
    private void sendJobListRefreshRequestToESBForCHE(RefreshJobListRequestEvent refreshRequestEvent, OPERATOR role){
    	  
    	logger.logMsg(LOG_LEVEL.INFO, refreshRequestEvent.getUserID()," Started sendJobListRefreshRequestToESBForCHE() For CHE Operator");
    	  
    	try{ 
    		
    	  CHEJobListRequestEvent requestEvent = new CHEJobListRequestEvent();
          requestEvent.setEquipmentID(refreshRequestEvent.getEquipmentID());
          requestEvent.setUserID(refreshRequestEvent.getUserID());
          requestEvent.setTerminalID(refreshRequestEvent.getTerminalID());
          requestEvent.setEventID(UUID.randomUUID().toString());
          requestEvent.setScheduled(true);

          ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                  .getAllocationDetails(refreshRequestEvent.getUserID());
          requestEvent.setLocation(allocationDetails.getLocation());
          
          User user = RDTCacheManager.getInstance().getUserDetails(refreshRequestEvent.getUserID());
          
          if (user != null) {
              requestEvent.setPassword(user.getPassword());
          }

          ESBQueueManager.getInstance().postMessage(requestEvent, role, refreshRequestEvent.getTerminalID());
    	}catch(Exception ex){
    		logger.logException(" Exception Occured In sendJobListRefreshRequestToESBForCHE()::", ex);
    	}
    }
}
