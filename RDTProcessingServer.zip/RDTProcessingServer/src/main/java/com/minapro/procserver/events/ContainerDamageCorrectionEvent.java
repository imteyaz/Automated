package com.minapro.procserver.events;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.util.DeviceCommParameters;

/**
 * ValueObject holding the damage correction details for a particular container from UI
 * @author Rosemary George
 *
 */
public class ContainerDamageCorrectionEvent extends Event implements Serializable{

    private static final long serialVersionUID = 4191244952691791467L;

    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    
    private String containerId;
    
    /**
     * List of updated damage records
     */
    private List<String> updatedRecords;
    
    /**
     * List of Deleted Damage Records
     */
    private List<String> deletedRecords;
    
    /**
     * List of newly added damage records
     */
    private List<String> addedRecords;
    
    private String remarks;
    
    private String moveType;

    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public List<String> getUpdatedRecords() {
        return updatedRecords;
    }

    public void setUpdatedRecords(String updatedRecords) {
        List<String> updatedCodes = new ArrayList<String>();
        
        if(updatedRecords != null && !updatedRecords.isEmpty()){
            for(String code: updatedRecords.split("\\"+ROW_SEPERATOR)){
                updatedCodes.add(code);
            }
        }
        this.updatedRecords = updatedCodes;
    }

    public List<String> getDeletedRecords() {
        return deletedRecords;
    }

    public void setDeletedRecords(String deletedRecords) {
        List<String> deletedCodes = new ArrayList<String>();
        
        if(deletedRecords != null && !deletedRecords.isEmpty()){
            for(String code: deletedRecords.split("\\"+ROW_SEPERATOR)){
                deletedCodes.add(code);
            }
        }
        this.deletedRecords = deletedCodes;
    }

    public List<String> getAddedRecords() {
        return addedRecords;
    }

    public void setAddedRecords(String addedRecords) {
        List<String> addedCodes = new ArrayList<String>();
        
        if(addedRecords != null && !addedRecords.isEmpty()){
            for(String code: addedRecords.split("\\"+ROW_SEPERATOR)){
                addedCodes.add(code);
            }
        }
        this.addedRecords = addedCodes;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

	@Override
	public String toString() {
		return "ContainerDamageCorrectionEvent [containerId=" + containerId + ", updatedRecords=" + updatedRecords
				+ ", deletedRecords=" + deletedRecords + ", addedRecords=" + addedRecords + ", remarks=" + remarks
				+ ", moveType=" + moveType + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}      
}
