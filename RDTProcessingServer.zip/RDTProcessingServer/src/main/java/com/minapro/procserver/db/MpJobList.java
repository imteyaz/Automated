package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
/**
 * The persistent class for the MP_JOB_LIST database table.
 * 
 */
@Entity
@Table(name="MP_JOB_LIST")
public class MpJobList implements Serializable{
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MpJobListPK id;

	@Column(name="EQUIPMENT_ID")
	private String equipmentId;

	@Column(name="FROM_LOCATION")
	private String fromLocation;

	@Column(name="LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Column(name="LAST_UPDATED_DATETIME")
	@Temporal(TemporalType.DATE)
	private Date lastUpdatedDatetime;

	@Column(name="MOVE_TYPE")
	private String moveType;

	@Column(name="REFERENCE_CONTAINER_ID")
	private String referenceContainerId;

	@Column(name="ROTATION_ID")
	private String rotationId;

	@Column(name="SEQ_NO")
	private Double seqNo;

	@Column(name="TERMINAL_ID")
	private String terminalId;

	@Column(name="TO_LOCATION")
	private String toLocation;

	public MpJobList() {
	}

	public MpJobListPK getId() {
		return this.id;
	}

	public void setId(MpJobListPK id) {
		this.id = id;
	}

	public String getEquipmentId() {
		return this.equipmentId;
	}

	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}

	public String getFromLocation() {
		return this.fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	
	public Date getLastUpdatedDatetime() {
		return lastUpdatedDatetime;
	}

	public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
		this.lastUpdatedDatetime = lastUpdatedDatetime;
	}

	public String getMoveType() {
		return this.moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public String getReferenceContainerId() {
		return this.referenceContainerId;
	}

	public void setReferenceContainerId(String referenceContainerId) {
		this.referenceContainerId = referenceContainerId;
	}

	public String getRotationId() {
		return this.rotationId;
	}

	public void setRotationId(String rotationId) {
		this.rotationId = rotationId;
	}

	public Double getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Double seqNo) {
		this.seqNo = seqNo;
	}

	public String getTerminalId() {
		return this.terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getToLocation() {
		return this.toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

}
