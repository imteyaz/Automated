package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key for delay and role mapping table
 * @author Rosemary George
 *
 */
@Embeddable
public class DelayGroupMappingPK implements Serializable{

    private static final long serialVersionUID = -4792988885317158339L;

    @Column(name = "SUB_TYPE")
    private String subType;

    @Column(name = "INT_USER_GRP_ID")
    private Integer roleId;
    
    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public int getIntUserGroupId() {
        return roleId;
    }

    public void setIntUserGroupId(int intUserGroupId) {
        this.roleId = intUserGroupId;
    }

    @Override
    public String toString() {
        return "DelayGroupMappingPK [subType=" + subType + ", intUserGroupId=" + roleId + "]";
    }
}
