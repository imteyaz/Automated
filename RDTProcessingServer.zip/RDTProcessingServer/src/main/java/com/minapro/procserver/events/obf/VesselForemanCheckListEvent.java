package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * Vessel Foreman CheckList Request
 * 
 * @author Prasad Tallapally
 *
 */
public class VesselForemanCheckListEvent extends Event implements Serializable {

    private static final long serialVersionUID = 934000743870914928L;
    // for QC1,QC2,QC3,QC4, we have equipment ID or Vessel No equipment id
    private String checkListType;

    public String getCheckListType() {
        return checkListType;
    }

    public void setCheckListType(String checkListType) {
        this.checkListType = checkListType;
    }

}
