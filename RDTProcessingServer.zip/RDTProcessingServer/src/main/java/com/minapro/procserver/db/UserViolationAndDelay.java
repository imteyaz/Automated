package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the violation details
 * 
 * @author 3123248
 *
 */
@Entity
@Table(name = "MP_USER_VIOLATION_DELAY")
public class UserViolationAndDelay implements Serializable {

    private static final long serialVersionUID = -5345517442621925761L;

    @Id
    @Column(name = "ID", nullable = false)
    private int id;

    @Column(name = "MESSAGE", nullable = false)
    private String message;

    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date markedTime;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_NM")
    private User user;

    @Column(name = "CATEGORY")
    private String category;

    public UserViolationAndDelay() {
    }

    public UserViolationAndDelay(String message, User user, VIOLATION_DELAY_CATEGORY category) {
        this.markedTime = new Date();
        this.message = message;
        this.user = user;
        this.category = category.toString();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getMarkedTime() {
        return markedTime;
    }

    public void setMarkedTime(Date markedTime) {
        this.markedTime = markedTime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public static enum VIOLATION_DELAY_CATEGORY {
        VIOLATION, DELAY
    }

    @Override
    public String toString() {
        return "UserViolationAndDelay [message=" + message + ", markedTime=" + markedTime + ", user=" + user
                + ", category=" + category + "]";
    }
}
