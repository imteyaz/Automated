package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Date;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.common.OperatorMessage;
import com.minapro.procserver.events.common.OperatorMessageResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the operator messages received from ESB. 
 * If the users are logged in to ATOM, sends the message as notification to the user
 * 
 * @author Rosemary George
 *
 */
public class OperatorMessageActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(OperatorMessageActor.class);
	
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
		
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof OperatorMessageResponseEvent){
			OperatorMessageResponseEvent responseEvent = (OperatorMessageResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, responseEvent.getEventID(), "Received operator message response event-" + responseEvent);
			handleOperatorMessageResponse(responseEvent);
		}
	}

	/**
	 * Iterates through the operator message list received from ESB and identifies the user associated with the equipment.
	 * ANd sends the message to user.
	 * 
	 * @param responseEvent
	 */
	private void handleOperatorMessageResponse(OperatorMessageResponseEvent responseEvent) {
		if(responseEvent.getOperatorMessages() != null)	{
			String equipmentId;
			String userId;
			for(OperatorMessage operatorMessage : responseEvent.getOperatorMessages()){
				
				equipmentId = operatorMessage.getEquipmentId();
				if(equipmentId != null){
					userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(equipmentId);
					logger.logMsg(LOG_LEVEL.INFO, equipmentId, "Associated user to equipment=" + userId);
					if(userId == null){
						continue;
					}
					
					sendMessageToUser(userId, operatorMessage.getMessage(), responseEvent.getTerminalID());
				}
			}
		}else {
			logger.logMsg(LOG_LEVEL.DEBUG, responseEvent.getEventID(), "No Operator messages received");
		}
	}
	
	/**
	 * Constructs the alert with the message received from ESB and sends to user
	 * @param userId
	 * @param message
	 * @param terminalId
	 */
	private void sendMessageToUser(String userId, String message, String terminalId){
		try {			
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);
	
			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(NOTIF);
			responseToDevice.append(VALUE_SEPARATOR).append(eventTypeID)
							.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString())					
							.append(VALUE_SEPARATOR).append(new Date())
							.append(VALUE_SEPARATOR).append(message)
							.append(VALUE_SEPARATOR).append(true)
							.append(VALUE_SEPARATOR).append(userId)
							.append(VALUE_SEPARATOR).append(terminalId);

			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), 
					operatorRole, userId);
		} catch (Exception e) {
			logger.logException("Caught exception while processing sendMessageToUser -", e);
		}
	}
}
