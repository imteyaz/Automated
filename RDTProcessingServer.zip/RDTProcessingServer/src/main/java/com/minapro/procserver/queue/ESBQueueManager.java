package com.minapro.procserver.queue;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.minapro.procserver.events.Event;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Singleton Class which handles the configurations for the queue which will be consumed by ESB
 * 
 * @author Rosemary George
 *
 */
public class ESBQueueManager {
    private static final Boolean NON_TRANSACTED = false;
    private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";
    /**
     * Terminal specific out queue which will be read by the ESB
     */
    private static final String DESTINATION_NAME_TERMINAL_OUTQ = "queue/esb_inQ";

    private MessageProducer producer;
    private Session session;
    private Connection connection;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ESBQueueManager.class);

    private static ESBQueueManager instance = new ESBQueueManager();

    private ESBQueueManager() {
    }

    public static ESBQueueManager getInstance() {
        return instance;
    }

    /**
     * Configures the ESB_INQ
     * 
     * @return
     */
    public boolean configureQueue() {

        logger.logMsg(LOG_LEVEL.DEBUG, "", "Configuring the ESB Producer");

        try {
            Context context = new InitialContext();
            ConnectionFactory factory = (ConnectionFactory) context.lookup(CONNECTION_FACTORY_NAME);

            // Terminal1 specific connection
            Destination destination = (Destination) context.lookup(DESTINATION_NAME_TERMINAL_OUTQ);

            connection = factory.createConnection();
            connection.start();

            session = connection.createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);
            producer = session.createProducer(destination);          

        } catch (Exception e) {
            logger.logException("Failed to configure Queue - Caught exception - ", e);
            return false;
        }
        return true;
    }

    /**
     * Posts the message to the ESB_INQ
     * 
     * @param event
     *            - the message to be posted to the ESB
     * @param operator
     *            - to identify operator specific queue on to which the message needs to be posted
     * @param terminal
     *            - to identify the terminal specific queue
     * @return boolean - true if the message is posted successfully, else false
     */
    public boolean postMessage(Event event, OPERATOR operator, String terminal) {
        logger.logMsg(LOG_LEVEL.DEBUG, event.getUserID(), "Posted message-" + event + " Terminal -" + terminal);

        try {
            ObjectMessage message = session.createObjectMessage();
            message.setObject(event);

            message.setStringProperty("eventGenerator", operator.toString());
            producer.send(message);
        } catch (Exception ex) {
            logger.logException("Caught exception while posting the message ", ex);
            return false;
        }

        return true;
    }

    /**
     * Closes all Queue related connections
     */
    public void closeConnection() {
        try {
            producer.close();
            session.close();
            connection.close();
        } catch (Exception e) {
            logger.logException("Caught exception while closing the connection, ignore - ", e);
        }
    }

}
