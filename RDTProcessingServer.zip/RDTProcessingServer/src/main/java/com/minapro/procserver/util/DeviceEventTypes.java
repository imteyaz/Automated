package com.minapro.procserver.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;

import org.infinispan.Cache;

import com.minapro.procserver.cache.RDTCacheContainer;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * <p>Singleton class holding the Event type mappings. <p>
 * 
 * <p>The ID to event type mapping is loaded from the DeviceEventType.properties file. Exposes an API to retrieve the
 * message type using Key. </p>
 * 
 * @author Rosemary George
 *
 */
public class DeviceEventTypes {
    private static DeviceEventTypes instance;

    /**
     * Map containing the evetTypes read from the properties file.
     */
    private Cache<String, String> eventTypes;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DeviceEventTypes.class);

    private DeviceEventTypes() {
        eventTypes = RDTCacheContainer.getCache("DeviceEventTypeCache");
        loadProperties();
    }

    /**
     * Reads the eventType property file and places the entries into the eventTypes map.
     */
    private void loadProperties() {
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream(RDTProcessingServerConstants.DEVICE_EVENT_TYPE_FILE_PATH));
            for (Entry<Object, Object> element : prop.entrySet()) {
                eventTypes.put(element.getKey().toString(), element.getValue().toString());
            }

        } catch (IOException ex) {
            logger.logException("Caught Exception while loading the properties : ", ex);
        }
    }

    public static DeviceEventTypes getInstance() {
        if (instance == null) {
            synchronized (DeviceEventTypes.class) {
                if (instance == null) {
                    instance = new DeviceEventTypes();
                }
            }
        }

        return instance;
    }

    /**
     * Returns the value of the specified KEY from the DeviceEventType.properties file.
     * 
     * @param code
     *            - Properties KEY
     * @return - Value of the specified KEY
     */
    public String getEventType(String code) {
        return eventTypes.get(code);
    }

}
