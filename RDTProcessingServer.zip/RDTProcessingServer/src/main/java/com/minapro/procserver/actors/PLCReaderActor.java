package com.minapro.procserver.actors;

import java.util.List;

import akka.actor.ActorRef;
import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.PLCData;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for reading PLC events from DB and pushing it to ESPER Actor. </p>
 * 
 * @author Venkataramana.ch
 *
 */

public class PLCReaderActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(PLCReaderActor.class);

    private ActorRef esperActor = RDTProcessingServer.getInstance().getEsperActor();

    @Override
    /**
     * Handles  PLCEvents
     */
    public void onReceive(Object message) throws Exception {

        String input = (String) message;
        EsperPLCEvent esperEvent = null;

        if ("READ".equalsIgnoreCase(input)) {
            logger.logMsg(LOG_LEVEL.DEBUG, "", "Polling PLC Table ");
            List<PLCData> plclist = (List<PLCData>) HibernateUtil.loadPLCData();

            try {
                if (!plclist.isEmpty()) {

                    for (PLCData event : plclist) {

                        // Populating Esper event out of received PLC event from DB
                        esperEvent = new EsperPLCEvent();
                        esperEvent.setNode(event.getPlcpk().getNode());
                        esperEvent.setTagName(event.getPlcpk().getTagName());
                        esperEvent.setTagValue(event.getTagValue());
                        esperEvent.setTagTime(event.getPlcpk().getTagTime());

                        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(
                                event.getPlcpk().getNode());

                        // Check whether user is logged in or not and unsubscribed from PLC events
                        if (userId != null && !RDTPLCCacheManager.getInstance().hasUserStoppedPLC(userId)) {
                            // pushing events to Esper
                            esperActor.tell(esperEvent, null);
                        }
                    }
                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, "", "No events received during this Iteration ");
                }
            } catch (Exception ex) {
                logger.logException("Caught exception while processing PLCReaderActor -", ex);
            }
        } else if ("echo".equals(message)) {
            logger.logMsg(LOG_LEVEL.DEBUG, "", "ECHO");
        }
    }
}
