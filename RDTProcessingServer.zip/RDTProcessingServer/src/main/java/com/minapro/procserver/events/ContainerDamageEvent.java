package com.minapro.procserver.events;

import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the details about the container damage notification
 * 
 * @author Rosemary George
 *
 */
public class ContainerDamageEvent extends Event implements Serializable {
    private static final long serialVersionUID = 5383485992912556092L;

    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);
    private static final String COLOUMN_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            COLUMN_SEPERATOR_KEY);
    
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerDamageEvent.class);

    /**
     * Contains all the damage details recorded
     */
    private List<DamageDetails> damageDetails;

    private String moveType;
    
    private String rotationId;

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public List<DamageDetails> getDamageDetails() {
        return damageDetails;
    }

    public void setDamageDetails(List<DamageDetails> damageDetails) {
        this.damageDetails = damageDetails;
    }

    /**
     * Parses the damageDetails to extract each container damage details
     * containerId^damageCode1|damageCode2|damageCode3^
     * TSArea^ITVId$containerId^damageCode1|damageCode2|damageCode3^TSArea^ITVId
     * 
     * @param damageDetails
     */
    public void setDamageDetails(String damageDetails) {
        List<DamageDetails> damageDetail = new ArrayList<DamageDetails>();

        try {
            String[] damageList = damageDetails.split("\\" + COLOUMN_SEPERATOR);

            String[] eachContainerDamageDetails;
            DamageDetails eachDetail;
            for (String damage : damageList) {
                eachContainerDamageDetails = damage.split("\\" + ITEM_SEPERATOR);
                eachDetail = new DamageDetails();
                eachDetail.setContainerID(eachContainerDamageDetails[0]);
                eachDetail.setDamageCodes(eachContainerDamageDetails[1].split("\\" + ROW_SEPERATOR));
                if (eachContainerDamageDetails.length >= 3) {
                	eachDetail.setItvId(eachContainerDamageDetails[2]);
                }                
                if (eachContainerDamageDetails.length >= 4) {
                    eachDetail.setTroubleShootAreaId(eachContainerDamageDetails[3]);
                }

                damageDetail.add(eachDetail);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while setting Damage Information:", ex);
        }

        this.damageDetails = damageDetail;
    }

    public String getRotationId() {
		return rotationId;
	}

	public void setRotationId(String rotationId) {
		this.rotationId = rotationId;
	}

	@Override
	public String toString() {
		return "ContainerDamageEvent [damageDetails=" + damageDetails + ", moveType=" + moveType + ", rotationId="
				+ rotationId + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}	    
}
