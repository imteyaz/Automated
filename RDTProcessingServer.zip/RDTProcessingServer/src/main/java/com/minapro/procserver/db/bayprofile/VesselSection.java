package com.minapro.procserver.db.bayprofile;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Defines the sections for the vessel
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_SECT_SPM")
public class VesselSection {
    /**
     * Composite Primary key - vesselNo + section No
     */
    @EmbeddedId
    private SectionPK pk = new SectionPK();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false)
    private Vessel vessel;

    @Column(name = "DK_UNDK_IND")
    private String deckOrUnderDeck;

    @Column(name = "SECT_TYPE")
    private String sectionType;

    @Column(name = "HATCHLESS_FLG")
    @org.hibernate.annotations.Type(type = "yes_no")
    private boolean hatchlessFlag;

    @Column(name = "DIST_FM_FORE")
    private float distanceFromFore;

    @Column(name = "DIST_FM_FORE_UOM")
    private String distanceFromForeUOM;

    @Column(name = "BAY_NOTE")
    private String bayNote;

    public SectionPK getPk() {
        return pk;
    }

    public void setPk(SectionPK pk) {
        this.pk = pk;
    }

    public String getDeckOrUnderDeck() {
        return deckOrUnderDeck;
    }

    public void setDeckOrUnderDeck(String deckOrUnderDeck) {
        this.deckOrUnderDeck = deckOrUnderDeck;
    }

    public String getSectionType() {
        return sectionType;
    }

    public void setSectionType(String sectionType) {
        this.sectionType = sectionType;
    }

    public boolean getHatchlessFlag() {
        return hatchlessFlag;
    }

    public void setHatchlessFlag(boolean hatchlessFlag) {
        this.hatchlessFlag = hatchlessFlag;
    }

    public float getDistanceFromFore() {
        return distanceFromFore;
    }

    public void setDistanceFromFore(float distanceFromFore) {
        this.distanceFromFore = distanceFromFore;
    }

    public String getDistanceFromForeUOM() {
        return distanceFromForeUOM;
    }

    public void setDistanceFromForeUOM(String distanceFromForeUOM) {
        this.distanceFromForeUOM = distanceFromForeUOM;
    }

    public String getBayNote() {
        return bayNote;
    }

    public void setBayNote(String bayNote) {
        this.bayNote = bayNote;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public void setVessel(Vessel vessel) {
        this.vessel = vessel;
    }

    @Transient
    public int getSectionNo() {
        return pk.getSectionNo();
    }

    public void setSectionNo(int sectionNo) {
        pk.setSectionNo(sectionNo);
    }
}
