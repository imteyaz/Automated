package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.tsc.TSCJobListActor;
import com.minapro.procserver.events.tsc.TSCJobListRequestEvent;

/**
 * Actor supervising all troubleshoot clerk related functionalities.
 * 
 * @author Rosemary George
 *
 */
public class TSCSupervisorActor extends UntypedActor {

    /**
     * Actor reference for handling all the joblist requests for troubleshoot clerk
     */
    private ActorRef tscJobListActor = getContext().actorOf(
            Props.create(TSCJobListActor.class).withRouter(new FromConfig()), "tscJobListActor");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {
                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof TSCJobListRequestEvent) {
            tscJobListActor.tell(message, getSelf());
        } else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, getSelf());
        }
    }
}
