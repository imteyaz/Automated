package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import akka.actor.ActorRef;

import com.espertech.esper.client.EventBean;
import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.plc.DelayRecordingEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/*
 * <p> Class responsible for detecting delay recording  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCDelayRecordingSubscriber implements StatementSubscriber {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QCDelayRecordingSubscriber.class);

    private ActorRef masterActor;

    public QCDelayRecordingSubscriber() {
        this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    public String getStatement() {

        // QC Delay Recording EPL Statement
        return "context EachQCUser select * from pattern [every ((event=ContainerMoveEvent) or (event1=CancelInspectionEvent) or (event2=CheckListInspectionEvent))"
                + " -> ((timer:interval(delayTime sec)) and not ContainerMoveEvent)]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EventBean> eventMap) {
    	Set<String> patternKeys = eventMap.keySet();
    	Event delayEvent = (Event)eventMap.get(patternKeys.iterator().next()).getUnderlying();

        logger.logMsg(LOG_LEVEL.DEBUG, "QC DELAY", "Received event " + delayEvent);
        
        SimpleDateFormat formatter = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
        String dateString = formatter.format(new Date());
        long delayTime = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(QC_DELAY_RECORDING));

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(delayEvent.getEquipmentID());

        if (userId != null) {

            StringBuilder sb = new StringBuilder();
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);
            sb.append("\n* DELAY RECORDING DETECTED OF USER " + delayEvent.getUserID() + " ON " + delayEvent.getEquipmentID());
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);

            logger.logMsg(LOG_LEVEL.INFO, userId, sb.toString());
            logger.logMsg(LOG_LEVEL.INFO, userId, "Received event :" + delayEvent);

            // Sending delay Recording Event to Master Actor
            DelayRecordingEvent delayRecordingEvent = new DelayRecordingEvent();
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(DELAY_RECORDING);
            delayRecordingEvent.setEventType(eventTypeID);
            delayRecordingEvent.setTimeStamp(dateString);
            delayRecordingEvent.setEventID(UUID.randomUUID().toString());
            delayRecordingEvent.setEquipmentID(delayEvent.getEquipmentID());
            delayRecordingEvent.setUserID(delayEvent.getUserID());
            delayRecordingEvent.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));

            Date currentTime = new Date();
            Date loggedInTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);

            long elapsedTimeInMilliSec = currentTime.getTime() - loggedInTime.getTime();
            long elapsedTimeInSec = elapsedTimeInMilliSec / 1000;

            logger.logMsg(LOG_LEVEL.INFO, userId, "Logging in Time :" + formatter.format(loggedInTime));
            logger.logMsg(LOG_LEVEL.INFO, userId, "Elapsed Time since Login:" + elapsedTimeInSec);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Delay Time since lastMove:" + delayTime);

            if (elapsedTimeInSec > delayTime) {
                logger.logMsg(LOG_LEVEL.INFO, userId, "Sending Delay Recording Alert to User");
                masterActor.tell(delayRecordingEvent, null);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId,
                        "User logged in elapsed time is less than the Delay time: skip sending Delay Recording");
            }
        }
    }
}