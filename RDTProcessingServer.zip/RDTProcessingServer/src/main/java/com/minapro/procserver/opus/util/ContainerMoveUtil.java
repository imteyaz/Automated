package com.minapro.procserver.opus.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.JOBLIST_VALIDATION_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REFERENCE_CONTAINER_SEPERATOR;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.CellGrid;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.opus.joblist.OpusQCJobListDAO;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.SealBrokenRequestEvent;
import com.minapro.procserver.events.hc.ITVSwapRequestEvent;
import com.minapro.procserver.events.hc.SwapContainerPosition;
import com.minapro.procserver.events.itv.ITV;
import com.minapro.procserver.events.itv.ITVLeftEvent;
import com.minapro.procserver.events.itv.ITVPerformanceEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.ITVWaitingTimeCalculatorService;
import com.minapro.procserver.util.LocalizationUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ContainerMoveUtil {

	private MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerMoveUtil.class);
	
	private static final ContainerMoveUtil  INSTANCE  = new ContainerMoveUtil();
	
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
	            VALUE_SEPERATOR_KEY);
	 private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
				.getCommParameter(ITEM_SEPERATOR_KEY);
   private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
	
   private static final String AFT = "AFT";
   private static final String IGNORE_MOVE_TYPES="IGNORE_MOVE_TYPES";
   
   private ContainerMoveUtil() { }
	
   public static ContainerMoveUtil getInstance() {
		return INSTANCE;
	}
   
	 /**
     * Sends the notification to all the ITVs involved in the container move operation, indicating the container ID
     * which has been placed on to the ITV. The container attributes like POD, weight, from and to location etc are also
     * included in the notification.
     * 
     * @param moveEvent
     */
    public void generateContainerPlacedMessageToITV(ContainerMoveEvent moveEvent, OPERATOR operatorRole) {

        logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
                "Generating Container Placed messages to all ITVS involved");

        ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
                moveEvent.getUserID(), moveEvent.getEquipmentID());

        List<String> itvIds = moveEvent.getToLocations();
        logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "ITVs Involved " + itvIds);

        if (itvIds != null && !itvIds.isEmpty()) {

            String containerId;
            JobListContainer jobContainer;
            Map<String, List<JobListContainer>> itvToContainers = new HashMap<String, List<JobListContainer>>();
            List<JobListContainer> containersOnItv;

            // Club twin container details in case of twin handling
            for (int i = 0; i < moveEvent.getContainerIDs().size(); i++) {
                containerId = moveEvent.getContainerIDs().get(i);
                if(operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)){
                    jobContainer = jobList.get(containerId+moveEvent.getMoveType());
                }else{
                	//TODO:Need to check this case once.
                    jobContainer = jobList.get(containerId+moveEvent.getMoveType());
                }

                containersOnItv = itvToContainers.get(itvIds.get(i));
                if (containersOnItv == null) {
                    containersOnItv = new ArrayList<JobListContainer>();
                    itvToContainers.put(itvIds.get(i), containersOnItv);
                }
                containersOnItv.add(jobContainer);
                
                logger.logMsg(LOG_LEVEL.INFO, itvIds.get(i), "Removing from Fetch Cache - " + containerId+moveEvent.getMoveType());
                RDTCacheManager.getInstance().removeFetchContainerMappingToITV(containerId+moveEvent.getMoveType());
            }

            // Converting List to Set to get the unique ITV Ids
            Set<String> itvEqmts = new HashSet<String>(itvIds);
            String itvUser = null;
            for (String itvId : itvEqmts) {

                itvUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(itvId);
                if (itvUser != null) {

                    // Add to ITV current location map
                    if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)) {
                    	logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID(),new StringBuilder(" Adding Data Into setITVCurrentLocation Cache ")
                    	.append(" ITV Id::").append(itvId).append(" Location Is::").append(moveEvent.getEquipmentID()).toString());
                        RDTCacheManager.getInstance().setITVCurrentLocation(itvId, moveEvent.getEquipmentID());
                    } else if (operatorRole.equals(OPERATOR.CHE)) {
                        
                      //Code Added by UmaMahesh For ITV Waiting Time Calculation.
                        String fromLocation  = moveEvent.getFromLocations()!=null ? moveEvent.getFromLocations().get(0) : null ;
                        
                        logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID(),"Before Calling ITV Arrived Updated Method From Location::"+fromLocation);
                      
                        if(fromLocation!=null){
                        	
                        	logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID(),new StringBuilder(" Adding Data Into setITVCurrentLocation Cache ")
                        	.append(" ITV Id::").append(itvId).append(" Location Is::").append(fromLocation.substring(0,3)).toString());
                        	
                        	RDTCacheManager.getInstance().setITVCurrentLocation(itvId, fromLocation.substring(0,3));
                        	ITVWaitingTimeCalculatorService.updateArrivedITVSRecord(moveEvent.getContainerIDs(), itvId, fromLocation);
                        } else {
                        	logger.logMsg(LOG_LEVEL.ERROR,moveEvent.getUserID(),new StringBuilder(" FromLocation Is Null In Container Move Event ").
                        			append(moveEvent.toString()).toString());
                        }
                    }

                    List<JobListContainer> jobListContainers = itvToContainers.get(itvId);
                    logger.logMsg(LOG_LEVEL.DEBUG, itvUser, "Containers on ITV :" + jobListContainers);
                    checkPinningStationRequirementAndSendDriveInstruction(jobListContainers, itvUser, itvId,
                            moveEvent.getTerminalID(), moveEvent.getUserID(), operatorRole);

                    if(DSCH.equals(moveEvent.getMoveType()) && OPERATOR.QC.equals(operatorRole)){
                    	logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "QC performed DSCH operation. Wait for HC confirmation");
					}else {
						ITVLeftEvent itvLeft = new ITVLeftEvent();
                        itvLeft.setTerminalID(moveEvent.getTerminalID());
                        itvLeft.setItvID(itvId);

                        EventUtil.getInstance().sendITVLeftMessageToCranes(itvLeft);
					}                    
                }
            }
        }
    }
    
    public void checkPinningStationRequirementAndSendDriveInstruction(List<JobListContainer> containers,
            String itvUser, String itvId, String terminalID, String movePerformedUser, OPERATOR movePerformedUserRole) {

        if (containers != null) {

            for (JobListContainer container : containers) {
                if (container != null) {
                    logger.logMsg(LOG_LEVEL.INFO, itvUser,
                            "Checking the Pinning requirement for the current container placed on ITV - " + container);
                    String cellLocation = "";
                    if (movePerformedUserRole.equals(OPERATOR.QC) || movePerformedUserRole.equals(OPERATOR.HC)) {
                        cellLocation = container.getFromLocation();
                    } else if (movePerformedUserRole.equals(OPERATOR.CHE)) {
                        // verify whether we get vessel position here or ITV id.
                        cellLocation = container.getToLocation();
                    }

                    CellGrid cell = RDTVesselProfileCacheManager.getInstance().getCellDetails(cellLocation,
                            movePerformedUser);
                    if (cell != null && cell.isPinningRequired()) {
                        /* do it here or move to ITV drive instruction???? */
                        RDTCacheManager.getInstance().setPinningRequiredStatus(itvUser, true);
                    } else {
                        RDTCacheManager.getInstance().setPinningRequiredStatus(itvUser, false);
                    }

                }
            }
        }
    }
    
    
    /**
     * Method is responsible for creating response message for container remove event from any of the operator like
     * HC,QC,OBF.
     * 
     * @param moveEvent
     * @param userId
     *            current logged in user
     * @return constructed message
     */
    public StringBuilder generateRemoveJobMessage(ContainerMoveEvent moveEvent, String userId) {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" generateRemoveJobMessage()").toString());

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_DONE);

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(RDTProcessingServerConstants.JOB_DONE);

        StringBuilder responseToDevice;
        // build the response to the device
        responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);

        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            if ("UserID".equalsIgnoreCase(msgFields.get(i))) {
                responseToDevice.append(userId);
            } else if ("containerIDs".equalsIgnoreCase(msgFields.get(i))) {
                List<String> containerIds = moveEvent.getContainerIDs();
                for (String container : containerIds) {
                    responseToDevice.append(container).append(ITEM_SEPERATOR).append(moveEvent.getMoveType()).append(ROW_SEPARATOR);
                }
            } else if ("ToLocations".equalsIgnoreCase(msgFields.get(i))) {
                List<String> toLocations = moveEvent.getToLocations();
                for (String to : toLocations) {
                    responseToDevice.append(to).append(ROW_SEPARATOR);
                }
            } else if ("OperationType".equalsIgnoreCase(msgFields.get(i))) {
                if (moveEvent.isAutomaticFlag()) {
                    responseToDevice.append("A");
                } else {
                    responseToDevice.append("M");
                }
            } else {
                EventUtil.getInstance().getEventParameter(moveEvent, msgFields.get(i), responseToDevice);
            }
        }

        return responseToDevice;
    }

    /**
     * Sends message to the ITV indicating that the container has been picked from ITV.Container move event can contain
     * maximum of 4 containers, so more than one ITV may be involved.
     * 
     * @param moveEvent
     */
    public void generateContainerPickedMessageToITV(ContainerMoveEvent moveEvent) {
        String itvUser = null;
        String prevItvId = null;
        StringBuilder responseToDevice;

        logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
                "Generating Container Picked from ITV messages to all ITVS involved");

        // Container move event can contain upto 4 container details, so different ITVs may be present
        int itvIndex = 0;
        String containerId;
        ITVPerformanceEvent itvPerformanceEvent;
    
        try {
			for (String itvId : moveEvent.getFromLocations()) {
			    if (prevItvId == null || !prevItvId.equals(itvId)) {
			  
			    	itvUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(itvId);
			        
			        logger.logMsg(LOG_LEVEL.INFO,itvUser,new StringBuilder(" Itv Id::").append(itvId).append(" ITV User::").append(itvUser).toString());
			        
			        if (itvUser != null) {
			            responseToDevice = generateRemoveJobMessage(moveEvent, itvUser);
			            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
			                    OPERATOR.ITV, moveEvent.getTerminalID());
			            
			            OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(moveEvent.getUserID());
			            /*
			             * Added by UmaMahesh for calculating ITV  Waiting Time..
			             */
			            if(operator.equals(OPERATOR.CHE)){
			            	
			            	String toLocation = moveEvent.getToLocations().get(0);
			            	
			            	if(toLocation != null){
			            		
			            		ITVWaitingTimeCalculatorService.updateArrivedITVSRecord(moveEvent.getContainerIDs(),itvId,toLocation);
			            	
			            		toLocation = toLocation.length()==3 ? toLocation.substring(0,3) : (toLocation.length()==4 ? toLocation.substring(0,4) : toLocation);
			            		
			            		RDTCacheManager.getInstance().setITVCurrentLocation(itvId, toLocation);
			            	}
			            }else if (operator.equals(OPERATOR.QC) || operator.equals(OPERATOR.HC)) {
			            	logger.logMsg(LOG_LEVEL.INFO,moveEvent.getUserID(),new StringBuilder(" Adding Data Into Set ITV Current Location").
			            			append(" Key ITV Id::").append(itvId).append(" Value Location  Id::").append(moveEvent.getEquipmentID()).toString());
			                RDTCacheManager.getInstance().setITVCurrentLocation(itvId, moveEvent.getEquipmentID());
			            }
			            //UmaMahesh added code ended
			        }
			        prevItvId = itvId;
			    }

			    containerId = moveEvent.getContainerIDs().get(itvIndex);
			    if (itvId != null && containerId != null) {
			        RDTCacheManager.getInstance().removeItvToCntrDetails(itvId, containerId);
			    }
			    itvIndex++;
			    if (itvUser != null) {

			        itvPerformanceEvent = new ITVPerformanceEvent();
			        itvPerformanceEvent.setEquipmentID(itvId);
			        itvPerformanceEvent.setUserID(itvUser);
			        RDTProcessingServer.getInstance().getMasterActor().tell(itvPerformanceEvent, null);
			    }
			}
			updateITVCompletedJobs(moveEvent);
		} catch (Exception e) {
			logger.logException("Exception Occured In generateContainerPickedMessageToITV Reason-", e);
		}
    }
    
    /**
     * Adds the move performed by user to the completed move cache. If the move is already completed and available in
     * cache, the same is updated
     * 
     * @param user
     * @param containerIds
     */
    public void updateCompletedMoves(User user, ContainerMoveEvent moveEvent, String equipmentId, OPERATOR role) {
        ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(user.getUserID());

        JobListContainer jobListContainer;
        ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(user.getUserID(),
                equipmentId);

        Map<String, CompletedContainerMoves> completedMoves = RDTCacheManager.getInstance().getCompletedJobs(
                allocationEvent.getRotationID(), equipmentId);
        
        //in case of MI, MO, AH and RH jobs, do not update, always insert new record into DB
        boolean isAlwaysInsert = DeviceCommParameters.getInstance().getCommParameter(IGNORE_MOVE_TYPES).contains(moveEvent.getMoveType());

        CompletedContainerMoves completedContainer = null;
        for (int i = 0; i < moveEvent.getContainerIDs().size(); i++) {
            if (completedMoves != null) {
                completedContainer = completedMoves.get(moveEvent.getContainerIDs().get(i).concat(moveEvent.getMoveType()));
            }

            if (completedContainer == null || isAlwaysInsert) {
                completedContainer = new CompletedContainerMoves();
                completedContainer.setContainerId(moveEvent.getContainerIDs().get(i));
                completedContainer.setExceptionOccured("N");
                completedContainer.setMoveType(moveEvent.getMoveType());

                if(role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC) || role.equals(OPERATOR.CHE)){
                    jobListContainer = jobList.get(moveEvent.getContainerIDs().get(i)+moveEvent.getMoveType());
                }else{
                    jobListContainer = jobList.get(moveEvent.getContainerIDs().get(i));
                }
                if (jobListContainer != null) {
                    StringBuilder referenceContainers = new StringBuilder();
                    if (jobListContainer.getTandemContainerIDs() != null) {
                        for (int j = 0; j < jobListContainer.getTandemContainerIDs().length; j++) {
                            referenceContainers.append(jobListContainer.getTandemContainerIDs()[j]).append(
                                    REFERENCE_CONTAINER_SEPERATOR);
                        }
                    } else if (jobListContainer.getTwinContainerId() != null
                            && !"".equals(jobListContainer.getTwinContainerId())) {
                        referenceContainers.append(jobListContainer.getTwinContainerId());
                    }
                    //added vessel and voyage details.
                    completedContainer.setVesselName(jobListContainer.getVesselName());
                    completedContainer.setVoyage(jobListContainer.getVoyage());
                    completedContainer.setReferenceContainers(referenceContainers.toString());
                    completedContainer.setJobKey(jobListContainer.getJobKey());
                }

                if(moveEvent.getToLocations() != null && moveEvent.getToLocations().size() > i){
                	completedContainer.setToLocation(moveEvent.getToLocations().get(i));
                }
                if(moveEvent.getFromLocations() != null && moveEvent.getFromLocations().size() > i){
                	completedContainer.setFromLocation(moveEvent.getFromLocations().get(i));
                }else {
                	completedContainer.setFromLocation("");
                }
                completedContainer.setIsAutomaticConfirmation(moveEvent.isAutomaticFlag() ? "Y" : "N");
                completedContainer.setIsSealOk(getSealInfo(moveEvent.getSealOk(), i, completedContainer.getContainerId(), moveEvent.getMoveType()));
                if(moveEvent.getDoorDirection() != null){
                	completedContainer.setDoorDirection(moveEvent.getDoorDirection().get(i));   
                }else {
                	completedContainer.setDoorDirection(AFT); 
                }
                if(moveEvent.getPosition() != null){
                	completedContainer.setPosition(moveEvent.getPosition().get(i));
                }else if(jobListContainer != null){
                	completedContainer.setPosition(jobListContainer.getPosition());
                }
                saveToDatabase(user, allocationEvent.getRotationID(), completedContainer, equipmentId);
            } else {
            	if(moveEvent.getToLocations() != null && moveEvent.getToLocations().size() > i){
            		completedContainer.setToLocation(moveEvent.getToLocations().get(i));
            	}
            	if(moveEvent.getFromLocations() != null && moveEvent.getFromLocations().size() > i){
            		completedContainer.setFromLocation(moveEvent.getFromLocations().get(i));
            	}else {
                	completedContainer.setFromLocation("");
                }
            	
                completedContainer.setIsAutomaticConfirmation("N");
                completedContainer.setIsSealOk(getSealInfo(moveEvent.getSealOk(), i, completedContainer.getContainerId(), moveEvent.getMoveType()));                
                if(moveEvent.getDoorDirection() != null){
                	completedContainer.setDoorDirection(moveEvent.getDoorDirection().get(i));                	
                }else {
                	completedContainer.setDoorDirection(AFT); 
                }
                
                if(moveEvent.getPosition() != null){
                	completedContainer.setPosition(moveEvent.getPosition().get(i));
                }
                Container container = RDTCacheManager.getInstance().getContainerDetails(completedContainer.getContainerId(), completedContainer.getMoveType());
                if(container != null){
                	container.setDoorDirection(completedContainer.getDoorDirection());
                }
                JournalEvent journal = new JournalEvent(completedContainer, UPDATETYPE.UPDATE);
                
                RDTProcessingServer.getInstance().getMasterActor().tell(journal, null);
            }

            RDTCacheManager.getInstance().addToCompletedJobs(completedContainer, user.getUserID(),
                    allocationEvent.getRotationID(), equipmentId);
            completedContainer = null;
            //Added By UmaMahesh 
            if(role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC)){
            	OpusQCJobListDAO.retrieveTwinTandemJobAndUpdateStatus(moveEvent.getContainerIDs().get(0), 
            			allocationEvent.getRotationID(),moveEvent.getTerminalID(),equipmentId);
            }
        }
    }
    
    /**
     * Retrieves the seal detail for the specified position. If no seal information is available returns null.
     * 
     * @param sealDetails
     * @param position
     * @return
     */
    public String getSealInfo(List<String> sealDetails, int position, String containerId, String moveType) {
        if (sealDetails != null && sealDetails.size() > position) {
            return sealDetails.get(position);
        }
        
        Container container = RDTCacheManager.getInstance().getContainerDetails(containerId, moveType);
       
        return container != null ? container.getIsEmpty() ? "N" : "Y" : "";
      
    } 
    
    
    /**
     * Save the completed move to the database
     * 
     * @param user
     * @param rotationID
     * @param container
     */
    public void saveToDatabase(User user, String rotationID, CompletedContainerMoves completedMove, String equipmentId) {
        completedMove.setUser(user);
        completedMove.setMoveTime(new Date());
        completedMove.setRotationId(rotationID);
        completedMove.setEquipment(equipmentId);

        Container container = RDTCacheManager.getInstance().getContainerDetails(completedMove.getContainerId(), completedMove.getMoveType());
        if (container != null) {
            completedMove.setCategory(container.getCategory());
            completedMove.setContainerId(container.getContainerID());
            completedMove.setIsoCode(container.getIsoCode());
            completedMove.setPod(container.getPod());
            completedMove.setRemarks(EventUtil.getInstance().getContainerIcon(container));
            completedMove.setIsEmpty(String.valueOf(container.getIsEmpty()));
            completedMove.setWeight(container.getWeight());
            completedMove.setHazardousCode(container.getHazardousCode());
            container.setDoorDirection(completedMove.getDoorDirection());
            completedMove.setDamaged(container.getIsDamaged());
        }else {
        	Container contr = new Container();
        	contr.setContainerID(completedMove.getContainerId());
        	contr.setDoorDirection(completedMove.getDoorDirection());
        	RDTCacheManager.getInstance().addContainer(contr, completedMove.getMoveType());
        }

        JournalEvent journal = new JournalEvent(completedMove, UPDATETYPE.ADD);
        RDTProcessingServer.getInstance().getMasterActor().tell(journal, null);
    }
    
    public void updateITVCompletedJobs(ContainerMoveEvent moveEvent) {

        logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "updating the ITV completed jobs");
        User user;
        CompletedContainerMoves completedContainer = new CompletedContainerMoves();

        if(moveEvent.getFromLocations() == null || moveEvent.getFromLocations().isEmpty()){
        	return;
        }
        
        String itvUser;
        for (int i = 0; i < moveEvent.getContainerIDs().size(); i++) {
            itvUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(moveEvent.getFromLocations().get(i));
            if (itvUser == null) {
                continue;
            }

            String containerId = moveEvent.getContainerIDs().get(i);
            Container container = RDTCacheManager.getInstance().getContainerDetails(moveEvent.getContainerIDs().get(i), moveEvent.getMoveType());
            if (container != null) {
                completedContainer.setCategory(container.getCategory());
                completedContainer.setIsoCode(container.getIsoCode());
                completedContainer.setPod(container.getPod());
                completedContainer.setRemarks(EventUtil.getInstance().getContainerIcon(container));
                completedContainer.setIsEmpty(String.valueOf(container.getIsEmpty()));
                completedContainer.setWeight(container.getWeight());
            }
            completedContainer.setContainerId(containerId);
            completedContainer.setEquipment(moveEvent.getFromLocations().get(i));
            completedContainer.setMoveType(moveEvent.getMoveType());
            completedContainer.setFromLocation(moveEvent.getFromLocations().get(i));
            completedContainer.setToLocation(moveEvent.getToLocations().get(i));
            completedContainer.setExceptionOccured("N");
            completedContainer.setIsSealOk(getSealInfo(moveEvent.getSealOk(), i, completedContainer.getContainerId(), moveEvent.getMoveType()));
            completedContainer.setIsAutomaticConfirmation(moveEvent.isAutomaticFlag() ? "Y" : "N");
            user = RDTCacheManager.getInstance().getUserDetails(itvUser);
            completedContainer.setUser(user);
            completedContainer.setMoveTime(new Date());

            JournalEvent journal = new JournalEvent(completedContainer, UPDATETYPE.ADD);           
           RDTProcessingServer.getInstance().getMasterActor().tell(journal, null);
        }
    }    
    
    public void sendITVJoblistRequest(ContainerMoveEvent moveEvent, OPERATOR operatorRole) {
    	try{
	        List<String> itvIds = null;
	        if (LOAD.equals(moveEvent.getMoveType())) {
	            if (operatorRole.equals(OPERATOR.CHE)) {
	                itvIds = moveEvent.getToLocations();
	            } else if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)) {
	                itvIds = moveEvent.getFromLocations();
	            }
	        } else if (DSCH.equals(moveEvent.getMoveType())) {
	            if (operatorRole.equals(OPERATOR.CHE)) {
	                itvIds = moveEvent.getFromLocations();
	            } else if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.HC)) {
	                itvIds = moveEvent.getToLocations();
	            }
	        }
	
	        if (itvIds != null && !itvIds.isEmpty()) {
	            Set<String> itvEqmts = new HashSet<String>(itvIds);
	            for (String itvId : itvEqmts) {
	                String itvUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(itvId);
	                if (itvUser != null && !RDTCacheManager.getInstance().getPinningRequiredStatus(itvUser)) {
	                    logger.logMsg(LOG_LEVEL.INFO, itvUser, "Getting Next Drive instruction");
	                    EventUtil.getInstance().sendITVJoblistRequestToESB(itvId, itvUser, moveEvent.getTerminalID());
	                }
	            }
	        }
    	}catch (Exception ex){
    		logger.logException("Caught exception in sendITVJoblistRequest" , ex);
    	}
    }
    
    /**
     * validating the ITV location - 
     * checks whether the toLocation is present in the ITV pool, or in the ITV equipment list or is it 01
     * 
     * @param toLocation
     * @return
     */

    public boolean getValidITVLocation(String toLocation, String equipmentId) {
        logger.logMsg(LOG_LEVEL.INFO, equipmentId, "Validating the ITV Location- " + toLocation);

        Set<ITV> itvList = RDTCacheManager.getInstance().getAssignedITVs(equipmentId);

        if (itvList != null) {
            for (ITV itv : itvList) {
                if ((itv.getItvId()).equalsIgnoreCase(toLocation)) {
                    return true;
                }
            }
        }

        if (RDTCacheManager.getInstance().getEquipmentDetails(toLocation) != null) {
            return true;
        }
        
        if("01".equals(toLocation)){
        	return true;
        }
        return false;
    }
    
	/**
	 * Checks whether any troubleshoot areas are part of the container confirmation. If the troubleshoot area is
	 * present, it indicates that seal issue present. In such case, a seal broken request is constructed and passed to
	 * the master actor for further processing.
	 * 
	 * @param moveEvent
	 * @param role
	 */
	public void checkAndSendTroubleshoot(ContainerMoveEvent moveEvent, OPERATOR role) {
	    List<String> tsAreas = moveEvent.getTsAreas();
	    try{
	        if (tsAreas != null && !tsAreas.isEmpty()) {
	            logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Seal Issue exists and user opted for troubleshoot");
	
	            SealBrokenRequestEvent sealBrokenEvent;
	            for (int index = 0; index < tsAreas.size(); index++) {
	                sealBrokenEvent = new SealBrokenRequestEvent();
	                sealBrokenEvent.setContainerId(moveEvent.getContainerIDs().get(index));
	                sealBrokenEvent.setEquipmentID(moveEvent.getEquipmentID());
	
	                // based on the move type and operator
	                String itvId;
	                if (role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC)) {
	                    if (LOAD.equalsIgnoreCase(moveEvent.getMoveType())) {
	                        itvId = moveEvent.getFromLocations().get(index);
	                    } else {
	                        itvId = moveEvent.getToLocations().get(index);
	                    }
	                } else {
	                    if (DSCH.equalsIgnoreCase(moveEvent.getMoveType())) {
	                        itvId = moveEvent.getFromLocations().get(index);
	                    } else {
	                        itvId = moveEvent.getToLocations().get(index);
	                    }
	                }
	                sealBrokenEvent.setItvId(itvId);
	
	                sealBrokenEvent.setMoveType(moveEvent.getMoveType());
	                sealBrokenEvent.setTerminalID(moveEvent.getTerminalID());
	                sealBrokenEvent.setTsAreaId(moveEvent.getTsAreas().get(index));
	                sealBrokenEvent.setUserID(moveEvent.getUserID());
	                RDTProcessingServer.getInstance().getMasterActor().tell(sealBrokenEvent, null);
	            }
	        } else {
	           logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(),
	                    "No Troubleshoot areas are present with container confirmation");
	        }
	   }catch(Exception ex){
	    	logger.logException("Caught exception while checkAndSendTroubleshoot-" , ex);
	    }
	}
    
	/**
     * Sends the toLocation validation status to the UI
     * @param isValid
     * @param errorMessage
     * @param moveEvent
     * @param role
     */
    public void sendValidationResponseToDevice(boolean isValid, String errorMessage, Event moveEvent, OPERATOR role){
    	String langKey = EventUtil.getInstance().getUserLanguage(moveEvent.getUserID());
    	
    	String eventTypeID = DeviceEventTypes.getInstance().getEventType(JOBLIST_VALIDATION_RESPONSE);
    	
        StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.RESP ).append(VALUE_SEPARATOR)
        		.append(eventTypeID).append(VALUE_SEPARATOR).append(moveEvent.getEventID()).append(VALUE_SEPARATOR)
        		.append( moveEvent.getTimeStamp()).append( VALUE_SEPARATOR ).append( isValid ).append( VALUE_SEPARATOR);
        if(errorMessage != null && !errorMessage.isEmpty()){
        	responseToDevice.append(LocalizationUtil.getMessage(langKey, errorMessage));
        }else {
        	responseToDevice.append("");
        }
        responseToDevice.append(VALUE_SEPARATOR + moveEvent.getUserID()
                + VALUE_SEPARATOR + moveEvent.getTerminalID());

        logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Sending Response to UI");

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                moveEvent.getTerminalID());
    }
    
    /**
	 * Checks and Retrieves the complatedContainerMove if present for the specified containerID
	 * 
	 * @param containerId
	 * @param userId
	 * @param equipmentId
	 * @return
	 */
	public CompletedContainerMoves getCompletedContainer(String containerId, String userId, String equipmentId,String moveType) {
		ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
				.getAllocationDetails(userId);
		CompletedContainerMoves completedMove = null;
		if (allocationEvent != null && allocationEvent.getRotationID() != null) {
			Map<String, CompletedContainerMoves> completedJobList = RDTCacheManager.getInstance().getCompletedJobs(
					allocationEvent.getRotationID(), equipmentId);
			if (completedJobList != null) {
				completedMove = completedJobList.get(containerId.concat(moveType));
			}
		}

		return completedMove;
	}

	/**
	 * Check whether the ITV changed from the previous job confirmation. If yes, initiates the ITV swap message to ESB
	 * 
	 * @param moveEvent
	 * @return
	 */
    public boolean checkAndInitiateITVSwap(ContainerMoveEvent moveEvent) {
		boolean status = false;
		logger.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Entering checkAndInitiateITVSwap method ");
		
		List<SwapContainerPosition> swapList = new ArrayList<SwapContainerPosition>();
		SwapContainerPosition swapContainer;
		CompletedContainerMoves completedMove;
		for(int indx=0; indx<moveEvent.getToLocations().size(); indx++){
			completedMove = getCompletedContainer(moveEvent.getContainerIDs()
					.get(indx), moveEvent.getUserID(), moveEvent.getEquipmentID(),moveEvent.getMoveType());
			
			logger.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Completed move is " + completedMove);
			
			if(completedMove!= null && !moveEvent.getToLocations().get(indx).equalsIgnoreCase(completedMove.getToLocation())){
				swapContainer = new SwapContainerPosition();
				swapContainer.setContainerId(completedMove.getContainerId());
				//set old itv id 
				swapContainer.setItvId(completedMove.getToLocation());
				swapContainer.setJobKey(completedMove.getJobKey());
				if(moveEvent.getPosition() != null && !moveEvent.getPosition().isEmpty()){
					swapContainer.setPositionOnChassis(moveEvent.getPosition().get(indx));
				}else {
					swapContainer.setPositionOnChassis(completedMove.getPosition());
				}
				swapContainer.setNewItvId(moveEvent.getToLocations().get(indx));
				swapContainer.setMoveType(moveEvent.getMoveType());
				swapList.add(swapContainer);
			}
		
			if(!swapList.isEmpty()){
				ITVSwapRequestEvent swapEvent = new ITVSwapRequestEvent();
				swapEvent.setUserID(moveEvent.getUserID());
				swapEvent.setEventID(UUID.randomUUID().toString());
				swapEvent.setSwapContainers(swapList);
				swapEvent.setEquipmentID(moveEvent.getEquipmentID());
				swapEvent.setTerminalID(moveEvent.getTerminalID());
				
				logger.logMsg(LOG_LEVEL.INFO, swapEvent.getUserID(), "Sending ITV swap request to ESB");
				ESBQueueManager.getInstance().postMessage(swapEvent, OPERATOR.COMMON, swapEvent.getTerminalID());
				status = true;
			}
		}
		
		return status;
	}
}
