package com.minapro.procserver.events;

public class OrphanContainerIsoCodesRequestEvent extends Event{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "OrphanContainerIsoCodesRequestEvent [getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getTerminalID()=" + getTerminalID() + ", getEventID()="
				+ getEventID() + "]";
	}
}
