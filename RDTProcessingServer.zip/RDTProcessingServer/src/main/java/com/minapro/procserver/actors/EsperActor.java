package com.minapro.procserver.actors;

import akka.actor.UntypedActor;

import com.minapro.procserver.cep.EsperEngine;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor which is responsible for forwarding the PLCData events to the Esper Engine. </p>
 * 
 * <p> Esper Engine is single instance, all the EsperActors will be forwarding the events to the same esperEngine. </p>
 * 
 * @author Rosemary George
 *
 */
public class EsperActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(EsperActor.class);
    private static final EsperEngine ESPER_ENGINE = new EsperEngine();

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof EsperPLCEvent) {
            EsperPLCEvent arrivedAtEsper = (EsperPLCEvent) message;
            logger.logMsg(LOG_LEVEL.TRACE, "Received @ESPER QC Event:", arrivedAtEsper.toString());
            ESPER_ENGINE.insertEvent(message);
        } else if (message instanceof EsperRMGPLCEvent) {
            EsperRMGPLCEvent rmgArrivedAtEsper = (EsperRMGPLCEvent) message;
            logger.logMsg(LOG_LEVEL.TRACE, "Received @ESPER RMG Event:", rmgArrivedAtEsper.toString());
            ESPER_ENGINE.insertEvent(message);
        } else {
            ESPER_ENGINE.insertEvent(message);
        }
    }
}
