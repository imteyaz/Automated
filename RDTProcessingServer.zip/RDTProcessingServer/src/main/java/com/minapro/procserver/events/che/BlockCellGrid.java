package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.Arrays;

import com.minapro.procserver.cache.CellGrid.CELL_STATUS;

/**
 *
 * @author UMAMAHESH M.
 *
 */
public class BlockCellGrid implements Serializable {

    private static final long serialVersionUID = -8148854999323813468L;

    /**
     * Indicates the status of the cell
     */
    private CELL_STATUS status;

    /**
     * The Yard row number corresponding to this cell
     */
    private int yardRowNo;

    /**
     * The Yard stack number corresponding to this cell
     */
    private int yardStackNo;

    /**
     * The container details if any is present in this cell
     */
    private YardProfileContainer[] currentYardContainer;

    /**
     * No Of Levels presented for corresponding block is
     * 
     * @return
     */
    private int wrkgStkHt;
    
    /**
     * Used to prepare Tiers for the given block number.
     * 
     * @param wrkgStkHt
     */
    public BlockCellGrid(int wrkgStkHt) {
        
    	this.wrkgStkHt = wrkgStkHt;
        
        this.currentYardContainer = new YardProfileContainer[wrkgStkHt];
        
        for(int i = 0; i<wrkgStkHt ; i++) {
        	 this.currentYardContainer[i] = new YardProfileContainer();
        }
        status = CELL_STATUS.AVAILABLE;
    }
    
   public int getWrkgStkHt() {
        return wrkgStkHt;
    }

    public void setWrkgStkHt(int wrkgStkHt) {
        this.wrkgStkHt = wrkgStkHt;
    }

    public CELL_STATUS getStatus() {
        return status;
    }

    public void setStatus(CELL_STATUS status) {
        this.status = status;
    }

    public int getYardRowNo() {
        return yardRowNo;
    }

    public void setYardRowNo(int rowSeqNo) {
        this.yardRowNo = rowSeqNo;
    }

    public int getYardStackNo() {
        return yardStackNo;
    }

    public void setYardStackNo(int yardStackNo) {
        this.yardStackNo = yardStackNo;
    }

    public YardProfileContainer getCurrentYardContainer(int currentTierNo) {
        return this.currentYardContainer[currentTierNo];
    }

    public void setCurrentYardContainer(int tierPosition, YardProfileContainer container) {
        this.currentYardContainer[tierPosition] = container;
    }

    /**
     * 
    public YardProfileContainer getPlannedYardContainer(int currentTierNo) {
		return plannedYardContainer[currentTierNo];
	}

	public void setPlannedYardContainer(int tierPosition, YardProfileContainer container) {
		this.plannedYardContainer[tierPosition] = container;
	}
    * */
	
    @Override
	public String toString() {
		return "BlockCellGrid [currentYardContainer="+ Arrays.toString(currentYardContainer) + "]";
	}

    

}
