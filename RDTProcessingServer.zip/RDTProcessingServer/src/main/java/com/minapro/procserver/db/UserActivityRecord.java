package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the user activity details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_USER_ACTIVITY")
public class UserActivityRecord implements Serializable {

    private static final long serialVersionUID = -147178280524832594L;

    @Id
    @Column(name = "USER_ACTIVITY_ID", nullable = false)
    private int userActivityId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_NM")
    private User user;

    @Column(name = "ROLE", nullable = false)
    private String role;

    @Column(name = "EQUIPMENT_ID")
    private String equipmentID;

    @Column(name = "LOGIN_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date loginDatetime;

    @Column(name = "LOGOUT_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date logoutDatetime;

    @Column(name = "BREAK_START_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date breakStartTime;

    @Column(name = "BREAK_END_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date breakEndTIme;

    @Column(name = "ACTIVITY_ID")
    private String activityId;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "ROTATION_NO")
    private Integer rotationId;

    @Column(name = "HOURS_WORKED")
    private Double totalHoursWorked;

    @Column(name = "BREAK_DURATION")
    private double totalBreakDuration;

    public int getUserActivityId() {
        return userActivityId;
    }

    public void setUserActivityId(int userActivityId) {
        this.userActivityId = userActivityId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getLoginDatetime() {
        return loginDatetime;
    }

    public void setLoginDatetime(Date loginDatetime) {
        this.loginDatetime = loginDatetime;
    }

    public Date getLogoutDatetime() {
        return logoutDatetime;
    }

    public void setLogoutDatetime(Date logoutDatetime) {
        this.logoutDatetime = logoutDatetime;
    }

    public String getActivity() {
        return activityId;
    }

    public void setActivity(String activityId) {
        this.activityId = activityId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public Integer getRotationId() {
        return rotationId;
    }

    public void setRotationId(Integer rotationId) {
        this.rotationId = rotationId;
    }

    public Double getTotalHoursWorked() {
        return totalHoursWorked;
    }

    public void setTotalHoursWorked(Double totalHoursWorked) {
        this.totalHoursWorked = totalHoursWorked;
    }

    public Date getBreakStartTime() {
        return breakStartTime;
    }

    public void setBreakStartTime(Date breakStartTime) {
        this.breakStartTime = breakStartTime;
    }

    public Date getBreakEndTIme() {
        return breakEndTIme;
    }

    public void setBreakEndTIme(Date breakEndTIme) {
        this.breakEndTIme = breakEndTIme;
    }

    public double getTotalBreakDuration() {
        return totalBreakDuration;
    }

    public void setTotalBreakDuration(double totalBreakDuration) {
        this.totalBreakDuration = totalBreakDuration;
    }

    @Override
    public String toString() {
        return "UserActivityRecord [userActivityId=" + userActivityId + ", user=" + user + ", role=" + role
                + ", equipmentID=" + equipmentID + ", loginDatetime=" + loginDatetime + ", logoutDatetime="
                + logoutDatetime + ", breakStartTime=" + breakStartTime + ", breakEndTIme=" + breakEndTIme
                + ", activityId=" + activityId + ", remarks=" + remarks + ", rotationId=" + rotationId
                + ", totalHoursWorked=" + totalHoursWorked + ", totalBreakDuration=" + totalBreakDuration + "]";
    }

}
