package com.minapro.procserver.actors.che;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.che.CancelShuffleRequestEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ShuffleJoblistCancelActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ShuffleJoblistCancelActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof CancelShuffleRequestEvent) {
                CancelShuffleRequestEvent cancelshuffleRequest = (CancelShuffleRequestEvent) message;
                logger.logMsg(LOG_LEVEL.INFO, cancelshuffleRequest.getUserID(), "Received  cancel shuffle job list request event  "
                        + cancelshuffleRequest);
                
                // remove the shuffled job
                RDTCacheManager.getInstance().deleteFromshuffledJobList(cancelshuffleRequest.getUserID(),cancelshuffleRequest.getJobListContainerId(),true);

            } else {
                unhandled(message);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while processing the message - ", ex);
        }
    }

}
