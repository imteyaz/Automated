package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the primary key for the Business Exception details
 * @author Rosemary George
 *
 */
@Embeddable
public class BusinessExceptionDetailsPk implements Serializable {
    
    private static final long serialVersionUID = 2454206915273897222L;

    @Column(name="EXCEPTION_ID")
    private String exceptionId;
    
    @Column(name="EXCEPTION_CODE")
    private String exceptionCode;

    public String getExceptionId() {
        return exceptionId;
    }

    public void setExceptionId(String exceptionId) {
        this.exceptionId = exceptionId;
    }

    public String getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(String exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    @Override
    public String toString() {
        return "BusinessExceptionDetailsPk [exceptionId=" + exceptionId + ", exceptionCode=" + exceptionCode + "]";
    }    
}
