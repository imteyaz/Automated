package com.minapro.procserver.db.alert;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * ValueObject holding the details of the alert being recorded
 * @author Rosemary George
 *
 */
@Entity
@Table(name="MP_ALERT_RECORD")
public class AlertRecord implements Serializable{
	
	private static final long serialVersionUID = -5666958147336363553L;

	@Id
	@SequenceGenerator(name = "alert_seq_gen", sequenceName = "MP_ALERT_RECORD_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "alert_seq_gen")
	@Column(name = "ALERT_RECORD_ID") 
	private Integer recordId;
	
	@Column(name="ALERT_TEXT_INSTANCE")
	private String alertMessage;
	
	@Column(name = "ALERT_CODE")
	private String code;
	
	@Column(name = "RAISED_BY")
	private String raisedBy;
	
	@Column(name = "RAISED_DATETIME")
	private Date raisedDateTime;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "CLOSED_BY")
	private String closedBy;
	
	@Column(name = "CLOSED_DATETIME")
	private Date closedDateTime;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "keyValueId", cascade = CascadeType.ALL)
    private Set<AlertKeyValue> keyValueDetails = new HashSet<AlertKeyValue>();

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public Set<AlertKeyValue> getKeyValueDetails() {
		return keyValueDetails;
	}

	public void setKeyValueDetails(Set<AlertKeyValue> keyValueDetails) {
		this.keyValueDetails = keyValueDetails;
	}

	public Integer getRecordId() {
		return recordId;
	}

	public void setRecordId(Integer recordId) {
		this.recordId = recordId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Date getRaisedDateTime() {
		return raisedDateTime;
	}

	public void setRaisedDateTime(Date raisedDateTime) {
		this.raisedDateTime = raisedDateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	public Date getClosedDateTime() {
		return closedDateTime;
	}

	public void setClosedDateTime(Date closedDateTime) {
		this.closedDateTime = closedDateTime;
	}

	@Override
	public String toString() {
		return "AlertRecord [recordId=" + recordId + ", alertMessage=" + alertMessage + ", code=" + code
				+ ", raisedBy=" + raisedBy + ", raisedDateTime=" + raisedDateTime + ", status=" + status
				+ ", keyValueDetails=" + keyValueDetails + "]";
	}	
}
