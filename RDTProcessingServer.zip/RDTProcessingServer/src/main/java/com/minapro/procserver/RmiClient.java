package com.minapro.procserver;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.TimeUnit;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class which act as the RMI client. It connects to the RMI server running on the IP:port mentioned in the properties
 * file.
 * 
 * @author Rosemary George
 *
 */
public class RmiClient {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RmiClient.class);

    private ReceiveMessageInterface rmiServer;
    private Registry registry;

    private static final String SERVER_ADDRESS = DeviceCommParameters.getInstance().getCommParameter("RMI_SERVER_IP");
    private static final String SERVER_PORT = DeviceCommParameters.getInstance().getCommParameter("RMI_SERVER_PORT");

    private static final RmiClient INSTANCE = new RmiClient();

    private RmiClient() {
        logger.logMsg(LOG_LEVEL.INFO, "", "Starting the RMI client");
        try {
            // get the registry
            registry = LocateRegistry.getRegistry(SERVER_ADDRESS, (new Integer(SERVER_PORT)).intValue());
            rmiServer = (ReceiveMessageInterface) (registry.lookup("rmiServer"));
        } catch (RemoteException e) {
            logger.logException("Caught exception while trying to start RMI client", e);
        } catch (NotBoundException e) {
            logger.logException("Caught exception while trying to start RMI client", e);
        }
    }

    public static RmiClient getInstance() {
        return INSTANCE;
    }

    /**
     * Issues the start the PLC scheduler for the specified role through RMI
     * 
     * @param role
     * @return
     */
    public boolean startPlc(String role) {
        try {
            return rmiServer.startPLC(role);
        } catch (RemoteException e) {
            logger.logException("Caught exception while trying to start PLC : ", e);
            return false;
        }
    }

    /**
     * Issues the Stop the PLC scheduler for the specified role through the RMI
     * 
     * @param role
     * @return
     */
    public boolean stopPlc(String role) {
        try {
            return rmiServer.stopPLC(role);
        } catch (RemoteException e) {
            logger.logException("Caught exception while trying to stop PLC : ", e);
            return false;
        }
    }

    /**
     * Issues the restart job list scheduler with the changed frequency details through the RMI
     * 
     * @param initialDelay
     * @param frequencyInterval
     * @param unit
     * @param role
     * @return
     */
    public boolean restartJobListScheduler(int initialDelay, int frequencyInterval, TimeUnit unit, OPERATOR role) {
    	logger.logMsg(LOG_LEVEL.INFO, role.toString()," Started restartJobListScheduler() In RMI Client");
        try {
            return rmiServer.restartJobListScheduler(initialDelay, frequencyInterval, unit, role);
        } catch (RemoteException e) {
            logger.logException("Caught exception while trying to restart job list scheduler : ", e);
            return false;
        }
    }

    /**
     * Issues the restart planned moves scheduler with the changed frequency details through the RMI
     * 
     * @param initialDelay
     * @param frequencyInterval
     * @param unit
     * @return
     */
    public boolean restartPlannedMovesScheduler(int initialDelay, int frequencyInterval, TimeUnit unit) {
        try {
            return rmiServer.restartPlannedMovesScheduler(initialDelay, frequencyInterval, unit);
        } catch (RemoteException e) {
            logger.logException("Caught exception while trying to planned moves scheduler : ", e);
            return false;
        }
    }

    /**
     * Issues heart beat ping to the RMI
     * 
     * @return
     * @throws RemoteException
     */
    public boolean checkMasterNodeHealth() throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, "", "Logged in QC user size ="
                + RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache());
        logger.logMsg(LOG_LEVEL.INFO, "", "Logged in CHE user size ="
                + RDTPLCCacheManager.getInstance().sizeOfCHELoggedInCache());
        return rmiServer.checkMasterStatus();
    }   
}
