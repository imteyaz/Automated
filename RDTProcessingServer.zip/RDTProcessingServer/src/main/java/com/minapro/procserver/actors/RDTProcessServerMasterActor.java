package com.minapro.procserver.actors;

import java.util.Arrays;
import java.util.List;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.actors.che.CHESupervisorActor;
import com.minapro.procserver.actors.plc.GeneralLiftOperationActor;
import com.minapro.procserver.events.BayProfileRequestEvent;
import com.minapro.procserver.events.CompletedJobListRequestEvent;
import com.minapro.procserver.events.ContainerDamageCorrectionEvent;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerDamageResponseEvent;
import com.minapro.procserver.events.ContainerDamagesRequestEvent;
import com.minapro.procserver.events.ContainerInquiryEvent;
import com.minapro.procserver.events.ContainerInquiryResponseEvent;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ContainerMoveResponseEvent;
import com.minapro.procserver.events.DeleteManualJobRequestEvent;
import com.minapro.procserver.events.ExchangeContainerResponseEvent;
import com.minapro.procserver.events.JobListAlertEvent;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.KeepAliveRequestEvent;
import com.minapro.procserver.events.KeepAliveResponseEvent;
import com.minapro.procserver.events.PlannedMovesResponseEvent;
import com.minapro.procserver.events.RefreshJobListRequestEvent;
import com.minapro.procserver.events.SwitchBayRequestEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerInquiryRequestEvent;
import com.minapro.procserver.events.UpdateContainerInquiryResponseEvent;
import com.minapro.procserver.events.UpdateContainerLocationResponseEvent;
import com.minapro.procserver.events.UpdateContainerResponseEvent;
import com.minapro.procserver.events.UpdateJobRequestEvent;
import com.minapro.procserver.events.hc.DamageCodeRequestEvent;
import com.minapro.procserver.events.plc.GeneralLiftOperationEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Master Actor which supervises the interaction of all the actors present in the RDT process layer. </p>
 * 
 * @author Rosemary George
 *
 */
public class RDTProcessServerMasterActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTProcessServerMasterActor.class);
	
    /**
     * All the common operations - give the class name here if new one is added
     */
    private static final List<String> COMMON_OPERATIONS = Arrays.asList(new String[] { "LoginEvent",
            "LoginResponseEvent", "LogoutEvent", "DLMEvent", "DLMResponseEvent", "AllocationEvent",
            "ConfirmAllocationEvent", "CertificateValidateEvent", "DelayConfirmationEvent", "JournalEvent",
            "CheckListInspectionEvent", "CancelInspectionEvent", "VesselBerthEvent", "VesselSailEvent",
            "BerthedVessel", "BaywiseContainerDetailsResponseEvent", "ConfirmAllocationResponseEvent",
            "OperatorAvailabilityEvent", "OperatorAvailabilityResponseEvent", "OperatorBreakReasonsEvent",
            "UpdateBayViewResponseEvent", "VesselBerthSideResponseEvent", "LanguagesGetRequestEvent",
            "LanguageChangeReqEvent", "RefreshVesselEvent", "AlertEvent", "TechSupportRequestEvent",
            "TechSupportValuesEvent", "SealBrokenRequestEvent", "JobSelectionEvent", "JobSelectionResponseEvent", 
            "CancelJobSelectionEvent", "CancelJobSelectionResponseEvent", 
            "MinaProAlertEvent", "AccidentIncidentRequestEvent", "AccidentIncidentConfirmEvent",
            "MovesToGoRequestEvent", "MovesToGoResponseEvent", "LogoutResponseEvent", "OperatorMessageResponseEvent"});
    /**
     * All the ITV specific operations - give the class name here if new one is added
     */
    private static final List<String> ITV_OPERATIONS = Arrays.asList(new String[] { "DriveInstructionEvent",
            "ITVArrivalEvent", "PinningStationJobConfirmationEvent", "ITVJobListEvent", "ITVPoolEvent",
            "ITVPoolRequestEvent","ITVPerformanceEvent", "FollowITVEvent", "CallITVEvent" });

    /**
     * All the PLC specific operations - give the class name here if new one is added
     */
    private static final List<String> PLC_OPERATIONS = Arrays.asList(new String[] { "ContainerHandleEvent",
            "DelayRecordingEvent", "DelayRecordingByOperatorEvent", "DelayRecordingConfirmationEvent", "EsperPLCEvent",
            "PLCJobdoneEvent", "BackReachEvent", "ContainerScreenMinimizeEvent", "ContainerDetectionEvent",
            "StopPLCInstructionEvent", "UpdateJobDetectedEvent", "PLCSchedulerEvent", "CHEPLCJobdoneEvent",
            "CHEContainerDetectionEvent", "CHEContainerHandleEvent", "CHERowChangeDetectionEvent",
            "ManualDelayRecordingConfirmationEvent", "EndDelayTriggerEvent", "AutoDelayReconfirmEvent" });
    /**
    * All the HC specific operations - give the class name here if new one is added related to HC operator
    */
    private static final List<String> HC_OPERATIONS = Arrays.asList(new String[] {"OutOfListContainersRequestEvent", "OrphanContainerEvent",
   		"OutOfListContainerResponseEvent","OrphanContainerResponseEvent", "TroubleshootAreasGetRequestEvent", 
          "TroubleshootConfirmRequestEvent","SwapRequestEvent", "SwapResponseEvent", "ITVSwapResponseEvent" });

    /**
     * All the Vessel Foreman specific operations - give the class name here if new one is added. LashersRequestEvent is
     * used for getting Logged in Lashers information.
     */
    private static final List<String> VF_OPERATIONS = Arrays.asList(new String[] { "VfOperatoinalViewEvent",
            "QCPerformanceEvent", "BayRowChangeNotifEvent", "VesselForemanCheckListEvent", "ViewPlanEvent",
            "LashersRequestEvent", "VesselDocumentEvent" });

    /**
     * All the Vessel Foreman specific operations - give the class name here if new one is added
     */
    private static final List<String> SHF_OPERATIONS = Arrays.asList(new String[] {
            "SHFPinningStationAllocationReqEvent", "SHFPinningStationAllocationChangeEvent", "QCLanesRequestEvent",
            "QcLanesChangeRequestEvent" });

    /**
     * All the CHE specific operations - give the class name here if new one is added
     */
    private static final List<String> CHE_OPERATIONS = Arrays.asList(new String[] { "BlockViewRequestEvent",
            "BlockWiseContainersResponseEvent", "StackViewRequestEvent", "EsperRMGPLCEvent", "ReeferConnectionResponseEvent", 
            "NewLocationRequestEvent","NewLocationResponseEvent",
            "InventoryRequestEvent","InventoryUpdateRequestEvent","InventoryUpdateResponseEvent","CHEJobListRequestEvent",
            "CHEJobListEvent","UpdateBlockContainersResponseEvent","ShuffleRequestEvent","ShuffleResponseEvent"});

    /**
     * All the Trouble shoot clerk specific operations - give the class name here if new one is added
     */
    private static final List<String> TSC_OPERATIONS = Arrays.asList(new String[] { "TSCJobListRequestEvent" });

    /**
     * Actor responsible for handling/supervising all common operations
     */
    private ActorRef commonOperationSupervisor = getContext().actorOf(Props.create(CommonOperationSupervisor.class),
            "commonOperationSupervisor");

    /**
     * Actor responsible for handling/supervising all itv specific operations
     */
    private ActorRef itvOperationSupervisor = getContext().actorOf(Props.create(ITVSupervisorActor.class),
            "itvOperationSupervisor");

    /**
     * Actor responsible for handling/supervising all PLC related operations
     */
    private ActorRef plcOperationSupervisor = getContext().actorOf(Props.create(PLCSupervisorActor.class),
            "plcOperationSupervisor");

    /**
     * Actor responsible for handling/supervising all Vessel Foreman related operations
     */
    private ActorRef vesselForemanOperationSupervisor = getContext().actorOf(
            Props.create(VesselForemanOperationalSuperVisorActor.class), "vesslForemanOperaionSupervisor");

    /**
     * Actor responsible for handling/supervising all Shore Foreman related operations
     */
    private ActorRef shoreForemanSupervisor = getContext().actorOf(Props.create(SHFOperationsSupervisorActor.class),
            "shoreForemanSupervisor");
    /**
     * Actor responsible for parsing all the incoming messages from devices
     */
    private ActorRef parserActor = getContext().actorOf(
            Props.create(EventParserActor.class).withRouter(new FromConfig()), "eventParser");
    /**
     * Actor responsible for handling all HC operator related activities/events
     */
    private ActorRef hcOperationSupervisor = getContext()
            .actorOf(Props.create(HCSupervisorActor.class), "hcOperations");
    /**
     * Actor responsible for handling all CHE operator related activities
     */
    private ActorRef cheOperationSupervisor = getContext().actorOf(Props.create(CHESupervisorActor.class),
            "cheOperations");

    /**
     * Actor responsible for handling all Troubleshoot Clerk operator related activities
     */
    private ActorRef tscOperationSupervisor = getContext().actorOf(Props.create(TSCSupervisorActor.class),
            "tscOperations");

    private ActorRef jobListActor = getContext().actorOf(Props.create(JobListActor.class).withRouter(new FromConfig()),
            "jobList");
  

    private ActorRef plannedMovesPollingActor = getContext().actorOf(
            Props.create(PlannedMovesActor.class).withRouter(new FromConfig()), "plannedMovesActor");

    private ActorRef containerMoveActor = getContext().actorOf(
            Props.create(ContainerMoveActor.class).withRouter(new FromConfig()), "containerMove");

    private ActorRef containerDamageActor = getContext().actorOf(
            Props.create(ContainerDamageActor.class).withRouter(new FromConfig()), "containerDamage");

    private ActorRef updateContainerActor = getContext().actorOf(
            Props.create(UpdateContainerActor.class).withRouter(new FromConfig()), "updateContainer");

    private ActorRef bayProfileActor = getContext().actorOf(
            Props.create(BayProfileActor.class).withRouter(new FromConfig()), "bayProfile");

    private ActorRef updateJobListActor = getContext().actorOf(
            Props.create(UpdateJobListActor.class).withRouter(new FromConfig()), "updateJobList");

    private ActorRef generalLiftOperationActor = getContext().actorOf(
            Props.create(GeneralLiftOperationActor.class).withRouter(new FromConfig()), "generalLiftOperation");

    private ActorRef completedJobListActor = getContext().actorOf(
            Props.create(CompletedJobListActor.class).withRouter(new FromConfig()), "completedJobList");

    private ActorRef refreshJobListActor = getContext().actorOf(
            Props.create(RefreshJobListActor.class).withRouter(new FromConfig()), "refreshJobList");

    private ActorRef containerMoveRespActor = getContext().actorOf(
            Props.create(ContainerMoveResponseActor.class).withRouter(new FromConfig()), "containerMoveResponse");

    private ActorRef jobListAlertActor = getContext().actorOf(
            Props.create(JobListAlertActor.class).withRouter(new FromConfig()), "jobListAlert");
    
    private ActorRef containerInquiryActor = getContext().actorOf(
            Props.create(ContainerInquiryActor.class).withRouter(new FromConfig()), "containerInquiryActor");
    
    private ActorRef updateContainerLocationActor = getContext().actorOf(
            Props.create(UpdateContainerLocationActor.class).withRouter(new FromConfig()), "updateContainerLocationActor");
    
    private ActorRef keepAliveActor = getContext().actorOf(
            Props.create(KeepAliveActor.class).withRouter(new FromConfig()), "keepAliveActor");
    
    private ActorRef exchangeActor = getContext().actorOf(
            Props.create(ExchangeContainerActor.class).withRouter(new FromConfig()), "exchangeContainerActor");
    

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {

                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    /**
     * Receives all messages and delegates to the respective actor based on the event type
     */
    public void onReceive(Object message) throws Exception {
        Object currentObj = message.getClass().getSimpleName();
        
        logger.logMsg(LOG_LEVEL.DEBUG, currentObj.toString(), "Received at Master");        

        if (message instanceof String) {
            parserActor.tell(message, getSelf());
        } else if (PLC_OPERATIONS.contains(currentObj)) {
            plcOperationSupervisor.tell(message, getSelf());
        } else if (COMMON_OPERATIONS.contains(currentObj)) {
            commonOperationSupervisor.tell(message, getSelf());
        } else if (ITV_OPERATIONS.contains(currentObj)) {
            itvOperationSupervisor.tell(message, getSelf());
        } else if (VF_OPERATIONS.contains(currentObj)) {
            vesselForemanOperationSupervisor.tell(message, getSelf());
        } else if (SHF_OPERATIONS.contains(currentObj)) {
            shoreForemanSupervisor.tell(message, getSelf());
        } else if (message instanceof JobListEvent || message instanceof JobListRequestEvent) {
            jobListActor.tell(message, getSelf());
        } else if (message instanceof ContainerMoveEvent) {
            containerMoveActor.tell(message, getSelf());
        } else if (message instanceof ContainerDamageEvent || message instanceof DamageCodeRequestEvent
                || message instanceof ContainerDamagesRequestEvent || message instanceof ContainerDamageCorrectionEvent
                || message instanceof ContainerDamageResponseEvent) {
            containerDamageActor.tell(message, getSelf());
        } else if (message instanceof UpdateContainerEvent || message instanceof UpdateContainerInquiryRequestEvent 
        		|| message instanceof UpdateContainerInquiryResponseEvent || message instanceof UpdateContainerResponseEvent) {
            updateContainerActor.tell(message, getSelf());
        } else if (message instanceof BayProfileRequestEvent || message instanceof SwitchBayRequestEvent) {
            bayProfileActor.tell(message, getSelf());
        } else if (message instanceof UpdateJobRequestEvent) {
            updateJobListActor.tell(message, getSelf());
        } else if (message instanceof GeneralLiftOperationEvent || message instanceof DeleteManualJobRequestEvent) {
            generalLiftOperationActor.tell(message, getSelf());
        } else if (HC_OPERATIONS.contains(currentObj)) {
            hcOperationSupervisor.tell(message, getSelf());
        } else if (CHE_OPERATIONS.contains(currentObj)) {
            cheOperationSupervisor.tell(message, getSelf());
        } else if (message instanceof CompletedJobListRequestEvent) {
            completedJobListActor.tell(message, getSelf());
        } else if (message instanceof RefreshJobListRequestEvent) {
            refreshJobListActor.tell(message, getSelf());
        } else if (message instanceof ContainerMoveResponseEvent) {
            containerMoveRespActor.tell(message, getSelf());
        } else if (message instanceof JobListAlertEvent) {
            jobListAlertActor.tell(message, getSelf());
        } else if (message instanceof PlannedMovesResponseEvent) {
            plannedMovesPollingActor.tell(message, getSelf());
        } else if (TSC_OPERATIONS.contains(currentObj)) {
            tscOperationSupervisor.tell(message, getSelf());
        } else if(message instanceof ContainerInquiryEvent || message instanceof ContainerInquiryResponseEvent){
            containerInquiryActor.tell(message, getSelf());
        } else if(message instanceof UpdateContainerLocationResponseEvent) {
        	updateContainerLocationActor.tell(message, getSelf());
        } else if( message instanceof KeepAliveRequestEvent || message instanceof KeepAliveResponseEvent){
        	keepAliveActor.tell(message, getSelf());
        } else if(message instanceof ExchangeContainerResponseEvent) { 
        	exchangeActor.tell(message, getSelf());
        } else {
        	logger.logMsg(LOG_LEVEL.DEBUG, currentObj.toString(), "***********NOT A HANDLED MESSAGE, DISCARDING***************");
            unhandled(message);
        }
    }
}
