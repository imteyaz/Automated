package com.minapro.procserver.util;

import static com.minapro.procserver.util.RDTQueryStatements.GET_CURRENT_TWIN_JOB_SNAPSHOT_QUERY;
import static com.minapro.procserver.util.RDTQueryStatements.GET_EXISISTING_TWIN_JOBS_QUERY;
import static com.minapro.procserver.util.RDTQueryStatements.GET_TWIN_JOBS_BY_ROTATION;
import static com.minapro.procserver.util.RDTQueryStatements.UPDATE_JOBLIST_SEQNO_QUERY;
import static com.minapro.procserver.util.RDTQueryStatements.UPDATE_TWIN_TANDEM_CONTAIERS;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.opus.joblist.OPUSQCJobListEntity;
import com.minapro.procserver.db.opus.queries.OPUSJobListQueries;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
public class QCJobListDAO {

	public static final QCJobListDAO INSTNACE = new QCJobListDAO();
	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(QCJobListDAO.class);

	private QCJobListDAO(){

	}

	public static QCJobListDAO getInstnace(){
		return INSTNACE;
	}
	
	/**
	 * Step 1:
	 * 
	 * Method is used to get the current snap shot sparks job list twin jobs based on the following three parameters.
	 * using join query on MP_JOB_LIST table and retrieving the current twin jobs.
	 * In order to avoid duplicate data overridden the equals() and hash code() methods.
	 * @param terminalId
	 * @param rotationId
	 * @param equipmentId
	 * @return
	 * @throws SQLException 
	 */

	@SuppressWarnings("unchecked")
	public Set<OPUSTwinTandemJobsPOJO> getCurrentSnapShotTwinJobs(String terminalId, String rotationId , String equipmentId) throws SQLException{

		LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Started getCurrentSnapShotTwinJobs():").append(" Terminal Id:: ").
				append(terminalId).append(" Rotation Id::").append(rotationId).append(" Equipment Id::").append(equipmentId).toString());

		Set<OPUSTwinTandemJobsPOJO> jobListPOJOList = null;

		Session session = TransactionManager.getSession();


		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			Query query = session.createSQLQuery(GET_CURRENT_TWIN_JOB_SNAPSHOT_QUERY);

			List<Object[]> twinJobsFromDB = query.setParameter("terminalId", terminalId).
					setParameter("rotationId", rotationId).setParameter("equipmentId", equipmentId).list();
			jobListPOJOList = new LinkedHashSet<OPUSTwinTandemJobsPOJO>();


			for(Object[] twinJobsData : twinJobsFromDB){
				OPUSTwinTandemJobsPOJO jobListPOJO = new OPUSTwinTandemJobsPOJO();
				jobListPOJO.setContainerID(twinJobsData[0]!=null ?twinJobsData[0].toString():null);
				jobListPOJO.setMoveKind(twinJobsData[1]!=null ?twinJobsData[1].toString():null);
				jobListPOJO.setFromLocation(twinJobsData[2]!=null ?twinJobsData[2].toString():null);
				jobListPOJO.setToLocation(twinJobsData[3]!=null ?twinJobsData[3].toString():null);
				jobListPOJO.setSeqNo(twinJobsData[4]!=null ?Double.valueOf(twinJobsData[4].toString()):null);
				jobListPOJO.setRefContainerID(twinJobsData[5]!=null ?twinJobsData[5].toString():null);
				jobListPOJO.setRefMoveKind(twinJobsData[6]!=null ?twinJobsData[6].toString():null);
				jobListPOJO.setRefFromLocation(twinJobsData[7]!=null ?twinJobsData[7].toString():null);
				jobListPOJO.setRefToLocation(twinJobsData[8]!=null ?twinJobsData[8].toString():null);
				jobListPOJO.setRefSeqNo(twinJobsData[9]!=null ?Double.valueOf(twinJobsData[9].toString()):null);
				jobListPOJO.setOperationCode("I");
				jobListPOJO.setTwinTandemId("0");
				jobListPOJO.setMinaproTwinSplit("N");
				jobListPOJOList.add(jobListPOJO);
				
			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");
		}

		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),new StringBuilder("Current Snap Shot Twin Job From Sparcs ").
				append(jobListPOJOList.toString()).toString());

		return jobListPOJOList;
	}
	/**
	 * Step 2:
	 * Retrieve existed sparks created Twin And Tandem Jobs From MP_TWINTANDEM_CONTAINER_LIST and MP_TWINTANDEM_JOBS 
	 * 
	 * @param terminalID
	 * @param rotationId
	 * @param equipmentId 
	 * @return TwinTandemJobs existed twin tandem jobs list
	 * @throws SQLException 
	 */
	@SuppressWarnings("unchecked")
	public  Set<TwinTandemJobs> getExistedTwinJobs(String terminalID, String rotationId , String equipmentId) throws SQLException{

		LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Started getExistedTwinJobs() To Retrive Already Existed Twin/Tandem Jobs").toString());

		Session session = null;

		List<TwinTandemJobs> existedTwinJobs = null;

		session = TransactionManager.getSession();

		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			existedTwinJobs = session.createQuery(GET_EXISISTING_TWIN_JOBS_QUERY)
					.setParameter("rotationId", rotationId)
					.setParameter("equipmentId", equipmentId)
					.setParameter("terminalID", terminalID).list();

		} else {
			
			throw new SQLException("Transaction Manager Returned Empty Session");
		}



		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),new StringBuilder("Existed Twin Jobs::").
				append(existedTwinJobs!=null ? existedTwinJobs.toString() : null).toString());

		return existedTwinJobs!=null ?  new HashSet<TwinTandemJobs>(existedTwinJobs) : null ;

	}

	/**
	 * 
	 * @param terminalId 
	 * @param rotationId
	 * @param equipmentId
	 * @return no of jobs available for above three inputs criteria.
	 * @throws SQLException 
	 */
	@SuppressWarnings("unchecked")
	public  List<OPUSQCJobListEntity> getQCJobListByRotationAndEquipment(String terminalId,String rotationId,
			String equipmentId) throws SQLException {
		
		LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Started getJobListByRotationAndEquipment()").toString());
			
			Session session = null;
			Transaction tx = null;
			List<OPUSQCJobListEntity> resultSet = null ;
			
			try {
				session = HibernateUtil.getSessionFactory().getCurrentSession();
				tx = session.beginTransaction();
				
				 resultSet = session.createQuery(OPUSJobListQueries.GET_QC_JOB_LIST_ENTITY)
						.setParameter("equipmentId", equipmentId).setParameter("rotationId", rotationId)
						.setParameter("terminalId", terminalId).list();
				tx.commit();
				
			} catch (Exception ex) {
				
				if(session!=null && session.isOpen()) {
					session.getTransaction().rollback();
				}
				LOGGER.logException("Exception Occured While Retrieving Job List Jobs From Database,Reason For Exception::",ex);
				
			}
			
			LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId())," Current Jobs ::::"+(resultSet!=null ? resultSet.toString() : null));
			return resultSet;
			}


	@SuppressWarnings("unchecked")
	public  List<TwinTandemJobs> getExistedTwinJobsByRotation(String rotationId) throws SQLException{

		LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Started getExistedTwinJobsByRotation():").
				append(" Rotation Id::").append(rotationId).toString());

		List<TwinTandemJobs> existedTwinJobs = null;

		Session session = TransactionManager.getSession();

		if(session!=null){
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			existedTwinJobs = session.createQuery(GET_TWIN_JOBS_BY_ROTATION) .setParameter("rotationId", rotationId).list();
		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");
		}

		LOGGER.logMsg(LOG_LEVEL.TRACE,rotationId,new StringBuilder("Existed Sparcs Created Twin Jobs::").
				append(existedTwinJobs!=null ? existedTwinJobs.toString() : null).toString());

		return existedTwinJobs;

	}
	/**
	 * Saves the data to the database
	 * 
	 * @param data
	 *            - the data to be persisted
	 * @throws SQLException 
	 */
	public void saveMultipleObjects(List<?> objects) throws SQLException{

		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),"Started saveMultipleObjects() To save new Twin Jobs into two tables");

		int count = 0;

		Session session = TransactionManager.getSession();
		
		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			for(Object data : objects){
				session.save(data);
				if(++count % 25 ==0 ){
					session.flush();
					session.clear();
				}
			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");

		}

	}

	//Updating Job List Containers
	public  void updateTwinTandemContainers(List<OPUSTwinTandemJobsPOJO> jobListContainers) throws SQLException,NullPointerException{

		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId())," Started updateTwinTandemContainers() To Update Multiple TwinTandem Container List");

		Session session = TransactionManager.getSession();

		if(session!=null){
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			for(OPUSTwinTandemJobsPOJO jobList : jobListContainers){
				Query query = session.createSQLQuery(UPDATE_TWIN_TANDEM_CONTAIERS);
				query.setParameter("containerId",jobList.getContainerID()).setParameter("fromLocation",jobList.getFromLocation());
				query.setParameter("toLocation",jobList.getToLocation()).setParameter("refContainerId",jobList.getRefContainerID())
				.setParameter("refFromLocation",jobList.getRefFromLocation()).setParameter("refToLocation",jobList.getRefToLocation())
				.setParameter("twinTandemId",jobList.getTwinTandemId());
				query.executeUpdate();
			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");

		}

	}


	public void batchUpdateJobListSeqNumbers(List<OPUSTwinTandemJobsPOJO> sequnceUpdateList) throws SQLException,NullPointerException{

		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),new StringBuilder("Started batchUpdateJobListSeqNumbers").toString());

		int count = 0;

		Session session  = TransactionManager.getSession();

		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			for(OPUSTwinTandemJobsPOJO twinJobsPojo : sequnceUpdateList){

				double newSeqNum = 0.0;
				double currentSeqNum =0.0;
				
				LOGGER.logMsg(LOG_LEVEL.TRACE,twinJobsPojo.getTwinTandemId().toString(),new StringBuilder("Container::").append(twinJobsPojo.getContainerID())
						.append(" Reference Container::").append(twinJobsPojo.getRefContainerID()).toString());
				
				if(twinJobsPojo.getSeqNo() > twinJobsPojo.getRefSeqNo()){
					newSeqNum = twinJobsPojo.getRefSeqNo() + 0.1;
					currentSeqNum = twinJobsPojo.getSeqNo();
					LOGGER.logMsg(LOG_LEVEL.TRACE,twinJobsPojo.getTwinTandemId().toString(),
							new StringBuilder("Seq Number Is Greater::").append(twinJobsPojo.getSeqNo()).
							append(" Updated Seq Number For Current Seq Number Is::").append(newSeqNum).toString());
				} else {
					newSeqNum = twinJobsPojo.getSeqNo() + 0.1;
					currentSeqNum = twinJobsPojo.getRefSeqNo();
					LOGGER.logMsg(LOG_LEVEL.TRACE,twinJobsPojo.getTwinTandemId().toString(),
							new StringBuilder("Reference Sequnce Number Is Greater::").append(twinJobsPojo.getRefSeqNo()).
							append(" Updated Seq Number For Current Seq Number Is::").append(newSeqNum).toString());
				}

				
				session.createQuery(UPDATE_JOBLIST_SEQNO_QUERY).setParameter("nsqlNo", newSeqNum).
				setParameter("seqNumber",currentSeqNum).executeUpdate();

				if(++count % 25 == 0){
					session.flush();
					session.clear();
				}

			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session For Current Thread".concat(String.valueOf(Thread.currentThread().getId())));

		}

}

	public void batchUpdateNonSparcsTwinsSeqNumbers(List<String> updateRequiredSeqs) throws SQLException,NullPointerException{

		LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),new StringBuilder("Started batchUpdateJobListSeqNumbers new Seq Number::").toString());

		
		Session session = TransactionManager.getSession();
		int count =0 ;

		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			for(String seqNumbers : updateRequiredSeqs){

				double primarySeqNo  = Double.valueOf(seqNumbers.split("\\|")[0]);
				double refSeqNo      = Double.valueOf(seqNumbers.split("\\|")[1]);
				double currentSeqNo  = 0.0;
				double newSeqNo      = 0.0;

				if(primarySeqNo > refSeqNo){
					LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId()),"Primary Seq Number Is Greater::"+primarySeqNo);
					newSeqNo =refSeqNo + 0.1;
					currentSeqNo = primarySeqNo;
				} else {
					LOGGER.logMsg(LOG_LEVEL.TRACE,String.valueOf(Thread.currentThread().getId())," Reference Sequnce Number Is Greater::"+refSeqNo);
					newSeqNo =primarySeqNo + 0.1;
					currentSeqNo = refSeqNo;
				}

				session.createQuery(UPDATE_JOBLIST_SEQNO_QUERY).setParameter("nsqlNo", newSeqNo).
				setParameter("seqNumber",currentSeqNo).executeUpdate();

				if(++count % 25 == 0){
					session.flush();
					session.clear();
				}

			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");

		}

	}

	/* Delete Twin Tandem Id's frm MP_TWINTANDEM_JOB_LIST , MP_TWINTANDEM_CONTAINER_LIST*/
	//Modified
	public void deleteBulkTwinTandemJobs(List<TwinTandemJobs> deletableTwinTandemList) throws SQLException,NullPointerException{

		LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId())," Started deleteBulkTwinTandemJobs() To delete twin tandem Id's - ");

		Session session = TransactionManager.getSession();

		

		if(session!=null){
			
			LOGGER.logMsg(LOG_LEVEL.DEBUG,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Current Session Hash Code::").append(session.hashCode()).toString());
			
			for(TwinTandemJobs twinTandemJob : deletableTwinTandemList){
				LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder(" Deleting TwinTandem Id::").
						append(twinTandemJob.getTwinTandemId()).toString());
				session.delete(twinTandemJob);
			}

		} else {
			throw new SQLException("Transaction Manager Returned Empty Session");

		}



	}

	/**
	 * Which used to delete twin tandem Id when user split tandem job from UI
	 * @param deletableTwinTandemList
	 */

	public void deleteTwinJobsForTandemSplit(List<TwinTandemJobs> deletableTwinTandemList){
		LOGGER.logMsg(LOG_LEVEL.INFO,""," Started deleteBulkTwinTandemJobs() To delete twin tandem Id's - ");
		Session session = null;
        Transaction transaction = null;
       try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            transaction = session.beginTransaction();
            for(TwinTandemJobs twinTandemJob : deletableTwinTandemList){
            	LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder(" Deleting TwinTandem Id::").
            			append(twinTandemJob.getTwinTandemId()).toString());
            	 session.delete(twinTandemJob);
            }
            transaction.commit();
        }catch(Exception ex){
        	if(session!=null && session.isOpen()){
        		session.getTransaction().rollback();
        	}
        	LOGGER.logException("Exception Occured While Deleting Twin Tandem Contaier List From Database With Following Reason::",ex);
        
        }
            
	}
	


}
