package com.minapro.procserver.db.damage;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.minapro.procserver.db.Terminal;

/**
 * ValueObject holding the damage code details from the database
 * @author Rosemary George
 *
 */
@Entity
@Table(name="MP_DAMAGECODE_MASTER")
public class DamageCode implements Serializable{
   
    private static final long serialVersionUID = 3983076779206397201L;

    @Id
    @Column(name = "DAMAGE_CODE")
    private String damageCodeId;
    
    @Column(name = "DESCRIPTION")
    private String description;
    
    @Column(name = "DAMAGE_SEVERITY_CODE")
    private String damageSeverityCode;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TERMINAL_ID", referencedColumnName = "TERMINAL_ID")
    private Terminal terminal;
    
    @Column(name = "CREATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDatetime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "VERSION")
    private int version;

    @Column(name = "ISDELETED")
    private String isDeleted;
    
    @Column(name = "DAMAGE_TYPE_CODE")
    private String damageTypeCode;
       
    public String getDamageSeverityCode() {
        return damageSeverityCode;
    }

    public void setDamageSeverityCode(String damageSeverityCode) {
        this.damageSeverityCode = damageSeverityCode;
    }

    public String getDamageTypeCode() {
        return damageTypeCode;
    }

    public void setDamageTypeCode(String damageTypeCode) {
        this.damageTypeCode = damageTypeCode;
    }

   
    
    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDatetime() {
        return lastUpdatedDatetime;
    }

    public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
        this.lastUpdatedDatetime = lastUpdatedDatetime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }    
   
    public String getDamageCode() {
        return damageCodeId;
    }

    public void setDamageCode(String damageCode) {
        this.damageCodeId = damageCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public void setTerminal(Terminal terminal) {
        this.terminal = terminal;        
    }   

    @Override
    public String toString() {
        return "DamageCode [damageCodeId=" + damageCodeId + ", description=" + description + ", damageSeverityCode="
                + damageSeverityCode + ", terminal=" + terminal
                + ", createdDatetime=" + createdDatetime + ", createdBy=" + createdBy + ", lastUpdatedDatetime="
                + lastUpdatedDatetime + ", lastUpdatedBy=" + lastUpdatedBy + ", version=" + version + ", isDeleted="
                + isDeleted + ", damageTypeCode=" + damageTypeCode + "]";
    }    
}
