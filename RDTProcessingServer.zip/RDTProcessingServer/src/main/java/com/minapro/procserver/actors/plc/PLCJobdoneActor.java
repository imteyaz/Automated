package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.QCPLCConstants.DSCH;
import static com.minapro.procserver.util.QCPLCConstants.FORTYSINGLE;
import static com.minapro.procserver.util.QCPLCConstants.GANTRY_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.LOAD;
import static com.minapro.procserver.util.QCPLCConstants.SINGLE;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER1_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.T1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.T2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.TANDEM;
import static com.minapro.procserver.util.QCPLCConstants.TWENTYSINGLE;
import static com.minapro.procserver.util.QCPLCConstants.TWIN;
import static com.minapro.procserver.util.RDTProcessingServerConstants.BACKREACH_EVENT;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING_MINIMIZE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_MOVE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GENERALLIFT_OPERATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_BACKREACH_START_VAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_HOIST_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_TROLLEY_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.events.BackReachEvent;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.ContainerScreenMinimizeEvent;
import com.minapro.procserver.events.plc.GeneralLiftOperationEvent;
import com.minapro.procserver.events.plc.ManualConfirmationAlertEvent;
import com.minapro.procserver.events.plc.PLCJobdoneEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/*
 * 
 * <p> Actor responsible for Sending jobdone to containerMove Actor <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class PLCJobdoneActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(PLCJobdoneActor.class);
  
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
    private static final String WAITING_MANUAL_CONFIRMATION = "Waiting for Manual Confirmation";
    private static final String DRASTIC_GANTRY_CHANGE_MSG = "Drastic gantry change detected. Please confirm this job manually";
    private static final String JOB_NOT_FOUND_IN_JOBLIST_MSG = "Unable to find the container in job list. Please confirm this move manually";
    private static final String SAME_LOCATION_DETECTED_MSG = "Detected the same location as previous move. Please confirm this job manually";
    private static final String NO_CONTAINER_AT_LOCATION_MSG = "Could not find container at detected location.Please confirm this move manually";
    private static final String GENEREL_LIFT_MSG = "Please confirm this move manually since previous one was General lift";
    private static final String UNABLE_TO_FIND_LOCATION_MSG = "Identified location doesn't match with vessel profile. Please confirm this move manually";
    private static final String MANUAL_CONFIRM_MSG = "Please confirm this move manually";
   
    @Override
    /**
     * Handles  PLCJobdoneEvent
     */
    public void onReceive(Object message) throws Exception {

        Container plcContainer = null;
        JobListContainer joblistContainer = null;
        JobListContainer twinContainer = null;

        boolean detected = false;
        boolean isBackReachDetected;
        boolean sameLocation = false;

        String eventTypeID;

        String dateString = DATE_FORMATTER.format(new Date());

        if (message instanceof PLCJobdoneEvent) {

            PLCJobdoneEvent jobDoneEvent = (PLCJobdoneEvent) message;
            String node = jobDoneEvent.getNode();
            String userId = jobDoneEvent.getUserId();
            String spreaderId = jobDoneEvent.getSpreaderId();
            double weightFromPLC = Double.parseDouble(jobDoneEvent.getContainerWeight());

            boolean isJobdone = true;
            String shiftedCellLocation = null;
            String jobType = "";

            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " RECEIVED JOB DONE FROM :" + spreaderId);

            /*
             * Resetting following flags for the next move
             */
            RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER1_LOCKEDUP, false);
            RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER2_LOCKEDUP, false);
            RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);

            // Reset backreach flag for the current move
            RDTPLCCacheManager.getInstance().addBackreachDetected(userId, false);

            try {
                // check if it's first Container move event of user
                boolean firstTimeflag = RDTPLCCacheManager.getInstance().getFirstTimeMapping(userId);
                boolean plcIgonreStatus = RDTPLCCacheManager.getInstance().getPlcIgnoreEntry(userId);

                // Check current job type from the joblist
                ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId, node);

                if (jobList != null && !jobList.isEmpty()) {
                    joblistContainer = (new ArrayList<JobListContainer>(jobList.values())).get(0);
                    jobType = joblistContainer.getContainerId();
                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " JOBLIST IS EMPTY");
                }                           
                
                if (jobType.startsWith("HATCHCOVER") || jobType.startsWith("MANCAGE")
                        || jobType.startsWith("BREAKBULK")) {
                    generalLiftOperation(userId, node, jobType, DATE_FORMATTER);
                } else {
                    if ((!firstTimeflag) && (!plcIgonreStatus)) {

                        waitUntilUnlockSubscribersExecuted(detected, userId, spreaderId);
                        
                        // To identify if back reach job itself is first operation
                        double[] lockSidePositions = PLCEventUtil.getInstance().getLockingTimePositions(node, spreaderId, true);
                        double[] unLockSidePositions = PLCEventUtil.getInstance().getUnLockingTimePositions(node, spreaderId,
                                true);    
                        
                        double[] lockDelta = PLCEventUtil.getInstance().getDeltaValues(node, spreaderId, true);
                        double[] unLockDelta = PLCEventUtil.getInstance().getDeltaValues(node, spreaderId, false);

                        ApplicationParameter qcParameter = RDTPLCCacheManager.getInstance().getApplicationParamter(
                                node + "_WSGANTRYLEGTROLLEYVALUE");
                        double wsLegTrolleyvalue = Double.parseDouble(qcParameter.getParameterValue());

                        String moveType = PLCEventUtil.getInstance().checkMoveType(lockSidePositions, userId, node);

                        // Check lock-lift-unlock happens at same side (i.e either on vessel (DISCH)
                        // or between the legs (LOAD)
                        if (LOAD.equalsIgnoreCase(moveType)) {
                            double backReachPosition = Double.parseDouble(DeviceCommParameters.getInstance()
                                    .getCommParameter(QC_BACKREACH_START_VAL));

                            // If unlock happens between the legs
                            if ((unLockSidePositions[0] < wsLegTrolleyvalue)
                                    && (unLockSidePositions[0] > backReachPosition)) {
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : UnlockTimePosition   :"
                                        + unLockSidePositions[0]);
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : WSGANTRYLEGTROLLEYVALUE   :"
                                        + wsLegTrolleyvalue);
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : Not a proper jobdone   :" + userId);
                                PLCEventUtil.getInstance().raiseNonVesselPosAlert(userId, node, unLockSidePositions[0]);
                                isJobdone = false;
                            }
                        } else if (DSCH.equalsIgnoreCase(moveType) && unLockSidePositions[0] > wsLegTrolleyvalue) {
                            // If unlock happens on vessel
                            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH : UnlockTimePosition   :"
                                    + unLockSidePositions[0]);
                            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH : WSGANTRYLEGTROLLEYVALUE   :"
                                    + wsLegTrolleyvalue);
                            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH : Not a proper jobdone   :" + userId);
                            isJobdone = false;
                        }

                        // If it is a proper job done
                        if (isJobdone) {
                            int[] positionsDelta = getTrolleyHoistGantryDelta(userId, lockSidePositions,
                                    unLockSidePositions, lockDelta, unLockDelta, moveType);

                            /*
                             * Difficult to derive exact bay ID in case of drastic bay change due to asymmetric gaps
                             * between bay's in each vessel
                             */
                            if (positionsDelta[2] > 1) {

                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "Drastic Change of Gantry Detected :  :"
                                        + userId);
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, WAITING_MANUAL_CONFIRMATION);

                                ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance().generateManualAlertEvent(userId,
                                		DRASTIC_GANTRY_CHANGE_MSG);
                                PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(
                                        manualConfirmationAlert);
                                // Ignore PLC reading for the next move, since it needs to be confirmed manually
                                RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);

                            } else {

                                // Check BackReach detected flag, Will be set in getLockingTimePositions()
                                // and getUnLockingTimePositions()
                                isBackReachDetected = RDTPLCCacheManager.getInstance().getBackreachDetected(userId);

                                PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(node);

                                if (!isBackReachDetected) {

                                    if (!("GENERALLIFT".equalsIgnoreCase(RDTPLCCacheManager.getInstance()
                                            .getPreviousJobType(userId)))) {
                                        if (DSCH.equalsIgnoreCase(moveType)) {
                                            /*
                                             * In case of DISCH, Location already derived in
                                             * ContainerIDfromPLCDetectionActor() No need to derive again
                                             */
                                            shiftedCellLocation = RDTPLCCacheManager.getInstance()
                                                    .getCurrentCellLocationOfUser(userId);
                                        } else {
                                            shiftedCellLocation = PLCEventUtil.getInstance().getShiftedCellLocation(
                                                    userId, positionsDelta, moveType);
                                        }
                                        

                                        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Job type assigment is done");
                                        RDTPLCCacheManager.getInstance().jobTypeCacheAssigment(
                                                RDTPLCCacheManager.getInstance().getCurrentJobTypeCache());

                                        /*
                                         * Check if previous location detected again for the current move. This
                                         * information is fetched from getShiftedCellLocation()
                                         */
                                        sameLocation = RDTPLCCacheManager.getInstance().getSameLocationDetectedCache(
                                                userId);

                                        String[] cellTokens = shiftedCellLocation.split("\\.");
                                        boolean isValidLocation = RDTVesselProfileCacheManager.getInstance().validateCell(userId, 
                                        		cellTokens[0], cellTokens[1], cellTokens[2]);
                                        logger.logMsg(LOG_LEVEL.INFO, userId, 
                                        		"VALIDATING Shifted Cell Location - " + shiftedCellLocation +" RESULT=" + isValidLocation);
                                        if(!isValidLocation){
                                        	initiateManualConfirmation(node, userId, "Detected location " 
                                        			+ shiftedCellLocation + " doesn't match with vessel profile. Please confirm this move manually");
                                        	return;
                                        }

                                        // Store derived cell location for next move
                                        RDTPLCCacheManager.getInstance().addCurrentCellLocationOfUser(userId,
                                                shiftedCellLocation);

                                        if(LOAD.equals(moveType)){
                                        	logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                    " LOAD case - Getting container from SelectedJob Cache");
                                        	String selectedContainerId = RDTCacheManager.getInstance().getSelectedJob(node);
                                        	if(selectedContainerId != null && selectedContainerId.endsWith(LOAD)){
                                        		plcContainer = new Container();
                                        		plcContainer.setContainerID(selectedContainerId.replace(LOAD, ""));                                        		
                                        	}
                                        }else {
                                        	// get the container details on the derived CellLocation from Bay plan
                                        	plcContainer = RDTVesselProfileCacheManager.getInstance().getContainerFromCell(
                                                userId, cellTokens[0], cellTokens[1], cellTokens[2], moveType);

                                        	if (plcContainer == null) {
                                        		logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                    " Could not found container in Bay plan");
                                        		plcContainer = PLCEventUtil.getInstance().lookForContainerInJobList(userId,
                                                    shiftedCellLocation, jobList, moveType);
                                        	}
                                        }

                                        if (plcContainer != null) {

                                            if (!sameLocation) {

                                                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                        " GOT THE CONTAINER FROM BAY PROFILE");
                                                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                        " From PLC Location :" + shiftedCellLocation
                                                                + " Container ID :" + plcContainer.getContainerID());

                                                checkContainerWeightMissmatch(userId, plcContainer, weightFromPLC,
                                                        node);

                                                // Sending Automatic Job Done Event to Device
                                                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                        " Sending Job done Event of User :" + userId);
                                                ContainerMoveEvent movement = new ContainerMoveEvent();

                                                // setting Job done Event
                                                eventTypeID = DeviceEventTypes.getInstance().getEventType(
                                                        CONTAINER_MOVE);
                                                movement.setEventType(eventTypeID);
                                                movement.setUserID(userId);
                                                movement.setTimeStamp(dateString);
                                                String uuid = UUID.randomUUID().toString();
                                                movement.setEventID(uuid);
                                                movement.setEquipmentID(node);
                                                movement.setTerminalID(DeviceCommParameters.getInstance()
                                                        .getCommParameter(TERMINAL_KEY));
                                                movement.setAutomaticFlag(true);
                                                movement.setPreJobConfirmation(false);
                                                movement.setPlcDerivedLocation(shiftedCellLocation);
                                                movement.setMoveType(moveType);

                                                /*
                                                 * To set the container ID's. need to check the job type whether its
                                                 * Single, Twin or Tandem In case of Twin and Tandem, corresponding
                                                 * containers ID's will be fetched from getTwinContainerId() &
                                                 * getTandemContainerIDs() of detected container in Bay plan
                                                 */
                                                double spreaderSize = RDTPLCCacheManager.getInstance()
                                                        .getSpreaderSizeDetails(userId + spreaderId);

                                                boolean isTandemDetected = RDTPLCCacheManager.getInstance()
                                                        .getTandemDetectionDetails(userId);                                                
                                                
												if(isTandemDetected){
                                            		movement.setPlcDerivedJobType(TANDEM);
                                            	}else if(spreaderSize == 2020){
                                            		movement.setPlcDerivedJobType(TWIN);
                                            	}else {
                                            		movement.setPlcDerivedJobType(SINGLE);
                                            	}
												
												JobListContainer plcDerivedJob = null;
												if(jobList != null){
													plcDerivedJob = jobList.get(plcContainer.getContainerID()+moveType);
												}
												
												if(plcDerivedJob == null){
													logger.logMsg(LOG_LEVEL.WARN, userId, "Unable to retrieve from job list-" + plcContainer);
													initiateManualConfirmation(node, userId, JOB_NOT_FOUND_IN_JOBLIST_MSG);
													return;
												}

                                                /* In case of Tandem, need to check 4 containers or 2 containers */
                                                if (isTandemDetected) {
                                                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                            " PLC DETECTED TANDEM CONTAINER");

                                                    String[] listOfContainers = null;

                                                    if (plcDerivedJob != null) {
                                                        listOfContainers = plcDerivedJob.getTandemContainerIDs();
                                                    }

                                                    if (listOfContainers != null && listOfContainers.length > 0) {

                                                        logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                                " RECEIVED TANDEM CONTAINERS FROM BAY PROFILE");

                                                        String[] fromLocations = new String[4];
                                                        String[] toLocations = new String[4];

                                                        int i = 0;
                                                        for (String containerId : listOfContainers) {
                                                            JobListContainer container = jobList.get(containerId+moveType);
                                                            fromLocations[i] = container.getFromLocation();
                                                            toLocations[i] = container.getToLocation();
                                                            i++;
                                                        }

                                                        if (i == 3) {
                                                            logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                                    " FOUR CONTAINERS ARE PLANNED AS TANDEM");
                                                            movement.setContainerIDs(plcContainer.getContainerID()
                                                                    + ROW_SEPARATOR + listOfContainers[0]
                                                                    + ROW_SEPARATOR + listOfContainers[1]
                                                                    + ROW_SEPARATOR + listOfContainers[2]);
                                                            movement.setFromLocations(plcDerivedJob.getFromLocation()
                                                                    + ROW_SEPARATOR + fromLocations[0]
                                                                    + ROW_SEPARATOR + fromLocations[1]
                                                                    + ROW_SEPARATOR + fromLocations[2]);
                                                            movement.setToLocations(plcDerivedJob.getToLocation()
                                                                    + ROW_SEPARATOR + toLocations[0]
                                                                    + ROW_SEPARATOR + toLocations[1] 
                                                                    + ROW_SEPARATOR + toLocations[2]);
                                                        } else if (i == 1) {
                                                            logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                                    " TWO CONTAINERS ARE PLANNED AS TANDEM");
                                                            movement.setContainerIDs(plcContainer.getContainerID()
                                                                    + ROW_SEPARATOR + listOfContainers[0]);
                                                            movement.setFromLocations(plcDerivedJob.getFromLocation()
                                                                    + ROW_SEPARATOR + fromLocations[0]);
                                                            movement.setToLocations(plcDerivedJob.getToLocation()
                                                                    + ROW_SEPARATOR + toLocations[0]);
                                                        }
                                                    } else {

                                                        logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                                " DO NOT GET TANDEM CONTAINERS FROM BAY PROFILE");
                                                        // At least to send one container confirmation back to User
                                                        movement.setContainerIDs(plcContainer.getContainerID());
                                                        movement.setFromLocations(plcDerivedJob.getFromLocation());
                                                        movement.setToLocations(plcDerivedJob.getToLocation());
                                                    }
                                                } else if (spreaderSize == 20 || spreaderSize == 40) {
                                                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                            " PLC DETECTED SINGLE CONTAINER");

                                                    movement.setContainerIDs(plcContainer.getContainerID());
                                                    movement.setFromLocations(plcDerivedJob.getFromLocation());                                                 
                                                    movement.setToLocations(plcDerivedJob.getToLocation());
                                                } else if (spreaderSize == 2020) {

                                                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                            " PLC DETECTED TWIN CONTAINER");
                                                    twinContainer = jobList.get(plcDerivedJob.getTwinContainerId()+moveType);
                                                    if (twinContainer != null) {
                                                        movement.setContainerIDs(plcContainer.getContainerID()
                                                                + ROW_SEPARATOR + twinContainer.getContainerId());
                                                        movement.setFromLocations(plcDerivedJob.getFromLocation()
                                                                + ROW_SEPARATOR + twinContainer.getFromLocation());
                                                        movement.setToLocations(plcDerivedJob.getToLocation()
                                                                + ROW_SEPARATOR + twinContainer.getToLocation());
                                                    } else {
                                                        logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                                " FROM BAY PROFILE ITS A SINGLE CONTAINER");
                                                        movement.setContainerIDs(plcContainer.getContainerID());
                                                        movement.setFromLocations(plcDerivedJob.getFromLocation());
                                                        movement.setToLocations(plcDerivedJob.getToLocation());
                                                    }
                                                }

                                                // Sending job done to container Move Actor
                                                getSender().tell(movement, null);

                                                // Resetting tandem flag for next move
                                                RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId,
                                                        false);

                                                // Sending Job done Event to EsperActor(Akka scheduler) for detecting
                                                // Delay Recording
                                                RDTProcessingServer.getInstance().getEsperActor().tell(movement, null);

                                                if (LOAD.equalsIgnoreCase(moveType)) {
                                                    PLCEventUtil.getInstance().sendWrongLocationDetected(userId,
                                                    		plcDerivedJob, shiftedCellLocation, node);
                                                }

                                            } else {
                                                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Same Location Detected :"
                                                        + shiftedCellLocation);
                                                // Pushing all Current Cache values into Previous Cache
                                                PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(node);
                                                RDTPLCCacheManager.getInstance().addSameLocationDetectedCache(userId,
                                                        false);
                                                initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);

                                                logger.logMsg(LOG_LEVEL.DEBUG, userId, WAITING_MANUAL_CONFIRMATION);

                                                ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance().generateManualAlertEvent(
                                                        userId, SAME_LOCATION_DETECTED_MSG);
                                                PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(
                                                        manualConfirmationAlert);

                                                // Ignore PLC reading for the next move, since it needs to be confirmed manually
                                                RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);

                                            }
                                        } else {

                                            logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                                    " Could not find the container at Location :" + shiftedCellLocation);
                                            // Pushing all Current Cache values into Previous Cache
                                            PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(node);
                                            initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);

                                            logger.logMsg(LOG_LEVEL.DEBUG, userId, WAITING_MANUAL_CONFIRMATION);

                                            ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance().generateManualAlertEvent(
                                                    userId, NO_CONTAINER_AT_LOCATION_MSG);
                                            PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(
                                                    manualConfirmationAlert);

                                            // Ignore PLC reading for the next move, since it needs to be confirmed
                                            // manually
                                            RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);

                                        }

                                    } else {
                                        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Previous Job was General Lift:");
                                        ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance().generateManualAlertEvent(
                                                userId, GENEREL_LIFT_MSG);
                                        PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(
                                                manualConfirmationAlert);

                                        // Ignore PLC reading for the next move, since it needs to be confirmed manually
                                        RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);
                                    }
                                } else {
                                    generateBackReachEvent(userId, dateString);
                                }
                            }
                        } else {
                            logger.logMsg(LOG_LEVEL.DEBUG, userId,
                                    " Ignore Detection since Container Lifted and placed at same location:  :");
                            // Restoring the previous move type as it is
                            String lastMoveType = RDTPLCCacheManager.getInstance().getMoveTypeOfUser(userId);
                            RDTPLCCacheManager.getInstance().addMoveTypeOfUser(userId, lastMoveType);
                            initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);
                        }
                    } else {
                        if (firstTimeflag) {
                            double spreaderSize = RDTPLCCacheManager.getInstance().getSpreaderSizeDetails(
                                    userId + spreaderId);

                            if (spreaderSize == 20 || spreaderSize == 40) {
                                if (spreaderSize == 20) {
                                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " SINGLE TWINTY");
                                    RDTPLCCacheManager.getInstance().addPreviousJobType(userId, TWENTYSINGLE);
                                } else if (spreaderSize == 40) {
                                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " SINGLE FORTY");
                                    RDTPLCCacheManager.getInstance().addPreviousJobType(userId, FORTYSINGLE);
                                }
                            } else if (spreaderSize == 2020) {
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, " TWIN CONTAINER");
                                RDTPLCCacheManager.getInstance().addPreviousJobType(userId, TWIN);
                            }

                            // Check BackReach detected flag, Will be set in getLockingTimePositions()
                            // and getUnLockingTimePositions()
                            isBackReachDetected = RDTPLCCacheManager.getInstance().getBackreachDetected(userId);

                            if (isBackReachDetected) {
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "Identified backreach job as First job :");
                                generateBackReachEvent(userId, dateString);
                            } else {
                                logger.logMsg(LOG_LEVEL.DEBUG, userId, "First Time Job Needs to be confirmed manually :");
                                createFirstJobManualConfirmAlert(userId, node);
                            }
                        } else {
                            logger.logMsg(LOG_LEVEL.DEBUG, userId, WAITING_MANUAL_CONFIRMATION);
                            ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance()
                            		.generateManualAlertEvent(userId, MANUAL_CONFIRM_MSG);
                            PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(manualConfirmationAlert);
                        }
                        // Pushing all Current Cache values into Previous Cache
                        PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(node);
                    }
                }
                // Resetting tandem flag for next move
                RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId, false);
            } catch (Exception e) {
            	initiateManualConfirmation(node, userId, UNABLE_TO_FIND_LOCATION_MSG);
                logger.logException("Caught exception while processing PLCJobdoneActor - ", e);
            }
        }
    }

    /**
     * Initiates the manual confirmation alert to the user and flushes PLC related cache
     * @param equipmentId
     * @param userId
     * @param message
     */
    private void initiateManualConfirmation(String equipmentId, String userId, String message) {
    	 // Pushing all Current Cache values into Previous Cache
        PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(equipmentId);

        logger.logMsg(LOG_LEVEL.DEBUG, userId, WAITING_MANUAL_CONFIRMATION);
        ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance()
        		.generateManualAlertEvent(userId, message);
        PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(manualConfirmationAlert);

        // Ignore PLC reading for the next move, since it needs to be confirmed manually
        RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);
        RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId, false);		
	}

	/**
     * Creates the MinaPro Alert for first job confirmation to be done manually and passes to master actor for further processing
     * @param userId
     * @param equipmentId
     */
	private void createFirstJobManualConfirmAlert(String userId, String equipmentId) {
		String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(userId);
		
		if (!RDTCacheManager.getInstance().isOperatorAvailable(userId) || inspectionStatus == null) {
			logger.logMsg(LOG_LEVEL.INFO, userId, "Operator marked unavailable or not completed checklist inspection. Ignore");
			return;
		}
		
		MinaProAlertEvent alert = new MinaProAlertEvent();
        alert.setAlertCode(ALERTCODE.QC_FIRST_JOB_CONFIRM_ALERT);
        alert.setUserID(userId);
        alert.setOperatorId(userId);
        alert.setEquipmentID(equipmentId);
        
        getSender().tell(alert, null);		
	}

	/**
     * 
     * <p> Responsible for sending back reach event to master Actor </p>
     * 
     * @param userId
     * @param dateString
     */
    private void generateBackReachEvent(String userId, String dateString) {
        // Sending BackReach Event Detected to Device
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Sending BackReach Event of User :");

        RDTPLCCacheManager.getInstance().addBackreachDetected(userId, false);
        String backReachType = RDTPLCCacheManager.getInstance().getBackreachType(userId);
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(BACKREACH_EVENT);

        BackReachEvent backReach = new BackReachEvent();
        backReach.setEventType(eventTypeID);
        backReach.setUserID(userId);
        backReach.setTimeStamp(dateString);
        String uuid = UUID.randomUUID().toString();
        backReach.setEventID(uuid);
        backReach.setBackReachType(backReachType);
        backReach.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));

        getSender().tell(backReach, null);
    }

    /**
     * 
     * <p> Responsible for sending container minimise event to master Actor. Just to avoid the container handling screen
     * hanging if job done detection fails </p>
     * 
     * @param userId
     * @param formatter
     */
    private void initaiteContainerMinimizeEvent(String userId, SimpleDateFormat formatter) {
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Send Container Screen Minimize Event :");

        ContainerScreenMinimizeEvent screenMinimizer = new ContainerScreenMinimizeEvent();

        // setting Container screen minimize Event to device
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(CONTAINER_HANDLING_MINIMIZE);
        String dateString = formatter.format(new Date());

        screenMinimizer.setUserID(userId);
        screenMinimizer.setTimeStamp(dateString);
        screenMinimizer.setEventType(eventTypeID);
        screenMinimizer.setEventID(UUID.randomUUID().toString());
        screenMinimizer.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
        screenMinimizer.setMessage("Minimize");

        getSender().tell(screenMinimizer, null);
    }

    /**
     * 
     * <p> Responsible for sending general lift operation event to Master Actor </p>
     * 
     * @param user
     * @param node
     * @param jobtype
     * @param formatter
     */
    public void generalLiftOperation(String user, String node, String jobType, SimpleDateFormat formatter) {
        PLCEventUtil.getInstance().movingCurrentCacheToPreviousCache(node);

        GeneralLiftOperationEvent generalOpsEvent = new GeneralLiftOperationEvent();
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(GENERALLIFT_OPERATION);

        String dateString = formatter.format(new Date());

        generalOpsEvent.setUserID(user);
        generalOpsEvent.setEquipmentID(node);
        generalOpsEvent.setEventID(UUID.randomUUID().toString());
        generalOpsEvent.setEventType(eventTypeID);
        generalOpsEvent.setJobString(jobType);
        generalOpsEvent.setJobDone(true);
        generalOpsEvent.setTimeStamp(dateString);
        generalOpsEvent.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));

        getSender().tell(generalOpsEvent, null);

        // Do not consider general lift operations for QC live performance calculation

        // Ignore PLC reading for the next move, since it needs to be confirmed manually
        RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(user, true);
    }

    /**
     * 
     * <p> Function checks whether all unlock Subscribers are executed, because unlock subscribers and
     * QCSpreader1Subscriber & QCSpreader1Subscriber will be in race to get execute. If QCSpreader subscriber executes
     * first, will send job done to PLCJobedone Actor which fails to fetch the unlocktime positions which are not
     * executed yet. To avoid this, waiting/checking in this function whether all unlock subscribers executed or not
     * </p>
     * 
     * @param detected
     * @param userId
     * @param spreaderId
     */
    public void waitUntilUnlockSubscribersExecuted(boolean detected, String userId, String spreaderId) {
        int sp1Id = Integer.parseInt(spreaderId.replaceAll("[\\D]", ""));
        String tPosTag = null;
        String hPosTag = null;
        String gPosTag = null;

        if (sp1Id == 1) {
            tPosTag = T1_POSITION_UNLOCK;
            hPosTag = H1_POSITION_UNLOCK;
            gPosTag = GANTRY_UNLOCK;
        } else if (sp1Id == 2) {
            tPosTag = T2_POSITION_UNLOCK;
            hPosTag = H2_POSITION_UNLOCK;
            gPosTag = GANTRY_UNLOCK;
        }

        boolean unLockDetected = detected;
        while (!unLockDetected) {
            boolean t1falg = RDTPLCCacheManager.getInstance().getuserToUnlockPositionMapping(
                    userId + tPosTag + spreaderId);
            boolean h1falg = RDTPLCCacheManager.getInstance().getuserToUnlockPositionMapping(
                    userId + hPosTag + spreaderId);
            boolean gfalg = RDTPLCCacheManager.getInstance().getuserToUnlockPositionMapping(
                    userId + gPosTag + spreaderId);

            if (t1falg && h1falg && gfalg) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Unlock Subscribers executed ");
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " SpreaderID : " + sp1Id);

                unLockDetected = true;
                RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(userId + tPosTag + spreaderId, false);
                RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(userId + hPosTag + spreaderId, false);
                RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(userId + gPosTag + spreaderId, false);
            } else {
                logger.logMsg(LOG_LEVEL.TRACE, userId, " Waiting for Unlock Subscribers to finish ");
                unLockDetected = false;
            }
        }
    }

    /**
     * 
     * <p> Identifies the number of row shifts, tier shifts and bay shifts from previous move to the current move.
     * 
     * Determines the row,tier & gantry shifts by dividing the delta of positions with following configured values in DB
     * which are basically container dimensions.
     * 
     * QC_TROLLEY_CHANGE_DELTA = 243 cm or 8 ft -> Width of the container QC_HOIST_CHANGE_DELTA = 262 cm or 8.6 ft ->
     * Height of the container
     * 
     * Length of container = 20 ft or 40ft
     * 
     * </p>
     * 
     * <p> Gantry change: QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA = 10ft -> To move the operation from Twin to Single QC
     * operator has to move the gantry of 10ft
     * 
     * In case of bay change operator moves 40ft QC_FORTY_GANTRY_CHANGE_DELTA
     * 
     * </p>
     * 
     * @param userId
     * @param lockSidePositions
     * @param unLockSidePositions
     * @param lockDelta
     * @param unLockDelta
     * @param moveType
     * @return int[]
     */
    public int[] getTrolleyHoistGantryDelta(String userId, double[] lockSidePositions, double[] unLockSidePositions,
            double[] lockDelta, double[] unLockDelta, String moveType) {

        int[] positionsDelta = null;

        positionsDelta = new int[4];
        double trolleyDiff = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                QC_TROLLEY_CHANGE_DELTA));
        double hoistDiff = Double.parseDouble(DeviceCommParameters.getInstance()
                .getCommParameter(QC_HOIST_CHANGE_DELTA));
        double gantryDiff = PLCEventUtil.getInstance().getGantryDiff(userId);

        if (DSCH.equalsIgnoreCase(moveType)) {
            PLCEventUtil.getInstance().getTrolleyHoistGantryDelta(userId, lockSidePositions, unLockSidePositions,
                    lockDelta, gantryDiff);
        } else if (LOAD.equalsIgnoreCase(moveType)) {

            // Since it is Load Op, we need to consider the delta of Positions at UnLocking Time
            String lastMoveType = RDTPLCCacheManager.getInstance().getMoveTypeOfUser(userId);

            if (DSCH.equalsIgnoreCase(lastMoveType)) {
                unLockDelta[0] = unLockSidePositions[0] - lockSidePositions[3];
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " ======PREVIOUS MOVE IS DISCHARGE ======= : ");
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " =======HOIST DIFF ======== : ");
                if ((unLockSidePositions[1] > 0 && lockSidePositions[4] > 0)
                        || (unLockSidePositions[1] < 0 && lockSidePositions[4] < 0)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " =======Both Hoist values are Positive or Negative========= : ");
                    unLockDelta[1] = unLockSidePositions[1] - lockSidePositions[4];
                } else if (unLockSidePositions[1] < 0 && lockSidePositions[4] > 0) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " ======Current Hoist is Negative and Prev Hoist is Positive======: ");
                    unLockDelta[1] = -(Math.abs(unLockSidePositions[1]) + lockSidePositions[4]);
                } else if (unLockSidePositions[1] > 0 && lockSidePositions[4] < 0) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " ======Current Hoist is Positive and Prev Hoist is Negative======: ");
                    unLockDelta[1] = unLockSidePositions[1] + Math.abs(lockSidePositions[4]);
                }

                logger.logMsg(LOG_LEVEL.DEBUG, userId, " ========GANTRY DIFF =======: ");
                if ((unLockSidePositions[2] > 0 && lockSidePositions[5] > 0)
                        || (unLockSidePositions[2] < 0 && lockSidePositions[5] < 0)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " ======Both Gantry values are Positive or Negative======: ");
                    unLockDelta[2] = unLockSidePositions[2] - lockSidePositions[5];
                } else if (unLockSidePositions[2] < 0 && lockSidePositions[5] > 0) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " ======Current Gantry is Negative and Prev Gantry is Positive====== : ");
                    unLockDelta[2] = -(Math.abs(unLockSidePositions[2]) + lockSidePositions[5]);

                } else if (unLockSidePositions[2] > 0 && lockSidePositions[5] < 0) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " ======Current Gantry is Positive and Prev Gantry is Negative====== : ");
                    unLockDelta[2] = unLockSidePositions[2] + Math.abs(lockSidePositions[5]);
                }
            }

            // Checking cabin position moved left or right from the previous move
            if ((unLockDelta[0] >= trolleyDiff) || (unLockDelta[0] <= -trolleyDiff)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : Calculating Trolley Delta :");
                // No.of Rows shifted from previous move
                positionsDelta[0] = PLCEventUtil.getInstance().deltaRound(unLockDelta[0], trolleyDiff);

            }

            // Checking Hoist Position going down or up from the
            // previous move ( i.e tier change)
            if ((unLockDelta[1] >= hoistDiff) || (unLockDelta[1] <= -hoistDiff)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD : Calculating Hoist Delta :");
                positionsDelta[1] = PLCEventUtil.getInstance().deltaRound(unLockDelta[1], hoistDiff);
            }

            // Checking Gantry Position is changed from the previous move ( i.e Bay change)
            if ((unLockDelta[2] >= gantryDiff) || (unLockDelta[2] <= -gantryDiff)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD : Calculating Gantry Delta :");

                if (gantryDiff != 0) {

                    positionsDelta[2] = PLCEventUtil.getInstance().deltaRound(unLockDelta[2], gantryDiff);

                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : Gantry Diff is Zero ");
                    positionsDelta[2] = 0;
                }
            } else {

                if (unLockDelta[2] > 0) {

                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : Gantry moved towards Right:");
                    RDTPLCCacheManager.getInstance().addGantryMovingDirection(userId, "R");

                } else {

                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "LOAD : Gantry moved towards Left:");
                    RDTPLCCacheManager.getInstance().addGantryMovingDirection(userId, "L");
                }
            }

            if ((unLockDelta[0] > 0 && unLockDelta[0] < trolleyDiff)
                    || (unLockDelta[0] < 0 && unLockDelta[0] > -trolleyDiff)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD : Calculating Trolley Delta with Tolerence :");

                if ((unLockDelta[0] > 0) && ((trolleyDiff - unLockDelta[0]) < 121)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD: Positive Trolley Delta Tolerence :"
                            + (trolleyDiff - unLockDelta[0]));
                    positionsDelta[0] = 1;
                } else if ((unLockDelta[0] < 0) && ((trolleyDiff - Math.abs(unLockDelta[0])) < 121)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " LOAD: Negative Trolley Delta Tolerence :" + (Math.abs(unLockDelta[0]) - trolleyDiff));
                    positionsDelta[0] = -1;
                }
            }

            if ((unLockDelta[1] > 0 && unLockDelta[1] < hoistDiff)
                    || (unLockDelta[1] < 0 && unLockDelta[1] > -hoistDiff)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD : Calculating Hoist Delta with Tolerence :");

                if ((unLockDelta[1] > 0) && ((hoistDiff - unLockDelta[1]) < 131)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " LOAD: Positive Hoist Delta Tolerence :"
                            + (hoistDiff - unLockDelta[1]));
                    positionsDelta[1] = 1;
                } else if ((unLockDelta[1] < 0) && ((hoistDiff - Math.abs(unLockDelta[1])) < 131)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId,
                            " LOAD: Negative Hoist Delta Tolerence :" + (Math.abs(unLockDelta[1]) - hoistDiff));
                    positionsDelta[1] = -1;
                }
            }
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " ========================Type of Move======================== : ");
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Load Op. trolleyDelta is  :" + positionsDelta[0]);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Load Op. hoistDelta is  :" + positionsDelta[1]);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Load Op. GantryDelta is  :" + positionsDelta[2]);
        }
        return positionsDelta;
    }

    /**
     * 
     * <p> Responsible for sending container weight missmatch event to Master Actor then alert will be sent to QC UI
     * </p>
     * 
     * @param userId
     * @param plcContainer
     * @param weightFromPLC
     * @param equipmentId
     */
    public void checkContainerWeightMissmatch(String userId, Container plcContainer, double weightFromPLC,
            String equipmentId) {
        ApplicationParameter weightObjectFromDB = RDTPLCCacheManager.getInstance().getApplicationParamter(
                "CONTAINER_WEIGHT");
        double configuredWeight = Double.parseDouble(weightObjectFromDB.getParameterValue());

        double sixtyPercentOfWeight = (configuredWeight * 60) / 100;
        double maxWeight = configuredWeight + sixtyPercentOfWeight;
        double minWeight = configuredWeight - sixtyPercentOfWeight;

        // Sending Container Weight Miss-match Event to Device
        if ((weightFromPLC <= minWeight) || (weightFromPLC >= maxWeight)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Sending Container weight Miss match Event of User :" + userId);
            MinaProAlertEvent alert = new MinaProAlertEvent();
            alert.setAlertCode(ALERTCODE.QC_WEIGHT_MISSMATCH_ALERT);
            alert.setUserID(userId);
            alert.setOperatorId(userId);
            alert.setContainerId(plcContainer.getContainerID());
            alert.setActualWeight(String.valueOf(weightFromPLC));
            alert.setPlannedWeight(plcContainer.getWeight());
            alert.setEquipmentID(equipmentId);
            
            getSender().tell(alert, null);
        }
    }  
}
