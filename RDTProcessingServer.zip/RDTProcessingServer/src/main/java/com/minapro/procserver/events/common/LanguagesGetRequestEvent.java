package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class LanguagesGetRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = 3820351214436563633L;
}
