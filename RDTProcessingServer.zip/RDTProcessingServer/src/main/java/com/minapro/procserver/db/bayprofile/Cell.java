package com.minapro.procserver.db.bayprofile;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "MP_CELL_SPM")
public class Cell {
    @EmbeddedId
    private CellPk pk;

    @Column(name = "UNAVLB_IND")
    @Type(type = "yes_no")
    private Boolean isAvialable;

    @Column(name = "DOOR_DIRN_IND")
    @Type(type = "yes_no")
    private Boolean doorDirectionIndicator;

    @Column(name = "ONLY_MTY_CTR_ALLOWD_FLG")
    @Type(type = "yes_no")
    private Boolean onlyEmptyContainerAllowedFlag;

    @Column(name = "HOT_SPOT_FLG")
    @Type(type = "yes_no")
    private Boolean hotSpotFlag;

    @Column(name = "ALLOWD_RFR_TYPE")
    @Type(type = "yes_no")
    private Boolean reeferTypeFlag;

    @Column(name = "ALLOWD_45")
    @Type(type = "yes_no")
    private Boolean allowed45Flag;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false) })
    private VesselSection section;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false)
    private Vessel vessel;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false),
            @JoinColumn(name = "DK_UNDK_IND", referencedColumnName = "DK_UNDK_IND", insertable = false, updatable = false),
            @JoinColumn(name = "BAY_OFFSET", referencedColumnName = "BAY_OFFSET", insertable = false, updatable = false) })
    private Bay bay;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false),
            @JoinColumn(name = "DK_UNDK_IND", referencedColumnName = "DK_UNDK_IND", insertable = false, updatable = false),
            @JoinColumn(name = "BAY_OFFSET", referencedColumnName = "BAY_OFFSET", insertable = false, updatable = false),
            @JoinColumn(name = "ROW_OFFSET", referencedColumnName = "ROW_OFFSET", insertable = false, updatable = false) })
    private BayRow bayRow;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false),
            @JoinColumn(name = "DK_UNDK_IND", referencedColumnName = "DK_UNDK_IND", insertable = false, updatable = false),
            @JoinColumn(name = "BAY_OFFSET", referencedColumnName = "BAY_OFFSET", insertable = false, updatable = false),
            @JoinColumn(name = "TIER_OFFSET", referencedColumnName = "TIER_OFFSET", insertable = false, updatable = false) })
    private BayTier bayTier;

    public CellPk getPk() {
        return pk;
    }

    public void setPk(CellPk pk) {
        this.pk = pk;
    }

    public Boolean getIsAvialable() {
        return isAvialable;
    }

    public void setIsAvialable(Boolean isAvialable) {
        this.isAvialable = isAvialable;
    }

    public Boolean getDoorDirectionIndicator() {
        return doorDirectionIndicator;
    }

    public void setDoorDirectionIndicator(Boolean doorDirectionIndicator) {
        this.doorDirectionIndicator = doorDirectionIndicator;
    }

    public Boolean getOnlyEmptyContainerAllowedFlag() {
        return onlyEmptyContainerAllowedFlag;
    }

    public void setOnlyEmptyContainerAllowedFlag(Boolean onlyEmptyContainerAllowedFlag) {
        this.onlyEmptyContainerAllowedFlag = onlyEmptyContainerAllowedFlag;
    }

    public Boolean getHotSpotFlag() {
        return hotSpotFlag;
    }

    public void setHotSpotFlag(Boolean hotSpotFlag) {
        this.hotSpotFlag = hotSpotFlag;
    }

    public Boolean getReeferTypeFlag() {
        return reeferTypeFlag;
    }

    public void setReeferTypeFlag(Boolean reeferTypeFlag) {
        this.reeferTypeFlag = reeferTypeFlag;
    }

    public Boolean getAllowed45Flag() {
        return allowed45Flag;
    }

    public void setAllowed45Flag(Boolean allowed45Flag) {
        this.allowed45Flag = allowed45Flag;
    }

    public VesselSection getSection() {
        return section;
    }

    public void setSection(VesselSection section) {
        this.section = section;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public void setVessel(Vessel vessel) {
        this.vessel = vessel;
    }

    public Bay getBay() {
        return bay;
    }

    public void setBay(Bay bay) {
        this.bay = bay;
    }

    public BayRow getBayRow() {
        return bayRow;
    }

    public void setBayRow(BayRow bayRow) {
        this.bayRow = bayRow;
    }

    public BayTier getBayTier() {
        return bayTier;
    }

    public void setBayTier(BayTier bayTier) {
        this.bayTier = bayTier;
    }

}
