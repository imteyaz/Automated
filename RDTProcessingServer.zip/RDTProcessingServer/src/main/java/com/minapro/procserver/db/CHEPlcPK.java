package com.minapro.procserver.db;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CHEPlcPK implements Serializable {

    private static final long serialVersionUID = -7399897983383094973L;

    @Column(name = "NODE_ID")
    private String node;

    @Column(name = "TAG_TIME")
    private Timestamp tagTime;

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public Timestamp getTagTime() {
        return tagTime;
    }

    public void setTagTime(Timestamp tagTime) {
        this.tagTime = tagTime;
    }

    @Override
    public String toString() {
        return "CHEPlcPK [node=" + node + ", tagTime=" + tagTime + "]";
    }

}
