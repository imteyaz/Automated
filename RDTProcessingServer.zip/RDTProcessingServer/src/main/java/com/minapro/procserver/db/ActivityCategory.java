package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * <p> ValueObject holding the details of activity category. </p>
 * 
 * <p> Activity can be categorized into operational, non-operational etc </p>
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_ACTIVITYTYPES_MASTER")
public class ActivityCategory extends Audit implements Serializable {

    private static final long serialVersionUID = -6233317278064052278L;

    @Id
    @Column(name = "ACTIVITY_TYPE_ID", nullable = false)
    private String categoryId;

    @Column(name = "DESCRIPTION")
    private String description;

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
