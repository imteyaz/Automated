package com.minapro.procserver.util;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TANDEM_JOB_TYPE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TWIN_JOB_TYPE;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.minapro.procserver.db.QCJobListEntity;
import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class QCJObListProcedureExecutionProcessor {

    private MinaProApplicationLogger logger = new MinaProApplicationLogger(QCJObListProcedureExecutionProcessor.class);
    private static final QCJObListProcedureExecutionProcessor INSTANCE = new QCJObListProcedureExecutionProcessor();

    private final QCJobListDAO qcJobListDAO = QCJobListDAO.getInstnace();

    private QCJObListProcedureExecutionProcessor() {
    }

    public static QCJObListProcedureExecutionProcessor getInstance() {
        return INSTANCE;
    }

    /**
     * Step 2.1 Method is responsible for checking the existed Sparks created twin container list with the current
     * retrieved twin jobs list based on some business conditions. Depending on the business condition updating the
     * OperationCode and MinaProTwinSplit and TwinTandemId in currentRetrieved twin jobs list. Business Logic : If
     * current sparcs created twin job is exactly equal to existed sparcs created twin job making current job operation
     * code as 'R'
     * 
     * @param currentTwinJobsSet
     * @param twinTandemContainerJob
     * @param minaproTwinSplit
     * @param twinTandemId
     */
    public void checkCurrentSpacrCreatedTwinJobsWithExistedForModifications(
            Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet, TwinTandemContainerList twinTandemContainerJob,
            String minaproTwinSplit, String twinTandemId) throws NullPointerException {

        for (OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet) {

            String operationCode;
            String moveType = currentTwinJob.getMoveKind();

            String currentTwinJobContainer = currentTwinJob.getContainerID();
            String currentTwinJobRefContainer = currentTwinJob.getRefContainerID();

            String currentTwinJobFromLocation = currentTwinJob.getFromLocation();
            String currentTwinJobToLocation = currentTwinJob.getToLocation();

            String currentTwinJobRefFromLocation = currentTwinJob.getRefFromLocation();
            String currentTwinJobRefToLocation = currentTwinJob.getRefToLocation();

            String existedTwinJobContainer = twinTandemContainerJob.getContainerId();
            String existedTwinJobRefContainer = twinTandemContainerJob.getRefContainerId();

            String existedTwinJobFromLocation = twinTandemContainerJob.getFromLocation();
            String existedTwinJobToLocation = twinTandemContainerJob.getToLocation();

            String existedTwinJobRefFromLocation = twinTandemContainerJob.getRefContrFromLocation();
            String existedTwinJobRefToLocation = twinTandemContainerJob.getRefContrToLocation();

            if (currentTwinJobContainer.equalsIgnoreCase(existedTwinJobContainer)
                    && currentTwinJobRefContainer.equalsIgnoreCase(existedTwinJobRefContainer)
                    || (existedTwinJobContainer.equals(currentTwinJobRefContainer) && existedTwinJobRefContainer
                            .equals(currentTwinJobContainer))) {

                operationCode = "R";

                if (moveType.equalsIgnoreCase(DSCH)
                        && (!currentTwinJobFromLocation.equalsIgnoreCase(existedTwinJobFromLocation) || !currentTwinJobRefFromLocation
                                .equalsIgnoreCase(existedTwinJobRefFromLocation))) {
                    operationCode = "U";
                } else if (moveType.equalsIgnoreCase(LOAD)
                        && (!currentTwinJobToLocation.equalsIgnoreCase(existedTwinJobToLocation) || !currentTwinJobRefToLocation
                                .equalsIgnoreCase(existedTwinJobRefToLocation))) {
                    operationCode = "U";
                }
                logger.logMsg(LOG_LEVEL.TRACE, twinTandemId,
                        " --Current Twin Tandem Id Operation Code--".concat(operationCode));

                updateCurrentTwinJobs(currentTwinJob, operationCode, twinTandemId, minaproTwinSplit);
                /* Break Condition is not present in procedure added by UmaMahesh. */
                break;

            } else if ((currentTwinJobContainer.equalsIgnoreCase(existedTwinJobContainer) || currentTwinJobRefContainer
                    .equalsIgnoreCase(existedTwinJobRefContainer))
                    || (existedTwinJobContainer.equalsIgnoreCase(currentTwinJobRefContainer) || existedTwinJobRefContainer
                            .equalsIgnoreCase(currentTwinJobContainer))) {
                logger.logMsg(LOG_LEVEL.TRACE, twinTandemId,
                        " --Both Containers Are Not Same--Setting Operation Code to 'U'");
                operationCode = "U";
                updateCurrentTwinJobs(currentTwinJob, operationCode, twinTandemId, minaproTwinSplit);

            }

        }

    }

    /**
     * Update Sparcs Created Twin Jobs object with TwinTandemId and OperationCode and MinaPro Twin Split
     * 
     * @param currentTwinJob
     *            : Sparcs Current TwinJob
     * @param operationCode
     *            : It can be I or U or R
     * @param twinTandemId
     *            :Existed TwinTademId in Database .
     * @param minaproTwinSplit
     *            : Y or N
     */
    private void updateCurrentTwinJobs(OPUSTwinTandemJobsPOJO currentTwinJob, String operationCode,
            String twinTandemId, String minaproTwinSplit) {
        currentTwinJob.setOperationCode(operationCode);
        currentTwinJob.setTwinTandemId(twinTandemId);
        currentTwinJob.setMinaproTwinSplit(minaproTwinSplit);
    }

    /**
     * Step 3: Method is responsible for preparing the twinTandemId list which are not available in the current twin
     * sparcs list. Adding those id's to list and returning that list.
     * 
     * @param currentTwinJobsSet
     * @param existedSparcsCreatedTwinJobs
     * @return
     */

    public List<TwinTandemJobs> prepareDeletableJobsListFromCurrentJobs(Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet,
            List<TwinTandemJobs> existedSparcsCreatedTwinJobs) {

        logger.logMsg(
                LOG_LEVEL.INFO,
                String.valueOf(Thread.currentThread().getId()),
                " Started prepareDeletableJobsListFromCurrentJobs(), delete from TWINTANDEM tables as new refresh does not have the pair received");

        List<TwinTandemJobs> deleteRequiredTwinTadenmIdList = new ArrayList<TwinTandemJobs>();

        boolean isTwinIdDeletable = false;

        for (TwinTandemJobs twinJobs : existedSparcsCreatedTwinJobs) {

            Integer twinTandeemId = twinJobs.getTwinTandemId();
            logger.logMsg(LOG_LEVEL.TRACE, String.valueOf(Thread.currentThread().getId()), new StringBuilder(
                    "Existed Sparcs Created Twin Tandem Id").append(twinTandeemId).toString());

            for (OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet) {
                if (Integer.parseInt(currentTwinJob.getTwinTandemId()) == twinTandeemId) {
                    logger.logMsg(LOG_LEVEL.TRACE, String.valueOf(Thread.currentThread().getId()), new StringBuilder(
                            " Current Sparcs Twin Job Twin Tandem  Id:").append(currentTwinJob.getTwinTandemId())
                            .toString());
                    isTwinIdDeletable = true;
                    break;
                }
            }
            if (!isTwinIdDeletable) {
                deleteRequiredTwinTadenmIdList.add(twinJobs);
            }
        }
        logger.logMsg(LOG_LEVEL.TRACE, String.valueOf(Thread.currentThread().getId()), new StringBuilder(
                " Delete Required TwinTandem Jobs List:::").append(deleteRequiredTwinTadenmIdList).toString());
        return deleteRequiredTwinTadenmIdList;

    }

    /**
     * Step 4: Method is responsible for preparing separate list objects to insert or update based on following
     * conditions. If operator code is 'I' need to insert new records into
     * MP_TWINTANDEM_JOB_LIST,MP_TWINTANDEM_CONTAINER_LIST tables. If operator code is 'U' need to update
     * MP_TWINTANDEM_CONTAINER_LIST table all columns with new values. After above two steps need to re arrange the
     * sequence numbers in MP_JOB_LIST.to prepare sequence update list checking the following condition.
     * MinaproTwinSplit = 'N' . If insertList not null then need to insert new records into
     * MP_TWINTANDEM_JOB_LIST,MP_TWINTANDEM_CONTAINER_LIST tables. If updateNeededList is not null then need to update
     * MP_TWINTANDEM_CONTAINER_LIST table all columns with new values. If sequnceUpdateList is not null need to check
     * following conditions based that logic needs to Mp_Job_List with new sequnce values. Business Condition : If seqNo
     * > referenceSeqNo then update mp_job_list set seqNo = referenceSeqNo +0.1 where seqNo = seqNo else update
     * mp_job_list set seqNo = seqNo +0.1 where seqNo = referenceSeqNo
     * 
     * @param currentTwinJobsSet
     * @param rotationId
     * @param terminalId
     * @param equipmentId
     * @return
     * @throws NullPointerException
     *             ,InterruptedException
     * @throws SQLException
     */

    public void prepareInsertOrUpdateRequiredList(Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet, String rotationId,
            String terminalId, String equipmentId) throws NullPointerException, SQLException {

        logger.logMsg(LOG_LEVEL.INFO, String.valueOf(Thread.currentThread().getId()),
                " Started prepareInsertOrUpdateRequiredList() To Prepare Insert Or Update List For Existed Sparcs Twin Jobs");

        final List<TwinTandemJobs> insertList = new LinkedList<TwinTandemJobs>();
        final List<OPUSTwinTandemJobsPOJO> twinTandemContaierUpdateList = new LinkedList<OPUSTwinTandemJobsPOJO>();

        List<TwinTandemJobs> existedTwinJobs = qcJobListDAO.getExistedTwinJobsByRotation(rotationId);

        for (OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet) {
            String operationCode = currentTwinJob.getOperationCode();
            logger.logMsg(LOG_LEVEL.INFO, String.valueOf(Thread.currentThread().getId()), " Current Operation Code::"
                    + operationCode);

            if ("I".equalsIgnoreCase(operationCode)) {
                TwinTandemJobs twinJob = new TwinTandemJobs();
                twinJob.setTerminalId(terminalId);
                twinJob.setRotationId(rotationId);
                twinJob.setEquipmentId(equipmentId);
                twinJob.setSparcsTwinIndicator("Y");
                twinJob.setTwinSplit("N");
                twinJob.setJobType(getTwinOrTandemType(currentTwinJob));
                TwinTandemContainerList currentTwinTandemContainer = new TwinTandemContainerList(
                        currentTwinJob.getContainerID(), currentTwinJob.getToLocation(),
                        currentTwinJob.getFromLocation(), currentTwinJob.getRefContainerID(),
                        currentTwinJob.getRefFromLocation(), currentTwinJob.getRefToLocation());
                currentTwinTandemContainer.setTwinTandemId(twinJob);
                twinJob.getTwinTandemDetails().add(currentTwinTandemContainer);

                /*
                 * Scenario::Sparcs created Twin And Sparcs Created Twin Made as tandem at that time Sparcs created job
                 * is deleting and creating new job in TwinTandemJobs as SPARCS_TWIN_IND = N And TWIN_TANDEM_TYPE = 'TN'
                 * And Adding Two records in Twin Tandem Container List with same TwinTandemId.To Avoid Inserting
                 * Duplicate Records Insertion checking currentJob with the TwinTandemContainerList table if available
                 * ignoring the new record.
                 */

                boolean isCurrentJobInsertable = true;
                for (TwinTandemJobs twinJobs : existedTwinJobs) {
                    if (twinJobs == null) {
                        break;
                    }
                    for (TwinTandemContainerList existedTwinTandemCntr : twinJobs.getTwinTandemDetails()) {
                        if (existedTwinTandemCntr.getContainerId().equalsIgnoreCase(currentTwinJob.getContainerID())
                                || existedTwinTandemCntr.getContainerId().equalsIgnoreCase(
                                        currentTwinJob.getRefContainerID())
                                || existedTwinTandemCntr.getRefContainerId().equalsIgnoreCase(
                                        currentTwinJob.getContainerID())
                                || existedTwinTandemCntr.getRefContainerId().equalsIgnoreCase(
                                        currentTwinJob.getRefContainerID())) {

                            logger.logMsg(
                                    LOG_LEVEL.INFO,
                                    String.valueOf(Thread.currentThread().getId()),
                                    new StringBuilder(
                                            "Current Twin Job Container Already Available In TwinTandemContainer List table,")
                                            .append("Ignoring To Insert into database And Exiting From Loop")
                                            .append(" Container ::").append(currentTwinJob.getContainerID())
                                            .append(" Ref Container Id::").append(currentTwinJob.getRefContainerID())
                                            .toString());
                            isCurrentJobInsertable = false;
                            break;
                        }
                    }
                }

                if (isCurrentJobInsertable) {
                    insertList.add(twinJob);
                }

            } else if ("U".equalsIgnoreCase(operationCode)) {
                twinTandemContaierUpdateList.add(currentTwinJob);
            }

        }

        if (insertList != null && !insertList.isEmpty()) {
            logger.logMsg(LOG_LEVEL.INFO, rotationId + equipmentId, " Insert Twin Jobs List::" + insertList.toString());
            qcJobListDAO.saveMultipleObjects(insertList);
        }

        if (twinTandemContaierUpdateList != null && !twinTandemContaierUpdateList.isEmpty()) {

            qcJobListDAO.updateTwinTandemContainers(twinTandemContaierUpdateList);
        }

    }

    /**
     * Method is responsible for creating MinaPro Created Twin jobs and Sparcs Created Twin jobs based on
     * sparcsTwinIndicator property condition. if sparcsTwinIndicator = Y means it is the Sparcs created twin job else
     * Twin job is created by minapro
     * 
     * @param availableJobs
     *            -- Which contains all twin jobs available in TwinTandemContainer List Table
     * @param sparcsTwinJobs
     *            -- Initially it is a empty list,Depending on sparcsTwinIndicator = Y adding current object to list
     * @param minaproTwinJobs
     *            -- Initially it is a empty list,Depending on sparcsTwinIndicator = N adding current object to list
     * 
     */
    public void seperateMinaProAndSparcsCreatedTwinJobs(Set<TwinTandemJobs> availableJobs,
            List<TwinTandemJobs> sparcsTwinJobs, List<TwinTandemJobs> minaproTwinJobs) {

        logger.logMsg(LOG_LEVEL.INFO, String.valueOf(Thread.currentThread().getId()),
                "Started seperateMinaProAndSparcsCreatedTwinJobs()");

        for (TwinTandemJobs twinJob : availableJobs) {

            if ("Y".equalsIgnoreCase(twinJob.getSparcsTwinIndicator())) {
                sparcsTwinJobs.add(twinJob);
            } else {
                minaproTwinJobs.add(twinJob);
            }

        }
    }

    public void processNonSparcsTwinJobs(List<TwinTandemJobs> existedMinaProCreatedTwinJobs,
            List<TwinTandemJobs> deletableTwinTandemIdList, List<QCJobListEntity> currentJobList)
            throws NullPointerException, SQLException {
        logger.logMsg(LOG_LEVEL.INFO, String.valueOf(Thread.currentThread().getId()),
                "Started processNonSparcsTwinJobs() To Check the status of MinaPro "
                        + " Created Existed Twin Jobs With Current Twin Jobs");

        List<String> updateRequiredSeqs = new ArrayList<String>();

        for (TwinTandemJobs existedMinaProTwinJob : existedMinaProCreatedTwinJobs) {

            if (existedMinaProTwinJob != null) {

                for (TwinTandemContainerList twinTandemContainer : existedMinaProTwinJob.getTwinTandemDetails()) {

                    boolean isTwinTandemIdDeletable = true;

                    String primaryCntrSeqNumber = null;
                    String refCntrSeqNumber = null;
                    MinaProTwinJobStatus twinJobStatus = null;

                    twinJobStatus = checkNonSparcsTwinJobPresentInCurrentJobList(currentJobList,
                            twinTandemContainer.getFromLocation(), twinTandemContainer.getToLocation(),
                            twinTandemContainer.getContainerId());
                    isTwinTandemIdDeletable = twinJobStatus.isJobDeletable();

                    if (isTwinTandemIdDeletable) {
                        deletableTwinTandemIdList.add(existedMinaProTwinJob);
                        continue;
                    } else {

                        primaryCntrSeqNumber = twinJobStatus.getSeqNumber() != -1 ? String.valueOf(twinJobStatus
                                .getSeqNumber()) : null;

                        twinJobStatus = checkNonSparcsTwinJobPresentInCurrentJobList(currentJobList,
                                twinTandemContainer.getRefContrFromLocation(),
                                twinTandemContainer.getRefContrToLocation(), twinTandemContainer.getRefContainerId());

                        isTwinTandemIdDeletable = twinJobStatus.isJobDeletable();

                        refCntrSeqNumber = twinJobStatus.getSeqNumber() != -1 ? String.valueOf(twinJobStatus
                                .getSeqNumber()) : null;

                        if (isTwinTandemIdDeletable) {
                            deletableTwinTandemIdList.add(existedMinaProTwinJob);
                            continue;
                        }
                    }
                    // Add update required sequence numbers to list.
                    if (!isTwinTandemIdDeletable && primaryCntrSeqNumber != null && refCntrSeqNumber != null) {
                        updateRequiredSeqs.add(primaryCntrSeqNumber.concat("|").concat(refCntrSeqNumber));
                    }
                }
            } else {
                return;
            }
        }
        if (updateRequiredSeqs != null && !updateRequiredSeqs.isEmpty()) {
            qcJobListDAO.batchUpdateNonSparcsTwinsSeqNumbers(updateRequiredSeqs);
        } else {
            logger.logMsg(LOG_LEVEL.INFO, String.valueOf(Thread.currentThread().getId()),
                    " No Need To Update MP_JOB_LIST for Non Sparcs Twin Jobs");
        }
    }

    /**
     * 
     * @param currentJobList
     *            Current Job List from Database
     * @param twinTandemContainer
     *            minaproCreatedTwinTandem Container List Data
     * @param container
     *            minaProCreated twin or tandem container
     * @return MinaProTwinJobStatus class , Which holds the status of the current job. (Means Current TwinTandem
     *         Container is deletable or not.)
     * @throws NullPointerException
     */
    public MinaProTwinJobStatus checkNonSparcsTwinJobPresentInCurrentJobList(List<QCJobListEntity> currentJobList,
            String fromLocation, String toLocation, String container) throws NullPointerException {

        boolean isTwinTandemIdDeletable = true;
        double seqNumber = -1;

        for (QCJobListEntity qcJobEntity : currentJobList) {
            if (qcJobEntity.getId().getContainerId().equalsIgnoreCase(container)) {

                logger.logMsg(LOG_LEVEL.TRACE, container,
                        new java.lang.StringBuilder(" Twin Tandem Container List Container").append("::")
                                .append(container).append(" Current Job List Container ")
                                .append(qcJobEntity.getId().getContainerId())
                                .append(" Are Equals Checking From To Location Based On MoveType").toString());

                if ((qcJobEntity.getMoveType().equalsIgnoreCase(DSCH))
                        && (qcJobEntity.getFromLocation().equalsIgnoreCase(fromLocation))) {
                    isTwinTandemIdDeletable = false;
                    seqNumber = qcJobEntity.getSeqNo();
                    break;
                } else if ((qcJobEntity.getMoveType().equalsIgnoreCase(LOAD))
                        && (qcJobEntity.getToLocation().equalsIgnoreCase(toLocation))) {
                    isTwinTandemIdDeletable = false;
                    seqNumber = qcJobEntity.getSeqNo();
                    break;
                }

            }
        }
        logger.logMsg(LOG_LEVEL.TRACE, container, new StringBuilder(" After Loop Iteration isTwinTandemIdDeletable")
                .append("::").append(isTwinTandemIdDeletable).append(" Seq Number::").append(seqNumber).toString());
        return new MinaProTwinJobStatus(isTwinTandemIdDeletable, seqNumber);
    }

    public final class MinaProTwinJobStatus {
        boolean isJobDeletable;
        double seqNumber;

        public MinaProTwinJobStatus(boolean isJobDeletable, double seqNumber) {
            super();
            this.isJobDeletable = isJobDeletable;
            this.seqNumber = seqNumber;
        }
        
        public boolean isJobDeletable() {
            return isJobDeletable;
        }

        public double getSeqNumber() {
            return seqNumber;
        }
    }

    public String getTwinOrTandemType(OPUSTwinTandemJobsPOJO pojo) {
        String jobType = TWIN_JOB_TYPE;
        if (pojo.getTwinTandemCode() != null || pojo.getRefTwinTandemCode() != null) {
            if ("M".equalsIgnoreCase(pojo.getTwinTandemCode()) || "M".equalsIgnoreCase(pojo.getRefTwinTandemCode())) {
                jobType = TANDEM_JOB_TYPE;
            }
        } else {
            logger.logMsg(
                    LOG_LEVEL.ERROR,
                    "",
                    new StringBuilder(" Current Job::").append(pojo)
                            .append(" Twin Tandem Code Is Null It Is UnExpected")
                            .append("Check Logs at dao.getCurrentSnapShotTwinJobs() At this Method").toString());
        }
        logger.logMsg(LOG_LEVEL.INFO, "", " Before Returning getTwinOrTandemType() , Current Job JobType(TN/TW) Is::"
                + jobType);
        return jobType;
    }
}
