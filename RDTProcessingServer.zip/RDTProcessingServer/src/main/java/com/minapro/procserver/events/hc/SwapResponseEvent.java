package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the swap response from the ESB
 * 
 * @author Rosemary George
 *
 */
public class SwapResponseEvent extends Event implements Serializable {

	private static final long serialVersionUID = -3063964344323092409L;
	
	/**
     * List of conatiners which are swapped
     */
    private List<SwapContainerPosition> swapContainerList;

	public List<SwapContainerPosition> getSwapContainerList() {
		return swapContainerList;
	}

	public void setSwapContainerList(List<SwapContainerPosition> swapContainerList) {
		this.swapContainerList = swapContainerList;
	}

	@Override
	public String toString() {
		return "SwapResponseEvent [swapContainerList=" + swapContainerList
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getTerminalID()=" + getTerminalID()
				+ ", getEventID()=" + getEventID() + "]";
	}
}
