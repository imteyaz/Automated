package com.minapro.procserver.actors.itv;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ShiftDetails;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.itv.ITVPerformanceEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for measuring the performance of ITV operators. </p>
 * 
 * <p> Measures the following parameter for each ITV operator. </p>
 * 
 * <p> Gross MovesPerHour - Indicates the actual speed of operation of the operator </p>
 * 
 */

public class ITVLivePerformanceActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVLivePerformanceActor.class);

    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dd.MM.yyyy HH:mm");
    
    private static final String TARGET_MPH = "ITV_TARGET_MPH";
    private static final long ONE_MINUTE_IN_MILLIS = 60000;

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof ITVPerformanceEvent) {
            ITVPerformanceEvent itvEvent = (ITVPerformanceEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, itvEvent.getUserID(), "Received ITVPerformance Event  -" + itvEvent);
            if (itvEvent.getUserID() != null) {
                PerformanceEvent performanceEvent = measureITVPerformance(itvEvent.getUserID(),
                        itvEvent.getEquipmentID());
                if(performanceEvent != null){
                	EventUtil.getInstance().sendPerformanceEvent(performanceEvent, OPERATOR.ITV);
                }
            }

        } else {
            unhandled(message);
        }

    }

    /**
     * Get the target MPH defined in the system(From application parameter). If no value is defined, default 10 is
     * returned.
     * 
     * @return
     */
    private double  getTragetMPH() {
        ApplicationParameter targetMovesPerHour = RDTPLCCacheManager.getInstance().getApplicationParamter(TARGET_MPH);
        Double targetMph = 1.2;
        if (targetMovesPerHour != null) {
            try {
                targetMph =Double.parseDouble(targetMovesPerHour.getParameterValue());
            } catch (Exception ex) {
                logger.logException("Caught exception while converting target mph", ex);
            }
        }
        return targetMph;
    }
    
    

    /**
     * <p> Measures the live performance of the specified ITV operator based on the following formula </p>
     * 
     * <p> Moves per hour = Total completed moves /totalTimeWorkedInHours ( previoushoursWorkedByITVUser +
     * currenthoursWorkedByITVUser) </p>
     * 
     */
    private PerformanceEvent measureITVPerformance(String userId, String itvId) {
        PerformanceEvent performanceEvent = null;
        
        double targetMph = getTragetMPH();
        
        logger.logMsg(LOG_LEVEL.INFO, userId, "Target Moves per Hour :" + targetMph);

        try {

            Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);            
            ShiftDetails shiftData = HibernateUtil.getShiftDataforLoggedInuser(loginTime, new Date(), userId);

            Date shiftStartTime;
            // round to the next minute so that the current job completed will be retrieved by the query
            Date shiftEndTime = new Date(Calendar.getInstance().getTimeInMillis()+ ONE_MINUTE_IN_MILLIS);
            if(shiftData == null){
            	logger.logMsg(LOG_LEVEL.DEBUG, userId, "Not able to retrieve shift details for user. Using login Time");
            	shiftStartTime = loginTime;
            }else {
            	shiftStartTime =  shiftData.getShiftStartDate();
            	shiftEndTime = shiftData.getShiftEndDate();
            }
            
            String shifStartTime = DATE_FORMATTER.format(shiftStartTime);
            String currentSystemTime = DATE_FORMATTER.format(shiftEndTime);

            logger.logMsg(LOG_LEVEL.INFO, userId, "Shift Start Time:" + shiftStartTime);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Current System Time :" + currentSystemTime);

            User user = RDTCacheManager.getInstance().getUserDetails(userId);

            Double previoushoursWorkedByITVUser = HibernateUtil.getPreviousHoursWorkedByITVUser(user, itvId,
                    shifStartTime, currentSystemTime);

            double diffInMillies = System.currentTimeMillis() - loginTime.getTime();
            double currenthoursWorkedByITVUser = diffInMillies / (1000 * 60 * 60);

            double totalTimeWorkedInHours = previoushoursWorkedByITVUser + currenthoursWorkedByITVUser;

            logger.logMsg(LOG_LEVEL.INFO, userId, "Total Hours worked by the User:" + totalTimeWorkedInHours);

            long completedITVJobs = HibernateUtil.getCompletedJobsByITVforThisShift(user, itvId, shifStartTime,
                    currentSystemTime);

            logger.logMsg(LOG_LEVEL.INFO, userId, "CompletedJobs by ITV :" + completedITVJobs);

            double grossMovesPerHour = completedITVJobs / totalTimeWorkedInHours;

            logger.logMsg(LOG_LEVEL.INFO, userId, "Gross Moves per Hour :" + grossMovesPerHour);

            performanceEvent = EventUtil.getInstance().constructPerformanceEvent(userId, grossMovesPerHour, 0, 0, 0, (int)completedITVJobs,
                    itvId,targetMph);
            
        } catch (Exception ex) {
            logger.logException("Caught exception during ITVLiveperformance", ex);
        }

        return performanceEvent;
    }

}
