package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SHUFFLEJOB_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import akka.actor.UntypedActor;

import com.minapro.procserver.actors.itv.ITVPoolActor;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.che.ShuffleResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
/**
 * The class is responsible for sending shuffle job list request to ESB and construct the shuffle job list response and send it to UI
 * @author UmaMahesh
 *
 */

public class ShuffleJoblistRequestActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVPoolActor.class);

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    
    private static final String TERMINAL = DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY);

    private static final String ERROR_MESSAGE = " Location/Container Cannot Be Null";
    @Override
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof ShuffleRequestEvent) {
                ShuffleRequestEvent shuffleRequest = (ShuffleRequestEvent) message;
                handleShuffleRequestEvent(shuffleRequest);
              
            } else if (message instanceof ShuffleResponseEvent) {
                ShuffleResponseEvent shuffleResponse = (ShuffleResponseEvent) message;
                logger.logMsg(LOG_LEVEL.INFO, shuffleResponse.getUserID(), "Received shuffle job response "
                        + shuffleResponse);
               
                sendShuffledJobsToDevice(shuffleResponse);
                
            } else {
                unhandled(message);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while processing the message - ", ex);
        }
    }
    private void handleShuffleRequestEvent(ShuffleRequestEvent shuffleRequest) {
    	
    	logger.logMsg(LOG_LEVEL.INFO, shuffleRequest.getUserID(), " Received shuffle job request event  "
                + shuffleRequest);
    	
    	if(shuffleRequest.getClass()==null || shuffleRequest.getFromLocation()==null || shuffleRequest.getFromLocation().isEmpty()){
    		
    		logger.logMsg(LOG_LEVEL.ERROR,shuffleRequest.getUserID(),new StringBuilder(" From Location/Container is null.").
    				append(" Generating Response From RDT ItSelf").toString());
    		ShuffleResponseEvent responseEvent= prepareShuffleResponseEvent(shuffleRequest);
    		sendShuffledJobsToDevice(responseEvent);
    	} else {
    		
    		shuffleRequest.setMoveType(RDTProcessingServerConstants.RH);
    		shuffleRequest.setJobListRefreshRequired(true);
    		
    		ESBQueueManager.getInstance().postMessage(shuffleRequest, 
    				RDTCacheManager.getInstance().getUserLoggedInRole(shuffleRequest.getUserID()), TERMINAL);
    	}

		
	}
	private ShuffleResponseEvent prepareShuffleResponseEvent(ShuffleRequestEvent shuffleRequest) {
	
		ShuffleResponseEvent responseEvent = new ShuffleResponseEvent();
		
		responseEvent.setUserID(shuffleRequest.getUserID());
		responseEvent.setTerminalID(TERMINAL);
		responseEvent.setEventID(shuffleRequest.getEventID());
		responseEvent.setEquipmentID(shuffleRequest.getEquipmentID());
		responseEvent.setContainerId(shuffleRequest.getContainerId());
		responseEvent.setErrorMessage(ERROR_MESSAGE);
		responseEvent.setSuccess(false);
		return responseEvent;
	}
	/**
     * <p>shuffle container details filled like </p>
     * <p>containerId^isoCode^weight^empty/full^currentLocation^newLocation</p> 
     * 
     * @param shuffleResponse
     */

    private void sendShuffledJobsToDevice(ShuffleResponseEvent shuffleResponse) {
        
        OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(shuffleResponse.getUserID());

        String eventType = DeviceEventTypes.getInstance().getEventType(SHUFFLEJOB_RESPONSE);
        
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventType).
        		append(VALUE_SEPERATOR).append( shuffleResponse.getEventID() ).append( VALUE_SEPERATOR).
        		append( shuffleResponse.getTimeStamp()).append(VALUE_SEPERATOR)
        		.append(shuffleResponse.isSuccess()).append(VALUE_SEPERATOR).append(shuffleResponse.getErrorMessage())
        		.append(VALUE_SEPERATOR).append(shuffleResponse.getUserID()).append(VALUE_SEPERATOR).append(TERMINAL);

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,TERMINAL);
    }

}
