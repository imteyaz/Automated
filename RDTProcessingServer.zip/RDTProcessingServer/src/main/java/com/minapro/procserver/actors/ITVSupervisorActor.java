package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.itv.CallITVActor;
import com.minapro.procserver.actors.itv.FollowITVActor;
import com.minapro.procserver.actors.itv.ITVArrivalActor;
import com.minapro.procserver.actors.itv.ITVJobConfirmationActor;
import com.minapro.procserver.actors.itv.ITVJobListActor;
import com.minapro.procserver.actors.itv.ITVLivePerformanceActor;
import com.minapro.procserver.actors.itv.ITVPoolActor;
import com.minapro.procserver.actors.itv.PinningStationActor;
import com.minapro.procserver.events.itv.CallITVEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.FollowITVEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.ITVJobConfirmationEvent;
import com.minapro.procserver.events.itv.ITVJobListEvent;
import com.minapro.procserver.events.itv.ITVPerformanceEvent;
import com.minapro.procserver.events.itv.ITVPoolEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;
import com.minapro.procserver.events.itv.PinningStationJobConfirmationEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for handling/supervising the ITV operator specific events</p>
 * 
 * @author Rosemary George
 *
 */
public class ITVSupervisorActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVSupervisorActor.class);
	
    /**
     * All ITV drive instructions events are forwarded to this actor
     */
    private ActorRef driveInstructionActor = getContext().actorOf(
            Props.create(ITVJobListActor.class).withRouter(new FromConfig()), "driveInstruction");

    private ActorRef itvArrivalActor = getContext().actorOf(
            Props.create(ITVArrivalActor.class).withRouter(new FromConfig()), "itvArrival");

    private ActorRef pinningStationActor = getContext().actorOf(
            Props.create(PinningStationActor.class).withRouter(new FromConfig()), "pinningStation");

    private ActorRef itvJobConfirmActor = getContext().actorOf(
            Props.create(ITVJobConfirmationActor.class).withRouter(new FromConfig()), "itvJobConfirm");

    private ActorRef itvPoolActor = getContext().actorOf(Props.create(ITVPoolActor.class).withRouter(new FromConfig()),
            "itvPool");
    
    private ActorRef itvLivePerformanceActor = getContext().actorOf(Props.create(ITVLivePerformanceActor.class).withRouter(new FromConfig()),
            "itvPerformance");
    
    private ActorRef followItvActor = getContext().actorOf(Props.create(FollowITVActor.class).withRouter(new FromConfig()),
            "followItv");
    
    private ActorRef callItvActor = getContext().actorOf(Props.create(CallITVActor.class).withRouter(new FromConfig()),
            "callItv");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {
                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    public void onReceive(Object message) throws Exception {
    	logger.logMsg(LOG_LEVEL.DEBUG, message.getClass().getSimpleName(), "Received at ITVSupervisorActor");
    	
        if (message instanceof DriveInstructionEvent || message instanceof ITVJobListEvent) {
            driveInstructionActor.tell(message, getSelf());
        } else if (message instanceof ITVArrivalEvent) {
            itvArrivalActor.tell(message, getSelf());
        } else if (message instanceof PinningStationJobConfirmationEvent) {
            pinningStationActor.tell(message, getSelf());
        } else if (message instanceof ITVJobConfirmationEvent) {
            itvJobConfirmActor.tell(message, getSelf());
        } else if (message instanceof ITVPoolEvent || message instanceof ITVPoolRequestEvent) {
            itvPoolActor.tell(message, getSelf());
        }else if (message instanceof ITVPerformanceEvent) {
        	itvLivePerformanceActor.tell(message, getSelf());
        }else if(message instanceof FollowITVEvent){
        	followItvActor.tell(message, getSelf());
        }else if(message instanceof CallITVEvent){
        	callItvActor.tell(message, getSelf());
        }else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, null);
        }
    }
}
