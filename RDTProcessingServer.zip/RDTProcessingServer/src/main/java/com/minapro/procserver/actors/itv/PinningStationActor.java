package com.minapro.procserver.actors.itv;

import java.util.List;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.PinningStationJobConfirmationEvent;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor class responsible for handling the pinning station related operations</p>
 * 
 * <p>If the pinning job is confirmed and if any pending drive instructions are available in cache for the specified
 * ITV, the DriveInstruction is generated for the ITV and sends to the communication server.</p>
 * 
 * @author Rosemary George
 *
 */
public class PinningStationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(PinningStationActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof PinningStationJobConfirmationEvent) {
            PinningStationJobConfirmationEvent psConfirmationEvent = (PinningStationJobConfirmationEvent) message;

            logger.logMsg(LOG_LEVEL.INFO, psConfirmationEvent.getContainerID(), "Pinning operation is complete");

            // feed to Esper
            RDTProcessingServer.getInstance().getEsperActor().tell(psConfirmationEvent, null);

            EventUtil.getInstance().sendITVJoblistRequestToESB(psConfirmationEvent.getEquipmentID(),
                    psConfirmationEvent.getUserID(), psConfirmationEvent.getTerminalID());
            
        } else {
            unhandled(message);
        }
    }

    /**
     * <p>Checks and sends the next driving instruction to the ITV if any pending instructions in the Cache. </p>
     * 
     * <p> If the next instruction is to move to QC side, retrieves the QCLane allocated to the QC and fills the lane
     * and driving directions. </>
     * 
     * <p> Finally, removes the drive instruction from the Cache. </p>
     * 
     * @param psConfirmationEvent
     */
    private void sendPendingDrivingInstruction(PinningStationJobConfirmationEvent psConfirmationEvent) {
        try {
            // check if the ITV has any pending instructions, if yes send it.
            List<DriveInstructionEvent> pendingInstructions = RDTCacheManager.getInstance().getPendingITVInstructions(
                    psConfirmationEvent.getEquipmentID());
            if (pendingInstructions != null) {
                logger.logMsg(LOG_LEVEL.INFO, psConfirmationEvent.getUserID(), "Sending DriveInstruction for ITV -"
                        + psConfirmationEvent.getEquipmentID());

                DriveInstructionEvent instruction = pendingInstructions.get(0);
                instruction.setUserID(psConfirmationEvent.getUserID());
                instruction.setTerminalID(psConfirmationEvent.getTerminalID());
                instruction.setEventID(UUID.randomUUID().toString());
                EventUtil.getInstance().setDriveTypeForInstruction(instruction);

                EventUtil.getInstance().sendDriveInstruction(instruction, RDTProcessingServerConstants.NOTIF);
                RDTCacheManager.getInstance().removeFromPendingITVInstructions(instruction);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while processing Pinning Station jobConfirmation : - ", ex);
        }
    }
}
