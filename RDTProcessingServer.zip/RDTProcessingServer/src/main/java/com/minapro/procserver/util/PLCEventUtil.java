package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.QCPLCConstants.DSCH;
import static com.minapro.procserver.util.QCPLCConstants.LOCK;
import static com.minapro.procserver.util.QCPLCConstants.PORT_SIDE;
import static com.minapro.procserver.util.QCPLCConstants.FORTYSINGLE;
import static com.minapro.procserver.util.QCPLCConstants.GANTRY_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.GANTRY_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.H2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.HOIST1_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.HOIST2_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.LOAD;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER1_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.STATE_L;
import static com.minapro.procserver.util.QCPLCConstants.STATE_LOCK;
import static com.minapro.procserver.util.QCPLCConstants.STATE_U;
import static com.minapro.procserver.util.QCPLCConstants.T1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.T2_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.TROLLEY1_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.TROLLEY2_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.TWENTYSINGLE;
import static com.minapro.procserver.util.QCPLCConstants.TWIN;
import static com.minapro.procserver.util.QCPLCConstants.UNLOCK;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_BACKREACH_START_VAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_FORTY_GANTRY_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_HOIST_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_TROLLEY_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_TWENTY_GANTRY_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.ManualConfirmationAlertEvent;
import com.minapro.procserver.events.plc.PLCJobdoneEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class having all the utility methods related to PLC operations
 * 
 * @author Rosemary George
 *
 */
public class PLCEventUtil {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(PLCEventUtil.class);
    
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
    
    private static final String CAPTURED = "CAPTURED : ";
    private static final int SPREADER_SIZE_20 = 20;
    private static final int SPREADER_SIZE_40 = 40;
    private static final int SPREADER_SIZE_2020 = 2020;

    private static final String LEFT = "L";
    private static final String RIGHT = "R";

    private static final String GANTRY_MOVED_LEFT = " Gantry moved towards Left :";
    private static final String GANTRY_MOVED_RIGHT = "Gantry moved towards Right :";

    private static final String LOCKSTRING = "Locking";
    private static final String UNLOCKSTRING = "UnLocking";

    private static final PLCEventUtil INSTANCE = new PLCEventUtil();

    private PLCEventUtil() {
    }

    public static PLCEventUtil getInstance() {
        return INSTANCE;
    }

    /**
     * 
     * <p> Responsible for sending manual confirmation po-up to master Actor. This indicates, automation failed to
     * detect the location of current move </p>
     * 
     * @param alertEvent
     */
    public void sendManualConfirmationAlertToOperator(ManualConfirmationAlertEvent alertEvent) {
        logger.logMsg(LOG_LEVEL.DEBUG, " ", "Sending Manual Confirmation Alert :" + alertEvent.getUserID());
        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(ALERT_MESSAGE);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF + valueSeperator + eventTypeID);
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                EventUtil.getInstance().getEventParameter(alertEvent, msgFields.get(i), responseToDevice);
            }

            User user = RDTCacheManager.getInstance().getUserDetails(alertEvent.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(alertEvent.getUserID());

                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        alertEvent.getTerminalID());
            }
        } catch (Exception e) {
            logger.logException("CHE User Caught exception while processing sendAlertMessageToUser -", e);
        }
    }

    /**
     * Saves the current job type for the user in the cache, based on the spreader size
     * 
     * @param userId
     * @param spreaderSize
     */
    public void saveCurrentJobType(String userId, double spreaderSize) {
        if (spreaderSize == SPREADER_SIZE_20 || spreaderSize == SPREADER_SIZE_40) {
            if (spreaderSize == SPREADER_SIZE_20) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, TWENTYSINGLE);
                RDTPLCCacheManager.getInstance().addCurrentJobType(userId, TWENTYSINGLE);
            } else if (spreaderSize == SPREADER_SIZE_40) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, FORTYSINGLE);
                RDTPLCCacheManager.getInstance().addCurrentJobType(userId, FORTYSINGLE);
            }
        } else if (spreaderSize == SPREADER_SIZE_2020) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, TWIN);
            RDTPLCCacheManager.getInstance().addCurrentJobType(userId, TWIN);
        }
    }

    /**
     * Updates the crane Gantry/hoist/trolley status for the specified user.
     * 
     * @param moveType
     * @param eventA
     * @param spreaderId
     */
    public void updateCraneMoveStatus(String craneEvent, String moveType, Map<String, EsperPLCEvent> eventMap) {

        EsperPLCEvent plc1 = eventMap.get("a");
        EsperPLCEvent plc2 = eventMap.get("b");
        String spreaderId = plc2.getTagName();
        String node = plc1.getNode();
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        String spreaderState = STATE_U;
        String otherSpreaderState = STATE_L;
        if (moveType.equalsIgnoreCase(STATE_LOCK)) {
            spreaderState = STATE_L;
            otherSpreaderState = STATE_U;
        }

        if (userId != null) {

            boolean spreaderStatus = RDTPLCCacheManager.getInstance().getSpreaderStatusMaping(
                    userId + spreaderId + craneEvent + spreaderState);

            // Check if this event is already captured because Lock event comes on every 5 sec
            if (!spreaderStatus) {

                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER)
                        .append("\n*" + craneEvent + moveType + " DETECTED! OF USER " + userId + " ON " + node
                                + " With " + spreaderId).append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                logger.logMsg(LOG_LEVEL.DEBUG, CAPTURED, plc1.toString());

                // storing Position during the lock/unlock time into cache
                RDTPLCCacheManager.getInstance().addPLCEventDetails(plc1.getNode() + plc1.getTagName() + spreaderId,
                        plc1.getTagValue());

                // setting flag to ignore lock/unlock event once the crane position is captured
                RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
                        userId + spreaderId + craneEvent + spreaderState, true);

                // Enable flag to capture the crane position during spreader unlock/lock
                RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
                        userId + spreaderId + craneEvent + otherSpreaderState, false);
                // Enabling flag to identify container lifted event
                RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, false);

                if (craneEvent.equals(TROLLEY1_POSITION) || craneEvent.equals(TROLLEY2_POSITION)) {
                    // Increase number of locks to identify the tandem job
                    int noOfLocks = RDTPLCCacheManager.getInstance().getSpreaderLockCountDetails(userId);
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "Current No of locks : " + noOfLocks);
                    RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, noOfLocks + 1);
                }                
            }
        }
    }

    /**
     * Updates the Unlock movement of crane hoist and trolley
     * 
     * @param craneEvent
     * @param cranePos
     * @param eventMap
     */
    public void updateCraneMoveUnlockStatus(String craneEvent, String cranePos, Map<String, EsperPLCEvent> eventMap) {
        EsperPLCEvent plc1 = eventMap.get("a");
        EsperPLCEvent plc2 = eventMap.get("b");
        String node = plc1.getNode();
        String spreaderId = plc2.getTagName();

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        if (userId != null) {

            boolean spreaderStatus = RDTPLCCacheManager.getInstance().getSpreaderStatusMaping(
                    userId + spreaderId + craneEvent + STATE_U);

            // Check if this event is already captured because Unlock event comes on every 5 sec
            if (!spreaderStatus) {

                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER)
                        .append("\n*" + craneEvent + "UNLOCK DETECTED! OF USER " + userId + " ON " + node + " With "
                                + spreaderId).append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                logger.logMsg(LOG_LEVEL.DEBUG, CAPTURED, plc1.toString());

                // storing Hoist1Position during unlock time into cache
                RDTPLCCacheManager.getInstance().addPLCEventDetails(plc1.getNode() + cranePos + spreaderId,
                        plc1.getTagValue());

                // setting this flag to verify whether unlock subscriber is captured before Job done is detected.
                // Using this flag in waitUntilUnlockSubscribersExecuted() under PLCJobdoneActor
                RDTPLCCacheManager.getInstance().adduserToUnlockPositionMapping(userId + cranePos + spreaderId, true);

                // Enable flag to capture during spreader lock
                RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(userId + spreaderId + craneEvent + STATE_L,
                        false);

                // setting flag to ignore unlock event once it is captured
                RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(userId + spreaderId + craneEvent + STATE_U,
                        true);
            }
        }
    }

    /**
     * Updates the spreader size for the QC
     * 
     * @param craneEvent
     * @param spreaderNo
     * @param eventMap
     */
    public void updateSpreaderSize(String craneEvent, Integer spreaderNo, Map<String, EsperPLCEvent> eventMap) {
        EsperPLCEvent plc1 = eventMap.get("event1");
        String node = plc1.getNode();
        Double spreaderSize = plc1.getTagValue();

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
        if (userId != null) {

            boolean sizeDetected = RDTPLCCacheManager.getInstance()
                    .getSpreaderSizeCapturedeDetails(userId + craneEvent);
            if (!sizeDetected) {

                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER)
                        .append("\n* SIZE" + spreaderNo + " EVENT DETECTED! OF USER " + userId + " ON " + node)
                        .append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                logger.logMsg(LOG_LEVEL.DEBUG, CAPTURED, plc1.toString());

                RDTPLCCacheManager.getInstance().addSpreaderSizeDetails(userId + craneEvent, spreaderSize);
                RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + craneEvent, true);

                logger.logMsg(LOG_LEVEL.DEBUG, userId, "SPREADER" + spreaderNo + " SIZE :" + spreaderSize);
                PLCEventUtil.getInstance().saveCurrentJobType(userId, spreaderSize);
            }
        }
    }

    /**
     * Construct and sends jobDone event to master actor if the lifted spreader is unlocked.
     * 
     * @param eventMap
     * @param spreaderEvent
     * @param spreaderNo
     */
    public void peformSpreaderChangeAction(Map<String, EsperPLCEvent> eventMap, String spreaderEvent, Integer spreaderNo) {
        EsperPLCEvent plc1 = eventMap.get("event1");
        String node = plc1.getNode();

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
        if (userId != null) {
            boolean sp1IsUnLocked = RDTPLCCacheManager.getInstance().getSpreader1UnlockDetails(userId + spreaderEvent);
            if (!sp1IsUnLocked) {
                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER)
                        .append("\n* SPREADER" + spreaderNo + " CHANGE DETECTED! OF USER " + userId + " ON " + node)
                        .append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "Received event :" + plc1);

                String liftedSpreaderId = RDTPLCCacheManager.getInstance().getworkingSpreaderMaping(userId);
                boolean isLifted = RDTPLCCacheManager.getInstance().getContainerLiftedDetails(userId);

                logger.logMsg(LOG_LEVEL.DEBUG, userId, "LiftedSpreader ID" + liftedSpreaderId + ", isLifted=" + isLifted);
                if (liftedSpreaderId.equals(plc1.getTagName()) && isLifted) {
                    PLCJobdoneEvent jobDoneEvent = new PLCJobdoneEvent();

                    jobDoneEvent.setNode(node);
                    jobDoneEvent.setUserId(userId);
                    jobDoneEvent.setContainerWeight(RDTPLCCacheManager.getInstance().getLiftedContainerWeight(userId));
                    jobDoneEvent.setSpreaderId(plc1.getTagName());

                    logger.logMsg(LOG_LEVEL.DEBUG, userId, "SENDING JOB DONE TO ACTOR");
                    RDTProcessingServer.getInstance().getMasterActor().tell(jobDoneEvent, null);

                    RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + plc1.getTagName(), true);
                    RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + spreaderEvent, false);

                } else {
                	if(!isLifted){
                		logger.logMsg(LOG_LEVEL.DEBUG, userId, "Resetting spreader locks- Did Not Lift properly : " + plc1.getTagName());
                		RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
                	}
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " Not Lifted with Spreader ID : " + plc1.getTagName());
                    RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + spreaderEvent, false);
                    RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, false);
                }
            }
        }
    }

    /**
     * 
     * <p> Responsible for sending wrong container picked event to Master Actor If Picked container ID is not matched
     * with the job list container ID in sequence then alert will be sent to QC UI </p>
     * 
     * @param userId
     * @param plcContainer
     * @param joblistContainer
     */
    public void sendWrongContainerPicked(String userId, Container plcContainer, JobListContainer joblistContainer, String equipmentID) {
        // Sending Wrong Container Picked Event to Device
        if (!(plcContainer.getContainerID().equalsIgnoreCase(joblistContainer.getContainerId()))) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "Sending Wrong Container Picked Event of User :" + userId);
            MinaProAlertEvent alert = new MinaProAlertEvent();
            alert.setAlertCode(ALERTCODE.QC_WRONG_CONTAINER_ALERT);
            alert.setUserID(userId); 
            alert.setOperatorId(userId);
            alert.setContainerId(plcContainer.getContainerID());
            alert.setPlannedContainerId(joblistContainer.getContainerId());
            alert.setEquipmentID(equipmentID);
            RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
        }
    }

    /**
     * 
     * <p> Responsible for rounding the fractional values to nearest integer value if the fractional part is greater
     * than 7 </p>
     * 
     * @param delta
     * @param configDiff
     * @return int
     */
    public int deltaRound(double delta, double configDiff) {
        int result = 0;

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" deltaRound()").toString());

        double rowDiff = delta / configDiff;
        int fractionPart = Integer.valueOf(String.valueOf(rowDiff).split("\\.")[1].charAt(0) + "");
        int intPart = Integer.valueOf(String.valueOf(rowDiff).split("\\.")[0]);

        if (fractionPart > 7) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "Fraction part is greater than 7");

            if (intPart < 0) {
                result = intPart - 1;
            } else {
                result = intPart + 1;
            }
        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "Fraction part is less than 7");
            result = (int) delta / (int) configDiff;
        }

        return result;
    }

    /**
     * Figures out the shifted bay ID based on the gantry delta and vessel berth side position
     * 
     * @param userId
     * @param gantryDelta
     * @param currentBayId
     * @param berthSide
     * @return
     */
    private Integer getShiftedBayId(String userId, int gantryDelta, int currentBayId, String berthSide) {
        Integer shiftedBayId = 0;

        String prevJobType = RDTPLCCacheManager.getInstance().getPreviousJobType(userId);
        String currentJobType = RDTPLCCacheManager.getInstance().getCurrentJobType(userId);

        if (gantryDelta == 0) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Previousjob type :" + prevJobType);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Current job type :" + currentJobType);

            if (TWIN.equalsIgnoreCase(prevJobType) && FORTYSINGLE.equalsIgnoreCase(currentJobType)) {
                String[] bayIds = RDTPLCCacheManager.getInstance().getTwinIdsOfUser(userId);
                shiftedBayId = (Integer.parseInt(bayIds[0]) + Integer.parseInt(bayIds[1])) / 2;

                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Twin bay ID's :" + bayIds[0] + ": " + bayIds[1]);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from TWIN TO FORTY IN SAME BAY :" + shiftedBayId);

            } else if (FORTYSINGLE.equalsIgnoreCase(prevJobType) && TWIN.equalsIgnoreCase(currentJobType)) {
                shiftedBayId = currentBayId - 1;
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from FORTY TO TWIN IN SAME BAY :" + shiftedBayId);

            } else if (TWIN.equalsIgnoreCase(prevJobType) && TWENTYSINGLE.equalsIgnoreCase(currentJobType)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from TWIN to TWENTY IN SAME BAY :");

                String[] bayIds = RDTPLCCacheManager.getInstance().getTwinIdsOfUser(userId);
                Integer logicalBayId = (Integer.parseInt(bayIds[0]) + Integer.parseInt(bayIds[1])) / 2;
                String gantryDirection = RDTPLCCacheManager.getInstance().getGantryMovingDirection(userId);

                if (LEFT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_LEFT);  
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? logicalBayId-1 : logicalBayId+1;                    
                } else if (RIGHT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_RIGHT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? logicalBayId+1 : logicalBayId-1;
                }

            } else if (TWENTYSINGLE.equalsIgnoreCase(prevJobType) && TWIN.equalsIgnoreCase(currentJobType)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from TWENTY to TWIN  IN SAME BAY :");
                String gantryDirection = RDTPLCCacheManager.getInstance().getGantryMovingDirection(userId);

                if (LEFT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_LEFT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId-2 : currentBayId;
                } else if (RIGHT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_RIGHT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId : currentBayId-2;
                }

            } else if (TWENTYSINGLE.equalsIgnoreCase(prevJobType) && FORTYSINGLE.equalsIgnoreCase(currentJobType)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from TWENTY to FORTY  IN SAME BAY :");
                String gantryDirection = RDTPLCCacheManager.getInstance().getGantryMovingDirection(userId);

                if (LEFT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_LEFT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId-1 : currentBayId+1;
                } else if (RIGHT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_RIGHT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId+1 : currentBayId-1;
                }

            } else if (FORTYSINGLE.equalsIgnoreCase(prevJobType) && TWENTYSINGLE.equalsIgnoreCase(currentJobType)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " Moved from FORTY to TWENTY IN SAME BAY :");
                String gantryDirection = RDTPLCCacheManager.getInstance().getGantryMovingDirection(userId);

                if (LEFT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_LEFT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId-1 : currentBayId+1;
                } else if (RIGHT.equalsIgnoreCase(gantryDirection)) {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, GANTRY_MOVED_RIGHT);
                    shiftedBayId = PORT_SIDE.equalsIgnoreCase(berthSide) ? currentBayId+1 : currentBayId-1;
                }
            } else {
                shiftedBayId = currentBayId;
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " WORKIG UNDER SAME BAY :" + shiftedBayId);
            }

        } else {
        	if (PORT_SIDE.equalsIgnoreCase(berthSide)) {
                shiftedBayId = (gantryDelta * 2) + currentBayId;
            } else {
                shiftedBayId = (gantryDelta * 2) - currentBayId;
            }
        }

        return shiftedBayId;
    }

    /**
     * 
     * <p> Derives the exact row, tier and Bay Id's from the number of row, tier and bay shifts received from
     * getTrolleyHoistGantryDelta() </p>
     * 
     * @param userId
     * @param positionsDelta
     * @param moveType
     * @return String
     */
    public String getShiftedCellLocation(String userId, int[] positionsDelta, String moveType) {
        String cell;
        int currentBayId;

        // Get the cell location of last container move (e.g 010203 i.e BayRowTier)
        cell = RDTPLCCacheManager.getInstance().getCurrentCellLocationOfUser(userId);
        String[] cellTokens = cell.split("\\.");
        currentBayId = Integer.parseInt(cellTokens[0]);

        String rotationId = RDTPLCCacheManager.getInstance().getUserToRotationIdMapping(userId);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Rotation ID :" + rotationId);

        String berthSide = RDTVesselProfileCacheManager.getInstance().getVesselBerthSide(rotationId);
        if(berthSide == null || berthSide.isEmpty()){
        	logger.logMsg(LOG_LEVEL.DEBUG, userId, " Failed to get Vessel Berth Side :Default PORT side");
        	berthSide = PORT_SIDE;
        }
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Vessel Berth Side :" + berthSide);

        Integer shiftedBayId = getShiftedBayId(userId, positionsDelta[2], currentBayId, berthSide);

        // adding "0" to the rowId and tierId which are less than 10
        String rowId = null;

        String tierId = null;

        String bayId = null;
        if (shiftedBayId < 10 && shiftedBayId >= 0) {
            bayId = "0" + shiftedBayId;
        } else {
            bayId = shiftedBayId.toString();
        }

        int previousIndex = RDTPLCCacheManager.getInstance().getQCUserstoPrevIndex(userId);
        int currentIndex = positionsDelta[0] + previousIndex;

        int previousTierIndex = RDTPLCCacheManager.getInstance().getQCUserstoPrevTierIndex(userId);
        int currentTierIndex = positionsDelta[1] + previousTierIndex;

        String[] arrayOfRows;
        String[] arrayOfTiers;

        String previousBay = RDTPLCCacheManager.getInstance().getQCUserstoPrevBay(userId);
        if (!bayId.equalsIgnoreCase(previousBay)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Shifted to another bay :" + bayId);

            arrayOfTiers = RDTVesselProfileCacheManager.getInstance().getBayTiers(userId, bayId);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "List Of Tiers :" + Arrays.asList(arrayOfTiers));
            tierId = arrayOfTiers[currentTierIndex];

            arrayOfRows = RDTVesselProfileCacheManager.getInstance().getBayRows(userId, bayId, tierId);

            RDTPLCCacheManager.getInstance().addUsersBaytoRowsMapping(userId, arrayOfRows);
            RDTPLCCacheManager.getInstance().addUsersBaytoTiersMapping(userId, arrayOfTiers);

        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Working under same Bay :" + bayId);
            arrayOfRows = RDTPLCCacheManager.getInstance().getUsersBaytoRowsMapping(userId);
            arrayOfTiers = RDTPLCCacheManager.getInstance().getUsersBaytoTiersMapping(userId);

            logger.logMsg(LOG_LEVEL.DEBUG, userId, "List Of Tiers :" + Arrays.asList(arrayOfTiers));
            tierId = arrayOfTiers[currentTierIndex];
        }

        logger.logMsg(LOG_LEVEL.DEBUG, userId, "List Of Rows :" + Arrays.asList(arrayOfRows));
        rowId = arrayOfRows[currentIndex];

        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Current Row Index :" + currentIndex);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Row ID mapped to Index :" + rowId);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Current Tier Index :" + currentTierIndex);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Tier ID mapped to Index :" + tierId);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "======================== Shifted Location ======================== : ");
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Shifted Row Id from Previous Move is :" + rowId);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Shifted Tier Id from Previous Move is :" + tierId);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Shifted Bay Id from Previous Move is :" + bayId);

        String shiftedCellLocation = bayId + "." + rowId + "." + tierId;

        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Shifted Cell from Previous move is :" + shiftedCellLocation);

        if (shiftedCellLocation.equals(cell)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Same Location detected :: " + "Prev :" + cell + "Current :"
                    + shiftedCellLocation);

            String lastMoveType = RDTPLCCacheManager.getInstance().getMoveTypeOfUser(userId);
            if (moveType.equalsIgnoreCase(lastMoveType)) {
                RDTPLCCacheManager.getInstance().addSameLocationDetectedCache(userId, true);
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " But move types are different :");
            }

        }
        RDTPLCCacheManager.getInstance().addCurrentCellLocationOfUser(userId, shiftedCellLocation);
        RDTPLCCacheManager.getInstance().addQCUserstoPrevIndex(userId, currentIndex);
        RDTPLCCacheManager.getInstance().addQCUserstoPrevTierIndex(userId, currentTierIndex);

        return shiftedCellLocation;
    }

    /**
     * 
     * <p> Retrieves the positions during lock and returns </p>
     * 
     * @param node
     * @param spreaderId
     * @param backReachCheckNeeded
     * @return double[]
     */
    public double[] getLockingTimePositions(String node, String spreaderId, boolean backReachCheckNeeded) {
        double[] lockTimePositions = new double[6];

        int sp1Id = Integer.parseInt(spreaderId.replaceAll("[\\D]", ""));
        String tPosTag = null;
        String hPosTag = null;
        String gPosTag = null;

        if (sp1Id == 1) {
            tPosTag = TROLLEY1_POSITION;
            hPosTag = HOIST1_POSITION;
            gPosTag = GANTRY_POSITION;
        } else if (sp1Id == 2) {
            tPosTag = TROLLEY2_POSITION;
            hPosTag = HOIST2_POSITION;
            gPosTag = GANTRY_POSITION;
        }

        // Get Trolley and Hoist Positions at locking time
        lockTimePositions[0] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + tPosTag + spreaderId);
        lockTimePositions[1] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + hPosTag + spreaderId);
        lockTimePositions[2] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + gPosTag + spreaderId);
        lockTimePositions[3] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + tPosTag + spreaderId);
        lockTimePositions[4] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + hPosTag + spreaderId);
        lockTimePositions[5] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + gPosTag + spreaderId);

        if (backReachCheckNeeded) {
            String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
            double backReachStart = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    QC_BACKREACH_START_VAL));
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Back Reach Start value = " + backReachStart);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Trolley Position Value = " + lockTimePositions[0]);
            if (lockTimePositions[0] <= backReachStart) {
                RDTPLCCacheManager.getInstance().addBackreachDetected(userId, true);
                RDTPLCCacheManager.getInstance().addBackreachType(userId, LOAD);
            }
        }

        return lockTimePositions;
    }

    /**
     * 
     * <p> Retrieves the positions during unlock and returns </p>
     * 
     * @param node
     * @param spreaderId
     * @param backReachCheckNeeded
     * @return double[]
     */
    public double[] getUnLockingTimePositions(String node, String spreaderId, boolean backReachCheckNeeded) {
        double[] unLockTimePositions = new double[6];

        int sp1Id = Integer.parseInt(spreaderId.replaceAll("[\\D]", ""));
        String tPosTag = null;
        String hPosTag = null;
        String gPosTag = null;

        if (sp1Id == 1) {
            tPosTag = T1_POSITION_UNLOCK;
            hPosTag = H1_POSITION_UNLOCK;
            gPosTag = GANTRY_UNLOCK;
        } else if (sp1Id == 2) {
            tPosTag = T2_POSITION_UNLOCK;
            hPosTag = H2_POSITION_UNLOCK;
            gPosTag = GANTRY_UNLOCK;
        }

        // Get Trolley and Hoist Positions at unlocking time
        unLockTimePositions[0] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + tPosTag + spreaderId);
        unLockTimePositions[1] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + hPosTag + spreaderId);
        unLockTimePositions[2] = RDTPLCCacheManager.getInstance().getPLCEventDetails(node + gPosTag + spreaderId);
        unLockTimePositions[3] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + tPosTag + spreaderId);
        unLockTimePositions[4] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + hPosTag + spreaderId);
        unLockTimePositions[5] = RDTPLCCacheManager.getInstance().getPrevPLCEventDetails(node + gPosTag + spreaderId);

        double backReachStart = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                QC_BACKREACH_START_VAL));
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);    
        if (backReachCheckNeeded) {                    
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Back Reach Start value = " + backReachStart);
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Trolley Position Value = " + unLockTimePositions[0]);
            if (unLockTimePositions[0] <= backReachStart) {
                RDTPLCCacheManager.getInstance().addBackreachDetected(userId, true);
                RDTPLCCacheManager.getInstance().addBackreachType(userId, DSCH);
            }
        }        

        return unLockTimePositions;
    }

    /**
     * 
     * <p> Identifies the move type( LOAD or DISCH) and returns. For each crane Trolley position on top of Water side
     * leg of gantry is configured in DB. So, if spreader locks before Water side leg then its LOAD, if it locks after
     * Water side leg then its DISCH </p>
     * 
     * @param lockSidePositions
     * @param unLockSidePositions
     * @param userId
     * @param node
     * @return String
     */
    public String checkMoveType(double[] lockSidePositions, String userId, String node) {
        String moveType = null;

        ApplicationParameter qcParameter = RDTPLCCacheManager.getInstance().getApplicationParamter(
                node + "_WSGANTRYLEGTROLLEYVALUE");
        double wsLegTrolleyvalue = Double.parseDouble(qcParameter.getParameterValue());

        if (lockSidePositions[0] < wsLegTrolleyvalue) {
            moveType = LOAD;            
        } else {
            moveType = DSCH;            
        }
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " MOVE TYPE IS   :" + moveType);
        return moveType;
    }

    /**
     * Identifies the gantry difference based on the current and previous job type
     * 
     * @param userId
     * @return
     */
    public double getGantryDiff(String userId) {
        double gantryDiff = 0;

        String prevJobType = RDTPLCCacheManager.getInstance().getPreviousJobType(userId);
        String currentJobType = RDTPLCCacheManager.getInstance().getCurrentJobType(userId);

        if ((TWIN.equalsIgnoreCase(prevJobType) && TWENTYSINGLE.equalsIgnoreCase(currentJobType))
                || (TWENTYSINGLE.equalsIgnoreCase(prevJobType) && TWIN.equalsIgnoreCase(currentJobType))
                || (TWENTYSINGLE.equalsIgnoreCase(prevJobType) && FORTYSINGLE.equalsIgnoreCase(currentJobType))
                || (FORTYSINGLE.equalsIgnoreCase(prevJobType) && TWENTYSINGLE.equalsIgnoreCase(currentJobType))) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "GANTRY WITHIN THE BAY   :");
            gantryDiff = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA));
        } else if (TWENTYSINGLE.equalsIgnoreCase(prevJobType) && TWENTYSINGLE.equalsIgnoreCase(currentJobType)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "GANTRY FROM TWENTY TO TWENTY WITHIN THE BAY   :");
            gantryDiff = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    QC_TWENTY_GANTRY_CHANGE_DELTA));
        } else if (FORTYSINGLE.equalsIgnoreCase(prevJobType) && FORTYSINGLE.equalsIgnoreCase(currentJobType)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "GANTRY FROM FORTY TO FORTY   :");
            gantryDiff = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    QC_FORTY_GANTRY_CHANGE_DELTA));
        } 
        return gantryDiff;
    }

    /**
     * 
     * <p> Identifies the number of row shifts, tier shifts and bay shifts from previous move to the current move.
     * 
     * Determines the row,tier & gantry shifts by dividing the delta of positions with following configured values in DB
     * which are basically container dimensions.
     * 
     * QC_TROLLEY_CHANGE_DELTA = 243 cm or 8 ft -> Width of the container QC_HOIST_CHANGE_DELTA = 262 cm or 8.6 ft ->
     * Height of the container
     * 
     * Length of container = 20 ft or 40ft
     * 
     * </p>
     * 
     * <p> Gantry change: QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA = 10ft -> To move the operation from Twin to Single QC
     * operator has to move the gantry of 10ft
     * 
     * In case of bay change operator moves 40ft QC_FORTY_GANTRY_CHANGE_DELTA
     * 
     * </p>
     * 
     * @param userId
     * @param lockSidePositions
     * @param unLockSidePositions
     * @param lockDelta
     * @param unLockDelta
     * @param moveType
     * @return int[]
     */
    public int[] getTrolleyHoistGantryDelta(String userId, double[] lockSidePositions, double[] unLockSidePositions,
            double[] lockDelta, double gantryDiff) {
        int[] positionsDelta = null;

        positionsDelta = new int[4];
        double trolleyDiff = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                QC_TROLLEY_CHANGE_DELTA));
        double hoistDiff = Double.parseDouble(DeviceCommParameters.getInstance()
                .getCommParameter(QC_HOIST_CHANGE_DELTA));

        // Since it is Discharge Op, we need to consider the delta of Positions at Locking Time
        String lastMoveType = RDTPLCCacheManager.getInstance().getMoveTypeOfUser(userId);

        if (LOAD.equalsIgnoreCase(lastMoveType)) {
            lockDelta[0] = lockSidePositions[0] - unLockSidePositions[3];

            logger.logMsg(LOG_LEVEL.DEBUG, userId, " =====PREVIOUS MOVE IS LOAD ====== : ");
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "=====HOIST DIFF ======: ");

            if ((lockSidePositions[1] > 0 && unLockSidePositions[4] > 0)
                    || (lockSidePositions[1] < 0 && unLockSidePositions[4] < 0)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " =======Both Hoist values are Positive or Negative=========:");
                lockDelta[1] = lockSidePositions[1] - unLockSidePositions[4];
            } else if (lockSidePositions[1] < 0 && unLockSidePositions[4] > 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " ======Current Hoist is Negative and Prev Hoist is Positive======:");
                lockDelta[1] = -(Math.abs(lockSidePositions[1]) + unLockSidePositions[4]);
            } else if (lockSidePositions[1] > 0 && unLockSidePositions[4] < 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " ======Current Hoist is Positive and Prev Hoist is Negative======:");
                lockDelta[1] = lockSidePositions[1] + Math.abs(unLockSidePositions[4]);
            }

            logger.logMsg(LOG_LEVEL.DEBUG, userId, " ========GANTRY DIFF =======:");
            if ((lockSidePositions[2] > 0 && unLockSidePositions[5] > 0)
                    || (lockSidePositions[2] < 0 && unLockSidePositions[5] < 0)) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " ======Both Gantry values are Positive or Negative======: ");
                lockDelta[2] = lockSidePositions[2] - unLockSidePositions[5];
            } else if (lockSidePositions[2] < 0 && unLockSidePositions[5] > 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " ======Current Gantry is Negative and Prev Gantry is Positive====== : ");
                lockDelta[2] = -(Math.abs(lockSidePositions[2]) + unLockSidePositions[5]);
            } else if (lockSidePositions[2] > 0 && unLockSidePositions[5] < 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " ======Current Gantry is Positive and Prev Gantry is Negative====== : ");
                lockDelta[2] = lockSidePositions[2] + Math.abs(unLockSidePositions[5]);
            }

        }

        // Checking cabin position moved left or right from the previous move
        if ((lockDelta[0] >= trolleyDiff) || (lockDelta[0] <= -trolleyDiff)) {
            // No.of Rows shifted from previous move
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH: Calculating Trolley Delta :");
            positionsDelta[0] = PLCEventUtil.getInstance().deltaRound(lockDelta[0], trolleyDiff);
        }

        // Checking Hoist Position going down or up from the previous move ( i.e tier change)
        if ((lockDelta[1] >= hoistDiff) || (lockDelta[1] <= -hoistDiff)) {
            // No.of Tiers shifted from previous move
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH:  Calculating Hoist Delta:");
            positionsDelta[1] = PLCEventUtil.getInstance().deltaRound(lockDelta[1], hoistDiff);
        }

        // Checking Gantry Position is changed from the previous move ( i.e Bay change)
        if ((lockDelta[2] >= gantryDiff) || (lockDelta[2] <= -gantryDiff)) {
            if (gantryDiff != 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH:  Calculating Gantry Delta :");
                positionsDelta[2] = PLCEventUtil.getInstance().deltaRound(lockDelta[2], gantryDiff);
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH:  Gantry Diff is Zero ");
                positionsDelta[2] = 0;
            }
        } else {
            if (lockDelta[2] > 0) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH:  Gantry moved towards Right:");
                RDTPLCCacheManager.getInstance().addGantryMovingDirection(userId, "R");
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH:  Gantry moved towards Left:");
                RDTPLCCacheManager.getInstance().addGantryMovingDirection(userId, "L");
            }
        }

        if ((lockDelta[0] > 0 && lockDelta[0] < trolleyDiff) || (lockDelta[0] < 0 && lockDelta[0] > -trolleyDiff)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH : Calculating Trolley Delta with Tolerence :");

            if ((lockDelta[0] > 0) && ((lockDelta[0] >=  (trolleyDiff/2)) && (lockDelta[0] < trolleyDiff ))) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " DSCH: Positive Trolley Delta variation :"
                        + (trolleyDiff - lockDelta[0]));
                positionsDelta[0] = 1;
            } else if ((lockDelta[0] < 0) && ((Math.abs(lockDelta[0]) >=  (trolleyDiff/2)) && (Math.abs(lockDelta[0]) < trolleyDiff ))) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " DSCH: Negative Trolley Delta variation :" + (Math.abs(lockDelta[0]) - trolleyDiff));
                positionsDelta[0] = -1;
            }
        }

        if ((lockDelta[1] > 0 && lockDelta[1] < hoistDiff) || (lockDelta[1] < 0 && lockDelta[1] > -hoistDiff)) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "DSCH : Calculating Hoist Delta with Tolerence :");

            if ((lockDelta[1] > 0) && ((lockDelta[1] >=  (hoistDiff/2)) && (lockDelta[1] < hoistDiff ))) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " DSCH: Positive Hoist Delta variation :"
                        + (hoistDiff - lockDelta[1]));
                positionsDelta[1] = 1;
            } else if ((lockDelta[1] < 0) && ((Math.abs(lockDelta[1]) >=  (hoistDiff/2)) && (Math.abs(lockDelta[1]) < hoistDiff ))) {
                logger.logMsg(LOG_LEVEL.DEBUG, userId,
                        " DSCH: Negative Hoist Delta variation :" + (Math.abs(lockDelta[1]) - hoistDiff));
                positionsDelta[1] = -1;
            }
        }

        logger.logMsg(LOG_LEVEL.DEBUG, userId, " =======Type of Move========= : ");
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Discharge Op. trolleyDelta is  :" + positionsDelta[0]);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Discharge Op. hoistDelta is  :" + positionsDelta[1]);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Discharge Op. gantryDelta is  :" + positionsDelta[2]);

        return positionsDelta;
    }

    /**
     * 
     * <p> Responsible for copying current cache values of positions to previous cache of specified user </p>
     * 
     * @param node
     */
    public void movingCurrentCacheToPreviousCache(String node) {
        double[] currentValues = new double[12];

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
        logger.logMsg(LOG_LEVEL.INFO, userId, new StringBuilder(ENTRY).append(" movingCurrentCacheToPreviousCache()")
                .toString());

        currentValues[0] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + TROLLEY1_POSITION + SPREADER1_LOCKEDUP);
        currentValues[1] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + TROLLEY2_POSITION + SPREADER2_LOCKEDUP);
        currentValues[2] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + HOIST1_POSITION + SPREADER1_LOCKEDUP);
        currentValues[3] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + HOIST2_POSITION + SPREADER2_LOCKEDUP);
        currentValues[4] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + GANTRY_POSITION + SPREADER1_LOCKEDUP);
        currentValues[5] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + GANTRY_POSITION + SPREADER2_LOCKEDUP);

        currentValues[6] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + T1_POSITION_UNLOCK + SPREADER1_LOCKEDUP);
        currentValues[7] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + T2_POSITION_UNLOCK + SPREADER2_LOCKEDUP);
        currentValues[8] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + H1_POSITION_UNLOCK + SPREADER1_LOCKEDUP);
        currentValues[9] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + H2_POSITION_UNLOCK + SPREADER2_LOCKEDUP);
        currentValues[10] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + GANTRY_UNLOCK + SPREADER1_LOCKEDUP);
        currentValues[11] = RDTPLCCacheManager.getInstance().getPLCEventDetails(
                node + GANTRY_UNLOCK + SPREADER2_LOCKEDUP);

        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + TROLLEY1_POSITION + SPREADER1_LOCKEDUP, currentValues[0]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + TROLLEY2_POSITION + SPREADER2_LOCKEDUP, currentValues[1]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + HOIST1_POSITION + SPREADER1_LOCKEDUP, currentValues[2]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + HOIST2_POSITION + SPREADER2_LOCKEDUP, currentValues[3]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + GANTRY_POSITION + SPREADER1_LOCKEDUP, currentValues[4]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + GANTRY_POSITION + SPREADER2_LOCKEDUP, currentValues[5]);

        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + T1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, currentValues[6]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + T2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, currentValues[7]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + H1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, currentValues[8]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + H2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, currentValues[9]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + GANTRY_UNLOCK + SPREADER1_LOCKEDUP, currentValues[10]);
        RDTPLCCacheManager.getInstance().getPrevPLCEventCache()
                .put(node + GANTRY_UNLOCK + SPREADER2_LOCKEDUP, currentValues[11]);

        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Cache assigment is done");
    }

    /**
     * 
     * <p> Retrieves the delta of current and previous positions during lock or unlock and returns </p>
     * 
     * @param node
     * @param spreaderId
     * @param isLocked
     * @return double[]
     */
    public double[] getDeltaValues(String node, String spreaderId, boolean isLocked) {
        double[] deltaValues = new double[3];

        double[] positionData;
        String lockUnlockString;
        if (isLocked) {
            positionData = PLCEventUtil.getInstance().getLockingTimePositions(node, spreaderId, true);
            lockUnlockString = LOCKSTRING;
        } else {
            positionData = PLCEventUtil.getInstance().getUnLockingTimePositions(node, spreaderId, true);
            lockUnlockString = UNLOCKSTRING;
        }

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " :=====" + lockUnlockString + "Time CURRENT CACHE ::=====  ");
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " TrolleyPosition of " + node + " is :" + positionData[0]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " HoistPosition of " + node + " is :" + positionData[1]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " GantryPosition of " + node + " is :" + positionData[2]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " :=====" + lockUnlockString + " Time PREVIOUS CACHE :====== ");
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " TrolleyPosition of " + node + " is :" + positionData[3]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " HoistPosition of " + node + " is :" + positionData[4]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " GantryPosition of " + node + " is :" + positionData[5]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " =======" + lockUnlockString + "Time DELTA is =====: : ");

        // Current Trolley position - previous Trolley position
        deltaValues[0] = positionData[0] - positionData[3];

        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " ======HOIST DIFF =====  : ");
        if ((positionData[1] > 0 && positionData[4] > 0) || (positionData[1] < 0 && positionData[4] < 0)) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + " =========Both Hoist values are Positive or Negative======= : ");
            deltaValues[1] = positionData[1] - positionData[4];
        } else if (positionData[1] < 0 && positionData[4] > 0) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + " =========Current Hoist is Negative and Prev Hoist is Positive======= : ");

            /*
             * If any one position is negative like this, we need to add both values by making the negative hoist value
             * as positive (using Math.abs(). Current hoist is negative and previous hoist is positive means hoist goes
             * down, to indicate that we need to store the negative hoist delta.
             */
            deltaValues[1] = -(Math.abs(positionData[1]) + positionData[4]);
        } else if (positionData[1] > 0 && positionData[4] < 0) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + "=========Current Hoist is Positive and Prev Hoist is Negative======== : ");

            /*
             * If any one position is negative like this, we need to add both values by making the negative hoist value
             * as positive (using Math.abs(). Current hoist is positive and previous hoist is negative means hoist goes
             * up, to indicate that we need to store the positive hoist delta.
             */
            deltaValues[1] = positionData[1] + Math.abs(positionData[4]);
        }

        if (isLocked) {
            deltaValues[2] = positionData[2] - positionData[5];
        }

        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " ========GANTRY DIFF ========== : ");
        if ((positionData[2] > 0 && positionData[5] > 0) || (positionData[2] < 0 && positionData[5] < 0)) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + " =======Both Gantry values are either Positive or Negative========= : ");
            deltaValues[2] = positionData[2] - positionData[5];
        } else if (positionData[2] < 0 && positionData[5] > 0) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + " ======Current Gantry is Negative and Prev Gantry is Positive======  : ");
            deltaValues[2] = -(Math.abs(positionData[2]) + positionData[5]);

        } else if (positionData[2] > 0 && positionData[5] < 0) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", userId
                    + " ======Current Gantry is Positive and Prev Gantry is Negative====== : ");
            deltaValues[2] = positionData[2] + Math.abs(positionData[5]);
        }

        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " TrolleyPosition DELTA is  :" + deltaValues[0]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " HoistPosition DELTA is  :" + deltaValues[1]);
        logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " GantryPosition DELTA is  :" + deltaValues[2]);

        return deltaValues;
    }

    /**
     * 
     * <p> Search for container in Joblist </p>
     * 
     * @param jobList
     * @return Container
     */
    public Container lookForContainerInJobList(String userId, String shiftedCellLocation,
            ListOrderedMap<String, JobListContainer> jobList, String moveType) {

        Container plcContainer = null;

        logger.logMsg(LOG_LEVEL.INFO, userId, new StringBuilder(ENTRY).append(" lookForContainerInJobList()")
                .toString());
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Move type :" + moveType);
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Location  :" + shiftedCellLocation);

		if (jobList != null) {
			for (String containerID : jobList.keySet()) {
				JobListContainer cntr = jobList.get(containerID);

				if ("DSCH".equalsIgnoreCase(moveType)) {
					if (shiftedCellLocation.equalsIgnoreCase(cntr.getFromLocation())) {
						plcContainer = new Container();
						plcContainer.setContainerID(cntr.getContainerId());
						break;
					}
				} else {
					if (shiftedCellLocation.equalsIgnoreCase(cntr.getToLocation())) {
						plcContainer = new Container();
						plcContainer.setContainerID(cntr.getContainerId());
						break;
					}
				}
			}
		}

        logger.logMsg(LOG_LEVEL.DEBUG, userId, "Corresponding ContainerID  :" + plcContainer);
        return plcContainer;
    }
    
    /**
     * Construct the ManualConfirmation ALert event with the specified message.
     * 
     * @param userId
     * @param message
     * @return
     */
    public ManualConfirmationAlertEvent generateManualAlertEvent(String userId, String message) {
        ManualConfirmationAlertEvent manualConfirmationAlert = new ManualConfirmationAlertEvent();
        String dateString = DATE_FORMATTER.format(new Date());

        manualConfirmationAlert.setUserID(userId);
        manualConfirmationAlert.setTimeStamp(dateString);
        manualConfirmationAlert.setEventID(UUID.randomUUID().toString());
        manualConfirmationAlert.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
        manualConfirmationAlert.setReason(message);

        return manualConfirmationAlert;
    }
    
    /**
     * 
     * <p> Responsible for sending wrong cell detected event to Master Actor </p>
     * 
     * @param userId
     * @param container
     * @param shiftedCellLocation
     */
    public void sendWrongLocationDetected(String userId, JobListContainer container, String shiftedCellLocation, String equipmentId) {
        logger.logMsg(LOG_LEVEL.DEBUG, userId, " Cell location from PLC/User :" + shiftedCellLocation);
        if (!(container.getToLocation().equalsIgnoreCase(shiftedCellLocation))) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "Sending Wrong Cell detected Event of User :");
            // Sending WrongCell Detected Event to Device
            MinaProAlertEvent alert = new MinaProAlertEvent();
            alert.setAlertCode(ALERTCODE.QC_WRONG_CELL_ALERT);
            alert.setUserID(userId);
            alert.setOperatorId(userId);
            alert.setContainerId(container.getContainerId());
            alert.setActualLocation(shiftedCellLocation);
            alert.setPlannedLocation(container.getToLocation());
            alert.setEquipmentID(equipmentId);
            
            RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
        }
    }
    
    /**
     * Raises the non vessel location alert as the crane unlocked the container between crane legs.
     * 
     * @param userId
     * @param equipmentId
     * @param unlockTrolleyPos
     */
    public void raiseNonVesselPosAlert(String userId, String equipmentId, double unlockTrolleyPos){
	   	logger.logMsg(LOG_LEVEL.DEBUG, userId, "Detected non- vessel Location : Trolley Position Value = " + unlockTrolleyPos);
    	
    	MinaProAlertEvent alert = new MinaProAlertEvent();
        alert.setAlertCode(ALERTCODE.QC_NON_VESSEL_POS_ALERT);
        alert.setUserID(userId);
        alert.setOperatorId(userId);
        alert.setEquipmentID(equipmentId);
        
        RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);       
    }  
    
    /**
     * Initializes all PLC related caches for the QC and CHE operator
     * 
     * @param user
     * @param node - equipmentId of the crane
     * @param timeStamp
     */
    public void initializePlcData(String userId, String node, Date timeStamp, OPERATOR operator) {

        RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);
        RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, false);
        RDTPLCCacheManager.getInstance().addSameLocationDetectedCache(userId, false);
        if (OPERATOR.QC.equals(operator)) {
            RDTPLCCacheManager.getInstance().addQCLoggedInentryToCache(userId, 1);

            RDTPLCCacheManager.getInstance().addUsertoFirstTimeMapping(userId, true);
            RDTPLCCacheManager.getInstance().addBackreachDetected(userId, false);

            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + TROLLEY1_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + TROLLEY2_POSITION + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + HOIST1_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + HOIST2_POSITION + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + GANTRY_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + GANTRY_POSITION + SPREADER2_LOCKEDUP, 0.0);

            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + TROLLEY1_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + TROLLEY2_POSITION + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + HOIST1_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + HOIST2_POSITION + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + GANTRY_POSITION + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + GANTRY_POSITION + SPREADER2_LOCKEDUP, 0.0);

            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + T1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + T2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + H1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + H2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + GANTRY_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPLCEventDetails(node + GANTRY_UNLOCK + SPREADER2_LOCKEDUP, 0.0);

            RDTPLCCacheManager.getInstance()
                    .addPrevPLCEventDetails(node + T1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance()
                    .addPrevPLCEventDetails(node + T2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance()
                    .addPrevPLCEventDetails(node + H1_POSITION_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance()
                    .addPrevPLCEventDetails(node + H2_POSITION_UNLOCK + SPREADER2_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + GANTRY_UNLOCK + SPREADER1_LOCKEDUP, 0.0);
            RDTPLCCacheManager.getInstance().addPrevPLCEventDetails(node + GANTRY_UNLOCK + SPREADER2_LOCKEDUP, 0.0);

            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + TROLLEY1_POSITION + LOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + TROLLEY2_POSITION + LOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + HOIST1_POSITION + LOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + HOIST2_POSITION + LOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + GANTRY_POSITION + LOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + GANTRY_POSITION + LOCK, false);

            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + TROLLEY1_POSITION + UNLOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + TROLLEY2_POSITION + UNLOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + HOIST1_POSITION + UNLOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + HOIST2_POSITION + UNLOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER1_LOCKEDUP + GANTRY_POSITION + UNLOCK, false);
            RDTPLCCacheManager.getInstance().addSpreaderStatusMaping(
            		userId + SPREADER2_LOCKEDUP + GANTRY_POSITION + UNLOCK, false);

            RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER1_LOCKEDUP, false);
            RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER2_LOCKEDUP, false);
            RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId, false);

            boolean sp1IsUnLocked = RDTPLCCacheManager.getInstance().getSpreader1UnlockDetails(
            		userId + SPREADER1_LOCKEDUP);
            boolean sp2IsUnLocked = RDTPLCCacheManager.getInstance().getSpreader1UnlockDetails(
            		userId + SPREADER2_LOCKEDUP);

            logger.logMsg(LOG_LEVEL.DEBUG, userId, "AFTER LOGIN SP1 STATUS :" + Boolean.toString(sp1IsUnLocked));
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "AFTER LOGIN SP2 STATUS :" + Boolean.toString(sp2IsUnLocked));

            RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + SPREADER1_LOCKEDUP,
                    false);
            RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + SPREADER2_LOCKEDUP,
                    false);
            RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
        } else if (OPERATOR.CHE.equals(operator)) {
            RDTPLCCacheManager.getInstance().addCHELoggedInentryToCache(userId, 1);

            RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + "spreader1_twist_lock",
                    false);
        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "PLC Initialization for Operator :" + operator);
        }
    }
}
