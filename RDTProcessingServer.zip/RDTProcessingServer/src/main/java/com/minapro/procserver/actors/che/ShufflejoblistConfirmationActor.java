package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SHUFFLEJOB_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import akka.actor.UntypedActor;

import com.minapro.procserver.actors.itv.ITVPoolActor;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.YardShuffleMoves;
import com.minapro.procserver.events.che.ConfirmShuffleRequestEvent;
import com.minapro.procserver.events.che.ConfirmShuffleResponseEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
/**
 * 
 * @author 344493
 *
 */

public class ShufflejoblistConfirmationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVPoolActor.class);
    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof ConfirmShuffleRequestEvent) {
                ConfirmShuffleRequestEvent shuffleConfirmRequest = (ConfirmShuffleRequestEvent) message;
                logger.logMsg(LOG_LEVEL.INFO, shuffleConfirmRequest.getUserID(),
                        "Received shuffle job  confirm event  " + shuffleConfirmRequest);
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(
                        shuffleConfirmRequest.getUserID());

                // remove the shuffled job
                RDTCacheManager.getInstance().deleteFromshuffledJobList(shuffleConfirmRequest.getUserID(),shuffleConfirmRequest.getShuffleContainerId(),false);

                ESBQueueManager.getInstance().postMessage(shuffleConfirmRequest, operatorRole,
                        shuffleConfirmRequest.getTerminalID());

                saveToDatabase(shuffleConfirmRequest);

            } else if (message instanceof ConfirmShuffleResponseEvent) {
                ConfirmShuffleResponseEvent confirmShuffleResponse = new ConfirmShuffleResponseEvent();
                sendConfirmShuffuledJobsToDevice(confirmShuffleResponse);
            }

            else {
                unhandled(message);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while processing the message - ", ex);
        }
    }

    private void saveToDatabase(ConfirmShuffleRequestEvent shuffleConfirmRequest) {

        YardShuffleMoves yardShuffleMoves = new YardShuffleMoves();

        User user = RDTCacheManager.getInstance().getUserDetails(shuffleConfirmRequest.getUserID());

        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(shuffleConfirmRequest.getUserID());

        yardShuffleMoves.setContainerId(shuffleConfirmRequest.getShuffleContainerId());
        yardShuffleMoves.setCreatedBy(user);
        yardShuffleMoves.setCreatedDateTime(shuffleConfirmRequest.getTimeStamp());
        yardShuffleMoves.setEquipmentID(shuffleConfirmRequest.getEquipmentID());
        yardShuffleMoves.setFromLocation(" ");// optional
        yardShuffleMoves.setMoveDateTime(shuffleConfirmRequest.getTimeStamp());
        yardShuffleMoves.setRotationNumber(Integer.parseInt(allocation.getRotationID()));
        yardShuffleMoves.setShuffleReason(" ");
        yardShuffleMoves.setShuffleReasonContainerId(" ");// optional
        yardShuffleMoves.setTerminal(shuffleConfirmRequest.getTerminalID());
        yardShuffleMoves.setToLocation(" ");// optional
        yardShuffleMoves.setUser(user);
       

        JournalEvent journalEvent = new JournalEvent(yardShuffleMoves, UPDATETYPE.ADD);
        getSender().tell(journalEvent, null);

    }

    private void sendConfirmShuffuledJobsToDevice(ConfirmShuffleResponseEvent confirmShuffleResponse) {

        OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(confirmShuffleResponse.getUserID());

        String eventType = DeviceEventTypes.getInstance().getEventType(SHUFFLEJOB_RESPONSE);
        StringBuilder responseToDevice = new StringBuilder(RESP + VALUE_SEPERATOR + eventType + VALUE_SEPERATOR
                + confirmShuffleResponse.getEventID() + VALUE_SEPERATOR + confirmShuffleResponse.getTimeStamp()
                + VALUE_SEPERATOR + confirmShuffleResponse.getShuffleContainerId() + VALUE_SEPERATOR
                + confirmShuffleResponse.getStatus() + VALUE_SEPERATOR + confirmShuffleResponse.getFailureReason()
                + VALUE_SEPERATOR + confirmShuffleResponse.getUserID() + VALUE_SEPERATOR
                + confirmShuffleResponse.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                confirmShuffleResponse.getTerminalID());

    }

}
