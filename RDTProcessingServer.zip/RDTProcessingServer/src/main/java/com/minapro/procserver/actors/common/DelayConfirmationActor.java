package com.minapro.procserver.actors.common;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserViolationAndDelay;
import com.minapro.procserver.db.UserViolationAndDelay.VIOLATION_DELAY_CATEGORY;
import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.DelayConfirmationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor class responsible for handling login delay confirmation event from the devices.</p>
 * 
 * <p>The delay reason is forwarded to the ESB and allocation details are sent to the device. The delay reason is
 * recorded in the MinaPro DB</p>
 * 
 * @author Rosemary George
 *
 */
public class DelayConfirmationActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(DelayConfirmationActor.class);

    @Override
    /**
     * Handles the <DelayConfirmEvent> messages from devices
     */
    public void onReceive(Object message) throws Exception {
        if (message instanceof DelayConfirmationEvent) {
            DelayConfirmationEvent delayConfirmEvent = (DelayConfirmationEvent) message;

            // send the allocation details to the masterActor
            AllocationEvent allocation = (AllocationEvent) RDTCacheManager.getInstance().getAllocationDetails(
                    delayConfirmEvent.getUserID());
            if (allocation != null) {
                // set the event id to be same as the one received in the request
                allocation.setEventID(delayConfirmEvent.getEventID());
                getSender().tell(allocation, null);
            }

            User user = RDTCacheManager.getInstance().getUserDetails(delayConfirmEvent.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance()
                        .getUserLoggedInRole(delayConfirmEvent.getUserID());
                ESBQueueManager.getInstance().postMessage(delayConfirmEvent, operatorRole,
                        delayConfirmEvent.getTerminalID());

                logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending the violation details to the database - "
                        + delayConfirmEvent);
                UserViolationAndDelay violation = new UserViolationAndDelay(delayConfirmEvent.getReasonCode(), user,
                        VIOLATION_DELAY_CATEGORY.VIOLATION);
                JournalEvent journalEvent = new JournalEvent(violation, UPDATETYPE.ADD);
                getSender().tell(journalEvent, null);
            }

        } else {
            unhandled(message);
        }
    }

}
