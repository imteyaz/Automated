package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_INQUIRY_FAILURE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_INQUIRY_SUCCESS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.ContainerInquiryEvent;
import com.minapro.procserver.events.ContainerInquiryResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor class responsible for handling the container inquiry functionality.
 * 
 * @author Rosemary George
 *
 */
public class ContainerInquiryActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerInquiryActor.class);
    
    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    
    @Override
    public void onReceive(Object message) throws Exception {
       if(message instanceof ContainerInquiryEvent){
           ContainerInquiryEvent inquiryEvent = (ContainerInquiryEvent)message;
           
           logger.logMsg(LOG_LEVEL.INFO, inquiryEvent.getUserID(), "Received container inquiry request-" + inquiryEvent);
           ESBQueueManager.getInstance().postMessage(inquiryEvent, OPERATOR.COMMON, inquiryEvent.getTerminalID());
       }else if(message instanceof ContainerInquiryResponseEvent){
           ContainerInquiryResponseEvent inquiryResponse = (ContainerInquiryResponseEvent)message;
           
           logger.logMsg(LOG_LEVEL.INFO, inquiryResponse.getUserID(), "Received container inquiry response-" + inquiryResponse);
           handleContainerInquiryResponse(inquiryResponse);
       }
    }

    /**
     * Handles the container inquiry response from ESB. 
     * 
     * In case the status is success, UI message will be like :
     * 1611~EventId~containerId~Line~Terminal~currentPos~status~yardIn~stop~damage~inboundVsl~outBoundVsl~
     * shipper~pod~loadPort~seal~IMOClass~reefer~plugIn~weight~oog~ISO~agent~moveKind~stodays~category~yardOut
     * ~reason~damageCode~inBoundRotation~outBoundRotation~consignee~destination~originPort~sealNo~UnNo~
     * temperature~plugInDays~content~OOGDimensions~userId~terminalId
     * 
     * @param inquiryResponse
     */
    private void handleContainerInquiryResponse(ContainerInquiryResponseEvent inquiryResponse) {
        try{
            String eventTypeId;
            
            StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR); 
            if(inquiryResponse.isInquiryStatus()){
                logger.logMsg(LOG_LEVEL.INFO, inquiryResponse.getUserID(), "Got the success response for container Inquiry.");
                eventTypeId = DeviceEventTypes.getInstance().getEventType(CONTAINER_INQUIRY_SUCCESS);
                responseToDevice.append(eventTypeId).append(VALUE_SEPERATOR).append(inquiryResponse.getEventID()).append(VALUE_SEPERATOR);
                
                fillContainerDetails(inquiryResponse, responseToDevice);
                
            }else {
                logger.logMsg(LOG_LEVEL.INFO, inquiryResponse.getUserID(), "Got the failure response for container Inquiry.");
                eventTypeId = DeviceEventTypes.getInstance().getEventType(CONTAINER_INQUIRY_FAILURE);
                
                responseToDevice.append(eventTypeId).append(VALUE_SEPERATOR).append(inquiryResponse.getEventID())
                        .append(VALUE_SEPERATOR).append(inquiryResponse.getContainerId());                        
            }
            
            responseToDevice.append(VALUE_SEPERATOR).append(inquiryResponse.getUserID())
                .append(VALUE_SEPERATOR).append(inquiryResponse.getTerminalID());
            
            OPERATOR role =  RDTCacheManager.getInstance().getUserLoggedInRole(inquiryResponse.getUserID());
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role, inquiryResponse.getTerminalID());
        }catch(Exception ex){
            logger.logException("Caught exception while handling container inquiry response-", ex);
        }
    }
    
    /**
     * Fills the container details to the UI response message
     * @param inquiryResponse
     * @param responseToDevice
     */
    private void fillContainerDetails(ContainerInquiryResponseEvent inquiryResponse, StringBuilder responseToDevice){
        responseToDevice.append(inquiryResponse.getContainerId())
        .append(VALUE_SEPERATOR).append(inquiryResponse.getLine() != null ?inquiryResponse.getLine():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getTerminal() != null ?inquiryResponse.getTerminal():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getCurrentPos()!= null ?inquiryResponse.getCurrentPos():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getStatus()!= null ?inquiryResponse.getStatus():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getYardIn()!= null ?inquiryResponse.getYardIn():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.isStopped())                
        .append(VALUE_SEPERATOR).append(inquiryResponse.isDamaged())
        .append(VALUE_SEPERATOR).append(inquiryResponse.getInBoundVessel()!= null ?inquiryResponse.getInBoundVessel():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getOutBoundVessel()!= null ?inquiryResponse.getOutBoundVessel():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getShipper()!= null ?inquiryResponse.getShipper():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getPod()!= null ?inquiryResponse.getPod():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getLoadPort()!= null ?inquiryResponse.getLoadPort():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.isSealed())
        .append(VALUE_SEPERATOR).append(inquiryResponse.getImoClass()!= null ?inquiryResponse.getImoClass():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.isReefer())
        .append(VALUE_SEPERATOR).append(inquiryResponse.isPluggedIn())
        .append(VALUE_SEPERATOR).append(inquiryResponse.getWeight()!= null ?inquiryResponse.getWeight():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.isOOG())
        .append(VALUE_SEPERATOR).append(inquiryResponse.getIso()!= null ?inquiryResponse.getIso():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getAgent()!= null ?inquiryResponse.getAgent():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getMoveKind()!= null ?inquiryResponse.getMoveKind():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getStoDays()!= null ?inquiryResponse.getStoDays():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getCategory()!= null ?inquiryResponse.getCategory():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getYardOut()!= null ?inquiryResponse.getYardOut():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getStopReason()!= null ?inquiryResponse.getStopReason():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getDamageCode()!= null ?inquiryResponse.getDamageCode():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getInBoundRotation()!= null ?inquiryResponse.getInBoundRotation():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getOutBoundRotation()!= null ?inquiryResponse.getOutBoundRotation():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getConsignee()!= null ?inquiryResponse.getConsignee():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getDestination()!= null ?inquiryResponse.getDestination():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getOriginPort()!= null ?inquiryResponse.getOriginPort():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getSealNo()!= null ?inquiryResponse.getSealNo():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getUnNo()!= null ?inquiryResponse.getUnNo():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getTemperature()!= null ?inquiryResponse.getTemperature():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getPlugInDays()!= null ?inquiryResponse.getPlugInDays():"")
        .append(VALUE_SEPERATOR).append(inquiryResponse.getContent()!= null ?inquiryResponse.getContent():"")
        .append(VALUE_SEPERATOR);
        
        responseToDevice.append(inquiryResponse.getOogLeft()!= null ?inquiryResponse.getOogLeft():"").append(ROW_SEPERATOR)
        .append(inquiryResponse.getOogRight()!= null ?inquiryResponse.getOogRight():"").append(ROW_SEPERATOR)
        .append(inquiryResponse.getOogFront()!= null ?inquiryResponse.getOogFront():"").append(ROW_SEPERATOR)
        .append(inquiryResponse.getOogBack()!= null ?inquiryResponse.getOogBack():"").append(ROW_SEPERATOR)
        .append(inquiryResponse.getOogTop()!= null ?inquiryResponse.getOogTop():"");
    }
}
