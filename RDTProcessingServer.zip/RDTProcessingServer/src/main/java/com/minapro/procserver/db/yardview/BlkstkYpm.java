package com.minapro.procserver.db.yardview;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * BlkstkYpm entity.
 * 
 * @author UMAMAHESH
 */
@Entity
@Table(name = "MP_BLKSTK_YPM")
public class BlkstkYpm implements java.io.Serializable {

    private static final long serialVersionUID = -565876203800533565L;
    @EmbeddedId
    @AttributeOverrides({
            @AttributeOverride(name = "intBlkNo", column = @Column(name = "INT_BLK_NO", nullable = false, precision = 5, scale = 0)),
            @AttributeOverride(name = "stkSeqNo", column = @Column(name = "STK_SEQ_NO", nullable = false, precision = 3, scale = 0)) })
    private BlkstkYpmId id;

    @Column(name = "BLK_STK_NO")
    private String blkStkNo;

    @Column(name = "CONTIGUITY_STK_NO")
    private Short contiguityStkNo;

    @Column(name = "RFR_ALLOWD_FLG")
    private String rfrAllowdFlg;

    @Column(name = "STK_NO_40")
    private String stkNo40;

    @Column(name = "STK_SLOT_LEN")
    private Double stkSlotLen;

    @Column(name = "STK_SLOT_LEN_UOM")
    private String stkSlotLenUom;

    @Column(name = "DEL_FLG")
    private String delFlg;

    @Column(name = "DOOR_DIRN_IND")
    private String doorDirnInd;

    @Column(name = "WRKG_STKG_HT")
    private Short wrkgStkgHt;

    @Column(name = "WRKG_STKG_HT_UOM")
    private String wrkgStkgHtUom;

    @Column(name = "APPLY_NUMSRS_FLG")
    private String applyNumsrsFlg;

    @Column(name = "INT_RFR_CONTRCTR_NO")
    private Long intRfrContrctrNo;

    public BlkstkYpmId getId() {
        return this.id;
    }

    public void setId(BlkstkYpmId id) {
        this.id = id;
    }

    public String getBlkStkNo() {
        return this.blkStkNo;
    }

    public void setBlkStkNo(String blkStkNo) {
        this.blkStkNo = blkStkNo;
    }

    public Short getContiguityStkNo() {
        return this.contiguityStkNo;
    }

    public void setContiguityStkNo(Short contiguityStkNo) {
        this.contiguityStkNo = contiguityStkNo;
    }

    public String getRfrAllowdFlg() {
        return this.rfrAllowdFlg;
    }

    public void setRfrAllowdFlg(String rfrAllowdFlg) {
        this.rfrAllowdFlg = rfrAllowdFlg;
    }

    public String getStkNo40() {
        return this.stkNo40;
    }

    public void setStkNo40(String stkNo40) {
        this.stkNo40 = stkNo40;
    }

    public Double getStkSlotLen() {
        return this.stkSlotLen;
    }

    public void setStkSlotLen(Double stkSlotLen) {
        this.stkSlotLen = stkSlotLen;
    }

    public String getStkSlotLenUom() {
        return this.stkSlotLenUom;
    }

    public void setStkSlotLenUom(String stkSlotLenUom) {
        this.stkSlotLenUom = stkSlotLenUom;
    }

    public String getDelFlg() {
        return this.delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public String getDoorDirnInd() {
        return this.doorDirnInd;
    }

    public void setDoorDirnInd(String doorDirnInd) {
        this.doorDirnInd = doorDirnInd;
    }

    public Short getWrkgStkgHt() {
        return this.wrkgStkgHt;
    }

    public void setWrkgStkgHt(Short wrkgStkgHt) {
        this.wrkgStkgHt = wrkgStkgHt;
    }

    public String getWrkgStkgHtUom() {
        return this.wrkgStkgHtUom;
    }

    public void setWrkgStkgHtUom(String wrkgStkgHtUom) {
        this.wrkgStkgHtUom = wrkgStkgHtUom;
    }

    public String getApplyNumsrsFlg() {
        return this.applyNumsrsFlg;
    }

    public void setApplyNumsrsFlg(String applyNumsrsFlg) {
        this.applyNumsrsFlg = applyNumsrsFlg;
    }

    public Long getIntRfrContrctrNo() {
        return this.intRfrContrctrNo;
    }

    public void setIntRfrContrctrNo(Long intRfrContrctrNo) {
        this.intRfrContrctrNo = intRfrContrctrNo;
    }
}