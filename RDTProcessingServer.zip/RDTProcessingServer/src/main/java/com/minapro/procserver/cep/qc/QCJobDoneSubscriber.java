package com.minapro.procserver.cep.qc;

import java.util.Map;

import akka.actor.ActorRef;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.PLCJobdoneEvent;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Class responsible for detecting PLC Job done event </p>
 * 
 * <p>Listener sends the container move event to Master Actor and also sends alerts in case of Container Weight
 * missmatch, Wrong container Picked and Wrong cell detected also pushes Events to master actor on every container move
 * event to calculate the QC Live performance</p>
 * 
 * <p> Pushes every container move event to master actor to detect the Delay Recording <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCJobDoneSubscriber implements StatementSubscriber {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QCJobDoneSubscriber.class);

    private ActorRef masterActor;

    public QCJobDoneSubscriber() {
        this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    @Override
    public String getStatement() {

        // QC Job done EPL Statement
        return "context EachQC select a,b from pattern[every (((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = lockedUpTagValue)) or (b=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = lockedUpTagValue)) or (b=EsperPLCEvent(tagName = 'Spreader1Twinlock' and tagValue = lockedUpTagValue)) or (b=EsperPLCEvent(tagName = 'Spreader2Twinlock' and tagValue = lockedUpTagValue))) "
                + "-> ((a=EsperPLCEvent(tagName = 'NettoLoad_WS' and tagValue > weight_threshold)) or "
                + "(a=EsperPLCEvent(tagName = 'NettoLoad_LS' and tagValue > ls_weight_threshold))) "
                + " -> ((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = unLockedUpTagValue)) or (b=EsperPLCEvent(tagName = 'Spreader2Lockedup' and tagValue = unLockedUpTagValue))  or (b=EsperPLCEvent(tagName = 'Spreader1Twinlock' and tagValue = unLockedUpTagValue)) or (b=EsperPLCEvent(tagName = 'Spreader2Twinlock' and tagValue = unLockedUpTagValue))))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {

        EsperPLCEvent plc1 = eventMap.get("a");
        EsperPLCEvent plc2 = eventMap.get("b");
        double weight = plc1.getTagValue();
        String containerWeight = Double.toString(weight);
        String spreaderId = plc2.getTagName();

        String node = plc1.getNode();
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        if (userId != null) {
            String liftedSpreaderId = RDTPLCCacheManager.getInstance().getworkingSpreaderMaping(userId);

            if (liftedSpreaderId.equals(spreaderId)) {

                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);
                sb.append("\n* JOB DONE DETECTED OF USER " + userId + " ON " + node + " With " + spreaderId);
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);

                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());

                PLCJobdoneEvent jobDoneEvent = new PLCJobdoneEvent();

                jobDoneEvent.setNode(node);
                jobDoneEvent.setUserId(userId);
                jobDoneEvent.setContainerWeight(containerWeight);
                jobDoneEvent.setSpreaderId(spreaderId);

                logger.logMsg(LOG_LEVEL.DEBUG, userId, "SENDING JOB DONE TO ACTOR");
                masterActor.tell(jobDoneEvent, null);
            }
        }
    }
}
