package com.minapro.procserver.cache;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.infinispan.Cache;

import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.events.ContainerMoveResponseEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.PlannedMovesEvent;

/**
 * <p> Singleton class containing all the cache related to the PLC operations. </p>
 * 
 * @author Venkataramana.ch
 *
 */

public class RDTPLCCacheManager {
	private static final RDTPLCCacheManager INSTANCE = new RDTPLCCacheManager();

	/**
	 * Current Operations PLC Event Details - node+eventFlag+SpreadFlag is the key <p> This Cache is used for storing
	 * the captured values of Trolley/Hoist/Gantry values of current container operation. </p>
	 */
	private Cache<String, Double> plcEventDetails = RDTCacheContainer.getCache("PLCEventCache");

	/**
	 * Previous Operations PLC Event details - node+eventFlag+SpreadFlag is the key This Cache is used for storing the
	 * captured values of Trolley/Hoist/Gantry values of Previous container operation. </p>
	 */
	private Cache<String, Double> prevPlcEventDetails = RDTCacheContainer.getCache("PrevPLCEventCache");

	/**
	 * Logged-in QC operators First time Job done flag details - QC userID is the key <p> This Cache is used for
	 * checking whether first operation is confirmed manually by user or not </p>
	 */
	private Cache<String, Boolean> qcFirstTimeJobdoneDetails = RDTCacheContainer.getCache("QCFirstTimeJobdone");

	/**
	 * QC EquipmentID to UserID mapping - EquipmentId is the key <p> This Cache is used for holding the mapping QC
	 * EquipmentID to QC userID <p>
	 */
	private Cache<String, String> equipmentToUserMapping = RDTCacheContainer.getCache("EquipmentUserMappingCache");

	/**
	 * QC UserID to EquipmentID mapping - UserID is the key <p> This Cache is used for holding the mapping QC userID to
	 * QC EquipmentID <p>
	 */
	private Cache<String, String> userToEquipmentMapping = RDTCacheContainer.getCache("UserEquipmentMappingCache");

	/**
	 * QC User to Initial Planned moves count mapping - equipment id is the key
	 */
	private Cache<String, PlannedMovesEvent> equipmentToPlannedMovesMapping = RDTCacheContainer
			.getCache("InitialPlannedMovesperUserCache");

	/**
	 * QC User to LoginTime mapping - UserId is the key
	 */
	private Cache<String, Date> usertoLoginTimeMapping = RDTCacheContainer.getCache("UsertoLoginTimeCache");

	/**
	 * QC User to Moves per Hour mapping - UserId is the key
	 */
	private Cache<String, Integer> usertoMovesPerHourMapping = RDTCacheContainer.getCache("QCUserMovesperHourCache");

	private Cache<String, Integer> userJobDoneMapping = RDTCacheContainer.getCache("UserJobDoneCounter");

	/**
	 * Trolley/Hoist/Gantry details captured details during Unlock - UserID is the key <p> This Cache is used for
	 * holding the mapping of QC UserID to current operations cell location So for the next move operation this will be
	 * the reference location i.e BayID.RowID.TierID<p>
	 */
	private Cache<String, String> userToCurrentCellMapping = RDTCacheContainer.getCache("QCCurrentCellLocation");

	/**
	 * QC UserID to current Operations moveType mapping - UserID is the key <p> This Cache is used for holding the
	 * mapping of QC UserID to current operations MoveType So for the next move operation this will be the reference to
	 * find out whether previous move was LOAD/DSCH<p>
	 */
	private Cache<String, String> moveTypeMapping = RDTCacheContainer.getCache("moveTypeCache");

	/**
	 * QC User to current Operations moveType mapping - UserID + PositionFlag + SpreaderID is the key <p> This Cache is
	 * used for holding the flag whether all positions are captured before unlocking or not.Before spreader unlocking
	 * all unlocking time positions must be captured </p>
	 */
	private Cache<String, Boolean> userToUnlockPositionMapping = RDTCacheContainer
			.getCache("userToUnlockPositionCache");

	private Cache<String, Integer> loggedInQCMapping = RDTCacheContainer.getCache("LoggedInQCUsersCache");
	private Cache<String, Integer> loggedInCHEMapping = RDTCacheContainer.getCache("LoggedInCHEUsersCache");

	/**
	 * QC UserID to ignore Automatic detection - UserID is the key <p> This Cache is used for holding the mapping of QC
	 * UserID to PLC automation calculation, that means, server is waiting for manual confirmation since previous
	 * detection was failed due to which server lost the reference </p>
	 */
	private Cache<String, Boolean> plcIgoneMapping = RDTCacheContainer.getCache("PLCIgnoreCache");

	/**
	 * QC UserID to Series of current working RowID's - UserID is the key <p> This Cache is used for preserving the
	 * current working rows of user since row ID's are not in sequence i.e 07 05 03 01 00 02 04 06 etc </p>
	 */
	private Cache<String, String[]> qcUserBayToRowsMapping = RDTCacheContainer.getCache("QCUserRowsCache");

	/**
	 * QC UserID to current working RowID index - UserID is the key <p> This Cache is used to preserve the current
	 * working Row index of Row Array </p>
	 */
	private Cache<String, Integer> qcUserPrevIndexMapping = RDTCacheContainer.getCache("QCUserPreviousIndexCache");

	/**
	 * QC UserID to current working BayID - UserID is the key <p> This Cache is used to preserve the current working Bay
	 * ID of QC user </p>
	 */
	private Cache<String, String> qcUserPrevBayMapping = RDTCacheContainer.getCache("QCUserPreviousBayCache");

	/**
	 * Application Parameters details - Parameter is the key
	 */
	private Cache<String, ApplicationParameter> applicationParameters = RDTCacheContainer
			.getCache("ApplicationParametersCache");

	/**
	 * QC User to Backreach detected flag mapping - UserId is the key <p> This cache holds the information whether the
	 * current operation is Backreach or not </p>
	 */
	private Cache<String, Boolean> qcUserBackreachMapping = RDTCacheContainer.getCache("UsertoBackreachCache");

	/**
	 * QC User to Backreach type(LOAD/DSCH) mapping - UserId is the key <p> This cache holds the information whether the
	 * current Backreach operation is Load of Discharge </p>
	 */
	private Cache<String, String> qcUserBackreachTypeMapping = RDTCacheContainer.getCache("BackreachTypeCache");

	/**
	 * QC User to Backreach joblist mapping - UserId is the key
	 */
	private Cache<String, Map<String, JobListContainer>> backReachJobList = RDTCacheContainer
			.getCache("BackReachJobListCache");

	/**
	 * Event captured information - UserId+SpreaderId+PositionFlag+LockUnlcokflag is the key <p> This flag is used to
	 * set the flag true if we captured the locking or unlocking time positions once, because same group of events
	 * repeats for every configured intervals, so in that case we need to ignore next occurrence of events after
	 * capturing the events immediately after the spreader lock or unlock </p>
	 */
	private Cache<String, Boolean> spreaderStatusMapping = RDTCacheContainer.getCache("SpreaderStatusCache");

	/**
	 * QC User's working Spreader mapping - UserId is the key <p> This cache holds the working spreader (Spreader1 or
	 * Spreder2) information which will be useful for further PLC Detections </p>
	 */
	private Cache<String, String> workingSpreaderMapping = RDTCacheContainer.getCache("WorkingSpreaderCache");

	/**
	 * QC User's to Spreader change detection details - UserId is the key <p> This cache holds the information whether
	 * to accept/process the corresponding spreader change detection from Esper or not. This is useful in Tandem
	 * detection because in this case we need to ignore spreader change detection of any one spreader to avoid multiple
	 * job done detection </p>
	 */
	private Cache<String, Boolean> spreader1UnlockDetails = RDTCacheContainer.getCache("Spreader1unlockstatusCache");

	/**
	 * QC SpreaderSize information - UserID is the key <p> This cache holds the information of current container size
	 * details, i.e in case of single Twenty it is 20,Single Forty it is 40 & in case of Twin it is 2020. </p>
	 */
	private Cache<String, Double> spreaderSizeDetails = RDTCacheContainer.getCache("SpreaderSizeCache");

	/**
	 * Container weight information - UserID is the key <p> This cache holds the information of current container weight
	 * </p>
	 */
	private Cache<String, String> containerweightDetails = RDTCacheContainer.getCache("ContainerWeightCache");

	/**
	 * Tandem Detection flag - UserID is the key <p> This cache holds whether the current move operation is Tandem or
	 * not </p>
	 */
	private Cache<String, Boolean> tandemDetectionDetails = RDTCacheContainer.getCache("TandemDetectionCache");

	/**
	 * Information of number of Spreader Locks - UserID is the key <p> This cache holds the number of spreader locks for
	 * current operation, if it is 1 means only one spreader is involved, 2 means two spreaders involved</p>
	 */
	private Cache<String, Integer> numberOfSperaderLocksDetails = RDTCacheContainer.getCache("SpreaderLockCountCache");

	/**
	 * Flag of spreader size captured details - UserID is the key <p> This cache holds the information about spreader
	 * size captured or not</p>
	 */
	private Cache<String, Boolean> spreaderSizeCapturedDetails = RDTCacheContainer
			.getCache("SpreaderSizeCapturedCache");

	/**
	 * Container lifted information - UserID is the key <p> This cache holds the information whether the container
	 * lifted by user or not, because sometimes container will be locked and unlocked without lifting it</p>
	 */
	private Cache<String, Boolean> containerLiftedDetails = RDTCacheContainer.getCache("containerLiftedCache");

	/**
	 * Previous JobType information - UserID is the key <p> This cache holds the information whether the previous
	 * operation was single twenty/Forty or Twin</p>
	 */
	private Cache<String, String> previousJobTypeDetails = RDTCacheContainer.getCache("previousJobTypeCache");

	/**
	 * Current JobType information - UserID is the key <p> This cache holds the information whether the current
	 * operation is single twenty/Forty or Twin</p>
	 */
	private Cache<String, String> currentJobTypeDetails = RDTCacheContainer.getCache("currentJobTypeCache");

	private Cache<String, String> userToRotationIdDetails = RDTCacheContainer.getCache("userToRotationIdCache");

	/**
	 * Flag to indicate whether same location detected - UserID is the key <p> Sometimes container can be lifted and
	 * placed at the same location, server needs to ignore such type of moves</p>
	 */
	private Cache<String, Boolean> sameLocationDetectedDetails = RDTCacheContainer
			.getCache("sameLocationDetectedCache");

	/**
	 * QC UserID to Series of current working TierID's - UserID is the key <p> This Cache is used for preserving the
	 * current working tiers of user since tier ID's are not in sequence from Deck to UnderDeck </p>
	 */
	private Cache<String, String[]> qcUserBayToTiersMapping = RDTCacheContainer.getCache("QCUserTiersCache");

	/**
	 * QC UserID to current working TierID index - UserID is the key <p> This Cache is used to preserve the current
	 * working Tier index of Tier Array </p>
	 */
	private Cache<String, Integer> qcUserPrevTierIndexMapping = RDTCacheContainer
			.getCache("QCUserPreviousTierIndexCache");

	/**
	 * QC UserID to array of bay ID's - UserID is the key <p> This Cache is used for holding the two bayId's in case of
	 * twin operation </p>
	 */
	private Cache<String, String[]> qcUsertoTwinTierIdsMapping = RDTCacheContainer.getCache("QCUsertoTwinTierIdsCache");

	/**
	 * Information about automation required or not - UserID is the key <p> This Cache holds the information whether QC
	 * user required PLC automation or not </p>
	 */
	private Cache<String, Boolean> stopPLCCacheDetails = RDTCacheContainer.getCache("stopPLCCache");

	/**
	 * Information about Gantry direction - UserID is the key <p> This Cache holds the information whether gantry moved
	 * towards left or right </p>
	 */
	private Cache<String, String> gantryDirectionDetails = RDTCacheContainer.getCache("gantryDirectionCache");

	/**
	 * Contains the total number of hours worked by a user for a specific rotation-equipment combination
	 */
	private Cache<String, Double> hoursWorkedForRotationEquipmentMap = RDTCacheContainer.getCache("HoursWorkedCache");

	private Cache<String, String> userToContainerDetails = RDTCacheContainer.getCache("userToContainerDetailsCache");

	private Cache<String, String> rowChangeByRMGCache = RDTCacheContainer.getCache("rowChangeByRMGCache");

	/**
	 * Contains whether open delay exists or not - equipmentId is the Key
	 */
	private Cache<String, Boolean> openDelayExistCache = RDTCacheContainer.getCache("OpenDelayCache");
	
	private Cache<String, String> userToFromLocationAndContainerDetails = RDTCacheContainer.getCache("userToFromLocationAndContainerDetailsCache");
	
	/**
	 * Contains the current pre job confirmation failure record - qcId is the key
	 */
	private Cache<String, List<ContainerMoveResponseEvent>> preJobConfirmationFailureMap = RDTCacheContainer.getCache("PreJobConfirmationFailureCache");

	private RDTPLCCacheManager() {
	}

	/**
	 * Gives the instance of RDTPLCCacheManager
	 * 
	 * @return
	 */
	public static RDTPLCCacheManager getInstance() {
		return INSTANCE;
	}

	/**
	 * Checks and returns true if the user has opted to stop PLC
	 * 
	 * @param userId
	 * @return
	 */
	public boolean hasUserStoppedPLC(String userId) {
		return stopPLCCacheDetails.containsKey(userId);
	}

	/**
	 * Add Yard Row Position to the specified User key
	 * 
	 * @param user_id
	 * @param count
	 */
	public void addUserTorowChangeByRMG(String userId, String yardRowPos) {
		rowChangeByRMGCache.put(userId, yardRowPos);

	}

	/**
	 * Get Yard Row Position to the specified User key
	 * 
	 * @param user_id
	 */
	public String getUserTorowChangeByRMG(String userId) {
		return rowChangeByRMGCache.get(userId);

	}

	/**
	 * Add Container to the specified User key
	 * 
	 * @param user_id
	 * @param count
	 */
	public void addUserToContainerDetails(String userId, String container) {
		userToContainerDetails.put(userId, container);

	}

	/**
	 * Get Container to the specified User key
	 * 
	 * @param user_id
	 */
	public String getUserToContainerDetails(String userId) {
		return userToContainerDetails.get(userId);

	}

	/**
	 * Add PLC details to the Cache
	 * 
	 * @param PLCKey
	 * @param tag_value
	 */
	public void addPLCEventDetails(String plcKey, Double tagValue) {
		plcEventDetails.put(plcKey, tagValue);

	}

	/**
	 * Retrieves the tag_value for the specified PLCKey
	 * 
	 * @param PLCKey
	 * @return tag_value
	 */
	public Double getPLCEventDetails(String plcKey) {
		return plcEventDetails.get(plcKey);
	}

	/**
	 * Add Previous PLC details to the Cache
	 * 
	 * @param PLCKey
	 * @param tag_value
	 */
	public void addPrevPLCEventDetails(String plcKey, Double tagValue) {
		prevPlcEventDetails.put(plcKey, tagValue);

	}

	/**
	 * Retrieves the PLCEventcache
	 * 
	 * @param PLCKey
	 * @return tag_value
	 */
	public Cache<String, Double> getPLCEventCache() {
		return plcEventDetails;
	}

	/**
	 * Retrieves the tag_value for the specified PLCKey
	 * 
	 * @param PLCKey
	 * @return tag_value
	 */
	public Double getPrevPLCEventDetails(String plcKey) {
		return prevPlcEventDetails.get(plcKey);
	}

	/**
	 * Retrieves the PrevPLCEventcache
	 * 
	 * @param PLCKey
	 * @return tag_value
	 */
	public Cache<String, Double> getPrevPLCEventCache() {
		return prevPlcEventDetails;
	}

	/**
	 * Adds the QC user to first time Job done flag mapping into the cache. user id is the key
	 * 
	 * @param user_id
	 * @param flag
	 */
	public void addUsertoFirstTimeMapping(String userId, boolean flag) {
		qcFirstTimeJobdoneDetails.put(userId, flag);

	}

	/**
	 * Retrieves the FirstTime Job done flag for the specified User key
	 * 
	 * @param user_id
	 */
	public boolean getFirstTimeMapping(String userId) {
		return qcFirstTimeJobdoneDetails.get(userId);

	}

	/**
	 * Adds the user to the Equipment Id mapping into the cache. user id is the key
	 * 
	 * @param user_id
	 * @param flag
	 */
	public void addEquipmentMappingtoUser(String equipmentId, String userId) {
		equipmentToUserMapping.put(equipmentId, userId);
		userToEquipmentMapping.put(userId, equipmentId);
	}
	
	/**
	 * Returns all the logged in users.
	 * 
	 * @return
	 */
	public Set<String> getLoggedInUsers(){
		return userToEquipmentMapping.keySet();
	}

	/**
	 * Retrieves the signed in equipmentID for the specified user
	 * 
	 * @param userId
	 * @return
	 */
	public String getSignedInEquipmentIdForUser(String userId) {
		return userToEquipmentMapping.get(userId);
	}

	/**
	 * Retrieves the user to the Equipment Id mapping into the cache. user id is the key
	 * 
	 * @param user_id
	 * @param flag
	 */
	public String getUserfromtheEquipment(String equipmentId) {
		return equipmentToUserMapping.get(equipmentId);

	}

	public void plcCacheAssigment(Cache<String, Double> currentCache) {
		prevPlcEventDetails.putAll(currentCache);

	}

	/**
	 * Add Initial Planned Moves Count for the specified Equipment key
	 * 
	 * @param equipmentId
	 * @param plannedMoves
	 */
	public void addPlannedMoves(String equipmentId, PlannedMovesEvent plannedMoves) {
		equipmentToPlannedMovesMapping.put(equipmentId, plannedMoves);

	}

	/**
	 * Retrieves the Planned Moves Count for the specified User key
	 * 
	 * @param user_id
	 */
	public int getPlannedMovesCount(String equipmentId) {
		int plannedMovesCount = 0;
		if (equipmentToPlannedMovesMapping.get(equipmentId) != null) {
			plannedMovesCount =  equipmentToPlannedMovesMapping.get(equipmentId).getPlannedMoves();
		}
		return plannedMovesCount;
	}

	
	/**
	 * Retrieves the Planned Moves for the specified Equipment key
	 * 
	 * @param equipmentId
	 */
	public PlannedMovesEvent getPlannedMoves(String equipmentId) {
		return equipmentToPlannedMovesMapping.get(equipmentId);
	}


	/**
	 * Add LoginTime for the specified User key
	 * 
	 * @param user_id
	 * @param loginTime
	 */
	public void addLoginTimeforUser(String userId, Date loginTime) {
		usertoLoginTimeMapping.put(userId, loginTime);

	}

	/**
	 * Retrieves the Login Time for the specified User key
	 * 
	 * @param user_id
	 */
	public Date getLoginTimeforUser(String userId) {
		return usertoLoginTimeMapping.get(userId);

	}

	/**
	 * Add MovesperHour for the specified QC User key
	 * 
	 * @param user_id
	 * @param loginTime
	 */
	public void addMovesperHourOfUser(String userId, int movesPerHour) {
		usertoMovesPerHourMapping.put(userId, movesPerHour);

	}

	/**
	 * Retrieves the MovesperHour for the specified QC User key
	 * 
	 * @param user_id
	 */
	public int getMovesperHourOfUser(String userId) {
		return usertoMovesPerHourMapping.get(userId);

	}

	public void addJobDoneCountOfUser(String userId, int noOfJobDone) {
		userJobDoneMapping.put(userId, noOfJobDone);

	}

	/**
	 * Retrieves the MovesperHour for the specified QC User key
	 * 
	 * @param user_id
	 */
	public int getJobDoneCountOfUser(String userId) {
		return userJobDoneMapping.get(userId);

	}

	/**
	 * Add current cell location of specified QC User key
	 * 
	 * @param user_id
	 * @param cellLocation
	 */
	public void addCurrentCellLocationOfUser(String userId, String cellLocation) {
		userToCurrentCellMapping.put(userId, cellLocation);

	}

	/**
	 * Retrieves current cell location of specified QC User key
	 * 
	 * @param user_id
	 */

	public String getCurrentCellLocationOfUser(String userId) {
		return userToCurrentCellMapping.get(userId);

	}

	/**
	 * Add Move type for specified QC User key
	 * 
	 * @param user_id
	 * @param type
	 */

	public void addMoveTypeOfUser(String userId, String type) {
		moveTypeMapping.put(userId, type);

	}

	/**
	 * Retrieves Move type of specified QC User key
	 * 
	 * @param user_id
	 */

	public String getMoveTypeOfUser(String userId) {
		return moveTypeMapping.get(userId);

	}

	/**
	 * Unlockevents detected flag details - QC user and unlockevent is the key
	 */
	public void adduserToUnlockPositionMapping(String key, boolean flag) {
		userToUnlockPositionMapping.put(key, flag);

	}

	/**
	 * Retrieves the falg for the specified User and unlock event combination
	 * 
	 * @param user_id
	 */
	public boolean getuserToUnlockPositionMapping(String key) {
		return userToUnlockPositionMapping.get(key);

	}

	public void addQCLoggedInentryToCache(String userId, int entry) {
		loggedInQCMapping.put(userId, entry);
	}

	public void addCHELoggedInentryToCache(String userId, int entry) {
		loggedInCHEMapping.put(userId, entry);
	}

	public void deleteQCEntryFromLoggedInCache(String userId) {
		loggedInQCMapping.remove(userId);
	}

	public void deleteCHEEntryFromLoggedInCache(String userId) {
		loggedInCHEMapping.remove(userId);
	}

	public int sizeOfQCLoggedInCache() {
		return loggedInQCMapping.size();
	}

	public int sizeOfCHELoggedInCache() {
		return loggedInCHEMapping.size();
	}

	public void addPlcIgnoreEntry(String key, boolean flag) {
		plcIgoneMapping.put(key, flag);

	}

	public boolean getPlcIgnoreEntry(String key) {
		return plcIgoneMapping.get(key);

	}

	/**
	 * Add Parameter details to the Cache
	 * 
	 * @param user
	 */
	public void addApplicationParamters(ApplicationParameter parameter) {
		applicationParameters.put(parameter.getParameterCode(), parameter);
	}

	public ApplicationParameter getApplicationParamter(String parameter) {
		return applicationParameters.get(parameter);
	}

	public void addUsersBaytoRowsMapping(String user, String[] currentRows) {
		qcUserBayToRowsMapping.put(user, currentRows);
	}

	public String[] getUsersBaytoRowsMapping(String user) {
		return qcUserBayToRowsMapping.get(user);

	}

	public void addQCUserstoPrevIndex(String user, int index) {
		qcUserPrevIndexMapping.put(user, index);
	}

	public int getQCUserstoPrevIndex(String user) {
		return qcUserPrevIndexMapping.get(user);

	}

	public void addQCUserstoPrevBay(String user, String bay) {
		qcUserPrevBayMapping.put(user, bay);
	}

	public String getQCUserstoPrevBay(String user) {

		return qcUserPrevBayMapping.get(user);

	}

	public void addBackreachDetected(String key, boolean flag) {
		qcUserBackreachMapping.put(key, flag);

	}

	public boolean getBackreachDetected(String key) {
		return qcUserBackreachMapping.get(key);

	}

	public void addBackreachType(String userId, String backReachType) {
		qcUserBackreachTypeMapping.put(userId, backReachType);

	}

	public String getBackreachType(String userId) {
		return qcUserBackreachTypeMapping.get(userId);

	}

	public void updateBackReachJobList(String userID, JobListContainer container) {
		Map<String, JobListContainer> jobs = backReachJobList.get(userID);

		if (jobs == null) {
			jobs = new LinkedHashMap<String, JobListContainer>();
			backReachJobList.put(userID, jobs);
		}
		jobs.put(container.getContainerId(), container);
	}

	public void deleteFromBackReachJobList(String userId, String containerId) {
		Map<String, JobListContainer> jobs = backReachJobList.get(userId);
		if (jobs != null) {
			jobs.remove(containerId);
		}
	}

	/**
	 * QC User Spreaders Status - QC user and SpreaderId is the key
	 */
	public void addSpreaderStatusMaping(String key, boolean flag) {
		spreaderStatusMapping.put(key, flag);
	}

	/**
	 * Retrieves the flag for the specified User and spreaderId combination
	 * 
	 * @param user_id
	 */
	public boolean getSpreaderStatusMaping(String key) {
		return spreaderStatusMapping.get(key);
	}

	/**
	 * QC User current Spreader - QC user is the key
	 */
	public void addworkingSpreaderMaping(String key, String spreaderId) {
		workingSpreaderMapping.put(key, spreaderId);
	}

	/**
	 * Retrieves the falg for the specified User and spreaderId combination
	 * 
	 * @param user_id
	 */
	public String getworkingSpreaderMaping(String key) {
		return workingSpreaderMapping.get(key);
	}

	/**
	 * QC User Spreaders Status - QC user and SpreaderId is the key
	 */
	public void addSpreader1UnlockDetails(String key, boolean flag) {
		spreader1UnlockDetails.put(key, flag);
	}

	/**
	 * Retrieves the falg for the specified User and spreaderId combination
	 * 
	 * @param user_id
	 */
	public boolean getSpreader1UnlockDetails(String key) {
		return spreader1UnlockDetails.get(key);
	}

	public void addSpreaderSizeDetails(String key, Double size) {
		spreaderSizeDetails.put(key, size);
	}

	public Double getSpreaderSizeDetails(String key) {
		return spreaderSizeDetails.get(key);
	}

	public void addLiftedContainerWeight(String user, String weight) {
		containerweightDetails.put(user, weight);
	}

	public String getLiftedContainerWeight(String user) {
		return containerweightDetails.get(user);
	}

	/**
	 * QC User Spreaders Status - QC user and SpreaderId is the key
	 */
	public void addTandemDetectionDetails(String user, boolean flag) {
		tandemDetectionDetails.put(user, flag);
	}

	/**
	 * Retrieves the falg for the specified User and spreaderId combination
	 * 
	 * @param user_id
	 */
	public boolean getTandemDetectionDetails(String user) {
		return tandemDetectionDetails.get(user);
	}

	public void addSpreaderLockCountDetails(String user, Integer count) {
		numberOfSperaderLocksDetails.put(user, count);
	}

	public Integer getSpreaderLockCountDetails(String user) {
		return numberOfSperaderLocksDetails.get(user);
	}

	public void addSpreaderSizeCapturedeDetails(String user, boolean flag) {
		spreaderSizeCapturedDetails.put(user, flag);
	}

	public boolean getSpreaderSizeCapturedeDetails(String user) {
		return spreaderSizeCapturedDetails.get(user);
	}

	public void addContainerLiftedDetails(String user, boolean flag) {
		containerLiftedDetails.put(user, flag);
	}

	public boolean getContainerLiftedDetails(String user) {
		return containerLiftedDetails.get(user);
	}

	public void addPreviousJobType(String user, String jobType) {
		previousJobTypeDetails.put(user, jobType);
	}

	public String getPreviousJobType(String user) {
		return previousJobTypeDetails.get(user);
	}

	public void addCurrentJobType(String user, String jobType) {
		currentJobTypeDetails.put(user, jobType);
	}

	public String getCurrentJobType(String user) {
		return currentJobTypeDetails.get(user);
	}

	public Cache<String, String> getCurrentJobTypeCache() {
		return currentJobTypeDetails;
	}

	public void jobTypeCacheAssigment(Cache<String, String> currentCache) {
		previousJobTypeDetails.putAll(currentCache);
	}

	public void addUserToRotationIdMapping(String user, String jobType) {
		userToRotationIdDetails.put(user, jobType);
	}

	public String getUserToRotationIdMapping(String user) {
		return userToRotationIdDetails.get(user);
	}

	public void addSameLocationDetectedCache(String user, boolean flag) {
		sameLocationDetectedDetails.put(user, flag);
	}

	public boolean getSameLocationDetectedCache(String user) {
		return sameLocationDetectedDetails.get(user);
	}

	public void addUsersBaytoTiersMapping(String user, String[] currentRows) {
		qcUserBayToTiersMapping.put(user, currentRows);
	}

	public String[] getUsersBaytoTiersMapping(String user) {
		return qcUserBayToTiersMapping.get(user);
	}

	public void addQCUserstoPrevTierIndex(String user, int index) {
		qcUserPrevTierIndexMapping.put(user, index);
	}

	public int getQCUserstoPrevTierIndex(String user) {
		return qcUserPrevTierIndexMapping.get(user);
	}

	public void addTwinIdsOfUser(String user, String[] bayIds) {
		qcUsertoTwinTierIdsMapping.put(user, bayIds);
	}

	public String[] getTwinIdsOfUser(String user) {
		return qcUsertoTwinTierIdsMapping.get(user);
	}

	public void addStopPLCCacheDetails(String user, boolean flag) {
		stopPLCCacheDetails.put(user, flag);
	}

	public void removeStopPLCCacheDetails(String user) {
		stopPLCCacheDetails.remove(user);
	}

	public void flushApplicationParameters() {
		applicationParameters.clear();
	}

	public void addGantryMovingDirection(String user, String direction) {
		gantryDirectionDetails.put(user, direction);
	}

	public String getGantryMovingDirection(String user) {
		return gantryDirectionDetails.get(user);
	}

	public void addPreviousHoursWorked(String userId, Double hoursWorked) {
		hoursWorkedForRotationEquipmentMap.put(userId, hoursWorked);
	}

	public Double getPreviousHoursWorked(String userId) {
		return hoursWorkedForRotationEquipmentMap.get(userId);
	}

	/**
	 * Clears the information stored in all caches for the specified user
	 * 
	 * @param userId
	 * @param equipmentId
	 */
	public void clearAllCacheForUser(String userId, String equipmentId) {
		if (equipmentId != null) {
			equipmentToUserMapping.remove(equipmentId);
		}
		usertoLoginTimeMapping.remove(userId);
		qcFirstTimeJobdoneDetails.remove(userId);
		userToEquipmentMapping.remove(userId);
	}

	/**
	 * Checks whether the open delay exists for the specified equipment.
	 * 
	 * @param equipmentId
	 * @return
	 */
	public boolean isOpenDelayExists(String equipmentId) {
		Boolean exists = openDelayExistCache.get(equipmentId);
		if (exists != null) {
			return exists;
		} else {
			return false;
		}
	}

	/**
	 * Adds an open delay indication for the specified equipment
	 * 
	 * @param equipmentId
	 */
	public void addOpenDelayForEquipment(String equipmentId) {
		openDelayExistCache.put(equipmentId, true);
	}

	/**
	 * Removes the open delay indication for the specified equipment
	 * 
	 * @param equipment
	 */
	public void removeOpenDelayForEquipment(String equipment) {
		openDelayExistCache.remove(equipment);
	}
	
	/**
	 * Adds the pre-job confirmation failure message to the cache for the specified qc.
	 * The previous entry will be overwritten.
	 * 
	 * @param qcId
	 * @param failureResp
	 */
	public void addPreJobConfirmFailure(String qcId, ContainerMoveResponseEvent failureResp){
		List<ContainerMoveResponseEvent> failureRespList = preJobConfirmationFailureMap.get(qcId);
		if(failureRespList == null){
			failureRespList = new ArrayList<ContainerMoveResponseEvent>();
			preJobConfirmationFailureMap.put(qcId, failureRespList);
		}
		
		failureRespList.add(failureResp);
	}
	
	/**
	 * Retrieves the pre-job confirmation failure message for the specified qc.
	 * @param qcId
	 * @return ContainerMoveResponseEvent.. null if no records found
	 */
	public List<ContainerMoveResponseEvent> getPreJobConfirmFailureMessage(String qcId){
		return preJobConfirmationFailureMap.get(qcId);
	}
	
	/**
	 * Removes the specified  pre-job confirmation failure message from the cache for teh QC
	 * @param qcId
	 * @param failureResp
	 */
	public void removePreJobConfirmFailureMessage(String qcId, ContainerMoveResponseEvent failureResp){
		List<ContainerMoveResponseEvent> failureRespList = preJobConfirmationFailureMap.get(qcId);
		if(failureRespList != null){
			failureRespList.remove(failureResp);
		}
	}
	
	/**
	 * Delete Container to the specified User key
	 * 
	 * @param user_id
	 */
	public void removeUserToContainerDetails(String userId) {
		userToContainerDetails.remove(userId);
	}
	
	/**
	 * add the PLC Detected Location and container(if found at lock time) to the specified User key
	 * 
	 * @param userId
	 * @param locationAndContainer
	 */
	public String addUserToFromLocationAndContainerDetails(String userId, String locationAndContainer) {
		return userToFromLocationAndContainerDetails.put(userId,locationAndContainer);
		
	}
	
	/**
	 * get the PLC Detected Location and container(if found at lock time) to the specified User key
	 * 
	 * @param userId
	 */
	public String getUserToFromLocationAndContainerDetails(String userId) {
		return userToFromLocationAndContainerDetails.get(userId);
		
	}
	
	/**
	 * remove the PLC Detected Location and container(if found at lock time) to the specified User key
	 * 
	 * @param userId
	 */
	public String removeUserToFromLocationAndContainerDetails(String userId) {
		return userToFromLocationAndContainerDetails.remove(userId);
		
	}
	
}
