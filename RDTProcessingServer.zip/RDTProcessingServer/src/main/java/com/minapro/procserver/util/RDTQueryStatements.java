package com.minapro.procserver.util;

/**
 * Interface specifying the queries used in Processing Server
 * 
 * @author Rosemary George
 *
 */
public interface RDTQueryStatements {

	//Retrieves the automatic delay which is open for the user,equipment and rotationID combination.
		public static final String GET_OPEN_DELAY_FOR_EQPMNTS = "FROM UserDelay a "
				+ "WHERE delayStartTime is not null AND delayEndTime is null AND isDeleted='N' ORDER BY delayId";
		
	//Retrieves the automatic delay which is open for the user,equipment and rotationID combination.
	public static final String GET_OPEN_DELAY_FOR_QC = "FROM UserDelay a "
			+ "WHERE delayStartTime is not null AND delayEndTime is null AND isDeleted='N' "
			+ "AND  equipmentID=:equipmentId AND rotationId=:rotationId ORDER BY delayId DESC";
	
	//Retrieves the automatic delay which is open for the user,equipment and rotationID combination.
	public static final String GET_OPEN_DELAY_FOR_CHE = "FROM UserDelay a "
			+ "WHERE delayStartTime is not null AND delayEndTime is null AND isDeleted='N' "
			+ "AND  equipmentID=:equipmentId ORDER BY delayId DESC";

	// Retrieves the list of damage location codes for the specific damage
	public static final String GET_DAMAGE_LOCATION_CODE_BY_DAMAGECODE = "SELECT d.pk.damageLocation FROM  DamageCodeLocationLink d where "
			+ "d.pk.damageCode=:damageCode ";

	// Identifies if the specified delay start/end time is overlapping with any existing delay for the
	// rotation+equipment+delayCode combination
	public static final String CHECK_OVERLAP_DELAY_RECORD_QUERY = "SELECT count(*) FROM UserDelay d"
			+ " WHERE delayCode=:delayCode AND isDeleted='N' "
			+ "AND  equipmentID=:equipmentID AND rotationId=:rotationId   "
			+ "AND (:delayStartTime between  d.delayStartTime AND d.delayEndTime "
			+ "OR :delayEndTime between d.delayStartTime AND d.delayEndTime)";

	// Retrieves the delay codes assigned to the specified role
	public static final String GET_DELAY_CODE = "FROM DelayReasonCode WHERE isDeleted='N'";

	// Retrieving the open delays for the rotation and equipment
	public static final String GET_OPEN_DELAYS_BY_ROLE_QUERY = "FROM UserDelay a "
			+ " WHERE delayStartTime is not null AND delayEndTime is null AND isDeleted='N' AND equipmentID=:equipmentId"
			+ "  AND rotationId=:rotationId AND "
			+ " a.delayCode IN (SELECT d.delaypk.delayReasonCodeID FROM DelayReasonCode d WHERE d.isDeleted='N')";

	// checking for is there any open delays in the database for the specified delay code
	public static final String CHECK_OPEN_DELAY_RECORD_QUERY = "FROM UserDelay "
			+ "WHERE delayStartTime is not null AND delayEndTime is null AND isDeleted='N' "
			+ "AND  equipmentID=:equipmentId AND rotationId=:rotationId AND delayCode=:delayCode";

	// Retrieving the latest user activity record which has no logout time
	public static final String CURRENT_USER_ACTIVITY_RECORD_QUERY = "SELECT a FROM UserActivityRecord a "
			+ " WHERE logoutDatetime is null AND user= :userName AND "
			+ " loginDatetime = (SELECT MAX(loginDatetime) FROM UserActivityRecord b WHERE b.user = a.user)";

	// Retrieving the latest user activity record which has no break end time
	public static final String CURRENT_USER_BREAK_TIME_RECORD = "SELECT a FROM UserActivityRecord a "
			+ " WHERE breakEndTIme is null AND user= :userName AND "
			+ " breakStartTime = (SELECT MAX(breakStartTime) FROM UserActivityRecord b WHERE b.user = a.user)";

	// For the specified vessel, retrieves only the bays which has 00 row present
	public static final String VESSEL_PROFILE_ZERO_ROW_QUERY = "SELECT c.pk.sectionNo, b.vesselBayNo "
			+ "FROM BayRow c, Bay b WHERE c.pk.vesselNo = b.pk.vesselNo AND c.pk.sectionNo = b.pk.sectNo "
			+ " AND c.pk.deckUnderDeck = b.pk.deckUnderDeck AND c.pk.bayOffset=b.pk.bayOffset "
			+ "AND c.vesselRowNo = '00' AND c.pk.vesselNo =:vesselNo";

	// For the specified vessel, retrieves the min and max values of row and tier offsets and the tier template details
	// for each bay
	public static final String VESSEL_PROFILE_MIN_MAX_OFFSET_BAYWISE_QUERY = "SELECT c.pk.sectionNo,c.pk.deckUnderDeck,b.vesselBayNo,"
			+ "min(c.pk.rowOffset),max(c.pk.rowOffset),min(c.pk.tierOffset),max(c.pk.tierOffset),t.headerId, t.isDefault "
			+ " FROM Cell c, Bay b, TemplateHeader t WHERE c.pk.vesselNo = b.pk.vesselNo AND c.pk.sectionNo = b.pk.sectNo "
			+ " AND c.pk.deckUnderDeck = b.pk.deckUnderDeck AND c.pk.bayOffset = b.pk.bayOffset "
			+ " AND b.tierTemplate.headerId = t.headerId AND c.pk.vesselNo =:vesselNo "
			+ " GROUP BY c.pk.sectionNo,c.pk.deckUnderDeck,b.vesselBayNo, t.headerId, t.isDefault"
			+ " ORDER BY c.pk.sectionNo,c.pk.deckUnderDeck,b.vesselBayNo, t.headerId, t.isDefault";

	// For the specified vessel and section, retrieves the cell details
	public static final String VESSEL_PROFILE_CELL_SECTION_WISE_QUERY = "SELECT b.vesselBayNo,b.pk.deckUnderDeck, c.pk.rowOffset,c.pk.tierOffset,"
			+ "c.isAvialable,c.onlyEmptyContainerAllowedFlag,c.hotSpotFlag,c.reeferTypeFlag,c.allowed45Flag "
			+ " FROM Cell c, Bay b WHERE c.pk.vesselNo = b.pk.vesselNo AND c.pk.sectionNo = b.pk.sectNo "
			+ " AND c.pk.deckUnderDeck = b.pk.deckUnderDeck AND c.pk.bayOffset = b.pk.bayOffset "
			+ "AND c.pk.vesselNo =:vesselNo AND c.pk.sectionNo=:sectionNo";

	// For the specified vessel, bay and Tier, retrieve whether the tier belongs to deck bay or under deck bay
	public static final String VESSEL_PROFILE_DECK_DETAILS_QUERY = "SELECT DISTINCT(bt.pk.deckUnderDeck) from BayTier bt, Bay b "
			+ " WHERE bt.pk.bayOffset = b.pk.bayOffset AND bt.pk.vesselNo=:vesselNo and b.vesselBayNo=:bayNo and bt.vesselTierNo=:tierNo";

	// For Vessel Foreman CheckList Response for a
	public static final String VESSEL_FOREMAN_CHECKLIST_QUERY = "select C.checklist_id,C.checklist_name,C.icon,C.category,C.mandatory,M.status"
			+ " from InspectionRecord I,InspectionCheckListMapping M,CheckList C where "
			+ "I.inspection_id=M.pk.inspectionRecord.inspection_id and M.pk.checkListItem.checklist_id=C.checklist_id and"
			+ " I.inspection_time=(select max(inspection_time) from InspectionRecord ins where ins.inspection_time between trunc(sysdate) and sysdate and user.userID=:userID) ";

	// check privileges
	public static final String CHECK_PRIVILAGE_AND_ACCESS_QUERY = "SELECT fg.int_user_grp_id,fg.FUNCTION_CD FROM functiongrpaccess_a fg,GRPDTLS_AM gr "
			+ "where fg.int_user_grp_id=gr.int_user_grp_id and gr.USER_GRP_NM=:groupName AND fg.FUNCTION_CD=:functionCode";

	// Retrieving the user activity records which has not logged out
	public static final String NO_LOGGED_OUT_USER_ACTIVITY_RECORD_QUERY = "select a from UserActivityRecord a "
			+ "where logoutDatetime is null and loginDatetime = (SELECT MAX(loginDatetime) FROM UserActivityRecord b "
			+ "WHERE b.user = a.user) and loginDatetime >= :loginTime";

	// Retrieving the QC mappings for all the currently berthed vessels
	public static final String BERTHED_VESSEL_QC_MAPPING_QUERY = "SELECT qc.rotationQcId.equipmentId, rc.rotationNumber "
			+ "FROM RotationQCMapping qc, RotationControl rc WHERE qc.rotationQcId.rotationControlId = rc.rotationControlId AND rc.status = 'B'";

	// Retrieves the sum of the hours the user has worked for the same rotation and crane
	public static final String TOTAL_HOURS_USER_WORKED_QUERY = "SELECT SUM(totalHoursWorked) FROM UserActivityRecord "
			+ "WHERE rotationId=:rotationNo AND user=:userId AND equipmentID=:equipmentId";

	// Retrieves the sum of the hours the equipment has worked for the same rotation
	public static final String TOTAL_HOURS_EQUIPMENT_WORKED_QUERY = "SELECT SUM(totalHoursWorked) FROM UserActivityRecord "
			+ "WHERE rotationId=:rotationNo AND equipmentID=:equipmentId";

	// Retrieves the count of users currently logged in as the specified role
	public static final String LOGGED_IN_USER_COUNT_QUERY = "SELECT count(*) FROM User u, UserRole g, UserRoleAssociation ug"
			+ " WHERE u.intUserId = ug.userRoleId.intUserId AND ug.userRoleId.intUserRoleId = g.roleId AND"
			+ " u.isDeleted = 'N' and u.accountStatus='A' AND u.loginStatus='Y' AND g.roleName = :roleName";

	// Retrieves the PLC events for CHE for the mentioned period
	public static final String CHE_PLC_QUERY = "FROM CHEPLCData WHERE plcpk.tagTime between (sysdate-:period/(1440*60)) "
			+ "and sysdate ORDER BY plcpk.tagTime ASC";

	// Retrieves the PLC events for QC for the mentioned period
	public static final String QC_PLC_QUERY = "FROM PLCData WHERE plcpk.node IN (:cranes) and (plcpk.tagTime between (sysdate-:period/(1440*60)) "
			+ "and sysdate) ORDER BY plcpk.tagTime ASC";
	
	// Retrieves the PLC events for QC for the mentioned period
	public static final String GET_QC_WORKING_EQUIPMENTS = "SELECT DISTINCT plcpk.node FROM PLCData WHERE plcpk.tagTime between (sysdate-:period/(24*60*60)) "
			+ "and sysdate ";
		
		// Retrieves the PLC events for QC for the mentioned period
	public static final String GET_CHE_WORKING_EQUIPMENTS = "SELECT DISTINCT plcpk.node  FROM CHEPLCData WHERE plcpk.tagTime between (sysdate-:period/(24*60*60)) "
			+ "and sysdate";

	public static final String TOTAL_COMPLETED_JOBS_CHE_EQUIPMENT_PER_SHIFT = "SELECT count(*) FROM CompletedContainerMoves "
			+ "WHERE equipment=:equipmentId AND moveTime BETWEEN  to_date(:shiftStartTime,'dd.mm.rrrr hh24:mi') AND to_date(:shiftEndTime,'dd.mm.rrrr hh24:mi')";

	public static final String TOTAL_COMPLETED_JOBS_CHE_USER_PER_SHIFT = "SELECT cm FROM CompletedContainerMoves cm "
			+ "WHERE user=:userObj AND equipment=:equipmentId AND moveTime BETWEEN  to_date(:shiftStartTime,'dd.mm.rrrr hh24:mi') AND to_date(:shiftEndTime,'dd.mm.rrrr hh24:mi')";

	// Retrieves the sum of the hours the user has worked for the same rotation and crane
	public static final String TOTAL_HOURS_CHE_USER_WORKED_QUERY = "SELECT SUM(totalHoursWorked) FROM UserActivityRecord "
			+ "WHERE user= :userObj AND loginDatetime >= to_date(:shiftStartTime,'dd.mm.rrrr hh24:mi') AND  logoutDatetime <= to_date(:shiftEndTime,'dd.mm.rrrr hh24:mi')";

	// Retrieves the exception description for the selected exception code
	public static final String EXCEPTION_DESC_QUERY = "SELECT em.description FROM ExceptionCodeMaster em where "
			+ "em.exceptionCode=:exceptionCode AND em.isDeleted='N'";

	// Retrieves all the records which is not completed and also the current date's completed jobs
	public static final String GET_TROUBLESHOOT_RECORDS_QUERY = "SELECT ts FROM TroubleShootRecord ts "
			+ "WHERE ts.status=:status1 OR ts.status=:status2 OR ts.resolvedDateTime>= :today";

	// Retrieving the user entries for which logout status is null
	public static final String LOGGED_IN_USERS_RECORD_QUERY = "FROM UserActivityRecord "
			+ " WHERE logoutDatetime is null ";

    // Retrieves the shift details
    public static final String SHIFTDATA_FORITV_LOGGEDINUSERS = "SELECT sd from  ShiftDetails sd  "
            + "where userId=:userId AND :loginTime  BETWEEN  sd.shiftStartDate AND sd.shiftEndDate "
            + "AND :systemTime  BETWEEN   sd.shiftStartDate AND sd.shiftEndDate ";
    
	// Retrieves the max value of the Index for the selected rotation, back reach type and move type combination
	public static final String BACKREACH_MAX_INDEX_BY_ROTATION = "SELECT MAX(uniqueIndex) FROM BackReachJobs "
			+ "WHERE pk.rotationId=:rotationId AND jobType=:jobType AND moveType=:moveType";

	//Retrieves the open damages which is recorded for the selected container.
	public static final String GET_OPEN_DAMAGE_FOR_CONTAINER = "SELECT d.damageTypeCode, d.damageSeverityCode, "
			+ "dr.damageCode, dr.damageLocationCode, dr.damageId, d.description FROM DamageRecording dr, DamageCode d "
			+ "WHERE dr.damageCode=d.damageCodeId AND dr.isDeleted='N' AND dr.containerId=:containerId";

	//Retrieves the damage types and its associated damage codes.
	public static final String GET_DAMAGE_TYPES_WITH_CODES_LOCATION = " SELECT d.DAMAGE_TYPE_CODE, d.DAMAGE_CODE, d.DAMAGE_SEVERITY_CODE, dl.DAMAGE_LOCATION, d.DESCRIPTION "
			+ "FROM MP_DAMAGECODE_MASTER d LEFT JOIN MP_DAMAGECODE_LOCATION_LINK dl ON d.DAMAGE_CODE=dl.DAMAGE_CODE WHERE d.ISDELETED='N'";

	//Retrieves the open damages which is recorded for the selected container.
	public static final String GET_DAMAGE_FOR_CONTAINER = "FROM DamageRecording dr "
			+ "WHERE dr.isDeleted='N' AND dr.containerId=:containerId";    

	// Retrieves the total completed jobs by the ITV operator
	public static final String TOTAL_COMPLETED_JOBS_ITV_EQUIPMENT_PER_SHIFT = "SELECT count(*) FROM CompletedContainerMoves "
			+ "where user=:user AND  equipment=:equipmentID  AND  moveTime BETWEEN   to_date(:shiftStartTime,'dd.mm.rrrr hh24:mi')  AND   to_date(:sysDateTime,'dd.mm.rrrr hh24:mi') ";

	// Retrieves the sum of the hours the ITV user has worked for the same equipment
	public static final String TOTAL_HOURS_ITV_USER_WORKED_QUERY = "SELECT SUM(totalHoursWorked) FROM UserActivityRecord "
			+ "WHERE user=:userId AND equipmentID=:equipmentId "
			+ "AND loginDatetime BETWEEN   to_date(:shiftStartTime,'dd.mm.rrrr hh24:mi')  AND  to_date(:sysDateTime,'dd.mm.rrrr hh24:mi')"; 

	//Deletes all the exceptions related to the vessel code
	public static final String CLEAR_VESSEL_EXCEPTION_QUERY = "DELETE FROM VesselException WHERE vesselNo=:vesselCode";

	// Retrieving the itv trailer ID's
	public static final String GET_TRAILER_ID = "SELECT trailerNo FROM ITVTrailerMaster";

	//Retrieves the QC/HC job list
	public static final String RETRIEVE_JOB_LIST_QUERY = "Select MP_JOB_LIST.SEQ_NO, MP_JOB_LIST.CONTAINER_ID,"
			+ " MP_JOB_LIST.MOVE_KIND, MP_JOB_LIST.FROM_LOCATION, MP_JOB_LIST.TO_LOCATION," +
			"(Select MP_TWINTANDEM_CONTAINER_LIST.TWINTANDEM_ID FROM MP_TWINTANDEM_CONTAINER_LIST, MP_TWINTANDEM_JOB_LIST " +
			"where MP_TWINTANDEM_CONTAINER_LIST.TWINTANDEM_ID=MP_TWINTANDEM_JOB_LIST.TWINTANDEM_ID and " +
			"(MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID= MP_JOB_LIST.CONTAINER_ID or " +
			"MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID= MP_JOB_LIST.CONTAINER_ID) " +
			"and MP_TWINTANDEM_JOB_LIST.MINAPRO_TWIN_SPLIT=:twinSplit " +
			"and MP_TWINTANDEM_JOB_LIST.EQUIPMENT_ID=:equipmentID and " +
			"MP_TWINTANDEM_JOB_LIST.ROTATION_ID=:rotationID and  " +
			"MP_TWINTANDEM_JOB_LIST.TERMINAL_ID=:terminalID) TWIN_ID,  " +
			"(Select MP_TWINTANDEM_JOB_LIST.TWIN_TANDEM_TYPE FROM MP_TWINTANDEM_CONTAINER_LIST, MP_TWINTANDEM_JOB_LIST  " +
			"where MP_TWINTANDEM_CONTAINER_LIST.TWINTANDEM_ID=MP_TWINTANDEM_JOB_LIST.TWINTANDEM_ID and " +
			"(MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID= MP_JOB_LIST.CONTAINER_ID or " +
			"MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID= MP_JOB_LIST.CONTAINER_ID) " +
			"and MP_TWINTANDEM_JOB_LIST.MINAPRO_TWIN_SPLIT=:twinSplit " +
			"and MP_TWINTANDEM_JOB_LIST.EQUIPMENT_ID=:equipmentID and  " +
			"MP_TWINTANDEM_JOB_LIST.ROTATION_ID=:rotationID and " +
			"MP_TWINTANDEM_JOB_LIST.TERMINAL_ID=:terminalID) TWIN_TYPE," +
			"(Select CASE WHEN MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID=MP_JOB_LIST.CONTAINER_ID THEN MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID " +
			"ELSE MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID END " +
			"FROM MP_TWINTANDEM_CONTAINER_LIST, MP_TWINTANDEM_JOB_LIST  " +
			"where MP_TWINTANDEM_CONTAINER_LIST.TWINTANDEM_ID=MP_TWINTANDEM_JOB_LIST.TWINTANDEM_ID and " +
			"(MP_TWINTANDEM_CONTAINER_LIST.CONTAINER_ID= MP_JOB_LIST.CONTAINER_ID or " +
			"MP_TWINTANDEM_CONTAINER_LIST.REFCONTAINER_ID= MP_JOB_LIST.CONTAINER_ID) " +
			"and MP_TWINTANDEM_JOB_LIST.MINAPRO_TWIN_SPLIT=:twinSplit " +
			"and MP_TWINTANDEM_JOB_LIST.EQUIPMENT_ID=:equipmentID and  " +
			"MP_TWINTANDEM_JOB_LIST.ROTATION_ID=:rotationID and " +
			"MP_TWINTANDEM_JOB_LIST.TERMINAL_ID=:terminalID) REFCONTAINER " +
			"from MP_JOB_LIST  where " +
			"MP_JOB_LIST.EQUIPMENT_ID=:equipmentID and MP_JOB_LIST.ROTATION_ID=:rotationID and MP_JOB_LIST.TERMINAL_ID=:terminalID " +
			"and MP_JOB_LIST.CONTAINER_ID not in ( select MP_COMPLETED_MOVES.CONTAINER_ID from MP_COMPLETED_MOVES where  " +
			"MP_COMPLETED_MOVES.CONTAINER_ID= mp_job_list.container_id AND "
			+ "MP_COMPLETED_MOVES.EQUIPMENT_ID=:equipmentID AND  MP_COMPLETED_MOVES.ROTATION_ID=:rotationID) order by MP_JOB_LIST.SEQ_NO" ;

	//Retrieves the twin tandem jobs recorded for the specified container, rotation and equipment combination
	public static final String GET_TWIN_TANDEM_RECORD = "SELECT tj FROM TwinTandemJobs tj, TwinTandemContainerList tc "
			+ "WHERE tj.twinTandemId=tc.pk.twinTandemId AND tj.rotationId=:rotationId AND tj.equipmentId=:equipmentId AND tj.jobType=:jobType "
			+ "AND (tc.pk.containerId=:containerId OR tc.refContainerId=:containerId)";

	public static final String GET_CURRENT_TWIN_JOB_SNAPSHOT_QUERY = "Select a.container_id as c, a.move_kind as m, a.from_location as f, a.to_location as t, a.seq_no as s, b.container_id as rc, b.move_kind as rm, b.from_location as rf, b.to_location as rt ,"
			+ " b.seq_no as rs from MP_JOB_LIST a, MP_JOB_LIST b"
			+ " where a.terminal_id=:terminalId and a.rotation_id=:rotationId and a.equipment_id=:equipmentId "
			+ " and a.container_id = b.reference_container_id";

	public static final String GET_EXISISTING_TWIN_JOBS_QUERY = "SELECT tj FROM TwinTandemJobs tj, TwinTandemContainerList tc "
			+ " WHERE tj.twinTandemId=tc.pk.twinTandemId AND tj.rotationId=:rotationId AND tj.equipmentId=:equipmentId "
			+ " AND tj.terminalId =:terminalID AND tj.isJobCompleted=:isJobCompleted";
	
	public static final String GET_TWIN_JOBS_BY_ROTATION = "SELECT tj FROM TwinTandemJobs tj, TwinTandemContainerList tc "
			+ " WHERE tj.twinTandemId=tc.pk.twinTandemId AND tj.rotationId=:rotationId ";

	public static final String DELETE_TWIN_JOB_QUERY = " Delete from TwinTandemJobs tj where tj.twinTandemId = :twinTandemId";
	
	public static final String UPDATE_JOBLIST_SEQNO_QUERY ="Update QCJobListEntity Set seqNo= :nsqlNo"
			+ " where seqNo= :seqNumber";
	
    
    //Retrieves the twin tandem jobs recorded for the specified container
    public static final String GET_TWIN_TANDEM_RECORD_BY_CONTAINER = "SELECT tj FROM TwinTandemJobs tj, TwinTandemContainerList tc "
            + "WHERE tj.twinTandemId=tc.pk.twinTandemId AND (tc.pk.containerId=:containerId OR tc.refContainerId=:containerId)";
   
    //Following Are Used to retrieve CHE JobList
    
    public static final String CHE_JOBS_RETRIEVAL_QUERY = "SELECT ch.MOVE_KIND,ch.CONTAINER_ID,ch.FROM_LOCATION,ch.TO_LOCATION,ch.EQUIPMENT_ID,ch.ROTATION_ID "
			+ " FROM MP_CHE_JOB_LIST ch WHERE ch.equipment_id =:equipmentId and "
			+ "ch.CONTAINER_ID NOT IN(select cm.CONTAINER_ID from MP_COMPLETED_MOVES cm,MP_CHE_JOB_LIST chj where "
			+ "cm.CONTAINER_ID = chj.CONTAINER_ID AND "
			+ "cm.EQUIPMENT_ID=:equipmentId and cm.move_time > sysdate-(:moveTime))";
  
    // Retrieves the delay codes assigned to the specified role
 	public static final String GET_DELAY_BY_CODE = "FROM DelayReasonCode WHERE isDeleted='N' AND delaypk.delayReasonCodeID=:reasonCode";
 	
 	// Retrieves the delay codes assigned with the specified Alert Code
  	public static final String GET_DELAY_BY_ALERT_CODE = "FROM DelayReasonCode WHERE isDeleted='N' AND alertCode=:alertCode";

 	public static final String UPDATE_TWIN_TANDEM_CONTAIERS = " UPDATE MP_TWINTANDEM_CONTAINER_LIST"
 				+ " SET CONTAINER_ID=:containerId, FROM_LOCATION = :fromLocation,"
 				+ " TO_LOCATION =:toLocation, REFCONTAINER_ID=:refContainerId,"
 				+ " REFFROM_LOCATION =:refFromLocation,REFTO_LOCATION=:refToLocation"
 				+ " WHERE twintandem_id= :twinTandemId";
 	
 	//Retrieves the list of equipments which are assigned to work on the specified container.
 	 public static final String GET_EQUIPMENTS_WORKING_ON_CONTAINER = "SELECT qc.equipment_id FROM MP_OPUS_QC_JOB_LIST qc WHERE qc.container_id=:containerId"
 				+ " union SELECT cj.equipment_id FROM MP_COMPLETED_MOVES cj WHERE cj.container_id=:containerId"
 				+ " union SELECT che.equipment_id FROM MP_OPUS_CHE_JOB_LIST che WHERE che.container_id=:containerId";
 	 
 	// Retrieves the total completed jobs by the ITV operator
 	public static final String TOTAL_COMPLETED_JOBS_QC_EQUIPMENT = "SELECT count(*) FROM CompletedContainerMoves "
 			+ "where equipment=:equipmentID AND rotationId=:rotationId AND moveTime >= to_date(:loginTime,'dd.mm.rrrr hh24:mi')"; 	
 	
 	// Retrieves the completed job based on container number
  	public static final String GET_COMPLETED_JOB_BY_CONTAINER = "FROM CompletedContainerMoves "
  			+ "where containerId=:containerId AND equipment!=:equipment"; 	
}
