package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_COMPLETED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.map.ListOrderedMap;
import org.hibernate.Session;
import org.hibernate.Transaction;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.db.opus.joblist.OPUSQCJobListEntity;
import com.minapro.procserver.db.opus.joblist.OPUSQcJobListHandler;
import com.minapro.procserver.db.opus.joblist.OpusQCJobListDAO;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.UpdateBayViewRequestEvent;
import com.minapro.procserver.opus.util.OpusQcJobListService;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.TransactionManager;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for handling the job list related events. </p>
 * 
 * <p> ESB will be pushing job list updates in every x seconds. This actor verifies and compares the ESB job list with
 * what is already present in the Cache. If the job is not found in cache, it is added to the Cache. Else for each
 * container, the from and to locations are compared with the current cache, to detect any change and updates the cache.
 * The delta from the Cache job list is then sent to the device. </p>
 * 
 * @author Rosemary George
 *
 */
public class JobListActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(JobListActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);
    
    
    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
    

    @Override
    /**
     * Handles JobListEvent(comes from ESB) and JobListRequestEvent(server initiated internally or from operator)
     */
    public void onReceive(Object message) throws Exception {
        if (message instanceof JobListEvent) {

        	JobListEvent jobList = (JobListEvent) message;
        	logger.logMsg(LOG_LEVEL.INFO, jobList.getUserID(), "Received QC JobList Event from ESB "+jobList);        
            handleJobListEventFromESB(jobList);
            
			logger.logMsg(LOG_LEVEL.INFO, jobList.getEquipmentID(), new StringBuilder(EQUIPMENT_JOB_LIST_REQUEST_COMPLETED).toString());
			RDTCacheManager	.getInstance().setEqJobListReqStatus(
							RDTCacheManager.getInstance().getUserLoggedInRole(jobList.getUserID()).equals(OPERATOR.HC) ? RDTCacheManager
									.getInstance().getQCEquipmentAllocatedForHC(jobList.getUserID())
									: jobList.getEquipmentID(), EquipmentJobListRequestStatus.COMPLETED);

        } else if (message instanceof JobListRequestEvent) {
            JobListRequestEvent jobList = (JobListRequestEvent) message;
            handleJobListRequestEventFromUser(jobList, jobList.isScheduled());
            
			logger.logMsg(LOG_LEVEL.INFO, jobList.getEquipmentID(), new StringBuilder(EQUIPMENT_JOB_LIST_REQUEST_COMPLETED).toString());
			RDTCacheManager.getInstance().setEqJobListReqStatus(
							RDTCacheManager.getInstance().getUserLoggedInRole(jobList.getUserID()).equals(OPERATOR.HC) ? RDTCacheManager
									.getInstance().getQCEquipmentAllocatedForHC(jobList.getUserID())
									: jobList.getEquipmentID(), EquipmentJobListRequestStatus.COMPLETED);          
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the job list event from ESB. The job list is compared with the job list present in the cache. The
     * modified, added and deleted jobs are identified and notified to the user.
     * 
     * @param jobList
     */
    private void handleJobListEventFromESB(JobListEvent jobList) {

        String equipmentId = jobList.getEquipmentID();
        // in case of HC job list, get the QC equipment allocated
        if (OPERATOR.HC.equals(RDTCacheManager.getInstance().getUserLoggedInRole(jobList.getUserID()))) {
            equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(jobList.getUserID());
            jobList.setEquipmentID(equipmentId);
        }

        ListOrderedMap<String, JobListContainer> jobsInCache = null; 
        try {
            jobsInCache = RDTCacheManager.getInstance().getJobList(
                jobList.getUserID(), equipmentId);
        }catch(Exception e){
            logger.logException("Caught exception while trying to get the jobList -", e);
        }

        String messageType = RESP;
        if (jobList.isScheduled()) {
            messageType = NOTIF;
        }

        OPERATOR userRole = RDTCacheManager.getInstance().getUserLoggedInRole(jobList.getUserID());
        try {

        	// get the rotationId of the user
        	ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
        			.getAllocationDetails(jobList.getUserID());
        	if(allocation!=null) {
        		executeProcedureLogic(jobList ,allocation.getRotationID());
        	}else{
        		logger.logMsg(LOG_LEVEL.ERROR,equipmentId," User Allocation Is Null.Procedure Execution Is Not Possible.");
        	}

        	List<JobListContainer> jobsFromDB = OpusQcJobListService.getInstnace().getOPUSQCJobList(jobList,allocation.getRotationID());  

        	StringBuilder deletedJobs = identifyDeletedJobs(jobList, jobsInCache, userRole, jobsFromDB);
        	List<JobListContainer> modifiedJobs = identifyDeltaOfJobs(jobList, jobsInCache, userRole, jobsFromDB);     
        	
        	if(modifiedJobs == null || !modifiedJobs.isEmpty() || deletedJobs.length() > 0){
        		JobListUtil.getInstnace().reorderJobsInCacheAsPerSequence(jobList.getUserID(), equipmentId);
        	}
        	
        	// in case this is the first time, send the updated cache..        	
        	if (messageType.equals(RESP)) {
        		if(modifiedJobs == null){
        			sendEmptyResponse(jobList, jobList.getUserID(), userRole);        			
        		}else {
        			handleJobListRequestEventFromUser(jobList, jobList.isScheduled());
        		}        		
        	} 

        	operatorsJobListView(modifiedJobs, jobList, deletedJobs, messageType);

        } catch (Exception e) {
        	logger.logException("Caught exception while processing jobListEvent -", e);
        	if(messageType.equals(RESP)){
        		sendEmptyResponse(jobList, jobList.getUserID(),RDTCacheManager.getInstance().getUserLoggedInRole(jobList.getUserID()));
        	}
        }
    }
 

	private List<JobListContainer> identifyDeltaOfJobs(JobListEvent jobList, ListOrderedMap<String, 
            JobListContainer> jobsInCache, OPERATOR role, List<JobListContainer> jobsFromDB) {
        
        List<JobListContainer> modifiedJobs = new ArrayList<JobListContainer>();
        List<String> updateRequiredContainerList = new ArrayList<String>();

        JobListContainer containerFromCache;
        Container bayProfileContainer;
        
        String moveType;
        // iterate each job from ESB
        for (JobListContainer containerFromDB : jobsFromDB) {
            if (jobsInCache != null) {
                containerFromCache = jobsInCache.get(containerFromDB.getContainerId()+containerFromDB.getMoveType());
            } else {
                containerFromCache = null;
            }

            // get the container from central cache
            bayProfileContainer = RDTCacheManager.getInstance().getContainerDetails(containerFromDB.getContainerId(), containerFromDB.getMoveType());

            // the job is not present in our job list cache for this operator
            if (containerFromCache == null) {
                if (bayProfileContainer == null) {
                    // container is not present in bay profile, so needs update about stowage position
                    updateRequiredContainerList.add(containerFromDB.getContainerId());
                } 
               
                logger.logMsg(LOG_LEVEL.INFO,jobList.getUserID(),
                		new StringBuilder("Current Job Is New Job From TOS..Adding To Modified List::").append(containerFromDB.getContainerId()).toString());

                modifiedJobs.add(containerFromDB);
                if(role.equals(OPERATOR.HC) || role.equals(OPERATOR.QC)){
                    moveType = containerFromDB.getMoveType();
                }else{
                    moveType = "";
                }
                // updates the job list with this new container
                RDTCacheManager.getInstance().updateJobList(jobList.getUserID(), containerFromDB, jobList.getEquipmentID(), moveType);

            } else {
             
                boolean isModified = false;
                // container is present in our job list cache, but different attributes and it is not manually
                // overridden job
                if(!containerFromCache.getFromLocation().equals(containerFromDB.getFromLocation()) ||
                		!containerFromCache.getToLocation().equals(containerFromDB.getToLocation()) || 
                		(containerFromCache.getPosition() != null && !containerFromCache.getPosition().equals(containerFromDB.getPosition())) ||
                		(new Double(containerFromCache.getSeqNumber()).compareTo(new Double(containerFromDB.getSeqNumber()))!=0)) {
                
                	logger.logMsg(LOG_LEVEL.INFO,jobList.getUserID(),new StringBuilder(" Current Container:").
                			append(containerFromCache.getContainerId()).append(" From/To Location Changed").
                			append(" Existed Job::").append(containerFromCache).append(" Current Job::").append(containerFromDB).toString());
                	containerFromCache.setFromLocation(containerFromDB.getFromLocation());
                	containerFromCache.setToLocation(containerFromDB.getToLocation());
                	containerFromCache.setSeqNumber(containerFromDB.getSeqNumber());
                	containerFromCache.setPosition(containerFromDB.getPosition());
                	isModified = true;
                }
                if (!containerFromCache.isManuallyOverridden() && containerFromCache.compareTo(containerFromDB) > 0) {
                	 logger.logMsg(LOG_LEVEL.INFO,jobList.getUserID(),new StringBuilder(" Current Job Is Modified:::").append(containerFromDB.toString()).
                   		  append(" Older Job (Cache Job Is)::").append(containerFromCache).toString());
                     
                	containerFromCache.setFromLocation(containerFromDB.getFromLocation());
                    containerFromCache.setToLocation(containerFromDB.getToLocation());
                    containerFromCache.setTwinContainerId(containerFromDB.getTwinContainerId());
                    isModified = true;
                }
                
                if(isModified){
                    modifiedJobs.add(containerFromCache);
                }
            }
        }
        
        if(modifiedJobs != null){
        	EventUtil.getInstance().checkForFLDContainers(modifiedJobs, jobList.getEquipmentID(), jobList.getUserID());
        }

        if (!updateRequiredContainerList.isEmpty()) {
           sendUpdateBayViewRequest(updateRequiredContainerList, jobList);  
           //101033, 101017 - if container details not found on cache, do not send job list.
           //wait for updateBayView Response from ESB.
           modifiedJobs = null;
        }
        
        return modifiedJobs;
    }

   
    /**
     * Handles the job list request initiated from the operator. In case of Foreman, the associated QC's job list is
     * retrieved.
     * 
     * If no jobs are present, and empty response is sent back to the operator(if first request).
     * 
     * @param jobRequest
     */
    private void handleJobListRequestEventFromUser(Event jobRequest, Boolean isScheduled) {
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(jobRequest.getUserID());

        String requestInitatedUser = jobRequest.getUserID();
        try {
            String equipmentId = jobRequest.getEquipmentID();
            if (operatorRole.equals(OPERATOR.HC)) {
                // in case of HC, check whether the job list is available for the QC equipment
                equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(requestInitatedUser);
            }

            logger.logMsg(LOG_LEVEL.INFO, requestInitatedUser, " jobList has been requested for " + equipmentId);
            ListOrderedMap<String, JobListContainer> pendingJobs = RDTCacheManager.getInstance().getJobList(
                    jobRequest.getUserID(), equipmentId);
            
            String messageType = RESP;
            if(isScheduled){
            	messageType = NOTIF;
            }
            
            if (pendingJobs != null && !pendingJobs.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, jobRequest.getUserID(),
                        "Received jobList request from device and pending jobs are " + pendingJobs.size());
                List<JobListContainer> jobs = new ArrayList<JobListContainer>(pendingJobs.values());
                JobListUtil.getInstnace().sendJobListToDevice(jobs, jobRequest, requestInitatedUser, messageType, operatorRole);
            } else {
            	if(RESP.equals(messageType)){
            		sendEmptyResponse(jobRequest, jobRequest.getUserID(), operatorRole);
            	}
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing jobListRequestEvent -", e);
        }
    }

    /**
     * Construct and sends an empty job list response to the user
     * 
     * @param event
     * @param userId
     * @param operatorRole
     */
    private void sendEmptyResponse(Event event, String userId, OPERATOR operatorRole) {
        logger.logMsg(LOG_LEVEL.INFO, userId, "No jobs to send to device");

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPARATOR).append(eventTypeID);

        responseToDevice.append(VALUE_SEPARATOR).append(event.getEventID()).append(VALUE_SEPARATOR)
                .append(VALUE_SEPARATOR).append(userId).append(VALUE_SEPARATOR).append(event.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                event.getTerminalID());
    }

    /**
     * Verifies and identifies the jobs which are present in the cache, but not there in the jobList event. These are
     * considered as no longer valid, and removed from the cache.
     * 
     * @param jobListEvent
     * @param jobsInCache
     */
    private StringBuilder identifyDeletedJobs(JobListEvent jobListEvent, 
            Map<String, JobListContainer> jobsInCache, OPERATOR role, List<JobListContainer> jobsFromDB) {
        StringBuilder containerIds = new StringBuilder();
        if (jobsInCache != null) {
            Collection<JobListContainer> deletedContainers = CollectionUtils.subtract(jobsInCache.values(),
                    jobsFromDB);
            if (deletedContainers != null && !deletedContainers.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getUserID(), "Identified JOBS to be deleted from CACHE- "
                        + deletedContainers);

                String moveType;
                for (JobListContainer container : deletedContainers) {

                    if (!container.getContainerId().startsWith("HATCHCOVER")
                            && !container.getContainerId().startsWith("MANCAGE")
                            && !container.getContainerId().startsWith("BREAKBULK")) {
                    	
                    	// delete from the job list
                        if(role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC)){
                            moveType = container.getMoveType();
                        }else{
                            moveType = "";
                        }
                        
                        if(container.isPreConfirmedJob()){
                        	logger.logMsg(LOG_LEVEL.INFO, jobListEvent.getUserID(), "Job is getting pre-confirmed. Not deleting it");
                        	continue;
                        }
                        
                        RDTCacheManager.getInstance().deleteFromJobList(jobListEvent.getUserID(),
                                container.getContainerId(), jobListEvent.getEquipmentID(), moveType);
                        containerIds.append(container.getContainerId()).append(ITEM_SEPERATOR).
                        		append(container.getMoveType()).append(ROW_SEPARATOR);
                    }
                }
            }
        }
        return containerIds;
    }

    /**
     * <p> Sends the Delete JOB message to the operator. The message format is below </p>
     * 
     * <p> 1602~eventId~timestamp~container1|container2|container3~Type~userId~TerminalId </p>
     * 
     * @param userID
     * @param terminalID
     * @param containerIds
     */
    private void sendDeletedNotificationToDevice(String userID, String terminalID, StringBuilder containerIds) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.REMOVE_JOB);
        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
        responseToDevice.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
                .append(FORMATTER.format(new Date())).append(VALUE_SEPARATOR).append(containerIds)
                .append(VALUE_SEPARATOR).append("DELETE").append(VALUE_SEPARATOR).append(userID)
                .append(VALUE_SEPARATOR).append(terminalID);

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userID);
        CommunicationServerQueueManager.getInstance()
                .postMessage(responseToDevice.toString(), operatorRole, terminalID);

    }   

   
    /**
     * Construct and send an update bay view request event to ESB
     * 
     * @param updateRequiredContainerList
     * @param event
     */
    private void sendUpdateBayViewRequest(List<String> updateRequiredContainerList, JobListEvent event) {
        logger.logMsg(LOG_LEVEL.INFO, event.getUserID(),
                "Sending List of Containers which require stowage position update.");

        UpdateBayViewRequestEvent updateRequestEvent = new UpdateBayViewRequestEvent();
        updateRequestEvent.setEquipmentID(event.getEquipmentID());
        updateRequestEvent.setUserID(event.getUserID());
        updateRequestEvent.setEventID(UUID.randomUUID().toString());
        updateRequestEvent.setTerminalID(event.getTerminalID());
        updateRequestEvent.setUpdateRequiredContainerList(updateRequiredContainerList);

        ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(event.getUserID());
        if (allocationEvent != null) {
            updateRequestEvent.setRotationID(allocationEvent.getRotationID());
        }

        //OPERATOR operator = RDTCacheManager.getInstance().getUserLoggedInRole(event.getUserID());
        ESBQueueManager.getInstance().postMessage(updateRequestEvent, OPERATOR.QC, event.getTerminalID());
    }

    /** 
     * Method Is Responsible For Providing JobList Synchronization among the users.
     * 
     * @param ModifiedJobs
     *            from identifyAndSaveDeltaOfJobs method return jobList
     * @param JobListEvent
     *            from ESB Queue
     */
    public void operatorsJobListView(List<JobListContainer> modifiedJobs, JobListEvent jobList,
            StringBuilder deletedJobs, String messageType) {
        // send the delta information to the device. The first time, the whole set of jobs will go to device.
        try {
            RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
            User user = rdtCacheMgr.getUserDetails(jobList.getUserID());
            OPERATOR operatorRole = rdtCacheMgr.getUserLoggedInRole(user.getUserID());

            boolean inspectionStatus;
            if (messageType.equals(NOTIF)) {
            	// send to the user form whom the job list is received
            	inspectionStatus = EventUtil.getInstance().getInspectionStatus(user.getUserID());
	            if (inspectionStatus) {
	                if (deletedJobs.length() > 0) {
	                    sendDeletedNotificationToDevice(user.getUserID(), jobList.getTerminalID(), deletedJobs);
	                }
	
	                if (modifiedJobs!= null && !modifiedJobs.isEmpty()) {
	                	 JobListUtil.getInstnace().sendJobListToDevice(modifiedJobs, jobList, user.getUserID(), messageType, operatorRole);
	                } else {
	                    if (messageType.equals(RESP)) {
	                        // indicates that this is the first time server received the job list for the user,
	                        // and no jobs are there to send to user.
	                        sendEmptyResponse(jobList, user.getUserID(), operatorRole);
	                    }
	                }
	            } else {
	                logger.logMsg(LOG_LEVEL.INFO, jobList.getUserID(),
	                        "Adding the JobList to Cache as pre-operational inspection is not completed.");
	            }
            }
            
            int modifiedJobCount = 0;
            if(modifiedJobs!= null && !modifiedJobs.isEmpty()){
            	modifiedJobCount = modifiedJobs.size();
            }
            // If the user is HC, notify the associated QC
            if (operatorRole.equals(OPERATOR.HC)) {
                String qcUserId = EventUtil.getInstance().getQcUserId(user.getUserID());
                logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Associated QC user is " + qcUserId);
                if (qcUserId != null) {
                    inspectionStatus = EventUtil.getInstance().getInspectionStatus(qcUserId);
                    if (inspectionStatus) {
                        logger.logMsg(LOG_LEVEL.INFO, qcUserId, "Inspection Status true, sending job updates- "
                                + "deletedJobs:" + deletedJobs.length() + ", modifiedJobs:" + modifiedJobCount);
                        if (deletedJobs.length() > 0) {
                            sendDeletedNotificationToDevice(qcUserId, jobList.getTerminalID(), deletedJobs);
                        }
                        if (modifiedJobs!= null && !modifiedJobs.isEmpty()) {
                            jobList.setUserID(qcUserId);
                            JobListUtil.getInstnace().sendJobListToDevice(modifiedJobs, jobList, qcUserId, NOTIF, OPERATOR.QC);
                        }
                    }
                }
            } else if (operatorRole.equals(OPERATOR.QC)) {
                // If the user is QC, notify the associated HC
                String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(jobList.getEquipmentID());
                logger.logMsg(LOG_LEVEL.INFO, jobList.getEquipmentID(), "Associated HC user is " + hcUser);
                if (hcUser != null) {
                    inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
                    if (inspectionStatus) {
                        logger.logMsg(LOG_LEVEL.INFO, hcUser, "Inspection Status true, "
                                + "sending job updates - deletedJobs:" + deletedJobs.length() + ", modifiedJobs:"
                                + modifiedJobCount);
                        if (deletedJobs.length() > 0) {
                            sendDeletedNotificationToDevice(hcUser, jobList.getTerminalID(), deletedJobs);
                        }
                        // Sending Messaging To HC
                        if (modifiedJobs!= null && !modifiedJobs.isEmpty()) {
                            jobList.setUserID(hcUser);
                            JobListUtil.getInstnace().sendJobListToDevice(modifiedJobs, jobList, hcUser, NOTIF, OPERATOR.HC);
                        }
                    }
                }
            }           
        } catch (Exception ex) {
            logger.logException("Caught exception while processing jobListEvent -", ex);
        }
    }
    
    /*
     * @UmaMahesh
     * Following Method  is related to Execute QCProcedure to Java Conversion logic code.
     * Following Line Is To Execute Database Procedure.
     * 	HibernateUtil.executeJobListProcedure(jobList.getTerminalID(), allocation.getRotationID(),
				jobList.getEquipmentID() );
     */
    public void executeProcedureLogic(JobListEvent jobList , String rotationId){

    	final String logId = rotationId.concat("-").concat(jobList.getEquipmentID());
    	//TODO:Here Count Is Enough,Need to change the query in future.
    	List<OPUSQCJobListEntity> jobsForEquipment = OpusQCJobListDAO.getInstnace().getQCJobListByRotationAndEquipment(
    			jobList,rotationId);

    	int noOfJobs = jobsForEquipment!=null ? jobsForEquipment.size() : 0;			

    	logger.logMsg(LOG_LEVEL.INFO, logId, new StringBuilder("No Of Jobs Received From Database For Current Equipment ")
    		.append(noOfJobs).toString());
    	
    	if (noOfJobs > 0) {
    		
    		Session session  = null;
    		try {
    			session= HibernateUtil.getSessionFactory().openSession();
    			TransactionManager.setSession(session);

    			Transaction tx = session.beginTransaction();
    			OPUSQcJobListHandler.getInstance().doJobListRestructure(jobList,rotationId);
    			tx.commit();
    		
    		} catch (Exception ex) {
    			logger.logException("Exception Occured In Current Thread Id::"+Thread.currentThread().getId(), ex);
    			if(session!=null && session.isOpen()){
    				session.getTransaction().rollback();
    			}
    		} finally{
    			logger.logMsg(LOG_LEVEL.INFO,logId," Executing Finally Block In JobList Actor");
    			if(session!=null && session.isOpen()){
    				session.close();
    			}
    			try {
    				TransactionManager.closeSession();
    			} catch (Exception ex){
    				logger.logException("Exception Occured While Closing Trasaction Mnager Close Conncetion() Reason-", ex);
    			}
    		}
    		 jobsForEquipment = OpusQCJobListDAO.getInstnace().getQCJobListByRotationAndEquipment(
        			jobList,rotationId);
    		updateSequenceNumberWithWorkQueue(jobsForEquipment);
    		
    	} else {
    		logger.logMsg(LOG_LEVEL.INFO, logId, "DeActivated The Work Queue, Delete Corresponding TWinTandemJobs From Tables.. ");
    		OpusQCJobListDAO.getInstnace().deleteDeActivatedJobs(jobList, rotationId);
    	}
    }

	private void updateSequenceNumberWithWorkQueue(List<OPUSQCJobListEntity> jobsForEquipment) {

		logger.logMsg(LOG_LEVEL.INFO,""," db retieved jobs order by workQueue and seq number::"+jobsForEquipment);
		
		double highestSeqNoFromLowestSeqWorkQueue = 1.0;
		
		
		 for(OPUSQCJobListEntity entity : jobsForEquipment) {
			  	entity.setSeqNo(highestSeqNoFromLowestSeqWorkQueue);
			  	highestSeqNoFromLowestSeqWorkQueue++;
		  }
	  
	  logger.logMsg(LOG_LEVEL.DEBUG,"",new StringBuilder(" After Update The Sequnce Number Final Entity Is::")
	  				.append(jobsForEquipment).append(" Calling Final Database Update..").toString());
	
	  HibernateUtil.updateMultipleObjects(jobsForEquipment);
	}
}
