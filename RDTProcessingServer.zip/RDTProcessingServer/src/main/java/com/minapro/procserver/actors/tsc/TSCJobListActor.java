package com.minapro.procserver.actors.tsc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.TroubleShootRecord;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.tsc.TSCJobListRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor class responsible for handling the TSC job list request
 * 
 * @author Rosemary George
 *
 */
public class TSCJobListActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(TSCJobListActor.class);
    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

    private static final String LEVEL_1_ALERT_TIME = "LEVEL_1_TROUBLESHOOT_DELAY_ALERT_TIME";
    private static final String LEVEL_2_ALERT_TIME = "LEVEL_2_TROUBLESHOOT_DELAY_ALERT_TIME";

    private static final String LEVEL_1_COLOUR_CODE = "#FFFFA5";
    private static final String LEVEL_2_COLOUR_CODE = "#FF3232";

    // Time is in minutes. If no configuration available, these values will be used
    private static final String LEVEL_1_DEFAULT_ALERT_TIME = "30";
    private static final String LEVEL_2_DEFAULT_ALERT_TIME = "60";

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof TSCJobListRequestEvent) {
            TSCJobListRequestEvent jobListRequest = (TSCJobListRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, jobListRequest.getUserID(), "Received joblist request:" + jobListRequest);

            handleJobListRequest(jobListRequest);
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the job list request from other Actors. If the request type is set as RESP, Delay alert details are also
     * sent
     * 
     * @param jobListRequest
     */
    private void handleJobListRequest(TSCJobListRequestEvent jobListRequest) {
        try {
            List<TroubleShootRecord> troubleshootJobs = RDTCacheManager.getInstance().getTroubleShootJobs(
                    jobListRequest.getTsArea());

            String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);
            StringBuilder responseToDevice = new StringBuilder(jobListRequest.getRequestType()).append( VALUE_SEPARATOR
                   ).append( eventTypeID);
            responseToDevice.append(VALUE_SEPARATOR).append(jobListRequest.getEventID()).append(VALUE_SEPARATOR);

            if (troubleshootJobs == null || troubleshootJobs.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, jobListRequest.getUserID(),
                        "No Active trouble shoot jobs for the TS area");

                // only in case of UI request, this empty is needed
                if (jobListRequest.getRequestType().equals(RESP)) {
                    responseToDevice.append(VALUE_SEPARATOR);
                } else {
                    return;
                }
            } else {
                logger.logMsg(LOG_LEVEL.INFO, jobListRequest.getUserID(), "Active trouble shoot jobs for the area is "
                        + troubleshootJobs.size());
                responseToDevice.append(generateJobMsg(troubleshootJobs)).append(VALUE_SEPARATOR);
            }

            if (jobListRequest.getRequestType().equals(RESP)) {
                responseToDevice.append(getColourCodeScheme()).append(VALUE_SEPARATOR);
            }

            responseToDevice.append(jobListRequest.getUserID()).append(VALUE_SEPARATOR)
                    .append(jobListRequest.getTerminalID());

            // send the batch message
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.TSC,
                    jobListRequest.getTerminalID());
        } catch (Exception ex) {
            logger.logException("Caught exception while processing jobListRequestEvent -", ex);
        }
    }

    /**
     * Retrieves the level1 and level2 alert times and its associated color codes. Level1 and level 2 alert times are
     * configured in application parameter. If these values are not yet configured, default values defined in the system
     * will be used.
     * 
     * Currently the colour codes for these two levels are hard coded to yellow and red respectively.
     * 
     * @return
     */
    private StringBuilder getColourCodeScheme() {
        StringBuilder alertMsg = new StringBuilder();

        ApplicationParameter level1Time = RDTPLCCacheManager.getInstance().getApplicationParamter(LEVEL_1_ALERT_TIME);
        if (level1Time != null) {
            alertMsg.append(level1Time.getParameterValue());
        } else {
            alertMsg.append(LEVEL_1_DEFAULT_ALERT_TIME);
        }

        alertMsg.append(ITEM_SEPARATOR).append(LEVEL_1_COLOUR_CODE).append(ROW_SEPARATOR);

        ApplicationParameter level2Time = RDTPLCCacheManager.getInstance().getApplicationParamter(LEVEL_2_ALERT_TIME);
        if (level2Time != null) {
            alertMsg.append(level2Time.getParameterValue());
        } else {
            alertMsg.append(LEVEL_2_DEFAULT_ALERT_TIME);
        }

        alertMsg.append(ITEM_SEPARATOR).append(LEVEL_2_COLOUR_CODE);

        return alertMsg;
    }

    /**
     * Constructs the messageFormat with job details
     * 
     * @param troubleshootJobs
     * @return
     */
    private StringBuilder generateJobMsg(List<TroubleShootRecord> troubleshootJobs) {
        StringBuilder jobs = new StringBuilder();

        Container container;
        String rotationId;
        String pow;

        for (TroubleShootRecord record : troubleshootJobs) {
            container = RDTCacheManager.getInstance().getContainerDetails(record.getContainerId(), record.getMoveType());
            rotationId = record.getRotationId();

            jobs.append(record.getTroubleShootRecordId()).append(ITEM_SEPARATOR).append(record.getCreatedDateTime())
                    .append(ITEM_SEPARATOR).append(record.getDamageCode().getExceptionCode()).append(ITEM_SEPARATOR)
                    .append(record.getDamageCode().getDescription()).append(ITEM_SEPARATOR)
                    .append(record.getContainerId()).append(ITEM_SEPARATOR).append(record.getItvId())
                    .append(ITEM_SEPARATOR).append(record.getRotationId()).append(ITEM_SEPARATOR);

            if (rotationId != null && !rotationId.isEmpty()) {
                String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(rotationId);
                if (vesselCode != null) {
                    Vessel vessel = RDTVesselProfileCacheManager.getInstance().getVesselFromBerthedList(vesselCode);
                    if (vessel != null) {
                        jobs.append(vessel.getVesselName());
                    }
                }
            } else {
                jobs.append(ITEM_SEPARATOR);
            }

            pow = RDTPLCCacheManager.getInstance().getSignedInEquipmentIdForUser(record.getCreatedBy().getUserID());
            jobs.append(pow).append(ITEM_SEPARATOR).append(record.getMoveType()).append(ITEM_SEPARATOR);

            if (container != null) {
                jobs.append(container.getIsoCode()).append(ITEM_SEPARATOR).append(container.getWeight())
                        .append(ITEM_SEPARATOR).append(EventUtil.getInstance().getContainerIcon(container))
                        .append(ITEM_SEPARATOR);
            } else {
                jobs.append(ITEM_SEPARATOR).append(ITEM_SEPARATOR).append(ITEM_SEPARATOR);
            }

            jobs.append(record.getStatus()).append(ROW_SEPARATOR);

        }

        return jobs;
    }
}
