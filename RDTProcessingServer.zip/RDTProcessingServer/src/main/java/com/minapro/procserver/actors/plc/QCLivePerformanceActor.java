package com.minapro.procserver.actors.plc;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for measuring the performance of QC operators. </p>
 *
 * <p> Measures the following parameter for each QC operator. </p>
 *
 * <p> Moves to go - Indicates the number of jobs pending for the operator. </p> <p> Gross MovesPerHour - Indicates the
 * actual speed of operation of the operator </p> <p> Target Moves Per hour - Indicates the target speed for the
 * operator </p> <p> Target Completion Time - Indicates the time needed by the operator to complete the jobs in the
 * current speed </p> <p> Moves behind - Indicates the number of jobs delayed by the operator because of the current
 * speed. </p>
 *
 * @author VenkatRamana CH
 *
 */
public class QCLivePerformanceActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(QCLivePerformanceActor.class);

    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

    private static final String TARGET_MPH = "QC_TARGET_MPH";
    private static final SimpleDateFormat DB_DATE_FORMATTER = new SimpleDateFormat("dd.MM.yyyy HH:mm");

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof EsperPLCEvent) {
            EsperPLCEvent plcEvent = (EsperPLCEvent) message;
            String node = plcEvent.getNode();
            String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

            if (userId == null) {
            	logger.logMsg(LOG_LEVEL.DEBUG, plcEvent.getNode(), "Not able to get the QC user. Checking for HC user");
            	userId = RDTCacheManager.getInstance().getHCUserAllocatedForQC(node);
            }
            
            if (userId != null) {
                PerformanceEvent performanceEvent = measureQCPerformance(userId, node);
                OPERATOR userRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
                EventUtil.getInstance().sendPerformanceEvent(performanceEvent, userRole);

                // send the details to the associated HC and Foreman too.
                sendPerformanceUpdateToRelatedUsers(node, performanceEvent);
            }else {
            	logger.logMsg(LOG_LEVEL.DEBUG, plcEvent.getNode(), "Not able to get the associated user");
            }

        } else {
            unhandled(message);
        }
    }

    /**
     * <p> Retrieves all the users, who have logged in for the specified QC equipment, from the cache and sends the
     * performance updates to them. </p>
     * 
     * <p> In case of HC user, the update is sent as the same message format as QC. For FOREMAN roles, the
     * PerformanceEvent is forwarded to the MasterActor. </p>
     * 
     * @param qcEquipmentId
     * @param performanceEvent
     */
	private void sendPerformanceUpdateToRelatedUsers(String qcEquipmentId, PerformanceEvent performanceEvent) {
		Set<String> relatedUsers = RDTCacheManager.getInstance().getAllUsersAtLocation(qcEquipmentId);
		OPERATOR userRole;
		String notifGeneratedUserId = performanceEvent.getUserID();
		for (String user : relatedUsers) {
			if (!user.equalsIgnoreCase(notifGeneratedUserId)) {
				userRole = RDTCacheManager.getInstance().getUserLoggedInRole(user);

				// set the user as current user to whom the message needs to be sent
				performanceEvent.setUserID(user);
				if (userRole.equals(OPERATOR.FOREMAN)) {
					RDTProcessingServer.getInstance().getMasterActor().tell(performanceEvent, null);
				} else {
					EventUtil.getInstance().sendPerformanceEvent(performanceEvent, userRole);
				}
			}
		}
	}

    /**
     * Get the target MPH defined in the system(From application parameter). If no value is defined, default 32 is
     * returned.
     * 
     * @return
     */
    private int getTragetMPH() {
        ApplicationParameter targetMovesPerHour = RDTPLCCacheManager.getInstance().getApplicationParamter(TARGET_MPH);
        int targetMph = 32;
        if (targetMovesPerHour != null) {
            try {
                targetMph = Integer.parseInt(targetMovesPerHour.getParameterValue());
            } catch (Exception ex) {
                logger.logException("Caught exception while converting target mph", ex);
            }
        }
        return targetMph;
    }

    /**
     * <p> Measures the live performance of the specified QC operator based on the following formula </p>
     * 
     * <p> Moves to Go = (Planned Moves – Completed moves ) for the QC </p> <p> Total moves = Moves completed by the
     * User for current Rotation and QC </p> <p> Moves Behind = Target Moves per hour * Total hours worked – Completed
     * moves </p> <p> Moves per hour = Total completed moves / number of hours worked </p>
     * 
     */
    private PerformanceEvent measureQCPerformance(String userId, String qcEquipmentId) {
        PerformanceEvent performanceEvent = null;

        int targetMph = getTragetMPH();

        try {

            String rotationId = null;
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(userId);
            if (allocation != null) {
                rotationId = allocation.getRotationID();
            }
            int plannedMoves = RDTPLCCacheManager.getInstance().getPlannedMovesCount(qcEquipmentId);

            int completedQCJobs = 0;
            Map<String, CompletedContainerMoves> completedJobsListForQc = RDTCacheManager.getInstance()
                    .getCompletedJobs(rotationId, qcEquipmentId);
            if (completedJobsListForQc != null) {
                completedQCJobs += completedJobsListForQc.size();
            }

            Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(userId);
            String startTime = DB_DATE_FORMATTER.format(loginTime);                   
           
            // Moves to Go = (Planned Moves – Completed moves ) for the QC
            int movesToGo = plannedMoves - completedQCJobs;
            if (movesToGo < 0) {
                movesToGo = 0;
            }
            
            double diffInMillies = System.currentTimeMillis() - loginTime.getTime();
            double totalTimeWorkedInHours = diffInMillies / (1000 * 60 * 60);            

            Double hoursWorkedByQC = RDTPLCCacheManager.getInstance().getPreviousHoursWorked(qcEquipmentId);
            logger.logMsg(LOG_LEVEL.INFO, qcEquipmentId, "TotalTimeWorkedInHours previously by QC :" + hoursWorkedByQC);
            if (hoursWorkedByQC != null) {
                hoursWorkedByQC += totalTimeWorkedInHours;
            } else {
                hoursWorkedByQC = totalTimeWorkedInHours;
            }
            logger.logMsg(LOG_LEVEL.INFO, qcEquipmentId, "TotalTimeWorkedInHours by QC :" + hoursWorkedByQC);   
            logger.logMsg(LOG_LEVEL.INFO, userId, "TotalTimeWorkedInHours by user :" + totalTimeWorkedInHours);            
            
            logger.logMsg(LOG_LEVEL.INFO, userId, "CompletedJobs by QC :" + completedQCJobs);
            
            double targetCompletionTime = plannedMoves / targetMph;

            // Moves Behind = Target Moves per hour * Total hours worked – Completed moves by the crane
            int movesBehind = (int) (targetMph * hoursWorkedByQC) - completedQCJobs;
            if (movesBehind < 0) {
                logger.logMsg(LOG_LEVEL.INFO, userId, "MovesBehind in Negative  :" + movesBehind);
                movesBehind = 0;
            }

            logger.logMsg(LOG_LEVEL.INFO, userId, "Target Moves per Hour :" + targetMph);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Moves Behind  :" + movesBehind);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Moves To Go  :" + movesToGo);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Target Completion Time :" + targetCompletionTime);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Planned Moves :" + plannedMoves);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Login TIME Time :" + DATE_FORMATTER.format(loginTime));

            int completedQCUserJobs = 0;
            Map<String, CompletedContainerMoves> completedJobsListForUser = RDTCacheManager.getInstance()
                    .getCompletedJobsForUser(userId, rotationId, qcEquipmentId);
            if (completedJobsListForUser != null) {
            	completedQCUserJobs += completedJobsListForUser.size();
            }
            logger.logMsg(LOG_LEVEL.INFO, userId, "Total CompletedJobs by QC user :" + completedQCUserJobs);
            
            Long completedUserJobs = HibernateUtil.getCompletedJobsByQC(qcEquipmentId, startTime, rotationId);              
            logger.logMsg(LOG_LEVEL.INFO, userId, "CompletedJobs by QC user for the current session :" + completedUserJobs);
            
            //Consider only the login time duration for MPH calculation
            // Moves per hour : Total completed moves / number of hours worked
            double grossMovesPerHour = completedUserJobs != null ? completedUserJobs / totalTimeWorkedInHours : 0.0;
            logger.logMsg(LOG_LEVEL.INFO, userId, "Gross Moves per Hour :" + grossMovesPerHour);
            
            performanceEvent = EventUtil.getInstance().constructPerformanceEvent(userId, grossMovesPerHour,
                    targetCompletionTime, movesToGo, movesBehind, completedQCJobs, qcEquipmentId,targetMph);
        } catch (Exception ex) {
            logger.logException("Caught exception during QCLiveperformance", ex);
        }

        return performanceEvent;
    }

}