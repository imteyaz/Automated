package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.GANTRY_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.GANTRY_UNLOCK;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

public class QCGantrySpreader1UnlockSubscriber implements StatementSubscriber {

    public QCGantrySpreader1UnlockSubscriber() {
    }

    @Override
    public String getStatement() {
        return "context EachQC select a,b from pattern [ every a=EsperPLCEvent(tagName = 'GantryPosition') -> (((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = unLockedUpTagValue))) and not EsperPLCEvent(tagName = 'GantryPosition'))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateCraneMoveUnlockStatus(GANTRY_POSITION, GANTRY_UNLOCK, eventMap);
    }
}
