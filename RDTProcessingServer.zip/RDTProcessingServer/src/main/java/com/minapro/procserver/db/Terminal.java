package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ValueObject holding the terminal details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_TERMINAL_MASTER")
public class Terminal extends Audit implements Serializable {

    private static final long serialVersionUID = -537105993140498135L;

    @Id
    @Column(name = "TERMINAL_ID", nullable = false)
    private String terminalId;

    @Column(name = "DESCRIPTION")
    private String description;

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
