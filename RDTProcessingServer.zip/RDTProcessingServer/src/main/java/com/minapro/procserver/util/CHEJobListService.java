package com.minapro.procserver.util;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.map.ListOrderedMap;

import scala.collection.mutable.StringBuilder;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.db.CheWeightageFactorEntity;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.ITVWaitingTimeEntity;
import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.db.yardview.BlkareaYpm;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.util.CHEJobListUtil.TimeType;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class CHEJobListService {

	private static final MinaProApplicationLogger LOGGER  = new MinaProApplicationLogger(CHEJobListService.class);

	private static final String TWIN = "Twin ";
	private static final String REF = "Ref ";
	private static final String CONTAINER_ID = " Container Id";
	private static final String COLUN = ":";
	private static final String EQUAL = "Equal";
	private static final String CHE = " che ";
	private static final String REF_CONTAINER_ID = REF.concat(CONTAINER_ID);
	private static final String TWIN_CONTAINER_ID = TWIN.concat(CONTAINER_ID);
	private static final String TWIN_REF_CONTAINER = TWIN.concat(REF_CONTAINER_ID);
	private static final String TO_JOBLIST = " To JobList";

	private  int cheWorkingStackNumber = 0;
	private List<ITVWaitingTimeEntity> iTVWaitingList = null ;
	CHEJobListSequnceCalculator cheJobSequnceCalculatorObj = CHEJobListSequnceCalculator.getInstance();

	private CHEJobListService(){
	}

	public static CHEJobListService getInstance(){
		return new CHEJobListService();
	}


	public List<JobListContainer> getCHEJobListFromDatabase(final Event event,final int jobCompletionDays
			,List<String> updateRequiredContinersList) throws NullPointerException{

		final String equipmentId  = event.getEquipmentID();
		final String userId       = event.getUserID();
		final String logId 		  = equipmentId.concat("-").concat(userId);

		String twinContainerId = null;
		String twinRefContainerId = null;
		String jobListContainerId = null;

		LOGGER.logMsg(LOG_LEVEL.INFO,logId,new StringBuilder(" Started getCHEJobListFromDatabase ").
				append(" UpdateRequiredContinersList ").append(updateRequiredContinersList).toString());

		List<JobListContainer> cheJobsList = new ArrayList<JobListContainer>() ;
		try {

			cheJobsList = updateRequiredContinersList!=null ? getCHEJobList(equipmentId, jobCompletionDays,updateRequiredContinersList) 
					: getCHEJobList(equipmentId, jobCompletionDays,null);

			LOGGER.logMsg(LOG_LEVEL.INFO,logId,new StringBuilder("Retrieved CHE Jobs Count From DB:::")
			.append(cheJobsList!=null ? cheJobsList.size() : 0).toString());

			if(cheJobsList!=null && !cheJobsList.isEmpty()){
				List<TwinTandemJobs> twinTandemJobsList =CHEJobListDAO.getInstance().getTwinTandemJobs(TwinTandemJobs.class,"N");
				
				LOGGER.logMsg(LOG_LEVEL.INFO, logId,new StringBuilder(" Retrieved Twin Tandem Jobs ").append(" MinaproTwinSplit=N Size Is::").
						append(twinTandemJobsList!=null ? twinTandemJobsList.size() : 0).toString());				
				LOGGER.logMsg(LOG_LEVEL.TRACE,logId,new StringBuilder(" Retrieved Twin Tandem Jobs List::").
						append(twinTandemJobsList!=null ? twinTandemJobsList.toString() : null).toString());

				if(twinTandemJobsList!=null && !twinTandemJobsList.isEmpty()) {
					for(JobListContainer cheCurrentJob : cheJobsList){
						jobListContainerId = cheCurrentJob.getContainerId();
						
						for(TwinTandemJobs twinTandemJobs : twinTandemJobsList){							
							if(twinTandemJobs!=null && twinTandemJobs.getTwinTandemDetails()!=null) {
								
								for(TwinTandemContainerList twinContainerList : twinTandemJobs.getTwinTandemDetails()){
									twinContainerId = twinContainerList.getContainerId();
									twinRefContainerId = twinContainerList.getRefContainerId();

									if(twinContainerId!=null && twinRefContainerId!=null) {

										if(twinContainerId.equalsIgnoreCase(jobListContainerId)){
											cheCurrentJob.setTwinContainerId(twinRefContainerId);

											LOGGER.logMsg(LOG_LEVEL.TRACE,logId,new StringBuilder(TWIN_CONTAINER_ID)
													.append(COLUN).append(twinContainerId).append(CHE).
													append(CONTAINER_ID).append(EQUAL).append("Setting")
													.append(TWIN_REF_CONTAINER).append(TO_JOBLIST).toString());
											break;
										} else if(twinRefContainerId.equalsIgnoreCase(jobListContainerId)){
											cheCurrentJob.setTwinContainerId(twinContainerId);

											LOGGER.logMsg(LOG_LEVEL.TRACE,logId,new StringBuilder(TWIN_REF_CONTAINER)
													.append(COLUN).append(twinRefContainerId).append(CHE).
													append(CONTAINER_ID).append(EQUAL).append("Setting")
													.append(TWIN_CONTAINER_ID).append(TO_JOBLIST).toString());
											break;
										}
									} 
								}								
							} else {
								break;
							}							
						}
					}
				} else {
					LOGGER.logMsg(LOG_LEVEL.INFO,logId + equipmentId, "No Twin Jobs Available In Database");
				}
			} else {
				LOGGER.logMsg(LOG_LEVEL.INFO,logId," No Jobs Retreived From DB For Current CHE Equipment::");
			}
		}catch(Exception ex){
			LOGGER.logException("Exception Occured While Retriving CHE Jobs From DB ", ex);
		}
		return cheJobsList;
	}


	public void calculateSeqNumber(List<JobListContainer> cheJobsList,final String equipmentId , final String userId){

		LOGGER.logMsg(LOG_LEVEL.INFO,userId," Started calculateSeqNumber() ");

		String cheWorkingLocation = getCHECurrentWorkingLocation(equipmentId,userId);
		cheWorkingStackNumber = (cheWorkingLocation!=null) ? getStackNumberFromLocation(cheWorkingLocation) : 0;

		LOGGER.logMsg(LOG_LEVEL.TRACE,userId,new StringBuilder(" che current working location from cache is").append(cheWorkingLocation).
				append(" Working Stack Number Is::").append(cheWorkingStackNumber).toString());
		LOGGER.logMsg(LOG_LEVEL.INFO,userId,"Calling retriveExistedITVArrivedRecord() From getCHEJobListFromDatabase()");

		iTVWaitingList = ITVWaitingTimeCalculatorService.retrieveArrivedITVSRecords(null,null,null,"N");

		LOGGER.logMsg(LOG_LEVEL.TRACE, userId, new StringBuilder(" Waiting ITVS List::").append(iTVWaitingList).toString());
		LOGGER.logMsg(LOG_LEVEL.INFO,userId,new StringBuilder().append("No Of ITV's Waiting At Yard Location::").
				append(iTVWaitingList!=null && !iTVWaitingList.isEmpty() ? iTVWaitingList.size() : 0).toString());

		for(JobListContainer cheCurrentJob : cheJobsList){
			try {
				setSeqNumberToCheJob(cheCurrentJob,userId);
			}catch(Exception ex) {
				LOGGER.logException(" Exception Occurred While Calculating The Weightage Factor Reason-", ex);
			}
		}
	}
	
	/*
	 * Method is responsible for calculate the sequence number for the current job.
	 */
	private void setSeqNumberToCheJob(JobListContainer cheJobListContainer,final String userId) {

		final String containerId       = cheJobListContainer.getContainerId();
		final String moveType 		   = cheJobListContainer.getMoveType();

		double finalSeqValue		   					 = 0.0;
		double moveKindWeightageFactorScore 			 = 0.0;
		double containerAttributesWeightageFactorScore   = 0.0;
		double vesselAttributesWeightageFactorScore      = 0.0;
		double cheStackChangeWeightageScore              = 0.0;
		double itvWaitingTime                            = 0.0;

		LOGGER.logMsg(LOG_LEVEL.TRACE, containerId," ============== Weightage Score Calculation Started  ================");

		try {

			final String vesselLocation     	 =  moveType.equalsIgnoreCase(LOAD) ? cheJobListContainer.getToLocation() : 
					(moveType.equalsIgnoreCase(DSCH) ? cheJobListContainer.getFromLocation() :null);

			final Container container     		 =  RDTCacheManager.getInstance().getContainerDetails(containerId, moveType);
			WeightageCriteria moveKindCriteria 	 =  getEnumFromString(WeightageCriteria.class,moveType);

			moveKindWeightageFactorScore 			 	 =  cheJobSequnceCalculatorObj.getMoveKindComputedValue(moveKindCriteria);
			containerAttributesWeightageFactorScore  	 =  getContainerAttributesWeightageScore(container);
			vesselAttributesWeightageFactorScore     	 =  getVesselRelatedWeightageScore(cheJobListContainer.getRotationId(), vesselLocation);
			cheStackChangeWeightageScore                 =  getCHEStackChangeWeightageScore(cheJobListContainer);
			CheWeightageFactorEntity itvWeightageEntity  =  RDTCacheManager.getInstance().getCheWeightageDetailsFromCache(
							WeightageType.ITV_WAITING_TIME, WeightageCriteria.CHE);

			itvWaitingTime = (iTVWaitingList!=null && !iTVWaitingList.isEmpty() && itvWeightageEntity!=null && itvWeightageEntity.getWeightageFactor() !=0 ) ? 
					getITVWaitingTime(cheJobListContainer,userId,itvWeightageEntity): 0.0;

		}catch(Exception ex) {
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append("While Calculating Weightage Factor() ")
					.append(REASON).toString(), ex);
		}

		finalSeqValue = moveKindWeightageFactorScore + containerAttributesWeightageFactorScore + 
				vesselAttributesWeightageFactorScore +cheStackChangeWeightageScore + itvWaitingTime;

		LOGGER.logMsg(LOG_LEVEL.TRACE, containerId.concat("-").concat(moveType),new StringBuilder(" MoveKind WeightageFactorScore  :").
				append(moveKindWeightageFactorScore).append(" ContainerAttributes WeightageFactorScore :").append(containerAttributesWeightageFactorScore)
				.append(" vesselAttributes WeightageFactorScore  :").append(vesselAttributesWeightageFactorScore).append(" cheStackChange WeightageScore :").
				append(cheStackChangeWeightageScore).append(" ITVWaitingTime WeightageFactorScore  :").append(itvWaitingTime).toString());

		LOGGER.logMsg(LOG_LEVEL.TRACE,containerId,new StringBuilder(" Final Seq Value Is:::").append(finalSeqValue).toString());

		cheJobListContainer.setSeqNumber(finalSeqValue);
		LOGGER.logMsg(LOG_LEVEL.TRACE, containerId," ============== Weightage Score Calculation Completed  ================");
	}

	private double getContainerAttributesWeightageScore(final Container container){

		double containerSizeValue 	= 0.0;
		double containerStatusValue = 0.0;
		double containerTypeValue   = 0.0;
		double finalCount = 0;

		try{
			if(container!=null){
				String size = container.getSize();
				WeightageCriteria sizeCriteria = size!=null ? size.startsWith("20") ? WeightageCriteria.TWENTY 
						: (size.startsWith("4") ? WeightageCriteria.FOURTY : null) : null;

				containerSizeValue = sizeCriteria!=null ? cheJobSequnceCalculatorObj.getContainerSizeComputedValue(sizeCriteria) : 0;
				WeightageCriteria statusCriteria = container.getIsEmpty() ? WeightageCriteria.EMPTY : WeightageCriteria.FULL;
				containerStatusValue = cheJobSequnceCalculatorObj.getContaierStatusComputedValue(statusCriteria);
				containerTypeValue = cheJobSequnceCalculatorObj.getContainerTypeComputedValue(getContainerTypeWeightageCriteria(container));
			} 
		}catch(Exception ex){
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append("While Calculating getContainerAttributesWeightageScore() ")
					.append(REASON).toString(), ex);
		}

		finalCount = containerSizeValue + containerStatusValue + containerTypeValue;
		return finalCount; 
	}

	private double getVesselRelatedWeightageScore(final String rotationId,final String location){

		double vesselTypeValue = 0;
		double vesselLocationValue = 0;
		double finalCount = 0.0;
		WeightageCriteria vesselTypeWeightageCriteria = null;
		Vessel vessel = null;
		String vesselCode = null;

		final RDTVesselProfileCacheManager rdtVesselCache = RDTVesselProfileCacheManager.getInstance();
		try{

			if(rotationId!=null) {
				vesselCode  = rdtVesselCache.getVesselCode(rotationId);
				vessel      = vesselCode!=null ? rdtVesselCache.getVesselFromBerthedList(vesselCode) : null;

				vesselTypeWeightageCriteria = vessel!=null ? 
						vessel.getMotherFeeder() =='M' ? WeightageCriteria.MOTHER : WeightageCriteria.FEEDER : null;

				vesselTypeValue 	= (vesselTypeWeightageCriteria!=null) ? 
						cheJobSequnceCalculatorObj.getVesselTypeComuptedValue(vesselTypeWeightageCriteria): 0;
			}

			if(location!=null && vesselCode!=null){
				WeightageCriteria locationCrieria = null;
				String bayNumber = location.split("\\.")[0];
				String tierNum = location.split("\\.")[2]!=null ? location.split("\\.")[2] : null;

				if(bayNumber!=null && tierNum!=null) {
					String deckIndicator = EventUtil.getInstance().findDeckType(tierNum,vesselCode,bayNumber);

					locationCrieria = deckIndicator!=null ? "D".equalsIgnoreCase(deckIndicator)? 
							WeightageCriteria.DECK : WeightageCriteria.UNDER_DECK : null ; 
				}

				vesselLocationValue	= locationCrieria!=null ? cheJobSequnceCalculatorObj.getVesselLocationComputedValue(locationCrieria) : 0;
			}
		}catch(Exception ex){
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Calculating getVesselRelatedWeightageScore() ")
					.append(REASON).toString(), ex);
		}

		LOGGER.logMsg(LOG_LEVEL.TRACE,"",new StringBuilder(" Vessel Type Weightage Factor Value").append(vesselTypeValue).
				append(" Vessel Location Weightage Factor Value:").append(vesselLocationValue).toString());

		finalCount = vesselTypeValue + vesselLocationValue;
		return finalCount;
	}

	private double getCHEStackChangeWeightageScore(JobListContainer currentCHEJob){
		try {

			String currentJobLocation = (currentCHEJob!=null) ? JobListUtil.getCHEJobYardLocationBasedOnMoveType(currentCHEJob) : null ;

			LOGGER.logMsg(LOG_LEVEL.TRACE,currentCHEJob.getContainerId(),new StringBuilder(" Curent che job").
					append(currentCHEJob).append(" Yard Location Is:").append(currentJobLocation).toString());
			
			return (currentJobLocation!=null && !currentJobLocation.isEmpty()) ? 
					calculateStackChangeWeightageScore(cheWorkingStackNumber,currentJobLocation) : 0.0;

		}catch (Exception ex) {
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
		}
		return 0;
	}

	private double calculateStackChangeWeightageScore(int cheWorkingStackNum , final String currentJobLocation) {

		double stackChangeWeightageFactorScore =0.0;
		int currentJobStackNumber = getStackNumberFromLocation(currentJobLocation);
		int stackDifference = Math.abs(currentJobStackNumber - cheWorkingStackNum);

		CheWeightageFactorEntity entity = RDTCacheManager.getInstance().
				getCheWeightageDetailsFromCache(WeightageType.CHE_LOCATION_CHANGE,WeightageCriteria.STACK_CHANGE);

		stackChangeWeightageFactorScore = entity!=null  ? entity.getWeightageFactor() * stackDifference : stackChangeWeightageFactorScore;

		LOGGER.logMsg(LOG_LEVEL.TRACE,currentJobLocation,new StringBuilder("Stack Change Weightage Factor")
			.append(stackChangeWeightageFactorScore).toString());

		return stackChangeWeightageFactorScore;
	}

	private String getCHECurrentWorkingLocation(final String equipmentId , final String userId){

		String cheCurrentWorkingPosition = null;
		try{

			String cntrAndMoveType  = RDTCacheManager.getInstance().getSelectedJob(equipmentId);
			LOGGER.logMsg(LOG_LEVEL.TRACE,userId,new StringBuilder(" Started getCHECurrentWorkingLocation()")
			.append("Current Selected Container::").append(cntrAndMoveType).toString());

			if(cntrAndMoveType!=null) {
				ListOrderedMap<String, JobListContainer> jobListFromCache = RDTCacheManager.getInstance().getJobList(userId,equipmentId);
				JobListContainer container = jobListFromCache!=null ? jobListFromCache.get(cntrAndMoveType) : null;
				cheCurrentWorkingPosition = container!=null ? JobListUtil.getCHEJobYardLocationBasedOnMoveType(container) : null;
			}
		}catch(Exception ex){
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
		}
		return cheCurrentWorkingPosition;
	}
	
	public <T extends Enum<T>> T getEnumFromString(Class<T> c, String string) {
		if( c != null && string != null ) {
			try {
				return Enum.valueOf(c, string.trim().toUpperCase());
			} catch(IllegalArgumentException ex) {
				LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Converting ").
						append(string).append( " To Enum ").append(REASON).toString(),ex);
			}
		}
		return null;
	}


	public static int getStackNumberFromLocation(final String cheWorkingLocation) {

		String [] blkStkRowTier = cheWorkingLocation!=null ? 
				BlockProfileUtil.getInstance().blkStackRowTierSplitter(cheWorkingLocation.split("\\.")[0],cheWorkingLocation) : null;
		try {
			return  (blkStkRowTier!=null  && blkStkRowTier[1]!=null && !blkStkRowTier[1].isEmpty()) 
					? Integer.parseInt(blkStkRowTier[1]) : 0  ;
		}catch(NumberFormatException ne) {
			LOGGER.logException(" Exception Occured While Seperating Statck Number From Location - ",ne);
			return 0;
		}
	}

	private  double getITVWaitingTime(JobListContainer currentCHEJob , final String userId,CheWeightageFactorEntity weightageEntity){

		double itvWaitingTime = 0.0;

		try{
			for(ITVWaitingTimeEntity waitingITV : iTVWaitingList){

				if(waitingITV.getprimaryKey().getContainerId() .equalsIgnoreCase(currentCHEJob.getContainerId())){
					LOGGER.logMsg(LOG_LEVEL.INFO,userId,new StringBuilder(" Current Waiting ITV Entity::").
							append(waitingITV.toString()).toString());

					long itvWaitingTimeInMins = CHEJobListUtil.getInstance().getTimeDiff(waitingITV.getArrivalTime(),TimeType.MINIUTES);
					double itvWaitingTimeWeightageScore  = weightageEntity.getWeightageFactor() * itvWaitingTimeInMins;

					LOGGER.logMsg(LOG_LEVEL.INFO,userId,new StringBuffer("Current Itv::").append(waitingITV.getprimaryKey().getITVNo())
							.append("Waiting Time In Mins Is::").append(itvWaitingTimeInMins).append("Weightage Factor Is:::")
							.append(itvWaitingTimeWeightageScore).toString());

					return  itvWaitingTimeWeightageScore; 
				}
			}
		}catch(Exception ex){
			LOGGER.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Calculating ").
					append( " ITV Waiting Time ").append(REASON).toString(),ex);
		}
		return itvWaitingTime;
	}


	/**
	 * Method is used to retrieve CHE JobList from database.
	 * @param equipmentId
	 * @param completedJobsRetrievalTime 
	 * @param updateRequiredContinersList :  if it is null means caller is requested for Plain JobList , 
	 * Not null means called expecting update required list details
	 * @return cheJoblist available jobs in database with reference container details.
	 */

	public List<JobListContainer>  getCHEJobList(final String equipmentId,final int completedJobsRetrievalTime,List<String> updateRequiredContinersList){

		LOGGER.logMsg(LOG_LEVEL.TRACE, equipmentId, " Started getCHEJobList() To Get Records From MP_CHE_JOB_LIST table"
				+ "along with Update Required Container List"); 

		List<JobListContainer> cheJobsList = new ArrayList<JobListContainer>();
		try {

			List<Object[]> cheJobListData = CHEJobListDAO.getInstance().getCHEJobListFromDatabase(equipmentId, completedJobsRetrievalTime);

			if(cheJobListData==null || cheJobListData.isEmpty()){
				return cheJobsList;
			}

			int seq = 0;
			if(updateRequiredContinersList == null) {
				for(Object[] object : cheJobListData){
					JobListContainer cheJob = prepareJobListContainer(object, seq++);
					cheJobsList.add(cheJob);
				}
			} else {
				for(Object[] object : cheJobListData){

					JobListContainer cheJob = prepareJobListContainer(object, seq++);
					String containerId = cheJob.getContainerId();

					if(isCurrentCntrRequiredUpdate(containerId, cheJob.getMoveType())){
						updateRequiredContinersList.add(containerId);
					}

					cheJobsList.add(cheJob);
				}

				LOGGER.logMsg(LOG_LEVEL.INFO,equipmentId,new StringBuilder("Current Equipment Containers Update Required Size Is::").
						append(updateRequiredContinersList!=null ? updateRequiredContinersList.size() : 0).append(" Data :")
						.append(updateRequiredContinersList).toString());
			}

			LOGGER.logMsg(LOG_LEVEL.TRACE,equipmentId,new StringBuilder("Current Equipment JobList Is").append(cheJobsList).toString());	

		}catch(Exception ex){
			LOGGER.logException("Exception Occured While Retrieving CHE JobList From DB Reason::", ex);
		}
		return cheJobsList;
	}

	private JobListContainer prepareJobListContainer(Object[] object, int seqNo) {
		JobListContainer cheJobList = new JobListContainer();
		cheJobList.setMoveType(object[0] != null ? object[0].toString() : null);
		cheJobList.setContainerId(object[1] != null ? object[1].toString() : null);
		cheJobList.setFromLocation(object[2] != null ? object[2].toString() : "");
		cheJobList.setToLocation(object[3] != null ? object[3].toString() : "");
		cheJobList.setEquipmentId(object[4] != null ? object[4].toString() : "");
		cheJobList.setRotationId(object[5] != null ? object[5].toString() : "");
		cheJobList.setVoyage(object[6] != null ? object[6].toString() : "");
		cheJobList.setVesselName(object[7] != null ? object[7].toString() : "");
		cheJobList.setJobKey(object[8] != null ? object[8].toString() : "");
		cheJobList.setPosition(object[9]!=null ? object[9].toString() : "");
		/*
		 * As per the latest decision - OPUS sequencing is based on the job status, priority and etw.
		 * The job list is retrieved based on this order. So inserting sequence number as iterate order
		 */
		//cheJobList.setSeqNumber(object[10]!=null ? Double.valueOf(object[10].toString()) :null);
		cheJobList.setSeqNumber(seqNo);
		cheJobList.setJobStatus(object[11]!=null ? object[11].toString() :"");
		return cheJobList;
	}

	/**
	 * Checking current Container is already available in Cache or not based on some business conditions
	 * @param containerId
	 * @return status of the Container in central cache.
	 * @throws NullPointerException
	 */
	public boolean isCurrentCntrRequiredUpdate(final String containerId, String moveType) throws NullPointerException{
		// get the container from central cache
		Container containerFromCentralCache = RDTCacheManager.getInstance().getContainerDetails(containerId, moveType);
		if(containerFromCentralCache==null || containerFromCentralCache.getIsoCode() == null ||
				containerFromCentralCache.getPod()==null || containerFromCentralCache.getWeight()==null){
			return true;
		}
		return false;
	}


	public List<ITVWaitingTimeEntity> getListOfWaitingITVS(){
		return iTVWaitingList;
	}

	private WeightageCriteria getContainerTypeWeightageCriteria(final Container container){		
		return  container.isHazardous() && container.isReefer() ? WeightageCriteria.HAZARDOUS_REEFER : 
			(container.isHazardous() ? WeightageCriteria.HAZARDOUS : (container.isOOG()?WeightageCriteria.OOG : 
				(container.isReefer() ? WeightageCriteria.REEFER : WeightageCriteria.NORMAL)));
	}
	
	@SuppressWarnings("unchecked")
	public void loadBlockDetailsToCache() {

		LOGGER.logMsg(LOG_LEVEL.INFO,""," Started loadBlockDetailsToCache()..");
		List<BlkareaYpm> blockDataList = (List<BlkareaYpm>)HibernateUtil.loadMasterData(BlkareaYpm.class, "blkId", false);

		LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("No Of Blocks Defined In Database Is::").
				append(blockDataList!=null ? blockDataList.size() : 0).toString());

		for(BlkareaYpm blockObj : blockDataList) {
			RDTYardProfileCacheManager.getInstance().setBlockObject(blockObj);
		}
	}
}
