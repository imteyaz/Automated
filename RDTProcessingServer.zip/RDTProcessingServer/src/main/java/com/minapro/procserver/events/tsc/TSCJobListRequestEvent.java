package com.minapro.procserver.events.tsc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the joblist request details for the Troubleshoot clerk
 * 
 * @author Rosemary George
 *
 */
public class TSCJobListRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -5865283820785958546L;

    /**
     * Indicates whether the request is for the initial job list request or update notification In case of initial
     * request, this will be set as RESP, and in notification cases, this will be set as NOTIF
     */
    private String requestType;

    /**
     * Indicates which TS area jobs are requested
     */
    private String tsArea;

    public String getTsArea() {
        return tsArea;
    }

    public void setTsArea(String tsArea) {
        this.tsArea = tsArea;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    @Override
    public String toString() {
        return "TSCJobListRequestEvent [requestType=" + requestType + ", tsArea=" + tsArea + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }
}
