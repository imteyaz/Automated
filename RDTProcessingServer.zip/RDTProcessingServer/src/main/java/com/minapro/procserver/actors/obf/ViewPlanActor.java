package com.minapro.procserver.actors.obf;

import static com.minapro.procserver.util.RDTProcessingServerConstants.FOREMAN_VIEW_PLAN_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.io.File;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.events.obf.ViewPlanEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * 
 * 
 * @author Prasad Tallapally
 * 
 *         Network Folder: SystemRoot/ViewName/Rotation_id.pdf OR SystemRoot/ViewName/rotation/QC_id.pdf
 * 
 *
 */
public class ViewPlanActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ViewPlanActor.class);
    private static final String DISCHARGE_BAY_VIEW_PLAN = "DISCHARGE_BAY_VIEW_PLAN";
    private static final String LOAD_BAY_VIEW_PLAN = "LOAD_BAY_VIEW_PLAN";
    private static final String CRANE_WORKING_PROGRAM_VIEW_PLAN = "CRANE_WORKING_PROGRAM_VIEW_PLAN";
    private static final String BREAK_BULK_HANDLING_VIEW_PLAN = "BREAK_BULK_HANDLING_VIEW_PLAN";
    private static final String LOAD_COLOR_PROFILE_VIEW_PLAN = "LOAD_COLOR_PROFILE_VIEW_PLAN";
    private static final String DISCHARGE_COLOR_PROFILE_VIEW_PLAN = "DISCHARGE_COLOR_PROFILE_VIEW_PLAN";

    private static final String DISCH_BAY = "DISCH_BAY";
    private static final String LOAD_BAY = "LOAD_BAY";
    private static final String CRANE_WORK = "CRANE_WORK";
    private static final String BREAK_BULK = "BREAK_BULK";
    private static final String LOAD_COLOR = "LOAD_COLOR";
    private static final String DISCH_COLOR = "DISCH_COLOR";

    private static final String FILE_TYPE = ".pdf";

    @Override
    public void onReceive(Object message) throws Exception {
        /**
         * viewName Input: DISCH_BAY LOAD_BAY CRANE_WORK BREAK_BULK LOAD_COLOR DISCH_COLOR
         */
        if (message instanceof ViewPlanEvent) {
            ViewPlanEvent viewPlanEvent = (ViewPlanEvent) message;
            StringBuilder filePath = new StringBuilder();
            StringBuilder responseToDevice = new StringBuilder();

            try {
                if (validateUserPriviliges(viewPlanEvent)) {
                    // Validating whether LoggedIn user has privilege to Access respective View Plan or not
                    StringBuilder access = new StringBuilder("Y");
                    prepareFilepath(filePath, viewPlanEvent);
                    prepareResponseToDevice(responseToDevice, filePath, access, viewPlanEvent);
                    postViewPlanToCommunicationServerQueue(responseToDevice, viewPlanEvent);
                } else {
                    StringBuilder access = new StringBuilder("N");
                    // TODO No Privileges to view plan,
                    prepareResponseToDevice(responseToDevice, filePath, access, viewPlanEvent);
                    postViewPlanToCommunicationServerQueue(responseToDevice, viewPlanEvent);
                }
            } catch (Exception exception) {
                logger.logException("Caught exception while making View Plan File Path", exception);
            }
        } else {
            unhandled(message);
        }
    }

    // TODO,implement validation
    private boolean validateUserPriviliges(ViewPlanEvent viewPlanEvent) {
        //
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(viewPlanEvent.getUserID());
        List<Object[]> accessList = HibernateUtil.getAccessPrivilegeByViewPlanAndRole(operatorRole.name(),
                viewPlanEvent.getViewName());
        if (accessList.isEmpty()) {
            return false;
        }
        return true;
    }

    // Preparing File path for accessing network view plan
    private void prepareFilepath(StringBuilder filePath, ViewPlanEvent viewPlanEvent) {
        String folderName = getFolderName(viewPlanEvent.getViewName());
        // //SystemRoot/ViewName/rotation/QC_id.pdf
        if (DISCH_BAY.equalsIgnoreCase(viewPlanEvent.getViewName())
                || LOAD_BAY.equalsIgnoreCase(viewPlanEvent.getViewName())
                || CRANE_WORK.equalsIgnoreCase(viewPlanEvent.getViewName())) {
            filePath.append(folderName).append(File.separator).append(viewPlanEvent.getRotationId())
                    .append(File.separator).append(viewPlanEvent.getEquipmentID()).append(FILE_TYPE);
        } else if (BREAK_BULK.equalsIgnoreCase(viewPlanEvent.getViewName())
                || LOAD_COLOR.equalsIgnoreCase(viewPlanEvent.getViewName())
                || DISCH_COLOR.equalsIgnoreCase(viewPlanEvent.getViewName())) {
            // SystemRoot/ViewName/Rotation_id.pdf
            filePath.append(folderName).append(File.separator).append(viewPlanEvent.getRotationId()).append(FILE_TYPE);
        }
    }

    /**
     * Based on the viewPlan selected by the user, the folderName is determined.
     * 
     * @param name
     * @return
     */
    private String getFolderName(String name) {
        String folderName = null;

        switch (name) {

        case DISCH_BAY:
            folderName = DeviceCommParameters.getInstance().getCommParameter(DISCHARGE_BAY_VIEW_PLAN);
            break;
        case LOAD_BAY:
            folderName = DeviceCommParameters.getInstance().getCommParameter(LOAD_BAY_VIEW_PLAN);
            break;
        case CRANE_WORK:
            folderName = DeviceCommParameters.getInstance().getCommParameter(CRANE_WORKING_PROGRAM_VIEW_PLAN);
            break;
        case BREAK_BULK:
            folderName = DeviceCommParameters.getInstance().getCommParameter(BREAK_BULK_HANDLING_VIEW_PLAN);
            break;
        case LOAD_COLOR:
            folderName = DeviceCommParameters.getInstance().getCommParameter(LOAD_COLOR_PROFILE_VIEW_PLAN);
            break;
        case DISCH_COLOR:
            folderName = DeviceCommParameters.getInstance().getCommParameter(DISCHARGE_COLOR_PROFILE_VIEW_PLAN);
            break;
        default:
            folderName = "";
        }

        return folderName;
    }

    // Posting viewPlan File path to Communication Server Queue
    private void postViewPlanToCommunicationServerQueue(StringBuilder responseToDevice, ViewPlanEvent viewPlanEvent) {
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(viewPlanEvent.getUserID());
        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                viewPlanEvent.getTerminalID());
    }

    // Preparing view plan message
    private void prepareResponseToDevice(StringBuilder responseToDevice, StringBuilder filePath, StringBuilder access,
            ViewPlanEvent viewPlanEvent) {
        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
        responseToDevice.append(RESP).append(valueSeperator).append(FOREMAN_VIEW_PLAN_RESPONSE).append(valueSeperator)
                .append(viewPlanEvent.getEventID()).append(valueSeperator).append(access).append(valueSeperator)
                .append(filePath).append(valueSeperator).append(viewPlanEvent.getUserID()).append(valueSeperator)
                .append(viewPlanEvent.getTerminalID());
    }

}
