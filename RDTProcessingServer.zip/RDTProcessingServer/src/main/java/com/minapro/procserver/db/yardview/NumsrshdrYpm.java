package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * NumsrshdrYpm entity.
 * 
 * @author CMC.UMAMAHESH
 */
@Entity
@Table(name = "MP_NUMSRSHDR_YPM")
public class NumsrshdrYpm implements java.io.Serializable {

    private static final long serialVersionUID = 7542648354717942288L;
    @Id
    @Column(name = "NUMSRS_ID")
    private String numsrsId;

    @Column(name = "NUMSRS_TYPE")
    private String numsrsType;

    public String getNumsrsId() {
        return this.numsrsId;
    }

    public void setNumsrsId(String numsrsId) {
        this.numsrsId = numsrsId;
    }

    public String getNumsrsType() {
        return this.numsrsType;
    }

    public void setNumsrsType(String numsrsType) {
        this.numsrsType = numsrsType;
    }
}