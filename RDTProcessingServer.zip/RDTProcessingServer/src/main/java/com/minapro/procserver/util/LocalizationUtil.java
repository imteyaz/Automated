package com.minapro.procserver.util;

import java.util.Locale;
import java.util.ResourceBundle;

import com.minapro.util.logging.MinaProApplicationLogger;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESOURCE_BUNDLE_FILE;

/**
 * Common utility class for all operations related to language specific messages.
 * @author 1201257
 *
 */
public class LocalizationUtil {
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(
			LocalizationUtil.class);
	
	
	private LocalizationUtil(){
		
	}

	/**
	 * Gets values from the specified POJO using reflection
	 * @param language
	 * @param messageKey
	 * @return
	 */
	public static String getMessage(String language, String messageKey) {
		String message = null;
		try {
			Locale.setDefault(new Locale("en"));
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle(RESOURCE_BUNDLE_FILE, locale);
			message = bundle.getString(messageKey);
		} catch (Exception ex) {
			logger.logException(
					"Caught exception while getting the localaized message for key "
							+ messageKey, ex);
		}

		return message;
	}

}
