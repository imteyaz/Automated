package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MP_CHECKLIST_HEADER_MASTER")
public class CheckListHeader extends Audit implements Serializable {

    private static final long serialVersionUID = 7476531509587179124L;

    @Id
    @Column(name = "CHECKLIST_HDR_ID")
    private Integer checkListHeaderId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "TYPE")
    private String type;

    /**
     * User roles associated with this check list item
     */
    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "checkListHeaderSet")
    private Set<UserRole> userRoles = new HashSet<UserRole>();

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "checkListHeader")
    private Set<CheckList> checkList = new HashSet<CheckList>();

    public Set<CheckList> getCheckList() {
        return checkList;
    }

    public void setCheckList(Set<CheckList> checkList) {
        this.checkList = checkList;
    }

    public Set<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(Set<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }

    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
