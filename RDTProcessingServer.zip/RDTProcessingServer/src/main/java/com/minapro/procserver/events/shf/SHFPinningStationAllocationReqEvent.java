package com.minapro.procserver.events.shf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Method responsible for holding SHF logged in user details
 * 
 * @author UMAMAHESH M
 *
 */
public class SHFPinningStationAllocationReqEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2535202875327567457L;

    @Override
    public String toString() {
        return "SHFPinningStationAllocationReqEvent [UserID=" + getUserID() + ",EquipmentID=" + getEquipmentID() + "]";
    }
}
