package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.INVENTORY_UPDTE_STATUS_RESPONSE;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * @author 1201257
 *
 */
public class InventoryUpdateRequestActor extends UntypedActor {
    
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(InventoryUpdateRequestActor.class);

	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
    @Override
    public void onReceive(Object message) throws Exception {
        // TODO Auto-generated method stub
        if (message instanceof InventoryUpdateRequestEvent) {
            sendInventoryUpdateDetaisToESB((InventoryUpdateRequestEvent) message);
        } else if(message instanceof InventoryUpdateResponseEvent){
        	sendInventoryUpdateStatusToUI((InventoryUpdateResponseEvent)message);
        } else {
        	unhandled(message);
        }

    }
    private void sendInventoryUpdateDetaisToESB(InventoryUpdateRequestEvent inventoryUpdateRequestEvent) {
        ESBQueueManager.getInstance().postMessage(inventoryUpdateRequestEvent, OPERATOR.CHE,
                inventoryUpdateRequestEvent.getTerminalID());

    }

    private void sendInventoryUpdateStatusToUI(InventoryUpdateResponseEvent message){


		try {

			logger.logMsg(LOG_LEVEL.INFO, message.getUserID(), new StringBuilder(ENTRY).append(" sendInventoryUpdateStatusToUI()")
					.toString());

			// get the message format
			List<String> msgFields = EventFormats.getInstance().getEventFields(INVENTORY_UPDTE_STATUS_RESPONSE);

			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(
					DeviceEventTypes.getInstance().getEventType(INVENTORY_UPDTE_STATUS_RESPONSE));

			final int noOfMsgFields = msgFields.size();

			for (int i = 1; i < noOfMsgFields; i++) {
				responseToDevice.append(VALUE_SEPERATOR);
				EventUtil.getInstance().getEventParameter(message, msgFields.get(i), responseToDevice);
			}

			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
					RDTCacheManager.getInstance().getUserLoggedInRole(message.getUserID()), message.getTerminalID());

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("in sendInventoryUpdateStatusToUI()").append(REASON)
					.toString(), ex);
		}
	
    }
}
