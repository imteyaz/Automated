package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.YARD_INVENTORY_UPDATE_POLL_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.YARD_INVENTORY_UPDATE_SLEEP_TIME;

import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.Unit;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class YardInventoryUpdatePollingActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(YardInventoryUpdatePollingActor.class);

	public static final long DEFAULT_BLOCK_REQUEST_WAIT_TIME = 500;

	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.TERMINAL_KEY);

	/*
	 * Parameter is used to distinguish the difference between which data source ESB needs to connect.
	 * isItFirstTimePolling =true means , it is a first time request posting to ESB, in this case ESB has to connect
	 * Promis Database. False means , second request on words ESB has to connect OPUS database.
	 */
	private static boolean isItFirstTimePolling = true;

	@Override
	public void onReceive(Object message) throws Exception {
		logger.logMsg(LOG_LEVEL.INFO, "", " Started YardInventoryUpdatePollingActor OnReceive()");
		sendYardInventoryUpdateRequestToESB();
	}

	/**
	 * Step 1 : Retrieve Blocks Information From Cache.Iterate the blocks. Step 2 : Request ESB to get block details and
	 * Update Cache with latest Inventory. Step 3 : Sleep current Thread for defined time
	 */
	private void sendYardInventoryUpdateRequestToESB() {

		Set<String> listOfBlockIds = RDTYardProfileCacheManager.getInstance().getBlockIdsAvailableInATOM();
		logger.logMsg(LOG_LEVEL.INFO, "", " List Of Available Blocks From ATOM Is::" + listOfBlockIds);

		if (listOfBlockIds != null && !listOfBlockIds.isEmpty()) {

			double pollTimeInMiniutes = getPollTimeInMiniutes();
			pollTimeInMiniutes = pollTimeInMiniutes == 0 ? pollTimeInMiniutes : (pollTimeInMiniutes / 24 / 60);

			double blockSleepTimeInMins = calculatQueryExecutionTimeInMins();
			blockSleepTimeInMins = blockSleepTimeInMins == 0 ? blockSleepTimeInMins : (blockSleepTimeInMins / 24 / 60);

			double finalInterval = pollTimeInMiniutes + blockSleepTimeInMins;
			
			if (blockSleepTimeInMins > 0 || isItFirstTimePolling) {
				
				for (String blockId : listOfBlockIds) {

					if (blockId == null || blockId.isEmpty()) {
						continue;
					}

					finalInterval = finalInterval + (DEFAULT_BLOCK_REQUEST_WAIT_TIME / 1000 / 60 / 24 / 60);
					sendBlockViewReqToESB(blockId, finalInterval);

					try {
						Thread.sleep(DEFAULT_BLOCK_REQUEST_WAIT_TIME);
					} catch (InterruptedException e) {
						logger.logException("Exception Occured While Applying Sleep", e);
					}
				}
			} else {
				sendBlockViewReqToESB(null, finalInterval);
			}

			isItFirstTimePolling = false;
		}
	}

	public void sendBlockViewReqToESB(String blockId, double timeLapse) {
		BlockViewRequestEvent blockViewReqEvnt = new BlockViewRequestEvent();
		blockViewReqEvnt.setBlockNumber(blockId);
		blockViewReqEvnt.setTerminalID(TERMINAL_ID);
		blockViewReqEvnt.setEventID(UUID.randomUUID().toString());
		blockViewReqEvnt.setPollingTimeReq(isItFirstTimePolling ? false : true);
		blockViewReqEvnt.setTimeLapse(timeLapse);

		ESBQueueManager.getInstance().postMessage(blockViewReqEvnt, OPERATOR.CHE_COMMON, TERMINAL_ID);
	}

	public double getPollTimeInMiniutes() {
		ApplicationParameter yardInvtPollTimeParam = RDTPLCCacheManager.getInstance().getApplicationParamter(
				YARD_INVENTORY_UPDATE_POLL_TIME);
		long definedPollTimeInMiniutes = 0;

		if (yardInvtPollTimeParam != null) {
			if (yardInvtPollTimeParam.getParameterValue() == "0") {
				return definedPollTimeInMiniutes;
			}
			definedPollTimeInMiniutes = getTimeInMiniutes(yardInvtPollTimeParam.getUnit(),
					yardInvtPollTimeParam.getParameterValue());
		}
		return definedPollTimeInMiniutes;
	}

	public double calculatQueryExecutionTimeInMins() {
		ApplicationParameter yardInvntrSleepTimeAppParam = RDTPLCCacheManager.getInstance().getApplicationParamter(
				YARD_INVENTORY_UPDATE_SLEEP_TIME);

		double definedQueryExecutionTimeInMins = 0;

		if (yardInvntrSleepTimeAppParam != null) {
			if (yardInvntrSleepTimeAppParam.getParameterValue() == "0") {
				return definedQueryExecutionTimeInMins;
			}
			definedQueryExecutionTimeInMins = getTimeInMiniutes(yardInvntrSleepTimeAppParam.getUnit(),
					yardInvntrSleepTimeAppParam.getParameterValue());
		}
		return definedQueryExecutionTimeInMins;
	}

	public int getTimeInMiniutes(Unit unit, String value) {
		String unitName = unit.getUnitName();
		int definedTime = Integer.parseInt(value);

		if ("minutes".equalsIgnoreCase(unitName) || unitName.startsWith("Minute")) {
			return definedTime;
		} else if ("hours".equalsIgnoreCase(unitName) || unitName.startsWith("Hour")) {
			return definedTime * 60;
		} else {
			return definedTime / 60;
		}
	}
}
