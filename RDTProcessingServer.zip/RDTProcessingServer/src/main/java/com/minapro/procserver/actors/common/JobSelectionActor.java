package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CANCEL_JOB_SELECTION_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.JOB_SELECTION_NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.JOB_SELECTION_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REFERENCE_CONTAINER_SEPERATOR;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.CancelJobSelectionResponseEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.JobSelectionResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the job selection and cancel job selection process Job selection is possible from two
 * operators - HC and CHE.
 * 
 * In case of HC, only job selection is available. The complete flow is handled at RDT. If the user marks a container as
 * selected, * the same is notified to the associated QC. If HC user needs to remove the selection, user will select
 * another container as selected. Cancel Job selection is not applicable to HC user.
 * 
 * In case of CHE, the job selection request is passed over to ESB for further processing. Based on the response from
 * ESB, the status is communicated back to the user. If the CHE user wants to select another job as selected, user needs
 * to first cancel the first job selection.
 * 
 * @author Rosemary George
 *
 */
public class JobSelectionActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(JobSelectionActor.class);

	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);

	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.ROW_SEPERATOR_KEY);

	@Override
	public void onReceive(Object message) throws Exception {

		if (message instanceof JobSelectionEvent) {

			JobSelectionEvent jobSelection = (JobSelectionEvent) message;

			logger.logMsg(LOG_LEVEL.WARN, jobSelection.getUserID(), "Received Job selection message -" + jobSelection);

			String location = getSelectedJobLocation(jobSelection);

			if(location!=null) {
				logger.logMsg(LOG_LEVEL.INFO,jobSelection.getUserID()," Location Is Able To Retrieve From JobList Cache , Current Location Is::"+location);
				jobSelection.setLocation(location);
			}

			handleJobSelectionRequest(jobSelection);

		} else if (message instanceof JobSelectionResponseEvent) {
			JobSelectionResponseEvent jobSelectionResp = (JobSelectionResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, jobSelectionResp.getUserID(), "Received Job selection response event :"
					+ jobSelectionResp);
			handleJobSelectionResponse(jobSelectionResp);

		} else if (message instanceof CancelJobSelectionEvent) {
			CancelJobSelectionEvent cancelJobSelectionRequest = (CancelJobSelectionEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, cancelJobSelectionRequest.getUserID(),
					"Received cancel Job Selection request event :" + cancelJobSelectionRequest);
			String jobKey = JobListUtil.getInstnace().getJobKeyForJobListCntr(cancelJobSelectionRequest.getContainerId(),cancelJobSelectionRequest.getMoveType(),
					cancelJobSelectionRequest.getUserID(),cancelJobSelectionRequest.getEquipmentID());
			cancelJobSelectionRequest.setJobKey(jobKey);
			handleCancelJobSelectionRequest(cancelJobSelectionRequest);
			
		} else if (message instanceof CancelJobSelectionResponseEvent) {
			CancelJobSelectionResponseEvent cancelJobSelectionResp = (CancelJobSelectionResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, cancelJobSelectionResp.getUserID(),
					"Received cancel job selection response event :" + cancelJobSelectionResp);
			
			handleCancelJobSelectionResponse(cancelJobSelectionResp);
			
		}else{
			unhandled(message);
		}
	}

	/**
	 * Handles the cancel job selection response from ESB.
	 * 
	 * @param cancelJobSelectionResp
	 */
	private void handleCancelJobSelectionResponse(CancelJobSelectionResponseEvent cancelJobSelectionResp) {

		logger.logMsg(LOG_LEVEL.DEBUG, cancelJobSelectionResp.getUserID(), "Received the response with status as "
				+ cancelJobSelectionResp.isSuccess());

		if (cancelJobSelectionResp.isSuccess()) {
			logger.logMsg(LOG_LEVEL.DEBUG, cancelJobSelectionResp.getUserID(), "Removing job selection equipment->"
					+ cancelJobSelectionResp.getEquipmentID());
			RDTCacheManager.getInstance().removeJobSelection(cancelJobSelectionResp.getEquipmentID());
		}

		OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(cancelJobSelectionResp.getUserID());
		sendResponseToUI(CANCEL_JOB_SELECTION_RESPONSE, cancelJobSelectionResp, cancelJobSelectionResp.isSuccess(),
				cancelJobSelectionResp.getErrorMessage(), role);
	}

	/**
	 * Handles the cancel job selection request from UI
	 * 
	 * @param cancelJobSelectionRequest
	 */
	private void handleCancelJobSelectionRequest(CancelJobSelectionEvent cancelJobSelectionRequest) {

		OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(cancelJobSelectionRequest.getUserID());
		logger.logMsg(LOG_LEVEL.INFO, cancelJobSelectionRequest.getUserID(), "The job selection request came from "
				+ role);

		ESBQueueManager.getInstance().postMessage(cancelJobSelectionRequest, role,
				cancelJobSelectionRequest.getTerminalID());
	}

	/**
	 * Handles the job selection response message from ESB.
	 * 
	 * If the status is true, saves the specified container as selected to cache and sends success response to user.
	 * else sends the failure response to user.
	 * 
	 * @param jobSelectionResp
	 */
	private void handleJobSelectionResponse(JobSelectionResponseEvent jobSelectionResp) {

		logger.logMsg(LOG_LEVEL.DEBUG, jobSelectionResp.getUserID(), "Received the response with status as "
				+ jobSelectionResp.isSuccess());

		OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(jobSelectionResp.getUserID());
		/*
		 * In Auto Re Handle case If error message is like Re Handle Required.At that time needs to initiate the Manual CHE JobList Refresh
		 * to get the Re Handle related jobs.
		 */
		if (jobSelectionResp.isSuccess()) {

			String containerWithMoveType = jobSelectionResp.getContainerId() + jobSelectionResp.getMoveType();
			logger.logMsg(LOG_LEVEL.DEBUG, jobSelectionResp.getUserID(), "Adding job selection equipment:container->"
					+ jobSelectionResp.getEquipmentID() + containerWithMoveType);		

			if (role.equals(OPERATOR.CHE)) {
				//updateLocationAndsendMessageToUI(jobSelectionResp, containerWithMoveType, role);
				// Checking the PLC  is doing any Job.
				if (RDTPLCCacheManager.getInstance().getUserToFromLocationAndContainerDetails(jobSelectionResp.getUserID())==null){
					RDTPLCCacheManager.getInstance().addUserToFromLocationAndContainerDetails(jobSelectionResp.getUserID(),jobSelectionResp.getContainerId()+"-"+jobSelectionResp.getNewLocation());
				}else{
					if(!RDTPLCCacheManager.getInstance().getUserToFromLocationAndContainerDetails(jobSelectionResp.getUserID()).split("-")[0].equalsIgnoreCase(jobSelectionResp.getContainerId())){
					RDTPLCCacheManager.getInstance().addUserToFromLocationAndContainerDetails(jobSelectionResp.getUserID(),jobSelectionResp.getContainerId()+"-"+jobSelectionResp.getNewLocation());
				}
			}
			RDTCacheManager.getInstance().addJobSelection(jobSelectionResp.getEquipmentID(), containerWithMoveType);	
			}
		} 
		
		sendResponseToUI(JOB_SELECTION_RESPONSE, jobSelectionResp, jobSelectionResp.isSuccess(),
				jobSelectionResp.getErrorMessage(), role);
	}

	/**
	 * Handles the job selection request from user. In case of HC, saves the specified container as selected to cache
	 * and sends success response to user. Also notifies corresponding QC. In case of CHE, the message is passed to ESB
	 * for further processing.
	 * 
	 * @param jobSelection
	 */
	private void handleJobSelectionRequest(JobSelectionEvent jobSelection) {

		OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(jobSelection.getUserID());
		logger.logMsg(LOG_LEVEL.INFO, jobSelection.getUserID(), "The job selection request came from " + role);

		String containerWithMoveType = jobSelection.getContainerId() + jobSelection.getMoveType();

		if (role.equals(OPERATOR.HC)) {

			String qcId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(jobSelection.getUserID());

			logger.logMsg(LOG_LEVEL.DEBUG, jobSelection.getUserID(), "Adding job selection equipment:container->"
					+ qcId + containerWithMoveType);

			RDTCacheManager.getInstance().addJobSelection(qcId, containerWithMoveType);

			sendResponseToUI(JOB_SELECTION_RESPONSE, jobSelection, true, "", role);

			String qcUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcId);

			logger.logMsg(LOG_LEVEL.DEBUG, jobSelection.getUserID(), "HC mapped qc is " + qcId
					+ " and the user logged into the QC is " + qcUser);

			if (qcUser != null) {
				notifyCorrespondingQC(qcUser, jobSelection);
			}

		} else if (role.equals(OPERATOR.CHE)) {

			logger.logMsg(LOG_LEVEL.DEBUG, jobSelection.getUserID(), "Sending Job Selection Request Event to ESB "
					+ jobSelection.getEquipmentID() + "  " + jobSelection.getUserID());
			RDTPLCCacheManager.getInstance().addUserToContainerDetails(jobSelection.getUserID(), jobSelection.getContainerId());
			
			ESBQueueManager.getInstance().postMessage(jobSelection, role, jobSelection.getTerminalID());
			
		}
	}

	/**
	 * Send notification message to specified QC user about the job selection.
	 * 
	 * @param qcUser
	 * @param jobSelection
	 */
	private void notifyCorrespondingQC(String qcUser, JobSelectionEvent jobSelection) {

		String eventType = DeviceEventTypes.getInstance().getEventType(JOB_SELECTION_NOTIF);

		StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPERATOR).append(eventType)
				.append(VALUE_SEPERATOR).append(jobSelection.getEventID()).append(VALUE_SEPERATOR);

		responseToDevice.append(jobSelection.getContainerId()).append(VALUE_SEPERATOR)
		.append(jobSelection.getMoveType()).append(VALUE_SEPERATOR).append(qcUser).append(VALUE_SEPERATOR)
		.append(jobSelection.getTerminalID());

		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.QC,
				jobSelection.getTerminalID());
	}

	/**
	 * Sends the job selection or cancel job Selection response message to UI depending on the responseType.
	 * 
	 * @param responseEvent
	 * @param status
	 * @param errorMessage
	 * @param role
	 */
	private void sendResponseToUI(String responseType, Event responseEvent, boolean status, String errorMessage,
			OPERATOR role) {

		String eventType = DeviceEventTypes.getInstance().getEventType(responseType);

		StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventType) 
				.append(VALUE_SEPERATOR).append(responseEvent.getEventID()).append(VALUE_SEPERATOR);

		responseToDevice.append(status).append(VALUE_SEPERATOR).append(errorMessage).append(VALUE_SEPERATOR)
		.append(responseEvent.getUserID()).append(VALUE_SEPERATOR).append(responseEvent.getTerminalID());

		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
				responseEvent.getTerminalID());
	}
	
	private void updateLocationAndsendMessageToUI(JobSelectionResponseEvent jobSelectionResp,
			String containerWithMoveType, OPERATOR role) {

		try {

			// get the container details from cache.
			ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
					jobSelectionResp.getUserID(), jobSelectionResp.getEquipmentID());

			JobListContainer container = jobList
					.get(jobSelectionResp.getContainerId() + jobSelectionResp.getMoveType());

			// Check whether to Location is changed or not if it is changed then update in JobList Cache and send JoList
			// update notification to UI.
			if (container != null && !container.getToLocation().equalsIgnoreCase(jobSelectionResp.getNewLocation())) {
				// Updating the Job List Cache and sending updated job list item to UI.
				logger.logMsg(LOG_LEVEL.DEBUG, jobSelectionResp.getEquipmentID(),
						"CHE Updating selected position entry in Joblist based on Job select Response from ESB");
				container.setToLocation(jobSelectionResp.getNewLocation());
				RDTCacheManager.getInstance().updateJobList(jobSelectionResp.getUserID(), container,
						jobSelectionResp.getEquipmentID(), jobSelectionResp.getMoveType());

				// get the container message format
				List<String> containerFields = EventFormats.getInstance().getEventFields("CONTAINER");
				String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);
				StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPERATOR).append(eventTypeID)
						.append(jobSelectionResp.getEventID().toString()).append(VALUE_SEPERATOR);

				String priorityColourCode;
				Integer priority = 0;
				String colourCode;
				Set<Vessel> berthedVessels = RDTVesselProfileCacheManager.getInstance().getBerthedVesselList();
				// get the job list message format
				List<String> msgFields = EventFormats.getInstance().getEventFields(
						RDTProcessingServerConstants.JOB_LIST);
				Container containerDetails = RDTCacheManager.getInstance().getContainerDetails(
						jobSelectionResp.getContainerId(), jobSelectionResp.getMoveType());
				String explosiveCodes = EventUtil.getInstance().getExplosiveCodes();

				// iterate through the jobList message formats				
				for (int i = 1; i < msgFields.size(); i++) {
					responseToDevice.append(VALUE_SEPERATOR);

					// For each container, iterate through the Container message format
					for (int conCounter = 0; conCounter < containerFields.size(); conCounter++) {

						if ("Remarks".equalsIgnoreCase(containerFields.get(conCounter))) {
							if (containerDetails != null) {
								responseToDevice.append(EventUtil.getInstance().getContainerIcon(containerDetails));
							} else {
								responseToDevice.append("");
							}
						} else if ("ColourCode".equalsIgnoreCase(containerFields.get(conCounter))) {
							if (containerDetails != null && containerDetails.getPod() != null) {
								colourCode = RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
										containerDetails.getPod());
							} else {
								colourCode = "";
							}
							responseToDevice.append(colourCode);
						} else if ("MoveType".equalsIgnoreCase(containerFields.get(conCounter))
								|| "FromLocation".equalsIgnoreCase(containerFields.get(conCounter))
								|| "ToLocation".equalsIgnoreCase(containerFields.get(conCounter))) {
							EventUtil.getInstance().getEventParameter(container, containerFields.get(conCounter),
									responseToDevice);
						} else if ("ContainerID".equalsIgnoreCase(containerFields.get(conCounter))) {
							responseToDevice.append(container.getContainerId());
						} else if ("TwinContainerId".equalsIgnoreCase(containerFields.get(conCounter))) {
							if (container.getTandemContainerIDs() != null
									&& container.getTandemContainerIDs().length > 0) {
								for (String tandem : container.getTandemContainerIDs()) {
									responseToDevice.append(tandem).append(REFERENCE_CONTAINER_SEPERATOR);
								}
								responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
							} else {
								responseToDevice.append(container.getTwinContainerId());
							}
						} else if ("Priority".equalsIgnoreCase(containerFields.get(conCounter))) {

							priority = EventUtil.getInstance().getPriorityScore(container, berthedVessels);
							responseToDevice.append(priority);
						} else if ("PriorityColour".equalsIgnoreCase(containerFields.get(conCounter))) {

							priorityColourCode = RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
									priority.toString());
							responseToDevice.append(priorityColourCode);
						} else if ("SealStatus".equalsIgnoreCase(containerFields.get(conCounter))) {
							if (containerDetails != null) {
								responseToDevice.append(containerDetails.isSealOn() ? "Y" : "N");
							} else {
								responseToDevice.append("Y");
							}
						} else if ("HazardousCode".equalsIgnoreCase(containerFields.get(conCounter))) {
							if (containerDetails != null && containerDetails.getHazardousCode()!= null 
									&& explosiveCodes != null && !explosiveCodes.isEmpty()) {
								responseToDevice.append(EventUtil.getInstance()
										.isExplosiveContainer(explosiveCodes, containerDetails.getHazardousCode()));
							} else {
								responseToDevice.append(false);
							}
						} else {
							EventUtil.getInstance().getEventParameter(containerDetails, containerFields.get(conCounter),
									responseToDevice);
						}
						responseToDevice.append(ITEM_SEPARATOR);
					}
					responseToDevice.append(ROW_SEPARATOR);
				}

				// send message to UI
				CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
						jobSelectionResp.getTerminalID());
			}else {
				logger.logMsg(LOG_LEVEL.DEBUG, jobSelectionResp.getUserID(), "No change in the toLocation");
			}

		} catch (Exception ex) {
			logger.logException("Caught Exception while building update job list message", ex);
		}

	}

	public String getSelectedJobLocation(JobSelectionEvent event){

		final String moveType = event.getMoveType();

		ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(event.getUserID(),event.getEquipmentID());

		if(jobList!=null){

			JobListContainer jobCntr = jobList.get(event.getContainerId()+event.getMoveType());

			if(jobCntr!=null) {

				if(LOAD.equals(moveType) || GO.equals(moveType) || MO.equals(moveType) || RH.equals(moveType)){
					return jobCntr.getFromLocation();
				} else {
					return jobCntr.getToLocation();
				}
			}
		} 
		return null;

	}
	
}
