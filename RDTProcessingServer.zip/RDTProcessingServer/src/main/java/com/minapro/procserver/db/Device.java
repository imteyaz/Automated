package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the device details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_DEVICE_MASTER")
public class Device extends Audit implements Serializable {

    private static final long serialVersionUID = -6045286970751559994L;

    @Id
    @Column(name = "DEVICE_ID", nullable = false)
    private String deviceId;

    @Column(name = "DEVICE_DESCRIPTION")
    private String deviceDescription;

    @Column(name = "IPADDRESS")
    private String ipaddress;

    @Column(name = "LISTENING_PORT")
    private Integer listeningPort;

    @Column(name = "SENDING_PORT")
    private Integer sendingPort;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "EQUIPMENT_ID", referencedColumnName = "EQUIPMENT_ID")
    private Equipment equipment;

    @Column(name = "MAKE")
    private String make;

    @Column(name = "MODEL")
    private String model;

    @Column(name = "OS_VERSION")
    private String osVersion;

    @Column(name = "CURRENT_APP_VERSION")
    private String currentOsVersion;

    @Column(name = "LAST_APP_VERSION_UPDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastVersionUpdate;

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getCurrentOsVersion() {
        return currentOsVersion;
    }

    public void setCurrentOsVersion(String currentOsVersion) {
        this.currentOsVersion = currentOsVersion;
    }

    public Date getLastVersionUpdate() {
        return lastVersionUpdate;
    }

    public void setLastVersionUpdate(Date lastVersionUpdate) {
        this.lastVersionUpdate = lastVersionUpdate;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceDescription() {
        return deviceDescription;
    }

    public void setDeviceDescription(String deviceDescription) {
        this.deviceDescription = deviceDescription;
    }

    public String getIpaddress() {
        return ipaddress;
    }

    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    public Integer getListeningPort() {
        return listeningPort;
    }

    public void setListeningPort(Integer listeningPort) {
        this.listeningPort = listeningPort;
    }

    public Integer getSendingPort() {
        return sendingPort;
    }

    public void setSendingPort(Integer sendingPort) {
        this.sendingPort = sendingPort;
    }

    public Equipment getEquipment() {
        return equipment;
    }

    public void setEquipment(Equipment equipment) {
        this.equipment = equipment;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}
