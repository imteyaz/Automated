package com.minapro.procserver.events.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the Container Handling event details
 * 
 * @author Venkataramana.ch
 *
 */

public class ContainerHandleEvent extends Event implements Serializable {

    private static final long serialVersionUID = -3580453396912135990L;
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerHandleEvent.class);

    private static String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private List<String> containerIDs;
    
    private String moveType;    

    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public List<String> getContainerIDs() {
        return containerIDs;
    }

    public void setContainerIDs(String containerIDs) {
        try {
            String[] containers = containerIDs.split("\\" + rowSeparator);
            this.containerIDs = new ArrayList<String>(Arrays.asList(containers));
        } catch (Exception ex) {
            logger.logException("Caught Exception ", ex);
            this.containerIDs = new ArrayList<String>();
        }
    }

	@Override
	public String toString() {
		return "ContainerHandleEvent [containerIDs=" + containerIDs + ", moveType=" + moveType + "]";
	}
}
