package com.minapro.procserver.actors.itv;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.itv.CallITVEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the call itv request from UI.
 * Once the request is received from UI, invokes operator availability event to ESB with the 
 * code provided by UI. Also generates the CALL_ITV_ALERT
 * 
 * @author Rosemary George
 *
 */
public class CallITVActor extends UntypedActor{

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CallITVActor.class);
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof CallITVEvent){
			try{
				CallITVEvent callItvEvent = (CallITVEvent) message;
				logger.logMsg(LOG_LEVEL.DEBUG, callItvEvent.getUserID(), "Recieved Call ITV event " + callItvEvent);
				informTOS(callItvEvent);
				generateAlert(callItvEvent);
			}catch(Exception ex){
				logger.logException("Caught exception in callITV ", ex);
			}
		}		
	}
	
	/**
	 * Constructs and sends the Operator availability event with the code to ESB to pass onto the TOS.
	 * @param callItvEvent
	 */
	private void informTOS(CallITVEvent callItvEvent){
		OperatorAvailabilityEvent availabilityEvent =  new OperatorAvailabilityEvent();
    	availabilityEvent.setEquipmentID(callItvEvent.getEquipmentID());
    	availabilityEvent.setEventID(callItvEvent.getEventID());
    	availabilityEvent.setIsAvailable("A");
    	availabilityEvent.setOperatorInitiated(true);
    	availabilityEvent.setUnavailableReason(callItvEvent.getCode());
    	availabilityEvent.setUserID(callItvEvent.getUserID());
    	availabilityEvent.setUserName(callItvEvent.getUserID());
    	
    	//set call itv as true to indicate to ESB that no response is required for this request.
    	availabilityEvent.setCallItv(true);	       	
    	
    	ESBQueueManager.getInstance().postMessage(availabilityEvent, OPERATOR.ITV, "T2");
	}
	
	/**
	 * Generates the Call ITV alert event and pass it to master actor for further processing
	 * @param callItvEvent
	 */
	private void generateAlert(CallITVEvent callItvEvent){
		logger.logMsg(LOG_LEVEL.DEBUG, callItvEvent.getUserID(), "Sending CALL ITV alert for equipment :" + callItvEvent.getEquipmentID());
        MinaProAlertEvent alert = new MinaProAlertEvent();
        alert.setAlertCode(ALERTCODE.CALL_ITV_ALERT);
        alert.setUserID(callItvEvent.getUserID());
        alert.setOperatorId(callItvEvent.getUserID());
        alert.setEquipmentID(callItvEvent.getEquipmentID());
        
        getSender().tell(alert, null);
	}
}
