package com.minapro.procserver.actors;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.events.BayProfileRequestEvent;
import com.minapro.procserver.events.CompletedJobListRequestEvent;
import com.minapro.procserver.events.ContainerDamageCorrectionEvent;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerDamagesRequestEvent;
import com.minapro.procserver.events.ContainerInquiryEvent;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.DeleteManualJobRequestEvent;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.RefreshJobListRequestEvent;
import com.minapro.procserver.events.SwitchBayRequestEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerInquiryRequestEvent;
import com.minapro.procserver.events.UpdateJobRequestEvent;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.CancelShuffleRequestEvent;
import com.minapro.procserver.events.che.ConfirmShuffleRequestEvent;
import com.minapro.procserver.events.che.InventoryRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.NewLocationRequestEvent;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.che.StackViewRequestEvent;
import com.minapro.procserver.events.common.AccidentIncidentConfirmEvent;
import com.minapro.procserver.events.common.AccidentIncidentRequestEvent;
import com.minapro.procserver.events.common.CancelInspectionEvent;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.CheckListInspectionEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.DLMEvent;
import com.minapro.procserver.events.common.DelayConfirmationEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.LanguageChangeReqEvent;
import com.minapro.procserver.events.common.LanguagesGetRequestEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.ManualDelayRecordingConfirmationEvent;
import com.minapro.procserver.events.common.MovesToGoRequestEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityResponseEvent;
import com.minapro.procserver.events.common.OperatorBreakReasonsEvent;
import com.minapro.procserver.events.common.SealBrokenRequestEvent;
import com.minapro.procserver.events.common.TechSupportRequestEvent;
import com.minapro.procserver.events.common.TechSupportValuesEvent;
import com.minapro.procserver.events.hc.DamageCodeRequestEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.hc.TroubleshootAreasGetRequestEvent;
import com.minapro.procserver.events.hc.TroubleshootConfirmRequestEvent;
import com.minapro.procserver.events.itv.CallITVEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.ITVJobConfirmationEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;
import com.minapro.procserver.events.itv.PinningStationJobConfirmationEvent;
import com.minapro.procserver.events.obf.LashersRequestEvent;
import com.minapro.procserver.events.obf.VesselDocumentEvent;
import com.minapro.procserver.events.obf.VesselForemanCheckListEvent;
import com.minapro.procserver.events.obf.VfOperatoinalViewEvent;
import com.minapro.procserver.events.obf.ViewPlanEvent;
import com.minapro.procserver.events.plc.AutoDelayReconfirmEvent;
import com.minapro.procserver.events.plc.DelayRecordingByOperatorEvent;
import com.minapro.procserver.events.plc.DelayRecordingConfirmationEvent;
import com.minapro.procserver.events.plc.GeneralLiftOperationEvent;
import com.minapro.procserver.events.plc.StopPLCInstructionEvent;
import com.minapro.procserver.events.shf.QCLanesRequestEvent;
import com.minapro.procserver.events.shf.QcLanesChangeRequestEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationChangeEvent;
import com.minapro.procserver.events.shf.SHFPinningStationAllocationReqEvent;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for parsing the incoming messages from devices. </p>
 * 
 * <p> The message will be of String format where values are differentiated with a separator. </p>
 * 
 * @author Rosemary George
 * 
 */
public class EventParserActor extends UntypedActor implements RDTProcessingServerConstants {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(EventParserActor.class);

    @Override
    /**
     * Handles messages of type String
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof String) {
            String msg = message.toString();
            if (msg != null && msg.trim().isEmpty()) {
                logger.logMsg(LOG_LEVEL.ERROR, "", "Received invalid message, discarding it.");
            } else {
                getSender().tell(parseMessage(msg), null);
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * <p> Parses the incoming message from device based on the event type. </p>
     * 
     * <p> The event format is obtained from the EventFormats using the event type. Corresponding POJO object is created
     * and returned. </p>
     * 
     * @param message
     *            - String message with values differentiated with a separator
     * @return - Respective event specific POJO object
     */
    private Object parseMessage(String message) {

        Event resultMsg = null;
        try {

            String[] tokens = EventUtil.getInstance().tokenize(message);

            String eventKey = DeviceEventTypes.getInstance().getEventType(tokens[0]);

            switch (eventKey) {

            case LOGIN_REQ:
            	resultMsg = new LoginEvent();
            	break;

            case DLM_REQ:
            	resultMsg = new DLMEvent();
            	break;

            case CONFIRM_ALLOCATION:
            	resultMsg = new ConfirmAllocationEvent();
            	break;

            case ITV_ARRIVAL:
            	resultMsg = new ITVArrivalEvent();
            	break;

            case PINNING_CONFIRMATION:
            	resultMsg = new PinningStationJobConfirmationEvent();
            	break;

            case DELAY_CONFIRMATION:
            	resultMsg = new DelayConfirmationEvent();
            	break;

            case ITV_JOB_CONFIRMATION:
            	resultMsg = new ITVJobConfirmationEvent();
            	break;

            case CONTAINER_MOVE:
            	resultMsg = new ContainerMoveEvent();
            	((ContainerMoveEvent) resultMsg).setAutomaticFlag(false);
            	break;

            case INSPECTION_RECORD:
            	resultMsg = new CheckListInspectionEvent();
            	break;

            case LOGOUT:
            	resultMsg = new LogoutEvent();
            	break;

            case CANCEL_INSPECTION:
            	resultMsg = new CancelInspectionEvent();
            	break;

            case JOB_LIST_REQUEST:
            	resultMsg = new JobListRequestEvent();
            	break;

            case ITV_POOL_REQUEST:
            	resultMsg = new ITVPoolRequestEvent();
            	break;

            case DAMAGED_CONTAINER:
            	resultMsg = new ContainerDamageEvent();
            	break;

            case DELAY_RECORD_CONFIRMATION:
            	resultMsg = new DelayRecordingConfirmationEvent();
            	break;

            case UPDATE_CONTAINER_INQUIRY_REQUEST:
            	resultMsg = new UpdateContainerInquiryRequestEvent();
            	break;
            	
            case UPDATED_CONTAINER_REQUEST:
            	resultMsg = new UpdateContainerEvent();
            	break;
            	
            case BAY_VIEW_REQUEST:
            	resultMsg = new BayProfileRequestEvent();
            	break;

            case UPDATE_JOB:
            	resultMsg = new UpdateJobRequestEvent();
            	break;

            case GENERALLIFT_OPERATION:
            	resultMsg = new GeneralLiftOperationEvent();
            	break;

            case OPERATOR_BREAK_REASONS:
            	resultMsg = new OperatorBreakReasonsEvent();
            	break;

            case OPERATOR_AVAILABILITY:
            	resultMsg = new OperatorAvailabilityEvent();
            	break;

            case OPERATOR_AVAILABILITY_RESPONSE:
            	resultMsg = new OperatorAvailabilityResponseEvent();
            	break;
          
            case ORPHAN_CONTAINER_CREATION_REQUEST:
            	resultMsg = new OrphanContainerEvent();
            	break;
           
            case OUT_OF_LIST_CNTRS_GET_REQUEST:
            	resultMsg = new OutOfListContainersRequestEvent();
            	break;

            case TROUBLESHOOT_AREAS_REQUEST:
            	resultMsg = new TroubleshootAreasGetRequestEvent();
            	break;

            case FOREMAN_OPERATIONAL_VIEW_REQUEST:
            	resultMsg = new VfOperatoinalViewEvent();
            	break;

            case SHF_PINNINGSTATION_VIEW_REQ:
            	resultMsg = new SHFPinningStationAllocationReqEvent();
            	break;

            case TROUBLESHOOT_CONFIRM_REQUEST:
            	resultMsg = new TroubleshootConfirmRequestEvent();
            	break;
            case VF_CHECKLIST_REQ:
            	resultMsg = new VesselForemanCheckListEvent();
            	break;

            case FOREMAN_VIEW_PLAN_REQUEST:
            	resultMsg = new ViewPlanEvent();
            	break;

            case SHF_CHANGE_ALLOCATION_REQ:
            	resultMsg = new SHFPinningStationAllocationChangeEvent();
            	break;

            case DELAY_RECORDING_BY_OPERATOR:
            	resultMsg = new DelayRecordingByOperatorEvent();
            	break;

            case QC_LANE_VIEW_REQ:
            	resultMsg = new QCLanesRequestEvent();
            	break;

            case QC_LANE_CHANGE_ALLOCATION_REQ:
            	resultMsg = new QcLanesChangeRequestEvent();
            	break;

            case LASHERS_REQUEST:
            	resultMsg = new LashersRequestEvent();
            	break;

            case FOREMAN_VESSEL_DOCUMENT_REQUEST:
            	resultMsg = new VesselDocumentEvent();
            	break;

            case YARD_VIEW_REQUEST:
            	resultMsg = new BlockViewRequestEvent();
            	break;

            case STACK_VIEW_REQUEST:
            	resultMsg = new StackViewRequestEvent();
            	break;

            case STOP_PLC_INSTRUCTION:
            	resultMsg = new StopPLCInstructionEvent();
            	break;

            case COMPLETED_JOB_LIST_REQUEST:
            	resultMsg = new CompletedJobListRequestEvent();
            	break;

            case REFRESH_JOB_LIST_REQUEST:
            	resultMsg = new RefreshJobListRequestEvent();
            	break;

            case DELETE_MANUAL_JOB:
            	resultMsg = new DeleteManualJobRequestEvent();
            	break;

            case LANGUAGES_REQ:
            	resultMsg = new LanguagesGetRequestEvent();
            	break;

            case LANGUAGE_CHANGE_REQ:
            	resultMsg = new LanguageChangeReqEvent();
            	break;

            case DAMAGE_CODE_REQUEST:
            	resultMsg = new DamageCodeRequestEvent();
            	break;
            case TECHNICAL_SUPPORT_REQUEST:
            	resultMsg = new TechSupportRequestEvent();
            	break;
            case TECHNICAL_SUPPORT_WITH_VALUES:
            	resultMsg = new TechSupportValuesEvent();
            	break;

            case SWAP_REQ:
            	resultMsg = new SwapRequestEvent();
            	break;

            case SEAL_BROKEN_REQUEST:
            	resultMsg = new SealBrokenRequestEvent();
            	break;

            case SWITCH_BAY_REQUEST:
            	resultMsg = new SwitchBayRequestEvent();
            	break;

            case MANUAL_DELAY_REQUEST:
            	resultMsg = new ManualDelayRecordingConfirmationEvent();
            	break;

            case CONTAINER_INQUIRY_REQUEST:
            	resultMsg = new ContainerInquiryEvent();
            	break;

            case CONTAINER_DAMAGES_REQUEST:
            	resultMsg = new ContainerDamagesRequestEvent();
            	break;

            case CONTAINER_DAMAGE_CORRECTION:
            	resultMsg = new ContainerDamageCorrectionEvent();
            	break;

            case NEW_LOCATION_REQUEST:
            	resultMsg = new NewLocationRequestEvent();
            	break;

            case INVENTORY_REQUEST:
            	resultMsg = new InventoryRequestEvent();
            	break;

            case INVENTORY_UPDATE_REQUEST:
            	resultMsg = new InventoryUpdateRequestEvent();
            	break;

            case SHUFFLEJOB_REQUEST:
            	resultMsg = new ShuffleRequestEvent();
            	break;

            case CONFIRM_SHUFFLEJOB_REQUEST:
            	resultMsg = new ConfirmShuffleRequestEvent();
            	break;

            case CANCEL_SHUFFLEJOB_REQUEST:
            	resultMsg = new CancelShuffleRequestEvent();
            	break;

            case CANCEL_JOB_SELECTION_REQUEST:
            	resultMsg = new CancelJobSelectionEvent();
            	break;

            case JOB_SELECTION_REQUEST:
            	resultMsg = new JobSelectionEvent();
            	break;

            case ACCIDENT_INCIDENT_REQUEST:
            	resultMsg = new AccidentIncidentRequestEvent();
            	break;

            case ACCIDENT_INCIDENT_CONFIRM:
            	resultMsg = new AccidentIncidentConfirmEvent();
            	break;

            case MOVES_TO_GO_REQUEST:
            	resultMsg = new MovesToGoRequestEvent();
            	break;
            	
            case AUTO_DELAY_RECONFIRMATION:
            	resultMsg = new AutoDelayReconfirmEvent();
            	break;
            	
            case CALL_ITV:
            	resultMsg = new CallITVEvent();
            	break;

            default:
            	resultMsg = null;
            }

            if (resultMsg != null) {

                List<String> msgFields = EventFormats.getInstance().getEventFields(eventKey);

                EventUtil.getInstance().setEventParameters(resultMsg, msgFields, tokens);
            }

            // Add equipment Id to the POJO if present
            String deviceId;
            if (resultMsg instanceof LoginEvent) {
                deviceId = ((LoginEvent) resultMsg).getDeviceID();
            } else {
                deviceId = RDTCacheManager.getInstance().getDeviceMapping(resultMsg.getUserID());
            }

            if (deviceId != null) {
                Device device = RDTCacheManager.getInstance().getDeviceDetails(deviceId);
                if (device != null) {
                    Equipment equipment = device.getEquipment();
                    if (equipment != null) {
                        resultMsg.setEquipmentID(equipment.getEquipmentID());
                    }
                    logger.logMsg(LOG_LEVEL.INFO, "************** EquipmentID", resultMsg.getEquipmentID());

                    if (resultMsg instanceof LoginEvent) {
                        // Clear cache
                        RDTCacheManager.getInstance().clearAllCacheForUser(resultMsg.getUserID(),
                                resultMsg.getEquipmentID());
                        RDTCacheManager.getInstance().addUserToDeviceMapping(resultMsg.getUserID(), deviceId);
                    }
                }
            }

            // Sending Manual QC job done event to Esper for detecting Delay Recording
            if (resultMsg instanceof ContainerMoveEvent || 
            		resultMsg instanceof CancelInspectionEvent || 
            		resultMsg instanceof CheckListInspectionEvent) {
                // pushing events to Esper
                RDTProcessingServer.getInstance().getEsperActor().tell(resultMsg, null);
            }
            if (resultMsg instanceof GeneralLiftOperationEvent) {
                GeneralLiftOperationEvent generalOpsEvent = (GeneralLiftOperationEvent) resultMsg;
                generalOpsEvent.setJobDone(false);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while parsing the message -", ex);
        }
        return resultMsg;
    }
}
