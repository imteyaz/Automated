package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the refresh job list request from device
 * 
 * @author Rosemary George
 *
 */
public class RefreshJobListRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7943972440333151379L;
}
