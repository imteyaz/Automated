package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ValueObject holding the Unit details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_UNIT_MASTER")
public class Unit extends Audit implements Serializable {
    private static final long serialVersionUID = 2951187500855569809L;

    @Id
    @Column(name = "UNIT_ID")
    private String unitId;

    @Column(name = "UNIT_NAME")
    private String unitName;

    @Column(name = "UNIT_DESC")
    private String description;

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
