package com.minapro.procserver.util;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.minapro.procserver.db.QCJobListEntity;
import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for executing the Chain of responsibilities to update the sequence number 
 * And perform CURD operations on  twin jobs tables in database.
 * @author UmaMahesh
 *
 */
public class QCJobListProcedureExecutionService {


	private static final QCJobListProcedureExecutionService INSTANCE= new QCJobListProcedureExecutionService();

	private final QCJObListProcedureExecutionProcessor qcJobListProcedureProcessor = QCJObListProcedureExecutionProcessor.getInstance();

	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(QCJobListProcedureExecutionService.class);

	private final QCJobListDAO qcJobListDAO = QCJobListDAO.getInstnace();

	private QCJobListProcedureExecutionService() {

	}

	public static QCJobListProcedureExecutionService getInstance(){
		return INSTANCE;
	}



	public  void executeQCJobList(String terminalId,String rotationId, String equipmentId,
			List<QCJobListEntity> currentJobsFromDB) throws NullPointerException, SQLException{

		List<TwinTandemJobs> deletableTwinTandemIdList 			 = null;
		Set<TwinTandemJobs> availableTwinTandemJobs 			 = null;

		List<TwinTandemJobs> existedSparcsCreatedTwinJobs       = new ArrayList<TwinTandemJobs>();
		List<TwinTandemJobs> existedMinaProCreatedTwinJobs      = new ArrayList<TwinTandemJobs>();


		LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId," Java Procedure Logic Execution Started ");


		/*
		 * Step 1: Retrieve current job list sparcs created twin jobs.
		 */
		Set<OPUSTwinTandemJobsPOJO>   currentSnapShotAllTwinJobsList = qcJobListDAO.getCurrentSnapShotTwinJobs(terminalId,rotationId,equipmentId);


		int currentRefreshTwinJobsCount = (currentSnapShotAllTwinJobsList!=null &&  !currentSnapShotAllTwinJobsList.isEmpty())
				? currentSnapShotAllTwinJobsList.size() : 0 ; 

				LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId, new StringBuilder("Current Refresh Sparcs Created Twin Jobs Size Is:::").
						append(currentRefreshTwinJobsCount).toString());

				/*
				 * Step 2 -- Retrieving All Twin Tandem Jobs From Database. and separate as MinaPro and Sparcs created twin jobs.
				 */
				availableTwinTandemJobs = qcJobListDAO.getExistedTwinJobs(terminalId,rotationId,equipmentId);
				int availableTwinJobsCount = availableTwinTandemJobs!=null ? availableTwinTandemJobs.size() : 0;

				LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId,new StringBuilder("Existed All Twin Jobs Size From DB Is::").
						append(availableTwinJobsCount).toString());

				//Separating MinaPro Created Twin jobs And Sparcs Created Twin Jobs.
				if(availableTwinJobsCount>0){

					qcJobListProcedureProcessor.seperateMinaProAndSparcsCreatedTwinJobs(availableTwinTandemJobs,existedSparcsCreatedTwinJobs, existedMinaProCreatedTwinJobs);

					LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId,new StringBuilder("Existed SparcsCreatedTwinJobs Size()::").
							append(existedSparcsCreatedTwinJobs!=null ? existedSparcsCreatedTwinJobs.size() : 0).toString());

					LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId,new StringBuilder("Existed MinaPro Created TwinJobs Size::").
							append(existedMinaProCreatedTwinJobs!=null ? existedMinaProCreatedTwinJobs.size() : 0).toString());
				}
				if(currentRefreshTwinJobsCount > 0){


					for(TwinTandemJobs twinJobs : existedSparcsCreatedTwinJobs){

						Set<TwinTandemContainerList> twinTadenContainerList = twinJobs.getTwinTandemDetails();

						String minaproTwinSplit = twinJobs.getTwinSplit();
						String twinTandeemId    = twinJobs.getTwinTandemId().toString();	

						LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId,"Existed Sparcs Created Twin Job Twin Tandem Id::"+twinTandeemId);

						for(TwinTandemContainerList twinTandemContainer : twinTadenContainerList){
							qcJobListProcedureProcessor.checkCurrentSpacrCreatedTwinJobsWithExistedForModifications
							(currentSnapShotAllTwinJobsList, twinTandemContainer, minaproTwinSplit,twinTandeemId);
						}
					}

					deletableTwinTandemIdList = qcJobListProcedureProcessor.prepareDeletableJobsListFromCurrentJobs(
							currentSnapShotAllTwinJobsList,existedSparcsCreatedTwinJobs);

					LOGGER.logMsg(LOG_LEVEL.INFO, rotationId+equipmentId,new StringBuilder("Deletable TwinTandem List For Existed Sparcs Created Twin Jobs::").
							append(deletableTwinTandemIdList!=null ? deletableTwinTandemIdList.size() : 0).toString());

					/*
					 * Comparison and DB operations will be complete.
					 */
					qcJobListProcedureProcessor.prepareInsertOrUpdateRequiredList(currentSnapShotAllTwinJobsList, rotationId, terminalId , equipmentId);

				} else {
					LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId," No Twins Are Available In Sparcs For Current Refresh, No Need To Execute Procedure Step 3 to 4");
				}

				/*
				 * step 5.1
				 */
				if(existedMinaProCreatedTwinJobs!=null && !existedMinaProCreatedTwinJobs.isEmpty()){

					deletableTwinTandemIdList = deletableTwinTandemIdList!=null ? deletableTwinTandemIdList :new ArrayList<TwinTandemJobs>() ; 

					qcJobListProcedureProcessor.processNonSparcsTwinJobs(existedMinaProCreatedTwinJobs,deletableTwinTandemIdList,currentJobsFromDB);

				}

				//Final Step Deleting Objects From TwinTandemContainer List table

				if(deletableTwinTandemIdList!=null && !deletableTwinTandemIdList.isEmpty()){ 

					LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId,new StringBuilder(" Calling Final Step In Procudere Logic To Delete Twin Jobs ")
					.append(" Which Are Not Available In Current Refresh JobList Table").
					append(deletableTwinTandemIdList!=null ? deletableTwinTandemIdList.size():0).toString());

					LOGGER.logMsg(LOG_LEVEL.TRACE,rotationId+equipmentId,new StringBuilder(" Final Deletable TwinTandem List::").
							append(deletableTwinTandemIdList.toString()).toString());

					qcJobListDAO.deleteBulkTwinTandemJobs(deletableTwinTandemIdList);

				}

				LOGGER.logMsg(LOG_LEVEL.INFO, rotationId+equipmentId,"Pocedure Execution Ended");
	}
	
			

			
		
	
}



