package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * ValueObject holding the completed container moves performed by user for a particular rotationID
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_COMPLETED_MOVES")
public class CompletedContainerMoves implements Serializable {
    private static final long serialVersionUID = 1610656825534610204L;

    @Id
    @SequenceGenerator(name = "seq_gen", sequenceName = "MP_COMPLETED_MOVES_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "seq_gen")
    @Column(name = "MOVE_ID")
    private int moveId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_NM")
    private User user;

    @Column(name = "EQUIPMENT_ID")
    private String equipment;

    @Column(name = "MOVE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date moveTime;

    @Column(name = "CONTAINER_ID")
    private String containerId;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    @Column(name = "MOVE_TYPE")
    private String moveType;

    @Column(name = "POD")
    private String pod;

    @Column(name = "ISO_CODE")
    private String isoCode;

    @Column(name = "WEIGHT")
    private String weight;

    @Column(name = "FROM_LOCATION")
    private String fromLocation;

    @Column(name = "TO_LOCATION")
    private String toLocation;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "REFERENCE_CONTAINERS")
    private String referenceContainers;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "IS_EXCEPTION")
    private String exceptionOccured;

    @Column(name = "EXCEPTION_RESOLVED")
    private String exceptionResolved;

    @Column(name = "EXCEPTION_REASON")
    private String exceptionReason;

    @Column(name = "IS_AUTOMATIC")
    private String isAutomaticConfirmation;

    @Column(name = "SEAL_OK")
    private String isSealOk;
    
    @Column(name = "DOOR_DIRECTION")
    private String doorDirection;
    
    @Column(name = "IMDG_CODE")
    private String hazardousCode;
    
    @Transient
    private boolean isDamaged;
    
    /*
     * Following Three are the new properties with respect to OPUS.
     * These properties needed when Exchange stowage position is required.
     */
    @Column(name = "VOYAGE")
    private String voyage;
   
    @Column(name = "VESSEL_NAME")
	private String vesselName;
    
    @Column(name = "JOB_KEY")
    private String jobKey;
    
    @Column(name = "POSITION")
    private String position;
    
    public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getVoyage() {
		return voyage;
	}

	public void setVoyage(String voyage) {
		this.voyage = voyage;
	}

	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public boolean isDamaged() {
		return isDamaged;
	}

	public void setDamaged(boolean isDamaged) {
		this.isDamaged = isDamaged;
	}

	public String getDoorDirection() {
		return doorDirection;
	}

	public void setDoorDirection(String doorDirection) {
		this.doorDirection = doorDirection;
	}

	public String getHazardousCode() {
		return hazardousCode;
	}

	public void setHazardousCode(String hazardousCode) {
		this.hazardousCode = hazardousCode;
	}

	public String getIsSealOk() {
        return isSealOk;
    }

    public void setIsSealOk(String isSealOk) {
        this.isSealOk = isSealOk;
    }

    public String getIsAutomaticConfirmation() {
        return isAutomaticConfirmation;
    }

    public void setIsAutomaticConfirmation(String isAutomaticConfirmation) {
        this.isAutomaticConfirmation = isAutomaticConfirmation;
    }

    public String getExceptionOccured() {
        return exceptionOccured;
    }

    public void setExceptionOccured(String exceptionOccured) {
        this.exceptionOccured = exceptionOccured;
    }

    public String getExceptionResolved() {
        return exceptionResolved;
    }

    public void setExceptionResolved(String exceptionResolved) {
        this.exceptionResolved = exceptionResolved;
    }

    public String getEquipment() {
        return equipment;
    }

    public void setEquipment(String equipment) {
        this.equipment = equipment;
    }

    public int getMoveId() {
        return moveId;
    }

    public void setMoveId(int moveId) {
        this.moveId = moveId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getMoveTime() {
        return moveTime;
    }

    public void setMoveTime(Date moveTime) {
        this.moveTime = moveTime;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getReferenceContainers() {
        return referenceContainers;
    }

    public void setReferenceContainers(String referenceContainers) {
        this.referenceContainers = referenceContainers;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getIsEmpty() {
        return status;
    }

    public void setIsEmpty(String status) {
        this.status = status;
    }

    public String getExceptionReason() {
        return exceptionReason;
    }

    public void setExceptionReason(String exceptionReason) {
        this.exceptionReason = exceptionReason;
    }

	@Override
	public String toString() {
		return "CompletedContainerMoves [user=" + user+", equipment=" + equipment + ", containerId=" + containerId + ", rotationId=" + rotationId
				+ ", moveType=" + moveType + ",  fromLocation="+ fromLocation + ", toLocation=" + toLocation + "referenceContainers=" + referenceContainers
				+ ", exceptionOccured=" + exceptionOccured+ ", exceptionResolved=" + exceptionResolved+ ", exceptionReason=" + exceptionReason
				+ ", isAutomaticConfirmation=" + isAutomaticConfirmation+ ", isSealOk=" + isSealOk + ", doorDirection=" + doorDirection
				+ ", hazardousCode=" + hazardousCode + ", isDamaged="+ isDamaged + ", voyage=" + voyage + ", vesselName="+ vesselName + ", jobKey=" + jobKey
				+ ", position=" + position+ "]";
	}
}
