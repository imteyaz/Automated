package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.HOIST1_POSITION;
import static com.minapro.procserver.util.QCPLCConstants.STATE_LOCK;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

/*
 * 
 * <p> Class responsible for detecting Hoist1Postition during the container
 * locking time  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCHoist1PositionSubscriber implements StatementSubscriber {

    public QCHoist1PositionSubscriber() {
    }

    @Override
    public String getStatement() {
        return "context EachQC select a,b from pattern [ every a=EsperPLCEvent(tagName = 'Hoist1Position') -> (((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = lockedUpTagValue))) and not EsperPLCEvent(tagName = 'Hoist1Position'))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateCraneMoveStatus(HOIST1_POSITION, STATE_LOCK, eventMap);
    }
}
