package com.minapro.procserver.actors;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.OneForOneStrategy;
import akka.actor.Props;
import akka.actor.SupervisorStrategy;
import akka.actor.SupervisorStrategy.Directive;
import akka.actor.UntypedActor;
import akka.japi.Function;
import akka.routing.FromConfig;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.actors.che.CHEMoveRowResponseActor;
import com.minapro.procserver.actors.plc.BackReachDetectedActor;
import com.minapro.procserver.actors.plc.CHEContainerHandlingActor;
import com.minapro.procserver.actors.plc.CHEPLCJobdoneActor;
import com.minapro.procserver.actors.plc.ContainerHandlingActor;
import com.minapro.procserver.actors.plc.ContainerHandlingMinimizeActor;
import com.minapro.procserver.actors.plc.ContainerIDfromPLCDetectionActor;
import com.minapro.procserver.actors.plc.DelayRecordingActor;
import com.minapro.procserver.actors.plc.DelayRecordingConfirmationActor;
import com.minapro.procserver.actors.plc.PLCJobdoneActor;
import com.minapro.procserver.actors.plc.PLCSchedulerStartStopActor;
import com.minapro.procserver.actors.plc.QCLivePerformanceActor;
import com.minapro.procserver.actors.plc.StopPLCInstructionActor;
import com.minapro.procserver.actors.plc.UpdateJobDetectedActor;
import com.minapro.procserver.events.BackReachEvent;
import com.minapro.procserver.events.common.ManualDelayRecordingConfirmationEvent;
import com.minapro.procserver.events.plc.AutoDelayReconfirmEvent;
import com.minapro.procserver.events.plc.CHEContainerDetectionEvent;
import com.minapro.procserver.events.plc.CHEPLCJobdoneEvent;
import com.minapro.procserver.events.plc.CHERowChangeDetectionEvent;
import com.minapro.procserver.events.plc.ContainerDetectionEvent;
import com.minapro.procserver.events.plc.ContainerHandleEvent;
import com.minapro.procserver.events.plc.ContainerScreenMinimizeEvent;
import com.minapro.procserver.events.plc.DelayRecordingByOperatorEvent;
import com.minapro.procserver.events.plc.DelayRecordingConfirmationEvent;
import com.minapro.procserver.events.plc.DelayRecordingEvent;
import com.minapro.procserver.events.plc.EndDelayTriggerEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.PLCJobdoneEvent;
import com.minapro.procserver.events.plc.PLCSchedulerEvent;
import com.minapro.procserver.events.plc.StopPLCInstructionEvent;
import com.minapro.procserver.events.plc.UpdateJobDetectedEvent;

/**
 * Actor responsible for handling/supervising all the events associated with PLC
 * 
 * @author Rosemary George
 *
 */
public class PLCSupervisorActor extends UntypedActor {

    private ActorRef containerHandlingActor = getContext().actorOf(
            Props.create(ContainerHandlingActor.class).withRouter(new FromConfig()), "containerHandling");

    private ActorRef delayRecordingActor = getContext().actorOf(
            Props.create(DelayRecordingActor.class).withRouter(new FromConfig()), "delayRecording");

    private ActorRef delayRecordingConfirmationActor = getContext().actorOf(
            Props.create(DelayRecordingConfirmationActor.class).withRouter(new FromConfig()),
            "delayRecordingConfirmation");

    private ActorRef qcLivePerformanceActor = getContext().actorOf(
            Props.create(QCLivePerformanceActor.class).withRouter(new FromConfig()), "qcLivePerformance");

    private ActorRef plcJobdoneActor = getContext().actorOf(
            Props.create(PLCJobdoneActor.class).withRouter(new FromConfig()), "PLCjobdone");

    private ActorRef backReachDetectedActor = getContext().actorOf(
            Props.create(BackReachDetectedActor.class).withRouter(new FromConfig()), "backReachOperation");

    private ActorRef plcSubscriptionActor = getContext().actorOf(
            Props.create(StopPLCInstructionActor.class).withRouter(new FromConfig()), "plcSubscription");

    private ActorRef containerScreenMinimizeActor = getContext()
            .actorOf(Props.create(ContainerHandlingMinimizeActor.class).withRouter(new FromConfig()),
                    "containerScreenMinimizer");

    private ActorRef updateJobDetectedActor = getContext().actorOf(
            Props.create(UpdateJobDetectedActor.class).withRouter(new FromConfig()), "updateJobDetected");

    private ActorRef jobhighlightActor = getContext().actorOf(
            Props.create(ContainerIDfromPLCDetectionActor.class).withRouter(new FromConfig()), "containerHighlight");

    private ActorRef plcSchedulerActor = getContext().actorOf(
            Props.create(PLCSchedulerStartStopActor.class).withRouter(new FromConfig()), "plcScheduler");

    private ActorRef chePlcJobdoneActor = getContext().actorOf(
            Props.create(CHEPLCJobdoneActor.class).withRouter(new FromConfig()), "CHEPLCjobdone");

    private ActorRef cheContainerHandlingActor = getContext().actorOf(
            Props.create(CHEContainerHandlingActor.class).withRouter(new FromConfig()), "CHEContainerHandling");

    private ActorRef cheMoveRowResponseActor = getContext().actorOf(
            Props.create(CHEMoveRowResponseActor.class).withRouter(new FromConfig()), "cheRowMoveResponse");

    /**
     * Defines the supervisor strategy to be followed
     */
    private static SupervisorStrategy strategy = new OneForOneStrategy(10, Duration.create("10 second"),
            new Function<Throwable, Directive>() {
                public Directive apply(Throwable t) {
                    return SupervisorStrategy.restart();
                }
            });

    @Override
    public SupervisorStrategy supervisorStrategy() {
        return strategy;
    }

    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof ContainerHandleEvent) {
            containerHandlingActor.tell(message, getSelf());
        } else if (message instanceof DelayRecordingEvent 
                || message instanceof DelayRecordingByOperatorEvent) {
            delayRecordingActor.tell(message, getSelf());
        } else if (message instanceof DelayRecordingConfirmationEvent
                ||  message instanceof ManualDelayRecordingConfirmationEvent
                || message instanceof EndDelayTriggerEvent
                || message instanceof AutoDelayReconfirmEvent) {
            delayRecordingConfirmationActor.tell(message, getSelf());
        } else if (message instanceof EsperPLCEvent) {
            qcLivePerformanceActor.tell(message, getSelf());
        } else if (message instanceof PLCJobdoneEvent) {
            plcJobdoneActor.tell(message, getSelf());
        } else if (message instanceof BackReachEvent) {
            backReachDetectedActor.tell(message, getSelf());
        } else if (message instanceof StopPLCInstructionEvent) {
            plcSubscriptionActor.tell(message, getSelf());
        } else if (message instanceof ContainerScreenMinimizeEvent) {
            containerScreenMinimizeActor.tell(message, getSelf());
        } else if (message instanceof UpdateJobDetectedEvent) {
            updateJobDetectedActor.tell(message, getSelf());
        } else if (message instanceof ContainerDetectionEvent) {
            jobhighlightActor.tell(message, getSelf());
        } else if (message instanceof PLCSchedulerEvent) {
            plcSchedulerActor.tell(message, getSelf());
        } else if (message instanceof CHEPLCJobdoneEvent) {
            chePlcJobdoneActor.tell(message, getSelf());
        } else if (message instanceof CHEContainerDetectionEvent) {
            cheContainerHandlingActor.tell(message, getSelf());
        } else if (message instanceof CHERowChangeDetectionEvent) {
            cheMoveRowResponseActor.tell(message, getSelf());
        } else {
            RDTProcessingServer.getInstance().getMasterActor().tell(message, getSelf());
        }
    }
}
