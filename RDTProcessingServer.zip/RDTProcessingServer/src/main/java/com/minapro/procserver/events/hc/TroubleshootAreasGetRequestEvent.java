package com.minapro.procserver.events.hc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Holding the Troubleshoot area request message fields information.
 * 
 * @author Umamahesh M
 *
 */
public class TroubleshootAreasGetRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = 9054891145430286299L;
}
