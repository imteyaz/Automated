package com.minapro.procserver.events;

import java.io.Serializable;

import com.minapro.procserver.events.BayProfileRequestEvent.BAY_VIEW;

/**
 * ValueObject holding the switch bay request from device. The request will indicate whether the device wants to switch
 * from Deck to UnderDeck or vice versa
 * 
 * @author Rosemary George
 *
 */
public class SwitchBayRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -6896360970752980267L;

    /**
     * Indicates whether Current or Future view is requested
     */
    private BAY_VIEW viewType;

    /**
     * Indicates which bayNo the request is for
     */
    private String bayNo;

    /**
     * Indicates whether requested for Deck or UnderDeck
     */
    private String deckIndication;

    public BAY_VIEW getViewType() {
        return viewType;
    }

    public void setViewType(String viewType) {
        if ("C".equalsIgnoreCase(viewType)) {
            this.viewType = BAY_VIEW.CURRENT;
        } else {
            this.viewType = BAY_VIEW.FUTURE;
        }
    }

    public String getBayNo() {
        return bayNo;
    }

    public void setBayNo(String bayNo) {
        this.bayNo = bayNo;
    }

    public String getDeckIndication() {
        return deckIndication;
    }

    public void setDeckIndication(String deckIndication) {
        this.deckIndication = deckIndication;
    }

    @Override
    public String toString() {
        return "SwitchBayRequestEvent [viewType=" + viewType + ", bayNo=" + bayNo + ", deckIndication="
                + deckIndication + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
