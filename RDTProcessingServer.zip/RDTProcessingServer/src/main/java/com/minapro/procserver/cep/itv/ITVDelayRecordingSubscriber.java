package com.minapro.procserver.cep.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.plc.DelayRecordingEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class responsible for detecting the ITV delay and act on it.
 * 
 * @author Rosemary George
 *
 */
public class ITVDelayRecordingSubscriber implements StatementSubscriber {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVDelayRecordingSubscriber.class);

    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

    @Override
    public String getStatement() {
        return "context SegmentByITVOperator "
                + "select event from pattern "
                + "[every (event=DriveInstructionEvent)"
                + " -> (timer:interval(itv_delay_time sec)) and not (ITVArrivalEvent or PinningStationJobConfirmationEvent)]";
    }

    public void update(Map<String, DriveInstructionEvent> eventMap) {
        DriveInstructionEvent event = eventMap.get("event");

        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(event.getEquipmentID());

        if (userId != null && RDTCacheManager.getInstance().isOperatorAvailable(userId)) {

            StringBuilder sb = new StringBuilder();
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);
            sb.append("\n* [ALERT] : ITV DELAY RECORDING EVENT DETECTED! OF USER " + userId);
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);
            logger.logMsg(LOG_LEVEL.INFO, userId, sb.toString());

            // Sending delay Recording Event to Master Actor
            DelayRecordingEvent delayRecordingEvent = new DelayRecordingEvent();
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(DELAY_RECORDING);
            delayRecordingEvent.setEventType(eventTypeID);
            delayRecordingEvent.setTimeStamp(FORMATTER.format(new Date()));
            delayRecordingEvent.setEventID(UUID.randomUUID().toString());
            delayRecordingEvent.setUserID(event.getUserID());
            delayRecordingEvent.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));

            logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "Sending Delay Recording Alert to User");
            RDTProcessingServer.getInstance().getMasterActor().tell(delayRecordingEvent, null);

        }
    }
}
