package com.minapro.procserver.events.hc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the swap request from the device
 * 
 * @author Rosemary George
 *
 */
public class SwapRequestEvent extends Event implements Serializable {

	private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
	private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);
	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(SwapRequestEvent.class);

	private static final long serialVersionUID = 394051223456581634L;

	/**
	 * the ITV which is carrying the containers that needs swapping
	 */
	private String itvId;
	
	/**
	 * ID of the containers which are going to be swapped. This format will be containerID1|containerID2
	 */
	private String containerIds;

	/**
	 * List of containers which are getting swapped
	 */
	private List<SwapContainerPosition> swapContainers;

	public List<SwapContainerPosition> getSwapContainers() {
		return swapContainers;
	}

	public void setSwapContainers(String swapContainers) {
		try {
			this.containerIds = swapContainers;
			
			String[] swapCntrList = swapContainers.split("\\" + ROW_SEPERATOR);
			String[] eachRow;
			List<SwapContainerPosition> swapList = new ArrayList<SwapContainerPosition>();
			SwapContainerPosition eachDetail;
			for (String swap : swapCntrList) {
				eachRow = swap.split("\\" + ITEM_SEPERATOR);
				eachDetail = new SwapContainerPosition();
				eachDetail.setContainerId(eachRow[0]);
				eachDetail.setPositionOnChassis(eachRow[1]);
				swapList.add(eachDetail);
			}
			this.swapContainers = swapList;
			
		} catch (Exception ex) {
			logger.logException("Caught exception while setting Swap Container details:", ex);
			this.swapContainers = new ArrayList<SwapContainerPosition>();
		}
	}

	public void setSwapContainers(List<SwapContainerPosition> swapContainers) {
		this.swapContainers = swapContainers;
	}

	public String getItvId() {
		return itvId;
	}

	public void setItvId(String itvId) {
		this.itvId = itvId;
	}
	
	public String getContainerIds() {
		return containerIds;
	}

	public void setContainerIds(String containers) {
		this.containerIds = containers;
	}

	@Override
	public String toString() {
		return "SwapRequestEvent [itvId=" + itvId + ", swapContainerList="
				+ swapContainers + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}
}
