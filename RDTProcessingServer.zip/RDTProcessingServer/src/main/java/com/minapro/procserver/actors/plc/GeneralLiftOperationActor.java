package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;

import java.util.Date;
import java.util.List;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.BackReachJobs;
import com.minapro.procserver.db.BackReachPK;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.DeleteManualJobRequestEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.plc.GeneralLiftOperationEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for adding General Lift Operation to Joblist. </p>
 * 
 * @author Venkataramana.ch
 * 
 */

public class GeneralLiftOperationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(GeneralLiftOperationActor.class);

    private static final String HATCHCOVER = "HATCHCOVER";
    private static final String MANCAGE = "MANCAGE";
    private static final String BREAKBULK = "BREAKBULK";
    private static final String CONTAINER = "CONTAINER";
    private static final String GENERALLIFT = "GENERALLIFT";

    private static final Object LOCKOBJ = new Object();
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
			.getCommParameter(ITEM_SEPERATOR_KEY);

    @Override
    /**
     * Handles General Lift Operation event
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof GeneralLiftOperationEvent) {
            GeneralLiftOperationEvent generalOperation = (GeneralLiftOperationEvent) message;

            if (OPERATOR.HC.equals(RDTCacheManager.getInstance().getUserLoggedInRole(generalOperation.getUserID()))) {
                generalOperation.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                        generalOperation.getUserID()));
            }
            handleGeneralLiftOperations(generalOperation);
        } else if (message instanceof DeleteManualJobRequestEvent) {
            DeleteManualJobRequestEvent manualDeleteOperation = (DeleteManualJobRequestEvent) message;
            logger.logMsg(LOG_LEVEL.DEBUG, manualDeleteOperation.getUserID(),
                    "Received Delete Manual Job request event-" + manualDeleteOperation);

            if (OPERATOR.HC
                    .equals(RDTCacheManager.getInstance().getUserLoggedInRole(manualDeleteOperation.getUserID()))) {
                manualDeleteOperation.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
                        manualDeleteOperation.getUserID()));
            }

            RDTCacheManager.getInstance().deleteFromJobList(manualDeleteOperation.getUserID(),
                    manualDeleteOperation.getJobId(), manualDeleteOperation.getEquipmentID(), manualDeleteOperation.getMoveType());
            sendDeleteMessageToOtherUsers(manualDeleteOperation);
        } else {
            unhandled(message);
        }

    }

    /**
     * Constructs and sends delete job operation performed by one operator to all other users who are working on the
     * same location.
     * 
     * @param manualDeleteOperation
     */
    private void sendDeleteMessageToOtherUsers(DeleteManualJobRequestEvent manualDeleteOperation) {
        try {
            Set<String> allocatedUsers = RDTCacheManager.getInstance().getAllUsersAtLocation(
                    manualDeleteOperation.getEquipmentID());
            String performedUser = manualDeleteOperation.getUserID();

            if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {
                String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                        RDTProcessingServerConstants.DELETE_MANUAL_JOB);
                String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

                StringBuilder responseToDevice;
                for (String currentUser : allocatedUsers) {
                    if (!currentUser.equals(performedUser)) {
                        String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(currentUser);
                        if (inspectionStatus != null) {
                            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(currentUser);

                            // build the response to the device
                            responseToDevice = new StringBuilder(NOTIF).append( valueSeperator).append( eventTypeID);
                            responseToDevice.append(valueSeperator).append(manualDeleteOperation.getEventID())
                                    .append(valueSeperator).append(manualDeleteOperation.getJobId())
                                    .append(valueSeperator).append(currentUser).append(valueSeperator)
                                    .append(manualDeleteOperation.getTerminalID());

                            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(),
                                    operatorRole, manualDeleteOperation.getTerminalID());
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }

    /**
     * Method Is responsible for handling all lift operations like MANCAGE,HATCHCOVER,BREAKBULK. If current operator is
     * HC, OBF need to send jobMessage to the QC operator. If current operator role is QC,send jobMessage to users
     * allocated in that location related to QC
     * 
     * @param generalOperation
     * @author UMAMAHESH M, Kumaraswamy (Added condition for OBF)
     */
    private void handleGeneralLiftOperations(GeneralLiftOperationEvent generalOperation) {

        logger.logMsg(
                LOG_LEVEL.INFO,
                generalOperation.getUserID(),
                new StringBuilder(ENTRY).append(" handleGeneralLiftOperations()").append(INPUT)
                        .append(generalOperation.toString()).toString());

        try {
            String currentLoggedInUserId = generalOperation.getUserID();
            RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

            if (!generalOperation.isJobDone()) {
                logger.logMsg(LOG_LEVEL.DEBUG, generalOperation.getUserID(), "Received General Operation event-"
                        + generalOperation);
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(currentLoggedInUserId);

                String currentJobId = saveGeneralLiftOperation(generalOperation, operatorRole);
                sendJobIdToUser(generalOperation, currentJobId);
                generalOperation.setJobString(currentJobId);

                JobListContainer container = new JobListContainer();
                container.setContainerId(currentJobId);
                container.setFromLocation(generalOperation.getFromLocation());
                container.setToLocation(generalOperation.getToLocation());
                container.setMoveType(generalOperation.getMoveType());

                if (operatorRole.equals(OPERATOR.HC)) {
                    // Getting Current Operating QCOperator userId with Current
                    // Logged in HC operator equipmentId
                    String qcEqupmntId = rdtCacheMgr.getQCEquipmentAllocatedForHC(currentLoggedInUserId);
                    updateJobList(currentLoggedInUserId, currentJobId, container, qcEqupmntId,
                            generalOperation.getMoveType());

                    String qcUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcEqupmntId);
                    if (qcUserId != null) {
                        generalOperation.setUserID(qcUserId);
                        sendResponseMsgToCorrespondingUser(generalOperation, false);

                        RDTPLCCacheManager.getInstance().addPreviousJobType(qcUserId, GENERALLIFT);
                    }
                } else if (operatorRole.equals(OPERATOR.FOREMAN)) {
                    // Getting Current Operating QCOperator userId with Current
                    // Logged in OBF operator equipmentId
                    // get the selected QC id from event (Which is coming from UI)
                    String qcEqupmntId = generalOperation.getQcId();
                    String position = generalOperation.getOrderNo();
                    updateJobListBasedOnPosition(currentLoggedInUserId, currentJobId, container, qcEqupmntId, position,
                            generalOperation.getMoveType());

                    String qcUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcEqupmntId);
                    if (qcUserId != null) {
                        generalOperation.setUserID(qcUserId);
                        sendResponseMsgToCorrespondingUser(generalOperation, false);
                    }
                } else if (operatorRole.equals(OPERATOR.QC)) {
                    updateJobList(currentLoggedInUserId, currentJobId, container, generalOperation.getEquipmentID(),
                            generalOperation.getMoveType());
                    sendResponseToAllUsers(generalOperation, false);

                    RDTPLCCacheManager.getInstance().addPreviousJobType(currentLoggedInUserId, GENERALLIFT);

                }
            } else {
                // PLC Operation
                sendResponseMsgToCorrespondingUser(generalOperation, true);
                sendResponseToAllUsers(generalOperation, true);
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }

    /**
     * Sends the unique job id back to the UI.
     * 
     * Message format is 1802~eventId~JobId~userId~TerminalId In case back reach job is Container, same containerID will
     * be sent back as JobId. Other cases it will be BackReachType_MoveKind_IndexNumb
     * 
     * @param generalOperation
     * @param currentJobId
     */
    private void sendJobIdToUser(GeneralLiftOperationEvent generalOperation, String currentJobId) {
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.GENERALLIFT_OPERATION_RESP);
        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(generalOperation.getUserID());

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RESP).append( valueSeperator).append( eventTypeID);
        responseToDevice.append(valueSeperator).append(generalOperation.getEventID()).append(valueSeperator)
                .append(currentJobId).append(valueSeperator).append(generalOperation.getUserID())
                .append(valueSeperator).append(generalOperation.getTerminalID());

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                generalOperation.getTerminalID());
    }

    /**
     * Saves the back reach job to the database
     * 
     * @param generalOperation
     * @param role
     * @return
     * @author Rosemary
     */
    private String saveGeneralLiftOperation(GeneralLiftOperationEvent generalOperation, OPERATOR role) {
        String currentjobId;

        String backReachType = generalOperation.getJobString().trim();
        if (!HATCHCOVER.equalsIgnoreCase(backReachType) && !MANCAGE.equalsIgnoreCase(backReachType)
                && !BREAKBULK.equalsIgnoreCase(backReachType)) {
            backReachType = CONTAINER;
        }

        User user = RDTCacheManager.getInstance().getUserDetails(generalOperation.getUserID());
        BackReachJobs job = new BackReachJobs();
        job.setCreatedBy(user);
        job.setCreatedDateTime(new Date());
        job.setFromLocation(generalOperation.getFromLocation());
        job.setJobType(backReachType);
        job.setMoveType(generalOperation.getMoveType());

        String qcEquipmentId = generalOperation.getEquipmentID();
        if (role.equals(OPERATOR.HC)) {
            qcEquipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(generalOperation.getUserID());
        } else if (role.equals(OPERATOR.FOREMAN)) {
            qcEquipmentId = generalOperation.getQcId();
        }
        job.setQcId(RDTCacheManager.getInstance().getEquipmentDetails(qcEquipmentId));
        job.setToLocation(generalOperation.getToLocation());

        ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(generalOperation.getUserID());
        
        String rotationId = "";
        if(allocation != null){
            rotationId = allocation.getRotationID();
        }
        logger.logMsg(LOG_LEVEL.DEBUG, generalOperation.getUserID(), "Associated rotation is " + rotationId);
        
        int index = 0;
        String moveType = generalOperation.getMoveType();
        synchronized (LOCKOBJ) {
            index = HibernateUtil.getBackReachUniqueIndex(rotationId, backReachType, moveType);
            index++;
            
            currentjobId = backReachType + "_" + generalOperation.getMoveType() + "_" + index;
        }

        BackReachPK pk = new BackReachPK();
        pk.setRotationId(rotationId);
        if (backReachType.equals(CONTAINER)) {
            pk.setId(generalOperation.getJobString());
            currentjobId = generalOperation.getJobString();
        } else {
            pk.setId(currentjobId);
        }
        job.setPk(pk);
        job.setUniqueIndex(index);

        JournalEvent journal = new JournalEvent(job, UPDATETYPE.ADD);
        getSender().tell(journal, null);

        return currentjobId;
    }

    /**
     * Method is responsible for calling JobList Updating method based on general lift operation. If it is DISCH job
     * should be added at first place
     * 
     * @param userId
     *            updated job list needed user
     * @param container
     *            added container i.e new container
     */
    private void updateJobList(String userId, String currentLiftOperation, JobListContainer container,
            String equipmentId, String moveType) {
        logger.logMsg(
                LOG_LEVEL.INFO,
                userId,
                new StringBuilder(ENTRY).append(" updateJobList()").append(INPUT).append(currentLiftOperation)
                        .append(container.toString()).toString());

        RDTCacheManager cacheManager = RDTCacheManager.getInstance();
        try {
            if (currentLiftOperation.startsWith(HATCHCOVER) && LOAD.equals(moveType)) {
                cacheManager.updateJobList(userId, container, equipmentId, moveType);
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, equipmentId, "Updating First entry in Joblist");
                cacheManager.updateFirstEntryInJobList(userId, container, equipmentId, moveType);
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }

    /**
     * Method is responsible for sending jobMessage to the corresponding allocated user.
     * 
     * @param generalOperation
     *            GeneralLiftOperationEvent POJO
     * @param isAutomatic
     *            Checking whether operation done by PLC or Manual operation by any of the Operator If true Operation
     *            done by PLC else any of the Operator
     * @author UMAMAHESH M
     */
    private void sendResponseMsgToCorrespondingUser(GeneralLiftOperationEvent generalOperation, boolean isAutomatic) {
        String eventType = RDTProcessingServerConstants.GENERALLIFT_OPERATION;
        if (isAutomatic) {
            eventType = RDTProcessingServerConstants.JOB_DONE;
        }

        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append( valueSeperator).append( eventTypeID);
            if (isAutomatic) {
                // get the message format
                List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);
                for (int i = 1; i < msgFields.size(); i++) {
                    responseToDevice.append(valueSeperator);
                    if ("ContainerIDs".equals(msgFields.get(i))) {
                        responseToDevice.append(generalOperation.getJobString());
                    } else if ("ToLocations".equalsIgnoreCase(msgFields.get(i))) {
                        responseToDevice.append(generalOperation.getToLocation());
                    } else if ("OperationType".equalsIgnoreCase(msgFields.get(i))) {
                        responseToDevice.append("A");
                    } else {
                        EventUtil.getInstance().getEventParameter(generalOperation, msgFields.get(i), responseToDevice);
                    }
                }
            } else {
                responseToDevice.append(valueSeperator).append(generalOperation.getEventID()).append(valueSeperator)
                        .append(generalOperation.getJobString()).append(ITEM_SEPERATOR).
                         append(generalOperation.getMoveType()).append(valueSeperator)
                        .append(generalOperation.getMoveType()).append(valueSeperator)
                        .append(generalOperation.getFromLocation()).append(valueSeperator)
                        .append(generalOperation.getToLocation()).append(valueSeperator)
                        .append(generalOperation.getUserID()).append(valueSeperator)
                        .append(generalOperation.getTerminalID());
            }

            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(generalOperation.getUserID());
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                    generalOperation.getTerminalID());

            if (isAutomatic) {
                logger.logMsg(LOG_LEVEL.DEBUG, generalOperation.getUserID(), "Sending Remove Job entry to Device");
                // remove the containers form job list
                String jobString = generalOperation.getJobString();
                RDTCacheManager.getInstance().deleteFromJobList(generalOperation.getUserID(), jobString,
                        generalOperation.getEquipmentID(), generalOperation.getMoveType());
            } else {
                logger.logMsg(LOG_LEVEL.INFO, "", "Current Operation Is Manual Operation");
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }

    /**
     * Method is responsible for sending response messages to QC related operators.
     * 
     * @param generalOperation
     *            GeneralLiftOperationEvent POJO
     * @param isAutomatic
     *            used to know whether it is related to PLC or Manual operation.
     * @author UMAMAHESH M
     */
    private void sendResponseToAllUsers(GeneralLiftOperationEvent generalOperation, boolean isAutomatic) {
        try {
            RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
            Set<String> allocatedUsers = rdtCacheMgr.getAllUsersAtLocation(generalOperation.getEquipmentID());

            if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {
                for (String currentUser : allocatedUsers) {
                    OPERATOR operatorRole = rdtCacheMgr.getUserLoggedInRole(currentUser);
                    if (operatorRole != OPERATOR.QC) {
                        String inspectionStatus = rdtCacheMgr.getInspectionStatus(currentUser);
                        generalOperation.setUserID(currentUser);
                        if (inspectionStatus != null) {
                            sendResponseMsgToCorrespondingUser(generalOperation, isAutomatic);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }

    /**
     * Method is responsible for calling JobList Updating method. Updating job for the selected Position.
     * 
     * @param userId
     *            updated job list needed user
     * @param container
     *            added container i.e new container
     * @param currentLiftOperation
     * 
     * @param equipmentId
     * 
     * @param position
     */
    private void updateJobListBasedOnPosition(String userId, String currentLiftOperation, JobListContainer container,
            String equipmentId, String position, String moveType) {
        logger.logMsg(
                LOG_LEVEL.INFO,
                "OBF",
                new StringBuilder(ENTRY).append("updateJobList()").append(INPUT).append(currentLiftOperation)
                        .append(container.toString()).toString());

        RDTCacheManager cacheManager = RDTCacheManager.getInstance();
        try {
            if (currentLiftOperation.startsWith(HATCHCOVER) && LOAD.equals(moveType)) {
                cacheManager.updateJobList(userId, container, equipmentId, moveType);
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, equipmentId, "OBF Updating selected position entry in Joblist");
                cacheManager.updateselectedPositionEntryInJobList(userId, container, equipmentId, position, moveType);
            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(REASON).toString(), ex);
        }
    }
}
