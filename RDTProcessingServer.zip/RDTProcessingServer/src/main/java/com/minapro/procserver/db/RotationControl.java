package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * ValueObject holding the vessel to rotation mapping
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_ROTATION_CONTROL_MASTER")
public class RotationControl extends Audit implements Serializable {

    private static final long serialVersionUID = -8621175187608873879L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rotationSequence")
    @SequenceGenerator(name = "rotationSequence", sequenceName = "MP_ROTATION_CONTROL_SEQ", allocationSize = 1, initialValue = 30)
    @Column(name = "ROTATION_CONTROL_ID", nullable = false)
    private Integer rotationControlId;

    @Column(name = "ROTATION_NO", nullable = false)
    private Integer rotationNumber;

    @Column(name = "VESSEL_NO", nullable = false)
    private Integer vesselNo;

    @Column(name = "BERTH_NO", nullable = false)
    private String berthNo;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @Column(name = "ETA", nullable = false)
    private Date eta;

    @Column(name = "TERMINAL_ID", nullable = false)
    private String terminalId;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MP_ROTATION_QC_MAPPING", joinColumns = @JoinColumn(name = "ROTATION_CONTROL_ID"), inverseJoinColumns = @JoinColumn(name = "EQUIPMENT_ID"))
    private Collection<Equipment> actualEquipments = new ArrayList<Equipment>();

    public Collection<Equipment> getActualEquipments() {
        return actualEquipments;
    }

    public void setActualEquipments(Collection<Equipment> actualEquipments) {
        this.actualEquipments = actualEquipments;
    }

    public Integer getRotationNumber() {
        return rotationNumber;
    }

    public void setRotationNumber(Integer rotationNumber) {
        this.rotationNumber = rotationNumber;
    }

    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNumber) {
        this.vesselNo = vesselNumber;
    }

    public Integer getRotationControlId() {
        return rotationControlId;
    }

    public void setRotationControlId(Integer rotationControlId) {
        this.rotationControlId = rotationControlId;
    }

    public String getBerthNo() {
        return berthNo;
    }

    public void setBerthNo(String berthNo) {
        this.berthNo = berthNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public Date getEta() {
        return eta;
    }

    public void setEta(Date eta) {
        this.eta = eta;
    }
}
