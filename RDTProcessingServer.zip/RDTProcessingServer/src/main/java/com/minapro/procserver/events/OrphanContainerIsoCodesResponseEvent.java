package com.minapro.procserver.events;

import java.util.Set;

public class OrphanContainerIsoCodesResponseEvent extends Event{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Set<String> isoCodes;

	public Set<String> getIsoCodes() {
		return isoCodes;
	}

	public void setIsoCodes(Set<String> isoCodes) {
		this.isoCodes = isoCodes;
	}

	@Override
	public String toString() {
		return "OrphanContainerIsoCodesResponseEvent [isoCodes=" + isoCodes
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getTerminalID()=" + getTerminalID()
				+ ", getEventID()=" + getEventID() + "]";
	}
	
}
