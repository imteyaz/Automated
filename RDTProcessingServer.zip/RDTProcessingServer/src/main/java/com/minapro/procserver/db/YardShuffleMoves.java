package com.minapro.procserver.db;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class YardShuffleMoves {

	@Id
	@Column(name = "YARD_SHUFFLE_MOVE_ID")
	private String yardShuffleMoveId;

	@Column(name = "CONTAINER_ID ", nullable = false)
	private String containerId;

	@Column(name = "EQUIPMENT_ID", nullable = false)
	private String equipmentID;

	@Column(name = "ROTATION_NO")
	private Integer rotationNumber;

	@Column(name = "TERMINAL", nullable = false)
	private String terminal;

	@Column(name = "SHUFFLE_REASON", nullable = false)
	private String shuffleReason;

	@Column(name = "FROM_LOCATION")
	private String fromLocation;

	@Column(name = "TO_LOCATION")
	private String toLocation;

	@Column(name = "SHUFFLE_REASON_CONTAINER_ID", nullable = false)
	private String shuffleReasonContainerId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "USER_ID", referencedColumnName = "USER_NM")
	private User user;

	@Column(name = "MOVE_DATETM", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDateTime;

	@Column(name = "CREATED_DATETIME", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date moveDateTime;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_NM")
	private User createdBy;

	public String getYardShuffleMoveId() {
		return yardShuffleMoveId;
	}

	public void setYardShuffleMoveId(String yardShuffleMoveId) {
		this.yardShuffleMoveId = yardShuffleMoveId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getEquipmentID() {
		return equipmentID;
	}

	public void setEquipmentID(String equipmentID) {
		this.equipmentID = equipmentID;
	}

	public Integer getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(Integer rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public String getShuffleReason() {
		return shuffleReason;
	}

	public void setShuffleReason(String shuffleReason) {
		this.shuffleReason = shuffleReason;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getShuffleReasonContainerId() {
		return shuffleReasonContainerId;
	}

	public void setShuffleReasonContainerId(String shuffleReasonContainerId) {
		this.shuffleReasonContainerId = shuffleReasonContainerId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Date getMoveDateTime() {
		return moveDateTime;
	}

	public void setMoveDateTime(Date moveDateTime) {
		this.moveDateTime = moveDateTime;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	
	
	

}
