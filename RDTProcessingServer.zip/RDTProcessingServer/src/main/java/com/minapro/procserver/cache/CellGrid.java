package com.minapro.procserver.cache;

import java.io.Serializable;

import com.minapro.procserver.events.common.BayProfileContainer;

/**
 * <p> ValueObject holding the cell information for a particular bay.row.tier</p>
 * 
 * @author Rosemary George
 *
 */
public class CellGrid implements Serializable {
    private static final long serialVersionUID = -7042423108378759348L;

    /**
     * Indicates the status of the cell
     */
    private CELL_STATUS status;
    /**
     * The vessel row number corresponding to this cell
     */
    private String vesselRowNo;
    /**
     * The vessel tier number corresponding to this cell
     */
    private String vesselTierNo;
    /**
     * The container details if any is present in this cell
     */
    private BayProfileContainer currentContainer;

    /**
     * Details of the container which is planned to be LOADed into this particular Cell
     */
    private BayProfileContainer plannedContainer;

    /**
     * Indicates whether pinning is required for this particular cell
     */
    private boolean isPinningRequired = false;

    /**
     * Indicates what kind of pinning is required for this cell
     */
    private PINNING_TYPE pinningType;

    /**
     * Creates the cellGrid object with status as UNAVAILABLE
     */
    public CellGrid() {
        this.status = CELL_STATUS.UNAVAILABLE;
    }

    public CELL_STATUS getStatus() {
        return status;
    }

    public void setStatus(CELL_STATUS status) {
        this.status = status;
    }

    public String getVesselRowNo() {
        return vesselRowNo;
    }

    public void setVesselRowNo(String vesselRowNo) {
        this.vesselRowNo = vesselRowNo;
    }

    public String getVesselTierNo() {
        return vesselTierNo;
    }

    public void setVesselTierNo(String vesselTierNo) {
        this.vesselTierNo = vesselTierNo;
    }

    public BayProfileContainer getCurrentContainer() {
        return currentContainer;
    }

    public BayProfileContainer getPlannedContainer() {
        return plannedContainer;
    }

    public void setPlannedContainer(BayProfileContainer plannedContainer) {
        this.plannedContainer = plannedContainer;
    }

    public void setCurrentContainer(BayProfileContainer container) {
        this.currentContainer = container;
    }

    @Override
    public String toString() {
        return "CellGrid [status=" + status + ", vesselRowNo=" + vesselRowNo + ", vesselTierNo=" + vesselTierNo
                + ", container=" + currentContainer + "]";
    }

    public PINNING_TYPE getPinningType() {
        return pinningType;
    }

    public void setPinningType(PINNING_TYPE pinningType) {
        this.pinningType = pinningType;
    }

    public boolean isPinningRequired() {
        return isPinningRequired;
    }

    public void setPinningRequired(boolean isPinningRequired) {
        this.isPinningRequired = isPinningRequired;
    }

    /**
     * Possible cell status values
     * 
     * @author Rosemary George
     *
     */
    public enum CELL_STATUS {
        UNAVAILABLE, AVAILABLE, NOTINUSE, ONLY_EMPTY_CONTAINER, REEFER, ALLOWED_45, HOT_SPOT
    }

    public enum MOVE_TYPE {
        LOAD, DSCH
    }
}
