package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the Wrong Cell Location Detected event details
 * 
 * @author Venkataramana.ch
 *
 */

public class WrongCellLocationDetectedEvent extends Event implements Serializable {

    private static final long serialVersionUID = 5430680590132678919L;

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "WrongCellLocationDetectedEvent [message=" + message + "]";
    }
}
