package com.minapro.procserver.cache;

import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.TreeSet;

import com.minapro.procserver.db.bayprofile.TemplateDetails;
import com.minapro.procserver.db.bayprofile.TemplateHeader;
import com.minapro.procserver.events.BayProfileRequestEvent.BAY_VIEW;
import com.minapro.procserver.events.common.BayProfileContainer;
import com.minapro.procserver.util.DeviceCommParameters;

/**
 * <p> ValueObject holding the bay profile details. </p>
 * 
 * <p> The Bay is represented as a set of rows and tiers. The maximum number of rows present in a bay is generally 20.
 * </p>
 * 
 * <p> This class represents the rows and tiers based on the offset value. </p>
 * 
 * <p> Rows :20,18,16,14,12,10,08,06,04,02,00,01,03,05,07,09,11,13,15,17,19 </p> <p> offsets: 0, 1, 2, 3, 4, 5, 6, 7, 8,
 * 9,10,11,12,13,14,15,16,17,28,29,20 </p>
 * 
 * <p> The row offsets can change if the vessel contains more than 20 row. This is just to show how the offsets are
 * given for the rows. The 00 row offset is read from the property file. </p>
 * 
 * <p> Deck Tiers : 80,82,84,86,88,90,92,... </p> <p> offsets : 0, 1, 2, 3, 4, 5, 6,.. </p>
 * 
 * <p> Under deck tiers : 02,04,06,08,10,12,14,-- </p> <p> Offsets : 0, 1, 2, 3, 4, 5, 6,.. </p>
 * 
 * <p> Even though the maximum number of rows is 20, the actual number of rows and tiers present will be different, so
 * the actual bay representation is stored in CellGrid[tier][row] array. </p>
 * 
 * <p> CellGrid tier dimension is calculated based on the formula - (maxTierOffSet - minTierOffset) +1 </p> <p> CellGrid
 * row dimension is calculated based on the formula - (maxRowOffset - minRowOffset). If the 00 row is present in the
 * this bay, the calculated row dimension value is incremented by 1. </p>
 * 
 * <p> This also holds the details about the containers present in the bay in the grid[tier][row] </p>
 * 
 * @author Rosemary George
 *
 */
public class BayProfile implements Serializable, Comparable<BayProfile> {
    private static final long serialVersionUID = 1196002347721024320L;

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);
    private static final String COLUMN_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            COLUMN_SEPERATOR_KEY);

    private static final int TWO = 2;
    private static final int TEN = 10;
    private static final int EIGHTY = 80;

    /**
     * The actual vessel Bay ID
     */
    private String vesselBayId;
    /**
     * Indicates whether Deck or under deck. True If the bay is under deck.
     */
    private boolean underDeckIndicator;
    /**
     * Minimum row offset present in this bay
     */
    private int minRowOffset;
    /**
     * Maximum offset present in this bay
     */
    private int maxRowOffset;
    /**
     * Minimum tier offset present in this bay
     */
    private int minTierOffset;
    /**
     * Maximum tier offset present in this bay
     */
    private int maxTierOffset;
    /**
     * Indicates whether the 00 row is present for this bay
     */
    private boolean zeroRowPresent;
    /**
     * Actual bay representation in [tier][row] manner
     */
    private CellGrid[][] cellGrid;

    /**
     * Indicates the offset value for the 00 row for this vessel
     */
    private int offsetFor00Row;

    /**
     * Indicates the tier template used for the bay
     */
    private String tierHeader;

    /**
     * Indicates whether the tier template is the standard one
     */
    private boolean isStdTierTemplate;

    /**
     * <p> Creates a new Bay profile with the specified attribute values. </p>
     * 
     * <p> Calculates the bay size and creates the CellGrid[tier][row] </p>
     * 
     * @param vesselBayId
     * @param underdeckIndication
     * @param minRowOffset
     * @param maxRowOffset
     * @param minTierOffset
     * @param maxTierOffset
     * @param zeroRowPresent
     */
    public BayProfile(String vesselBayId, boolean underdeckIndication, int minRowOffset, int maxRowOffset,
            int minTierOffset, int maxTierOffset, boolean zeroRowPresent) {
        this.vesselBayId = vesselBayId;
        this.underDeckIndicator = underdeckIndication;
        this.minRowOffset = minRowOffset;
        this.maxRowOffset = maxRowOffset;
        this.minTierOffset = minTierOffset;
        this.maxTierOffset = maxTierOffset;
        this.zeroRowPresent = zeroRowPresent;

        int tierNos = maxTierOffset - minTierOffset + 1;
        int rowNos = maxRowOffset - minRowOffset;
        if (zeroRowPresent) {
            rowNos++;
        }

        this.cellGrid = new CellGrid[tierNos][rowNos];
        initializeCellGrid();
    }

    public int getOffsetFor00Row() {
        return offsetFor00Row;
    }

    public void setOffsetFor00Row(int maxNoOfRows) {
        this.offsetFor00Row = maxNoOfRows / TWO;
    }

    public String getTierHeader() {
        return tierHeader;
    }

    public void setTierHeader(String tierHeader) {
        this.tierHeader = tierHeader;
    }

    public boolean isStdTierTemplate() {
        return isStdTierTemplate;
    }

    public void setStdTierTemplate(boolean isStdTierTemplate) {
        this.isStdTierTemplate = isStdTierTemplate;
    }

    public String getVesselBayId() {
        return vesselBayId;
    }

    public void setVesselBayId(String vesselBayId) {
        this.vesselBayId = vesselBayId;
    }

    public boolean isUnderDeckIndicator() {
        return underDeckIndicator;
    }

    public void setUnderDeckIndicator(boolean underDeckIndicator) {
        this.underDeckIndicator = underDeckIndicator;
    }

    public int getMinRowOffset() {
        return minRowOffset;
    }

    public void setMinRowOffset(int minRowOffset) {
        this.minRowOffset = minRowOffset;
    }

    public int getMaxRowOffset() {
        return maxRowOffset;
    }

    public void setMaxRowOffset(int maxRowOffset) {
        this.maxRowOffset = maxRowOffset;
    }

    public int getMinTierOffset() {
        return minTierOffset;
    }

    public void setMinTierOffset(int minTierOffset) {
        this.minTierOffset = minTierOffset;
    }

    public int getMaxTierOffset() {
        return maxTierOffset;
    }

    public void setMaxTierOffset(int maxTierOffset) {
        this.maxTierOffset = maxTierOffset;
    }

    public boolean isZeroRowPresent() {
        return zeroRowPresent;
    }

    public void setZeroRowPresent(boolean zeroRowPresent) {
        this.zeroRowPresent = zeroRowPresent;
    }

    public CellGrid[][] getCellGrid() {
        return cellGrid;
    }

    public void setCellGrid(CellGrid[][] cellGrid) {
        this.cellGrid = Arrays.copyOf(cellGrid, cellGrid.length);
    }

    /**
     * <p> Initializes the CellGrid[tier][row] array with default "unavailable" status Objects. </p>
     * 
     * <p> This is necessary to indicate which cells are actually present in each row and tier. All rows will not have
     * same number of tiers. </p>
     *
     */
    private void initializeCellGrid() {
        for (int tierIndex = 0; tierIndex < this.cellGrid.length; tierIndex++) {
            for (int rowIndex = 0; rowIndex < this.cellGrid[tierIndex].length; rowIndex++) {
                this.cellGrid[tierIndex][rowIndex] = new CellGrid();
            }
        }
    }

    /**
     * <p> Compares this instance of BayProfile with another BayProfile Object. </p> <p> Treats both as same if the
     * bayId and underDeckIndication are same and returns 0. else returns 1 </p>
     */
    @Override
    public int compareTo(BayProfile otherBayProfile) {
        if (this.underDeckIndicator == otherBayProfile.underDeckIndicator
                && this.vesselBayId.equals(otherBayProfile.vesselBayId)) {
            return 0;
        } else {
            return 1;
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + maxRowOffset;
        result = prime * result + maxTierOffset;
        result = prime * result + minRowOffset;
        result = prime * result + minTierOffset;
        result = prime * result + (underDeckIndicator ? 1231 : 1237);
        result = prime * result + ((vesselBayId == null) ? 0 : vesselBayId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        BayProfile other = (BayProfile) obj;
        if (maxRowOffset != other.maxRowOffset) {
            return false;
        }
        if (maxTierOffset != other.maxTierOffset) {
            return false;
        }
        if (minRowOffset != other.minRowOffset) {
            return false;
        }
        if (minTierOffset != other.minTierOffset) {
            return false;
        }
        if (underDeckIndicator != other.underDeckIndicator) {
            return false;
        }
        if (vesselBayId == null) {
            if (other.vesselBayId != null) {
                return false;
            }
        } else if (!vesselBayId.equals(other.vesselBayId)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "BayProfile [vesselBayId=" + vesselBayId + ", underDeckIndicator=" + underDeckIndicator
                + ", minRowOffset=" + minRowOffset + ", maxRowOffset=" + maxRowOffset + ", minTierOffset="
                + minTierOffset + ", maxTierOffset=" + maxTierOffset + ", ZeroRowPresent=" + zeroRowPresent
                + ", cellGrid=" + cellGrid.length + ",TierTemplate=" + tierHeader + "]";
    }

    /**
     * <p> Retrieves the CellGrid object from the CellGrid[tier][row] array. </p>
     * 
     * <p> The tier dimension of the cellGrid is calculated as maxTierOffset - tierOffset provided. </p> <p> The row
     * dimension of the cellGrid is calculated as provided rowOffset - minRowOffset </p>
     * 
     * @param rowOffset
     * @param tierOffset
     * @return CellGrid Object corresponding to the mentioned offsets
     */
    public CellGrid getCellGrid(int rowOffset, int tierOffset) {
        int tierDimension = this.maxTierOffset - tierOffset;
        int rowDimension = rowOffset - this.minRowOffset;
        if (rowOffset > offsetFor00Row && !this.zeroRowPresent) {
            rowDimension--;
        }

        return this.cellGrid[tierDimension][rowDimension];
    }

    /**
     * Creates the bay view message based on the specified type - current or future
     * 
     * @param eventType
     *            - indicates whether front view or top view
     * @return StringBuilder containing CellGrid[tier][row] details
     */
    public StringBuilder getBayView(BAY_VIEW viewType, boolean partOfTwinBay) {
        return generateFrontView(viewType, partOfTwinBay);
    }

    /**
     * <p> Generates the bay front view for this particular bay as expected by the device. Sends the row and tier
     * headers to be displayed and then each cell status and the container in it </p>
     * 
     * <p> rowHeaders will be filled as 02^00^01 </p> <p> tierHeaders will be filled as 86^84^82^80 for Deck and as
     * 06^04^02 for under deck </p> <p> cellDetails will be filled as </p> <p>
     * cell00Status^containerId#cell01Status^containerId#cell02Status^containerId|cell10Status^containerId#cell11Status^
     * containerId#cell12Status^containerId </p>
     * 
     * @return bayView - rowHeaders~tierHeaders~cellDetails
     * 
     */
    private StringBuilder generateFrontView(BAY_VIEW viewType, boolean partOfTwinBay) {
        StringBuilder cellDetails = new StringBuilder();

        CellGrid cell;
        BayProfileContainer bayContainer;
        String colourCode = "";

        // Iterate through tiers
        for (int tierIndex = 0; tierIndex < cellGrid.length; tierIndex++) {
            // Iterate through rows
            for (int rowIndex = 0; rowIndex < cellGrid[tierIndex].length; rowIndex++) {
                cell = this.cellGrid[tierIndex][rowIndex];

                cellDetails.append(cell.getStatus().ordinal()).append(ITEM_SEPERATOR);
                bayContainer = getProfileContainer(viewType, cell);

                if (bayContainer != null) {
                    if (partOfTwinBay && "40".equals(bayContainer.getContainer().getSize())) {
                        colourCode = "+";
                    } else if (bayContainer.getContainer().getPod() != null) {
                        colourCode = RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
                                bayContainer.getContainer().getPod());
                    } else {
                        colourCode = "";
                    }

                    cellDetails.append(bayContainer.getContainer().getContainerID()).append(ITEM_SEPERATOR)
                            .append(bayContainer.getContainer().isReefer()).append(ITEM_SEPERATOR)
                            .append(bayContainer.getContainer().isHazardous()).append(ITEM_SEPERATOR)
                            .append(bayContainer.getContainer().isOOG()).append(ITEM_SEPERATOR)
                            .append(bayContainer.isROB()).append(ITEM_SEPERATOR)
                            .append(bayContainer.getContainer().getPod()).append(ITEM_SEPERATOR).append(colourCode)
                            .append(ITEM_SEPERATOR).append(bayContainer.getContainer().getIsDamaged());
                } else {
                    cellDetails.append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR)
                            .append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR).append(ITEM_SEPERATOR);
                }
                cellDetails.append(COLUMN_SEPERATOR);
            }

            cellDetails.delete(cellDetails.length() - 1, cellDetails.length());

            cellDetails.append(ROW_SEPERATOR);
        }

        cellDetails.delete(cellDetails.length() - 1, cellDetails.length());

        return generateRowHeaders().append(VALUE_SEPERATOR).append(generateTierHeaders()).append(VALUE_SEPERATOR)
                .append(cellDetails);
    }

    /**
     * Returns the BayProfileContainer present in the Cell. Depending on the view type, this will return current
     * occupying container(for CURRENT view) and planned container(FUTURE view)
     * 
     * @param viewType
     * @param cell
     * @return
     */
    private BayProfileContainer getProfileContainer(BAY_VIEW viewType, CellGrid cell) {
        BayProfileContainer bayContainer = null;
        if (viewType.equals(BAY_VIEW.CURRENT)) {
            bayContainer = cell.getCurrentContainer();
        } else {
            bayContainer = cell.getPlannedContainer();
            // if nothing planned, check for ROB.
            if (bayContainer == null && cell.getCurrentContainer() != null && cell.getCurrentContainer().isROB()) {
                bayContainer = cell.getCurrentContainer();
            }
        }
        return bayContainer;
    }

    /**
     * <p> Gets the row offset for the specified row number </p>
     * 
     * <p> calculates the offset using the following conditions </p> <p> For even numbered rows, the offset =
     * offsetFor00Row - (rowNo/2) </p> <p> For odd numbered rows, the offset = offsetFor00Row + (rowNo/2) + 1 </p>
     * 
     * @param veselRowNo
     * @return rowOffset
     */
    public int getRowOffset(String veselRowNo) {
        int rowOffset;

        int rowNo = Integer.parseInt(veselRowNo);

        // even numbered row
        if ((rowNo % TWO) == 0) {
            rowOffset = (offsetFor00Row - (rowNo / TWO));
        } else {
            rowOffset = (offsetFor00Row + (rowNo / TWO) + 1);
        }

        return rowOffset;
    }

    /**
     * <p> Gets the tier offset for the specified vessel tier Number </p>
     * 
     * <p> calculates the offset using the following conditions </p> <p> For tiers on the deck, the offset = ((tierNo
     * -80) /2) -1 </p> <p> For tiers on the under deck, the offset = (tierNo/2) -1 </p>
     * 
     * @param vesselTierNo
     * @return tierOffset
     */
    public int getTierOffset(String vesselTierNo) {
        int tierOffset;

        if (!this.isStdTierTemplate) {
            return getTierOffsetFromTemplate(vesselTierNo);
        }

        int tierNo = Integer.parseInt(vesselTierNo);

        // on the deck
        if (tierNo >= EIGHTY) {
            tierOffset = (tierNo - EIGHTY) / TWO;
        } else {
            tierOffset = (tierNo / TWO) - 1;
        }

        return tierOffset;
    }

    /**
     * Retrieves the tier offset from the template
     * 
     * @param vesselTierNo
     * @return
     */
    private int getTierOffsetFromTemplate(String vesselTierNo) {
        TemplateHeader template = RDTVesselProfileCacheManager.getInstance().getTemplateHeader(this.tierHeader);

        for (TemplateDetails details : template.getTemplateDetails()) {
            if (details.getVesselLabel().equals(vesselTierNo)) {
                return details.getPk().getOffset();
            }
        }

        return 0;
    }

    /**
     * <p> Generates the Row headers for this bay. </p>
     * 
     * <p> Uses the min and max row offsets to generate the actual vessel row numbers. <p>
     * 
     * <p> if the rowOffset is less than offsetFor00Row, the formula used to get the row number is
     * (offsetFor00Row-offset)*2 </p> <p> For offsets greater than offsetFor00Row, the formula used is
     * ((offset-offsetFor00Row)*2)-1 </p>
     * 
     * @return rowHeaders in the form 06^04^02^01^03^05
     */
    public StringBuilder generateRowHeaders() {
        StringBuilder rowHeaders = new StringBuilder();

        int rowNo = 0;
        for (int rowOffset = this.minRowOffset; rowOffset <= this.maxRowOffset; rowOffset++) {
            if (rowOffset == offsetFor00Row) {
                if (this.zeroRowPresent) {
                    rowHeaders.append("00").append(ITEM_SEPERATOR);
                }
                continue;
            } else if (rowOffset < offsetFor00Row) {
                rowNo = (offsetFor00Row - rowOffset) * TWO;
            } else if (rowOffset > offsetFor00Row) {
                rowNo = ((rowOffset - offsetFor00Row) * TWO) - 1;
            }

            if (rowNo >= TEN) {
                rowHeaders.append(rowNo).append(ITEM_SEPERATOR);
            } else {
                rowHeaders.append("0" + rowNo).append(ITEM_SEPERATOR);
            }
        }
        rowHeaders.delete(rowHeaders.length() - 1, rowHeaders.length());

        return rowHeaders;
    }

    /**
     * <p> Generates the Tier headers for this bay. </p>
     * 
     * <p> Uses the min and max tier offsets to generate the actual vessel tier numbers. <p>
     * 
     * <p> If the Bay is under deck, the formula used to get the tier number is (offset*2)+2 </p> <p> Else, the formula
     * used is (offset*2)+80 </p>
     * 
     * @return tier Headers in the form 06^04^02(under deck) or 88^86^84^82^80(deck)
     */
    private StringBuilder generateTierHeaders() {
        StringBuilder tierHeaders = new StringBuilder();

        if (!this.isStdTierTemplate) {
            return getTierHeadersFromTemplate(false);
        }

        int tierNo;
        for (int tierOffset = maxTierOffset; tierOffset >= this.minTierOffset; tierOffset--) {
            tierNo = tierOffset * TWO;
            if (this.isUnderDeckIndicator()) {
                tierNo = tierNo + TWO;
            } else {
                tierNo = tierNo + EIGHTY;
            }

            if (tierNo >= TEN) {
                tierHeaders.append(tierNo).append(ITEM_SEPERATOR);
            } else {
                tierHeaders.append("0" + tierNo).append(ITEM_SEPERATOR);
            }
        }

        tierHeaders.delete(tierHeaders.length() - 1, tierHeaders.length());

        return tierHeaders;
    }

    /**
     * Generates the Tier numbers for the specified bay in Ascending or descending order
     * 
     * @param isAscending
     * @return
     */
    private StringBuilder getTierHeadersFromTemplate(boolean isAscending) {
        StringBuilder tierHeaders = new StringBuilder();

        TemplateHeader template = RDTVesselProfileCacheManager.getInstance().getTemplateHeader(this.tierHeader);
        TreeSet<TemplateDetails> details = new TreeSet<TemplateDetails>(template.getTemplateDetails());
        Iterator<TemplateDetails> itr;
        if (isAscending) {
            itr = details.iterator();
        } else {
            itr = details.descendingIterator();
        }

        TemplateDetails tier;
        // till the lower boundary is reached, do not add the tier numbers
        // and in case the upper boundary is reached for this bay, stop adding the tier numbers
        while (itr.hasNext()) {
            tier = itr.next();

            if ((tier.getPk().getOffset() > maxTierOffset && isAscending)
                    || (tier.getPk().getOffset() < minTierOffset && !isAscending)) {
                break;
            }

            if ((tier.getPk().getOffset() < minTierOffset && isAscending)
                    || (tier.getPk().getOffset() > maxTierOffset && !isAscending)) {
                continue;
            }

            tierHeaders.append(tier.getVesselLabel()).append(ITEM_SEPERATOR);
        }

        tierHeaders.delete(tierHeaders.length() - 1, tierHeaders.length());

        return tierHeaders;
    }

    /**
     * <p> Generates the Tier headers for this bay. </p>
     * 
     * <p> Uses the min and max tier offsets to generate the actual vessel tier numbers. <p>
     * 
     * <p> If the Bay is under deck, the formula used to get the tier number is (offset*2)+2 </p> <p> Else, the formula
     * used is (offset*2)+80 </p>
     * 
     * @return tier Headers in the form 06^04^02(under deck) or 88^86^84^82^80(deck)
     */
    public StringBuilder tempGenerateTierHeaders() {
        StringBuilder tierHeaders = new StringBuilder();

        if (!this.isStdTierTemplate) {
            return getTierHeadersFromTemplate(true);
        }

        int tierNo;
        for (int tierOffset = minTierOffset; tierOffset <= this.maxTierOffset; tierOffset++) {
            tierNo = tierOffset * TWO;
            if (this.isUnderDeckIndicator()) {
                tierNo = tierNo + TWO;
            } else {
                tierNo = tierNo + EIGHTY;
            }

            if (tierNo >= TEN) {
                tierHeaders.append(tierNo).append(ITEM_SEPERATOR);
            } else {
                tierHeaders.append("0" + tierNo).append(ITEM_SEPERATOR);
            }
        }

        tierHeaders.delete(tierHeaders.length() - 1, tierHeaders.length());

        return tierHeaders;
    }
}
