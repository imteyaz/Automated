package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.INSPECTION_CHECKLIST;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.PlannedMovesRequestEvent;
import com.minapro.procserver.events.common.AlertEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.ConfirmAllocationResponseEvent;
import com.minapro.procserver.events.plc.PLCSchedulerEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the ConfirmAllocationResponseEvent. This event is issued only when ESB finds any
 * failure with confirming the allocation to the end point.</p>
 * 
 * <p> Once the event is received, it needs to be intimated to the user as alert. </p>
 * 
 * @author Rosemary George
 *
 */
public class ConfirmAllocationResponseActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ConfirmAllocationResponseActor.class);
    private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.TERMINAL_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof ConfirmAllocationResponseEvent) {
            ConfirmAllocationResponseEvent responseEvent = (ConfirmAllocationResponseEvent) message;

            if ("success".equalsIgnoreCase(responseEvent.getReason())) {
                logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(),
                        "Recieved success response for confirm allocation from ESB : " + responseEvent);

                OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());

                if (role.equals(OPERATOR.QC)) {

                    logger.logMsg(LOG_LEVEL.INFO, " ", " Current Operator Is QC Calling getPlannedMovesForQC()");
                    try {
                        getPlannedMovesForQC(responseEvent.getUserID());
                    } catch (Exception ex) {
                        logger.logException(
                                " Exception Occured While Getting Planned Moves Value For The Current User::", ex);
                    }

                }

                if (role.equals(OPERATOR.QC) || role.equals(OPERATOR.CHE)) {

                    logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(),
                            "Sending PLC Start Instruction to Scheduler :");
                    // Sending Start Instruction to PLC Scheduler
                    PLCSchedulerEvent plcscheduler = new PLCSchedulerEvent();
                    plcscheduler.setInstruction("start");
                    plcscheduler.setOperator(role.toString());
                    getSender().tell(plcscheduler, null);
                }

                sendInspectionCheckList(responseEvent);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, responseEvent.getUserID(),
                        "Recieved failure response for confirm allocation from ESB : " + responseEvent);

                sendAlertMessageToUser(responseEvent);
            }
        } else {
            unhandled(message);
        }
    }

    private void sendInspectionCheckList(ConfirmAllocationResponseEvent responseEvent) {
        User user = RDTCacheManager.getInstance().getUserDetails(responseEvent.getUserID());
        EventUtil.getInstance().sendInspectionCheckList(user, responseEvent, INSPECTION_CHECKLIST);

        OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());
        /**
         * CHE Operator No Need to send ITV Pool Request To ESB , Deriving ITV Pool From ATOM Itself.
         */
        if (role.equals(OPERATOR.QC) || role.equals(OPERATOR.HC) /*|| role.equals(OPERATOR.CHE)*/) {
            // Send request to get the ITVpool
        	EventUtil.getInstance().requestITVpool(responseEvent, role);
        }
    }    

    /**
     * Construct the Confirm allocation failure alert to the device
     * 
     * @param ConfirmAllocationResponseEvent
     */
    private void sendAlertMessageToUser(ConfirmAllocationResponseEvent alertEvent) {
        AlertEvent event = new AlertEvent();
        event.setEventID(alertEvent.getEventID());
        event.setUserID(alertEvent.getUserID());
        event.setEquipmentID(alertEvent.getEquipmentID());
        event.setTerminalID(alertEvent.getTerminalID());
        event.setTimeStamp(new Date().toString());
        event.setReason("Received Login failure message from TOS :" + alertEvent.getReason()
                + ". Please contact System Administrator.");
        event.setBeepRequired(false);

        EventUtil.getInstance().sendAlertMessageToUser(event);
    }

    /**
     * Method is responsible for getting PlannedMoves from ESB,for the logged in QC operator. Calling the PlannedMoves
     * value After got Confirm Allocation Success response from ESB.
     * 
     * @UmaMahesh
     * 
     */
    private void getPlannedMovesForQC(String currentUser) {

        logger.logMsg(LOG_LEVEL.INFO, currentUser, " Started getPlannedMovesForQC()");

        Equipment equipment = null;
        String pow = null;
        String rotationId = null;

        final RDTCacheManager rdtCache = RDTCacheManager.getInstance();
        PlannedMovesRequestEvent plannedMovesReqEvent = new PlannedMovesRequestEvent();
        List<PlannedMovesEvent> plannedMovesReqEvntList = new ArrayList<PlannedMovesEvent>();

        Device device = rdtCache.getDeviceDetails(rdtCache.getDeviceMapping(currentUser));

        if (device != null && device.getEquipment() != null) {

            equipment = device.getEquipment();

            pow = equipment.getPow();

            if (pow != null) {

                PlannedMovesEvent plannedMoveEvent = new PlannedMovesEvent();

                ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) rdtCache
                        .getAllocationDetails(currentUser);

                rotationId = allocationDetails.getRotationID();

                plannedMoveEvent.setUserID(currentUser);
                plannedMoveEvent.setEquipmentID(equipment.getEquipmentID());
                plannedMoveEvent.setPow(pow);
                plannedMoveEvent.setRotationId(rotationId);
                plannedMoveEvent.setTerminalID(TERMINAL_ID);
                plannedMoveEvent.setPlannedMoves(0);
                logger.logMsg(LOG_LEVEL.INFO, "", " Adding PlannedMoveEvent to List " + plannedMoveEvent.toString());
                plannedMovesReqEvntList.add(plannedMoveEvent);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, " ", "Pow is null in databse,First Update POW Value In Database");
            }

            plannedMovesReqEvent.setPlannedMovesRequest(plannedMovesReqEvntList);

            logger.logMsg(LOG_LEVEL.INFO, "", " Posting Data Into ESB Queue Manager " + plannedMovesReqEvent.toString());

            ESBQueueManager.getInstance().postMessage(plannedMovesReqEvent, OPERATOR.QC, TERMINAL_ID);

        } else {
            logger.logMsg(LOG_LEVEL.INFO, "", " Current User Role Is QC But Device And Equipment Mapping Was Not Done");
        }
    }
}
