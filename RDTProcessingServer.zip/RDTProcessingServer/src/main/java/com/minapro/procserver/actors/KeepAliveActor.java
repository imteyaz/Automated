package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TOS_STATUS_NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.KEEP_ALIVE_ERROR_MSG;

import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.KeepAliveRequestEvent;
import com.minapro.procserver.events.KeepAliveResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the TOS heart beat status requests and responses
 * @author Rosemary George
 *
 */
public class KeepAliveActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(KeepAliveActor.class);
	
	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY);
	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
	
	private static final String REQUEST_RECEIVED_LOG = "Received Keep Alive request event, posting to ESB";
	
	
	@Override
	public void onReceive(Object message) throws Exception {
		if(message instanceof KeepAliveRequestEvent){
			KeepAliveRequestEvent requestEvent = (KeepAliveRequestEvent) message;
			
			logger.logMsg(LOG_LEVEL.INFO, "", REQUEST_RECEIVED_LOG);
			ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.COMMON, TERMINAL_ID);			
			
		}else if(message instanceof KeepAliveResponseEvent){
			KeepAliveResponseEvent responseEvent = (KeepAliveResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, "", "Received keep alive message from ESB with status =" + responseEvent.isStatus());
			
			handleKeepAliveResponse(responseEvent);			
		}else {
			getSender().tell(message, null);
		}
	}

	/**
	 * Handles the keep alive status message from ESB. The keep alive status is updated in the system
	 * and a notification is generated to all logged-in users.
	 * 
	 * @param message
	 */
	private void handleKeepAliveResponse(KeepAliveResponseEvent responseEvent) {
		try {
			
			RDTCacheManager.getInstance().updateKeepAliveStatus(responseEvent.isStatus());
			
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(TOS_STATUS_NOTIF);
			
			StringBuilder response = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
			response.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString())
					.append(VALUE_SEPARATOR).append(responseEvent.isStatus())
					.append(VALUE_SEPARATOR);
			
			if(!responseEvent.isStatus()){
				response.append(KEEP_ALIVE_ERROR_MSG);
				markJobListStatusAsCompleted();
			}
			response.append(VALUE_SEPARATOR);

			Set<String> userList = RDTCacheManager.getInstance().getAllocatedUsers();
			if (userList != null && !userList.isEmpty()) {
				OPERATOR operatorRole;
				StringBuilder responseToDevice;
				for (String userId : userList) {
					responseToDevice = new StringBuilder(response);
					responseToDevice.append(userId).append(VALUE_SEPARATOR).append(TERMINAL_ID);
					
					operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
					CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole, TERMINAL_ID);
				}
			}			
		} catch (Exception e) {
			logger.logException("Caught exception while processing Keep alive response message -", e);
		}		
	}

	/**
	 * Marks the job list request status to completed for all the logged in users.
	 */
	private void markJobListStatusAsCompleted() {
		Set<String> userList = RDTCacheManager.getInstance().getAllocatedUsers();
		if(userList != null){
			String equipmentId;
			OPERATOR role;
			for(String userId:userList){
				role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
				if(OPERATOR.HC.equals(role)){
					equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(userId);
				}else {
					equipmentId = RDTPLCCacheManager.getInstance().getSignedInEquipmentIdForUser(userId);
				}
				
				if(equipmentId != null){
					logger.logMsg(LOG_LEVEL.INFO, userId, "OPUS DOWN - Setting job list status to completed- " + equipmentId);
					RDTCacheManager	.getInstance().setEqJobListReqStatus(equipmentId, EquipmentJobListRequestStatus.COMPLETED);
				}
			}
		}
	}
}
