package com.minapro.procserver.util;

/**
 * Final Class Holds the queries which are related to CHE Block Related Operations.
 * 
 * @author UMAMAHESH.M
 */
public final class BlockViewQueryStatements {
	
	public static final String BLK_TYPE = "X";

    public static final String YARD_ROWS_STACKS = "select ctr.stkCount,ctr.rowCount,ctr.maxStkgHt,ctr.wrkgStkgHt"
            + " from CtrblkYpm ctr"
            + " where ctr.intCtrBlkNo=(select blkArea.intBlkNo from BlkareaYpm blkArea where blkArea.blkId=:blockId)";

    public static final String ROW_OR_STACK_DATA = "select num.id.seqNo,num.no20ft,num.no40ft "
            + "from NumsrsdtlsYpm num " + "where num.id.numsrsId=:numsrsId ORDER BY num.id.seqNo";

    public static final String YARD_ROW_DATA = "SELECT R.id.rowSeqNo, R.blkRowNo,R.wrkgStkgHt"
            + " FROM BlkrowYpm R WHERE R.id.intBlkNo = "
            + "(select blkArea.intBlkNo from BlkareaYpm blkArea where blkArea.blkId=:blockId)"
            + " ORDER BY R.id.rowSeqNo";

    public static final String YARD_STACK_DATA = " SELECT S.id.stkSeqNo, S.blkStkNo ,S.stkNo40"
            + " FROM BlkareaYpm B, BlkstkYpm S WHERE S.id.intBlkNo = "
            + " (select blkArea.intBlkNo from BlkareaYpm blkArea where blkArea.blkId=:blockId) "
            + " AND B.intBlkNo = S.id.intBlkNo and B.blkType != 'X' " + " ORDER BY S.id.stkSeqNo";

    public static final String YARD_BLOCK_CELL_DATA = "select B.intBlkNo as blkAreaBlkNo," + "B.blkId as blkAreaBlkId,"
            + "CTR.rowCount as rowCount, CTR.stkCount as stkCount,S.id.stkSeqNo as blkStkSeqNo,"
            + "S.blkStkNo,R.id.rowSeqNo as rowSeqNo,R.blkRowNo as blkRowNo,"
            + "CTR.wrkgStkgHt as wrkgStkgHt , CTR.maxStkgHt as maxStkgHt"
            + " FROM BlkareaYpm B, BlkstkYpm S, BlkrowYpm R, CtrblkYpm CTR"
            + " WHERE S.id.intBlkNo =(select intBlkNo from BlkareaYpm where blkId =:blockId )"
            + " AND B.intBlkNo = S.id.intBlkNo" + " AND B.blkType != '" + BLK_TYPE + "'"
            + " AND R.id.intBlkNo = B.intBlkNo" + " AND R.id.intBlkNo = S.id.intBlkNo"
            + " AND B.intBlkNo = CTR.intCtrBlkNo " + " ORDER BY R.id.rowSeqNo,S.id.stkSeqNo";

    /**
     * Query is used to retrieve the maximum number of stacks,rows,tiers information related to one block
     *     // R.BLK_ROW_NO DESC, S.BLK_STK_NO ASC
     */
    public static final String YARD_PARAMETERS = "SELECT MAX(CTR.maxStkgHt) as maxStkgHt,"
            + "MAX(CTR.rowCount) as rowCount AS ROW_COUNT," + "MAX(CTR.stkCount) as stkCount "
            + "FROM BlkareaYpm B, BlkstkYpm S, BlkrowYpm R, CtrblkYpm CTR"
            + " WHERE S.id.intBlkNo =(select intBlkNo from BlkareaYpm where blkId =:blockId ) "
            + " AND B.intBlkNo = S.id.intBlkNo " + " AND B.blkType != '" + BLK_TYPE + "'"
            + " AND R.id.intBlkNo = B.intBlkNo" + " AND R.id.intBlkNo = S.id.intBlkNo"
            + " AND B.intBlkNo = CTR.intCtrBlkNo " + " ORDER BY R.id.rowSeqNo,S.id.stkSeqNo";


  public static final String GET_BLOCK_CELL_POSITION =  "SELECT R.WRKG_STKG_HT FROM MP_BLKAREA_YPM B, MP_BLKSTK_YPM S, MP_BLKROW_YPM R "
				+ " WHERE S.INT_BLK_NO =(SELECT INT_BLK_NO FROM MP_BLKAREA_YPM WHERE BLK_ID = :blockNumber) "
				+ " AND B.INT_BLK_NO = S.INT_BLK_NO "
				+ " AND R.INT_BLK_NO = B.INT_BLK_NO "
				+ " AND S.INT_BLK_NO = R.INT_BLK_NO "
				+ " AND R.BLK_ROW_NO = :rowName "
				+ " AND (S.BLK_STK_NO = :stkNumber OR s.stk_no_40 = :stkNumber)";

	private BlockViewQueryStatements(){		
	}
}
