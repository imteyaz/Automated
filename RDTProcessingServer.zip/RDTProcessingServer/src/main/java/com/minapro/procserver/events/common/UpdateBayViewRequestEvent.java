package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details for Bay view update request. This event is fired to ESB when server detects the
 * containers present in an operators job list is not available in the bay profile. This can happen if container's
 * stowage position is not yet updated in the planning system.
 * 
 * @author Rosemary George
 *
 */
public class UpdateBayViewRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -3621012413148233622L;

    /**
     * Contains list of container IDs which doesn't exist in the BayProfile
     */
    private List<String> updateRequiredContainerList;

    /**
     * Indicates the rotation id of ship to which the containers belongs to
     */
    private String rotationID;

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    public List<String> getUpdateRequiredContainerList() {
        return updateRequiredContainerList;
    }

    public void setUpdateRequiredContainerList(List<String> updateRequiredContainerList) {
        this.updateRequiredContainerList = updateRequiredContainerList;
    }

    @Override
    public String toString() {
        return "UpdateBayViewRequestEvent [updateRequiredContainerList=" + updateRequiredContainerList
                + ", rotationID=" + rotationID + ", UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID() + "]";
    }
}
