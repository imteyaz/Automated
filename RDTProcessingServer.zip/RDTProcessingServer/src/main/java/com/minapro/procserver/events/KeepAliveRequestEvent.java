package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject requesting the TOS heart beat status
 * @author Rosemary George
 *
 */
public class KeepAliveRequestEvent extends Event implements Serializable {
	
	private static final long serialVersionUID = 135046101773717686L;

	@Override
	public String toString() {
		return "KeepAliveRequestEvent [TerminalID=" + getTerminalID() + ", EventID=" + getEventID() + "]";
	}
}
