package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entity Class holding the Back reach jobs. The back reach jobs are classified per rotation and based on the type and
 * move type.
 * 
 * Any operation happens to the back reach side will be captured and recorded. It can be Hatch cover, Break Bulk, Man
 * Cage or Container
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_BACKREACH_JOBS")
public class BackReachJobs implements Serializable {

    private static final long serialVersionUID = -9021460421325383022L;

    @EmbeddedId
    private BackReachPK pk;

    @Column(name = "BACKREACH_TYPE", nullable = false)
    private String jobType;

    @Column(name = "MOVE_TYPE", nullable = false)
    private String moveType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "QC_ID", referencedColumnName = "EQUIPMENT_ID")
    private Equipment qcId;

    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDateTime;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CREATED_BY", referencedColumnName = "USER_NM")
    private User createdBy;

    @Column(name = "FROM_LOCATION", nullable = false)
    private String fromLocation;

    @Column(name = "TO_LOCATION", nullable = false)
    private String toLocation;

    @Column(name = "INDEX_VAL", nullable = false)
    private Integer uniqueIndex;

    public BackReachPK getPk() {
        return pk;
    }

    public void setPk(BackReachPK pk) {
        this.pk = pk;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public Equipment getQcId() {
        return qcId;
    }

    public void setQcId(Equipment qcId) {
        this.qcId = qcId;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public Integer getUniqueIndex() {
        return uniqueIndex;
    }

    public void setUniqueIndex(Integer uniqueIndex) {
        this.uniqueIndex = uniqueIndex;
    }

    @Override
    public String toString() {
        return "BackReachJobs [pk=" + pk + ", jobType=" + jobType + ", moveType=" + moveType + ", qcId=" + qcId
                + ", createdDateTime=" + createdDateTime + ", createdBy=" + createdBy + ", fromLocation="
                + fromLocation + ", toLocation=" + toLocation + ", uniqueIndex=" + uniqueIndex + "]";
    }
}
