package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.AH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING_MINIMIZE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_MOVE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.CHEPLCJobdoneEvent;
import com.minapro.procserver.events.plc.ContainerScreenMinimizeEvent;
import com.minapro.procserver.events.plc.ManualConfirmationAlertEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * 
 * <p> Actor responsible for Sending job done to containerMove Actor <p>
 * 
 * @author Kumaraswamy
 * 
 */
public class CHEPLCJobdoneActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEPLCJobdoneActor.class);

	private static final String TRUCK_IDENTIFIER = "T";
	private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

	private static final String EXPRESSION_STR = "[\\.]";
	private static final String CONTR_FROM_LOC_STR = " Type Container From Location -- ";
	private static final String CONTR_TO_LOC_STR = " Container To Location -- ";
	private static final String CONTR_YARD_LOCK_POS = " Container Yard Lock Position -- ";

	String lockPosition = null;
	String lockContainerId = null;

	@Override
	/**
	 * Handles  CHEPLCJobdoneEvent
	 */
	public void onReceive(Object message) throws Exception {

		if (message instanceof CHEPLCJobdoneEvent) {
			CHEPLCJobdoneEvent jobDoneEvent = (CHEPLCJobdoneEvent) message;
			logger.logMsg(LOG_LEVEL.DEBUG, " ", " RECEIVED JOB DONE::" + jobDoneEvent);
			handlePLCJobDoneEvent(jobDoneEvent);
		} else {
			unhandled(message);
		}
	}

	public void handlePLCJobDoneEvent(CHEPLCJobdoneEvent jobDoneEvent) {

		String node = jobDoneEvent.getNode();
		String userId = jobDoneEvent.getUserId();

		boolean isJobdone = true;
		boolean containerPlacedInTruck = false;
		String yardPositionWhenLock = null;
		String yardPositionWhenUnLock = null;
		String moveType = null;
		String containerId = null;
		String jobFromLocation = null;
		String jobToLocation = null;

		boolean containerFoundStatus = false;

		try {

			/* Resetting following flags for the next move */
			RDTPLCCacheManager.getInstance().addSpreaderSizeCapturedeDetails(userId + "spreader1_twist_lock", false);
			RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, false);
			String lockContainerPositionDetails = RDTPLCCacheManager.getInstance()
					.getUserToFromLocationAndContainerDetails(userId);

			logger.logMsg(LOG_LEVEL.DEBUG, userId, " Lock Position Details ContainerId and FromLocation-- "
					+ lockContainerPositionDetails);

			if (lockContainerPositionDetails != null) {
				String[] containerAndLocation = lockContainerPositionDetails.split("-");
				lockContainerId = containerAndLocation[0];
				lockPosition = containerAndLocation[1];
			}

			ContainerMoveEvent movement = new ContainerMoveEvent();

			logger.logMsg(LOG_LEVEL.DEBUG, userId, " Un Lock Position -- " + jobDoneEvent.getUnLockYardPosition());

			ListOrderedMap<String, JobListContainer> jobsInCache = RDTCacheManager.getInstance().getJobList(userId,
					jobDoneEvent.getEquipmentID());
			Collection<JobListContainer> jobs = jobsInCache.values();
			logger.logMsg(LOG_LEVEL.DEBUG, userId, " Job List Size -- " + jobs.size());

			for (JobListContainer job : jobs) {

				jobFromLocation = job.getFromLocation() != null ? job.getFromLocation().replaceAll(EXPRESSION_STR, "")
						: "";
				jobToLocation = job.getToLocation() != null ? job.getToLocation().replaceAll(EXPRESSION_STR, "") : "";
				// Checking the JobList container from Location data length
				// with yard Position data length.

				moveType = job.getMoveType();
				logger.logMsg(LOG_LEVEL.DEBUG, userId, job.getContainerId() + " Move Type -- " + moveType);
				// AH & RH

				if (MI.equalsIgnoreCase(moveType) || DSCH.equalsIgnoreCase(moveType) || GI.equalsIgnoreCase(moveType)) {
					yardPositionWhenUnLock = getParsedYardLocation(jobDoneEvent.getUnLockYardPosition(), jobToLocation);
					if (jobToLocation.equals(yardPositionWhenUnLock)) {
						containerId = job.getContainerId();
						containerFoundStatus = true;
						break;
					}
				} else if (RH.equalsIgnoreCase(moveType)) {
					yardPositionWhenLock = getParsedYardLocation(jobDoneEvent.getLockYardPosition(), jobFromLocation);
					yardPositionWhenUnLock = getParsedYardLocation(jobDoneEvent.getUnLockYardPosition(), jobToLocation);
					if (jobFromLocation.equals(yardPositionWhenLock) || jobToLocation.equals(yardPositionWhenUnLock)) {
						containerId = job.getContainerId();
						containerFoundStatus = true;
						break;
					}
				}

				logger.logMsg(LOG_LEVEL.DEBUG, userId, moveType + CONTR_FROM_LOC_STR + jobFromLocation);
				logger.logMsg(LOG_LEVEL.DEBUG, userId, moveType + CONTR_TO_LOC_STR + jobToLocation);
				logger.logMsg(LOG_LEVEL.DEBUG, userId, moveType + CONTR_YARD_LOCK_POS + yardPositionWhenLock);
				logger.logMsg(LOG_LEVEL.DEBUG, userId, moveType + " Container Yard Un Lock Position -- "
						+ yardPositionWhenUnLock);

				if ((jobDoneEvent.getMoveYardPosition() != null && jobDoneEvent.getMoveYardPosition().contains("Lane"))
						&& lockContainerId != null && lockContainerId.equalsIgnoreCase(job.getContainerId())) {
					containerId = job.getContainerId();
					containerFoundStatus = true;
					break;
				} else if ((jobDoneEvent.getMoveYardPosition() != null && jobDoneEvent.getMoveYardPosition().contains(
						"Yard"))
						&& (moveType.equalsIgnoreCase(MO) || moveType.equalsIgnoreCase(RH) || job.getMoveType()
								.equalsIgnoreCase(AH))
						&& lockContainerId != null
						&& lockContainerId.equalsIgnoreCase(job.getContainerId())) {
					containerId = job.getContainerId();
					containerFoundStatus = true;
					break;
				}
			}

			if (lockPosition != null && lockPosition.equalsIgnoreCase(yardPositionWhenUnLock)) {
				isJobdone = false;
			}

			// Check any job selected by the user for job confirmation.
			if (!containerFoundStatus) {
				logger.logMsg(LOG_LEVEL.DEBUG, userId, " Checking any job selected by User using Job Selection  -- ");
				if (RDTPLCCacheManager.getInstance().getUserToContainerDetails(userId) != null
						&& RDTPLCCacheManager.getInstance().getUserToFromLocationAndContainerDetails(userId) != null) {
					containerId = RDTPLCCacheManager.getInstance().getUserToContainerDetails(userId);
					logger.logMsg(LOG_LEVEL.DEBUG, userId, " Job selected by User using Job Selection  -- "
							+ containerId);

					if (containerId != null) {
						for (JobListContainer job : jobs) {
							if (containerId.equalsIgnoreCase(job.getContainerId())) {
								logger.logMsg(LOG_LEVEL.DEBUG, userId, " Found the container Selected by User  -- "
										+ containerId);
								moveType = job.getMoveType();
								break;
							}
						}
					}
				}
			}

			// If it is a proper job done
			if (isJobdone) {
				logger.logMsg(LOG_LEVEL.DEBUG, " ", ":Container Id based on PLC YardLocation :" + containerId);

				// Checking the Container is placed in Yard or Truck.
				if (jobDoneEvent.getUnLockYardPosition().length() > 0
						&& jobDoneEvent.getUnLockYardPosition().contains(".")
						&& jobDoneEvent.getUnLockYardPosition().split("\\.")[1].contains(TRUCK_IDENTIFIER)) {

					containerPlacedInTruck = true;
				}
				
				// if user select or default seelcted container does not match with unloaction container id then
				// raised alert

				// Sending Automatic Job Done Event to Device
				logger.logMsg(LOG_LEVEL.DEBUG, " ", userId + " CHE Sending Job done Event of User :" + userId);
				
				if (containerId != null) {
					// Check the Container placed in planned yard Location for DISH, RECV & YARD.
					if (!containerPlacedInTruck) {
						// Send alert to the user for Wrong planned position.
						createNonPlannedPositionAlert(userId, node, containerId, jobToLocation, yardPositionWhenUnLock);
					}

					movement = constructContainerMoveEvent(userId, node, containerId, moveType);
					RDTPLCCacheManager.getInstance().removeUserToContainerDetails(userId);

					RDTPLCCacheManager.getInstance().removeUserToFromLocationAndContainerDetails(userId);

					if (moveType != null) {
						movement.setMoveType(moveType);
					}
					logger.logMsg(LOG_LEVEL.DEBUG, " ", " Container Move Event  :" + movement);
					// Sending job done to container Move Actor
					getSender().tell(movement, null);

				} else {
					initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);
					manualConfirmationAlertEvent(userId, DATE_FORMATTER);
				}
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, " ",
						" CHE Ignore Detection since Container Lifted and placed at same location:  :" + userId);

				// Initiating Container Minimize event to minimize.
				initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);
			}
			// Resetting tandem flag for next move
		} catch (Exception e) {
			// Initiating Container Minimize event to ui.
			initaiteContainerMinimizeEvent(userId, DATE_FORMATTER);
			manualConfirmationAlertEvent(userId, DATE_FORMATTER);

			// Ignore PLC reading for the next move, since it needs to be
			// confirmed manually
			logger.logException("Caught exception while processing CHE PLCJobdoneActor - ", e);
		}
	}

	/**
	 * Constructs the containerMoveEvent
	 * 
	 * @param userId
	 * @param node
	 * @param containerId
	 * @return
	 */
	private ContainerMoveEvent constructContainerMoveEvent(String userId, String node, String containerId,
			String moveType) {
		ContainerMoveEvent containerMove = new ContainerMoveEvent();

		containerMove.setEventType(DeviceEventTypes.getInstance().getEventType(CONTAINER_MOVE));
		containerMove.setUserID(userId);
		containerMove.setTimeStamp(DATE_FORMATTER.format(new Date()));
		containerMove.setEventID(UUID.randomUUID().toString());
		containerMove.setEquipmentID(node);
		containerMove.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
		containerMove.setAutomaticFlag(true);

		if (moveType != null) {
			containerMove.setMoveType(moveType);
		} else {
			containerMove.setMoveType(DSCH);
		}

		ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId, node);
		String jobType = RDTPLCCacheManager.getInstance().getCurrentJobType(userId);
		if (jobList != null) {
			
			if (!"TWIN".equals(jobType)) {
				containerMove.setContainerIDs(containerId);

				logger.logMsg(LOG_LEVEL.DEBUG, userId, " CHE Container Id  :" + containerId + "  :: MoveType :: "
						+ moveType);

				containerMove.setFromLocations(jobList.get(containerId + moveType).getFromLocation());
				containerMove.setToLocations(jobList.get(containerId + moveType).getToLocation());
			} else {

				logger.logMsg(LOG_LEVEL.DEBUG, userId, " CHE Container Id  :" + containerId + "  :: MoveType :: "
						+ moveType);

				JobListContainer twinContainer = jobList.get(jobList.get(containerId + moveType).getTwinContainerId());
				containerMove.setContainerIDs(containerId + ROW_SEPARATOR + twinContainer.getContainerId());
				containerMove.setFromLocations(jobList.get(containerId+ moveType).getFromLocation() + ROW_SEPARATOR
						+ twinContainer.getFromLocation());

				containerMove.setToLocations(jobList.get(containerId+ moveType).getToLocation());
			}
		}
		containerMove.setMoveType(moveType);

		return containerMove;
	}

	/**
	 * 
	 * <p> Responsible for sending container minimize event to master Actor. Just to avoid the container handling screen
	 * hanging if job done detection fails </p>
	 * 
	 * @param userId
	 * @param formatter
	 */
	private void initaiteContainerMinimizeEvent(String userId, SimpleDateFormat formatter) {
		logger.logMsg(LOG_LEVEL.DEBUG, " ", "Send Container Screen Minimize Event :" + userId);

		ContainerScreenMinimizeEvent screenMinimizer = new ContainerScreenMinimizeEvent();

		// setting Container screen minimize Event to device
		String eventTypeID = DeviceEventTypes.getInstance().getEventType(CONTAINER_HANDLING_MINIMIZE);

		screenMinimizer.setUserID(userId);
		screenMinimizer.setTimeStamp(formatter.format(new Date()));
		screenMinimizer.setEventType(eventTypeID);
		screenMinimizer.setEventID(UUID.randomUUID().toString());
		screenMinimizer.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
		screenMinimizer.setMessage("Minimize");

		getSender().tell(screenMinimizer, null);
	}

	/**
	 * 
	 * <p> Responsible for sending manual confirmation to the ManualConfirmationEvent. </p>
	 * 
	 * @param userId
	 * @param formatter
	 */
	private void manualConfirmationAlertEvent(String userId, SimpleDateFormat formatter) {
		logger.logMsg(LOG_LEVEL.DEBUG, " ", " CHE Waiting for Manual Confirmation:" + userId);
		ManualConfirmationAlertEvent manualConfirmationAlert = new ManualConfirmationAlertEvent();
		manualConfirmationAlert.setUserID(userId);
		manualConfirmationAlert.setTimeStamp(formatter.format(new Date()));
		manualConfirmationAlert.setEventID(UUID.randomUUID().toString());
		manualConfirmationAlert.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
		manualConfirmationAlert.setReason("Unable to find the Location,Please confirm this move manually");
		PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(manualConfirmationAlert);
	}

	/**
	 * 
	 * <p> Responsible to Parse the yardLocation which is provided by RMG PLC when lock/unlock time </p>
	 * 
	 * @param yardLocationStr
	 * @param jobLocation
	 */
	private String getParsedYardLocation(String yardLocationStr, String jobLocation) {
		String parsedLocation = yardLocationStr.replaceAll("[\\s.]", "");
		if (parsedLocation.length() > jobLocation.length() && parsedLocation.length() > 7) {
			parsedLocation = parsedLocation.substring(0, 3) + parsedLocation.substring(4, parsedLocation.length());
		}

		return parsedLocation;
	}

	/**
	 * Creates non-planned position alert and pass to MasterActor for further processing
	 * 
	 * @param userId
	 * @param equipmentId
	 * @param containerId
	 * @param plannedPosition
	 * @param plcDetectedLocation
	 */
	private void createNonPlannedPositionAlert(String userId, String equipmentId, String containerId,
			String plannedPosition, String plcDetectedLocation) {
		if (!plannedPosition.equalsIgnoreCase(plcDetectedLocation)) {
			MinaProAlertEvent alert = new MinaProAlertEvent();
			alert.setAlertCode(ALERTCODE.CHE_WRONG_POS_ALERT);
			alert.setEquipmentID(equipmentId);
			alert.setOperatorId(userId);
			alert.setUserID(userId);
			alert.setActualLocation(plcDetectedLocation);
			alert.setPlannedLocation(plannedPosition);
			alert.setContainerId(containerId);
			logger.logMsg(LOG_LEVEL.DEBUG, userId, "Generating alert : CHE_WRONG_POS_ALERT for " + equipmentId);
			RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
		}
	}
}
