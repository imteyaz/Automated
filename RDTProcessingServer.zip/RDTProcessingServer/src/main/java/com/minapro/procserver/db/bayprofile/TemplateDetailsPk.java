package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the primary key for the Template details
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class TemplateDetailsPk implements Serializable {

    private static final long serialVersionUID = 2454206915273897222L;

    @Column(name = "NUMSRS_ID")
    private String headerId;

    @Column(name = "SEQ_NO")
    private Integer offset;

    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((headerId == null) ? 0 : headerId.hashCode());
        result = prime * result + ((offset == null) ? 0 : offset.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        TemplateDetailsPk other = (TemplateDetailsPk) obj;
        if (headerId == null) {
            if (other.headerId != null) {
                return false;
            }
        } else if (!headerId.equals(other.headerId)) {
            return false;
        }
        if (offset == null) {
            if (other.offset != null) {
                return false;
            }
        } else if (!offset.equals(other.offset)) {
            return false;
        }
        return true;
    }
}
