package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.STACK_VIEW_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.events.che.StackViewRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class StackViewRequestActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(StackViewRequestActor.class);

	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);



	@Override
	public void onReceive(Object message) throws Exception {
		
		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(ON_RECEIVE).toString());

		if (message instanceof StackViewRequestEvent) {

			StackViewRequestEvent stackViewReq = (StackViewRequestEvent) message;
			handleStackViewRequest(stackViewReq);
		}

	}

	
	public void handleStackViewRequest(StackViewRequestEvent stackViewReq)  {

		try {

			if(stackViewReq.getBlockNumber()==null || stackViewReq.getBlockNumber().isEmpty() || stackViewReq.getStackNumber()==null || stackViewReq.getStackNumber().isEmpty()) {

				logger.logMsg(LOG_LEVEL.ERROR,stackViewReq.getUserID()," Block Number/Stack Number Is Null , UnAble To Proceed Further");
				sendEmptyResponseFromStackView(stackViewReq);
				return;
			}

			BlockProfile blockProfile = RDTYardProfileCacheManager.getInstance().getBlockToYardProfile(stackViewReq.getBlockNumber());

			if(blockProfile!=null) {

				String stackSeqNumbersToDisplay = BlockProfileUtil.getInstance().doProcessForRequestedStackNumber(stackViewReq);

				logger.logMsg(LOG_LEVEL.INFO,""," Stack Seq Numbers For Stack View Are::"+stackSeqNumbersToDisplay);

				if(null!=stackSeqNumbersToDisplay){
					sendStackViewResponse(stackViewReq, stackSeqNumbersToDisplay);
				} else {
					sendEmptyResponseFromStackView(stackViewReq);
				}

			}else {
				
				logger.logMsg(LOG_LEVEL.ERROR,stackViewReq.getUserID(),stackViewReq.getBlockNumber().concat(" Block Profile Is Not Defined,Send Empty Response--"));
				sendEmptyResponseFromStackView(stackViewReq);
			}
			
		} catch (Exception ex) {
		
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" OnReceive() ").append(REASON)
					.toString(), ex);
			sendEmptyResponseFromStackView(stackViewReq);
		}


	}
	private void sendStackViewResponse(StackViewRequestEvent stackReq, String stackSeqNumber) {

		logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendStackViewResponse()").append(INPUT)
				.append(stackReq.toString()).toString());

		String blockNumber = stackReq.getBlockNumber();

		StringBuilder responseToDevice = new StringBuilder(RESP ).append( VALUE_SEPERATOR ).
				append(DeviceEventTypes.getInstance().getEventType(STACK_VIEW_RESPONSE)).
				append( VALUE_SEPERATOR).append( stackReq.getEventID() ).append( VALUE_SEPERATOR);

		try {

			int blockMaxWorkingTier = RDTYardProfileCacheManager.getInstance().getMaxWorkingTierForBLock(stackReq.getBlockNumber());
			int requestedStackSeqNumber = Integer.parseInt(stackSeqNumber);

			blockMaxWorkingTier = (blockMaxWorkingTier==0 ? 6 : blockMaxWorkingTier);

			logger.logMsg(LOG_LEVEL.INFO,blockNumber.concat(stackSeqNumber)," Requested Block Maximum Wirking Stk Height Is::"+blockMaxWorkingTier);

			responseToDevice.append(RDTYardProfileCacheManager.getInstance().getBlockRelatedStockData(blockNumber).get(stackSeqNumber)).
			append(VALUE_SEPERATOR).append(BlockProfile.prepareRowData(blockNumber,false)).append(VALUE_SEPERATOR).
			append(BlockProfile.prepareStackView(stackReq,requestedStackSeqNumber-1,blockMaxWorkingTier)).
			append(VALUE_SEPERATOR).append(blockMaxWorkingTier).append(VALUE_SEPERATOR).
			append(stackReq.getUserID()).append(VALUE_SEPERATOR).append(stackReq.getTerminalID());

			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), RDTCacheManager.getInstance().getUserLoggedInRole(stackReq.getUserID()),
					stackReq.getTerminalID());



		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" sendStackViewResponse() ").append(REASON)
					.toString(), ex);
		}

	}

	public void sendEmptyResponseFromStackView(StackViewRequestEvent stackReq){

		logger.logMsg(LOG_LEVEL.INFO, stackReq.getUserID(), " Started sendEmptyResponse()");

		StringBuilder responseToDevice = new StringBuilder(RESP ).append( VALUE_SEPERATOR ).
				append(DeviceEventTypes.getInstance().getEventType(STACK_VIEW_RESPONSE) ).append( VALUE_SEPERATOR).append( stackReq.getEventID() ).append( VALUE_SEPERATOR);

		responseToDevice.append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(VALUE_SEPERATOR)
		.append(stackReq.getUserID()).append(VALUE_SEPERATOR)
		.append(stackReq.getTerminalID());

		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), RDTCacheManager.getInstance().getUserLoggedInRole(stackReq.getUserID()),
				stackReq.getTerminalID());
	}

}
