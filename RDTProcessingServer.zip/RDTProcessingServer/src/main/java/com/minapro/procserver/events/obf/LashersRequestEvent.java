package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Holding foreman request for getting Logged in Lashers.
 * 
 * @author UMAMAHESH M
 *
 */
public class LashersRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -7464379637394114326L;

    @Override
    public String toString() {
        return "LashersRequestEvent [getUserID()=" + getUserID() + "]";
    }
}
