package com.minapro.procserver.opus.util;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OPUS_TANDEM_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OPUS_TWIN_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TANDEM_JOB_TYPE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TWIN_JOB_TYPE;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.minapro.procserver.db.TwinTandemContainerList;
import com.minapro.procserver.db.TwinTandemJobs;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.db.opus.joblist.OPUSQCJobListEntity;
import com.minapro.procserver.db.opus.joblist.OpusQCJobListDAO;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.OPUSTwinTandemJobsPOJO;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;


public class OpusQcJobListService {
	
	private static final OpusQcJobListService INSTNACE = new OpusQcJobListService();
	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(OpusQcJobListService.class);
	
	public static final String YES = "Y";
	public static final String NO  = "N";
	
	private static final OpusQCJobListDAO DAO = OpusQCJobListDAO.getInstnace();

	List<OPUSQCJobListEntity> fourTwentyTandemJobsList = new ArrayList<OPUSQCJobListEntity>(4);

	private OpusQcJobListService(){

	}

	public static OpusQcJobListService getInstnace(){
		return INSTNACE;
	}

	/*
	 * When ESB Insert data into OPUS Job List At that time ESB Won't insert the Reference Container.
	 *  
	 * @param terminalId
	 * @param rotationId
	 * @param equipmentId
	 * @return List of Available Twin/Tandem JobList(OPUSQCJobListEntity) jobs.
	 * @throws NullPointerException
	 * @throws SQLException
	 */
	public List<OPUSQCJobListEntity> getTwinAndTandemJobsWithOutRefCntrs(final String terminalId ,final String rotationId , 
			final String equipmentId,final String[] vesselVoyage) throws NullPointerException, SQLException{

		final String logId = rotationId.concat("-").concat(equipmentId);

		LOGGER.logMsg(LOG_LEVEL.INFO,logId, " Started Twin And Tandem Jobs Without Reference Containers Method.");

		List<OPUSQCJobListEntity> twinTandemJobs = DAO.getTwinAndTandemFromJobList(terminalId, rotationId, equipmentId,vesselVoyage);

		LOGGER.logMsg(LOG_LEVEL.TRACE,logId,new StringBuilder("Current Refresh OPUS Created TWin/Tandem Jobs WithOut Ref Cntrs Data Is::").
				append(twinTandemJobs!=null ? twinTandemJobs.toString() : null).toString());

		return twinTandemJobs;
	}

	/*
	 * Updating the JobList Table with Reference Container Along With Sequnce Number for OPUS created Twin/Tandem Jobs.
	 */
	public void updateOpusJobList(List<OPUSQCJobListEntity> currentRefreshTwinTandemJobs) 
			throws NullPointerException, SQLException {

		DAO.updateOPUSQcJobList(currentRefreshTwinTandemJobs);

	}

	/*
	 * Method is responsible for Setting Reference Container to the Existed Twin And Tandem Jobs Based on Following Business Logic.
	 * Business Logic : Check Twin Tandem Id , If Job is Twin check for another reference Twin Id and update those two jobs with container.
	 * If job is 2*40 Tandem Follow above step , If job is 4*20 Tandem(Finding it based on location.), 
	 * OPUS job list contains same tandem id for 4 jobs club all those based on TwinTandemId.
	 * 
	 * @param List<OPUSQCJobListEntity> twinTandemJobs
	 * 
	 */
	public void setReferenceContainer(List<OPUSQCJobListEntity> twinTandemJobs) {
		//TO Find the Reference Container, Applying Self Join logic on List.

		for(OPUSQCJobListEntity mainEntity : twinTandemJobs) {

			String mainContainerId = mainEntity.getId().getContainerId();
			String mainTwinTandemCode = mainEntity.getTwinTandemCd();
			String mainTwinTandemId = mainEntity.getExistedTwinTandemIdFromTable();

			for(OPUSQCJobListEntity subEntity : twinTandemJobs) {

				if(OPUS_TWIN_CODE.equalsIgnoreCase(mainTwinTandemCode) && 
						(mainTwinTandemId.equalsIgnoreCase(subEntity.getExistedTwinTandemIdFromTable()))
						&& (!mainContainerId.equalsIgnoreCase(subEntity.getId().getContainerId()))) {

					mainEntity.setRefContainerId(subEntity.getId().getContainerId());
					//setSeqNumber(mainEntity,subEntity);
					break;

				} else if(OPUS_TANDEM_CODE.equalsIgnoreCase(mainTwinTandemCode) && 
						(mainTwinTandemId.equalsIgnoreCase(subEntity.getExistedTwinTandemIdFromTable()))
						&& ( !mainContainerId.equalsIgnoreCase(subEntity.getId().getContainerId()))) {


					if(JobListUtil.isItTwoFortyTandem(getVesselLocation(mainEntity))) {
						mainEntity.setRefContainerId(subEntity.getId().getContainerId());
						//setSeqNumber(mainEntity,subEntity);
					} else {
						setRefAndTandemCntrFor4TwentyTandem(mainEntity,twinTandemJobs);
					}

					break;
				}
			}

		}

	}

	public static void setSeqNumber(OPUSQCJobListEntity mainEntity,
			OPUSQCJobListEntity subEntity) {

		if(mainEntity.getSeqNo() > subEntity.getSeqNo()) {
			mainEntity.setSeqNo(subEntity.getSeqNo() + 0.1);
		}


	}

	private static void setRefAndTandemCntrFor4TwentyTandem(OPUSQCJobListEntity mainEntity , List<OPUSQCJobListEntity> twinTandemJobs){


		String[] bayRowTier = JobListUtil.getBayRowTier(getVesselLocation(mainEntity));

		String tandemContainers = "" ;

		String mainContainerId     = mainEntity.getId().getContainerId();

		//double mainSeqNumber = mainEntity.getSeqNo();

	//	boolean temp = true;


		for(OPUSQCJobListEntity subEntity : twinTandemJobs) {

			String[] subEntityBayRowTier = JobListUtil.getBayRowTier(getVesselLocation(subEntity));

			if(OPUS_TANDEM_CODE.equalsIgnoreCase(subEntity.getTwinTandemCd()) && (mainEntity.getExistedTwinTandemIdFromTable().equalsIgnoreCase(subEntity.getExistedTwinTandemIdFromTable()))
					&& (!mainContainerId.equalsIgnoreCase(subEntity.getId().getContainerId()))){

				//If job is 4*20 tandem At that time we needed rest of the three partners container numbers.
				tandemContainers = tandemContainers.concat(subEntity.getId().getContainerId()).concat(",");

				//Following condition is used to find out the reference container for current job based on location.

				if((!subEntityBayRowTier[0].equals(bayRowTier[0])) && 
						(subEntityBayRowTier[1].equalsIgnoreCase(bayRowTier[1])) && 
						(subEntityBayRowTier[2].equalsIgnoreCase(bayRowTier[2]))){
					
					mainEntity.setRefContainerId(subEntity.getId().getContainerId());
					
					subEntity.setRefContainerId(mainContainerId);
					//subEntity.setSeqNo(mainSeqNumber+0.10);
					
				} /*else {
					
					//Which means sequence number already modified.
					if(subEntity.getSeqNo() - (int)subEntity.getSeqNo()==0){
						continue;
					}
					//Setting seq numbers for other twin job in  4*20 Tandem jobs. 
					subEntity.setSeqNo(temp?mainSeqNumber+0.20:mainSeqNumber+0.30);
					temp = false;
				}*/

			}
		}
		if(!"".equalsIgnoreCase(tandemContainers) && tandemContainers.length() > 0){
			tandemContainers = tandemContainers.substring(0,tandemContainers.length()-1);
			mainEntity.setTandemContainers(tandemContainers);
		}
	}


	private static String getVesselLocation(OPUSQCJobListEntity entity) {

		return "DSCH".equalsIgnoreCase(entity.getId().getMoveKind())  ? entity.getFromLocation() : entity.getToLocation();
	}

	/*
	 * Step 2.1 Method is responsible for checking the existed Sparks created twin container list with the current
	 * retrieved twin jobs list based on some business conditions. Depending on the business condition updating the
	 * OperationCode and MinaProTwinSplit and TwinTandemId in currentRetrieved twin jobs list.
	 * Business Logic : 
	 * If current OPUS created twin job is exactly equal to existed OPUS created twin job making current job operation code as 'R'
	 * @param currentTwinJobsSet
	 * @param twinTandemContainerJob
	 * @param minaproTwinSplit
	 * @param twinTandemId
	 */
	public void checkCurrentTwinTandemJobsWithExisted(Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet,
			TwinTandemContainerList twinTandemContainerJob,String minaproTwinSplit,String twinTandemId) throws NullPointerException{


		for(OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet){
			
			String operationCode;
			String moveType 					  = currentTwinJob.getMoveKind();

			String currentTwinJobContainer        = currentTwinJob.getContainerID();
			String currentTwinJobRefContainer     = currentTwinJob.getRefContainerID();

			String currentTwinJobFromLocation     = currentTwinJob.getFromLocation();
			String currentTwinJobToLocation       = currentTwinJob.getToLocation();

			String currentTwinJobRefFromLocation  = currentTwinJob.getRefFromLocation();
			String currentTwinJobRefToLocation    = currentTwinJob.getRefToLocation();

			String existedTwinJobContainer	      = twinTandemContainerJob.getContainerId()	;
			String existedTwinJobRefContainer     = twinTandemContainerJob.getRefContainerId();

			String existedTwinJobFromLocation     = twinTandemContainerJob.getFromLocation();
			String existedTwinJobToLocation       = twinTandemContainerJob.getToLocation();

			String existedTwinJobRefFromLocation  = twinTandemContainerJob.getRefContrFromLocation();
			String existedTwinJobRefToLocation    = twinTandemContainerJob.getRefContrToLocation();


			if (currentTwinJobContainer.equalsIgnoreCase(existedTwinJobContainer) && 
					currentTwinJobRefContainer.equalsIgnoreCase(existedTwinJobRefContainer)){

				operationCode = "R";
			
				if (moveType.equalsIgnoreCase(DSCH) && (!currentTwinJobFromLocation.equalsIgnoreCase(existedTwinJobFromLocation)
							|| !currentTwinJobRefFromLocation.equalsIgnoreCase(existedTwinJobRefFromLocation))) {
					operationCode = "U" ;
				} else if (moveType.equalsIgnoreCase(LOAD) && (!currentTwinJobToLocation.equalsIgnoreCase(existedTwinJobToLocation)
							|| !currentTwinJobRefToLocation.equalsIgnoreCase(existedTwinJobRefToLocation))) {
					operationCode = "U" ;
				}
				LOGGER.logMsg(LOG_LEVEL.TRACE,twinTandemId," --Current Twin Tandem Id Operation Code--".concat(operationCode));

				updateCurrentTwinJobs(currentTwinJob,operationCode,twinTandemId,minaproTwinSplit);
				/*Break Condition is not present in procedure added by UmaMahesh. */
				break;

			} else if(existedTwinJobContainer.equals(currentTwinJobRefContainer) && existedTwinJobRefContainer.equals(currentTwinJobContainer)){
				operationCode = "R";

				if (moveType.equalsIgnoreCase(DSCH) && (!existedTwinJobFromLocation.equalsIgnoreCase(currentTwinJobRefFromLocation)
							|| !existedTwinJobRefFromLocation.equalsIgnoreCase(currentTwinJobFromLocation))) {
					operationCode = "U" ;
				} else if (moveType.equalsIgnoreCase(LOAD) && (!existedTwinJobToLocation.equalsIgnoreCase(currentTwinJobRefToLocation)
							|| !existedTwinJobRefToLocation.equalsIgnoreCase(currentTwinJobToLocation))) {
					operationCode = "U" ;
				}
				LOGGER.logMsg(LOG_LEVEL.TRACE,twinTandemId," --Current Twin Tandem Id Operation Code--".concat(operationCode));

				updateCurrentTwinJobs(currentTwinJob,operationCode,twinTandemId,minaproTwinSplit);
				break;

			} else if ((currentTwinJobContainer.equalsIgnoreCase(existedTwinJobContainer) || currentTwinJobRefContainer
					.equalsIgnoreCase(existedTwinJobRefContainer))
					|| (existedTwinJobContainer.equalsIgnoreCase(currentTwinJobRefContainer) || existedTwinJobRefContainer
							.equalsIgnoreCase(currentTwinJobContainer))) {
				LOGGER.logMsg(LOG_LEVEL.TRACE,twinTandemId," --Both Containers Are Not Same--Setting Operation Code to 'U'");
				operationCode = "U" ;
				updateCurrentTwinJobs(currentTwinJob,operationCode,twinTandemId,minaproTwinSplit);

			} 

		}




	}
	/**
	 * Update Sparcs Created Twin Jobs object with TwinTandemId and OperationCode and MinaPro Twin Split
	 * 
	 * @param currentTwinJob : Sparcs Current TwinJob
	 * @param operationCode  : It can be I or U or R 
	 * @param twinTandemId   :Existed TwinTademId in Database .  
	 * @param minaproTwinSplit : Y or N
	 */
	private void updateCurrentTwinJobs(OPUSTwinTandemJobsPOJO currentTwinJob, String operationCode, String twinTandemId,
			String minaproTwinSplit) {
		LOGGER.logMsg(LOG_LEVEL.TRACE,twinTandemId,new StringBuilder(" Setting Values To Current Twin job Pojo").
				append(" Opearation Code::").append(operationCode).append(" Current Pojo is::").append(currentTwinJob).toString());
		currentTwinJob.setOperationCode(operationCode);
		currentTwinJob.setTwinTandemId(twinTandemId);
		currentTwinJob.setMinaproTwinSplit(minaproTwinSplit);
	}



	/**
	 * Step 3: Method is responsible for preparing the twinTandemId list which are not available in the current twin
	 * sparcs list. Adding those id's to list and returning that list.
	 * 
	 * @param currentTwinJobsSet
	 * @param existedSparcsCreatedTwinJobs
	 * @return
	 */

	public List<TwinTandemJobs> prepareDeletableJobsListFromCurrentJobs(Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet,
			List<TwinTandemJobs> existedSparcsCreatedTwinJobs) {

		LOGGER.logMsg(LOG_LEVEL.INFO,""," Started prepareDeletableJobsListFromCurrentJobs(), delete from TWINTANDEM tables as new refresh does not have the pair received");

		List<TwinTandemJobs> deleteRequiredTwinTadenmIdList = new ArrayList<TwinTandemJobs>();


		for(TwinTandemJobs twinJobs : existedSparcsCreatedTwinJobs){

			boolean isTwinIdDeletable = false;

			Integer twinTandeemId    = twinJobs.getTwinTandemId();	

			LOGGER.logMsg(LOG_LEVEL.TRACE,"",new StringBuilder("Existed Sparcs Created Twin Tandem Id").append(twinTandeemId).toString());

			for(OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet){
				if(Integer.parseInt(currentTwinJob.getTwinTandemId())==twinTandeemId){
					LOGGER.logMsg(LOG_LEVEL.TRACE,"",new StringBuilder(" Current Sparcs Twin Job Twin Tandem  Id:").append(currentTwinJob.getTwinTandemId()).toString());
					isTwinIdDeletable = true;
					break;
				}
			}
			if(!isTwinIdDeletable){
				deleteRequiredTwinTadenmIdList.add(twinJobs);
			}
		}
		LOGGER.logMsg(LOG_LEVEL.TRACE,"",new StringBuilder(" Delete Required TwinTandem Jobs List:::").append(deleteRequiredTwinTadenmIdList)
				.toString());
		return deleteRequiredTwinTadenmIdList;

	}

	/**
	 * Step 4: Method is responsible for preparing separate list objects to insert or update based on following
	 * conditions. If operator code is 'I' need to insert new records into
	 * MP_TWINTANDEM_JOB_LIST,MP_TWINTANDEM_CONTAINER_LIST tables. If operator code is 'U' need to update
	 * MP_TWINTANDEM_CONTAINER_LIST table all columns with new values. After above two steps need to re arrange the
	 * sequence numbers in MP_JOB_LIST.to prepare sequence update list checking the following condition.
	 * MinaproTwinSplit = 'N' . If insertList not null then need to insert new records into
	 * MP_TWINTANDEM_JOB_LIST,MP_TWINTANDEM_CONTAINER_LIST tables. If updateNeededList is not null then need to update
	 * MP_TWINTANDEM_CONTAINER_LIST table all columns with new values. If sequnceUpdateList is not null need to check
	 * following conditions based that logic needs to Mp_Job_List with new sequnce values. Business Condition : If seqNo
	 * > referenceSeqNo then update mp_job_list set seqNo = referenceSeqNo +0.1 where seqNo = seqNo else update
	 * mp_job_list set seqNo = seqNo +0.1 where seqNo = referenceSeqNo
	 * 
	 * @param currentTwinJobsSet
	 * @param rotationId
	 * @param terminalId
	 * @param equipmentId
	 * @param availableTwinTandemJobs 
	 * @param availableTwinTandemJobs 
	 * @return
	 * @throws NullPointerException,InterruptedException 
	 * @throws SQLException 
	 */
	//TODO :: Need to do code re-factor After basic testing.
	public void prepareInsertOrUpdateRequiredList(Set<OPUSTwinTandemJobsPOJO> currentTwinJobsSet, String rotationId,
			String terminalId, String equipmentId) throws NullPointerException, SQLException {

		LOGGER.logMsg(LOG_LEVEL.INFO,""," Started prepareInsertOrUpdateRequiredList() To Prepare Insert Or Update List For Existed Sparcs Twin Jobs");

		final List<TwinTandemJobs> insertList 					 = new LinkedList<TwinTandemJobs>();
		final List<OPUSTwinTandemJobsPOJO> twinTandemContaierUpdateList    = new LinkedList<OPUSTwinTandemJobsPOJO>();

		for(OPUSTwinTandemJobsPOJO currentTwinJob : currentTwinJobsSet) {
			
			String operationCode = currentTwinJob.getOperationCode();
			LOGGER.logMsg(LOG_LEVEL.INFO,""," Current Operation Code::"+operationCode);

			if ("I".equalsIgnoreCase(operationCode)) {
				List<TwinTandemJobs> availableTwinTandemJobs = OpusQCJobListDAO.getInstnace().loadExistedTwinTandemJobs(rotationId, equipmentId, terminalId);
			
				//If job is already available ignore current job insertion into database.
				if(isCurJobAvailableInTwinTandemCntrListTable(availableTwinTandemJobs, currentTwinJob)) {
					continue;
				}

				TwinTandemJobs twinJob = null;

				String twinTandemType = getTwinOrTandemType(currentTwinJob);
				TwinTandemContainerList currentTwinTandemContainer = null;

				if(twinTandemType.equalsIgnoreCase(TANDEM_JOB_TYPE)){

					if(JobListUtil.isItTwoFortyTandem(
							"DSCH".equalsIgnoreCase(currentTwinJob.getMoveKind()) ? currentTwinJob.getFromLocation():currentTwinJob.getToLocation())) {
						twinJob = prepareTwinTandemJob(rotationId,terminalId,equipmentId,TANDEM_JOB_TYPE);
						currentTwinTandemContainer = prepareTwinandemCntrList(currentTwinJob);
						currentTwinTandemContainer.setTwinTandemId(twinJob);
						twinJob.getTwinTandemDetails().add(currentTwinTandemContainer);
						LOGGER.logMsg(LOG_LEVEL.INFO,""," Current Job Is 2*40 Tandem Job::");
						currentTwinJob.setIsCurJobModified(true);

					} else {

						for(OPUSTwinTandemJobsPOJO subTwinJob : currentTwinJobsSet){


							if(currentTwinJob.getTwinTandemCodeId().equalsIgnoreCase(subTwinJob.getTwinTandemCodeId()) &&
									!(subTwinJob.getIsCurJobModified() || currentTwinJob.getIsCurJobModified()) &&
									!currentTwinJob.getContainerID().equalsIgnoreCase(subTwinJob.getContainerID()) &&
									!currentTwinJob.getRefContainerID().equalsIgnoreCase(subTwinJob.getRefContainerID())) {


								twinJob = prepareTwinTandemJob(rotationId,terminalId,equipmentId,TANDEM_JOB_TYPE);

								currentTwinTandemContainer = prepareTwinandemCntrList(subTwinJob);
								currentTwinTandemContainer.setTwinTandemId(twinJob);
								twinJob.getTwinTandemDetails().add(currentTwinTandemContainer);

								currentTwinTandemContainer = prepareTwinandemCntrList(currentTwinJob);
								currentTwinTandemContainer.setTwinTandemId(twinJob);
								twinJob.getTwinTandemDetails().add(currentTwinTandemContainer);

								LOGGER.logMsg(LOG_LEVEL.INFO,""," Current Job Is 4*20 Tandem:");
								subTwinJob.setIsCurJobModified(true);
								currentTwinJob.setIsCurJobModified(true);

								break;
							}
						}
					}

				} else {
					twinJob = prepareTwinTandemJob(rotationId,terminalId,equipmentId,TWIN_JOB_TYPE);
					currentTwinTandemContainer = prepareTwinandemCntrList(currentTwinJob);
					currentTwinTandemContainer.setTwinTandemId(twinJob);
					twinJob.getTwinTandemDetails().add(currentTwinTandemContainer);
					LOGGER.logMsg(LOG_LEVEL.INFO,""," Current Job Is Twin Job ");
					currentTwinJob.setIsCurJobModified(true);
				}

				if(twinJob!=null){
					insertList.add(twinJob);
				}

			} else if ("U".equalsIgnoreCase(operationCode)) {
				twinTandemContaierUpdateList.add(currentTwinJob);
			}



		}

		if(insertList!=null && !insertList.isEmpty()){
			LOGGER.logMsg(LOG_LEVEL.INFO,rotationId+equipmentId," Insert Twin Jobs List::"+insertList.toString());
			DAO.saveMultipleObjects(insertList);
		}

		if(twinTandemContaierUpdateList!=null && !twinTandemContaierUpdateList.isEmpty()){

			DAO.updateTwinTandemContainerList(twinTandemContaierUpdateList);
		}

	}


	public  void processNonOPUSTwinTandemJobs(List<TwinTandemJobs> existedMinaProCreatedTwinJobs , List<TwinTandemJobs> deletableTwinTandemIdList,
			List<OPUSQCJobListEntity> currentJobList) throws NullPointerException, SQLException{

		LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("Started processNonSparcsTwinJobs() To Check the status of MinaPro ")
		.append("Created Existed Twin Jobs With Current Twin Jobs").toString());

		Set<TwinTandemJobs> minaproCreatedTandemJobsList  = new HashSet<TwinTandemJobs>();

		List<OPUSQCJobListEntity> entityList              = new ArrayList<OPUSQCJobListEntity>();

		for(TwinTandemJobs existedMinaProTwinJob : existedMinaProCreatedTwinJobs){

			if(existedMinaProTwinJob!=null) {

				boolean isIt4TwentyTandemJob = false;

				for(TwinTandemContainerList twinTandemContainer : existedMinaProTwinJob.getTwinTandemDetails()){

					boolean isTwinTandemIdDeletable      = true;

					double primaryCntrSeqNumber          = -1.0;
					double refCntrSeqNumber              = -1.0 ;

					MinaProTwinJobStatus twinJobStatus   = null;

					OPUSQCJobListEntity firstEntity=null,secondEntity=null;

					twinJobStatus = checkNonOPUSTwinJobPresentInCurrentJobList(currentJobList,twinTandemContainer.getFromLocation(),
							twinTandemContainer.getToLocation(),twinTandemContainer.getContainerId());

					isTwinTandemIdDeletable = twinJobStatus.isJobDeletable();

					if(isTwinTandemIdDeletable){
						deletableTwinTandemIdList.add(existedMinaProTwinJob);
						continue;
					} else {
						firstEntity = twinJobStatus.getEntity();

						primaryCntrSeqNumber = twinJobStatus.getSeqNumber()!=-1.0 ? twinJobStatus.getSeqNumber() : primaryCntrSeqNumber ;

						twinJobStatus = checkNonOPUSTwinJobPresentInCurrentJobList(currentJobList,twinTandemContainer.getRefContrFromLocation(),
								twinTandemContainer.getRefContrToLocation(),twinTandemContainer.getRefContainerId());

						isTwinTandemIdDeletable = twinJobStatus.isJobDeletable();

						refCntrSeqNumber = twinJobStatus.getSeqNumber()!=-1 ? twinJobStatus.getSeqNumber() : refCntrSeqNumber ;

						if(isTwinTandemIdDeletable){
							deletableTwinTandemIdList.add(existedMinaProTwinJob);
							continue;
						}
					}
					//Add update required sequence numbers to list.
					if(!isTwinTandemIdDeletable && primaryCntrSeqNumber!=-1.0 && refCntrSeqNumber!=-1.0) {
						secondEntity = twinJobStatus.getEntity();
						/* If Condition is used to Set the Sequence number for 4*20 Tandem jobs  
						 * Else Condition is used to Set the Sequence Number for 2*40 Tandem Job or 2*20 Twin JObs created from Minapro Application.
						 */
						if(existedMinaProTwinJob.getSparcsTwinIndicator().equalsIgnoreCase(NO) && 
								existedMinaProTwinJob.getJobType().equalsIgnoreCase(TANDEM_JOB_TYPE) && existedMinaProTwinJob.getTwinTandemDetails().size() ==2) {
							isIt4TwentyTandemJob =true;

						} else {
							updateMinaproTwinJobsSeqNumbers(primaryCntrSeqNumber,refCntrSeqNumber,firstEntity,secondEntity);
						}

						entityList.add(firstEntity);
						entityList.add(secondEntity);

					}

				}
				if(isIt4TwentyTandemJob){
					minaproCreatedTandemJobsList.add(existedMinaProTwinJob);
				}
			}else {
				return;
			}

		}

		//Update MinPro Created Sequnce Numbers...
		if(!minaproCreatedTandemJobsList.isEmpty()) {

			LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("Minapro Cretaed Tandem Jobs List::").append(minaproCreatedTandemJobsList).toString());

			setSeqFor4TwntyTandmCreatdByMinaPro(entityList , minaproCreatedTandemJobsList);
		} else {
			LOGGER.logMsg(LOG_LEVEL.INFO,"",new StringBuilder("At Present No Jobs are available as Minapro Created 4*20 Tandem Jobs").toString());
		}



	}

	private void updateMinaproTwinJobsSeqNumbers(double primarySeqNo,
			double refSeqNo, OPUSQCJobListEntity firstEntity,OPUSQCJobListEntity secondEntity) throws NullPointerException, SQLException {

		LOGGER.logMsg(LOG_LEVEL.INFO,"", " Started updateMinaproTwinJobsSeqNumbers() To Update MinaPro "
				+ "Created Twin And 2*40 Tandem Jobs Seq Number");

		double newSeqNo      = 0.0;

		if(primarySeqNo > refSeqNo){
			newSeqNo = refSeqNo + 0.1;
			firstEntity.setSeqNo(newSeqNo);
			secondEntity.setSeqNo(refSeqNo);
		} else {
			newSeqNo =primarySeqNo + 0.1;
			firstEntity.setSeqNo(newSeqNo);
			secondEntity.setSeqNo(primarySeqNo);
		}


		LOGGER.logMsg(LOG_LEVEL.INFO,""," After Update...Entities Are First Entity::"
				+firstEntity.toString() + " Second Entity::"+secondEntity.toString());
		List<OPUSQCJobListEntity> twinUpdateJobs = new ArrayList<OPUSQCJobListEntity>();
		twinUpdateJobs.add(firstEntity);
		twinUpdateJobs.add(secondEntity);
		LOGGER.logMsg(LOG_LEVEL.INFO,""," Updating Twin/Tandem Jobs Into Database.........");
		DAO.updateOPUSQcJobList(twinUpdateJobs);

	}

	/**
	 * 
	 * @param currentJobList Current Job List  from Database
	 * @param twinTandemContainer minaproCreatedTwinTandem Container List Data
	 * @param container minaProCreated twin or tandem container 
	 * @return MinaProTwinJobStatus class , Which holds the status of the current job.
	 * (Means Current TwinTandem Container is deletable or not.)
	 * @throws NullPointerException
	 */
	public MinaProTwinJobStatus checkNonOPUSTwinJobPresentInCurrentJobList(List<OPUSQCJobListEntity> currentJobList,
			String fromLocation,String toLocation,String container) throws NullPointerException{

		boolean isTwinTandemIdDeletable = true;
		double seqNumber = -1.0;
		OPUSQCJobListEntity entity = null ;
		for(OPUSQCJobListEntity qcJobEntity : currentJobList){

			if(qcJobEntity.getId().getContainerId() .equalsIgnoreCase(container)){

				LOGGER.logMsg(LOG_LEVEL.TRACE,container,new java.lang.StringBuilder(" Twin Tandem Container List Container").
						append("::").append(container) . append(" Current Job List Container ").append(qcJobEntity.getId().getContainerId())
						.append(" Are Equals Checking From To Location Based On MoveType").toString());

				if ((qcJobEntity.getId().getMoveKind().equalsIgnoreCase(DSCH))&& (qcJobEntity.getFromLocation()
						.equalsIgnoreCase(fromLocation))) {
					isTwinTandemIdDeletable = false;
					seqNumber = qcJobEntity.getSeqNo();
					entity = qcJobEntity;
					break;
				} else if ((qcJobEntity.getId().getMoveKind().equalsIgnoreCase(LOAD))
						&& (qcJobEntity.getToLocation()
								.equalsIgnoreCase(toLocation))) {
					isTwinTandemIdDeletable =false;
					seqNumber = qcJobEntity.getSeqNo();
					entity = qcJobEntity;
					break;
				}

			}
		}
		LOGGER.logMsg(LOG_LEVEL.TRACE,container,new StringBuilder(" After Loop Iteration isTwinTandemIdDeletable").
				append("::").append(isTwinTandemIdDeletable).append(" Seq Number::").append(seqNumber).toString());
		return new MinaProTwinJobStatus(isTwinTandemIdDeletable, seqNumber,entity);
	}

	private final class MinaProTwinJobStatus{

		boolean isJobDeletable;
		double seqNumber;
		OPUSQCJobListEntity entity;
		
		public MinaProTwinJobStatus(boolean isJobDeletable, double seqNumber , OPUSQCJobListEntity entity) {
            super();
            this.isJobDeletable = isJobDeletable;
            this.seqNumber = seqNumber;
            this.entity = entity;
        }
		public OPUSQCJobListEntity getEntity() {
			return entity;
		}

		public boolean isJobDeletable() {
			return isJobDeletable;
		}

		public double getSeqNumber() {
			return seqNumber;
		}

		@Override
		public String toString() {
			return "MinaProTwinJobStatus [isJobDeletable=" + isJobDeletable
					+ ", seqNumber=" + seqNumber + ", entity=" + entity + "]";
		}
	}

    private void setSeqFor4TwntyTandmCreatdByMinaPro(List<OPUSQCJobListEntity> entityList,
            Set<TwinTandemJobs> minaproTandemJobs) throws NullPointerException, SQLException {

        LOGGER.logMsg(LOG_LEVEL.INFO, "",
                " Started setSeqFor4TwntyTandmCreatdByMinaPro() Entity List::" + entityList.toString());

        for (TwinTandemJobs mainMinaproTandemJob : minaproTandemJobs) {

            double currentJobSeqNo = -1.0;
            for (TwinTandemContainerList mainCntrList : mainMinaproTandemJob.getTwinTandemDetails()) {

                boolean isCurEntityAvailable = false;
                for (OPUSQCJobListEntity entity : entityList) {

                    isCurEntityAvailable = mainCntrList.getContainerId().equalsIgnoreCase(
                            entity.getId().getContainerId()) ? true : (mainCntrList.getRefContainerId()
                            .equalsIgnoreCase(entity.getId().getContainerId()) ? true : false);

                    if (isCurEntityAvailable) {
                        currentJobSeqNo = (currentJobSeqNo == -1.0) ? entity.getSeqNo() + 0.1 : currentJobSeqNo + 0.1;
                        entity.setSeqNo(currentJobSeqNo);
                    }
                }
            }
        }

        LOGGER.logMsg(LOG_LEVEL.INFO, " ", " Before Update Into Database..Updated OPUSJobList Entity Is:::"
                + entityList.toString());
        DAO.updateOPUSQcJobList(entityList);
    }

	public List<JobListContainer> getOPUSQCJobList(JobListEvent jobList,String rotationID){

		LOGGER.logMsg(LOG_LEVEL.INFO," "," Started getOPUSQCJobList() To get QC JobList.");
		List<JobListContainer> jobListContainers = null;
		try {
		    jobListContainers =  prepareJobListFromDBResponse(DAO.getOPUSQCJobListFromDatabase(
					jobList.getTerminalID(),rotationID,jobList.getEquipmentID(),JobListUtil.getVesselAndVoyageDetails(jobList.getUserID())));
		}catch(Exception ex) {
			LOGGER.logException("Exception Occured While Retrieving QC JobList Reason-", ex);
		}
		return jobListContainers;
	}

	private List<JobListContainer> prepareJobListFromDBResponse(List<Object[]> jobListObjectArray) {

		LOGGER.logMsg(LOG_LEVEL.INFO," "," Started prepareJobListFromDBResponse() to prepare List of JobList from db response..");

		List<JobListContainer> jobList  = new ArrayList<JobListContainer>();		
		if(null == jobListObjectArray || jobListObjectArray.isEmpty()){
			return jobList;
		}
		
		/*0-MP_OPUS_QC_JOB_LIST.SEQ_NO,
 		1-MP_OPUS_QC_JOB_LIST.CONTAINER_ID,
 		2-MP_OPUS_QC_JOB_LIST.MOVE_KIND, 
 		3-MP_OPUS_QC_JOB_LIST.FROM_LOCATION, 
 		4-MP_OPUS_QC_JOB_LIST.TO_LOCATION,
		5-MP_OPUS_QC_JOB_LIST.TANDEM_CONTAINERS,
		6-MP_OPUS_QC_JOB_LIST.ISO,
		7-MP_OPUS_QC_JOB_LIST.POD,
		8-MP_OPUS_QC_JOB_LIST.WT,
		9-MP_OPUS_QC_JOB_LIST.VOYAGE,
		10-MP_OPUS_QC_JOB_LIST.VESSEL_NAME,
		11-MP_OPUS_QC_JOB_LIST.JOB_KEY,
		12-MP_OPUS_QC_JOB_LIST.CATEGEORY,
		13-MP_OPUS_QC_JOB_LIST.STATUS,
		14-MP_OPUS_QC_JOB_LIST.POC
		15-MP_OPUS_QC_JOB_LIST.JOB_QUEUE_NAME
		16-MP_OPUS_QC_JOB_LIST.JOB_QUEUE_SEQUENCE
		17-REFCONTAINER*/
		for(Object[] jobListObject : jobListObjectArray){				
			
			JobListContainer jobListContainer = new JobListContainer();
			Container container = new Container();

			jobListContainer.setSeqNumber(jobListObject[0]!=null ? Double.valueOf(jobListObject[0].toString()) : null);
			jobListContainer.setContainerId(jobListObject[1]!=null ? jobListObject[1].toString() : null);
			container.setContainerID(jobListObject[1]!=null ? jobListObject[1].toString() : null);
			
			jobListContainer.setMoveType(jobListObject[2]!=null ? jobListObject[2].toString() : null);
			jobListContainer.setFromLocation(jobListObject[3]!=null ? jobListObject[3].toString() : "");
			jobListContainer.setToLocation(jobListObject[4]!=null ? jobListObject[4].toString() : "");
			jobListContainer.setTandemContainerIDs(jobListObject[5]!=null ? jobListObject[5].toString().split("\\,") : null);
			container.setIsoCode(jobListObject[6]!=null ? jobListObject[6].toString() : null);
			container.setPod(jobListObject[7]!=null ? jobListObject[7].toString() : null);
			container.setWeight(jobListObject[8]!=null ? jobListObject[8].toString() : null);
			jobListContainer.setVoyage(jobListObject[9]!=null ? jobListObject[9].toString() : null);
			jobListContainer.setVesselName(jobListObject[10]!=null ? jobListObject[10].toString() : null);
			jobListContainer.setJobKey(jobListObject[11]!=null ? jobListObject[11].toString() : null);
			container.setCategory(jobListObject[12]!=null ? jobListObject[12].toString() : null);
			container.setEmpty(jobListObject[13]!=null ? "M".equalsIgnoreCase(jobListObject[13].toString()) ? true : false : false);
			jobListContainer.setPosition(jobListObject[14]!=null ? jobListObject[14].toString() :null);
			jobListContainer.setJobWorkQueueName(jobListObject[15]!=null ? jobListObject[15].toString() :null);
			jobListContainer.setJobWorkQueueSeqNo(jobListObject[16]!=null ? Integer.valueOf(jobListObject[16].toString()) :null);
			jobListContainer.setTwinContainerId(jobListObject[17]!=null ? jobListObject[17].toString() :null);


			jobListContainer.setContainer(container);
			
			LOGGER.logMsg(LOG_LEVEL.INFO,""," JobList Container :::"+jobListContainer);

			jobList.add(jobListContainer);

		}

		LOGGER.logMsg(LOG_LEVEL.TRACE," ","Final JobList Object From DB Is::"+(jobList!=null ? jobList.toString() : null));
		return jobList;
	}

	public String getTwinOrTandemType(OPUSTwinTandemJobsPOJO pojo) {
		String jobType = TWIN_JOB_TYPE;
		if((pojo.getTwinTandemCode()!=null || pojo.getRefTwinTandemCode()!=null) && 
		        (pojo.getTwinTandemCode().equalsIgnoreCase(OPUS_TANDEM_CODE) || pojo.getRefTwinTandemCode().equalsIgnoreCase(OPUS_TANDEM_CODE))) {
				jobType =  TANDEM_JOB_TYPE;
		}
		return jobType;
	}


	/**
	 * Method is responsible for creating MinaPro Created Twin jobs and Sparcs Created Twin jobs based on sparcsTwinIndicator property condition.
	 * if sparcsTwinIndicator = Y means it is the Sparcs created twin job else Twin job is created by minapro
	 * @param availableJobs -- Which contains all twin jobs available in TwinTandemContainer List Table
	 * @param sparcsTwinJobs -- Initially it is a empty list,Depending on sparcsTwinIndicator = Y  adding current object to list
	 * @param minaproTwinJobs -- Initially it is a empty list,Depending on sparcsTwinIndicator = N  adding current object to list
	 * 
	 */
	public void seperateMinaProAndSparcsCreatedTwinJobs(Set<TwinTandemJobs> availableJobs , List<TwinTandemJobs> sparcsTwinJobs, 
			List<TwinTandemJobs> minaproTwinJobs) {

		LOGGER.logMsg(LOG_LEVEL.INFO,"","Started seperateMinaProAndSparcsCreatedTwinJobs()");

		for(TwinTandemJobs twinJob : availableJobs) {

			if(YES.equalsIgnoreCase(twinJob.getSparcsTwinIndicator())){
				sparcsTwinJobs.add(twinJob);
			} else {
				minaproTwinJobs.add(twinJob) ; 
			}

		}
	}


	public TwinTandemContainerList prepareTwinandemCntrList(OPUSTwinTandemJobsPOJO currentTwinJob){
		return new TwinTandemContainerList(
				currentTwinJob.getContainerID(), currentTwinJob.getToLocation(),
				currentTwinJob.getFromLocation(), currentTwinJob.getRefContainerID(),
				currentTwinJob.getRefFromLocation(),currentTwinJob.getRefToLocation());
	}

	public TwinTandemJobs prepareTwinTandemJob(String rotationId , String terminalId , String equipmentId , String twinTandemCd){
		TwinTandemJobs twinJob = new TwinTandemJobs();
		twinJob.setTerminalId(terminalId);
		twinJob.setRotationId(rotationId);
		twinJob.setEquipmentId(equipmentId);
		twinJob.setSparcsTwinIndicator(YES);
		twinJob.setTwinSplit(NO);
		twinJob.setJobType(twinTandemCd);
		twinJob.setIsJobCompleted(NO);
		return twinJob;
	}
	
	public boolean isCurJobAvailableInTwinTandemCntrListTable(List<TwinTandemJobs> availableTwinTandemJobs, 
			OPUSTwinTandemJobsPOJO currentTwinJob){

		
		for(TwinTandemJobs availableTwinJobs : availableTwinTandemJobs){

			if(availableTwinJobs==null){
				return false;
			}

			for(TwinTandemContainerList existedTwinTandemCntr :availableTwinJobs.getTwinTandemDetails() ){

				if((existedTwinTandemCntr.getContainerId() .equalsIgnoreCase(currentTwinJob.getContainerID())
						&& existedTwinTandemCntr.getRefContainerId().equalsIgnoreCase(currentTwinJob.getRefContainerID()))
						|| (existedTwinTandemCntr.getContainerId() .equalsIgnoreCase(currentTwinJob.getRefContainerID())
								&& existedTwinTandemCntr.getRefContainerId().equalsIgnoreCase(currentTwinJob.getContainerID()))){

					LOGGER.logMsg(LOG_LEVEL.INFO,String.valueOf(Thread.currentThread().getId()),new StringBuilder("Current Twin Job Container Already Available In TwinTandemContainer List table,")
					.append(" Current Twin Job Is ::").append(currentTwinJob.toString()).append(" Existed Twin job Is::").append(availableTwinJobs.toString()).toString());

					return true;
				}
			}
		}
		return false;
	}
}

