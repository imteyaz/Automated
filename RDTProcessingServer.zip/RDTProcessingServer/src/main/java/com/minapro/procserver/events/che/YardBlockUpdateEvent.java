package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the yard block IDs which are altered through Admin application
 * 
 * @author Rosemary GEorge
 *
 */
public class YardBlockUpdateEvent extends Event implements Serializable {

	private static final long serialVersionUID = 1580811945383617821L;

	/*
	 * Unique identification number for tracking purpose
	 */
	private String eventId;
	
	private List<String> updatedBlocks;

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public List<String> getUpdatedBlocks() {
		return updatedBlocks;
	}

	public void setUpdatedBlocks(List<String> updatedBlocks) {
		this.updatedBlocks = updatedBlocks;
	}

	@Override
	public String toString() {
		return "YardBlockUpdateEvent [eventId=" + eventId + ", updatedBlocks=" + updatedBlocks + "]";
	}	
}
