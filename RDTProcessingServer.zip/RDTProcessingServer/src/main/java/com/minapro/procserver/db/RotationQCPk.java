package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the Rotation QC mapping primary key
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class RotationQCPk implements Serializable {

    private static final long serialVersionUID = -3566813859404521178L;

    @Column(name = "ROTATION_CONTROL_ID")
    private Integer rotationControlId;

    @Column(name = "EQUIPMENT_ID")
    private String equipmentId;

    public RotationQCPk() {
    }

    public Integer getRotationControlId() {
        return rotationControlId;
    }

    public void setRotationControlId(Integer rotationControlId) {
        this.rotationControlId = rotationControlId;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
}
