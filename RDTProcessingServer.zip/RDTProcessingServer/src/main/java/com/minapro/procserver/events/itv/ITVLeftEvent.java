package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the ITV Left Message of a particular ITV
 * 
 * @author venkataramana.ch
 *
 */
public class ITVLeftEvent extends Event implements Serializable {

    private static final long serialVersionUID = -6949502123674052265L;

    private String itvID;

    public String getItvID() {
        return itvID;
    }

    public void setItvID(String itvID) {
        this.itvID = itvID;
    }

    @Override
    public String toString() {
        return "ITVLeftEvent [ItvID=" + itvID + "]";
    }

}
