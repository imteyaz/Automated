package com.minapro.procserver.actors.hc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_SWAP;

import java.util.List;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.hc.ITVSwapResponseEvent;
import com.minapro.procserver.events.hc.SwapContainerPosition;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.hc.SwapResponseEvent;
import com.minapro.procserver.opus.util.ContainerMoveUtil;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the swap request from the HC/ITV operator
 * 
 * @author Rosemary George
 *
 */
public class SwapActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(SwapActor.class);

	private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			VALUE_SEPERATOR_KEY);
	private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			ITEM_SEPERATOR_KEY);
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			ROW_SEPERATOR_KEY);
	
	private static final String COLUMN_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
			COLUMN_SEPERATOR_KEY);

	public static final String FORWARDPOSITION = "F";
	public static final String AFTPOSITION = "A";
		
	private static final String REASON = "Reason";
	private static final String BEEP_REQUIRED = "BeepRequired";
	private static final String SWAP_FAIL_MSG = "Swap request failed at TOS. Please contact system administrator";
	private static final String SWAP_SUCCESS_MSG = "Swap completed successfully at TOS";

	@Override
	public void onReceive(Object message) throws Exception {
		if (message instanceof SwapRequestEvent) {
			SwapRequestEvent swapEvent = (SwapRequestEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, swapEvent.getUserID(), "Received swap request from user - " + swapEvent);
			handleSwapOperation(swapEvent);
		} else if(message instanceof SwapResponseEvent){
			SwapResponseEvent swapRespEvent = (SwapResponseEvent) message;
			logger.logMsg(LOG_LEVEL.INFO, swapRespEvent.getUserID(), "Received swap response from ESB - " + swapRespEvent);
			handleSwapResponseEvent(swapRespEvent);
		} else if( message instanceof ITVSwapResponseEvent){
			ITVSwapResponseEvent itvSwapResp = (ITVSwapResponseEvent)message;
			logger.logMsg(LOG_LEVEL.INFO, itvSwapResp.getUserID(), "Received ITV swap response from ESB - " + itvSwapResp);
			handleITVSwapResponseEvent(itvSwapResp);
		}else {
			unhandled(message);
		}
	}

	/**
	 * 
	 * @param itvSwapResp
	 */
	private void handleITVSwapResponseEvent(ITVSwapResponseEvent itvSwapResp) {
		try{
			boolean swapStatus = true;
			StringBuilder containerWithItv = new StringBuilder();
			CompletedContainerMoves completedMove;	
			String currentItvNo;
			for(SwapContainerPosition swapContainer: itvSwapResp.getSwapContainerList()){
				containerWithItv.append(swapContainer.getContainerId()).append(ITEM_SEPARATOR)
				.append(swapContainer.getMoveType()).append(COLUMN_SEPARATOR);				
				
				if(!swapContainer.isStatus()){
					logger.logMsg(LOG_LEVEL.DEBUG, itvSwapResp.getUserID(), "Swap failed for conatiner - " + swapContainer);
					swapStatus = false;
					containerWithItv.append(swapContainer.getItvId());
					currentItvNo = swapContainer.getItvId();
				}else {
					containerWithItv.append(swapContainer.getNewItvId());
					currentItvNo = swapContainer.getNewItvId();
				}
				containerWithItv.append(ROW_SEPARATOR);		
				
				//in case the completed move is not updated with the current itv number, updating it
				completedMove = ContainerMoveUtil. getInstance().getCompletedContainer(swapContainer.getContainerId(), itvSwapResp.getUserID(), 
						itvSwapResp.getEquipmentID(), swapContainer.getMoveType());		
				if(completedMove!= null && !completedMove.getToLocation().equalsIgnoreCase(currentItvNo)){
					completedMove.setToLocation(currentItvNo);
					JournalEvent journal = new JournalEvent(completedMove, UPDATETYPE.UPDATE);	                
	                RDTProcessingServer.getInstance().getMasterActor().tell(journal, null);
				}
			}
			
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(ITV_SWAP);
			StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR)
					.append(eventTypeID).append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
					.append(swapStatus).append(VALUE_SEPARATOR);
			
			if(!swapStatus){
				responseToDevice.append(containerWithItv);
			}
			
			responseToDevice.append(VALUE_SEPARATOR).append(itvSwapResp.getUserID())
				.append(VALUE_SEPARATOR).append(itvSwapResp.getTerminalID());
			
			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(itvSwapResp.getUserID());
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
					itvSwapResp.getTerminalID());
			
		}catch(Exception ex){
			logger.logException("Caught exception while handling itv swap response", ex);
		}		
	}

	/**
	 * Handles the swap response event received from ESB. If the swap status is false for any of the containers involved, sends 
	 * alert to the UI
	 * 
	 * @param swapRespEvent
	 */
	private void handleSwapResponseEvent(SwapResponseEvent swapRespEvent) {
		logger.logMsg(LOG_LEVEL.INFO, swapRespEvent.getUserID(), "Received swap response event -" + swapRespEvent);
		try {			
			boolean swapStatus =  isSwapSuccess(swapRespEvent);
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);
	
			// get the message format
			List<String> msgFields = EventFormats.getInstance().getEventFields(ALERT_MESSAGE);

			// build the response to the device
			StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
			for (int i = 1; i < msgFields.size(); i++) {
				responseToDevice.append(VALUE_SEPARATOR);
				if (REASON.equalsIgnoreCase(msgFields.get(i))) {
					if(swapStatus){
						responseToDevice.append(SWAP_SUCCESS_MSG);
					}else {
						responseToDevice.append(SWAP_FAIL_MSG);
					}
				} else if (BEEP_REQUIRED.equalsIgnoreCase(msgFields.get(i))) {
					responseToDevice.append(false);
				} else {
					EventUtil.getInstance().getEventParameter(swapRespEvent, msgFields.get(i), responseToDevice);
				}					
			}

			OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(swapRespEvent.getUserID());
			CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
					swapRespEvent.getTerminalID());
		} catch (Exception e) {
			logger.logException("Caught exception while processing handleSwapResponseEvent -", e);
		}
	}

	/**
	 * validates whether the swap request was successful. Returns true only if all container swap was successful. 
	 * @param swapRespEvent
	 * @return
	 */
	private boolean isSwapSuccess(SwapResponseEvent swapRespEvent) {
		for(SwapContainerPosition swapContainer: swapRespEvent.getSwapContainerList()){
			if(!swapContainer.isStatus()){
				logger.logMsg(LOG_LEVEL.DEBUG, swapRespEvent.getUserID(), "Swap failed for conatiner - " + swapContainer);
				return false;
			}
		}
		return true;
	}

	/**
	 * Handles the swap operation request. The request can come from either HC or ITV operator. In case swap is
	 * initiated by HC operator, a notification is generated for the ITV operator to indicate that the containers are
	 * swapped.
	 * 
	 * @param swapEvent
	 */
	private void handleSwapOperation(SwapRequestEvent swapEvent) {
		try {
			OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(swapEvent.getUserID());
			if (OPERATOR.HC.equals(role)) {
				swapEvent.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(
						swapEvent.getUserID()));
			}
					
			if(swapEvent.getSwapContainers() != null){
				logger.logMsg(LOG_LEVEL.DEBUG, swapEvent.getUserID(), "Swap request initiated by device. Filling jobKey");
				
				JobListContainer jobFromCache;
				for(SwapContainerPosition swapContainer: swapEvent.getSwapContainers()){
					logger.logMsg(LOG_LEVEL.DEBUG, swapEvent.getUserID(), "Swap Container - " + swapContainer);
					if(swapContainer.getItvId() == null){
						if(OPERATOR.ITV.equals(role)){
							swapContainer.setItvId(swapEvent.getEquipmentID());
						}else {
							swapContainer.setItvId(swapEvent.getItvId());
						}
					}
					
					if(swapContainer.getJobKey() == null){						
						if(OPERATOR.ITV.equals(role)){
							swapContainer.setJobKey(RDTCacheManager.getInstance().getjobKeyFromITVJobList(swapContainer.getItvId(), 
									swapContainer.getContainerId()));
						} else {
							logger.logMsg(LOG_LEVEL.WARN, swapEvent.getUserID(), "Looking in Current Jobs - CHE initiated");
							ListOrderedMap<String, JobListContainer> jobsInCache =RDTCacheManager.getInstance().getJobList(
					                swapEvent.getUserID(), swapEvent.getEquipmentID());
							
							if(jobsInCache == null){
								logger.logMsg(LOG_LEVEL.DEBUG, swapEvent.getUserID(), "Swap - No jobs present in cache");									
							}else {
								//can only happen for LOAD or MO jobs
								jobFromCache = jobsInCache.get(swapContainer.getContainerId()+LOAD);
								logger.logMsg(LOG_LEVEL.DEBUG, swapEvent.getUserID(), "CHE SWAP - Looking for LOAD job -" + jobFromCache);	
								if(jobFromCache == null){
									jobFromCache = jobsInCache.get(swapContainer.getContainerId()+MO);
									logger.logMsg(LOG_LEVEL.DEBUG, swapEvent.getUserID(), "CHE SWAP - Looking for MO Job -" + jobFromCache);	
								}
								swapContainer.setJobKey(jobFromCache != null ? jobFromCache.getJobKey() : "");
							}
						}
					}
				}
				
				logger.logMsg(LOG_LEVEL.INFO, swapEvent.getUserID(), "Swap requested: - Send to ESB");
				ESBQueueManager.getInstance().postMessage(swapEvent, OPERATOR.COMMON, swapEvent.getTerminalID());
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while handling the swap operation ", ex);
		}
	}
}
