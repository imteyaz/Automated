package com.minapro.procserver.actors.common;

import java.util.List;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.bayprofile.BerthedVessel;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.VesselSailEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the vessel sail event from the ESB.</p>
 * 
 * <p>When the vessel sail event is received, the actor removes the vessel profile and associated container details from
 * the cache. </p>
 * 
 * @author Rosemary George
 *
 */
public class VesselSailActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselSailActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof VesselSailEvent) {
            VesselSailEvent sailEvent = (VesselSailEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, "", "Received Vessel Sail information from ESB -" + sailEvent);

            try {
                if (RDTVesselProfileCacheManager.getInstance().getVesselCode(sailEvent.getRotationID()) != null) {
                    // Remove all the Bay to section mapping from cache
                    Set<String> bayToSectionKeySet = RDTVesselProfileCacheManager.getInstance()
                            .getBaySectionMapKeySet();
                    for (String bayId : bayToSectionKeySet) {
                        if (bayId.startsWith(sailEvent.getVesselCode())) {
                            RDTVesselProfileCacheManager.getInstance().removeBaySectionMapping(bayId);
                        }
                    }

                    // Remove all the section to bay profile mapping from the cache
                    Set<String> sectToBayProfileKeySet = RDTVesselProfileCacheManager.getInstance()
                            .getSectionBayProfileKeySet();
                    for (String sectId : sectToBayProfileKeySet) {
                        if (sectId.startsWith(sailEvent.getVesselCode())) {
                            RDTVesselProfileCacheManager.getInstance().removeSectionBayProfileMapping(sectId);
                        }
                    }

                    // Remove all other vessel mappings from cache
                    Vessel vessel = HibernateUtil.getVessel(sailEvent.getVesselCode());
                    if (vessel != null) {
                        vessel.setRotationId(sailEvent.getRotationID());
                        RDTVesselProfileCacheManager.getInstance().removeVesselFromBerthedList(vessel);
                    }
                    RDTVesselProfileCacheManager.getInstance().removeVesselMapping(sailEvent.getRotationID());
                    RDTVesselProfileCacheManager.getInstance().removeVesselBerthSide(sailEvent.getRotationID());

                    logger.logMsg(LOG_LEVEL.DEBUG, sailEvent.getRotationID(), "Clearing the qc to rotation mapping");
                    RDTVesselProfileCacheManager.getInstance().clearQCToRotationMapiing(sailEvent.getRotationID());

                    logger.logMsg(LOG_LEVEL.DEBUG, sailEvent.getRotationID(), "Clearing the completed job list cache");
                    RDTCacheManager.getInstance().clearCompletedJobsForRotation(sailEvent.getRotationID());

                    deleteROBContainers(sailEvent.getRotationID());
                    
                    RDTVesselProfileCacheManager.getInstance().removeHeavyHookUser(sailEvent.getRotationID());

                    deleteVesselData(sailEvent.getVesselCode());
                    
                    RDTVesselProfileCacheManager.getInstance().removeVesselBerthSide(sailEvent.getRotationID());
                } else {
                    logger.logMsg(LOG_LEVEL.INFO, "vesselCode" + sailEvent.getVesselCode(),
                            "The vessel details are already deleted from cache. Ignore this event ");
                }

            } catch (Exception ex) {
                logger.logException("Caught exception while processing the vessel Sail event - " + sailEvent, ex);
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * Deletes all the ROB containers of the specified rotation from the Container cache
     * 
     * @param rotationID
     */
    private void deleteROBContainers(String rotationID) {
        List<String> robContainers = RDTVesselProfileCacheManager.getInstance().getROBList(rotationID);
        if (robContainers != null && !robContainers.isEmpty()) {
            logger.logMsg(LOG_LEVEL.DEBUG, rotationID, "Found ROB containers - " + robContainers.size());

            for (String robContainer : robContainers) {
                RDTCacheManager.getInstance().deleteContainer(robContainer);
            }

            RDTVesselProfileCacheManager.getInstance().clearROBList(rotationID);
        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, rotationID, "No ROB containers are present.No cache delete necessary");
        }
    }

    /**
     * Deletes the vessel from the berthed vessel details table
     * 
     * @param vesselCode
     */
    private void deleteVesselData(String vesselCode) {
        logger.logMsg(LOG_LEVEL.INFO, "", "Removing the vessel details from the data base for vessel :" + vesselCode);
        BerthedVessel vesselInfo = new BerthedVessel();
        vesselInfo.setVesselCode(vesselCode);

        JournalEvent journalEvent = new JournalEvent(vesselInfo, UPDATETYPE.DELETE);
        getSender().tell(journalEvent, null);
    }
}
