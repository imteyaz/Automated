package com.minapro.procserver.events.itv;

/**
 * Possible driving instruction types for an ITV
 * 
 * @author Rosemary George
 *
 */
public enum DriveType {
    PS, QC, YARD, GEN, TS
}
