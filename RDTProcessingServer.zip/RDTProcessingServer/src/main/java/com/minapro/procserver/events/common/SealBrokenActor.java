package com.minapro.procserver.events.common;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SEAL_BROKEN_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.SEAL_ISSUE_TS_ID;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Date;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.ExceptionCodeMaster;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TroubleShootRecord;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.TroubleShootStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for sending seal broken code with description.
 * 
 * @author 3131663
 *
 */
public class SealBrokenActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(SealBrokenActor.class);
    private static final String PIPE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof SealBrokenRequestEvent) {
            SealBrokenRequestEvent sealBrokenEvent = (SealBrokenRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, sealBrokenEvent.getUserID(), "Received Seal broken request -"+sealBrokenEvent);
            recordSealBrokenEvent(sealBrokenEvent);
        } else {
            unhandled(message);
        }
    }

    /**
     * Records the seal broken request from the device, and records a troubleshoot request too
     * @param sealBrokenEvent
     */
    private void recordSealBrokenEvent(SealBrokenRequestEvent sealBrokenEvent) {
        try{
            Container container = RDTCacheManager.getInstance().getContainerDetails(sealBrokenEvent.getContainerId(), sealBrokenEvent.getMoveType());
            if(container != null){
                logger.logMsg(LOG_LEVEL.INFO, sealBrokenEvent.getUserID(), "Marking seal broken for the container " 
                        + sealBrokenEvent.getContainerId());   
                if(container.getIsEmpty()){
                    container.setSealOn(true);
                }else {
                    container.setSealOn(false);
                }
            }
            
            logger.logMsg(LOG_LEVEL.INFO, sealBrokenEvent.getUserID(), "Creating Troublshoot record for container:"
                    + sealBrokenEvent.getContainerId());
    
            User user = RDTCacheManager.getInstance().getUserDetails(sealBrokenEvent.getUserID());
            
            String rotationId = "";
            ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(sealBrokenEvent.getUserID());
            if(allocationEvent != null){
                rotationId = allocationEvent.getRotationID();
            }
            
            TroubleShootRecord record = new TroubleShootRecord();
            record.setContainerId(sealBrokenEvent.getContainerId());
            record.setCreatedBy(user);
            record.setCreatedDateTime(new Date());
            record.setRotationId(rotationId);
            record.setStatus(TroubleShootStatus.PENDING.toString());
            record.setMoveType(sealBrokenEvent.getMoveType());
    
            record.setDamageCode(getSealBrokenCodeFromDB());
    
            // itv = RDTCacheManager.getInstance().getEquipmentDetails(itvs.get(indx));
            record.setItvId(sealBrokenEvent.getItvId());
    
            /*tsArea = RDTCacheManager.getInstance().getTroubleShootAreaById(tsData.getTsAreaId(),
                    message.getTerminalID());*/
            record.setTroubleshootArea(sealBrokenEvent.getTsAreaId());
    
            /* Following Cache Information is used for TroubleSoot Clerk.. */
            RDTCacheManager.getInstance().addTroubleshootRequests(record);
    
            JournalEvent journalEvent = new JournalEvent(record, UPDATETYPE.ADD);
            getSender().tell(journalEvent, null);
        }catch(Exception ex){
            logger.logException("Caught exception while recording the seal broken request ", ex);
        }
    }

    /**
     * Method is responsible to send seal broken code with description to UI. Reading SEAL_ISSUE_TS_ID parameter value
     * from ApplicationParameters cache.Value corresponding to Parameter code is one of the exceptions codes which is
     * defined in MP_EXCEPTION_CODES table. Final response message
     * like:RESP~2208~139456387~123VIn|435yery|QC1234|vin123~TSCode11^Seal Issue~user1~T2
     * 123VIn|435yery|QC1234|vin123:Trouble Shoot Areas TSCode11^Seal Issue:Seal Broken Code with Description
     * 
     * @param SealBrokenRequestEvent
     */
    @SuppressWarnings("unused")
    private void sendSealBrokenCodeWithDesc(SealBrokenRequestEvent sealBrokenReq) {

        logger.logMsg(LOG_LEVEL.INFO, sealBrokenReq.getUserID(), new StringBuilder(ENTRY).append(getClass().getName())
                .append(" sendSealBrokenValues() ").append(INPUT).append(sealBrokenReq.toString()).toString());

        String terminalId = sealBrokenReq.getTerminalID();
        String userId = sealBrokenReq.getUserID();
        String eventId = sealBrokenReq.getEventID();
        StringBuilder troubleShootData = new StringBuilder();
        String eventType = SEAL_BROKEN_RESPONSE;
        try {
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
            Set<TroubleshootAreaMaster> troubleshootAreas = RDTCacheManager.getInstance().getTroubleShootAreas(
                    terminalId);
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
            StringBuilder responseToDevice = new StringBuilder(RESP + VALUE_SEPERATOR + eventTypeID + VALUE_SEPERATOR
                    + eventId + VALUE_SEPERATOR);

            if (troubleshootAreas != null) {
                logger.logMsg(LOG_LEVEL.INFO, userId, "Trouble Shoot Areas Are " + troubleshootAreas.toString());
                for (TroubleshootAreaMaster troubleShootArea : troubleshootAreas) {
                    troubleShootData.append(troubleShootArea.getTroubleshootAreaId()).append(PIPE_SEPERATOR);
                }
                troubleShootData.delete(troubleShootData.length() - 1, troubleShootData.length());

            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId, "No Trouble Shoot Areas Are Found At Current Terminal "
                        + terminalId);
            }

            ExceptionCodeMaster code = getSealBrokenCodeFromDB();
            StringBuilder sealBrokenCodeWithDesc = new StringBuilder();
            if(code != null){
                sealBrokenCodeWithDesc.append(code.getExceptionCode()).append(ITEM_SEPERATOR).append(code.getDescription());
            }
             

            logger.logMsg(LOG_LEVEL.INFO, userId, "Exception Code With Descriptin Is " + sealBrokenCodeWithDesc);
            responseToDevice.append(troubleShootData).append(VALUE_SEPERATOR).append(sealBrokenCodeWithDesc)
                    .append(VALUE_SEPERATOR).append(userId).append(VALUE_SEPERATOR).append(terminalId);

            logger.logMsg(
                    LOG_LEVEL.INFO,
                    userId,
                    new StringBuilder(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
                            .append(responseToDevice.toString()).toString());

            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                    terminalId);
        } catch (Exception ex) {
            logger.logException(" Exception Occured In sendSealBrokenValues() ", ex);
        }
    }

    /**
     * Method is responsible for sending Seal Broken Code with Description
     * 
     * @return
     */
    private ExceptionCodeMaster getSealBrokenCodeFromDB() {

        String sealIssueTsID = "";
        ExceptionCodeMaster exception = null;

        ApplicationParameter sealIssue = RDTPLCCacheManager.getInstance().getApplicationParamter(SEAL_ISSUE_TS_ID);

        if (null != sealIssue) {
            logger.logMsg(LOG_LEVEL.INFO,  "", " Seal_Issue_TS ID From Application Parameters Is " + sealIssueTsID.toString());
            sealIssueTsID = sealIssue.getParameterValue();
            exception = HibernateUtil.getExceptionCodeById(sealIssueTsID);           
        }

        return exception;
    }
}
