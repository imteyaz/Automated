package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.QCPLCConstants.DSCH;
import static com.minapro.procserver.util.QCPLCConstants.LOAD;
import static com.minapro.procserver.util.QCPLCConstants.TWIN;
import static com.minapro.procserver.util.QCPLCConstants.TANDEM;
import static com.minapro.procserver.util.QCPLCConstants.SINGLE;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER1_LOCKEDUP;
import static com.minapro.procserver.util.QCPLCConstants.SPREADER2_LOCKEDUP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_MOVE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_BACKREACH_START_VAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import scala.collection.mutable.StringBuilder;
import akka.actor.ActorRef;
import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.plc.ContainerDetectionEvent;
import com.minapro.procserver.events.plc.ContainerHandleEvent;
import com.minapro.procserver.events.plc.ManualConfirmationAlertEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/*
 * 
 * <p> Actor responsible for Identifying container ID's during container lifting itself 
 * in case of Discharge <p>
 * 
 * @author venkataramana.ch
 * 
 */

public class ContainerIDfromPLCDetectionActor extends UntypedActor {

	private ActorRef masterActor;

	private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
	private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(
			ContainerIDfromPLCDetectionActor.class);

	public ContainerIDfromPLCDetectionActor() {
		this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
	}

	@Override
	/**
	 * Handles  ContainerDetectionEvent
	 */
	public void onReceive(Object message) throws Exception {

		Container plcContainer = null;		
		boolean isTandem;
		String jobKind = SINGLE;
		String[] listOfContainers = null;

		if (message instanceof ContainerDetectionEvent) {

			ContainerDetectionEvent detectionEvent = (ContainerDetectionEvent) message;
			String node = detectionEvent.getNode();
			String userId = detectionEvent.getUserId();
			String spreaderId = detectionEvent.getSpreaderId();

			try {

				double[] lockSidePositions = PLCEventUtil.getInstance()
						.getLockingTimePositions(node, spreaderId, false);
				double[] unLockSidePositions = PLCEventUtil.getInstance().getUnLockingTimePositions(node, spreaderId,
						false);

				String moveType = PLCEventUtil.getInstance().checkMoveType(lockSidePositions, userId, node);
				ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId,
						node);
				
				isTandem = checkIfTandem(userId, spreaderId);

				// Resetting number of locks to zero for next job
				RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);

				// Check if waiting for manual confirmation
				boolean plcIgonreStatus = RDTPLCCacheManager.getInstance().getPlcIgnoreEntry(userId);
				if (!plcIgonreStatus) {

					// Retrieve SpreaderSize to identify job type (i.e Single(20 or 40) or Twin)
					double spreaderSize = RDTPLCCacheManager.getInstance().getSpreaderSizeDetails(userId + spreaderId);

					if (isTandem) {
						jobKind = TANDEM;
					} else if (spreaderSize == 2020) {
						jobKind = TWIN;
					}

					/*
					 * Deriving location to identify container ID in case of Discharge only because we can derive it
					 * after the container lock itself
					 */
					if (DSCH.equalsIgnoreCase(moveType)) {

						double gantryDiff = PLCEventUtil.getInstance().getGantryDiff(userId);
						double[] lockDelta = PLCEventUtil.getInstance().getDeltaValues(node, spreaderId, true);
						int[] positionsDelta = PLCEventUtil.getInstance().getTrolleyHoistGantryDelta(userId,
								lockSidePositions, unLockSidePositions, lockDelta, gantryDiff);

						/*
						 * Difficult to derive exact bay ID in case of drastic bay change due to asymmetric gaps between
						 * bay's in each vessel
						 */
						if (positionsDelta[2] > 1) {

							logger.logMsg(LOG_LEVEL.DEBUG, userId, "Drastic Change of Gantry Detected :  :");
							logger.logMsg(LOG_LEVEL.DEBUG, userId, "Waiting for Manual Confirmation:");
						} else {

							String shiftedCellLocation = PLCEventUtil.getInstance().getShiftedCellLocation(userId,
									positionsDelta, moveType);
							String[] cellTokens = shiftedCellLocation.split("\\.");

							// Store derived cell location for next move
							RDTPLCCacheManager.getInstance().addCurrentCellLocationOfUser(userId, shiftedCellLocation);

							// get the container details on the derived CellLocation from Bay plan
							plcContainer = RDTVesselProfileCacheManager.getInstance().getContainerFromCell(userId,
									cellTokens[0], cellTokens[1], cellTokens[2], DSCH);

							if (plcContainer == null) {
								logger.logMsg(LOG_LEVEL.DEBUG, userId, " Could not found container in Bay plan");
								plcContainer = PLCEventUtil.getInstance().lookForContainerInJobList(userId,
										shiftedCellLocation, jobList, moveType);
							}

							if (plcContainer != null) {

								logger.logMsg(LOG_LEVEL.DEBUG, userId, " GOT THE CONTAINER FROM BAY PROFILE/JOBLIST");
								logger.logMsg(LOG_LEVEL.DEBUG, userId, " From PLC Location :" + shiftedCellLocation
										+ " Container ID :" + plcContainer.getContainerID());

								ContainerHandleEvent handlingEvent = new ContainerHandleEvent();
								handlingEvent.setMoveType(DSCH);
								JobListContainer plcDetectedJob = jobList.get(plcContainer.getContainerID() + DSCH);

								if (!isTandem) {

									// Check job type, single or twin
									if (spreaderSize == 20 || spreaderSize == 40) {
										// check if lifted container is twin container from SPARCS
										if (plcDetectedJob != null && plcDetectedJob.getTwinContainerId() != null
												&& !plcDetectedJob.getTwinContainerId().isEmpty()) {

											logger.logMsg(LOG_LEVEL.DEBUG, userId, " Single Detected but Planned TWIN");

											String twinContainerId = plcDetectedJob.getTwinContainerId();
											handlingEvent.setContainerIDs(plcContainer.getContainerID() + ROW_SEPARATOR
													+ twinContainerId);
										} else {
											logger.logMsg(LOG_LEVEL.DEBUG, userId, " Single Detected");
											handlingEvent.setContainerIDs(plcContainer.getContainerID());
										}
									} else if (spreaderSize == 2020) {
										if (plcDetectedJob != null && plcDetectedJob.getTwinContainerId() == null) {
											logger.logMsg(LOG_LEVEL.DEBUG, userId, " UnPlanned TWIN Detected");
										} else {
											logger.logMsg(LOG_LEVEL.DEBUG, userId, " Planned TWIN");
											if (plcDetectedJob != null) {
												String twinContainerId = plcDetectedJob.getTwinContainerId();
												handlingEvent.setContainerIDs(plcContainer.getContainerID()
														+ ROW_SEPARATOR + twinContainerId);
											} else {
												logger.logMsg(LOG_LEVEL.DEBUG, userId,
														" Unable to get job from job list");
											}

										}
									}
								} else {
									logger.logMsg(LOG_LEVEL.DEBUG, userId, " TANDEM DETECTED");

									if (plcDetectedJob != null) {
										listOfContainers = plcDetectedJob.getTandemContainerIDs();
									}

									if (listOfContainers != null && listOfContainers.length > 0) {
										logger.logMsg(LOG_LEVEL.DEBUG, userId,
												" RECEIVED TANDEM CONTAINERS FROM BAY PROFILE");

										if (listOfContainers.length == 3) {
											logger.logMsg(LOG_LEVEL.DEBUG, userId,
													" FOUR CONTAINERS ARE PLANNED AS TANDEM");
											handlingEvent.setContainerIDs(plcContainer.getContainerID() + ROW_SEPARATOR
													+ listOfContainers[0] + listOfContainers[1] + ROW_SEPARATOR
													+ listOfContainers[2]);

										} else if (listOfContainers.length == 1) {
											logger.logMsg(LOG_LEVEL.DEBUG, userId,
													" TWO CONTAINERS ARE PLANNED AS TANDEM");
											handlingEvent.setContainerIDs(plcContainer.getContainerID() + ROW_SEPARATOR
													+ listOfContainers[0]);
										}
									}
								}

								// Sending container Handling with container ID's
								generateContainerHandlingEvent(userId, handlingEvent);

								// get current container details from job list
								if(jobList != null && !jobList.isEmpty()){
									JobListContainer joblistContainer = (new ArrayList<JobListContainer>(jobList.values())).get(0);
									PLCEventUtil.getInstance().sendWrongContainerPicked(userId, plcContainer,
										joblistContainer, node);
								}
							} else {
								logger.logMsg(LOG_LEVEL.INFO, userId, " DID NOT GET THE CONTAINER FROM BAY PROFILE/JOBLIST");
								RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
							}
						}
					} else {
						if(isBackReachDetected(lockSidePositions[0], node)){
							logger.logMsg(LOG_LEVEL.INFO, userId, "OPERATOR PERFORMING BACKREACH LOAD. WAITING FOR UNLOCK");
						}else {
							handleLoadScenario(userId, node, jobKind, jobList);		
						}
					}
				} else {
					logger.logMsg(LOG_LEVEL.INFO, userId, " WAITING FOR MANUAL CONFIRMATION");
				}
			} catch (Exception e) {
				// Resetting number of locks to zero for next job
				RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
				logger.logException("Caught exception while processing ContainerIDfromPLCDetectionActor - ", e);
			}
		}
	}
	
	/**
	 * Verifies whether the crane is performing BACK REACH LOAD operation based on the trolley position at lock time
	 * 
	 * @param trolleyPositionAtLock
	 * @param node
	 * @return true if trolleyPositionAtLock is less than back reach start value, else false
	 */
	private boolean isBackReachDetected(double trolleyPositionAtLock, String node) {
		 String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
         double backReachStart = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                 QC_BACKREACH_START_VAL));
         logger.logMsg(LOG_LEVEL.DEBUG, userId, "Back Reach Start value = " + backReachStart);
         logger.logMsg(LOG_LEVEL.DEBUG, userId, "Trolley Position Value = " + trolleyPositionAtLock);
         if (trolleyPositionAtLock <= backReachStart) {
        	 return true;
         }
         
		return false;
	}

	/**
	 * Handles the container load scenario. If any load job is promoted by the HC operator, highlights the promoted job.
	 * Else identifies the first load job in the job list and highlight the job.
	 * 
	 * If the job kind identified from the PLC event(SINGLE/TWIN/TANDEM) doens't match with the 
	 * selected job, raises an alert and wait for manual confirmation.
	 * 
	 * If the job kind matches, sends job confirmation message to ESB. And mark the job as pre-confirmed 
	 * in cache.
	 * 
	 * @param userId
	 * @param node
	 * @param jobKind
	 * @param jobList
	 */
	private void handleLoadScenario(String userId, String node, String jobKind, 
			ListOrderedMap<String, JobListContainer> jobList) {
		String selectedJob = RDTCacheManager.getInstance().getSelectedJob(node);
		logger.logMsg(LOG_LEVEL.DEBUG, userId,
				" PERFORMING LOAD--- checking  if any job is pre selected -" + selectedJob);
		JobListContainer selectedContainer = getFirstLoadJobFromJobList(userId, jobList);
		if (selectedJob != null && selectedJob.endsWith(LOAD) && jobList.get(selectedJob) != null) {
			logger.logMsg(LOG_LEVEL.DEBUG, userId, " GOT PRE SELECTED JOB ---" + selectedJob);
			selectedContainer = jobList.get(selectedJob);
		} else if (selectedContainer != null) {
			RDTCacheManager.getInstance().addJobSelection(node,
					selectedContainer.getContainerId() + selectedContainer.getMoveType());
		}

		boolean isAsPlanned = checkJobMoveKindMatchAsPlanned(selectedContainer, jobKind);
		if (isAsPlanned) {
			highLightJob(userId, selectedContainer, jobKind);
			generateContainerConfirmationToESB(selectedContainer, jobKind, userId, node, jobList);
		} else {
			RDTPLCCacheManager.getInstance().addSpreaderLockCountDetails(userId, 0);
			RDTPLCCacheManager.getInstance().addPlcIgnoreEntry(userId, true);
			ManualConfirmationAlertEvent manualConfirmationAlert = PLCEventUtil.getInstance()
					.generateManualAlertEvent(userId, "Detected " + jobKind	+ " move which does not match with Job list");
			PLCEventUtil.getInstance().sendManualConfirmationAlertToOperator(manualConfirmationAlert);
			RDTCacheManager.getInstance().removeJobSelection(node);
		}
	}
	
	/**
	 * Iterates through the job list and finds the first LOAD job. If job list empty or no LOAD jobs present, returns null
	 * @param jobList
	 * @return
	 */
	private JobListContainer getFirstLoadJobFromJobList(String userId, ListOrderedMap<String, JobListContainer> jobList){
		if(jobList != null && !jobList.isEmpty()){
			for(JobListContainer jobContainer : jobList.values()){
				if(LOAD.equalsIgnoreCase(jobContainer.getMoveType())){
					logger.logMsg(LOG_LEVEL.INFO, userId, "First LOAD job in the job list is " + jobContainer);
					return jobContainer;
				}
			}
		}		
		return null;
	}

	/**
	 * Construct and sends the container move event to ESB with preJobConfirmation value set as true
	 * 
	 * @param selectedContainer
	 * @param jobKind
	 * @param user
	 * @param node
	 * @param jobList
	 */
	private void generateContainerConfirmationToESB(JobListContainer selectedContainer, String jobKind, String user,
			String node, ListOrderedMap<String, JobListContainer> jobList) {

		try {
			ContainerMoveEvent movement = new ContainerMoveEvent();
			movement.setEventType(DeviceEventTypes.getInstance().getEventType(CONTAINER_MOVE));
			movement.setUserID(user);
			movement.setTimeStamp(FORMATTER.format(new Date()));
			movement.setEventID(UUID.randomUUID().toString());
			movement.setEquipmentID(node);
			movement.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));
			movement.setAutomaticFlag(true);
			movement.setMoveType(LOAD);
			movement.setPreJobConfirmation(true);

			StringBuilder containerIds = new StringBuilder(selectedContainer.getContainerId());
			StringBuilder fromLocations = new StringBuilder(selectedContainer.getFromLocation());
			StringBuilder toLocations = new StringBuilder(selectedContainer.getToLocation());

			logger.logMsg(LOG_LEVEL.INFO, user, "Updating the jobs as pre-confirmed in the job list");
			selectedContainer.setPreConfirmedJob(true);

			JobListContainer referenceContainer;
			if (jobKind.equals(TWIN)) {
				containerIds.append(ROW_SEPARATOR).append(selectedContainer.getTwinContainerId());
				referenceContainer = jobList.get(selectedContainer.getTwinContainerId() + LOAD);
				referenceContainer.setPreConfirmedJob(true);
				if (referenceContainer != null) {
					fromLocations.append(ROW_SEPARATOR).append(referenceContainer.getFromLocation());
					toLocations.append(ROW_SEPARATOR).append(referenceContainer.getToLocation());
				}
			} else if (jobKind.equals(TANDEM)) {
				String[] tandemReferences = selectedContainer.getTandemContainerIDs();
				for (String tandemContainerId : tandemReferences) {
					containerIds.append(ROW_SEPARATOR).append(tandemContainerId);
					referenceContainer = jobList.get(tandemContainerId + LOAD);
					referenceContainer.setPreConfirmedJob(true);
					if (referenceContainer != null) {
						fromLocations.append(ROW_SEPARATOR).append(referenceContainer.getFromLocation());
						toLocations.append(ROW_SEPARATOR).append(referenceContainer.getToLocation());
					}
				}
			}

			movement.setContainerIDs(containerIds.toString());
			movement.setFromLocations(fromLocations.toString());
			movement.setToLocations(toLocations.toString());

			ESBQueueManager.getInstance().postMessage(movement, OPERATOR.QC, movement.getTerminalID());
		} catch (Exception ex) {
			logger.logException("Caught exception while generateContainerConfirmationToESB", ex);
		}
	}

	/**
	 * Verifies whether the current LOAD job performing by the operator is as per the plan. From PLC, based on the
	 * spreader size identifies the job type - SINGLE, TWIN or TANDEM. And cross verifies with the selected job. If no
	 * jobs pre-selected, then verifies against the first job available in the job list.
	 * 
	 * If jobKind and the container parameters(twinContainerId, TandemContainerIDs) are matching, returns true. Else
	 * false.
	 * 
	 * @param selectedContainer
	 *            - pre selected job
	 * @param jobList
	 * @param jobKind
	 *            - calculated based on the spreader size
	 * 
	 * @return
	 */
	private boolean checkJobMoveKindMatchAsPlanned(JobListContainer selectedContainer, String jobKind) {
		boolean matchPlanned = false;
		try {
			if (selectedContainer != null) {
				if ((SINGLE.equals(jobKind)
						&& (selectedContainer.getTwinContainerId() == null || selectedContainer.getTwinContainerId()
								.isEmpty()) && selectedContainer.getTandemContainerIDs() == null)
						|| (TWIN.equals(jobKind) && selectedContainer.getTwinContainerId() != null
								&& !selectedContainer.getTwinContainerId().isEmpty() && selectedContainer
								.getTandemContainerIDs() == null)
						|| (TANDEM.equals(jobKind) && selectedContainer.getTandemContainerIDs() != null && selectedContainer
								.getTandemContainerIDs().length != 0)) {
					matchPlanned = true;
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while checkJobMoveKindMatchAsPlanned", ex);
			matchPlanned = true;
		}

		logger.logMsg(LOG_LEVEL.INFO, jobKind, " VERIFYING THE PLC DETECTED JOBTYPE WITH SELECTED JOB TYPE="
				+ selectedContainer + ". AND RESULT IS " + matchPlanned);

		return matchPlanned;
	}

	/**
	 * In case of the load, highlights the pre-selected container if any.. else first load job from the users job list. 
	 * 
	 * @param userId
	 * @param jobList
	 */
	private void highLightJob(String userId, JobListContainer selectedContainer, String jobKind) {

		logger.logMsg(LOG_LEVEL.INFO, userId, " LOAD: HIGHLIGHTING CONTAINER FROM JOBLIST");	

		StringBuilder containerIds = new StringBuilder(selectedContainer.getContainerId());
		if (jobKind.equals(TWIN)) {
			containerIds.append(ROW_SEPARATOR).append(selectedContainer.getTwinContainerId());
		} else if (jobKind.equals(TANDEM)) {
			String[] tandemReferences = selectedContainer.getTandemContainerIDs();
			for (String tandemContainerId : tandemReferences) {
				containerIds.append(ROW_SEPARATOR).append(tandemContainerId);
			}
		}
		ContainerHandleEvent handlingEvent = new ContainerHandleEvent();
		handlingEvent.setContainerIDs(containerIds.toString());
		handlingEvent.setMoveType(LOAD);
		generateContainerHandlingEvent(userId, handlingEvent);
	}

	/**
	 * Checks if the current job is tandem. This is determined based on the number of trolley position locks. If both
	 * are locked, it is Tandem operation
	 * 
	 * @param userId
	 * @param spreaderId
	 * @return
	 */
	private boolean checkIfTandem(String userId, String spreaderId) {
		int numberOfLocks = RDTPLCCacheManager.getInstance().getSpreaderLockCountDetails(userId);
		logger.logMsg(LOG_LEVEL.DEBUG, userId, " Number of Spreader Locks :" + numberOfLocks);

		// Checking if job type is Tandem (i.e in case of tandem, number of locks will be 2)
		// One lock for trolley1position another lock for trolley2position
		if (numberOfLocks == 2) {
			performTandemCacheUpdate(userId, spreaderId);
			return true;
		} else {
			RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId, false);
			return false;
		}
	}

	/**
	 * When Tandem move is detected, updates the caches for both spreaders
	 * 
	 * @param userId
	 * @param spreaderId
	 */
	private void performTandemCacheUpdate(String userId, String spreaderId) {

		RDTPLCCacheManager.getInstance().addTandemDetectionDetails(userId, true);

		/*
		 * If its Tandem, Ignore other spreader completely and consider only one spreader because there is not much
		 * difference between the positions of spreader1 & spreader2. also if we consider two spreaders then two jobdone
		 * events will be pushed to PLCJobdoneActor which is wrong
		 */
		if (SPREADER1_LOCKEDUP.equalsIgnoreCase(spreaderId)) {

			logger.logMsg(LOG_LEVEL.DEBUG, userId, " LIFTED WITH SPREADER1");

			// Ignoring Spreader2 (useful in QCSpreder2chageSubscriber())
			RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER2_LOCKEDUP, true);

			// Making Working spreader as Spreader1 since container lifting detected with this spreader
			// ( useful in QCSpreder1chageSubscriber())
			RDTPLCCacheManager.getInstance().addworkingSpreaderMaping(userId, SPREADER1_LOCKEDUP);

			// Making Spreader1 Active( useful in QCSpreder1chageSubscriber())
			RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER1_LOCKEDUP, false);

		} else if (SPREADER2_LOCKEDUP.equalsIgnoreCase(spreaderId)) {

			logger.logMsg(LOG_LEVEL.DEBUG, userId, " LIFTED WITH SPREADER2");

			// Ignoring Spreader1 ( useful in QCSpreder1chageSubscriber())
			RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER1_LOCKEDUP, true);

			// Making Working spreader as Spreader2 since container lifting detected with this spreader
			// (useful in QCSpreder2chageSubscriber())
			RDTPLCCacheManager.getInstance().addworkingSpreaderMaping(userId, SPREADER2_LOCKEDUP);

			// Making Spreader2 Active (useful in QCSpreder2chageSubscriber())
			RDTPLCCacheManager.getInstance().addSpreader1UnlockDetails(userId + SPREADER2_LOCKEDUP, false);
		}
	}

	/**
	 * <p> Responsible for sending container handling event to ContainerHandlingActor. </p>
	 * 
	 * @param userId
	 * @param dateString
	 * @param handlingEvent
	 */
	private void generateContainerHandlingEvent(String userId, ContainerHandleEvent handlingEvent) {
		// Sending Container Handling Event to Master Actor
		String eventTypeID = DeviceEventTypes.getInstance().getEventType(CONTAINER_HANDLING);
		handlingEvent.setEventType(eventTypeID);
		handlingEvent.setUserID(userId);
		handlingEvent.setTimeStamp(FORMATTER.format(new Date()));
		handlingEvent.setEventID(UUID.randomUUID().toString());
		handlingEvent.setTerminalID(DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY));

		logger.logMsg(LOG_LEVEL.INFO, userId, " Sending Container Handling Event to User");
		masterActor.tell(handlingEvent, null);
	}
}
