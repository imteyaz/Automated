package com.minapro.procserver.events.hc;

import java.io.Serializable;

/**
 * ValueObject holding the swap request from the device
 * 
 * @author Rosemary George
 *
 */
public class SwapContainerPosition implements Serializable {

    private static final long serialVersionUID = 6525485734909409580L;
    
    /**
     * Unique Container ID
     */
    private String containerId;    
    
    /**
     * move type - can be LOAD, DSCH or MO
     */
    private String moveType;
    
    /**
     * Jobkey ex., FCIU2419980120161124111708 formed from OPUS interface
     */
    private String jobKey;
    
    /**
     * positionOnChassis Fore or Aft Flag e.g) Fore="F", Aft="A",Center="C" otherwise:""
     */
    private String positionOnChassis;
    
     /**
     * the ITV which is carrying the containers that needs swapping
     */
    private String itvId;
    
    /**
     * Swap status of container in ITV
     */
    private boolean status;
    
    /**
     * Swap status of container in ITV
     */
    private String errorMessage;

    /**
     * the New ITV which is carrying the containers that needs to changed
     */
    private String newItvId;
    
    public String getItvId() {
        return itvId;
    }

    public void setItvId(String itvId) {
        this.itvId = itvId;
    }
        
    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getJobKey() {
        return jobKey;
    }

    public void setJobKey(String jobKey) {
        this.jobKey = jobKey;
    }

    public String getPositionOnChassis() {
        return positionOnChassis;
    }

    public void setPositionOnChassis(String positionOnChassis) {
        this.positionOnChassis = positionOnChassis;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

	public String getNewItvId() {
		return newItvId;
	}

	public void setNewItvId(String newItvId) {
		this.newItvId = newItvId;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errormessage) {
		this.errorMessage = errormessage;
	}

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	@Override
	public String toString() {
		return "SwapContainerPosition [containerId=" + containerId + ", moveType=" + moveType + ", jobKey=" + jobKey
				+ ", positionOnChassis=" + positionOnChassis + ", itvId=" + itvId + ", status=" + status
				+ ", errorMessage=" + errorMessage + ", newItvId=" + newItvId + "]";
	}	
}
