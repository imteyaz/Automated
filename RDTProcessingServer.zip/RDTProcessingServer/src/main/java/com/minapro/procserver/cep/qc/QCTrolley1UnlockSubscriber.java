package com.minapro.procserver.cep.qc;

import static com.minapro.procserver.util.QCPLCConstants.T1_POSITION_UNLOCK;
import static com.minapro.procserver.util.QCPLCConstants.TROLLEY1_POSITION;

import java.util.Map;

import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.util.PLCEventUtil;

/*
 * 
 * <p> Class responsible for detecting Trolley1Position during the container
 * Unlocking time  <p>
 * 
 * @author venkataramana.ch
 * 
 */
public class QCTrolley1UnlockSubscriber implements StatementSubscriber {

    public QCTrolley1UnlockSubscriber() {
    }

    @Override
    public String getStatement() {
        return "context EachQC select a,b from pattern [ every a=EsperPLCEvent(tagName = 'Trolley1Position') -> (((b=EsperPLCEvent(tagName = 'Spreader1Lockedup' and tagValue = unLockedUpTagValue))) and not EsperPLCEvent(tagName = 'Trolley1Position'))]";
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperPLCEvent> eventMap) {
        PLCEventUtil.getInstance().updateCraneMoveUnlockStatus(TROLLEY1_POSITION, T1_POSITION_UNLOCK, eventMap);
    }
}
