package com.minapro.procserver.cep.che;

import java.util.Map;

import akka.actor.ActorRef;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.plc.CHERowChangeDetectionEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Class responsible for detecting the row move in yard position .</p>
 * 
 * <p>The pattern used to detect is row position changed by CHE </p>
 *
 * 
 * @author Kumaraswamy
 *
 */
public class CHERowChangeSubscriber implements StatementSubscriber {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHERowChangeSubscriber.class);

    private ActorRef masterActor;

    @Override
    public String getStatement() {
        return "context EachCHE select event1 from pattern[every ((event1=EsperRMGPLCEvent(yardPos !='')) )]";
    }

    public void update(Map<String, EsperRMGPLCEvent> eventMap) {
        EsperRMGPLCEvent rowMoveEvent = eventMap.get("event1");
        String yardPosition = rowMoveEvent.getYardPos();
        String node = rowMoveEvent.getNode();
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);

        // set the first time yard row number into the cache then next time check the row number match
        if (!yardPosition.isEmpty() && RDTPLCCacheManager.getInstance().getUserTorowChangeByRMG(userId).isEmpty()) {
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "set the row value initially in CHERowCache.");
            // set the row value initially in CHERowCache.
            RDTPLCCacheManager.getInstance().addUserTorowChangeByRMG(userId, yardPosition.split(".")[1].substring(0));
        } else if (!yardPosition.split(".")[1].substring(0).equals(
                RDTPLCCacheManager.getInstance().getUserTorowChangeByRMG(userId))) {
            // checking the row if already exists in cache or not.
            // Updating value in cache. & sending alert message to UI.
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "Not exists the row in Cache");
            String yardRowPosition = yardPosition.split(".")[1].substring(0);
            logger.logMsg(LOG_LEVEL.DEBUG, " ", "updating new row in Cache");
            RDTPLCCacheManager.getInstance().addUserTorowChangeByRMG(userId, yardRowPosition);
            CHERowChangeDetectionEvent cheRowMoveDetectionEvent = new CHERowChangeDetectionEvent();
            cheRowMoveDetectionEvent.setUserID(userId);
            cheRowMoveDetectionEvent.setNode(node);
            cheRowMoveDetectionEvent.setRowPosition(yardRowPosition);
            cheRowMoveDetectionEvent.setYardPosition(yardPosition);
            masterActor.tell(cheRowMoveDetectionEvent, null);
        }
    }
}
