package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the CHEContainer Detection event details
 * 
 * @author Kumaraswamy
 *
 */

public class CHERowChangeDetectionEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6886259447423103109L;

    private String node;
    private String userId;
    private String rowPosition;
    private String yardPosition;

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRowPosition() {
        return rowPosition;
    }

    public void setRowPosition(String rowPosition) {
        this.rowPosition = rowPosition;
    }

    public String getYardPosition() {
        return yardPosition;
    }

    public void setYardPosition(String yardPosition) {
        this.yardPosition = yardPosition;
    }

    @Override
    public String toString() {
        return "CHERowChangeDetectionEvent [node=" + node + ", userId=" + userId + ", rowPosition=" + rowPosition
                + ", yardPosition=" + yardPosition + "]";
    }
}
