package com.minapro.procserver.cep.che;

import java.util.Map;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.ActorRef;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.plc.CHEContainerDetectionEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Class responsible for detecting the container handling when the CHE starts picking up the container.</p>
 * 
 * <p> The pattern used to detect is MP_SpreaderLocked =1 followed by MP_Weight >1.9 </p>
 * 
 * <p> Once the pattern is detected, ContainerHandlingEvent is constructed and send to the master actor for further
 * processing </p>
 * 
 * @author Kumaraswamy
 *
 */
public class CHEContainerHandlingSubscriber implements StatementSubscriber {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEContainerHandlingSubscriber.class);

    private ActorRef masterActor;

    public CHEContainerHandlingSubscriber() {
        this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    @Override
    public String getStatement() {
        // identifies container handling pattern
        //return "context EachCHE select event1 from pattern[every ((event1=EsperRMGPLCEvent(spreader1TwistLock = 1 and spreaderLsWeight > 0)))]";
    	return "context EachCHE select event1,event2 from pattern[every ((event1=EsperRMGPLCEvent(spreader1TwistLock = 1))"
		 + "-> ((event2=EsperRMGPLCEvent(spreaderLsWeight>0))))]";
    
    }

    /**
     * Listener gets called when the container handling pattern is detected
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperRMGPLCEvent> eventMap) {
        EsperRMGPLCEvent lockedUpEvent = eventMap.get("event1");
        EsperRMGPLCEvent event2 = eventMap.get("event2");
        String node = lockedUpEvent.getNode();
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
        
        //logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE Received Lock event :" + lockedUpEvent);
        //logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE Received Lock event with Weight >0" + event2);
        
        logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE Container Lifted Status :" + RDTPLCCacheManager.getInstance().getContainerLiftedDetails(userId));
        
        if (userId != null) {
            boolean isLifted = RDTPLCCacheManager.getInstance().getContainerLiftedDetails(userId);
            if (!isLifted) {
                StringBuilder sb = new StringBuilder();
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);
                sb.append("\n* [ALERT] : CHE Container Handling DETECTED! OF USER " + userId);
                sb.append(MinaproLoggerConstants.LINE_FORMATTER);
                logger.logMsg(LOG_LEVEL.DEBUG, userId, sb.toString());
                
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE Received Lock event :" + lockedUpEvent);
                
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE Received Lock event with Weight >0 :" + event2);
                
                EventUtil.getInstance().checkAndTriggerOpenEndDelay(userId, node);
                                
                RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId, true);
                CHEContainerDetectionEvent cheDetectionEvent = new CHEContainerDetectionEvent();
                cheDetectionEvent.setNode(node);
                cheDetectionEvent.setUserId(userId);
                cheDetectionEvent.setSpreaderId("SPREADER1_TWIST_LOCK");
                cheDetectionEvent.setYardPosition(event2.getYardPos());
                cheDetectionEvent.setLaneId(event2.getLaneId());
                cheDetectionEvent.setWeight((float)event2.getSpreaderLsWeight());
                cheDetectionEvent.setSize(event2.getSpreader1Size());
                // Identifying the JOB type using spreader size.
                int spreaderSize = Integer.valueOf(event2.getSpreader1Size());
                PLCEventUtil.getInstance().saveCurrentJobType(userId, spreaderSize);
                
                logger.logMsg(LOG_LEVEL.DEBUG, userId, "SENDING CHE DETECTION TO CONTAINER ACTOR");

                ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId,
                        node);

                // Check for Job list is Empty or Not
                if (jobList!=null && !jobList.isEmpty()) {
                    masterActor.tell(cheDetectionEvent, null);
                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, userId, " CHE JOB List is Empty");
                }
            }
        }
    }
}
