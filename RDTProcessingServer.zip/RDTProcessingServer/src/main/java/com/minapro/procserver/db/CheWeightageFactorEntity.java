package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="MP_CHE_WEIGHTAGE_FACTOR")
public class CheWeightageFactorEntity extends Audit implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private CheWeightageFactorPK id;
	@Column(name="WF_SCORE")
	private double weightageScore;
	
	@Column(name="WF_FACTOR")
	private double weightageFactor;
	
	
	public double getWeightageScore() {
		return weightageScore;
	}
	
	public CheWeightageFactorPK getId() {
		return id;
	}
	public void setId(CheWeightageFactorPK id) {
		this.id = id;
	}
	public void setWeightageScore(double weightageScore) {
		this.weightageScore = weightageScore;
	}
	public double getWeightageFactor() {
		return weightageFactor;
	}
	public void setWeightageFactor(double weightageFactor) {
		this.weightageFactor = weightageFactor;
	}
	
	@Override
	public String toString() {
		return "CheWeightageFactorEntity [Weightage Type =" + id.getWeightageType() + 
				" Weightage Criteria = "+id.getWeightageCritaria()+", weightageScore="
				+ weightageScore + ", weightageFactor=" + weightageFactor
				+ ",CreatedBy=" + getCreatedBy()
				+ "]";
	}
}
