package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.minapro.procserver.db.Audit;

/**
 * ValueObjcet holding the template header details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_NUMSRSHDR_SPM")
public class TemplateHeader extends Audit implements Serializable {

    private static final long serialVersionUID = -7920596353659481286L;

    @Id
    @Column(name = "NUMSRS_ID")
    private String headerId;

    @Column(name = "NUMSRS_TYPE")
    private String type;

    @Column(name = "IS_DEFAULT")
    private String isDefault;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "templateHeader")
    private Set<TemplateDetails> templateDetails = new TreeSet<TemplateDetails>();

    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public Set<TemplateDetails> getTemplateDetails() {
        return templateDetails;
    }

    public void setTemplateDetails(Set<TemplateDetails> templateDetails) {
        this.templateDetails = templateDetails;
    }
}
