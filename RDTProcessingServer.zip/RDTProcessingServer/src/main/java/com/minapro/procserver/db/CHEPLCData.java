package com.minapro.procserver.db;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the RMG PLC details
 * 
 * @author Kumaraswamy
 *
 */
@Entity
@Table(name = "MINAPRO_PLC_RMG")
public class CHEPLCData {
    @EmbeddedId
    private CHEPlcPK plcpk;

    @Column(name = "SPREADER_LS_WEIGHT")
    private String spreaderLsWeight;

    @Column(name = "SPREADER1_SIZE")
    private String spreader1Size;

    @Column(name = "YARD_POS")
    private String yardPos;

    @Column(name = "TROLLEY_POS")
    private String trolleyPos;

    @Column(name = "TERMINAL_ID")
    private String terminalId;

    @Column(name = "CONTROL_SYSTEM_TYPE")
    private String controlSystemType;

    @Column(name = "SPREADER1_TWIST_LOCK")
    private String spreader1TwistLock;

    @Column(name = "LANE_ID")
    private String laneId;
    
    public String getLaneId() {
		return laneId;
	}

	public void setLaneId(String laneId) {
		this.laneId = laneId;
	}
	
    public CHEPlcPK getPlcpk() {
        return plcpk;
    }

    public void setPlcpk(CHEPlcPK plcpk) {
        this.plcpk = plcpk;
    }

    public String getSpreaderLsWeight() {
        return spreaderLsWeight;
    }

    public void setSpreaderLsWeight(String spreaderLsWeight) {
        this.spreaderLsWeight = spreaderLsWeight;
    }

    public String getSpreader1Size() {
        return spreader1Size;
    }

    public void setSpreader1Size(String spreader1Size) {
        this.spreader1Size = spreader1Size;
    }

    public String getYardPos() {
        return yardPos;
    }

    public void setYardPos(String yardPos) {
        this.yardPos = yardPos;
    }

    public String getTrolleyPos() {
        return trolleyPos;
    }

    public void setTrolleyPos(String trolleyPos) {
        this.trolleyPos = trolleyPos;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getControlSystemType() {
        return controlSystemType;
    }

    public void setControlSystemType(String controlSystemType) {
        this.controlSystemType = controlSystemType;
    }

    public String getSpreader1TwistLock() {
        return spreader1TwistLock;
    }

    public void setSpreader1TwistLock(String spreader1TwistLock) {
        this.spreader1TwistLock = spreader1TwistLock;
    }

	@Override
	public String toString() {
		return "CHEPLCData [plcpk=" + plcpk + ", spreaderLsWeight="
				+ spreaderLsWeight + ", spreader1Size=" + spreader1Size
				+ ", yardPos=" + yardPos + ", trolleyPos=" + trolleyPos
				+ ", terminalId=" + terminalId + ", controlSystemType="
				+ controlSystemType + ", spreader1TwistLock="
				+ spreader1TwistLock + ", laneId=" + laneId + "]";
	}

}
