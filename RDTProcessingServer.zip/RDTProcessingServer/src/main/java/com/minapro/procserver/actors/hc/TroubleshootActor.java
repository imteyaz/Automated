package com.minapro.procserver.actors.hc;

import static com.minapro.procserver.util.MinaproLoggerConstants.COMM_QUEUE_MGR;
import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.FINAL_CREATED_MSG;
import static com.minapro.procserver.util.MinaproLoggerConstants.INPUT;
import static com.minapro.procserver.util.MinaproLoggerConstants.POST_DATA;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TROUBLESHOOT_AREAS_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.ExceptionCodeMaster;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TroubleShootRecord;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.hc.TroubleShootDetails;
import com.minapro.procserver.events.hc.TroubleshootAreasGetRequestEvent;
import com.minapro.procserver.events.hc.TroubleshootConfirmRequestEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.DriveType;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.TroubleShootStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for handling all trouble shoot related activities. If any damage or problem occurred to the
 * container,logged in user needs to pick troubleshoot area and error code in the UI screen and After that request needs
 * to send deleted containers information to all the users and remove those containers from the JobList and send updated
 * JobList into ESB server.
 * 
 * @author UMAMAHESH M
 *
 */
public class TroubleshootActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(TroubleshootActor.class);
    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof TroubleshootAreasGetRequestEvent) {
            sendTroubleShootAreas((TroubleshootAreasGetRequestEvent) message);
        } else if (message instanceof TroubleshootConfirmRequestEvent) {
            handleTroubleshootRequest((TroubleshootConfirmRequestEvent) message);
        }
    }

    /**
     * Method Is responsible for getting Trouble shoot ares and exceptions codes from the cache. After that posting data
     * to the COMM server with TroubleShootAreas POJO
     * 
     * @param TroubleShootAreas
     *            POJO
     */
    private void sendTroubleShootAreas(TroubleshootAreasGetRequestEvent troubleshootAreaEvent) {
        logger.logMsg(LOG_LEVEL.INFO, troubleshootAreaEvent.getUserID(),
                new StringBuilder(ENTRY).append(getClass().getName()).append(" sendTroubleShootAreas() ").append(INPUT)
                        .append(troubleshootAreaEvent.toString()).toString());

        try {
            String terminalId = troubleshootAreaEvent.getTerminalID();
            String userId = troubleshootAreaEvent.getUserID();
            String eventId = troubleshootAreaEvent.getEventID();
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);

            String eventType = TROUBLESHOOT_AREAS_RESPONSE;

            Set<TroubleshootAreaMaster> troubleshootAreas = RDTCacheManager.getInstance().getTroubleShootAreas(
                    terminalId);

            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

            // Get Break Reason Code,And Get Data From Cache,Sending Response To CommServer
            StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventTypeID) 
            		.append(VALUE_SEPERATOR).append(eventId).append(VALUE_SEPERATOR);
            
            StringBuilder troubleShootData = new StringBuilder();

            StringBuilder exceptionCodes = getExceptionCodes();

            if (troubleshootAreas != null && !troubleshootAreas.isEmpty()) {
                logger.logMsg(LOG_LEVEL.INFO, userId, "Trouble Shoot Areas Are " + troubleshootAreas.toString());
                for (TroubleshootAreaMaster troubleShootArea : troubleshootAreas) {
                    troubleShootData.append(troubleShootArea.getTroubleshootAreaId()).append(ROW_SEPERATOR);
                }
                troubleShootData.delete(troubleShootData.length() - 1, troubleShootData.length());

            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId, "No Trouble Shoot Areas Are Found At Current Terminal "
                        + terminalId);
            }
            responseToDevice.append(troubleShootData).append(VALUE_SEPERATOR).append(exceptionCodes)
                    .append(VALUE_SEPERATOR).append(userId).append(VALUE_SEPERATOR).append(terminalId);

            logger.logMsg(
                    LOG_LEVEL.INFO,
                    userId,
                    new StringBuilder(POST_DATA).append(COMM_QUEUE_MGR).append(FINAL_CREATED_MSG)
                            .append(responseToDevice.toString()).toString());

            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                    terminalId);

        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in sendTroubleShootAreas() ").append(REASON)
                            .toString(), ex);
        }
    }

    /**
     * Method is responsible for Processing user selected trouble shoot area and exception codes Send instructions to
     * ITV user Send container move event to SPARCS system.
     * 
     * Saves the troubleshoot record in DB as well as in Cache. A trouble shoot record will be created for each of the
     * exception code selected per container. For example : if two containers are part of the troubleshoot message with
     * 5 troubleshoot codes, 10 troubleshoot records will be created in DB and Cache.
     * 
     * @param message
     */
    @SuppressWarnings("unchecked")
    private void handleTroubleshootRequest(TroubleshootConfirmRequestEvent message) {
        logger.logMsg(LOG_LEVEL.INFO, message.getUserID(),
                new StringBuilder(ENTRY).append(" handleTroubleshootRequest() ").append(INPUT).append(message)
                        .toString());

        List<TroubleShootDetails> tsDetails = message.getTsDetails();

        List<ExceptionCodeMaster> exceptionCodes = (List<ExceptionCodeMaster>) HibernateUtil.loadMasterData(
                ExceptionCodeMaster.class, null, true);

        User createdUser = RDTCacheManager.getInstance().getUserDetails(message.getUserID());
        String rotationId = ((ConfirmAllocationEvent) RDTCacheManager.getInstance().getAllocationDetails(
                message.getUserID())).getRotationID();

        TroubleShootRecord record;
        ExceptionCodeMaster codeMaster;
       
        String[] tsCodes;
        for (TroubleShootDetails tsData : tsDetails) {
            tsCodes = tsData.getTroubleShootCodes();

            logger.logMsg(LOG_LEVEL.INFO, createdUser.getUserID(), "Creating Troublshoot record for container:"
                    + tsData.getContainerID());

            for (String code : tsCodes) {
                record = new TroubleShootRecord();
                record.setContainerId(tsData.getContainerID());
                record.setCreatedBy(createdUser);
                record.setCreatedDateTime(new Date());
                record.setRotationId(rotationId);
                record.setStatus(TroubleShootStatus.PENDING.toString());
                record.setMoveType(message.getMoveType());

                codeMaster = getTroubleshootCode(exceptionCodes, code);
                record.setDamageCode(codeMaster);

                // itv = RDTCacheManager.getInstance().getEquipmentDetails(itvs.get(indx));
                record.setItvId(tsData.getItvId());

                /*
                 * tsArea = RDTCacheManager.getInstance().getTroubleShootAreaById(tsData.getTsAreaId(),
                 * message.getTerminalID());
                 */
                record.setTroubleshootArea(tsData.getTsAreaId());

                /* Following Cache Information is used for TroubleSoot Clerk.. */
                RDTCacheManager.getInstance().addTroubleshootRequests(record);

                JournalEvent journalEvent = new JournalEvent(record, UPDATETYPE.ADD);
                getSender().tell(journalEvent, null);
            }
        }
    }

    /**
     * Iterates the Exception list and returns the ExceptionCode matches with the specified tsCode, else returns null
     * 
     * @param exceptionCodes
     * @param tsCode
     * @return
     */
    private ExceptionCodeMaster getTroubleshootCode(List<ExceptionCodeMaster> exceptionCodes, String tsCode) {
        for (ExceptionCodeMaster exceptionCode : exceptionCodes) {
            if (exceptionCode.getExceptionCode().equalsIgnoreCase(tsCode)) {
                return exceptionCode;
            }
        }
        return null;
    }

    /**
     * Method is responsible for sending drive instruction to the corresponding ITV driver
     * 
     * @param troubleshootRequest
     *            POJO
     * 
     */
    @SuppressWarnings("unused")
    private DriveInstructionEvent createDriveInstructionToITV(TroubleshootConfirmRequestEvent troubleshootRequest,
            String itvId, String troubleShootArea) {

        logger.logMsg(
                LOG_LEVEL.INFO,
                troubleshootRequest.getUserID(),
                new StringBuilder(ENTRY).append(" createDriveInstructionToITV() ").append(INPUT)
                        .append(troubleshootRequest.toString()).toString());
        DriveInstructionEvent driveInstruction = new DriveInstructionEvent();
        try {

            // Getting ITV userId with iTVid.
            String iTVUserId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(itvId);

            /* Setting DriveInstructionEvent with TroubleshootConfirmRequest event result values */
            driveInstruction.setUserID(iTVUserId);
            // driveInstruction.setContainerIds(troubleshootRequest.getContainerIds());
            driveInstruction.setTerminalID(troubleshootRequest.getTerminalID());
            driveInstruction.setDriveType(DriveType.TS);
            driveInstruction.setEventID(UUID.randomUUID().toString());
            driveInstruction.setLocationID(troubleShootArea);
        } catch (Exception ex) {
            logger.logException(
                    new StringBuilder(EXCEPTION_OCCURED).append(" in sendDriveInstructionToITV() ").append(REASON)
                            .toString(), ex);
        }

        return driveInstruction;
    }

    /**
     * Method is responsible for retrieving available exception codes in database and created sample message with
     * exception codes with pipe separator.
     *
     * @return TSCode1^Leaking Container|TSCode2^Incorrect Container Number|TSCode3^Reefer Malfunction|TSCode4^Lashing
     *         Issue (for OOG) like that
     */
    @SuppressWarnings("unchecked")
    private StringBuilder getExceptionCodes() {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" getExceptionCodes() ").toString());
        StringBuilder exceptions = new StringBuilder();
        try {
            List<ExceptionCodeMaster> exceptionCodes = (List<ExceptionCodeMaster>) HibernateUtil.loadMasterData(
                    ExceptionCodeMaster.class, null, true);
            if (exceptionCodes != null && !exceptionCodes.isEmpty()) {
                for (ExceptionCodeMaster exceptionMaster : exceptionCodes) {
                    exceptions.append(exceptionMaster.getExceptionCode()).append(ITEM_SEPERATOR)
                            .append(exceptionMaster.getDescription()).append(ROW_SEPERATOR);
                }
                exceptions.delete(exceptions.length() - 1, exceptions.length());
            } else {
                logger.logMsg(LOG_LEVEL.INFO, "", "Exception Codes are not available,List Is Empty");
            }
            logger.logMsg(LOG_LEVEL.INFO, "", "Exception Codes Are " + exceptions.toString());
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" in getExceptionCodes() ").append(REASON)
                    .toString(), ex);
        }
        return exceptions;
    }
}

/*
    *//**
 * Send container moved indication to SPARCS system.
 * 
 * @param troubleShootRequest
 *            POJO with troubleshoot area id and exception code
 */
/*
 * private void sendContainerMoveEventToSparcs(TroubleshootConfirmRequestEvent tsRequest) {
 * 
 * logger.logMsg(LOG_LEVEL.INFO, tsRequest.getUserID(), new
 * StringBuilder(ENTRY).append(getClass().getName()).append(" sendContainerMoveEventToSparcs() ")
 * .append(INPUT).append(tsRequest.toString()).toString()); try { OPERATOR role =
 * RDTCacheManager.getInstance().getUserLoggedInRole(tsRequest.getUserID());
 * 
 * if (OPERATOR.HC.equals(role)) {
 * tsRequest.setEquipmentID(RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(tsRequest.getUserID())); }
 * 
 * if(((role.equals(OPERATOR.HC)|| role.equals(OPERATOR.QC)) && tsRequest.getMoveType().equalsIgnoreCase(DSCH)) ||
 * (role.equals(OPERATOR.CHE) && (tsRequest.getMoveType().equalsIgnoreCase(LOAD) ||
 * tsRequest.getMoveType().equalsIgnoreCase(DELIVERY)))){ logger.logMsg(LOG_LEVEL.INFO, tsRequest.getUserID(),
 * "Send ContainerMove to message to master actor as the moveType is " + tsRequest.getMoveType());
 * 
 * ContainerMoveEvent cntrMoveEvent = new ContainerMoveEvent(); cntrMoveEvent.setAutomaticFlag(false);
 * cntrMoveEvent.setUserID(tsRequest.getUserID()); cntrMoveEvent.setEquipmentID(tsRequest.getEquipmentID());
 * cntrMoveEvent.setTerminalID(tsRequest.getTerminalID()); cntrMoveEvent.setEventID(UUID.randomUUID().toString());
 * cntrMoveEvent.setMoveType(tsRequest.getMoveType());
 * 
 * StringBuilder containers = new StringBuilder(); StringBuilder fromLocations = new StringBuilder(); StringBuilder
 * toLocations = new StringBuilder(); JobListContainer container = null; int index = 0; for (String containerId :
 * tsRequest.getContainerIds()) { containers.append(containerId).append(ROW_SEPERATOR);
 * toLocations.append(tsRequest.getITVId().get(index)).append(ROW_SEPERATOR); container =
 * RDTCacheManager.getInstance().getJobList(tsRequest.getUserID(), tsRequest.getEquipmentID()).get(containerId);
 * if(container != null){ fromLocations.append(container.getFromLocation()).append(ROW_SEPERATOR); } index++; }
 * 
 * cntrMoveEvent.setContainerIDs(containers.toString()); cntrMoveEvent.setFromLocations(fromLocations.toString());
 * cntrMoveEvent.setToLocations(toLocations.toString());
 * 
 * logger.logMsg(LOG_LEVEL.INFO, tsRequest.getUserID(), "calling ContainerMove Actor with ContainerMoveEvent " +
 * cntrMoveEvent.toString()); RDTProcessingServer.getInstance().getMasterActor().tell(cntrMoveEvent, getSelf()); }else {
 * logger.logMsg(LOG_LEVEL.INFO, tsRequest.getUserID(), "No need to confirm container to SPARCS as the moveType is " +
 * tsRequest.getMoveType()); } } catch (Exception ex) { logger.logException(new
 * StringBuilder(EXCEPTION_OCCURED).append(" in sendContainerMoveEventToSparcs() ") .append(REASON).toString(), ex); } }
 * }
 */