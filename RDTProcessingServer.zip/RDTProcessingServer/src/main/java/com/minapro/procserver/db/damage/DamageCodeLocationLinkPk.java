package com.minapro.procserver.db.damage;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Primary Key for the damageCodeLocationLink table
 * 
 * @author Rosemary George
 *
 */
@Embeddable
public class DamageCodeLocationLinkPk implements Serializable {

    private static final long serialVersionUID = 6057005611325783560L;

    // foreign key references DAMAGECODE_MASTER
    @Column(name = "DAMAGE_CODE")
    private String damageCode;

    // FOREIGNKEY REFERENCES "MP_DAMAGECODE_LOCATION
    @Column(name = "DAMAGE_LOCATION")
    private String damageLocation;

    public String getDamageCode() {
        return damageCode;
    }

    public void setDamageCode(String damageCode) {
        this.damageCode = damageCode;
    }

    public String getDamageLocation() {
        return damageLocation;
    }

    public void setDamageLocation(String damageLocation) {
        this.damageLocation = damageLocation;
    }
}
