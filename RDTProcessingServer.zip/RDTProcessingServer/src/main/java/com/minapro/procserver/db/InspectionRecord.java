package com.minapro.procserver.db;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the inspection record details which needs to be persisted in DB
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_INSPECTION_RECORD")
public class InspectionRecord implements Serializable {
    private static final long serialVersionUID = 2141930246978008307L;

    @Id
    @SequenceGenerator(name = "my_gen", sequenceName = "MP_INSPECTION_RECORD_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "my_gen")
    @Column(name = "INSPECTION_ID", nullable = false)
    private Integer inspectionId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_NM")
    private User user;

    @Column(name = "INSPECTION_TIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date inspectionTime;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "REMARKS")
    private String remarks;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.checkListItem", cascade = CascadeType.ALL)
    private Set<InspectionCheckListMapping> checkListItems = new HashSet<InspectionCheckListMapping>();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CHECKLIST_HDR_ID", referencedColumnName = "CHECKLIST_HDR_ID")
    private CheckListHeader checkListHeader;

    public CheckListHeader getCheckListHeader() {
        return checkListHeader;
    }

    public void setCheckListHeader(CheckListHeader checkListHeader) {
        this.checkListHeader = checkListHeader;
    }

    public Set<InspectionCheckListMapping> getCheckListItems() {
        return checkListItems;
    }

    public void setCheckListItems(Set<InspectionCheckListMapping> checkListItems) {
        this.checkListItems = checkListItems;
    }

    public Integer getInspectionId() {
        return inspectionId;
    }

    public void setInspectionId(Integer inspectionId) {
        this.inspectionId = inspectionId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getInspectionTime() {
        return inspectionTime;
    }

    public void setInspectionTime(Date inspectionTime) {
        this.inspectionTime = inspectionTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String toString() {
        return "InspectionRecord [inspection_id=" + inspectionId + ", user=" + user + ", inspection_time="
                + inspectionTime + ", status=" + status + ", remarks=" + remarks + ", checkListItems=" + checkListItems
                + "]";
    }
}
