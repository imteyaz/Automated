package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.TERMINAL_KEY;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.events.common.OperatorMessageRequestEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Poller Actor responsible for firing the operator message request event to ESB at periodic interval of 3 minutes.
 * 
 * @author Rosemary George
 *
 */
public class OperatorMessagePollerActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(OperatorMessagePollerActor.class);
	
	@Override
	public void onReceive(Object message) throws Exception {
		logger.logMsg(LOG_LEVEL.INFO, "", "Started Operator Message Poller");
		
		try {			
			List<String> loggedInEquipments = getLoggedInEquipments();
			if(!loggedInEquipments.isEmpty()){
				String terminalId = DeviceCommParameters.getInstance().getCommParameter(TERMINAL_KEY);
				OperatorMessageRequestEvent requestEvent = new OperatorMessageRequestEvent();
				requestEvent.setEventID(UUID.randomUUID().toString());		
				requestEvent.setTerminalID(terminalId);
				requestEvent.setLoggedInEquipments(loggedInEquipments);
				ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.COMMON, terminalId);
			}else {
				logger.logMsg(LOG_LEVEL.DEBUG, "POLLER", "Currently no logged in users");
			}
		}catch(Exception ex){
			logger.logException("Caught exception in OperatorMessagePollerActor ", ex);
		}
	}

	private List<String> getLoggedInEquipments() {
		List<String> loggedInEquipments = new ArrayList<String>();
		
		Set<String> allocatedUsers = RDTCacheManager.getInstance().getAllocatedUsers();	
		String equipmentId;
		if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {
			for (String currentUser : allocatedUsers) {
				equipmentId = RDTPLCCacheManager.getInstance().getSignedInEquipmentIdForUser(currentUser);
				if(equipmentId != null){
					loggedInEquipments.add(equipmentId);
				}
			}
		}
		
		return loggedInEquipments;
	}
}
