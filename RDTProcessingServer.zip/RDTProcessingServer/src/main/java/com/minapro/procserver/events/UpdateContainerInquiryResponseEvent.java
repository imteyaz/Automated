package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.Set;

public class UpdateContainerInquiryResponseEvent extends Event implements
		Serializable {

	private static final long serialVersionUID = -7309931274611432758L;
	
	 /**
     * Indicates whether the particular container details were retrieved or not. 
     * True means, the inquiry successful, else false
     */
    private boolean inquiryStatus;

    private UpdateContainerEvent updateContainerEvent;    
    private Set<String> isoCodes;

	public boolean isInquiryStatus() {
		return inquiryStatus;
	}

	public Set<String> getIsoCodes() {
		return isoCodes;
	}

	public void setIsoCodes(Set<String> isoCodes) {
		this.isoCodes = isoCodes;
	}

	public void setInquiryStatus(boolean inquiryStatus) {
		this.inquiryStatus = inquiryStatus;
	}

	public UpdateContainerEvent getUpdateContainerEvent() {
		return updateContainerEvent;
	}

	public void setUpdateContainerEvent(UpdateContainerEvent updateContainerEvent) {
		this.updateContainerEvent = updateContainerEvent;
	}

	@Override
	public String toString() {
		return "UpdateContainerInquiryResponseEvent [inquiryStatus="
				+ inquiryStatus + ", UpdateContainerEvent="
				+ updateContainerEvent + ", getUserID()=" + getUserID()
				+ ", getEquipmentID()=" + getEquipmentID()
				+ ", getTerminalID()=" + getTerminalID() + ", getEventID()="
				+ getEventID() + "]";
	}
}
