package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REEFER_CONNECTED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REEFER_DISCONNECTED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.che.ReeferConnectionResponseEvent;
import com.minapro.procserver.events.che.ReeferWithStatusEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ReeferStatusResponseActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ReeferStatusResponseActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(ON_RECEIVE).toString());
        if (message instanceof ReeferConnectionResponseEvent) {

            ReeferConnectionResponseEvent reeferStatusResponse = (ReeferConnectionResponseEvent) message;

            sendReeferStatusToDevice(reeferStatusResponse);
        } else {
            unhandled(message);
        }
    }

    public void sendReeferStatusToDevice(ReeferConnectionResponseEvent reeferStatusResponse) {

        logger.logMsg(LOG_LEVEL.INFO, reeferStatusResponse.getUserID(), "Sending Reefers Status");

        List<ReeferWithStatusEvent> reefersWithStatus = reeferStatusResponse.getReeferContainersList();

        StringBuilder containersInfo = new StringBuilder();
        String currentStatus;

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(
                RDTProcessingServerConstants.REEFER_STATUS_NOTIF);

        OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(reeferStatusResponse.getUserID());

        // get the job list message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(
                RDTProcessingServerConstants.REEFER_STATUS_NOTIF);

        // build the response to the device
        StringBuilder responseToDevice = null;
        String msgField;

        responseToDevice = new StringBuilder(NOTIF + VALUE_SEPARATOR + eventTypeID);

        for (ReeferWithStatusEvent reefer : reefersWithStatus) {

            // get the container from central cache
            Container bayProfileContainer = RDTCacheManager.getInstance().getContainerDetails(reefer.getContainerId(), reefer.getMoveType());

            if (bayProfileContainer != null) {

                if (reefer.isConnected()) {
                    currentStatus = "T";
                } else {
                    currentStatus = "F";
                }

                if (!bayProfileContainer.getReeferStatus().equalsIgnoreCase(currentStatus)) {

                    containersInfo.append(reefer.getContainerId()).append(ITEM_SEPARATOR).append(currentStatus)
                            .append(ROW_SEPARATOR);
                    RDTCacheManager.getInstance().addContainer(bayProfileContainer, reefer.getMoveType());

                }
            } else {
                logger.logMsg(LOG_LEVEL.INFO, reeferStatusResponse.getUserID(),
                        "Container does not exist in bayProfile :" + reefer.getContainerId());
            }

        }

        // iterate through the jobList message formats
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(VALUE_SEPARATOR);
            msgField = msgFields.get(i);

            if ("ContainerIDs".equalsIgnoreCase(msgField)) {

                responseToDevice.append(containersInfo);

            } else if ("TimeStamp".equalsIgnoreCase(msgField)) {

                SimpleDateFormat formatter = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
                String currentTimestamp = formatter.format(new Date());
                responseToDevice.append(currentTimestamp);

            } else if ("ConnectedColor".equalsIgnoreCase(msgField)) {

                responseToDevice.append(RDTVesselProfileCacheManager.getInstance().getColourCode(REEFER_CONNECTED));

            } else if ("DisconnectedColor".equalsIgnoreCase(msgField)) {

                responseToDevice.append(RDTVesselProfileCacheManager.getInstance().getColourCode(REEFER_DISCONNECTED));
            } else {
                EventUtil.getInstance().getEventParameter(reeferStatusResponse, msgField, responseToDevice);
            }
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                reeferStatusResponse.getTerminalID());

    }
}
