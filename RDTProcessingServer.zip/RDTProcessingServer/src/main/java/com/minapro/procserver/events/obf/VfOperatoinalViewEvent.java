package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * Vessel Foreman View Event.
 * 
 * @author Prasad.Tallapally
 *
 */
public class VfOperatoinalViewEvent extends Event implements Serializable {
    private static final long serialVersionUID = -1946605268899319378L;
}
