package com.minapro.procserver.db.bayprofile;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * ValueObject holding the row details per bay
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_BAYROW_SPM")
public class BayRow {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset + rowOffset
     */
    @EmbeddedId
    private BayRowPk pk;

    @Column(name = "VSL_ROW_NO")
    private String vesselRowNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false) })
    private VesselSection section;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false)
    private Vessel vessel;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false),
            @JoinColumn(name = "DK_UNDK_IND", referencedColumnName = "DK_UNDK_IND", insertable = false, updatable = false),
            @JoinColumn(name = "BAY_OFFSET", referencedColumnName = "BAY_OFFSET", insertable = false, updatable = false) })
    private Bay bay;

    public BayRowPk getPk() {
        return pk;
    }

    public void setPk(BayRowPk pk) {
        this.pk = pk;
    }

    public String getVesselRowNo() {
        return vesselRowNo;
    }

    public void setVesselRowNo(String vesselRowNo) {
        this.vesselRowNo = vesselRowNo;
    }

    public VesselSection getSection() {
        return section;
    }

    public void setSection(VesselSection section) {
        this.section = section;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public void setVessel(Vessel vessel) {
        this.vessel = vessel;
    }

    public Bay getBay() {
        return bay;
    }

    public void setBay(Bay bay) {
        this.bay = bay;
    }

    @Transient
    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    @Transient
    public int getRowOffset() {
        return pk.getRowOffset();
    }

    public void setRowOffset(int rowOffset) {
        pk.setRowOffset(rowOffset);
    }
}
