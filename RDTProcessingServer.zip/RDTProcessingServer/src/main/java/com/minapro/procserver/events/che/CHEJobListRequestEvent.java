package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class CHEJobListRequestEvent extends Event implements Serializable{


    private static final long serialVersionUID = -5510733174809973457L;

    private String location;

    /**
     * Indicates whether the request is initiated from the scheduler or not
     */
    private boolean isScheduled;
    
    private String password;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

  
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "JobListRequestEvent [location=" + location + ", isScheduled=" + isScheduled + ","
        		+ " getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }


}
