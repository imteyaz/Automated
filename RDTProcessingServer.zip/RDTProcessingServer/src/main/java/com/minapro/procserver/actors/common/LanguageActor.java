package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LANGUAGES_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.LanguageMaster;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.common.LanguageChangeReqEvent;
import com.minapro.procserver.events.common.LanguagesGetRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for handling all language related operations. Retrieving list of available languages in db and
 * modifying the language for user depending on the the user input.
 * 
 * @author CMC.UmaMahesh
 *
 */
public class LanguageActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(LanguageActor.class);

    private static final String PIPE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);

    private static String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "****", "Start OnReceive()");

        if (message instanceof LanguagesGetRequestEvent) {
            handleLanguagesGetRequest((LanguagesGetRequestEvent) message);
        } else if (message instanceof LanguageChangeReqEvent) {
            try {
                handleLanguageChangeRequest((LanguageChangeReqEvent) message);
            } catch (Exception ex) {
                logger.logException(" Exception Occured While Updating the User Language  ", ex);
            }
        } else {
            unhandled(message);
        }
    }

    /**
     * Method is responsible to retrieve available languages in database. Sample Input message
     * like:1410~783511536~1212~2~Friday 25-May-2015 09:55:18 Sample Output Message to COMM server is:
     * RESP~1411~Telugu^te
     * |Tamil^ta|Arabic^ar|Aragonese^an|Afrikaans^af|Avestan^ae|Chinese^zh|Dutch^nl|French^fr|Galician
     * ^gl|German^de|Kannada^kn| Japanese^ja|Italian^it|Irish^ga|Hindi^hi|Latin^la|Malayalam^ml|Oriya^or|Nepali^ne
     * |Marathi^mr|Panjabi^pa|Sanskrit^sa~1212~2
     * 
     * @param LanguagesGetRequestEvent
     *            POJO with above message.
     * 
     */
    @SuppressWarnings("unchecked")
    private void handleLanguagesGetRequest(LanguagesGetRequestEvent languageEvent) {

        logger.logMsg(LOG_LEVEL.INFO, "",
                "Started handleLanguagesGetRequest() With Input Value " + languageEvent.toString());
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(LANGUAGES_RESPONSE);
        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();
        String terminalId = languageEvent.getTerminalID();
        String eventId = languageEvent.getEventID();
        try {
            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventTypeID)
                    .append(VALUE_SEPERATOR).append(eventId).append(VALUE_SEPERATOR);

            String userId = languageEvent.getUserID();

            List<LanguageMaster> languageMasters = (List<LanguageMaster>) HibernateUtil.loadMasterData(
                    LanguageMaster.class, null, false);

            if (languageMasters != null) {
                logger.logMsg(LOG_LEVEL.INFO, userId, " Languages Available in Database Are  " + languageMasters.size());
                for (LanguageMaster languageMaster : languageMasters) {
                    responseToDevice.append(languageMaster.getLanguageName()).append(ITEM_SEPERATOR)
                            .append(languageMaster.getLanguageCode()).append(PIPE_SEPARATOR);
                }
            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId, " Languages Are Not Defined In Database ");
            }
            responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
            responseToDevice.append(VALUE_SEPERATOR).append(userId).append(VALUE_SEPERATOR).append(terminalId);
            logger.logMsg(LOG_LEVEL.INFO, userId, "Final Response Message Is " + responseToDevice.toString());

            User user = rdtCacheMgr.getUserDetails(userId);
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        languageEvent.getTerminalID());
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while getting List Of Languages From Db", ex);
        }
    }

    /**
     * <p> Method is responsible for changing the current logged in user related Language settings in database. </p> <p>
     * Sample Input message like:1412~783511536~1212~2~Friday 25-May-2015 10:30:18~EN. </p> <p> Updating the user
     * language status in cache userMap and calling addUserDetails() with updated user object(langCode). </p> <p>
     * Finally update same user object into database </p>
     */
    private void handleLanguageChangeRequest(LanguageChangeReqEvent langChangeEvent) {

        logger.logMsg(LOG_LEVEL.INFO, langChangeEvent.getUserID(),
                "Started handleLanguageChangeRequest() With Input Value " + langChangeEvent.toString());

        RDTCacheManager rdtCacheMgr = RDTCacheManager.getInstance();

        String userId = langChangeEvent.getUserID();
        String modifiedLangCode = langChangeEvent.getModifiedLang();
        User user = rdtCacheMgr.getUserDetails(userId);

        if (user != null) {
            logger.logMsg(LOG_LEVEL.INFO, userId, " User Language Before Update Is  " + user.getDeafultLanguage());

            user.setDeafultLanguage(modifiedLangCode);
            /*
             * updating in cache
             */
            rdtCacheMgr.addUserDetails(user);

            /*
             * updating in database UserDetails table
             */

            logger.logMsg(LOG_LEVEL.INFO, userId,
                    " User Id Related To Logged In User " + userId + " Is  " + user.getIntUserId());

            HibernateUtil.updateUserLangCode(modifiedLangCode, user.getIntUserId());

            logger.logMsg(LOG_LEVEL.INFO, userId,
                    " User Language After Update Is  " + rdtCacheMgr.getUserDetails(userId).getDeafultLanguage());

        } else {
            logger.logMsg(LOG_LEVEL.ERROR, userId, "User Object Is Not Avaiable In Cache,Unable To Update Lang");
        }
    }
}
