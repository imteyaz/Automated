package com.minapro.procserver.util;
/**
 * Enum is used to define the different Weightage Criteria,Which are already available In
 * Weightage Factor Table Weightage criteria column values.
 * These values are used to calculate the Weightage Factor of the che joblist.
 * Imp Note : If any new new value added to this column in database needs to add same column in this class.
 * @author UmaMahesh
 *
 */
public enum WeightageCriteria {
	/**
	 * 
	 * OPUS Is different move types for Yard side equipments like (RS,RMG,RTG,ECH)
	 * MI 	:	Movement In(In sparcs It is a Yard move type)
	 * MO	:	Movement Out(In Sparcs It is a Yard move type)
	 * GI	:	Gate In(In Sparcs It is a Receipt move type)
	 * GO	:	Gate Out.(In Sparcs It is a Delivery move type)
	 * RH	:	Rehandling
	 * LC	:	Load Cancel
	 * GC	:	Gate Cancel
	 * 
	 */
	LOAD,DSCH,MI,MO,GI,GO,RH,GC,LC,NORMAL,HAZARDOUS,OOG,REEFER,HAZARDOUS_REEFER,MOTHER,
	FEEDER,FULL,EMPTY,DECK,UNDER_DECK,TWENTY,FOURTY,STACK_CHANGE,CHE
}
