package com.minapro.procserver.events.plc;

import java.io.Serializable;
import java.sql.Timestamp;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding CHEPLCJobdoneEvent event details
 * 
 * @author Kumaraswamy
 *
 */

public class CHEPLCJobdoneEvent extends Event implements Serializable {

    private static final long serialVersionUID = -4588735982368072816L;

    private String node;
    private String userId;
    private String spreaderId;
    private String containerWeight;

    private Timestamp lockTime;
    private Timestamp moveTime;
    private Timestamp unlockTime;

    private String lockYardPosition;
    private String moveYardPosition;
    private String unLockYardPosition;

    private Double lockSpreaderWeight;
    private Double moveSpreaderWeight;
    private Double unLockSpreaderWeight;

    private Double lockTrollyPosition;
    private Double moveTrollyPosition;
    private Double unLockTrollyPosition;

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSpreaderId() {
        return spreaderId;
    }

    public void setSpreaderId(String spreaderId) {
        this.spreaderId = spreaderId;
    }

    public String getContainerWeight() {
        return containerWeight;
    }

    public void setContainerWeight(String containerWeight) {
        this.containerWeight = containerWeight;
    }

    public Timestamp getLockTime() {
        return lockTime;
    }

    public void setLockTime(Timestamp lockTime) {
        this.lockTime = lockTime;
    }

    public Timestamp getMoveTime() {
        return moveTime;
    }

    public void setMoveTime(Timestamp moveTime) {
        this.moveTime = moveTime;
    }

    public Timestamp getUnlockTime() {
        return unlockTime;
    }

    public void setUnlockTime(Timestamp unlockTime) {
        this.unlockTime = unlockTime;
    }

    public String getLockYardPosition() {
        return lockYardPosition;
    }

    public void setLockYardPosition(String lockYardPosition) {
        this.lockYardPosition = lockYardPosition;
    }

    public String getMoveYardPosition() {
        return moveYardPosition;
    }

    public void setMoveYardPosition(String moveYardPosition) {
        this.moveYardPosition = moveYardPosition;
    }

    public String getUnLockYardPosition() {
        return unLockYardPosition;
    }

    public void setUnLockYardPosition(String unLockYardPosition) {
        this.unLockYardPosition = unLockYardPosition;
    }

    public Double getLockSpreaderWeight() {
        return lockSpreaderWeight;
    }

    public void setLockSpreaderWeight(Double lockSpreaderWeight) {
        this.lockSpreaderWeight = lockSpreaderWeight;
    }

    public Double getMoveSpreaderWeight() {
        return moveSpreaderWeight;
    }

    public void setMoveSpreaderWeight(Double moveSpreaderWeight) {
        this.moveSpreaderWeight = moveSpreaderWeight;
    }

    public Double getUnLockSpreaderWeight() {
        return unLockSpreaderWeight;
    }

    public void setUnLockSpreaderWeight(Double unLockSpreaderWeight) {
        this.unLockSpreaderWeight = unLockSpreaderWeight;
    }

    public Double getLockTrollyPosition() {
        return lockTrollyPosition;
    }

    public void setLockTrollyPosition(Double lockTrollyPosition) {
        this.lockTrollyPosition = lockTrollyPosition;
    }

    public Double getMoveTrollyPosition() {
        return moveTrollyPosition;
    }

    public void setMoveTrollyPosition(Double moveTrollyPosition) {
        this.moveTrollyPosition = moveTrollyPosition;
    }

    public Double getUnLockTrollyPosition() {
        return unLockTrollyPosition;
    }

    public void setUnLockTrollyPosition(Double unLockTrollyPosition) {
        this.unLockTrollyPosition = unLockTrollyPosition;
    }

    @Override
    public String toString() {
        return "RMGPLCJobdoneEvent [node=" + node + ", userId=" + userId + ", spreaderId=" + spreaderId
                + ", containerWeight=" + containerWeight + ", lockTime=" + lockTime + ", moveTime=" + moveTime
                + ", unlockTime=" + unlockTime + ", lockYardPosition=" + lockYardPosition + ", moveYardPosition="
                + moveYardPosition + ", unLockYardPosition=" + unLockYardPosition + ", lockSpreaderWeight="
                + lockSpreaderWeight + ", moveSpreaderWeight=" + moveSpreaderWeight + ", unLockSpreaderWeight="
                + unLockSpreaderWeight + ", lockTrollyPosition=" + lockTrollyPosition + ", moveTrollyPosition="
                + moveTrollyPosition + ", unLockTrollyPosition=" + unLockTrollyPosition + "]";
    }
}
