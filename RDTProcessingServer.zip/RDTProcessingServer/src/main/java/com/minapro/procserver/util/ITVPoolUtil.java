package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.opus.joblist.JobListUtil;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.itv.ITV;
import com.minapro.procserver.events.itv.ITVPoolEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ITVPoolUtil {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVPoolUtil.class);

    private static final ITVPoolUtil INSTANCE = new ITVPoolUtil();

    private ITVPoolUtil() {
    }

    public static ITVPoolUtil getInstance() {
        return INSTANCE;
    }

    /**
     * Method is responsible for creating ITV Pool from CHE JobList. Depending Move types getting ITV location , After
     * checking whether it is a defined as equipment in ATOM or not, If it is defined in Equipment adding to pool list
     * else ignoring.
     * 
     * @param event
     * @return Set of itv's
     */
    public Set<ITV> prepareITVPoolFromCHEJobList(final Event event) {

        final String userId = event.getUserID();
        Set<ITV> itvList = null;
        try {

            ListOrderedMap<String, JobListContainer> cheJobs = RDTCacheManager.getInstance().getJobList(userId,
                    event.getEquipmentID());

            if (cheJobs != null && !cheJobs.isEmpty() && cheJobs.values() != null) {
                itvList = prepareITVList(cheJobs);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, userId, " No Jobs Are Available In Cache , Returning ITV Pool As Null");

            }
        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append("In prepareITVPoolFromCHEJobList() ")
                    .append(REASON).toString(), ex);
        }
        return itvList;
    }

    private ITV getCurrentITVFromCachedITVPool(String itvNo, Collection<Set<ITV>> cachedITVPoolITVList) {
        ITV currentITV = null;
        for (Set<ITV> itvList : cachedITVPoolITVList) {
            for (ITV itv : itvList) {
                if (itv != null && itvNo.equals(itv.getItvId())) {
                    return itv;
                }
            }
        }
        return currentITV;
    }

    public ITV createITVObject(String itvNo, JobListContainer container) {
        ITV itv = new ITV();

        itv.setLoadCapacity((CHEJobListService.getStackNumberFromLocation(JobListUtil
                .getCHEJobYardLocationBasedOnMoveType(container)) & 1) == 1 ? 20 : 40);
        itv.setItvId(itvNo);
        itv.setNoOfContainer(container.getTwinContainerId() != null && !container.getTwinContainerId().isEmpty() ? 2
                : 1);

        return itv;
    }

    public void createITVPoolRequest(Event event) {
        ITVPoolEvent poolEvent = new ITVPoolEvent();
        poolEvent.setEventID(UUID.randomUUID().toString());
        poolEvent.setEquipmentID(event.getEquipmentID());
        poolEvent.setUserID(event.getUserID());
        poolEvent.setTerminalID(event.getTerminalID());
        poolEvent.setItvList(prepareITVPoolFromCHEJobList(event));
        RDTProcessingServer.getInstance().getMasterActor().tell(poolEvent, null);
    }

    public void setITVPoolListToCache(Event event) {
        Set<ITV> listOfITVSFromCHEJobList = prepareITVPoolFromCHEJobList(event);
        logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), new StringBuilder(
                " Current Operator Is CHE , ITV Pool List From CHE JobList").append(listOfITVSFromCHEJobList)
                .toString());
        if(listOfITVSFromCHEJobList != null){
        	RDTCacheManager.getInstance().addAssignedITVs(event.getEquipmentID(), listOfITVSFromCHEJobList);
        }
    }

    public Set<ITV> prepareITVList(ListOrderedMap<String, JobListContainer> cheJobs) {

        Set<ITV> listOfITVs = new HashSet<ITV>();
        Collection<Set<ITV>> cachedITVPoolList = RDTCacheManager.getInstance().getCachedITVSFromITVPoolCache();

        for (JobListContainer container : cheJobs.values()) {

            final String itvNo = JobListUtil.getITVNoFromCHEJobListBasedOnMoveType(container);
            boolean status = JobListUtil.isCurrentToLocationITVNumber(itvNo);

            if (status) {
                ITV itv = null;

                if (cachedITVPoolList != null && !cachedITVPoolList.isEmpty()) {
                    ITV itvFromCache = getCurrentITVFromCachedITVPool(itvNo, cachedITVPoolList);
                    itv = (itvFromCache == null ? createITVObject(itvNo, container) : itvFromCache);
                } else {
                    itv = createITVObject(itvNo, container);
                }

                listOfITVs.add(itv);
            }
        }
        return listOfITVs;
    }
}
