package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REFERENCE_CONTAINER_SEPERATOR;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BayProfile;
import com.minapro.procserver.cache.CellGrid;
import com.minapro.procserver.cache.CellGrid.MOVE_TYPE;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.BusinessException;
import com.minapro.procserver.db.bayprofile.VesselException;
import com.minapro.procserver.db.bayprofile.VesselException.exceptionType;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.common.BayProfileContainer;
import com.minapro.procserver.events.common.BaywiseContainerDetailsResponseEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.UpdateBayViewResponseEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the bay wise container details response coming from ESB.</p>
 * 
 * <p> For the bay, the corresponding section is identified and retrieves the bay profile from cache. Iterates through
 * the container list and updates the CellGrid[tier][row] array of the bay profile with container details. </p>
 * 
 * <p> Also updates the Central container Cache with the container details as this will be accessed by the JobListActor
 * to compare and send job list to respective operators. </p>
 * 
 * @author Rosemary George
 *
 */
public class BaywiseContainersActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BaywiseContainersActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);
    
    private static final String SYSTEM_USER = "system";
    private static final String EXCEPTION_TYPE = "Container Detail Missing";
    private static final String FUNCTION_CODE = "JOBLIST PROCESSING";

    // private literals
    private static final String REMARKS = "Remarks";
    private static final String COLOURCODE = "ColourCode";
    private static final String MOVETYPE = "MoveType";
    private static final String FROM_LOCATION = "FromLocation";
    private static final String TO_LOCATION = "ToLocation";
    private static final String JOBS = "Jobs";
    private static final String CONTAINER = "CONTAINER";
    private static final String TWIN_CONTAINER = "TwinContainerId";
    private static final String CONTAINER_ID = "ContainerID";

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof BaywiseContainerDetailsResponseEvent) {

            BaywiseContainerDetailsResponseEvent containerDetailsPerBay = (BaywiseContainerDetailsResponseEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, "",
                    "Received container details for the vessel- " + containerDetailsPerBay.getVesselCode() + " bay "
                            + containerDetailsPerBay.getBayNo());

            if (containerDetailsPerBay.getContainerList() != null
                    && !containerDetailsPerBay.getContainerList().isEmpty()) {
                handleBaywiseContainerDetailsResponse(containerDetailsPerBay);
            }

        } else if (message instanceof UpdateBayViewResponseEvent) {
            UpdateBayViewResponseEvent updateBayViewResponse = (UpdateBayViewResponseEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, "", "Received UpdateBayViewResponseEvent- " + updateBayViewResponse);

            processUpdateBayViewResponse(updateBayViewResponse);
        } else {
            unhandled(message);
        }
    }

    /**
     * Processes the updated container details coming from ESB. For each container, the associated bay is derived from
     * the rotation id and the container stowage position. And the bay profile is updated with the container details. In
     * case of logical bay, both the physical bay gets updated.
     * 
     * The update is sent to the devices as a series of bay view update notifications.
     * 
     * @param updateBayViewResponse
     */
    private void processUpdateBayViewResponse(UpdateBayViewResponseEvent updateBayViewResponse) {
        // get the rotation id using the User
        ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(updateBayViewResponse.getUserID());
        if (allocationEvent != null && updateBayViewResponse.getUpdatedContainerList() != null
                && !updateBayViewResponse.getUpdatedContainerList().isEmpty()) {

            String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(
                    allocationEvent.getRotationID());
            String sectionNo, stowagePosition, bayNo, tierNo, rowNo;

            ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
                    updateBayViewResponse.getUserID(), updateBayViewResponse.getEquipmentID());

            Map<String, StringBuilder[]> bayUpdateMap = new HashMap<String, StringBuilder[]>();
            String bayKey, cell;

            for (BayProfileContainer updatedContainer : updateBayViewResponse.getUpdatedContainerList()) {
                try {
                    stowagePosition = updatedContainer.getStowagePosition();

                    if (stowagePosition == null) {
                        JobListContainer jobContainer = jobList.get(updatedContainer.getContainer().getContainerID()+updatedContainer.getMoveType());
                        if (jobContainer != null) {
                            logger.logMsg(LOG_LEVEL.TRACE, updateBayViewResponse.getUserID(),
                                    "Stowage position is still null, retrieving the position data from job list :"
                                            + jobContainer);
                            if (jobContainer.getMoveType().equals(LOAD)) {
                                stowagePosition = jobContainer.getToLocation();
                            } else {
                                stowagePosition = jobContainer.getFromLocation();
                            }

                            stowagePosition = stowagePosition.replaceAll("\\.", "");
                        } else {
                            continue;
                        }
                    }

                    bayNo = stowagePosition.substring(0, 2);
                    rowNo = stowagePosition.substring(2, 4);
                    tierNo = stowagePosition.substring(stowagePosition.length() - 2);

                    String physicalBayNo = bayNo;
                    if (EventUtil.getInstance().isLogicalBay(bayNo)) {
                        physicalBayNo = getPhysicalBayNo(bayNo);
                    }
                    String deckIndication = EventUtil.getInstance().findDeckType(tierNo, vesselCode, physicalBayNo);

                    sectionNo = RDTVesselProfileCacheManager.getInstance().getAssociatedSection(vesselCode,
                            physicalBayNo, deckIndication);
                    logger.logMsg(LOG_LEVEL.DEBUG, bayNo, "Associated section is " + sectionNo + ", stowage="
                            + stowagePosition + ",container=" + updatedContainer);
                    if (sectionNo != null) {
                        if (EventUtil.getInstance().isLogicalBay(bayNo)) {
                            logger.logMsg(LOG_LEVEL.DEBUG, bayNo, "Filling the container details for LOGICAL bay");
                            for (BayProfile bayProfile : RDTVesselProfileCacheManager.getInstance()
                                    .getBayProfiles(sectionNo).values()) {
                                updateBayCell(stowagePosition, updatedContainer, bayProfile,
                                        allocationEvent.getRotationID(), vesselCode);

                                bayKey = bayProfile.getVesselBayId() + VALUE_SEPARATOR + deckIndication;
                                cell = bayProfile.getVesselBayId() + "." + rowNo + "." + tierNo;
                                addToBayViewUpdateMap(bayUpdateMap, bayKey, updatedContainer, cell);
                            }
                        } else {
                            BayProfile bayProfile = RDTVesselProfileCacheManager.getInstance()
                                    .getBayProfiles(sectionNo).get(bayNo);

                            updateBayCell(stowagePosition, updatedContainer, bayProfile,
                                    allocationEvent.getRotationID(), vesselCode);

                            bayKey = bayNo + VALUE_SEPARATOR + deckIndication;
                            cell = bayNo + "." + rowNo + "." + tierNo;
                            addToBayViewUpdateMap(bayUpdateMap, bayKey, updatedContainer, cell);
                        }                        
                    }else {
                        logger.logMsg(LOG_LEVEL.INFO, bayNo, "Failed to get the section associated with the bay. Bay must be missing in vessel profile");
                        createVesselException(exceptionType.BAY_MISSING, bayNo, allocationEvent.getRotationID(), vesselCode, null);
                    }
                    
                    logger.logMsg(LOG_LEVEL.DEBUG, bayNo,
                            "Adding Container to central Cache -" + updatedContainer.getContainer());
                    RDTCacheManager.getInstance().addContainer(updatedContainer.getContainer(), updatedContainer.getMoveType());
                } catch (Exception ex) {
                    logger.logException("Caught exception while processUpdateBayViewResponse for container - "
                            + updatedContainer, ex);
                }
            }
            
            /*sendBayViewUpdateToDevice(bayUpdateMap, updateBayViewResponse.getUserID(),
                    updateBayViewResponse.getTerminalID());  */        
        }
        
        logger.logMsg(LOG_LEVEL.INFO, updateBayViewResponse.getUserID(),
                "Send to QC and Identify the associated HC user and send job list update");
        informJobUpdate(updateBayViewResponse);
        
        handleFailedToFectchContainers(updateBayViewResponse.getUnLocatedContainerList(), 
                    allocationEvent.getRotationID(), updateBayViewResponse.getUserID());
    }

    /**
     * Creates business exception with exception type=Container details Missing and Function code = JOB LIST PROCESSING
     * for each failed to fetch container which has been returned by ESB 
     * 
     * @param unLocatedContainerList
     * @param rotationID
     * @param user
     */
    private void handleFailedToFectchContainers(List<String> unLocatedContainerList, String rotationID, String user) {
       if(unLocatedContainerList != null && !unLocatedContainerList.isEmpty()){
           logger.logMsg(LOG_LEVEL.DEBUG, rotationID, "Logging Business exception for failed to fetch containers");
           
           BusinessException exception;
           for(String container: unLocatedContainerList){
               try{
                   exception = new BusinessException();
                   exception.setCotainerId(container);
                   exception.setCreatedDateTime(new Date());
                   exception.setCreatedBy(user);
                   exception.setExceptionType(EXCEPTION_TYPE);
                   exception.setFunctionCode(FUNCTION_CODE);
                   exception.setRotationNo(Integer.parseInt(rotationID));
                   
                   JournalEvent journal = new JournalEvent(exception, UPDATETYPE.ADD);
                   getSender().tell(journal, null);
               }catch(Exception ex){
                   logger.logException("Caught exception while recording business exception for container " +container, ex);
               }
           }
       }
    }

    /**
     * Returns the physical bay no if the specified bayNo is a logical one
     * 
     * @param bayNo
     * @return
     */
    private String getPhysicalBayNo(String bayNo) {
        // check whether it is logical bay, then get one of the physical one
        Integer bay = Integer.parseInt(bayNo);
        String physicalBay = bayNo;
        if (bay % 2 == 0) {
            bay--;
            if (bay < 10) {
                physicalBay = "0" + bay;
            } else {
                physicalBay = bay.toString();
            }
        }
        return physicalBay;
    }

    /**
     * Identifies the HC user associated with the QC and if the HC user is past the pre-operational inspection stage,
     * sends the job list updates to the user
     * 
     * @param updateBayViewResponse
     */
    private void informJobUpdate(UpdateBayViewResponseEvent updateBayViewResponse) {
    	sendJobListRequest(updateBayViewResponse);
        String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(updateBayViewResponse.getEquipmentID());
        logger.logMsg(LOG_LEVEL.INFO, updateBayViewResponse.getEquipmentID(), "Associated HC user is " + hcUser);
        if (hcUser != null) {
            boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
            if (inspectionStatus) {
                logger.logMsg(LOG_LEVEL.INFO, hcUser, "Inspection Status true, sending job update");
                updateBayViewResponse.setUserID(hcUser);
                sendJobListRequest(updateBayViewResponse);
            }
        }
    }
    
    /**
     * Construct and sends job list request to master actor
     * @param updateBayViewResponse
     */
    private void sendJobListRequest(UpdateBayViewResponseEvent updateBayViewResponse){
    	JobListRequestEvent request = new JobListRequestEvent();
    	request.setEquipmentID(updateBayViewResponse.getEquipmentID());
    	request.setEventID(UUID.randomUUID().toString());
    	request.setScheduled(true);
    	request.setTerminalID(updateBayViewResponse.getTerminalID());
    	request.setUserID(updateBayViewResponse.getUserID());
    	
    	getSender().tell(request, null);
    }

    /**
     * sends an update job list message to device to update the container attributes.
     * 
     */
    private void sendJobListUpdateToDevice(UpdateBayViewResponseEvent responseEvent) {
        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.JOB_LIST);

            // get the job list message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(RDTProcessingServerConstants.JOB_LIST);

            // get the container message format
            List<String> containerFields = EventFormats.getInstance().getEventFields(CONTAINER);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(RDTProcessingServerConstants.NOTIF + VALUE_SEPARATOR
                    + eventTypeID);
            String msgField;
            String colourCode;
            
            String explosiveCodes = EventUtil.getInstance().getExplosiveCodes(); 

            ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(
                    responseEvent.getUserID(), responseEvent.getEquipmentID());

            BayProfileContainer recievedContainer;

            // iterate through the jobList message formats
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(VALUE_SEPARATOR);
                msgField = msgFields.get(i);

                // in case of Jobs fields, its time to iterate through the containers
                if (msgField.equalsIgnoreCase(JOBS)) {
                    // Iterate till the size of the container list
                    for (int j = 0; j < responseEvent.getUpdatedContainerList().size(); j++) {
                        recievedContainer = responseEvent.getUpdatedContainerList().get(j);
                        JobListContainer job = jobList.get(recievedContainer.getContainer().getContainerID()+recievedContainer.getMoveType());
                        if (job != null) {
                            Container container = recievedContainer.getContainer();

                            // For each container, iterate through the Container message format
                            for (int conCounter = 0; conCounter < containerFields.size(); conCounter++) {
                                if (containerFields.get(conCounter).equalsIgnoreCase(REMARKS)) {
                                    if (container != null) {
                                        responseToDevice.append(EventUtil.getInstance().getContainerIcon(container));
                                    } else {
                                        responseToDevice.append("");
                                    }
                                } else if (containerFields.get(conCounter).equalsIgnoreCase(COLOURCODE)) {
                                    if (container != null && container.getPod() != null) {
                                        colourCode = RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
                                                container.getPod());
                                    } else {
                                        colourCode = "";
                                    }
                                    responseToDevice.append(colourCode);
                                } else if (containerFields.get(conCounter).equalsIgnoreCase(MOVETYPE)
                                        || containerFields.get(conCounter).equalsIgnoreCase(FROM_LOCATION)
                                        || containerFields.get(conCounter).equalsIgnoreCase(TO_LOCATION)) {
                                    EventUtil.getInstance().getEventParameter(job, containerFields.get(conCounter),
                                            responseToDevice);
                                } else if (TWIN_CONTAINER.equalsIgnoreCase(containerFields.get(conCounter))) {
                                    if (job.getTandemContainerIDs() != null && job.getTandemContainerIDs().length > 0) {
                                        for (String tandem : job.getTandemContainerIDs()) {
                                            responseToDevice.append(tandem).append(REFERENCE_CONTAINER_SEPERATOR);
                                        }
                                        responseToDevice.delete(responseToDevice.length() - 1,
                                                responseToDevice.length());
                                    } else {
                                        responseToDevice.append(job.getTwinContainerId());
                                    }
                                } else if (containerFields.get(conCounter).equalsIgnoreCase(CONTAINER_ID)) {
                                    responseToDevice.append(container.getContainerID());
                                } else if ("Priority".equalsIgnoreCase(containerFields.get(conCounter))
                                        || "PriorityColour".equalsIgnoreCase(containerFields.get(conCounter))) {
                                    logger.logMsg(LOG_LEVEL.TRACE, responseEvent.getUserID(),
                                            "Priority Not for QC/HC. Ignore");
                                } else if ("SealStatus".equalsIgnoreCase(containerFields.get(conCounter))) {
                                    if(container!= null){
                                        responseToDevice.append(container.isSealOn()?"Y":"N");
                                    }
                                }else if ("HazardousCode".equalsIgnoreCase(containerFields.get(conCounter))) {
                                    if(container!= null && explosiveCodes != null  && container.getHazardousCode()!= null){
                                        responseToDevice.append(EventUtil.getInstance()
												.isExplosiveContainer(explosiveCodes, container.getHazardousCode()));
                                    }else {
                                        responseToDevice.append(false); 
                                    }
                                } else if("SequenceNumber".equalsIgnoreCase(containerFields.get(conCounter))){
                                	responseToDevice.append(job.getSeqNumber());
                                }else {
                                    EventUtil.getInstance().getEventParameter(container,
                                            containerFields.get(conCounter), responseToDevice);
                                }

                                responseToDevice.append(ITEM_SEPARATOR);
                            }
                        }
                        responseToDevice.append(ROW_SEPARATOR);
                    }
                } else {
                    EventUtil.getInstance().getEventParameter(responseEvent, msgField, responseToDevice);
                }
            }

            // send the batch message
            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(responseEvent.getUserID());
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                    responseEvent.getTerminalID());
        } catch (Exception ex) {
            logger.logException("Caught exception while building the joblist update -", ex);
        }

    }

    /**
     * Constructs and sends the bay view update to the device
     * 
     * @param bayUpdateMap
     * @param userID
     * @param terminalID
     */
    private void sendBayViewUpdateToDevice(Map<String, StringBuilder[]> bayUpdateMap, String userID, String terminalID) {
        StringBuilder responseToDevice = null;
        StringBuilder[] values = null;
        OPERATOR operator = null;

        SimpleDateFormat formatter = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");
        String eventType = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.BAY_VIEW_UPDATE);

        for (String bayKey : bayUpdateMap.keySet()) {
            values = bayUpdateMap.get(bayKey);
            responseToDevice = new StringBuilder();

            String dateString = formatter.format(new Date());

            responseToDevice.append(RDTProcessingServerConstants.NOTIF).append(VALUE_SEPARATOR).append(eventType)
                    .append(VALUE_SEPARATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPARATOR)
                    .append(dateString).append(VALUE_SEPARATOR).append(bayKey).append(VALUE_SEPARATOR).append(values[0])
                    .append(VALUE_SEPARATOR).append(values[1]).append(VALUE_SEPARATOR).append(userID)
                    .append(VALUE_SEPARATOR).append(terminalID);

            operator = RDTCacheManager.getInstance().getUserLoggedInRole(userID);
            CommunicationServerQueueManager.getInstance()
                    .postMessage(responseToDevice.toString(), operator, terminalID);
        }
    }

    /**
     * Stores the cell positions and associated container details in the provided bayUpdateMap.
     * 
     * The Cell positions will be stored as cell1|cell2|cell3 etc..
     * 
     * The associated containers will be placed as
     * containerId^reeferstatus^hazardrousStatus^OutOfGaugeStatus^ROBstatus^POD
     * ^colourcode|containerId^reeferstatus^hazardrousStatus^OutOfGaugeStatus^ROBstatus^POD^colourcode etc
     * 
     * @param bayUpdateMap
     * @param bayKey
     * @param updatedContainer
     * @param cell
     */
    private void addToBayViewUpdateMap(Map<String, StringBuilder[]> bayUpdateMap, String bayKey,
            BayProfileContainer updatedContainer, String cell) {
        StringBuilder cellPositions = null, containerDetails = null;

        /*
         * Check the bay details are already present in the map, then get the cell and container details, else create
         * new cell and container strings
         */
        StringBuilder[] values = bayUpdateMap.get(bayKey);
        if (values == null) {
            cellPositions = new StringBuilder();
            containerDetails = new StringBuilder();
            values = new StringBuilder[] { cellPositions, containerDetails };
            bayUpdateMap.put(bayKey, values);
        } else {
            cellPositions = values[0];
            containerDetails = values[1];
        }

        cellPositions.append(cell + ROW_SEPARATOR);

        String colourCode;
        if (updatedContainer.getContainer().getPod() != null) {
            colourCode = RDTVesselProfileCacheManager.getInstance().getColourCodeForPOD(
                    updatedContainer.getContainer().getPod());
        } else {
            colourCode = "";
        }

        containerDetails.append(updatedContainer.getContainer().getContainerID()).append(ITEM_SEPARATOR)
                .append(updatedContainer.getContainer().isReefer()).append(ITEM_SEPARATOR)
                .append(updatedContainer.getContainer().isHazardous()).append(ITEM_SEPARATOR)
                .append(updatedContainer.getContainer().isOOG()).append(ITEM_SEPARATOR).append(updatedContainer.isROB())
                .append(ITEM_SEPARATOR).append(updatedContainer.getContainer().getPod()).append(ITEM_SEPARATOR)
                .append(colourCode).append(ITEM_SEPARATOR).append(updatedContainer.getContainer().getIsDamaged())
                .append(ROW_SEPARATOR);
    }   

    /**
     * Handles the bay wise response message from ESB. The associated bay profile is retrieved from cache and the
     * container details are filled as per the stowage position
     * 
     * In case of logical bay, the both of the physical bays are updated.
     * 
     * @param containerDetailsPerBay
     */
    private void handleBaywiseContainerDetailsResponse(BaywiseContainerDetailsResponseEvent containerDetailsPerBay) {
        // check if it is for logical bay
        String bayNo = containerDetailsPerBay.getBayNo();

        String sectionNo = RDTVesselProfileCacheManager.getInstance().getAssociatedSection(
                containerDetailsPerBay.getVesselCode(), bayNo, containerDetailsPerBay.getUnderDeckIndication());

        logger.logMsg(LOG_LEVEL.DEBUG, "", " Associated section for the bay is " + sectionNo);

        if(sectionNo != null){
	        if (EventUtil.getInstance().isLogicalBay(bayNo)) {
	            logger.logMsg(LOG_LEVEL.DEBUG, "", "Filling the container details for LOGICAL bay");
	            for (BayProfile bayProfile : RDTVesselProfileCacheManager.getInstance().getBayProfiles(sectionNo).values()) {
	                fillBayProfileWithContainerDetails(containerDetailsPerBay.getContainerList(), bayProfile,
	                        containerDetailsPerBay.getRotationID(),containerDetailsPerBay.getVesselCode());
	            }
	        } else {
	            BayProfile bayProfile = RDTVesselProfileCacheManager.getInstance().getBayProfiles(sectionNo)
	                    .get(containerDetailsPerBay.getBayNo());
	
	            fillBayProfileWithContainerDetails(containerDetailsPerBay.getContainerList(), bayProfile,
	                    containerDetailsPerBay.getRotationID(), containerDetailsPerBay.getVesselCode());
	        }
        }
    }

    /**
     * updates the specified bay profile with container details. Also updates the container cache.
     *
     * @param containerList
     *            - List of containers available on the bay
     * @param bayProfile
     *            - corresponding bay profile.
     * 
     */
    private void fillBayProfileWithContainerDetails(List<BayProfileContainer> containerList, BayProfile bayProfile,
            String rotationId, String vesselCode) {
        logger.logMsg(LOG_LEVEL.INFO, "", "Start to fill container details for bay " + bayProfile.getVesselBayId());
        String stowagePosition;

        for (BayProfileContainer container : containerList) {
            stowagePosition = container.getStowagePosition();

            updateBayCell(stowagePosition, container, bayProfile, rotationId, vesselCode);
        }
    }

    /**
     * Updates the particular cell in the bay. Uses stowage position to identify the location in the
     * CellGrid[tier][row]. The stowage position pattern from DPW system is BBRRTT(bayrowtier) </p>
     * 
     * <p> Depending on the move type, the container details will be placed as current or planned container. </p>
     * 
     * @param stowagePosition
     * @param container
     * @param bayProfile
     */
    private void updateBayCell(String stowagePosition, BayProfileContainer bayContainer, BayProfile bayProfile,
            String rotationId, String vesselCode) {
        try {
            int rowOffset = bayProfile.getRowOffset(stowagePosition.substring(2, 4));
            int tierOffset = bayProfile.getTierOffset(stowagePosition.substring(4));

            CellGrid cell = bayProfile.getCellGrid(rowOffset, tierOffset);
            if (MOVE_TYPE.LOAD.toString().equalsIgnoreCase(bayContainer.getMoveType())) {
                cell.setPlannedContainer(bayContainer);
            } else {
                cell.setCurrentContainer(bayContainer);
            }

            if (bayContainer.isROB()) {
                RDTVesselProfileCacheManager.getInstance().addToROBList(rotationId,
                        bayContainer.getContainer().getContainerID());
            }

            RDTCacheManager.getInstance().addContainer(bayContainer.getContainer(), bayContainer.getMoveType());
        } catch (Exception ex) {
            logger.logException("Caught exception while filling the bay profile with conatiner details -"
                    + stowagePosition, ex);
            createVesselException(exceptionType.CELL_MISSING, bayProfile.getVesselBayId(), rotationId, vesselCode, stowagePosition);
        }
    }

    /**
     * Record vessel exception in DB based on the exception type
     * @param exceptionType
     * @param bayNo
     * @param rotationId
     * @param vesselCode
     * @param stowagePosition
     */
    private void createVesselException(exceptionType exceptionType, String bayNo, String rotationId, String vesselCode,
            String stowagePosition) {
        try{
           VesselException exception = new VesselException();
           exception.setExceptionType(exceptionType.toString());
           exception.setVesselNo(Integer.parseInt(vesselCode));
           exception.setRotation(Integer.parseInt(rotationId));
           exception.setCreatedDateTime(new Date());
           exception.setCreatedBy(SYSTEM_USER);
           exception.setBay(bayNo);
           if(VesselException.exceptionType.CELL_MISSING.equals(exceptionType) && stowagePosition != null){
               String rowNo = stowagePosition.substring(2, 4);
               String tierNo = stowagePosition.substring(4);
               exception.setRow(rowNo);
               exception.setTier(tierNo);
           }
           
           logger.logMsg(LOG_LEVEL.INFO, vesselCode+rotationId, "Recording vessel exception " + exception);           
           JournalEvent journal = new JournalEvent(exception, UPDATETYPE.ADD);
           getSender().tell(journal, null);
        }catch(Exception ex){
            logger.logException("Caught exception while recording vessel exception ", ex);
        }
    }
}
