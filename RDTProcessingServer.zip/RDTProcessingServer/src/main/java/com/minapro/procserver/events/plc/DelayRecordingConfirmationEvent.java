package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class DelayRecordingConfirmationEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6204110494725034478L;

    /**
     * The delay reason code which the user has selected
     */
    private String reasonCode;

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode.trim();
    }

    @Override
    public String toString() {
        return "DelayRecordingConfirmationEvent [reasonCode=" + reasonCode + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }

}