package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding the details about an equipment. The equipment are mapped to terminal wise
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_EQUIPMENT_MASTER")
public class Equipment extends Audit implements Serializable {

    private static final long serialVersionUID = -1428474557566334796L;

    @Id
    @Column(name = "EQUIPMENT_ID", nullable = false)
    private String equipmentID;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "EQUIPMENT_TYPE_ID", referencedColumnName = "EQUIPMENT_TYPE_ID")
    private EquipmentType equipmentType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TERMINAL_ID", referencedColumnName = "TERMINAL_ID")
    private Terminal terminal;

    @Column(name = "EQUIPMENT_NAME", nullable = false)
    private String equipmentName;

    @Column(name = "EQUIPMENT_DESCRIPTION")
    private String equipmentDescription;

    @Column(name = "MAKE", nullable = false)
    private String make;

    @Column(name = "MODEL", nullable = false)
    private String model;

    @Column(name = "POW")
    private String pow;

    public String getPow() {
        return pow;
    }

    public void setPow(String pow) {
        this.pow = pow;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public String getEquipmentDescription() {
        return equipmentDescription;
    }

    public void setEquipmentDescription(String equipmentDescription) {
        this.equipmentDescription = equipmentDescription;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public EquipmentType getEquipmentType() {
        return equipmentType;
    }

    public void setEquipmentType(EquipmentType equipmentType) {
        this.equipmentType = equipmentType;
    }

    public Terminal getTerminal() {
        return terminal;
    }

    public void setTerminal(Terminal terminal) {
        this.terminal = terminal;
    }
}
