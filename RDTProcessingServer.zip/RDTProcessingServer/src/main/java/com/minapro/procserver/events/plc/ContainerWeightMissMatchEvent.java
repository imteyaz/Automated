package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the Container Weight Missmatch event details
 * 
 * @author Venkataramana.ch
 *
 */

public class ContainerWeightMissMatchEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6051242543848905613L;

    private String message;

    private String containerID;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    @Override
    public String toString() {
        return "ContainerWeightMissMatchEvent [message=" + message + ", containerID=" + containerID + "]";
    }

}
