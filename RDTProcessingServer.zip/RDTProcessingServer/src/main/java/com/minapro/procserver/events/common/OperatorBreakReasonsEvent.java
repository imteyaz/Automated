package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.Set;

import com.minapro.procserver.events.Event;

public class OperatorBreakReasonsEvent extends Event implements Serializable {

    private static final long serialVersionUID = 3287072259391745681L;
    /**
     * Holding Set of Operator Break Reasons.
     */
    private Set<String> breakReasons;

    public Set<String> getBreakReasons() {
        return breakReasons;
    }

    public void setBreakReasons(Set<String> breakReasons) {
        this.breakReasons = breakReasons;
    }

    @Override
    public String toString() {
        return "OperatorBreakReasonsEvent [breakReasons=" + breakReasons + "]";
    }
}
