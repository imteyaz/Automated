package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.BAY_FRONT_VIEW;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;
import java.util.Map;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BayProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.BayProfileRequestEvent;
import com.minapro.procserver.events.BayProfileRequestEvent.BAY_VIEW;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.SwitchBayRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for handling the bay view requests from the devices.</p>
 * 
 * <p> Based on the vessel code, bay No and deck/under deck flag, the associated section is retrieved. The section may
 * contain more than one bay. Though the device asked for only one bay, all the bays belonging to the same section is
 * sent to the device one by one. </p>
 * 
 * @author Rosemary George
 *
 */
public class BayProfileActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BayProfileActor.class);

    private static final String BAY_SEPERATOR_KEY = ",";

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof BayProfileRequestEvent) {
            BayProfileRequestEvent profileRequest = (BayProfileRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, profileRequest.getUserID(), "Requested bay profile for " + profileRequest);

            handleBayProfileRequest(profileRequest);
        } else if (message instanceof SwitchBayRequestEvent) {
            SwitchBayRequestEvent switchBayRequest = (SwitchBayRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, switchBayRequest.getUserID(), "Requested bay switch -" + switchBayRequest);

            String bay = switchBayRequest.getBayNo().substring(0, 2);
            generateBayView(switchBayRequest, bay, switchBayRequest.getDeckIndication(), switchBayRequest.getViewType());
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the bay profile request from the device
     * 
     * @param profileRequest
     */
    private void handleBayProfileRequest(BayProfileRequestEvent profileRequest) {
        try {
            String bayNo = profileRequest.getCellLocation().substring(0, 2);
            String tierNo = profileRequest.getCellLocation().substring(profileRequest.getCellLocation().length() - 2);

            // get the allocation details to get the rotation ID
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(profileRequest.getUserID());
            String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(allocation.getRotationID());
            String deckInd = EventUtil.getInstance().findDeckType(tierNo, vesselCode, bayNo);

            generateBayView(profileRequest, bayNo, deckInd, profileRequest.getViewType());
        } catch (Exception ex) {
            logger.logException("Caught exception while creating the bay Profile message to device for bay No "
                    + profileRequest.getCellLocation(), ex);
            sendEmptyProfileToDevice(profileRequest, "-1", "");
        }
    }

    /**
     * Constructs and sends the bay view for the requested bay.
     * 
     * @param profileRequest
     * @param bayNo
     * @param deckIndication
     * @param viewType
     */
    private void generateBayView(Event profileRequest, String bayNo, String deckIndication, BAY_VIEW viewType) {
        try {

            // get the allocation details to get the rotation ID
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(profileRequest.getUserID());
            String vesselCode = RDTVesselProfileCacheManager.getInstance().getVesselCode(allocation.getRotationID());

            String sectionNo = RDTVesselProfileCacheManager.getInstance().getAssociatedSection(vesselCode, bayNo,
                    deckIndication);

            logger.logMsg(LOG_LEVEL.DEBUG, profileRequest.getUserID(), " Associated section for the bay is "
                    + sectionNo);
            if (sectionNo != null) {
                Map<String, BayProfile> bayProfiles = RDTVesselProfileCacheManager.getInstance().getBayProfiles(
                        sectionNo);

                /*
                 * Bug #124011 - UI expects two bay responses always in case of twin bays, both the bay details needs to
                 * be sent to the UI. In case of more than two bay in the section, send the requested bay and the
                 * immediate next. If there is only one bay for this section, get the next bay from the next section
                 */
                int baySizeInSection = bayProfiles.size();
                logger.logMsg(LOG_LEVEL.DEBUG, profileRequest.getUserID(), "Bays available for the section is "
                        + baySizeInSection);

                if (baySizeInSection == 2) {
                    int bayCount = 0;
                    String bay1 = "", bay2 = "";
                    for (String bay : bayProfiles.keySet()) {
                        if (bayCount == 0) {
                            bay1 = bay;
                        } else {
                            bay2 = bay;
                        }
                        bayCount++;
                    }
                    sendBayProfileToDevice(profileRequest, bayProfiles.get(bay1), bayProfiles.get(bay2), viewType,
                            true, deckIndication);
                } else if (baySizeInSection == 1) {
                    BayProfile nextBay = getBayFromNextSection(vesselCode, sectionNo, deckIndication,
                            profileRequest.getUserID());
                    sendBayProfileToDevice(profileRequest, bayProfiles.get(bayNo), nextBay, viewType, false,
                            deckIndication);
                } else if (baySizeInSection > 2) {
                    int counter = 0, bayPosition = 0;
                    BayProfile nextBay = null;
                    for (String bay : bayProfiles.keySet()) {
                        counter++;
                        if (bay.equals(bayNo)) {
                            bayPosition = counter;
                        } else if (counter > bayPosition) {
                            nextBay = bayProfiles.get(bay);
                            break;
                        }
                    }

                    if (nextBay == null) {
                        logger.logMsg(LOG_LEVEL.DEBUG, profileRequest.getUserID(),
                                "Couldn't get the second bay to send to UI from this section " + baySizeInSection);
                        nextBay = getBayFromNextSection(vesselCode, sectionNo, deckIndication,
                                profileRequest.getUserID());
                    }

                    sendBayProfileToDevice(profileRequest, bayProfiles.get(bayNo), nextBay, viewType, false,
                            deckIndication);
                }
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, profileRequest.getUserID(), " The bay requested doesn't exist " + bayNo);
                sendEmptyProfileToDevice(profileRequest, bayNo, deckIndication);
            }
        } catch (Exception ex) {
            logger.logException(
                    "Caught exception while creating the bay Profile message to device for bay No " + bayNo, ex);
            sendEmptyProfileToDevice(profileRequest, "-1", deckIndication);
        }
    }

    /**
     * Tries to retrieve the next bay from the next section in the vessel
     * 
     * @param vesselCode
     * @param sectionNo
     * @param deckIndication
     * @param profileRequest
     */
    private BayProfile getBayFromNextSection(String vesselCode, String sectionNo, String deckIndication, String userId) {
        String[] sectionDetails = sectionNo.split(":");
        int nextSection = Integer.parseInt(sectionDetails[1]) + 1;
        logger.logMsg(LOG_LEVEL.INFO, vesselCode, "Trying to get the bay from next section " + nextSection);

        String nextSectionKey = vesselCode + ":" + nextSection;
        boolean bayFound = false;
        BayProfile nextBay = null;
        for (String section : RDTVesselProfileCacheManager.getInstance().getSectionBayProfileKeySet()) {
            if (section.equals(nextSectionKey)) {
                logger.logMsg(LOG_LEVEL.DEBUG, vesselCode, "Found the next section with bays ");

                Map<String, BayProfile> bayProfiles = RDTVesselProfileCacheManager.getInstance()
                        .getBayProfiles(section);
                String currentBayDeckIndication;
                for (String bay : bayProfiles.keySet()) {
                    nextBay = bayProfiles.get(bay);
                    currentBayDeckIndication = nextBay.isUnderDeckIndicator() ? "U" : "D";
                    if (!currentBayDeckIndication.equals(deckIndication)) {
                        logger.logMsg(LOG_LEVEL.DEBUG, vesselCode,
                                "The DeckIndication doesn't match : Actual Deck requested:" + deckIndication
                                        + ", but found the next bay with " + currentBayDeckIndication);
                        return null;
                    } else {
                        return nextBay;
                    }
                }
            }
        }

        if (!bayFound) {
            logger.logMsg(LOG_LEVEL.DEBUG, userId, " Couldn't find next section for the vessel");
        }

        return null;
    }

    /**
     * Sends an empty bay profile response to the device, indicating that the requested bay is not present for the
     * vessel.
     * 
     * @param profileRequest
     * @param bayNo
     */
    private void sendEmptyProfileToDevice(Event profileRequest, String bayNo, String deckInd) {
        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(BAY_FRONT_VIEW);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            
            StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID);
           
            responseToDevice.append(valueSeperator).append(profileRequest.getEventID()).append(valueSeperator)
                    .append(bayNo).append(valueSeperator).append(valueSeperator).append(valueSeperator)
                    .append(BAY_SEPERATOR_KEY).append(valueSeperator).append(valueSeperator).append(valueSeperator)
                    .append(valueSeperator);

            if (deckInd != null) {
                responseToDevice.append(deckInd);
            }
            responseToDevice.append(valueSeperator).append(profileRequest.getUserID()).append(valueSeperator)
                    .append(profileRequest.getTerminalID());

            User user = RDTCacheManager.getInstance().getUserDetails(profileRequest.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(profileRequest.getUserID());
                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        profileRequest.getTerminalID());
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while creating the empty bay Profile message to device for bay No "
                    + bayNo, ex);
        }
    }

    /**
     * <p> Construct and send the bay view details to device. </p>
     * 
     * <p> For the specified bayProfile, the cellGrid[tier][row] is converted into the message as -
     * rowHeader1^rowHeader2^rowHeader3~tierHeader1^tierHeader2~
     * cell00Status^containerId#cell01Status^containerId#cell02Status
     * ^containerId|cell10Status^containerId#cell11Status^containerId#cell12Status^containerId</p>
     * 
     * @param profileRequest
     * @param bayProfile
     * @param viewType
     */
    private void sendBayProfileToDevice(Event profileRequest, BayProfile bayProfile1, BayProfile bayProfile2,
            BAY_VIEW viewType, boolean partOfTwinBay, String deckInd) {
        logger.logMsg(LOG_LEVEL.INFO, profileRequest.getUserID(),
                "Creating bay profile details message to device for bayNo:" + bayProfile1.getVesselBayId());

        try {
            String eventType = BAY_FRONT_VIEW;

            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID);
           
            String msgField;
            
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                msgField = msgFields.get(i);
                if ("BayDetails".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(bayProfile1.getVesselBayId()).append(valueSeperator)
                            .append(bayProfile1.getBayView(viewType, false)).append(BAY_SEPERATOR_KEY);

                    if (bayProfile2 != null) {
                        responseToDevice.append(bayProfile2.getVesselBayId()).append(valueSeperator)
                                .append(bayProfile2.getBayView(viewType, partOfTwinBay));
                    }else {
                    	responseToDevice.append(valueSeperator).append(valueSeperator).append(valueSeperator);
                    }
                } else if ("DeckIndication".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(deckInd);
                } else {
                    EventUtil.getInstance().getEventParameter(profileRequest, msgFields.get(i), responseToDevice);
                }
            }

            User user = RDTCacheManager.getInstance().getUserDetails(profileRequest.getUserID());
            if (user != null) {
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(profileRequest.getUserID());
                CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                        profileRequest.getTerminalID());
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while creating the bay Profile message to device for bay No "
                    + bayProfile1.getVesselBayId(), ex);
        }
    }
}
