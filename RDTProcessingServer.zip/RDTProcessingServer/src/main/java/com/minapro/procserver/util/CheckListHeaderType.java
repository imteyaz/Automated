package com.minapro.procserver.util;

/**
 * Enum indicating the possible types of checklist headers applicable
 * 
 * @author Rosemary George
 *
 */
public enum CheckListHeaderType {
    PRE_OP("PRE OPERATIONAL"), POST_OP("POST OPERATIONAL"), VESSEL("VESSEL"), SECURITY("SECURITY"), BERTH("BERTH");

    private String name;

    private CheckListHeaderType(String name) {
        this.setName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
