package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the updated container location details.
 * 
 * @author Rosemary George
 *
 */
public class UpdateContainerLocationEvent extends Event implements Serializable {

	private static final long serialVersionUID = -8105400518310537947L;

	/**
	 * container which is getting updated
	 */
	private String containerId;

	/**
	 * the current location of the container in the vessel will be in bb.rr.tt format
	 */
	private String location;

	/**
	 * RotationID of the vessel to which the container belongs to
	 */
	private String rotationId;
	
	/**
     * Vessel name passed which should be retrieved from joblist
     */
    private String vessel;
    
    /**
     * Voyage number passed which should be retrieved from joblist
     */
    private String voyage;
    /**
     * Container Move Type
     */
    private String moveType;
    
    /**
     * Source location of the container in vessel
     */
    private String sourceLocation;
    
    
	
    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}
	public String getVessel() {
		return vessel;
	}

	public void setVessel(String vessel) {
		this.vessel = vessel;
	}

	public String getVoyage() {
		return voyage;
	}

	public void setVoyage(String voyage) {
		this.voyage = voyage;
	}

	public String getSourceLocation() {
		return sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	public String getRotationId() {
		return rotationId;
	}

	public void setRotationId(String rotationId) {
		this.rotationId = rotationId;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "UpdateContainerLocationEvent [containerId=" + containerId
				+ ", location=" + location + ", rotationId=" + rotationId
				+ ", vessel=" + vessel + ", voyage=" + voyage + ", moveType="
				+ moveType + ", sourceLocation=" + sourceLocation
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}

	
}
