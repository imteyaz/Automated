package com.minapro.procserver.events;

import java.io.Serializable;

public class OPUSTwinTandemJobsPOJO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4534869564579129834L;
	private String containerID;
	private String moveKind;
	private String fromLocation;
	private String toLocation;
	private String twinTandemCode;
	private double seqNo;
	
	private String refContainerID;
	private String refMoveKind;
	private String refFromLocation;
	private String refToLocation;
	private double refSeqNo;
	private String refTwinTandemCode;
	private String twinTandemCodeId;
	private String refCntrtwinTandemCodeId;
	
	private boolean isCurJobModified;
	
	private String operationCode;
    private String twinTandemId;
    private String minaproTwinSplit;
	
	public String getTwinTandemCodeId() {
        return twinTandemCodeId;
    }

    public void setTwinTandemCodeId(String twinTandemCodeId) {
        this.twinTandemCodeId = twinTandemCodeId;
    }

    public String getRefCntrtwinTandemCodeId() {
        return refCntrtwinTandemCodeId;
    }

    public void setRefCntrtwinTandemCodeId(String refCntrtwinTandemCodeId) {
        this.refCntrtwinTandemCodeId = refCntrtwinTandemCodeId;
    }
    
	public boolean getIsCurJobModified() {
		return isCurJobModified;
	}

	public void setIsCurJobModified(boolean isCurJobModified) {
		this.isCurJobModified = isCurJobModified;
	}

	public String getTwinTandemCode() {
		return twinTandemCode;
	}

	public void setTwinTandemCode(String twinTandemCode) {
		this.twinTandemCode = twinTandemCode;
	}

	public String getRefTwinTandemCode() {
		return refTwinTandemCode;
	}

	public void setRefTwinTandemCode(String refTwinTandemCode) {
		this.refTwinTandemCode = refTwinTandemCode;
	}	
	
	public String getContainerID() {
		return containerID;
	}

	public void setContainerID(String containerID) {
		this.containerID = containerID;
	}

	public String getMoveKind() {
		return moveKind;
	}

	public void setMoveKind(String moveKind) {
		this.moveKind = moveKind;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public double getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(double seqNo) {
		this.seqNo = seqNo;
	}

	public double getRefSeqNo() {
		return refSeqNo;
	}

	public void setRefSeqNo(double refSeqNo) {
		this.refSeqNo = refSeqNo;
	}

	public String getRefContainerID() {
		return refContainerID;
	}

	public void setRefContainerID(String refContainerID) {
		this.refContainerID = refContainerID;
	}

	public String getRefMoveKind() {
		return refMoveKind;
	}

	public void setRefMoveKind(String refMoveKind) {
		this.refMoveKind = refMoveKind;
	}

	public String getRefFromLocation() {
		return refFromLocation;
	}

	public void setRefFromLocation(String refFromLocation) {
		this.refFromLocation = refFromLocation;
	}

	public String getRefToLocation() {
		return refToLocation;
	}

	public void setRefToLocation(String refToLocation) {
		this.refToLocation = refToLocation;
	}

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public String getTwinTandemId() {
		return twinTandemId;
	}

	public void setTwinTandemId(String jtwinTandemId) {
		this.twinTandemId = jtwinTandemId;
	}

	public String getMinaproTwinSplit() {
		return minaproTwinSplit;
	}

	public void setMinaproTwinSplit(String sparcsSplit) {
		this.minaproTwinSplit = sparcsSplit;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((containerID == null) ? 0 : containerID.hashCode())
				+ ((refContainerID == null) ? 0 : refContainerID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		OPUSTwinTandemJobsPOJO otherObj = (OPUSTwinTandemJobsPOJO) obj;
		
		if (otherObj == null || containerID == null || otherObj.containerID == null) {
			return false;
		}
		
		if (refContainerID == null || otherObj.refContainerID == null) {
			return false;
		}

		if ((containerID.equals(otherObj.refContainerID)) && (refContainerID.equals(otherObj.containerID))
				|| (containerID.equals(otherObj.containerID) && refContainerID.equals(otherObj.refContainerID))) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "OPUSTwinTandemJobsPOJO [containerID=" + containerID
				+ ", moveKind=" + moveKind + ", fromLocation=" + fromLocation
				+ ", toLocation=" + toLocation + ", twinTandemCode="
				+ twinTandemCode + ", seqNo=" + seqNo + ", refContainerID="
				+ refContainerID + ", refMoveKind=" + refMoveKind
				+ ", refFromLocation=" + refFromLocation + ", refToLocation="
				+ refToLocation + ", refSeqNo=" + refSeqNo
				+ ", refTwinTandemCode=" + refTwinTandemCode
				+ ", twinTandemCodeId=" + twinTandemCodeId
				+ ", refCntrtwinTandemCodeId=" + refCntrtwinTandemCodeId
				+ ", operationCode=" + operationCode + ", twinTandemId="
				+ twinTandemId + ", minaproTwinSplit=" + minaproTwinSplit + "]";
	}	
}
