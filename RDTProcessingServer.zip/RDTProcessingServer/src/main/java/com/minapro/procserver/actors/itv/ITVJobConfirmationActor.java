package com.minapro.procserver.actors.itv;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITVJobConfirmationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * </p>Actor class responsible for handling the ITVJobConfirmationEvent coming from the communication server.</p>
 * 
 * <p>The event is forwarded to the ESB for informing the DPW It systems. Also if any pending instructions are available
 * for the ITV in the cache, the instruction is forwarded to the device.</p>
 * 
 * @author Rosemary George
 *
 */
public class ITVJobConfirmationActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVJobConfirmationActor.class);

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof ITVJobConfirmationEvent) {
            ITVJobConfirmationEvent jobConfirmation = (ITVJobConfirmationEvent) message;
            try {
                logger.logMsg(LOG_LEVEL.INFO, jobConfirmation.getEquipmentID(),
                        "ITV JobConfirmation received with container-" + jobConfirmation.getContainerID());

                User user = RDTCacheManager.getInstance().getUserDetails(jobConfirmation.getUserID());
                OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(jobConfirmation.getUserID());
                ESBQueueManager.getInstance().postMessage(jobConfirmation, operatorRole,
                        jobConfirmation.getTerminalID());

                // check for pending instructions
                List<DriveInstructionEvent> pendingInstructions = RDTCacheManager.getInstance()
                        .getPendingITVInstructions(jobConfirmation.getEquipmentID());
                if (pendingInstructions != null && !pendingInstructions.isEmpty()) {
                    DriveInstructionEvent driveInstruction = pendingInstructions.get(0);
                    logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Sending DriveInstruction for ITV -"
                            + driveInstruction);
                    getSender().tell(driveInstruction, null);
                    RDTCacheManager.getInstance().removeFromPendingITVInstructions(driveInstruction);
                }
            } catch (Exception e) {
                logger.logException("Caught exception while processing ITV Job confirmation event - ", e);
            }
        } else {
            unhandled(message);
        }
    }
}
