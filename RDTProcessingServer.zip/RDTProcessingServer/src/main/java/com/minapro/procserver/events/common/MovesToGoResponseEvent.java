package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the moves to go response event.
 * @author Rosemary George
 *
 */
public class MovesToGoResponseEvent extends Event implements Serializable{

	private static final long serialVersionUID = 5258726751273821569L;

	/**
	 * Equipment for which the planned moves are requested
	 */
	private String qcId;
	
	/**
	 * List of container count based on the moveType+size+empty/full combination
	 */
	private List<MovesToGoContainers> movesToGoList;

	public String getQcId() {
		return qcId;
	}

	public void setQcId(String qcId) {
		this.qcId = qcId;
	}

	public List<MovesToGoContainers> getMovesToGoList() {
		return movesToGoList;
	}

	public void setMovesToGoList(List<MovesToGoContainers> movesToGoList) {
		this.movesToGoList = movesToGoList;
	}

	@Override
	public String toString() {
		return "MovesToGoResponseEvent [qcId=" + qcId + ", movesToGoList=" + movesToGoList + ", getUserID()="
				+ getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}	
}
