package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * @author Umamahesh M
 *
 */
public class OperatorAvailabilityEvent extends Event implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * For Operator Status Whether Available Or Non Available
     */
    private String isAvailable;

    /**
     * Which location Request has come And Which Location Response has To sent
     */
    private String location;

    private String rotationID;

    private String password;
    /**
     * User going to break with this reason
     */
    private String unavailableReason;

    private String unAvailableDuration;
    
    private String userName;
    
    /**
     * Indicates whether the request is initiated by operator or system
     */
    private boolean isOperatorInitiated;
    
    private boolean createDelay;
    
    /**
     * Vessel name passed which should be retrieved from job list
     */
    private String vessel;
    
    /**
     * Voyage number passed which should be retrieved from job list
     */
    private String voyage;
    
    /**
     * Indicates whether invoked from call ITV feature or not.
     */
    private boolean callItv;
    
    public boolean isCallItv() {
		return callItv;
	}

	public void setCallItv(boolean callItv) {
		this.callItv = callItv;
	}

	public boolean isCreateDelay() {
		return createDelay;
	}

	public void setCreateDelay(String createDelay) {
		this.createDelay = "T".equalsIgnoreCase(createDelay)? true :false;
	}
    
    public boolean isOperatorInitiated() {
		return isOperatorInitiated;
	}

	public void setOperatorInitiated(boolean isOperatorInitiated) {
		this.isOperatorInitiated = isOperatorInitiated;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUnAvailableDuration() {
        return unAvailableDuration;
    }

    public void setUnAvailableDuration(String unAvailableDuration) {
        this.unAvailableDuration = unAvailableDuration;
    }

    public String getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getUnavailableReason() {
        return unavailableReason;
    }

    public void setUnavailableReason(String unavailableReason) {
        this.unavailableReason = unavailableReason;
    }
    
    public String getVessel() {
		return vessel;
	}

	public void setVessel(String vessel) {
		this.vessel = vessel;
	}

	public String getVoyage() {
		return voyage;
	}

	public void setVoyage(String voyage) {
		this.voyage = voyage;
	}

	@Override
	public String toString() {
		return "OperatorAvailabilityEvent [isAvailable=" + isAvailable + ", location=" + location + ", rotationID="
				+ rotationID + ", password=" + password + ", unavailableReason=" + unavailableReason
				+ ", unAvailableDuration=" + unAvailableDuration + ", userName=" + userName + ", isOperatorInitiated="
				+ isOperatorInitiated + ", createDelay=" + createDelay + ", vessel=" + vessel + ", voyage=" + voyage
				+ ", callItv=" + callItv + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}
}
