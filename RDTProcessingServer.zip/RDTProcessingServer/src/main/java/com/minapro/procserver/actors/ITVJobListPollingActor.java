package com.minapro.procserver.actors;

import static com.minapro.procserver.util.MinaproLoggerConstants.OPERATOR_IN_BREAK;

import java.util.Set;
import java.util.UUID;

import scala.collection.mutable.StringBuilder;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.procserver.util.EventUtil.EquipmentJobListRequestStatus;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import akka.actor.UntypedActor;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS;
import static com.minapro.procserver.util.MinaproLoggerConstants.EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS;
/**
 * Actor responsible for sending ITV job list request to ESB periodically. The actor wakes at configured intervals and
 * sends job list requests for all ITVs which are logged in and completed the checklist inspection.
 * If already one job list request is in progress, no job list request is sent for that particular ITV.
 * 
 * @author Rosemary George
 *
 */
public class ITVJobListPollingActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVJobListPollingActor.class);
	private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
			RDTProcessingServerConstants.TERMINAL_KEY);
	
	@Override
	public void onReceive(Object message) throws Exception {
		
		if(RDTCacheManager.getInstance().getKeepAliveStatus()){
			Equipment equipment = null;
			
			try {
				// look for all users who have confirmed allocations
				RDTCacheManager rdtCacheManager = RDTCacheManager.getInstance();
				Set<String> userList = rdtCacheManager.getAllocatedUsers();
				User user;
				if (userList != null && !userList.isEmpty()) {	
					
					for (String userId : userList) {
						OPERATOR operator = rdtCacheManager.getUserLoggedInRole(userId);	
						if (operator.equals(OPERATOR.ITV)) {
							if (!rdtCacheManager.isOperatorAvailable(userId)) {
								logger.logMsg(LOG_LEVEL.INFO, userId, OPERATOR_IN_BREAK);
								continue;
							}
							String deviceId;
							deviceId = rdtCacheManager.getDeviceMapping(userId);	
							if (deviceId != null) {
								Device device = rdtCacheManager.getDeviceDetails(deviceId);
								user = rdtCacheManager.getUserDetails(userId);
								if (device != null) {
									logger.logMsg(LOG_LEVEL.INFO, userId, "Current Operator Is ITV");	
									equipment = device.getEquipment();
									sendJobListRequest(device, user);
								}								
							}	
						} 
					}
				} 
			} catch (Exception ex) {
				logger.logException("Caught exception while polling :", ex);
				if(equipment!=null) {
					RDTCacheManager.getInstance().setEqJobListReqStatus(equipment.getEquipmentID(),EquipmentJobListRequestStatus.COMPLETED);
				}
			}
		} else {
			logger.logMsg(LOG_LEVEL.WARN, "", "Keep alive status is DOWN. Not sending job list polling request");
		}
	}
	
	/**
	 * Constructs the JobListRequestEvent and sends it to ESB
	 * 
	 * @param device
	 * @param user
	 */
	private void sendJobListRequest(Device device, User user) {

		Equipment equipment = device.getEquipment();
		if (equipment != null) {
			String userId = user.getUserID();
			String equipmentId = equipment.getEquipmentID();

			String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(userId);
			if (inspectionStatus != null) {

				/*
				 * Condition added to check whether current equipment job list request is in progress stage or not. If
				 * it is in progress stage Ignore current refresh for current equipment.
				 */
				if (EventUtil.isEquipmentJobListReqInProgress(equipmentId)) {
					logger.logMsg(LOG_LEVEL.WARN, userId,
							new StringBuilder(equipmentId).append(EQUIPMENT_JOB_LIST_REQUEST_IN_PROGRESS).toString());
					return;
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, userId,
							new StringBuilder(equipmentId).append(EQUIPMENT_JOB_LIST_REQ_COMPLETE_TO_IN_PROGRESS).toString());
					RDTCacheManager.getInstance().setEqJobListReqStatus(equipmentId,
							EquipmentJobListRequestStatus.IN_PROGRESS);
				}
				logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "Sending joblist request");

				JobListRequestEvent requestEvent = new JobListRequestEvent();
				requestEvent.setEquipmentID(equipment.getEquipmentID());
				requestEvent.setUserID(userId);
				requestEvent.setTerminalID(TERMINAL_ID);
				requestEvent.setEventID(UUID.randomUUID().toString());
				requestEvent.setScheduled(true);

				ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
						.getAllocationDetails(userId);
				requestEvent.setLocation(allocationDetails.getLocation());

				requestEvent.setRotationId(allocationDetails.getRotationID());
				requestEvent.setPassword(user.getPassword());

				ESBQueueManager.getInstance().postMessage(requestEvent, OPERATOR.ITV, TERMINAL_ID);
			} else {
				logger.logMsg(LOG_LEVEL.INFO, user.getUserID(),
						"Skipping JobList poll as pre-operational inspection is not completed.");
			}
		} 
	}
}
