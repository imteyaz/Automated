package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.minapro.procserver.db.Audit;

/**
 * ValueObject which holds the colour code details for specific items
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_COLOUR_CODE_MASTER")
public class ColourCode extends Audit implements Serializable {

    private static final long serialVersionUID = 7558375290322984378L;

    @Id
    @GeneratedValue
    @Column(name = "COLOUR_CODE_ID")
    private int id;

    @Column(name = "ITEM_NAME")
    private String itemName;

    @Column(name = "ITEM_GROUP")
    private String itemGroup;

    @Column(name = "HEXA_CODE")
    private String hexaCode;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemGroup() {
        return itemGroup;
    }

    public void setItemGroup(String itemGroup) {
        this.itemGroup = itemGroup;
    }

    public String getHexaCode() {
        return hexaCode;
    }

    public void setHexaCode(String hexaCode) {
        this.hexaCode = hexaCode;
    }
}
