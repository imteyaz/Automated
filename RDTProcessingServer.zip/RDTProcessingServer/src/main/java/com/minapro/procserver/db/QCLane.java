package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ValueObject holding details about the QC Lanes available
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_QC_LANE_MASTER")
public class QCLane extends Audit implements Serializable {

    private static final long serialVersionUID = 378657622358104119L;

    @Id
    @Column(name = "LANE_ID", nullable = false)
    private String laneID;

    @Column(name = "DRIVE_DIRECTION", nullable = false)
    private String drivingDirection;

    @Column(name = "AVAILABILITY", nullable = false)
    private String available;

    @Column(name = "LANE_DESCRIPTION")
    private String laneDescription;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TERMINAL_ID", referencedColumnName = "TERMINAL_ID")
    private Terminal terminalId;

    public String getLaneDescription() {
        return laneDescription;
    }

    public void setLaneDescription(String laneDescription) {
        this.laneDescription = laneDescription;
    }

    public Terminal getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(Terminal terminalId) {
        this.terminalId = terminalId;
    }

    public String getLaneID() {
        return laneID;
    }

    public void setLaneID(String laneID) {
        this.laneID = laneID;
    }

    public String getDrivingDirection() {
        return drivingDirection;
    }

    public void setDrivingDirection(String drivingDirection) {
        this.drivingDirection = drivingDirection;
    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }
}
