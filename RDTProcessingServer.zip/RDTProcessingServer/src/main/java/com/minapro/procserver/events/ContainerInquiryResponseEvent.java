package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the details of the container for which the inquiry is requested
 * @author Rosemary George
 *
 */
public class ContainerInquiryResponseEvent extends Event implements Serializable{

    private static final long serialVersionUID = -527495233001999960L;

    private String containerId;
    
    /**
     * Indicates whether the particular container details were retrieved or not. 
     * True means, the inquiry successful, else false
     */
    private boolean inquiryStatus;
    
    private String line;
    
    private String terminal;
    
    private String currentPos;
    
    private String status;
    
    private String yardIn;
    
    private boolean isStopped;
    
    private boolean isDamaged;
    
    private String inBoundVessel;
    
    private String inBoundRotation;
    
    private String outBoundVessel;
    
    private String outBoundRotation;
    
    private String shipper;
    
    private String pod;
    
    private  String loadPort;
    
    private boolean isSealed;
    
    private String sealNo;
    
    private String imoClass;
    
    private boolean isReefer;
    
    private boolean isPluggedIn;
    
    private String weight;
    
    /**
     * OOG related attributes
     */
    private boolean isOOG;
    private String oogLeft;    
    private String oogRight;
    private String oogFront;
    private String oogBack;
    private String oogTop;
    
    private String iso;
    
    private String agent;
    
    private String moveKind;
    
    private String stoDays;
    
    private String category;
    
    private String yardOut;
    
    private String stopReason;
    
    private String damageCode;
    
    private String consignee;
    
    private String destination;
    
    private String originPort;
    
    private String unNo;
    
    private String temperature;
    
    private String plugInDays;
    
    private String content;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public boolean isInquiryStatus() {
        return inquiryStatus;
    }

    public void setInquiryStatus(boolean inquiryStatus) {
        this.inquiryStatus = inquiryStatus;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getCurrentPos() {
        return currentPos;
    }

    public void setCurrentPos(String currentPos) {
        this.currentPos = currentPos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getYardIn() {
        return yardIn;
    }

    public void setYardIn(String yardIn) {
        this.yardIn = yardIn;
    }

    public boolean isStopped() {
        return isStopped;
    }

    public void setStopped(boolean isStopped) {
        this.isStopped = isStopped;
    }

    public boolean isDamaged() {
        return isDamaged;
    }

    public void setDamaged(boolean isDamaged) {
        this.isDamaged = isDamaged;
    }

    public String getInBoundVessel() {
        return inBoundVessel;
    }

    public void setInBoundVessel(String inBoundVessel) {
        this.inBoundVessel = inBoundVessel;
    }

    public String getInBoundRotation() {
        return inBoundRotation;
    }

    public void setInBoundRotation(String inBoundRotation) {
        this.inBoundRotation = inBoundRotation;
    }

    public String getOutBoundVessel() {
        return outBoundVessel;
    }

    public void setOutBoundVessel(String outBoundVessel) {
        this.outBoundVessel = outBoundVessel;
    }

    public String getOutBoundRotation() {
        return outBoundRotation;
    }

    public void setOutBoundRotation(String outBoundRotation) {
        this.outBoundRotation = outBoundRotation;
    }

    public String getShipper() {
        return shipper;
    }

    public void setShipper(String shipper) {
        this.shipper = shipper;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getLoadPort() {
        return loadPort;
    }

    public void setLoadPort(String loadPort) {
        this.loadPort = loadPort;
    }

    public boolean isSealed() {
        return isSealed;
    }

    public void setIsSealed(boolean isSealed) {
        this.isSealed = isSealed;
    }

    public String getSealNo() {
        return sealNo;
    }

    public void setSealNo(String sealNo) {
        this.sealNo = sealNo;
    }

    public String getImoClass() {
        return imoClass;
    }

    public void setImoClass(String imoClass) {
        this.imoClass = imoClass;
    }

    public boolean isReefer() {
        return isReefer;
    }

    public void setReefer(boolean isReefer) {
        this.isReefer = isReefer;
    }

    public boolean isPluggedIn() {
        return isPluggedIn;
    }

    public void setPluggedIn(boolean isPluggedIn) {
        this.isPluggedIn = isPluggedIn;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public boolean isOOG() {
        return isOOG;
    }

    public void setOOG(boolean isOOG) {
        this.isOOG = isOOG;
    }

    public String getOogLeft() {
        return oogLeft;
    }

    public void setOogLeft(String oogLeft) {
        this.oogLeft = oogLeft;
    }

    public String getOogRight() {
        return oogRight;
    }

    public void setOogRight(String oogRight) {
        this.oogRight = oogRight;
    }

    public String getOogFront() {
        return oogFront;
    }

    public void setOogFront(String oogFront) {
        this.oogFront = oogFront;
    }

    public String getOogBack() {
        return oogBack;
    }

    public void setOogBack(String oogBack) {
        this.oogBack = oogBack;
    }

    public String getOogTop() {
        return oogTop;
    }

    public void setOogTop(String oogTop) {
        this.oogTop = oogTop;
    }

    public String getIso() {
        return iso;
    }

    public void setIso(String iso) {
        this.iso = iso;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getMoveKind() {
        return moveKind;
    }

    public void setMoveKind(String moveKind) {
        this.moveKind = moveKind;
    }

    public String getStoDays() {
        return stoDays;
    }

    public void setStoDays(String stoDays) {
        this.stoDays = stoDays;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getYardOut() {
        return yardOut;
    }

    public void setYardOut(String yardOut) {
        this.yardOut = yardOut;
    }

    public String getStopReason() {
        return stopReason;
    }

    public void setStopReason(String stopReason) {
        this.stopReason = stopReason;
    }

    public String getDamageCode() {
        return damageCode;
    }

    public void setDamageCode(String damageCode) {
        this.damageCode = damageCode;
    }

    public String getConsignee() {
        return consignee;
    }

    public void setConsignee(String consignee) {
        this.consignee = consignee;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getOriginPort() {
        return originPort;
    }

    public void setOriginPort(String originPort) {
        this.originPort = originPort;
    }

    public String getUnNo() {
        return unNo;
    }

    public void setUnNo(String unNo) {
        this.unNo = unNo;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getPlugInDays() {
        return plugInDays;
    }

    public void setPlugInDays(String plugInDays) {
        this.plugInDays = plugInDays;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ContainerInquiryResponseEvent [containerId=" + containerId + ", inquiryStatus=" + inquiryStatus
                + ", line=" + line + ", terminal=" + terminal + ", currentPos=" + currentPos + ", status=" + status
                + ", yardIn=" + yardIn + ", isStopped=" + isStopped + ", isDamaged=" + isDamaged + ", inBoundVessel="
                + inBoundVessel + ", inBoundRotation=" + inBoundRotation + ", outBoundVessel=" + outBoundVessel
                + ", outBoundRotation=" + outBoundRotation + ", shipper=" + shipper + ", pod=" + pod + ", loadPort="
                + loadPort + ", isSealed=" + isSealed + ", sealNo=" + sealNo + ", imoClass=" + imoClass + ", isReefer="
                + isReefer + ", isPluggedIn=" + isPluggedIn + ", weight=" + weight + ", isOOG=" + isOOG + ", oogLeft="
                + oogLeft + ", oogRight=" + oogRight + ", oogFront=" + oogFront + ", oogBack=" + oogBack + ", oogTop="
                + oogTop + ", iso=" + iso + ", agent=" + agent + ", moveKind=" + moveKind + ", stoDays=" + stoDays
                + ", category=" + category + ", yardOut=" + yardOut + ", stopReason=" + stopReason + ", damageCode="
                + damageCode + ", consignee=" + consignee + ", destination=" + destination + ", originPort="
                + originPort + ", unNo=" + unNo + ", temperature=" + temperature + ", plugInDays=" + plugInDays
                + ", content=" + content + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }   
}
