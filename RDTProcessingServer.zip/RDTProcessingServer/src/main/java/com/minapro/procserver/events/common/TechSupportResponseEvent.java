package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.Set;

import com.minapro.procserver.events.Event;

public class TechSupportResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2155090319667350304L;

    private Set<String> problemCodes;

    public Set<String> getProblemCodes() {
        return problemCodes;
    }

    public void setProblemCodes(Set<String> problemCodes) {
        this.problemCodes = problemCodes;
    }

    public String toString() {
        return "TechSupportResponseEvent [UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID()
                + ", TerminalID=" + getTerminalID() + " Probelm Codes= " + problemCodes + "]";
    }
}
