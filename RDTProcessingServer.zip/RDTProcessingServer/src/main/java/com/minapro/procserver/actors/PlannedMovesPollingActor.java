package com.minapro.procserver.actors;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.Device;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.PlannedMovesRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;
import static com.minapro.procserver.util.MinaproLoggerConstants.OPERATOR_IN_BREAK;

/**
 * Class is responsible to send request to ESb for every one hour(It is configurable at Admin Module) to get the planned
 * moves from BPA-CONTAINER_MOVES table. At the time of polling checking logged in users and If operator is of type QC
 * Sending request to esb else skipping that re quest. After notification came from ESB,putting all values into the
 * cache.
 * 
 * @author UmaMahesh.M
 *
 */
public class PlannedMovesPollingActor extends UntypedActor {

    MinaProApplicationLogger logger = new MinaProApplicationLogger(PlannedMovesPollingActor.class);

    private static final String TERMINAL_ID = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.TERMINAL_KEY);

    @Override
    public void onReceive(Object msg) throws Exception {
    	
    	try {
            getWorkingQCs();
        } catch (Exception ex) {
            logger.logException(" Exception Occured While Getting Logged In QC Users Retrieval", ex);
        }
    }

    public void getWorkingQCs() {

        logger.logMsg(LOG_LEVEL.INFO, "", " Started getWorkingQCs()");

        RDTCacheManager rdtCache = RDTCacheManager.getInstance();
        Set<String> allocatedUsers = rdtCache.getAllocatedUsers();

        if (allocatedUsers != null && !(allocatedUsers.isEmpty())) {

            PlannedMovesRequestEvent plannedMovesReqEvent = new PlannedMovesRequestEvent();
            List<PlannedMovesEvent> plannedMovesReqEvntList = new ArrayList<PlannedMovesEvent>();

            Equipment equipment = null;
            String pow = null;
            String rotationId = null;

            logger.logMsg(LOG_LEVEL.INFO, " ", " No Of Logged In Users  " + allocatedUsers.size());

            for (String currentUser : allocatedUsers) {
            	
            	if(!rdtCache.isOperatorAvailable(currentUser)){
            		logger.logMsg(LOG_LEVEL.INFO,currentUser,OPERATOR_IN_BREAK);
            		continue;
            	}
                OPERATOR operatorRole = rdtCache.getUserLoggedInRole(currentUser);

                logger.logMsg(LOG_LEVEL.INFO, " ", " Current user " + currentUser + " Role Is  " + operatorRole);

                if (operatorRole.equals(OPERATOR.QC)) {

                    Device device = rdtCache.getDeviceDetails(rdtCache.getDeviceMapping(currentUser));

                    if (device != null && device.getEquipment().getEquipmentID() != null) {

                        equipment = device.getEquipment();
                    }

                } else if (operatorRole.equals(OPERATOR.HC)) {

                    equipment = rdtCache.getEquipmentDetails(rdtCache.getQCEquipmentAllocatedForHC(currentUser));

                    if (equipment != null) {

                        int plannedMoves = RDTPLCCacheManager.getInstance().getPlannedMovesCount(equipment.getEquipmentID());

                        if (plannedMoves != 0) {
                            logger.logMsg(LOG_LEVEL.INFO, currentUser,
                                    " Planned Moves Count Already Available In Cache For Current HC User ");
                            continue;
                        }

                    } else {
                        logger.logMsg(LOG_LEVEL.DEBUG, currentUser,
                                " Equipment Is Not Available In Cache For Current Logged In HC Operator");
                        continue;
                    }
                } else {
                    logger.logMsg(LOG_LEVEL.INFO, " ", " Current user " + currentUser + " Is Not A QC Operator");
                    continue;
                }

                pow = equipment.getPow();

                if (pow != null) {

                    PlannedMovesEvent plannedMoveEvent = new PlannedMovesEvent();

                    ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) rdtCache
                            .getAllocationDetails(currentUser);

                    rotationId = allocationDetails.getRotationID();

                    plannedMoveEvent.setUserID(currentUser);
                    plannedMoveEvent.setEquipmentID(equipment.getEquipmentID());
                    plannedMoveEvent.setPow(pow);
                    plannedMoveEvent.setRotationId(rotationId);
                    plannedMoveEvent.setTerminalID(TERMINAL_ID);
                    plannedMoveEvent.setPlannedMoves(0);
                    logger.logMsg(LOG_LEVEL.INFO, "", " Adding PlannedMoveEvent to List " + plannedMoveEvent.toString());
                    plannedMovesReqEvntList.add(plannedMoveEvent);
                } else {
                    logger.logMsg(LOG_LEVEL.INFO, " ", "Pow is null in databse,Update POW according to Equipment");
                    continue;
                }
            }
           
            plannedMovesReqEvent.setPlannedMovesRequest(plannedMovesReqEvntList);
            int currentWorkingQCsCount = plannedMovesReqEvntList.size();
            logger.logMsg(LOG_LEVEL.INFO, "", " No Of QC's Working As Of now::" + currentWorkingQCsCount);

            if (currentWorkingQCsCount > 0) {
                logger.logMsg(LOG_LEVEL.INFO, "","Posting Data Into ESB Queue Manager ");

                ESBQueueManager.getInstance().postMessage(plannedMovesReqEvent, OPERATOR.QC, TERMINAL_ID);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, "", " No QC Operator Is Logged In As Of Now");
            }

        } else {
            logger.logMsg(LOG_LEVEL.INFO, " ", " No Users Are Logged In As Of Now");
        }
    }
}
