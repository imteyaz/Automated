package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the General Lift Operation event details Modified by Kumaraswamy - added qcId, orderNo for OBF
 * Role.
 * 
 * @author Venkataramana.ch
 * 
 */

public class GeneralLiftOperationEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8643025368204505874L;

    private String jobString;

    private boolean jobDone;

    private String moveType;

    private String fromLocation;

    private String toLocation;

    private String qcId;

    private String orderNo;

    public String getJobString() {
        return jobString;
    }

    public void setJobString(String jobString) {
        this.jobString = jobString;
    }

    public boolean isJobDone() {
        return jobDone;
    }

    public void setJobDone(boolean jobDone) {
        this.jobDone = jobDone;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getQcId() {
        return qcId;
    }

    public void setQcId(String qcId) {
        this.qcId = qcId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    @Override
    public String toString() {
        return "GeneralLiftOperationEvent [jobString=" + jobString + ", jobDone=" + jobDone + ", moveType=" + moveType
                + ", fromLocation=" + fromLocation + ", toLocation=" + toLocation + ", qcId=" + qcId + ", orderNo="
                + orderNo + "]";
    }

}
