package com.minapro.procserver.cep;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_DELAY_RECORDING_INTERVAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOCKED_UP_VALUE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LS_WEIGHT_THRESHOLD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_DELAY_RECORDING;
import static com.minapro.procserver.util.RDTProcessingServerConstants.UNLOCKED_UP_VALUE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.WS_WEIGHT_THRESHOLD;

import java.io.Serializable;

import com.espertech.esper.client.Configuration;
import com.espertech.esper.client.EPAdministrator;
import com.espertech.esper.client.EPRuntime;
import com.espertech.esper.client.EPServiceProvider;
import com.espertech.esper.client.EPServiceProviderManager;
import com.espertech.esper.client.EPStatement;
import com.minapro.procserver.cep.che.CHEContainerHandlingSubscriber;
import com.minapro.procserver.cep.che.CHEJobDoneSubscriber;
import com.minapro.procserver.cep.che.CHERowChangeSubscriber;
import com.minapro.procserver.cep.itv.ITVDelayRecordingSubscriber;
import com.minapro.procserver.cep.qc.QCContainerHandlingSubscriber;
import com.minapro.procserver.cep.qc.QCDelayRecordingSubscriber;
import com.minapro.procserver.cep.qc.QCGantryPositionSubscriber;
import com.minapro.procserver.cep.qc.QCGantrySpreader1UnlockSubscriber;
import com.minapro.procserver.cep.qc.QCGantrySpreader2UnlockSubscriber;
import com.minapro.procserver.cep.qc.QCHoist1PositionSubscriber;
import com.minapro.procserver.cep.qc.QCHoist1UnlockSubscriber;
import com.minapro.procserver.cep.qc.QCHoist2PositionSubscriber;
import com.minapro.procserver.cep.qc.QCHoist2UnlockSubscriber;
import com.minapro.procserver.cep.qc.QCSpreader1SizeSubscriber;
import com.minapro.procserver.cep.qc.QCSpreader1Subscriber;
import com.minapro.procserver.cep.qc.QCSpreader2SizeSubscriber;
import com.minapro.procserver.cep.qc.QCSpreader2Subscriber;
import com.minapro.procserver.cep.qc.QCTrolley1PositionSubscriber;
import com.minapro.procserver.cep.qc.QCTrolley1UnlockSubscriber;
import com.minapro.procserver.cep.qc.QCTrolley2PositionSubscriber;
import com.minapro.procserver.cep.qc.QCTrolley2UnlockSubscriber;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.common.CancelInspectionEvent;
import com.minapro.procserver.events.common.CheckListInspectionEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.PinningStationJobConfirmationEvent;
import com.minapro.procserver.events.plc.EsperPLCEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.exception.CEPEngineExceptionHandler;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * <p>Class responsible for the Complex Event Processing. </p>
 * 
 * <p>ESPER related configurations are done at start up time </p>
 * 
 * @author Rosemary George
 *
 */
public class EsperEngine implements Serializable {

    private static final long serialVersionUID = -5836242732657829778L;

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(EsperEngine.class);

    private Configuration epConfig;
    private EPServiceProvider epService;
    private EPRuntime epRuntime;

    public EsperEngine() {
        epConfig = new Configuration();
        epConfig.getEngineDefaults().getExceptionHandling().addClass(CEPEngineExceptionHandler.class);
        initalize();
    }

    /**
     * Feeds the events to the ESPER runtime for pattern detection
     * 
     * @param event
     */
    public void insertEvent(Object event) {
        epRuntime.sendEvent(event);
    }

    /**
     * Creates the EPL statements for pattern detection and registers the subscriber for it
     * 
     * @param subscriber
     */

    private void createEPL(StatementSubscriber subscriber, EPStatement contextStatement) {
        EPAdministrator epAdmin = epService.getEPAdministrator();
        EPStatement epStatement;
        if (subscriber != null) {
            epStatement = epAdmin.createEPL(subscriber.getStatement());

            if (contextStatement != null) {
                contextStatement.setSubscriber(subscriber);
            }

            epStatement.setSubscriber(subscriber);
        }
    }

    /**
     * Initializes the ESPER CEP Runtime with the events and event subscribers
     */
    private void initalize() {
        try {
            epConfig.addEventType(EsperPLCEvent.class);
            epConfig.addEventType(EsperRMGPLCEvent.class);
            epConfig.addEventType(ContainerMoveEvent.class);
            epConfig.addEventType(DriveInstructionEvent.class);
            epConfig.addEventType(ITVArrivalEvent.class);
            epConfig.addEventType(PinningStationJobConfirmationEvent.class);
            epConfig.addEventType(CancelInspectionEvent.class);
            epConfig.addEventType(CheckListInspectionEvent.class);

            addVariableValues();

            epService = EPServiceProviderManager.getDefaultProvider(epConfig);
            epRuntime = epService.getEPRuntime();

            configureQCPatterns();
            //Commenting out ITV delay detection until Sanjay confirms the behaviour
            //configureITVPatterns();
            configureCHEPatterns();

        } catch (Exception ex) {
            logger.logException("Caught exception while initializing esper engine : ", ex);
        }
    }

    /**
     * Registers the variables needed for the Expressions.
     * 
     */
    private void addVariableValues() {

        // ITV specific
        Integer itvDelayTime = 0;
        try {
            itvDelayTime = Integer.parseInt(DeviceCommParameters.getInstance().getCommParameter(
                    ITV_DELAY_RECORDING_INTERVAL));
            epConfig.addVariable("itv_delay_time", Integer.class, itvDelayTime);
        } catch (Exception ex) {
            logger.logException("Caught exception while configuring variables for ITV- ", ex);
        }

        // QC specific
        try {
            Double weightThreshold = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    WS_WEIGHT_THRESHOLD));
            Double lsWeightThreshold = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    LS_WEIGHT_THRESHOLD));
            Double lockedUpTagValue = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    LOCKED_UP_VALUE));
            Double unLockedUpTagValue = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    UNLOCKED_UP_VALUE));
            Double delayTime = Double.parseDouble(DeviceCommParameters.getInstance().getCommParameter(
                    QC_DELAY_RECORDING));

            epConfig.addVariable("weight_threshold", Double.class, weightThreshold);
            epConfig.addVariable("ls_weight_threshold", Double.class, lsWeightThreshold);
            epConfig.addVariable("lockedUpTagValue", Double.class, lockedUpTagValue);
            epConfig.addVariable("unLockedUpTagValue", Double.class, unLockedUpTagValue);
            epConfig.addVariable("delayTime", Double.class, delayTime);
        } catch (Exception ex) {
            logger.logException("Caught exception while configuring Variable for QC -", ex);
        }
    }

    /**
     * Configures the patterns needed for detecting ITV related events such as delay recording
     */
    @SuppressWarnings("unused")
    private void configureITVPatterns() {
        EPStatement itvDelayContextStatement = epService.getEPAdministrator().createEPL(
                "create context SegmentByITVOperator " + "partition by " + "userID from DriveInstructionEvent, "
                        + "userID from ITVArrivalEvent, " + "userID from PinningStationJobConfirmationEvent");

        createEPL(new ITVDelayRecordingSubscriber(), itvDelayContextStatement);
    }

    /**
     * Configures all the patterns needed for detecting QC related events. Creates the context statements, variables,
     * queries and the subscribers.
     */
    private void configureQCPatterns() {
        EPAdministrator epAdmin = epService.getEPAdministrator();

        EPStatement qcContextStatement = epAdmin
                .createEPL("create context EachQC partition by node from EsperPLCEvent");
        
        EPStatement qcUserContextStatement = epAdmin
                .createEPL("create context EachQCUser partition by "
                		+ "userID from ContainerMoveEvent, "
                		+ "userID from CancelInspectionEvent, "
                		+ "userID from CheckListInspectionEvent");

        createEPL(new QCContainerHandlingSubscriber(), qcContextStatement);
        createEPL(new QCDelayRecordingSubscriber(), qcUserContextStatement);
        createEPL(new QCTrolley1PositionSubscriber(), qcContextStatement);
        createEPL(new QCTrolley2PositionSubscriber(), qcContextStatement);
        createEPL(new QCHoist1PositionSubscriber(), qcContextStatement);
        createEPL(new QCHoist2PositionSubscriber(), qcContextStatement);
        createEPL(new QCTrolley1UnlockSubscriber(), qcContextStatement);
        createEPL(new QCTrolley2UnlockSubscriber(), qcContextStatement);
        createEPL(new QCHoist1UnlockSubscriber(), qcContextStatement);
        createEPL(new QCHoist2UnlockSubscriber(), qcContextStatement);
        createEPL(new QCGantryPositionSubscriber(), qcContextStatement);
        createEPL(new QCGantrySpreader1UnlockSubscriber(), qcContextStatement);
        createEPL(new QCGantrySpreader2UnlockSubscriber(), qcContextStatement);
        createEPL(new QCSpreader1Subscriber(), qcContextStatement);
        createEPL(new QCSpreader2Subscriber(), qcContextStatement);
        createEPL(new QCSpreader1SizeSubscriber(), qcContextStatement);
        createEPL(new QCSpreader2SizeSubscriber(), qcContextStatement);
        createEPL(new QCSpreader2SizeSubscriber(), qcContextStatement);

    }

    private void configureCHEPatterns() {
        EPAdministrator epAdmin = epService.getEPAdministrator();

        EPStatement cheContextStatement = epAdmin
                .createEPL("create context EachCHE partition by node from EsperRMGPLCEvent");
        createEPL(new CHERowChangeSubscriber(), cheContextStatement);
        createEPL(new CHEContainerHandlingSubscriber(), cheContextStatement);
        createEPL(new CHEJobDoneSubscriber(), cheContextStatement);

    }
}
