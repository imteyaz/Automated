package com.minapro.procserver.db.yardview;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * BlkrowYpm entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "MP_BLKROW_YPM")
public class BlkrowYpm implements java.io.Serializable {

    private static final long serialVersionUID = -8888069703598681755L;

    @EmbeddedId
    @AttributeOverrides({ @AttributeOverride(name = "intBlkNo", column = @Column(name = "INT_BLK_NO")),
            @AttributeOverride(name = "rowSeqNo", column = @Column(name = "ROW_SEQ_NO")) })
    private BlkrowYpmId id;

    @Column(name = "BLK_ROW_NO")
    private String blkRowNo;

    @Column(name = "CONTIGUITY_ROW_NO")
    private Short contiguityRowNo;

    @Column(name = "DEAD_END_ROW_FLG")
    private String deadEndRowFlg;

    @Column(name = "RFR_ALLOWD_FLG")
    private String rfrAllowdFlg;

    @Column(name = "WRKG_STKG_HT")
    private Short wrkgStkgHt;

    @Column(name = "WRKG_STKG_HT_UOM")
    private String wrkgStkgHtUom;

    @Column(name = "DEL_FLG")
    private String delFlg;

    @Column(name = "DOOR_DIRN_IND")
    private String doorDirnInd;

    @Column(name = "ROW_LEN")
    private Double rowLen;

    @Column(name = "ROW_LEN_UOM")
    private String rowLenUom;

    public BlkrowYpmId getId() {
        return this.id;
    }

    public void setId(BlkrowYpmId id) {
        this.id = id;
    }

    public String getBlkRowNo() {
        return this.blkRowNo;
    }

    public void setBlkRowNo(String blkRowNo) {
        this.blkRowNo = blkRowNo;
    }

    public Short getContiguityRowNo() {
        return this.contiguityRowNo;
    }

    public void setContiguityRowNo(Short contiguityRowNo) {
        this.contiguityRowNo = contiguityRowNo;
    }

    public String getDeadEndRowFlg() {
        return this.deadEndRowFlg;
    }

    public void setDeadEndRowFlg(String deadEndRowFlg) {
        this.deadEndRowFlg = deadEndRowFlg;
    }

    public String getRfrAllowdFlg() {
        return this.rfrAllowdFlg;
    }

    public void setRfrAllowdFlg(String rfrAllowdFlg) {
        this.rfrAllowdFlg = rfrAllowdFlg;
    }

    public Short getWrkgStkgHt() {
        return this.wrkgStkgHt;
    }

    public void setWrkgStkgHt(Short wrkgStkgHt) {
        this.wrkgStkgHt = wrkgStkgHt;
    }

    public String getWrkgStkgHtUom() {
        return this.wrkgStkgHtUom;
    }

    public void setWrkgStkgHtUom(String wrkgStkgHtUom) {
        this.wrkgStkgHtUom = wrkgStkgHtUom;
    }

    public String getDelFlg() {
        return this.delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public String getDoorDirnInd() {
        return this.doorDirnInd;
    }

    public void setDoorDirnInd(String doorDirnInd) {
        this.doorDirnInd = doorDirnInd;
    }

    public Double getRowLen() {
        return this.rowLen;
    }

    public void setRowLen(Double rowLen) {
        this.rowLen = rowLen;
    }

    public String getRowLenUom() {
        return this.rowLenUom;
    }

    public void setRowLenUom(String rowLenUom) {
        this.rowLenUom = rowLenUom;
    }
}