package com.minapro.procserver.actors.obf;

import static com.minapro.procserver.util.RDTProcessingServerConstants.BAY_ROW_CHANGE_NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.QC_PERFORMANCE_NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.obf.BayRowChangeNotifEvent;
import com.minapro.procserver.events.plc.PerformanceEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * 
 * 
 * @author Prasad.Tallapally
 *
 */
public class VesselForemanNotifActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(VesselForemanNotifActor.class);

    @Override
    public void onReceive(Object object) throws Exception {
        Event event = (Event) object;
        String userId = event.getUserID();
        String terminalId = event.getTerminalID();
        StringBuilder message = new StringBuilder();

        if (event instanceof BayRowChangeNotifEvent) {
            prepareBayRowChangeOrQcPerformanceNotifMsg(BAY_ROW_CHANGE_NOTIF, message, event);
        } else if (event instanceof PerformanceEvent) {
            prepareBayRowChangeOrQcPerformanceNotifMsg(QC_PERFORMANCE_NOTIF, message, event);
        } else {
            unhandled(message);
        }
        postBayRowChangeAndQueuePerformNotifMsgToCommServerQueue(message, userId, terminalId);

    }

    /**
     * 
     * Preparing Bay Row Change Notification Msg
     * 
     * @param bayRowChangeMsg
     */
    private void prepareBayRowChangeOrQcPerformanceNotifMsg(String eventType, StringBuilder message, Event event) {
        logger.logMsg(LOG_LEVEL.INFO, event.getUserID(), "");
        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);
            
            // get the message format
            
            List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);
            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append(valueSeperator).append(eventTypeID);
            
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                EventUtil.getInstance().getEventParameter(event, msgFields.get(i), responseToDevice);
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while sending notification for " + eventType, ex);
        }

    }

    /**
     * Posting Bay Row Change Message And Queue Performance Message To Communication Server Queue
     * 
     * @param bayRowChangeMsg
     * @param userId
     * @param terminalId
     */
    private void postBayRowChangeAndQueuePerformNotifMsgToCommServerQueue(StringBuilder message, String userId,
            String terminalId) {
        User user = RDTCacheManager.getInstance().getUserDetails(userId);
        if (user != null) {
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
            CommunicationServerQueueManager.getInstance().postMessage(message.toString(), operatorRole, terminalId);
        }

    }
}
