package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;

import java.util.List;
import java.util.Map;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.events.che.BlockWiseContainersResponseEvent;
import com.minapro.procserver.events.che.YardProfileContainer;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is used to prepare the block structure and sending final message to the logged in requested user. Block is a
 * combination of Rows and Stacks and Tiers. Rows are alphabets it can be start with any character.usually one block
 * consists maximum of 20 rows and minimum of 2. and end with any character.In database for every row number is mapped
 * with seqNo. 
 * Stacks are numbers Usually one block consists maximum of 50 stacks.,minimum of 10 stacks. 
 * Just like Rows,Stacks also doesn't maintain any numbering  order, It can start at any number and ends with any number. 
 * First time request getting data from Database and putting into
 * different caches defined in BlockProfileCache. Next request onwards pulling data BlockProfileCache. First preparing
 * CellData structure with NoOf rows and tiers,after that filling CellData with retrieved containers from ESB.
 * 
 * @author UMAMAHESH M.
 *
 */
public class BlockViewResponseActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockViewResponseActor.class);

   @Override
   public void onReceive(Object message) throws Exception {
	   // logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(ON_RECEIVE).toString());
	   
	   if (message instanceof BlockWiseContainersResponseEvent) {

		   BlockWiseContainersResponseEvent blkWiseCntrsResEvnt = (BlockWiseContainersResponseEvent)message;
		   prepareYardBlockView(blkWiseCntrsResEvnt);

		   
	   } else {
		   unhandled(message);
	   }
   }

    /**
     * Method is responsible to calling yardView message preparation methods. 
     * prepareBlockCellDataSkeleton() for basic cell structure creation ,prepareRowData() for Row Data,
     * prepareStackData() for stacks preparation. 
     * @param BlockWiseContainersResponseEvent
     *            from request.
     */
    private void prepareYardBlockView(BlockWiseContainersResponseEvent blockWiseCntrsResp) {
    	
    	final String blockNumber = blockWiseCntrsResp.getBlockID();
    	
    	logger.logMsg(LOG_LEVEL.INFO,blockNumber,new StringBuilder(" BlockWise Containers Details Response Event Received ").
    			append(" From ").append(blockWiseCntrsResp.isPollingTimeReq() ? " Opus " : " Promise ").toString());
    	
    	List<YardProfileContainer> containersFromESB = blockWiseCntrsResp.getContainers();
      
       
        try {
        	
        	int receivedContainersFromESBSize = containersFromESB!=null ? containersFromESB.size() : 0;
        	
        	logger.logMsg(LOG_LEVEL.INFO,blockNumber," Containers Received From ESB With Size : "+receivedContainersFromESBSize);
        	
        	if(receivedContainersFromESBSize>0){
                prepareBlockCellDataWithContainers(blockNumber, containersFromESB);
             } 
         } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" prepareYardBlockView() ").append(REASON)
                    .toString(), ex);
           
        }
    }
    /**
	 * Method is used to prepare the BlockCellGrid object with the current container.
	 * @param blockNumber
	 * @param containers
	 * @param stackDataMap
	 */
    private void prepareBlockCellDataWithContainers(String blockNumber,List<YardProfileContainer> containers) {
    	

        try {
            
        	for (YardProfileContainer yardContainer : containers) {
            	
        		String yardPosition =yardContainer.getYardPosition();
            	
            	blockNumber = (yardPosition!=null && !yardPosition.isEmpty() && yardPosition.length()>3) ? yardPosition.substring(0,3):null;
        	
           
            	if(blockNumber==null){            			
            			
            		logger.logMsg(LOG_LEVEL.ERROR,""," Un able to get Block Number Continuing the loop ...");
            			continue;            	
            
            	} else {
            		
            			RDTYardProfileCacheManager blockCache = RDTYardProfileCacheManager.getInstance();
            			
            			
            			BlockProfile blockProfile = blockCache.getBlockToYardProfile(blockNumber);            			
            			
            			if(blockProfile==null){
            				
            				logger.logMsg(LOG_LEVEL.ERROR,blockNumber," Block Structure Is Not Defined..Continuing For Loop...");
            				continue;
            			}
            			
            			BlockProfile.prepareStackData(blockNumber,false);
            			
            			Map<String, String> rowDataMap = blockCache.getBlockRelatedRowData(blockNumber);
            			Map<String, String> stackDataMap = blockCache.getBlockRelatedStockData(blockNumber);
            			
            			
            			BlockProfileUtil.getInstance().prepareBlockCellWithContainer(blockNumber, yardContainer, rowDataMap, stackDataMap, blockProfile,null);
            		}            		
            	}
        } catch (Exception ex) {
        	 logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" prepareBlockCellDataWithContainers() ")
                    .append(REASON).toString(), ex);
        }
    }

   

   
   
	
	
}
