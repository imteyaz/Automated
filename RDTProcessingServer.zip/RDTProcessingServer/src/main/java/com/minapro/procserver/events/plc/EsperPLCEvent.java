package com.minapro.procserver.events.plc;

import java.sql.Timestamp;

/**
 * ValueObject holding the data received from PLC after parsing.
 * 
 * @author Rosemary George
 *
 */
public class EsperPLCEvent {

    private String node;
    private String tagName;
    private double tagValue;
    private Timestamp tagTime;
    private int noOfContainers;

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public double getTagValue() {
        return tagValue;
    }

    public void setTagValue(double tagValue) {
        this.tagValue = tagValue;
    }

    public Timestamp getTagTime() {
        return tagTime;
    }

    public void setTagTime(Timestamp tagTime) {
        this.tagTime = tagTime;
    }

    public int getNoOfContainers() {
        return noOfContainers;
    }

    public void setNoOfContainers(int noOfContainers) {
        this.noOfContainers = noOfContainers;
    }

    @Override
    public String toString() {
        return "EsperPLCEvent [node=" + node + ", tagName=" + tagName + ", tagValue=" + tagValue + ", tagTime="
                + tagTime + ", noOfContainers=" + noOfContainers + "]";
    }
}
