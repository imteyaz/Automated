package com.minapro.procserver.db;

// default package

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * TroubleshootareaMaster entity.
 * 
 * @author Umamahesh M
 */
@Entity
@Table(name = "MP_TROUBLESHOOTAREA_MASTER")
public class TroubleshootAreaMaster implements java.io.Serializable {

    private static final long serialVersionUID = 7614494047807836763L;
    
    @Id
    @Column(name = "TROUBLESHOOT_AREA_ID")
    private String troubleshootAreaId;
    
    @Column(name = "TERMINAL_ID")
    private String termianlId;

    @Column(name = "DESCRIPTION", length = 250)
    private String description;
    
    @Column(name = "AVAILABILITY", nullable = false, length = 1)
    private String availability;

    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDatetime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "VERSION", nullable = false)
    private Integer version;

    @Column(name = "ISDELETED")
    private String isDeleted;
      
    public String getTroubleshootAreaId() {
        return troubleshootAreaId;
    }

    public void setTroubleshootAreaId(String troubleshootAreaId) {
        this.troubleshootAreaId = troubleshootAreaId;
    }
    
    public String getTermianlId() {
        return termianlId;
    }

    public void setTermianlId(String termianlId) {
        this.termianlId = termianlId;
    }
   
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    
    public String getAvailability() {
        return this.availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDatetime() {
        return lastUpdatedDatetime;
    }

    public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
        this.lastUpdatedDatetime = lastUpdatedDatetime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}