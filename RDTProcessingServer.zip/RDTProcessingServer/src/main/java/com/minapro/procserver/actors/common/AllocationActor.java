package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ACTIVITY_CODES;
import static com.minapro.procserver.util.RDTProcessingServerConstants.EQP_USER_ALLOCATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.INSPECTION_CHECKLIST;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LANGUAGE_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MAN_USER_ALLOCATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NON_OPERATIONAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NON_OP_CODES;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OPERATIONAL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROTATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TOS_STATUS_NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.TRAILER_NO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.KEEP_ALIVE_ERROR_MSG;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.Activity;
import com.minapro.procserver.db.Equipment;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.bayprofile.Vessel;
import com.minapro.procserver.events.common.AlertEvent;
import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for handling the allocation details about a user.</p>
 * 
 * <p> It handles the <code>AllocationEvent</code> from ESB and construct the message to the device. Also it processes
 * the allocation confirmation from the device and forwards to ESB.</p>
 * 
 * @author Rosemary George
 * 
 */
public class AllocationActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(AllocationActor.class);

    private static final String VALUE_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ROW_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ROW_SEPERATOR_KEY);
    private static final String ITEM_SEPARATOR = DeviceCommParameters.getInstance().getCommParameter(
            RDTProcessingServerConstants.ITEM_SEPERATOR_KEY);

    @Override
    /**
     * Handles messages of type AllocationEvent and ConfirmAllocationEvent
     */
    public void onReceive(Object message) throws Exception {
        try {
            if (message instanceof AllocationEvent) {
                AllocationEvent allocationDetails = (AllocationEvent) message;
                logger.logMsg(LOG_LEVEL.INFO, allocationDetails.getUserID(), "Received allocation details from ESB - "
                        + allocationDetails);
                sendAllocationDetails(allocationDetails);
            } else if (message instanceof ConfirmAllocationEvent) {
                ConfirmAllocationEvent confirmAllocation = (ConfirmAllocationEvent) message;
                logger.logMsg(LOG_LEVEL.INFO, confirmAllocation.getUserID(),
                        "Received confirm allocation details from user - " + confirmAllocation);
                confirmAllocation(confirmAllocation);
            } else {
                unhandled(message);
            }
        } catch (Exception e) {
            logger.logException("Caught exception while processing - ", e);
        }
    }

    /**
     * <p>In case of Equipment operators, the confirmed allocation details are passed down to ESB if the activity type
     * is operational and he inspection check list is generated and send to the user </p>
     * 
     * Performs the QC/CHE specific actions during the confirm allocation - Flush the previous job list cache, in case
     * any change detected - Updates the totalHoursWorked by the user and the equipment to the cache
     * 
     * Performs the ITV specific actions needed during confirm allocation event - Updates the ITV equipment with the
     * trailer ID entered by the user - based on the selected activity, posts the message to ESB
     * 
     * Performs the HC specific actions needed during the confirm allocation event - links the HC and the selected QC in
     * both the ways.
     * 
     * @param allocationDetails
     */
    private void confirmAllocation(ConfirmAllocationEvent allocationDetails) {
        User user = RDTCacheManager.getInstance().getUserDetails(allocationDetails.getUserID());
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(allocationDetails.getUserID());
        RDTCacheManager.getInstance().addAllocationDetails(allocationDetails);

        assignUserToSelectedLocation(allocationDetails.getUserID(), allocationDetails.getLocation(), operatorRole);

        if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.CHE)) {
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Performing QC-CHE specific confirm allocation actions");
            RDTCacheManager.getInstance().flushJobListForEquipment(allocationDetails.getRotationID(),
                    allocationDetails.getEquipmentID());
            performEquipmentOperatorConfirmAllocation(allocationDetails, operatorRole, user);

            // keep the total hours worked previously for the same equipment and rotation combination
            Double totalHoursWorked = HibernateUtil.getPrviousHoursWorkedByUser(user,
                    allocationDetails.getRotationID(), allocationDetails.getEquipmentID());
            RDTPLCCacheManager.getInstance().addPreviousHoursWorked(user.getUserID(), totalHoursWorked);
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "TotalTimeWorkedInHours previously by user :"
                    + totalHoursWorked);

            Double totalHoursWorkedByEquipment = HibernateUtil.getPrviousHoursWorkedByEquipment(
                    allocationDetails.getRotationID(), allocationDetails.getEquipmentID());
            RDTPLCCacheManager.getInstance().addPreviousHoursWorked(allocationDetails.getEquipmentID(),
                    totalHoursWorkedByEquipment);
            logger.logMsg(LOG_LEVEL.INFO, allocationDetails.getEquipmentID(),
                    "TotalTimeWorkedInHours previously by equipment :" + totalHoursWorkedByEquipment);
        } else if (operatorRole.equals(OPERATOR.ITV)) {
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Performing ITV specific confirm allocation actions");

            Activity activityCode = RDTCacheManager.getInstance().getActivity(allocationDetails.getActivityCode());
            if (activityCode != null && OPERATIONAL.equalsIgnoreCase(activityCode.getActivityType().getCategoryId())) {
                allocationDetails.setPassword(user.getPassword());

                if(allocationDetails.getTrailerID() != null && !allocationDetails.getTrailerID().isEmpty()){
                    RDTCacheManager.getInstance().addITVTrailer(allocationDetails.getEquipmentID(),
                        allocationDetails.getTrailerID());
                }

                logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Trailer ID is :" + allocationDetails.getTrailerID());

                ESBQueueManager.getInstance().postMessage(allocationDetails, operatorRole,
                        allocationDetails.getTerminalID());

            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(),
                        "ITV User selected non operational Activity. No action is taken");
            }
        } else if (operatorRole.equals(OPERATOR.HC)) {
            performHCConfirmAllocation(allocationDetails, user);
        } else if (operatorRole.equals(OPERATOR.TSC)) {
            logger.logMsg(LOG_LEVEL.INFO, allocationDetails.getUserID(),
                    "TSC clerk confirm allocation - sending checklist");
            EventUtil.getInstance().sendInspectionCheckList(user, allocationDetails, INSPECTION_CHECKLIST);
        }

        int rotationId = 0;
        if (allocationDetails.getRotationID() != null && !allocationDetails.getRotationID().isEmpty()) {
            rotationId = Integer.parseInt(allocationDetails.getRotationID());
        }
        HibernateUtil.updateUserActivity(user, allocationDetails.getActivityCode(), allocationDetails.getRemarks(),
                null, rotationId, 0);
    }

    /**
     * Performs the HC confirm allocation related actions. If the QC selected by the HC is already mapped to another HC,
     * throws an error.
     * 
     * @param allocationDetails
     * @param user
     */
    private void performHCConfirmAllocation(ConfirmAllocationEvent allocationDetails, User user) {
        logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "Performing HC specific confirm allocation actions");

        // Checking if already an HC is associated with the selected QC.
        String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(allocationDetails.getLocation());
        if (hcUser != null) {
            sendHCAlreadyAssociatedMessage(allocationDetails);
        } else {
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), "No HC user is associated with the selected QC:"
                    + allocationDetails.getLocation());
            // the QC equipment selected by HC user will be present in the location field.
            RDTCacheManager.getInstance().assignHcToQcEquipment(allocationDetails.getUserID(),
                    allocationDetails.getLocation());

            EventUtil.getInstance().sendInspectionCheckList(user, allocationDetails, INSPECTION_CHECKLIST);
            
            /*
             * OPUS - No need for HC to login. only QC, ITV, CHE login to OPUS
             * 
            allocationDetails.setPassword(user.getPassword());
            allocationDetails.setLocation(getLocation(allocationDetails.getLocation()));
            ESBQueueManager.getInstance()
                    .postMessage(allocationDetails, OPERATOR.HC, allocationDetails.getTerminalID());
                    */

            if (allocationDetails.getEquipmentID() != null) {
                RDTCacheManager.getInstance().addUserToLocation(allocationDetails.getUserID(),
                        allocationDetails.getEquipmentID());
            }
        }
    }

    /**
     * Sends failure response to User as already another HC is associated with the QC.
     * 
     * @param allocationDetails
     */
    private void sendHCAlreadyAssociatedMessage(ConfirmAllocationEvent allocationDetails) {
        AlertEvent alert = new AlertEvent();
        alert.setEventID(allocationDetails.getEventID());
        alert.setUserID(allocationDetails.getUserID());
        alert.setEquipmentID(allocationDetails.getEquipmentID());
        alert.setTerminalID(allocationDetails.getTerminalID());
        alert.setTimeStamp(new Date().toString());
        alert.setReason("Hatch Clerk has been already assigned to the selected QC, Please choose another one");

        alert.setBeepRequired(false);
        EventUtil.getInstance().sendAlertMessageToUser(alert);
    }

    /**
     * Assigns the user to the location he has selected in the Allocation screen. In case of CHE, the user will be
     * selecting a range of yard, the whole range is broken down to specific blocks and the user is assigned to all the
     * blocks in between the range.
     * 
     * @param userId
     * @param location
     * @param role
     */
    private void assignUserToSelectedLocation(String userId, String location, OPERATOR role) {
        String[] locations = null;
        if (location != null && !location.isEmpty()) {

            logger.logMsg(LOG_LEVEL.INFO, userId, "Extracting Location of CHE:");
            if (role.equals(OPERATOR.CHE)) {

                locations = location.split("\\" + ITEM_SEPARATOR);
                String fromLocation = locations[0];

                logger.logMsg(LOG_LEVEL.INFO, userId, "CHE Location:" + fromLocation);
                RDTCacheManager.getInstance().addUserToLocation(userId, fromLocation);

            } else {

                locations = location.split("\\" + ROW_SEPARATOR);
                for (String eachLocation : locations) {
                    RDTCacheManager.getInstance().addUserToLocation(userId, eachLocation);
                }
            }
        }
    }

    /**
     * Get the location details for the QC with the specified equipmentId.
     * 
     * @param qcEquipmentId
     * @return
     */
    private String getLocation(String qcEquipmentId) {
        String location = "";

        // Get the location from the QC
        Equipment qcEquipment = RDTCacheManager.getInstance().getEquipmentDetails(qcEquipmentId);
        if (qcEquipment != null) {
            return qcEquipment.getPow();
        }

        return location;
    }

    /**
     * <p>the confirmed allocation details are passed down to ESB if the activity type is operational and the inspection
     * check list is generated and send to the user </p>
     * 
     * @param allocationDetails
     * @param role
     * @param user
     */
    private void performEquipmentOperatorConfirmAllocation(ConfirmAllocationEvent allocationDetails, OPERATOR role,
            User user) {
        Activity activityCode = RDTCacheManager.getInstance().getActivity(allocationDetails.getActivityCode());
        if (activityCode != null && OPERATIONAL.equalsIgnoreCase(activityCode.getActivityType().getCategoryId())) {
            allocationDetails.setPassword(user.getPassword());

            if (role.equals(OPERATOR.QC)) {
                RDTCacheManager.getInstance().addUserToLocation(allocationDetails.getUserID(),
                        allocationDetails.getEquipmentID());
                allocationDetails.setLocation(getLocation(allocationDetails.getEquipmentID()));

                RDTPLCCacheManager.getInstance().addUserToRotationIdMapping(allocationDetails.getUserID(),
                        allocationDetails.getRotationID());
            }

            ESBQueueManager.getInstance().postMessage(allocationDetails, role, allocationDetails.getTerminalID());
        } else {
            logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(),
                    "User selected non operational Activity. No action is taken");
        }
    }

    /**
     * Construct the allocation details to the device and post it to the communication layer queue
     * 
     * @param allocationDetails
     */
    private void sendAllocationDetails(AllocationEvent allocationDetails) {
        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(allocationDetails.getUserID());

        // build the response to the device
        StringBuilder responseToDevice;

        if (operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.CHE) || operatorRole.equals(OPERATOR.ITV)) {
        	responseToDevice = new StringBuilder(RESP).append( VALUE_SEPARATOR).
        			append(DeviceEventTypes.getInstance().getEventType(EQP_USER_ALLOCATION));
        	fillEquipmentOperatorAllocationDetails(allocationDetails, responseToDevice, operatorRole, ROW_SEPARATOR,
                    VALUE_SEPARATOR);
        } else {
            responseToDevice = new StringBuilder(RESP).append(VALUE_SEPARATOR)
                    .append(DeviceEventTypes.getInstance().getEventType(MAN_USER_ALLOCATION)).append(VALUE_SEPARATOR);
            responseToDevice.append(allocationDetails.getEventID()).append(VALUE_SEPARATOR);

            fillManOperatorAllocationDetails(allocationDetails, responseToDevice, operatorRole);
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                allocationDetails.getTerminalID());
        
        //verify TOS heart beat status. If down, send notification to UI
        verifyKeepAliveStatus(allocationDetails.getUserID(), operatorRole, allocationDetails.getTerminalID());
    }

    /**
     * Verifies whether the TOS heart beat status is up. If not, sends the notification
     * to the user
     * @param userID
     */
    private void verifyKeepAliveStatus(String userID, OPERATOR role, String terminalId) {
		if(!RDTCacheManager.getInstance().getKeepAliveStatus()){
			logger.logMsg(LOG_LEVEL.INFO, userID, "TOS keep alive status is DOWN. Sending notification to user");
			
			try {
				String eventTypeID = DeviceEventTypes.getInstance().getEventType(TOS_STATUS_NOTIF);
				
				StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPARATOR).append(eventTypeID);
				
				responseToDevice.append(VALUE_SEPARATOR).append(UUID.randomUUID().toString())
					.append(VALUE_SEPARATOR).append(false).append(VALUE_SEPARATOR)				
					.append(KEEP_ALIVE_ERROR_MSG).append(VALUE_SEPARATOR)
					.append(userID).append(VALUE_SEPARATOR).append(terminalId);
				
				CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role, terminalId);
			} catch (Exception e) {
				logger.logException("Caught exception while processing verifyKeepAliveStatus -", e);
			}		
		}		
	}

	/**
     * Constructs the allocation details needed for the non-equipment operators
     * 
     * @param allocationDetails
     * @param responseToDevice
     * @param operatorRole
     */
    private void fillManOperatorAllocationDetails(AllocationEvent allocationDetails, StringBuilder responseToDevice,
            OPERATOR operatorRole) {
        logger.logMsg(LOG_LEVEL.DEBUG, allocationDetails.getUserID(),
                "Adding allocation details for the non-equipment operators");

        if (operatorRole.equals(OPERATOR.HC) || operatorRole.equals(OPERATOR.FOREMAN)
                || operatorRole.equals(OPERATOR.VSUP)) {
            addRotationIdsToResponse(responseToDevice, null);
            responseToDevice.append(VALUE_SEPARATOR);
            addAvailableEquipmentDetails(responseToDevice, "QC");
        } else if (operatorRole.equals(OPERATOR.YSUP)) {
            // rotationID will be empty, keep empty
            responseToDevice.append(VALUE_SEPARATOR);
            addAvailableEquipmentDetails(responseToDevice, "CHE");
        } else if (operatorRole.equals(OPERATOR.TSC)) {
            responseToDevice.append(VALUE_SEPARATOR);
            responseToDevice.append(getAvailableTSAreas(allocationDetails.getTerminalID()));
        }

        User userObj = RDTCacheManager.getInstance().getUserDetails(allocationDetails.getUserID());
        responseToDevice.append(VALUE_SEPARATOR).append(userObj.getDeafultLanguage()).append(VALUE_SEPARATOR)
                .append(allocationDetails.getUserID()).append(VALUE_SEPARATOR)
                .append(allocationDetails.getTerminalID());
    }

    /**
     * Retrieves the troubleshoot areas defined for the selected terminalID.
     * 
     * @param terminalID
     * @return
     */
    private StringBuilder getAvailableTSAreas(String terminalID) {
        Set<TroubleshootAreaMaster> troubleshootAreas = RDTCacheManager.getInstance().getTroubleShootAreas(terminalID);

        StringBuilder tsAreas = new StringBuilder();
        for (TroubleshootAreaMaster tsArea : troubleshootAreas) {
            tsAreas.append(tsArea.getTroubleshootAreaId()).append(ROW_SEPARATOR);
        }

        return tsAreas;
    }

    /**
     * Gets IDs of all the equipments available in the system based on the specified equipment type and appends to the
     * response.
     * 
     * @param responseToDevice
     * @param equipmentType
     */
    private void addAvailableEquipmentDetails(StringBuilder responseToDevice, String equipmentType) {
        List<String> qcIds = RDTCacheManager.getInstance().getEquipmentDetailsOfType(equipmentType);
        for (String qc : qcIds) {
            responseToDevice.append(qc).append("#");
        }
        responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
    }

    /**
     * Retrieves the rotation ID of all the vessels which are currently berthed on the Terminal and appends to the
     * response.
     * 
     * @param responseToDevice
     *            - the response which is getting built to send to the device
     */
    private void addRotationIdsToResponse(StringBuilder responseToDevice, String equipmentId) {
        Set<Vessel> berthedVessels = RDTVesselProfileCacheManager.getInstance().getBerthedVesselList();
        logger.logMsg(LOG_LEVEL.INFO, "", "Berthed vessel available in Memory are : " + berthedVessels);
        if (berthedVessels != null && !berthedVessels.isEmpty()) {
            List<String> rotations = null;
            if (equipmentId != null) {
                rotations = RDTVesselProfileCacheManager.getInstance().getRotationDetailsForQC(equipmentId);
                logger.logMsg(LOG_LEVEL.INFO, equipmentId, "QC mapped rotations are - " + rotations);
            }

            for (Vessel vessel : berthedVessels) {

                if (equipmentId != null) {
                    if (rotations == null || rotations.isEmpty() || rotations.contains(vessel.getRotationId())) {
                        responseToDevice.append(vessel.getRotationId()).append(ITEM_SEPARATOR)
                                .append(vessel.getVesselName()).append(ROW_SEPARATOR);
                    }
                } else {
                    responseToDevice.append(vessel.getRotationId()).append(ITEM_SEPARATOR)
                            .append(vessel.getVesselName()).append(ITEM_SEPARATOR);

                    List<String> relatedQcs = RDTVesselProfileCacheManager.getInstance().getQCsAllocatedForRotation(
                            vessel.getRotationId());
                    if (relatedQcs != null) {
                        for (String qc : relatedQcs) {
                            responseToDevice.append(qc).append("#");
                        }
                    }
                    responseToDevice.append(ROW_SEPARATOR);
                }
            }

            responseToDevice.delete(responseToDevice.length() - 1, responseToDevice.length());
        }
    }

    /**
     * Constructs the allocation details message for the equipment operator
     * 
     * @param allocationDetails
     * @param responseToDevice
     * @param role
     */
    private void fillEquipmentOperatorAllocationDetails(AllocationEvent allocationDetails,
            StringBuilder responseToDevice, OPERATOR role, String rowSeperator, String valueSeperator) {
        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(EQP_USER_ALLOCATION);

        // segregate the activities into operational and Non-Operational
        StringBuilder activities = new StringBuilder(), nonOperationalActivitities = new StringBuilder();
        Set<String> activityCodes = RDTCacheManager.getInstance().getActivityCodes();
        for (String activity : activityCodes) {
            if (activity.equalsIgnoreCase(OPERATIONAL) || activity.equalsIgnoreCase(NON_OPERATIONAL)) {
                activities.append(activity).append(rowSeperator);
            } else {
                nonOperationalActivitities.append(activity).append(rowSeperator);
            }
        }

        allocationDetails.setLocation(getLocation(allocationDetails.getEquipmentID()));

        String msgField;
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(valueSeperator);
            msgField = msgFields.get(i);

            if (msgField.equalsIgnoreCase(ROTATION)) {
                if (role.equals(OPERATOR.QC)) {
                    addRotationIdsToResponse(responseToDevice, allocationDetails.getEquipmentID());
                }
            } else if (msgField.equalsIgnoreCase(ACTIVITY_CODES)) {
                responseToDevice.append(activities);
            } else if (msgField.equalsIgnoreCase(NON_OP_CODES)) {
                responseToDevice.append(nonOperationalActivitities);
            } else if (LANGUAGE_CODE.equalsIgnoreCase(msgField)) {
                User userObj = RDTCacheManager.getInstance().getUserDetails(allocationDetails.getUserID());
                responseToDevice.append(userObj.getDeafultLanguage());
            } else if (msgField.equalsIgnoreCase(TRAILER_NO)) {
                if (role.equals(OPERATOR.ITV)) {
                    responseToDevice.append(getAvailableTrailers());
                }
            } else {
                EventUtil.getInstance().getEventParameter(allocationDetails, msgFields.get(i), responseToDevice);
            }
        }
    }

    /**
     * Get the available trailer ID's subtract from cache
     * 
     * @return
     */
    private StringBuilder getAvailableTrailers() {
        List<String> trailerIdsList = HibernateUtil.itvTrailerIDsList();
        Collection<String> usedTrailerNos = RDTCacheManager.getInstance().getUsedTrailerNos();
        StringBuilder trailerID = new StringBuilder();
        if (usedTrailerNos != null) {
            Collection<String> availableTrailerList = CollectionUtils.subtract(trailerIdsList, usedTrailerNos);
            logger.logMsg(LOG_LEVEL.INFO, "", "identified the availabe jobs to be subtract from cache : "
                    + availableTrailerList);
            for (String trailerNo : availableTrailerList) {
                trailerID.append(trailerNo).append(ROW_SEPARATOR);
            }
        }
        return trailerID;
    }
}