package com.minapro.procserver.events.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.util.DeviceCommParameters;

/**
 * ValueObject holding the drive instruction details for an ITV
 * 
 * @author Rosemary George
 *
 */
public class DriveInstructionEvent extends Event implements Serializable {
    private static final long serialVersionUID = 4927804350930930743L;
    String rowSeperator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    /**
     * The location to where the ITV needs to go can be QC,pinning station or yard IDs. In Twin lift, can have at most
     * two locations in case of yard.
     */
    private String locationID;

    /**
     * The container IDs which the ITV is carrying Can have at most two container IDs, in case of twin lift
     */
    private String containerID = "";

    /**
     * general instructions like "wait for next job"..
     */
    private String generalInstruction;
    
    /**
     * container length
     */
    private String length;

    /**
     * In case the drive instruction is to go to QC, the lane ID will be specified here
     */
    private String laneID;

    /**
     * Indicates the type of the drive instruction
     */
    private DriveType driveType;

    /**
     * In case the driveType is QC, the driving direction will be specified here
     */
    private String driveDirection;
    
    
    /**
     * Move type DSCH/LOAD/HK
     */    
    private String moveType;
    
    /**
     * Job action carry/fetch
     */
    private String action;
    
    /**
     * Indicates the position of the container on ITV - AFT/FORWARD
     */
    private String position;
   
    private Set<String> failedToDeckContainers;
    
    /**
     * Indicates whether the itv arrived at the location
     */
    private boolean isArrived;
    
    private String jobKey;    
        
	public String getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public boolean isArrived() {
		return isArrived;
	}

	public void setArrived(boolean isArrived) {
		this.isArrived = isArrived;
	}

	public Set<String> getFailedToDeckContainers() {
		return failedToDeckContainers;
	}
	
	public void setFailedToDeckContainers(Set<String> failedToDeckContainers) {
		this.failedToDeckContainers = failedToDeckContainers;
	}


	public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getLaneID() {
        return laneID;
    }

    public void setLaneID(String laneID) {
        this.laneID = laneID;
    }

    public String getGeneralInstruction() {
        return generalInstruction;
    }

    public void setGeneralInstruction(String generalInstruction) {
        this.generalInstruction = generalInstruction;
    }

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    /**
     * Sometimes containerIds more than one
     * 
     * @param containers
     */
    public void setContainerIds(List<String> containers) {
        for (String container : containers) {
            containerID += container.concat(rowSeperator);
        }
    }

    public String getDriveType() {
        return driveType.toString();
    }

    public void setDriveType(DriveType driveType) {
        this.driveType = driveType;
    }

    public String getDriveDirection() {
        return driveDirection;
    }

    public void setDriveDirection(String driveDirection) {
        this.driveDirection = driveDirection;
    }    

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	@Override
	public String toString() {
		return "DriveInstructionEvent [locationID=" + locationID + ", containerID=" + containerID
				+ ", generalInstruction=" + generalInstruction + ", length=" + length + ", laneID=" + laneID
				+ ", moveType=" + moveType + ", action=" + action + ", position=" + position + ", isArrived="
				+ isArrived + ", jobKey=" + jobKey + ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getEventID()=" + getEventID() + "]";
	}
}
