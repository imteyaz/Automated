package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

/**
 * ValueObject holding the exchange container response status from ESB
 * @author Rosemary George
 *
 */
public class ExchangeContainerResponseEvent extends Event implements Serializable {
	
	private static final long serialVersionUID = 7181687252803889669L;
	
	private List<ExchangeStatus> exchangeStatus;

	public List<ExchangeStatus> getExchangeStatus() {
		return exchangeStatus;
	}

	public void setExchangeStatus(List<ExchangeStatus> exchangeStatus) {
		this.exchangeStatus = exchangeStatus;
	}

	@Override
	public String toString() {
		return "ExchangeContainerResponseEvent [exchangeStatus=" + exchangeStatus + ", UserID()="
				+ getUserID() + ", EquipmentID()=" + getEquipmentID() + ", EventID()=" + getEventID() + "]";
	}	
}
