package com.minapro.procserver.actors.itv;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITV_POOL;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.itv.ITV;
import com.minapro.procserver.events.itv.ITVPoolEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.ITVPoolUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the ITV pool request events from QC and HC devices and also handling the pool events
 * from ESB.
 * 
 * @author Rosemary George
 *
 */
public class ITVPoolActor extends UntypedActor {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVPoolActor.class);
	
	private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);
	private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
	private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ITEM_SEPERATOR_KEY);

	@Override
	public void onReceive(Object message) throws Exception {

		try {
			if (message instanceof ITVPoolRequestEvent) {
				
				ITVPoolRequestEvent poolRequest = (ITVPoolRequestEvent) message;
				
				logger.logMsg(LOG_LEVEL.INFO, poolRequest.getUserID(), "Received ITV pool request event for equipment "
						+ poolRequest.getEquipmentID());

				if (RDTCacheManager.getInstance().getUserLoggedInRole(poolRequest.getUserID()).equals(OPERATOR.CHE)) {
					ITVPoolUtil.getInstance().setITVPoolListToCache(poolRequest);
				}
				sendITVPoolToDevice(poolRequest, RESP);
			
			} else if (message instanceof ITVPoolEvent) {
				
				ITVPoolEvent poolEvent = (ITVPoolEvent) message;

				logger.logMsg(LOG_LEVEL.INFO, poolEvent.getUserID(),new StringBuilder("Received ITV pool event from ESB for equipment- ")
								.append(poolEvent.getEquipmentID()).append(" Event Details ::")
								.append(poolEvent).toString());

				handleITVPoolResponseFromESB(poolEvent);
			} else {
				unhandled(message);
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while processing the message - ", ex);
		}
	}

	/**
	 * Identifies the HC user associated with the equipment if it is QC and sends the updated pool information In case
	 * of CHE, sends directly to the CHE operator.
	 * 
	 * @param poolEvent
	 */
	private void sendITVPoolNotification(ITVPoolEvent poolEvent) {

		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(poolEvent.getUserID());

		// only send the itv pool notification to HC user.
		String hcUser = poolEvent.getUserID();
		if (operatorRole.equals(OPERATOR.QC)) {
			hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(poolEvent.getEquipmentID());
			logger.logMsg(LOG_LEVEL.INFO, poolEvent.getEquipmentID(), "Associated HC user is " + hcUser);
			if (hcUser != null) {
				boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
				if (inspectionStatus) {
					poolEvent.setUserID(hcUser);
				}
			}
		}
		sendITVPoolToDevice(poolEvent, NOTIF);
	}

	/**
	 * Construct the message with ITV list retrieved from the Cache and sends to the requested device.
	 * 
	 * @param poolEvent
	 */
	private void sendITVPoolToDevice(Event poolEvent, String messageType) {
		
		// get the message format
		List<String> msgFields = EventFormats.getInstance().getEventFields(ITV_POOL);		

		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(poolEvent.getUserID());

		// build the response to the device
		StringBuilder responseToDevice = new StringBuilder(messageType ).append(VALUE_SEPERATOR).append(DeviceEventTypes.getInstance().getEventType(ITV_POOL));
		
		String msgField;
		
		final int msgFieldsSize = msgFields.size();
		
		for (int i = 1; i < msgFieldsSize; i++) {
			
			responseToDevice.append(VALUE_SEPERATOR);
			msgField = msgFields.get(i);

			if ("ITVs".equalsIgnoreCase(msgField)) {
				
				
				String equipmentId = (OPERATOR.HC.equals(operatorRole)) ?  RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(poolEvent.getUserID()) : poolEvent.getEquipmentID();
				
				Set<ITV> itvList = RDTCacheManager.getInstance().getAssignedITVs(equipmentId);
				
				if (itvList != null && !itvList.isEmpty()) {
					
					for (ITV itv : itvList) {
						// itvId^20^2|itvId1^40^1|itvId2^20^1
						responseToDevice.append(itv.getItvId()).append(ITEM_SEPERATOR).append(itv.getLoadCapacity())
						.append(ITEM_SEPERATOR).append(itv.getNoOfContainer()).append(ROW_SEPERATOR);
					}
					
				}
				
			} else {
				EventUtil.getInstance().getEventParameter(poolEvent, msgFields.get(i), responseToDevice);
			}
		}

		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
				poolEvent.getTerminalID());
	}

	
	public void handleITVPoolResponseFromESB(ITVPoolEvent poolEvent) {

		Set<ITV> itvListInCache = RDTCacheManager.getInstance().getAssignedITVs(poolEvent.getEquipmentID());
		Set<ITV> itvListFromTOS = poolEvent.getItvList();

		Collection<ITV> deltaOfItvs1 = null;
		Collection<ITV> deltaOfItvs2 = null;
		
		logger.logMsg(LOG_LEVEL.INFO, poolEvent.getUserID(), " itvListInCache::"
				+ (itvListInCache != null ? itvListInCache.toString() : null) + " ITV List From TOS::"
				+ (itvListFromTOS != null ? itvListFromTOS.toString() : null));

		if (itvListInCache != null && !itvListInCache.isEmpty() && itvListFromTOS != null) {
			deltaOfItvs1 = CollectionUtils.subtract(itvListInCache, itvListFromTOS);
			deltaOfItvs2 = CollectionUtils.subtract(itvListFromTOS, itvListInCache);
			logger.logMsg(LOG_LEVEL.INFO, poolEvent.getUserID(), " ITV Delta::" + deltaOfItvs1 + deltaOfItvs2);
		}

		logger.logMsg(LOG_LEVEL.INFO, poolEvent.getUserID(), " Adding to AssignedITVs Cache");
		RDTCacheManager.getInstance().addAssignedITVs(poolEvent.getEquipmentID(), itvListFromTOS);

		if ((deltaOfItvs1 != null && !deltaOfItvs1.isEmpty()) || (deltaOfItvs2 != null && !deltaOfItvs2.isEmpty())) {
			logger.logMsg(LOG_LEVEL.INFO, poolEvent.getEquipmentID(), "Identified pool difference. Sending to UI");
			sendITVPoolNotification(poolEvent);
		}
	}

}
