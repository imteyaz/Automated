package com.minapro.procserver.events.plc;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject trigger that automatic delay if any exists can be closed
 * @author Rosemary George
 *
 */
public class EndDelayTriggerEvent extends Event implements Serializable{
    private static final long serialVersionUID = 3310377083350614827L;    
}
