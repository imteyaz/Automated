package com.minapro.procserver.actors.common;

import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.CHEJobListUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ITVWaitingTimePollingActor extends UntypedActor{
	 
	MinaProApplicationLogger logger = new MinaProApplicationLogger(ITVWaitingTimePollingActor.class);

	  @Override
		public void onReceive(Object message) throws Exception {
		logger.logMsg(LOG_LEVEL.INFO,""," ITV Waiting TIme Polling Actor OnReceive()..");
		  if(isAnyCHEUserLoggedIn()) {
			  
			  CHEJobListUtil.getInstance().sendITVWaitingTimeToCHEUsers();
		  } else {
			  logger.logMsg(LOG_LEVEL.DEBUG, "", "Currently there is no CHE Users Logged In , No Need To Check ITVS Waiting TIme");
		  }
			
		}
	  
	  public boolean isAnyCHEUserLoggedIn(){ 
		
			// look for all users who have confirmed allocations
			RDTCacheManager rdtCacheManager = RDTCacheManager.getInstance();
			Set<String> userList = rdtCacheManager.getAllocatedUsers();

			logger.logMsg(LOG_LEVEL.INFO, " ", "List of Users Logged In : " + userList);
			
			if (userList != null && !userList.isEmpty()) {	
			
				for (String userId : userList) {	
				
					if(rdtCacheManager.getUserLoggedInRole(userId).equals(OPERATOR.CHE) && rdtCacheManager.isOperatorAvailable(userId)) {
							return true;
					} 
					
				}
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Currently there is no logged in users");
			}
		
		return false;
	  }
		
	}
