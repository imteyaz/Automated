package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * <p> ValueObject holding the details of Cancel Inspection action performed by the user
 * 
 * @author Rosemary George
 *
 */
public class CancelInspectionEvent extends Event implements Serializable {
    private static final long serialVersionUID = -8155300239207536265L;

    @Override
    public String toString() {
        return "CancelInspectionEvent [UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID() + ", TerminalID="
                + getTerminalID() + "]";
    }

}
