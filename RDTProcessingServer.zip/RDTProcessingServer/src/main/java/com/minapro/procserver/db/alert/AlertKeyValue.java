package com.minapro.procserver.db.alert;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * ValueObject holding the parameter key and its value associated with the alert
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_ALERT_KEY_VALUES")
public class AlertKeyValue {

	@Id
	@SequenceGenerator(name = "alertKey_seq_gen", sequenceName = "MP_ALERT_KEY_VALUE_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "alertKey_seq_gen")
	@Column(name = "ALERT_KEY_VALUE_ID")
	private Integer keyValueId;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ALERT_RECORD_ID", referencedColumnName = "ALERT_RECORD_ID")
	private AlertRecord alertRecord;

	@Column(name = "KEY_NAME")
	private String keyName;

	@Column(name = "KEY_VALUE")
	private String keyValue;

	public Integer getKeyValueId() {
		return keyValueId;
	}

	public void setKeyValueId(Integer keyValueId) {
		this.keyValueId = keyValueId;
	}

	public AlertRecord getAlertRecord() {
		return alertRecord;
	}

	public void setAlertRecord(AlertRecord alertRecord) {
		this.alertRecord = alertRecord;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}
}
