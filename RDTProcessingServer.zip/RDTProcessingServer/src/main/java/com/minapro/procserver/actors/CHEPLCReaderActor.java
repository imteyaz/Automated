package com.minapro.procserver.actors;

import java.util.List;

import akka.actor.ActorRef;
import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.db.CHEPLCData;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor responsible for reading RMG PLC events from DB and pushing it to ESPER Actor. </p>
 * 
 * @author Kumaraswamy
 *
 */

public class CHEPLCReaderActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEPLCReaderActor.class);

    private ActorRef esperActor = RDTProcessingServer.getInstance().getEsperActor();

    @Override
    /**
     * Handles  RMG PLCEvents
     */
    public void onReceive(Object message) throws Exception {

        String input = (String) message;

        if ("READ".equalsIgnoreCase(input)) {
            logger.logMsg(LOG_LEVEL.DEBUG, "", "Polling RMG PLC Table ");
            List<CHEPLCData> rmgPlclist = (List<CHEPLCData>) HibernateUtil.loadRMGPLCData();

            try {
                if (!rmgPlclist.isEmpty()) {
                    for (CHEPLCData event : rmgPlclist) {
                        pushPLCEventToEsper(event);
                    }
                } else {
                    logger.logMsg(LOG_LEVEL.DEBUG, "", "No events received during this Iteration ");
                }
            } catch (Exception ex) {
                logger.logException("Caught exception while processing RMG PLCReaderActor -", ex);
            }
        } else if ("echo".equals(message)) {
            logger.logMsg(LOG_LEVEL.DEBUG, "", "ECHO");
        }
    }

    /**
     * Sends the specified event to the ESPER engine for pattern detection
     * 
     * @param event
     */
    private void pushPLCEventToEsper(CHEPLCData event) {
        // Populating Esper event out of received RMG PLC event from DB
        EsperRMGPLCEvent esperEvent = new EsperRMGPLCEvent();
        esperEvent.setNode(event.getPlcpk().getNode());
        esperEvent.setControlSystemType(event.getControlSystemType());

        if (event.getSpreader1Size() != null) {
            esperEvent.setSpreader1Size(Integer.valueOf(event.getSpreader1Size()));
        }
        if (event.getSpreader1TwistLock() != null) {
            esperEvent.setSpreader1TwistLock(Integer.valueOf(event.getSpreader1TwistLock()));
        }
        if (event.getSpreaderLsWeight() != null) {
            esperEvent.setSpreaderLsWeight(Double.valueOf(event.getSpreaderLsWeight()));
        }

        esperEvent.setTerminalId(event.getTerminalId());

        if (event.getTrolleyPos() != null) {
            esperEvent.setTrolleyPos(Double.valueOf(event.getTrolleyPos()));
        }

        esperEvent.setYardPos(event.getYardPos());
        esperEvent.setTagTime(event.getPlcpk().getTagTime());
        esperEvent.setLaneId(event.getLaneId());
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(event.getPlcpk().getNode());
        
        //to send ITV arrived or dispatched messages to logged in CHE users
        RDTCacheManager.getInstance().addUserToLocation(userId, event.getYardPos().substring(0,3));

        // Check whether user is logged in or not and unsubscribed from RMG PLC events
        if (userId != null && !RDTPLCCacheManager.getInstance().hasUserStoppedPLC(userId)) {
            // pushing events to Esper
            esperActor.tell(esperEvent, null);
        }
    }
}
