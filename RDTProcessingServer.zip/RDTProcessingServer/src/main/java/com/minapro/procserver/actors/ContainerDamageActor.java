package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.COLUMN_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_DAMAGE_DETAILS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DAMAGE_CODE_RESPONSE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ITEM_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DAMAGE_MAJOR_SEVERITY_VALUE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DAMAGE_MAJOR_SEVERITY_DEFAULT_VALUE;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.ApplicationParameter;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.TroubleshootAreaMaster;
import com.minapro.procserver.db.damage.DamageCode;
import com.minapro.procserver.db.damage.DamageRecording;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerDamageCorrectionEvent;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerDamagesRequestEvent;
import com.minapro.procserver.events.DamageDetails;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.hc.DamageCodeRequestEvent;
import com.minapro.procserver.events.hc.TroubleShootDetails;
import com.minapro.procserver.events.hc.TroubleshootConfirmRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Actor responsible for handling the container damage messages
 * 
 * @author Rosemary George
 *
 */
public class ContainerDamageActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerDamageActor.class);
    private static final String ROW_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);
    private static final String ITEM_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(ITEM_SEPERATOR_KEY);
    private static final String COLUMN_SEPERATOR = DeviceCommParameters.getInstance()
            .getCommParameter(COLUMN_SEPERATOR_KEY);
    
    private static final String HASH_SEPERATOR = "#";
    private static final String AMPERSAND_SEPERATOR = "&";

    /**
     * Handles the below events
     *  - ContainerDamageEvent
     *  - DamageCodeRequestEvent
     *  - ContainerDamagesRequestEvent
     *  - ContainerDamageCorrectionEvent
     */
    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof ContainerDamageEvent) {
            ContainerDamageEvent damagedContainer = (ContainerDamageEvent) message;
            logger.logMsg(LOG_LEVEL.WARN, damagedContainer.getUserID(), "Received damage message -" + damagedContainer);
            handleDamageContainerConfirmation(damagedContainer);
        } else if (message instanceof DamageCodeRequestEvent) {
            DamageCodeRequestEvent requestEvent = (DamageCodeRequestEvent) message;
            logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Received damage code request event :"
                    + requestEvent);
            sendDamageCodeToDevice(requestEvent);
        } else if(message instanceof ContainerDamagesRequestEvent) {
            ContainerDamagesRequestEvent damageRequestEvent = (ContainerDamagesRequestEvent)message;
            logger.logMsg(LOG_LEVEL.INFO, damageRequestEvent.getUserID(), "Received container damage records request event :"
                    + damageRequestEvent);
            
            sendContainerDamageDetails(damageRequestEvent);
        } else if(message instanceof ContainerDamageCorrectionEvent) {
            ContainerDamageCorrectionEvent correctionEvent = (ContainerDamageCorrectionEvent)message;
            logger.logMsg(LOG_LEVEL.INFO, correctionEvent.getUserID(), "Received container damage correction event :"
                    + correctionEvent);
            
            handleDamageCorrection(correctionEvent);
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the damage correction event from UI. This may contain updates, deletion or Addition of Damage records for
     * a particular container. 
     * 
     * @param correctionEvent
     */
    private void handleDamageCorrection(ContainerDamageCorrectionEvent correctionEvent) {
        try{
            Map<String, DamageRecording> existingDamages = HibernateUtil.getDamagesForContainer(correctionEvent.getContainerId());
            if(existingDamages == null){
                logger.logMsg(LOG_LEVEL.INFO, correctionEvent.getContainerId(), "NO Existing damages for the container");
                existingDamages = new HashMap<String, DamageRecording>();
            }
            
            String[] delCodes = deleteDamageRecords(correctionEvent, existingDamages);            
            updateDamageRecords(correctionEvent, existingDamages);
            
            String rotationId = "";
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent)RDTCacheManager.getInstance()
                    .getAllocationDetails(correctionEvent.getUserID());            
            if(allocation != null){
                rotationId = allocation.getRotationID();
            }
            
            String[] added;            
            String loc;
            List<String> addedRecords = correctionEvent.getAddedRecords();
            int addedSize = 0;
            if(addedRecords!= null){
                addedSize = addedRecords.size();
            }
            
            String[] codes = new String[existingDamages.size()+addedSize];
            int index = 0;
            if(addedRecords != null && !addedRecords.isEmpty()){
                for(String addedCode:addedRecords){
                    added = addedCode.split("\\"+ITEM_SEPERATOR);
                    if(added.length >=2){
                        loc = added[1];
                    }else{
                        loc=null;
                    }
                    insertDamageRecordToDB(correctionEvent, correctionEvent.getContainerId(), added[0].trim(), rotationId, loc);
                    codes[index++] = added[0].trim();
                }
            }
            
            
            /**inform ESB about the damage changes for the container
             * ESB expects the container damage event with all the existing damages for the container
             */
            DamageDetails details = new DamageDetails();
            details.setContainerID(correctionEvent.getContainerId());            
           
            for(String damage: existingDamages.keySet()){
                codes[index++] = existingDamages.get(damage).getDamageCode();
            }
            details.setDamageCodes(codes);
            details.setDeletedDamageCodes(delCodes);
            List<DamageDetails> detailsList = new ArrayList<DamageDetails>();
            detailsList.add(details);
            
            ContainerDamageEvent damageEvent = new ContainerDamageEvent();
            damageEvent.setDamageDetails(detailsList);
            damageEvent.setEquipmentID(correctionEvent.getEquipmentID());
            damageEvent.setEventID(correctionEvent.getEventID());
            damageEvent.setTerminalID(correctionEvent.getTerminalID());
            damageEvent.setUserID(correctionEvent.getUserID());
            damageEvent.setRotationId(rotationId);
            
            //send the container damage request to common queue as multiple roles can record damage
            ESBQueueManager.getInstance().postMessage(damageEvent, OPERATOR.COMMON, correctionEvent.getTerminalID());
            if(codes.length == 0){
            	logger.logMsg(LOG_LEVEL.INFO, correctionEvent.getContainerId(), "No more active damage records for the container");
            	updateContainerDamageStatus(correctionEvent);
            }
        }catch (Exception ex) {
            logger.logException("Caught exception while handleDamageCorrection- ", ex);
        }
    }
    
    private void updateContainerDamageStatus(ContainerDamageCorrectionEvent damageEvent) {
    	try {
	    	Container container=RDTCacheManager.getInstance().getContainerDetails(damageEvent.getContainerId());
	        if(container != null){
	            container.setDamaged(false);
	            logger.logMsg(LOG_LEVEL.DEBUG, damageEvent.getUserID(), "Damage code status is: " +container.getIsDamaged());
	        }else {
	        	logger.logMsg(LOG_LEVEL.DEBUG, damageEvent.getUserID(), "Did not find container in Central Cache. Checking in Completed Moves");
	        	OPERATOR role =  RDTCacheManager.getInstance().getUserLoggedInRole(damageEvent.getUserID());
	         	String equipmentId = damageEvent.getEquipmentID();
	         	if(role.equals(OPERATOR.HC)){
	         		equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(damageEvent.getUserID());
	         	}
	         	
	         	 String rotationId = "";         
	             ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
	                     .getAllocationDetails(damageEvent.getUserID());             
	             if (allocation != null) {
	                 rotationId = allocation.getRotationID();
	             }
	         	Map<String, CompletedContainerMoves> completedMoves = RDTCacheManager.getInstance().getCompletedJobs(
	                     rotationId, equipmentId);
	        	if(completedMoves != null){
	        		CompletedContainerMoves completedMove = completedMoves.get(damageEvent.getContainerId().concat(damageEvent.getMoveType()));
	        		if(completedMove != null){
	        			completedMove.setDamaged(false);
	        			logger.logMsg(LOG_LEVEL.DEBUG, damageEvent.getUserID(), "Damage code status is: " +completedMove.isDamaged());
	        		}
	        	}
	        }
    	}catch(Exception ex){
    		logger.logException("Caught exception while updating damage status for container "+ damageEvent.getContainerId(), ex);
    	}
		
    	generateDamageNotificationToAll(damageEvent.getContainerId(), false, damageEvent.getTerminalID());
	}

	/**
     * Mark the records as Deleted in Database for all the damages which are marked from UI as deleted
     * @param correctionEvent
     * @param existingDamages
     */
    private String[] deleteDamageRecords(ContainerDamageCorrectionEvent correctionEvent, 
            Map<String, DamageRecording> existingDamages){
        List<String> deletedDamages =  correctionEvent.getDeletedRecords();
        logger.logMsg(LOG_LEVEL.INFO, correctionEvent.getUserID(), "The deleted damage records =" + deletedDamages);          
        
        String[] delCodes = null;
        DamageRecording record;
        if(deletedDamages != null && !deletedDamages.isEmpty()){
            delCodes = new String[deletedDamages.size()];
            
            int delIndex = 0;
            for(String delCode:deletedDamages){
                record = existingDamages.remove(delCode.trim());
                logger.logMsg(LOG_LEVEL.DEBUG, correctionEvent.getUserID(), "Deleting Damage record =" + record); 
                delCodes[delIndex++] = record.getDamageCode();
                
                if(record != null){
                    record.setIsDeleted("Y");
                    record.setLastUpdatedDatetime(new Date());
                    record.setLastUpdatedBy(correctionEvent.getUserID());
                    JournalEvent journalEvent = new JournalEvent(record, UPDATETYPE.UPDATE);
                    getSender().tell(journalEvent, null);
                }
            }
        }
        
        return delCodes;
    }
    
    /**
     * Updates the damage records in DB for all the damages which are marked as updated ones.
     * 
     * @param correctionEvent
     * @param existingDamages
     */
    private void updateDamageRecords(ContainerDamageCorrectionEvent correctionEvent, 
            Map<String, DamageRecording> existingDamages){
        
        List<String> updatedDamages =  correctionEvent.getUpdatedRecords();
        logger.logMsg(LOG_LEVEL.INFO, correctionEvent.getUserID(), "The updated damage records =" + updatedDamages);
        if(updatedDamages != null && !updatedDamages.isEmpty()){
            String[] update;
            DamageRecording record;
            for(String updatedCode:updatedDamages){
                update = updatedCode.split("\\"+ITEM_SEPERATOR);
                record = existingDamages.get(update[0].trim());
                logger.logMsg(LOG_LEVEL.DEBUG, correctionEvent.getUserID(), "Updating Damage record =" + record); 
                                    
                if(record != null){
                    record.setDamageLocationCode(update[1]);
                    record.setDamageRemarks(correctionEvent.getRemarks());
                    record.setLastUpdatedDatetime(new Date());
                    record.setLastUpdatedBy(correctionEvent.getUserID());
                    JournalEvent journalEvent = new JournalEvent(record, UPDATETYPE.UPDATE);
                    getSender().tell(journalEvent, null);
                }
            }
        }
    }

    /**
     * Constructs and send the existing damage details for the specified container to the UI
     * 
     * Constructed message to UI will be like 
     *      2211~eventId~containerId~DamageTypeDetails~ListOfDamagRecords~userId~TerminalId
     * 
     * DamageTypeDetails will be filled like 
     *  Damagetype1^code1#loc1&loc2&loc3#sevr#Desc|code2#loc1&loc2&loc3#sevr#Desc$DamageType2^code3#loc1&loc2&loc3#sevr#Desc|code4#loc1&loc2&loc3#sevr#Desc...
.
     * 
     * ListOfDamageRecords will be filled like
     *    Id^type^severity^code^location^loc1&loc2&loc3^desc|Id^type^severity^code^location^loc1&loc2&loc3^desc......
     * 
     * @param damageRequestEvent
     */
    private void sendContainerDamageDetails(ContainerDamagesRequestEvent damageRequestEvent) {
        
        String eventType = DeviceEventTypes.getInstance().getEventType(CONTAINER_DAMAGE_DETAILS);
      
        StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventType).
        		append(VALUE_SEPERATOR).append(damageRequestEvent.getEventID()).append(VALUE_SEPERATOR);
        
        try{
            responseToDevice.append(damageRequestEvent.getContainerId()).append(VALUE_SEPERATOR);
            Map<String, List<String>> damageCodesWithLocation =  getDamageTypesAndLocation(responseToDevice);
            
            responseToDevice.append(VALUE_SEPERATOR)
                    .append(getOpenDamageRecords(damageRequestEvent.getContainerId(), damageCodesWithLocation)).append(VALUE_SEPERATOR)
                    .append(damageRequestEvent.getUserID()).append(VALUE_SEPERATOR).append(damageRequestEvent.getTerminalID());            
        }catch (Exception ex) {
            logger.logException("Caught exception while sendContainerDamageDetails- ", ex);
            
            responseToDevice.append(damageRequestEvent.getContainerId()).append(VALUE_SEPERATOR)
            .append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(damageRequestEvent.getUserID())
            .append(VALUE_SEPERATOR).append(damageRequestEvent.getTerminalID());
        }
        
        OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(damageRequestEvent.getUserID());
        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                damageRequestEvent.getTerminalID());
    }

    /**
     * Retrieves the open damage records and constructs the details in below format
     * 
     * Id^type^severity^code^location^loc1&loc2&loc3^desc|Id^type^severity^code^location^loc1&loc2&loc3^desc......
     * 
     * @param containerId
     * @return
     */
    private StringBuilder getOpenDamageRecords(String containerId, Map<String, List<String>> damageCodesWithLocation) {
        StringBuilder damageRecords = new StringBuilder();
        List<Object[]> damageList = HibernateUtil.getOpenDamagesForContainer(containerId);
        
        List<String> locations;
        if(damageList != null && !damageList.isEmpty()){
            logger.logMsg(LOG_LEVEL.INFO, containerId, "Number of open damages for the container is " + damageList.size());
            
            for (Object[] row : damageList) {
               damageRecords.append(row[4]).append(ITEM_SEPERATOR).append(row[0])
                   .append(ITEM_SEPERATOR).append(row[1])
                   .append(ITEM_SEPERATOR).append(row[2]).append(ITEM_SEPERATOR)
                   .append(row[3]).append(ITEM_SEPERATOR);
               
               locations = damageCodesWithLocation.get(row[2].toString());
               if(locations != null){
                   for(String loc:locations){
                       damageRecords.append(loc).append(AMPERSAND_SEPERATOR);
                   }
                   
                   EventUtil.getInstance().removeTrailingSeparator(AMPERSAND_SEPERATOR, damageRecords);                  
               }
               damageRecords.append(ITEM_SEPERATOR).append(row[5]).append(ROW_SEPERATOR);
            }
            
            EventUtil.getInstance().removeTrailingSeparator(ROW_SEPERATOR, damageRecords);            
        }
        return damageRecords;
    }

    /**
     * Retrieves the list of damage types and its associated damage codes
     * 
     * Damagetype1^code1#loc1&loc2&loc3#sevr#desc|code2#loc1&loc2&loc3#sevr#desc$DamageType2^code3#loc1&loc2&loc3#sevr#desc|code4#loc1&loc2&loc3#sevr#desc...
     * @return
     */
    private Map<String, List<String>> getDamageTypesAndLocation(StringBuilder responseToDevice) {
        List<Object[]> damageCodes = HibernateUtil.getDamageCodesWithTypeAndLocation();
        
        Map<String, List<String>> damageCodesWithLocation = new HashMap<String, List<String>>();
        
        if(damageCodes != null && !damageCodes.isEmpty()){
            logger.logMsg(LOG_LEVEL.INFO, "", "Number of damage codes available are " + damageCodes.size());
            
            Map<String, Set<String>> damageTypeDetails = new HashMap<String, Set<String>>();           
            Map<String, String> damageCodeSeverityType = new HashMap<String, String>();
            
            /**
             * Iterate through the query result set and segregate into damageType with codes and 
             * codes with its associated locations, severity and type
             */
            String damageType, damageCode, damageSeverity, damageLocation, damageDesc;
            List<String> locations;
            Set<String> codes;
            for (Object[] row : damageCodes) {
                damageType = row[0]!= null ? row[0].toString():"";
                damageCode = row[1].toString();
                damageSeverity = row[2]!= null ? row[2].toString():"";
                damageLocation = row[3]!= null ? row[3].toString():"";
                damageDesc = row[4]!= null ? row[4].toString() : "";
                
                locations = damageCodesWithLocation.get(damageCode);
                if(locations == null){
                    locations = new ArrayList<String>();
                    damageCodesWithLocation.put(damageCode, locations);
                }
                locations.add(damageLocation);
                
                codes = damageTypeDetails.get(damageType);
                if(codes == null){
                    codes = new HashSet<String>();
                    damageTypeDetails.put(damageType, codes);
                }
                codes.add(damageCode);
                
                damageCodeSeverityType.put(damageCode, damageSeverity+HASH_SEPERATOR+damageDesc);
            }
            
            /**
             * Iterating through the damageTypes and its associated codes to build the response message
             * Damagetype1^code1#loc1&loc2&loc3#sevr#desc|code2#loc1&loc2&loc3#sevr#desc$DamageType2^code3#loc1&loc2&loc3#sevr#desc|code4#loc1&loc2&loc3#sevr#desc...
             */
            for(String type:damageTypeDetails.keySet()){
                responseToDevice.append(type).append(ITEM_SEPERATOR);
                
                codes = damageTypeDetails.get(type);
                for(String code: codes){
                    responseToDevice.append(code).append(HASH_SEPERATOR);
                    locations = damageCodesWithLocation.get(code);
                    for(String loc: locations){
                        responseToDevice.append(loc).append(AMPERSAND_SEPERATOR);
                    }
                    
                    EventUtil.getInstance().removeTrailingSeparator(AMPERSAND_SEPERATOR, responseToDevice);                    
                    responseToDevice.append(HASH_SEPERATOR).append(damageCodeSeverityType.get(code)).append(ROW_SEPERATOR);
                }
                
                EventUtil.getInstance().removeTrailingSeparator(ROW_SEPERATOR, responseToDevice);
                responseToDevice.append(COLUMN_SEPERATOR);
            }  
            
            EventUtil.getInstance().removeTrailingSeparator(COLUMN_SEPERATOR, responseToDevice);
        }
        
        return damageCodesWithLocation;
    }

    /**
     * Handles the Damage container recording, sends the damaged record details to SPARCS. If the damage code requires
     * troubleshooting, the troubleshoot area will be present with the code. In such cases, generates the troubleshoot
     * request internally.
     * 
     * @param damagedContainer
     * 
     *            containerId^damageCode1|damageCode2|damageCode3^TSArea^ITVId$containerId^damageCode1|damageCode2|
     *            damageCode3^TSArea^ITVId
     */
    @SuppressWarnings("unchecked")
    private void handleDamageContainerConfirmation(ContainerDamageEvent damagedContainer) {
        String rotationId = "";
        try {
            ConfirmAllocationEvent allocation = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                    .getAllocationDetails(damagedContainer.getUserID());
            
            if (allocation != null) {
                rotationId = allocation.getRotationID();
            }
        } catch (Exception ex) {
            logger.logException("Caught exception while handleDamageContainerConfirmation- ", ex);
        }
        
        OPERATOR role =  RDTCacheManager.getInstance().getUserLoggedInRole(damagedContainer.getUserID());
    	String equipmentId = damagedContainer.getEquipmentID();
    	if(role.equals(OPERATOR.HC)){
    		equipmentId = RDTCacheManager.getInstance().getQCEquipmentAllocatedForHC(damagedContainer.getUserID());
    	}
    	Map<String, CompletedContainerMoves> completedMoves = RDTCacheManager.getInstance().getCompletedJobs(
                rotationId, equipmentId);

        List<DamageDetails> damageDetails = damagedContainer.getDamageDetails();
        /*
         * TODO::Needs to retrieve Damage Severity(major/minor) from database and check 
         * current damage code with database retrieved damage code.
         *  Read Major Damage Severity Value From Application Parameters.Depending On that Value Needs to decide 
		 * Current Damage Code is Major damage or not.
         */
        
        List<DamageCode> listOfDamagesFromDB = (List<DamageCode>) HibernateUtil.loadMasterData(DamageCode.class,"damageCodeId", true);
        int majorDamageSeverityValue = getMajorDamageSeverityValue();
		
        boolean isCurrentDamageMajor;
        
        for (DamageDetails damage : damageDetails) {
            
        	String[] damageCodes = damage.getDamageCodes();
            
            try {
            	
            	isCurrentDamageMajor = false;
                
            	for (String damageCode : damageCodes) {
                	/*
                	 * Following If Condition Is Added by UmaMahesh.Setting Damage Code severity to DamageDetails Object.
                	 * If isCurrentDamageMajor is true means one of current damage codes is already Major, 
                	 * In that case no need to check for other damage codes.
                	 */
                	if(!isCurrentDamageMajor) {
                		isCurrentDamageMajor = isCurrentDamageMajorDamage(listOfDamagesFromDB, damageCode , majorDamageSeverityValue);
                		
                		damage.setMajorDamage(isCurrentDamageMajor);
                	}
                    insertDamageRecordToDB(damagedContainer, damage.getContainerID(), damageCode.trim(), rotationId, null);
                }
            } catch (Exception ex) {
                logger.logException("Caught exception while inserting the record in to the DB- ", ex);
            }
            
            Container container=RDTCacheManager.getInstance().getContainerDetails(damage.getContainerID(), damagedContainer.getMoveType());
            if(container != null){
                container.setDamaged(true);
                logger.logMsg(LOG_LEVEL.DEBUG, damagedContainer.getUserID(), "Damage code status is: " +container.getIsDamaged());
            }else {
            	logger.logMsg(LOG_LEVEL.DEBUG, damagedContainer.getUserID(), "Did not find container in Central Cache. Checking in Complated Moves");
            	if(completedMoves != null){
            		CompletedContainerMoves completedMove = completedMoves.get(damage.getContainerID().concat(damagedContainer.getMoveType()));
            		if(completedMove != null){
            			completedMove.setDamaged(true);
            			logger.logMsg(LOG_LEVEL.DEBUG, damagedContainer.getUserID(), "Damage code status is: " +completedMove.isDamaged());
            		}
            	}
            }
            
            generateDamageNotificationToAll(damage.getContainerID(), true, damagedContainer.getTerminalID());
        }       

        // generateTroubleshootRequest(damagedContainer, damageDetails);
        
        //send the container damage request to common queue as multiple roles can record damage
        damagedContainer.setRotationId(rotationId);
        ESBQueueManager.getInstance().postMessage(damagedContainer, OPERATOR.COMMON, damagedContainer.getTerminalID());        
    }

    private int getMajorDamageSeverityValue() {
    	
    	ApplicationParameter applicationParams = RDTPLCCacheManager.getInstance().getApplicationParamter(
				DAMAGE_MAJOR_SEVERITY_VALUE);
		
		int majorDamageSeverityValue = DAMAGE_MAJOR_SEVERITY_DEFAULT_VALUE;
		
		try{
			majorDamageSeverityValue = (applicationParams!=null && applicationParams.getParameterValue()!=null ? 
				Integer.valueOf(applicationParams.getParameterValue()): DAMAGE_MAJOR_SEVERITY_DEFAULT_VALUE);
		}catch(NumberFormatException nex) {
			logger.logMsg(LOG_LEVEL.ERROR,applicationParams.getParameterValue()," Unable To Convert Parameter Value To Integer"
					.concat(" Check Parameter Value In Admin App Application Parameters Master Screen::"+nex));
			
		}
		return majorDamageSeverityValue;
	}

	/**
     * Generates the container damage status notification to QC/HC/CHE operators who has the container in their  current/completed job list
     * 
     * @param containerId
     * @param damageStatus
     * @param terminalId
     */
	private void generateDamageNotificationToAll(String containerId, boolean damageStatus, String terminalId) {
		try {
			String eventTypeID = DeviceEventTypes.getInstance().getEventType(RDTProcessingServerConstants.DAMAGE_CONTAINER_NOTIF);
			
			StringBuilder damageNotif = new StringBuilder(NOTIF ).append(VALUE_SEPERATOR).append(eventTypeID);
		
			damageNotif.append(VALUE_SEPERATOR).append(UUID.randomUUID().toString())
				.append(VALUE_SEPERATOR).append(containerId).append(VALUE_SEPERATOR)
				.append(damageStatus).append(VALUE_SEPERATOR);
			
			List<String> equipmentIds = HibernateUtil.getEquipmentsWorkingOnContainer(containerId);			
			if (equipmentIds != null) {
				String userId;
				StringBuilder finalNotif;
				OPERATOR role;
				for (String equipmentId : equipmentIds) {
					logger.logMsg(LOG_LEVEL.DEBUG, containerId, "Equipment " + equipmentId
							+ " is associated with the container.");
					userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(equipmentId);
					if(userId ==  null){
						userId = RDTCacheManager.getInstance().getHCUserAllocatedForQC(equipmentId);
					}
					
					if (userId != null) {
						role = RDTCacheManager.getInstance().getUserLoggedInRole(userId);
						//in case of ITV, no need to send the notification. Only to QC,HC,CHE
						if(role.equals(OPERATOR.ITV)){
							continue;
						}
						
						boolean inspectionStatus = EventUtil.getInstance().getInspectionStatus(userId);
						if (inspectionStatus) {
							logger.logMsg(LOG_LEVEL.DEBUG, containerId, "Sending the notification to Associated user:"
									+ userId);
							finalNotif = new StringBuilder(damageNotif).append(userId).append(VALUE_SEPERATOR).append(terminalId);
							CommunicationServerQueueManager.getInstance().postMessage(finalNotif.toString(), role, terminalId);
						}
						
						if (role.equals(OPERATOR.QC)) {
							String hcUser = RDTCacheManager.getInstance().getHCUserAllocatedForQC(equipmentId);
							logger.logMsg(LOG_LEVEL.INFO, equipmentId, "Associated HC user is " + hcUser);
							if (hcUser != null) {
								inspectionStatus = EventUtil.getInstance().getInspectionStatus(hcUser);
								if (inspectionStatus) {
									finalNotif = new StringBuilder(damageNotif).append(hcUser).append(VALUE_SEPERATOR)
											.append(terminalId);
									CommunicationServerQueueManager.getInstance().postMessage(finalNotif.toString(),
											role, terminalId);
								}
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught Exception while generating notification", ex);
		}
	}

	/**
     * inserts the damage record in to DB
     * 
     * @param damagedContainer
     * @param containerId
     * @param eachdamageCode
     * @param rotationId
     * @param user
     */
    private DamageRecording insertDamageRecordToDB(Event damagedContainer, String containerId, String eachdamageCode,
            String rotationId, String locationCode) {

        DamageRecording damageRecord = new DamageRecording();

        damageRecord.setDamageCode(eachdamageCode);
        damageRecord.setContainerId(containerId);
        damageRecord.setRotationId(rotationId);
        damageRecord.setTerminalId(damagedContainer.getTerminalID());
        damageRecord.setCreatedDatetime(damagedContainer.getTimeStamp());
        damageRecord.setCreatedBy(damagedContainer.getUserID());
        damageRecord.setIsDeleted("N");
        if(locationCode != null){
            damageRecord.setDamageLocationCode(locationCode);
        }else {
            List<String> damageLocationCodes = HibernateUtil.getDamageLocationCodes(damageRecord.getDamageCode());
            if (damageLocationCodes != null && !damageLocationCodes.isEmpty()) {
                damageRecord.setDamageLocationCode(damageLocationCodes.get(0));
            }
        }

        JournalEvent journalEvent = new JournalEvent(damageRecord, UPDATETYPE.ADD);
        getSender().tell(journalEvent, null);
        
        return damageRecord;
    }

    /**
     * Constructs the troubleshoot request and sends to the master actor for further processing
     * 
     * @param damagedContainer
     * @param codesAndAreas
     */
    @SuppressWarnings("unused")
    private void generateTroubleshootRequest(ContainerDamageEvent damagedContainer, List<DamageDetails> damageDetails) {
        TroubleshootConfirmRequestEvent tsRequest = new TroubleshootConfirmRequestEvent();
        tsRequest.setEquipmentID(damagedContainer.getEquipmentID());
        tsRequest.setEventID(damagedContainer.getEventID());
        tsRequest.setTerminalID(damagedContainer.getTerminalID());
        tsRequest.setTimeStamp(damagedContainer.getTimeStamp().toString());
        tsRequest.setUserID(damagedContainer.getUserID());

        List<TroubleShootDetails> tsDetails = new ArrayList<TroubleShootDetails>();

        for (DamageDetails damage : damageDetails) {
            TroubleShootDetails troubleShootDetails = new TroubleShootDetails();
            troubleShootDetails.setContainerID(damage.getContainerID());
            troubleShootDetails.setItvId(damage.getItvId());
            troubleShootDetails.setTsAreaId(damage.getTroubleShootAreaId());
            /*
             * //TO DO troubleShootDetails.setTroubleShootCodes(troubleShootCodes);
             */

            tsDetails.add(troubleShootDetails);
        }

        tsRequest.setTroubleShootDetails(tsDetails);
        tsRequest.setMoveType(damagedContainer.getMoveType());

        getSender().tell(tsRequest, null);
    }

    /**
     * Constructs the damage code response to the user with damage code details and troubleshoot areas
     * 
     * @param requestEvent
     */
    private void sendDamageCodeToDevice(DamageCodeRequestEvent requestEvent) {
        try {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(DAMAGE_CODE_RESPONSE);

            // Get Break Reason Code,And Get Data From Cache,Sending Response To CommServer
            StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR).append(eventTypeID)
            		.append(VALUE_SEPERATOR).append( requestEvent.getEventID()).append(VALUE_SEPERATOR);
            
            responseToDevice.append(getTroubleShootAreas(requestEvent)).append(VALUE_SEPERATOR)
                    .append(getDamageCodes(requestEvent)).append(VALUE_SEPERATOR).append(requestEvent.getUserID())
                    .append(VALUE_SEPERATOR).append(requestEvent.getTerminalID());

            OPERATOR role = RDTCacheManager.getInstance().getUserLoggedInRole(requestEvent.getUserID());
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                    requestEvent.getTerminalID());
        } catch (Exception ex) {
            logger.logException("Caught exception while sendDamageCodeToDevice- ", ex);
        }
    }

    /**
     * Gets the troubleshoot areas defined for the specified terminal and constructs the response TSArea1|TSArea2...
     * 
     * @param requestEvent
     * @return
     */
    private StringBuilder getTroubleShootAreas(DamageCodeRequestEvent requestEvent) {
        StringBuilder troubleShootData = new StringBuilder();
        Set<TroubleshootAreaMaster> troubleshootAreas = RDTCacheManager.getInstance().getTroubleShootAreas(
                requestEvent.getTerminalID());

        if (troubleshootAreas != null && !troubleshootAreas.isEmpty()) {
            logger.logMsg(LOG_LEVEL.DEBUG, requestEvent.getUserID(), "Available Troubleshoot area codes are "
                    + troubleshootAreas);
            for (TroubleshootAreaMaster troubleShootArea : troubleshootAreas) {
                troubleShootData.append(troubleShootArea.getTroubleshootAreaId()).append(ROW_SEPERATOR);
            }
            troubleShootData.delete(troubleShootData.length() - 1, troubleShootData.length());
        } else {
            logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(),
                    "No Trouble Shoot Areas Are Found At Current Terminal " + requestEvent.getTerminalID());
        }

        return troubleShootData;
    }

    /**
     * Retrieves the damage codes present in the database and constructs the response like below
     * DamageCode1^Desc^Y/N|DamageCode2^desc^Y/N....
     * 
     * @param requestEvent
     * @return
     */
    @SuppressWarnings("unchecked")
    private StringBuilder getDamageCodes(DamageCodeRequestEvent requestEvent) {
        StringBuilder damageCodes = new StringBuilder();
        List<DamageCode> damageCodeList = (List<DamageCode>) HibernateUtil.loadMasterData(DamageCode.class,
                "damageCodeId", true);

        if (damageCodeList != null && !damageCodeList.isEmpty()) {
            logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "Available damage codes are " + damageCodeList);
            for (DamageCode damageCode : damageCodeList) {
                damageCodes.append(damageCode.getDamageCode()).append(ITEM_SEPERATOR)
                        .append(damageCode.getDescription()).append(ITEM_SEPERATOR).append(ROW_SEPERATOR);
            }
            damageCodes.delete(damageCodes.length() - 1, damageCodes.length());
        } else {
            logger.logMsg(LOG_LEVEL.INFO, requestEvent.getUserID(), "No damage codes are present in the system ");
        }

        return damageCodes;
    }    
    
    private boolean isCurrentDamageMajorDamage(List<DamageCode> damageCodeList ,  String currentDamageCode , int majorDamageSeverityValue){
    		
    	for(DamageCode damage : damageCodeList) {

    		if(damage.getDamageCode().equalsIgnoreCase(currentDamageCode) && 
    				Integer.valueOf(currentDamageCode) >= majorDamageSeverityValue){
    		
    			logger.logMsg(LOG_LEVEL.INFO,currentDamageCode,new StringBuilder(" Current Damage Code::").
    					append(currentDamageCode).append(" Is Greater Than Or Equal Major Damage Severity Value::").
    					append(majorDamageSeverityValue).toString());
    			return true;
    		}

    	}
    	return false;
    }
}
