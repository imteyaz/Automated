package com.minapro.procserver.actors.common;

import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

import akka.actor.UntypedActor;

/**
 * Actor responsible for persisting the events into Database.
 * 
 * @author Rosemary George
 *
 */
public class JournalActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(JournalActor.class);

    @Override
    public void onReceive(Object event) throws Exception {
        if (event instanceof JournalEvent) {
            JournalEvent journal = (JournalEvent) event;
            Object journalData = journal.getJournalData();
            switch (journal.getOperationType()) {
            case UPDATE:
                logger.logMsg(LOG_LEVEL.DEBUG, "", "Received data to update in DB - " + journalData);
                HibernateUtil.updateData(journalData);
                break;

            case ADD:
                logger.logMsg(LOG_LEVEL.DEBUG, "", "Received data to persist in DB - " + journalData);
                HibernateUtil.saveData(journalData);
                break;

            case DELETE:
                logger.logMsg(LOG_LEVEL.DEBUG, "", "Received data to delete from DB - " + journalData);
                HibernateUtil.deleteData(journalData);
                break;

            default:
                logger.logMsg(LOG_LEVEL.ERROR, "", "Received unknown operation type. Discarding the message");
            }
        } else {
            unhandled(event);
        }
    }
}
