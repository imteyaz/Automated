package com.minapro.procserver.db.yardview;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * BlkareaYpm entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "MP_BLKAREA_YPM")
public class BlkareaYpm implements java.io.Serializable {

    private static final long serialVersionUID = 5085391733873574182L;

    @Id
    @Column(name = "INT_BLK_NO")
    private Integer intBlkNo;

    @Column(name = "BLK_ID")
    private String blkId;

    @Column(name = "BLK_TYPE")
    private String blkType;

    @Column(name = "TMPL_FLG")
    private String tmplFlg;

    @Column(name = "USR_PP_CD")
    private String usrPpCd;

    @Column(name = "INT_TMNL_NO")
    private Short intTmnlNo;

    @Column(name = "AREA_TYPE_IND")
    private String areaTypeInd;

    public Integer getIntBlkNo() {
        return this.intBlkNo;
    }

    public void setIntBlkNo(Integer intBlkNo) {
        this.intBlkNo = intBlkNo;
    }

    public String getBlkId() {
        return this.blkId;
    }

    public void setBlkId(String blkId) {
        this.blkId = blkId;
    }

    public String getBlkType() {
        return this.blkType;
    }

    public void setBlkType(String blkType) {
        this.blkType = blkType;
    }

    public String getTmplFlg() {
        return this.tmplFlg;
    }

    public void setTmplFlg(String tmplFlg) {
        this.tmplFlg = tmplFlg;
    }

    public String getUsrPpCd() {
        return this.usrPpCd;
    }

    public void setUsrPpCd(String usrPpCd) {
        this.usrPpCd = usrPpCd;
    }

    public Short getIntTmnlNo() {
        return this.intTmnlNo;
    }

    public void setIntTmnlNo(Short intTmnlNo) {
        this.intTmnlNo = intTmnlNo;
    }

    public String getAreaTypeInd() {
        return this.areaTypeInd;
    }

    public void setAreaTypeInd(String areaTypeInd) {
        this.areaTypeInd = areaTypeInd;
    }
}