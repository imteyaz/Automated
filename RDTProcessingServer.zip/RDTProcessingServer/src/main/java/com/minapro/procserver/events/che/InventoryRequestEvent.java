package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;


/**
 *Value object holding the inventory request details from UI to ESB.
 * @author 1201257
 *
 */
public class InventoryRequestEvent extends Event implements Serializable{

    private static final long serialVersionUID = 8075277084652828267L;
    
  
    private String stackNumber;
    private String rowNumber;
    
    public String getStackNumber() {
        return stackNumber;
    }
    public void setStackNumber(String stackNumber) {
        this.stackNumber = stackNumber;
    }
    public String getRowNumber() {
        return rowNumber;
    }
    public void setRowNumber(String rowNumber) {
        this.rowNumber = rowNumber;
    }
    
    @Override
    public String toString() {
        return "InventoryRequestEvent [stackNumber=" + stackNumber + ", rowNumber=" + rowNumber + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
