package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the alert message from ESB, which will be forwarded to the specified user.
 * 
 * @author Rosemary George
 *
 */
public class AlertEvent extends Event implements Serializable {

    private static final long serialVersionUID = 8711940734194382645L;

    private String reason;
    
    private boolean beepRequired;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "AlertEvent [message=" + reason + ", UserID=" + getUserID() + ", EquipmentID=" + getEquipmentID()
                + ", TerminalID=" + getTerminalID() + ", EventID=" + getEventID() + "]";
    }

	public String getBeepRequired() {
		return beepRequired?"true":"false";
	}

	public void setBeepRequired(boolean beepRequired) {
		this.beepRequired = beepRequired;
	}
}
