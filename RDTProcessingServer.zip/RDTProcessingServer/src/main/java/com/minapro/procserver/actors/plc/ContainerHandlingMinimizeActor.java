package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.CONTAINER_HANDLING_MINIMIZE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.plc.ContainerScreenMinimizeEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

public class ContainerHandlingMinimizeActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerHandlingMinimizeActor.class);

    @Override
    /**
     * Handles Wrong Container Lift event
     */
    public void onReceive(Object message) throws Exception {

        if (message instanceof ContainerScreenMinimizeEvent) {

            ContainerScreenMinimizeEvent minimizer = (ContainerScreenMinimizeEvent) message;

            logger.logMsg(LOG_LEVEL.DEBUG, minimizer.getUserID(), "Received Container handling screen minimize event-"
                    + minimizer);

            User user = RDTCacheManager.getInstance().getUserDetails(minimizer.getUserID());
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(user.getUserID());
            sendContainerScreenMinimizeEvent(minimizer, operatorRole);

        } else {
            unhandled(message);
        }

    }

    private void sendContainerScreenMinimizeEvent(ContainerScreenMinimizeEvent minimizer, OPERATOR operator) {

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(CONTAINER_HANDLING_MINIMIZE);

        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(NOTIF).append( valueSeperator).append( minimizer.geEventType());

        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(valueSeperator);
            EventUtil.getInstance().getEventParameter(minimizer, msgFields.get(i), responseToDevice);
        }

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                minimizer.getTerminalID());

    }

}
