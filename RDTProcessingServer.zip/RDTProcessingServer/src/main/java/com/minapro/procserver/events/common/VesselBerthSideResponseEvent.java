package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the vessel berthing side details from ESB
 * 
 * @author Rosemary George
 *
 */
public class VesselBerthSideResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = 1121834983164413378L;

    /**
     * Indicates the rotation id of the currently berthed vessel
     */
    private String rotationId;

    /**
     * Indicates the berthing side of the vessel - P for port side/ S for star boat side
     */
    private String berthSide;

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getBerthSide() {
        return berthSide;
    }

    public void setBerthSide(String berthSide) {
        this.berthSide = berthSide;
    }

    @Override
    public String toString() {
        return "VesselBerthSideResponseEvent [rotationId=" + rotationId + ", berthSide=" + berthSide + ", UserID="
                + getUserID() + ", EquipmentID=" + getEquipmentID() + "]";
    }
}
