package com.minapro.procserver.db.damage;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the damage code location link details from the database
 * @author kalyani
 *
 */
@Entity
@Table(name="MP_DAMAGECODE_LOCATION_LINK")
public class DamageCodeLocationLink implements Serializable {

    private static final long serialVersionUID = 9052141200276907030L;

    @EmbeddedId
    private DamageCodeLocationLinkPk pk;  

    @Column(name = "CREATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDatetime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;
    
    @Column(name = "VERSION")
    private int version;

    @Column(name = "ISDELETED")
    private String isDeleted;
     
    public DamageCodeLocationLinkPk getPk() {
        return pk;
    }

    public void setPk(DamageCodeLocationLinkPk pk) {
        this.pk = pk;
    }
    
    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDatetime() {
        return lastUpdatedDatetime;
    }

    public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
        this.lastUpdatedDatetime = lastUpdatedDatetime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "DamageCodeLocationLink [pk=" + pk + ", createdDatetime=" + createdDatetime + ", createdBy=" + createdBy
                + ", lastUpdatedDatetime=" + lastUpdatedDatetime + ", lastUpdatedBy=" + lastUpdatedBy + ", version="
                + version + ", isDeleted=" + isDeleted + "]";
    }
}
