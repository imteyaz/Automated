package com.minapro.procserver.events;

/**
 * ValueObject holding the running status of a container at a given point of time. The object will be created when an operator performs an action on the container. 
 * 
 * For example, in case of Discharge, the object gets created when QC picks up the container from vessel location.
 * The status of the object keeps changing as different operators perform actions during the discharge process. 
 * And it gets finally destroyed once the CHE places it in the yard.
 * 
 * @author Rosemary George
 *
 */
public class ContainerRunningStatus {
	
	/**
     * ID of the container
     */
    private String containerID;
    
	/**
	 * Indicates the location from the container is picked up - can be Vessel, yard or ITV
	 */
	private String previousPosition;
	
	/**
	 * Indicate the current location of the container - - can be Vessel, yard or ITV
	 */
	private String currentLocation;
	
	/**
	 * Indicates the current status of job - LOAD/DSCH/HK/DLVR/RECV/LC/GC
	 */
	private String jobStatus;
	
	/**
	 * Indicates the operator who performed the current operation on the container - can be QC/ITV/CHE/HC
	 */
	private String operatedBy;

	public String getContainerID() {
		return containerID;
	}

	public void setContainerID(String containerID) {
		this.containerID = containerID;
	}

	public String getPreviousPosition() {
		return previousPosition;
	}

	public void setPreviousPosition(String previousPosition) {
		this.previousPosition = previousPosition;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getOperatedBy() {
		return operatedBy;
	}

	public void setOperatedBy(String operatedBy) {
		this.operatedBy = operatedBy;
	}	
}
