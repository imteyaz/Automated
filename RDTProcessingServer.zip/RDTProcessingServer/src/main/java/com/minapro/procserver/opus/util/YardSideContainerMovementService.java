package com.minapro.procserver.opus.util;

import static com.minapro.procserver.util.RDTProcessingServerConstants.DSCH;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.GROUND;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOAD;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MI;
import static com.minapro.procserver.util.RDTProcessingServerConstants.MO;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RH;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.map.ListOrderedMap;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.db.User;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is responsible for performing all CHE Related Job Confirmations to ESB like (Job Selection , Job Confirmation)
 * @author UmaMahesh
 *
 */
public class YardSideContainerMovementService {

	private static final MinaProApplicationLogger LOGGER = new MinaProApplicationLogger(YardSideContainerMovementService.class);	
	private static final YardSideContainerMovementService  INSTANCE  = new YardSideContainerMovementService();	
	private final ContainerMoveUtil containerMoveUtil = ContainerMoveUtil. getInstance();
	
	private YardSideContainerMovementService() { }
	 
	public static YardSideContainerMovementService getInstance() {
		return INSTANCE;
	}
	
	/**
     * <p>Handles the container move operation happens at the Yard side. The possible container move types are</p>
     * 
     * <p> Load - moving container from yard to ship</p> <p> Discharge - Moving container from Ship to Yard</p> <p>
     * Receive - Placing container in yard from External truck</p> <p> Delivery - Moving container from yard to external
     * truck</p>
     * 
     * @param moveEvent
     * @param user
     * @param operatorRole
     */
	public void handleYardSideContainerMoveOperation(ContainerMoveEvent moveEvent, User user, OPERATOR operatorRole) {

		LOGGER.logMsg(LOG_LEVEL.INFO, user.getUserID(), "handleYardSideContainerMoveOperation - started");
		
		try {      
			if(!moveEvent.isAutomaticFlag()){
				//In CHE Don't Validate ToLocation,,Send By Default Message As True To Operator
				containerMoveUtil.sendValidationResponseToDevice(true,"", moveEvent, operatorRole);
			}
			
			validateAndUpdateContainerPosition(moveEvent);		
			
			CompletedContainerMoves cont = containerMoveUtil.getCompletedContainer(moveEvent.getContainerIDs().get(0), moveEvent.getUserID(),
					moveEvent.getEquipmentID(),moveEvent.getMoveType());
			if(cont!= null && (LOAD.equalsIgnoreCase(moveEvent.getMoveType()) || MO.equalsIgnoreCase(moveEvent.getMoveType()))){
				LOGGER.logMsg(LOG_LEVEL.INFO, user.getUserID(), "confirmed a completed LOAD/MO job again. Checking for ITV swap");
				
				boolean isITVSwapDone = containerMoveUtil.checkAndInitiateITVSwap(moveEvent);
				if(isITVSwapDone){
					LOGGER.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "ITV swap detected and send");
					return;
				}
			}
			
			// remove the containers form job list
			List<String> containerIds = moveEvent.getContainerIDs();
			containerMoveUtil.updateCompletedMoves(user, moveEvent, moveEvent.getEquipmentID(), operatorRole);
			
			for (String containerId : containerIds) {
				RDTCacheManager.getInstance().deleteFromJobList(moveEvent.getUserID(), containerId,
						moveEvent.getEquipmentID(), "");

				// remove the container from central cache as it is DELIVERed to external truck and left the port
				if (GO.equalsIgnoreCase(moveEvent.getMoveType())) {
					RDTCacheManager.getInstance().deleteContainer(containerId);
				}
			}
		} catch (Exception ex) {
			LOGGER.logException("Caught exception while processing Yard side container move", ex);
		}

		// in case of automatic container confirmation, send job done message to CHE
		if (moveEvent.isAutomaticFlag()) {
			StringBuilder jobDoneMessage = containerMoveUtil.generateRemoveJobMessage(moveEvent, moveEvent.getUserID());
			LOGGER.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Sending Auto Job confirmation to CHE User ");
			CommunicationServerQueueManager.getInstance().postMessage(jobDoneMessage.toString(), OPERATOR.CHE,
					moveEvent.getTerminalID());
		}

		updateCHEPerformanceParameters(moveEvent);
		ESBQueueManager.getInstance().postMessage(moveEvent, operatorRole, moveEvent.getTerminalID());
	}
    
	private void validateAndUpdateContainerPosition(ContainerMoveEvent moveEvent) {
		if(moveEvent.getPosition() == null || moveEvent.getPosition().isEmpty()){
			
			ListOrderedMap<String, JobListContainer> jobsInCache =RDTCacheManager.getInstance().getJobList(
	                moveEvent.getUserID(), moveEvent.getEquipmentID());
			
			if(jobsInCache == null){
				LOGGER.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "No jobs present in cache");
				return;
			}
			
			List<String> positions = new ArrayList<String>();
			for(String containerId: moveEvent.getContainerIDs()){
				positions.add(jobsInCache.get(containerId)!= null ? jobsInCache.get(containerId+moveEvent.getMoveType()).getPosition(): "");
			}
			moveEvent.setPosition(positions);
			LOGGER.logMsg(LOG_LEVEL.DEBUG, moveEvent.getUserID(), "Container positions - " + moveEvent.getPosition());
		}		
	}

	/**
     * Sends the updated performance parameters to the Performance calculating Actor
     * 
     * @param moveEvent
     */
    private void updateCHEPerformanceParameters(ContainerMoveEvent moveEvent) {
        try {
            LOGGER.logMsg(LOG_LEVEL.INFO, "",
                    " Started UpdateCHEPerformanceParameters() With Input Value " + moveEvent.toString());
            EsperRMGPLCEvent chePlc = new EsperRMGPLCEvent();
            chePlc.setNode(moveEvent.getEquipmentID());
            RDTProcessingServer.getInstance().getMasterActor().tell(chePlc, null);
        } catch (Exception ex) {
            LOGGER.logException("Caught exception while performing updateCHEPerformanceParameters ", ex);
        }
    }
    
    /*
     * The method is responsible for validating the vessel location and yard location and send the response to UI
     * toLocation.startsWith("GR")
     */
    public boolean checkValidMessage(ContainerMoveEvent moveEvent, OPERATOR role) {
        boolean isValid = true;
        String errorMessage = "";
        String toLocation;
        
        if(!moveEvent.isAutomaticFlag()){	        
        	try{
	           
	        	for (int i = 0; i < moveEvent.getToLocations().size(); i++) {	
                    toLocation = moveEvent.getToLocations().get(i);
                    LOGGER.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Validating the To  Location" + toLocation);
                  
                    if(GROUND.equals(toLocation)) {
                    	return true;
                    }
                    if (LOAD.equalsIgnoreCase(moveEvent.getMoveType()) ||  MO.equalsIgnoreCase(moveEvent.getMoveType())) {
                    		isValid = containerMoveUtil.getValidITVLocation(toLocation, moveEvent.getEquipmentID());                        
                    } else if (DSCH.equalsIgnoreCase(moveEvent.getMoveType()) || GI.equalsIgnoreCase(moveEvent.getMoveType()) 
                    		|| MI.equalsIgnoreCase(moveEvent.getMoveType())	|| RH.equalsIgnoreCase(moveEvent.getMoveType())) {

                       // YardValidationStatus isValidYard = BlockProfileUtil.getInstance().doYardLocationValidation(toLocation);
                        //isValid = (YardValidationStatus.NO_ERROR).equals(isValidYard) ? true : false;
                    	
                    	//No yard validation required as per the on-site workshop on March 2017
                    	isValid = true;
                    } else {
                    	LOGGER.logMsg(LOG_LEVEL.WARN,moveEvent.getUserID(),new StringBuilder(" Current MoveType::").append(moveEvent.getMoveType()).
                    			append(" Is Not Handled , Returning True By Default").toString());
                    	isValid = true;
                    }

                    if (!isValid) {
                        errorMessage = "InValidToLocationError";
                        LOGGER.logMsg(LOG_LEVEL.INFO, moveEvent.getUserID(), "Not the valid Cell and Yard Locations.. Breaking");
                        break;
                    }
                }      
	        } catch (Exception ex) {
	            LOGGER.logException("Caught exceptionw hile validating the toLocation", ex);
	        }
	        
	        containerMoveUtil.sendValidationResponseToDevice(isValid, errorMessage, moveEvent, role);
        }
        return isValid;    
    }
}
