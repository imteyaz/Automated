package com.minapro.procserver.cache;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;

import com.minapro.procserver.util.RDTProcessingServerConstants;

/**
 * <p>This sample cache container acts as a factory and a mechanism with which to create and configure an embedded cache
 * manager, and to hold this cache manager such that other code can access it.</p>
 * 
 * @author Rosemary George
 */
public class RDTCacheContainer {
    private static final String INFINISPAN_CONFIGURATION = RDTProcessingServerConstants.CONFIG_DIRECTORY
            + "infinispan-local.xml";
    private static final EmbeddedCacheManager CACHE_MANAGER;

    private RDTCacheContainer() {
    }

    static {
        try {
            CACHE_MANAGER = new DefaultCacheManager(INFINISPAN_CONFIGURATION);
        } catch (IOException e) {
            throw new RuntimeException("Unable to configure Infinispan", e);
        }
    }

    /**
     * Retrieves a named cache.
     * 
     * @param cacheName
     *            name of cache to retrieve
     * @param <K>
     *            type used as keys in this cache
     * @param <V>
     *            type used as values in this cache
     * @return a cache
     */
    public static <K, V> Cache<K, V> getCache(String cacheName) {
        if (cacheName == null) {
            throw new NullPointerException("Cache name cannot be null!");
        }
        return CACHE_MANAGER.getCache(cacheName);
    }

    /**
     * Retrieves the embedded cache manager.
     * 
     * @return a cache manager
     */
    public static EmbeddedCacheManager getCacheContainer() {
        return CACHE_MANAGER;
    }
}
