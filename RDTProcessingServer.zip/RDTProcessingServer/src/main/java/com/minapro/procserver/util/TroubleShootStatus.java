package com.minapro.procserver.util;

/**
 * Enum indicating the possible status values for a trouble shoot record
 * 
 * @author Rosemary George
 *
 */
public enum TroubleShootStatus {

    PENDING("PENDING"), IN_PROGRESS("IN PROGRESS"), COMPLETED("COMPLETED"), CLOSED("CLOSED");

    private String name;

    private TroubleShootStatus(String name) {
        this.setName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
