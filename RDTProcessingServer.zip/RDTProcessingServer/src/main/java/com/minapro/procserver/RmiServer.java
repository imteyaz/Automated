package com.minapro.procserver;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.concurrent.TimeUnit;

import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class which act as the RMI server.
 * 
 * @author Rosemary George
 *
 */
@SuppressWarnings("serial")
public class RmiServer extends java.rmi.server.UnicastRemoteObject implements ReceiveMessageInterface {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(RmiServer.class);

    private static final int PORT = 3232;

    String thisAddress;
    // rmi registry for lookup the remote objects.
    Registry registry;

    public RmiServer() throws RemoteException {
        try {
            // get the address of this host.
            thisAddress = (InetAddress.getLocalHost()).toString();
        } catch (Exception e) {
            logger.logException("Caught exception while trying to get the RMI IP ", e);
            throw new RemoteException("can't get inet address.");
        }

        logger.logMsg(LOG_LEVEL.INFO, "", "Starting up RMI server with Addess :" + thisAddress + ":" + PORT);

        try {
            // create the registry and bind the name and object.
            registry = LocateRegistry.createRegistry(PORT);
            registry.rebind("rmiServer", this);
        } catch (RemoteException e) {
            throw e;
        }
    }

    /**
     * Starts the PLC scheduler
     */
    @Override
    public boolean startPLC(String role) throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, role, "Received start PLC scheduler instruction");
        RDTProcessingServer.getInstance().startPLCScheduler(role);
        return true;
    }

    /**
     * Stops the PLC scheduler
     */
    @Override
    public boolean stopPLC(String role) throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, role, "Received stop PLC scheduler instruction");
        RDTProcessingServer.getInstance().stopPLCScheduler(role);
        return true;
    }

    /**
     * Ping request from RMI Client
     */
    @Override
    public boolean checkMasterStatus() throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, "", "Received Master node heartbeat message and is active");
        logger.logMsg(LOG_LEVEL.INFO, "", "Logged in QC user size ="
                + RDTPLCCacheManager.getInstance().sizeOfQCLoggedInCache());
        logger.logMsg(LOG_LEVEL.INFO, "", "Logged in CHE user size ="
                + RDTPLCCacheManager.getInstance().sizeOfCHELoggedInCache());
        return true;
    }

    /**
     * Restarts the job list scheduler
     */
    @Override
    public boolean restartJobListScheduler(int initialDelay, int frequencyInterval, TimeUnit unit, OPERATOR role)
            throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, role.toString(),
                "Received restart job list scheduler with initialDelay:frequencyInterval:Unit =" + initialDelay + ":"
                        + frequencyInterval + ":" + unit.toString());
        RDTProcessingServer.getInstance().restartJobListScheduler(initialDelay, frequencyInterval, unit, role);
        return true;
    }

    /**
     * Restarts the planned move scheduler
     */
    @Override
    public boolean restartPlannedMovesScheduler(int initialDelay, int frequencyInterval, TimeUnit unit)
            throws RemoteException {
        logger.logMsg(LOG_LEVEL.INFO, "",
                "Received restart planned moves scheduler with initialDelay:frequencyInterval:Unit =" + initialDelay
                        + ":" + frequencyInterval + ":" + unit.toString());
        RDTProcessingServer.getInstance().restartPlannedMovesScheduler(initialDelay, frequencyInterval, unit);
        return true;
    }
}
