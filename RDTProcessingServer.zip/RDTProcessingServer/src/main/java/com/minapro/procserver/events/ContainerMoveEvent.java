package com.minapro.procserver.events;

import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.util.logging.MinaProApplicationLogger;

/**
 * ValueObject holding the details about container movement
 * 
 * @author Rosemary George
 *
 */
public class ContainerMoveEvent extends Event implements Serializable {
    private static final long serialVersionUID = 2593293221995672513L;

    private static String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(ContainerMoveEvent.class);

    /**
     * Can be at most two container IDs- applicable in twin lift case
     */
    private List<String> containerIDs;

    /**
     * the source location of the container- can be vessel, ITV ID or Yard location depending on the context Can also
     * contain at most tow locations in case of twin lift case
     */
    private List<String> fromLocations;

    /**
     * The destination location of the container - can be vessel, ITV ID or Yard location depending on the context Can
     * also contain at most tow locations in case of twin lift case
     */
    private List<String> toLocations;

    /**
     * Flag - to check whether it is automatic job confirmation from PLC or Manual job confirm
     */
    private boolean automaticFlag = false;

    /**
     * Indicates whether it is discharge or load operation.
     */
    private String moveType;

    /**
     * Indicates whether the container seal is ok or not.
     */
    private List<String> sealOk;
    
    /**
     * The troubleshoot areas selected for the container. This can be empty too.
     * If there are multiple containers, there can be that many tsAreas depending on the seal status of the container.
     */
    private List<String> tsAreas;
    
    private List<String> doorDirection;
    
    /**
     * If true  -Indicates that the event is raised as pre job confirmation. 
     */
    private boolean preJobConfirmation;
    
    /**
     * plc derived cell location for this move - filled only in auto confirm mode
     */
    private String plcDerivedLocation;
    
    /**
     * plc Derived job type(SINGLE/TWIN/TANDEM) of this move - filled only in auto confirm mode
     */
    private String plcDerivedJobType;
    
    /**
     * positionOnChassis Fore or Aft Flag e.g) Fore="F", Aft="A",Center="C" otherwise:""
     */
    private List<String> position;
    
    public List<String> getPosition() {
		return position;
	}
    
    public void setPosition(List<String> position) {
		this.position = position;
    }
    
	public void setPosition(String position) {
		try {
            String[] pos = position.split("\\" + rowSeparator);
            this.position = new ArrayList<String>(Arrays.asList(pos));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting positionOnChasis Information:", ex);
            this.position = new ArrayList<String>();
        }		
	}

    public String getPlcDerivedJobType() {
		return plcDerivedJobType;
	}

	public void setPlcDerivedJobType(String plcDerivedJobType) {
		this.plcDerivedJobType = plcDerivedJobType;
	}

	public boolean isPreJobConfirmation() {
		return preJobConfirmation;
	}

	public void setPreJobConfirmation(boolean preJobConfirmation) {
		this.preJobConfirmation = preJobConfirmation;
	}
	
	public String getPlcDerivedLocation() {
		return plcDerivedLocation;
	}

	public void setPlcDerivedLocation(String plcDerivedLocation) {
		this.plcDerivedLocation = plcDerivedLocation;
	}

	public List<String> getDoorDirection() {
		return doorDirection;
	}

	public void setDoorDirection(String doorDirection) {
		try {
            String[] doorDir = doorDirection.split("\\" + rowSeparator);
            this.doorDirection = new ArrayList<String>(Arrays.asList(doorDir));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting Door direction Information:", ex);
            this.doorDirection = new ArrayList<String>();
        }
	}

	public List<String> getTsAreas() {
        return tsAreas;
    }

    public void setTsAreas(String tsAreas) {
        try {
            String[] tsArea = tsAreas.trim().split("\\" + rowSeparator);
            this.tsAreas = new ArrayList<String>(Arrays.asList(tsArea));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting TS Area Information:", ex);
            this.tsAreas = new ArrayList<String>();
        }
    }

    public List<String> getSealOk() {
        return sealOk;
    }

    public void setSealOk(String sealOk) {
        try {
            String[] sealInfo = sealOk.split("\\" + rowSeparator);
            this.sealOk = new ArrayList<String>(Arrays.asList(sealInfo));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting Seal Information:", ex);
            this.sealOk = new ArrayList<String>();
        }
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public List<String> getContainerIDs() {
        return containerIDs;
    }

    public void setContainerIDs(String containerIDs) {
        try {
            String[] containers = containerIDs.split("\\" + rowSeparator);
            this.containerIDs = new ArrayList<String>(Arrays.asList(containers));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting container IDs:", ex);
            this.containerIDs = new ArrayList<String>();
        }
    }

    public List<String> getFromLocations() {
        return fromLocations;
    }

    public void setFromLocations(String fromLocations) {
        try {
            String[] fromLocation = fromLocations.split("\\" + rowSeparator);
            this.fromLocations = new ArrayList<String>(Arrays.asList(fromLocation));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting From location:", ex);
            this.fromLocations = new ArrayList<String>();
        }
    }

    public List<String> getToLocations() {
        return toLocations;
    }

    public void setToLocations(String toLocations) {
        try {
            String[] toLocation = toLocations.split("\\" + rowSeparator);
            this.toLocations = new ArrayList<String>(Arrays.asList(toLocation));
        } catch (Exception ex) {
            logger.logException("Caught exception while setting To Locations:", ex);
            this.toLocations = new ArrayList<String>();
        }
    }

    public boolean isAutomaticFlag() {
        return automaticFlag;
    }

    public void setAutomaticFlag(boolean automaticFlag) {
        this.automaticFlag = automaticFlag;
    }

	@Override
	public String toString() {
		return "ContainerMoveEvent [containerIDs=" + containerIDs + ", fromLocations=" + fromLocations
				+ ", toLocations=" + toLocations + ", automaticFlag=" + automaticFlag + ", moveType=" + moveType
				+ ", sealOk=" + sealOk + ", tsAreas=" + tsAreas + ", doorDirection=" + doorDirection
				+ ", preJobConfirmation=" + preJobConfirmation + ", plcDerivedLocation=" + plcDerivedLocation + ", position=" + position
				+ ", UserID()=" + getUserID() + ", EquipmentID()=" + getEquipmentID() + ", EventID()="
				+ getEventID() + "]";
	}
}
