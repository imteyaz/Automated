package com.minapro.procserver.db.damage;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the damage recording details from the database
 * 
 * @author kalyani
 * 
 */
@Entity
@Table(name = "MP_DAMAGE_RECORDING")
public class DamageRecording implements Serializable {

    private static final long serialVersionUID = 6009701438542882546L;

    @Id
    @SequenceGenerator(name = "damage_seq_gen", sequenceName = "MP_DAMAGE_ID_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "damage_seq_gen")
    @Column(name = "DAMAGE_ID")
    private Integer damageId;
        
    @Column(name = "DAMAGE_CODE")
    private String damageCode;
     
    @Column(name = "CONTAINER_ID")
    private String containerId;

    @Column(name = "TERMINAL_ID")
    private String  terminalId;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    @Column(name = "DAMAGE_LOCATION_CODE")
    private String damageLocationCode;

    @Column(name = "DAMAGE_REMARKS")
    private String damageRemarks;

    @Column(name = "CREATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDatetime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDatetime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "ISDELETED")
    private String isDeleted;

    public String getDamageCode() {
        return damageCode;
    }

    public void setDamageCode(String damageCode) {
        this.damageCode = damageCode;
    }

    public Integer getDamageId() {
        return damageId;
    }

    public void setDamageId(Integer damageId) {
        this.damageId = damageId;
    }

   
    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

  

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getDamageLocationCode() {
        return damageLocationCode;
    }

    public void setDamageLocationCode(String damageLocationCode) {
        this.damageLocationCode = damageLocationCode;
    }

    public String getDamageRemarks() {
        return damageRemarks;
    }

    public void setDamageRemarks(String damageRemarks) {
        this.damageRemarks = damageRemarks;
    }

    public Date getCreatedDatetime() {
        return createdDatetime;
    }

    public void setCreatedDatetime(Date createdDatetime) {
        this.createdDatetime = createdDatetime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDatetime() {
        return lastUpdatedDatetime;
    }

    public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
        this.lastUpdatedDatetime = lastUpdatedDatetime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "DamageRecording [damageCode=" + damageCode + ", damageId=" + damageId + ", containerId=" + containerId
                + ", terminalId=" + terminalId + ", rotationId=" + rotationId + ", damageLocationCode="
                + damageLocationCode + ", damageRemarks=" + damageRemarks + ", createdDatetime=" + createdDatetime
                + ", createdBy=" + createdBy + ", lastUpdatedDatetime=" + lastUpdatedDatetime + ", lastUpdatedBy="
                + lastUpdatedBy + ", isDeleted=" + isDeleted + "]";
    }

}
