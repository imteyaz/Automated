package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the container inquiry request from the UI.
 * 
 * @author Rosemary George
 *
 */
public class ContainerInquiryEvent extends Event implements Serializable{

    private static final long serialVersionUID = 1826808177158504338L;
    
    /**
     * ID of the container which is requested by UI
     */
    private String containerId;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    @Override
    public String toString() {
        return "ContainerInquiryEvent [containerId=" + containerId + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }    
}
