package com.minapro.procserver.actors;

import static com.minapro.procserver.util.RDTProcessingServerConstants.HEAVY_HOOK;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.RDTVesselProfileCacheManager;
import com.minapro.procserver.db.CompletedContainerMoves;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p>Actor responsible for evaluating the HeavyHook QC operator.</p>
 * 
 * <p> The Actor will be run every 5 minutes and monitor the current job list for all the logged in QC operators and
 * identify the operator with maximum jobs present. Sends the heavy hook indication to the operator. If the operator is
 * different from the last identified one, sends a no-longer heavy hook indication to the previous operator.</p>
 * 
 * @author Rosemary George
 *
 */
public class HeavyHookActor extends UntypedActor {
    
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(HeavyHookActor.class);
    
    private static final String MEMORY_STATUS = "----MEMORY STATUS----";
    private static final String MEMORY_FOOTPRINT = "****************** RDT - MEMORY FOOT PRINT ********************";

    @Override
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.DEBUG, "", "Checking for the heavy hook operator");

        try {
        	identifyHeavyHookUsersForRotation();            
        } catch (Exception ex) {
            logger.logException("Caught exception while performing heavyhook check -", ex);
        }

        logger.logMsg(LOG_LEVEL.DEBUG, "", "Checking for the heavy hook operator is completed");
        
        logger.logMsg(LOG_LEVEL.INFO, "", MEMORY_FOOTPRINT);
        logger.logMsg(LOG_LEVEL.INFO, MEMORY_STATUS, "Max memory: " + Runtime.getRuntime().maxMemory() / 1024);
        logger.logMsg(LOG_LEVEL.INFO, MEMORY_STATUS, "Allocated memory for RDT: " + Runtime.getRuntime().totalMemory() / 1024);
        logger.logMsg(LOG_LEVEL.INFO, MEMORY_STATUS, "Free memory after RDT consumption : " + Runtime.getRuntime().freeMemory() / 1024);
        logger.logMsg(LOG_LEVEL.INFO, "", MEMORY_FOOTPRINT);
    }

    /**
     * Constructs and sends the heavy hook alert to master actor for further processing
     * @param newHeavyHook
     */
    private void generateHeavyHookAlert(String newHeavyHook) {
		MinaProAlertEvent alert = new MinaProAlertEvent();
		alert.setAlertCode(ALERTCODE.HEAVY_HOOK_ALERT);
		
		ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(newHeavyHook);
		alert.setEquipmentID(allocationDetails.getEquipmentID());		
		alert.setUserID(newHeavyHook);
		alert.setOperatorId(newHeavyHook);
		
		logger.logMsg(LOG_LEVEL.INFO, newHeavyHook, " Raising Heavyhook Alert");
		RDTProcessingServer.getInstance().getMasterActor().tell(alert, null);
	}

	/**
     * Identifies the HC user mapped to the specified qc operator and generates the heavy hook status notification to HC
     * 
     * @param qcUser
     * @param status
     */
    private void updateHCUser(String qcUser, boolean status) {
        ConfirmAllocationEvent allocationDetails = (ConfirmAllocationEvent) RDTCacheManager.getInstance()
                .getAllocationDetails(qcUser);
        String hcUserId = RDTCacheManager.getInstance().getHCUserAllocatedForQC(allocationDetails.getEquipmentID());
        if (hcUserId != null) {
            logger.logMsg(LOG_LEVEL.DEBUG, qcUser + ":" + hcUserId,
                    "Identified the HC user and informing heavyhook status as " + status);
            sendHeavyHookMessage(hcUserId, status);
        }
    } 
    
    /**
     * Identifies the heavy hook equipment for all the berthed vessels.
     * Heavy hook is calculated as the QC which is having the highest MovesToGo value for the rotation.
     * 
     * MovesToGo = planned moves - completed moves by QC.
     * 
     */
    private void identifyHeavyHookUsersForRotation(){
    	String qcUser = null, heavyHookQcId = null, heavyHookUser = null;
    	int highestMTG = 0;
    	int plannedMoves = 0;
    	int movesToGo = 0;
    	Map<String, CompletedContainerMoves> completedJobsListForQc = null;
    	ConfirmAllocationEvent allocationDetails = null;
    	
    	Set<String>  berthedVessels = RDTVesselProfileCacheManager.getInstance().getBerthedRotationList();
    	if(berthedVessels != null && !berthedVessels.isEmpty()){
    		List<String> rotationWiseQcList;
    		for(String rotation : berthedVessels){
    			rotationWiseQcList = RDTVesselProfileCacheManager.getInstance().getQCsAllocatedForRotation(rotation);
    			heavyHookQcId = null;
    			heavyHookUser = null;
				highestMTG = 0;
				
    			if(rotationWiseQcList != null && !rotationWiseQcList.isEmpty()){    				
    				for(String qcId : rotationWiseQcList){
    					qcUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(qcId);
    					
    					if(qcUser != null){
    						allocationDetails = (ConfirmAllocationEvent)RDTCacheManager.getInstance().getAllocationDetails(qcUser);
    						if(allocationDetails != null && rotation.equalsIgnoreCase(allocationDetails.getRotationID())){
    							plannedMoves = RDTPLCCacheManager.getInstance().getPlannedMovesCount(qcId);
    	    					completedJobsListForQc = RDTCacheManager.getInstance().getCompletedJobs(rotation, qcId);
    	    					movesToGo = plannedMoves;
    	    					if(completedJobsListForQc != null){
    	    						movesToGo = plannedMoves - completedJobsListForQc.size();
    	    					}
    	    					
    	    					if(movesToGo > 0 && movesToGo >highestMTG){
    	    						heavyHookQcId = qcId;
    	    						highestMTG = movesToGo;
    	    						heavyHookUser = qcUser;
    	    					}
    						}
    					}   					
    				}    				
    				
    				if(heavyHookQcId != null) {
    					logger.logMsg(LOG_LEVEL.INFO, rotation, "Identified heavy hook for rotation is " 
        						+ heavyHookQcId + " with MTG=" + highestMTG);
    					performHeavyHookMarking(rotation, heavyHookQcId, heavyHookUser);    									
    				}    				
    			}else {
    				logger.logMsg(LOG_LEVEL.INFO, rotation, "No QCs allocated for the rotation. No Heavy hook checking performed");
    			}
    		}
    	}else {
    		logger.logMsg(LOG_LEVEL.INFO, "", "Currently no Berthed Vessels present in the system.");
    	}
    }
    
    /**
     * Sends heavy hook alert for the new heavy hook equipment and its logged in users like QC and HC operator.
     * And sends ho longer heavy hook alert to previous heavy hook equipment and its users.
     * 
     * @param rotation
     * @param heavyHookQC
     * @param heavyHookUser
     */
    private void performHeavyHookMarking(String rotation, String heavyHookQC, String heavyHookUser){
    	String previousHeavyHookQcId = RDTVesselProfileCacheManager.getInstance().getHeavyHookUser(rotation);
		if(heavyHookQC.equalsIgnoreCase(previousHeavyHookQcId)){
			logger.logMsg(LOG_LEVEL.DEBUG, rotation, "No Change in the heavy hook, still " 
					+ heavyHookQC + " is heavyhook");
		}else {
			boolean heavyHookMessageSent = sendHeavyHookMessage(heavyHookUser, true);
            if (heavyHookMessageSent) {
                updateHCUser(heavyHookUser, true);
            	generateHeavyHookAlert(heavyHookUser);
            }
			if(previousHeavyHookQcId != null && heavyHookMessageSent){
				String perviousheavyHookUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(previousHeavyHookQcId);
				if(perviousheavyHookUser != null){
					sendHeavyHookMessage(perviousheavyHookUser, false);
					updateHCUser(perviousheavyHookUser, false);
				}
			}
			
			RDTVesselProfileCacheManager.getInstance().addHeavyHookUser(rotation, heavyHookQC);
		}    	
    }

    /**
     * Sends the heavy hook alert to the user.
     * 
     * @param heavyHookUser
     *            - the user to whom the alert needs to be send
     * @param status
     *            - true indicates user is the current heavy hook operator. false indicates that the operator is no
     *            longer heavy hook operator
     */
    private boolean sendHeavyHookMessage(String heavyHookUser, boolean status) {

        String inspectionStatus = RDTCacheManager.getInstance().getInspectionStatus(heavyHookUser);
        String terminalId = DeviceCommParameters.getInstance().getCommParameter(
                RDTProcessingServerConstants.TERMINAL_KEY);

        if (inspectionStatus != null) {
            String eventTypeID = DeviceEventTypes.getInstance().getEventType(HEAVY_HOOK);

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(HEAVY_HOOK);

            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append(valueSeperator).append(eventTypeID);

            String msgField;
            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                msgField = msgFields.get(i);

                if ("EventID".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(UUID.randomUUID());
                } else if ("Status".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(status);
                } else if ("UserID".equalsIgnoreCase(msgField)) {
                    responseToDevice.append(heavyHookUser);
                } else {
                    responseToDevice.append(terminalId);
                }
            }

            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(heavyHookUser);
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
                    terminalId);
            return true;
        } else {
            logger.logMsg(LOG_LEVEL.INFO, heavyHookUser,
                    "Skip sending heavyhook alert as pre-operational inspection is not completed.");
            return false;
        }
    }
}
