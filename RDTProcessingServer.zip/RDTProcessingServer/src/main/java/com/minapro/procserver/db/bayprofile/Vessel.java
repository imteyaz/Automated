package com.minapro.procserver.db.bayprofile;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * ValueObject holding the vessel details
 * 
 * @author Rosemary George
 *
 */
@Entity
@Table(name = "MP_VSL_SPM")
public class Vessel implements Serializable, Comparable<Vessel> {

    private static final long serialVersionUID = -8754249159018501078L;

    @Id
    @Column(name = "INT_VSL_NO", nullable = false)
    private Integer vesselNo;

    @Column(name = "VSL_CD")
    private String vesselCode;

    @Column(name = "VSL_NM")
    private String vesselName;

    @Column(name = "VSL_TYPE")
    private String vesselType;

    @Column(name = "MTHR_FEEDR_IND")
    private char motherFeeder;

    @Column(name = "OVRALL_LEN")
    private int length;

    @Column(name = "OVRALL_LEN_UOM")
    private String lengthUom;

    @Column(name = "VSL_WD")
    private int width;

    @Column(name = "VSL_WD_UOM")
    private String widthUom;

    @Column(name = "VSL_HT")
    private int height;

    @Column(name = "TEU_CPCTY")
    private int teuCapacity;

    @Column(name = "MAX_NO_ROWS")
    private int maxNoOfRows;

    @Transient
    private String rotationId;
    
    @Transient
    private String voyageNo;
    
    @Transient
    private String vesselNameFromTos;

    public String getVoyageNo() {
		return voyageNo;
	}

	public void setVoyageNo(String voyageNo) {
		this.voyageNo = voyageNo;
	}

	public String getVesselNameFromTos() {
		return vesselNameFromTos;
	}

	public void setVesselNameFromTos(String vesselNameFromTos) {
		this.vesselNameFromTos = vesselNameFromTos;
	}

	public int getMaxNoOfRows() {
        return maxNoOfRows;
    }

    public void setMaxNoOfRows(int maxNoOfRows) {
        this.maxNoOfRows = maxNoOfRows;
    }

    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(int vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getVesselName() {
        return vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }

    public String getVesselType() {
        return vesselType;
    }

    public void setVesselType(String vesselType) {
        this.vesselType = vesselType;
    }

  
    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getLengthUom() {
        return lengthUom;
    }

    public char getMotherFeeder() {
		return motherFeeder;
	}

	public void setMotherFeeder(char motherFeeder) {
		this.motherFeeder = motherFeeder;
	}

	public void setLengthUom(String lengthUom) {
        this.lengthUom = lengthUom;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public String getWidthUom() {
        return widthUom;
    }

    public void setWidthUom(String widthUom) {
        this.widthUom = widthUom;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getTeuCapacity() {
        return teuCapacity;
    }

    public void setTeuCapacity(int teuCapacity) {
        this.teuCapacity = teuCapacity;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((rotationId == null) ? 0 : rotationId.hashCode());
        result = prime * result + ((vesselCode == null) ? 0 : vesselCode.hashCode());
        result = prime * result + vesselNo;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Vessel other = (Vessel) obj;
        if (rotationId == null) {
            if (other.rotationId != null) {
                return false;
            }
        } else if (!rotationId.equals(other.rotationId)) {
            return false;
        }
        if (vesselCode == null) {
            if (other.vesselCode != null) {
                return false;
            }
        } else if (!vesselCode.equals(other.vesselCode)) {
            return false;
        }
        if (vesselNo != other.vesselNo) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Vessel anotherVessel) {
        if (this.vesselNo == anotherVessel.vesselNo && this.vesselCode.equals(anotherVessel.vesselCode)
                && this.rotationId.equals(anotherVessel.rotationId)) {
            return 0;
        } else {
            return 1;
        }
    }

	@Override
	public String toString() {
		return "Vessel [vesselNo=" + vesselNo + ", vesselCode=" + vesselCode + ", vesselName=" + vesselName
				+ ", motherFeeder=" + motherFeeder + ", rotationId=" + rotationId + ", voyageNo=" + voyageNo
				+ ", opusVesselName=" + vesselNameFromTos + "]";
	}    
}
