package com.minapro.procserver.events.shf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * @author UMAMAHESH M
 *
 */
public class SHFPinningStationAllocationChangeEvent extends Event implements Serializable {

    private static final long serialVersionUID = -5499480157075497165L;

    private String qcChangedPinningStations;

    /**
     * @return the qcChangedPinningStations
     */
    public String getQcChangedPinningStations() {
        return qcChangedPinningStations;
    }

    /**
     * @param qcChangedPinningStations
     *            the qcChangedPinningStations to set
     */
    public void setQcChangedPinningStations(String qcChangedPinningStations) {
        this.qcChangedPinningStations = qcChangedPinningStations;
    }

    @Override
    public String toString() {
        return "SHFPinningStationAllocationChangeEvent [qcsWithChangePinningStations=" + qcChangedPinningStations
                + ",UserID=" + getUserID() + ",EquipmentID=" + getEquipmentID() + ",TerminalID=" + getTerminalID()
                + "]";
    }
}
