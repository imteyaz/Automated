package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class TechSupportValuesEvent extends Event implements Serializable {

    private static final long serialVersionUID = -8137896434628167024L;

    private String location;

    private String problemCodes;

    private String problemDescription;

    private String locationDescription;

    private String assetNumber;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getProblemCodes() {
        return problemCodes;
    }

    public void setProblemCodes(String problemCodes) {
        this.problemCodes = problemCodes;
    }

    public String getProblemDescription() {
        return problemDescription;
    }

    public void setProblemDescription(String problemDescription) {
        this.problemDescription = problemDescription;
    }

    public String getLocationDescription() {
        return locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public String getAssetNumber() {
        return assetNumber;
    }

    public void setAssetNumber(String assetNumber) {
        this.assetNumber = assetNumber;
    }

    @Override
    public String toString() {
        return "TechSupportValuesEvent [location=" + location + ", problemCodes=" + problemCodes
                + ", problemDescription=" + problemDescription + ", locationDescription=" + locationDescription
                + ", assetNumber=" + assetNumber + "]";
    }
}
