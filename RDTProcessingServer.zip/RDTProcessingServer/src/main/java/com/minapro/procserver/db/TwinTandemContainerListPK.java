package com.minapro.procserver.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * ValueObject holding the Primary Key for the Twin Tandem container details
 * @author Rosemary George
 *
 */
@Embeddable
public class TwinTandemContainerListPK implements Serializable{

    private static final long serialVersionUID = -318226177007446619L;

    @ManyToOne
    @JoinColumn(name = "TWINTANDEM_ID")
    private TwinTandemJobs twinTandemId;
     
    @Column(name="CONTAINER_ID")
    private String containerId;

    public TwinTandemJobs getTwinTandemId() {
        return twinTandemId;
    }

    public void setTwinTandemId(TwinTandemJobs twinTandemId) {
        this.twinTandemId = twinTandemId;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }
}
