package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the vessel berthing side request event details
 * 
 * @author Rosemary George
 *
 */
public class VesselBerthSideRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -2869692706009117741L;

    /**
     * Indicates the current rotation id of the vessel
     */
    private String rotationId;

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    @Override
    public String toString() {
        return "VesselBerthSideRequestEvent [rotationId=" + rotationId + ", UserID=" + getUserID() + ", EquipmentID="
                + getEquipmentID() + "]";
    }

}
