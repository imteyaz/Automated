package com.minapro.procserver.cep.che;

import java.util.Map;

import org.apache.commons.collections4.map.ListOrderedMap;

import akka.actor.ActorRef;

import com.minapro.procserver.RDTProcessingServer;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cep.StatementSubscriber;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.plc.CHEPLCJobdoneEvent;
import com.minapro.procserver.events.plc.EsperRMGPLCEvent;
import com.minapro.procserver.util.MinaproLoggerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Class responsible for detecting RMG PLC Job done event </p>
 * 
 * <p>Listener sends the container move event to Master Actor and also sends alerts in case of Container Weight
 * missmatch, Wrong container Picked and Wrong cell detected also pushes Events to master actor on every container move
 * event to calculate the CHE Live performance</p>
 * 
 * <p> Pushes every container move event to master actor to detect the Delay Recording <p>
 * 
 * @author Kumaraswamy
 * 
 */
public class CHEJobDoneSubscriber implements StatementSubscriber {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobDoneSubscriber.class);

    private ActorRef masterActor;

    public CHEJobDoneSubscriber() {
        this.masterActor = RDTProcessingServer.getInstance().getMasterActor();
    }

    @Override
    public String getStatement() {

	        // CHE Job done EPL Statement
//    	return "context EachCHE select a,b from pattern [ "
//        + "every ( (a=EsperRMGPLCEvent(spreader1TwistLock = 1 )) "
//        + "-> ((b=EsperRMGPLCEvent(spreader1TwistLock = 0)) and not (EsperRMGPLCEvent(spreader1TwistLock = 1 )) ) ) ]";
//    
    	/*return "context EachCHE select a,b from pattern [ "
        + "every ( (b=EsperRMGPLCEvent(spreader1TwistLock = 1 )) "
		 + "-> ( (a=EsperRMGPLCEvent(spreaderLsWeight > 0)) or "
                + "(a=EsperPLCEvent(spreaderLsWeight < 0))) "
        + "-> ((b=EsperRMGPLCEvent(spreader1TwistLock = 0 and spreaderLsWeight = 0)) ) ) ]";*/
    	
    	return "context EachCHE select event1,event2 from pattern[every ( (event1=EsperRMGPLCEvent(spreader1TwistLock = 1))"
		 + "-> ((event2=EsperRMGPLCEvent(spreader1TwistLock = 0)) ) )  ]";
    	
    }

    /**
     * Listener gets called on receiving the Job done event
     * 
     * @param eventMap
     */
    public void update(Map<String, EsperRMGPLCEvent> eventMap) {

        EsperRMGPLCEvent plc1 = eventMap.get("event1");
        EsperRMGPLCEvent plc2 = eventMap.get("event2");
        double weight = Double.valueOf(plc1.getSpreaderLsWeight());
        String containerWeight = Double.toString(weight);
        
		logger.logMsg(LOG_LEVEL.DEBUG, " ","CHE Before UnLock Event :: "+plc1);
        logger.logMsg(LOG_LEVEL.DEBUG, " ","CHE After Unlock Event :: "+plc2);      
        
        String node = plc1.getNode();
        String userId = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(node);
        RDTPLCCacheManager.getInstance().addContainerLiftedDetails(userId,
				false);
        
        if (userId != null) {

            StringBuilder sb = new StringBuilder();
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);
            sb.append("\n* JOB DONE DETECTED OF USER " + userId + " ON " + node);
            sb.append(MinaproLoggerConstants.LINE_FORMATTER);
            logger.logMsg(LOG_LEVEL.DEBUG, " ", sb.toString());
			logger.logMsg(LOG_LEVEL.DEBUG, " ","CHE Lock Event :: "+plc1);
            logger.logMsg(LOG_LEVEL.DEBUG, " ","CHE Unlock Event :: "+plc2);            
            CHEPLCJobdoneEvent jobDoneEvent = new CHEPLCJobdoneEvent();
            jobDoneEvent.setEquipmentID(node);
            
            jobDoneEvent.setNode(node);
            jobDoneEvent.setUserId(userId);
            jobDoneEvent.setContainerWeight(containerWeight);

            jobDoneEvent.setLockTime(plc1.getTagTime());
            jobDoneEvent.setUnlockTime(plc2.getTagTime());

            jobDoneEvent.setLockYardPosition(plc1.getYardPos());
            jobDoneEvent.setUnLockYardPosition(plc2.getYardPos());
            jobDoneEvent.setMoveYardPosition(plc2.getLaneId());
            
            jobDoneEvent.setLockSpreaderWeight(Double.valueOf(plc1.getSpreaderLsWeight()));
            jobDoneEvent.setUnLockSpreaderWeight(Double.valueOf(plc2.getSpreaderLsWeight()));
            jobDoneEvent.setLockTrollyPosition(Double.valueOf(plc1.getTrolleyPos()));
            jobDoneEvent.setMoveTrollyPosition(Double.valueOf(plc2.getTrolleyPos()));
            logger.logMsg(LOG_LEVEL.DEBUG, userId, "CHE SENDING JOB DONE TO ACTOR");

            // Check for Joblist is Empty or Not
            ListOrderedMap<String, JobListContainer> jobList = RDTCacheManager.getInstance().getJobList(userId, node);

            // Check for Joblist is Empty or Not
            if (jobList!=null && !jobList.isEmpty()) {
                masterActor.tell(jobDoneEvent, null);
            } else {
                logger.logMsg(LOG_LEVEL.DEBUG, userId, " CHE JOB List is Empty");
            }

        }
    }
}
