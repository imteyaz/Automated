package com.minapro.procserver.util;

import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import scala.collection.mutable.StringBuilder;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.db.CheWeightageFactorEntity;
import com.minapro.util.logging.MinaProApplicationLogger;

public class CHEJobListSequnceCalculator implements CHEJobListSequenceCalulatorInterface {

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEJobListSequnceCalculator.class);
	
	private static final CHEJobListSequnceCalculator INSTANCE = new CHEJobListSequnceCalculator();

	private CHEJobListSequnceCalculator() {

	}

	public static CHEJobListSequnceCalculator getInstance() {
		return INSTANCE;
	}

	public double getMoveKindComputedValue(WeightageCriteria weightageCriteria) {

		return getWeightageFactorByTypeAndCriteria(WeightageType.MOVE_TYPE, weightageCriteria);

	}

	public double getContainerTypeComputedValue(WeightageCriteria weightageCriteria) {

		return getWeightageFactorByTypeAndCriteria(WeightageType.CONTAINER_TYPE, weightageCriteria);
		
	}

	public double getContainerSizeComputedValue(WeightageCriteria weightageCriteria) {

		return getWeightageFactorByTypeAndCriteria(WeightageType.CONTAINER_SIZE, weightageCriteria);

	}

	public double getContaierStatusComputedValue(WeightageCriteria weightageCriteria) {

		return getWeightageFactorByTypeAndCriteria(WeightageType.CONTAINER_STATUS, weightageCriteria);
	}

	public double getVesselTypeComuptedValue(WeightageCriteria weightageCriteria) {

		return getWeightageFactorByTypeAndCriteria(WeightageType.VESSEL_TYPE, weightageCriteria);

	}

	public double getVesselLocationComputedValue(WeightageCriteria weightageCriteria) {
		
		return getWeightageFactorByTypeAndCriteria(WeightageType.VESSEL_LOCATION, weightageCriteria);

	}


	public double getWeightageFactorByTypeAndCriteria(WeightageType type, WeightageCriteria criteria) {

		try {
			CheWeightageFactorEntity entity = RDTCacheManager.getInstance().getCheWeightageDetailsFromCache(type,criteria);
			return entity!=null ? entity.getWeightageFactor() * entity.getWeightageScore() : 0.0;

		} catch (Exception ex) {
			logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" While Calculating Weightage Type")
					.append(type).append(" Criteria::").append(criteria).append(REASON).toString(), ex);
			return 0;
		}
	}

}
