package com.minapro.procserver.db.yardview;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * NumsrsdtlsYpm entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "MP_NUMSRSDTLS_YPM")
public class NumsrsdtlsYpm implements java.io.Serializable {

    private static final long serialVersionUID = -5238749056532988053L;
    @EmbeddedId
    @AttributeOverrides({
            @AttributeOverride(name = "numsrsId", column = @Column(name = "NUMSRS_ID", nullable = false, length = 5)),
            @AttributeOverride(name = "seqNo", column = @Column(name = "SEQ_NO", nullable = false, precision = 6, scale = 0)) })
    private NumsrsdtlsYpmId id;

    @Column(name = "NO_20FT")
    private String no20ft;

    @Column(name = "NO_40FT")
    private String no40ft;

    public NumsrsdtlsYpmId getId() {
        return this.id;
    }

    public void setId(NumsrsdtlsYpmId id) {
        this.id = id;
    }

    public String getNo20ft() {
        return this.no20ft;
    }

    public void setNo20ft(String no20ft) {
        this.no20ft = no20ft;
    }

    public String getNo40ft() {
        return this.no40ft;
    }

    public void setNo40ft(String no40ft) {
        this.no40ft = no40ft;
    }

}