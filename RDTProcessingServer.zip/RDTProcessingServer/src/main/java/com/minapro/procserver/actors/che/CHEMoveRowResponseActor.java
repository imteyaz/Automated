package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ALERT_MESSAGE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.CHE_MOVED_TO_ROW;
import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.OF_YARD_LOCATION;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.plc.CHERowChangeDetectionEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Class is used to send message to UI for CHE Row move in yard block.
 * 
 * @author Kumaraswamy.
 *
 */
public class CHEMoveRowResponseActor extends UntypedActor {
    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(CHEMoveRowResponseActor.class);

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);

    @Override
    public void onReceive(Object message) throws Exception {
        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(ON_RECEIVE).toString());
        if (message instanceof CHERowChangeDetectionEvent) {
            sendRowMoveInYardBlockResponseMessage((CHERowChangeDetectionEvent) message);
        } else {
            unhandled(message);
        }
    }

    private void sendRowMoveInYardBlockResponseMessage(CHERowChangeDetectionEvent cheRowChangeDetectionEvent) {

    	try {
    		logger.logMsg(LOG_LEVEL.INFO, "", "Sending message CHE row move in Yard Location ");
    		String userId = cheRowChangeDetectionEvent.getUserID();
    		String rowPosition = cheRowChangeDetectionEvent.getRowPosition();
    		String yardPosition = cheRowChangeDetectionEvent.getYardPosition();
    		String eventTypeID = DeviceEventTypes.getInstance().getEventType(ALERT_MESSAGE);
    		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    		String dateString = formatter.format(new Date());
    		// build the response to the device
    		StringBuilder responseToDevice = new StringBuilder(NOTIF).append(VALUE_SEPERATOR).append(eventTypeID);
    		
    		responseToDevice.append(VALUE_SEPERATOR).append(UUID.randomUUID().toString()).append(VALUE_SEPERATOR);
    		responseToDevice.append(dateString);
    		responseToDevice.append(CHE_MOVED_TO_ROW + rowPosition + OF_YARD_LOCATION + yardPosition);
    		responseToDevice.append(VALUE_SEPERATOR + "false" +VALUE_SEPERATOR).append(userId);
    		responseToDevice.append(VALUE_SEPERATOR + cheRowChangeDetectionEvent.getTerminalID());
    		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.CHE,
    				cheRowChangeDetectionEvent.getTerminalID());

    	} catch (Exception ex) {
            logger.logException("Error while Sending message CHE row move in Yard Location ", ex);

        }
    }
}
