package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the call itv message from UI
 * @author Rosemary George
 *
 */
public class CallITVEvent extends Event implements Serializable{

	private static final long serialVersionUID = 3879130820255366059L;

	//Contains the code sent by UI
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "CallITVEvent [code=" + code + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
				+ ", getEventID()=" + getEventID() + "]";
	}	
}
