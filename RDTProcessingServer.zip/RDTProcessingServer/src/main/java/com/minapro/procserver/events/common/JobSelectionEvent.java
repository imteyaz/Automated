package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the job selection request from UI. 
 * In case of Twin/Tandem containers, the first container will be sent as selected. 
 * But all the containers part of the TWIN/TANDEM is considered selected.
 * 
 * @author Rosemary George
 *
 */
public class JobSelectionEvent extends Event implements Serializable{

	private static final long serialVersionUID = -8339661472755314753L;
	
	private String containerId;
	
	private String moveType;
	
	/*
	 * isJobListRefreshRequired = true means ESB needs to initiate the 
	 * CHE JobList request to OPUS after send JobSelectionRequest
	 */
	private boolean isJobListRefreshRequired;
	
	/**
	 * Based on the move type will be filled with from or to location.
	 */
	private String location;	
	
	public boolean isJobListRefreshRequired() {
		return isJobListRefreshRequired;
	}

	public void setJobListRefreshRequired(boolean isJobListRefreshRequired) {
		this.isJobListRefreshRequired = isJobListRefreshRequired;
	}	

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	@Override
	public String toString() {
		return "JobSelectionEvent [containerId=" + containerId + ", moveType=" + moveType + ", location=" + location
				+ ", UserID()=" + getUserID() + ", EquipmentID()=" + getEquipmentID() + ", EventID()="
				+ getEventID() + "]";
	}

}
