package com.minapro.procserver.db.opus.joblist;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
@Entity
@Table(name="MP_OPUS_QC_JOB_LIST")
public class OPUSQCJobListEntity implements Serializable{
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OpusQcJobListPK id;
	
	@Column(name="FROM_LOCATION")
	private String fromLocation;
	
	@Column(name="VESSEL_NAME")
	private String vesselName;

	@Column(name="JOB_KEY")
	private String jobKey;

	@Column(name="VOYAGE")
	private String voyage;

	@Transient
	private String minaproTwinSplit;
	
	@Column(name="TANDEM_CONTAINERS")
	private String tandemContainers;

	@Column(name="LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPDATED_DATETIME")
	private Date lastUpdatedDatetime;

	@Column(name="SEQ_NO")
	private double seqNo;

	@Column(name="TERMINAL_ID")
	private String terminalId;

	@Column(name="TO_LOCATION")
	private String toLocation;

	@Column(name="TWIN_TANDEM_CD")
	private String twinTandemCd;

	@Column(name="TWIN_TANDEM_ID")
	private String existedTwinTandemIdFromTable;

	@Column(name="JOB_QUEUE_NAME")
	private String jobWorkQueueName;

	@Column(name="JOB_QUEUE_SEQUENCE")
	private int jobWorkQueueSeqNo;
	
	@Column(name="REFERENCE_CONTAINER_ID")
	private String refContainerId;
	
	@Transient
	private String operationCode = "I";
	
	@Transient
	private boolean isCurJobModified;
	
	/**
	 * Following are the container attributes , Which are coming from OPUS API.
	 * As of now retrieving from PROMIS . If client asks to get from OPUS then map following props
	 * with database column names..
	 */
	private String categeory;
	private String iso;
	private String pod;
	private String status;
	private String wt;
	
	public OPUSQCJobListEntity() {
    }
	
	public boolean getIsCurJobModified() {
		return isCurJobModified;
	}

	public void setIsCurJobModified(boolean isCurJobModified) {
		this.isCurJobModified = isCurJobModified;
	}
	
	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	public String getVesselName() {
		return vesselName;
	}

	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}

	public String getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public String getVoyage() {
		return voyage;
	}

	public void setVoyage(String voyage) {
		this.voyage = voyage;
	}

	public String getMinaproTwinSplit() {
		return minaproTwinSplit;
	}

	public void setMinaproTwinSplit(String minaproTwinSplit) {
		this.minaproTwinSplit = minaproTwinSplit;
	}

	public String getRefContainerId() {
		return refContainerId;
	}

	public void setRefContainerId(String refContainerId) {
		this.refContainerId = refContainerId;
	}	

	public OpusQcJobListPK getId() {
		return this.id;
	}

	public void setId(OpusQcJobListPK id) {
		this.id = id;
	}

	public String getCategeory() {
		return this.categeory;
	}

	public void setCategeory(String categeory) {
		this.categeory = categeory;
	}


	public String getFromLocation() {
		return this.fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getIso() {
		return this.iso;
	}

	public void setIso(String iso) {
		this.iso = iso;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDatetime() {
		return this.lastUpdatedDatetime;
	}

	public void setLastUpdatedDatetime(Date lastUpdatedDatetime) {
		this.lastUpdatedDatetime = lastUpdatedDatetime;
	}

	public String getPod() {
		return this.pod;
	}

	public void setPod(String pod) {
		this.pod = pod;
	}

	public double getSeqNo() {
		return this.seqNo;
	}

	public void setSeqNo(double seqNo) {
		this.seqNo = seqNo;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTerminalId() {
		return this.terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getToLocation() {
		return this.toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getTwinTandemCd() {
		return this.twinTandemCd;
	}

	public void setTwinTandemCd(String twinTandemCd) {
		this.twinTandemCd = twinTandemCd;
	}

	public String getExistedTwinTandemIdFromTable() {
		return this.existedTwinTandemIdFromTable;
	}

	public void setExistedTwinTandemIdFromTable(String existedTwinTandemIdFromTable) {
		this.existedTwinTandemIdFromTable = existedTwinTandemIdFromTable;
	}

	public String getWt() {
		return this.wt;
	}

	public void setWt(String wt) {
		this.wt = wt;
	}

	@Override
	public String toString() {
		return "OPUSQCJobListEntity [Container=" + id.getContainerId() + ", equipmentId=" + id.getEquipmentId()
		        + ", fromLocation=" + fromLocation + ", Move Type=" + id.getMoveKind()
				+ ", jobKey=" + jobKey+ ", voyage=" + voyage + ", tandemContainers="+ tandemContainers + ", seqNo=" + seqNo + ", twinTandemCd="
				+ twinTandemCd + ", refContainerId=" + refContainerId + "]";
	}

	public String getTandemContainers() {
		return tandemContainers;
	}

	public void setTandemContainers(String tandemContainers) {
		this.tandemContainers = tandemContainers;
	}
	
	public String getJobWorkQueueName() {
		return jobWorkQueueName;
	}

	public void setJobWorkQueueName(String jobWorkQueueName) {
		this.jobWorkQueueName = jobWorkQueueName;
	}

	public int getJobWorkQueueSeqNo() {
		return jobWorkQueueSeqNo;
	}

	public void setJobWorkQueueSeqNo(int jobWorkQueueSeqNo) {
		this.jobWorkQueueSeqNo = jobWorkQueueSeqNo;
	}
}
