package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the Delete manual job request from device
 * 
 * @author Rosemary George
 *
 */
public class DeleteManualJobRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -4010834442490651449L;

    private String jobId;
    
    private String moveType;

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    @Override
    public String toString() {
        return "DeleteManualJobRequestEvent [jobId=" + jobId + ", moveType=" + moveType + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }
}
