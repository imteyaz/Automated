package com.minapro.procserver.actors.plc;

import static com.minapro.procserver.util.RDTProcessingServerConstants.NOTIF;
import static com.minapro.procserver.util.RDTProcessingServerConstants.UPDATE_JOB_DETECTED;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.List;

import akka.actor.UntypedActor;

import com.minapro.procserver.events.plc.UpdateJobDetectedEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;

public class UpdateJobDetectedActor extends UntypedActor {
    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof UpdateJobDetectedEvent) {
            UpdateJobDetectedEvent updateJob = (UpdateJobDetectedEvent) message;

            // get the message format
            List<String> msgFields = EventFormats.getInstance().getEventFields(UPDATE_JOB_DETECTED);
            String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

            // build the response to the device
            StringBuilder responseToDevice = new StringBuilder(NOTIF).append( valueSeperator).append( updateJob.geEventType());

            for (int i = 1; i < msgFields.size(); i++) {
                responseToDevice.append(valueSeperator);
                EventUtil.getInstance().getEventParameter(updateJob, msgFields.get(i), responseToDevice);
            }

            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), OPERATOR.QC,
                    updateJob.getTerminalID());
        }
    }
}
