package com.minapro.procserver.util;

import java.io.File;

/**
 * All the constants needed for the processing server are define here
 * 
 * @author Rosemary George
 * 
 */
public interface RDTProcessingServerConstants {
    // File Paths
    public static final String CONFIG_DIRECTORY = System.getProperty("user.dir") + File.separator + "config"
            + File.separator;
    
    public static final String RESOURCE_BUNDLE_FILE = "MessageBundle";

    public static final String DEVICE_EVENT_TYPE_FILE_PATH = CONFIG_DIRECTORY + "DeviceEventType.properties";

    public static final String EVENT_FORMAT_FILE_PATH = "config" + File.separator + "EventFormats.xml";

    public static final String DEVIVE_COMM_PARAMETER_FILE_PATH = CONFIG_DIRECTORY
            + "DeviceCommunicationParameters.properties";

    public static final String LOG4J_FILE_PATH = CONFIG_DIRECTORY + "log4j.xml";

    public static final String COLUMN_SEPERATOR_KEY = "COLUMN_SEPERATOR";
    public static final String VALUE_SEPERATOR_KEY = "VALUE_SEPERATOR";
    public static final String ITEM_SEPERATOR_KEY = "ITEM_SEPERATOR";
    public static final String ROW_SEPERATOR_KEY = "ROW_SEPERATOR";
    public static final String MAX_NO_OF_JOBS_KEY = "MAX_NO_OF_JOBS";
    public static final String BREAK1_AFTERLOGIN_HOURS = "BREAK1_AFTERLOGIN_HOURS";
    public static final String BREAK1_DURATION = "BREAK1_DURATION";
    public static final String BREAK2_AFTERLOGIN_HOURS = "BREAK2_AFTERLOGIN_HOURS";
    public static final String BREAK2_DURATION = "BREAK2_DURATION";
    public static final String DISPLAY_LOGIN_DELAY_KEY = "DISPLAY_LOGIN_DELAY";
    public static final String TERMINAL_KEY = "TERMINAL";

    // QC Related ESPER values
    public static final String WS_WEIGHT_THRESHOLD = "WS_WEIGHT_THRESHOLD";
    public static final String LS_WEIGHT_THRESHOLD = "LS_WEIGHT_THRESHOLD";
    public static final String LOCKED_UP_VALUE = "LOCKED_UP_VALUE";
    public static final String UNLOCKED_UP_VALUE = "UNLOCKED_UP_VALUE";
    public static final String QC_DELAY_RECORDING = "QC_DELAY_RECORDING";
    public static final String QC_TROLLEY_CHANGE_DELTA = "QC_TROLLEY_CHANGE_DELTA";
    public static final String QC_HOIST_CHANGE_DELTA = "QC_HOIST_CHANGE_DELTA";
    public static final String QC_GANTRY_CHANGE_DELTA = "QC_GANTRY_CHANGE_DELTA";
    public static final String QC_BACKREACH_START_VAL = "QC_BACKREACH_START_VAL";
    public static final String QC_BACKREACH_END_VAL = "QC_BACKREACH_END_VAL";
    public static final String QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA = "QC_TWIN_TO_SINGLE_GANTRY_CHANGE_DELTA";
    public static final String QC_TWENTY_GANTRY_CHANGE_DELTA = "QC_TWENTY_GANTRY_CHANGE_DELTA";
    public static final String QC_FORTY_GANTRY_CHANGE_DELTA = "QC_FORTY_GANTRY_CHANGE_DELTA";

    // ITV related ESPER values
    public static final String ITV_DELAY_RECORDING_INTERVAL = "ITV_DELAY_RECORDING_INTERVAL";

    // CHE related ESPER constants
    public static final String CHE_WEIGHT_THRESHOLD = "CHE_WEIGHT_THRESHOLD";
    public static final String CHE_LOCKED_VALUE = "CHE_LOCKED_VALUE";
    public static final String CHE_UNLOCKED_VALUE = "CHE_UNLOCKED_VALUE";

    public static final String PLC_READ_INTERVAL = "PLC_READ_INTERVAL";
    public static final String CHE_PLC_READ_INTERVAL = "CHE_PLC_READ_INTERVAL";
    public static final String BAY_VIEW_00_OFFSET = "BAY_VIEW_00_OFFSET";
    public static final String WORKING_EQUIPMENTS_READ_INTERVAL = "WORKING_EQUIPMENTS_READ_INTERVAL";
    public static final String HEAVY_HOOK_POLL_FREQUENCY = "HEAVY_HOOK_POLL_FREQUENCY";
    public static final String JOB_LIST_POLL_FREQUENCY = "JOB_LIST_POLL_FREQUENCY";

    // Device request types
    public static final String LOGIN_REQ = "LOGIN_REQ";
    public static final String CONFIRM_ALLOCATION = "CONFIRM_ALLOCATION";
    public static final String DLM_REQ = "DLM_REQ";
    public static final String ITV_ARRIVAL = "ITV_ARRIVAL";
    public static final String PINNING_CONFIRMATION = "PINNING_CONFIRMATION";
    public static final String DELAY_CONFIRMATION = "DELAY_CONFIRMATION";
    public static final String ITV_JOB_CONFIRMATION = "ITV_JOB_CONFIRMATION";
    public static final String CONTAINER_MOVE = "CONTAINER_MOVE";
    public static final String INSPECTION_RECORD = "INSPECTION_RECORD";
    public static final String CANCEL_INSPECTION = "CANCEL_INSPECTION";
    public static final String JOB_LIST_REQUEST = "JOB_LIST_REQUEST";
    public static final String ITV_POOL_REQUEST = "ITV_POOL_REQUEST";
   
    public static final String UPDATE_CONTAINER_INQUIRY_REQUEST  = "UPDATE_CONTAINER_INQUIRY_REQUEST";
    public static final String UPDATE_CONTAINER_INQUIRY_RESPONSE = "UPDATE_CONTAINER_INQUIRY_RESPONSE";
    public static final String UPDATED_CONTAINER_STATUS_RESPONSE = "UPDATED_CONTAINER_STATUS_RESPONSE";
    public static final String UPDATED_CONTAINER_REQUEST 		 = "UPDATED_CONTAINER_REQUEST";
    
    public static final String BAY_VIEW_REQUEST = "BAY_VIEW_REQUEST";
    public static final String SWITCH_BAY_REQUEST = "SWITCH_BAY_REQUEST";
    public static final String LOGOUT = "LOGOUT";
    public static final String UPDATE_JOB = "UPDATE_JOB";
    public static final String COMPLETED_JOB_LIST_REQUEST = "COMPLETED_JOB_LIST_REQUEST";
    public static final String REFRESH_JOB_LIST_REQUEST = "REFRESH_JOB_LIST_REQUEST";
    public static final String DELETE_MANUAL_JOB = "DELETE_MANUAL_JOB";
    public static final String SWAP_REQ = "SWAP_REQ";
    public static final String MANUAL_DELAY_REQUEST = "MANUAL_DELAY_REQUEST";
    public static final String JOB_SELECTION_REQUEST = "JOB_SELECTION_REQUEST";
    public static final String CANCEL_JOB_SELECTION_REQUEST = "CANCEL_JOB_SELECTION_REQUEST";
    public static final String JOB_SELECTION_RESPONSE = "JOB_SELECTION_RESPONSE";
    public static final String CANCEL_JOB_SELECTION_RESPONSE = "CANCEL_JOB_SELECTION_RESPONSE";
    public static final String JOB_SELECTION_NOTIF = "JOB_SELECTION_NOTIF";

    /**
     * Following Two constants are related to OperatorAvailability Event.
     */
    public static final String OPERATOR_AVAILABILITY = "OPERATOR_AVAILABILITY";
    public static final String OPERATOR_BREAK_REASONS = "OPERATOR_BREAK_REASONS";

    /**
     * Following constant is related to OrphanContainer Event
     */
    public static final String OUT_OF_LIST_CNTRS_GET_REQUEST  = "OUT_OF_LIST_CNTRS_GET_REQUEST";
    public static final String OUT_OF_LIST_CNTRS_RESPONSE = "OUT_OF_LIST_CNTRS_RESPONSE";
    public static final String ORPHAN_CONTAINER_STATUS_RESPONSE = "ORPHAN_CONTAINER_STATUS_RESPONSE";
    public static final String ORPHAN_CONTAINER_CREATION_REQUEST="ORPHAN_CONTAINER_CREATION_REQUEST";
    /**
     * Following Constants Responsible For Handling TroubleShoot Request and Responses
     */
    public static final String TROUBLESHOOT_AREAS_RESPONSE = "TROUBLESHOOT_AREAS_RESPONSE";
    public static final String TROUBLESHOOT_CONFIRM_REQUEST = "TROUBLESHOOT_CONFIRM_REQUEST";
    public static final String TROUBLESHOOT_AREAS_REQUEST = "TROUBLESHOOT_AREAS_REQUEST";
    /**
     * Following constants responsible for SHF Pinning Station allocations
     */
    public static final String SHF_PINNINGSTATION_VIEW_RESPONSE = "SHF_PINNINGSTATION_VIEW_RESPONSE";
    public static final String SHF_PINNINGSTATION_VIEW_REQ = "SHF_PINNINGSTATION_VIEW_REQ";
    public static final String SHF_CHANGE_ALLOCATION_REQ = "SHF_CHANGE_ALLOCATION_REQ";
    /**
     * Following constants related to Logged In Lashers request and response
     */
    public static final String LASHERS_REQUEST = "LASHERS_REQUEST";
    /**
     * Following Two constants are related to Delay Recording by Operator
     */
    public static final String DELAY_RECORDING_BY_OPERATOR = "DELAY_RECORDING_BY_OPERATOR";

    public static final String DELAY_RECORDING_BY_OPERATOR_RESPONSE = "DELAY_RECORDING_BY_OPERATOR_RESPONSE";

    /**
     * Following Constants Realated to QCLanes
     * 
     */
    public static final String QC_LANE_VIEW_REQ = "QC_LANE_VIEW_REQ";

    public static final String QC_LANE_VIEW_RESPONSE = "QC_LANE_VIEW_RESPONSE";
    public static final String QC_LANE_CHANGE_ALLOCATION_REQ = "QC_LANE_CHANGE_ALLOCATION_REQ";
    /**
     * Following Messages related to YARD_VIEW
     */
    public static final String YARD_VIEW_REQUEST = "YARD_VIEW_REQUEST";
    public static final String YARD_VIEW_RESPONSE = "YARD_VIEW_RESPONSE";
    public static final String STACK_VIEW_REQUEST = "STACK_VIEW_REQUEST";
    public static final String STACK_VIEW_RESPONSE = "STACK_VIEW_RESPONSE";
    public static final String NEW_LOCATION_REQUEST = "NEW_LOCATION_REQUEST";
    public static final String INVENTORY_REQUEST = "INVENTORY_REQUEST";
    public static final String INVENTORY_UPDATE_REQUEST = "INVENTORY_UPDATE_REQUEST";

    /**
     * Messages related to Damage recording, Correction
     */
    public static final String DAMAGE_CODE_REQUEST = "DAMAGE_CODE_REQUEST";
    public static final String DAMAGE_CODE_RESPONSE = "DAMAGE_CODE_RESPONSE";
    public static final String DAMAGED_CONTAINER = "DAMAGED_CONTAINER";
    public static final String CONTAINER_DAMAGES_REQUEST = "CONTAINER_DAMAGES_REQUEST";
    public static final String CONTAINER_DAMAGE_CORRECTION = "CONTAINER_DAMAGE_CORRECTION";
    public static final String CONTAINER_DAMAGE_DETAILS = "CONTAINER_DAMAGE_DETAILS";
    public static final String DAMAGE_CONTAINER_NOTIF = "DAMAGE_CONTAINER_NOTIF";
    
   
    /**
     * Following Constants are related to Tech Support
     * 
     */
    public static final String TECHNICAL_SUPPORT_REQUEST = "TECHNICAL_SUPPORT_REQUEST";
    public static final String TECHINCAL_SUPPORT_FILEDS_RESPONSE = "TECHINCAL_SUPPORT_FILEDS_RESPONSE";
    public static final String TECHNICAL_SUPPORT_WITH_VALUES = "TECHNICAL_SUPPORT_WITH_VALUES";
    // Device response types
    public static final String LOGIN_FAILURE = "LOGIN_FAILURE";
    public static final String LOGIN_SUCCESS = "LOGIN_SUCCESS";
    public static final String DLM_RESPONSE = "DLM_RESPONSE";
    public static final String LOGIN_DELAY = "LOGIN_DELAY";
    public static final String DRIVE_INSTRUCTION = "DRIVE_INSTRUCTION";
    public static final String PLACED_CONTAINER_ITV = "PLACED_CONTAINER_ITV";
    public static final String JOB_LIST = "JOB_LIST";
    public static final String ITV_ARRIVED = "ITV_ARRIVED";
    public static final String ITV_DISPATCHED = "ITV_DISPATCHED";
    public static final String ITV_LEFT = "ITV_LEFT";
    public static final String ITV_GOTOMESSAGE = "ITV_GOTOMESSAGE";
    public static final String ITV_SWAP = "ITV_SWAP";
    public static final String JOB_DONE = "JOB_DONE";
    public static final String REMOVE_JOB = "REMOVE_JOB";
    public static final String EQP_USER_ALLOCATION = "EQP_USER_ALLOCATION";
    public static final String MAN_USER_ALLOCATION = "MAN_USER_ALLOCATION";
    public static final String INSPECTION_CHECKLIST = "INSPECTION_CHECKLIST";
    public static final String ITV_POOL = "ITV_POOL";
    public static final String CONTAINER_HANDLING = "CONTAINER_HANDLING";
    public static final String BAY_FRONT_VIEW = "BAY_FRONT_VIEW";
    public static final String BAY_TOP_VIEW = "BAY_TOP_VIEW";
    public static final String BAY_TOP_VIEW_UPDATE = "BAY_TOP_VIEW_UPDATE";
    public static final String BAY_VIEW_UPDATE = "BAY_VIEW_UPDATE";
    public static final String COMPLETED_JOB_LIST_RESP = "COMPLETED_JOB_LIST_RESP";
    public static final String REEFER_STATUS_NOTIF = "REEFER_STATUS_NOTIF";
    public static final String REEFER_CONNECTED = "REEFER_CONNECTED";
    public static final String REEFER_DISCONNECTED = "REEFER_DISCONNECTED";

    // Following Three related to Languages.
    public static final String LANGUAGES_REQ = "LANGUAGES_REQ";
    public static final String LANGUAGES_RESPONSE = "LANGUAGES_RESPONSE";
    public static final String LANGUAGE_CHANGE_REQ = "LANGUAGE_CHANGE_REQ";
    // Vessel Foreman Operation View
    public static final String FOREMAN_OPT_VIEW = "FOREMAN_OPT_VIEW";
    public static final String BAY_ROW_CHANGE_NOTIF = "BAY_ROW_CHANGE_NOTIF";
    public static final String QC_PERFORMANCE_NOTIF = "QC_PERFORMANCE_NOTIF";
    public static final String VF_CHECKLIST_REQ = "VF_CHECKLIST_REQ";
    public static final String FOREMAN_OPERATIONAL_VIEW_REQUEST = "FOREMAN_OPERATIONAL_VIEW_REQUEST";
    public static final String FOREMAN_VIEW_PLAN_REQUEST = "FOREMAN_VIEW_PLAN_REQUEST";
    public static final String FOREMAN_VIEW_PLAN_RESPONSE = "FOREMAN_VIEW_PLAN_RESPONSE";
    public static final String FOREMAN_VESSEL_DOCUMENT_REQUEST = "FOREMAN_VESSEL_DOCUMENT_REQUEST";
    public static final String FOREMAN_VESSEL_DOCUMENT_RESPONSE = "FOREMAN_VESSEL_DOCUMENT_RESPONSE";

    public static final String HEAVY_HOOK = "HEAVY_HOOK";
    public static final String DELAY_RECORDING = "DELAY_RECORDING";
    public static final String DELAY_RECORD_CONFIRMATION = "DELAY_RECORD_CONFIRMATION";
    public static final String AUTO_DELAY_RECONFIRMATION = "AUTO_DELAY_RECONFIRMATION";
    public static final String AUTO_DELAY_CONFIRM_VALIDATION = "AUTO_DELAY_CONFIRM_VALIDATION";
    public static final String DELAY_RECORD_RESPONSE = "DELAY_RECORD_RESPONSE";
    public static final String PERFORMANCE = "PERFORMANCE";
    public static final String GENERALLIFT_OPERATION = "GENERALLIFT_OPERATION";
    public static final String GENERALLIFT_OPERATION_RESP = "GENERALLIFT_OPERATION_RESP";
    public static final String CONTAINER_HANDLING_MINIMIZE = "CONTAINER_HANDLING_MINIMIZE";
    public static final String STOP_PLC_INSTRUCTION = "STOP_PLC_INSTRUCTION";
    public static final String CONTAINER_MOVE_RESPONSE = "CONTAINER_MOVE_RESPONSE";

    public static final String OPERATOR_AVAILABILITY_RESPONSE = "OPERATOR_AVAILABILITY_RESPONSE";
    public static final String BACKREACH_EVENT = "BACKREACH_EVENT";
    public static final String UPDATE_JOB_DETECTED = "UPDATE_JOB_DETECTED";
    public static final String ALERT_MESSAGE = "ALERT_MESSAGE";
    public static final String SCROLLING_ALERT = "SCROLLING_ALERT_MESSAGE";
    
    /**
     * Following Constants realted to Seal Broken
     */
    public static final String SEAL_BROKEN_REQUEST = "SEAL_BROKEN_REQUEST";

    public static final String SEAL_BROKEN_RESPONSE = "SEAL_BROKEN_RESPONSE";

    public static final String SEAL_ISSUE_TS_ID = "SEAL_ISSUE_TS_ID";
    // prefix to the messages sent to devices
    public static final String RESP = "RESP";
    public static final String NOTIF = "NOTIF";

    public static final String MOVE_TYPE_LOAD = "L";
    public static final String MOVE_TYPE_DISCHARGE = "D";

    public static final String STATUS_SUCCESS = "success";
    public static final String STATUS_FAILURE = "failure";

    public static final String REASON_CODE = "ReasonCodes";
    public static final String DELAY_TIME = "DelayTime";
    public static final String OPERATIONAL_DELAY = "OPERATIONAL_DELAY";

    public static final String OPERATIONAL = "Operational";
    public static final String NON_OPERATIONAL = "Non-Operational";
    public static final String ROTATION = "RotationIDs";
    public static final String ACTIVITY_CODES = "ActivityCodes";
    public static final String NON_OP_CODES = "NonOpCodes";
    public static final String TRAILER_NO = "TrailerNo";
    public static final String CHECKLIST = "checkLists";
    public static final String TROUBLE_SHOOT = "TS";
    public static final String ROW_DATA = "RowData";
    public static final String STACK_DATA = "StackData";
    public static final String LANGUAGE_CODE = "LanguageCode";

    // these are related Port Operational constants.

    public static final String RMG = "RMG";

    public static final String LOAD = "LOAD";
    public static final String DSCH = "DSCH";
    public static final String RECEIPT = "RECV";
    public static final String DELIVERY = "DLVR";
    public static final String YARD = "YARD";

    public static final String SPACE = "";
    public static final String REFERENCE_CONTAINER_SEPERATOR = "#";
    public static final String CHE_MOVED_TO_ROW = " CHE Moved to row : ";
    public static final String OF_YARD_LOCATION = "  of the yard location : ";

    public static final String BREAK_START_TIME = "BREAK_START_TIME";
    public static final String BREAK_END_TIME = "BREAK_END_TIME";

    // constants related to Container Inquiry
    public static final String CONTAINER_INQUIRY_REQUEST = "CONTAINER_INQUIRY_REQUEST";
    public static final String CONTAINER_INQUIRY_SUCCESS = "CONTAINER_INQUIRY_SUCCESS";
    public static final String CONTAINER_INQUIRY_FAILURE = "CONTAINER_INQUIRY_FAILURE";

    
    public static final String SHUFFLEJOB_REQUEST = "SHUFFLEJOB_REQUEST";
    public static final String CONFIRM_SHUFFLEJOB_REQUEST="CONFIRM_SHUFFLEJOB_REQUEST";
    public static final String CANCEL_SHUFFLEJOB_REQUEST="CANCEL_SHUFFLEJOB_REQUEST";
    public static final String SHUFFLEJOB_RESPONSE= "SHUFFLEJOB_RESPONSE";
    public static final String CONFIRM_SHUFFLEJOB_RESPONSE ="CONFIRM_SHUFFLEJOB_RESPONSE";
    public static final String AUTOMATIC_CONFIRM_SHUFFLEJOB_RESPONSE ="AUTOMATIC_CONFIRM_SHUFFLEJOB_RESPONSE";
    public static final String JOBLIST_VALIDATION_RESPONSE="JOBLIST_VALIDATION_RESPONSE";
    
    public static final String GROUND ="GROUND";

    public static final String TWIN_JOB_TYPE = "TW";
    public static final String TANDEM_JOB_TYPE = "TN";
    
    //Accident/Incident related constants
    public static final String ACCIDENT_INCIDENT_REQUEST = "ACCIDENT_INCIDENT_REQUEST";
    public static final String ACCIDENT_INCIDENT_CONFIRM = "ACCIDENT_INCIDENT_CONFIRM";
    public static final String ACCIDENT_INCIDENT_RESPONSE = "ACCIDENT_INCIDENT_RESPONSE";
    public static final String ACCIDENT_INCIDENT_CONFIRM_STATUS = "ACCIDENT_INCIDENT_CONFIRM_STATUS";
    
    public static final String MOVES_TO_GO_REQUEST = "MOVES_TO_GO_REQUEST";
    public static final String MOVES_TO_GO_RESPONSE = "MOVES_TO_GO_RESPONSE";
    
    public static final String TOS_STATUS_NOTIF = "TOS_STATUS_NOTIF";
    public static final String KEEP_ALIVE_ERROR_MSG = "TOS system is down, please contact system Administrator";
    
    
    //Following Constants are used to define the Damage Severity
    
    public static final String DAMAGE_MAJOR_SEVERITY_VALUE 			= "DAMAGE_MAJOR_SEVERITY_VALUE";
    public static final int   DAMAGE_MAJOR_SEVERITY_DEFAULT_VALUE 	= 50;
    /*
     * ITV Waiting Time Params
     * Started
     */
    public static final String ITV_WAITING_TIME_PARAMS 			= "ITV_WAITING_TIME_PARAMS";
    public static final String ITV_WAITING_SLOW_BLINK_PARAM 	= "ITV_WAITING_SLOW_BLINK_PARAM";
    public static final String ITV_WAITING_NORMAL_BLINK_PARAM 	= "ITV_WAITING_NORMAL_BLINK_PARAM";
    public static final String ITV_WAITING_HIGH_BLINK_PARAM 	= "ITV_WAITING_HIGH_BLINK_PARAM";
    public static final String ITV_WAITING_DEFAULT_COLOR_CODE   = "#f4a142";
    
    public static final String EQUIPMENT_PLC_EVENTS_STATUS = "EQUIPMENT_PLC_EVENTS_STATUS";
   
    /*
     * Following are the New Move Types Supported by OPUS.
     * Started
     */
    public static final String MI  = "MI";
    public static final String MO  = "MO";
    public static final String GI  = "GI";
    public static final String GO  = "GO";
    public static final String LC  = "LC";
    public static final String GC  = "GC";
    public static final String RH  = "RH";
    public static final String AH  = "AH";
    //Ended
    
    public static final String YARD_INVENTORY_UPDATE_SLEEP_TIME  = "YARD_INVENTORY_UPDATE_SLEEP_TIME";
    public static final String YARD_INVENTORY_UPDATE_POLL_TIME  = "YARD_INVENTORY_UPDATE_POLL_TIME";
    
    public static final String FOLLOW_ITV = "FOLLOW_ITV";
    public static final String INVENTORY_UPDTE_STATUS_RESPONSE="INVENTORY_UPDTE_STATUS_RESPONSE";
    
    public static final String OPUS_TWIN_CODE 	= "W";    
    public static final String OPUS_TANDEM_CODE     = "M";
    
    public static final String CALL_ITV = "CALL_ITV";
}
