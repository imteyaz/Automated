package com.minapro.procserver.actors.common;

import static com.minapro.procserver.util.RDTProcessingServerConstants.BREAK_END_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.DELAY_TIME;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOGIN_DELAY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOGIN_FAILURE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.LOGIN_SUCCESS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.REASON_CODE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.ROW_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.STATUS_FAILURE;
import static com.minapro.procserver.util.RDTProcessingServerConstants.STATUS_SUCCESS;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTPLCCacheManager;
import com.minapro.procserver.cache.UPDATETYPE;
import com.minapro.procserver.db.DelayReasonCode;
import com.minapro.procserver.db.HibernateUtil;
import com.minapro.procserver.db.User;
import com.minapro.procserver.db.UserActivityRecord;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.CertificateValidateEvent;
import com.minapro.procserver.events.common.JournalEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LoginResponseEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.LogoutResponseEvent;
import com.minapro.procserver.events.common.MinaProAlertEvent;
import com.minapro.procserver.events.plc.PLCSchedulerEvent;
import com.minapro.procserver.queue.AdminNotificationListener;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.ESBQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.procserver.util.EventFormats;
import com.minapro.procserver.util.EventUtil;
import com.minapro.procserver.util.PLCEventUtil;
import com.minapro.procserver.util.RDTProcessingServerConstants;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Actor Class handling the business logic related to the Login/Logout request from the devices. </p>
 * 
 * @author Rosemary George
 *
 */
public class LoginActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(LoginActor.class);

    @Override
    /**
     * Handles messages of type LoginEvent,LogoutEvent and LoginResponseEvent
     */
    public void onReceive(Object message) throws Exception {
        if (message instanceof LoginEvent) {
            handleLoginEvent((LoginEvent) message);
        } else if (message instanceof LoginResponseEvent) {
            handleLoginResponseEvent((LoginResponseEvent) message);
        } else if (message instanceof LogoutEvent) {
            handleLogoutEvent((LogoutEvent) message);
        } else if(message instanceof LogoutResponseEvent){
        	handleLogoutResponseEvent((LogoutResponseEvent)message);
        } else {
            unhandled(message);
        }
    }

    /**
     * Handles the logout response message from ESB, raises the logout failure alert
     * @param message
     */
    private void handleLogoutResponseEvent(LogoutResponseEvent logoutResponse) {
		logger.logMsg(LOG_LEVEL.INFO, logoutResponse.getUserID(), 
				"Recieved log out response message with status =" + logoutResponse.isStatus());
		
		if(!logoutResponse.isStatus()){
			MinaProAlertEvent alert = new MinaProAlertEvent();
			alert.setAlertCode(ALERTCODE.LOGOUT_FAILURE_ALERT);
			alert.setUserID(logoutResponse.getUserID());
			alert.setOperatorId(logoutResponse.getUserID());
			alert.setEquipmentID(logoutResponse.getEquipmentID());
        
			getSender().tell(alert, null);		
		}
	}

	/**
     * <p> Handles the LoginEvent received from the communication server. </p>
     * 
     * <p> The login credentials are validated at the communication layer. So if the message reached here means the
     * login details are valid and matching with the user credentials stored in MinaPro DB, so the message is passed to
     * the ESB for further processing. </p>
     * 
     * @param loginEvent
     */
    private void handleLoginEvent(LoginEvent loginEvent) {
 
    	logger.logMsg(LOG_LEVEL.DEBUG, loginEvent.getUserID(), "Received Login Message -" + loginEvent);

        try {

            User user = RDTCacheManager.getInstance().getUserDetails(loginEvent.getUserID());
            // set the de-crypted password for the user
            user.setPassword(loginEvent.getPassword());
            RDTCacheManager.getInstance().setUserLoggedInRole(loginEvent.getUserID(), loginEvent.getRole());
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(loginEvent.getUserID());

            // Add the Equipment to user mapping to cache
            if (loginEvent.getEquipmentID() != null) {
                String mappedUser = RDTPLCCacheManager.getInstance().getUserfromtheEquipment(
                        loginEvent.getEquipmentID());
                logger.logMsg(LOG_LEVEL.INFO, loginEvent.getEquipmentID(),
                        "Previously Mapped user with the equipment is " + mappedUser);
                if (mappedUser != null && !mappedUser.equals(loginEvent.getUserID())) {
                    sendLoginFailureMessage(loginEvent, operatorRole);
                    return;
                }
                logger.logMsg(LOG_LEVEL.INFO, "",
                        "Mapping user:" + user.getUserID() + " to Equipment:" + loginEvent.getEquipmentID());
                RDTPLCCacheManager.getInstance().addEquipmentMappingtoUser(loginEvent.getEquipmentID(),
                        user.getUserID());
            }         

            initalizeAndSaveData(loginEvent, user, operatorRole);
            
            if (OPERATOR.QC.equals(operatorRole) || OPERATOR.CHE.equals(operatorRole)
                    || (OPERATOR.ITV.equals(operatorRole) || OPERATOR.HC.equals(operatorRole))) {
            	/*20-Sept-2016 : commenting out sending to ESB as ROSTIMA issue persists in ESB
                ESBQueueManager.getInstance().postMessage(loginEvent, operatorRole, loginEvent.getTerminalID());
                */
                constructSuccessLoginResponse(loginEvent);
            } else {
                logger.logMsg(LOG_LEVEL.INFO, loginEvent.getUserID(),
                        "MAN operator - Not sending the LOGIN request to ESB");
                sendAllocationMsg(loginEvent);
            }

        } catch (Exception e) {
            logger.logException("Caught exception while processing loginEvent -", e);
        }
    }    

	/**
     * Initializes the various cache based on the role of the user logged in. Also saves the user activity in the
     * database.
     * 
     * @param loginEvent
     * @param user
     * @param role
     */
    private void initalizeAndSaveData(LoginEvent loginEvent, User user, OPERATOR role) {
        // Add the user device mapping to cache
        RDTCacheManager.getInstance().addUserToDeviceMapping(user.getUserID(), loginEvent.getDeviceID());

        RDTPLCCacheManager.getInstance().addLoginTimeforUser(user.getUserID(), new Date());           

        saveUserLoginDetails(user, loginEvent);
        
        
        // Saving all logged-in QC user's information
        if (OPERATOR.QC.equals(role) || OPERATOR.CHE.equals(role)) {
            logger.logMsg(LOG_LEVEL.DEBUG, loginEvent.getUserID(),
                    role + " Users Equipment ID :" + loginEvent.getEquipmentID());
            PLCEventUtil.getInstance().initializePlcData(user.getUserID(), loginEvent.getEquipmentID(), new Date(), role);
        }
        if (OPERATOR.ITV.equals(role)) {

            // this is due to AutoPush implementation for ITV in ESB
            AdminNotificationListener.reloadUsers();
            user = RDTCacheManager.getInstance().getUserDetails(loginEvent.getUserID());
            user.setPassword(loginEvent.getPassword());
            RDTCacheManager.getInstance().addUserDetails(user);
            RDTPLCCacheManager.getInstance().addUsertoFirstTimeMapping(loginEvent.getUserID(), true);
        }
    }

    
	/**
     * Sends failure message to user as another user is already using the equipment
     * 
     * @param loginEvent
     * @param role
     */
    private void sendLoginFailureMessage(LoginEvent loginEvent, OPERATOR role) {

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(LOGIN_FAILURE);
        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

        StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID);
        
        responseToDevice.append(valueSeperator).append(loginEvent.getEventID()).append(valueSeperator)
                .append(loginEvent.getUserID()).append(valueSeperator)
                .append("Another User is already logged in with the same equipment. Please try another");

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), role,
                loginEvent.getTerminalID());
    }

    /**
     * Construct the allocation event and forward to the master actor for further processing
     * 
     * @param loginEvent
     */
    private void sendAllocationMsg(LoginEvent loginEvent) {
        AllocationEvent allocation = new AllocationEvent();
        allocation.setEventID(loginEvent.getEventID());
        allocation.setUserID(loginEvent.getUserID());
        allocation.setTerminalID(loginEvent.getTerminalID());
        allocation.setEquipmentID(loginEvent.getEquipmentID());

        getSender().tell(allocation, null);
    }

   

    /**
     * <p> Handles the LogoutEvent received from the communication server. </p>
     * 
     * <p> The information related to the user activities are cleared from the caches and the event is passed to ESB for
     * further processing </p>
     * 
     * @param logoutEvent
     */
    private void handleLogoutEvent(LogoutEvent logoutEvent) {
        logger.logMsg(LOG_LEVEL.DEBUG, logoutEvent.getUserID(), "Received Logout Message -" + logoutEvent);
        
        User user = RDTCacheManager.getInstance().getUserDetails(logoutEvent.getUserID());

        OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(logoutEvent.getUserID());
        //Setting Current Logged In User Equipment PLC Event Status
        EventUtil.setCurrentEquipmentPLCWorkingStatus(logoutEvent,false);
        //To OPUS, only equipment operators log out required.
        if(operatorRole.equals(OPERATOR.QC) || operatorRole.equals(OPERATOR.ITV) || operatorRole.equals(OPERATOR.CHE)){
        	ESBQueueManager.getInstance().postMessage(logoutEvent, operatorRole, logoutEvent.getTerminalID());
        }
        
        try {
            Date loginTime = RDTPLCCacheManager.getInstance().getLoginTimeforUser(user.getUserID());
            double totalTimeWorkedInHours = 0.0;
            if(loginTime!=null) {
            	double diffInMillies = System.currentTimeMillis() - loginTime.getTime();
            	totalTimeWorkedInHours = diffInMillies / (1000 * 60 * 60);
            	
            	logger.logMsg(LOG_LEVEL.DEBUG, logoutEvent.getUserID(), "Login Time=" + loginTime + ", DiifInMillies=" + diffInMillies
            			+ ", totalHoursWorked=" + totalTimeWorkedInHours);
            }

            if (logoutEvent.getTimeStamp() == null) {
                logoutEvent.setTimeStamp(new Date().toString());
            }

            HibernateUtil.updateUserActivity(user, null, null, logoutEvent.getTimeStamp(), 0, totalTimeWorkedInHours);
            
            /*
             * Following two statements are used to set make operator is un available and updating the break end time in
             * the database
             * 
             * @UmaMahesh M
             */
            if (!(RDTCacheManager.getInstance().isOperatorAvailable(user.getUserID()))) {
                logger.logMsg(LOG_LEVEL.INFO, "",
                        " Operator In Break,But Logout Event Got,Updating User Break End Time In Database And Cache To False");
                RDTCacheManager.getInstance().setOperatorAvailability(user.getUserID(), false);
                HibernateUtil.updateUserBreakTime(user, BREAK_END_TIME);
            }
        }catch (Exception e) {
            logger.logException("Caught exception while updating userActivity or break time during logoutEvent -", e);
        }

        try {
            if (OPERATOR.QC.equals(operatorRole)) {

                if (RDTPLCCacheManager.getInstance().hasUserStoppedPLC(logoutEvent.getUserID())) {

                    logger.logMsg(LOG_LEVEL.DEBUG, " ", "Removing entry from stop PLC subscription cache");
                    RDTPLCCacheManager.getInstance().removeStopPLCCacheDetails(logoutEvent.getUserID());

                }
                RDTPLCCacheManager.getInstance().deleteQCEntryFromLoggedInCache(logoutEvent.getUserID());

                // Sending Stop Instruction to PLC Scheduler
                PLCSchedulerEvent plcscheduler = new PLCSchedulerEvent();
                plcscheduler.setInstruction("stop");
                plcscheduler.setOperator(OPERATOR.QC.toString());
                getSender().tell(plcscheduler, null);
            }

            if (OPERATOR.CHE.equals(operatorRole)) {

                if (RDTPLCCacheManager.getInstance().hasUserStoppedPLC(logoutEvent.getUserID())) {
                    logger.logMsg(LOG_LEVEL.DEBUG, " ", "Removing entry from stop RMG PLC subscription cache");
                    RDTPLCCacheManager.getInstance().removeStopPLCCacheDetails(logoutEvent.getUserID());
                }
                RDTPLCCacheManager.getInstance().deleteCHEEntryFromLoggedInCache(logoutEvent.getUserID());

                // Sending Stop Instruction to PLC Scheduler
                PLCSchedulerEvent rmgPlcscheduler = new PLCSchedulerEvent();
                rmgPlcscheduler.setInstruction("stop");
                rmgPlcscheduler.setOperator(OPERATOR.CHE.toString());
                getSender().tell(rmgPlcscheduler, null);
            }

            if (OPERATOR.ITV.equals(operatorRole)) {
                logger.logMsg(LOG_LEVEL.DEBUG, " ", "Removing currentLocation entry from cache");
                RDTCacheManager.getInstance().flushITVCurrentLocation(logoutEvent.getUserID());
                RDTCacheManager.getInstance().removeTrailerNoFromITV(logoutEvent.getEquipmentID());
                RDTCacheManager.getInstance().clearItvInstructions(logoutEvent.getEquipmentID());
            }

            // Clear Cache of the QC User
            RDTPLCCacheManager.getInstance().clearAllCacheForUser(user.getUserID(), logoutEvent.getEquipmentID());
           
            // Remove all user related information from the cache
            RDTCacheManager.getInstance().clearAllCacheForUser(user.getUserID(), logoutEvent.getEquipmentID());

        } catch (Exception e) {
            logger.logException("Caught exception while processing logoutEvent -", e);
        }
    }
    
    /**
     * Dummy method to mimic login response event from ESB till ROSTIMA is stabilized
     * @param loginEvent
     */
    private void constructSuccessLoginResponse(LoginEvent loginEvent) {
		LoginResponseEvent responseEvent = new LoginResponseEvent();
		responseEvent.setUserID(loginEvent.getUserID());
		responseEvent.setEventID(loginEvent.getEventID());
		responseEvent.setEquipmentID(loginEvent.getEquipmentID());
		responseEvent.setTerminalID(loginEvent.getTerminalID());
		responseEvent.setStatus(STATUS_SUCCESS);
		
		CertificateValidateEvent certificate = new CertificateValidateEvent();
		certificate.setStatus(STATUS_SUCCESS);
		responseEvent.setValidateCertificateDetails(certificate);
		
		AllocationEvent allocation = new AllocationEvent();
		allocation.setUserID(loginEvent.getUserID());
        allocation.setTerminalID(loginEvent.getTerminalID());
        allocation.setShiftStartTime(new Date());
        responseEvent.setAllocationDetails(allocation);
		
		handleLoginResponseEvent(responseEvent);
	}

    /**
     * <p>Handles the LoginResponseEvent from the ESB. LoginResponse will contain the allocation details and certificate
     * validation status.</p>
     * 
     * <p>In case of any error in contacting the DPW IT systems, ESB will set the status field in loginResponse as
     * failure. A failure message is sent back to the device in such cases.</p>
     * 
     * <p>Else, the shift start time is extracted from the allocation details and the time difference is calculated. If
     * there is delay in reporting to work, Login Delay message with a set of reason code is sent to the device. </p>
     * 
     * <p>The login delay reporting is decided based on the property value DISPLAY_LOGIN_DELAY. If the property is set
     * to FALSE, the login delay functionality is skipped. </p>
     * 
     * <p> If all conditions are met, a login success message is prepared and sent to the device.</p>
     * 
     * @param loginResponse
     */
    private void handleLoginResponseEvent(LoginResponseEvent loginResponse) {
        logger.logMsg(LOG_LEVEL.DEBUG, loginResponse.getUserID(), "Received LoginResponse Message -" + loginResponse);

        try {
            OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(loginResponse.getUserID());

            String eventType;
            AllocationEvent allocation = null;
            CertificateValidateEvent certificate = null;
            if (STATUS_FAILURE.equalsIgnoreCase(loginResponse.getStatus())) {
                eventType = LOGIN_FAILURE;
                sendLoginRespone(loginResponse, eventType, operatorRole);
            } else {
                certificate = loginResponse.getValidateCertificateDetails();
                // copy the common parameter from response
                certificate.setUserID(loginResponse.getUserID());
                certificate.setTerminalID(loginResponse.getTerminalID());
                certificate.setEquipmentID(loginResponse.getEquipmentID());

                allocation = loginResponse.getAllocationDetails();
                // copy common parameters from loginResponse
                allocation.setEventID(loginResponse.getEventID());
                allocation.setUserID(loginResponse.getUserID());
                allocation.setTerminalID(loginResponse.getTerminalID());
                allocation.setEquipmentID(loginResponse.getEquipmentID());

                // check whether login delay needs to be displayed
                boolean delayFunctionStatus = Boolean.parseBoolean(DeviceCommParameters.getInstance().getCommParameter(
                        RDTProcessingServerConstants.DISPLAY_LOGIN_DELAY_KEY));

                if (delayFunctionStatus && allocation.getShiftStartTime() != null) {
                    String delayTime = calculateDelayTime(allocation.getShiftStartTime());
                    // if delay in login, cache the allocation details
                    if (delayTime != null) {
                        sendLoginDelayResponse(loginResponse, delayTime, operatorRole);
                        RDTCacheManager.getInstance().addAllocationDetails(allocation);
                        getSender().tell(certificate, null);

                        return;
                    }
                }
                eventType = LOGIN_SUCCESS;
            }

            if (allocation != null) {
                getSender().tell(allocation, null);
            }

            if (certificate != null) {
                getSender().tell(certificate, null);
            }

        } catch (Exception e) {
            logger.logException("Caught exception while processing LoginResponseEvent -", e);
        }
    }

    /**
     * Saves the user login time in the database table "user_activity"
     * 
     * @param user
     */
    private void saveUserLoginDetails(User user, LoginEvent loginEvent) {
        UserActivityRecord activityRecord = new UserActivityRecord();
        if (loginEvent.getTimeStamp() == null) {
        	loginEvent.setTimeStamp(new Date().toString());
        }
        
        activityRecord.setLoginDatetime(loginEvent.getTimeStamp());
        activityRecord.setUser(user);
        activityRecord.setRole(loginEvent.getRole());
        activityRecord.setEquipmentID(loginEvent.getEquipmentID());

        /**
         * Setting operator availability value true.
         * 
         * @UmaMahesh
         */
        if (null != user && null != loginEvent) {
            logger.logMsg(LOG_LEVEL.INFO, user.getUserID(), " Setting operator availability Value to true in cache "
                    + user.getUserID() + loginEvent.getRole());
            RDTCacheManager.getInstance().setOperatorAvailability(user.getUserID(), true);
        }
        JournalEvent journal = new JournalEvent(activityRecord, UPDATETYPE.ADD);
        getSender().tell(journal, null);
    }

    /**
     * <p> Generates and sends the login delay message back to the devices </p>
     * 
     * @param loginResponse
     *            - event received from ESB
     * @param delayMinutes
     *            - the delay time in minutes
     * @param operator
     *            - the operator specific queue to which the message to be sent
     */
    private void sendLoginDelayResponse(Event loginResponse, String delayMinutes, OPERATOR operator) {

        String eventTypeID = DeviceEventTypes.getInstance().getEventType(LOGIN_DELAY);

        // get the message format
        List<String> msgFields = EventFormats.getInstance().getEventFields(LOGIN_DELAY);

        String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

        // build the response to the device
        StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID);

        String field;
        for (int i = 1; i < msgFields.size(); i++) {
            responseToDevice.append(valueSeperator);
            field = msgFields.get(i);
            if (field.equals(REASON_CODE)) {
                fillDelayReasonCodes(responseToDevice);
            } else if (field.equals(DELAY_TIME)) {
                responseToDevice.append(delayMinutes);
            } else {
                EventUtil.getInstance().getEventParameter(loginResponse, msgFields.get(i), responseToDevice);
            }
        }

        logger.logMsg(LOG_LEVEL.DEBUG, loginResponse.getUserID(), "Sending LoginDelay Message -" + responseToDevice);

        CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
                loginResponse.getTerminalID());

    }

    /**
     * <p> Retrieves the delay reason codes from cache and fills in the response to the device </p>
     * 
     * @param responseToDevice
     */
    private void fillDelayReasonCodes(StringBuilder responseToDevice) {
    	
    	Set<DelayReasonCode> reasonCodes = RDTCacheManager.getInstance().getDelayReasonCodes(LOGIN_DELAY);
 
    	String rowSeparator = DeviceCommParameters.getInstance().getCommParameter(ROW_SEPERATOR_KEY);
    	
    	for (DelayReasonCode delayReason : reasonCodes) {
    		responseToDevice.append(delayReason.getDelaypk().getDelayReasonCodeID()).append(rowSeparator);
    	}
    }

    /**
     * <p> Calculates the time difference in milliseconds between the current server time and shiftStartTime </p> <p> If
     * difference is detected, returns the delayed time in HH:mm:ss format, else returns null </p>
     * 
     * @param shiftStartTime
     *            - the shift start time received from ESB
     * @return delay time in HH:mm:ss format
     */
    private String calculateDelayTime(Date shiftStartTime) {
    	
    	long diffInMillies = System.currentTimeMillis() - shiftStartTime.getTime();
    	long delayInMinutes = TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);

    	if (delayInMinutes > 0) {
    		return String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(diffInMillies),
    				TimeUnit.MILLISECONDS.toMinutes(diffInMillies) % TimeUnit.HOURS.toMinutes(1),
    				TimeUnit.MILLISECONDS.toSeconds(diffInMillies) % TimeUnit.MINUTES.toSeconds(1));
    	} else {
    		return null;
    	}
    }

    /**
     * <p> Construct the login response to the device and post it to the communication layer queue </p>
     * 
     * @param loginResponse
     * @param eventType
     */
    private void sendLoginRespone(Event loginResponse, String eventType, OPERATOR operator) {

    	String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

    	// get the message format
    	List<String> msgFields = EventFormats.getInstance().getEventFields(eventType);

    	String valueSeperator = DeviceCommParameters.getInstance().getCommParameter(VALUE_SEPERATOR_KEY);

    	// build the response to the device
    	StringBuilder responseToDevice = new StringBuilder(RESP).append(valueSeperator).append(eventTypeID);

    	for (int i = 1; i < msgFields.size(); i++) {
    		responseToDevice.append(valueSeperator);
    		EventUtil.getInstance().getEventParameter(loginResponse, msgFields.get(i), responseToDevice);
    	}

    	CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operator,
    			loginResponse.getTerminalID());
    }
}