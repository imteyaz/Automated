package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ITVPerformanceEvent  extends Event implements Serializable{

	
	private static final long serialVersionUID = 7369778540377627771L;

}
