package com.minapro.procserver.db.bayprofile;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * ValueObject holding the bay details for a vessel
 * 
 * @author 3123248
 *
 */
@Entity
@Table(name = "MP_BAY_SPM")
public class Bay {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset
     */
    @EmbeddedId
    private BayPk pk;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false)
    private Vessel vessel;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumns({
            @JoinColumn(name = "INT_SECT_NO", referencedColumnName = "INT_SECT_NO", insertable = false, updatable = false),
            @JoinColumn(name = "INT_VSL_NO", referencedColumnName = "INT_VSL_NO", insertable = false, updatable = false) })
    private VesselSection section;

    @Column(name = "VSL_BAY_NO")
    private String vesselBayNo;

    @Column(name = "LOGICAL_BAY_FLG")
    @org.hibernate.annotations.Type(type = "yes_no")
    private boolean isLogicalBay;

    @Column(name = "CNTR_ROW_PRSNT_FLG")
    @org.hibernate.annotations.Type(type = "yes_no")
    private boolean isContainerRowPresent;

    @ManyToOne
    @JoinColumn(name = "TIER_TEMPLATE", referencedColumnName = "NUMSRS_ID")
    private TemplateHeader tierTemplate;

    public TemplateHeader getTierTemplate() {
        return tierTemplate;
    }

    public void setTierTemplate(TemplateHeader tierTemplate) {
        this.tierTemplate = tierTemplate;
    }

    public BayPk getPk() {
        return pk;
    }

    public void setPk(BayPk pk) {
        this.pk = pk;
    }

    public String getVesselBayNo() {
        return vesselBayNo;
    }

    public void setVesselBayNo(String vesselBayNo) {
        this.vesselBayNo = vesselBayNo;
    }

    public boolean isLogicalBay() {
        return isLogicalBay;
    }

    public void setLogicalBay(boolean isLogicalBay) {
        this.isLogicalBay = isLogicalBay;
    }

    public boolean isContainerRowPresent() {
        return isContainerRowPresent;
    }

    public void setContainerRowPresent(boolean isContainerRowPresent) {
        this.isContainerRowPresent = isContainerRowPresent;
    }

    public VesselSection getSection() {
        return section;
    }

    public void setSection(VesselSection section) {
        this.section = section;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public void setVessel(Vessel vessel) {
        this.vessel = vessel;
    }

    @Transient
    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    @Transient
    public int getBayOffset() {
        return pk.getBayOffset();
    }

    public void setBayOffset(int bayOffset) {
        pk.setBayOffset(bayOffset);
    }

}
