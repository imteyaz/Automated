package com.minapro.procserver.events.obf;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * 
 * @author Prasad.Tallapally
 *
 */
public class ViewPlanEvent extends Event implements Serializable {

    private static final long serialVersionUID = 6293155656935807385L;

    private String viewName;
    private String rotationId;

    public String getViewName() {
        return viewName;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

}
