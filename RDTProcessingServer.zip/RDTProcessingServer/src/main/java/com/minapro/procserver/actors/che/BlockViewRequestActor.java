package com.minapro.procserver.actors.che;

import static com.minapro.procserver.util.MinaproLoggerConstants.ENTRY;
import static com.minapro.procserver.util.MinaproLoggerConstants.EXCEPTION_OCCURED;
import static com.minapro.procserver.util.MinaproLoggerConstants.ON_RECEIVE;
import static com.minapro.procserver.util.MinaproLoggerConstants.REASON;
import static com.minapro.procserver.util.RDTProcessingServerConstants.RESP;
import static com.minapro.procserver.util.RDTProcessingServerConstants.VALUE_SEPERATOR_KEY;
import static com.minapro.procserver.util.RDTProcessingServerConstants.YARD_VIEW_RESPONSE;

import java.util.List;
import java.util.Map;

import akka.actor.UntypedActor;

import com.minapro.procserver.cache.BlockProfile;
import com.minapro.procserver.cache.RDTCacheManager;
import com.minapro.procserver.cache.RDTYardProfileCacheManager;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.queue.CommunicationServerQueueManager;
import com.minapro.procserver.queue.OPERATOR;
import com.minapro.procserver.util.BlockProfileUtil;
import com.minapro.procserver.util.DeviceCommParameters;
import com.minapro.procserver.util.DeviceEventTypes;
import com.minapro.util.logging.MinaProApplicationLogger;
import com.minapro.util.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * <p> Class is responsible for sending the BlockView response to the requested logged in user. Request object consists
 * of block number,stack number,depending on block number preparing yard view. </p>
 *  
 *  <p> First Checking In Cache Whether Block Profile Available for requested block number . If available Constructing from 
 *  block profile else requesting esb to get the list of containers for that block number.If response comes from ESB
 *  BlockViewResponseActor.java will be executed</p>
 * 
 * @author UMAMAHESH M
 */
public class BlockViewRequestActor extends UntypedActor {

    private static MinaProApplicationLogger logger = new MinaProApplicationLogger(BlockViewRequestActor.class);

    private static final String VALUE_SEPERATOR = DeviceCommParameters.getInstance().getCommParameter(
            VALUE_SEPERATOR_KEY);

   
    
    @Override
    public void onReceive(Object message) throws Exception {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(getClass().getSimpleName())
                .append(ON_RECEIVE).toString());

        if (message instanceof BlockViewRequestEvent) {
            findBlockProfileInCache((BlockViewRequestEvent) message);
        } else {
            unhandled(message);
        }
    }

    /**
     * <p>Method is responsible for checking the block profile is present in cache or not.</p> 
     * <ul><li>If block profile information available in cache calling sendBlockViewRespMessageFromCache() 
     * to prepare final response message.</li>
     * <li>Else sending request to ESB to get containers information from ESB.</li></ul>
     *<h3>Expected Parameters To the class</h3> <p>: BlockViewRequestEvent Should Consists Of block number and stack number </p>
     */
    private void findBlockProfileInCache(BlockViewRequestEvent blockViewReq) { 
    
    logger.logMsg(LOG_LEVEL.INFO, "",new StringBuilder(ENTRY).append(" findBlockProfileInCache() ").toString());
   
    BlockProfile blockProfile = null;
    
    String blockNumber = blockViewReq.getBlockNumber();
    
    if(blockNumber==null || blockNumber.isEmpty()){
    	logger.logMsg(LOG_LEVEL.ERROR,blockViewReq.getUserID()," Block Number Is Null , UnAble To Proceed Further");
    	sendEmptyResponse(blockViewReq);
    	return;
    }

    try {
    	
    	blockProfile = RDTYardProfileCacheManager.getInstance().getBlockToYardProfile(blockNumber);
    	
    	if (blockProfile == null ) {
           logger.logMsg(LOG_LEVEL.INFO,blockNumber,"Block Structure Is Not Defined In Database,Sending Empty Response");
            sendEmptyResponse(blockViewReq);
        } else {
        	logger.logMsg(LOG_LEVEL.INFO, " ","Containers Information  Available In Cache,Preparing Final Response Message");
            sendBlockViewRespMessageFromCache(blockViewReq, blockProfile);
        }

    } catch (Exception ex) {
        logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" findBlockProfileInCache() ").append(REASON)
                        .toString(), ex);
    }}
   
    /**
     * Method is responsible for sending Complete block view response to the requested user.
     * <h4>Method Work Flow::</h4><ul>
     * <li>Getting Row Data And Stack Data With Respect to Block Number.</li>
     * <li>At a time we have to show only 11 Stacks For requested block number</li>
     * <li>Implemented this logic in prepareStacksSeqNumbersForBlockView().</li>
     * <li> If we receive empty list means no stacks are available in database for that block number.
     * Sending empty response to the UI </li>
     * <li>else performing following operations.
     * <li>Preparing Stack numbers corresponding to list o sequence values.</li>
     * <li>calling prepareBlockViewWithLimitedStackNumbers() to get each and every cell information in the block.Combining all
     * data and sending that response to UI </li></li></ul>
     * <h5> Method Parameters:: </h5>
     * @param blockRequestEvent
     * @param blockProfile
     */
    private void sendBlockViewRespMessageFromCache(BlockViewRequestEvent blockRequestEvent, BlockProfile blockProfile) {

        logger.logMsg(LOG_LEVEL.INFO, "", new StringBuilder(ENTRY).append(" sendBlockViewRespMessageFromCache()").toString());
       
        List<String> listOfStackSeqValuesToDisplay = null;

        String blockNumber = blockRequestEvent.getBlockNumber();
        String eventTypeID = DeviceEventTypes.getInstance().getEventType(YARD_VIEW_RESPONSE);

        String stackNumber = blockRequestEvent.getStackNumber();
        
        StringBuilder rowData = BlockProfile.prepareRowData(blockNumber,false);
        
        BlockProfile.prepareStackData(blockNumber,false);
       
        try {
        	Map<String,String> stackCompleteDataMap = RDTYardProfileCacheManager.getInstance().getBlockRelatedStockData(blockNumber);
            
        	listOfStackSeqValuesToDisplay = stackCompleteDataMap!=null ? BlockProfileUtil.getInstance().
        			prepareStacksSeqNumbersForBlockView(blockNumber,stackNumber) : null ;
        	
        	StringBuilder responseToDevice = new StringBuilder(RESP).append(VALUE_SEPERATOR) 
        			.append(eventTypeID).append(VALUE_SEPERATOR).append(blockRequestEvent.getEventID()).append(VALUE_SEPERATOR);
                    
           if(listOfStackSeqValuesToDisplay!=null && !(listOfStackSeqValuesToDisplay.isEmpty())) {
            
            	StringBuilder stackValuesForInput = BlockProfileUtil.getInstance().
            			getStackValuesBasedOnInput(listOfStackSeqValuesToDisplay, stackCompleteDataMap);
            	 
            	responseToDevice.append(stackValuesForInput) .append(VALUE_SEPERATOR).append(rowData).append(VALUE_SEPERATOR).
            	append(blockProfile.prepareBlockViewWithLimitedStackNumbers(blockRequestEvent,listOfStackSeqValuesToDisplay).append(VALUE_SEPERATOR).append(blockRequestEvent.getUserID()).
            	append(VALUE_SEPERATOR).append(blockRequestEvent.getTerminalID()));
            	
            	logger.logMsg(LOG_LEVEL.INFO, blockRequestEvent.getUserID(), "Posting Data Into Com Server");
            	
            } else {
            	logger.logMsg(LOG_LEVEL.INFO,blockRequestEvent.getUserID()," No Stack Numbers are Available In Database...Preparing Empty Response");
            
            	responseToDevice.append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(blockRequestEvent.getUserID()).
            	append(VALUE_SEPERATOR).append(blockRequestEvent.getTerminalID());

            }
            CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), 
            		RDTCacheManager.getInstance().getUserLoggedInRole(blockRequestEvent.getUserID()),blockRequestEvent.getTerminalID());


        } catch (Exception ex) {
            logger.logException(new StringBuilder(EXCEPTION_OCCURED).append(" sendBlockViewRespMessageFromCache() ")
                    .append(REASON).toString(), ex);
            sendEmptyResponse(blockRequestEvent);
            
        }
    }
    
    /**
   	 * Constructs and sends the empty response to the user.
   	 * 
   	 * @param blockWiseCntrsRuquestEvent
   	 */
   	public void sendEmptyResponse(BlockViewRequestEvent blockWiseCntrsRuquestEvent) {
   		
   		logger.logMsg(LOG_LEVEL.INFO, blockWiseCntrsRuquestEvent.getUserID(), " Started sendEmptyResponse()");
   		String eventType = YARD_VIEW_RESPONSE;
   		String eventTypeID = DeviceEventTypes.getInstance().getEventType(eventType);

   		StringBuilder responseToDevice = new StringBuilder(RESP + VALUE_SEPERATOR + eventTypeID + VALUE_SEPERATOR
   				+ blockWiseCntrsRuquestEvent.getEventID() + VALUE_SEPERATOR);

   		responseToDevice.append(VALUE_SEPERATOR).append(VALUE_SEPERATOR).append(VALUE_SEPERATOR)
   				.append(blockWiseCntrsRuquestEvent.getUserID()).append(VALUE_SEPERATOR)
   				.append(blockWiseCntrsRuquestEvent.getTerminalID());

   		OPERATOR operatorRole = RDTCacheManager.getInstance().getUserLoggedInRole(blockWiseCntrsRuquestEvent.getUserID());
   		CommunicationServerQueueManager.getInstance().postMessage(responseToDevice.toString(), operatorRole,
   				blockWiseCntrsRuquestEvent.getTerminalID());
   	} 
   	
}
