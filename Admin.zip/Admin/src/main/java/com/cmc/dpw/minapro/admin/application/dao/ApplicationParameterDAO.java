package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.ApplicationParameterDTO;
import com.cmc.dpw.minapro.admin.application.entities.ApplicationParameter;
import com.cmc.dpw.minapro.admin.application.entities.Unit;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * ApplicationParameterDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class ApplicationParameterDAO extends GenericDAO<ApplicationParameter> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationParameterDAO.class);
/**
 * This method is used to search ApplicationParameters
 * @param parameterCodeVal
 * @param parameterValueVal
 * @param start
 * @param limit
 * @return Map<String, Object>
 */
    public Map<String, Object> searchApplicationParameters(String parameterCodeVal, String parameterValueVal,
            int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +" Entering ApplicationParameter DAO's searchApplicationParameters method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(ApplicationParameter.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { parameterCodeVal, parameterValueVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchApplicationParameters with parameterCode: {} , parameterValue : {}",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(parameterCodeVal))  && parameterCodeVal != null) {
            likeValue = "";
            String parameterCode = likeValue.concat(percentage).concat(parameterCodeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("parameterCode", parameterCode).ignoreCase());

        }

        if (!("".equalsIgnoreCase(parameterValueVal))  && parameterValueVal != null) {
            likeValue = "";
            String parameterValue = likeValue.concat(percentage).concat(parameterValueVal).concat(percentage);
            searchCriteria.add(Restrictions.like("parameterValue", parameterValue).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******** Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Object[]> searchApplicationParameters = (List<Object[]>) searchCriteria.list();
        List<ApplicationParameter> actualAppParams = new ArrayList<ApplicationParameter>();

        for (Object[] userArr : searchApplicationParameters) {
            ApplicationParameter appParam = (ApplicationParameter) userArr[1];
            Unit currentUnit = (Unit) userArr[0];
            appParam.setUnitName(currentUnit.getUnitName());
            appParam.setUnitId(currentUnit.getUnitId());
            appParam.setUnit(null);
            actualAppParams.add(appParam);

            LOGGER.debug("Got the value of ApplicationParameter: {}", appParam.getParameterCode());
        }

        List<ApplicationParameterDTO> actualAppParamsDtoList =  util.map(actualAppParams, ApplicationParameterDTO.class);
        
        String totalRecords = count.toString();

        LOGGER.debug("******** data: {}", actualAppParamsDtoList);
        LOGGER.debug("******** totalCount: {}", totalRecords);

        resultMap.put("data", actualAppParamsDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting ApplicationParameterDAO's searchApplicationParameters method ");

        return resultMap;
    }
}
