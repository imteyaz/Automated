package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * Trailer POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class TrailerDTO extends AuditDTO implements Serializable {

   
    private static final long serialVersionUID = 1L;
    private Integer trailerId;
    private String trailerNo;
    
    public Integer getTrailerId() {
        return trailerId;
    }
    public void setTrailerId(Integer trailerId) {
        this.trailerId = trailerId;
    }
    public String getTrailerNo() {
        return trailerNo;
    }
    public void setTrailerNo(String trailerNo) {
        this.trailerNo = trailerNo;
    }

}
