package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * DelayReasonCodeDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@JsonAutoDetect
public class DelayReasonCodeDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String delayReasonId;
    private String description;
    private String delayType;
    private String subType; 
    private String alertCode ;
    private char machineStoppage;
    private char isDelayOpen ;
    
    public String getDelayReasonId() {
        return delayReasonId;
    }
    public void setDelayReasonId(String delayReasonId) {
        this.delayReasonId = delayReasonId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getDelayType() {
        return delayType;
    }
    public void setDelayType(String delayType) {
        this.delayType = delayType;
    }
    public String getSubType() {
        return subType;
    }
    public void setSubType(String subType) {
        this.subType = subType;
    }
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    public char getIsDelayOpen() {
        return isDelayOpen;
    }
    public void setIsDelayOpen(char isDelayOpen) {
        this.isDelayOpen = isDelayOpen;
    }
    public char getMachineStoppage() {
        return machineStoppage;
    }
    public void setMachineStoppage(char machineStoppage) {
        this.machineStoppage = machineStoppage;
    }
    
    
    
}
