package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * TroubleShootArea POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class TroubleShootAreaDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String troubleShootAreaId;
    private String description;
    private String terminalId;
    private String availability;
    
    
    public String getTroubleShootAreaId() {
        return troubleShootAreaId;
    }
    public void setTroubleShootAreaId(String troubleShootAreaId) {
        this.troubleShootAreaId = troubleShootAreaId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getAvailability() {
        return availability;
    }
    public void setAvailability(String availability) {
        this.availability = availability;
    }

   
}
