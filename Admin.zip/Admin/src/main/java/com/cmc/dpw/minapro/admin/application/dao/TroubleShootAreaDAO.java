package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.TroubleShootAreaDTO;
import com.cmc.dpw.minapro.admin.application.entities.TroubleShootArea;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * TroubleShootAreaDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class TroubleShootAreaDAO extends GenericDAO<TroubleShootArea> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(TroubleShootArea.class);
    /**
     * This method is used to search TroubleShootAreas
     * @param troubleShootAreaIdVal
     * @param descriptionVal
     * @param terminalIdVal
     * @param availabilityVal
     * @param start
     * @param limit
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchTroubleShootAreas(String troubleShootAreaIdVal, String descriptionVal,
            String terminalIdVal, String availabilityVal, int start, int limit) {
        
        Map<String, Object> resultMap = new HashMap<String, Object>();
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering into TroubleShootArea's searchTroubleShootArea's method..");
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(TroubleShootArea.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] requestParameters = { troubleShootAreaIdVal, descriptionVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchTroubleAreas with troubleShoot Id:{}, and description:{}",
                requestParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(troubleShootAreaIdVal))  && troubleShootAreaIdVal != null) {
            likeValue = "";
            String troubleShootAreaId = likeValue.concat(percentage).concat(troubleShootAreaIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("troubleShootAreaId", troubleShootAreaId).ignoreCase());
        }

        if (!("".equalsIgnoreCase(descriptionVal))  && descriptionVal != null) {
            likeValue = "";

            
            String  description = likeValue.concat(percentage).concat(descriptionVal).concat(percentage);
            searchCriteria.add(Restrictions.like("description", description).ignoreCase());

        }

        if (!("".equalsIgnoreCase(terminalIdVal))  && terminalIdVal != null)  {
            likeValue = "";
            String terminalId = likeValue.concat(percentage).concat(terminalIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("terminalId", terminalId).ignoreCase());
        }

        if (!("".equalsIgnoreCase(availabilityVal))  && availabilityVal != null) {
            likeValue = "";

            String availability = likeValue.concat(percentage).concat(availabilityVal).concat(percentage);
            searchCriteria.add(Restrictions.like("availability", availability).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******* Count: {}", count);
        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<TroubleShootArea> searchTroubleShootAreas = (List<TroubleShootArea>) searchCriteria.list();
        List<TroubleShootAreaDTO> searchTroubleShootAreasDtoList =  util.map(searchTroubleShootAreas, TroubleShootAreaDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("****** data:{}", searchTroubleShootAreasDtoList);
        LOGGER.debug("***** total Records : {}", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchTroubleShootAreasDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        for (TroubleShootArea troubleShootArea : searchTroubleShootAreas) {
            LOGGER.debug("********* troubleShootAreaId : {}", troubleShootArea.getTroubleShootAreaId());
        }

        LOGGER.debug("**** Exiting from TroubleShootArea DAO ...");
        return resultMap;
    }
}
