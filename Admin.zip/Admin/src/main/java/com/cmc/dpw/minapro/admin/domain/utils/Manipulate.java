package com.cmc.dpw.minapro.admin.domain.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
 * @author Bhavesh
 * 
 *         This annotation is meant to use for publishing message to RDT queues. Message contains only the table name RDT
 *         will use this information to refresh the cache.
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Manipulate {
    String table() default "";

    String[] tables() default "";
}
