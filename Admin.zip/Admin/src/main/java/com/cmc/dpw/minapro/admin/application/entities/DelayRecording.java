package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the violation details
 * 
 * @author Imran
 * 
 */
@Entity
@Table(name = "MP_DELAY_RECORDING")
public class DelayRecording implements Serializable {

    private static final long serialVersionUID = -902967598250209660L;

    @Id
    @Column(name = "DELAY_ID")
    private int delayId;

    @Column(name = "DELAY_CODE")
    private String delayCode;

    @Column(name = "TERMINAL_ID")
    private String terminalId;

    @Column(name = "ROTATION_ID")
    private String rotationId;

    @Column(name = "EQUIPMENT_ID")
    private String equipmentID;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "ISDELETED")
    private String isDeleted;

    @Column(name = "DELAY_START_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date delayStartTime;

    @Column(name = "DELAY_END_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date delayEndTime;

    @Column(name = "IS_AUTOMATIC")
    private String isAutomated;

    public DelayRecording() {
    }

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public int getdelayId() {
        return delayId;
    }

    public void setdelayId(int delayId) {
        this.delayId = delayId;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getDealyCode() {
        return delayCode;
    }

    public void setDealyCode(String delayCode) {
        this.delayCode = delayCode;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getdelayStartTime() {
        return delayStartTime;
    }

    public void setdelayStartTime(Date startTime) {
        this.delayStartTime = startTime;
    }

    public Date getdelayEndTime() {
        return delayEndTime;
    }

    public void setdelayEndTime(Date endTime) {
        this.delayEndTime = endTime;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getIsAutomated() {
        return isAutomated;
    }

    public void setIsAutomated(String isAutomated) {
        this.isAutomated = isAutomated;
    }

}
