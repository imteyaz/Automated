package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.VesselExceptionDAO;
import com.cmc.dpw.minapro.admin.application.dto.VesselExceptionDTO;
import com.cmc.dpw.minapro.admin.application.entities.VesselExceptionEntity;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * VesselExceptionEntity Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class VesselExceptionService {

    @Autowired
    private VesselExceptionDAO vesselExceptionDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselExceptionService.class);

    /**
     * This method is used to read VesselExceptionEntity
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<VesselExceptionEntity> getVesselExceptionList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  VesselExceptionEntity service's getVesselExceptionList");
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);
        return vesselExceptionDAO.findAll();

    }

    /**
     * This method is used to read VesselExceptionEntity
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchVesselExceptionList(String vesselExceptionId, String vesselName, String rotation, String exceptionType,
            String vesselNo, Boolean onlyCountRequired, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselExceptionEntity service's searchVesselExceptionList method");
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);

        String[] requestParameters = { vesselExceptionId, vesselName, rotation, exceptionType, vesselNo };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In VesselExceptionEntity service searchVesselExceptionList  with vesselExceptionId: {} , vesselExceptionName : {}, make : {}, model : {}, vesselExceptionTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionEntity service's searchVesselExceptionList method");

        return vesselExceptionDAO.searchVesselExceptions(vesselExceptionId, vesselName, rotation, exceptionType, vesselNo, onlyCountRequired, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<VesselExceptionEntity> containing the created VesselExceptionEntity data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_VESSEL_EXCEPTIONS")
    public List<VesselExceptionEntity> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselExceptionEntity service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  vesselException service's  create : {} ", data);

        List<VesselExceptionEntity> newVesselExceptions = new ArrayList<VesselExceptionEntity>();
        List<VesselExceptionEntity> list = util.getEntitiesFromDto(data, VesselExceptionDTO.class ,VesselExceptionEntity.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (VesselExceptionEntity vesselException : list) {

            Date currentDate = new Date();
            vesselException.setCreatedDateTime(currentDate);
            vesselException.setCreatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselExceptionEntity Id property in vesselException service's create : {}",
                    vesselException.getVesselExceptionId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling vesselException DAO findOne");

            VesselExceptionEntity alreadyVesselException = vesselExceptionDAO.findOne(vesselException.getVesselExceptionId());

            if (alreadyVesselException == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling vesselException DAO create");
                newVesselExceptions.add(vesselExceptionDAO.create(vesselException));
            } else {
                char isDeleted = 'N' ;

                if (isDeleted == 'Y') {
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling vesselException DAO update");
                    newVesselExceptions.add(vesselExceptionDAO.update(vesselException));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionEntity service's create method");
        return newVesselExceptions;
    }

    /**
     * This method is used to update VesselExceptionEntity
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<VesselExceptionEntity> containing the updated VesselExceptionEntity datas
     */
    @Transactional
    @Manipulate(table = "MP_VESSEL_EXCEPTIONS")
    public List<VesselExceptionEntity> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselExceptionEntity service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  vesselException  service's  update : {} ", data);
        List<VesselExceptionEntity> returnVesselExceptions = new ArrayList<VesselExceptionEntity>();

        List<VesselExceptionEntity> updatedVesselExceptions = util.getEntitiesFromDto(data, VesselExceptionDTO.class ,VesselExceptionEntity.class);

        for (VesselExceptionEntity vesselException : updatedVesselExceptions) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"vesselExceptionId property in vesselException service update : {}", vesselException.getVesselExceptionId());
            returnVesselExceptions.add(vesselExceptionDAO.update(vesselException));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionEntity service's update method");

        return returnVesselExceptions;
    }

    /**
     * This method is used to delete VesselExceptionEntity
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_VESSEL_EXCEPTIONS")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselExceptionEntity service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In vesselException's service delete : {} ", data);
       
        List<VesselExceptionEntity> deletedVesselExceptions = util.getEntitiesFromDto(data, VesselExceptionDTO.class ,VesselExceptionEntity.class);

        for (VesselExceptionEntity vesselException : deletedVesselExceptions) {
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselExceptionEntity Id property in vesselException service delete : {}",vesselException.getVesselExceptionId());
            vesselExceptionDAO.delete(vesselException);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionEntity service's delete method");
    }
    
    @Transactional
    public void createVesselException(VesselExceptionEntity vesselException) {
        
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);
        vesselExceptionDAO.create(vesselException);
    }
    
    @Transactional(readOnly = true)
    public  List<VesselExceptionEntity> findAllOPUSVesselExceptions() {
        
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);
       return vesselExceptionDAO.findByPropertyValue(VesselExceptionEntity.class, "createdBy", "Admin App OPUS Scheduler", true);
        
    }

    @Transactional
    public void updateVesselException(VesselExceptionEntity equipmentNotFoundException) {
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);
        vesselExceptionDAO.update(equipmentNotFoundException);
        
    }

    @Transactional
    public void clearVesselExceptionsForRotation(Integer rotationNumber) {
        vesselExceptionDAO.setClazz(VesselExceptionEntity.class);
        vesselExceptionDAO.deleteByRotationNo(rotationNumber);
    }
    
    
    

}
