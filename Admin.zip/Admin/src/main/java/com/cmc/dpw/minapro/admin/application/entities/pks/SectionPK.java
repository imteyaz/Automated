package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key to identify the sections defined in a vessel.
 * 
 * @author Rosemary George
 * 
 */
@Embeddable
public class SectionPK implements Serializable {

    private static final long serialVersionUID = 2440278774156955823L;

    @Column(name = "INT_VSL_NO")
    private int vesselNo;

    @Column(name = "INT_SECT_NO")
    private int sectionNo;

    public int getSectionNo() {
        return sectionNo;
    }

    public void setSectionNo(int sectionNo) {
        this.sectionNo = sectionNo;
    }

    public int getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(int vesselNo) {
        this.vesselNo = vesselNo;
    }

}
