package com.cmc.dpw.minapro.admin.web.security;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.domain.utils.AesUtil;

public class Encrypter {
    
    private Encrypter(){
        super();
    }

    public static String decryptPassword(int keySize, int iterationCount,String salt,String iv, String ciphertext){
            
            String passphrase = MessageConstants.PASSPHRASE ;
            AesUtil aesUtil = new AesUtil(keySize, iterationCount);
            return aesUtil.decrypt(salt, iv, passphrase, ciphertext);
    }
}
