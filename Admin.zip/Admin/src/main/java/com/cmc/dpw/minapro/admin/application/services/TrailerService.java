package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.TrailerDAO;
import com.cmc.dpw.minapro.admin.application.dto.TrailerDTO;
import com.cmc.dpw.minapro.admin.application.entities.Trailer;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Trailer Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class TrailerService {

    @Autowired
    private TrailerDAO trailerDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(TrailerService.class);

    /**
     * This method is used to read Trailer
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Trailer> getTrailerList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Trailer service's getTrailerList");
        trailerDAO.setClazz(Trailer.class);
        return trailerDAO.findAll();

    }

    /**
     * This method is used to read Trailer
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchTrailerList(String trailerNo, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Trailer service's searchTrailerList method");
        trailerDAO.setClazz(Trailer.class);

        String[] requestParameters = { trailerNo};
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Trailer service searchTrailerList  with trailerNo: {} ",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Trailer service's searchTrailerList method");

        return trailerDAO.searchTrailers(trailerNo, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Trailer> containing the created Trailer data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_TRAILER_MASTER")
    public List<Trailer> create(String data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Trailer service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  trailer service's  create : {} ", data);

        List<Trailer> newTrailers = new ArrayList<Trailer>();
        List<Trailer> list =  util.fetchEntitiesFromDto(data, TrailerDTO.class,Trailer.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Trailer trailer : list) {

            Date currentDate = new Date();
            trailer.setCreatedDateTime(currentDate);
            trailer.setLastUpdatedDateTime(currentDate);
            trailer.setCreatedBy(userId.toString());
            trailer.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Trailer Id property in trailer service's create : {}",
                    trailer.getTrailerId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling trailer DAO findOne");

            Trailer alreadyTrailer = checkUniqueness(trailer) ;

            if (alreadyTrailer == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"calling trailer DAO create");
                newTrailers.add(trailerDAO.create(trailer));
            } else {
                char isDeleted = alreadyTrailer.getIsDeleted();

                if (isDeleted == 'Y') {
                    trailer.setVersion(alreadyTrailer.getVersion());
                    trailer.setIsDeleted('N');
                    trailer.setTrailerId(alreadyTrailer.getTrailerId());
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling trailer DAO update");
                    newTrailers.add(trailerDAO.update(trailer));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        
        
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Trailer service's create method");
        return newTrailers;
    }

    
    private Trailer checkUniqueness(Trailer trailer){
        
        Trailer duplicateTrailer = null ;
        
        List<Trailer> duplicateTrailerList = trailerDAO.findByPropertyValue(Trailer.class, "trailerNo", trailer.getTrailerNo(), true);
        
        if(!duplicateTrailerList.isEmpty()){
            duplicateTrailer = duplicateTrailerList.get(0);
        }
        
        return duplicateTrailer ;
    }
    
    
    /**
     * This method is used to update Trailer
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Trailer> containing the updated Trailer datas
     * @throws ExistingRecordException 
     */
    @Transactional
    @Manipulate(table = "MP_TRAILER_MASTER")
    public List<Trailer> update(String data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Trailer service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  trailer  service's  update : {} ", data);
        List<Trailer> returnTrailers = new ArrayList<Trailer>();

        List<Trailer> updatedTrailers = util.fetchEntitiesFromDto(data, TrailerDTO.class,Trailer.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Trailer trailer : updatedTrailers) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"trailerId property in trailer service update : {}", trailer.getTrailerId());
            trailer.setLastUpdatedDateTime(currentDate);
            trailer.setLastUpdatedBy(userId.toString());

            Trailer alreadyTrailer = checkUniqueness(trailer) ;

            if (alreadyTrailer == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +" updating straightaway as no existing trailer no found as duplicate");
                returnTrailers.add(trailerDAO.update(trailer));
            } else {
                char isDeleted = alreadyTrailer.getIsDeleted();

                if (isDeleted == 'Y') {
                    trailer.setVersion(alreadyTrailer.getVersion());
                    trailer.setIsDeleted('N');
                    trailer.setTrailerId(alreadyTrailer.getTrailerId());
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"updating after changing isdeleted to N from Y as duplicate found");
                    returnTrailers.add(trailerDAO.update(trailer));
                } else {
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }
            
            
            returnTrailers.add(trailerDAO.update(trailer));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Trailer service's update method");

        return returnTrailers;
    }

    /**
     * This method is used to delete Trailer
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_TRAILER_MASTER")
    public void delete(String data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Trailer service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In trailer's service delete : {} ", data);
        List<Trailer> deletedTrailers =  util.fetchEntitiesFromDto(data, TrailerDTO.class,Trailer.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Trailer trailer : deletedTrailers) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Trailer Id property in trailer service delete : {}",
                    trailer.getTrailerId());
            trailer.setLastUpdatedDateTime(currentDate);
            trailer.setLastUpdatedBy(userId.toString());
            trailer.setIsDeleted('Y');
            trailerDAO.delete(trailer);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Trailer service's delete method");
    }

}
