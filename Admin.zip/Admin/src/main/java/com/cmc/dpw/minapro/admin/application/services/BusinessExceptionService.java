package com.cmc.dpw.minapro.admin.application.services;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.dao.BusinessExceptionDAO;
import com.cmc.dpw.minapro.admin.application.entities.BusinessExceptionEntity;

/**
 * BusinessExceptionEntity Service
 * 
 * 
 */
@Service
public class BusinessExceptionService {
    
    @Autowired
    private BusinessExceptionDAO businessExceptionDAO;
    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessExceptionService.class) ;
    
    @Transactional(readOnly=true)
    public List<BusinessExceptionEntity> getBusinessExceptionList(){
        LOGGER.info("###########Entering  BusinessExceptionEntity service's getBusinessExceptionList");
        businessExceptionDAO.setClazz(BusinessExceptionEntity.class);
        return businessExceptionDAO.findAll();
    }
    
    @Transactional(readOnly=true)
    public Map<String, Object> searchBusinessExceptionList(String containerId,String rotationNo, String businessExceptionType,String functionCode, int start,int limit){
        LOGGER.info("############Entering BusinessExceptionEntity service's searchBusinessExceptionList method");
        businessExceptionDAO.setClazz(BusinessExceptionEntity.class);
        LOGGER.info("############calling DAO and Exiting BusinessExceptionEntity service's searchBusinessExceptionList method");
        return businessExceptionDAO.searchBusinessExceptionsHeaders(containerId,rotationNo,businessExceptionType,functionCode,start,limit);
    }
    
}
