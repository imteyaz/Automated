package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.RotationControlDTO;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.entities.RotationControl;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * RotationControl DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class RotationControlDAO extends GenericDAO<RotationControl> {

    @Autowired
    private Util util;
    @Autowired
    private VesselExceptionDAO vesselExceptionsDAO;
    private static final Logger LOGGER = LoggerFactory.getLogger(RotationControlDAO.class);
    /**
     * This method is used to search RotationControls
     * @param rotationNumberVal
     * @param equipmentIdVal
     * @param vesselCodeVal
     * @param parsedFromDateVal
     * @param parsedToDateVal
     * @param activeVal
     * @param start
     * @param limit
     * @param berthNoVal
     * @param terminalIdVal
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchRotationControls(String rotationNumberVal, String equipmentIdVal,
            String vesselCodeVal, Date parsedFromDateVal, Date parsedToDateVal, String activeVal, int start, int limit,
            String berthNoVal, String terminalIdVal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering RotationControl DAO's searchRotationControls method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";
        int i = 0;

        Criteria searchCriteria = session.createCriteria(RotationControl.class, "rotation");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String parsedFromDate = "";
        if (parsedFromDateVal != null) {
            parsedFromDate = parsedFromDateVal.toString();
        }
        String[] searchParameters = { rotationNumberVal, equipmentIdVal, vesselCodeVal, parsedFromDate, activeVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchRotationControls in RotationControl DAO with rotationNumber: {} , equipmentId : {} , vesselCode : {} , etaDate : {} , active : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        searchCriteria.addOrder(Order.asc(MessageConstants.ETADATE));
       
        if  (!("".equalsIgnoreCase(rotationNumberVal)) && rotationNumberVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.eq("rotationNumber", Integer.parseInt(rotationNumberVal)));
            i++;
        }
       
        if  (!("".equalsIgnoreCase(vesselCodeVal)) && vesselCodeVal != null) {
            likeValue = "";
            searchCriteria.createAlias("rotation.actualVessel", "vessel");
            String  vesselCode = likeValue.concat(percentage).concat(vesselCodeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("vessel.vesselCode", vesselCode).ignoreCase());
            i++;
        }
        
        if   (!("".equalsIgnoreCase(equipmentIdVal)) && equipmentIdVal != null) {
            likeValue = "";
            searchCriteria.createAlias("rotation.actualEquipments", "equipment");
            String equipmentId = likeValue.concat(percentage).concat(equipmentIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("equipment.equipmentId", equipmentId).ignoreCase());
            i++;
        }
        
        if  (!("".equalsIgnoreCase(activeVal)) && activeVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.eq("status", activeVal).ignoreCase());
            i++;
        }

        if (parsedFromDateVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.ge(MessageConstants.ETADATE, parsedFromDateVal));
            i++;
        }

        if (parsedToDateVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.le(MessageConstants.ETADATE, parsedToDateVal));
            i++;
        }
        if (!("".equalsIgnoreCase(berthNoVal)) && berthNoVal != null) {
            likeValue = "";
            String berthNo = likeValue.concat(percentage).concat(berthNoVal).concat(percentage);
            searchCriteria.add(Restrictions.like("berthNo", berthNo).ignoreCase());
            i++;
        }

        if (!("".equalsIgnoreCase(terminalIdVal))  && terminalIdVal != null) {
            likeValue = "";
            String terminalId = likeValue.concat(percentage).concat(terminalIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("terminalId", terminalId).ignoreCase());
            i++;
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<RotationControl> searchRotationControls = null;

        if (i == 0) {
            Query query = session
                    .createQuery("select distinct r from RotationControl r left join fetch r.actualEquipments where r.isDeleted ='N' order by r.etaDate asc");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<RotationControl> rotationControlList = query.list();

            LOGGER.debug("currentRotationControl using HQL");

            for (RotationControl currentRotationControl : rotationControlList) {

                LOGGER.debug(currentRotationControl.getRotationNumber() + "has equipments :");

            }
            searchRotationControls = rotationControlList;
        } else {

            searchRotationControls = new ArrayList<RotationControl>();
            LOGGER.debug("######Criteria executing#############");
            List<RotationControl> tempRotationControls = (List<RotationControl>) searchCriteria.list();
            for (Object temp : tempRotationControls) {

                Object[] rotationArray = (Object[]) temp;

                searchRotationControls.add((RotationControl) rotationArray[MessageConstants.ARRAY_TWO]);
            }

        }
        
      

        String totalRecords = count.toString();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" Searching rotation Control..following records found : ");

        for (RotationControl currentRotationControl : searchRotationControls) {

            List<Equipment> equipments = (List) currentRotationControl.getActualEquipments();
            List<String> actualEquipmentsList = new ArrayList<String>();

            for (Equipment currentEquipment : equipments) {
                String currentEquipmentId = currentEquipment.getEquipmentId();
                LOGGER.debug("currentEquipment: " + currentEquipmentId);
                actualEquipmentsList.add(currentEquipmentId);
            }
            String allEquipments = StringUtils.join(actualEquipmentsList, ',');

            currentRotationControl.setAllEquipments(allEquipments);
            currentRotationControl.setEquipmentId(allEquipments);
            LOGGER.debug("###################");

            Vessel correspondingVessel = currentRotationControl.getActualVessel();
            String vesselCode = correspondingVessel.getVesselCode();
            Integer vesselNo = correspondingVessel.getVesselNo();

            currentRotationControl.setVesselCode(vesselCode);
            currentRotationControl.setVesselNo(vesselNo);
            currentRotationControl.setEta(currentRotationControl.getEtaDate());
            
            
            String rotationVal  = currentRotationControl.getRotationNumber().toString() ;
            
            Map<String, Object> exceptionRecordsMap = vesselExceptionsDAO.searchVesselExceptions(null, null, rotationVal, null, null, true, 0, 10000);
            String totalExceptionRecords = (String) exceptionRecordsMap.get(MessageConstants.TOTALCOUNT_KEY);
            currentRotationControl.setErrorCount(Integer.parseInt(totalExceptionRecords));

            LOGGER.debug(" -> rotationControl Id  : {}", currentRotationControl.getRotationNumber());
        }
        
        List<RotationControlDTO> searchRotationControlsDtoList =  util.map(searchRotationControls, RotationControlDTO.class);
        
        LOGGER.debug("******* data from DB: {}", searchRotationControlsDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchRotationControlsDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" exiting rotationControlDAO's searchRotationControls method ");
        return resultMap;
    }
    
}


