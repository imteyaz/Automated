package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class WeightageFactorPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private String weightageType;
    private String weightageCriteria;

    @Column(name = "WF_TYPE")
    public String getWeightageType() {
        return weightageType;
    }

    public void setWeightageType(String weightageType) {
        this.weightageType = weightageType;
    }

    @Column(name = "WF_CRITERIA")
    public String getWeightageCriteria() {
        return weightageCriteria;
    }

    public void setWeightageCriteria(String weightageCriteria) {
        this.weightageCriteria = weightageCriteria;
    }
}
