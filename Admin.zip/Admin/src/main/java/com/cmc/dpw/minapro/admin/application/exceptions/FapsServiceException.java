/**
 * 
 */
package com.cmc.dpw.minapro.admin.application.exceptions;


/**
 * @author Bhavesh
 * 
 *         Top level class for Exception is FAPS application. All other Application Exception must be derived from this
 *         class
 */
public class FapsServiceException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private final FapsExceptionType exceptionType;

    public FapsServiceException() {
        super();
        exceptionType = FapsExceptionType.DEFAULT ;
    }

    public FapsServiceException(String exceptionMessage) {

        super(exceptionMessage);
        exceptionType = FapsExceptionType.DEFAULT ;
    }

    public FapsServiceException(Throwable throwable) {

        super(throwable);
        exceptionType = FapsExceptionType.DEFAULT ;
    }

    public FapsServiceException(String exceptionMessage, Throwable throwable) {

        super(exceptionMessage, throwable);
        exceptionType = FapsExceptionType.DEFAULT ;
    }

    public FapsServiceException(FapsExceptionType exceptionType, Throwable e) {
        super(e);
        this.exceptionType = exceptionType;
    }

    public FapsExceptionType getExceptionType() {
        return exceptionType;
    }

}
