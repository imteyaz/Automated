package com.cmc.dpw.minapro.admin.web.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
public class LoginController {

    /**
     * This method is used to login
     * @param error
     * @param logout
     * @param timeout
     * @param request
     * @return ModelAndView
     */
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView login(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            @RequestParam(value = "timeout", required = false) String timeout, HttpServletRequest request) {
        ModelAndView model = new ModelAndView();
      
        if (error != null) {
            model.addObject("error", "Invalid username or password !");
        }

        if (logout != null) {
            model.addObject("msg", "You've been logged out successfully.");

        }

        if (timeout != null) {
            model.addObject("msg", "Sorry, your session expired. Please login again !");
        }

        model.setViewName("login");

        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        return model;

    }
    
    /**
     * This method is used to welcome user
     * @return ModelAndView
     */
    @RequestMapping(value = "/welcome", method = RequestMethod.GET)
    public ModelAndView welocmeUser() {

        ModelAndView model = new ModelAndView();
       
        model.setViewName("index");
        model.addObject("appVersion", MessageConstants.APP_VERSION);
      

        return model;

    }

}