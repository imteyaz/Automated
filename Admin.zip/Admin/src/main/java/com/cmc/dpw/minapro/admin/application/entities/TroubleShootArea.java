package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * TroubleShootArea POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "TroubleShootArea")
@Table(name = "MP_TROUBLESHOOTAREA_MASTER")
public class TroubleShootArea extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String troubleShootAreaId;
    private String description;
    private String terminalId;
    private String availability;

    @Id
    @Column(name = "TROUBLESHOOT_AREA_ID", nullable = false)
    public String getTroubleShootAreaId() {
        return troubleShootAreaId;
    }

    public void setTroubleShootAreaId(String troubleShootAreaId) {
        this.troubleShootAreaId = troubleShootAreaId;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @Column(name = "AVAILABILITY", nullable = false)
    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
    
}
