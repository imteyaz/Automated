package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.BayPk;

/**
 * ValueObject holding the bay details for a vessel
 * 
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_BAY_SPM")
public class Bay implements Serializable {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset
     */
    @EmbeddedId
    private BayPk pk;

    @Column(name = "VSL_BAY_NO")
    private String vesselBayNo;

    @Column(name = "LOGICAL_BAY_FLG")
    private char isLogicalBay;

    @Column(name = "CNTR_ROW_PRSNT_FLG")
    private char isContainerRowPresent;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;
    
    @Column(name = "TIER_TEMPLATE")
    private String tierTemplate;
    

    public BayPk getPk() {
        return pk;
    }

    public void setPk(BayPk pk) {
        this.pk = pk;
    }

    public String getVesselBayNo() {
        return vesselBayNo;
    }

    public void setVesselBayNo(String vesselBayNo) {
        this.vesselBayNo = vesselBayNo;
    }

    public char isLogicalBay() {
        return isLogicalBay;
    }

    public void setIsLogicalBay(char isLogicalBay) {
        this.isLogicalBay = isLogicalBay;
    }

    public char isContainerRowPresent() {
        return isContainerRowPresent;
    }

    public void setIsContainerRowPresent(char isContainerRowPresent) {
        this.isContainerRowPresent = isContainerRowPresent;
    }

    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    public Integer getBayOffset() {
        return pk.getBayOffset();
    }

    public void setBayOffset(Integer bayOffset) {
        pk.setBayOffset(bayOffset);
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getTierTemplate() {
        return tierTemplate;
    }

    public void setTierTemplate(String tierTemplate) {
        this.tierTemplate = tierTemplate;
    }

    public char getIsLogicalBay() {
        return isLogicalBay;
    }

    public char getIsContainerRowPresent() {
        return isContainerRowPresent;
    }
 
    
}
