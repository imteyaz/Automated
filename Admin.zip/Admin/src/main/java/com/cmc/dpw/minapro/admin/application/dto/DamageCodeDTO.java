package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Collection;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * DamageCodeDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@JsonAutoDetect
public class DamageCodeDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageCodePk;
    private String description;
    private String damageSeverityCode;
    private String terminalId;
    private String damageTypeId;
    private String damageLocationId;
    private String allDamageLocations;
    private Collection<DamageLocationDTO> actualDamageLocations;
    
    
    public String getDamageCodePk() {
        return damageCodePk;
    }
    public void setDamageCodePk(String damageCodePk) {
        this.damageCodePk = damageCodePk;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getDamageSeverityCode() {
        return damageSeverityCode;
    }
    public void setDamageSeverityCode(String damageSeverityCode) {
        this.damageSeverityCode = damageSeverityCode;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getDamageTypeId() {
        return damageTypeId;
    }
    public void setDamageTypeId(String damageTypeId) {
        this.damageTypeId = damageTypeId;
    }
    public String getDamageLocationId() {
        return damageLocationId;
    }
    public void setDamageLocationId(String damageLocationId) {
        this.damageLocationId = damageLocationId;
    }
    public String getAllDamageLocations() {
        return allDamageLocations;
    }
    public void setAllDamageLocations(String allDamageLocations) {
        this.allDamageLocations = allDamageLocations;
    }
    public Collection<DamageLocationDTO> getActualDamageLocations() {
        return actualDamageLocations;
    }
    public void setActualDamageLocations(Collection<DamageLocationDTO> actualDamageLocations) {
        this.actualDamageLocations = actualDamageLocations;
    }

}
