package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dao.NumSrsHeaderDAO;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsDetails;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsHeader;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;

/**
 * NumSrsHeader Service
 * 
 * 
 */
@Service
public class NumSrsHeaderService {
    
    @Autowired
    private NumSrsHeaderDAO numSrsHeaderDAO;
    @Autowired
    private GenericDAO genericDAO ;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(NumSrsHeaderService.class) ;

    @Transactional(readOnly=true)
    public List<NumSrsHeader> getNumSrsHeaderList(){
        LOGGER.info("###########Entering  NumSrsHeader service's getNumSrsHeaderList");
        numSrsHeaderDAO.setClazz(NumSrsHeader.class);
        return numSrsHeaderDAO.findAll();
    }
    
    @Transactional(readOnly=true)
    public Map<String, Object> searchNumSrsHeaderList(String numSrsHeaderId,String numSrsHeaderName, String numSrsHeaderTypeId,int start,int limit){
        LOGGER.info("############Entering NumSrsHeader service's searchNumSrsHeaderList method");
        
        numSrsHeaderDAO.setClazz(NumSrsHeader.class);
        
        String[] requestParameters={numSrsHeaderId,numSrsHeaderName,numSrsHeaderTypeId};
        LOGGER.debug("************In NumSrsHeader service searchNumSrsHeaderList  with numSrsHeaderId: {} , numSrsHeaderName : {}, numSrsHeaderTypeId : {}", requestParameters);
        LOGGER.info("############Exiting NumSrsHeader service's searchNumSrsHeaderList method");
        
        return numSrsHeaderDAO.searchNumSrsHeaders(numSrsHeaderId,numSrsHeaderName,numSrsHeaderTypeId,start,limit);
    }
    
    
    private List<NumSrsHeader> create(List<NumSrsHeader> newNumSrsHeaders ,String userId) throws ExistingRecordException{
        LOGGER.info("###########Entering NumSrsHeader service's create method");
        
        List<NumSrsHeader> createdNumSrsHeaders = new ArrayList<NumSrsHeader>();
        
        for (NumSrsHeader numSrsHeader : newNumSrsHeaders){
            
            Date currentDate =  new Date();
            
            numSrsHeader.setInsDttm(currentDate);
            numSrsHeader.setUpdDttm(currentDate);
            numSrsHeader.setUpdUsrCd(userId);
            numSrsHeader.setInsUsrCd(userId);
            
            LOGGER.debug("***********NumSrsHeader Id property in numSrsHeader service's create : {}", numSrsHeader.getNumSrsId());
            LOGGER.info("###########calling numSrsHeader DAO findOne");
         
            NumSrsHeader alreadyNumSrsHeader =  numSrsHeaderDAO.findOne(numSrsHeader.getNumSrsId());
            
            if(alreadyNumSrsHeader==null){
                LOGGER.info("###########calling numSrsHeader DAO create");
                createdNumSrsHeaders.add(numSrsHeaderDAO.create(numSrsHeader));
            }else{
                char isDeleted = alreadyNumSrsHeader.getIsDeleted();
                
                if(isDeleted=='Y'){
                    numSrsHeader.setIsDeleted('N');
                    LOGGER.info("###########calling numSrsHeader DAO update");
                    createdNumSrsHeaders.add(numSrsHeaderDAO.update(numSrsHeader));
                }else{
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                //end of else BELOW - entity not null
            }
            //end of for loop BELOW
        }  
            LOGGER.info("##########Exiting NumSrsHeader service's create method");
            return createdNumSrsHeaders;
    }
    
    
    private List<NumSrsHeader> update(List<NumSrsHeader> updatedNumSrsHeaders, String userId){
        LOGGER.info("###########Entering NumSrsHeader service's update method");
        List<NumSrsHeader> modifiedNumSrsHeaders = new ArrayList<NumSrsHeader>();
        
        for (NumSrsHeader numSrsHeader : updatedNumSrsHeaders){
            Date currentDate =  new Date();
            LOGGER.debug("***********numSrsHeaderId property in numSrsHeader service update : {}", numSrsHeader.getNumSrsId());
            numSrsHeader.setUpdDttm(currentDate);
            numSrsHeader.setUpdUsrCd(userId);
            modifiedNumSrsHeaders.add(numSrsHeaderDAO.update(numSrsHeader));
        }
        LOGGER.info("############Exiting NumSrsHeader service's update method");
        return modifiedNumSrsHeaders;
    }
    
    
    private void delete(List<NumSrsHeader> deletedNumSrsHeaders, String userId){
        LOGGER.info("###########Entering NumSrsHeader service's delete method");
        
        for (NumSrsHeader numSrsHeader : deletedNumSrsHeaders){
            Date currentDate =  new Date();
            LOGGER.debug("***********NumSrsHeader Id property in numSrsHeader service delete : {}", numSrsHeader.getNumSrsId());
            numSrsHeader.setIsDeleted('Y');
            numSrsHeader.setUpdDttm(currentDate);
            numSrsHeader.setUpdUsrCd(userId);
            numSrsHeaderDAO.delete(numSrsHeader) ;
        }
        LOGGER.info("############Exiting NumSrsHeader service's delete method");
    }
   
    @Transactional
    public void saveChanges(List<NumSrsDetails> delChildRecordsList,
            List<NumSrsDetails> newChildRecordsList, List<NumSrsDetails> updatedChildRecordsList,
            List<NumSrsHeader> newRecordsList, List<NumSrsHeader> updatedRecordsList, List<NumSrsHeader> delRecordsList, Principal principal) throws ExistingRecordException {
        
        Integer userId = util.getUserIdFromPrincipal(principal); 
        String userIdString = userId.toString();
        Date currentDate = new Date();
        
        if(delChildRecordsList!=null && !delChildRecordsList.isEmpty()){
            genericDAO.setClazz(NumSrsDetails.class);
            for(NumSrsDetails numSrsDetails : delChildRecordsList ){
                numSrsDetails.setIsDeleted('Y');
                numSrsDetails.setUpdDttm(currentDate);
                numSrsDetails.setUpdUsrCd(userIdString);
                genericDAO.hardDelete(numSrsDetails);
            }
        }
        
        if(newChildRecordsList!=null && !newChildRecordsList.isEmpty()){
            genericDAO.setClazz(NumSrsDetails.class);
            for(NumSrsDetails numSrsDetails : newChildRecordsList ){
                numSrsDetails.setUpdDttm(currentDate);
                numSrsDetails.setUpdUsrCd(userIdString);
                numSrsDetails.setInsDttm(currentDate);
                numSrsDetails.setInsUsrCd(userIdString);
                genericDAO.create(numSrsDetails);
            }
        }
        if(updatedChildRecordsList!=null && !updatedChildRecordsList.isEmpty()){
            genericDAO.setClazz(NumSrsDetails.class);
            for(NumSrsDetails numSrsDetails : updatedChildRecordsList ){
                numSrsDetails.setUpdDttm(currentDate);
                numSrsDetails.setUpdUsrCd(userIdString);
                genericDAO.update(numSrsDetails);
            }
        }
        
        if(newRecordsList!=null && !newRecordsList.isEmpty()){
            create(newRecordsList,userIdString);
        }
        
        if(updatedRecordsList!=null && !updatedRecordsList.isEmpty()){
            update(updatedRecordsList,userIdString);
        }
        
        if(delRecordsList!=null && !delRecordsList.isEmpty()){
            delete(delRecordsList, userIdString);
        }
        
    }

    
}
