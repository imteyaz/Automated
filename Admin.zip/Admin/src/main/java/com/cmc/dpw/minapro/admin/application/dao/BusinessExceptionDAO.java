package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.dto.BusinessExceptionDTO;
import com.cmc.dpw.minapro.admin.application.entities.BusinessExceptionDetails;
import com.cmc.dpw.minapro.admin.application.entities.BusinessExceptionEntity;
import com.cmc.dpw.minapro.admin.domain.utils.Util;


/**
 * BusinessExceptionEntity DAO class.
 * 
 */
@Repository
public class BusinessExceptionDAO extends GenericDAO<BusinessExceptionEntity>{
    
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessExceptionDAO.class) ;
    
    public Map<String, Object> searchBusinessExceptionsHeaders(String containerIdVal,String rotationNoVal,String businessExceptionTypeVal,String functionCodeVal, int start,int limit ){
        
        LOGGER.info("############ Entering BusinessExceptionEntity DAO's searchBusinessExceptionsHeaders method");
        
        Map<String,Object> resultMap = new HashMap<String,Object>();
        
         Session session = getCurrentSession();
         int i =0 ;
         
        Criteria searchCriteria = session.createCriteria(BusinessExceptionEntity.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        
             Util.addIntgerRestrictions(searchCriteria, "rotationNo", rotationNoVal);
        i =  Util.addRestrictions(searchCriteria, "cotainerId", containerIdVal, false,i);
        i =  Util.addRestrictions(searchCriteria, "exceptionType", businessExceptionTypeVal, false,i);
        i =  Util.addRestrictions(searchCriteria, "functionCode", functionCodeVal, false,i);
        
        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();
        searchCriteria.setProjection(null);
    
        List<BusinessExceptionEntity> searchBusinessExceptions =  null ;
        
        StringBuilder sql = new StringBuilder("select u from BusinessExceptionEntity u where 1 = 1 ") ; 
              
              if(containerIdVal !=null && !containerIdVal.isEmpty()){
                  sql.append(" and lower(u.cotainerId) like lower('%" + containerIdVal + "%')") ;
              }
              
              if(businessExceptionTypeVal !=null && !businessExceptionTypeVal.isEmpty()){
                  sql.append(" and lower(u.exceptionType) like lower('%" + businessExceptionTypeVal + "%')") ;
              }
              
              if(functionCodeVal !=null && !functionCodeVal.isEmpty()){
                  sql.append(" and lower(u.functionCode) like lower('%" + functionCodeVal + "%')") ;
              }
              
              if(rotationNoVal !=null && !rotationNoVal.isEmpty()){
                  sql.append(" and u.rotationNo = " + rotationNoVal ) ;
              }
              
              
              Query query = session.createQuery(sql.toString());
              query.setMaxResults(limit);
              query.setFirstResult(start);
              
            LOGGER.debug("Going to execute following HQL :" + sql.toString() );
            List<BusinessExceptionEntity> businessExceptionList = query.list();
            LOGGER.debug("businessExceptionsList size using list.size " + businessExceptionList.size());
            LOGGER.debug("businessExceptionsList using HQL");
            
            searchBusinessExceptions = businessExceptionList ;
        
         for(BusinessExceptionEntity businessException: searchBusinessExceptions){
             LOGGER.debug(" ********* current businessException's Id  : {}" ,businessException.getExceptionId()); 
             List<BusinessExceptionDetails> currentDetails =  (List<BusinessExceptionDetails>) businessException.getBusinessExceptionDetails() ;
             
             for(BusinessExceptionDetails currentBusinessExceptionDetails: currentDetails){
                String exceptionCode = currentBusinessExceptionDetails.getPk().getExceptionCode() ;
                currentBusinessExceptionDetails.setTempExceptionCode(exceptionCode);
             }
         
         }
         
        List<BusinessExceptionDTO> searchBusinessExceptionDtoList =  util.map(searchBusinessExceptions, BusinessExceptionDTO.class);
        String totalRecords = count.toString();
        
        LOGGER.debug("******* data from DB: {}" ,searchBusinessExceptionDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}" ,totalRecords); 
        
         resultMap.put("data",searchBusinessExceptionDtoList);
         resultMap.put("totalCount",totalRecords) ;
        
         LOGGER.debug("********* exiting businessExceptionDAO's searchBusinessExceptionsHeaders method ") ;
         return resultMap ;
       }
    
}
