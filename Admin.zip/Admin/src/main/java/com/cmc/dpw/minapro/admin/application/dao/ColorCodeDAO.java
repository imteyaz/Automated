package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.ColorCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ColorCode;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ColorCode DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class ColorCodeDAO extends GenericDAO<ColorCode> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ColorCodeDAO.class);
/**
 * This method is used to search ColorCodes
 * @param itemNameVal
 * @param itemGroupVal
 * @param start
 * @param limit
 * @return Map<String, Object>
 */
    public Map<String, Object> searchColorCodes(String itemNameVal, String itemGroupVal, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ColorCode DAO's searchColorCodes method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(ColorCode.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { itemNameVal, itemGroupVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchColorCodes in ColorCode DAO with itemName: {} , itemGroup : {} , make : {} , model : {} , colorCodeTypeId : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(itemNameVal))  && itemNameVal != null) {
            likeValue = "";

            String itemName = likeValue.concat(percentage).concat(itemNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("itemName", itemName).ignoreCase());

        }

        if (!("".equalsIgnoreCase(itemGroupVal))  && itemGroupVal != null) {
            likeValue = "";

            String itemGroup = likeValue.concat(percentage).concat(itemGroupVal).concat(percentage);
            searchCriteria.add(Restrictions.like("itemGroup", itemGroup).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<ColorCode> searchColorCodes = (List<ColorCode>) searchCriteria.list();
        List<ColorCodeDTO> searchColorCodeDtoList =  util.map(searchColorCodes, ColorCodeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data from DB: {}", searchColorCodeDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchColorCodeDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        for (ColorCode colorCode : searchColorCodes) {

            LOGGER.debug(" ********* colorCode Id  : {}", colorCode.getColorCodeId());
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" exiting colorCodeDAO's searchColorCodes method ");
        return resultMap;
    }
}
