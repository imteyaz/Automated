package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.PinningStation;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.PinningStationService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/pinningStation")
public class PinningStationController {

    @Autowired
    private PinningStationService pinningStationService;
    private static final Logger LOGGER = LoggerFactory.getLogger(PinningStationController.class);
    /**
     * This method is used to search pinningStation
     * @param pinningStationId
     * @param terminalId
     * @param availability
     * @param limit
     * @param start
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String pinningStationId,
            @RequestParam(required = false) String terminalId, @RequestParam(required = false) String availability,
            @RequestParam(required = false) int limit, @RequestParam(required = false) int start) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start PinningStationController Seacrh PinningStation method");
        
        String[] requestParameters = { pinningStationId, terminalId, availability };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"PinningStationController-->search pinningStationId:{}, terminalId:{},availability:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStationController Seacrh PinningStation method");

            Map<String, Object> pinningMap = pinningStationService.searchPinningStationList(pinningStationId,
                    terminalId, availability, start, limit);

            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStationController Seacrh PinningStation method");
            return getMap(pinningMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"PinningStationController-->Seacrh PinningStation-->Catch Block :{}", e);
            return getModelMapError("Error retrieving PinningStations from database.");
        }
    }

    /**
     * This method creates the PinningStation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal)  {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start PinningStationController Create PinningStation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<PinningStation> pinningStations = pinningStationService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStationController Create PinningStation method");
            return getMap(pinningStations);

        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError("Error trying to create PinningStation due to following exception :{}" + cause.getMessage());
            
        }  catch ( ExistingRecordException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create PinningStation :{}" + e.getCustomErrorMessage());
            
        }   catch (Exception e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create pinningStation.");
        }
    }

    /**
     * This method updates the PinningStation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start PinningStationController Update PinningStation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<PinningStation> pinningStations = pinningStationService.update(data, principal);

            return getMap(pinningStations);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update pinningStation. ");
        }
    }

    /**
     * This method deletes the PinningStation.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start PinningStationController Delete PinningStation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            pinningStationService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStationController Delete PinningStation method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete pinningStation.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<PinningStation> pinningStations) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, pinningStations);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> pinningMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) pinningMap.get("totalCount");

        List<PinningStation> pinningStations = (List<PinningStation>) pinningMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", pinningStations);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, pinningStations);
        modelMap.put(MessageConstants.SUCCESS_KEY,  true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> modelMap 
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
