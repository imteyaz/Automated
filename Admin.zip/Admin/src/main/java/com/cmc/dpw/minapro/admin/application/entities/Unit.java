package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Unit POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Unit")
@Table(name = "MP_UNIT_MASTER")
public class Unit extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;

    private String unitId;
    private String unitName;
    private String unitDescription;
    

    @Id
    @Column(name = "UNIT_ID", nullable = false)
    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }

    @Column(name = "UNIT_NAME", nullable = false)
    public String getUnitName() {
        return unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    @Column(name = "UNIT_DESC")
    public String getUnitDescription() {
        return unitDescription;
    }

    public void setUnitDescription(String unitDescription) {
        this.unitDescription = unitDescription;
    }

}