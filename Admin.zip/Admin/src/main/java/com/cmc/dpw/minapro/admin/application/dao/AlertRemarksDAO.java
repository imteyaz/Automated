package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.AlertRemarksDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertRemarks;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * AlertRemarks DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class AlertRemarksDAO extends GenericDAO<AlertRemarks> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRemarksDAO.class);
    @Autowired
    private Util util;
    /**
     * This method is used to search AlertRemarkss
     * @param Map<String,Object> alertRecordId
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchAlertRemarkss(String alertRecordId,int start,int limit) {
        
        String[] searchParameters = { alertRecordId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  "Processing searchAlertRemarks in AlertRemarks DAO with alertRecordId: {}  ", searchParameters);

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(AlertRemarks.class, "alertRemarks");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        searchCriteria.addOrder(Order.desc("createdDateTime"));
       
        Util.addIntgerRestrictions(searchCriteria, "alertRecordId", alertRecordId);
       
        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+ " count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        LOGGER.debug("######executing Criteria #############");
        List<AlertRemarks> searchAlertRemarks = (List<AlertRemarks>) searchCriteria.list();
       
        List<AlertRemarksDTO> alertRemarksDtoList =  util.map(searchAlertRemarks, AlertRemarksDTO.class); 

        String totalRecords = count.toString();

        LOGGER.debug("******* data from DB: {}", searchAlertRemarks);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", alertRemarksDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" Finished Searching Alert Remarks..following records found : " );

        for (AlertRemarks currentAlertRemarks : searchAlertRemarks) {

              Integer recordId =  currentAlertRemarks.getAlertRecordId();
              Integer remarkId =   currentAlertRemarks.getAlertRemarkId() ;
              LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" Alert Record Id : "  + recordId+  " & Alert remarks id : " + remarkId);
         
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" exiting alertRemarksDAO's searchAlertRemarkss method ");
        return resultMap;
    }
  
   
   

    
}


