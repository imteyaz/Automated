package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.ActivityTypeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ActivityType;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ActivityType DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Repository
public class ActivityTypeDAO extends GenericDAO<ActivityType> {
    
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityTypeDAO.class);
/**
 * This method is used to search ActivityTypes
 * @param activityTypeIdVal
 * @param descriptionVal
 * @param start
 * @param limit
 * @return Map<String, Object>
 */
    public Map<String, Object> searchActivityTypes(String activityTypeIdVal, String descriptionVal, int start, int limit) {
        
        LOGGER.info( MessageConstants.INFO_INDICATOR +"Entering ActivityType DAO's searchActivityTypes method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(ActivityType.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { activityTypeIdVal, descriptionVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchActivityTypes with activityTypeId: {} , description : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(activityTypeIdVal)) && activityTypeIdVal != null ) {
            likeValue = "";

            String activityTypeId = likeValue.concat(percentage).concat(activityTypeIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("activityTypeId", activityTypeId).ignoreCase());


        }

        if (!("".equalsIgnoreCase(descriptionVal)) && descriptionVal != null) {
            likeValue = "";

            String description = likeValue.concat(percentage).concat(descriptionVal).concat(percentage);
            searchCriteria.add(Restrictions.like("description", description).ignoreCase());


        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<ActivityType> searchActivityTypes = (List<ActivityType>) searchCriteria.list();
        List<ActivityTypeDTO> searchActivityTypesDtoList =  util.map(searchActivityTypes, ActivityTypeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("data: {}", searchActivityTypesDtoList);
        LOGGER.debug("totalCount: {}", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchActivityTypesDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        for (ActivityType activityType : searchActivityTypes) {
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityTypeId from activityTypes List: {}", activityType.getActivityTypeId());

        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting ActivityType's DAO searchActivityTypes method ");

        return resultMap;
    }

}
