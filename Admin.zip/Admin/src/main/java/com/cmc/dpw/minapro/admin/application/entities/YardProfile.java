/*package com.cmc.dpw.minapro.admin.application.entities;

public class YardProfile {

}
 */

package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class YardProfile implements Serializable {

    private Integer blkNo;
    private String blkType;
    private String blkId;
    private Integer wrkgStkgHt;
    private Integer maxStkgHt;
    private Integer rowCount;
    private Integer sktCount;
    private Integer stkSeqNo;
    private String blkStkNo;
    private Integer rowSeqNo;
    private String blkRowNo;

    @Id
    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    public String getBlkType() {
        return blkType;
    }

    public void setBlkType(String blkType) {
        this.blkType = blkType;
    }

    public String getBlkId() {
        return blkId;
    }

    public void setBlkId(String blkId) {
        this.blkId = blkId;
    }

    public Integer getMaxStkgHt() {
        return maxStkgHt;
    }

    public void setMaxStkgHt(Integer maxStkgHt) {
        this.maxStkgHt = maxStkgHt;
    }

    public Integer getWrkgStkgHt() {
        return wrkgStkgHt;
    }

    public void setWrkgStkgHt(Integer wrkgStkgHt) {
        this.wrkgStkgHt = wrkgStkgHt;
    }

    public Integer getRowCount() {
        return rowCount;
    }

    public void setRowCount(Integer rowCount) {
        this.rowCount = rowCount;
    }

    public Integer getSktCount() {
        return sktCount;
    }

    public void setSktCount(Integer sktCount) {
        this.sktCount = sktCount;
    }

    public Integer getStkSeqNo() {
        return stkSeqNo;
    }

    public void setStkSeqNo(Integer stkSeqNo) {
        this.stkSeqNo = stkSeqNo;
    }

    public String getBlkStkNo() {
        return blkStkNo;
    }

    public void setBlkStkNo(String blkStkNo) {
        this.blkStkNo = blkStkNo;
    }

    public Integer getRowSeqNo() {
        return rowSeqNo;
    }

    public void setRowSeqNo(Integer rowSeqNo) {
        this.rowSeqNo = rowSeqNo;
    }

    public String getBlkRowNo() {
        return blkRowNo;
    }

    public void setBlkRowNo(String blkRowNo) {
        this.blkRowNo = blkRowNo;
    }

    @Override
    public String toString() {
        return "YardProfile [blkNo=" + blkNo + ", blkType=" + blkType + ", blkId=" + blkId + ", wrkgStkgHt="
                + wrkgStkgHt + ", maxStkgHt=" + maxStkgHt + ", rowCount=" + rowCount + ", sktCount=" + sktCount
                + ", stkSeqNo=" + stkSeqNo + ", blkStkNo=" + blkStkNo + ", rowSeqNo=" + rowSeqNo + ", blkRowNo="
                + blkRowNo + "]";
    }

}
