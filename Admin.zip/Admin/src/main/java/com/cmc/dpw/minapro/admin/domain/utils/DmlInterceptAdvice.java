package com.cmc.dpw.minapro.admin.domain.utils;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Pointcut;
import org.springframework.aop.support.AbstractPointcutAdvisor;

public class DmlInterceptAdvice extends AbstractPointcutAdvisor {

    public Pointcut getPointcut() {

        return null;
    }

    public Advice getAdvice() {

        return null;
    }

}