package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * EquipmentTypeDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class EquipmentTypeDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String equipmentTypeId;
    private String equipmentDescription;
    
    public String getEquipmentTypeId() {
        return equipmentTypeId;
    }
    public void setEquipmentTypeId(String equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }
    public String getEquipmentDescription() {
        return equipmentDescription;
    }
    public void setEquipmentDescription(String equipmentDescription) {
        this.equipmentDescription = equipmentDescription;
    }
   
    
    
}
