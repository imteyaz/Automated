package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonBackReference;


/**
 * Role POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class RoleDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private int intUserGroupId;
    private String userGroupCd;
    private String sDesc;
    private String userGroupName;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;

    private String srvTypeGroupCd;
    private char isDeleted;
    private Collection<UserDTO> actualUsers = new ArrayList<UserDTO>();
    private Integer version;
    private String createdBy;
    private String lastUpdatedBy;
    private Date createdDateTime;
    private Date lastUpdatedDateTime;
    
    public int getIntUserGroupId() {
        return intUserGroupId;
    }
    public void setIntUserGroupId(int intUserGroupId) {
        this.intUserGroupId = intUserGroupId;
    }
    public String getUserGroupCd() {
        return userGroupCd;
    }
    public void setUserGroupCd(String userGroupCd) {
        this.userGroupCd = userGroupCd;
    }
    public String getsDesc() {
        return sDesc;
    }
    public void setsDesc(String sDesc) {
        this.sDesc = sDesc;
    }
    public String getUserGroupName() {
        return userGroupName;
    }
    public void setUserGroupName(String userGroupName) {
        this.userGroupName = userGroupName;
    }
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }
    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }
    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }
    public String getSrvTypeGroupCd() {
        return srvTypeGroupCd;
    }
    public void setSrvTypeGroupCd(String srvTypeGroupCd) {
        this.srvTypeGroupCd = srvTypeGroupCd;
    }
    public char getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
    
    @JsonBackReference
    public Collection<UserDTO> getActualUsers() {
        return actualUsers;
    }
    public void setActualUsers(Collection<UserDTO> actualUsers) {
        this.actualUsers = actualUsers;
    }
    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }
    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }
    
}
