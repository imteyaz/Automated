package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.VesselExceptionEntity;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.VesselExceptionService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/vesselException")
public class VesselExceptionController {

    @Autowired
    private VesselExceptionService vesselExceptionService;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselExceptionController.class);

    /**
     * This method searches for all the vesselExceptions matching the search criteria
     * as entered by the end user
     * 
     * @param vesselExceptionId
     * @param vesselName
     * @param rotation
     * @param exceptionType
     * @param vesselNo
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String vesselExceptionId,
            @RequestParam(required = false) String vesselName, @RequestParam(required = false) String rotation,
            @RequestParam(required = false) String exceptionType, @RequestParam(required = false) String vesselNo,
            @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselExceptionController Seacrh VesselExceptionEntity method");
     
        String[] requestParameters = { vesselExceptionId, vesselName, rotation, exceptionType, vesselNo };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselExceptionController-->search vesselExceptionId:{},vesselName :{},rotation :{},exceptionType:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselExceptionController Seacrh VesselExceptionEntity method");

            Map<String, Object> vesselExceptionsMap = vesselExceptionService.searchVesselExceptionList(vesselExceptionId, vesselName, rotation,
                    exceptionType, vesselNo, false ,start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionController Seacrh VesselExceptionEntity method");
            return getMap(vesselExceptionsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselExceptionController-->search VesselExceptionEntity-->Catch Block :{}", e);
            return getModelMapError("Error retrieving VesselExceptions from database.");
        }
    }

    /**
     * This method creates the vesselException as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created vesselException data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start> VesselExceptionController> Create VesselExceptionEntity method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Data{}", data);

        try {
            List<VesselExceptionEntity> vesselExceptions = vesselExceptionService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionController Create VesselExceptionEntity method");
            return getMap(vesselExceptions);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create vesselException due to following exception  :{}" + cause.getMessage());
            
        }   catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create vesselException :{}" + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create vesselException.");
        }

    }
    
    /**
     * This method updates the vesselException as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated vesselException data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselExceptionController Update VesselExceptionEntity method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<VesselExceptionEntity> vesselExceptions = vesselExceptionService.update(data, principal);
            return getMap(vesselExceptions);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update vesselException. ");

        }
    }

    
    /**
     * This method deletes the vesselException.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted vesselException data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselExceptionController Delete VesselExceptionEntity method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            vesselExceptionService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselExceptionController Delete VesselExceptionEntity method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete vesselException.");

        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param vesselExceptions List of vesselExceptions
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<VesselExceptionEntity> vesselExceptions) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", vesselExceptions);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> vesselExceptionsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) vesselExceptionsMap.get("totalCount");

        List<VesselExceptionEntity> vesselExceptions = (List<VesselExceptionEntity>) vesselExceptionsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", vesselExceptions);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, vesselExceptions);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }
   
}
