package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_BLKSTK_YPM")
public class YardStack implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer blkNo;
    private Integer stkSeqNo;
    private String blkStkNo;
    private Integer wrkStkgHt;
    private Integer conStkNo;
    private String allowdFlg;
    private String stkNo;
    private Integer slotLen;
    private String slotLenUom;
    private String delFlg;
    private String doorDirn;
    private String wrkStkgHtUom;
    private String numsrsFlg;
    private Integer rfrContrctrNo;
    private Integer verStamp;
    private String usrCd;
    private Date insDttm;
    private String insUsrFlg;
    private String updUsrCd;
    private Date updDttm;
    private String updUsrFlg;
    private String txnCd;
    private Integer txnNo;

    @Id
    @Column(name = "INT_BLK_NO")
    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    @Id
    @Column(name = "STK_SEQ_NO")
    public Integer getStkSeqNo() {
        return stkSeqNo;
    }

    public void setStkSeqNo(Integer stkSeqNo) {
        this.stkSeqNo = stkSeqNo;
    }

    @Column(name = "BLK_STK_NO")
    public String getBlkStkNo() {
        return blkStkNo;
    }

    public void setBlkStkNo(String blkStkNo) {
        this.blkStkNo = blkStkNo;
    }

    @Column(name = "WRK_STKG_HT")
    public Integer getWrkStkgHt() {
        return wrkStkgHt;
    }

    public void setWrkStkgHt(Integer wrkStkgHt) {
        this.wrkStkgHt = wrkStkgHt;
    }

    @Column(name = "CONTIGUITY_STK_NO")
    public Integer getConStkNo() {
        return conStkNo;
    }

    public void setConStkNo(Integer conStkNo) {
        this.conStkNo = conStkNo;
    }

    @Column(name = "RFR_ALLOWD_FLG")
    public String getAllowdFlg() {
        return allowdFlg;
    }

    public void setAllowdFlg(String allowdFlg) {
        this.allowdFlg = allowdFlg;
    }

    @Column(name = "STK_NO_40")
    public String getStkNo() {
        return stkNo;
    }

    public void setStkNo(String stkNo) {
        this.stkNo = stkNo;
    }

    @Column(name = "STK_SLOT_LEN")
    public Integer getSlotLen() {
        return slotLen;
    }

    public void setSlotLen(Integer slotLen) {
        this.slotLen = slotLen;
    }

    @Column(name = "STK_SLOT_LEN_UOM")
    public String getSlotLenUom() {
        return slotLenUom;
    }

    public void setSlotLenUom(String slotLenUom) {
        this.slotLenUom = slotLenUom;
    }

    @Column(name = "DEL_FLG")
    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    @Column(name = "DOOR_DIRN_IND")
    public String getDoorDirn() {
        return doorDirn;
    }

    public void setDoorDirn(String doorDirn) {
        this.doorDirn = doorDirn;
    }

    @Column(name = "WRKG_STKG_HT_UOM")
    public String getWrkStkgHtUom() {
        return wrkStkgHtUom;
    }

    public void setWrkStkgHtUom(String wrkStkgHtUom) {
        this.wrkStkgHtUom = wrkStkgHtUom;
    }

    @Column(name = "APPLY_NUMSRS_FLG")
    public String getNumsrsFlg() {
        return numsrsFlg;
    }

    public void setNumsrsFlg(String numsrsFlg) {
        this.numsrsFlg = numsrsFlg;
    }

    @Column(name = "INT_RFR_CONTRCTR_NO")
    public Integer getRfrContrctrNo() {
        return rfrContrctrNo;
    }

    public void setRfrContrctrNo(Integer rfrContrctrNo) {
        this.rfrContrctrNo = rfrContrctrNo;
    }

    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Column(name = "ADT_INS_USR_CD")
    public String getUsrCd() {
        return usrCd;
    }

    public void setUsrCd(String usrCd) {
        this.usrCd = usrCd;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getInsUsrFlg() {
        return insUsrFlg;
    }

    public void setInsUsrFlg(String insUsrFlg) {
        this.insUsrFlg = insUsrFlg;
    }

    @Column(name = "ADT_UPD_USR_CD")
    public String getUpdUsrCd() {
        return updUsrCd;
    }

    public void setUpdUsrCd(String updUsrCd) {
        this.updUsrCd = updUsrCd;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }

    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdUsrFlg() {
        return updUsrFlg;
    }

    public void setUpdUsrFlg(String updUsrFlg) {
        this.updUsrFlg = updUsrFlg;
    }

    @Column(name = "ADT_TXN_CD")
    public String getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }

    @Column(name = "ADT_TXN_NO")
    public Integer getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }

}
