package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.ActivityTypeDAO;
import com.cmc.dpw.minapro.admin.application.dto.ActivityTypeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ActivityType;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ActivityType Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class ActivityTypeService {

    @Autowired
    private ActivityTypeDAO activityTypeDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityTypeService.class);

    /**
     * This method is used to get ActivityType List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<ActivityType> getActivityTypeList() {
   LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  ActivityType service's getActivityTypeList");
        activityTypeDAO.setClazz(ActivityType.class);
        return activityTypeDAO.findAll();

    }

    /**
     * This method is used to  search ActivityType List
     * @return Map<String, Object> containing the search ActivityType data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchActivityTypeList(String activityTypeId, String description, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityType service's searchActivityTypeList method");
        activityTypeDAO.setClazz(ActivityType.class);

        String[] requestParameters = { activityTypeId, description };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR +"In ActivityType service searchActivityTypeswith activityTypeId: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType service's searchActivityTypeList method");
        return activityTypeDAO.searchActivityTypes(activityTypeId, description, start, limit);

    }

    /**
     * This method is used to create activityType
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ActivityType> containing list of ActivityType
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITYTYPES_MASTER")
    public List<ActivityType> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityType service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  activityType service's  create : {} ", data);
      
        List<ActivityType> newActivityTypes = new ArrayList<ActivityType>();

        List<ActivityType> newActivityTypesList = util.getEntitiesFromDto(data, ActivityTypeDTO.class, ActivityType.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (ActivityType activityType : newActivityTypesList) {

            Date currentDate = new Date();

            activityType.setCreatedDateTime(currentDate);
            activityType.setLastUpdatedDateTime(currentDate);
            activityType.setCreatedBy(userId.toString());
            activityType.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityTypeId property in activityType service create : {}",
                    activityType.getActivityTypeId());

            ActivityType alreadyActivityType = activityTypeDAO.findOne(activityType.getActivityTypeId());

            if (alreadyActivityType == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling activityType DAO");
                newActivityTypes.add(activityTypeDAO.create(activityType));
            } else {
                char isDeleted = alreadyActivityType.getIsDeleted();

                if (isDeleted == 'Y') {
                    activityType.setVersion(alreadyActivityType.getVersion());
                    activityType.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling activityType DAO update");
                    newActivityTypes.add(activityTypeDAO.update(activityType));
                }   else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null   
            }
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType service's create method");
        return newActivityTypes;
    }

    /**
     * This method is used to update activityType
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ActivityType>
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITYTYPES_MASTER")
    public List<ActivityType> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityType service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  activityType  service's  update : {} ", data);
        List<ActivityType> returnActivityTypes = new ArrayList<ActivityType>();
        
        List<ActivityTypeDTO> updatedActivityTypesDto = util.getEntitiesFromRequest(data, ActivityTypeDTO.class);
        List<ActivityType> updatedActivityTypes =  util.map(updatedActivityTypesDto, ActivityType.class);
        
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ActivityType activityType : updatedActivityTypes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityTypeId property in activityType service update : {}",
                    activityType.getActivityTypeId());
            activityType.setLastUpdatedDateTime(currentDate);
            activityType.setLastUpdatedBy(userId.toString());
            returnActivityTypes.add(activityTypeDAO.update(activityType));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType service's update method");
        return returnActivityTypes;
    }

    /**
     * This method is used to delete activityType
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITYTYPES_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityType service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In activityType's service delete : {} ", data);
        
        List<ActivityTypeDTO> deletedActivityTypesDto = util.getEntitiesFromRequest(data, ActivityTypeDTO.class);
        List<ActivityType> deletedActivityTypes =  util.map(deletedActivityTypesDto, ActivityType.class);                
        
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ActivityType activityType : deletedActivityTypes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityTypeId property in activityType service delete : {}",
                    activityType.getActivityTypeId());
            activityType.setLastUpdatedDateTime(currentDate);
            activityType.setLastUpdatedBy(userId.toString());
            activityType.setIsDeleted('Y');
            activityTypeDAO.delete(activityType);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType service's delete method");
    }

}
