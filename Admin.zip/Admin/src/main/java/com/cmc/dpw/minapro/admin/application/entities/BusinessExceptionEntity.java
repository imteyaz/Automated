package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObjcet holding the template header details
 * @author Imran Rawani
 *
 */
@Entity
@Table(name= "MP_BUSINESS_EXCEPTION")
public class BusinessExceptionEntity implements Serializable{
   
    private static final long serialVersionUID = -7920596353659481286L;

    @Id
    @Column(name="EXCEPTION_ID")
    private Integer exceptionId;
    
    @Column(name="EXCEPTION_TYPE")
    private String exceptionType;
    
    @Column(name="EXCEPTION_DESC")
    private String exceptionDesc;
    
    @Column(name="CONTAINER_ID")
    private String cotainerId;
    
    @Column(name="ROTATION_NO")
    private Integer rotationNo;
    
    @Column(name="FUNCTION_CODE")
    private String functionCode;
    
    @Column(name="CREATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDateTime;
    
    @Column(name="CREATED_BY")
    private String createdBy;
  
    @OneToMany(fetch=FetchType.EAGER)
    @JoinColumn(name = "EXCEPTION_ID", referencedColumnName = "EXCEPTION_ID", insertable = false, updatable = false)
    
    private Collection<BusinessExceptionDetails>  businessExceptionDetails = new ArrayList<BusinessExceptionDetails>();

    public Integer getExceptionId() {
        return exceptionId;
    }

    public void setExceptionId(Integer exceptionId) {
        this.exceptionId = exceptionId;
    }

    public String getExceptionType() {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    public String getExceptionDesc() {
        return exceptionDesc;
    }

    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    public String getCotainerId() {
        return cotainerId;
    }

    public void setCotainerId(String cotainerId) {
        this.cotainerId = cotainerId;
    }

    public Integer getRotationNo() {
        return rotationNo;
    }

    public void setRotationNo(Integer rotationNo) {
        this.rotationNo = rotationNo;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Collection<BusinessExceptionDetails> getBusinessExceptionDetails() {
        return businessExceptionDetails;
    }

    public void setBusinessExceptionDetails(Collection<BusinessExceptionDetails> businessExceptionDetails) {
        this.businessExceptionDetails = businessExceptionDetails;
    }

}
