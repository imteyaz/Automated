package com.cmc.dpw.minapro.admin.application.services;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
/**
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Service
public class CommonsService {

    @Autowired
    private GenericDAO genericDAO;
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonsService.class);

    @Transactional(readOnly = true)
    public Map<String, Object> fetchForeignKeyList(String entityName, String columnName, String filterColumnName,
            String filterColumnVal, String query, int start, int limit) {
        /**
         * This method is used to fetch ForeignKey List
         * @return genericDAO
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Commons service's fetchForeignKetList method");
        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Commons service fetchForeignKeyList  with entityName: {} , columnName : {}, query : {}",
                fetchParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Commons service's fetchForeignKetList method");
        return genericDAO.findForeignKeys(entityName, columnName, filterColumnName, filterColumnVal, query, start,limit);
    }
    
    @Transactional(readOnly = true)
    public Map<String, Object> fetchRecordsWithoutAssociation(String entityName, String columnName, String filterColumnName,
            String filterColumnVal, String query, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Commons service's fetchRecordsWithoutAssociation method");
        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Commons service fetchRecordsWithoutAssociation  with entityName: {} , columnName : {}, query : {}",
                fetchParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Commons service's fetchRecordsWithoutAssociation method");
        return genericDAO.fetchRecordsWithoutAssociation(entityName, columnName, filterColumnName, filterColumnVal, query, start,limit);
    }
    
    @Transactional(readOnly = true)
    public Map<String, Object> findIntegerForeignKeys(String entityName, String columnName, String filterColumnName,
            String filterColumnVal, String query, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Commons service's findIntegerForeignKeys method");
        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Commons service findIntegerForeignKeys  with entityName: {} , columnName : {}, query : {}",
                fetchParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Commons service's findIntegerForeignKeys method");
        
        return genericDAO.fetchRecordsWithoutAssociation(entityName, columnName, filterColumnName, filterColumnVal, query, start,limit);
    }
    
    
    @Transactional(readOnly = true)
    public Map<String, Object> fetchForeignKeysByFilters(String entityName, Map<String, Object> columnValuePairs,Map<String, Object> filtersMap, Boolean checkEquality, String orElseAnd, String query, int start, int limit) {
        /**
         * This method is used to fetchForeignKeysByFilters
         * @return genericDAO
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Commons service's fetchForeignKeysByFilters method");
        String[] fetchParameters = { entityName, query, orElseAnd };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Commons service fetchForeignKeysByFilters  with entityName: {} , query : {}, orElseAnd : {}",
                fetchParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Commons service's fetchForeignKeysByFilters method");
        return genericDAO.getFilteredRecordsBasedOnCondition(entityName, columnValuePairs,filtersMap, checkEquality, orElseAnd,query,start,limit);
    }

}
