package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cmc.dpw.minapro.admin.application.entities.pks.NumberingSeriesDetailsPk;
/**
 * NumSrsDetailsDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NumSrsDetailsDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer seqNo;
    private String no20Ft;
    private String no40Ft;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insExtUsrFlg;
    private String updUsrCd;
    private Date updDttm;
    private String updExtUsrFlg;
    private String txnCd;
    private Integer txnNo;
    private char isDeleted;
    private NumberingSeriesDetailsPk pk;
    public Integer getSeqNo() {
        return seqNo;
    }
    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }
    public String getNo20Ft() {
        return no20Ft;
    }
    public void setNo20Ft(String no20Ft) {
        this.no20Ft = no20Ft;
    }
    public String getNo40Ft() {
        return no40Ft;
    }
    public void setNo40Ft(String no40Ft) {
        this.no40Ft = no40Ft;
    }
    public Integer getVerStamp() {
        return verStamp;
    }
    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }
    public String getInsUsrCd() {
        return insUsrCd;
    }
    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }
    public Date getInsDttm() {
        return insDttm;
    }
    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }
    public String getInsExtUsrFlg() {
        return insExtUsrFlg;
    }
    public void setInsExtUsrFlg(String insExtUsrFlg) {
        this.insExtUsrFlg = insExtUsrFlg;
    }
    public String getUpdUsrCd() {
        return updUsrCd;
    }
    public void setUpdUsrCd(String updUsrCd) {
        this.updUsrCd = updUsrCd;
    }
    public Date getUpdDttm() {
        return updDttm;
    }
    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }
    public String getUpdExtUsrFlg() {
        return updExtUsrFlg;
    }
    public void setUpdExtUsrFlg(String updExtUsrFlg) {
        this.updExtUsrFlg = updExtUsrFlg;
    }
    public String getTxnCd() {
        return txnCd;
    }
    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }
    public Integer getTxnNo() {
        return txnNo;
    }
    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }
    public char getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
    public NumberingSeriesDetailsPk getPk() {
        return pk;
    }
    public void setPk(NumberingSeriesDetailsPk pk) {
        this.pk = pk;
    }

}

