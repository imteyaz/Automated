package com.cmc.dpw.minapro.admin.application.opus.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.opus.dao.OpusVesselDao;
import com.cmc.dpw.minapro.admin.application.opus.entities.OpusEquipmentDto;
import com.cmc.dpw.minapro.admin.application.opus.entities.OpusVesselDto;

@Service
public class OpusVesselService {
    
    @Autowired
    private OpusVesselDao opusVesselDao ;
    private static final Logger LOGGER = LoggerFactory.getLogger(OpusVesselService.class);
    
    
    @Transactional(value="opusTransactionManager",readOnly=true)
    public List<OpusVesselDto> fetchRegisteredRotations() {
       return opusVesselDao.fetchRegisteredRotations();
    }
    
    @Transactional(value="opusTransactionManager",readOnly=true)
    public List<OpusEquipmentDto> fetchEquipmentsForRotation(String rotationNo) {
        return opusVesselDao.fetchEquipmentsForRotation(rotationNo);
     }

    @Transactional(value="opusTransactionManager",readOnly=true)
    public List<OpusVesselDto> fetchBerthedRotations(String atomRegisteredRotations) {
        return opusVesselDao.fetchBerthedRotations(atomRegisteredRotations);
        
    }
    
    @Transactional(value="opusTransactionManager",readOnly=true)
    public List<OpusVesselDto> fetchSailedRotations(String atomBerthedRotations) {
        return opusVesselDao.fetchSailedRotations(atomBerthedRotations);
    }

}
