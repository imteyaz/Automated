package com.cmc.dpw.minapro.admin.application.dto;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;

public class GenericGroupAssociationDTO {
    private String groupId;
    private String associateId;
    private Integer accessCode;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAssociateId() {
        return associateId;
    }

    public void setAssociateId(String associateId) {
        this.associateId = associateId;
    }

    @Override
    public int hashCode() {
        final int prime = MessageConstants.THIRITY_ONE;
        int result = MessageConstants.ARRAY_ONE;
        result = prime * result + ((associateId == null) ? 0 : associateId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
       
        GenericGroupAssociationDTO other = (GenericGroupAssociationDTO) obj;
        if (associateId == null && other.associateId != null || !associateId.equals(other.associateId)) {
            return false;
        }
        return true;
    }

    public Integer getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(Integer accessCode) {
        this.accessCode = accessCode;
    }

}
