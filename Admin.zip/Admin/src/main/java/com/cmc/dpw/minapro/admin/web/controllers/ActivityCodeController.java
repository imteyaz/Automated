package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.ActivityCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.ActivityCodeService;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Controller - Spring
 * 
 * @author Imran Rawani
 * @since  2014-Dec 
 */

@Controller
@RequestMapping(value = "/activityCode")
public class ActivityCodeController {
   
    @Autowired
    private ActivityCodeService activityCodeService;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityCodeController.class);
    
    /**This method searches for all the activityCodes matching the search criteria
     * as entered by the end user
     * @param activityId
     * @param activityTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody
    public Map<String, Object> view(@RequestParam(required = false) String activityId,
            @RequestParam(required = false) String activityTypeId, @RequestParam(required = false) int limit,
            @RequestParam(required = false) int start) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode controller's Search method");
        String[] requestParameters = { activityId, activityTypeId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ActivityCodeCntroller-->Search activityId :{}, activityTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ActivityCode controller's Search method");

            Map<String, Object> equipmentsMap = activityCodeService.searchActivityCodeList(activityId, activityTypeId,
                    start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode controller's Search method");
            return getMap(equipmentsMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ActivityCodeCntroller-->SearchActivityCode-->Catch Block :{}", e);
            return Util.getModelMapError("Error retrieving activity Code from database.");
        }
    }

    /**
     * This method creates the ActivityCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Object data, Principal principal) {
 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode controller's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);

        try {
            List<ActivityCode> activityCodes = activityCodeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode controller's create method");
            return getMap(activityCodes);
        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return Util.getModelMapError("Error trying to create activity Code due to following exception:{}" + cause.getMessage());
            
        } catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException:{}", e);
            return Util.getModelMapError("Error trying to create activity Code : " + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Create-->Generic Exception:{}", e);
            return Util.getModelMapError("Error trying to create activity Code.");
        }
    }
    
    /**
     * This method updates the ActivityCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode controller's update method");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);

        try {
            List<ActivityCode> activityCodes = activityCodeService.update(data, principal);
            return getMap(activityCodes);
            
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Update-->Generic Exception:{}", e);
            return Util.getModelMapError("Error trying to update activityCode.");
        }
    }
    
    /**
     * This method deletes the ActivityCode.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody
    public Map<String, Object> delete(@RequestBody Object data, Principal principal) {
         
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode controller's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);

        try {

            activityCodeService.delete(data, principal);
            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode controller's delete method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Delete-->Generic Exception:{}", e);
            return Util.getModelMapError("Error trying to delete activityCode.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<ActivityCode> activityCodes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, activityCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> activityCodesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) activityCodesMap.get("totalCount");

        List<ActivityCode> activityCodes = (List<ActivityCode>) activityCodesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", activityCodes);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, activityCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

}
