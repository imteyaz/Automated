package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.BayRowPk;

/**
 * ValueObject holding the row details per bay
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Entity
@Table(name = "MP_BAYROW_SPM")
public class BayRow implements Serializable {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset + rowOffset
     */
    @EmbeddedId
    private BayRowPk pk;

    @Column(name = "VSL_ROW_NO")
    private String vesselRowNo;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    // @Version
    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;

    public BayRowPk getPk() {
        return pk;
    }

    public void setPk(BayRowPk pk) {
        this.pk = pk;
    }

    public String getVesselRowNo() {
        return vesselRowNo;
    }

    public void setVesselRowNo(String vesselRowNo) {
        this.vesselRowNo = vesselRowNo;
    }

    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    public Integer getRowOffset() {
        return pk.getRowOffset();
    }

    public void setRowOffset(Integer rowOffset) {
        pk.setRowOffset(rowOffset);
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
