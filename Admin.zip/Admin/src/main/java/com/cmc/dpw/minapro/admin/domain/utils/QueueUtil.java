package com.cmc.dpw.minapro.admin.domain.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;

public class QueueUtil {

    private static final Boolean NON_TRANSACTED = false;
    private static Connection connection = null;
    private static ConnectionFactory factory = null;
    private static Session session = null;
    private static MessageProducer adminProducer = null;
    private static Queue adminQueue = null;
    private static MessageProducer commonProducer = null;
    private static Queue commonQueue = null;
    private static final Logger LOGGER = LoggerFactory.getLogger(QueueUtil.class);

    private QueueUtil() {
        super();
    }

    public static void init() {
        try {
            String propertiesFileName = "config.properties";
            Properties prop = new Properties();

            String folderName = ApplicationContextProvider.getContextName().substring(1);
            String path = System.getProperty("jboss.server.config.dir");

            path = path.concat(File.separator).concat(folderName).concat(File.separator).concat(propertiesFileName);
            String propertiesFilePath = propertiesFileName;
            if (new File(path).exists()) {
                propertiesFilePath = path;
                prop.load(new FileInputStream(propertiesFilePath));
                LOGGER.debug("loaded application properties from user defined file:" + propertiesFilePath);
                
            } else {
                InputStream inpStream = Thread.currentThread().getContextClassLoader()
                        .getResourceAsStream(propertiesFilePath);
                prop.load(inpStream);
                LOGGER.debug("loaded application properties from default file: " + propertiesFilePath);
            }
            String queUser = (String) prop.get("userName");
            String quePwd = (String) prop.get("password");
            String finalIp = (String) prop.get("queueIp");
            factory = new ActiveMQConnectionFactory(queUser.toString().trim(),quePwd.toString().trim(),finalIp);
            
            LOGGER.debug("******QueueUtil---->init-->connection factory created");

            connection = factory.createConnection();
            LOGGER.debug("******QueueUtil---->init-->connection created");
            
            connection.start();
            LOGGER.debug("******QueueUtil---->init-->connection started ");
            
            session = connection.createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);
            LOGGER.debug("******QueueUtil---->init-->session created");
            
            adminQueue = session.createQueue("ADMIN_NOTIF");
            LOGGER.debug("******QueueUtil---->init--->Admin Queue created " + adminQueue);
            
            adminProducer = session.createProducer(adminQueue);
            LOGGER.debug("******QueueUtil---->init--->Admin Producer created " + adminProducer);

            commonQueue = session.createQueue(MessageConstants.T2_ESB_COMMON_OUTQ);
            LOGGER.debug("******QueueUtil---->init--->common Queue created " + commonQueue);
            
            commonProducer = session.createProducer(commonQueue);
            LOGGER.debug("******QueueUtil---->init--->common Producer created " + commonProducer);

        } catch (Exception e) {
            LOGGER.debug("******QueueUtil---->init---->Exception", e);

            if (connection != null) {
                try {
                    adminProducer.close();
                    commonProducer.close();
                    session.close();
                    connection.close();
                    LOGGER.error("******QueueUtil---->init---->Exception---> Done closing connection");
                    LOGGER.error(MessageConstants.ERROR_INDICATOR + "ACTIVE MQ Connection initialization failed");
                    LOGGER.error(MessageConstants.ERROR_INDICATOR + "REDEPLOY APP URGENTLY - NO COMMUNICATION TO RDT CAN BE MADE");

                } catch (JMSException jmse) {
                    LOGGER.debug("******QueueUtil---->init---->Exception---JMSException while closing connection/session/producers", jmse);
                    
                } catch (Exception ge) {
                    LOGGER.debug("******QueueUtil---->---->init---->Exception--->generic exception while closing connection/session/producers", ge);
                }
            }
        }
    }

    public static Connection getConnection() {
        if (connection == null) {
            try {
                LOGGER.debug("getConnection-->connection was null @" + new Date());
                connection = factory.createConnection();
                LOGGER.debug("******QueueUtil---->getConnection-->connection created");
                connection.start();
                LOGGER.debug("******QueueUtil---->getConnection-->connection started ");

            } catch (JMSException jmse) {
                LOGGER.error("******QueueUtil---->getConnection--->JMSException while creating or starting connection",jmse);
            }

        }
        return connection;
    }

    public static Session getSession() {
        if (session == null) {
            try {
                LOGGER.debug("getSession-->session was null @" + new Date());
                session = getConnection().createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);
                LOGGER.debug("******QueueUtil---->getSession--->session created");

            } catch (JMSException jmse) {
                LOGGER.error("******QueueUtil---->getSession--->JMSException while creating session");
            }
        }
        return session;
    }

    public static MessageProducer getAdminProducer() {
        if (adminProducer == null) {
            try {
                LOGGER.debug("getAdminProducer-->adminProducer was null @" + new Date());
                
                adminQueue = getSession().createQueue("ADMIN_NOTIF");
                LOGGER.debug("******QueueUtil---->getAdminProducer--->Admin Queue created " + adminQueue);
                
                adminProducer = getSession().createProducer(adminQueue);
                LOGGER.debug("******QueueUtil---->getAdminProducer--->Admin Producer created " + adminProducer);

            } catch (JMSException jmse) {
                LOGGER.error("******QueueUtil---->getAdminProducer--->JMSException while creating AdminProducer");
            }
        }

        return adminProducer;
    }

    public static MessageProducer getCommonProducer() {

        if (commonProducer == null) {
            try {
                LOGGER.debug("getCommonProducer-->commonProducer was null @" + new Date());
                
                commonQueue = getSession().createQueue(MessageConstants.T2_ESB_COMMON_OUTQ);
                LOGGER.debug("******QueueUtil---->getCommonProducer--->common Queue created " + commonQueue);
                
                commonProducer = getSession().createProducer(commonQueue);
                LOGGER.debug("******QueueUtil---->getCommonProducer--->Common Producer created " + commonProducer);

            } catch (JMSException jmse) {
                LOGGER.error("******QueueUtil---->getCommonProducer--->JMSException while creating commonProducer");
            }
        }

        return commonProducer;
    }


    public static void publishToQueues(String tableName) {
        try {

            TextMessage textMessage = getSession().createTextMessage(tableName);
            LOGGER.debug("*****Sending message " + textMessage + " to queue");
            textMessage.setStringProperty("eventGenerator", "UPDATE");
            getAdminProducer().send(textMessage);
            LOGGER.debug("*****Passed : " + tableName + " to queue ADMIN_NOTIF");
            

        } catch (Exception e) {

            LOGGER.error("!^!^!^!^--QueueUtil-->publishToQueues(tableName)--> Exception", e);
            LOGGER.debug("QueueUtil--->Exception", e.getStackTrace());
            LOGGER.debug("^!^!^!^!^!^!^!^!^! " + e.getMessage());
            LOGGER.debug("^!^!^!^!^!^!^!^!^! Unable to pass the message to queue ADMIN_NOTIF for : " + tableName);
        } 

    }

    public static void publishToQueues(String queueName, Serializable eventMsg) {
        try {

            ObjectMessage objectMessage = getSession().createObjectMessage(eventMsg);

            if ("ADMIN_NOTIF".equalsIgnoreCase(queueName)) {
                getAdminProducer().send(objectMessage);
            } else if (MessageConstants.T2_ESB_COMMON_OUTQ.equalsIgnoreCase(queueName)) {
                getCommonProducer().send(objectMessage);
            }

            LOGGER.debug("****Passed to queue :" + queueName + " event :" + eventMsg.toString());

        } catch (Exception e) {

            LOGGER.error("!^!^!^!^--QueueUtil---> publishToQueues--->Exception", e);
            LOGGER.warn("^^^^^^ Unable to publish to queue : {}", e.getMessage());
            LOGGER.debug("QueueUtil-->publishToQueues-->Exception", e.getStackTrace());
            LOGGER.debug("^!^!^!^!^!^!^!^!^!" + e.getMessage());
            LOGGER.debug("^!^!^!^!^!^!^!^!^! Unable to pass the event : " + eventMsg.toString() + " to queue "
                    + queueName);
        }

    }

    public static void shutDown() {

        if (connection != null) {
            try {
                adminProducer.close();
                commonProducer.close();
                session.close();
                connection.close();
                LOGGER.debug("******QueueUtil--> shutdown-->Cleaned up producers,session and connection.");

            } catch (JMSException jmse) {
                LOGGER.debug("******QueueUtil--> shutdown-->JMSException while closing", jmse);
            } catch (Exception ge) {
                LOGGER.debug("******QueueUtil--> shutdown-->generic exception while closing", ge);
            }
        }
    }
}