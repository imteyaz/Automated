package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key to identify the bays defined under sections for a vessel
 * 
 * @author Rosemary George
 * 
 */
@Embeddable
public class BayPk implements Serializable {

    private static final long serialVersionUID = 5119931525214764973L;

    @Column(name = "INT_VSL_NO")
    private Integer vesselNo;

    @Column(name = "INT_SECT_NO")
    private Integer sectionNo;

    @Column(name = "DK_UNDK_IND")
    private String deckUnderDeck;

    @Column(name = "BAY_OFFSET")
    private Integer bayOffset;

    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }

    public Integer getSectionNo() {
        return sectionNo;
    }

    public void setSectionNo(Integer sectNo) {
        this.sectionNo = sectNo;
    }

    public String getDeckUnderDeck() {
        return deckUnderDeck;
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        this.deckUnderDeck = deckUnderDeck;
    }

    public Integer getBayOffset() {
        return bayOffset;
    }

    public void setBayOffset(Integer bayOffset) {
        this.bayOffset = bayOffset;
    }
}
