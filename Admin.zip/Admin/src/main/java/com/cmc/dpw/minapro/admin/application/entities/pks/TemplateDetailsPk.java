package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the primary key for the Template details
 * @author Rosemary George
 *
 */
@Embeddable
public class TemplateDetailsPk implements Serializable {
    
    private static final long serialVersionUID = 2454206915273897222L;

    @Column(name="NUMSRS_ID")
    private String headerId;
    
    @Column(name="SEQ_NO")
    private Integer offset;

    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }
}
