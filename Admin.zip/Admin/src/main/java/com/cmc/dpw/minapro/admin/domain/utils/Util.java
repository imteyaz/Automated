package com.cmc.dpw.minapro.admin.domain.utils;

import java.io.IOException;
import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ezmorph.object.DateMorpher;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.util.JSONUtils;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.User;

/**
 * Util class. Contains some common methods that can be used for common operations.
 */
@Component
public class Util {
    @Autowired 
    private DozerBeanMapper  dozerBeanMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(Util.class);

    public void registerDateMorpher() {
        DateMorpher tempDateMorpher = new DateMorpher(new String[] { "dd/MM/yyyy HH:mm:ss" });
        JSONUtils.getMorpherRegistry().registerMorpher(tempDateMorpher);
    }
  
    /**
     * 
     * @param <T>
     * @param data - json data from request
     * @return
     */

    public <T> List<T> getEntitiesFromRequest(Object data, Class<T> pojo) {

        LOGGER.debug("data as in request :" + data);
        registerDateMorpher();

        List<T> list;
        String excludeDto = MessageConstants.EXCLUDE_DTO;
        int index = data.toString().indexOf('[');
        LOGGER.debug("index:" + index);
        // it is an array - have to cast to array object
        if (data.toString().indexOf('[') > -1 && !(pojo.getName().equals(excludeDto))) {
            LOGGER.debug("pojo:" + pojo.getName());
            list = getGenericEntityListFromJSON(data, pojo);
            LOGGER.debug("57 line : " + list);

        } else {
            // it is only one object - cast to object/bean
            T genericEntity = getGenericEntityFromJSON(data, pojo);

            list = new ArrayList<T>();
            list.add(genericEntity);
            LOGGER.debug("In else loop : " + list);
        }
        LOGGER.debug("returning " + list);
        return list;
    }

    /**
     * Transform json data format into object
     * 
     * @param <T>
     * @param data
     *            - json data from request
     * @return
     */
    private <T> T getGenericEntityFromJSON(Object data, Class<T> genericEntity) {
        T newGenericEntity = null;
        LOGGER.debug("\n \n printing data:" + data);
        try {
            JSONObject jsonObject = JSONObject.fromObject(data);
            LOGGER.debug("Json  object data:" + jsonObject);

            String temp = jsonObject.toString();
            String tempjsondata = temp.replace("{\"data\":", "");
            int lastindex = tempjsondata.lastIndexOf('}');
            String truncatedTempjson = tempjsondata.substring(0, lastindex);
            LOGGER.debug("After conversion inside  ..." + truncatedTempjson);

            JSONObject finaljsonObject = JSONObject.fromObject(truncatedTempjson);
            JSONObject fullFinaljsonObject = finaljsonObject.discard("trnsType");

            LOGGER.debug("fullFinaljsonObject*****" + fullFinaljsonObject);

            newGenericEntity = (T) JSONObject.toBean(fullFinaljsonObject, genericEntity);

        } catch (Exception exception) {
            LOGGER.error("!^!^!^!^--JSON --> Exception", exception);
            LOGGER.warn("Error trying to getGenericEntityFromJSON : {}", exception.getMessage());
            LOGGER.debug("***********Exception Stacktrace : {}", exception.getStackTrace());
            LOGGER.debug(" Root cause is" + exception.getMessage());
        }

        return newGenericEntity;
    }

    /**
     * Transform json data format into list of objects
     * 
     * @param <T>
     * @param data
     *            - json data from request
     * @return
     */
    @SuppressWarnings("unchecked")
    private <T> List<T> getGenericEntityListFromJSON(Object data, Class<T> genericEntity) {
        LOGGER.debug("print data", data);
        JSONArray jsonArraydata = JSONArray.fromObject(data);
        LOGGER.debug("jsonArraydata " + jsonArraydata);

        String tempArray = jsonArraydata.toString();

        String tempjsondata = tempArray.replace("[{\"data\":", "");
        int lastindex = tempjsondata.lastIndexOf('}');
        String truncatedTempjson = tempjsondata.substring(0, lastindex);
        LOGGER.debug("Array --conversion inside  ..." + truncatedTempjson);

        JSONArray finaljsonObject = JSONArray.fromObject(truncatedTempjson);

        List<T> newGenericEntities = (List<T>) JSONArray.toCollection(finaljsonObject, genericEntity);
        LOGGER.debug("newGenericEntities: " + newGenericEntities);
        return newGenericEntities;
    }

    public Integer getUserIdFromPrincipal(Principal principal) {

        UsernamePasswordAuthenticationToken unpat = (UsernamePasswordAuthenticationToken) principal;

        User user = (User) unpat.getPrincipal();
        return user.getUserId();

    }

    public Date getParsedDateFromString(String datePattern, String dateInString) {

        SimpleDateFormat formatter = new SimpleDateFormat(datePattern);
        Date parsedDate = null;
        try {
            parsedDate = formatter.parse(dateInString);
        } catch (ParseException e) {

            LOGGER.error("!^!^!^!^-- Unable to parse date : {}", e.getMessage());
            LOGGER.debug("Util--->getParsedDateFromString-->dateInString", dateInString);
            LOGGER.debug("Util--->getParsedDateFromString-->datePattern", datePattern);
            
            LOGGER.debug("Util--->ParseException", e.getStackTrace());
        }

        return parsedDate;

    }

    public String appendDateTime(String dateString, String timeString, String defaultTimeString) {

        String appendedDateTime = null;
        StringBuilder dateTimeString = new StringBuilder();

        if ("".equals(timeString) || timeString == null) {
            dateTimeString.append(dateString).append('/').append(defaultTimeString);
        } else {

            dateTimeString.append(dateString).append('/').append(timeString);
        }

        appendedDateTime = dateTimeString.toString();

        return appendedDateTime;

    }
    

    public static void addRestrictions(Criteria searchCriteria,String columnName,String columnValue,boolean checkEquality){

        String percentage = "%";
        String likeValue = "";
        
        if (columnValue != null && !columnValue.isEmpty()) {
            
            if(checkEquality){
                searchCriteria.add(Restrictions.eq(columnName, columnValue));
            }else{
                String finalColumnValue = likeValue.concat(percentage).concat(columnValue).concat(percentage);
                searchCriteria.add(Restrictions.like(columnName, finalColumnValue).ignoreCase());
            }
            
          }

    }
    
    public static void addIntgerRestrictions(Criteria searchCriteria,String columnName,String columnValue){

        if (columnValue != null && !columnValue.isEmpty()){
            searchCriteria.add(Restrictions.eq(columnName, Integer.parseInt(columnValue)));
          }

    }

    public static Integer addRestrictions(Criteria searchCriteria, String columnName, String columnValue, boolean checkEquality, Integer i) {
        String percentage = "%";
        String likeValue = "";
        Integer temp = i ;
        if (columnValue != null && !columnValue.isEmpty()) {
            temp ++ ;
            if(checkEquality){
                searchCriteria.add(Restrictions.eq(columnName, columnValue));
            }else{
                String finalColumnValue = likeValue.concat(percentage).concat(columnValue).concat(percentage);
                searchCriteria.add(Restrictions.like(columnName, finalColumnValue).ignoreCase());
            }
            
          }
        return temp ;
    }
    
    public static String createErrorMessage(String type, String componentName){
        String errorMessage = "" ;
        
        switch(type){
        case "insert" : errorMessage = MessageConstants.CREATE_ERROR_MESSAGE ;
            break ;
        case "update" : errorMessage = MessageConstants.UPDATE_ERROR_MESSAGE ;
            break ;
        case "delete" : errorMessage = MessageConstants.DELETE_ERROR_MESSAGE ;
            break ;
         default :   errorMessage = MessageConstants.REQUEST_FAILED_MESSAGE ;
        }
        return  errorMessage + componentName; 
    }

    
    public <T, U>List<U> map(final List<T> source, final Class<U> destType) {
        final Mapper mapper = dozerBeanMapper;
        final List<U> dest = new ArrayList<U>();
        if (source != null) {
            for (T element : source) {
                if (element == null) {
                    continue;
                }
                dest.add(mapper.map(element, destType));
            }
        }
        // finally removing all null values (if any)
        
        List delList = new ArrayList();
        delList.add(null);
        dest.removeAll(delList);

        return dest;
    }

    public <E, T> List<E> getEntitiesFromDto(Object data,  Class<T> dtoClass, Class<E> entityClass) {
        
        List<T> dtoList = getEntitiesFromRequest(data, dtoClass);
        return  map(dtoList, entityClass);
    }
    
 public <E, T> List<E> fetchEntitiesFromDto(String data,  Class<T> dtoClass, Class<E> entityClass) {
        
        List<T> dtoList = convertDataToDto(data, dtoClass);
        return  map(dtoList, entityClass);
    }
    
    
    
    public <T> List<T> convertDataToDto(String data, Class<T> pojo) {

        LOGGER.debug("convertDataToDto --> data  :" + data);

        List<T> list = null;
       
        ObjectMapper objectMapper = new ObjectMapper();
        
        try {
            list =  objectMapper.readValue(data,new TypeReference<List<T>>() {}) ;
        } catch (JsonParseException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"JsonParseException ", e);
        } catch (JsonMappingException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"JsonMappingException", e);
        } catch (IOException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"IOException", e);
        }
        
        LOGGER.debug("successfuly converted Json Data to Dto : following records" + list);
        return list;
    }

    
    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    public static Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

    public static void addFloatRestrictions(Criteria searchCriteria, String columnName, String columnValue, boolean checkEquality) {
        
        if (columnValue != null && !columnValue.isEmpty()){
            searchCriteria.add(Restrictions.eq(columnName, Double.parseDouble(columnValue)));
          }
        
    }
}