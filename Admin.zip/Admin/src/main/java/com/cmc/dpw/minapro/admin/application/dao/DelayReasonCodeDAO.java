package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.DelayReasonCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DelayReasonCode;
import com.cmc.dpw.minapro.admin.application.entities.DelayRecording;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * DelayReasonCodeDAO
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Repository
public class DelayReasonCodeDAO extends GenericDAO<DelayReasonCode> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DelayReasonCodeDAO.class);

    /**
     * This method is used to search DelayReasonCodes
     * 
     * @param delayReasonId
     * @param description
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchDelayReasonCodes(String delayReasonId, String description, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Entering DelayReasonCode DAO's searchDelayReasonCodes method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        Integer i = 0;

        Criteria searchCriteria = session.createCriteria(DelayReasonCode.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { delayReasonId, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "Processing searchDelayReasonCodes with delayReasonId: {} , description : {}", searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        i = Util.addRestrictions(searchCriteria, "delayReasonId", delayReasonId, false, i);
        i = Util.addRestrictions(searchCriteria, "description", description, false, i);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******* Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<DelayReasonCode> searchDelayReasonCodes = null;

        List<DelayReasonCode> refinedDelayCodes = null;

        if (i == 0) {
            Query query = session.createQuery("select distinct d from DelayReasonCode d where d.isDeleted = 'N' ");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<DelayReasonCode> delayReasonList = query.list();

            searchDelayReasonCodes = delayReasonList;

            refinedDelayCodes = findOpenDelays(searchDelayReasonCodes, i);

        } else {

            searchDelayReasonCodes = (List<DelayReasonCode>) searchCriteria.list();
            refinedDelayCodes = findOpenDelays(searchDelayReasonCodes, i);
        }

        List<DelayReasonCodeDTO> searchDelayReasonCodesDtoList = util.map(refinedDelayCodes, DelayReasonCodeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data: {}", searchDelayReasonCodesDtoList);
        LOGGER.debug("******* totalCount: {}", totalRecords);

        resultMap.put("data", searchDelayReasonCodesDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "exiting DelayReasonCode DAO's searchDelayReasonCodes method ");

        return resultMap;
    }

    private List<DelayReasonCode> findOpenDelays(List searchDelayReasonCodes, Integer criteriaAdded) {

        List<DelayReasonCode> actualDelayCodes = new ArrayList<DelayReasonCode>();

        if (criteriaAdded > 0) {

            for (Object currentDelayCodeNRecording : searchDelayReasonCodes) {
                Object[] delayArray = (Object[]) currentDelayCodeNRecording;
                DelayReasonCode currentDelay = (DelayReasonCode) delayArray[1];
                actualDelayCodes.add(currentDelay);
            }

        } else {
            actualDelayCodes = (List<DelayReasonCode>) searchDelayReasonCodes;
        }

        for (DelayReasonCode delayReasonCode : actualDelayCodes) {

            LOGGER.debug("^^^^^^^^^^^^^^^^^");
            LOGGER.debug("******* delayReasonId : {}", delayReasonCode.getDelayReasonId());

            List<DelayRecording> delayrecordings = (List<DelayRecording>) delayReasonCode.getDelayRecordings();
            for (DelayRecording currentDelayRecording : delayrecordings) {
                LOGGER.debug("       ******* currentDelayRecordingId : {}", currentDelayRecording.getdelayId());
                if (currentDelayRecording.getdelayEndTime() == null
                        || currentDelayRecording.getdelayEndTime().toString().isEmpty()) {
                    LOGGER.debug("delay recording opened for delay id" + delayReasonCode.getDelayReasonId());
                    delayReasonCode.setIsDelayOpen('Y');
                }
            }

        }
        return actualDelayCodes;
    }

}
