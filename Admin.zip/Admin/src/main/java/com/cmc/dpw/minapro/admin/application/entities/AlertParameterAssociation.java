package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * AlertParameterAssociation POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "AlertParameterAssociation")
@Table(name = "MP_ALERT_PARAMETER_MAPPING")
public class AlertParameterAssociation implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertParamId;
    private String alertCode;
    private Integer paramterId;
    private AlertParameterKey actualkey ;
    
    @Id
    @Column(name = "ALERT_PARAM_MAP_ID", nullable = false)
    public Integer getAlertParamId() {
        return alertParamId;
    }
    public void setAlertParamId(Integer alertParamId) {
        this.alertParamId = alertParamId;
    }
    
    @Column(name = "ALERT_CODE", nullable = false)
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    
    @Column(name = "PARAMETER_ID", nullable = false)
    public Integer getParamterId() {
        return paramterId;
    }
    public void setParamterId(Integer paramterId) {
        this.paramterId = paramterId;
    }
    
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "PARAMETER_ID", referencedColumnName = "PARAMETER_ID", insertable = false, updatable = false)
    public AlertParameterKey getActualkey() {
        return actualkey;
    }
    public void setActualkey(AlertParameterKey actualkey) {
        this.actualkey = actualkey;
    }
    
    
  
    
    
   
    
   
    
    
    

    
    
    
     
    
    

}
