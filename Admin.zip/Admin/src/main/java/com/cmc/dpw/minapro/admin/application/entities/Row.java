package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * Row POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_BLKROW_YPM")
public class Row implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer blkNo;
    private Integer rowSeqNo;
    private String blkRowNo;
    private Integer rowNo;
    private String endRowFlg;
    private String allowdFlg;
    private String wrkgStkgHt;
    private Integer wrkgStkgHtUom;
    private String delFlg;
    private String doorDirnInd;
    private Integer rowLen;
    private String rowLenUom;
    private String accessDirnInd;
    private String numsrsFlg;
    private Integer rfrNo;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insUsrFlg;
    private String userCd;
    private Date updDttm;
    private String updUsrFlg;
    private String txnCd;
    private Integer txnNo;

    @Id
    @Column(name = "INT_BLK_NO")
    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    @Id
    @Column(name = "ROW_SEQ_NO")
    public Integer getRowSeqNo() {
        return rowSeqNo;
    }

    public void setRowSeqNo(Integer rowSeqNo) {
        this.rowSeqNo = rowSeqNo;
    }

    @Column(name = "BLK_ROW_NO")
    public String getBlkRowNo() {
        return blkRowNo;
    }

    public void setBlkRowNo(String blkRowNo) {
        this.blkRowNo = blkRowNo;
    }

    @Column(name = "CONTIGUITY_ROW_NO")
    public Integer getRowNo() {
        return rowNo;
    }

    public void setRowNo(Integer rowNo) {
        this.rowNo = rowNo;
    }

    @Column(name = "DEAD_END_ROW_FLG")
    public String getEndRowFlg() {
        return endRowFlg;
    }

    public void setEndRowFlg(String endRowFlg) {
        this.endRowFlg = endRowFlg;
    }

    @Column(name = "RFR_ALLOWD_FLG")
    public String getAllowdFlg() {
        return allowdFlg;
    }

    public void setAllowdFlg(String allowdFlg) {
        this.allowdFlg = allowdFlg;
    }

    @Column(name = "WRKG_STKG_HT")
    public String getWrkgStkgHt() {
        return wrkgStkgHt;
    }

    public void setWrkgStkgHt(String wrkgStkgHt) {
        this.wrkgStkgHt = wrkgStkgHt;
    }

    @Column(name = "WRKG_STKG_HT_UOM")
    public Integer getWrkgStkgHtUom() {
        return wrkgStkgHtUom;
    }

    public void setWrkgStkgHtUom(Integer wrkgStkgHtUom) {
        this.wrkgStkgHtUom = wrkgStkgHtUom;
    }

    @Column(name = "DEL_FLG")
    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    @Column(name = "DOOR_DIRN_IND")
    public String getDoorDirnInd() {
        return doorDirnInd;
    }

    public void setDoorDirnInd(String doorDirnInd) {
        this.doorDirnInd = doorDirnInd;
    }

    @Column(name = "ROW_LEN")
    public Integer getRowLen() {
        return rowLen;
    }

    public void setRowLen(Integer rowLen) {
        this.rowLen = rowLen;
    }

    @Column(name = "ROW_LEN_UOM")
    public String getRowLenUom() {
        return rowLenUom;
    }

    public void setRowLenUom(String rowLenUom) {
        this.rowLenUom = rowLenUom;
    }

    @Column(name = "ACCESS_DIRN_IND")
    public String getAccessDirnInd() {
        return accessDirnInd;
    }

    public void setAccessDirnInd(String accessDirnInd) {
        this.accessDirnInd = accessDirnInd;
    }

    @Column(name = "APPLY_NUMSRS_FLG")
    public String getNumsrsFlg() {
        return numsrsFlg;
    }

    public void setNumsrsFlg(String numsrsFlg) {
        this.numsrsFlg = numsrsFlg;
    }

    @Column(name = "INT_RFR_CONTRCTR_NO")
    public Integer getRfrNo() {
        return rfrNo;
    }

    public void setRfrNo(Integer rfrNo) {
        this.rfrNo = rfrNo;
    }

    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Column(name = "ADT_INS_USR_CD")
    public String getInsUsrCd() {
        return insUsrCd;
    }

    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getInsUsrFlg() {
        return insUsrFlg;
    }

    public void setInsUsrFlg(String insUsrFlg) {
        this.insUsrFlg = insUsrFlg;
    }

    @Column(name = "ADT_UPD_USR_CD")
    public String getUserCd() {
        return userCd;
    }

    public void setUserCd(String userCd) {
        this.userCd = userCd;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }

    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdUsrFlg() {
        return updUsrFlg;
    }

    public void setUpdUsrFlg(String updUsrFlg) {
        this.updUsrFlg = updUsrFlg;
    }

    @Column(name = "ADT_TXN_CD")
    public String getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }

    @Column(name = "ADT_TXN_NO")
    public Integer getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }

}
