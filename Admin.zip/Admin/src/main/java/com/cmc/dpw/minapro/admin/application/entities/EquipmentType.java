package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * EquipmentType POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "EquipmentType")
@Table(name = "MP_EQUIPMENT_TYPE_MASTER")
public class EquipmentType extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;

    private String equipmentTypeId;
    private String equipmentDescription;
   
    @Id
    @Column(name = "EQUIPMENT_TYPE_ID", nullable = false)
    public String getEquipmentTypeId() {
        return equipmentTypeId;
    }

    public void setEquipmentTypeId(String equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }

    @Column(name = "DESCRIPTION")
    public String getEquipmentDescription() {
        return equipmentDescription;
    }

    public void setEquipmentDescription(String equipmentDescription) {
        this.equipmentDescription = equipmentDescription;
    }
    
}
