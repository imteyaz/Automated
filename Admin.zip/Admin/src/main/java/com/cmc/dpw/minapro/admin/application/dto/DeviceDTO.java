package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * DeviceDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@JsonAutoDetect
public class DeviceDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String deviceId;
    private String deviceDescription;
    private String ipAddress;
    private String listeningPort;
    private String sendingPort;
    private String equipmentId;
    private String make;
    private String model;
    
    private String osVersion;
    private String currentVersion;
    private Date versionLastUpdatedOn;
    
    
    public String getDeviceId() {
        return deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    public String getDeviceDescription() {
        return deviceDescription;
    }
    public void setDeviceDescription(String deviceDescription) {
        this.deviceDescription = deviceDescription;
    }
    public String getIpAddress() {
        return ipAddress;
    }
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
    public String getListeningPort() {
        return listeningPort;
    }
    public void setListeningPort(String listeningPort) {
        this.listeningPort = listeningPort;
    }
    public String getSendingPort() {
        return sendingPort;
    }
    public void setSendingPort(String sendingPort) {
        this.sendingPort = sendingPort;
    }
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public String getMake() {
        return make;
    }
    public void setMake(String make) {
        this.make = make;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getOsVersion() {
        return osVersion;
    }
    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }
    public String getCurrentVersion() {
        return currentVersion;
    }
    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }
    public Date getVersionLastUpdatedOn() {
        return versionLastUpdatedOn;
    }
    public void setVersionLastUpdatedOn(Date versionLastUpdatedOn) {
        this.versionLastUpdatedOn = versionLastUpdatedOn;
    }

}
