package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * QC_Lane POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "QC_Lane")
@Table(name = "MP_QC_LANE_MASTER")
public class QCLane  extends Audit  implements Serializable {
  
    private static final long serialVersionUID = 1L;
    private String laneId;
    private String laneDescription;
    private String availability;
    private String driveDirection;
    private String terminalId;

    @Id
    @Column(name = "LANE_ID", nullable = false)
    public String getLaneId() {
        return laneId;
    }

    public void setLaneId(String laneId) {
        this.laneId = laneId;
    }

    @Column(name = "LANE_DESCRIPTION")
    public String getLaneDescription() {
        return laneDescription;
    }

    public void setLaneDescription(String laneDescription) {
        this.laneDescription = laneDescription;
    }

    @Column(name = "AVAILABILITY", nullable = false)
    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    @Column(name = "DRIVE_DIRECTION", nullable = false)
    public String getDriveDirection() {
        return driveDirection;
    }

    public void setDriveDirection(String driveDirection) {
        this.driveDirection = driveDirection;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
   
}
