package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.AlertCodeDAO;
import com.cmc.dpw.minapro.admin.application.dto.AlertCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * AlertCode Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class AlertCodeService {

    @Autowired
    private AlertCodeDAO alertCodeDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertCodeService.class);

    /**
     * This method is used to get AlertCode List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<AlertCode> getAlertCodeList() {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  AlertCode service's getAlertCodeList");
        alertCodeDAO.setClazz(AlertCode.class);
        return alertCodeDAO.findAll();

    }

    /**
     * This method is used to search AlertCode List
     * @return Map<String, Object> containing the search AlertCode data and success indicator or
     * the error message and failure indicator.
     */
    
    @Transactional(readOnly = true)
    public Map<String, Object> searchAlertCodeList(String alertCodePK, String description, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertCode service's searchAlertCodeList method");
        alertCodeDAO.setClazz(AlertCode.class);

        String[] requestParameters = { alertCodePK, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In AlertCode service searchActivityCodeswith alertCode: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertCode service's searchAlertCodeList method");
        return alertCodeDAO.searchAlertCodes(alertCodePK, description, start, limit);

    }

    /**
     * This method is used to create alertCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<AlertCode>
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_ALERTCODES_MASTER")
    public List<AlertCode> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertCode service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  alertCode service's  create : {} ", data);
        List<AlertCode> newAlertCodes = new ArrayList<AlertCode>();

        List<AlertCode> newAlertCodesList =  util.getEntitiesFromDto(data,AlertCodeDTO.class,AlertCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (AlertCode alertCode : newAlertCodesList) {

            Date currentDate = new Date();

            alertCode.setCreatedDateTime(currentDate);
            alertCode.setLastUpdatedDateTime(currentDate);
            alertCode.setCreatedBy(userId.toString());
            alertCode.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"AlertCode Id property in alertCode service's create : {}",
                    alertCode.getAlertCodePK());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling alertCode DAO findOne");

            AlertCode alreadyAlertCode = alertCodeDAO.findOne(alertCode.getAlertCodePK());

            if (alreadyAlertCode == null) {
                LOGGER.info("caling alertCode DAO");
                newAlertCodes.add(alertCodeDAO.create(alertCode));
            } else {
                char isDeleted = alreadyAlertCode.getIsDeleted();

                if (isDeleted == 'Y') {
                    alertCode.setVersion(alreadyAlertCode.getVersion());
                    alertCode.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling alertCode DAO update");
                    newAlertCodes.add(alertCodeDAO.update(alertCode));
                }  else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null  
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertCode service's create method");
        return newAlertCodes;
    }

    /**
     * This method is used to update alertCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<AlertCode>
     */
    @Transactional
    @Manipulate(table = "MP_ALERTCODES_MASTER")
    public List<AlertCode> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertCode service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  alertCode  service's  update : {} ", data);
        List<AlertCode> returnAlertCodes = new ArrayList<AlertCode>();
        
        List<AlertCode> updatedAlertCodes =  util.getEntitiesFromDto(data,AlertCodeDTO.class,AlertCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (AlertCode alertCode : updatedAlertCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"alertCode property in alertCode service update : {}", alertCode.getAlertCodePK());
            alertCode.setLastUpdatedDateTime(currentDate);
            alertCode.setLastUpdatedBy(userId.toString());
            returnAlertCodes.add(alertCodeDAO.update(alertCode));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertCode service's update method");
        return returnAlertCodes;
    }

    /**
     * This method is used to delete alertCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_ALERTCODES_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertCode service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In alertCode's service delete : {} ", data);

        List<AlertCode> deletedAlertCodes =  util.getEntitiesFromDto(data,AlertCodeDTO.class,AlertCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (AlertCode alertCode : deletedAlertCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"alertCode property in alertCode service delete : {}", alertCode.getAlertCodePK());
            alertCode.setLastUpdatedDateTime(currentDate);
            alertCode.setLastUpdatedBy(userId.toString());
            alertCode.setIsDeleted('Y');
            alertCodeDAO.delete(alertCode);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertCode service's delete method");
    }
  
}
