package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * Terminal POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class TerminalDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String terminalId;
    private String description;
    
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

}
