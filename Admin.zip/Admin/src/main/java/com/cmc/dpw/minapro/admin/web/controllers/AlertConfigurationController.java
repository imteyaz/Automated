package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.AlertConfigurationDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertConfiguration;
import com.cmc.dpw.minapro.admin.application.services.AlertConfigurationService;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/alertConfiguration")
public class AlertConfigurationController {

    @Autowired
    private AlertConfigurationService alertConfigurationService;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertConfigurationController.class);

    /**
     * This method searches for all the alertConfigurations matching the search criteria
     * as entered by the end user
     * 
     * @param alertCode
     * @param alertText
     * @param description
     * @param severity
     * @param soundRequired
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String alertCode,
            @RequestParam(required = false) String alertText, @RequestParam(required = false) String description,
            @RequestParam(required = false) String severity, @RequestParam(required = false) String soundRequired,
            @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertConfigurationController Seacrh AlertConfiguration method");
     
        String[] requestParameters = { alertCode, alertText, description, severity, soundRequired };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"AlertConfigurationController-->search alertConfigurationId:{},alertConfigurationName :{},make :{},alertConfigurationTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertConfigurationController Seacrh AlertConfiguration method");

            Map<String, Object> alertConfigurationsMap = alertConfigurationService.searchAlertConfigurationList(alertCode, alertText, description,
                    severity, soundRequired, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertConfigurationController Seacrh AlertConfiguration method");
            return getMap(alertConfigurationsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"AlertConfigurationController-->search AlertConfiguration-->Catch Block :{}", e);
            return getModelMapError("Error retrieving AlertConfigurations from database.");
        }
    }

    
    /**
     * This method updates the alertConfiguration as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated alertConfiguration data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody String data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertConfigurationController Update AlertConfiguration method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        List<AlertConfiguration> updatedData = null ;
        try {
            updatedData = util.fetchEntitiesFromDto(data, AlertConfigurationDTO.class,AlertConfiguration.class);
            
            List<AlertConfiguration> alertConfigurations = alertConfigurationService.update(updatedData, principal);
            return getMap(alertConfigurations);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update alertConfiguration. ");

        }
    }
    
    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param alertConfigurations List of alertConfigurations
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<AlertConfiguration> alertConfigurations) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", alertConfigurations);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> alertConfigurationsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) alertConfigurationsMap.get("totalCount");

        List<AlertConfiguration> alertConfigurations = (List<AlertConfiguration>) alertConfigurationsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", alertConfigurations);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, alertConfigurations);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }


}
