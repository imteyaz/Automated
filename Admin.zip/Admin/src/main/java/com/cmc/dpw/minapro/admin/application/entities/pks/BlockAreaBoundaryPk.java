package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BlockAreaBoundaryPk implements Serializable {
    @Column(name = "INT_BLK_NO")
    private Integer blkNo;

    @Column(name = "SEQ_NO")
    private Integer seqNo;

    @Column(name = "X_COORD")
    private Integer xCoord;

    @Column(name = "Y_COORD")
    private Integer yCoord;

    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    public Integer getxCoord() {
        return xCoord;
    }

    public void setxCoord(Integer xCoord) {
        this.xCoord = xCoord;
    }

    public Integer getyCoord() {
        return yCoord;
    }

    public void setyCoord(Integer yCoord) {
        this.yCoord = yCoord;
    }

}
