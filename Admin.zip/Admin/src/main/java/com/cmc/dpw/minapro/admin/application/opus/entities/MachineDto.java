package com.cmc.dpw.minapro.admin.application.opus.entities;

public class MachineDto {

    private String machineId;
    private String machineType;
    private Character machineStatus;
    
    
    public String getMachineId() {
        return machineId;
    }
    public void setMachineId(String machineId) {
        this.machineId = machineId;
    }
    public String getMachineType() {
        return machineType;
    }
    public void setMachineType(String machineType) {
        this.machineType = machineType;
    }
    public Character getMachineStatus() {
        return machineStatus;
    }
    public void setMachineStatus(Character machineStatus) {
        this.machineStatus = machineStatus;
    }
    
    
    
    
}
