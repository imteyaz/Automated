package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
/**
 * CheckList POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "CheckList")
@Table(name = "MP_CHECKLIST_MASTER")
public class CheckList extends Audit implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String checkListId;
    private String checkListName;
    private String description;
    private char mandatory;
    private String icon;
    private String category;
    private Integer checkListHeaderId;
    private String checkListHeaderName;
    private CheckListHeader checkListheader;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CHECKLIST_HDR_ID")
    public CheckListHeader getCheckListheader() {
        return checkListheader;
    }

    public void setCheckListheader(CheckListHeader checkListheader) {
        this.checkListheader = checkListheader;
    }

    @Transient
    public String getCheckListHeaderName() {
        return checkListHeaderName;
    }

    public void setCheckListHeaderName(String checkListHeaderName) {
        this.checkListHeaderName = checkListHeaderName;
    }

    @Id
    @Column(name = "CHECKLIST_ID", nullable = false)
    public String getCheckListId() {
        return checkListId;
    }

    public void setCheckListId(String checkListId) {
        this.checkListId = checkListId;
    }

    @Column(name = "CHECKLIST_NAME")
    public String getCheckListName() {
        return checkListName;
    }

    public void setCheckListName(String checkListName) {
        this.checkListName = checkListName;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;

    }

    @Column(name = "MANDATORY")
    public char getMandatory() {
        return mandatory;
    }

    public void setMandatory(char mandatory) {
        this.mandatory = mandatory;
    }

    @Column(name = "ICON")
    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Column(name = "CATEGORY")
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Transient
    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }

    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }

}
