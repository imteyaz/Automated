package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import com.cmc.dpw.minapro.admin.application.entities.Unit;

/**
 * ApplicationParameterDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@JsonAutoDetect
public class ApplicationParameterDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String parameterCode;
    private String parameterValue;
    private String unitId;
    private String description;
    private String unitName;
    
    private Unit unit;
    
    public String getParameterCode() {
        return parameterCode;
    }
    public void setParameterCode(String parameterCode) {
        this.parameterCode = parameterCode;
    }
    public String getParameterValue() {
        return parameterValue;
    }
    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }
    public String getUnitId() {
        return unitId;
    }
    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getUnitName() {
        return unitName;
    }
    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    public Unit getUnit() {
        return unit;
    }
    public void setUnit(Unit unit) {
        this.unit = unit;
    }
  
    
}
