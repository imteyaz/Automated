package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.WeightageFactorDAO;
import com.cmc.dpw.minapro.admin.application.dto.WeightageFactorDTO;
import com.cmc.dpw.minapro.admin.application.entities.WeightageFactor;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * WeightageFactor Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class WeightageFactorService {

    @Autowired
    private WeightageFactorDAO weightageFactorDAO;
    @Autowired
    private Util util;
   
    private static final Logger LOGGER = LoggerFactory.getLogger(WeightageFactorService.class);

    /**
     * This method is used to read WeightageFactor
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<WeightageFactor> getWeightageFactorList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  WeightageFactor service's getWeightageFactorList");
        weightageFactorDAO.setClazz(WeightageFactor.class);
        return weightageFactorDAO.findAll();

    }

    /**
     * This method is used to read WeightageFactor
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchWeightageFactorList(String weightageFactorType, String weightageFactorCriteria, String weightageFactor, String weightageScore,
            int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering WeightageFactor service's searchWeightageFactorList method");
        weightageFactorDAO.setClazz(WeightageFactor.class);

        String[] requestParameters = { weightageFactorType, weightageFactorCriteria, weightageFactor, weightageScore };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In WeightageFactor service searchWeightageFactorList  with weightageFactorType: {} , weightageFactorCriteria : {}, weightageFactor : {}, weightageScore : {}, weightageFactorTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting WeightageFactor service's searchWeightageFactorList method");

        return weightageFactorDAO.searchWeightageFactors(weightageFactorType, weightageFactorCriteria, weightageFactor, weightageScore,  start, limit);
    }

    /**
     * This method is used to update WeightageFactor
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<WeightageFactor> containing the updated WeightageFactor datas
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_CHE_WEIGHTAGE_FACTOR")
    public List<WeightageFactor> update(Object data, Principal principal) throws InvalidValueException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering WeightageFactor service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  weightageFactor  service's  update : {} ", data);
        List<WeightageFactor> returnWeightageFactors = new ArrayList<WeightageFactor>();

        List<WeightageFactor> updatedWeightageFactors = util.getEntitiesFromDto(data, WeightageFactorDTO.class,WeightageFactor.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (WeightageFactor weightageFactor : updatedWeightageFactors) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"weightageFactorType property in weightageFactor service update : {}", weightageFactor.toString());
            weightageFactor.setLastUpdatedDateTime(currentDate);
            weightageFactor.setLastUpdatedBy(userId.toString());
            returnWeightageFactors.add(weightageFactorDAO.update(weightageFactor));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting WeightageFactor service's update method");

        return returnWeightageFactors;
    }


    
    
 
   
}
