package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * CheckListHeader POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class CheckListHeaderDTO extends AuditDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private Integer checkListHeaderId;
    private String name;
    private String type;
    private Integer roleId;
    private String roleName;
    private String allRoles;
    
    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }
    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public Integer getRoleId() {
        return roleId;
    }
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
    public String getRoleName() {
        return roleName;
    }
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    public String getAllRoles() {
        return allRoles;
    }
    public void setAllRoles(String allRoles) {
        this.allRoles = allRoles;
    }
    
}
