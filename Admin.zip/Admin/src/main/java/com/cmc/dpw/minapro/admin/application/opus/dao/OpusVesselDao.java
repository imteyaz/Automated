package com.cmc.dpw.minapro.admin.application.opus.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.opus.entities.OpusEquipmentDto;
import com.cmc.dpw.minapro.admin.application.opus.entities.OpusVesselDto;

@Repository
public class OpusVesselDao extends OPUSGenericDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(OpusVesselDao.class);

    public List<OpusVesselDto> fetchRegisteredRotations() {

        Session session = getCurrentSession();

        String registerVesselSql = "SELECT VOYAGE.VSB_VOY_EVOYAGEOUT Rotation," + "  VOYAGE.VSB_VOY_VESSEL VesselCode,"
                + "  VESSEL.CDV_VSL_NAME VesselName," + "  VOYAGE.VSB_VOY_ESTARR_DATE EtaDate,"
                + "  VOYAGE.VSB_VOY_ESTARR_TIME EtaTime," + "  VOYAGE.VSB_VOY_ACTBER_DATE ActualBerthDate,"
                + "  VOYAGE.VSB_VOY_STATUS Status," + "  VOYAGE.VSB_VOY_VOYAGE VoyageNo,"
                + "  VOYAGE.VSB_VOY_BERTHNO BerthNo" + "  FROM  VSB_VOYAGE VOYAGE, CDV_VESSEL VESSEL"
                + "  WHERE  VOYAGE.VSB_VOY_VESSEL = VESSEL.CDV_VSL_CODE"
                + "  AND TRUNC(VOYAGE.CRE_DT) = TRUNC(SYSDATE)" + "  AND VOYAGE.VSB_VOY_ACTBER_DATE IS NULL"
                + "  AND VOYAGE.VSB_VOY_STATUS != 'D' ";

        SQLQuery registerRotationsQuery = session.createSQLQuery(registerVesselSql)
                .addScalar("Rotation", new StringType()).addScalar("VesselCode", new StringType())
                .addScalar("VesselName", new StringType()).addScalar("EtaDate", new StringType())
                .addScalar("EtaTime", new StringType()).addScalar("ActualBerthDate", new StringType())
                .addScalar("Status", new StringType()).addScalar("VoyageNo", new StringType())
                .addScalar("BerthNo", new StringType());

        Query fetchRegisterRotationsQuery = registerRotationsQuery.setResultTransformer(Transformers
                .aliasToBean(OpusVesselDto.class));

        List<OpusVesselDto> registeredRotationsList = (List<OpusVesselDto>) fetchRegisterRotationsQuery.list();

        return registeredRotationsList;

    }

    public List<OpusVesselDto> fetchBerthedRotations(String atomRegisteredRotations) {

        Session session = getCurrentSession();

        String berthedRotationsSql = "SELECT VOYAGE.VSB_VOY_EVOYAGEOUT Rotation,"
                + "  VOYAGE.VSB_VOY_VESSEL VesselCode," + "  VESSEL.CDV_VSL_NAME VesselName,"
                + "  VOYAGE.VSB_VOY_ESTARR_DATE EtaDate," + "  VOYAGE.VSB_VOY_ESTARR_TIME EtaTime,"
                + "  VOYAGE.VSB_VOY_ACTBER_DATE ActualBerthDate," + "  VOYAGE.VSB_VOY_STATUS Status,"
                + "  VOYAGE.VSB_VOY_VOYAGE VoyageNo," + "  VOYAGE.VSB_VOY_BERTHNO BerthNo," + " VOYAGE.VSB_VOY_BERTHSIDE BerthSide "
                + "  FROM  VSB_VOYAGE VOYAGE, CDV_VESSEL VESSEL"
                + "  WHERE  VOYAGE.VSB_VOY_VESSEL = VESSEL.CDV_VSL_CODE" + "  AND VOYAGE .VSB_VOY_EVOYAGEOUT IN ("
                + atomRegisteredRotations + ")" // REGISTERED VESSEL IN ATOM"
                + "  AND VOYAGE.VSB_VOY_ACTBER_DATE IS NOT NULL" + "  AND VOYAGE.VSB_VOY_STATUS != 'D' ";

        SQLQuery berthedRotationsQuery = session.createSQLQuery(berthedRotationsSql)
                .addScalar("Rotation", new StringType()).addScalar("VesselCode", new StringType())
                .addScalar("VesselName", new StringType()).addScalar("EtaDate", new StringType())
                .addScalar("EtaTime", new StringType()).addScalar("ActualBerthDate", new StringType())
                .addScalar("Status", new StringType()).addScalar("VoyageNo", new StringType())
                .addScalar("BerthNo", new StringType()).addScalar("BerthSide", new StringType());

        Query opusBerthedRotationsQuery = berthedRotationsQuery.setResultTransformer(Transformers
                .aliasToBean(OpusVesselDto.class));

        List<OpusVesselDto> berthedRotationsList = (List<OpusVesselDto>) opusBerthedRotationsQuery.list();

        return berthedRotationsList;

    }

    public List<OpusVesselDto> fetchSailedRotations(String atomBerthedRotations) {

        Session session = getCurrentSession();

        String sailedRotationsSql = "SELECT VOYAGE.VSB_VOY_EVOYAGEOUT Rotation,"
                + "  VOYAGE.VSB_VOY_VESSEL VesselCode," + "  VESSEL.CDV_VSL_NAME VesselName,"
                + "  VOYAGE.VSB_VOY_ESTARR_DATE EtaDate," + "  VOYAGE.VSB_VOY_ESTARR_TIME EtaTime,"
                + "  VOYAGE.VSB_VOY_ACTBER_DATE ActualBerthDate," + "  VOYAGE.VSB_VOY_STATUS Status,"
                + "  VOYAGE.VSB_VOY_VOYAGE VoyageNo," + "  VOYAGE.VSB_VOY_BERTHNO BerthNo"
                + "  FROM  VSB_VOYAGE VOYAGE, CDV_VESSEL VESSEL"
                + "  WHERE  VOYAGE.VSB_VOY_VESSEL = VESSEL.CDV_VSL_CODE" + "  AND VOYAGE .VSB_VOY_EVOYAGEOUT IN ("
                + atomBerthedRotations + ")" // BERTHED VESSEL IN ATOM
                + "  AND VOYAGE.VSB_VOY_STATUS = 'D' ";

        SQLQuery sailedRotationsQuery = session.createSQLQuery(sailedRotationsSql)
                .addScalar("Rotation", new StringType()).addScalar("VesselCode", new StringType())
                .addScalar("VesselName", new StringType()).addScalar("EtaDate", new StringType())
                .addScalar("EtaTime", new StringType()).addScalar("ActualBerthDate", new StringType())
                .addScalar("Status", new StringType()).addScalar("VoyageNo", new StringType())
                .addScalar("BerthNo", new StringType());

        Query opusSailedRotationsQuery = sailedRotationsQuery.setResultTransformer(Transformers
                .aliasToBean(OpusVesselDto.class));

        List<OpusVesselDto> sailedRotationsList = (List<OpusVesselDto>) opusSailedRotationsQuery.list();

        return sailedRotationsList;

    }

    public List<OpusEquipmentDto> fetchEquipmentsForRotation(String rotationNo) {

        Session session = getCurrentSession();

        String fetchEquipmentsSql = " SELECT DISTINCT QueSchedule.JOB_QUE_CRANENO EquipmentId"
                + "     FROM  JOB_QUEUE_SCHEDULE QueSchedule, VSB_VOYAGE voyage  "
                + "     WHERE  voyage .VSB_VOY_VOYAGE = QueSchedule.JOB_QUE_VOYAGE "
                + "     AND voyage.VSB_VOY_EVOYAGEOUT = '" + rotationNo + "'"
                + "     AND NVL(QueSchedule.JOB_QUE_COMPFLAG,'X') <> 'C' "
                + "     AND QueSchedule.JOB_QUE_CRANENO IS NOT NULL";

        SQLQuery equipmentsQuery = session.createSQLQuery(fetchEquipmentsSql)
                .addScalar("EquipmentId", new StringType());

        Query fetchEquipmentsQuery = equipmentsQuery.setResultTransformer(Transformers
                .aliasToBean(OpusEquipmentDto.class));

        List<OpusEquipmentDto> equipmentsList = (List<OpusEquipmentDto>) fetchEquipmentsQuery.list();

        return equipmentsList;

    }

}
