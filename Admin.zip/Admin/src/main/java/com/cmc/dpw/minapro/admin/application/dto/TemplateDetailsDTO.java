package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cmc.dpw.minapro.admin.application.entities.pks.TemplateDetailsPk;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateDetailsDTO extends AuditDTO  implements Serializable{

    private static final long serialVersionUID = -1427275763592689322L;

    private TemplateDetailsPk pk;
    private String vesselLabel;
    private Integer seqNo;
    private String headerId;
    
    private Integer version;
    private char isDeleted;

    
    public TemplateDetailsPk getPk() {
        return pk;
    }
    public void setPk(TemplateDetailsPk pk) {
        this.pk = pk;
    }
    public String getVesselLabel() {
        return vesselLabel;
    }
    public void setVesselLabel(String vesselLabel) {
        this.vesselLabel = vesselLabel;
    }
    public Integer getSeqNo() {
        return seqNo;
    }
    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }
    public String getHeaderId() {
        return headerId;
    }
    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }
    
    public Integer getVersion() {
        return version;
    }
    public void setVersion(Integer version) {
        this.version = version;
    }
    public char getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
    
}

   

