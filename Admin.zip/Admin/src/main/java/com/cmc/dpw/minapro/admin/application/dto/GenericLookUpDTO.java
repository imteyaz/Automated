package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

/**
 * 
 * 
 * 
 * @author Prasad Tallapally
 * 
 *         Need to use in all places, where two fields look up's are there
 */
@SuppressWarnings("serial")
public class GenericLookUpDTO implements Serializable {
    private String code;
    private String name;
    private String defaultFlag;
    private String serviceTypeGroupCode;
    // used in Admin module
    private String accessCode;

    public String getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(String defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

    public String getServiceTypeGroupCode() {
        return serviceTypeGroupCode;
    }

    public void setServiceTypeGroupCode(String serviceTypeGroupCode) {
        this.serviceTypeGroupCode = serviceTypeGroupCode;
    }

}
