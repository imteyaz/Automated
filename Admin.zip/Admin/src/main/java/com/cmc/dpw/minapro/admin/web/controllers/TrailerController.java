package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Trailer;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.TrailerService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/trailer")
public class TrailerController {

    @Autowired
    private TrailerService trailerService;
    private static final Logger LOGGER = LoggerFactory.getLogger(TrailerController.class);

    /**
     * This method searches for all the trailers matching the search criteria
     * as entered by the end user
     * 
     * @param trailerId
     * @param trailerName
     * @param make
     * @param model
     * @param trailerTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String trailerNo, @RequestParam(required = false) int start, 
            @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TrailerController Seacrh Trailer method");
     
        String[] requestParameters = { trailerNo};
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"TrailerController-->search trailerNo:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TrailerController Seacrh Trailer method");

            Map<String, Object> trailersMap = trailerService.searchTrailerList(trailerNo, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TrailerController Seacrh Trailer method");
            return getMap(trailersMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"TrailerController-->search Trailer-->Catch Block :{}", e);
            return getModelMapError("Error retrieving Trailers from database.");
        }
    }

    /**
     * This method creates the trailer as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created trailer data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody String data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start> TrailerController> Create Trailer method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Data{}", data);

        try {
            List<Trailer> trailers = trailerService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TrailerController Create Trailer method");
            return getMap(trailers);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create trailer due to following exception  :{}" + cause.getMessage());
            
        }   catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"create -- >ExistingRecordException", e);
            return getModelMapError("Error trying to create trailer : " + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Unable to create trailer.");
        }

    }
    
    /**
     * This method updates the trailer as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated trailer data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody String data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TrailerController Update Trailer method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<Trailer> trailers = trailerService.update(data, principal);
            return getMap(trailers);

        } catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"update --> ExistingRecordException", e);
            return getModelMapError("Error trying to update trailer due to following reason  : : " + e.getCustomErrorMessage());
            
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update trailer. ");
        }
    }

    
    /**
     * This method deletes the trailer.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted trailer data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody String data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TrailerController Delete Trailer method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            trailerService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TrailerController Delete Trailer method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete trailer.");

        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param trailers List of trailers
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<Trailer> trailers) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", trailers);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> trailersMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) trailersMap.get("totalCount");

        List<Trailer> trailers = (List<Trailer>) trailersMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", trailers);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, trailers);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }
   
}
