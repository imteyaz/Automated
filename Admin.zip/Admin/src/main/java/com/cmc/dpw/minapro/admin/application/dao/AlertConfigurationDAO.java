package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.AlertConfigurationDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertConfiguration;
import com.cmc.dpw.minapro.admin.application.entities.AlertGroupAssociation;
import com.cmc.dpw.minapro.admin.application.entities.AlertParameterAssociation;
import com.cmc.dpw.minapro.admin.application.entities.AlertParameterKey;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * AlertConfiguration DAO class.
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class AlertConfigurationDAO extends GenericDAO<AlertConfiguration> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlertConfigurationDAO.class);
    @Autowired
    private Util util;

    /**
     * This method is used to search AlertConfigurations
     * 
     * @param alertCodeVal
     * @param severityVal
     * @param alertTextVal
     * @param descriptionVal
     * @param soundRequiredVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchAlertConfigurations(String alertCodeVal, String alertTextVal,
            String descriptionVal, String severityVal, String soundRequiredVal, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Entering AlertConfiguration DAO's searchAlertConfigurations method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        Integer i = 0;

        Criteria searchCriteria = session.createCriteria(AlertConfiguration.class);
        searchCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

        i = Util.addRestrictions(searchCriteria, "alertCode", alertCodeVal, false, i);
        i = Util.addRestrictions(searchCriteria, "alertText", alertTextVal, false, i);
        i = Util.addRestrictions(searchCriteria, "description", descriptionVal, false, i);
        i = Util.addRestrictions(searchCriteria, "severity", severityVal, false, i);
        i = Util.addRestrictions(searchCriteria, "soundRequired", soundRequiredVal, false, i);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "count of records matched with given search criteria : {}",
                count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<AlertConfiguration> searchAlertConfigurations = null;

        if (i == 0) {
            Query query = session.createQuery("select distinct ac from AlertConfiguration ac");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            searchAlertConfigurations = query.list();

        } else {

            List<Object[]> tempAlertConfigurations = (List<Object[]>) searchCriteria.list();
            List<AlertConfiguration> actualAlertConfigurations = new ArrayList<AlertConfiguration>();

            for (Object[] alertgroupArray : tempAlertConfigurations) {
                AlertConfiguration currentAlert = (AlertConfiguration) alertgroupArray[2];
                actualAlertConfigurations.add(currentAlert);
            }
            searchAlertConfigurations = actualAlertConfigurations;
        }

        String totalRecords = count.toString();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "data from DB: {}", searchAlertConfigurations);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "total count of records matched with given search criteria  : {}", totalRecords);

        for (AlertConfiguration currentAlert : searchAlertConfigurations) {

            StringBuilder activeRoles = new StringBuilder();

            Collection<AlertGroupAssociation> alertsubscribersMap = currentAlert.getAlertsubscribersMap();
            int j = 0;
            int roleCount = alertsubscribersMap.size();
            for (AlertGroupAssociation currentMapping : alertsubscribersMap) {
                currentMapping.setGroupName(currentMapping.getGroup().getUserGroupName());
                j++;
                String roleId = String.valueOf(currentMapping.getGroupId());
                String isActive = currentMapping.getIsActive();
                if ("Y".equalsIgnoreCase(isActive)) {
                    activeRoles.append(roleId);
                    if (roleCount != j) {
                        activeRoles.append(',');
                    }
                }
            }

            currentAlert.setSubscribers(activeRoles.toString());

            List<AlertParameterAssociation> currentAlertKeysMap = (List<AlertParameterAssociation>) currentAlert
                    .getAlertKeysMap();
            int keyCount = currentAlertKeysMap.size();
            int k = 0;
            StringBuilder keyNames = new StringBuilder();
            for (AlertParameterAssociation currentParamMap : currentAlertKeysMap) {
                AlertParameterKey currentParamKey = currentParamMap.getActualkey();
                String paramName = currentParamKey.getParamName();
                k++;
                keyNames.append(paramName);
                if (keyCount != k) {
                    keyNames.append(", ");
                }

            }
            currentAlert.setKeys(keyNames.toString());

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "alertConfiguration Id  : {}", currentAlert.getAlertCode());
        }

        List<AlertConfigurationDTO> actualAlertConfigurationsDtoList = util.map(searchAlertConfigurations,
                AlertConfigurationDTO.class);

        resultMap.put("data", actualAlertConfigurationsDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "exiting alertConfigurationDAO's searchAlertConfigurations method ");
        return resultMap;
    }
}
