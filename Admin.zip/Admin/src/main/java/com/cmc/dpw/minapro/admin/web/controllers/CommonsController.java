package com.cmc.dpw.minapro.admin.web.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.GenericLookUpDTO;
import com.cmc.dpw.minapro.admin.application.dto.MenuItem;
import com.cmc.dpw.minapro.admin.application.entities.RotationControl;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.services.CommonsService;
import com.cmc.dpw.minapro.admin.application.services.UserService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
public class CommonsController {

    @Autowired
    private UserService userService;
    @Autowired
    private CommonsService commonsService;
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonsController.class);
/**
 * This method searches for all the commons matching the search criteria
 * as entered by the end user
 * @param entityName
 * @param columnName
 * @param filterColumnName
 * @param filterColumnVal
 * @param query
 * @param start
 * @param limit
 * @return @return  Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/common/getForeignKeys")
    @ResponseBody public 
    Map<String, Object> fetchForeignKeys(@RequestParam String entityName, @RequestParam String columnName,
            @RequestParam(required = false) String filterColumnName,
            @RequestParam(required = false) String filterColumnVal, @RequestParam(required = false) String query,
            @RequestParam int start, @RequestParam int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start --> CommonsController --> getForeignKeys");

        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CommonsController-->getForeignKeys entityName:{},columnName:{}, query:{} ",
                fetchParameters);

        try {
            Map<String, Object> foreignKeysMap = commonsService.fetchForeignKeyList(entityName, columnName,
                    filterColumnName, filterColumnVal, query, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Returning from CommonsController getForeignKeys method");
            return getMap(foreignKeysMap);
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CommonsController-->getForeignKeys -->Catch Block :{}", e);
            return getModelMapError(MessageConstants.FOREIGN_KEYS_ERROR);
        }

    }
    
    @RequestMapping(value = "/common/getPlainRecords")
    @ResponseBody public 
    Map<String, Object> fetchRecordsWithoutAssociation(@RequestParam String entityName, @RequestParam String columnName,
            @RequestParam(required = false) String filterColumnName,
            @RequestParam(required = false) String filterColumnVal, @RequestParam(required = false) String query,
            @RequestParam int start, @RequestParam int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start --> CommonsController--> getPlainRecords");

        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CommonsController-->fetchRecordsWithoutAssociation >>params-->> entityName:{},columnName:{}, query:{} ",
                fetchParameters);

        try {
            Map<String, Object> foreignKeysMap = commonsService.fetchRecordsWithoutAssociation(entityName, columnName,
                    filterColumnName, filterColumnVal, query, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CommonsController fetchRecordsWithoutAssociation method");
            return getMap(foreignKeysMap);
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CommonsController-->fetchRecordsWithoutAssociation -->Catch Block :{}", e);
            return getModelMapError(MessageConstants.FOREIGN_KEYS_ERROR);
        }

    }
    
    @RequestMapping(value = "/common/getIntegerTypeForeignKeys")
    @ResponseBody public 
    Map<String, Object> findIntegerForeignKeys(@RequestParam String entityName, @RequestParam String columnName,
            @RequestParam(required = false) String filterColumnName,
            @RequestParam(required = false) String filterColumnVal, @RequestParam(required = false) String query,
            @RequestParam int start, @RequestParam int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start --> CommonsController --> getIntegerTypeForeignKeys");

        String[] fetchParameters = { entityName, columnName, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CommonsController-->getIntegerTypeForeignKeys >> params -->> entityName:{},columnName:{}, query:{} ",
                fetchParameters);

        try {
            Map<String, Object> foreignKeysMap = commonsService.fetchRecordsWithoutAssociation(entityName, columnName,
                    filterColumnName, filterColumnVal, query, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CommonsController findIntegerForeignKeys method");
            return getMap(foreignKeysMap);
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CommonsController-->findIntegerForeignKeys -->Catch Block :{}", e);
            return getModelMapError(MessageConstants.FOREIGN_KEYS_ERROR);
        }

    }
    
    /**
     * This method searches for all the commons matching the search criteria
     * as entered by the end user
     * @param entityName
     * @param columnName
     * @param ColumnVal
     * @param used to get ForeignKeys
     */
    @RequestMapping(value = "/common/getFilteredForeignKeys")
    @ResponseBody public 
    Map<String, Object> fetchFilteredForeignKeys(@RequestParam String entityName, @RequestParam Map<String,Object> columnValuePairs,
            @RequestParam String checkEquality,  @RequestParam String orElseAnd, @RequestParam(required = false) String query,
            @RequestParam int start, @RequestParam int limit) {

        Map<String, Object> foreignKeysMap = null; 
        Boolean equalsOrLike = Boolean.valueOf(checkEquality);
        
        try {

        ObjectMapper mapper = new ObjectMapper();
        
        String json = (String) columnValuePairs.get("columnValuePairs");
        
        Map<String, Object> restrictionsMap = new HashMap<String, Object>();

        // convert JSON string to Map
        restrictionsMap = mapper.readValue(json, new TypeReference<Map<String, String>>(){
        });

        
        String filterJson = (String) columnValuePairs.get("filterColumnValuePairs");
        
        Map<String, Object> filtersMap = new HashMap<String, Object>();

        // convert JSON string to Map
        if(filterJson!=null){
             filtersMap = mapper.readValue(filterJson, new TypeReference<Map<String, String>>(){
             });
        }
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CommonsController fetchFilteredForeignKeys method");

        String[] fetchParameters = { entityName, orElseAnd, query };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CommonsController-->fetchFilteredForeignKeys entityName:{},columnName:{}, query:{} ",
                fetchParameters);
          foreignKeysMap = commonsService.fetchForeignKeysByFilters(entityName, restrictionsMap,filtersMap, equalsOrLike, orElseAnd, query, start, limit);
          
          
          if("RotationControl".equalsIgnoreCase(entityName)){
               List equipVesselRotationList =   (List) foreignKeysMap.get("data") ;
               List<RotationControl> rotationsList = new ArrayList<RotationControl>();
               
               for(Object obj: equipVesselRotationList ) {
                   Object[] actualObject = (Object[])obj ;
                   Vessel currentVessel = (Vessel) actualObject[1] ;
                   RotationControl currentRotation = (RotationControl) actualObject[2] ;
                   currentRotation.setVesselCode(currentVessel.getVesselCode());
                   currentRotation.setBerthNo(currentVessel.getVesselName());
                   rotationsList.add(currentRotation);
               }
               foreignKeysMap.put("data", rotationsList) ;
           
          }
          
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CommonsController fetchFilteredForeignKeys method");
           

    } catch (JsonGenerationException e) {
        LOGGER.error(MessageConstants.ERROR_INDICATOR +": CommonsController-->fetchFilteredForeignKeys -->JsonGenerationException :{}", e);
        
    } catch (JsonMappingException e) {
        LOGGER.error(MessageConstants.ERROR_INDICATOR +": CommonsController-->fetchFilteredForeignKeys -->JsonMappingException :{}", e);
        
    } catch (IOException e) {
        LOGGER.error(MessageConstants.ERROR_INDICATOR +": CommonsController-->fetchFilteredForeignKeys -->IOException :{}", e);
        
    } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +": CommonsController-->fetchFilteredForeignKeys -->Generic Catch Block :{}", e);
            return getModelMapError(MessageConstants.FOREIGN_KEYS_ERROR);
    }
        return getMap(foreignKeysMap);
    }
    
    /**
     * Generates modelMap to return to the modelAndView
     * @param Map<String, Object> foreignKeysMap
     * @return Map<String, Object> modelMap containing the data, success indicator and total count 
     */

    private Map<String, Object> getMap(Map<String, Object> foreignKeysMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) foreignKeysMap.get("totalCount");

        List<String> foreignKeys = (List<String>) foreignKeysMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , foreignKeys);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, foreignKeys);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    @RequestMapping(value = "/menuItem/list.action", method = RequestMethod.POST)
    @ResponseBody public 
    Map<String, Object> prepareDynamicMenu(Locale locale, Model model, String userId) {
        
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        List<GenericLookUpDTO> fucntionAccessCodeList = new ArrayList<GenericLookUpDTO>();
        String[] requestParameters = { model.toString(), locale.toString() };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CommonsController-->menuItem CommonsController:{}",
                requestParameters);
        String json = "[";
        if (userId != null && userId.trim().length() != 0) {
            try {

                List<MenuItem> domainMenuList = userService.prepareDynamicMenu(userId);
                List<MenuItem> actualMenuList = new ArrayList<MenuItem>();
                if (domainMenuList != null && !domainMenuList.isEmpty()) {

                    for (MenuItem menu : domainMenuList) {

                        if (menu.getParentMenuId() == null) {
                            actualMenuList.add(menu);
                        } else {
                            // else block is useful for preparing Screen and AccessCode Object List
                            // , for applying security(Denied Menu: QUERY/QUERY,INSERT,UPDATE/QUERY,INSERT/FULL
                            // CONTROLL)
                            // ESP FOR OPENING A SCREEN WHEN WE CLICK ON HYPERLINK INSIDE THE GRID COLUMN
                            if (menu.getAccessCode() != null) {
                                GenericLookUpDTO genericLookUpDTO = new GenericLookUpDTO();
                                genericLookUpDTO.setCode(menu.getMenuId());
                                genericLookUpDTO.setName(menu.getName());
                                genericLookUpDTO.setAccessCode(menu.getAccessCode());
                                fucntionAccessCodeList.add(genericLookUpDTO);
                            }

                        }
                    }
                    Collections.sort(actualMenuList, new Comparator<MenuItem>() {
                        public int compare(MenuItem o1, MenuItem o2) {
                            if ((o1 != null && o2 != null) && (o1.getSortOrder() != null && o2.getSortOrder() != null) ){
                                    return o1.getSortOrder().compareTo(o2.getSortOrder());
                            }
                            return 0;
                        }
                    });
                    for (MenuItem menu : actualMenuList) {
                        menu = consolidateMenuList(menu, domainMenuList);
                    }

                }

                json = makeMenuJSON(actualMenuList, json);

            } catch (Exception e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR +"CommonsController-->menuItem CommonsController-->Catch Block :{}", e);
            }
        }
        json += "]";

        modelMap.put("menuObject", json);
        modelMap.put("funActionObject", fucntionAccessCodeList);
        return modelMap;

    }

    /**
     * 
     * 
     * Preparing JSON format
     * 
     * @param mainMenuList
     * @param JSON
     * @return List<MenuItem> mainMenuList
     */
    private String makeMenuJSON(List<MenuItem> mainMenuList, String json) {
        String resultJson = json ;
        int count = 0;
        if (mainMenuList != null && !mainMenuList.isEmpty()) {
            for (MenuItem menuItem : mainMenuList) {
                resultJson += "{'text':'" + menuItem.getName() + "'" + ",'iconCls':'" + menuItem.getIconCls() + "'"
                        + ",'userId':'" + menuItem.getUserId() + "'" + ",'serviceType':'" + menuItem.getServiceType()
                        + "'" + ",'accessCode':'" + menuItem.getAccessCode() + "'" + ",'functionCode':'"
                        + menuItem.getMenuId() + "'";
                List<MenuItem> list = menuItem.getList();

                if (list != null && !list.isEmpty()) {
                    resultJson += ",'menu':[";
                    resultJson = makeMenuJSON(list, resultJson);
                    resultJson += "]}";
                } else {
                    if (menuItem.getHandler() != null && menuItem.getHandler().length() != 0) {
                        resultJson += ",'handler':function(){" + menuItem.getHandler() + "(this)}";
                    }
                    resultJson += "}";

                }

                if (count < (mainMenuList.size() - 1)) {
                    count++;
                    resultJson += ",";
                }

            }
            count = 0;

        }
        return resultJson;
    }

    /**
     * 
     * 
     * Consolidating Menu list
     * 
     * @param menu
     * @param domainMenuList
     * @return List<MenuItem> domainMenuList
     */
    private MenuItem consolidateMenuList(MenuItem menu, List<MenuItem> domainMenuList) {

        List<MenuItem> tempList = new ArrayList<MenuItem>();
        for (MenuItem sub : domainMenuList) {
            if (sub.getParentMenuId() != null && menu.getMenuId().equalsIgnoreCase(sub.getParentMenuId())) {
                tempList.add(sub);
                consolidateMenuList(sub, domainMenuList);
            }
        }
        if (tempList != null) {

            Collections.sort(tempList, new Comparator<MenuItem>() {
                public int compare(MenuItem o1, MenuItem o2) {
                    if( (o1 != null && o2 != null) && (o1.getSortOrder() != null && o2.getSortOrder() != null)){
                            return o1.getSortOrder().compareTo(o2.getSortOrder());
                    }
                    return 0;
                }
            });

        }
        menu.setList(tempList);
        return menu;
    }

    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
