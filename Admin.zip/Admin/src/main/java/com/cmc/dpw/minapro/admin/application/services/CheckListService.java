package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.CheckListDAO;
import com.cmc.dpw.minapro.admin.application.dao.CheckListHeaderDAO;
import com.cmc.dpw.minapro.admin.application.dto.CheckListDTO;
import com.cmc.dpw.minapro.admin.application.entities.CheckList;
import com.cmc.dpw.minapro.admin.application.entities.CheckListHeader;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Checklist Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class CheckListService {

    @Autowired
    private CheckListDAO checklistDAO;
    @Autowired
    private CheckListHeaderDAO checklistHeaderDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListService.class);

    /**
     * This method is used to get CheckList List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<CheckList> getCheckListList() {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  CheckList service's getCheckListList");
        checklistDAO.setClazz(CheckList.class);
        return checklistDAO.findAll();

    }

    /**
     * @param used to search CheckList List
     *@return Map<String, Object> containing the search CheckList data and success indicator or
     * the error message and failure indicator.
     */
    
    @Transactional(readOnly = true)
    public Map<String, Object> searchCheckListList(String checkListId, String checkListName, String mandatory,
            String icon, String category, String name, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList service's searchCheckListList method");
        checklistDAO.setClazz(CheckList.class);

        String[] requestParameters = { checkListId, checkListName, icon, category, name };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "************In CheckList service searchCheckListList  with CheckListId: {} , CheckListName : {}, icon   : {},  category : {}, checkListHeaderId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList service's searchCheckListList method");

        return checklistDAO.searchCheckLists(checkListId, checkListName, mandatory, icon, category, name, start, limit);
    }

    /**
     * This method is used to create CheckList
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<CheckList>
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_MASTER")
    public List<CheckList> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  CheckList service's  create : {} ", data);

        List<CheckList> newCheckLists = new ArrayList<CheckList>();
        List<CheckList> list = util.getEntitiesFromDto(data, CheckListDTO.class ,CheckList.class);
        
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (CheckList checkList : list) {

            Integer checkListHeaderId = checkList.getCheckListHeaderId();
            checklistHeaderDAO.setClazz(CheckListHeader.class);
            CheckListHeader checkListHeader = checklistHeaderDAO.findOne(checkListHeaderId);
            checkList.setCheckListheader(checkListHeader);

            Date currentDate = new Date();
            checkList.setCreatedDateTime(currentDate);
            checkList.setLastUpdatedDateTime(currentDate);
            checkList.setCreatedBy(userId.toString());
            checkList.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckList Id property in CheckList service's create : {}",
                    checkList.getCheckListId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling CheckList DAO findOne");

            CheckList alreadyCheckList = checklistDAO.findOne(checkList.getCheckListId());

            if (alreadyCheckList == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling CheckList DAO create");
                newCheckLists.add(checklistDAO.create(checkList));
            } else {
                char isDeleted = alreadyCheckList.getIsDeleted();

                if (isDeleted == 'Y') {
                    checkList.setVersion(alreadyCheckList.getVersion());
                    checkList.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling CheckList DAO update");
                    newCheckLists.add(checklistDAO.update(checkList));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null
            }
         // end of for loop
        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList service's create method");
        return newCheckLists;
    }

    /**
     * This method is used to update CheckList
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<CheckList>
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_MASTER")
    public List<CheckList> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  CheckList  service's  update : {} ", data);
        List<CheckList> returnCheckLists = new ArrayList<CheckList>();

        List<CheckList> updatedCheckLists = util.getEntitiesFromDto(data, CheckListDTO.class ,CheckList.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (CheckList checkList : updatedCheckLists) {

            Integer checkListHeaderId = checkList.getCheckListHeaderId();
            checklistHeaderDAO.setClazz(CheckListHeader.class);
            CheckListHeader checkListHeader = checklistHeaderDAO.findOne(checkListHeaderId);
            checkList.setCheckListheader(checkListHeader);

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckListId property in CheckList service update : {}", checkList.getCheckListId());
            checkList.setLastUpdatedDateTime(currentDate);
            checkList.setLastUpdatedBy(userId.toString());
            returnCheckLists.add(checklistDAO.update(checkList));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList service's update method");
        return returnCheckLists;
    }

    /**
     * This method is used to delete CheckList
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In CheckList's service delete : {} ", data);
       
        List<CheckList> deletedCheckLists = util.getEntitiesFromDto(data, CheckListDTO.class ,CheckList.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (CheckList checkList : deletedCheckLists) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckList Id property in CheckList service delete : {}",
                    checkList.getCheckListId());
            checkList.setLastUpdatedDateTime(currentDate);
            checkList.setLastUpdatedBy(userId.toString());
            checkList.setIsDeleted('Y');
            checklistDAO.delete(checkList);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList service's delete method");
    }
   
}
