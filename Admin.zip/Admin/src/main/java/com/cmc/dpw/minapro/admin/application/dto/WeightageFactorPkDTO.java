package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

public class WeightageFactorPkDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String weightageType;
    private String weightageCriteria;
    
    public String getWeightageType() {
        return weightageType;
    }
    public void setWeightageType(String weightageType) {
        this.weightageType = weightageType;
    }
    public String getWeightageCriteria() {
        return weightageCriteria;
    }
    public void setWeightageCriteria(String weightageCriteria) {
        this.weightageCriteria = weightageCriteria;
    }

    
}
