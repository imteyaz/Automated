package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.GenericGroupAssociationDTO;
import com.cmc.dpw.minapro.admin.application.dto.GenericLookUpDTO;
import com.cmc.dpw.minapro.admin.application.dto.GroupDTO;
import com.cmc.dpw.minapro.admin.application.dto.MenuItem;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;
/**
 * GroupUserSecurityDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class GroupUserSecurityDAO extends GenericDAO {

    Map<String, Object> resultMap = new HashMap<String, Object>();
    private static final Logger LOGGER = LoggerFactory.getLogger(GroupUserSecurityDAO.class);
/**
 * This method is used to search Roles
 * @param userNameVal
 * @param roleNameVal
 * @param roleIdVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchRoles(String userNameVal, String roleNameVal, String roleIdVal, int start,
            int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->searchRoles method");
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";
        int i = 0;
        Criteria searchCriteria = session.createCriteria(Role.class, "roleClass");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { userNameVal, roleNameVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , searchParameters);

        if (!("".equalsIgnoreCase(userNameVal)) && userNameVal != null) {

            searchCriteria.createAlias("roleClass.actualUsers", "user");
            searchCriteria.add(Restrictions.eq("user.userName", userNameVal).ignoreCase());
            i++;
        }

        if (!("".equalsIgnoreCase(roleNameVal)) && roleNameVal != null) {
            likeValue = "";
            String roleName = likeValue.concat(percentage).concat(roleNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("userGroupName", roleName).ignoreCase());
            i++;
        }

        if (!("".equalsIgnoreCase(roleIdVal)) && roleIdVal != null) {
            likeValue = "";
            String roleId = likeValue.concat(percentage).concat(roleIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("userGroupCd", roleId).ignoreCase());
            i++;
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , count);
        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Role> searchRoles = null;

        if (i != 0) {

            String sql = "select distinct r from Role r left join fetch r.actualUsers au where " +

            "lower(r.userGroupName) like lower('%" + roleNameVal + "%')";

            if (!userNameVal.isEmpty()) {
                sql = sql + " and  lower(au.userName) like lower('%" + userNameVal + "%')";
            }

            Query query = session.createQuery(sql);

            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<Role> rolesList = query.list();

            searchRoles = rolesList;

        } else {

            searchRoles = (List<Role>) searchCriteria.list();
        }

        List<GroupDTO> groupDtoList = new ArrayList<GroupDTO>();

        for (Role role : searchRoles) {

            GroupDTO tempGroupDto = new GroupDTO();
            tempGroupDto.setGroupName(role.getUserGroupName());
            tempGroupDto.setGroupCode(role.getUserGroupCd());
            tempGroupDto.setGroupDesc(role.getsDesc());
            tempGroupDto.setServiceTypeCode(role.getSrvTypeGroupCd());
            tempGroupDto.setGroupId(role.getIntUserGroupId());
            tempGroupDto.setSystemDefined(role.getSystemDefined());
            groupDtoList.add(tempGroupDto);

        }

        String totalRecords = count.toString();
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , searchRoles);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, groupDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        resultMap.put(MessageConstants.SUCCESS_KEY, true);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR );
        return resultMap;

    }

    public List<GenericLookUpDTO> getGroupAssociatedUserDetails(String groupId, String serviceType) {
        /**
         * This method is used to getGroupAssociatedUserDetails
         * @return userDtoList
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->getGroupAssociatedUserDetails");
        Session session = getCurrentSession();
        Criteria searchCriteria = session.createCriteria(User.class, "usser");

        searchCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        String[] searchParameters = { groupId, serviceType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , searchParameters);
        if (groupId != null && !groupId.isEmpty()) {
            searchCriteria.createAlias("usser.actualRoles", "role");
            searchCriteria.add(Restrictions.eq("role.intUserGroupId", Integer.parseInt(groupId)));
        }

        List<User> searchUsers = (List<User>) searchCriteria.list();

        List<GenericLookUpDTO> userDtoList = new ArrayList<GenericLookUpDTO>();

        for (User user : searchUsers) {

            GenericLookUpDTO tempUserDto = new GenericLookUpDTO();
            tempUserDto.setName(user.getUserName());
            tempUserDto.setCode(user.getUserId().toString());
            userDtoList.add(tempUserDto);
        }

        return userDtoList;
    }

    public List<GenericLookUpDTO> getGroupAvailableUserDetails(String groupId, String userName) {
        /**
         * This method is used to getGroupAvailableUserDetails
         * @return (List<GenericLookUpDTO>) userCriteria.list()
         */
        Session session = getCurrentSession();
        String sql = "SELECT u.user_nm name, u.int_user_id code  FROM mp_userdtls_am u where LOWER(u.user_nm) like  LOWER('%"
                + userName + "%')";

        if (!groupId.isEmpty() && groupId != null) {
            String grpSql = " AND NOT EXISTS "
                    + "(SELECT 1 FROM mp_usergrp_a ug WHERE ug.int_user_id = u.int_user_id AND "
                    + "ug.int_user_grp_id=" + Integer.parseInt(groupId) + ")";

            sql = sql.concat(grpSql);
        }

        SQLQuery query = session.createSQLQuery(sql).addScalar("name", new StringType())
                .addScalar("code", new StringType());

        Query userCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(GenericLookUpDTO.class));

        return (List<GenericLookUpDTO>) userCriteria.list();

    }

    public List<MenuItem> getModuleDetails(String serviceType) {
        /**
         * This method is used to getModuleDetails
         * @return (List<MenuItem>) menuCriteria.list()
         */
        Session session = getCurrentSession();
        String[] parameters = { serviceType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , parameters);
        String sql = "SELECT child_module_cd menuId," + " b.module_nm name," + " parent_module_cd parentMenuId, "
                + " CONNECT_BY_ISLEAF sortOrder " + " FROM mp_moduletree_a a," + "mp_moduledescr_am b"
                + " WHERE a.child_module_cd = b.module_cd " + " START WITH parent_module_cd      = 'FAPSB'"
                + " CONNECT BY prior child_module_cd = parent_module_cd ";

        SQLQuery query = session.createSQLQuery(sql).addScalar("menuId", new StringType())
                .addScalar("name", new StringType()).addScalar("sortOrder", new IntegerType())
                .addScalar("parentMenuId", new StringType());

        Query menuCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(MenuItem.class));

        return (List<MenuItem>) menuCriteria.list();
    }

    public List<GenericLookUpDTO> getAvailableFunctionDetailsByModuleId(String moduleId, String groupId,
            String serviceType) {
        /**
         * This  method is used to getAvailableFunctionDetailsByModuleId
         * @return (List<GenericLookUpDTO>) menuCriteria.list()
         */
        Session session = getCurrentSession();
        String[] parameters = { serviceType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , parameters);

        String sql = "SELECT c.function_nm name," + "c.function_cd code,"
                + "NVL((SELECT menu_cd  FROM mp_functiongrpaccess_a WHERE function_cd = c.function_cd "
                + "and int_user_grp_id =" + Integer.parseInt(groupId) + "),1) accessCode "
                + "FROM mp_functiontree_a f," + "mp_functiondescr_am c " + "WHERE f.module_cd = '" + moduleId + "'"
                + " AND f.function_cd = c.function_cd" + " AND c.function_cd NOT IN" + " (SELECT a.function_cd"
                + " FROM mp_functiongrpaccess_a a," + " mp_functiontree_a b" + " WHERE a.function_cd = b.function_cd"
                + " AND b.module_cd  ='" + moduleId + "'" + " AND a.int_user_grp_id  =" + Integer.parseInt(groupId)
                + " AND b.module_cd in (SELECT module_cd FROM mp_moduledescr_am)" + ")";

        SQLQuery query = session.createSQLQuery(sql).addScalar(MessageConstants.CODE_KEY, new StringType())
                .addScalar(MessageConstants.NAME_KEY, new StringType())
                .addScalar(MessageConstants.ACCESSCODE_KEY, new StringType());

        Query menuCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(GenericLookUpDTO.class));
        return (List<GenericLookUpDTO>) menuCriteria.list();
    }

    public List<GenericLookUpDTO> getAssociatedFunctionDetailsByModuleId(String moduleId, String groupId,
            String serviceType) {
        /**
         * This method is used to getAssociatedFunctionDetailsByModuleId
         * @return (List<GenericLookUpDTO>) menuCriteria.list()
         */
        Session session = getCurrentSession();
        String[] parameters = { serviceType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , parameters);
        String sql = "SELECT c.function_nm name , c.function_cd code,  a.MENU_CD accessCode,  c.SHOW_FLG defaultFlag"
                + " FROM mp_functiongrpaccess_a a,   mp_functiontree_a b,  mp_functiondescr_am c "
                + " WHERE a.function_cd   = b.function_cd " + " AND b.module_cd = '" + moduleId + "'"
                + " AND a.int_user_grp_id = " + Integer.parseInt(groupId) + " AND a.function_cd     = c.function_cd";

        SQLQuery query = session.createSQLQuery(sql).addScalar("code", new StringType())
                .addScalar("name", new StringType()).addScalar("accessCode", new StringType())
                .addScalar("defaultFlag", new StringType());

        Query menuCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(GenericLookUpDTO.class));
        return (List<GenericLookUpDTO>) menuCriteria.list();
    }

    public List<GroupDTO> findGroupByCodeAndName(String code, String name) {
        /**
         * This method is used to findGroupByCodeAndName
         * @return (List<GroupDTO>) grpCriteria.list()
         */
        Session session = getCurrentSession();

        String sql = "select INT_USER_GRP_ID groupId,USER_GRP_CD groupCode,USER_GRP_NM groupName,S_DESCR groupDesc from MP_GRPDTLS_AM "
                + " where lower(USER_GRP_CD) = lower('" + code + "') or lower(USER_GRP_NM) = lower('" + name + "')";

        SQLQuery query = session.createSQLQuery(sql).addScalar("groupId", new IntegerType())
                .addScalar("groupCode", new StringType()).addScalar("groupName", new StringType())
                .addScalar("groupDesc", new StringType());

        Query grpCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(GroupDTO.class));
        return (List<GroupDTO>) grpCriteria.list();
    }

    public List<GenericLookUpDTO> getFunctionCodesAssociatedWithUserAndGroup(String userId) {
        /**
         * This method is used to getFunctionCodesAssociatedWithUserAndGroup
         * @return query.list()
         */
        String[] parameters = { userId };
        Session session = getCurrentSession();
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , parameters);
        Query query = session.createQuery("select distinct fga from FunctionGroupAccess fga");

        return query.list();
    }

    public List<GenericLookUpDTO> getAllUserDetails(String searchUserName) {
        /**
         * This method is used to getAllUserDetails
         * @return userDtoList
         */
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";
        Criteria searchCriteria = session.createCriteria(User.class, "userClass");
        searchCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        String[] searchParameters = { searchUserName };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , searchParameters);

        if (!searchUserName.isEmpty() && searchUserName != null) {
            likeValue = "";
            String searchUserNameVal = likeValue.concat(percentage).concat(searchUserName).concat(percentage);
            searchCriteria.add(Restrictions.like("userName", searchUserNameVal).ignoreCase());
        }
        List<User> searchUsers = (List<User>) searchCriteria.list();
        List<GenericLookUpDTO> userDtoList = new ArrayList<GenericLookUpDTO>();

        for (User user : searchUsers) {

            GenericLookUpDTO tempUserDto = new GenericLookUpDTO();
            tempUserDto.setName(user.getUserName());
            tempUserDto.setCode(user.getUserId().toString());

            userDtoList.add(tempUserDto);

        }

        return userDtoList;
    }

    public List<GenericGroupAssociationDTO> getFunctionsByGroupId(String copyGroupId) {
        /**
         * This method is used to getFunctionsByGroupId
         * @return (List<GenericGroupAssociationDTO>) funcCriteria.list()
         */
        Session session = getCurrentSession();

        String sql = "select INT_USER_GRP_ID groupId, FUNCTION_CD associateId, MENU_CD accessCode FROM mp_functiongrpaccess_a"
                + " WHERE INT_USER_GRP_ID = " + Integer.parseInt(copyGroupId);

        SQLQuery query = session.createSQLQuery(sql).addScalar("groupId", new StringType())
                .addScalar("associateId", new StringType()).addScalar("accessCode", new IntegerType());

        Query funcCriteria = (Query) query.setResultTransformer(Transformers
                .aliasToBean(GenericGroupAssociationDTO.class));
        return (List<GenericGroupAssociationDTO>) funcCriteria.list();

    }

    public boolean deleteGroupAssociations(int groupId) {

        Session session = getCurrentSession();

        String userSql = "delete from mp_usergrp_a where int_user_grp_id = " + groupId;

        String functionSql = "delete from mp_functiongrpaccess_a where int_user_grp_id = " + groupId;

        SQLQuery delUserGrpquery = session.createSQLQuery(userSql);

        SQLQuery delFuncGrpQuery = session.createSQLQuery(functionSql);

        delUserGrpquery.executeUpdate();

        delFuncGrpQuery.executeUpdate();

        return true;

    }

}
