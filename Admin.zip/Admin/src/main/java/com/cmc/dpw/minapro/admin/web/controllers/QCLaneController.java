package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.QCLane;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.QCLaneService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/QC_Lane")
public class QCLaneController {

    @Autowired
    private QCLaneService qcLaneService;
    private static final Logger LOGGER = LoggerFactory.getLogger(QCLaneController.class);
    /**
     * This method searches for all the QC_Lanes matching the search criteria
     * as entered by the end user
     * @param availability
     * @param driveDirection
     * @param limit
     * @param start
     *  @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String laneId,
            @RequestParam(required = false) String availability, @RequestParam(required = false) String driveDirection,
            @RequestParam(required = false) int limit, @RequestParam(required = false) int start) {
       

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start QCLaneController Seacrh QCLane method");

        String[] requestParameters = { laneId, availability, driveDirection };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"QCLaneController-->Seacrh laneId:{},availability:{},driveDirection:{} ",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering QCLaneController Seacrh QCLane method");

            Map<String, Object> qcLanesMap = qcLaneService.searchQCLaneList(laneId, availability, driveDirection,
                    start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QCLaneController Seacrh QCLane method");
            return getMap(qcLanesMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"QCLaneController-->Seacrh QCLane-->Catch Block :{}", e);
            return getModelMapError("Error retrieving QCLanes from database.");
        }
    }

    /**
     * This method creates the QCLane as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created QCLane data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start QCLaneController Create QCLane method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<QCLane> qcLanes = qcLaneService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QC_Lane controller's searchQC_Lanes method");
            return getMap(qcLanes);

        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError("Error trying to create QC Lane due to following exception :{}" + cause.getMessage());
            
        } catch(ExistingRecordException e){
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create QC Lane :{}" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create QC Lane.");
        }
    }

    /**
     * This method updates the QCLane as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated QCLane data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start QCLaneController Update QCLane method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<QCLane> qcLanes = qcLaneService.update(data, principal);

            return getMap(qcLanes);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update QC_Lane. ");
        }
    }

    /**
     * This method deletes the QCLane.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted QCLane data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start QCLaneController Delete QCLane method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            qcLaneService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QCLaneController Delete QCLane method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete QC_Lane.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param QC_Lanes List of qc_lane
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<QCLane> qcLanes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, qcLanes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> qcLanesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) qcLanesMap.get("totalCount");

        List<QCLane> qcLanes = (List<QCLane>) qcLanesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", qcLanes);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, qcLanes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
