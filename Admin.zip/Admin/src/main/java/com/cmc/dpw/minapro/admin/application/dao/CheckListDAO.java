package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.CheckListDTO;
import com.cmc.dpw.minapro.admin.application.entities.CheckList;
import com.cmc.dpw.minapro.admin.application.entities.CheckListHeader;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * CheckListDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class CheckListDAO extends GenericDAO<CheckList> {
    
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListDAO.class);
/**
 * This method is used to search CheckLists
 * @param checkListdVal
 * @param checkListNameVal
 * @param mandatoryVal
 * @param iconVal
 * @param categoryVal
 * @param checkListHeaderNameVal
 * @param start
 * @param limit
 * @return Map<String, Object>
 */
    public Map<String, Object> searchCheckLists(String checkListdVal, String checkListNameVal, String mandatoryVal,
            String iconVal, String categoryVal, String checkListHeaderNameVal, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList DAO's searchCheckListHeaders method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
      
        Criteria searchCriteria = session.createCriteria(CheckList.class, "checkList");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { checkListdVal, checkListNameVal, mandatoryVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchCheckList in CheckList DAO with checkListdVal: {} , checkListNameVal : {}  , mandatoryVal : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        Util.addRestrictions(searchCriteria, "checkListId", checkListdVal, false);
        Util.addRestrictions(searchCriteria, "checkListName", checkListNameVal, false);
        Util.addRestrictions(searchCriteria, "mandatory", mandatoryVal, false);
        Util.addRestrictions(searchCriteria, "icon", iconVal, false);
        Util.addRestrictions(searchCriteria, "category", categoryVal, false);
       
        if (checkListHeaderNameVal != null   && !(checkListHeaderNameVal.isEmpty()) ) {
            searchCriteria.createAlias("checkList.checkListheader", "header");
            searchCriteria.add(Restrictions.eq("header.name", checkListHeaderNameVal));
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Object[]> searchCheckLists = (List<Object[]>) searchCriteria.list();
        List<CheckList> actualcheckLists = new ArrayList<CheckList>();

        for (Object[] userArr : searchCheckLists) {
            CheckList currentCheckList = (CheckList) userArr[2];
            CheckListHeader currentCheckListHeader = (CheckListHeader) userArr[0];

            currentCheckList.setCheckListHeaderName(currentCheckListHeader.getName());
            currentCheckList.setCheckListHeaderId(currentCheckListHeader.getCheckListHeaderId());

            currentCheckList.setCheckListheader(null);
            actualcheckLists.add(currentCheckList);

        }

        List<CheckListDTO> searchCheckListsDtoList =  util.map(actualcheckLists, CheckListDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data from DB: {}", searchCheckListsDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchCheckListsDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        for (CheckList checkList : actualcheckLists) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"checkListHeader Id  : {}", checkList.getCheckListId());
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting checkListHeaderDAO's searchCheckListHeaders method ");
        return resultMap;
    }

    public boolean deleteByParentId(CheckListHeader checkListHeader) {

        Integer headerId = checkListHeader.getCheckListHeaderId();

        Session session = getCurrentSession();

        // soft delete

        String checkListSql = "update mp_checklist_master set isdeleted = 'Y' where checklist_hdr_id = " + headerId;

        SQLQuery delcheckListspquery = session.createSQLQuery(checkListSql);

        int deletedRows = delcheckListspquery.executeUpdate();
        Integer[] params = { headerId, deletedRows };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Inside checkListDAO's deleteByParentId with checkListHeader Id : {} , deletedrows : {}  ",
                params);

        return true;
    }

}
