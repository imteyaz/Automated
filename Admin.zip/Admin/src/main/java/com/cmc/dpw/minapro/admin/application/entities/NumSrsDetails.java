package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cmc.dpw.minapro.admin.application.entities.pks.NumberingSeriesDetailsPk;
/**
 * NumSrsDetails POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_NUMSRSDTLS_YPM")
public class NumSrsDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer seqNo;
    private String no20Ft;
    private String no40Ft;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insExtUsrFlg;
    private String updUsrCd;
    private Date updDttm;
    private String updExtUsrFlg;
    private String txnCd;
    private Integer txnNo;
    private char isDeleted;
    private NumberingSeriesDetailsPk pk;
    
    @EmbeddedId
    public NumberingSeriesDetailsPk getPk() {
        return pk;
    }

    public void setPk(NumberingSeriesDetailsPk pk) {
        this.pk = pk;
    }

    @Transient
    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    @Column(name = "NO_20FT")
    public String getNo20Ft() {
        return no20Ft;
    }

    public void setNo20Ft(String no20Ft) {
        this.no20Ft = no20Ft;
    }

    @Column(name = "NO_40FT")
    public String getNo40Ft() {
        return no40Ft;
    }

    public void setNo40Ft(String no40Ft) {
        this.no40Ft = no40Ft;
    }

    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Column(name = "ADT_INS_USR_CD")
    public String getInsUsrCd() {
        return insUsrCd;
    }

    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getInsExtUsrFlg() {
        return insExtUsrFlg;
    }

    public void setInsExtUsrFlg(String insExtUsrFlg) {
        this.insExtUsrFlg = insExtUsrFlg;
    }

    @Column(name = "ADT_UPD_USR_CD")
    public String getUpdUsrCd() {
        return updUsrCd;
    }

    public void setUpdUsrCd(String updUsrCd) {
        this.updUsrCd = updUsrCd;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }

    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdExtUsrFlg() {
        return updExtUsrFlg;
    }

    public void setUpdExtUsrFlg(String updExtUsrFlg) {
        this.updExtUsrFlg = updExtUsrFlg;
    }

    @Column(name = "ADT_TXN_CD")
    public String getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }

    @Column(name = "ADT_TXN_NO")
    public Integer getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }
    
    @Column(name = "ISDELETED", nullable = false)
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}

/*
 * NUMSRS_ID VARCHAR2(5 BYTE) SEQ_NO NUMBER(6,0) NO_20FT VARCHAR2(3 BYTE) NO_40FT VARCHAR2(3 BYTE) ADT_VER_STAMP
 * NUMBER(6,0) ADT_INS_USR_CD VARCHAR2(10 BYTE) ADT_INS_DTTM DATE ADT_INS_EXT_USR_FLG CHAR(1 BYTE) ADT_UPD_USR_CD
 * VARCHAR2(10 BYTE) ADT_UPD_DTTM DATE ADT_UPD_EXT_USR_FLG CHAR(1 BYTE) ADT_TXN_CD VARCHAR2(15 BYTE) ADT_TXN_NO
 * NUMBER(15,0)
 */
