package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RotationQCPk implements Serializable {

   

    private Integer rotationControlId;
    private String equipmentId;
    
    public RotationQCPk() {
    }

    @Column(name = "ROTATION_CONTROL_ID")
    public Integer getRotationControlId() {
        return rotationControlId;
    }

    public void setRotationControlId(Integer rotationControlId) {
        this.rotationControlId = rotationControlId;
    }

    @Column(name = "EQUIPMENT_ID")
    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

}
