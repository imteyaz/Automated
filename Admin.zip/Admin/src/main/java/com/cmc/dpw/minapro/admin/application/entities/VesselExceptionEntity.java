package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;
/**
 * VesselExceptionEntity POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "VesselExceptionEntity")
@Table(name = "MP_VESSEL_EXCEPTIONS")
public class VesselExceptionEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer vesselExceptionId;
    private Integer vesselNo;
    private Integer rotation;
    private String exceptionType;
    private String description;
    private String bay;
    private String row;
    private String tier;
    private String vesselName;
    private Date createdDateTime;
    private String createdBy;
    private Integer version;
    private String equipmentId;
    
   
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vesselExceptionSequence")
    @SequenceGenerator(name = "vesselExceptionSequence", sequenceName = "MP_VESSEL_EXCEPTIONS_SEQ", allocationSize = 1, initialValue = 30)
    @Column(name = "VLS_EXCEPTION_ID", nullable = false)
    public Integer getVesselExceptionId() {
        return vesselExceptionId;
    }

    public void setVesselExceptionId(Integer vesselExceptionId) {
        this.vesselExceptionId = vesselExceptionId;
    }

    @Column(name = "INT_VSL_NO", nullable = false)
    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }

    @Column(name = "ROTATION_NO", nullable = false)
    public Integer getRotation() {
        return rotation;
    }

    public void setRotation(Integer rotation) {
        this.rotation = rotation;
    }

    @Column(name = "EXCEPTION_TYPE", nullable = false)
    public String getExceptionType() {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    @Column(name = "EXCEPTION_DESC", nullable = false)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "BAY_NO", nullable = false)
    public String getBay() {
        return bay;
    }

    public void setBay(String bay) {
        this.bay = bay;
    }

    @Column(name = "ROW_NO", nullable = false)
    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    @Column(name = "TIER_NO", nullable = false)
    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }
    
    @Transient
    public String getVesselName() {
        return vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }

    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    @Column(name = "CREATED_BY", nullable = false)
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Version
    @Column(name = "VERSION")
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
    @Column(name = "EQUIPMENT_ID")
    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    
    

}
