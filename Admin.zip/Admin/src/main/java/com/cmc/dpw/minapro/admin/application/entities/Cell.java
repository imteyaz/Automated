package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.CellPk;
/**
 * Cell POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_CELL_SPM")
public class Cell implements Serializable {
    @EmbeddedId
    private CellPk pk;

    @Column(name = "UNAVLB_IND")
    private char isAvialable;

    @Column(name = "DOOR_DIRN_IND")
    private char doorDirectionIndicator;

    @Column(name = "ONLY_MTY_CTR_ALLOWD_FLG")
    private char onlyEmptyContainerAllowedFlag;

    @Column(name = "HOT_SPOT_FLG")
    private char hotSpotFlag;

    @Column(name = "ALLOWD_RFR_TYPE")
    private char reeferTypeFlag;

    @Column(name = "ALLOWD_45")
    private char allowed45Flag;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;

    public CellPk getPk() {
        return pk;
    }

    public void setPk(CellPk pk) {
        this.pk = pk;
    }

    public char getIsAvialable() {
        return isAvialable;
    }

    public void setIsAvialable(char isAvialable) {
        this.isAvialable = isAvialable;
    }

    public char getDoorDirectionIndicator() {
        return doorDirectionIndicator;
    }

    public void setDoorDirectionIndicator(char doorDirectionIndicator) {
        this.doorDirectionIndicator = doorDirectionIndicator;
    }

    public char getOnlyEmptyContainerAllowedFlag() {
        return onlyEmptyContainerAllowedFlag;
    }

    public void setOnlyEmptyContainerAllowedFlag(char onlyEmptyContainerAllowedFlag) {
        this.onlyEmptyContainerAllowedFlag = onlyEmptyContainerAllowedFlag;
    }

    public char getHotSpotFlag() {
        return hotSpotFlag;
    }

    public void setHotSpotFlag(char hotSpotFlag) {
        this.hotSpotFlag = hotSpotFlag;
    }

    public char getReeferTypeFlag() {
        return reeferTypeFlag;
    }

    public void setReeferTypeFlag(char reeferTypeFlag) {
        this.reeferTypeFlag = reeferTypeFlag;
    }

    public char getAllowed45Flag() {
        return allowed45Flag;
    }

    public void setAllowed45Flag(char allowed45Flag) {
        this.allowed45Flag = allowed45Flag;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
