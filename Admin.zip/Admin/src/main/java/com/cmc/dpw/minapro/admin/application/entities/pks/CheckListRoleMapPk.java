package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key
 * 
 * @author Imran Rawani
 * 
 */
@Embeddable
public class CheckListRoleMapPk implements Serializable {

    private static final long serialVersionUID = 5119931525214764973L;

   
    private Integer checkListHeaderId;
    private Integer roleId;

    @Column(name = "CHECKLIST_HDR_ID")
    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }

    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }

    @Column(name = "INT_USER_GRP_ID")
    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    
}
