package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnore;

/**
 * AlertGroupAssociation DTO
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class AlertGroupAssociationDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRoleId;
    private String alertCode;
    private Integer groupId;
    private String isActive;
    private String groupName ;
    private RoleDTO group ;
    
    public Integer getAlertRoleId() {
        return alertRoleId;
    }
    public void setAlertRoleId(Integer alertRoleId) {
        this.alertRoleId = alertRoleId;
    }
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    public Integer getGroupId() {
        return groupId;
    }
    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
    public String getIsActive() {
        return isActive;
    }
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    
    @JsonIgnore
    public RoleDTO getGroup() {
        return group;
    }
    public void setGroup(RoleDTO group) {
        this.group = group;
    }
   
    
    
}
