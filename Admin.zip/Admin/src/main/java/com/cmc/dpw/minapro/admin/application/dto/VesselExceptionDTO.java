package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * VesselExceptionEntity POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class VesselExceptionDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer vesselExceptionId;
    private Integer vesselNo;
    private Integer rotation;
    private String exceptionType;
    private String description;
    private String bay;
    private String row;
    private String tier;
    private String equipmentId;
    private String vesselName;
    private Date createdDateTime;
    private String createdBy;
    
    public Integer getVesselExceptionId() {
        return vesselExceptionId;
    }
    public void setVesselExceptionId(Integer vesselExceptionId) {
        this.vesselExceptionId = vesselExceptionId;
    }
    public Integer getVesselNo() {
        return vesselNo;
    }
    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }
    public Integer getRotation() {
        return rotation;
    }
    public void setRotation(Integer rotation) {
        this.rotation = rotation;
    }
    public String getExceptionType() {
        return exceptionType;
    }
    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getBay() {
        return bay;
    }
    public void setBay(String bay) {
        this.bay = bay;
    }
    public String getRow() {
        return row;
    }
    public void setRow(String row) {
        this.row = row;
    }
    public String getTier() {
        return tier;
    }
    public void setTier(String tier) {
        this.tier = tier;
    }
    public String getVesselName() {
        return vesselName;
    }
    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }
    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    
    
   
}
