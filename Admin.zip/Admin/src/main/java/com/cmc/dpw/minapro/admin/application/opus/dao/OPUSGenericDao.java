package com.cmc.dpw.minapro.admin.application.opus.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.interfaces.IGenericDao;
/**
 * GenericDAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class OPUSGenericDao<T extends Serializable> implements IGenericDao<T> {

    private Class<T> clazz;
    private static final Logger LOGGER = LoggerFactory.getLogger(OPUSGenericDao.class);

   
    SessionFactory sessionFactory;

    public void setClazz(Class<T> clazzToSet) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Generic DAO's setClazz method");
        this.clazz = clazzToSet;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    @Autowired
    @Qualifier("opusSessionFactory")
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"OPUS Session factory object is autowired !");
    }
    
    @SuppressWarnings("unchecked")
    public T findOne(Object id) {

        return (T) getCurrentSession().get(clazz, (Serializable) id);
    }

    @SuppressWarnings("unchecked")
    public T findOne(String id) {

        return (T) getCurrentSession().get(clazz, id);
    }

    @SuppressWarnings("unchecked")
    public T findOne(Integer id) {

        return (T) getCurrentSession().get(clazz, id);
    }

    @SuppressWarnings("unchecked")
    public List<T> findAll() {

        return getCurrentSession().createQuery("from " + clazz.getName()).list();
    }

    public T create(T entity) {
        /**
         * This method is used to create entity
         * @return entity
         */
        getCurrentSession().persist(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record created sucessfully...");
        return entity;
    }

    public T update(T entity) {
        /**
         * This method is used to update entity
         */
        getCurrentSession().merge(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record Updated sucessfully...");
        return entity;
    }

    public T saveOrupdate(T entity) {
        /**
         * This method is used to saveOrupdate entity
         * @return entity
         */
        getCurrentSession().saveOrUpdate(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record saved/updated sucessfully...");
        return entity;
    }

    public void delete(T entity) {
        /**
         * This method is used to soft delete entity
         */
        getCurrentSession().merge(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record soft deleted sucessfully...");
    }

    public void hardDelete(T entity) {
        /**
         * This method is used to hardDelete entity
         */
        getCurrentSession().delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record hard deleted sucessfully...");

    }

    public T save(T entity) {
        getCurrentSession().save(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record saved sucessfully...");
        return entity;
    }
   
    public void deleteById(String entityId) {
        T entity = findOne(entityId);
        delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"selected Record hard deleted sucessfully for string primary key...");
    }
    
    public void hardDeleteById(Integer entityId) {
        T entity = findOne(entityId);
        delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"selected Record hard deleted  sucessfully for integer primary key...");
    }

    protected final Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }
    
  

}