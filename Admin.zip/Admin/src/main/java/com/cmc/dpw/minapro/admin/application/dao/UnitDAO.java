package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.UnitDTO;
import com.cmc.dpw.minapro.admin.application.entities.Unit;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * UnitDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class UnitDAO extends GenericDAO<Unit> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(UnitDAO.class);
    /**
     * This method is used to search Units
     * @param unitCodeVal
     * @param unitNameVal
     * @param start
     * @param limit
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchUnits(String unitCodeVal, String unitNameVal, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Unit DAO's searchUnits method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(Unit.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { unitCodeVal, unitNameVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchUnits with unitcode: {} , unitName : {}", searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(unitCodeVal))  && unitCodeVal != null) {
            likeValue = "";
            String unitCode = likeValue.concat(percentage).concat(unitCodeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("unitId", unitCode));
        }

        if (!("".equalsIgnoreCase(unitNameVal))  && unitNameVal != null) {
            likeValue = "";
            String unitName = likeValue.concat(percentage).concat(unitNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("unitName", unitName).ignoreCase());
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Unit> searchUnits = (List<Unit>) searchCriteria.list();
        List<UnitDTO> searchUnitsDtoList =  util.map(searchUnits, UnitDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data: {}", searchUnitsDtoList);
        LOGGER.debug("******* totalCount: {}", totalRecords);

        resultMap.put("data", searchUnitsDtoList);
        resultMap.put("totalCount", totalRecords);

        for (Unit unit : searchUnits) {
            LOGGER.debug("******** unit : {}", unit.getUnitName());

        }
        LOGGER.debug("********* exiting UnitDAO's searchUnits method ");
        return resultMap;
    }

}
