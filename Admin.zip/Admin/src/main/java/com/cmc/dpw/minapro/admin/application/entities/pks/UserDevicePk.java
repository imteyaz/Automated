package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UserDevicePk implements Serializable {
    
    private static final long serialVersionUID = 2454206915273897222L;

    private String userId;
    private String deviceId;
    
    @Column(name="INT_USER_ID")
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    @Column(name="DEVICE_ID")
    public String getDeviceId() {
        return deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    
    
}
