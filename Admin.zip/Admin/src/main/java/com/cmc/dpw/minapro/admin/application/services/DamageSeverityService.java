package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DamageSeverityDAO;
import com.cmc.dpw.minapro.admin.application.dto.DamageSeverityDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageSeverity;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * DamageSeverity Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class DamageSeverityService {

    @Autowired
    private DamageSeverityDAO damageSeverityDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageSeverityService.class);

    /**
     * This method is used to get DamageSeverity List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<DamageSeverity> getDamageSeverityList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  DamageSeverity service's getDamageSeverityList");
        damageSeverityDAO.setClazz(DamageSeverity.class);
        return damageSeverityDAO.findAll();

    }

    /**
     * This method is used to search DamageSeverity List
     * @return Map<String, Object> containing the search DamageSeverity data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDamageSeverityList(String damageSeverityCode, String description, int start,
            int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageSeverity service's searchDamageSeverityList method");

        damageSeverityDAO.setClazz(DamageSeverity.class);

        String[] requestParameters = { damageSeverityCode, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In DamageSeverity service searchDamageSeveritys with damageSeverityCode: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageSeverity service's searchDamageSeverityList method");
        return damageSeverityDAO.searchDamageSeveritys(damageSeverityCode, description, start, limit);

    }

    /**
     * This method is used to create DamageSeverity
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageSeverity> containing the created DamageSeverity data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGESEVERITY_MASTER")
    public List<DamageSeverity> create(Object data, Principal principal) throws ExistingRecordException {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageSeverity service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageSeverity service's  create : {} ", data);
       
        List<DamageSeverity> newDamageSeverities = new ArrayList<DamageSeverity>();

        List<DamageSeverity> list = util.getEntitiesFromDto(data, DamageSeverityDTO.class, DamageSeverity.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (DamageSeverity damageSeverity : list) {
            Date currentDate = new Date();

            damageSeverity.setCreatedDateTime(currentDate);
            damageSeverity.setLastUpdatedDateTime(currentDate);
            damageSeverity.setCreatedBy(userId.toString());
            damageSeverity.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageSeverityCode property in damageSeverity service create : {}",
                    damageSeverity.getDamageSeverityCode());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageSeverity DAO findOne");

            DamageSeverity alreadyDamageSeverity = damageSeverityDAO.findOne(damageSeverity.getDamageSeverityCode());

            if (alreadyDamageSeverity == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageSeverity DAO create");
                newDamageSeverities.add(damageSeverityDAO.create(damageSeverity));
            } else {
                char isDeleted = alreadyDamageSeverity.getIsDeleted();

                if (isDeleted == 'Y') {
                    damageSeverity.setVersion(alreadyDamageSeverity.getVersion());
                    damageSeverity.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageSeverity DAO update");
                    newDamageSeverities.add(damageSeverityDAO.update(damageSeverity));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null  
            }
         // end of for loop
        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageSeverity service's create method");
        return newDamageSeverities;
    }

    /**
     * This method is used to update DamageSeverity
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageSeverity> containing the updated DamageSeverity data
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGESEVERITY_MASTER")
    public List<DamageSeverity> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageSeverity service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageSeverity  service's  update : {} ", data);
        List<DamageSeverity> returnDamageSeveritys = new ArrayList<DamageSeverity>();

        List<DamageSeverity> updatedDamageSeveritys = util.getEntitiesFromDto(data, DamageSeverityDTO.class, DamageSeverity.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageSeverity damageSeverity : updatedDamageSeveritys) {
            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageSeverityCode property in damageSeverity service update : {}",
                    damageSeverity.getDamageSeverityCode());
            damageSeverity.setLastUpdatedDateTime(currentDate);
            damageSeverity.setLastUpdatedBy(userId.toString());
            returnDamageSeveritys.add(damageSeverityDAO.update(damageSeverity));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageSeverity service's update method");
        return returnDamageSeveritys;
    }

    /**
     * This method is used to delete DamageSeverity
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGESEVERITY_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageSeverity service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In damageSeverity's service delete : {} ", data);

        List<DamageSeverity> deletedDamageSeveritys = util.getEntitiesFromDto(data, DamageSeverityDTO.class, DamageSeverity.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageSeverity damageSeverity : deletedDamageSeveritys) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageSeverityCode property in damageSeverity service delete : {}",
                    damageSeverity.getDamageSeverityCode());
            damageSeverity.setLastUpdatedDateTime(currentDate);
            damageSeverity.setLastUpdatedBy(userId.toString());
            damageSeverity.setIsDeleted('Y');
            damageSeverityDAO.delete(damageSeverity);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageSeverity service's delete method");
    }

}
