package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.RoleDAO;
import com.cmc.dpw.minapro.admin.application.dto.RoleDTO;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Role Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class RoleService {

    @Autowired
    private RoleDAO roleDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleService.class);

    /**
     * This method is used to get Role List
     * @return  List<T>
     */
    @Transactional(readOnly = true)
    public List<Role> getRoleList() {
        
        LOGGER.debug("Got the request to Role service");
        roleDAO.setClazz(Role.class);
        return roleDAO.findAll();
    }

    /**
     * This method is used to search Role List
     * @return Map<String, Object> containing the search Role data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchRoleList(String userName, String roleName, int start, int limit) {
       
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Got the request to view Roles...Inside Role service");
        roleDAO.setClazz(Role.class);

        String[] requestParameters = { userName, roleName };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchRoles with userName: {} , roleName : {}", requestParameters);

        return roleDAO.searchRoles(userName, roleName, start, limit);

    }

    /**
     * This method is used to create Role
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Role> containing created Role data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_GRPDTLS_AM")
    public List<Role> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"data in role service create : {} ", data);
        List<Role> newRoles = new ArrayList<Role>();

        List<Role> list = util.getEntitiesFromDto(data, RoleDTO.class,Role.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        for (Role role : list) {

            Date currentDate = new Date();

            role.setCreatedDateTime(currentDate);
            role.setLastUpdatedDateTime(currentDate);
            role.setCreatedBy(userId.toString());
            role.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Role Id property in role service's create : {}", role.getIntUserGroupId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling role DAO findOne");

            Role alreadyRole = roleDAO.findOne(role.getIntUserGroupId());

            if (alreadyRole == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling role DAO create");
                newRoles.add(roleDAO.create(role));
            } else {
                char isDeleted = alreadyRole.getIsDeleted();

                if (isDeleted == 'Y') {
                    role.setVersion(alreadyRole.getVersion());
                    role.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling role DAO update");
                    newRoles.add(roleDAO.update(role));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Role service's create method");
        return newRoles;
    }

    /**
     * This method is used to update Role
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Role> containing updated Role data
     */
    @Transactional
    @Manipulate(table = "MP_GRPDTLS_AM")
    public List<Role> update(Object data, Principal principal) {
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"data in role service update : {} ", data);
        List<Role> returnRoles = new ArrayList<Role>();

        List<Role> updatedRoles = util.getEntitiesFromDto(data, RoleDTO.class,Role.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Role role : updatedRoles) {

            Date currentDate = new Date();

            role.setLastUpdatedDateTime(currentDate);
            role.setLastUpdatedBy(userId.toString());
            returnRoles.add(roleDAO.update(role));
        }

        return returnRoles;
    }

    /**
     * This method is used to delete Role
     * @param data The json data coming from the UI
     */
    @Transactional
    @Manipulate(table = "MP_GRPDTLS_AM")
    public void delete(Object data, Principal principal) {
        
        LOGGER.debug("data in role service delete : {} ", data);

        List<Role> deletedRoles = util.getEntitiesFromDto(data, RoleDTO.class,Role.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Role role : deletedRoles) {

            Date currentDate = new Date();

            role.setLastUpdatedDateTime(currentDate);
            role.setLastUpdatedBy(userId.toString());
            role.setIsDeleted('Y');
            roleDAO.delete(role);
        }
    }
    
}
