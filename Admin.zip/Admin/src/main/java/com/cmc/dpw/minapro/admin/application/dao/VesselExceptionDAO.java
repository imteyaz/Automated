package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.VesselExceptionDTO;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselExceptionEntity;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * VesselExceptionEntity DAO class.
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class VesselExceptionDAO extends GenericDAO<VesselExceptionEntity> {

    @Autowired
    private Util util;
    @Autowired
    private VesselDAO vesselDAO;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselExceptionDAO.class);

    /**
     * This method is used to search VesselExceptions
     * 
     * @param vesselExceptionIdVal
     * @param vesselNameVal
     * @param rotationVal
     * @param exceptionTypeVal
     * @param vesselNoVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchVesselExceptions(String vesselExceptionIdVal, String vesselNameVal,
            String rotationVal, String exceptionTypeVal, String vesselNoVal, Boolean onlyCountRequired, int start,
            int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Entering VesselExceptionEntity DAO's searchVesselExceptions method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(VesselExceptionEntity.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        Util.addIntgerRestrictions(searchCriteria, "vesselExceptionId", vesselExceptionIdVal);
        Util.addIntgerRestrictions(searchCriteria, "rotation", rotationVal);
        Util.addIntgerRestrictions(searchCriteria, "vesselNo", vesselNameVal);
        Util.addRestrictions(searchCriteria, "exceptionType", exceptionTypeVal, true);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();
        String totalRecords = count.toString();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "count of records matched with given search criteria : {}",
                count);

        searchCriteria.setProjection(null);
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<VesselExceptionEntity> searchVesselExceptions = null;

        if (!onlyCountRequired) {
            searchVesselExceptions = (List<VesselExceptionEntity>) searchCriteria.list();

            for (VesselExceptionEntity vesselException : searchVesselExceptions) {

                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "vesselException Id  : {}",
                        vesselException.getVesselExceptionId());

                List<Vessel> vesselsList = vesselDAO.findByPropertyValue(Vessel.class, "vesselNo",
                        vesselException.getVesselNo(), false);
                Vessel currentVessel = vesselsList.get(0);
                String vesselName = currentVessel.getVesselName();
                String vesselCode = currentVessel.getVesselCode();

                String combinedNameCode = vesselCode + "    -     " + vesselName;
                vesselException.setVesselName(combinedNameCode);

            }
        }

        List<VesselExceptionDTO> searchVesselExceptionsDtoList = util.map(searchVesselExceptions,
                VesselExceptionDTO.class);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "data from DB: {}", searchVesselExceptionsDtoList);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchVesselExceptionsDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "exiting vesselExceptionDAO's searchVesselExceptions method ");
        return resultMap;
    }

    public boolean deleteByRotationNo(Integer rotationNumber) {

        Session session = getCurrentSession();

        String delExceptionSql = "DELETE FROM MP_VESSEL_EXCEPTIONS WHERE CREATED_BY = 'Admin App OPUS Scheduler' AND ROTATION_NO =  "
                + rotationNumber;

        SQLQuery delExceptionquery = session.createSQLQuery(delExceptionSql);

        delExceptionquery.executeUpdate();

        return true;
    }

}
