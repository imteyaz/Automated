package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.entities.TemplateHeader;
import com.cmc.dpw.minapro.admin.domain.utils.Util;


/**
 * VesselTemplate DAO class.
 * 
 */
@Repository
public class VesselTemplateHeaderDAO extends GenericDAO<TemplateHeader>{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselTemplateHeaderDAO.class) ;
    
    public Map<String, Object> searchVesselTemplatesHeaders(String vesselTemplateHeaderIdVal,String vesselTemplateHeaderNameVal,String vesselTemplateHeaderTypeIdVal,int start,int limit ){
        
        LOGGER.info("############ Entering VesselTemplateHeader DAO's searchVesselTemplatesHeaders method");
        
        Map<String,Object> resultMap = new HashMap<String,Object>();
        
         Session session = getCurrentSession();
         int i =0 ;
         
        Criteria searchCriteria = session.createCriteria(TemplateHeader.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        
        String[] searchParameters={vesselTemplateHeaderIdVal,vesselTemplateHeaderNameVal,vesselTemplateHeaderTypeIdVal};
        LOGGER.debug("*********** Processing searchVesselTemplatesHeaders in VesselTemplateHeader DAO with vesselTemplateHeaderId: {} , vesselTemplateHeaderName : {} , vesselTemplateHeaderTypeId : {} ", searchParameters);
        
        searchCriteria.add(Restrictions.eq("isDeleted", 'N')) ;
        
      i =  Util.addRestrictions(searchCriteria, "headerId", vesselTemplateHeaderIdVal, false,i);
      i =  Util.addRestrictions(searchCriteria, "type", vesselTemplateHeaderTypeIdVal, false,i);
         
        Criteria totalCriteria = searchCriteria ;
        
        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count=(Long)totalCriteria.uniqueResult();
        
        LOGGER.debug("******count of records matched with given search criteria : {}" ,count);
        
        searchCriteria.setProjection(null);
         
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        
        List<TemplateHeader> searchVesselTemplatesHeaders =  null ;
        
        StringBuilder sql = new StringBuilder("select distinct u from TemplateHeader u where u.isDeleted = 'N' ") ; 
              
              if(vesselTemplateHeaderIdVal !=null && !vesselTemplateHeaderIdVal.isEmpty()){
                  sql.append(" and lower(u.headerId) like lower('%" + vesselTemplateHeaderIdVal + "%')") ;
              }
              
              if(vesselTemplateHeaderTypeIdVal !=null && !vesselTemplateHeaderTypeIdVal.isEmpty()){
                  sql.append(" and lower(u.type) like lower('%" + vesselTemplateHeaderTypeIdVal + "%')") ;
              }
              
              Query query = session.createQuery(sql.toString());
              query.setMaxResults(limit);
              query.setFirstResult(start);
              
            
            List<TemplateHeader> templateHeaderList = query.list();
            LOGGER.debug("templateHeadersList using HQL");
            
            searchVesselTemplatesHeaders = templateHeaderList ;
            String totalRecords = count.toString() ;
        
            LOGGER.debug("******* data from DB: {}" ,searchVesselTemplatesHeaders);
            LOGGER.debug("******* total count of records matched with given search criteria  : {}" ,totalRecords); 
            
             resultMap.put("data",searchVesselTemplatesHeaders);
             resultMap.put("totalCount",totalRecords) ;
            
             for(TemplateHeader templateHeader: searchVesselTemplatesHeaders){
                 LOGGER.debug(" ********* current templateHeader's Id  : {}" ,templateHeader.getHeaderId()); 
             }
             
             LOGGER.debug("********* exiting vesselTemplateHeaderDAO's searchVesselTemplatesHeaders method ") ;
             return resultMap ;
           }
    
}
