package com.cmc.dpw.minapro.admin.application.common;

public class MessageConstants {
    
    public static final String APP_VERSION = "?ver=2.4";
    
    public static final String APP_VERSION_KEY = "appVersion";

    public static final String FAILURE_STATUS = "failure";
    
    public static final String EXCLUDE_DTO = "com.cmc.dpw.minapro.admin.application.dto.UserDTO";
    
    public static final String PASSPHRASE = "2cmc0MERGES1tcs5";
    
    public static final String USER_NOT_FOUND = "User was not found!";

    public static final String EXISTING_RECORD_EXCEPTION_MESSAGE = " Record already exists. Please change the id and try again.";

    public static final String EXISTING_USERID_EXCEPTION_MESSAGE = "User with this User Id already exists";

    public static final String EXISTING_USERNAME_EXCEPTION_MESSAGE = "User with this UserName already exists";

    public static final String EXISTING_GROUPCODE_ERROR_MESSAGE = "The Group Code you entered already exists. Please try another Group Code";

    public static final String EXISTING_GROUPNAME_ERROR_MESSAGE = "The Group Name you entered already exists. Please try another Group Name";

    public static final String EXISTING_ROTATIONID_ERROR_MESSAGE = "The Vessel Code you entered already exists.";

    public static final String EXISTING_VESSELNAME_ERROR_MESSAGE = "The Vessel Name you entered already exists.";
    
    public static final String UNIQUE_ROTATION_TERMINAL_EXCEPTION_MESSAGE = " A record with the same combination of rotation number and terminal Id already exists .This combination should be unique.";

    public static final String WRONG_ROTATION_VESSELCODE_EXCEPTION_MESSAGE  = "Another record with the same Rotation No has been mapped to a different VesselCode. You can not map the same rotation(on different terminals) to different vessels." ;
    
    public static final String SUCCESS_KEY = "success";

    public static final String T2_ESB_COMMON_OUTQ = "T2_ESB_COMMON_OUTQ";

    public static final int HASH_LENGTH_THREE = 3;

    public static final int HASH_LENGTH_TWO = 2;

    public static final String ACCESSCODE_KEY = "accessCode";

    public static final String NAME_KEY = "name";

    public static final String CODE_KEY = "code";

    public static final String DATA_KEY = "data";

    public static final String TOTALCOUNT_KEY = "totalCount";

    public static final String MESSAGE_KEY = "message";

    public static final String ERROR_KEY = "error";

    public static final int ARRAY_TWO = 2;

    public static final String JSONVESSELDTO_KEY = "jsonVesselDTO";

    public static final String STATUS_KEY = "status";

    public static final String ITEMS_KEY = "items";

    public static final String TOTAL_KEY = "total";

    public static final String TOTALRECORDS_KEY = "totalRecords";

    public static final String ROLES_KEY = "roles";

    public static final int THOUSAND = 1000;

    public static final int ONE_TWENTY_EIGHT = 128;

    public static final int ARRAY_ONE = 1;

    public static final int ZERO = 0;

    public static final int EIGHT = 8;

    public static final int THIRITY_ONE = 31;

    public static final String ETADATE = "etaDate";

    public static final String EMPTY = "empty";

    public static final String ISDELETEDCOLUMN = "isDeleted";
 
    public static final String ERROR_INDICATOR = "!^!^!^!^";

    public static final String WARN_INDICATOR = "^^^^^^^";

    public static final String DEBUG_INDICATOR = "*********";

    public static final String INFO_INDICATOR = "######";

    public static final String PK_VESSELNO = "pk.vesselNo";

    public static final String CREATE_ROTATIONCONTROL = "Error trying to create Rotation : ";
    
    public static final String UPDATE_ROTATIONCONTROL = "Error trying to update Rotation : ";

    public static final String DATA_LOGGER =  "Data : {}"; 
    
    public static final String ENTITY_PACKAGE_NAME = "com.cmc.dpw.minapro.admin.application.entities.";
    
    public static final String VESSEL_CREATE_ERROR_MESSAGE =  "Error trying to create Vessel :{}" ;
    
    public static final String FOREIGN_KEYS_ERROR =  "Error retrieving ForeignKeys from database" ;

    public static final String CREATE_ERROR_MESSAGE =  "Error trying to create " ;
    
    public static final String UPDATE_ERROR_MESSAGE =  "Error trying to update " ;
    
    public static final String DELETE_ERROR_MESSAGE =  "Error trying to delete " ;
    
    public static final String BIRTH_EVENT =  "Birth" ;
    
    public static final String EXISTING_RECORD_EXCEPTION =  "ExistingRecordException -->> :{}" ;
    
    public static final String DATE_TIME_FORMAT =  "dd/MM/yyyy/HH:mm" ;
    
    public static final String OPUS_DATE_TIME_FORMAT =  "yyyyMMdd/HHmmss" ;
    
    public static final String INSERT_TYPE =  "insert" ;
    
    public static final String USER_ENTITY =  "user" ;

    public static final String REQUEST_FAILED_MESSAGE = "Somethimg went wrong : Unable to save changes to ";
    
    public static final String CHAR_SET = "UTF-8" ;
    
    public static final String BAD_CREDENTIALS_MESSAGE = "Invalid Username/Password combination." ;
    
    public static final String LOGGEDIN_UPDATE_FAIL_MESSAGE = " : The user you are trying to update is currently logged in - Please force logout the user and try updating again." ;

    public static final String UPDATE_TYPE = "update";

    public static final String EXISTING_TEMPLATEDETAILS_RECORD_EXCEPTION_MESSAGE = " already exists. Please make this combination unique and try again. ";

    public static final String INVALID_DEFAULT_FOR_TYPE_MESSAGE = " There can be only one default template for a particular type.Please make sure you change the existing default template to non default first before trying to save again.";
    
    public static final String DUPLICATE_QC_POW_MESSAGE_START = " There can be only one QC mapped to a particular POW. </br></br>";
    
    public static final String DUPLICATE_QC_POW_MESSAGE_END = " </br></br>Please change the pow and try again !";

    public static final String DUPLICATE_DEVICE_EQUIPMENT_MESSAGE_START = " There can be only one device mapped to a particular equipment. </br></br>";

    public static final String DUPLICATE_DEVICE_EQUIPMENT_MESSAGE_END = " </br></br>Please change the Equipment ID and try again !";

    public static final String DEVICE_IN_USE_MESSAGE_START = " Device which is currently in use can not be updated or deleted. </br></br>";

    public static final String DEVICE_IN_USE_MESSAGE_END = " </br></br>Please wait for the user until he logs off or force logoff the user and try again !";

    public static final String EQUIPMENT_IN_USE_MESSAGE_START = " An Equipment which is currently in use can not be updated or deleted. </br></br>";

    public static final String EQUIPMENT_IN_USE_MESSAGE_END = " </br></br>Please wait for the user until he logs off or force logoff the user and try again !!!";

    public static final String RAISEDDATE = "raisedDateTime";

    public static final String CREATE_ALERTREMARKS = "Error trying to add Remarks : ";
    
    public static final String DEFAULT_BERTH_NO = "UNDEFINED_BERTH_NO";
    
    private  MessageConstants(){
        super();
    }
    
   

   

}