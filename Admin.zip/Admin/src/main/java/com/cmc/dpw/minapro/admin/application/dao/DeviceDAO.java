package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.DeviceDTO;
import com.cmc.dpw.minapro.admin.application.entities.Device;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * DeviceDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class DeviceDAO extends GenericDAO<Device> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceDAO.class);
/**
 * This method is used to search Devices
 * @param deviceIdVal
 * @param ipAddressVal
 * @param equipmentIdVal
 * @param makeVal
 * @param modelVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchDevices(String deviceIdVal, String ipAddressVal, String equipmentIdVal,
            String makeVal, String modelVal, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Device DAO's searchDevices method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        
        Criteria searchCriteria = session.createCriteria(Device.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { deviceIdVal, ipAddressVal, equipmentIdVal, makeVal, modelVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchDevices with deviceId: {} , ipAddress : {} , equipmentId : {} , make : {} , model: {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        Util.addRestrictions(searchCriteria, "deviceId", deviceIdVal, false);
        Util.addRestrictions(searchCriteria, "ipAddress", ipAddressVal, false);
        Util.addRestrictions(searchCriteria, "equipmentId", equipmentIdVal, false);
        Util.addRestrictions(searchCriteria, "make", makeVal, false);
        Util.addRestrictions(searchCriteria, "model", modelVal, false);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("****** Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Device> searchDevices = (List<Device>) searchCriteria.list();
        List<DeviceDTO> searchDevicesDtoList =  util.map(searchDevices, DeviceDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data: {}", searchDevicesDtoList);
        LOGGER.debug("******* totalCount: {}", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchDevicesDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        for (Device device : searchDevices) {
            LOGGER.debug(" deviceId : {}", device.getDeviceId());

        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" exiting Device DAO's searchDevices method ");
        return resultMap;
    }
}
