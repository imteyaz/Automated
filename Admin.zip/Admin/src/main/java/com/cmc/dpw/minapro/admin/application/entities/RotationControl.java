package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * RotationControl POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "RotationControl")
@Table(name = "MP_ROTATION_CONTROL_MASTER")
public class RotationControl  extends Audit implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private Integer rotationControlId;
    private Integer rotationNumber;
    private Integer vesselNo;
    private String vesselCode;
    private String berthNo;
    private char status;
    private Date etaDate;
    private Date eta;
    private String terminalId;
    private String allEquipments;
    private String equipmentId;
    private Collection<Equipment> actualEquipments = new ArrayList<Equipment>();
    private Vessel actualVessel;
    private Integer errorCount; 
    private String voyageNo;
    private String berthSide;
    

    private Boolean isActiveModified;
    private Boolean isQCModified;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MP_ROTATION_QC_MAPPING", joinColumns = @JoinColumn(name = "ROTATION_CONTROL_ID"), inverseJoinColumns = @JoinColumn(name = "EQUIPMENT_ID"))
    public Collection<Equipment> getActualEquipments() {
        return actualEquipments;
    }

    public void setActualEquipments(Collection<Equipment> actualEquipments) {
        this.actualEquipments = actualEquipments;
    }

    @Transient
    public String getAllEquipments() {
        return allEquipments;
    }

    public void setAllEquipments(String allEquipments) {
        this.allEquipments = allEquipments;
    }

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "VESSEL_NO")
    /*
     * @JoinTable(name="MP_ROTATION_QC_MAPPING", joinColumns=@JoinColumn(name="VESSEL_NO"),
     * inverseJoinColumns=@JoinColumn(name="INT_VSL_NO") )
     */
    public Vessel getActualVessel() {
        return actualVessel;
    }

    public void setActualVessel(Vessel actualVessel) {
        this.actualVessel = actualVessel;
    }

    @Transient
    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    @Column(name = "ROTATION_NO", nullable = false)
    public Integer getRotationNumber() {
        return rotationNumber;
    }

    public void setRotationNumber(Integer rotationNumber) {
        this.rotationNumber = rotationNumber;
    }

    // @Column(name="VESSEL_NO", nullable=false)
    @Transient
    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNumber) {
        this.vesselNo = vesselNumber;
    }

    @Transient
    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    @Column(name = "ETA", nullable = false)
    public Date getEtaDate() {
        return etaDate;
    }

    public void setEtaDate(Date etaDate) {
        this.etaDate = etaDate;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rotationSequence")
    @SequenceGenerator(name = "rotationSequence", sequenceName = "MP_ROTATION_CONTROL_SEQ", allocationSize = 1, initialValue = 30)
    @Column(name = "ROTATION_CONTROL_ID", nullable = false)
    public Integer getRotationControlId() {
        return rotationControlId;
    }

    public void setRotationControlId(Integer rotationControlId) {
        this.rotationControlId = rotationControlId;
    }

    @Column(name = "BERTH_NO", nullable = false)
    public String getBerthNo() {
        return berthNo;
    }

    public void setBerthNo(String berthNo) {
        this.berthNo = berthNo;
    }

    @Column(name = "STATUS", nullable = false)
    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    
    @Transient
    public Boolean getIsActiveModified() {
        return isActiveModified;
    }

    public void setIsActiveModified(Boolean isActiveModified) {
        this.isActiveModified = isActiveModified;
    }

    @Transient
    public Boolean getIsQCModified() {
        return isQCModified;
    }

    public void setIsQCModified(Boolean isQCModified) {
        this.isQCModified = isQCModified;
    }

    @Transient
    public Date getEta() {
        return eta;
    }

    public void setEta(Date eta) {
        this.eta = eta;
    }

    @Transient
    public Integer getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Integer errorCount) {
        this.errorCount = errorCount;
    }

    @Column(name = "VOYAGE_NO")
    public String getVoyageNo() {
        return voyageNo;
    }

    public void setVoyageNo(String voyageNo) {
        this.voyageNo = voyageNo;
    }

    @Column(name = "BERTH_SIDE")
    public String getBerthSide() {
        return berthSide;
    }

    public void setBerthSide(String berthSide) {
        this.berthSide = berthSide;
    }
    
    
    

}
