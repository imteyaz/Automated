package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.dto.NumSrsHeaderDTO;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsDetails;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsHeader;
import com.cmc.dpw.minapro.admin.domain.utils.Util;


/**
 * NumSrsHeader DAO class.
 * 
 */
@Repository
public class NumSrsHeaderDAO extends GenericDAO<NumSrsHeader>{
    
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(NumSrsHeaderDAO.class) ;
    
    public Map<String, Object> searchNumSrsHeaders(String numSrsHeaderIdVal,String numSrsHeaderNameVal,String numSrsHeaderTypeIdVal,int start,int limit ){
         
        LOGGER.info("############ Entering NumSrsHeader DAO's searchNumSrsHeaders method");
        
        Map<String,Object> resultMap = new HashMap<String,Object>();
        
         Session session = getCurrentSession();
         int i =0 ;
         
        Criteria searchCriteria = session.createCriteria(NumSrsHeader.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        
        String[] searchParameters={numSrsHeaderIdVal,numSrsHeaderNameVal,numSrsHeaderTypeIdVal};
        LOGGER.debug("*********** Processing searchNumSrsHeaders in NumSrsHeader DAO with numSrsHeaderId: {} , numSrsHeaderName : {} , numSrsHeaderTypeId : {} ", searchParameters);
        
        searchCriteria.add(Restrictions.eq("isDeleted", 'N')) ;
        
        Util.addRestrictions(searchCriteria, "numSrsId", numSrsHeaderIdVal, false);
        Util.addRestrictions(searchCriteria, "numsrsType", numSrsHeaderTypeIdVal, false);
         
        Criteria totalCriteria = searchCriteria ;
        
        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count=(Long)totalCriteria.uniqueResult();
        
        LOGGER.debug("******count of records matched with given search criteria : {}" ,count);
        
        searchCriteria.setProjection(null);
         
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        
        List<NumSrsHeader> searchNumSrsHeaders =  null ;
         
         if(i==0) {
              Query query = session.createQuery("select distinct u from NumSrsHeader u left join fetch u.actualNumSeriesDetails");
              query.setMaxResults(limit);
              query.setFirstResult(start);
              
            
            List<NumSrsHeader> numSrsHeadersList = query.list();
            
             LOGGER.debug("numSrsHeadersList using HQL");
            
            
            searchNumSrsHeaders = numSrsHeadersList ;
         }else{
             LOGGER.debug("numSrsHeader using searchCriteria");
             searchNumSrsHeaders  = (List<NumSrsHeader>)searchCriteria.list();
         }
         
        
        
         for(NumSrsHeader numSrsHeader: searchNumSrsHeaders){
             
             LOGGER.debug(" ********* numSrsHeader Id  : {}" ,numSrsHeader.getNumSrsId()); 
             
             List<NumSrsDetails> currentNumSrsDetailsList = (List<NumSrsDetails>) numSrsHeader.getActualNumSeriesDetails();
             
             
             for(NumSrsDetails currentNumSrsDetails: currentNumSrsDetailsList){
                 
                 Integer seqNo =  currentNumSrsDetails.getPk().getSeqNo() ;
                 
                 currentNumSrsDetails.setSeqNo(seqNo);
                 
             }
         }
        
        List<NumSrsHeaderDTO> searchNumSrsDtoList =  util.map(searchNumSrsHeaders, NumSrsHeaderDTO.class);
        String totalRecords = count.toString() ;
        
        LOGGER.debug("******* data from DB: {}" ,searchNumSrsDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}" ,totalRecords); 
        
         resultMap.put("data",searchNumSrsDtoList);
         resultMap.put("totalCount",totalRecords) ;
         
        
         LOGGER.debug("********* exiting numSrsHeaderDAO's searchNumSrsHeaders method ") ;
         return resultMap ;
       }
    
}
