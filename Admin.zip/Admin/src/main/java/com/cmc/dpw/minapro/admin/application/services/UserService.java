package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.CommonsDAO;
import com.cmc.dpw.minapro.admin.application.dao.RoleDAO;
import com.cmc.dpw.minapro.admin.application.dao.UserDAO;
import com.cmc.dpw.minapro.admin.application.dto.MenuItem;
import com.cmc.dpw.minapro.admin.application.dto.RolesCheckBoxDTO;
import com.cmc.dpw.minapro.admin.application.dto.UserDTO;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.exceptions.LoggedInUserException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * User Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class UserService {

    @Autowired
    private CommonsDAO commonsDAO;
    @Autowired
    private UserDAO userDAO;
    @Autowired
    private RoleDAO roleDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

    /**
     * This method is used to get User List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<User> getUserList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->getUserList-->UserService ");
        userDAO.setClazz(User.class);
        return userDAO.findAll();
    }

    /**
     * This method is used to search User List
     *  @return Map<String, Object> containing the search User data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchUserList(String userId, String userName, String firstName, String lastName,
            String userDescription, String accountStatus, String roles, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering User service's searchUserList method");
        userDAO.setClazz(User.class);

        String[] requestParameters = { userName, firstName, lastName };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting User service's searchUserList method ");

        return userDAO.searchUsers(userId, userName, firstName, lastName, userDescription, accountStatus, roles, start,
                limit);

    }

    /**
     * This method is used to create User
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<User> containing created User data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_USERDTLS_AM")
    public List<User> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->create-->UserService ");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , data);
        userDAO.setClazz(User.class);
        Collection<Role> actualRoles = null;
        List<User> newUsers = new ArrayList<User>();
        List<User> list = util.getEntitiesFromDto(data, UserDTO.class,User.class);

        Integer loggedInUserId = util.getUserIdFromPrincipal(principal);

        for (User user : list) {
            Integer userId = user.getUserId();
            User alreadyUser = userDAO.findOne(userId);

            if (alreadyUser == null) {

                String enteredUserName = user.getUserName().toUpperCase();
                User userHavingSameUserName = userDAO.getUserByUsername(enteredUserName);

                if (userHavingSameUserName != null) {
                    throw new ExistingRecordException(MessageConstants.EXISTING_USERNAME_EXCEPTION_MESSAGE);
                } else {

                    Date currentDate = new Date();
                    user.setCreatedDateTime(currentDate);
                    user.setLastUpdatedDateTime(currentDate);
                    user.setCreatedBy(loggedInUserId.toString());
                    user.setLastUpdatedBy(loggedInUserId.toString());
                    user.setLoginStatus("N");
                    user.setUserName(enteredUserName);

                    actualRoles = new ArrayList<Role>();
                    List rolesList = (List) user.getRoles();

                    for (int i = 0; i < rolesList.size(); i++) {

                        int roleID = Integer.parseInt((String) rolesList.get(i));
                        Role role = roleDAO.findOne(roleID);

                        actualRoles.add(role);
                    }
                    user.setActualRoles(actualRoles);

                    LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering-->create-->UserService");
                    newUsers.add(userDAO.create(user));
                }

            } else {

                throw new ExistingRecordException(MessageConstants.EXISTING_USERID_EXCEPTION_MESSAGE);
            }

            // end of else - entity not null

        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting-->create-->UserService ");
        return newUsers;
    }

    /**
     * This method is used to update User 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<User> containing updated Unit data
     * @throws LoggedInUserException 
     */
    @Transactional
    @Manipulate(table = "MP_USERDTLS_AM")
    public List<User> update(Object data, Principal principal) throws LoggedInUserException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->update-->UserService ");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , data);
        List<User> returnUsers = new ArrayList<User>();
        Collection<Role> actualRoles = null;
        
        List<User> updatedUsers = util.getEntitiesFromDto(data, UserDTO.class,User.class);
        Integer loggedInUserId = util.getUserIdFromPrincipal(principal);

        for (User user : updatedUsers) {

            actualRoles = new ArrayList<Role>();

            List rolesList = (List) user.getRoles();
            for (int i = 0; i < rolesList.size(); i++) {

                int roleID = Integer.parseInt((String) rolesList.get(i));
                Role role = roleDAO.findOne(roleID);

                actualRoles.add(role);
            }
            Integer userId = user.getUserId();
            User userFromDB = findUserByUserID(userId);
            
           if("Y".equalsIgnoreCase(userFromDB.getLoginStatus()) ){
               throw new LoggedInUserException(MessageConstants.LOGGEDIN_UPDATE_FAIL_MESSAGE);
           }

            userFromDB.setUserName(user.getUserName().toUpperCase());
            userFromDB.setFirstName(user.getFirstName());
            userFromDB.setLastName(user.getLastName());
            userFromDB.setUserDescription(user.getUserDescription());
            userFromDB.setAccountStatus(user.getAccountStatus());
            userFromDB.setTelephoneNo(user.getTelephoneNo());
            userFromDB.setMobileNo(user.getMobileNo());
            userFromDB.setFaxNo(user.getFaxNo());
            userFromDB.setEmailId(user.getEmailId());
            userFromDB.setDefaultLanguage(user.getDefaultLanguage());
            userFromDB.setPassword(user.getPassword());
            userFromDB.setIv(user.getIv());
            userFromDB.setSalt(user.getSalt());
            userFromDB.setActualRoles(actualRoles);

            Date currentDate = new Date();
            userFromDB.setLastUpdatedDateTime(currentDate);
            userFromDB.setLastUpdatedBy(loggedInUserId.toString());

            returnUsers.add(userDAO.update(userFromDB));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting-->update-->UserService ");
        return returnUsers;
    }

    /**
     * This method is used to delete User
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_USERDTLS_AM")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start-->delete-->UserService ");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , data);

        List<User> deletedUsers = util.getEntitiesFromDto(data, UserDTO.class,User.class);
        Integer userId = util.getUserIdFromPrincipal(principal) ;
        for (User user : deletedUsers) {
            user.setLastUpdatedBy(userId.toString());
            userDAO.delete(user);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting-->delete-->UserService ");
    }
    /**
     * This method is used to update User
     * @param user
     * @return Boolean
     */
    @Transactional
    public boolean updateUser(User user) {
        
        User updatedUser = userDAO.update(user);
        Boolean success = null;
        if (updatedUser != null) {
            success = true;
        } else {
            success = false;
        }
        return success;
    }

    /**
     * This method is used to prepareDynamicMenu
     * @param userId
     * @return CommonsDAO
     * 
     */
    @Transactional
    public List<MenuItem> prepareDynamicMenu(String userId) throws SQLException {

        return commonsDAO.createMenuList(userId);
    }

    @Transactional
    public User getUserByUsername(String username) {
        return userDAO.getUserByUsername(username);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public User findUserByUserID(Integer userId) {
        return userDAO.findOne(userId);
    }

  
    /**
     * This method is used to get Roles
     * @return resultMap
     */
    @Transactional
    public Map<String, Object> getRoles() {
        roleDAO.setClazz(Role.class);
        List<Role> rolesList = roleDAO.findAll();
        List<RolesCheckBoxDTO> rolesCBList = new ArrayList<RolesCheckBoxDTO>();

        for (Role r : rolesList) {

            String grpId = (Integer.valueOf(r.getIntUserGroupId())).toString();

            RolesCheckBoxDTO roleCB = new RolesCheckBoxDTO();
            roleCB.setBoxLabel(r.getUserGroupName());
            roleCB.setInputValue(grpId);
            roleCB.setName("roles");

            rolesCBList.add(roleCB);
        }

        Map<String, Object> resultMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        resultMap.put(MessageConstants.DATA_KEY, rolesCBList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, rolesCBList.size());
        resultMap.put(MessageConstants.SUCCESS_KEY, true);
        return resultMap;
    }

}
