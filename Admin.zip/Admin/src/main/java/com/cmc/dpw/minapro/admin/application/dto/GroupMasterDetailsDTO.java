package com.cmc.dpw.minapro.admin.application.dto;

import java.util.List;

public class GroupMasterDetailsDTO {

    private List<GroupDTO> groupList;
    private List<GenericGroupAssociationDTO> groupUserList;
    private List<GenericGroupAssociationDTO> groupFunctionList;
    private List<GenericGroupAssociationDTO> removedList;
    private Integer result;
    private String action;
    private String copyGroupId;
    private String serviceType;

    public List<GroupDTO> getGroupList() {
        return groupList;
    }

    public void setGroupList(List<GroupDTO> groupList) {
        this.groupList = groupList;
    }

    public List<GenericGroupAssociationDTO> getGroupUserList() {
        return groupUserList;
    }

    public void setGroupUserList(List<GenericGroupAssociationDTO> groupUserList) {
        this.groupUserList = groupUserList;
    }

    public List<GenericGroupAssociationDTO> getGroupFunctionList() {
        return groupFunctionList;
    }

    public void setGroupFunctionList(List<GenericGroupAssociationDTO> groupFunctionList) {
        this.groupFunctionList = groupFunctionList;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getCopyGroupId() {
        return copyGroupId;
    }

    public void setCopyGroupId(String copyGroupId) {
        this.copyGroupId = copyGroupId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public List<GenericGroupAssociationDTO> getRemovedList() {
        return removedList;
    }

    public void setRemovedList(List<GenericGroupAssociationDTO> removedList) {
        this.removedList = removedList;
    }

}
