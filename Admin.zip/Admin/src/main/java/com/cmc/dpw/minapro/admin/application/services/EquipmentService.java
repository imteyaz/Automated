package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DeviceDAO;
import com.cmc.dpw.minapro.admin.application.dao.EquipmentDAO;
import com.cmc.dpw.minapro.admin.application.dao.UserDeviceMappingDAO;
import com.cmc.dpw.minapro.admin.application.dto.EquipmentDTO;
import com.cmc.dpw.minapro.admin.application.entities.Device;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.entities.UserDeviceMapping;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Equipment Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class EquipmentService {

    @Autowired
    private EquipmentDAO equipmentDAO;
    @Autowired
    private UserDeviceMappingDAO userDeviceMappingDAO ;
    @Autowired
    private DeviceDAO deviceDao ;
    @Autowired
    private Util util;
   
    private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentService.class);

    /**
     * This method is used to read Equipment
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Equipment> getEquipmentList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Equipment service's getEquipmentList");
        equipmentDAO.setClazz(Equipment.class);
        return equipmentDAO.findAll();

    }

    /**
     * This method is used to read Equipment
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchEquipmentList(String equipmentId, String equipmentName, String make, String model,
            String equipmentTypeId, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Equipment service's searchEquipmentList method");
        equipmentDAO.setClazz(Equipment.class);

        String[] requestParameters = { equipmentId, equipmentName, make, model, equipmentTypeId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Equipment service searchEquipmentList  with equipmentId: {} , equipmentName : {}, make : {}, model : {}, equipmentTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Equipment service's searchEquipmentList method");

        return equipmentDAO.searchEquipments(equipmentId, equipmentName, make, model, equipmentTypeId, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Equipment> containing the created Equipment data
     * @throws ExistingRecordException
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_EQUIPMENT_MASTER")
    public List<Equipment> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Equipment service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  equipment service's  create : {} ", data);

        List<Equipment> newEquipments = new ArrayList<Equipment>();
        
        List<Equipment> list = util.getEntitiesFromDto(data, EquipmentDTO.class,Equipment.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Equipment equipment : list) {
            try {
                checkPowMapping(equipment);
            }catch (InvalidValueException e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR +"EquipmentService-->create-->InvalidValueException Catch Block :{}", e);
                throw new ExistingRecordException(e.getCustomErrorMessage()) ;
            }
            Date currentDate = new Date();
            equipment.setCreatedDateTime(currentDate);
            equipment.setLastUpdatedDateTime(currentDate);
            equipment.setCreatedBy(userId.toString());
            equipment.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Equipment Id property in equipment service's create : {}",
                    equipment.getEquipmentId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling equipment DAO findOne");

            Equipment alreadyEquipment = equipmentDAO.findOne(equipment.getEquipmentId());

            if (alreadyEquipment == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling equipment DAO create");
                newEquipments.add(equipmentDAO.create(equipment));
            } else {
                char isDeleted = alreadyEquipment.getIsDeleted();

                if (isDeleted == 'Y') {
                    equipment.setVersion(alreadyEquipment.getVersion());
                    equipment.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling equipment DAO update");
                    newEquipments.add(equipmentDAO.update(equipment));
                } else {
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Equipment service's create method");
        return newEquipments;
    }

    /**
     * This method is used to update Equipment
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Equipment> containing the updated Equipment datas
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_EQUIPMENT_MASTER")
    public List<Equipment> update(Object data, Principal principal) throws InvalidValueException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Equipment service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  equipment  service's  update : {} ", data);
        List<Equipment> returnEquipments = new ArrayList<Equipment>();

        List<Equipment> updatedEquipments = util.getEntitiesFromDto(data, EquipmentDTO.class,Equipment.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Equipment equipment : updatedEquipments) {
            checkPowMapping(equipment) ;
            checkEquipmentStatus(equipment);
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"equipmentId property in equipment service update : {}", equipment.getEquipmentId());
            equipment.setLastUpdatedDateTime(currentDate);
            equipment.setLastUpdatedBy(userId.toString());
            returnEquipments.add(equipmentDAO.update(equipment));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Equipment service's update method");

        return returnEquipments;
    }

    /**
     * This method is used to delete Equipment
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_EQUIPMENT_MASTER")
    public void delete(Object data, Principal principal) throws InvalidValueException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Equipment service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In equipment's service delete : {} ", data);
        
        List<Equipment> deletedEquipments = util.getEntitiesFromDto(data, EquipmentDTO.class,Equipment.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Equipment equipment : deletedEquipments) {
            checkEquipmentStatus(equipment);
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Equipment Id property in equipment service delete : {}",
                    equipment.getEquipmentId());
            equipment.setLastUpdatedDateTime(currentDate);
            equipment.setLastUpdatedBy(userId.toString());
            equipment.setIsDeleted('Y');
            equipmentDAO.delete(equipment);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Equipment service's delete method");
    }

    private Equipment checkPowMapping(Equipment equipment) throws InvalidValueException{
        
        Equipment duplicatePow = null ;
        List<Equipment>  duplicatePowList = equipmentDAO.findByPropertyValue(Equipment.class, "pow", equipment.getPow(), true);
        
        if(duplicatePowList!=null && !duplicatePowList.isEmpty()){
            duplicatePow = duplicatePowList.get(0);
            if(!duplicatePow.getEquipmentId().equalsIgnoreCase(equipment.getEquipmentId())){
                throw new InvalidValueException(MessageConstants.DUPLICATE_QC_POW_MESSAGE_START + duplicatePow.getEquipmentId() + " is already mapped to pow " + duplicatePow.getPow() + " !" + MessageConstants.DUPLICATE_QC_POW_MESSAGE_END);
            }
        }
        return duplicatePow ;
    }
    
    private boolean checkEquipmentStatus(Equipment equipment) throws InvalidValueException{
        
        List<Device> deviceListForEquipment = deviceDao.findByPropertyValue(Device.class, "equipmentId",equipment.getEquipmentId(), true);
        
        if(deviceListForEquipment!=null && !deviceListForEquipment.isEmpty()){
            Device device = deviceListForEquipment.get(0);
            UserDeviceMapping deviceInUse = null ;
            List<UserDeviceMapping>  deviceInUseList = userDeviceMappingDAO.findByPropertyValue(UserDeviceMapping.class, "pk.deviceId", device.getDeviceId(), true);
            
            if(deviceInUseList!=null && !deviceInUseList.isEmpty()){
                deviceInUse = deviceInUseList.get(0);
                throw new InvalidValueException(MessageConstants.EQUIPMENT_IN_USE_MESSAGE_START + "A User having user Id as " + deviceInUse.getPk().getUserId() + " is already logged on to Device Id  " + deviceInUse.getPk().getDeviceId() + " and this device Id is mapped to the equipment Id " + equipment.getEquipmentId() + MessageConstants.EQUIPMENT_IN_USE_MESSAGE_END);
            }
            
        }
        return true ;
        
 }

    @Transactional(readOnly = true)
    public List<Equipment> loadAllEquipments() {
        return equipmentDAO.loadAllEquipments();
         
    }
   
}
