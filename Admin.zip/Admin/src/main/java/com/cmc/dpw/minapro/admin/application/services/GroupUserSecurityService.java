package com.cmc.dpw.minapro.admin.application.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dao.GroupUserSecurityDAO;
import com.cmc.dpw.minapro.admin.application.dao.RoleDAO;
import com.cmc.dpw.minapro.admin.application.dto.GenericGroupAssociationDTO;
import com.cmc.dpw.minapro.admin.application.dto.GenericLookUpDTO;
import com.cmc.dpw.minapro.admin.application.dto.GroupDTO;
import com.cmc.dpw.minapro.admin.application.dto.GroupMasterDetailsDTO;
import com.cmc.dpw.minapro.admin.application.dto.MenuItem;
import com.cmc.dpw.minapro.admin.application.entities.FunctionGroupAccess;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.application.entities.pks.FunctionGroupId;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
/**
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Service
public class GroupUserSecurityService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GroupUserSecurityService.class);

    @Autowired
    private GroupUserSecurityDAO groupUserSecurityDAO;

    @Autowired
    private RoleDAO roleDAO;

    @Autowired
    private GenericDAO genericDAO;

    @Transactional
    public Map<String, Object> getGroupDtls(String userNamefield, String groupCodeField,
            String groupNameField, int limit, int start)  {

        return groupUserSecurityDAO.searchRoles(userNamefield, groupNameField, groupCodeField, start, limit);
    }

    @Transactional
    public List<GenericLookUpDTO> getGroupAssociatedUserDetails(String groupId, String serviceType) {
        return groupUserSecurityDAO.getGroupAssociatedUserDetails(groupId, serviceType);
    }

    @Transactional
    public List<GenericLookUpDTO> getGroupAvailableUserDetails(String groupId, String userName){
        return groupUserSecurityDAO.getGroupAvailableUserDetails(groupId, userName);
    }

/**
 * This method is used to get Module Details
 * @param serviceType
 * @return StringBuilder
 */
    @Transactional
    public String getModuleDetails(String serviceType) {
        List<MenuItem> domainMenuList = groupUserSecurityDAO.getModuleDetails(serviceType);
        List<MenuItem> actualMenuList = new ArrayList<MenuItem>();

        if (domainMenuList != null && !domainMenuList.isEmpty()) {
            for (MenuItem menu : domainMenuList) {
                if (menu.getParentMenuId() != null && "FAPSB".equalsIgnoreCase(menu.getParentMenuId())) {
                    actualMenuList.add(menu);
                }
            }

            for (MenuItem menu : actualMenuList) {
                menu = associateParentToChildMenuItem(menu, domainMenuList);
            }

        }
        String menuTreeJSON = "[";
        menuTreeJSON = createModuleTree(actualMenuList, menuTreeJSON);

        menuTreeJSON += "]";

        StringBuilder sb = new StringBuilder("");
        sb.append("{'text': '.','children' : ");
        sb.append(menuTreeJSON);
        sb.append("}");
        return sb.toString();
    }
    /**
     * This mehtod is used to associate Parent To Child MenuItem
     * @param menu
     * @param domainMenuList
     * @return MenuItem
     */
    private MenuItem associateParentToChildMenuItem(MenuItem menu, List<MenuItem> domainMenuList) {

        List<MenuItem> tempList = new ArrayList<MenuItem>();
        for (MenuItem sub : domainMenuList) {
            if (sub.getParentMenuId() != null && menu.getMenuId().equalsIgnoreCase(sub.getParentMenuId())) {
                tempList.add(sub);
                associateParentToChildMenuItem(sub, domainMenuList);
            }
        }

        menu.setList(tempList);
        return menu;
    }

    private String createModuleTree(List<MenuItem> mainMenuList, String json) {

        int count = 0;
        String resultJson = json ;
        if (mainMenuList != null && !mainMenuList.isEmpty()) {
            for (MenuItem menuItem : mainMenuList) {
                resultJson += "{'name':'" + menuItem.getName() + "'" + ",'code':'" + menuItem.getMenuId() + "'";
                List<MenuItem> list = menuItem.getList();

                if (list != null && !list.isEmpty()) {
                    resultJson += ",'children':[";
                    resultJson = createModuleTree(list, resultJson);
                    resultJson += "]}";
                } else {
                    if (menuItem.getSortOrder() != null && menuItem.getSortOrder() == 1) {
                        resultJson += ",'leaf':true";
                    }
                    resultJson += "}";

                }

                if (count < (mainMenuList.size() - 1)) {
                    count++;
                    resultJson += ",";
                }

            }
            count = 0;

        }
        return resultJson;
    }

    /**
     * This method is used to get Available FunctionDetails By ModuleId
     * @param moduleId
     * @param groupId
     * @param serviceType
     * @return GroupUserSecurityDAO
     */
    @Transactional
    public List<GenericLookUpDTO> getAvailableFunctionDetailsByModuleId(String moduleId, String groupId,
            String serviceType) {
        return groupUserSecurityDAO.getAvailableFunctionDetailsByModuleId(moduleId, groupId, serviceType);
    }

    /**
     * This method is used to get Available FunctionDetails By ModuleId
     * @param moduleId
     * @param groupId
     * @param serviceType
     * @return GroupUserSecurityDAO
     */
    @Transactional
    public List<GenericLookUpDTO> getAssociatedFunctionDetailsByModuleId(String moduleId, String groupId,
            String serviceType)  {
        return groupUserSecurityDAO.getAssociatedFunctionDetailsByModuleId(moduleId, groupId, serviceType);
    }

    /**
     * This method is used to delete Group By Group Id
     * @param grpArray
     */
    @Transactional
    @Manipulate(table = "MP_GRPDTLS_AM")
    public void deleteGroupByGroupId(String[] grpArray)  {

        for (String grpId : grpArray) {

            Role role = roleDAO.findOne(Integer.parseInt(grpId));
            if (role != null) {
                boolean wasDeleteSuccessful = groupUserSecurityDAO.deleteGroupAssociations(Integer.parseInt(grpId));

                if (wasDeleteSuccessful) {
                    roleDAO.hardDelete(role);
                }
            }

        }

    }
    /**
     * This method is used to save Group Associated User And Function Details
     * @param groupMasterDetailsDTO
     */
    @Transactional
    @Manipulate(table = "MP_GRPDTLS_AM")
    public void saveGroupAssociatedUserAndFunctionDetails(GroupMasterDetailsDTO groupMasterDetailsDTO){

        Role currentGroup = null;
        List<User> actualUsers = new ArrayList<User>();
        boolean isNewGroup = false;
        Date currentDate = new Date();
        

            if (groupMasterDetailsDTO != null
                    && groupMasterDetailsDTO.getAction() != null
                    && ("COPY".equalsIgnoreCase(groupMasterDetailsDTO.getAction()) || 
                            "EDIT" .equalsIgnoreCase(groupMasterDetailsDTO.getAction()))) {

                List<GenericGroupAssociationDTO> copyFunctionList = groupMasterDetailsDTO.getGroupFunctionList();

                Set<GenericGroupAssociationDTO> associatedFunctionSet = new HashSet<GenericGroupAssociationDTO>(
                        copyFunctionList);

                groupMasterDetailsDTO.setGroupFunctionList(new ArrayList<GenericGroupAssociationDTO>(
                        associatedFunctionSet));

                int roleId = groupMasterDetailsDTO.getGroupList().get(0).getGroupId();

                currentGroup = roleDAO.findOne(roleId);

            } else {
                isNewGroup = true;
                currentGroup = new Role();
                String groupName = groupMasterDetailsDTO.getGroupList().get(0).getGroupName();
                String groupCode = groupMasterDetailsDTO.getGroupList().get(0).getGroupCode();

                currentGroup.setUserGroupName(groupName);
                currentGroup.setUserGroupCd(groupCode);
                currentGroup.setCreatedDateTime(currentDate);
                currentGroup.setIsDeleted('N');
                currentGroup.setSrvTypeGroupCd("TTS");
                currentGroup.setSystemDefined("N");
            }

            String groupDesc = groupMasterDetailsDTO.getGroupList().get(0).getGroupDesc();
            currentGroup.setsDesc(groupDesc);
            currentGroup.setLastUpdatedDateTime(currentDate);

            List<GenericGroupAssociationDTO> userGroupList = groupMasterDetailsDTO.getGroupUserList();

            for (GenericGroupAssociationDTO currentUserGroup : userGroupList) {
                int userId = Integer.parseInt(currentUserGroup.getAssociateId());
                User user = new User();
                user.setUserId(userId);
                actualUsers.add(user);
            }
            currentGroup.setActualUsers(actualUsers);

            Role updatedRole = roleDAO.saveOrupdate(currentGroup);
            LOGGER.debug("testing:" + updatedRole.getIntUserGroupId());
            List<GenericGroupAssociationDTO> modifiedFunctions = groupMasterDetailsDTO.getGroupFunctionList();
            List<GenericGroupAssociationDTO> removedFunctions = groupMasterDetailsDTO.getRemovedList();

            for (GenericGroupAssociationDTO currentModifiedFunction : modifiedFunctions) {

                int accessCode = currentModifiedFunction.getAccessCode();
                int groupId = updatedRole.getIntUserGroupId();
                String functionCode = currentModifiedFunction.getAssociateId();

                FunctionGroupAccess functionGroup = new FunctionGroupAccess();
                FunctionGroupId fgId = new FunctionGroupId();
                fgId.setIntUserGroupId(groupId);
                fgId.setFunctionCode(functionCode);
                functionGroup.setFunctionGroupId(fgId);
                functionGroup.setAccessCode(accessCode);

                functionGroup.setLastUpdatedDateTime(currentDate);

                if (isNewGroup) {

                    functionGroup.setCreatedDateTime(currentDate);
                    functionGroup.setLastUpdatedDateTime(currentDate);
                }

                genericDAO.saveOrupdate(functionGroup);

            }

            if (!removedFunctions.isEmpty()) {

                for (GenericGroupAssociationDTO currentRemovedFunction : removedFunctions) {

                    int groupId = updatedRole.getIntUserGroupId();
                    String functionCode = currentRemovedFunction.getAssociateId();

                    FunctionGroupAccess functionGroup = new FunctionGroupAccess();
                    FunctionGroupId fgId = new FunctionGroupId();
                    fgId.setIntUserGroupId(groupId);
                    fgId.setFunctionCode(functionCode);
                    functionGroup.setFunctionGroupId(fgId);

                    genericDAO.hardDelete(functionGroup);

                }
            }
    }

    @Transactional
    public List<GroupDTO> findGroupByCodeAndName(String code, String name) {
        return groupUserSecurityDAO.findGroupByCodeAndName(code, name);
    }

    @Transactional
    public List<GenericLookUpDTO> getFunctionCodesAssociatedWithUserAndGroup(String userId) {
        return groupUserSecurityDAO.getFunctionCodesAssociatedWithUserAndGroup(userId);
    }

    @Transactional
    public List<GenericLookUpDTO> getAllUserDetails(String searchUserName) {
        return groupUserSecurityDAO.getAllUserDetails(searchUserName);
    }

}
