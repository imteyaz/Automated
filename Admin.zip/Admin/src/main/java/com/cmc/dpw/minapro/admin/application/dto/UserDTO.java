package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonManagedReference;

/**
 * UserDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class UserDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer userId;
    private Integer alwdLoginAttempts;
    private Integer preExpWarningPeriod;
    private Integer alwdInactivityPeriod;
    private Integer passwdValidPeriod;
    private Integer delIntUserId;
    private String intrnlUserInd;
    private String accountStatus;
    private String userPriviledgeCls;
    private String userName;
    private String password;
    private String firstName;
    private String lastName;
    private String userDescription;
    private String telephoneNo;
    private String mobileNo;
    private String emailId;
    private String faxNo;
    private String tzInfo;
    private String defaultLanguage;
    private String iv;
    private String salt;
    private Date passwdValidDate;
    private Date userCreationDatTime;
    private Date lastLogin;
    private String loginStatus;
    private Date delDatTime;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String createdBy;
    private String lastUpdatedBy;
    private Date createdDateTime;
    private Date lastUpdatedDateTime;
    private String stringRoles;
    private LanguageDTO language;
    private List<String> roles = new ArrayList<String>();
    private Collection<RoleDTO> actualRoles = new ArrayList<RoleDTO>();
    private String equipmentId;
    private String deviceId;
    
    
    
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public String getDeviceId() {
        return deviceId;
    }
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getAlwdLoginAttempts() {
        return alwdLoginAttempts;
    }
    public void setAlwdLoginAttempts(Integer alwdLoginAttempts) {
        this.alwdLoginAttempts = alwdLoginAttempts;
    }
    public Integer getPreExpWarningPeriod() {
        return preExpWarningPeriod;
    }
    public void setPreExpWarningPeriod(Integer preExpWarningPeriod) {
        this.preExpWarningPeriod = preExpWarningPeriod;
    }
    public Integer getAlwdInactivityPeriod() {
        return alwdInactivityPeriod;
    }
    public void setAlwdInactivityPeriod(Integer alwdInactivityPeriod) {
        this.alwdInactivityPeriod = alwdInactivityPeriod;
    }
    public Integer getPasswdValidPeriod() {
        return passwdValidPeriod;
    }
    public void setPasswdValidPeriod(Integer passwdValidPeriod) {
        this.passwdValidPeriod = passwdValidPeriod;
    }
    public Integer getDelIntUserId() {
        return delIntUserId;
    }
    public void setDelIntUserId(Integer delIntUserId) {
        this.delIntUserId = delIntUserId;
    }
    public String getIntrnlUserInd() {
        return intrnlUserInd;
    }
    public void setIntrnlUserInd(String intrnlUserInd) {
        this.intrnlUserInd = intrnlUserInd;
    }
    public String getAccountStatus() {
        return accountStatus;
    }
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }
    public String getUserPriviledgeCls() {
        return userPriviledgeCls;
    }
    public void setUserPriviledgeCls(String userPriviledgeCls) {
        this.userPriviledgeCls = userPriviledgeCls;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getUserDescription() {
        return userDescription;
    }
    public void setUserDescription(String userDescription) {
        this.userDescription = userDescription;
    }
    public String getTelephoneNo() {
        return telephoneNo;
    }
    public void setTelephoneNo(String telephoneNo) {
        this.telephoneNo = telephoneNo;
    }
    public String getMobileNo() {
        return mobileNo;
    }
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getFaxNo() {
        return faxNo;
    }
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }
    public String getTzInfo() {
        return tzInfo;
    }
    public void setTzInfo(String tzInfo) {
        this.tzInfo = tzInfo;
    }
    public String getDefaultLanguage() {
        return defaultLanguage;
    }
    public void setDefaultLanguage(String defaultLanguage) {
        this.defaultLanguage = defaultLanguage;
    }
    public String getIv() {
        return iv;
    }
    public void setIv(String iv) {
        this.iv = iv;
    }
    public String getSalt() {
        return salt;
    }
    public void setSalt(String salt) {
        this.salt = salt;
    }
    public Date getPasswdValidDate() {
        return passwdValidDate;
    }
    public void setPasswdValidDate(Date passwdValidDate) {
        this.passwdValidDate = passwdValidDate;
    }
    public Date getUserCreationDatTime() {
        return userCreationDatTime;
    }
    public void setUserCreationDatTime(Date userCreationDatTime) {
        this.userCreationDatTime = userCreationDatTime;
    }
    public Date getLastLogin() {
        return lastLogin;
    }
    public void setLastLogin(Date lastLogin) {
        this.lastLogin = lastLogin;
    }
    public String getLoginStatus() {
        return loginStatus;
    }
    public void setLoginStatus(String loginStatus) {
        this.loginStatus = loginStatus;
    }
    public Date getDelDatTime() {
        return delDatTime;
    }
    public void setDelDatTime(Date delDatTime) {
        this.delDatTime = delDatTime;
    }
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }
    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }
    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }
    public String getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }
    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }
    public String getStringRoles() {
        return stringRoles;
    }
    public void setStringRoles(String stringRoles) {
        this.stringRoles = stringRoles;
    }
    public LanguageDTO getLanguage() {
        return language;
    }
    public void setLanguage(LanguageDTO language) {
        this.language = language;
    }
    public List<String> getRoles() {
        return roles;
    }
    public void setRoles(List<String> roles) {
        this.roles = roles;
    }
    
    @JsonManagedReference
    public Collection<RoleDTO> getActualRoles() {
        return actualRoles;
    }
    public void setActualRoles(Collection<RoleDTO> actualRoles) {
        this.actualRoles = actualRoles;
    }

}
