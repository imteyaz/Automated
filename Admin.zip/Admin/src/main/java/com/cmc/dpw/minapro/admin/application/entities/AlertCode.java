package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * AlertCode POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "AlertCode")
@Table(name = "MP_ALERTCODES_MASTER")
public class AlertCode extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String alertCodePK;
    private String description;

    @Id
    @Column(name = "ALERT_CODE", nullable = false)
    public String getAlertCodePK() {
        return alertCodePK;
    }

    public void setAlertCodePK(String alertCodePK) {
        this.alertCodePK = alertCodePK;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
