package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.application.services.EquipmentService;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/equipment")
public class EquipmentController {

    @Autowired
    private EquipmentService equipmentService;
    private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentController.class);

    /**
     * This method searches for all the equipments matching the search criteria
     * as entered by the end user
     * 
     * @param equipmentId
     * @param equipmentName
     * @param make
     * @param model
     * @param equipmentTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String equipmentId,
            @RequestParam(required = false) String equipmentName, @RequestParam(required = false) String make,
            @RequestParam(required = false) String model, @RequestParam(required = false) String equipmentTypeId,
            @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start EquipmentController Seacrh Equipment method");
     
        String[] requestParameters = { equipmentId, equipmentName, make, model, equipmentTypeId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"EquipmentController-->search equipmentId:{},equipmentName :{},make :{},equipmentTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering EquipmentController Seacrh Equipment method");

            Map<String, Object> equipmentsMap = equipmentService.searchEquipmentList(equipmentId, equipmentName, make,
                    model, equipmentTypeId, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting EquipmentController Seacrh Equipment method");
            return getMap(equipmentsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"EquipmentController-->search Equipment-->Catch Block :{}", e);
            return Util.getModelMapError("Error retrieving Equipments from database.");
        }
    }

    /**
     * This method creates the equipment as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created equipment data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start> EquipmentController> Create Equipment method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Data{}", data);

        try {
            List<Equipment> equipments = equipmentService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting EquipmentController Create Equipment method");
            return getMap(equipments);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return Util.getModelMapError("Error trying to create equipment due to following exception  :{}" + cause.getMessage());
            
        }  catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return Util.getModelMapError("Error trying to create equipment :" + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return Util.getModelMapError("Error trying to create equipment.");
        }

    }
    
    /**
     * This method updates the equipment as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated equipment data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start EquipmentController Update Equipment method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<Equipment> equipments = equipmentService.update(data, principal);
            return getMap(equipments);

        } catch (InvalidValueException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +" Start--> EquipmentController>update-->InvalidValueException", e);
            return Util.getModelMapError("Error trying to update equipment :" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return Util.getModelMapError("Error trying to update equipment. ");

        }
    }

    
    /**
     * This method deletes the equipment.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted equipment data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start EquipmentController Delete Equipment method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            equipmentService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting EquipmentController Delete Equipment method");
            return modelMap;

        }catch (InvalidValueException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +" --> delete --> InvalidValueException", e);
            return Util.getModelMapError("Error trying to delete equipment :" + e.getCustomErrorMessage());
            
        }catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return Util.getModelMapError("Error trying to delete equipment.");

        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param equipments List of equipments
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<Equipment> equipments) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", equipments);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> equipmentsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) equipmentsMap.get("totalCount");

        List<Equipment> equipments = (List<Equipment>) equipmentsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", equipments);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, equipments);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

}
