package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * AlertParameterKey POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "AlertParameterKey")
@Table(name = "MP_ALERT_PARAMETER_KEY_MASTER")
public class AlertParameterKey implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer paramId;
    private String paramName;
    

    @Id
    @Column(name = "PARAMETER_ID", nullable = false)
    public Integer getParamId() {
        return paramId;
    }
    public void setParamId(Integer paramId) {
        this.paramId = paramId;
    }
    
    @Column(name = "PARAMETER_NAME", nullable = false)
    public String getParamName() {
        return paramName;
    }
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }
  

    


}
