package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.AlertRemarksDAO;
import com.cmc.dpw.minapro.admin.application.dto.AlertRemarksDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertRemarks;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Util;


/**
 * AlertRemarks Service
 * @author Imran Rawani
 * @since 2016-Aug
 * 
 */
@Service
public class AlertRemarksService {

    @Autowired
    private AlertRemarksDAO alertRemarksDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRemarksService.class);

    /**
     * This method is used to get AlertRemarks List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<AlertRemarks> getAlertRemarksList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  AlertRemarks service's getAlertRemarksList");
        alertRemarksDAO.setClazz(AlertRemarks.class);
        return alertRemarksDAO.findAll();

    }

    /**
     * This method is used to search AlertRemarks List
     * @return Map<String, Object> containing the search AlertRemarks data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchAlertRemarks(String alertRecordId, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertRemarks service's searchAlertRemarks method");
        alertRemarksDAO.setClazz(AlertRemarks.class);
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRemarks service's searchAlertRemarks method");
        return alertRemarksDAO.searchAlertRemarkss(alertRecordId,start,limit );
    }

    /**
     * This method is used to update AlertRemarksList
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<AlertRemarks>
     * @throws ExistingRecordException
     */
    @Transactional
    public List<AlertRemarks> addRemarks(Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertRemarks service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  alertRemarks  service's  create : {} ", data);
        
        List<AlertRemarks> returnAlertRemarks = new ArrayList<AlertRemarks>();
        alertRemarksDAO.setClazz(AlertRemarks.class);

        List<AlertRemarks> addedAlertRemarks = util.getEntitiesFromDto(data, AlertRemarksDTO.class, AlertRemarks.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (AlertRemarks currentAlertRemarks : addedAlertRemarks) {

            Date currentDate = new Date();
            currentAlertRemarks.setCreatedBy(userId);
            currentAlertRemarks.setCreatedDateTime(currentDate);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"creating alertRemarks for alertRemark Id: {}",currentAlertRemarks.getAlertRemarkId());
            returnAlertRemarks.add(alertRemarksDAO.create(currentAlertRemarks));
            
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRemarks service's update method");
        return returnAlertRemarks;
    }
    
}
