package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.TroubleShootAreaDAO;
import com.cmc.dpw.minapro.admin.application.dto.TroubleShootAreaDTO;
import com.cmc.dpw.minapro.admin.application.entities.TroubleShootArea;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * TroubleShootArea Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class TroubleShootAreaService {

    @Autowired
    private TroubleShootAreaDAO troubleShootAreaDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(TroubleShootAreaService.class);

    /**
     * This method is used to get TroubleShootArea List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<TroubleShootArea> getTroubleShootAreaList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  TroubleShootArea service's getTroubleShootAreaList");
        troubleShootAreaDAO.setClazz(TroubleShootArea.class);
        return troubleShootAreaDAO.findAll();

    }

    /**
     * This method is used to search TroubleShootArea
     * @return Map<String, Object> containing the search TroubleShootArea data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchTroubleShootAreaList(String troubleShootAreaId, String description,
            String terminalId, String availability, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TroubleShootArea service's searchTroubleShootAreaList method");
        troubleShootAreaDAO.setClazz(TroubleShootArea.class);

        String[] requestParameters = { troubleShootAreaId, description, terminalId, availability };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In TroubleShootArea service searchTroubleShootAreas with troubleShootAreaId: {} , description : {} , terminalId : {} , availability : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootArea service's searchTroubleShootAreaList method");
        return troubleShootAreaDAO.searchTroubleShootAreas(troubleShootAreaId, description, terminalId, availability,
                start, limit);

    }

    /**
     * This method is used to create TroubleShootArea
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<TroubleShootArea> containing created TroubleShootArea data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_TROUBLESHOOTAREA_MASTER")
    public List<TroubleShootArea> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TroubleShootArea service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  troubleShootArea service's  create : {} ", data);

        List<TroubleShootArea> newTroubleShootAreas = new ArrayList<TroubleShootArea>();

        List<TroubleShootArea> list = util.getEntitiesFromDto(data, TroubleShootAreaDTO.class ,TroubleShootArea.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        for (TroubleShootArea troubleShootArea : list) {

            Date currentDate = new Date();

            troubleShootArea.setCreatedDateTime(currentDate);
            troubleShootArea.setLastUpdatedDateTime(currentDate);
            troubleShootArea.setCreatedBy(userId.toString());
            troubleShootArea.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"TroubleShootArea Id property in troubleShootArea service's create : {}",
                    troubleShootArea.getTroubleShootAreaId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling troubleShootArea DAO findOne");

            TroubleShootArea alreadyTroubleShootArea = troubleShootAreaDAO.findOne(troubleShootArea
                    .getTroubleShootAreaId());

            if (alreadyTroubleShootArea == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling troubleShootArea DAO");
                newTroubleShootAreas.add(troubleShootAreaDAO.create(troubleShootArea));
            } else {

                char isDeleted = alreadyTroubleShootArea.getIsDeleted();

                if (isDeleted == 'Y') {
                    troubleShootArea.setVersion(alreadyTroubleShootArea.getVersion());
                    troubleShootArea.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling troubleShootArea DAO update");
                    newTroubleShootAreas.add(troubleShootAreaDAO.update(troubleShootArea));
                } else {
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootArea service's create method");
        return newTroubleShootAreas;
    }

    /**
     * This method is used to update TroubleShootArea 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<TroubleShootArea> containing updated TroubleShootArea data
     */
    @Transactional
    @Manipulate(table = "MP_TROUBLESHOOTAREA_MASTER")
    public List<TroubleShootArea> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TroubleShootArea service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  troubleShootArea  service's  update : {} ", data);

        List<TroubleShootArea> returnTroubleShootAreas = new ArrayList<TroubleShootArea>();

        List<TroubleShootArea> updatedTroubleShootAreas = util.getEntitiesFromDto(data, TroubleShootAreaDTO.class ,TroubleShootArea.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (TroubleShootArea troubleShootArea : updatedTroubleShootAreas) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"troubleShootAreaId property in troubleShootArea service update : {}",
                    troubleShootArea.getTroubleShootAreaId());
            troubleShootArea.setLastUpdatedDateTime(currentDate);
            troubleShootArea.setLastUpdatedBy(userId.toString());
            returnTroubleShootAreas.add(troubleShootAreaDAO.update(troubleShootArea));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootArea service's update method");
        return returnTroubleShootAreas;
    }

    /**
     * This methos is used to delete TroubleShootArea
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_TROUBLESHOOTAREA_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TroubleShootArea service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In troubleShootArea's service delete : {} ", data);

        List<TroubleShootArea> deletedTroubleShootAreas = util.getEntitiesFromDto(data, TroubleShootAreaDTO.class ,TroubleShootArea.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (TroubleShootArea troubleShootArea : deletedTroubleShootAreas) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"troubleShootAreaId property in troubleShootArea service delete : {}",
                    troubleShootArea.getTroubleShootAreaId());
            troubleShootArea.setLastUpdatedDateTime(currentDate);
            troubleShootArea.setLastUpdatedBy(userId.toString());
            troubleShootArea.setIsDeleted('Y');
            troubleShootAreaDAO.delete(troubleShootArea);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootArea service's delete method");
    }

}
