package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dao.VesselTemplateHeaderDAO;
import com.cmc.dpw.minapro.admin.application.dto.TemplateHeaderDTO;
import com.cmc.dpw.minapro.admin.application.entities.Bay;
import com.cmc.dpw.minapro.admin.application.entities.TemplateDetails;
import com.cmc.dpw.minapro.admin.application.entities.TemplateHeader;
import com.cmc.dpw.minapro.admin.application.entities.pks.TemplateDetailsPk;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * TemplateHeader Service
 * 
 * 
 */
@Service
public class VesselTemplateHeaderService {
    
    @Autowired
    private VesselTemplateHeaderDAO vesselTemplateHeaderDAO;
    @Autowired
    private GenericDAO genericDAO ;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselTemplateHeaderService.class) ;
    
    @Transactional(readOnly=true)
    public List<TemplateHeader> getVesselTemplateHeaderList(){
        LOGGER.info("###########Entering  TemplateHeader service's getVesselTemplateHeaderList");
        vesselTemplateHeaderDAO.setClazz(TemplateHeader.class);
        return vesselTemplateHeaderDAO.findAll();
    }
    
    @Transactional(readOnly=true)
    public Map<String, Object> searchVesselTemplateHeaderList(String vesselTemplateHeaderId,String vesselTemplateHeaderName, String vesselTemplateHeaderTypeId,int start,int limit){
        LOGGER.info("############Entering TemplateHeader service's searchVesselTemplateHeaderList method");
        
        vesselTemplateHeaderDAO.setClazz(TemplateHeader.class);
        
        String[] requestParameters={vesselTemplateHeaderId,vesselTemplateHeaderName,vesselTemplateHeaderTypeId};
        LOGGER.debug("************In TemplateHeader service searchVesselTemplateHeaderList  with vesselTemplateHeaderId: {} , vesselTemplateHeaderName : {}, vesselTemplateHeaderTypeId : {}", requestParameters);
        LOGGER.info("############Exiting TemplateHeader service's searchVesselTemplateHeaderList method");
        
        Map<String, Object> headersMap = vesselTemplateHeaderDAO.searchVesselTemplatesHeaders(vesselTemplateHeaderId,vesselTemplateHeaderName,vesselTemplateHeaderTypeId,start,limit);
        List<TemplateHeader> searchVesselTemplatesHeaders =  (List<TemplateHeader>) headersMap.get("data");
        
        for(TemplateHeader templateHeader: searchVesselTemplatesHeaders){
             String headerId = templateHeader.getHeaderId() ;
             LOGGER.debug(" ********* current templateHeader's Id  : {}" ,templateHeader.getHeaderId()); 
             genericDAO.setClazz(TemplateDetails.class);
             List<TemplateDetails> currentTemplateDetailsList =  genericDAO.findByPropertyValue(TemplateDetails.class, "pk.headerId", headerId, false) ;
             
             List<Bay> bayList4CurrentTemplate =  genericDAO.findByPropertyValue(Bay.class, "tierTemplate", headerId, false) ;
             int bayCount4Template = bayList4CurrentTemplate.size() ;
             
             for(TemplateDetails currentTemplateDetails : currentTemplateDetailsList){
                 Integer seqNo =  currentTemplateDetails.getPk().getOffset() ;
                 currentTemplateDetails.setSeqNo(seqNo);
             }
             templateHeader.setTemplateDetails(currentTemplateDetailsList);
             templateHeader.setBayList(bayList4CurrentTemplate);
             if(bayCount4Template>0){
                 templateHeader.setIsUsed('Y');
             }else{
                 templateHeader.setIsUsed('N');
             }
             
             
         }
        List<TemplateHeaderDTO> searchVesselTemplatesHeadersDtoList =  util.map(searchVesselTemplatesHeaders, TemplateHeaderDTO.class);
        
        headersMap.put("data", searchVesselTemplatesHeadersDtoList);
        return headersMap ;
    }
    
    
    private List<TemplateHeader> create(List<TemplateHeader> newVesselTemplateHeaders ,String userId) throws ExistingRecordException{
        LOGGER.info("###########Entering TemplateHeader service's create method");
        
        List<TemplateHeader> createdVesselTemplateHeaders = new ArrayList<TemplateHeader>();
        
        for (TemplateHeader vesselTemplateHeader : newVesselTemplateHeaders){
            
            Date currentDate =  new Date();
            vesselTemplateHeader.setCreatedDateTime(currentDate);
            vesselTemplateHeader.setLastUpdatedDateTime(currentDate);
            vesselTemplateHeader.setLastUpdatedBy(userId);
            vesselTemplateHeader.setCreatedBy(userId);
            
            LOGGER.debug("***********TemplateHeader Id property in vesselTemplateHeader service's create : {}", vesselTemplateHeader.getHeaderId());
            LOGGER.info("###########calling vesselTemplateHeader DAO findOne");
         
            TemplateHeader alreadyVesselTemplateHeader =    vesselTemplateHeaderDAO.findOne(vesselTemplateHeader.getHeaderId());
            
            if(alreadyVesselTemplateHeader==null){
                LOGGER.info("###########calling vesselTemplateHeader DAO create");
                createdVesselTemplateHeaders.add(vesselTemplateHeaderDAO.create(vesselTemplateHeader));
            }else{
                char isDeleted = alreadyVesselTemplateHeader.getIsDeleted();
                
                if(isDeleted=='Y'){
                    vesselTemplateHeader.setVersion(alreadyVesselTemplateHeader.getVersion());
                    vesselTemplateHeader.setIsDeleted('N');
                    LOGGER.info("###########calling vesselTemplateHeader DAO update");
                    createdVesselTemplateHeaders.add(vesselTemplateHeaderDAO.update(vesselTemplateHeader));
                }else{
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                //end of else below- entity not null
            }
            //end of for loop below
        }  
            LOGGER.info("##########Exiting TemplateHeader service's create method");
            return createdVesselTemplateHeaders;
    }
    
    
    private List<TemplateHeader> update(List<TemplateHeader> updatedVesselTemplateHeaders, String userId){
        LOGGER.info("###########Entering TemplateHeader service's update method");
        List<TemplateHeader> modifiedVesselTemplateHeaders = new ArrayList<TemplateHeader>();
        for (TemplateHeader vesselTemplateHeader : updatedVesselTemplateHeaders){
            
            Date currentDate =  new Date();
            LOGGER.debug("***********vesselTemplateHeaderId property in vesselTemplateHeader service update : {}", vesselTemplateHeader.getHeaderId());
            vesselTemplateHeader.setLastUpdatedDateTime(currentDate);
            vesselTemplateHeader.setLastUpdatedBy(userId);
            modifiedVesselTemplateHeaders.add(vesselTemplateHeaderDAO.update(vesselTemplateHeader));
        }
        LOGGER.info("############Exiting TemplateHeader service's update method");
        return modifiedVesselTemplateHeaders;
    }
    
    
    private void delete(List<TemplateHeader> deletedVesselTemplateHeaders, String userId){
        LOGGER.info("###########Entering TemplateHeader service's delete method");
        
        for (TemplateHeader vesselTemplateHeader : deletedVesselTemplateHeaders){
           String headerId = vesselTemplateHeader.getHeaderId() ;
           
           LOGGER.debug("***********TemplateHeader Id property in vesselTemplateHeader service delete : {}", vesselTemplateHeader.getHeaderId());
           
           
            genericDAO.setClazz(TemplateDetails.class);
            List<TemplateDetails> currentTemplateDetailsList =  genericDAO.findByPropertyValue(TemplateDetails.class, "pk.headerId", headerId, false);
            int childRecordsLength = currentTemplateDetailsList.size() ;
            LOGGER.debug("*********** count of  child records while deleting TemplateHeaderId  : {}", headerId + "is :{}" + childRecordsLength);
            int  i=1 ;
            for(TemplateDetails currentTemplateDetails : currentTemplateDetailsList){
                genericDAO.hardDelete(currentTemplateDetails);
                LOGGER.debug("*********** Successfully deleted child record having pk (header Id) as : {}", currentTemplateDetails.getPk().getHeaderId() + "and seq no as :{}" + currentTemplateDetails.getPk().getOffset());
                i++ ;
            }
            i=i-1 ;
            
            LOGGER.debug("***********Total no. of child records deleted for heaader id : {}", vesselTemplateHeader.getHeaderId() + "are :{}" + i );
            
            Date currentDate =  new Date();
            LOGGER.debug("***********going to delete vesselTemplateHeader now  : {}", vesselTemplateHeader.getHeaderId());
            vesselTemplateHeader.setIsDeleted('Y');
            vesselTemplateHeader.setLastUpdatedDateTime(currentDate);
            vesselTemplateHeader.setLastUpdatedBy(userId);
            vesselTemplateHeaderDAO.delete(vesselTemplateHeader) ;
            
        }
        LOGGER.info("############Exiting TemplateHeader service's delete method");
    }
  
    @Transactional(propagation=Propagation.REQUIRED)
    public void saveChanges(List<TemplateDetails> delChildRecordsList,
            List<TemplateDetails> newChildRecordsList, List<TemplateDetails> updatedChildRecordsList,
            List<TemplateHeader> newRecordsList, List<TemplateHeader> updatedRecordsList, List<TemplateHeader> delRecordsList, Principal principal) throws ExistingRecordException {
        
        Integer userId = util.getUserIdFromPrincipal(principal); 
        String userIdString = userId.toString();
        Date currentDate = new Date();
        
         if(updatedRecordsList!=null && !updatedRecordsList.isEmpty()){
                update(updatedRecordsList,userIdString);
         }
        
        if(newRecordsList!=null && !newRecordsList.isEmpty()){
            create(newRecordsList,userIdString);
        }
        
        if(delChildRecordsList!=null && !delChildRecordsList.isEmpty()){
            genericDAO.setClazz(TemplateDetails.class);
            for(TemplateDetails templateDetails : delChildRecordsList ){
                templateDetails.setIsDeleted('Y');
                templateDetails.setLastUpdatedDateTime(currentDate);
                templateDetails.setLastUpdatedBy(userIdString);
                setPk(templateDetails);
                genericDAO.hardDelete(templateDetails);
            }
        }
        
        if(newChildRecordsList!=null && !newChildRecordsList.isEmpty()){
            genericDAO.setClazz(TemplateDetails.class);
            for(TemplateDetails templateDetails : newChildRecordsList ){
                templateDetails.setLastUpdatedDateTime(currentDate);
                templateDetails.setLastUpdatedBy(userIdString);
                templateDetails.setCreatedDateTime(currentDate);
                templateDetails.setCreatedBy(userIdString);
                setPk(templateDetails);
                TemplateDetails duplicateRecord = checkDuplicates(templateDetails);
                
                if(duplicateRecord==null){
                    
                    TemplateDetails duplicateLabelTemplateDetails = checkDuplicateLabels(templateDetails) ;
                     if(duplicateLabelTemplateDetails == null){
                         genericDAO.create(templateDetails);
                     }else{
                         String duplicateHeaderId = duplicateLabelTemplateDetails.getPk().getHeaderId();
                         Integer duplicateSequence= duplicateLabelTemplateDetails.getPk().getOffset();
                         String duplicateLabel = duplicateLabelTemplateDetails.getVesselLabel();
                         throw new ExistingRecordException(" Vessel label " + duplicateLabel +" is already in use for header Id " + duplicateHeaderId + " and sequence no" + duplicateSequence);
                     }
                    
                }else{
                    String duplicateHeader = templateDetails.getPk().getHeaderId();
                   Integer duplicateOffset =  templateDetails.getPk().getOffset() ;
                    throw new ExistingRecordException( " A record of Template Details having header id as " + duplicateHeader  + " and sequence no as "+ duplicateOffset + MessageConstants.EXISTING_TEMPLATEDETAILS_RECORD_EXCEPTION_MESSAGE);
                }
                
                
            }
        }
        if(updatedChildRecordsList!=null && !updatedChildRecordsList.isEmpty()){
            genericDAO.setClazz(TemplateDetails.class);
            for(TemplateDetails templateDetails : updatedChildRecordsList ){
                templateDetails.setLastUpdatedDateTime(currentDate);
                templateDetails.setLastUpdatedBy(userIdString);
                setPk(templateDetails);
                genericDAO.update(templateDetails);
            }
        }
        
        
        if(delRecordsList!=null && !delRecordsList.isEmpty()){
            delete(delRecordsList, userIdString);
        }
        
    }
    
    private TemplateDetails checkDuplicateLabels( TemplateDetails templateDetails) throws ExistingRecordException {
        
        TemplateDetails duplicateLabelTemplateDetails = null ;
        String label =templateDetails.getVesselLabel() ;
        
        genericDAO.setClazz(TemplateDetails.class);
        List<TemplateDetails> searchResults = genericDAO.findByPropertyValue(TemplateDetails.class, "vesselLabel", label, false);
        
        for(TemplateDetails td : searchResults ){
            if(td.getPk().getHeaderId().equalsIgnoreCase(templateDetails.getHeaderId())){
                duplicateLabelTemplateDetails = td ;
            }
        }
        
        return duplicateLabelTemplateDetails;
    }
    
    private TemplateDetails checkDuplicates( TemplateDetails templateDetails) throws ExistingRecordException {
        
           TemplateDetails duplicateTemplateDetails = null ;
           TemplateDetailsPk  pk = templateDetails.getPk() ;
           
           genericDAO.setClazz(TemplateDetails.class);
           duplicateTemplateDetails =  (TemplateDetails) genericDAO.findOne(pk) ;
           return duplicateTemplateDetails;
        }
    
    private void setPk(TemplateDetails templateDetails ){
        TemplateDetailsPk pk = new TemplateDetailsPk();
        pk.setHeaderId(templateDetails.getHeaderId());
        pk.setOffset(templateDetails.getSeqNo());
        
        templateDetails.setPk(pk);
    }
    
}
