package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.AlertCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertCode;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * AlertCode DAO class.
 * 
 */

@Repository
public class AlertCodeDAO extends GenericDAO<AlertCode> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertCodeDAO.class);
    /**
     * This method is used to search AlertCodes
     * @param alertCodeVal
     * @param descriptionVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */

    public Map<String, Object> searchAlertCodes(String alertCodeVal, String descriptionVal, int start, int limit) {

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Got the request to searchAlertCodes...Inside AlertCode DAO");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(AlertCode.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { alertCodeVal, descriptionVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchAlertCodes with alertCode: {} , description : {}", searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(alertCodeVal))  && alertCodeVal != null) {
            likeValue = "";
            String alertCode = likeValue.concat(percentage).concat(alertCodeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("alertCodePK", alertCode));
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Adding alertCode restrictions: {}", alertCode);
        }

        if (!("".equalsIgnoreCase(descriptionVal))  && descriptionVal != null) {
            likeValue = "";

            String description = likeValue.concat(percentage).concat(descriptionVal).concat(percentage);
            searchCriteria.add(Restrictions.like("description", description).ignoreCase());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Adding description restrictions: {}", description);

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<AlertCode> searchAlertCodes = (List<AlertCode>) searchCriteria.list();
        List<AlertCodeDTO> searchAlertCodesDtoList =  util.map(searchAlertCodes, AlertCodeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("data: {}", searchAlertCodesDtoList);
        LOGGER.debug("totalCount: {}", totalRecords);

        resultMap.put("data", searchAlertCodesDtoList);
        resultMap.put("totalCount", totalRecords);

        for (AlertCode alertCode : searchAlertCodes) {
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Got the value of alertCode from alertCodes: {}", alertCode.getAlertCodePK());

        }

        return resultMap;
    }
}
