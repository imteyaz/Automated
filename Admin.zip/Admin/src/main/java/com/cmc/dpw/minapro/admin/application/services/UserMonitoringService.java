package com.cmc.dpw.minapro.admin.application.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.RoleDAO;
import com.cmc.dpw.minapro.admin.application.dao.UserMonitoringDAO;
import com.cmc.dpw.minapro.admin.application.dto.RolesCheckBoxDTO;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;

/**
 * UserMonitoring Service
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class UserMonitoringService {

    @Autowired
    private UserMonitoringDAO userMonitoringDAO;
    @Autowired
    private RoleDAO roleDAO;

    private static final Logger LOGGER = LoggerFactory.getLogger(UserMonitoringService.class);

    /**
     * This method is used to get UserMonitoring List
     * 
     * @return List<T>
     */

    /**
     * This method is used to search UserMonitoring List
     * 
     * @param limit
     * @param start
     * @param roles
     * @param accountStatus
     * @param loginStatus
     * @param equipmentId
     * @param deviceId
     * @param userName
     * @param userId
     * @return Map<String, Object> containing the search UserMonitoring data and success indicator or the error message
     *         and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchUserMonitoringList(String userId, String userName, String deviceId,
            String equipmentId, String loginStatus, String accountStatus, String roles, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Entering UserMonitoring service's searchUserMonitoringList method");
        userMonitoringDAO.setClazz(User.class);

        String[] requestParameters = { userId, userName, deviceId, equipmentId, loginStatus, accountStatus, roles };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR, requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Exiting UserMonitoring service's searchUserMonitoringList method ");

        return userMonitoringDAO.searchUserMonitorings(userId, userName, deviceId, equipmentId, loginStatus,
                accountStatus, roles, start, limit);

    }

    /**
     * This method is used to get Roles
     * 
     * @return resultMap
     */
    @Transactional
    public Map<String, Object> getRoles() {
        roleDAO.setClazz(Role.class);
        List<Role> rolesList = roleDAO.findAll();
        List<RolesCheckBoxDTO> rolesCBList = new ArrayList<RolesCheckBoxDTO>();

        for (Role r : rolesList) {

            String grpId = (Integer.valueOf(r.getIntUserGroupId())).toString();

            RolesCheckBoxDTO roleCB = new RolesCheckBoxDTO();
            roleCB.setBoxLabel(r.getUserGroupName());
            roleCB.setInputValue(grpId);
            roleCB.setName("roles");

            rolesCBList.add(roleCB);
        }

        Map<String, Object> resultMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        resultMap.put(MessageConstants.DATA_KEY, rolesCBList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, rolesCBList.size());
        resultMap.put(MessageConstants.SUCCESS_KEY, true);
        return resultMap;
    }
   //tariq
    @Transactional
    public Map<String, Object> ClearCacheforcelogout() {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap = userMonitoringDAO.ClearCacheforcelogout();
       
        
        modelMap.put("deletedcount", modelMap.get("deletedcount"));

        return modelMap;
    }

}
