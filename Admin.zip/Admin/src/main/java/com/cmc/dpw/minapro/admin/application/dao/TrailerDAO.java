package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.TrailerDTO;
import com.cmc.dpw.minapro.admin.application.entities.Trailer;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Trailer DAO class.
 * @author Imran Rawani
 * @since 2016-June
 */
@Repository
public class TrailerDAO extends GenericDAO<Trailer> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(TrailerDAO.class);
    
    
    /**
     * This method is used to search Trailers
     * @param trailerNoVal
     * @param start
     * @param limit
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchTrailers(String trailerNoVal,int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Trailer DAO's searchTrailers method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(Trailer.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        Util.addRestrictions(searchCriteria, "trailerNo", trailerNoVal, false);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Trailer> searchTrailers = (List<Trailer>) searchCriteria.list();

        String totalRecords = count.toString();
        List<TrailerDTO> searchTrailersDtoList =  util.map(searchTrailers, TrailerDTO.class);
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"data from DB: {}", searchTrailersDtoList);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchTrailersDtoList);
        resultMap.put("totalCount", totalRecords);

        for (Trailer trailer : searchTrailers) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"trailer Id  : {}", trailer.getTrailerId());
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting trailerDAO's searchTrailers method ");
        return resultMap;
    }
}
