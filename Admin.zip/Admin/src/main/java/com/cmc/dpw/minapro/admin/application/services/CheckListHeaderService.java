package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.CheckListDAO;
import com.cmc.dpw.minapro.admin.application.dao.CheckListHeaderDAO;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dto.CheckListHeaderDTO;
import com.cmc.dpw.minapro.admin.application.entities.CheckList;
import com.cmc.dpw.minapro.admin.application.entities.CheckListHeader;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * CheckListHeader Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class CheckListHeaderService {

    @Autowired
    private CheckListHeaderDAO checkListHeaderDAO;
    @Autowired
    private CheckListDAO checkListDAO;
    @Autowired
    private GenericDAO genericDAO ;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListHeaderService.class);

    /**
     * This method is used to get CheckListHeader List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<CheckListHeader> getCheckListHeaderList() {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  CheckListHeader service's getCheckListHeaderList");
        checkListHeaderDAO.setClazz(CheckListHeader.class);
        return checkListHeaderDAO.findAll();
    }
    
    private void mapRoles(CheckListHeader header){
        
        List actualRoles = new ArrayList<Role>();
        String rolesList = header.getAllRoles();
        String[] rolesArray = rolesList.split(",");
        for (int i = 0; i < rolesArray.length; i++) {
            String roleNamme = rolesArray[i];
            genericDAO.setClazz(Role.class);
            List<Role> finalRolesList =  (List<Role>) genericDAO.findByPropertyValue(Role.class,"userGroupName",roleNamme,true);
            if(!finalRolesList.isEmpty()){
                Role role = (finalRolesList).get(0);
                actualRoles.add(role);
            }
        }
        header.setActualRoles(actualRoles);
        
    }
    
    /**
     * This method is used to search CheckListHeader List
     * @return Map<String, Object> containing the search CheckListHeader data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchCheckListHeaderList(String checkListHeaderId, String checkListHeaderName,
            String checkListHeaderType, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeader service's searchCheckListHeaderList method");
        checkListHeaderDAO.setClazz(CheckListHeader.class);

        String[] requestParameters = { checkListHeaderId, checkListHeaderName, checkListHeaderType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In CheckListHeader service searchCheckListHeaderList  with checkListHeaderId: {} , checkListHeaderName : {}, make : {}, model : {}, checkListHeaderTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeader service's searchCheckListHeaderList method");

        Map<String, Object> resultMap = checkListHeaderDAO.searchCheckListHeaders(checkListHeaderId, checkListHeaderName, checkListHeaderType,
                start, limit);

        
        List<CheckListHeader> searchCheckListHeaders = (List<CheckListHeader>) resultMap.get("data");
        resultMap.put("data", searchCheckListHeaders);
        return resultMap ;
    }

    /**
     * This method is used to create CheckListHeader
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<CheckListHeader>
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_HEADER_MASTER")
    public List<CheckListHeader> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeader service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  checkListHeader service's  create : {} ", data);

        List<CheckListHeader> newCheckListHeaders = new ArrayList<CheckListHeader>();
        List<CheckListHeader> list = util.getEntitiesFromDto(data,CheckListHeaderDTO.class, CheckListHeader.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (CheckListHeader checkListHeader : list) {

            Date currentDate = new Date();
            checkListHeader.setCreatedDateTime(currentDate);
            checkListHeader.setLastUpdatedDateTime(currentDate);
            checkListHeader.setCreatedBy(userId.toString());
            checkListHeader.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckListHeader Id property in checkListHeader service's create : {}",
                    checkListHeader.getCheckListHeaderId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling checkListHeader DAO findOne");
            Integer roleId = checkListHeader.getRoleId();
            String roleName = checkListHeader.getRoleName();
            mapRoles(checkListHeader);
            if(roleName.isEmpty() || roleName == null ){
                roleId = null ; 
            }
            CheckListHeader alreadyCheckListHeader = checkListHeaderDAO.findOne(checkListHeader.getCheckListHeaderId());
            
            if (alreadyCheckListHeader == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling checkListHeader DAO create");
                
                newCheckListHeaders.add(checkListHeaderDAO.create(checkListHeader));
                
            } else {
                char isDeleted = alreadyCheckListHeader.getIsDeleted();

                if (isDeleted == 'Y') {
                    checkListHeader.setVersion(alreadyCheckListHeader.getVersion());
                    checkListHeader.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling checkListHeader DAO update");
                    newCheckListHeaders.add(checkListHeaderDAO.update(checkListHeader));
                    mapRoles(checkListHeader);
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeader service's create method");
        return newCheckListHeaders;
    }

    /**
     * This method is used to update CheckListHeader
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<CheckListHeader>
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_HEADER_MASTER")
    public List<CheckListHeader> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeader service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  checkListHeader  service's  update : {} ", data);
        List<CheckListHeader> returnCheckListHeaders = new ArrayList<CheckListHeader>();

        List<CheckListHeader> updatedCheckListHeaders = util.getEntitiesFromDto(data,CheckListHeaderDTO.class, CheckListHeader.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (CheckListHeader checkListHeader : updatedCheckListHeaders) {
            Integer roleId = checkListHeader.getRoleId();
            String roleName = checkListHeader.getRoleName();
            if(roleName.isEmpty() || roleName == null ){
                roleId = null ; 
            }
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"checkListHeaderId property in checkListHeader service update : {}",
                    checkListHeader.getCheckListHeaderId());
            checkListHeader.setLastUpdatedDateTime(currentDate);
            checkListHeader.setLastUpdatedBy(userId.toString());
            mapRoles(checkListHeader);
            returnCheckListHeaders.add(checkListHeaderDAO.update(checkListHeader));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeader service's update method");
        return returnCheckListHeaders;
    }

    /**
     * This method is used to delete CheckListHeader
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_CHECKLIST_HEADER_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeader service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In checkListHeader's service delete : {} ", data);
       
        List<CheckListHeader> deletedCheckListHeaders = util.getEntitiesFromDto(data,CheckListHeaderDTO.class, CheckListHeader.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        boolean success = false;

        for (CheckListHeader checkListHeader : deletedCheckListHeaders) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckListHeader Id property in checkListHeader service delete : {}",
                    checkListHeader.getCheckListHeaderId());
            checkListHeader.setLastUpdatedDateTime(currentDate);
            checkListHeader.setLastUpdatedBy(userId.toString());
            checkListHeader.setIsDeleted('Y');
            checkListHeader.setActualRoles(null);
            checkListHeaderDAO.delete(checkListHeader);

            checkListDAO.setClazz(CheckList.class);
            success = checkListDAO.deleteByParentId(checkListHeader);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeader service's delete method");
    }
}
