package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cmc.dpw.minapro.admin.application.entities.Bay;
import com.cmc.dpw.minapro.admin.application.entities.BayRow;
import com.cmc.dpw.minapro.admin.application.entities.BayTier;
import com.cmc.dpw.minapro.admin.application.entities.Cell;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselSection;

@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("serial")
public class VesselDTO implements Serializable {
    
    private Vessel vesselInfo;
    private List<VesselSection> sectionList;
    private List<Bay> bayList;
    private List<BayRow> bayRowList;
    private List<BayTier> bayTierList;
    private List<Cell> cellList;
    private String result;

    public Vessel getVesselInfo() {
        return vesselInfo;
    }

    public void setVesselInfo(Vessel vesselInfo) {
        this.vesselInfo = vesselInfo;
    }

    public List<VesselSection> getSectionList() {
        return sectionList;
    }

    public void setSectionList(List<VesselSection> sectionList) {
        this.sectionList = sectionList;
    }

    public List<Bay> getBayList() {
        return bayList;
    }

    public void setBayList(List<Bay> bayList) {
        this.bayList = bayList;
    }

    public List<BayRow> getBayRowList() {
        return bayRowList;
    }

    public void setBayRowList(List<BayRow> bayRowList) {
        this.bayRowList = bayRowList;
    }

    public List<BayTier> getBayTierList() {
        return bayTierList;
    }

    public void setBayTierList(List<BayTier> bayTierList) {
        this.bayTierList = bayTierList;
    }

    public List<Cell> getCellList() {
        return cellList;
    }

    public void setCellList(List<Cell> cellList) {
        this.cellList = cellList;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

}
