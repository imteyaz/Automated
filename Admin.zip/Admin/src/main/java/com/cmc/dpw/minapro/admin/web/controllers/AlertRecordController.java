package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.AlertRecord;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.AlertRecordService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/alertRecord")
public class AlertRecordController {

    @Autowired
    private AlertRecordService alertRecordService;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRecordController.class);
    /**
     * This method searches for all the Alert Records matching the search criteria
     * as entered by the end user
     * @param Map<String,Object> columnValuePairs containing the column names as keys and their values as values in the map
     * @return  Map<String, Object> containing the data and success indicator.
     * 
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view( @RequestParam Map<String,Object> columnValuePairs)  {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertRecordController Search AlertRecord method");

        try {
            Map<String, Object> alertRecordsMap = alertRecordService.searchAlertRecordList(columnValuePairs);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRecordController Search AlertRecord method");
            return getMap(alertRecordsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Exception-->Search", e);
            return getModelMapError("Error retrieving AlertRecords from database.");
        }
    }

    
    /**
     * This method updates the Alert Record as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<AlertRecord> containing the updated Alert Record data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertRecordController Update AlertRecord method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            List<AlertRecord> updatedAlertRecords = alertRecordService.update(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRecordController Update AlertRecord method");

            return getMap(updatedAlertRecords);

        } catch (ExistingRecordException e){

            LOGGER.error(MessageConstants.ERROR_INDICATOR + MessageConstants.EXISTING_RECORD_EXCEPTION, e);
            return getModelMapError(MessageConstants.UPDATE_ROTATIONCONTROL + e.getCustomErrorMessage());
            
            
        }   catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update :{}", e);
            return getModelMapError(MessageConstants.UPDATE_ROTATIONCONTROL);
        }
    }
    
    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> containing the rotation data and success indicator or
     * the error message and failure indicator.
     */
    private Map<String, Object> getMap(List<AlertRecord> alertRecords) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, alertRecords);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> alertRecordsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) alertRecordsMap.get("totalCount");

        List<AlertRecord> alertRecords = (List<AlertRecord>) alertRecordsMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , alertRecords);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, alertRecords);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
