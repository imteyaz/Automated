package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DamageLocationDAO;
import com.cmc.dpw.minapro.admin.application.dto.DamageLocationDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageLocation;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * DamageLocation Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class DamageLocationService {

    @Autowired
    private DamageLocationDAO damageLocationDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageLocationService.class);

    /**
     * This method is used to read DamageLocation
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<DamageLocation> getDamageLocationList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  DamageLocation service's getDamageLocationList");
        damageLocationDAO.setClazz(DamageLocation.class);
        return damageLocationDAO.findAll();

    }

    /**
     * This method is used to read DamageLocation
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDamageLocationList(String damageLocationId, String damageLocationName, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageLocation service's searchDamageLocationList method");
        damageLocationDAO.setClazz(DamageLocation.class);

        String[] requestParameters = { damageLocationId, damageLocationName };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In DamageLocation service searchDamageLocationList  with damageLocationId: {} , damageLocationName : {}, make : {}, model : {}, damageLocationTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocation service's searchDamageLocationList method");

        return damageLocationDAO.searchDamageLocations(damageLocationId, damageLocationName, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageLocation> containing the created DamageLocation data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_LOCATION")
    public List<DamageLocation> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageLocation service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageLocation service's  create : {} ", data);

        List<DamageLocation> newDamageLocations = new ArrayList<DamageLocation>();
        
        List<DamageLocation> list = util.getEntitiesFromDto(data,DamageLocationDTO.class, DamageLocation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageLocation damageLocation : list) {

            Date currentDate = new Date();
            damageLocation.setCreatedDateTime(currentDate);
            damageLocation.setLastUpdatedDateTime(currentDate);
            damageLocation.setCreatedBy(userId.toString());
            damageLocation.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageLocation Id property in damageLocation service's create : {}",
                    damageLocation.getDamageLocationId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageLocation DAO findOne");

            DamageLocation alreadyDamageLocation = damageLocationDAO.findOne(damageLocation.getDamageLocationId());

            if (alreadyDamageLocation == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageLocation DAO create");
                newDamageLocations.add(damageLocationDAO.create(damageLocation));
            } else {
                char isDeleted = alreadyDamageLocation.getIsDeleted();

                if (isDeleted == 'Y') {
                    damageLocation.setVersion(alreadyDamageLocation.getVersion());
                    damageLocation.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageLocation DAO update");
                    newDamageLocations.add(damageLocationDAO.update(damageLocation));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocation service's create method");
        return newDamageLocations;
    }

    /**
     * This method is used to update DamageLocation
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageLocation> containing the updated DamageLocation datas
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_LOCATION")
    public List<DamageLocation> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageLocation service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageLocation  service's  update : {} ", data);
        List<DamageLocation> returnDamageLocations = new ArrayList<DamageLocation>();

        List<DamageLocation> updatedDamageLocations = util.getEntitiesFromDto(data,DamageLocationDTO.class, DamageLocation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageLocation damageLocation : updatedDamageLocations) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageLocationId property in damageLocation service update : {}", damageLocation.getDamageLocationId());
            damageLocation.setLastUpdatedDateTime(currentDate);
            damageLocation.setLastUpdatedBy(userId.toString());
            returnDamageLocations.add(damageLocationDAO.update(damageLocation));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocation service's update method");

        return returnDamageLocations;
    }

    /**
     * This method is used to delete DamageLocation
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_LOCATION")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageLocation service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In damageLocation's service delete : {} ", data);
        
        List<DamageLocation> deletedDamageLocations = util.getEntitiesFromDto(data,DamageLocationDTO.class, DamageLocation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageLocation damageLocation : deletedDamageLocations) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageLocation Id property in damageLocation service delete : {}",
                    damageLocation.getDamageLocationId());
            damageLocation.setLastUpdatedDateTime(currentDate);
            damageLocation.setLastUpdatedBy(userId.toString());
            damageLocation.setIsDeleted('Y');
            damageLocationDAO.delete(damageLocation);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocation service's delete method");
    }

}
