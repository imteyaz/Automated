package com.cmc.dpw.minapro.admin.application.opus.entities;

public class OpusEquipmentDto {

    private String equipmentId;

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    
    
}
