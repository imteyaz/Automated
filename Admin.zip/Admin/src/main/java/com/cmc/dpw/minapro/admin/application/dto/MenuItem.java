package com.cmc.dpw.minapro.admin.application.dto;

import java.util.List;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
/**
 * MenuItem POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
public class MenuItem {
    private String menuId;
    private String name;
    private String iconCls;
    private String handler;
    private String parentMenuId;
    private String accessCode;
    private String userId;
    private String serviceType;
    private List<MenuItem> list;
    private Integer sortOrder;

    public MenuItem() {
        super();
    }

    public MenuItem(String menuId) {
        super();
        this.menuId = menuId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = MessageConstants.THIRITY_ONE;
        int result = MessageConstants.ARRAY_ONE;
        result = prime * result + ((menuId == null) ? 0 : menuId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
       
        MenuItem other = (MenuItem) obj;
        if (menuId == null && other.menuId != null || !menuId.equals(other.menuId) ){
                return false;
        } 
        return true;
        
    }

    public List<MenuItem> getList() {
        return list;
    }

    public void setList(List<MenuItem> list) {
        this.list = list;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIconCls() {
        return iconCls;
    }

    public void setIconCls(String iconCls) {
        this.iconCls = iconCls;
    }

    public String getHandler() {
        return handler;
    }

    public void setHandler(String handler) {
        this.handler = handler;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getParentMenuId() {
        return parentMenuId;
    }

    public void setParentMenuId(String parentMenuId) {
        this.parentMenuId = parentMenuId;
    }

    public String getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
}
