package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Composite primary key to identify the tiers in a bay of the vessel
 * 
 * @author Rosemary George
 * 
 */
@Embeddable
public class BayTierPk implements Serializable {

    private static final long serialVersionUID = 6968804940240435997L;

    @Column(name = "INT_VSL_NO")
    private int vesselNo;

    @Column(name = "DK_UNDK_IND")
    private String deckUnderDeck;

    @Column(name = "BAY_OFFSET")
    private int bayOffset;

    @Column(name = "INT_SECT_NO")
    private int sectionNo;

    @Column(name = "TIER_OFFSET")
    private int tierOffset;

    public int getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(int vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getDeckUnderDeck() {
        return deckUnderDeck;
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        this.deckUnderDeck = deckUnderDeck;
    }

    public int getBayOffset() {
        return bayOffset;
    }

    public void setBayOffset(int bayOffset) {
        this.bayOffset = bayOffset;
    }

    public int getSectionNo() {
        return sectionNo;
    }

    public void setSectionNo(int sectionNo) {
        this.sectionNo = sectionNo;
    }

    public int getTierOffset() {
        return tierOffset;
    }

    public void setTierOffset(int tierOffset) {
        this.tierOffset = tierOffset;
    }
}
