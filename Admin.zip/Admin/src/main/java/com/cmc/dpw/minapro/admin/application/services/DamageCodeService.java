package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DamageCodeDAO;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dto.DamageCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageCode;
import com.cmc.dpw.minapro.admin.application.entities.DamageLocation;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * DamageCode Service
 *@author Imran Rawani
 *@since 2014-Dec 
 * 
 */
@Service
public class DamageCodeService {

    @Autowired
    private DamageCodeDAO damageCodeDAO;
    @Autowired
    private GenericDAO genericDAO ;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageCodeService.class);

    /**
     * This method is used to read DamageCode
     * @return List<T> 
     */
    @Transactional(readOnly = true)
    public List<DamageCode> getDamageCodeList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  DamageCode service's getDamageCodeList");
        damageCodeDAO.setClazz(DamageCode.class);
        return damageCodeDAO.findAll();

    }

    /**
     * This method is used to read DamageCode 
     * @param damageLocationCode 
     * @param damageTypeCode 
     *@return Map<String, Object> containing the search DamageCode data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDamageCodeList(String damageCode, String damageSeverityCode, String damageTypeCode, String damageLocationCode, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCode service's searchDamageCodeList method");
        damageCodeDAO.setClazz(DamageCode.class);

        String[] requestParameters = { damageCode, damageSeverityCode };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In DamageCode service searchDamageCodeswith damageCode: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCode service's searchDamageCodeList method");
        return damageCodeDAO.searchDamageCodes(damageCode, damageSeverityCode,damageTypeCode, damageLocationCode, start, limit);

    }

    /**
     * This method is used to create DamageCode 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<DamageCode> containing the created DamageCode data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGECODE_MASTER")
    public List<DamageCode> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCode service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageCode service's  create : {} ", data);
        List<DamageCode> newDamageCodes = new ArrayList<DamageCode>();

        List<DamageCode> list = util.getEntitiesFromDto(data,DamageCodeDTO.class, DamageCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (DamageCode damageCode : list) {
            Date currentDate = new Date();

            damageCode.setCreatedDateTime(currentDate);
            damageCode.setLastUpdatedDateTime(currentDate);
            damageCode.setCreatedBy(userId.toString());
            damageCode.setLastUpdatedBy(userId.toString());
            mapDamageLocations(damageCode);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageCode property in damageCode service create : {}",
                    damageCode.getDamageCodePk());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling equipment DAO findOne");

            DamageCode alreadyDamageCode = damageCodeDAO.findOne(damageCode.getDamageCodePk());

            if (alreadyDamageCode == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageCode DAO create");
                newDamageCodes.add(damageCodeDAO.create(damageCode));
            } else {

                char isDeleted = alreadyDamageCode.getIsDeleted();

                if (isDeleted == 'Y') {
                    damageCode.setVersion(alreadyDamageCode.getVersion());
                    damageCode.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageCode DAO update");
                    newDamageCodes.add(damageCodeDAO.update(damageCode));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting damageCode service's create method");
        return newDamageCodes;
    }

    /**
     * This method is used to update DamageCode 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<DamageCode> containing the updated DamageCode data
     *
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGECODE_MASTER")
    public List<DamageCode> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCode service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageCode  service's  update : {} ", data);
        List<DamageCode> returnDamageCodes = new ArrayList<DamageCode>();
        
        List<DamageCode> updatedDamageCodes = util.getEntitiesFromDto(data,DamageCodeDTO.class, DamageCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageCode damageCode : updatedDamageCodes) {
            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageCode property in damageCode service update : {}",
                    damageCode.getDamageCodePk());
            damageCode.setLastUpdatedDateTime(currentDate);
            damageCode.setLastUpdatedBy(userId.toString());
            mapDamageLocations(damageCode);
            returnDamageCodes.add(damageCodeDAO.update(damageCode));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCode service's update method");
        return returnDamageCodes;
    }
    
private void mapDamageLocations(DamageCode damageCode){
        
        List actualLocations = new ArrayList<DamageLocation>();
        String locationsList = damageCode.getAllDamageLocations();
        String[] locationsArray = locationsList.split(",");
        for (int i = 0; i < locationsArray.length; i++) {
            String locationNamme = locationsArray[i];
            genericDAO.setClazz(DamageLocation.class);
            List<DamageLocation> finalLocationsList =  (List<DamageLocation>) genericDAO.findByPropertyValue(DamageLocation.class,"damageLocationId",locationNamme,true);
            if(!finalLocationsList.isEmpty()){
                DamageLocation damageLocation = (finalLocationsList).get(0);
                actualLocations.add(damageLocation);
            }
        }
        damageCode.setActualDamageLocations(actualLocations);
        
    }

    /**
     * This method is used to delete DamageCode 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGECODE_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCode service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In damageCode's service delete : {} ", data);

        List<DamageCode> deletedDamageCodes = util.getEntitiesFromDto(data,DamageCodeDTO.class, DamageCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageCode damageCode : deletedDamageCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageCode property in damageCode service delete : {}",
                    damageCode.getDamageCodePk());
            damageCode.setLastUpdatedDateTime(currentDate);
            damageCode.setLastUpdatedBy(userId.toString());
            damageCode.setIsDeleted('Y');
            damageCode.setActualDamageLocations(null);
            damageCodeDAO.delete(damageCode);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCode service's delete method");
    }

}
