package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * AlertRemarks POJO
 * @author Imran Rawani
 * @since 2016-Aug
 */

@Entity(name = "AlertRemarks")
@Table(name = "MP_ALERT_REMARKS")
public class AlertRemarks implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRemarkId;
    private Integer alertRecordId;
    private String remarks;
    private Integer createdBy ;
    private Date createdDateTime;
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "alertRemarksSequence")
    @SequenceGenerator(name = "alertRemarksSequence", sequenceName = "MP_ALERT_REMARKS_SEQ", allocationSize = 1, initialValue = 8)
   
    @Column(name = "ALERT_REMARK_ID", nullable = false)
    public Integer getAlertRemarkId() {
        return alertRemarkId;
    }
    public void setAlertRemarkId(Integer alertRemarkId) {
        this.alertRemarkId = alertRemarkId;
    }
    
    @Column(name = "ALERT_RECORD_ID", nullable = false)
    public Integer getAlertRecordId() {
        return alertRecordId;
    }
    public void setAlertRecordId(Integer alertRecordId) {
        this.alertRecordId = alertRecordId;
    }
    
    @Column(name = "REMARKS", nullable = false)
    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    @Column(name = "CREATED_BY", nullable = false)
    public Integer getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
    
    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    

   
    
    
    
    
    
   

    


}
