package com.cmc.dpw.minapro.admin.application.services;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dao.RollbackRotationDAO;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Vessel Service
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class RollbackRotationService {

	@Autowired
	private RollbackRotationDAO rollbackRotationDAO;
	@Autowired
	private GenericDAO genericDAO;
	@Autowired
	private Util util;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RollbackRotationService.class);
	Map<String, Object> modelMap = new HashMap<String, Object>(
			MessageConstants.HASH_LENGTH_THREE);

	@Transactional
	public Map<String, Object> rollbackRotation(String rotation) {
		modelMap = rollbackRotationDAO.rollbackRotation(rotation);
		modelMap.put("deletedcount", modelMap.get("deletedcount"));

		return modelMap;
	}

}
