package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("serial")
public class GroupDTO implements Serializable {
    /**
     * 
     */
    private Integer groupId;
    private String groupName;
    private String groupCode;
    private String groupDesc;
    private String serviceType;
    private Integer userId;
    private String defaultGroupFlag;
    private String systemDefined ;
    private List<GroupDTO> groupList;
    private List<GenericGroupAssociationDTO> groupUserList;
    private List<GenericGroupAssociationDTO> moduleList;
    private List<GenericGroupAssociationDTO> removedList;
    private Integer result;
    private String serviceTypeCode;
    private String serviceTypeDesc;
    private String action;
    private String copyGroupId;

    public List<GroupDTO> getGroupList() {
        return groupList;
    }

    public void setGroupList(List<GroupDTO> groupList) {
        this.groupList = groupList;
    }

    public List<GenericGroupAssociationDTO> getGroupUserList() {
        return groupUserList;
    }

    public void setGroupUserList(List<GenericGroupAssociationDTO> groupUserList) {
        this.groupUserList = groupUserList;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getDefaultGroupFlag() {
        return defaultGroupFlag;
    }

    public void setDefaultGroupFlag(String defaultGroupFlag) {
        this.defaultGroupFlag = defaultGroupFlag;
    }

    public String getServiceTypeCode() {
        return serviceTypeCode;
    }

    public void setServiceTypeCode(String serviceTypeCode) {
        this.serviceTypeCode = serviceTypeCode;
    }

    public String getServiceTypeDesc() {
        return serviceTypeDesc;
    }

    public void setServiceTypeDesc(String serviceTypeDesc) {
        this.serviceTypeDesc = serviceTypeDesc;
    }

    public List<GenericGroupAssociationDTO> getModuleList() {
        return moduleList;
    }

    public void setModuleList(List<GenericGroupAssociationDTO> moduleList) {
        this.moduleList = moduleList;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getCopyGroupId() {
        return copyGroupId;
    }

    public void setCopyGroupId(String copyGroupId) {
        this.copyGroupId = copyGroupId;
    }

    public List<GenericGroupAssociationDTO> getRemovedList() {
        return removedList;
    }

    public void setRemovedList(List<GenericGroupAssociationDTO> removedList) {
        this.removedList = removedList;
    }

    public String getSystemDefined() {
        return systemDefined;
    }

    public void setSystemDefined(String systemDefined) {
        this.systemDefined = systemDefined;
    }

    
}
