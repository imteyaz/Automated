package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * AlertRemarks POJO
 * @author Imran Rawani
 * @since 2016-Aug
 */

public class AlertRemarksDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRemarkId;
    private Integer alertRecordId;
    private String remarks;
    private Integer createdBy ;
    private Date createdDateTime;
    
    
    public Integer getAlertRemarkId() {
        return alertRemarkId;
    }
    public void setAlertRemarkId(Integer alertRemarkId) {
        this.alertRemarkId = alertRemarkId;
    }
    public Integer getAlertRecordId() {
        return alertRecordId;
    }
    public void setAlertRecordId(Integer alertRecordId) {
        this.alertRecordId = alertRecordId;
    }
    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    public Integer getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
    public Date getCreatedDateTime() {
        return createdDateTime;
    }
    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }
    
   

}
