package com.cmc.dpw.minapro.admin.application.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.dto.MenuItem;
/**
 * CommonsDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class CommonsDAO extends GenericDAO {
    /**
     * This method is used to createMenuList
     * @return (List<MenuItem>) menuCriteria.list()
     */
    public List<MenuItem> createMenuList(String userId) throws SQLException {
        
        Session session = getCurrentSession();

        String sql = "select" + " fam.function_cd menuId ," + " fam.FUNCTION_DESCR  name, " + " fam.icon_cls iconCls, "
                + " fam.menu_position_cd sortOrder, " + " fam.exe_nm handler, " + " fta.module_cd parentMenuId, "
                + " min(fga.menu_cd) accessCode, " + " ua.int_user_id userId, " + " fam.srv_type_grp_cd  serviceType"
                + " from mp_functiondescr_am fam,MP_FUNCTIONTREE_A " + " FTA,mp_functiongrpaccess_a "
                + " fga,MP_USERGRP_A ua,mp_grpdtls_am ga" + " WHERE " + " fam.function_cd = fta.function_cd "
                + " AND fam.show_flg=\'Y\' " + " AND fam.function_cd = fga.function_cd "
                + " and fga.int_user_grp_id = " + " ua.int_user_grp_id " + " and ua.int_user_id = "
                + Integer.parseInt(userId)
                + " and ua.int_user_grp_id "
                + " = ga.int_user_grp_id "
                + " group by fam.function_cd, "
                + " fam.FUNCTION_DESCR, "
                + " fam.icon_cls, "
                + " fam.menu_position_cd, "
                + " fam.exe_nm, "
                + " fta.module_cd, "
                + " ua.int_user_id, "
                + " fam.srv_type_grp_cd "
                +

                " UNION "
                + " select "
                + " distinct "
                + " ma.child_module_cd menuId, "
                + " (select ab.module_nm "
                + " from "
                + " mp_moduledescr_am ab "
                + " where ab.module_cd = ma.child_module_cd) name, "
                + " (select ab.icon_cls "
                + " from "
                + " mp_moduledescr_am ab "
                + " where ab.module_cd = "
                + " ma.child_module_cd) iconCls, "
                + " (select ab.MENU_POSITION_CD "
                + " from "
                + " mp_moduledescr_am ab "
                + " where ab.module_cd = "
                + " ma.child_module_cd) sortOrder, "
                + " NULL handler, "
                + " DECODE(ma.parent_module_cd,\'FAPSB\',NULL,ma.parent_module_cd) "
                + " parent_id, "
                + " NULL accessCode, "
                + " NULL userId, "
                + " NULL serviceType "
                + " from "
                + " mp_moduletree_a ma "
                + " WHERE ma.show_flg=\'Y\' "
                + " start with "
                + " ma.child_module_cd "
                + " "
                + " in (select "
                + " "
                + " DISTINCT "
                + " "
                + " fta.module_cd "
                + " "
                + " from mp_functiondescr_am "
                + " fam,MP_FUNCTIONTREE_A "
                + " FTA,mp_functiongrpaccess_a "
                + " fga,MP_USERGRP_A ua,mp_grpdtls_am "
                + " ga "
                + " "
                + " WHERE "
                + " fam.function_cd = fta.function_cd "
                + " "
                + " AND fam.function_cd = "
                + " fga.function_cd "
                + "  "
                + " and fga.int_user_grp_id = ua.int_user_grp_id "
                + " "
                + " and "
                + " ua.int_user_id = "
                + Integer.parseInt(userId)
                + " "
                + " and ua.int_user_grp_id = ga.int_user_grp_id) "
                + " "
                + " connect by prior "
                + " ma.parent_module_cd = ma.child_module_cd";

        SQLQuery query = session.createSQLQuery(sql).addScalar("menuId", new StringType())
                .addScalar("name", new StringType()).addScalar("iconCls", new StringType())
                .addScalar("sortOrder", new IntegerType()).addScalar("handler", new StringType())
                .addScalar("parentMenuId", new StringType()).addScalar("accessCode", new StringType())
                .addScalar("userId", new StringType()).addScalar("serviceType", new StringType());

        Query menuCriteria = (Query) query.setResultTransformer(Transformers.aliasToBean(MenuItem.class));

        return (List<MenuItem>) menuCriteria.list();

    }

}
