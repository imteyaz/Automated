package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.CheckListHeader;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.CheckListHeaderService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/checkListHeader")
public class CheckListHeaderController {

    @Autowired
    private CheckListHeaderService checkListHeaderService;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListHeaderController.class);
/**
 * This method searches for all the checkListHeaders matching the search criteria
 * as entered by the end user
 * @param checkListHeaderId
 * @param name
 * @param type
 * @param start
 * @param limit
 * @return Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/view.action")
    @ResponseBody
    public Map<String, Object> view(@RequestParam(required = false) String checkListHeaderId,
            @RequestParam(required = false) String name, @RequestParam(required = false) String type,
            @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckListHeaderController Seacrh CheckListHeader method");

        String[] requestParameters = { checkListHeaderId, name, type };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR +"CheckListHeaderController-->Seacrh checkListHeaderId :{}, name:{}, type:{} ",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeaderController Seacrh CheckListHeader method");

            Map<String, Object> checkListHeadersMap = checkListHeaderService.searchCheckListHeaderList(
                    checkListHeaderId, name, type, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeaderController Seacrh CheckListHeader method");
            return getMap(checkListHeadersMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            return getModelMapError("Error retrieving CheckListHeaders from database.");
        }
    }
    
    /**
     * This method creates the CheckListHeader as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody
    public Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckListHeaderController Create CheckListHeader method");
        LOGGER.debug( MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);

        try {
            List<CheckListHeader> checkListHeaders = checkListHeaderService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeaderController Create CheckListHeader method");
            return getMap(checkListHeaders);

        } catch (DataIntegrityViolationException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create checkListHeader due to following exception :{}" + cause.getMessage());
            
        } catch (ExistingRecordException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create checkListHeader :{}" + e.getCustomErrorMessage());

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create checkListHeader.");
        }
    }
    
    /**
     * This method updates the CheckListHeader as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/update.action")
    @ResponseBody
    public Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckListHeaderController Update CheckListHeader method");
        LOGGER.debug( MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {
            List<CheckListHeader> checkListHeaders = checkListHeaderService.update(data, principal);
            return getMap(checkListHeaders);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update checkListHeader. ");
        }
    }

    /**
     * This method deletes the CheckListHeader.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody
    public Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckListHeaderController Delete CheckListHeader method");
        LOGGER.debug( MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            checkListHeaderService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckListHeaderController Delete CheckListHeader method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete checkListHeader.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<CheckListHeader> checkListHeaders) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, checkListHeaders);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> checkListHeadersMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) checkListHeadersMap.get("totalCount");

        List<CheckListHeader> checkListHeaders = (List<CheckListHeader>) checkListHeadersMap.get("data");

        LOGGER.debug( MessageConstants.DEBUG_INDICATOR +"CheckListHeaderController --> getMap --> totalRecords :{} ", totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"CheckListHeaderController --> getMap --> checkListHeaders List  :{} ", checkListHeaders);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, checkListHeaders);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
