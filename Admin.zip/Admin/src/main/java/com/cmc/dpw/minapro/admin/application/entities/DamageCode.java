package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
/**
 * DamageCode POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "DamageCode")
@Table(name = "MP_DAMAGECODE_MASTER")
public class DamageCode extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageCodePk;
    private String description;
    private String damageSeverityCode;
    private String terminalId;
    private String damageTypeId;
    private String damageLocationId;
    private String allDamageLocations;
    private Collection<DamageLocation> actualDamageLocations;
    
    @Transient
    public String getDamageLocationId() {
        return damageLocationId;
    }

    public void setDamageLocationId(String damageLocationId) {
        this.damageLocationId = damageLocationId;
    }

    @Transient
    public String getAllDamageLocations() {
        return allDamageLocations;
    }

    public void setAllDamageLocations(String allDamageLocations) {
        this.allDamageLocations = allDamageLocations;
    }

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MP_DAMAGECODE_LOCATION_LINK", joinColumns = @JoinColumn(name = "DAMAGE_CODE"), inverseJoinColumns = @JoinColumn(name = "DAMAGE_LOCATION"))
    public Collection<DamageLocation> getActualDamageLocations() {
        return actualDamageLocations;
    }

    public void setActualDamageLocations(Collection<DamageLocation> actualDamageLocations) {
        this.actualDamageLocations = actualDamageLocations;
    }

    @Id
    @Column(name = "DAMAGE_CODE", nullable = false)
    public String getDamageCodePk() {
        return damageCodePk;
    }

    public void setDamageCodePk(String damageCodePk) {
        this.damageCodePk = damageCodePk;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "DAMAGE_SEVERITY_CODE", nullable = false)
    public String getDamageSeverityCode() {
        return damageSeverityCode;
    }

    public void setDamageSeverityCode(String damageSeverityCode) {
        this.damageSeverityCode = damageSeverityCode;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    
    @Column(name = "DAMAGE_TYPE_CODE", nullable = false)
    public String getDamageTypeId() {
        return damageTypeId;
    }

    public void setDamageTypeId(String damageTypeId) {
        this.damageTypeId = damageTypeId;
    }

}
