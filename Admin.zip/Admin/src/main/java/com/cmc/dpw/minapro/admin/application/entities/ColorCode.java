package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ColorCode POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "ColorCode")
@Table(name = "MP_COLOUR_CODE_MASTER")
public class ColorCode extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String colorCodeId;
    private String itemName;
    private String itemGroup;
    private String hexaCode;

    @Id
    @Column(name = "COLOUR_CODE_ID", nullable = false)
    public String getColorCodeId() {
        return colorCodeId;
    }

    public void setColorCodeId(String colorCodeId) {
        this.colorCodeId = colorCodeId;
    }

    @Column(name = "ITEM_NAME", nullable = false)
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Column(name = "ITEM_GROUP", nullable = false)
    public String getItemGroup() {
        return itemGroup;
    }

    public void setItemGroup(String itemGroup) {
        this.itemGroup = itemGroup;
    }

    @Column(name = "HEXA_CODE", nullable = false)
    public String getHexaCode() {
        return hexaCode;
    }

    public void setHexaCode(String hexaCode) {
        this.hexaCode = hexaCode;
    }

}
