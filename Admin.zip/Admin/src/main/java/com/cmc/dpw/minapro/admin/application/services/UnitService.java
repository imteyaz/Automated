package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.UnitDAO;
import com.cmc.dpw.minapro.admin.application.dto.UnitDTO;
import com.cmc.dpw.minapro.admin.application.entities.Unit;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * Unit Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class UnitService {

    @Autowired
    private UnitDAO unitDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(UnitService.class);

    /**
     * This method is used to get Unit List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Unit> getUnitList() {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Unit service's getUnitList");
        unitDAO.setClazz(Unit.class);
        return unitDAO.findAll();
    }

    /**
     * This method is used to search Unit List
     * @return Map<String, Object> containing the search Unit data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchUnitList(String unitId, String description, int start, int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Unit service's searchUnitList method");
        unitDAO.setClazz(Unit.class);

        String[] requestParameters = { unitId, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In Unit service searchActivityCodeswith unitId: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Unit service's searchUnitList method");
        return unitDAO.searchUnits(unitId, description, start, limit);

    }

    /**
     * This method is used to create Unit
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Unit> containing created Unit data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_UNIT_MASTER")
    public List<Unit> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Unit service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  unit service's  create : {} ", data);

        List<Unit> newUnits = new ArrayList<Unit>();
        List<Unit> list = util.getEntitiesFromDto(data, UnitDTO.class, Unit.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Unit unit : list) {

            Date currentDate = new Date();

            unit.setCreatedDateTime(currentDate);
            unit.setLastUpdatedDateTime(currentDate);
            unit.setCreatedBy(userId.toString());
            unit.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"unitId property in unit service create : {}", unit.getUnitId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling unit DAO findOne");

            Unit alreadyUnit = unitDAO.findOne(unit.getUnitId());

            if (alreadyUnit == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling unit DAO create");
                newUnits.add(unitDAO.create(unit));
            } else {

                char isDeleted = alreadyUnit.getIsDeleted();

                if (isDeleted == 'Y') {
                    unit.setVersion(alreadyUnit.getVersion());
                    unit.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"calling unit DAO update");
                    newUnits.add(unitDAO.update(unit));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }

                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Unit service's create method");
        return newUnits;
    }

    /**
     * This method is used to update Unit 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<Unit> containing updated Unit data
     */
    @Transactional
    @Manipulate(table = "MP_UNIT_MASTER")
    public List<Unit> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Unit service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  unit  service's  update : {} ", data);

        List<Unit> returnUnits = new ArrayList<Unit>();

        List<Unit> updatedUnits = util.getEntitiesFromDto(data, UnitDTO.class, Unit.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Unit unit : updatedUnits) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"unitId property in unit service update : {}", unit.getUnitId());
            unit.setLastUpdatedDateTime(currentDate);
            unit.setLastUpdatedBy(userId.toString());
            returnUnits.add(unitDAO.update(unit));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Unit service's update method");
        return returnUnits;
    }

    /**
     * This method is used to delete Unit
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_UNIT_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Unit service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In unit's service delete : {} ", data);

        List<Unit> deletedUnits = util.getEntitiesFromDto(data, UnitDTO.class, Unit.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Unit unit : deletedUnits) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"unitId property in unit service delete : {}", unit.getUnitId());
            unit.setLastUpdatedDateTime(currentDate);
            unit.setLastUpdatedBy(userId.toString());
            unit.setIsDeleted('Y');
            unitDAO.delete(unit);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Unit service's delete method");
    }

}
