package com.cmc.dpw.minapro.admin.application.services;

import java.io.Serializable;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.EquipmentDAO;
import com.cmc.dpw.minapro.admin.application.dao.RotationControlDAO;
import com.cmc.dpw.minapro.admin.application.dao.VesselDAO;
import com.cmc.dpw.minapro.admin.application.dto.RotationControlDTO;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.entities.RotationControl;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
import com.minapro.procserver.events.common.VesselBerthEvent;
import com.minapro.procserver.events.common.VesselSailEvent;

/**
 * RotationControl Service
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class RotationControlService {

    @Autowired
    private RotationControlDAO rotationControlDAO;
    @Autowired
    private EquipmentDAO equipmentDAO;
    @Autowired
    private VesselDAO vesselDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(RotationControlService.class);

    /**
     * This method is used to get RotationControl List
     * 
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<RotationControl> getRotationControlList() {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Entering  RotationControl service's getRotationControlList");
        rotationControlDAO.setClazz(RotationControl.class);
        return rotationControlDAO.findAll();

    }

    /**
     * This method is used to search RotationControl List
     * 
     * @return Map<String, Object> containing the search RotationControl data and success indicator or the error message
     *         and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchRotationControlList(String rotationNumber, String equipmentId, String vesselCode,
            String etaDateFrom, String etaTimeFrom, String etaDateTo, String etaTimeTo, String active, int start,
            int limit, String berthNo, String terminalId) {

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Entering RotationControl service's searchRotationControlList method");
        rotationControlDAO.setClazz(RotationControl.class);

        String[] requestParameters = { rotationNumber, equipmentId, vesselCode, etaDateFrom, active };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR
                        + "In RotationControl service searchRotationControlList  with rotationNumber: {} , equipmentId : {}, vesselCode : {}, etaDate : {}, active : {}",
                requestParameters);

        String defaultFromTime = "00:00";
        String defaultToTime = "23:59";
        Date parsedFromDate = null;
        Date parsedToDate = null;
        if (!"".equalsIgnoreCase(etaDateFrom) && etaDateFrom != null) {
            String appendedFromDate = util.appendDateTime(etaDateFrom, etaTimeFrom, defaultFromTime);
            parsedFromDate = util.getParsedDateFromString(MessageConstants.DATE_TIME_FORMAT, appendedFromDate);
            LOGGER.debug("parsedFromDate :" + parsedFromDate);
        } else {
            parsedFromDate = null;
        }

        if (!"".equalsIgnoreCase(etaDateTo) && etaDateTo != null) {
            String appendedToDate = util.appendDateTime(etaDateTo, etaTimeTo, defaultToTime);
            parsedToDate = util.getParsedDateFromString(MessageConstants.DATE_TIME_FORMAT, appendedToDate);
            LOGGER.debug("parsedToDate :" + parsedToDate);
        } else {
            parsedToDate = null;
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Exiting RotationControl service's searchRotationControlList method");
        return rotationControlDAO.searchRotationControls(rotationNumber, equipmentId, vesselCode, parsedFromDate,
                parsedToDate, active, start, limit, berthNo, terminalId);
    }

    /**
     * This method is used to create RotationControlList
     * 
     * @param data
     *            The json data coming from the UI
     * @param principal
     *            The java.security.Principal containing logged in user details
     * @return List<RotationControl> containing created Rotation data
     * @throws ExistingRecordException
     */
    @Transactional
    public List<RotationControl> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info("Entering RotationControl service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "In  rotationControl service's  create : {} ", data);

        List<RotationControl> newRotationControls = new ArrayList<RotationControl>();

        List<RotationControl> list = util.getEntitiesFromDto(data, RotationControlDTO.class, RotationControl.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        rotationControlDAO.setClazz(RotationControl.class);

        for (RotationControl rotationControl : list) {

            Date currentDate = new Date();
            rotationControl.setCreatedDateTime(currentDate);
            rotationControl.setLastUpdatedDateTime(currentDate);
            rotationControl.setCreatedBy(userId.toString());
            rotationControl.setLastUpdatedBy(userId.toString());
            rotationControl.setIsDeleted('N');
            RotationControl alreadyRotationControl = checkDuplicates(rotationControl);
            setEquipmentnVessel(rotationControl);

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                    + "RotationControl Id property in rotationControl service's create : {}",
                    rotationControl.getRotationNumber());
            LOGGER.info(MessageConstants.INFO_INDICATOR + "calling rotationControl DAO findOne");

            if (alreadyRotationControl == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR
                        + "No existing record : creating new : calling rotationControl DAO create");
                newRotationControls.add(rotationControlDAO.create(rotationControl));
            } else {
                char isDeleted = alreadyRotationControl.getIsDeleted();

                if (isDeleted == 'Y') {
                    rotationControl.setVersion(alreadyRotationControl.getVersion());
                    rotationControl.setIsDeleted('N');
                    LOGGER.info("existing record found : calling rotationControl DAO update");
                    newRotationControls.add(rotationControlDAO.update(rotationControl));
                } else {
                    throw new ExistingRecordException(MessageConstants.UNIQUE_ROTATION_TERMINAL_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting RotationControl service's create method");

        return newRotationControls;
    }

    /**
     * This mehtod is used to publish Vessel Event
     * 
     * @param rotationControl
     * @param eventMsg
     * @param eventName
     */
    public void publishVesselEvent(RotationControl rotationControl, Serializable eventMsg, String eventName) {

        String rotationNumber = null;
        String vesselCode = null;
        String berthNo = null;
        String vesselName = null;
        String voyageNo = null;
        String berthSide = null ;
        VesselBerthEvent vb = null;
        VesselSailEvent vs = null;

        rotationNumber = rotationControl.getRotationNumber().toString();
        vesselCode = rotationControl.getVesselNo().toString();
        vesselName = rotationControl.getActualVessel().getVesselName();
        voyageNo = rotationControl.getVoyageNo();
        berthSide= rotationControl.getBerthSide();

        berthNo = rotationControl.getBerthNo();
        if ("Birth".equalsIgnoreCase(eventName)) {
            vb = (VesselBerthEvent) eventMsg;
            vb.setVesselCode(vesselCode);
            vb.setRotationID(rotationNumber);
            vb.setBerthID(berthNo);
            vb.setVesselName(vesselName);
            vb.setVoyage(voyageNo);
            vb.setBerthSide(berthSide);
            QueueUtil.publishToQueues(MessageConstants.T2_ESB_COMMON_OUTQ, vb);
        } else if ("Sail".equalsIgnoreCase(eventName)) {

            vs = (VesselSailEvent) eventMsg;
            vs.setVesselCode(vesselCode);
            vs.setRotationID(rotationNumber);
            vs.setBerthID(berthNo);
            vs.setVesselName(vesselName);
            vs.setVoyage(voyageNo);
            QueueUtil.publishToQueues(MessageConstants.T2_ESB_COMMON_OUTQ, vs);
        }

        String[] vesselEventDetails = { rotationNumber, vesselCode, vesselName, voyageNo, eventName };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR
                        + "Passing VesselEvent to queue with rotationNumber: {} , vesselCode : {} , vesselName : {} , voyageNo : {} and eventName : {}",
                vesselEventDetails);

    }

    /**
     * This method is set the eqipments & Vessel for rotation passed.
     * 
     * @param rotationControl
     */
    private void setEquipmentnVessel(RotationControl rotationControl) {
        Collection<Equipment> actualEquipments = null;
        String allEquipments = rotationControl.getAllEquipments();

        String[] equipmentArray = allEquipments.split(",");

        actualEquipments = new ArrayList<Equipment>();
        List equipmentList = new ArrayList<String>(Arrays.asList(equipmentArray));

        for (int i = 0; i < equipmentList.size(); i++) {

            String equipmentID = (String) equipmentList.get(i);
            equipmentDAO.setClazz(Equipment.class);
            Equipment equipment = equipmentDAO.findOne(equipmentID);
            actualEquipments.add(equipment);
        }
        rotationControl.setActualEquipments(actualEquipments);

        Integer vesselNo = rotationControl.getVesselNo();
        vesselDAO.setClazz(Vessel.class);
        Vessel associatedVessel = (Vessel) vesselDAO.findOne(vesselNo);
        rotationControl.setActualVessel(associatedVessel);

    }

    private RotationControl checkDuplicates(RotationControl rotationControl) throws ExistingRecordException {

        RotationControl duplicateRotationControl = null;
        String terminal = rotationControl.getTerminalId();
        Integer rotationNo = rotationControl.getRotationNumber();
        String vesselCode = rotationControl.getVesselCode();
        Integer rotationControlId = rotationControl.getRotationControlId();

        List<RotationControl> existingRotations = rotationControlDAO.findByPropertyValue(RotationControl.class,
                "rotationNumber", rotationNo, false);
        if (existingRotations != null) {

            for (RotationControl existingRotationNo : existingRotations) {
                Integer existingRotationControlId = existingRotationNo.getRotationControlId();
                String existingRotationTerminal = existingRotationNo.getTerminalId();
                String existingVesselCode = existingRotationNo.getActualVessel().getVesselCode();
                boolean isSameRecord = false;
                if (rotationControlId != null && rotationControlId.intValue() == existingRotationControlId.intValue()) {
                    isSameRecord = true;
                }
                if (terminal.equalsIgnoreCase(existingRotationTerminal) && !isSameRecord) {
                    duplicateRotationControl = existingRotationNo;
                    break;
                } else if (!vesselCode.equalsIgnoreCase(existingVesselCode) && !isSameRecord) {
                    throw new ExistingRecordException(MessageConstants.WRONG_ROTATION_VESSELCODE_EXCEPTION_MESSAGE);
                }
            }
        }
        return duplicateRotationControl;
    }

    /**
     * This method is used to update RotationControlList
     * 
     * @param data
     *            The json data coming from the UI
     * @param principal
     *            The java.security.Principal containing logged in user details
     * @return List<RotationControl>
     * @throws ExistingRecordException
     */
    @Transactional
    public List<RotationControl> update(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Entering RotationControl service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "In  rotationControl  service's  update : {} ", data);
        List<RotationControl> returnRotationControls = new ArrayList<RotationControl>();
        rotationControlDAO.setClazz(RotationControl.class);

        List<RotationControl> updatedRotationControls = util.getEntitiesFromDto(data, RotationControlDTO.class,
                RotationControl.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (RotationControl rotationControl : updatedRotationControls) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                    + "rotationNumber property in rotationControl service update : {}",
                    rotationControl.getRotationNumber());
            rotationControl.setLastUpdatedDateTime(currentDate);
            rotationControl.setLastUpdatedBy(userId.toString());
            rotationControl.setIsDeleted('N');
            RotationControl alreadyRotationControl = checkDuplicates(rotationControl);
            setEquipmentnVessel(rotationControl);

            if (alreadyRotationControl == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR
                        + "No exisitng record found -->> calling rotationControl DAO update");
                returnRotationControls.add(rotationControlDAO.update(rotationControl));
            } else {
                char isDeleted = alreadyRotationControl.getIsDeleted();

                if (isDeleted == 'Y') {
                    rotationControl.setRotationControlId(alreadyRotationControl.getRotationControlId());
                    rotationControl.setVersion(alreadyRotationControl.getVersion());
                    rotationControl.setIsDeleted('N');
                    LOGGER.info("isDeleted = Y --> calling rotationControl DAO update to update the existing record");
                    returnRotationControls.add(rotationControlDAO.update(rotationControl));
                } else {
                    throw new ExistingRecordException(MessageConstants.UNIQUE_ROTATION_TERMINAL_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting RotationControl service's update method");
        return returnRotationControls;
    }

    public boolean refreshCache(String rotationNumber, String vesselCode) {
        boolean success = true;
        RotationControl rc = new RotationControl();
        rc.setRotationNumber(Integer.parseInt(rotationNumber));
        rc.setVesselCode(vesselCode);
        return success;
    }

    /**
     * This method is used to delete RotationControlList
     * 
     * @param data
     *            The json data coming from the UI
     * @param principal
     *            The java.security.Principal containing logged in user details
     */
    @Transactional
    public void delete(Object data, Principal principal) {
        /**
         * This method is used to delete RotationControlList
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Entering RotationControl service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "In rotationControl's service delete : {} ", data);

        List<RotationControl> deletedRotationControls = util.getEntitiesFromDto(data, RotationControlDTO.class,
                RotationControl.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (RotationControl rotationControl : deletedRotationControls) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                    + "RotationControl Id property in rotationControl service delete : {}",
                    rotationControl.getRotationNumber());
            RotationControl roatationFromDB = rotationControlDAO.findOne(rotationControl.getRotationControlId());

            roatationFromDB.setLastUpdatedDateTime(currentDate);
            roatationFromDB.setLastUpdatedBy(userId.toString());
            roatationFromDB.setIsDeleted('Y');
            roatationFromDB.setActualEquipments(null);
            rotationControlDAO.hardDelete(roatationFromDB);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting RotationControl service's delete method");
    }

    
    @Transactional(readOnly = true)
    public List<RotationControl> loadAllRotations() {
        rotationControlDAO.setClazz(RotationControl.class);
        return rotationControlDAO.findAll();

    }

    @Transactional(readOnly = true)
    public List<RotationControl> loadRegisteredRotations() {
        rotationControlDAO.setClazz(RotationControl.class);
        return rotationControlDAO.findByPropertyValue(RotationControl.class, "status", "R", true);
    }

    @Transactional(readOnly = true)
    public List<RotationControl> loadBerthedRotations() {
        rotationControlDAO.setClazz(RotationControl.class);
        return rotationControlDAO.findByPropertyValue(RotationControl.class, "status", "B", true);
    }

    @Transactional
    public void createRotationsFromOpus(List<RotationControl> rotationsToBeCreated) {
        rotationControlDAO.setClazz(RotationControl.class);
        for (RotationControl rotationControl : rotationsToBeCreated) {
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "createRotationsFromOpus-->START-->rotation-->" + rotationControl.getRotationNumber());
            rotationControlDAO.create(rotationControl);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "createRotationsFromOpus-->END-->rotation-->" + rotationControl.getRotationNumber());

        }

    }

    @Transactional
    public void updateRotationsFromOpus(List<RotationControl> rotationsToBeUpdated, String status) {
        
        rotationControlDAO.setClazz(RotationControl.class);
        VesselBerthEvent vb = new VesselBerthEvent();
        VesselSailEvent vs = new VesselSailEvent();
        
        for (RotationControl rotationControl : rotationsToBeUpdated) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "updateRotationsFromOpus-->START-->rotation-->" + rotationControl.getRotationNumber() + " & status-->" + status);
            rotationControlDAO.update(rotationControl);
            
            if("B".equalsIgnoreCase(status)){
            publishVesselEvent(rotationControl, vb, MessageConstants.BIRTH_EVENT);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "updateRotationsFromOpus-->published berth event for rotation-->" + rotationControl.getRotationNumber());
            }
            else if("EQ".equalsIgnoreCase(status)){
                //QueueUtil.publishToQueues("MP_ROTATION_QC_MAPPING");
                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "updateRotationsFromOpus-->publishing of equipment changes might be required for rotation-->" + rotationControl.getRotationNumber());
            }
            else if("S".equalsIgnoreCase(status)){
            publishVesselEvent(rotationControl, vs, "Sail");
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "updateRotationsFromOpus-->published sailed event for rotation-->" + rotationControl.getRotationNumber());
            }

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "updateRotationsFromOpus-->END-->rotation-->" + rotationControl.getRotationNumber());
        }

    }

}
