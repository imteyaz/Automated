package com.cmc.dpw.minapro.admin.application.interfaces;

public interface IGenericService {

}
