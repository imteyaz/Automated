package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FunctionGroupId implements Serializable {

    private static final long serialVersionUID = 1L;

    private String functionCode;
    private int intUserGroupId;
    
    public FunctionGroupId() {
    }

    @Column(name = "FUNCTION_CD")
    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    @Column(name = "INT_USER_GRP_ID")
    public int getIntUserGroupId() {
        return intUserGroupId;
    }

    public void setIntUserGroupId(int intUserGroupId) {
        this.intUserGroupId = intUserGroupId;
    }
}
