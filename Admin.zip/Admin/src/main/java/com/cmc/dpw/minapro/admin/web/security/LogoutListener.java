package com.cmc.dpw.minapro.admin.web.security;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.session.SessionDestroyedEvent;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.application.services.UserService;


@Component
public class LogoutListener implements ApplicationListener<SessionDestroyedEvent> {

    @Autowired
    private UserService userService;

    
    @Override
    public void onApplicationEvent(SessionDestroyedEvent event){
        List<SecurityContext> lstSecurityContext = event.getSecurityContexts();
        User  loggedInUser = null ;
        for (SecurityContext securityContext : lstSecurityContext){
            loggedInUser = (User) securityContext.getAuthentication().getPrincipal();
            Integer userId =  loggedInUser.getUserId();
            //securityContext.getAuthentication().isAuthenticated()
            User user = userService.findUserByUserID(userId);
            
            if(user!=null){
                user.setLoginStatus("N");
            }
             
             userService.updateUser(user);
            
        }
    }

}