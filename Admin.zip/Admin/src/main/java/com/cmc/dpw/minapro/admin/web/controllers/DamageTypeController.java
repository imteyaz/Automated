package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.DamageType;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.DamageTypeService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/damageType")
public class DamageTypeController {

    @Autowired
    private DamageTypeService damageTypeService;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageTypeController.class);

    /**
     * This method searches for all the damageTypes matching the search criteria
     * as entered by the end user
     * 
     * @param damageTypeId
     * @param damageTypeName
     * @param make
     * @param model
     * @param damageTypeTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String damageTypeId,
            @RequestParam(required = false) String damageTypeDesc, @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageTypeController Seacrh DamageType method");
     
        String[] requestParameters = { damageTypeId, damageTypeDesc };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageTypeController-->search damageTypeId:{},damageTypeName :{},make :{},damageTypeTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageTypeController Seacrh DamageType method");

            Map<String, Object> damageTypesMap = damageTypeService.searchDamageTypeList(damageTypeId, damageTypeDesc, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageTypeController Seacrh DamageType method");
            return getMap(damageTypesMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DamageTypeController-->search DamageType-->Catch Block :{}", e);
            return getModelMapError("Error retrieving DamageTypes from database.");
        }
    }

    /**
     * This method creates the damageType as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created damageType data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start> DamageTypeController> Create DamageType method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Data{}", data);

        try {
            List<DamageType> damageTypes = damageTypeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageTypeController Create DamageType method");
            return getMap(damageTypes);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create damageType due to following exception  :{}" + cause.getMessage());
            
        }   catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create damageType : " + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create damageType.");
        }

    }
    
    /**
     * This method updates the damageType as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated damageType data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageTypeController Update DamageType method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<DamageType> damageTypes = damageTypeService.update(data, principal);
            return getMap(damageTypes);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update damageType. ");

        }
    }

    
    /**
     * This method deletes the damageType.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted damageType data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageTypeController Delete DamageType method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            damageTypeService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageTypeController Delete DamageType method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete damageType.");

        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param damageTypes List of damageTypes
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<DamageType> damageTypes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", damageTypes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> damageTypesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) damageTypesMap.get("totalCount");

        List<DamageType> damageTypes = (List<DamageType>) damageTypesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", damageTypes);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, damageTypes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
