package com.cmc.dpw.minapro.admin.application.opus.common;


import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;

@Component
public class AppDownManager implements ApplicationListener<ContextClosedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppDownManager.class);
    
    @Override
    public void onApplicationEvent(final ContextClosedEvent event) {
        
        LOGGER.debug("$$$$$$$$$ Admin App going down @ " + new Date() );
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  "Calling shutdown - destroying jms sonnection,sessions !!");
                
        QueueUtil.shutDown();
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  "Done Calling shutdown - destroyed jms sonnection,sessions successfully !!");
    }
    

}
