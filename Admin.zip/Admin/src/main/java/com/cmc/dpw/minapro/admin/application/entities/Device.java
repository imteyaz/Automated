package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Device POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Device")
@Table(name = "MP_DEVICE_MASTER")
public class Device extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String deviceId;
    private String deviceDescription;
    private String ipAddress;
    private String listeningPort;
    private String sendingPort;
    private String equipmentId;
    private String make;
    private String model;
    
    private String osVersion;
    private String currentVersion;
    private Date versionLastUpdatedOn;

    @Column(name = "OS_VERSION")
    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    @Column(name = "CURRENT_APP_VERSION")
    public String getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }

    @Id
    @Column(name = "DEVICE_ID", nullable = false)
    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @Column(name = "DEVICE_DESCRIPTION")
    public String getDeviceDescription() {
        return deviceDescription;
    }

    public void setDeviceDescription(String deviceDescription) {
        this.deviceDescription = deviceDescription;
    }

    @Column(name = "IPADDRESS", nullable = false)
    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Column(name = "LISTENING_PORT", nullable = false)
    public String getListeningPort() {
        return listeningPort;
    }

    public void setListeningPort(String listeningPort) {
        this.listeningPort = listeningPort;
    }

    @Column(name = "SENDING_PORT", nullable = false)
    public String getSendingPort() {
        return sendingPort;
    }

    public void setSendingPort(String sendingPort) {
        this.sendingPort = sendingPort;
    }

    @Column(name = "EQUIPMENT_ID")
    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    @Column(name = "MAKE", nullable = false)
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    @Column(name = "MODEL", nullable = false)
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Column(name = "LAST_APP_VERSION_UPDATE")
    public Date getVersionLastUpdatedOn() {
        return versionLastUpdatedOn;
    }

    public void setVersionLastUpdatedOn(Date versionLastUpdatedOn) {
        this.versionLastUpdatedOn = versionLastUpdatedOn;
    }

}
