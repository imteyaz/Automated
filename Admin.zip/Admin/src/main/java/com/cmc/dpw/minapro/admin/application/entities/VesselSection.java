package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.SectionPK;

/**
 * Defines the sections for the vessel
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Entity
@Table(name = "MP_SECT_SPM")
public class VesselSection implements Serializable {
    /**
     * Composite Primary key - vesselNo + section No
     */
    @EmbeddedId
    private SectionPK pk = new SectionPK();

    @Column(name = "DK_UNDK_IND")
    private String deckOrUnderDeck;

    @Column(name = "SECT_TYPE")
    private String sectionType;

    @Column(name = "HATCHLESS_FLG")
    // @org.hibernate.annotations.Type(type="yes_no")
    private char hatchlessFlag;

    @Column(name = "DIST_FM_FORE")
    private float distanceFromFore;

    @Column(name = "DIST_FM_FORE_UOM")
    private String distanceFromForeUOM;

    @Column(name = "BAY_NOTE")
    private String bayNote;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    // @Version
    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;

    public SectionPK getPk() {
        return pk;
    }

    public void setPk(SectionPK pk) {
        this.pk = pk;
    }

    public String getDeckOrUnderDeck() {
        return deckOrUnderDeck;
    }

    public void setDeckOrUnderDeck(String deckOrUnderDeck) {
        this.deckOrUnderDeck = deckOrUnderDeck;
    }

    public String getSectionType() {
        return sectionType;
    }

    public void setSectionType(String sectionType) {
        this.sectionType = sectionType;
    }

    public char getHatchlessFlag() {
        return hatchlessFlag;
    }

    public void setHatchlessFlag(char hatchlessFlag) {
        this.hatchlessFlag = hatchlessFlag;
    }

    public float getDistanceFromFore() {
        return distanceFromFore;
    }

    public void setDistanceFromFore(float distanceFromFore) {
        this.distanceFromFore = distanceFromFore;
    }

    public String getDistanceFromForeUOM() {
        return distanceFromForeUOM;
    }

    public void setDistanceFromForeUOM(String distanceFromForeUOM) {
        this.distanceFromForeUOM = distanceFromForeUOM;
    }

    public String getBayNote() {
        return bayNote;
    }

    public void setBayNote(String bayNote) {
        this.bayNote = bayNote;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
