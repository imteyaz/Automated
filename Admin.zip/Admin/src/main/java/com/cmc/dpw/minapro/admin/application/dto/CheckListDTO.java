package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * CheckListDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class CheckListDTO extends AuditDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String checkListId;
    private String checkListName;
    private String description;
    private char mandatory;
    private String icon;
    private String category;
    private Integer checkListHeaderId;
    private String checkListHeaderName;
    private CheckListHeaderDTO checkListheader;
    
    
    public String getCheckListId() {
        return checkListId;
    }
    public void setCheckListId(String checkListId) {
        this.checkListId = checkListId;
    }
    public String getCheckListName() {
        return checkListName;
    }
    public void setCheckListName(String checkListName) {
        this.checkListName = checkListName;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public char getMandatory() {
        return mandatory;
    }
    public void setMandatory(char mandatory) {
        this.mandatory = mandatory;
    }
    public String getIcon() {
        return icon;
    }
    public void setIcon(String icon) {
        this.icon = icon;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }
    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }
    public String getCheckListHeaderName() {
        return checkListHeaderName;
    }
    public void setCheckListHeaderName(String checkListHeaderName) {
        this.checkListHeaderName = checkListHeaderName;
    }
    public CheckListHeaderDTO getCheckListheader() {
        return checkListheader;
    }
    public void setCheckListheader(CheckListHeaderDTO checkListheader) {
        this.checkListheader = checkListheader;
    }

}
