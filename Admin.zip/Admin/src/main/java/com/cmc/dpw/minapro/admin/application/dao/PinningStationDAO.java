package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.PinningStationDTO;
import com.cmc.dpw.minapro.admin.application.entities.PinningStation;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * PinningStationDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class PinningStationDAO extends GenericDAO<PinningStation> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(PinningStationDAO.class);
/**
 * This method is used to search PinningStations
 * @param pinningStationIdVal
 * @param terminalIdVal
 * @param availabilityVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchPinningStations(String pinningStationIdVal, String terminalIdVal,
            String availabilityVal, int start, int limit) {
       
        Map<String, Object> resultMap = new HashMap<String, Object>();
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStation DAO's searchPinningStations method");
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(PinningStation.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(pinningStationIdVal))  && pinningStationIdVal != null) {
            likeValue = "";
            String pinningStationId = likeValue.concat(percentage).concat(pinningStationIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("pinningStationId", pinningStationId).ignoreCase());
        }

        if (!("".equalsIgnoreCase(terminalIdVal))  && terminalIdVal != null) {
            likeValue = "";


            String terminalId = likeValue.concat(percentage).concat(terminalIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("terminalId", terminalId).ignoreCase());

        }

        if (!("".equalsIgnoreCase(availabilityVal))  && availabilityVal != null) {
            likeValue = "";

            String availability = likeValue.concat(percentage).concat(availabilityVal).concat(percentage);
            searchCriteria.add(Restrictions.like("availability", availability).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("********** count:{}", count);
        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<PinningStation> searchPinningStations = (List<PinningStation>) searchCriteria.list();
        List<PinningStationDTO> searchPinningStationsDtoList =  util.map(searchPinningStations, PinningStationDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug(" ******* data: {}", searchPinningStationsDtoList);
        LOGGER.debug("****** total Records : {}", totalRecords);
        
        resultMap.put("data", searchPinningStationsDtoList);
        resultMap.put("totalCount", totalRecords);

        for (PinningStation pinningStation : searchPinningStations) {
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"pinning staiton Id", pinningStation.getPinningStationId());
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Exititng pinningStation's searchPinningStations method....");
        return resultMap;

    }

}
