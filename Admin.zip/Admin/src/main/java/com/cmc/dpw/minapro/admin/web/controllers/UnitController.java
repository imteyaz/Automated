package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Unit;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.UnitService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/unit")
public class UnitController {

    @Autowired
    private UnitService unitService;
    private static final Logger LOGGER = LoggerFactory.getLogger(UnitController.class);
    /**
     * This method searches for all the units matching the search criteria
     * as entered by the end user
     * @param unitId
     * @param unitName
     * @param limit
     * @param start
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String unitId,
            @RequestParam(required = false) String unitName, @RequestParam(required = false) int limit,
            @RequestParam(required = false) int start)  {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering unit controller's searchUnits method");

        String[] requestParameters = { unitId, unitName };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"UnitController-->update unitId:{},unitName:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"calling unit service");

            Map<String, Object> unitsMap = unitService.searchUnitList(unitId, unitName, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting unit controller's searchUnits method");
            return getMap(unitsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"UnitController-->Seacrh Unit-->Catch Block :{}", e);
            return getModelMapError("Error retrieving Units from database.");
        }
    }

    /**
     * This method creates the unit as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created unit data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering unit controller's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<Unit> units = unitService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting unit controller's create method");
            return getMap(units);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create unit due to following exception :" + cause.getMessage());
            
        }  catch (ExistingRecordException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create unit :" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create unit.");
        }
    }

    /**
     * This method updates the unit as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated unit data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start unit controller's updateUnits method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<Unit> units = unitService.update(data, principal);

            return getMap(units);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update unit. ");
        }
    }

    /**
     * This method deletes the unit.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted unit data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start unit controller's deleteUnits method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            unitService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting unit controller's deleteUnits method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete unit.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param units List of units
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<Unit> units) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, units);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> unitsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) unitsMap.get("totalCount");

        List<Unit> units = (List<Unit>) unitsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", units);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, units);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }
   
}
