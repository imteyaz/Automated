package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Terminal POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Terminal")
@Table(name = "MP_TERMINAL_MASTER")
public class Terminal extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String terminalId;
    private String description;

    @Id
    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @Column(name = "DESCRIPTION", nullable = false)
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
