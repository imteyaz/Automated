package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.AlertConfigurationDAO;
import com.cmc.dpw.minapro.admin.application.dao.AlertGroupMapDAO;
import com.cmc.dpw.minapro.admin.application.entities.AlertConfiguration;
import com.cmc.dpw.minapro.admin.application.entities.AlertGroupAssociation;

/**
 * AlertConfiguration Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class AlertConfigurationService {

    @Autowired
    private AlertConfigurationDAO alertConfigurationDAO;
    @Autowired
    private AlertGroupMapDAO alertRoleMapDao ;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertConfigurationService.class);

    /**
     * This method is used to read AlertConfiguration
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<AlertConfiguration> getAlertConfigurationList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  AlertConfiguration service's getAlertConfigurationList");
        alertConfigurationDAO.setClazz(AlertConfiguration.class);
        return alertConfigurationDAO.findAll();

    }

    /**
     * This method is used to search AlertConfiguration
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchAlertConfigurationList(String alertCode, String alertText, String description, String severity,
            String soundRequired, int start, int limit) {
       
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertConfiguration service's searchAlertConfigurationList method");
        alertConfigurationDAO.setClazz(AlertConfiguration.class);

        String[] requestParameters = { alertCode, alertText, description, severity, soundRequired };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In AlertConfiguration service searchAlertConfigurationList  with alertConfigurationId: {} , alertConfigurationName : {}, make : {}, model : {}, alertConfigurationTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertConfiguration service's searchAlertConfigurationList method");

        return alertConfigurationDAO.searchAlertConfigurations(alertCode, alertText, description, severity, soundRequired, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<AlertConfiguration> containing the created AlertConfiguration data
     * @throws ExistingRecordException
     */
   

    /**
     * This method is used to update AlertConfiguration
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<AlertConfiguration> containing the updated AlertConfiguration datas
     */
    @Transactional
    public List<AlertConfiguration> update(List<AlertConfiguration> updateData, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertConfiguration service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  alertConfiguration  service's  update : {} ", updateData);
        List<AlertConfiguration> returnAlertConfigurations = new ArrayList<AlertConfiguration>();


        for (AlertConfiguration alertConfiguration : updateData) {
            
            saveRoleMapping(alertConfiguration) ;
            returnAlertConfigurations.add(alertConfigurationDAO.update(alertConfiguration));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertConfiguration service's update method");

        return returnAlertConfigurations;
    }

    private boolean saveRoleMapping(AlertConfiguration alertConfig){
        Boolean result = false ;
        
        List<AlertGroupAssociation> alertRoleMap= alertConfig.getAlertsubscribersMap() ;
        
        for(AlertGroupAssociation currentRoleMap: alertRoleMap){
            currentRoleMap.setIsActive("N");
        }
        
       String[] groupIdArray =  alertConfig.getSubscribers().split(",");
    if(groupIdArray.length>0 && !groupIdArray[0].isEmpty()){
      
       for(String groupId : groupIdArray){
           
           Integer roleId = Integer.parseInt(groupId) ;
           for(AlertGroupAssociation currentRoleMap: alertRoleMap){
               if(currentRoleMap.getGroupId()==roleId){
                   currentRoleMap.setIsActive("Y");
               }
               alertRoleMapDao.setClazz(AlertGroupAssociation.class);
               alertRoleMapDao.update(currentRoleMap) ;
           }
       }
    }else{
        for(AlertGroupAssociation currentRoleMap: alertRoleMap){
            alertRoleMapDao.setClazz(AlertGroupAssociation.class);
            alertRoleMapDao.update(currentRoleMap) ;
        }
    }
        return result ;
    }
      

}
