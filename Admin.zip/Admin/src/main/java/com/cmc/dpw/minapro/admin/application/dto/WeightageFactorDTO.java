package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * WeightageFactor DTO
 */
@JsonAutoDetect
public class WeightageFactorDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
  
    private WeightageFactorPkDTO pk;
    
    private double weightageScore;
    private double weightageFactor;
    private String type;
    private String criteria;
    private String id ;
    
    public WeightageFactorPkDTO getPk() {
        return pk;
    }
    public void setPk(WeightageFactorPkDTO pk) {
        this.pk = pk;
    }
    public double getWeightageScore() {
        return weightageScore;
    }
    public void setWeightageScore(double weightageScore) {
        this.weightageScore = weightageScore;
    }
    public double getWeightageFactor() {
        return weightageFactor;
    }
    public void setWeightageFactor(double weightageFactor) {
        this.weightageFactor = weightageFactor;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getCriteria() {
        return criteria;
    }
    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    

}
