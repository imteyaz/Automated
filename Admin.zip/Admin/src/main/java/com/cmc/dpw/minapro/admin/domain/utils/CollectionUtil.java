package com.cmc.dpw.minapro.admin.domain.utils;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.GenericLookUpDTO;
import com.cmc.dpw.minapro.admin.application.exceptions.FapsServiceException;

public class CollectionUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(CollectionUtil.class);
    private CollectionUtil(){
        
    }
    public static <T> List getDuplicate(Collection<T> list) {

        final List<T> duplicatedObjects = new ArrayList<T>();
        Set<T> set = new HashSet<T>() {
            @Override
            public boolean add(T e) {
                if (contains(e)) {
                    duplicatedObjects.add(e);
                }
                return super.add(e);
            }
        };
        for (T t : list) {
            set.add(t);
        }
        return duplicatedObjects;
    }

    public static <T> boolean hasDuplicate(Collection<T> list) throws FapsServiceException {
        if (getDuplicate(list).isEmpty()){
            return false;
        }
        throw new FapsServiceException("exceptionMessage");
    }

    public static Set<Object> findDuplicatesInList(List<?> beanList) {
        LOGGER.debug("findDuplicatesInList::" + beanList);
        Set<Object> duplicateRowSet = null;
        duplicateRowSet = new LinkedHashSet<Object>();
        for (int i = 0; i < beanList.size(); i++) {
            Object superString = beanList.get(i);
            LOGGER.debug("findDuplicatesInList::superString::" + superString);
            for (int j = 0; j < beanList.size(); j++) {
                if (i != j) {
                    Object subString = beanList.get(j);
                   LOGGER.debug("findDuplicatesInList::subString::" + subString);
                    if (superString.equals(subString)) {
                        duplicateRowSet.add(beanList.get(j));
                    }
                }
            }
        }
        LOGGER.debug("findDuplicatesInList::duplicationSet::" + duplicateRowSet);
        return duplicateRowSet;
    }

    public static List<GenericLookUpDTO> getSublist(List<GenericLookUpDTO> list, int start, int limit) {
        if (list != null && list.size() > start) {
            return list.subList(start, start + limit > list.size() ? list.size() : start + limit);
        }
        return list;
    }

    public static <T> List findDuplicatesInList(List<T> beanList, String[] keys) {

        List<T> duplicateBeanList = new ArrayList<T>();

        if (beanList != null && beanList.size() > 1) {

            try {
                for (int i = 1; i < beanList.size(); i++) {
                    T beanToCompare = beanList.get(i - 1);
                    T bean = beanList.get(i);
                    int count = 0;
                    int j = 0;

                    for (; j < keys.length; j++) {
                        Object valueToCompare = BeanUtils.getProperty(beanToCompare, keys[j]);
                        Object currentBeanValue = BeanUtils.getProperty(bean, keys[j]);

                        if (valueToCompare.equals(currentBeanValue)) {
                            count++;
                        } else {
                            continue;
                        }
                    }
                    if (count == keys.length) {

                        duplicateBeanList.add(beanList.get(i));
                    }
                }
            } catch (IllegalAccessException e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR , e);
            } catch (InvocationTargetException e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR , e);
            } catch (NoSuchMethodException e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR , e);
            }
        }
        return duplicateBeanList;
    }
}
