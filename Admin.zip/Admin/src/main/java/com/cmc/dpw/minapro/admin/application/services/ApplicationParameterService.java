package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.ApplicationParameterDAO;
import com.cmc.dpw.minapro.admin.application.dao.UnitDAO;
import com.cmc.dpw.minapro.admin.application.dto.ApplicationParameterDTO;
import com.cmc.dpw.minapro.admin.application.entities.ApplicationParameter;
import com.cmc.dpw.minapro.admin.application.entities.Unit;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ApplicationParameter Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class ApplicationParameterService {
    @Autowired
    private ApplicationParameterDAO applicationParameterDAO;
    @Autowired
    private UnitDAO unitDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationParameterService.class);

    /**
     * This method is used to get ApplicationParameter List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<ApplicationParameter> getApplicationParameterList() {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  ApplicationParameter service's getApplicationParameterList");
        applicationParameterDAO.setClazz(ApplicationParameter.class);
        return applicationParameterDAO.findAll();

    }

    /**
     * This method is used to search ApplicationParameter List
     * @param parameterCode
     * @param parameterValue
     * @param start
     * @param limit
     * @return Map<String, Object> containing the search ApplicationParameter data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchApplicationParameterList(String parameterCode, String parameterValue, int start,
            int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ApplicationParameter service's searchApplicationparameterList method");
        applicationParameterDAO.setClazz(ApplicationParameter.class);

        String[] requestParameters = { parameterCode, parameterValue };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                " In Applicationparameter service searchApplicationParameters with parameterCode: {} , parameterValue : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter service's searchApplicationParameterList method");
        return applicationParameterDAO.searchApplicationParameters(parameterCode, parameterValue, start, limit);

    }

    /**
     * This method is used to create ApplicationParameter
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ApplicationParameter> containing created ApplicationParameter data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_APPLICATIONPARAMETER_MASTER")
    public List<ApplicationParameter> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ApplicationParameter service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  applicationParameter service's  create : {} ", data);
        List<ApplicationParameter> newApplicationParameters = new ArrayList<ApplicationParameter>();

        List<ApplicationParameter> list = util.getEntitiesFromDto(data, ApplicationParameterDTO.class, ApplicationParameter.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (ApplicationParameter applicationParameter : list) {

            Date currentDate = new Date();

            String unitId = applicationParameter.getUnitId();
            Unit unit = getUnitById(unitId);
            applicationParameter.setUnit(unit);
            applicationParameter.setCreatedDateTime(currentDate);
            applicationParameter.setLastUpdatedDateTime(currentDate);
            applicationParameter.setCreatedBy(userId.toString());
            applicationParameter.setLastUpdatedBy(userId.toString());

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"parameterCode property in applicationParameter service create : {}",
                    applicationParameter.getParameterCode());

            ApplicationParameter alreadyApplicationParameter = applicationParameterDAO.findOne(applicationParameter
                    .getParameterCode());

            if (alreadyApplicationParameter == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling applicationParameter DAO create");
                newApplicationParameters.add(applicationParameterDAO.create(applicationParameter));

            } else {
                char isDeleted = alreadyApplicationParameter.getIsDeleted();

                if (isDeleted == 'Y') {
                    applicationParameter.setVersion(alreadyApplicationParameter.getVersion());
                    applicationParameter.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling applicationParameter DAO update");
                    newApplicationParameters.add(applicationParameterDAO.update(applicationParameter));
                }  else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null    
            }
         // end of for loop
        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter service's create method");
        return newApplicationParameters;
    }

    /**
     * This method is  used to update ApplicationParameter
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ApplicationParameter> containing updated ApplicationParameter data
     */
    @Transactional
    @Manipulate(table = "MP_APPLICATIONPARAMETER_MASTER")
    public List<ApplicationParameter> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ApplicationParameter service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  applicationParameter  service's  update : {} ", data);
        List<ApplicationParameter> returnApplicationParameters = new ArrayList<ApplicationParameter>();

        List<ApplicationParameter> updatedApplicationParameters = util.getEntitiesFromDto(data, ApplicationParameterDTO.class, ApplicationParameter.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ApplicationParameter applicationParameter : updatedApplicationParameters) {

            Date currentDate = new Date();
            String unitId = applicationParameter.getUnitId();
            Unit unit = getUnitById(unitId);
            applicationParameter.setUnit(unit);

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"parameterCode property in applicationParameter service update : {}",
                    applicationParameter.getParameterCode());
            applicationParameter.setLastUpdatedDateTime(currentDate);
            applicationParameter.setLastUpdatedBy(userId.toString());
            returnApplicationParameters.add(applicationParameterDAO.update(applicationParameter));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter service's update method");
        return returnApplicationParameters;
    }

    /**
     * This method is used to delete ApplicationParameter
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return (Unit) session
     */
    @Transactional
    @Manipulate(table = "MP_APPLICATIONPARAMETER_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ApplicationParameter service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In applicationParameter's service delete : {} ", data);

        List<ApplicationParameter> deletedApplicationParameters = util.getEntitiesFromDto(data, ApplicationParameterDTO.class, ApplicationParameter.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ApplicationParameter applicationParameter : deletedApplicationParameters) {

            Date currentDate = new Date();
            String unitId = applicationParameter.getUnitId();
            Unit unit = getUnitById(unitId);
            applicationParameter.setUnit(unit);

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"parameterCode property in applicationParameter service delete : {}",
                    applicationParameter.getParameterCode());
            applicationParameter.setLastUpdatedBy(userId.toString());
            applicationParameter.setLastUpdatedDateTime(currentDate);
            applicationParameter.setIsDeleted('Y');
            applicationParameterDAO.delete(applicationParameter);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter service's delete method");
    }

    private Unit getUnitById(String unitId) {
        unitDAO.setClazz(Unit.class);
        return unitDAO.findOne(unitId);
    }

}
