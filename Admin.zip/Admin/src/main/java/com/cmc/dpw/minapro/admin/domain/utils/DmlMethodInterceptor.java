package com.cmc.dpw.minapro.admin.domain.utils;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.AfterReturningAdvice;

/**
 * 
 * @author Bhavesh
 * 
 *         Intercepts all service method which are having annotation @Manipulate. Pull out the table name form
 *         annotation and publishing message to RDT queues. Message should get published only if a successful
 *         Add/Update/Delete operation is performed on the master screen.
 * 
 */
public class DmlMethodInterceptor implements AfterReturningAdvice {

    private static final Logger LOGGER = LoggerFactory.getLogger(DmlMethodInterceptor.class);

    public void afterReturning(Object returnValue, Method method, Object[] args, Object target) {
        LOGGER.debug("******* Intercepting method  " + method.getName());
        if (method.isAnnotationPresent(Manipulate.class)) {
            LOGGER.debug(" ******* ### method  " + method.getName() + " has annotaion Manipulate ");
            Manipulate annotation = (Manipulate) method.getAnnotation(Manipulate.class);
            Object[] requestParameters = { returnValue, args, target};
            LOGGER.debug("START -> DmlMethodInterceptor -> afterReturning -> params : returnValue :{} ,args :{},target:{}" + requestParameters);
            try {
                QueueUtil.publishToQueues(annotation.table());
            } catch (Exception e) {
                LOGGER.error("!^!^!^!^--DmlMethodInterceptor --> afterReturning --> Exception",e);
                LOGGER.warn("^^^^^Failed to publish to Queue : {}", e.getMessage());
                LOGGER.debug("Failed to publish to Queue :{}" + e.getMessage());
            }
        }

    }
}