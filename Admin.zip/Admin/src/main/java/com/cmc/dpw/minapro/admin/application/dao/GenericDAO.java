package com.cmc.dpw.minapro.admin.application.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.interfaces.IGenericDao;
/**
 * GenericDAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class GenericDAO<T extends Serializable> implements IGenericDao<T> {

    private Class<T> clazz;
    private static final Logger LOGGER = LoggerFactory.getLogger(GenericDAO.class);

    SessionFactory sessionFactory;

    public void setClazz(Class<T> clazzToSet) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Generic DAO's setClazz method");
        this.clazz = clazzToSet;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Session factory object is autowired !");
    }
    
    @SuppressWarnings("unchecked")
    public T findOne(Object id) {

        return (T) getCurrentSession().get(clazz, (Serializable) id);
    }

    @SuppressWarnings("unchecked")
    public T findOne(String id) {

        return (T) getCurrentSession().get(clazz, id);
    }

    @SuppressWarnings("unchecked")
    public T findOne(Integer id) {

        return (T) getCurrentSession().get(clazz, id);
    }

    @SuppressWarnings("unchecked")
    public List<T> findByPropertyValue(Class<T> entity, String property, Object propertyValue, boolean ignoreCase) {
        /**
         * This method is used to findByPropertyValue
         * @return searchResults
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering into Generic DAO's findByPropertyValue method........");
        List<T> searchResults = null;

        Class currentClass = entity;
        setClazz(currentClass);

        Session session = getCurrentSession();
        Criteria searchCriteria = session.createCriteria(entity);

        if (ignoreCase) {
            searchCriteria.add(Restrictions.eq(property, propertyValue).ignoreCase());
        } else {
            searchCriteria.add(Restrictions.eq(property, propertyValue));
        }

        List matchingRecords = (List) searchCriteria.list();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting GenericDAO's findByPropertyValue method ");

        searchResults = matchingRecords;

        return searchResults;

    }

    @SuppressWarnings("unchecked")
    public List<T> findAll() {

        return getCurrentSession().createQuery("from " + clazz.getName()).list();
    }

    public T create(T entity) {
        /**
         * This method is used to create entity
         * @return entity
         */
        getCurrentSession().persist(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record created sucessfully...");
        return entity;
    }

    public T update(T entity) {
        /**
         * This method is used to update entity
         */
        getCurrentSession().merge(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record Updated sucessfully...");
        return entity;
    }

    public T saveOrupdate(T entity) {
        /**
         * This method is used to saveOrupdate entity
         * @return entity
         */
        getCurrentSession().saveOrUpdate(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record saved/updated sucessfully...");
        return entity;
    }

    public void delete(T entity) {
        /**
         * This method is used to soft delete entity
         */
        getCurrentSession().merge(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record soft deleted sucessfully...");
    }

    public void hardDelete(T entity) {
        /**
         * This method is used to hardDelete entity
         */
        getCurrentSession().delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record hard deleted sucessfully...");

    }

    public T save(T entity) {
        getCurrentSession().save(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Record saved sucessfully...");
        return entity;
    }
   
    public void deleteById(String entityId) {
        T entity = findOne(entityId);
        delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"selected Record hard deleted sucessfully for string primary key...");
    }
    
    public void hardDeleteById(Integer entityId) {
        T entity = findOne(entityId);
        delete(entity);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"selected Record hard deleted  sucessfully for integer primary key...");
    }

    protected final Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }
    
    /**
     * This method is used to fetchRecordsWithoutAssociation
     * @return resultMap
     */
    public Map<String, Object> fetchRecordsWithoutAssociation(String entityName, String columnName, String filterColumnName,
            String filterColumnVal, String query, int start, int limit) {
       
        Map<String, Object> resultMap = new HashMap<String, Object>();

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering into Generic DAO's fetchRecordsWithoutAssociation method........");
        String packageName = MessageConstants.ENTITY_PACKAGE_NAME ;
        String fullyQualifiedName = packageName.concat(entityName);

        Class currentClass = null ;
        
        try {
             currentClass = Class.forName(fullyQualifiedName);
            setClazz(currentClass);

        } catch (ClassNotFoundException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" GenericDAO --> fetchRecordsWithoutAssociation --> ClassNotFoundException ",e);
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" Unable to load class for the given entity : {} ", entityName);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" Stacktrace : {}", e.getStackTrace());
            

        }
        String percentage = "%";
        String likeValue = "";
        Session session = getCurrentSession();
        String modifiedQuery = likeValue.concat(percentage).concat(query).concat(percentage);

        Criteria searchCriteria = session.createCriteria(clazz);
        searchCriteria.add(Restrictions.like(columnName, modifiedQuery).ignoreCase());
        searchCriteria.add(Restrictions.eq(MessageConstants.ISDELETEDCOLUMN, 'N'));
        
        Query hqlQuery = session.createQuery("select distinct ch from " + entityName + " ch where ch.isDeleted = 'N' and lower(ch." +columnName + ") like lower('" + modifiedQuery +"')");
        hqlQuery.setMaxResults(limit);
        hqlQuery.setFirstResult(start);

        List heasdersList = hqlQuery.list();
        
        Criteria totalCriteria = searchCriteria;
        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        String totalRecords = count.toString();
        searchCriteria.setProjection(null);
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        resultMap.put("data", heasdersList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting GenericDAO's fetchRecordsWithoutAssociation method ");
        return resultMap;
    }
    
    /**
     * This method is used to findForeignKeys
     * @return resultMap
     */
    public Map<String, Object> findForeignKeys(String entityName, String columnName, String filterColumnName,
            String filterColumnVal, String query, int start, int limit) {
       
        Map<String, Object> resultMap = new HashMap<String, Object>();

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering into Generic DAO's findForeignKeys method........");
        String packageName = MessageConstants.ENTITY_PACKAGE_NAME ;
        String fullyQualifiedName = packageName.concat(entityName);
        Class currentClass = null ;
        try {
             currentClass = Class.forName(fullyQualifiedName);
            setClazz(currentClass);

        } catch (ClassNotFoundException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"--> Exception",e);
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" Class Not Found for the given entity : {} ", entityName);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" Exception Stacktrace : {}", e.getStackTrace());
            

        }
        
        Boolean isColumnInteger = null ;
        Boolean isColumnString = null ;
        String percentage = "%";
        String likeValue = "";
        Session session = getCurrentSession();
        String modifiedQuery = likeValue.concat(percentage).concat(query).concat(percentage);
        Criteria searchCriteria = session.createCriteria(clazz);
        searchCriteria.add(Restrictions.eq(MessageConstants.ISDELETEDCOLUMN, 'N'));
        LOGGER.debug("columnName :" + columnName);
       try {
           
         String dataType =  currentClass.getDeclaredField(columnName).getType().getName();
         LOGGER.debug("dataType : " + dataType );
            if(("java.lang.String").equalsIgnoreCase(dataType)){
                isColumnString = true ;
                searchCriteria.add(Restrictions.like(columnName, modifiedQuery).ignoreCase());
                LOGGER.debug("isColumnString" + isColumnString );
            }else if(("java.lang.Integer").equalsIgnoreCase(dataType) && !query.isEmpty()  ){
                isColumnInteger = true ;
                searchCriteria.add(Restrictions.eq(columnName, Integer.parseInt(query)));
                LOGGER.debug("isColumnInteger" + isColumnInteger );
            }
        
    } catch (NoSuchFieldException e) {
        LOGGER.error(MessageConstants.ERROR_INDICATOR +"NoSuchFieldException--> ",e);
    } catch (SecurityException e) {
        LOGGER.error(MessageConstants.ERROR_INDICATOR +"SecurityException--> ",e);
    }
       
        if((filterColumnName != null && !filterColumnName.isEmpty()) && (filterColumnVal != null && !filterColumnVal.isEmpty())){
                searchCriteria.add(Restrictions.eq(filterColumnName, filterColumnVal));
        }

        Criteria totalCriteria = searchCriteria;
        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        String totalRecords = count.toString();
        searchCriteria.setProjection(null);
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List foreignKeys = (List) searchCriteria.list();

        resultMap.put("data", foreignKeys);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting GenericDAO's findForeignKeys method ");
        return resultMap;
    }
    
    public Map<String, Object> getFilteredRecordsBasedOnCondition(String entityName, Map<String, Object> searchColumnValuePairs,Map<String, Object> filtersMap, Boolean checkEquality, String orElseAnd,String query,int start, int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GenericDAO--> getFilteredRecordsBasedOnCondition()  ");
        
        Map<String, Object> resultMap = new HashMap<String, Object>();
        String packageName = MessageConstants.ENTITY_PACKAGE_NAME ;
        String fullyQualifiedName = packageName.concat(entityName);
        try {
            Class currentClass = Class.forName(fullyQualifiedName);
            setClazz(currentClass);

        } catch (ClassNotFoundException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" getFilteredRecordsBasedOnCondition --> Exception",e);
            LOGGER.warn(MessageConstants.WARN_INDICATOR+" unable to load class for the given entity : {} ", entityName);
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" ClassNotFoundException for the given entity : {} ", e);

        }
        String[] requestParameters = {checkEquality.toString(), orElseAnd, query};
        LOGGER.info(MessageConstants.INFO_INDICATOR +"GenericDAO--> getFilteredRecordsBasedOnCondition() --> params - checkEquality :{} , orElseAnd : {} , query : {}" ,requestParameters);
        
        String percentage = "%";
        String likeValue = "";
        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(clazz);
        searchCriteria.add(Restrictions.eq(MessageConstants.ISDELETEDCOLUMN, 'N'));

        Iterator<Entry<String, Object>> iter = searchColumnValuePairs.entrySet().iterator();
        List<Criterion> criteriaList = new ArrayList<Criterion>();
        while (iter.hasNext()) {

            Entry<String, Object> columnNameValuePair = iter.next();
            String columnName = columnNameValuePair.getKey();
            Object columnValue = columnNameValuePair.getValue();
            String finalColumnValue = columnValue.toString();
            Criterion ithRestriction = null ;
            likeValue = "";
            finalColumnValue = likeValue.concat(percentage).concat(finalColumnValue).concat(percentage);
            ithRestriction = Restrictions.like(columnName, finalColumnValue).ignoreCase();

            criteriaList.add(ithRestriction);
            }
        
        Integer noOfColumnRestrictions =  criteriaList.size();
        if(noOfColumnRestrictions==MessageConstants.HASH_LENGTH_TWO){
            
            searchCriteria.add(Restrictions.or(criteriaList.get(0),criteriaList.get(1)));
        }

        Iterator<Entry<String, Object>> filterIter = filtersMap.entrySet().iterator();
        while (filterIter.hasNext()) {
            Entry<String, Object> filterColumnNameValuePair = filterIter.next();
            String filterColumnName = filterColumnNameValuePair.getKey();
            Object filterColumnValue = filterColumnNameValuePair.getValue();
            if(filterColumnValue!=null){
                 String finalColumnValue = filterColumnValue.toString();
                 searchCriteria.add(Restrictions.eq(filterColumnName, finalColumnValue));
            }
        }
        
      
        Criteria totalCriteria = searchCriteria;
        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        String totalRecords = count.toString();
        searchCriteria.setProjection(null);
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        
        List recordsFound = (List) searchCriteria.list();

        resultMap.put("data", recordsFound);
        resultMap.put(MessageConstants.SUCCESS_KEY, true);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY,totalRecords);
        
        
        return resultMap;
    }
    
    /**
     * This method is used to checkUniqueRecord
     * @return resultMap
     */
    public Map<String, Object> checkUniqueRecord(String entityName, Map<String, Object> uniqueColumns) {
        
        Map<String, Object> resultMap = new HashMap<String, Object>();
        Boolean isRecordPresent = false;
        String packageName = MessageConstants.ENTITY_PACKAGE_NAME ;
        String fullyQualifiedName = packageName.concat(entityName);
        try {
            Class currentClass = Class.forName(fullyQualifiedName);

            setClazz(currentClass);

        } catch (ClassNotFoundException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Check Unique Record --> Exception",e);
            LOGGER.warn(MessageConstants.WARN_INDICATOR+"unable to load class for the given entity : {} ", entityName);
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ClassNotFoundException for the given entity : {} ", e);

        }
        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(clazz);

        Iterator<Entry<String, Object>> iter = uniqueColumns.entrySet().iterator();
        while (iter.hasNext()) {

            Entry<String, Object> columnNameValuePair = iter.next();
            String columnName = columnNameValuePair.getKey();
            Object columnValue = columnNameValuePair.getValue();
            String finalColumnValue = columnValue.toString();
            columnValue.getClass();
            searchCriteria.add(Restrictions.eq(columnName, finalColumnValue));
        }

        List recordsFound = (List) searchCriteria.list();

        int recordsSize = recordsFound.size();

        if (recordsSize > 0) {
            isRecordPresent = true;
        }

        resultMap.put("data", recordsFound);
        resultMap.put("isRecordPresent", isRecordPresent);

        return resultMap;
    }

}