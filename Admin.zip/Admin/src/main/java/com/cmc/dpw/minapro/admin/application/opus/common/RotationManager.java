package com.cmc.dpw.minapro.admin.application.opus.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.opus.controllers.OpusVesselController;
import com.cmc.dpw.minapro.admin.application.opus.services.OpusVesselService;


@Component
public class RotationManager {

    @Autowired
    OpusVesselController opusVesselContoller;// = new OpusVesselController();
    
    private static final Logger LOGGER = LoggerFactory.getLogger(RotationManager.class);

    private void syncRegisteredRotations() {
        opusVesselContoller.syncRegisteredRotations();
    };

    private void syncBerthedRotations() {
        opusVesselContoller.syncBerthedRotations();;
    };

    private void syncSailedRotations() {
        opusVesselContoller.syncSailedRotations();
    }

    public void manageRegisteredRotations() {
        
        try{
            syncRegisteredRotations();
        }catch(Exception e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"RotationManager-->syncRegisteredRotations-->Catch Block :{}", e);
        }
        
    }

    public void manageBerthedRotations() {
        
        try{
            syncBerthedRotations();
        }catch(Exception e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"RotationManager-->syncBerthedRotations-->Catch Block :{}", e);
        }
        

    }

    public void manageSailedRotations() {
        
        try{
            syncSailedRotations();
        }catch(Exception e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"RotationManager-->syncSailedRotations-->Catch Block :{}", e);
        }
        

    }

    public void manageEquipmentMappings() {
        opusVesselContoller.syncEquipmentMappingsForRotations();
    };

}
