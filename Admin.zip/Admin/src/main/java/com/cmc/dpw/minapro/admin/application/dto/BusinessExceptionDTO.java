package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ValueObjcet holding the template header details
 * @author Imran Rawani
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessExceptionDTO implements Serializable{
   
    private static final long serialVersionUID = -7920596353659481286L;

    private Integer exceptionId;
    private String exceptionType;
    private String exceptionDesc;
    private String cotainerId;
    private Integer rotationNo;
    private String functionCode;
    private Date createdDateTime;
    private String createdBy;
    private Collection<BusinessExceptionDetailsDTO>  businessExceptionDetails = new ArrayList<BusinessExceptionDetailsDTO>();

    public Integer getExceptionId() {
        return exceptionId;
    }

    public void setExceptionId(Integer exceptionId) {
        this.exceptionId = exceptionId;
    }

    public String getExceptionType() {
        return exceptionType;
    }

    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    public String getExceptionDesc() {
        return exceptionDesc;
    }

    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    public String getCotainerId() {
        return cotainerId;
    }

    public void setCotainerId(String cotainerId) {
        this.cotainerId = cotainerId;
    }

    public Integer getRotationNo() {
        return rotationNo;
    }

    public void setRotationNo(Integer rotationNo) {
        this.rotationNo = rotationNo;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Collection<BusinessExceptionDetailsDTO> getBusinessExceptionDetails() {
        return businessExceptionDetails;
    }

    public void setBusinessExceptionDetails(Collection<BusinessExceptionDetailsDTO> businessExceptionDetails) {
        this.businessExceptionDetails = businessExceptionDetails;
    }

}
