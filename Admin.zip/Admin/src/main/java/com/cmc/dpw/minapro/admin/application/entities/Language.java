package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Language POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Language")
@Table(name = "MP_LANGUAGES_MASTER")
public class Language implements Serializable {

    private static final long serialVersionUID = 1L;
    private String languageName;
    private String languageCode;
    private char isDeleted;

    @Column(name = "LANGUAGE_NAME")
    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    @Id
    @Column(name = "LANGUAGE_CODE")
    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    @Column(name = "ISDELETED")
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
