package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

/**
 * ValueObject holding the vessel details
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_VSL_SPM")
public class Vessel implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vesselSequence")
    @SequenceGenerator(name = "vesselSequence", sequenceName = "MP_VESSEL_SEQ", allocationSize = 1, initialValue = 30)
    @Column(name = "INT_VSL_NO", nullable = false)
    private Integer vesselNo;

    @Column(name = "VSL_CD")
    private String vesselCode;

    @Column(name = "VSL_NM")
    private String vesselName;

    @Column(name = "VSL_TYPE")
    private String vesselType;

    @Column(name = "MTHR_FEEDR_IND")
    // @org.hibernate.annotations.Type(type="yes_no")
    private String motherFeeder;

    @Column(name = "OVRALL_LEN")
    private Float length;

    @Column(name = "OVRALL_LEN_UOM")
    private String lengthUom;

    @Column(name = "VSL_WD")
    private Float width;

    @Column(name = "VSL_WD_UOM")
    private String widthUom;

    @Column(name = "VSL_HT")
    private Float height;

    @Column(name = "TEU_CPCTY")
    private Integer teuCapacity;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Version
    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;

    @Column(name = "MAX_NO_ROWS", nullable = false)
    private Integer maxRows;

    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getVesselName() {
        return vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }

    public String getVesselType() {
        return vesselType;
    }

    public void setVesselType(String vesselType) {
        this.vesselType = vesselType;
    }

    public String getMotherFeeder() {
        return motherFeeder;
    }

    public void setMotherFeeder(String motherFeeder) {
        this.motherFeeder = motherFeeder;
    }

    public Float getLength() {
        return length;
    }

    public void setLength(Float length) {
        this.length = length;
    }

    public String getLengthUom() {
        return lengthUom;
    }

    public void setLengthUom(String lengthUom) {
        this.lengthUom = lengthUom;
    }

    public Float getWidth() {
        return width;
    }

    public void setWidth(Float width) {
        this.width = width;
    }

    public String getWidthUom() {
        return widthUom;
    }

    public void setWidthUom(String widthUom) {
        this.widthUom = widthUom;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public Integer getTeuCapacity() {
        return teuCapacity;
    }

    public void setTeuCapacity(Integer teuCapacity) {
        this.teuCapacity = teuCapacity;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Integer getMaxRows() {
        return maxRows;
    }

    public void setMaxRows(Integer maxRows) {
        this.maxRows = maxRows;
    }

}
