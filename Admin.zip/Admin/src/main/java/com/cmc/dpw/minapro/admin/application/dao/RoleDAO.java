package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.RoleDTO;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * RoleDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class RoleDAO extends GenericDAO<Role> {

    @Autowired
    private Util util;
    Map<String, Object> resultMap = new HashMap<String, Object>();
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleDAO.class);
/**
 * This method is used to search Roles
 * @param userNameVal
 * @param roleNameVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchRoles(String userNameVal, String roleNameVal, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering into Role DAO's searchRoles method ");
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";
        int i = 0;

        Criteria searchCriteria = session.createCriteria(Role.class, "roleClass");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { userNameVal, roleNameVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"processing searchRoles in Role DAO with role Id :{},role name:{}", searchParameters);

        if (!("".equalsIgnoreCase(userNameVal))  && userNameVal != null) {
            searchCriteria.createAlias("roleClass.actualUsers", "user");
            searchCriteria.add(Restrictions.eq("user.userName", userNameVal).ignoreCase());
            i++;
        }

        if (!("".equalsIgnoreCase(roleNameVal))  && roleNameVal != null)  {
            likeValue = "";
            String roleName = likeValue.concat(percentage).concat(roleNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("userGroupName", roleName).ignoreCase());
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("***** count: {}", count);
        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Role> searchRoles = null;

        if (i != 0) {

            Query query = session
                    .createQuery("select distinct r from Role r left join fetch r.actualUsers au where lower(au.userName) like lower('%"
                            + userNameVal + "%')" + " and lower(r.userGroupName) like lower('%" + roleNameVal + "%')");

            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<Role> rolesList = query.list();

            searchRoles = rolesList;

        }  else {

        searchRoles = (List<Role>) searchCriteria.list();

        }

        List<RoleDTO> searchRolesDtoList =  util.map(searchRoles, RoleDTO.class);
        String totalRecords = count.toString();
        
        LOGGER.debug("******* data from DB: {}", searchRolesDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchRolesDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug("**** Exiting from Role DAO searchRoles method");
        return resultMap;

    }

    public Role findOne(Integer roleId) {

        return (Role) getCurrentSession().get(Role.class, roleId);
    }

}
