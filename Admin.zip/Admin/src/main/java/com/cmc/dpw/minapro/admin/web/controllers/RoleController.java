package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.RoleService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/role")
public class RoleController {

    @Autowired
    private RoleService roleService;
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleController.class);
    /**
     * This method searches for all the roles matching the search criteria
     * as entered by the end user
     * @param roleName
     * @param userName
     * @param limit
     * @param start
     * @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String userName,
            @RequestParam(required = false) String roleName, @RequestParam(required = false) int limit,
            @RequestParam(required = false) int start) {
        

        LOGGER.debug("Got the request to view Roles...Inside Role controller");

        String[] requestParameters = { userName, roleName };
        LOGGER.debug("Processing searchRoles with userName: {} , roleName : {}", requestParameters);

        try {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"caling role service");
            Map<String, Object> rolesMap = roleService.searchRoleList(userName, roleName, start, limit);

            return getMap(rolesMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"RoleController-->Seacrh Role-->Catch Block :{}", e);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RoleController search Roles method");
            return getModelMapError("Error retrieving Roles from database.");
        }
    }

    /**
     * This method creates the role as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created role data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering RoleController Create Role method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<Role> roles = roleService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RoleController Create Role method");
            return getMap(roles);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create role due to following exception :{}" + cause.getMessage());
            
        }    catch (ExistingRecordException e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create role :{}" + e.getCustomErrorMessage());    
            
        }   catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create role.");
        }
    }

    /**
     * This method updates the role as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated role data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
       
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<Role> roles = roleService.update(data, principal);

            return getMap(roles);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update role. ");
        }
    }

    /**
     * This method deletes the role.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted role data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            roleService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);

            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete role.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param roles List of roles
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<Role> roles) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, roles);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> rolesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) rolesMap.get("totalCount");

        List<Role> roles = (List<Role>) rolesMap.get("data");

        LOGGER.debug(MessageConstants.TOTALRECORDS_KEY, totalRecords);
        LOGGER.debug(MessageConstants.ROLES_KEY, roles);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, roles);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
