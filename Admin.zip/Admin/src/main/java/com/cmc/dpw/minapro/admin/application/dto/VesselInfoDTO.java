package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * ValueObject holding the vessel details
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
public class VesselInfoDTO implements Serializable {

    private Integer vesselNo;
    private String vesselCode;
    private String vesselName;
    private String vesselType;
    private char motherFeeder;
    private Float length;
    private String lengthUom;
    private Float width;
    private String widthUom;
    private Float height;
    private Integer teuCapacity;
    private Date createdDateTime;
    private String createdBy;
    private Date lastUpdatedDateTime;
    private String lastUpdatedBy;
    private Integer version;
    private char isDeleted;
    private Integer maxRows;

    public Integer getVesselNo() {
        return vesselNo;
    }

    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getVesselName() {
        return vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }

    public String getVesselType() {
        return vesselType;
    }

    public void setVesselType(String vesselType) {
        this.vesselType = vesselType;
    }

    public char isMotherFeeder() {
        return motherFeeder;
    }

    public char getMotherFeeder() {
        return motherFeeder;
    }
    
    public void setMotherFeeder(char motherFeeder) {
        this.motherFeeder = motherFeeder;
    }

    public Float getLength() {
        return length;
    }

    public void setLength(Float length) {
        this.length = length;
    }

    public String getLengthUom() {
        return lengthUom;
    }

    public void setLengthUom(String lengthUom) {
        this.lengthUom = lengthUom;
    }

    public Float getWidth() {
        return width;
    }

    public void setWidth(Float width) {
        this.width = width;
    }

    public String getWidthUom() {
        return widthUom;
    }

    public void setWidthUom(String widthUom) {
        this.widthUom = widthUom;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public Integer getTeuCapacity() {
        return teuCapacity;
    }

    public void setTeuCapacity(Integer teuCapacity) {
        this.teuCapacity = teuCapacity;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Integer getMaxRows() {
        return maxRows;
    }

    public void setMaxRows(Integer maxRows) {
        this.maxRows = maxRows;
    }
    
}
