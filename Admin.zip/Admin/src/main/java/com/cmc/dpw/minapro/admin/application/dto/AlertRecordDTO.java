package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * AlertRecord DTO
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class AlertRecordDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRecordId;
    private String alertCode;
    private String alertText;
    private String raisedBy;
    private char status;
    private Date raisedDateTime;
    private Integer closedBy;
    private Date closedDateTime;
    
    public Integer getAlertRecordId() {
        return alertRecordId;
    }
    public void setAlertRecordId(Integer alertRecordId) {
        this.alertRecordId = alertRecordId;
    }
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    public String getAlertText() {
        return alertText;
    }
    public void setAlertText(String alertText) {
        this.alertText = alertText;
    }
    public String getRaisedBy() {
        return raisedBy;
    }
    public void setRaisedBy(String raisedBy) {
        this.raisedBy = raisedBy;
    }
    public char getStatus() {
        return status;
    }
    public void setStatus(char status) {
        this.status = status;
    }
    public Date getRaisedDateTime() {
        return raisedDateTime;
    }
    public void setRaisedDateTime(Date raisedDateTime) {
        this.raisedDateTime = raisedDateTime;
    }
    public Integer getClosedBy() {
        return closedBy;
    }
    public void setClosedBy(Integer closedBy) {
        this.closedBy = closedBy;
    }
    public Date getClosedDateTime() {
        return closedDateTime;
    }
    public void setClosedDateTime(Date closedDateTime) {
        this.closedDateTime = closedDateTime;
    }

   

}
