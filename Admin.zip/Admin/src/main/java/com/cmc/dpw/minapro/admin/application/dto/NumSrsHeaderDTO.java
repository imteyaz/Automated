package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NumSrsHeaderDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String numSrsId;
    private String numsrsType;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insExtUsrFlg;
    private String updUsrCd;
    private Date updDttm;
    private String updExtUsrFlg;
    private String txnCd;
    private Integer txnNo;
    private char isDeleted;
    private Collection<NumSrsDetailsDTO>  actualNumSeriesDetails = new ArrayList<NumSrsDetailsDTO>();
    
    
    public String getNumSrsId() {
        return numSrsId;
    }
    public void setNumSrsId(String numSrsId) {
        this.numSrsId = numSrsId;
    }
    public String getNumsrsType() {
        return numsrsType;
    }
    public void setNumsrsType(String numsrsType) {
        this.numsrsType = numsrsType;
    }
    public Integer getVerStamp() {
        return verStamp;
    }
    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }
    public String getInsUsrCd() {
        return insUsrCd;
    }
    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }
    public Date getInsDttm() {
        return insDttm;
    }
    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }
    public String getInsExtUsrFlg() {
        return insExtUsrFlg;
    }
    public void setInsExtUsrFlg(String insExtUsrFlg) {
        this.insExtUsrFlg = insExtUsrFlg;
    }
    public String getUpdUsrCd() {
        return updUsrCd;
    }
    public void setUpdUsrCd(String updUsrCd) {
        this.updUsrCd = updUsrCd;
    }
    public Date getUpdDttm() {
        return updDttm;
    }
    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }
    public String getUpdExtUsrFlg() {
        return updExtUsrFlg;
    }
    public void setUpdExtUsrFlg(String updExtUsrFlg) {
        this.updExtUsrFlg = updExtUsrFlg;
    }
    public String getTxnCd() {
        return txnCd;
    }
    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }
    public Integer getTxnNo() {
        return txnNo;
    }
    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }
    public char getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
    public Collection<NumSrsDetailsDTO> getActualNumSeriesDetails() {
        return actualNumSeriesDetails;
    }
    public void setActualNumSeriesDetails(Collection<NumSrsDetailsDTO> actualNumSeriesDetails) {
        this.actualNumSeriesDetails = actualNumSeriesDetails;
    }
    

}
