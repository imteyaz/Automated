package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DamageTypeDAO;
import com.cmc.dpw.minapro.admin.application.dto.DamageTypeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageType;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * DamageType Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class DamageTypeService {

    @Autowired
    private DamageTypeDAO damageTypeDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageTypeService.class);

    /**
     * This method is used to read DamageType
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<DamageType> getDamageTypeList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  DamageType service's getDamageTypeList");
        damageTypeDAO.setClazz(DamageType.class);
        return damageTypeDAO.findAll();

    }

    /**
     * This method is used to read DamageType
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDamageTypeList(String damageTypeId, String damageTypeDesc, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageType service's searchDamageTypeList method");
        damageTypeDAO.setClazz(DamageType.class);

        String[] requestParameters = { damageTypeId, damageTypeDesc };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In DamageType service searchDamageTypeList  with damageTypeId: {} , damageTypeDesc : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageType service's searchDamageTypeList method");

        return damageTypeDAO.searchDamageTypes(damageTypeId, damageTypeDesc, start, limit);
    }

    /**
     * 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageType> containing the created DamageType data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_TYPE")
    public List<DamageType> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageType service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageType service's  create : {} ", data);

        List<DamageType> newDamageTypes = new ArrayList<DamageType>();
        List<DamageType> list = util.getEntitiesFromDto(data,DamageTypeDTO.class, DamageType.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageType damageType : list) {

            Date currentDate = new Date();
            damageType.setCreatedDateTime(currentDate);
            damageType.setLastUpdatedDateTime(currentDate);
            damageType.setCreatedBy(userId.toString());
            damageType.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageType Id property in damageType service's create : {}",
                    damageType.getDamageTypeId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageType DAO findOne");

            DamageType alreadyDamageType = damageTypeDAO.findOne(damageType.getDamageTypeId());

            if (alreadyDamageType == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageType DAO create");
                newDamageTypes.add(damageTypeDAO.create(damageType));
            } else {
                char isDeleted = alreadyDamageType.getIsDeleted();

                if (isDeleted == 'Y') {
                    damageType.setVersion(alreadyDamageType.getVersion());
                    damageType.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling damageType DAO update");
                    newDamageTypes.add(damageTypeDAO.update(damageType));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageType service's create method");
        return newDamageTypes;
    }

    /**
     * This method is used to update DamageType
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DamageType> containing the updated DamageType datas
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_TYPE")
    public List<DamageType> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageType service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  damageType  service's  update : {} ", data);
        List<DamageType> returnDamageTypes = new ArrayList<DamageType>();

        List<DamageType> updatedDamageTypes = util.getEntitiesFromDto(data,DamageTypeDTO.class, DamageType.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageType damageType : updatedDamageTypes) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageTypeId property in damageType service update : {}", damageType.getDamageTypeId());
            damageType.setLastUpdatedDateTime(currentDate);
            damageType.setLastUpdatedBy(userId.toString());
            returnDamageTypes.add(damageTypeDAO.update(damageType));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageType service's update method");

        return returnDamageTypes;
    }

    /**
     * This method is used to delete DamageType
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_DAMAGE_TYPE")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageType service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In damageType's service delete : {} ", data);
       
        List<DamageType> deletedDamageTypes = util.getEntitiesFromDto(data,DamageTypeDTO.class, DamageType.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DamageType damageType : deletedDamageTypes) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageType Id property in damageType service delete : {}",
                    damageType.getDamageTypeId());
            damageType.setLastUpdatedDateTime(currentDate);
            damageType.setLastUpdatedBy(userId.toString());
            damageType.setIsDeleted('Y');
            damageTypeDAO.delete(damageType);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageType service's delete method");
    }

}
