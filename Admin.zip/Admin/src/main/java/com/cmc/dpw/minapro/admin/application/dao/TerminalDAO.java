package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.TerminalDTO;
import com.cmc.dpw.minapro.admin.application.entities.Terminal;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * TerminalDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class TerminalDAO extends GenericDAO<Terminal> {

    @Autowired
    private Util util;
    Map<String, Object> resultMap = new HashMap<String, Object>();
    private static final Logger LOGGER = LoggerFactory.getLogger(TerminalDAO.class);
/**
 * This method is used to search Terminals
 * @param terminalIdVal
 * @param descriptionVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchTerminals(String terminalIdVal, String descriptionVal, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering in Terminal DAO's searchTerminals.....");
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(Terminal.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { terminalIdVal, descriptionVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchTerminals with terminal ID:{} ,description:{} ", searchParameters);
        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(terminalIdVal))  && terminalIdVal != null) {
            likeValue = "";
            String terminalId = likeValue.concat(percentage).concat(terminalIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("terminalId", terminalId).ignoreCase());
        }

        if (!("".equalsIgnoreCase(descriptionVal))  && descriptionVal != null) {
            likeValue = "";
           
            // needs to be changed this activity ID for exact search
            String description = likeValue.concat(percentage).concat(descriptionVal).concat(percentage);
            searchCriteria.add(Restrictions.like("description", description).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(" ******* count : {} " + count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Terminal> searchTerminals = (List<Terminal>) searchCriteria.list();
        List<TerminalDTO> searchTerminalsDtoList =  util.map(searchTerminals, TerminalDTO.class);
        String totalRecords = count.toString();
        
        LOGGER.debug("******* data from DB: {}", searchTerminalsDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchTerminalsDtoList);
        resultMap.put("totalCount", totalRecords);

        for (Terminal terminal : searchTerminals) {
            LOGGER.debug("****** Termnal ID :{}", terminal.getTerminalId());
        }
        LOGGER.debug("**** Exiting From Terminal DAO ");
        return resultMap;

    }

}
