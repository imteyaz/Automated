package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.NumSrsDTO;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsHeader;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.NumSrsHeaderService;

/**
 * Controller - Spring
 * 
 * 
 */
@Controller
@RequestMapping(value = "/numSrsHeader")
public class NumberingSeriesController {

    @Autowired
    private NumSrsHeaderService numSrsHeaderService;
    private static final Logger LOGGER = LoggerFactory.getLogger(NumberingSeriesController.class);

    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String,Object> view(
            @RequestParam(required = false) String numSrsHeaderId,
            @RequestParam(required = false) String numSrsHeaderName,
            @RequestParam(required = false) String numSrsHeaderTypeId,
            @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {

        LOGGER.info("###########Entering NumSrsHeader controller's searchNumSrsHeaders method");

        String[] requestParameters = { numSrsHeaderId, numSrsHeaderName,numSrsHeaderTypeId };
        LOGGER.debug(
                "***********Inside NumSrsHeader Controller's searchNumSrsHeaders with numSrsHeaderId: {} , numSrsHeaderName : {} , numSrsHeaderTypeId : {} ",
                requestParameters);

        try {
            LOGGER.info("###########calling numSrsHeader service");

            Map<String, Object> numSrsHeadersMap = numSrsHeaderService
                    .searchNumSrsHeaderList(numSrsHeaderId, numSrsHeaderName, numSrsHeaderTypeId, start, limit);
            LOGGER.info("###########Exiting NumSrsHeader controller's searchNumSrsHeaders method");
            return getMap(numSrsHeadersMap);

        } catch (Exception e) {
            LOGGER.error("!^!^!^!^-- Unable to Retrieve  objects from DB : {}", e.getMessage());
             LOGGER.error(MessageConstants.ERROR_INDICATOR +"NumSrsController-->search -->Catch Block :{}", e);
            return getModelMapError("Error retrieving NumSrsHeaders from database.");
        }
    }
    
    @RequestMapping(value = "/saveHeaderDetails")
    @ResponseBody public 
    Map<String,Object> saveParentChildRecords(String data,Principal principal){
        LOGGER.info("###########Entering NumSrsHeader controller's saveParentChildRecords method");
        LOGGER.debug("***********data in numSrsHeader controller's saveParentChildRecords : {} ",
                data);
        try {
            ObjectMapper mapper = new ObjectMapper();
            NumSrsDTO numSrsDetails  = mapper.readValue(data,new TypeReference<NumSrsDTO>(){});
            if(numSrsDetails!=null ){
                List delChildRecordsList = numSrsDetails.getDeletedChildRecords();
                List newChildRecordsList = numSrsDetails.getNewChildRecords();
                List updatedChildRecordsList = numSrsDetails.getUpdatedChildRecords();
                List newRecordsList = numSrsDetails.getNewParentRecords();
                List updatedRecordsList = numSrsDetails.getUpdatedParentRecords();
                List delRecordsList = numSrsDetails.getDeletedParentRecords();
                
                numSrsHeaderService.saveChanges(delChildRecordsList,newChildRecordsList,updatedChildRecordsList,newRecordsList,updatedRecordsList,delRecordsList,principal);
                numSrsDetails.setResult(MessageConstants.SUCCESS_KEY);
                LOGGER.info("###########Exiting NumSrsHeader controller's saveHeaderDetails");
            }           
        }catch (ExistingRecordException ex) {
            LOGGER.error("Error trying to save Numbering Series Definition : {}", ex);
            return getModelMapError("Error trying to create numSrsHeader :" + ex.getCustomErrorMessage());
        }catch (Exception e) {
            LOGGER.error("Error trying to save Numbering Series Definition :{}", e);
            return getModelMapError("Error trying to save Numbering Series Definition numSrsHeader.");
        }
        
        return getMap();
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return
     */
    private Map<String, Object> getMap() {
        //List<NumSrsHeader> numSrsHeaders
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> numSrsHeadersMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) numSrsHeadersMap.get(MessageConstants.TOTALCOUNT_KEY);
        List<NumSrsHeader> numSrsHeaders = (List<NumSrsHeader>) numSrsHeadersMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", numSrsHeaders);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put("data", numSrsHeaders);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            message
     * @return
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put("message", msg);
        modelMap.put("success", false);
        modelMap.put("error", true);

        return modelMap;
    }

}
