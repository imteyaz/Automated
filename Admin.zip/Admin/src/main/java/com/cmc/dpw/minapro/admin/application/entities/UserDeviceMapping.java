package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.UserDevicePk;

/**
 * UserDeviceMapping POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "UserDeviceMapping")
@Table(name = "MP_USER_DEVICE_MAPPING")
public class UserDeviceMapping implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private UserDevicePk pk ;

    @EmbeddedId
    public UserDevicePk getPk() {
        return pk;
    }

    public void setPk(UserDevicePk pk) {
        this.pk = pk;
    }
   
}
