package com.cmc.dpw.minapro.admin.web.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.BusinessExceptionEntity;
import com.cmc.dpw.minapro.admin.application.services.BusinessExceptionService;

/**
 * Controller - Spring
 * 
 * 
 */
@Controller
@RequestMapping(value = "/businessException")
public class BusinessExceptionController {

    @Autowired
    private BusinessExceptionService businessExceptionService;
    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessExceptionController.class);

    @RequestMapping(value = "/view.action")
    @ResponseBody public 
    Map<String, Object> view(
            @RequestParam(required = false) String containerId,
            @RequestParam(required = false) String businessExceptionType ,
            @RequestParam(required = false) String rotationNo,
            @RequestParam(required = false) String functionCode,
            @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {

        LOGGER.info("###########Entering BusinessExceptionEntity controller's searchBusinessExceptions method");

        String[] requestParameters = { containerId, rotationNo,businessExceptionType,functionCode };
        LOGGER.debug(
                "***********Inside BusinessExceptionEntity Controller's searchBusinessExceptions with containerId: {} , rotationNo : {} , businessExceptionType : {} ,functionCode :{}",
                requestParameters);

        try {
            LOGGER.info("###########calling businessException service");

            Map<String, Object> businessExceptionsMap = businessExceptionService
                    .searchBusinessExceptionList(containerId, rotationNo, businessExceptionType, functionCode ,start, limit);
            LOGGER.info("###########Exiting BusinessExceptionEntity controller's searchBusinessExceptions method");
            return getMap(businessExceptionsMap);

        } catch (Exception e) {
            LOGGER.error("!^!^!^!^-- Unable to Retrieve  objects from DB : {}", e.getMessage());
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"NumSrsController-->search -->Catch Block :{}", e);
            return getModelMapError("Error retrieving BusinessExceptions from database.");
        }
    }
    

    private Map<String, Object> getMap(Map<String, Object> businessExceptionsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords =  (String) businessExceptionsMap.get(MessageConstants.TOTALCOUNT_KEY);

        List<BusinessExceptionEntity> businessExceptions = (List<BusinessExceptionEntity>) businessExceptionsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", businessExceptions);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put("data", businessExceptions);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

      /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
