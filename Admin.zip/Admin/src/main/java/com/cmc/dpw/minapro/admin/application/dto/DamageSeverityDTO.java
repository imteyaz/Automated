package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * DamageSeverityDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class DamageSeverityDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageSeverityCode;
    private String description;
    
    public String getDamageSeverityCode() {
        return damageSeverityCode;
    }
    public void setDamageSeverityCode(String damageSeverityCode) {
        this.damageSeverityCode = damageSeverityCode;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    
}
