package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * Equipment DTO
 */
@JsonAutoDetect
public class EquipmentDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String equipmentId;
    private String equipmentName;
    private String equipmentDescription;
    private String make;
    private String model;
    private String equipmentTypeId;
    private String terminalId;
    private String pow;
    
    
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public String getEquipmentName() {
        return equipmentName;
    }
    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }
    public String getEquipmentDescription() {
        return equipmentDescription;
    }
    public void setEquipmentDescription(String equipmentDescription) {
        this.equipmentDescription = equipmentDescription;
    }
    public String getMake() {
        return make;
    }
    public void setMake(String make) {
        this.make = make;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getEquipmentTypeId() {
        return equipmentTypeId;
    }
    public void setEquipmentTypeId(String equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getPow() {
        return pow;
    }
    public void setPow(String pow) {
        this.pow = pow;
    }

}
