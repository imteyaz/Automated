package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.ColorCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.ColorCodeService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/colorCode")
public class ColorCodeController {

    @Autowired
    private ColorCodeService colorCodeService;
    private static final Logger LOGGER = LoggerFactory.getLogger(ColorCodeController.class);
    /**
     * This method searches for all the colorCodes matching the search criteria
     * as entered by the end user
     * @param itemName
     * @param itemGroup
     * @param start
     * @param limit
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String itemName,
            @RequestParam(required = false) String itemGroup, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ColorCodeController Seacrh ColorCode method");
        String[] requestParameters = { itemName, itemGroup };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ColorCodeController-->Seacrh itemName :{}, itemGroup:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ColorCodeController Seacrh ColorCode method");
            Map<String, Object> colorCodesMap = colorCodeService.searchColorCodeList(itemName, itemGroup, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCodeController Seacrh ColorCode method");
            return getMap(colorCodesMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Search", e);
            return getModelMapError("Error retrieving ColorCodes from database.");
        }
    }
    
    /**
     * This method creates the ColorCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ColorCodeController Create ColorCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER,data);

        try {
            List<ColorCode> colorCodes = colorCodeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCodeController Create ColorCode method");
            return getMap(colorCodes);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create ColorCode :{}" + cause.getMessage());
            
        } catch(ExistingRecordException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create colorCode :{}" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create colorCode.");
        }
    }


    /**
     * This method updates the ColorCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ColorCodeController Update ColorCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {
            List<ColorCode> colorCodes = colorCodeService.update(data, principal);
            return getMap(colorCodes);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update colorCode. ");
        }
    }


    /**
     * This method deletes the ColorCode.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
          
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ColorCodeController Delete ColorCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            colorCodeService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCodeController Delete ColorCode method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete colorCode.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<ColorCode> colorCodes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, colorCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> colorCodesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) colorCodesMap.get("totalCount");

        List<ColorCode> colorCodes = (List<ColorCode>) colorCodesMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , colorCodes);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, colorCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return  Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
