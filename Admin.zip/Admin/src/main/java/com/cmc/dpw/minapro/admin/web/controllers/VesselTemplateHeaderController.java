package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.TemplateDetailsDTO;
import com.cmc.dpw.minapro.admin.application.dto.TemplateHeaderDTO;
import com.cmc.dpw.minapro.admin.application.entities.TemplateDetails;
import com.cmc.dpw.minapro.admin.application.entities.TemplateHeader;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.VesselTemplateHeaderService;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Controller - Spring
 * 
 * 
 */
@Controller
@RequestMapping(value = "/vesselTemplate")
public class VesselTemplateHeaderController {

    @Autowired
    private VesselTemplateHeaderService vesselTemplateHeaderService;
    @Autowired
    private Util util ;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselTemplateHeaderController.class);

    @RequestMapping(value = "/view.action")
    @ResponseBody public 
    Map<String, Object> view(
            @RequestParam(required = false) String vesselTemplateHeaderId,
            @RequestParam(required = false) String vesselTemplateHeaderName,
            @RequestParam(required = false) String vesselTemplateHeaderTypeId,
            @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {

        LOGGER.info("###########Entering TemplateHeader controller's searchVesselTemplateHeaders method");

        String[] requestParameters = { vesselTemplateHeaderId, vesselTemplateHeaderName,vesselTemplateHeaderTypeId };
        LOGGER.debug(
                "***********Inside TemplateHeader Controller's searchVesselTemplateHeaders with vesselTemplateHeaderId: {} , vesselTemplateHeaderName : {} , vesselTemplateHeaderTypeId : {} ",
                requestParameters);

        try {
            LOGGER.info("###########calling vesselTemplateHeader service");

            Map<String, Object> vesselTemplateHeadersMap = vesselTemplateHeaderService
                    .searchVesselTemplateHeaderList(vesselTemplateHeaderId, vesselTemplateHeaderName, vesselTemplateHeaderTypeId, start, limit);
            LOGGER.info("###########Exiting TemplateHeader controller's searchVesselTemplateHeaders method");
            return getMap(vesselTemplateHeadersMap);

        } catch (Exception e) {
            LOGGER.error("!^!^!^!^-- Unable to Retrieve  objects from DB : {}", e.getMessage());
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"NumSrsController-->search -->Catch Block :{}", e);
            return getModelMapError("Error retrieving VesselTemplateHeaders from database.");
        }
    }
    
    @RequestMapping(value = "/saveHeaderDetails")
    @ResponseBody public 
    Map<String, Object> saveParentChildRecords(@RequestParam Map<String,Object> data,Principal principal) {
        LOGGER.info("###########Entering TemplateHeader controller's saveParentChildRecords method");
        LOGGER.debug("***********data in vesselTemplateHeader controller's saveParentChildRecords : {} ",
                data);
         SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.setDateFormat(dateFormat);
            
            String deletedChildListJson = (String) data.get("deletedChildRecords");
            List<TemplateDetailsDTO> deletedChildListDTO  = mapper.readValue(deletedChildListJson,  new TypeReference<List<TemplateDetailsDTO>>(){});
            List<TemplateDetails> deletedChildList = util.map(deletedChildListDTO, TemplateDetails.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "deletedChildList :" + deletedChildList  );
            
            String updatedChildListJson = (String) data.get("updatedChildRecords");
            List<TemplateDetailsDTO> updatedChildListDTO  = mapper.readValue(updatedChildListJson,  new TypeReference<List<TemplateDetailsDTO>>(){});
            List<TemplateDetails> updatedChildList = util.map(updatedChildListDTO, TemplateDetails.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "updatedChildList :" + updatedChildList  );
            
            String newChildListJson = (String) data.get("newChildRecords");
            List<TemplateDetailsDTO> newChildListDTO  = mapper.readValue(newChildListJson,  new TypeReference<List<TemplateDetailsDTO>>(){});
            List<TemplateDetails> newChildList = util.map(newChildListDTO, TemplateDetails.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "newChildList :" + newChildList  );
            
            
            String newParentListJson = (String) data.get("newParentRecords");
            List<TemplateHeaderDTO> newParentListDTO  = mapper.readValue(newParentListJson,  new TypeReference<List<TemplateHeaderDTO>>(){});
            List<TemplateHeader> newParentList = util.map(newParentListDTO, TemplateHeader.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "newParentList :" + newParentList  );
            
            String updatedParentListJson = (String) data.get("updatedParentRecords");
            List<TemplateHeaderDTO> updatedParentListDTO  = mapper.readValue(updatedParentListJson,  new TypeReference<List<TemplateHeaderDTO>>(){});
            List<TemplateHeader> updatedParentList = util.map(updatedParentListDTO, TemplateHeader.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "updatedParentList :" + updatedParentList  );
            
            String deletedParentListJson = (String) data.get("deletedParentRecords");
            List<TemplateHeaderDTO> deletedParentListDTO  = mapper.readValue(deletedParentListJson,  new TypeReference<List<TemplateHeaderDTO>>(){});
            List<TemplateHeader> deletedParentList = util.map(deletedParentListDTO, TemplateHeader.class) ;
            LOGGER.info(MessageConstants.INFO_INDICATOR + "deletedParentList :" + deletedParentList  );
            
            vesselTemplateHeaderService.saveChanges(deletedChildList,newChildList,updatedChildList,newParentList,updatedParentList,deletedParentList,principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR + "-->Exiting TemplateHeader controller's saveHeaderDetails method");
            return getMap();
            
        }catch (ExistingRecordException ex) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", ex);
            return getModelMapError("Error trying to create Template :" + ex.getCustomErrorMessage());
            
        }catch (Exception e) {
            LOGGER.error("Error trying to save Vessel Template :{}", e);
            return getModelMapError("Error trying to save Vessel Template Header.");
        }
        
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return
     */
    private Map<String, Object> getMap() {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> vesselTemplateHeadersMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) vesselTemplateHeadersMap.get(MessageConstants.TOTALCOUNT_KEY);

        List<TemplateHeader> vesselTemplateHeaders = (List<TemplateHeader>) vesselTemplateHeadersMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", vesselTemplateHeaders);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put("data", vesselTemplateHeaders);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

      /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }
   
}
