package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * DelayReasonCode POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "DelayReasonCode")
@Table(name = "MP_DELAYREASONCODE_MASTER")
public class DelayReasonCode extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String delayReasonId;
    private String description;
    private String delayType;
    private String subType;
    private String alertCode;
    private Collection<DelayRecording> delayRecordings = new ArrayList<DelayRecording>();
    private char machineStoppage;
    private char isDelayOpen ;
    

    
    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "DELAY_CODE", referencedColumnName = "DELAY_REASON_ID",insertable=false,updatable=false)
    public Collection<DelayRecording> getDelayRecordings() {
        return delayRecordings;
    }

    public void setDelayRecordings(Collection<DelayRecording> delayRecordings) {
        this.delayRecordings = delayRecordings;
    }

    @Id
    @Column(name = "DELAY_REASON_ID", nullable = false)
    public String getDelayReasonId() {
        return delayReasonId;
    }

    public void setDelayReasonId(String delayReasonId) {
        this.delayReasonId = delayReasonId;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "DELAY_TYPE")
    public String getDelayType() {
        return delayType;
    }

    public void setDelayType(String delayType) {
        this.delayType = delayType;
    }

    @Column(name = "SUB_TYPE")
    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }
    
    @Column(name = "ALERT_CODE") 
    public String getAlertCode() {
        return alertCode;
    }

    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }

    @Column(name = "MACHINE_STOPPAGE")
    public char getMachineStoppage() {
        return machineStoppage;
    }

    public void setMachineStoppage(char machineStoppage) {
        this.machineStoppage = machineStoppage;
    }

    @Transient
    public char getIsDelayOpen() {
        return isDelayOpen;
    }

    public void setIsDelayOpen(char isDelayOpen) {
        this.isDelayOpen = isDelayOpen;
    }
    
    
    
    
}
