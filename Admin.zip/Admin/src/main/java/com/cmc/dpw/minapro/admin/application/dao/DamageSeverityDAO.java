package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.DamageSeverityDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageSeverity;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * DamageSeverityDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class DamageSeverityDAO extends GenericDAO<DamageSeverity> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageSeverityDAO.class);
/**
 * This method is used to search DamageSeveritys
 * @param damageSeverityCodeVal
 * @param descriptionVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchDamageSeveritys(String damageSeverityCodeVal, String descriptionVal, int start,
            int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +" Entering DamageCode DAO's searchDamageSeveritys method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(DamageSeverity.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { damageSeverityCodeVal, descriptionVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchDamageCodes with damageSeverityCode: {} , description : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(damageSeverityCodeVal))  && damageSeverityCodeVal != null) {
            likeValue = "";
            String damageSeverityCode = likeValue.concat(percentage).concat(damageSeverityCodeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("damageSeverityCode", damageSeverityCode));

        }

        if (!("".equalsIgnoreCase(descriptionVal))  && descriptionVal != null) {
            likeValue = "";
            String description = likeValue.concat(percentage).concat(descriptionVal).concat(percentage);
            searchCriteria.add(Restrictions.like("description", description).ignoreCase());

        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******** Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<DamageSeverity> searchDamageSeveritys = (List<DamageSeverity>) searchCriteria.list();
        List<DamageSeverityDTO> searchDamageSeverityDtoList =  util.map(searchDamageSeveritys, DamageSeverityDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data: {}", searchDamageSeverityDtoList);
        LOGGER.debug("******* totalCount: {}", totalRecords);

        resultMap.put("data", searchDamageSeverityDtoList);
        resultMap.put("totalCount", totalRecords);

        for (DamageSeverity damageSeverity : searchDamageSeveritys) {
            LOGGER.debug("******* damageSeverityCode : {}", damageSeverity.getDamageSeverityCode());

        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting DamageSeverityDAO's searchdamageSeveritys method ");

        return resultMap;
    }
}
