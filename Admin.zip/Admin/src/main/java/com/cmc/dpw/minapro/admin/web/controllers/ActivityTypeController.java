package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.ActivityType;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.ActivityTypeService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Controller
@RequestMapping(value = "/activityType")
public class ActivityTypeController {
/**
 * This method searches for all the activityTypes matching the search criteria
 * as entered by the end user
 * @param activityTypeId
 * @param description
 * @return  Map<String, Object> containing the data and success indicator.
 */
    @Autowired
    private ActivityTypeService activityTypeService;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityTypeController.class);

    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String activityTypeId,
            @RequestParam(required = false) String description, @RequestParam(required = false) int limit,
            @RequestParam(required = false) int start) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ActivityType controller's searchActivityTypes method");

        String[] requestParameters = { activityTypeId, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ActivityTypeCntroller-->Seacrh activityTypeId :{}, description:{}",

                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"calling activityType service");
            Map<String, Object> activityTypesMap = activityTypeService.searchActivityTypeList(activityTypeId,
                    description, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType controller's searchActivityTypes method");
            return getMap(activityTypesMap);
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ActivityTypeCntroller-->Search ActivityType-->Catch Block :{}", e);
            return getModelMapError("Error retrieving activityTypes from database.");
        }
    }
    
    /**
     * This method creates the ActivityType as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ActivityType controller's CreateActivityTypes method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);

        try {
            List<ActivityType> activityTypes = activityTypeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType controller's createActivityTypes method");
            return getMap(activityTypes);
        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError("Error trying to create ActivityType :{}" + cause.getMessage());
        } catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create activityType :{}" + e.getCustomErrorMessage());
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            return getModelMapError("Error trying to create activityType.");
        }
    }
    
    /**
     * This method updates the ActivityType as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
         LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {
            List<ActivityType> activityTypes = activityTypeService.update(data, principal);
            return getMap(activityTypes);
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ActivityTypeCntroller-->Update ActivityType-->Catch Block :{}", e);
            return getModelMapError("Error trying to update activityType. ");
        }
    }
    
    /**
     * This method deletes the ActivityType.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
          
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ActivityType controller's deleteActivityTypes method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);

        try {
            activityTypeService.delete(data, principal);
            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityType controller's deleteActivityTypes method");
            return modelMap;
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ActivityTypeCntroller-->delete ActivityType-->Catch Block :{}", e);
            return getModelMapError("Error trying to delete activityType.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return  Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<ActivityType> activityTypes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, activityTypes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> activityTypesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) activityTypesMap.get("totalCount");

        List<ActivityType> activityTypes = (List<ActivityType>) activityTypesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", activityTypes);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, activityTypes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return  Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        return modelMap;
    }

}
