package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
/**
 * Trailer POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Trailer")
@Table(name = "MP_TRAILER_MASTER")
public class Trailer extends Audit implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Integer trailerId;
    private String trailerNo;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trailerSequence")
    @SequenceGenerator(name = "trailerSequence", sequenceName = "MP_TRAILER_MASTER_ID", allocationSize = 1, initialValue = 30)
    @Column(name = "TRAILER_ID", nullable = false)
    public Integer getTrailerId() {
        return trailerId;
    }

    public void setTrailerId(Integer trailerId) {
        this.trailerId = trailerId;
    }

    @Column(name = "TRAILER_NO", nullable = false)
    public String getTrailerNo() {
        return trailerNo;
    }

    public void setTrailerNo(String trailerNo) {
        this.trailerNo = trailerNo;
    }
   
}
