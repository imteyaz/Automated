package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.CheckListHeaderDTO;
import com.cmc.dpw.minapro.admin.application.entities.CheckListHeader;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * CheckListHeader DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class CheckListHeaderDAO extends GenericDAO<CheckListHeader> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListHeaderDAO.class);
    
    /**
     * This method is used to search CheckListHeaders
     * @param checkListHeaderIdVal
     * @param checkListHeaderNameVal
     * @param checkListHeaderTypeVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchCheckListHeaders(String checkListHeaderIdVal, String checkListHeaderNameVal,
            String checkListHeaderTypeVal, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckListHeader DAO's searchCheckListHeaders method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";
        Integer i = 0;

        Criteria searchCriteria = session.createCriteria(CheckListHeader.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { checkListHeaderIdVal, checkListHeaderNameVal, checkListHeaderTypeVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchCheckListHeaders in CheckListHeader DAO with checkListHeaderId: {} , checkListHeaderName : {} , checkListHeaderType : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(checkListHeaderIdVal))  && checkListHeaderIdVal != null) {
            likeValue = "";
            i++;
            searchCriteria.add(Restrictions.eq("checkListHeaderId", Integer.parseInt(checkListHeaderIdVal)));
        }

        if (!("".equalsIgnoreCase(checkListHeaderNameVal))  && checkListHeaderNameVal != null) {
            likeValue = "";
            i++;
            String checkListHeaderName = likeValue.concat(percentage).concat(checkListHeaderNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("name", checkListHeaderName).ignoreCase());

        }

        if (!("".equalsIgnoreCase(checkListHeaderTypeVal))  && checkListHeaderTypeVal != null) {
            likeValue = "";
            i++;
            String checkListHeaderType = likeValue.concat(percentage).concat(checkListHeaderTypeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("type", checkListHeaderType).ignoreCase());
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        
        List<CheckListHeader> searchCheckListHeaders = null ;
        
        if (i == 0) {
            Query query = session.createQuery("select distinct ch from CheckListHeader ch left join fetch ch.actualRoles where ch.isDeleted = 'N' ");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<CheckListHeader> heasdersList = query.list();

            searchCheckListHeaders = heasdersList;
        } else {

            searchCheckListHeaders = searchCriteria.list();
        }

        String totalRecords = count.toString();

        LOGGER.debug("******* data from DB: {}", searchCheckListHeaders);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        List<CheckListHeader> searchCheckListHeadersResults = new ArrayList<CheckListHeader>() ;
        
        for (Object obj : searchCheckListHeaders) {

            CheckListHeader currentCheckListHeader = null ;
            
            if(i==0){
                currentCheckListHeader =  (CheckListHeader) obj ;
            }else{
                Object[] checkRoleArray = (Object[]) obj ;
                currentCheckListHeader  = (CheckListHeader) checkRoleArray[1];
            }
            
            List<String> assignedRoles = new ArrayList<String>();
            
            StringBuilder roleNames = new StringBuilder();
            Collection<Role> actualRoles = currentCheckListHeader.getActualRoles();
            int roleCount = actualRoles.size();
            int j = 0;
            for (Role currentRole : actualRoles) {
                j++;
                String roleId = String.valueOf(currentRole.getIntUserGroupId());
                assignedRoles.add(roleId);
                roleNames.append(currentRole.getUserGroupName());

                if (roleCount != j) {
                    roleNames.append(',');
                }
            }
            currentCheckListHeader.setAllRoles(roleNames.toString());
            searchCheckListHeadersResults.add(currentCheckListHeader);
            
            LOGGER.debug("***** currentCheckListHeaderID: {}",currentCheckListHeader.getCheckListHeaderId());
            LOGGER.debug("***** is mapped to roles: {}",currentCheckListHeader.getCheckListHeaderId());
        }
        
        List<CheckListHeaderDTO> searchCheckListHeaderDtoList =  util.map(searchCheckListHeadersResults, CheckListHeaderDTO.class);
        
        resultMap.put("data", searchCheckListHeaderDtoList);
        resultMap.put("totalCount", totalRecords);
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" exiting checkListHeaderDAO's searchCheckListHeaders method ");
        return resultMap;
    }
}
