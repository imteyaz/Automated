package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DeviceDAO;
import com.cmc.dpw.minapro.admin.application.dao.UserDeviceMappingDAO;
import com.cmc.dpw.minapro.admin.application.dto.DeviceDTO;
import com.cmc.dpw.minapro.admin.application.entities.Device;
import com.cmc.dpw.minapro.admin.application.entities.UserDeviceMapping;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Device Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class DeviceService {
    
    @Autowired
    private DeviceDAO deviceDAO;
    @Autowired
    private UserDeviceMappingDAO userDeviceMappingDAO ;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceService.class);

    /**
     * This method is used to read Device
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Device> getDeviceList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Device service's getDeviceList");
        deviceDAO.setClazz(Device.class);
        return deviceDAO.findAll();

    }

    /**
     * This method is used to read Device 
     * @return Map<String, Object> containing the search Device data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDeviceList(String deviceId, String ipAddress, String equipmentId, String make,
            String model, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Device service's searchDeviceList method");
        deviceDAO.setClazz(Device.class);

        String[] requestParameters = { deviceId, ipAddress, equipmentId, make, model };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In Device service searchActivityCodeswith deviceId: {} , ipAddress : {}, equipmentId : {}, make : {}, model : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Device service's searchDeviceList method");
        return deviceDAO.searchDevices(deviceId, ipAddress, equipmentId, make, model, start, limit);

    }

    /**
     * This method is used to create Device
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<Device> containing created Device data
     * @throws ExistingRecordException
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_DEVICE_MASTER")
    public List<Device> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Device service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  device service's  create : {} ", data);
        List<Device> newDevices = new ArrayList<Device>();

        List<Device> list = util.getEntitiesFromDto(data, DeviceDTO.class,Device.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (Device device : list) {
            try {
                checkEquipmentMapping(device);
                checkDeviceStatus(device) ;
            } catch (InvalidValueException e) {
                LOGGER.error(MessageConstants.ERROR_INDICATOR +"DeviceService-->create-->InvalidValueException Catch Block :{}", e);
                throw new ExistingRecordException(e.getCustomErrorMessage()) ;
            }
            Date currentDate = new Date();

            device.setCreatedDateTime(currentDate);
            device.setLastUpdatedDateTime(currentDate);
            device.setCreatedBy(userId.toString());
            device.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"deviceId property in device service create : {}", device.getDeviceId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling device DAO findOne");

            Device alreadyDevice = deviceDAO.findOne(device.getDeviceId());

            if (alreadyDevice == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling device DAO create");
                newDevices.add(deviceDAO.create(device));
            } else {
                char isDeleted = alreadyDevice.getIsDeleted();

                if (isDeleted == 'Y') {
                    device.setVersion(alreadyDevice.getVersion());
                    device.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling device DAO update");
                    newDevices.add(deviceDAO.update(device));
                }   else {

                    // end of else - entity not null
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
            }

            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Device service's create method");
        return newDevices;
    }

    /**
     * This method is used to update Device
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<Device> containing updated Device data
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_DEVICE_MASTER")
    public List<Device> update(Object data, Principal principal) throws InvalidValueException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Device service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  device  service's  update : {} ", data);
        List<Device> returnDevices = new ArrayList<Device>();

        List<Device> updatedDevices = util.getEntitiesFromDto(data, DeviceDTO.class,Device.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Device device : updatedDevices) {
            checkEquipmentMapping(device);
            checkDeviceStatus(device) ;
            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"deviceId property in device service update : {}", device.getDeviceId());
            device.setLastUpdatedDateTime(currentDate);
            device.setLastUpdatedBy(userId.toString());
            returnDevices.add(deviceDAO.update(device));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Device service's update method");
        return returnDevices;
    }

    private Device checkEquipmentMapping(Device device) throws InvalidValueException{
        
        Device duplicateDevice = null ;
        List<Device>  duplicateDeviceList = deviceDAO.findByPropertyValue(Device.class, "equipmentId", device.getEquipmentId(), true);
        
        if(duplicateDeviceList!=null && !duplicateDeviceList.isEmpty()){
            duplicateDevice = duplicateDeviceList.get(0);
            
           if(!duplicateDevice.getDeviceId().equalsIgnoreCase(device.getDeviceId()) && duplicateDevice.getIsDeleted()== 'N'){
               throw new InvalidValueException(MessageConstants.DUPLICATE_DEVICE_EQUIPMENT_MESSAGE_START + "A Device having device Id as " + duplicateDevice.getDeviceId() + " is already mapped to Equipment Id  " + duplicateDevice.getEquipmentId() + " !" + MessageConstants.DUPLICATE_DEVICE_EQUIPMENT_MESSAGE_END);
           }
        }
        return duplicateDevice ;
    }
    
    
    private UserDeviceMapping checkDeviceStatus(Device device) throws InvalidValueException{
            
            UserDeviceMapping deviceInUse = null ;
            userDeviceMappingDAO.setClazz(UserDeviceMapping.class);
            List<UserDeviceMapping>  deviceInUseList = userDeviceMappingDAO.findByPropertyValue(UserDeviceMapping.class, "pk.deviceId", device.getDeviceId(), true);
            
            if(deviceInUseList!=null && !deviceInUseList.isEmpty()){
                deviceInUse = deviceInUseList.get(0);
                throw new InvalidValueException(MessageConstants.DEVICE_IN_USE_MESSAGE_START + "A User having user Id as " + deviceInUse.getPk().getUserId() + " is already logged on to Device Id  " + deviceInUse.getPk().getDeviceId() + " !" + MessageConstants.DEVICE_IN_USE_MESSAGE_END);
            }
            
            return deviceInUse ;
            
   }
    
    /**
     * This method is used to delete Device
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @throws InvalidValueException 
     */
    @Transactional
    @Manipulate(table = "MP_DEVICE_MASTER")
    public void delete(Object data, Principal principal) throws InvalidValueException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Device service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In device's service delete : {} ", data);

        List<Device> deletedDevices = util.getEntitiesFromDto(data, DeviceDTO.class,Device.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Device device : deletedDevices) {
            checkDeviceStatus(device);
            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"deviceId property in device service delete : {}", device.getDeviceId());
            device.setLastUpdatedDateTime(currentDate);
            device.setLastUpdatedBy(userId.toString());
            device.setIsDeleted('Y');
            deviceDAO.delete(device);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Device service's delete method");
    }
   
}
