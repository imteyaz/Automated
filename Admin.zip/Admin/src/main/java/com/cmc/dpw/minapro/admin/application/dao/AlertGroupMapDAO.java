package com.cmc.dpw.minapro.admin.application.dao;

import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.entities.AlertGroupAssociation;

/**
 * AlertConfiguration DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class AlertGroupMapDAO extends GenericDAO<AlertGroupAssociation> {
    
}
