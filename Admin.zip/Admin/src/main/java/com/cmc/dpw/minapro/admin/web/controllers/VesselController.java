package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.VesselDTO;
import com.cmc.dpw.minapro.admin.application.entities.Bay;
import com.cmc.dpw.minapro.admin.application.entities.BayRow;
import com.cmc.dpw.minapro.admin.application.entities.BayTier;
import com.cmc.dpw.minapro.admin.application.entities.Cell;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselSection;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.VesselService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/vessel")
public class VesselController {

    @Autowired
    private VesselService vesselService;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselController.class);
    /**
     * This method searches for all the Vessels matching the search criteria
     * as entered by the end user 
     * @param vesselCode
     * @param vesselType
     * @param vesselName
     * @param start
     * @param limit
     * @return Map<String, Object> containing the data and success indicator.
     */
   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String vesselNo,
            @RequestParam(required = false) String vesselCode, @RequestParam(required = false) String vesselName,
            @RequestParam(required = false) String vesselType, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselController Search Vessel method");
        

        String[] requestParameters = { vesselNo, vesselCode, vesselName, vesselType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselController-->Seacrh vesselNo:{},vesselCode:{},vesselName:{},vesselType:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselController Search Vessel method");

            Map<String, Object> vesselsMap = vesselService.searchVesselList(vesselNo, vesselCode, vesselName,
                    vesselType, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselController Search Vessel method");
            return getMap(vesselsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR, e);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselController-->View Vessels-->Catch Block :{}", e.getStackTrace());
            return getModelMapError("Error retrieving Vessels from database.");
        }
    }

    /**
     * This method creates the vessel as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created vessel data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/CreateVesselProfile", method = { RequestMethod.POST })
    @ResponseBody public
    Map<String, Object> createVessel(String vesselData) {
        
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> createVessel()  ");
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            VesselDTO vesselDetails = objectMapper.readValue(vesselData, new TypeReference<VesselDTO>() {
            });

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"new vessel details from UI",vesselDetails);
            if (vesselDetails != null) {

                Vessel vesselInfo = vesselDetails.getVesselInfo();
                List<VesselSection> sectionList = vesselDetails.getSectionList();
                List<Bay> bayList = vesselDetails.getBayList();
                List<BayRow> bayRowList = vesselDetails.getBayRowList();
                List<BayTier> bayTierList = vesselDetails.getBayTierList();
                List<Cell> cellList = vesselDetails.getCellList();

                vesselService.createVessel(vesselInfo, sectionList, bayList, bayRowList, bayTierList, cellList);

                vesselDetails.setResult(MessageConstants.SUCCESS_KEY);
                modelMap.put(MessageConstants.SUCCESS_KEY, true);

            }

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController--> createVessel()  -->Exception Block  ", e);
            return getModelMapError(e.getMessage());
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->VesselController--> createVessel()  ");
        return modelMap;
    }
    
    
    /**
     * This method adds the vessel as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the added vessel data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/addVesselProfile", method = { RequestMethod.GET })
    @ResponseBody public
    ModelAndView addVessel() {
        ModelAndView model = new ModelAndView("vesselProfile");
        model.addObject(MessageConstants.APP_VERSION_KEY, MessageConstants.APP_VERSION);
        
        return  model;
    }

    /**
     * This method is used to edit Vessel Profile
     * @param vesselNo
     * @return ModelAndView
     */
    @RequestMapping(value = "/editVesselProfile", method = { RequestMethod.GET })
    @ResponseBody public
    ModelAndView editVessel(String vesselNo) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> editVesselProfile()  ");
        ModelAndView model = new ModelAndView("editVesselProfile");
        model.addObject(MessageConstants.APP_VERSION_KEY, MessageConstants.APP_VERSION);
        VesselDTO vDto = null;

        try {
            vDto = vesselService.editVessel(vesselNo);

            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();

            String jsonVesselDTO = ow.writeValueAsString(vDto);
            if (jsonVesselDTO == null) {
                jsonVesselDTO = MessageConstants.EMPTY;
            }
            model.addObject(MessageConstants.JSONVESSELDTO_KEY, jsonVesselDTO);
            model.addObject(MessageConstants.SUCCESS_KEY, true);
            model.addObject(MessageConstants.EMPTY);

        } catch (Exception e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Edit Vessel-->Catch Block :{}", e);
            model.addObject(MessageConstants.SUCCESS_KEY, false);
            model.addObject(MessageConstants.ERROR_KEY, e.getMessage());
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->VesselController--> editVesselProfile()  ");
        return model;
    }

    /**
     * This method is used to view Vessel Profile
     * @param vesselNo
     * @return ModelAndView
     */
    @RequestMapping(value = "/viewVesselProfile", method = { RequestMethod.GET })
    @ResponseBody public
    ModelAndView viewVessel(String vesselNo) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> viewVesselProfile()  ");
        ModelAndView model = new ModelAndView("viewVesselProfile");
        model.addObject(MessageConstants.APP_VERSION_KEY, MessageConstants.APP_VERSION);
        VesselDTO vDto = null;

        try {
            vDto = vesselService.editVessel(vesselNo);

            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();

            String jsonVesselDTO = ow.writeValueAsString(vDto);
            if (jsonVesselDTO == null) {
                jsonVesselDTO = "'empty'";
            }
            model.addObject(MessageConstants.JSONVESSELDTO_KEY, jsonVesselDTO);
            model.addObject(MessageConstants.SUCCESS_KEY, true);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Seacrh Vessel-->Catch Block :{}", e);
            model.addObject(MessageConstants.SUCCESS_KEY, false);
            model.addObject(MessageConstants.ERROR_KEY, e.getMessage());
        }

        LOGGER.info("END-->VesselController--> viewVesselProfile()  ");
        return model;
    }

    /**
     * This method is used to delete Vessel by Vessel No
     * @param vesselNo
     * @return Map<String, Object> modelMap
     */
    @RequestMapping(value = "/deleteVesselByvesselNo", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> deleteVesselByvesselNo(String vesselNo) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        String[] vesselArray = vesselNo.split(",");

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> deleteVesselByvesselNo() ");

            vesselService.deleteVesselByvesselNo(vesselArray);
            modelMap.put(MessageConstants.STATUS_KEY, "success");

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->VesselController--> deleteVesselByvesselNo() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.FAILURE_STATUS);
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->deleteVesselByvesselNo()-->Exception block-->", e);
        }
        return modelMap;

    }

    /**
     * This method is used to saveEditedVessel
     * @param vesselData
     * @return Map<String, Object> modelMap
     */
    @RequestMapping(value = "/saveEditedVessel", method = { RequestMethod.POST })
    @ResponseBody public
    Map<String, Object> saveModifiedVessel(String vesselData) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> saveModifiedVessel()  ");

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            VesselDTO vesselDetails = objectMapper.readValue(vesselData, new TypeReference<VesselDTO>() {
            });

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"edited vessel details from UI",vesselDetails);
            if (vesselDetails != null) {

                Vessel vesselInfo = vesselDetails.getVesselInfo();
                List<VesselSection> sectionList = vesselDetails.getSectionList();
                List<Bay> bayList = vesselDetails.getBayList();
                List<BayRow> bayRowList = vesselDetails.getBayRowList();
                List<BayTier> bayTierList = vesselDetails.getBayTierList();
                List<Cell> cellList = vesselDetails.getCellList();

                vesselService.saveEditedVessel(vesselInfo, sectionList, bayList, bayRowList, bayTierList, cellList);

                vesselDetails.setResult(MessageConstants.SUCCESS_KEY);
                modelMap.put(MessageConstants.SUCCESS_KEY, true);

            }

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController--> saveModifiedVessel()  -->Exception Block  ", e);
            return getModelMapError(e.getMessage());
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->VesselController--> saveModifiedVessel()  ");
        return modelMap;
    }

    /**
     * This method is used to checkVesselNo
     * @param vesselNo
     * @return  Map<String, Object> modelMap
     */
    @RequestMapping(value = "/checkVesselNo", method = RequestMethod.POST)
    @ResponseBody public
    Map<String, Object> validateVesselNo(String vesselNo) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> validateVesselNo() ");

            modelMap = (Map<String, Object>) vesselService.validateVesselNo(vesselNo);

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->VesselController--> validateVesselNo() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.FAILURE_STATUS);
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error("VesselController-->validateVesselNo()-->Exception block-->", e);
        }
        return modelMap;

    }

    /**
     * This methos is used to checkVesselName
     * @param vesselName
     * @return Map<String, Object> modelMap
     */
    @RequestMapping(value = "/checkVesselName", method = RequestMethod.POST)
    @ResponseBody public
    Map<String, Object> validateVesselName(String vesselName) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->VesselController--> validateVesselName() ");

            modelMap = (Map<String, Object>) vesselService.validateVesselName(vesselName);

            LOGGER.info("END-->VesselController--> validateVesselName() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.FAILURE_STATUS);
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->validateVesselName()-->Exception block-->", e);
        }
        return modelMap;

    }

    /**
     * This method is used to create vessel
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object>
     */
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering VesselController Create Vessel method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            List<Vessel> vessels = vesselService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselController Create Vessel method");
            return getMap(vessels);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Create Vessel-->DataIntegrityViolationException: {}", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError(MessageConstants.VESSEL_CREATE_ERROR_MESSAGE + cause.getMessage());
            
        }  catch (ExistingRecordException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Create Vessel-->ExistingRecordException :{}", e);
            return getModelMapError(MessageConstants.VESSEL_CREATE_ERROR_MESSAGE + e.getCustomErrorMessage());
            
        }  catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Create Vessel--> Generic Exception :{}", e);
            return getModelMapError("Error trying to create Vessel.");
        }
    }

    /**
     * This method is used to update vessel
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object>
     */
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselController Update Vessel method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            List<Vessel> vessels = vesselService.update(data, principal);
            return getMap(vessels);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"VesselController-->Update Vessel-->Catch Block :{}", e);
            return getModelMapError("Error trying to update Vessel. ");

        }
    }

    /**
     * This method is used to delete vessel
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object>
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start VesselController Delete Vessel method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselController-->Delete Vessel:{}", data);
        try {
            vesselService.delete(data, principal);

            Map<String, Object> map = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            map.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting VesselController delete Vessel method");
            return map;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"VesselController-->Delete Vessel-->Exception Stacktrace :{}", e.getStackTrace());
            return getModelMapError("Error trying to delete Vessel.");

        }
    }

    /**
     * Generates Map to return in the AndView
     * 
     * @param contacts
     * @return  Map<String, Object> map
     */
    private Map<String, Object> getMap(List<Vessel> vessels) {

        Map<String, Object> map = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        map.put(MessageConstants.DATA_KEY, vessels);
        map.put(MessageConstants.SUCCESS_KEY, true);
        return map;
    }

    private Map<String, Object> getMap(Map<String, Object> vesselsMap) {

        Map<String, Object> map = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) vesselsMap.get("totalCount");

        List<Vessel> vessels = (List<Vessel>) vesselsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", vessels);

        map.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        map.put(MessageConstants.DATA_KEY, vessels);
        map.put(MessageConstants.SUCCESS_KEY, true);

        return map;
    }

    /**
     * Generates Map to return in the AndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> map 
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> map = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        map.put(MessageConstants.MESSAGE_KEY, msg);
        map.put(MessageConstants.SUCCESS_KEY, false);
        map.put(MessageConstants.ERROR_KEY, true);

        return map;
    }

}
