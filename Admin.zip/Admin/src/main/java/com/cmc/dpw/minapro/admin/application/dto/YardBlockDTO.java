package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class YardBlockDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String blockIdentifier;
    private String contSize;
    private String blockType;
    private String slotLength;
    private String slotWidth;
    private String noOfRows;
    private String interRowDistance;
    private String noOfSlots;
    private String interSlotDistance;
    private String rowOrientation;
    private String rowSeries;
    private String slotSeries;
    private String levelSeries;
    private String maxHeight;
    private String workingHeight;
    private String absoluteStackingHeight;
    private String laneLocation;
    private String laneIdentifierUpper;
    private String laneIdentifierLower;
    private String serialNo;
    private String xPosition;
    private String yPosition;
    private String slotSeriesStart;
    private String levelSeriesStart;
    private String rowSeriesStart;
    private String unit;
    private boolean isTwentyFooter ;
    private boolean isFortyFooter ;
    private boolean isFortyFiveFooter ;
    

    public String getBlockIdentifier() {
        return blockIdentifier;
    }

    public void setBlockIdentifier(String blockIdentifier) {
        this.blockIdentifier = blockIdentifier;
    }

    public String getContSize() {
        return contSize;
    }

    public void setContSize(String contSize) {
        this.contSize = contSize;
    }

    public String getBlockType() {
        return blockType;
    }

    public void setBlockType(String blockType) {
        this.blockType = blockType;
    }

    public String getSlotLength() {
        return slotLength;
    }

    public void setSlotLength(String slotLength) {
        this.slotLength = slotLength;
    }

    public String getSlotWidth() {
        return slotWidth;
    }

    public void setSlotWidth(String slotWidth) {
        this.slotWidth = slotWidth;
    }

    public String getNoOfRows() {
        return noOfRows;
    }

    public void setNoOfRows(String noOfRows) {
        this.noOfRows = noOfRows;
    }

    public String getInterRowDistance() {
        return interRowDistance;
    }

    public void setInterRowDistance(String interRowDistance) {
        this.interRowDistance = interRowDistance;
    }

    public String getNoOfSlots() {
        return noOfSlots;
    }

    public void setNoOfSlots(String noOfSlots) {
        this.noOfSlots = noOfSlots;
    }

    public String getInterSlotDistance() {
        return interSlotDistance;
    }

    public void setInterSlotDistance(String interSlotDistance) {
        this.interSlotDistance = interSlotDistance;
    }

    public String getRowOrientation() {
        return rowOrientation;
    }

    public void setRowOrientation(String rowOrientation) {
        this.rowOrientation = rowOrientation;
    }

    public String getRowSeries() {
        return rowSeries;
    }

    public void setRowSeries(String rowSeries) {
        this.rowSeries = rowSeries;
    }

    public String getSlotSeries() {
        return slotSeries;
    }

    public void setSlotSeries(String slotSeries) {
        this.slotSeries = slotSeries;
    }

    public String getLevelSeries() {
        return levelSeries;
    }

    public void setLevelSeries(String levelSeries) {
        this.levelSeries = levelSeries;
    }

    public String getMaxHeight() {
        return maxHeight;
    }

    public void setMaxHeight(String maxHeight) {
        this.maxHeight = maxHeight;
    }

    public String getWorkingHeight() {
        return workingHeight;
    }

    public void setWorkingHeight(String workingHeight) {
        this.workingHeight = workingHeight;
    }

    public String getAbsoluteStackingHeight() {
        return absoluteStackingHeight;
    }

    public void setAbsoluteStackingHeight(String absoluteStackingHeight) {
        this.absoluteStackingHeight = absoluteStackingHeight;
    }

    public String getLaneLocation() {
        return laneLocation;
    }

    public void setLaneLocation(String laneLocation) {
        this.laneLocation = laneLocation;
    }

    public String getLaneIdentifierUpper() {
        return laneIdentifierUpper;
    }

    public void setLaneIdentifierUpper(String laneIdentifierUpper) {
        this.laneIdentifierUpper = laneIdentifierUpper;
    }

    public String getLaneIdentifierLower() {
        return laneIdentifierLower;
    }

    public void setLaneIdentifierLower(String laneIdentifierLower) {
        this.laneIdentifierLower = laneIdentifierLower;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getxPosition() {
        return xPosition;
    }

    public void setxPosition(String xPosition) {
        this.xPosition = xPosition;
    }

    public String getyPosition() {
        return yPosition;
    }

    public void setyPosition(String yPosition) {
        this.yPosition = yPosition;
    }

    public String getSlotSeriesStart() {
        return slotSeriesStart;
    }

    public void setSlotSeriesStart(String slotSeriesStart) {
        this.slotSeriesStart = slotSeriesStart;
    }

    public String getLevelSeriesStart() {
        return levelSeriesStart;
    }

    public void setLevelSeriesStart(String levelSeriesStart) {
        this.levelSeriesStart = levelSeriesStart;
    }

    public String getRowSeriesStart() {
        return rowSeriesStart;
    }

    public void setRowSeriesStart(String rowSeriesStart) {
        this.rowSeriesStart = rowSeriesStart;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public boolean isTwentyFooter() {
        return isTwentyFooter;
    }

    public void setTwentyFooter(boolean isTwentyFooter) {
        this.isTwentyFooter = isTwentyFooter;
    }

    public boolean isFortyFooter() {
        return isFortyFooter;
    }

    public void setFortyFooter(boolean isFortyFooter) {
        this.isFortyFooter = isFortyFooter;
    }

    public boolean isFortyFiveFooter() {
        return isFortyFiveFooter;
    }

    public void setFortyFiveFooter(boolean isFortyFiveFooter) {
        this.isFortyFiveFooter = isFortyFiveFooter;
    }

    
}
