package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

/**
 * AlertParameterAssociation DTO
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class AlertParameterAssociationDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertParamId;
    private String alertCode;
    private Integer paramterId;
    private AlertParameterKeyDTO actualkey ;
    
    
    public Integer getAlertParamId() {
        return alertParamId;
    }
    public void setAlertParamId(Integer alertParamId) {
        this.alertParamId = alertParamId;
    }
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    public Integer getParamterId() {
        return paramterId;
    }
    public void setParamterId(Integer paramterId) {
        this.paramterId = paramterId;
    }
    public AlertParameterKeyDTO getActualkey() {
        return actualkey;
    }
    public void setActualkey(AlertParameterKeyDTO actualkey) {
        this.actualkey = actualkey;
    }
    
   
    
  
    
    
   
    
   
    
    
    

    
    
    
     
    
    

}
