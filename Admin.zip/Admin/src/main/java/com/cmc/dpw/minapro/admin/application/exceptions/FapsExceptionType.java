/**
 * 
 */
package com.cmc.dpw.minapro.admin.application.exceptions;

/**
 * @author Bhavesh
 * 
 */
public enum FapsExceptionType {

    SAVE, UPDATE, DELETE , DEFAULT
}
