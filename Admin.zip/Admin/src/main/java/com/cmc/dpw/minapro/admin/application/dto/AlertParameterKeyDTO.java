package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

/**
 * AlertParameterKey DTO
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class AlertParameterKeyDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer paramId;
    private String paramName;
    
    public Integer getParamId() {
        return paramId;
    }
    public void setParamId(Integer paramId) {
        this.paramId = paramId;
    }
    public String getParamName() {
        return paramName;
    }
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }
    

    

    


}
