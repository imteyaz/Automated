package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.CheckList;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.CheckListService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/checklist")
public class CheckListController {

    @Autowired
    private CheckListService checkListService;
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckListController.class);
/**
 * This method searches for all the checklists matching the search criteria
 * as entered by the end user
 * @param checkListId
 * @param checkListName
 * @param mandatory
 * @param icon
 * @param category
 * @param name
 * @param start
 * @param limit
 * @return Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String checkListId,
            @RequestParam(required = false) String checkListName, @RequestParam(required = false) String mandatory,
            @RequestParam(required = false) String icon, @RequestParam(required = false) String category,

            @RequestParam(required = false) String name, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckList controller's searchCheckLists method");

        String[] requestParameters = { checkListId, checkListName, mandatory, icon, name };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR +"Inside CheckList Controller's searchCheckLists with checkListId: {} , checkListName : {} , mandatory : {} , icon : {} , name : {} ",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering CheckList controller's searchCheckLists method");

            Map<String, Object> checkListsMap = checkListService.searchCheckListList(checkListId, checkListName,
                    mandatory, icon, category, name, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList controller's searchCheckLists method");
            return getMap(checkListsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CheckListController-->Search CheckList-->Catch Block :{}", e);
            return getModelMapError("Error retrieving CheckLists from database.");
        }
    }

    /**
     * This method creates the CheckList as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckList controller's createCheckLists method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);

        try {
            List<CheckList> checkLists = checkListService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList controller's create method");
            return getMap(checkLists);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create checkList due to following exception:{}" + cause.getMessage());
            
        } catch (ExistingRecordException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create checkList :{}" + e.getCustomErrorMessage());
            
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            return getModelMapError("Error trying to create checkList.");
        }

    }
   
    /**
     * This method updates the CheckList as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckList controller's updateCheckLists method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {
            List<CheckList> checkLists = checkListService.update(data, principal);
            return getMap(checkLists);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CheckListController-->update CheckList-->Catch Block :{}", e);
            return getModelMapError("Error trying to update checkList. ");
        }
    }

    /**
     * This method deletes the CheckList.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start CheckList controller's deleteCheckLists method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            checkListService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting CheckList controller's deleteCheckLists method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"CheckListController-->delete CheckList-->Catch Block :{}", e);
            return getModelMapError("Error trying to delete checkList.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<CheckList> checkLists) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.TOTAL_KEY, checkLists.size());
        modelMap.put(MessageConstants.DATA_KEY, checkLists);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> checkListsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) checkListsMap.get("totalCount");

        List<CheckList> checkLists = (List<CheckList>) checkListsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", checkLists);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, checkLists);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;

    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
