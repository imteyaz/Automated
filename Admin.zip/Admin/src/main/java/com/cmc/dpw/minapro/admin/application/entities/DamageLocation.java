package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * DamageLocation POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "DamageLocation")
@Table(name = "MP_DAMAGE_LOCATION")
public class DamageLocation extends Audit implements Serializable {

    
    private static final long serialVersionUID = 1L;
    private String damageLocationId;
    private String damageLocationDescription;

    @Id
    @Column(name = "DAMAGE_LOCATION_CODE", nullable = false)
    public String getDamageLocationId() {
        return damageLocationId;
    }

    public void setDamageLocationId(String damageLocationId) {
        this.damageLocationId = damageLocationId;
    }

    @Column(name = "DAMAGE_LOCATION_DESC")
    public String getDamageLocationDescription() {
        return damageLocationDescription;
    }

    public void setDamageLocationDescription(String damageLocationDescription) {
        this.damageLocationDescription = damageLocationDescription;
    }
   
}
