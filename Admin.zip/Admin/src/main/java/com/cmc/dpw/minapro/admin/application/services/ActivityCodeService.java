package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.ActivityCodeDAO;
import com.cmc.dpw.minapro.admin.application.dto.ActivityCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ActivityCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ActivityCode Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class ActivityCodeService {

    @Autowired
    private ActivityCodeDAO activityCodeDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityCodeService.class);

    /**
     * This method is used to get ActivityCode List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<ActivityCode> getActivityCodeList() {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  ActivityCode service's getActivityCodeList");

        activityCodeDAO.setClazz(ActivityCode.class);
        return activityCodeDAO.findAll();

    }

    /**
     * This method is used to search ActivityCode List
     * @param activityId
     * @param activityType
     * @param start
     * @param limit
     *  @return Map<String, Object> containing the search ActivityCode data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchActivityCodeList(String activityId, String activityType, int start, int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode service's searchActivityCodeList method");
        activityCodeDAO.setClazz(ActivityCode.class);
        
        String[] requestParameters = { activityId, activityType };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In ActivityCode service searchActivityCodeswith activityId: {} , activityType : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode service's searchActivityCodeList method");
        return activityCodeDAO.searchActivityCodes(activityId, activityType, start, limit);

    }

    /**
     * This method creates the ActivityCode as entered by the end user
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ActivityCode> containing list of ActivityCode
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITY_MASTER")
    public List<ActivityCode> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  activityCode service's  create : {} ", data);

        List<ActivityCode> newActivityCodes = new ArrayList<ActivityCode>();
        
        List<ActivityCode> newActivityCodesList =  util.getEntitiesFromDto(data, ActivityCodeDTO.class ,ActivityCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ActivityCode activityCode : newActivityCodesList) {

            Date currentDate = new Date();

            activityCode.setCreatedDateTime(currentDate);
            activityCode.setLastUpdatedDateTime(currentDate);
            activityCode.setCreatedBy(userId.toString());
            activityCode.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityId property in activiyCode service create : {}",
                    activityCode.getActivityId());
            ActivityCode alreadyEquipment = activityCodeDAO.findOne(activityCode.getActivityId());

            if (alreadyEquipment == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling activityCode DAO create");
                newActivityCodes.add(activityCodeDAO.create(activityCode));

            } else {
                char isDeleted = alreadyEquipment.getIsDeleted();

                if (isDeleted == 'Y') {
                    activityCode.setVersion(alreadyEquipment.getVersion());
                    activityCode.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling activityCode DAO update");
                    newActivityCodes.add(activityCodeDAO.update(activityCode));

                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null  
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode service's create method");
        return newActivityCodes;
    }

    /**
     *This method updates the ActivityCode as entered by the end user
     *@param data The json data coming from the UI
     *@return  List<ActivityCode>
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITY_MASTER")
    public List<ActivityCode> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  activityCode  service's  update : {} ", data);

        List<ActivityCode> returnActivityCodes = new ArrayList<ActivityCode>();

        List<ActivityCode> updatedActivityCodes =  util.getEntitiesFromDto(data, ActivityCodeDTO.class ,ActivityCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ActivityCode activityCode : updatedActivityCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityId property in activiyCode service update : {}",
                    activityCode.getActivityId());

            activityCode.setLastUpdatedDateTime(currentDate);

            activityCode.setLastUpdatedBy(userId.toString());
            returnActivityCodes.add(activityCodeDAO.update(activityCode));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode service's update method");
        return returnActivityCodes;
    }

    /**
     *This method deletes the ActivityCode as entered by the end user
     *@param data The json data coming from the UI
     *@return  List<ActivityCode>
     */
    @Transactional
    @Manipulate(table = "MP_ACTIVITY_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In activityCode's service delete : {} ", data);
        
        List<ActivityCode> deletedActivityCodes =  util.getEntitiesFromDto(data, ActivityCodeDTO.class ,ActivityCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ActivityCode activityCode : deletedActivityCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"activityId property in activiyCode service delete : {}",
                    activityCode.getActivityId());

            activityCode.setLastUpdatedDateTime(currentDate);
            activityCode.setLastUpdatedBy(userId.toString());
            activityCode.setIsDeleted('Y');
            activityCodeDAO.delete(activityCode);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ActivityCode service's delete method");
    }

}
