package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessExceptionDetailsDTO implements Serializable{

    private static final long serialVersionUID = -1427275763592689322L;

    
    private String exceptionValue;
    private String exceptionDesc;
    private String tempExceptionCode;

    public String getExceptionValue() {
        return exceptionValue;
    }

    public void setExceptionValue(String exceptionValue) {
        this.exceptionValue = exceptionValue;
    }

    public String getExceptionDesc() {
        return exceptionDesc;
    }

    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    public String getTempExceptionCode() {
        return tempExceptionCode;
    }

    public void setTempExceptionCode(String tempExceptionCode) {
        this.tempExceptionCode = tempExceptionCode;
    }
  
}

