package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.TroubleShootArea;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.TroubleShootAreaService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/troubleShootArea")
public class TroubleShootAreaController {

    @Autowired
    private TroubleShootAreaService troubleShootAreaService;
    private static final Logger LOGGER = LoggerFactory.getLogger(TroubleShootAreaController.class);
    /**
     * This method searches for all the troubleShootArea matching the search criteria
     * as entered by the end user
     * @param troubleShootAreaId
     * @param description
     * @param terminalId
     * @param availability
     * @param start
     * @param limit
     * @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String troubleShootAreaId,
            @RequestParam(required = false) String description, @RequestParam(required = false) String terminalId,
            @RequestParam(required = false) String availability, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {
        

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TroubleShootAreaController Seacrh TroubleShootArea method");

        String[] requestParameters = { troubleShootAreaId, description, terminalId, availability };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"TroubleShootAreaController-->Seacrh troubleShootAreaId:{},description:{},terminalId:{},availability:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering TroubleShootAreaController Seacrh TroubleShootArea method");

            Map<String, Object> troubleShootAreasMap = troubleShootAreaService.searchTroubleShootAreaList(
                    troubleShootAreaId, description, terminalId, availability, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootAreaController Seacrh TroubleShootArea method");
            return getMap(troubleShootAreasMap);

        } catch (Exception e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Search", e);
            return getModelMapError("Error retrieving TroubleShootAreas from database.");
        }
    }

    /**
     * This method creates the TroubleShootArea as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created TroubleShootArea data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal)  {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TroubleShootAreaController Create TroubleShootArea method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<TroubleShootArea> troubleShootAreas = troubleShootAreaService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootAreaController Create TroubleShootArea method");
            return getMap(troubleShootAreas);

        } catch (DataIntegrityViolationException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();

            return getModelMapError("Error trying to create troubleShootArea due to following exception :{}" + cause.getMessage());

            
        }   catch (ExistingRecordException e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);

            return getModelMapError("Error trying to create troubleShootArea :{}" + e.getCustomErrorMessage());

            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create TroubleShootArea.");
        }
    }

    /**
     * This method updates the TroubleShootArea as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated TroubleShootArea data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal)  {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TroubleShootAreaController Update TroubleShootArea method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            List<TroubleShootArea> troubleShootAreas = troubleShootAreaService.update(data, principal);

            return getMap(troubleShootAreas);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update troubleShootArea. ");
        }
    }

    /**
     * This method deletes the TroubleShootArea.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted TroubleShootArea data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start TroubleShootAreaController Delete TroubleShootArea method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            troubleShootAreaService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting TroubleShootAreaController Delete TroubleShootArea method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete troubleShootArea.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param troubleShootAreas List of troubleShootAreas
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<TroubleShootArea> troubleShootAreas) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, troubleShootAreas);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }
    /**
     * 
     * @param troubleShootAreasMap
     * @return  Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(Map<String, Object> troubleShootAreasMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) troubleShootAreasMap.get("totalCount");

        List<TroubleShootArea> troubleShootAreas = (List<TroubleShootArea>) troubleShootAreasMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , troubleShootAreas);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, troubleShootAreas);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     *@return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
