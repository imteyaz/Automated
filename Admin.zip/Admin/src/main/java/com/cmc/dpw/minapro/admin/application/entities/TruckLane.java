package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * TruckLane POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity
@Table(name = "MP_TRUCKLANE_YPM")
public class TruckLane implements Serializable {

    private static final long serialVersionUID = 1L;
    private String truckLaneID;
    private Integer tmnlNo;
    private String descr;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insExtUsrFlg;
    private String updUsrCd;
    private Date updDttm;
    private String updExtUsrFlg;
    private String txnCd;
    private Integer txnNo;
    private char isDeleted;

    @Id
    @Column(name = "TRUCKLANE_ID")
    public String getTruckLaneID() {
        return truckLaneID;
    }

    public void setTruckLaneID(String truckLaneID) {
        this.truckLaneID = truckLaneID;
    }

    @Id
    @Column(name = "INT_TMNL_NO")
    public Integer getTmnlNo() {
        return tmnlNo;
    }

    public void setTmnlNo(Integer tmnlNo) {
        this.tmnlNo = tmnlNo;
    }

    @Column(name = "L_DESCR")
    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Column(name = "ADT_INS_USR_CD")
    public String getInsUsrCd() {
        return insUsrCd;
    }

    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getInsExtUsrFlg() {
        return insExtUsrFlg;
    }

    public void setInsExtUsrFlg(String insExtUsrFlg) {
        this.insExtUsrFlg = insExtUsrFlg;
    }

    @Column(name = "ADT_UPD_USR_CD")
    public String getUpdUsrCd() {
        return updUsrCd;
    }

    public void setUpdUsrCd(String updUsrCd) {
        this.updUsrCd = updUsrCd;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }

    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdExtUsrFlg() {
        return updExtUsrFlg;
    }

    public void setUpdExtUsrFlg(String updExtUsrFlg) {
        this.updExtUsrFlg = updExtUsrFlg;
    }

    @Column(name = "ADT_TXN_CD")
    public String getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }

    @Column(name = "ADT_TXN_NO")
    public Integer getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }
    
    @Column(name = "ISDELETED", nullable = false)
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
