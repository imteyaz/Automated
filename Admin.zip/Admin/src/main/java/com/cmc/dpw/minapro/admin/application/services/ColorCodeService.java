package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.ColorCodeDAO;
import com.cmc.dpw.minapro.admin.application.dto.ColorCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ColorCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ColorCode Service
 * @author Imran Rawani
 * @since 2014-Dec 
 * 
 */
@Service
public class ColorCodeService {
    @Autowired
    private ColorCodeDAO colorCodeDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ColorCodeService.class);

    /**
     * This method is used to get ColorCode List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<ColorCode> getColorCodeList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  ColorCode service's getColorCodeList");
        colorCodeDAO.setClazz(ColorCode.class);
        return colorCodeDAO.findAll();

    }

    /**
     * This method is used to search ColorCode List
     * @return Map<String, Object> containing the search ColorCode data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchColorCodeList(String itemName, String itemGroup, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ColorCode service's searchColorCodeList method");
        colorCodeDAO.setClazz(ColorCode.class);

        String[] requestParameters = { itemName, itemGroup };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In ColorCode service searchColorCodeList  with itemName: {} , itemGroup : {}, make : {}, model : {}, colorCodeTypeId : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCode service's searchColorCodeList method");

        return colorCodeDAO.searchColorCodes(itemName, itemGroup, start, limit);
    }

    /**
     * This method is used to create ColorCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ColorCode> containing the created ColorCode data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_COLOUR_CODE_MASTER")
    public List<ColorCode> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ColorCode service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  colorCode service's  create : {} ", data);

        List<ColorCode> newColorCodes = new ArrayList<ColorCode>();
        List<ColorCode> list = util.getEntitiesFromDto(data,ColorCodeDTO.class,ColorCode.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ColorCode colorCode : list) {

            Date currentDate = new Date();
            colorCode.setCreatedDateTime(currentDate);
            colorCode.setLastUpdatedDateTime(currentDate);
            colorCode.setCreatedBy(userId.toString());
            colorCode.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ColorCode Id property in colorCode service's create : {}",
                    colorCode.getColorCodeId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling colorCode DAO findOne");

            ColorCode alreadyColorCode = colorCodeDAO.findOne(colorCode.getColorCodeId());

            if (alreadyColorCode == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling colorCode DAO create");
                newColorCodes.add(colorCodeDAO.create(colorCode));
            } else {

                char isDeleted = alreadyColorCode.getIsDeleted();

                if (isDeleted == 'Y') {
                    colorCode.setVersion(alreadyColorCode.getVersion());
                    colorCode.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling colorCode DAO update");
                    newColorCodes.add(colorCodeDAO.update(colorCode));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCode service's create method");
        return newColorCodes;
    }

    /**
     * This method is used to update ColorCode 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<ColorCode>
     */
    @Transactional
    @Manipulate(table = "MP_COLOUR_CODE_MASTER")
    public List<ColorCode> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ColorCode service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  colorCode  service's  update : {} ", data);
        List<ColorCode> returnColorCodes = new ArrayList<ColorCode>();

        List<ColorCode> updatedColorCodes = util.getEntitiesFromDto(data,ColorCodeDTO.class,ColorCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ColorCode colorCode : updatedColorCodes) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"colorCodeId property in colorCode service update : {}", colorCode.getColorCodeId());
            colorCode.setLastUpdatedDateTime(currentDate);
            colorCode.setLastUpdatedBy(userId.toString());
            returnColorCodes.add(colorCodeDAO.update(colorCode));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCode service's update method");
        return returnColorCodes;
    }

    /**
     * This method is used to delete ColorCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_COLOUR_CODE_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.DEBUG_INDICATOR +"Entering ColorCode service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In colorCode's service delete : {} ", data);
        
        List<ColorCode> deletedColorCodes = util.getEntitiesFromDto(data,ColorCodeDTO.class,ColorCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (ColorCode colorCode : deletedColorCodes) {
            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ColorCode Id property in colorCode service delete : {}",
                    colorCode.getColorCodeId());
            colorCode.setLastUpdatedDateTime(currentDate);
            colorCode.setLastUpdatedBy(userId.toString());
            colorCode.setIsDeleted('Y');
            colorCodeDAO.delete(colorCode);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ColorCode service's delete method");
    }
    
}
