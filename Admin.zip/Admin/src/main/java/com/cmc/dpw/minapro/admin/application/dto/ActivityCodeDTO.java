package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * ActivityCodeDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@JsonAutoDetect
public class ActivityCodeDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String activityId;
    private String description;
    private String activityTypeId;
    private String terminalId;
    
    public String getActivityId() {
        return activityId;
    }
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getActivityTypeId() {
        return activityTypeId;
    }
    public void setActivityTypeId(String activityTypeId) {
        this.activityTypeId = activityTypeId;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
}
