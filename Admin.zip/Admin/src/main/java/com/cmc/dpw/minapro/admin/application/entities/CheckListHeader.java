package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
/**
 * CheckListHeader POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "CheckListHeader")
@Table(name = "MP_CHECKLIST_HEADER_MASTER")
public class CheckListHeader extends Audit implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Integer checkListHeaderId;
    private String name;
    private String type;
    private Integer roleId;
    private String roleName;
    private String allRoles;
    private Collection<Role> actualRoles;
    
    @Transient
    public String getAllRoles() {
        return allRoles;
    }

    public void setAllRoles(String allRoles) {
        this.allRoles = allRoles;
    }

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "MP_CHECKLIST_ROLE_MAP", joinColumns = @JoinColumn(name = "CHECKLIST_HDR_ID"), inverseJoinColumns = @JoinColumn(name = "INT_USER_GRP_ID"))
    public Collection<Role> getActualRoles() {
        return actualRoles;
    }

   

    public void setActualRoles(Collection<Role> actualRoles) {
        this.actualRoles = actualRoles;
    }

    @Id
    @Column(name = "CHECKLIST_HDR_ID", nullable = false)
    public Integer getCheckListHeaderId() {
        return checkListHeaderId;
    }

    public void setCheckListHeaderId(Integer checkListHeaderId) {
        this.checkListHeaderId = checkListHeaderId;
    }

    @Column(name = "NAME")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "TYPE")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

   
    @Transient
    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    @Transient
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
