package com.cmc.dpw.minapro.admin.application.opus.common;


import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;

@Component
public class SchedulerRunner implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    OpusScheduler opusScheduler ;
    boolean isSchedulerStarted = false;
    
    @Override
    public void onApplicationEvent(final ContextRefreshedEvent event) {
        
        if(!isSchedulerStarted){
            QueueUtil.init();
            runScheduler();
        }
       
        
    }
    
    public void runScheduler(){
        
        TimerTask task = opusScheduler ; //new OpusScheduler();

        Timer timer = new Timer();
        timer.schedule(task, 1000,600000);
        isSchedulerStarted = true;
        }

}
