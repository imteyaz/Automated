package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * DamageSeverity POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "DamageSeverity")
@Table(name = "MP_DAMAGESEVERITY_MASTER")
public class DamageSeverity extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageSeverityCode;
    private String description;

    @Id
    @Column(name = "DAMAGE_SEVERITY_CODE", nullable = false)
    public String getDamageSeverityCode() {
        return damageSeverityCode;
    }

    public void setDamageSeverityCode(String damageSeverityCode) {
        this.damageSeverityCode = damageSeverityCode;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
