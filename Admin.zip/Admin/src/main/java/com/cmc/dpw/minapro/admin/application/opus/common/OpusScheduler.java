package com.cmc.dpw.minapro.admin.application.opus.common;

import java.util.Date;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;

@Component
public class OpusScheduler extends TimerTask {

    @Autowired
    RotationManager rotationManager;// = new RotationManager();
    
    private static final Logger LOGGER = LoggerFactory.getLogger(OpusScheduler.class);

    @Override
    public void run() {

       // System.out.println("OPUS scheduler started @~" + new Date());
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OPUS scheduler started @~" + new Date()) ;

        rotationManager.manageRegisteredRotations();

        rotationManager.manageBerthedRotations();

        rotationManager.manageSailedRotations();
        
        rotationManager.manageEquipmentMappings();
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OPUS scheduler stopped @~" + new Date()) ;

      //  System.out.println("OPUS scheduler stopped @~" + new Date());

    }

}
