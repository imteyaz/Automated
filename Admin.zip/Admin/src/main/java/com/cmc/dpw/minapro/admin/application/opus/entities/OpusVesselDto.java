package com.cmc.dpw.minapro.admin.application.opus.entities;

import java.util.Date;

public class OpusVesselDto {
    
    private String rotation;
    private String vesselCode;
    private String vesselName;
    private String etaDate;
    private String etaTime;
    private String actualBerthDate;
    private String voyageNo;
    private String berthNo;
    private String status;
    private String berthSide;
    
    
    public String getRotation() {
        return rotation;
    }
    public void setRotation(String rotation) {
        this.rotation = rotation;
    }
    public String getVesselCode() {
        return vesselCode;
    }
    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }
    public String getVesselName() {
        return vesselName;
    }
    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }
    public String getEtaDate() {
        return etaDate;
    }
    public void setEtaDate(String etaDate) {
        this.etaDate = etaDate;
    }
    public String getEtaTime() {
        return etaTime;
    }
    public void setEtaTime(String etaTime) {
        this.etaTime = etaTime;
    }
    public String getActualBerthDate() {
        return actualBerthDate;
    }
    public void setActualBerthDate(String actualBerthDate) {
        this.actualBerthDate = actualBerthDate;
    }
    public String getVoyageNo() {
        return voyageNo;
    }
    public void setVoyageNo(String voyageNo) {
        this.voyageNo = voyageNo;
    }
    public String getBerthNo() {
        return berthNo;
    }
    public void setBerthNo(String berthNo) {
        this.berthNo = berthNo;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getBerthSide() {
        return berthSide;
    }
    public void setBerthSide(String berthSide) {
        this.berthSide = berthSide;
    }
    
    

}


