package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.QCLaneDAO;
import com.cmc.dpw.minapro.admin.application.dto.QCLaneDTO;
import com.cmc.dpw.minapro.admin.application.entities.QCLane;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * QCLane Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class QCLaneService {

    @Autowired
    private QCLaneDAO qcLaneDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(QCLaneService.class);

    /**
     * This method is used to get QCLane List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<QCLane> getQCLaneList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  QC_Lane service's getQC_LaneList");
        qcLaneDAO.setClazz(QCLane.class);
        return qcLaneDAO.findAll();

    }

    /**
     * This method is used to search QCLane List
     * @return Map<String, Object> containing the search QCLane data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchQCLaneList(String laneId, String availability, String driveDirection, int start,
            int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering QC_Lane service's searchQC_LaneList method");
        qcLaneDAO.setClazz(QCLane.class);

        String[] requestParameters = { laneId, availability, driveDirection };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In QC_Lane service searchQCLanes with laneId: {} , availability : {} , driveDirection : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QC_Lane service's searchQC_LaneList method");
        return qcLaneDAO.searchQCLanes(laneId, availability, driveDirection, start, limit);

    }

    /**
     * This method is used to create QCLane
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<QCLane> containing created QCLane data
     * @throws ExistingRecordException 
     */
    @Transactional
    @Manipulate(table = "MP_QC_LANE_MASTER")
    public List<QCLane> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering QC_Lane service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  QC_Lane service's  create : {} ", data);

        List<QCLane> newQCLanes = new ArrayList<QCLane>();
        List<QCLane> list = util.getEntitiesFromDto(data, QCLaneDTO.class ,QCLane.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (QCLane qcLane : list) {

            Date currentDate = new Date();

            qcLane.setCreatedDateTime(currentDate);
            qcLane.setLastUpdatedDateTime(currentDate);
            qcLane.setCreatedBy(userId.toString());
            qcLane.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"laneId property in qcLane service create : {}", qcLane.getLaneId());
            QCLane alreadyQCLane = qcLaneDAO.findOne(qcLane.getLaneId());

            if (alreadyQCLane == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling QC_Lane DAO");
                newQCLanes.add(qcLaneDAO.create(qcLane));
            } else {

                char isDeleted = alreadyQCLane.getIsDeleted();

                if (isDeleted == 'Y') {
                    qcLane.setVersion(alreadyQCLane.getVersion());
                    qcLane.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling qcLane DAO update");
                    newQCLanes.add(qcLaneDAO.update(qcLane));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QC_Lane service's create method");
        return newQCLanes;
    }

    /**
     * This method is used to update QCLane 
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<QCLane> containing updated QCLane data
     */
    @Transactional
    @Manipulate(table = "MP_QC_LANE_MASTER")
    public List<QCLane> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering QC_Lane service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  QC_Lane  service's  update : {} ", data);
        List<QCLane> returnQCLanes = new ArrayList<QCLane>();

        List<QCLane> updatedQCLanes = util.getEntitiesFromDto(data, QCLaneDTO.class ,QCLane.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (QCLane qcLane : updatedQCLanes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"laneId property in qcLane service update : {}", qcLane.getLaneId());
            qcLane.setLastUpdatedDateTime(currentDate);
            qcLane.setLastUpdatedBy(userId.toString());
            returnQCLanes.add(qcLaneDAO.update(qcLane));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QC_Lane service's update method");
        return returnQCLanes;
    }

    /**
     * This method is used to delete QCLane
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_QC_LANE_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering QC_Lane service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In QC_Lane's service delete : {} ", data);

        List<QCLane> deletedQCLanes = util.getEntitiesFromDto(data, QCLaneDTO.class ,QCLane.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (QCLane qcLane : deletedQCLanes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"laneId property in qcLane service delete : {}", qcLane.getLaneId());
            qcLane.setLastUpdatedDateTime(currentDate);
            qcLane.setLastUpdatedBy(userId.toString());
            qcLane.setIsDeleted('Y');
            qcLaneDAO.delete(qcLane);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting QC_Lane service's delete method");
    }

}
