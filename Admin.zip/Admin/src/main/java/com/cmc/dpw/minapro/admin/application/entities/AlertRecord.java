package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * AlertRecord POJO
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "AlertRecord")
@Table(name = "MP_ALERT_RECORD")
public class AlertRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRecordId;
    private String alertCode;
    private String alertText;
    private String raisedBy;
    private char status;
    private Date raisedDateTime;
    private Integer closedBy;
    private Date closedDateTime;

    @Id
    @Column(name = "ALERT_RECORD_ID", nullable = false)
    public Integer getAlertRecordId() {
        return alertRecordId;
    }

    public void setAlertRecordId(Integer alertRecordId) {
        this.alertRecordId = alertRecordId;
    }

    @Column(name = "ALERT_CODE", nullable = false)
    public String getAlertCode() {
        return alertCode;
    }

    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }

    @Column(name = "ALERT_TEXT_INSTANCE", nullable = false)
    public String getAlertText() {
        return alertText;
    }

    public void setAlertText(String alertText) {
        this.alertText = alertText;
    }

    @Column(name = "RAISED_BY", nullable = false)
    public String getRaisedBy() {
        return raisedBy;
    }

    public void setRaisedBy(String raisedBy) {
        this.raisedBy = raisedBy;
    }

    @Column(name = "STATUS", nullable = false)
    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    @Column(name = "RAISED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getRaisedDateTime() {
        return raisedDateTime;
    }

    public void setRaisedDateTime(Date raisedDateTime) {
        this.raisedDateTime = raisedDateTime;
    }

    @Column(name = "CLOSED_BY")
    public Integer getClosedBy() {
        return closedBy;
    }

    public void setClosedBy(Integer closedBy) {
        this.closedBy = closedBy;
    }

    @Column(name = "CLOSED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getClosedDateTime() {
        return closedDateTime;
    }

    public void setClosedDateTime(Date closedDateTime) {
        this.closedDateTime = closedDateTime;
    }

}
