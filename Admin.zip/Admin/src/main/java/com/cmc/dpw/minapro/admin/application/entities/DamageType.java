package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * DamageType POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "DamageType")
@Table(name = "MP_DAMAGE_TYPE")
public class DamageType extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageTypeId;
    private String damageTypeDescription;

    @Id
    @Column(name = "DAMAGE_TYPE", nullable = false)
    public String getDamageTypeId() {
        return damageTypeId;
    }

    public void setDamageTypeId(String damageTypeId) {
        this.damageTypeId = damageTypeId;
    }

   
    @Column(name = "DAMAGE_TYPE_DESC")
    public String getDamageTypeDescription() {
        return damageTypeDescription;
    }

    public void setDamageTypeDescription(String damageTypeDescription) {
        this.damageTypeDescription = damageTypeDescription;
    }
}
