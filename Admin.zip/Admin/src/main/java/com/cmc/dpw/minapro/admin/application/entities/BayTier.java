package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.BayTierPk;

/**
 * ValueObject holding the Tier details of a bay of the vessel
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Entity
@Table(name = "MP_BAYTIER_SPM")
public class BayTier implements Serializable {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset + tierOffset
     */
    @EmbeddedId
    private BayTierPk pk;

    @Column(name = "VSL_TIER_NO")
    private String vesselTierNo;

    @Column(name = "SECDY_TIER_NO")
    private String secondaryTierNo;

    @Column(name = "TWEENDK_FLG")
    private char tweenDeckFlag;

    @Column(name = "CREATED_DATETIME")
    // , nullable=false)
    private Date createdDateTime;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "LAST_UPDATED_DATETIME")
    private Date lastUpdatedDateTime;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "VERSION")
    // , nullable=false)
    private Integer version;

    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;

    public BayTierPk getPk() {
        return pk;
    }

    public void setPk(BayTierPk pk) {
        this.pk = pk;
    }

    public String getVesselTierNo() {
        return vesselTierNo;
    }

    public void setVesselTierNo(String vesselTierNo) {
        this.vesselTierNo = vesselTierNo;
    }

    public String getSecondaryTierNo() {
        return secondaryTierNo;
    }

    public void setSecondaryTierNo(String secondaryTierNo) {
        this.secondaryTierNo = secondaryTierNo;
    }

    public char isTweenDeckFlag() {
        return tweenDeckFlag;
    }

    public void setTweenDeckFlag(char tweenDeckFlag) {
        this.tweenDeckFlag = tweenDeckFlag;
    }

    public Integer getTierOffset() {
        return pk.getTierOffset();
    }

    public void setTierOffset(Integer tierOffset) {
        pk.setTierOffset(tierOffset);
    }

    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
