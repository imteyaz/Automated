package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.UserGroupId;

/**
 * UserGroupAssociation POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "UserGroupAssociation")
@Table(name = "MP_USERGRP_A")
public class UserGroupAssociation implements Serializable {

    private static final long serialVersionUID = 1L;
    private UserGroupId userGroupId;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String adtInsUserName;
    private String adtUpdUserName;
    private Date adtInsDatTime;
    private Date adtUpdDatTime;

    @EmbeddedId
    public UserGroupId getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(UserGroupId userGroupId) {
        this.userGroupId = userGroupId;
    }

    @Column(name = "ADT_INS_FUNCTION_CD")
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }

    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }

    @Column(name = "ADT_UPD_FUNCTION_CD")
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }

    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }

    @Column(name = "ADT_INS_USER_NM")
    public String getAdtInsUserName() {
        return adtInsUserName;
    }

    public void setAdtInsUserName(String adtInsUserName) {
        this.adtInsUserName = adtInsUserName;
    }

    @Column(name = "ADT_UPD_USER_NM")
    public String getAdtUpdUserName() {
        return adtUpdUserName;
    }

    public void setAdtUpdUserName(String adtUpdUserName) {
        this.adtUpdUserName = adtUpdUserName;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getAdtInsDatTime() {
        return adtInsDatTime;
    }

    public void setAdtInsDatTime(Date adtInsDatTime) {
        this.adtInsDatTime = adtInsDatTime;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getAdtUpdDatTime() {
        return adtUpdDatTime;
    }

    public void setAdtUpdDatTime(Date adtUpdDatTime) {
        this.adtUpdDatTime = adtUpdDatTime;
    }

}
