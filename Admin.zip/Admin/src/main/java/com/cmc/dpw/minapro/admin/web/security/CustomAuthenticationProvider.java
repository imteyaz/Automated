package com.cmc.dpw.minapro.admin.web.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.application.services.UserService;

/**
 * 
 * A custom authentication provider.
 * 
 * @author Imran Rawani
 * 
 */
@Component("customAuthenticationProvider")
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
    private UserService userService;

    @Override
    public Authentication authenticate(Authentication authentication) {
        String username = authentication.getName();
        String password = (String) authentication.getCredentials();

        String[] passwordArray = password.split("#");

        String encryptedPassword = passwordArray[MessageConstants.ZERO];
        String iv = passwordArray[MessageConstants.ARRAY_ONE];
        String salt = passwordArray[MessageConstants.ARRAY_TWO];

        String submittedPassword = Encrypter.decryptPassword(MessageConstants.ONE_TWENTY_EIGHT, MessageConstants.THOUSAND, salt, iv, encryptedPassword);

        String originalPassword = null;
        User user = null ;
        
        try{
             user = userService.getUserByUsername(username);
        }catch(Exception e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Exception while logging in - trying to find user by username -->",e);
        }

        

        if (user == null) {
            throw new BadCredentialsException(MessageConstants.BAD_CREDENTIALS_MESSAGE);
        } else {

            String accountStatus = user.getAccountStatus();

            if (!("A").equalsIgnoreCase(accountStatus)) {
                throw new DisabledException("User Account is disabled");
            }

            String storedPassword = user.getPassword();
            String storedIV = user.getIv();
            String storedSalt = user.getSalt();
            originalPassword = Encrypter.decryptPassword(MessageConstants.ONE_TWENTY_EIGHT,
                    MessageConstants.THOUSAND, storedSalt, storedIV, storedPassword);
        }

        if (!originalPassword.equals(submittedPassword)) {
            throw new BadCredentialsException(MessageConstants.BAD_CREDENTIALS_MESSAGE);
        }

        List<Role> userRoles = (List<Role>) user.getActualRoles();

        Collection<GrantedAuthority> authorities = getAuthorities(userRoles);

        user.setLastLogin(new Date());
        user.setLoginStatus("Y");
        userService.updateUser(user);

        return new UsernamePasswordAuthenticationToken(user, encryptedPassword, authorities);

    }

    @ExceptionHandler(AccessDeniedException.class)
    public ModelAndView handleCustomException(AccessDeniedException ex) {

        ModelAndView model = new ModelAndView("/error");
        model.addObject("exception", ex);
        return model;

    }

    /**
     * Retrieves the correct ROLE type depending on the access level, where access level is an Integer. Basically, this
     * interprets the access value whether it's for a regular user or admin.
     * 
     * @param userRoles
     *            an integer value representing the access of the user
     * @return collection of granted authorities
     */
    public Collection<GrantedAuthority> getAuthorities(List<Role> userRoles) {
        // Create a list of grants for this user
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>(MessageConstants.ARRAY_TWO);

        // All users are granted with ROLE_USER access
        // Therefore this user gets a ROLE_USER by default
        authList.add(new GrantedAuthorityImpl("ROLE_USER"));

        int i = 0;
        for (Role currentRole : userRoles) {

            if (currentRole.getIntUserGroupId() == MessageConstants.ARRAY_ONE) {
                // User has admin access
                authList.add(new GrantedAuthorityImpl("ROLE_ADMIN"));
                i++;
            }

            if (currentRole.getIntUserGroupId() == MessageConstants.EIGHT) {
                // User has minapro admin access
                authList.add(new GrantedAuthorityImpl("ROLE_MINAPRO_ADMIN"));
                i++;
            }

        }

        /*
         * Earlier implementation allowed only admin and minapro admin users to login
         */

        // Return list of granted authorities
        return authList;
    }

    @Override
    public boolean supports(Class<?> arg0) {
        return true;
    }

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

}
