package com.cmc.dpw.minapro.admin.application.exceptions;

public class LoggedInUserException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private final String customErrorMessage;

    public LoggedInUserException(String mssg) {
        this.customErrorMessage = mssg;
    }
   
    public String getCustomErrorMessage() {
        return customErrorMessage;
    }

}
