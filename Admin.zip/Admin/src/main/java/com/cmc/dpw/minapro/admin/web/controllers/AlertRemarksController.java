package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.AlertRemarks;
import com.cmc.dpw.minapro.admin.application.services.AlertRemarksService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/alertRemarks")
public class AlertRemarksController {

    @Autowired
    private AlertRemarksService alertRemarksService;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRemarksController.class);
    /**
     * This method searches for all the rotations matching the search criteria
     * as entered by the end user
     * @param equipmentId
     * @param etaDateFrom
     * @param etaDateTo
     * @param status
     * @param terminalId
     * @param vesselCode
     * @param etaTimeFrom
     * @param etaTimeTo
     * @param berthNo
     * @param start
     * @return  Map<String, Object> containing the data and success indicator.
     * 
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view( @RequestParam String  alertRecordId, int start, int limit)  {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertRemarksController Search AlertRemarks method");
        try {
            Map<String, Object> alertRemarkssMap = alertRemarksService.searchAlertRemarks(alertRecordId,start,limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"AlertRemarksController -- > Search --> END");
            return getMap(alertRemarkssMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Exception-->Search", e);
            return getModelMapError("Error retrieving AlertRemarkss from database.");
        }
    }

    
    /**
     * This method updates the Alert Record as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<AlertRemarks> containing the updated Alert Record data and success indicator or
     * the error message and failure indicator.
     */  
    
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> addRemarks(@RequestBody Object data, Principal principal) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start AlertRemarksController create AlertRemarks method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            List<AlertRemarks> addedAlertRemarks = alertRemarksService.addRemarks(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRemarksController create AlertRemarks method");

            return getMap(addedAlertRemarks);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->create :{}", e);
            return getModelMapError(MessageConstants.CREATE_ALERTREMARKS);
        }
    }
    

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> containing the rotation data and success indicator or
     * the error message and failure indicator.
     */
    private Map<String, Object> getMap(List<AlertRemarks> alertRemarks) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, alertRemarks);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> alertRemarksMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) alertRemarksMap.get("totalCount");

        List<AlertRemarks> alertRemarkss = (List<AlertRemarks>) alertRemarksMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , alertRemarkss);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, alertRemarkss);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }
  
}
