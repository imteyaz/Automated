package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the primary key for the BusinessExceptionDetailsPk
 * @author Rosemary George
 *
 */
@Embeddable
public class BusinessExceptionDetailsPk implements Serializable {
    
    private static final long serialVersionUID = 2454206915273897222L;

    @Column(name="EXCEPTION_ID")
    private String exceptionId;
    
    @Column(name="EXCEPTION_CODE")
    private String exceptionCode;

    public String getExceptionId() {
        return exceptionId;
    }

    public void setExceptionId(String exceptionId) {
        this.exceptionId = exceptionId;
    }

    public String getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(String exceptionCode) {
        this.exceptionCode = exceptionCode;
    }
    
}
