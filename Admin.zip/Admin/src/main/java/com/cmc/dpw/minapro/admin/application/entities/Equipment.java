package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * Equipment POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "Equipment")
@Table(name = "MP_EQUIPMENT_MASTER")
public class Equipment extends Audit implements Serializable {
   
    private static final long serialVersionUID = 1L;
    private String equipmentId;
    private String equipmentName;
    private String equipmentDescription;
    private String make;
    private String model;
    private String equipmentTypeId;
    private String terminalId;
    private String pow;
   

    @Id
    @Column(name = "EQUIPMENT_ID", nullable = false)
    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    @Column(name = "EQUIPMENT_NAME", nullable = false)
    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    @Column(name = "EQUIPMENT_DESCRIPTION")
    public String getEquipmentDescription() {
        return equipmentDescription;
    }

    public void setEquipmentDescription(String equipmentDescription) {
        this.equipmentDescription = equipmentDescription;
    }

    @Column(name = "MAKE", nullable = false)
    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    @Column(name = "MODEL", nullable = false)
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Column(name = "EQUIPMENT_TYPE_ID", nullable = false)
    public String getEquipmentTypeId() {
        return equipmentTypeId;
    }

    public void setEquipmentTypeId(String equipmentTypeId) {
        this.equipmentTypeId = equipmentTypeId;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    @Column(name = "POW")
    public String getPow() {
        return pow;
    }

    public void setPow(String pow) {
        this.pow = pow;
    }
}
