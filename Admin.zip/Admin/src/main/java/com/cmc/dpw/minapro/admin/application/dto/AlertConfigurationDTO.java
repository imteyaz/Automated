package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
/**
 * AlertConfiguration DTO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlertConfigurationDTO implements Serializable {
   
    private static final long serialVersionUID = 1L;
    private String alertCode;
    private String alertText;
    private String description;
    private char severity;
    private char soundRequired;
    private String subscribers;
    private String keys;
    private String expiryTime ;
    private List<AlertGroupAssociationDTO> alertsubscribersMap = new ArrayList<AlertGroupAssociationDTO>();
    private Collection<AlertParameterAssociationDTO> alertKeysMap = new ArrayList<AlertParameterAssociationDTO>();
    
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    public String getAlertText() {
        return alertText;
    }
    public void setAlertText(String alertText) {
        this.alertText = alertText;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public char getSeverity() {
        return severity;
    }
    public void setSeverity(char severity) {
        this.severity = severity;
    }
    public char getSoundRequired() {
        return soundRequired;
    }
    public void setSoundRequired(char soundRequired) {
        this.soundRequired = soundRequired;
    }
    public String getSubscribers() {
        return subscribers;
    }
    public void setSubscribers(String subscribers) {
        this.subscribers = subscribers;
    }
    public String getKeys() {
        return keys;
    }
    public void setKeys(String keys) {
        this.keys = keys;
    }
    public List<AlertGroupAssociationDTO> getAlertsubscribersMap() {
        return alertsubscribersMap;
    }
    public void setAlertsubscribersMap(List<AlertGroupAssociationDTO> alertsubscribersMap) {
        this.alertsubscribersMap = alertsubscribersMap;
    }
    public Collection<AlertParameterAssociationDTO> getAlertKeysMap() {
        return alertKeysMap;
    }
    public void setAlertKeysMap(Collection<AlertParameterAssociationDTO> alertKeysMap) {
        this.alertKeysMap = alertKeysMap;
    }
    
    public String getExpiryTime() {
        return expiryTime;
    }
    public void setExpiryTime(String expiryTime) {
        this.expiryTime = expiryTime;
    }
     
    
    
}
