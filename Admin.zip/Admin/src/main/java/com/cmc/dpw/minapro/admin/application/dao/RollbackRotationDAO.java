package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Vessel DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class RollbackRotationDAO extends GenericDAO {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(RollbackRotationDAO.class);
    Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
    public Map<String, Object>  rollbackRotation(String rotation) {
        
        Session session = getCurrentSession();

        if (rotation.length() > 0) {
                
                String MP_BACKREACH_JOBS_SQL= "delete from MP_BACKREACH_JOBS   where  rotation_id ="+ rotation;
                String MP_BUSINESS_EXCEPTION_SQL= "delete from MP_BUSINESS_EXCEPTION   where  rotation_no ="+ rotation;
                String MP_COMPLETED_MOVES_SQL= "delete from MP_COMPLETED_MOVES  where  rotation_id ="+ rotation;
                String MP_DAMAGE_RECORDING_SQL= "delete from MP_DAMAGE_RECORDING  where  rotation_id ="+ rotation;
                String MP_DELAY_RECORDING_SQL= "delete from MP_DELAY_RECORDING  where  rotation_id ="+ rotation;
               
                String MP_TWINTANDEM_CONTAINER_LIST_SQL=  "delete from MP_TWINTANDEM_CONTAINER_LIST a" +
                        " where  a.twintandem_id in (select b.twintandem_id" +
                        " from   MP_TWINTANDEM_JOB_LIST b " +
                        "where  b.rotation_id = " + rotation + " )" ;
                
                String MP_TWINTANDEM_JOB_LIST_SQL= " delete from MP_TWINTANDEM_JOB_LIST  where  rotation_id ="+ rotation;
              
                
                SQLQuery delMP_BACKREACH_JOBS_SQL = session.createSQLQuery(MP_BACKREACH_JOBS_SQL);
                SQLQuery delMP_BUSINESS_EXCEPTION_SQL = session.createSQLQuery(MP_BUSINESS_EXCEPTION_SQL);
                SQLQuery delMP_COMPLETED_MOVES_SQL = session.createSQLQuery(MP_COMPLETED_MOVES_SQL);
                SQLQuery delMP_DAMAGE_RECORDING_SQL= session.createSQLQuery(MP_DAMAGE_RECORDING_SQL);
                SQLQuery delMP_DELAY_RECORDING_SQL = session.createSQLQuery(MP_DELAY_RECORDING_SQL);

                SQLQuery delMP_TWINTANDEM_CONTAINER_LIST_SQL = session.createSQLQuery(MP_TWINTANDEM_CONTAINER_LIST_SQL);
                SQLQuery delMP_TWINTANDEM_JOB_LIST_SQL = session.createSQLQuery(MP_TWINTANDEM_JOB_LIST_SQL);

                int deletedBACKREACHRows = delMP_BACKREACH_JOBS_SQL.executeUpdate();
                int deletedBUSINESS_EXCEPTIONRows = delMP_BUSINESS_EXCEPTION_SQL.executeUpdate();
                int deletedCOMPLETED_MOVESRowsCount = delMP_COMPLETED_MOVES_SQL.executeUpdate();
                int deletedDAMAGE_RECORDINGRows = delMP_DAMAGE_RECORDING_SQL.executeUpdate();
                int deletedDELAY_RECORDINGRows = delMP_DELAY_RECORDING_SQL.executeUpdate();
                
                int deletedTWINTANDEM_CONTAINER_LISTRows = delMP_TWINTANDEM_CONTAINER_LIST_SQL.executeUpdate();
                int deletedTWINTANDEM_JOB_LISTRows = delMP_TWINTANDEM_JOB_LIST_SQL.executeUpdate();
                
                String msg="Please find the deleted records count below : </br></br> "
                		+ deletedBACKREACHRows+"  records deleted from  table MP_BACKREACH_JOBS. </br>"
                		+ deletedBUSINESS_EXCEPTIONRows+"  records deleted from  table MP_BUSINESS_EXCEPTION.</br>"
                		+ deletedCOMPLETED_MOVESRowsCount+"  records deleted from  table MP_COMPLETED_MOVES. </br>"
                		+ deletedDAMAGE_RECORDINGRows+"  records deleted from  table MP_DAMAGE_RECORDING. </br>"
                		+ deletedDELAY_RECORDINGRows+"  records deleted from  table MP_DELAY_RECORDING .</br>"
                		+ deletedTWINTANDEM_CONTAINER_LISTRows+"  records deleted from  table MP_TWINTANDEM_CONTAINER .</br>"
                		+ deletedTWINTANDEM_JOB_LISTRows+"  records deleted from  table MP_TWINTANDEM_JOB_LIST. </br>"
                		;
                modelMap.put("deletedcount", msg);	
                
                LOGGER.debug("deletedBACKREACHRows : " + deletedBACKREACHRows);
                LOGGER.debug("deletedBUSINESS_EXCEPTIONRows : " + deletedBUSINESS_EXCEPTIONRows);
                LOGGER.debug("deletedCOMPLETED_MOVESRowsCount : " + deletedCOMPLETED_MOVESRowsCount);
                LOGGER.debug("deletedDAMAGE_RECORDINGRows : " + deletedDAMAGE_RECORDINGRows);
                LOGGER.debug("deletedDELAY_RECORDINGRows : " + deletedDELAY_RECORDINGRows);
                LOGGER.debug("deletedTWINTANDEM_JOB_LISTRows : " + deletedTWINTANDEM_JOB_LISTRows);
                LOGGER.debug("deletedTWINTANDEM_CONTAINER_LISTRows : " + deletedTWINTANDEM_CONTAINER_LISTRows);
               

        }

        return modelMap;

    }

}
