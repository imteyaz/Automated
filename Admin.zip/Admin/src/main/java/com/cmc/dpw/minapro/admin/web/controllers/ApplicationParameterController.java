package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.ApplicationParameter;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.ApplicationParameterService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/applicationParameter")
public class ApplicationParameterController {

    @Autowired
    private ApplicationParameterService applicationParameterService;
    private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationParameterController.class);
    /**
     * This method searches for all the applicationParameters matching the search criteria
     * as entered by the end user
     * @param parameterCode
     * @param parameterValue
     * @return  Map<String, Object> containing the data and success indicator.
     */

    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String parameterCode,
            @RequestParam(required = false) String parameterValue, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit) {
        
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ApplicationParameter controller's searchApplicationParameter method");

        String[] requestParameters = { parameterCode, parameterValue };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"ApplicationParameterController-->Search parameterCode :{},parameterValue:{} ", 
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ApplicationParameter controller's searchApplicationParameter method");
            Map<String, Object> applicationParametersMap = applicationParameterService.searchApplicationParameterList(
                    parameterCode, parameterValue, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter controller's searchApplicationParameter method");
            return getMap(applicationParametersMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ApplicationParameterController-->Search ApplicationParamete-->Catch Block :{}", e);
            return getModelMapError("Error retrieving ApplicationParameters from database.");
        }
    }
    
    /**
     * This method creates the ApplicationParameter as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
         

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ApplicationParameter controller's createApplicationParameter method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<ApplicationParameter> applicationParameters = applicationParameterService.create(data, principal);
            LOGGER.info("Exiting ApplicationParameter controller's create ApplicationParameters method");
            return getMap(applicationParameters);
        } catch (DataIntegrityViolationException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create equipment :{}" + cause.getMessage());
        } catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create application parameter :{}" + e.getCustomErrorMessage());
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            return getModelMapError("Error trying to create application parameter.");
        }
    }
    
    /**
     * This method updates the ApplicationParameter as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */  

    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ApplicationParameter controller's updateApplicationParameter method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<ApplicationParameter> applicationParameters = applicationParameterService.update(data, principal);

            return getMap(applicationParameters);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ApplicationParameterController-->Update ApplicationParamete-->Catch Block :{}", e);
            return getModelMapError("Error trying to update applicationParameter. ");
        }
    }
    
    /**
     * This method deletes the ApplicationParameter.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start ApplicationParameter controller's deletepplicationParameter method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            applicationParameterService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting ApplicationParameter controller's deleteApplicationParameter method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ApplicationParameterController-->Delete ApplicationParamete-->Catch Block :{}", e);
            return getModelMapError("Error trying to delete applicationParameter.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param application parameters
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<ApplicationParameter> applicationParameters) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, applicationParameters);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> applicationParametersMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) applicationParametersMap.get("totalCount");

        List<ApplicationParameter> applicationParameters = (List<ApplicationParameter>) applicationParametersMap
                .get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", applicationParameters);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, applicationParameters);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }
   
}
