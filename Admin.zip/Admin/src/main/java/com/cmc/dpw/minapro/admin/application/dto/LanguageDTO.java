package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

/**
 * LanguageDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class LanguageDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String languageName;
    private String languageCode;
    private char isDeleted;
    
    public String getLanguageName() {
        return languageName;
    }
    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }
    public String getLanguageCode() {
        return languageCode;
    }
    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
    public char getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

}
