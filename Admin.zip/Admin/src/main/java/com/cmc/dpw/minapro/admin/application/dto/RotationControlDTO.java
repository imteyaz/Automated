package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;

/**
 * RotationControlDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class RotationControlDTO  extends AuditDTO implements Serializable {

    
    private static final long serialVersionUID = 1L;
    private Integer rotationControlId;
    private Integer rotationNumber;
    private Integer vesselNo;
    private String vesselCode;
    private String berthNo;
    private char status;
    private Date etaDate;
    private Date eta;
    private String terminalId;
    private String allEquipments;
    private String equipmentId;
    private Collection<EquipmentDTO> actualEquipments = new ArrayList<EquipmentDTO>();
    private Integer errorCount; 
    private String  voyageNo ;
    private String berthSide ;
    private Boolean isActiveModified;
    private Boolean isQCModified;
    
    
    public Integer getRotationControlId() {
        return rotationControlId;
    }
    public void setRotationControlId(Integer rotationControlId) {
        this.rotationControlId = rotationControlId;
    }
    public Integer getRotationNumber() {
        return rotationNumber;
    }
    public void setRotationNumber(Integer rotationNumber) {
        this.rotationNumber = rotationNumber;
    }
    public Integer getVesselNo() {
        return vesselNo;
    }
    public void setVesselNo(Integer vesselNo) {
        this.vesselNo = vesselNo;
    }
    public String getVesselCode() {
        return vesselCode;
    }
    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }
    public String getBerthNo() {
        return berthNo;
    }
    public void setBerthNo(String berthNo) {
        this.berthNo = berthNo;
    }
    public char getStatus() {
        return status;
    }
    public void setStatus(char status) {
        this.status = status;
    }
    public Date getEtaDate() {
        return etaDate;
    }
    public void setEtaDate(Date etaDate) {
        this.etaDate = etaDate;
    }
    public Date getEta() {
        return eta;
    }
    public void setEta(Date eta) {
        this.eta = eta;
    }
    public String getTerminalId() {
        return terminalId;
    }
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }
    public String getAllEquipments() {
        return allEquipments;
    }
    public void setAllEquipments(String allEquipments) {
        this.allEquipments = allEquipments;
    }
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public Collection<EquipmentDTO> getActualEquipments() {
        return actualEquipments;
    }
    public void setActualEquipments(Collection<EquipmentDTO> actualEquipments) {
        this.actualEquipments = actualEquipments;
    }
    public Integer getErrorCount() {
        return errorCount;
    }
    public void setErrorCount(Integer errorCount) {
        this.errorCount = errorCount;
    }
    public Boolean getIsActiveModified() {
        return isActiveModified;
    }
    public void setIsActiveModified(Boolean isActiveModified) {
        this.isActiveModified = isActiveModified;
    }
    public Boolean getIsQCModified() {
        return isQCModified;
    }
    public void setIsQCModified(Boolean isQCModified) {
        this.isQCModified = isQCModified;
    }
    public String getVoyageNo() {
        return voyageNo;
    }
    public void setVoyageNo(String voyageNo) {
        this.voyageNo = voyageNo;
    }
    public String getBerthSide() {
        return berthSide;
    }
    public void setBerthSide(String berthSide) {
        this.berthSide = berthSide;
    }

    
}
