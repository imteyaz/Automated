package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * DamageTypeDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class DamageTypeDTO extends AuditDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String damageTypeId;
    private String damageTypeDescription;
    
    public String getDamageTypeId() {
        return damageTypeId;
    }
    public void setDamageTypeId(String damageTypeId) {
        this.damageTypeId = damageTypeId;
    }
    public String getDamageTypeDescription() {
        return damageTypeDescription;
    }
    public void setDamageTypeDescription(String damageTypeDescription) {
        this.damageTypeDescription = damageTypeDescription;
    }
   
}
