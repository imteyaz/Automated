package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.cmc.dpw.minapro.admin.application.entities.pks.WeightageFactorPK;

@Entity
@Table(name = "MP_CHE_WEIGHTAGE_FACTOR")
public class WeightageFactor implements Serializable {

    
    private static final long serialVersionUID = 1L;
   
    private WeightageFactorPK pk;
   
    private double weightageScore;
    private double weightageFactor;
    private String type;
    private String criteria;
    private String id ;
    
    
    private Date createdDateTime;
    private String createdBy;
    private Date lastUpdatedDateTime;
    private String lastUpdatedBy;
    private Integer version;
    private char isDeleted;

    
    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    @Column(name = "CREATED_BY")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    @Column(name = "LAST_UPDATED_BY")
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @Version
    @Column(name = "VERSION", nullable = false)
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Column(name = "ISDELETED", nullable = false)
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
    
    @EmbeddedId
    public WeightageFactorPK getPk() {
        return pk;
    }

    public void setPk(WeightageFactorPK pk) {
        this.pk = pk;
    }
    

    @Column(name = "WF_SCORE", nullable = false)
    public double getWeightageScore() {
        return weightageScore;
    }

  

    public void setWeightageScore(double weightageScore) {
        this.weightageScore = weightageScore;
    }

    @Column(name = "WF_FACTOR", nullable = false)
    public double getWeightageFactor() {
        return weightageFactor;
    }

    public void setWeightageFactor(double weightageFactor) {
        this.weightageFactor = weightageFactor;
    }

    @Transient
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Transient
    public String getCriteria() {
        return criteria;
    }

    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }

    
    @Transient
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "CheWeightageFactorEntity [Weightage Type =" + pk.getWeightageType() + " Weightage Criteria = "
                + pk.getWeightageCriteria() + "]";
    }
}

