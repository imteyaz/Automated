package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.cmc.dpw.minapro.admin.application.entities.NumSrsDetails;
import com.cmc.dpw.minapro.admin.application.entities.NumSrsHeader;

@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("serial")
public class NumSrsDTO implements Serializable{
    /**
     * 
     */
    private List<NumSrsDetails> deletedChildRecords;
    private List<NumSrsDetails> newChildRecords;
    private List<NumSrsDetails> updatedChildRecords;
    
    private List<NumSrsHeader> newParentRecords;
    private List<NumSrsHeader> updatedParentRecords;
    private List<NumSrsHeader> deletedParentRecords;
    private String result;
    
    
    
    public List<NumSrsDetails> getDeletedChildRecords() {
        return deletedChildRecords;
    }

    public void setDeletedChildRecords(List<NumSrsDetails> deletedChildRecords) {
        this.deletedChildRecords = deletedChildRecords;
    }

    public List<NumSrsDetails> getNewChildRecords() {
        return newChildRecords;
    }

    public void setNewChildRecords(List<NumSrsDetails> newChildRecords) {
        this.newChildRecords = newChildRecords;
    }

    public List<NumSrsDetails> getUpdatedChildRecords() {
        return updatedChildRecords;
    }

    public void setUpdatedChildRecords(List<NumSrsDetails> updatedChildRecords) {
        this.updatedChildRecords = updatedChildRecords;
    }

    public List<NumSrsHeader> getNewParentRecords() {
        return newParentRecords;
    }

    public void setNewParentRecords(List<NumSrsHeader> newParentRecords) {
        this.newParentRecords = newParentRecords;
    }

    public List<NumSrsHeader> getUpdatedParentRecords() {
        return updatedParentRecords;
    }

    public void setUpdatedParentRecords(List<NumSrsHeader> updatedParentRecords) {
        this.updatedParentRecords = updatedParentRecords;
    }

    public List<NumSrsHeader> getDeletedParentRecords() {
        return deletedParentRecords;
    }

    public void setDeletedParentRecords(List<NumSrsHeader> deletedParentRecords) {
        this.deletedParentRecords = deletedParentRecords;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

}
