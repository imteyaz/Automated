package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.WeightageFactor;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.application.services.WeightageFactorService;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/weightageFactor")
public class WeightageFactorController {

    @Autowired
    private WeightageFactorService weightageFactorService;
    private static final Logger LOGGER = LoggerFactory.getLogger(WeightageFactorController.class);

    /**
     * This method searches for all the weightageFactors matching the search criteria
     * as entered by the end user
     * 
     * @param weightageFactorType
     * @param weightageFactorCriteria
     * @param weightageFactor
     * @param weightageScore
     * @param weightageFactorTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String weightageFactorType,
            @RequestParam(required = false) String weightageFactorCriteria, @RequestParam(required = false) String weightageFactor,
            @RequestParam(required = false) String weightageScore,  @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start WeightageFactorController Seacrh WeightageFactor method");
     
        String[] requestParameters = { weightageFactorType, weightageFactorCriteria, weightageFactor, weightageScore };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"WeightageFactorController-->search weightageFactorType:{},weightageFactorCriteria :{},weightageFactor :{},weightageFactorTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering WeightageFactorController Seacrh WeightageFactor method");

            Map<String, Object> weightageFactorsMap = weightageFactorService.searchWeightageFactorList(weightageFactorType, weightageFactorCriteria, weightageFactor,
                    weightageScore, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting WeightageFactorController Seacrh WeightageFactor method");
            return getMap(weightageFactorsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"WeightageFactorController-->search WeightageFactor-->Catch Block :{}", e);
            return Util.getModelMapError("Error retrieving WeightageFactors from database.");
        }
    }

  
    
    /**
     * This method updates the weightageFactor as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated weightageFactor data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start WeightageFactorController Update WeightageFactor method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<WeightageFactor> weightageFactors = weightageFactorService.update(data, principal);
            return getMap(weightageFactors);

        } catch (InvalidValueException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +" Start--> WeightageFactorController>update-->InvalidValueException", e);
            return Util.getModelMapError("Error trying to update weightageFactor :" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return Util.getModelMapError("Error trying to update weightageFactor. ");

        }
    }

    /**
     * Generates weightageScoreMap to return in the weightageScoreAndView
     * 
     * @param weightageFactors List of weightageFactors
     * @return Map<String, Object> weightageScoreMap
     */
    private Map<String, Object> getMap(List<WeightageFactor> weightageFactors) {

        Map<String, Object> weightageScoreMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        weightageScoreMap.put("data", weightageFactors);
        weightageScoreMap.put(MessageConstants.SUCCESS_KEY, true);
        return weightageScoreMap;
    }

    private Map<String, Object> getMap(Map<String, Object> weightageFactorsMap) {

        Map<String, Object> weightageScoreMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) weightageFactorsMap.get("totalCount");

        List<WeightageFactor> weightageFactors = (List<WeightageFactor>) weightageFactorsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", weightageFactors);

        weightageScoreMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        weightageScoreMap.put(MessageConstants.DATA_KEY, weightageFactors);
        weightageScoreMap.put(MessageConstants.SUCCESS_KEY, true);

        return weightageScoreMap;
    }

}
