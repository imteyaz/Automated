package com.cmc.dpw.minapro.admin.web.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.GenericLookUpDTO;
import com.cmc.dpw.minapro.admin.application.dto.GroupDTO;
import com.cmc.dpw.minapro.admin.application.dto.GroupMasterDetailsDTO;
import com.cmc.dpw.minapro.admin.application.services.GroupUserSecurityService;
import com.cmc.dpw.minapro.admin.domain.utils.CollectionUtil;
/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/admin")
public class GroupUserSecurityController {

    @Autowired
    private GroupUserSecurityService groupUserSecurityService;
    private static final Logger LOGGER = LoggerFactory.getLogger(GroupUserSecurityController.class);
/**
 * 
 * @param msg
 * @return Map<String, Object> modelMap
 */
    private Map<String, Object> getModelMapError(String msg) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        return modelMap;
    }
/**
 * This method is used to get Group details
 * @param start
 * @param limit
 * @param groupCodeField
 * @param groupNameField
 * @param userNamefield
 * @return  Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/getGroupDtls", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> getGroupDtls(int start, int limit,  String groupCodeField,
            String groupNameField, String userNamefield) {
        try {

            LOGGER.info("START-->GroupUserSecurityController-->getGroupDtls()");

            Map<String, Object> groupList = groupUserSecurityService.getGroupDtls( userNamefield,
                    groupCodeField, groupNameField, limit, start);

            LOGGER.info("END-->GroupUserSecurityController-->getGroupDtls()");
            return groupList;

        } catch (Exception e) {

            LOGGER.error("GroupUserSecurityController-->getGroupDtls()-->Exception block-->", e);
            return getModelMapError(e.getMessage());
        }
    }
    /**
     * This method is used to get Group Available User Details
     * @param start
     * @param limit
     * @param searchUserName
     * @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/getGroupAvailableUserDetails", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> getGroupAvailableUserDetails(int start,int limit, String searchUserName) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        try {
            LOGGER.info("START-->GroupUserSecurityController--> getGroupAvailableUserDetails() ");
            List<GenericLookUpDTO> userList = groupUserSecurityService.getAllUserDetails(searchUserName);

            List<GenericLookUpDTO> subList = (List<GenericLookUpDTO>) CollectionUtil.getSublist(userList, start, limit);
            modelMap.put(MessageConstants.TOTALCOUNT_KEY, userList.size());
            modelMap.put(MessageConstants.DATA_KEY, subList);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getGroupAvailableUserDetails() ");
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"GroupUserSecurityController-->getGroupAvailableUserDetails()-->Exception block-->", e);
        }

        return modelMap;
    }

    /**
     * 
     * @param groupId
     * @param serviceType
     * @return  List<GenericLookUpDTO> containing the Group Associated user details and 
     * the success indicator or the error message
     */
    @RequestMapping(value = "/getGroupAssociatedUserDetails", method = RequestMethod.GET)
    @ResponseBody public
    List<GenericLookUpDTO> getGroupAssociatedUserDetails(String groupId, String serviceType) {
        List<GenericLookUpDTO> groupList = null;
        /**
         * @return  Map<String, Object> containing the data and success indicator.
         */
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> getGroupAssociatedUserDetails() ");
            groupList = groupUserSecurityService.getGroupAssociatedUserDetails(groupId, serviceType);

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getGroupAssociatedUserDetails() ");
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"GroupUserSecurityController-->getGroupAssociatedUserDetails()-->Exception block-->", e);
        }

        return groupList;
    }

    /**
     * This method is used to get module details
     * @param groupId
     * @param serviceType
     * @return null
     */
    @RequestMapping(value = "/getModuleDetails", method = RequestMethod.GET)
    @ResponseBody public
    String getModuleDetails(String groupId, String serviceType) {
        String[] parameters = { serviceType,groupId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"GroupUserSecurityController--> getModuleDetails - serviceType:{} , groupId :{}", parameters);
        String moduleTree = null;
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> getModuleDetails() ");
            moduleTree = groupUserSecurityService.getModuleDetails(serviceType);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getModuleDetails() ");

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"GroupUserSecurityController-->getModuleDetails()-->Exception block-->", e);
        }
        return moduleTree;
    }

    /**
     * This method is used to get Available function details by moduleId
     * @param moduleId
     * @param groupId
     * @param serviceType
     * @return  List<GenericLookUpDTO>
     */
    @RequestMapping(value = "/getAvailableFunctionDetailsByModuleId", method = RequestMethod.GET)
    @ResponseBody public
    List<GenericLookUpDTO> getAvailableFunctionDetailsByModuleId(String moduleId, String groupId, String serviceType) {
        List<GenericLookUpDTO> functionList = null;
        String groupIdVal = groupId ;
        if ("".equalsIgnoreCase(groupId)) {
            groupIdVal = "0";
        }
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> getAvailableFunctionDetailsByModuleId() ");
            functionList = groupUserSecurityService.getAvailableFunctionDetailsByModuleId(moduleId, groupIdVal,
                    serviceType);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getAvailableFunctionDetailsByModuleId() ");
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +
                    "GroupUserSecurityController-->getAvailableFunctionDetailsByModuleId()-->Exception block-->", e);
        }
        return functionList;
    }

    /**
     * This method is used to getAssociatedFunctionDetailsByModuleId
     * @param moduleId
     * @param groupId
     * @param serviceType
     * @return List<GenericLookUpDTO> contianing Associated function details by ModuleId
     */
    @RequestMapping(value = "/getAssociatedFunctionDetailsByModuleId", method = RequestMethod.GET)
    @ResponseBody public
    List<GenericLookUpDTO> getAssociatedFunctionDetailsByModuleId(String moduleId, String groupId, String serviceType) {
        List<GenericLookUpDTO> functionList = null;
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> getAssociatedFunctionDetailsByModuleId() ");

            functionList = groupUserSecurityService.getAssociatedFunctionDetailsByModuleId(moduleId, groupId,
                    serviceType);

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getAssociatedFunctionDetailsByModuleId() ");
        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +
                    "GroupUserSecurityController-->getAssociatedFunctionDetailsByModuleId()-->Exception block-->", e);
        }
        return functionList;
    }

    /**
     * This method is used to deleteGroupByGroupId
     * @param groupId
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/deleteGroupByGroupId", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> deleteGroupByGroupId(String groupId) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        String[] grpArray = groupId.split(",");
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> deleteGroupByGroupId() ");

            groupUserSecurityService.deleteGroupByGroupId(grpArray);
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.SUCCESS_KEY);

            LOGGER.info("END-->GroupUserSecurityController--> deleteGroupByGroupId() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, "failure");
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"GroupUserSecurityController-->deleteGroupByGroupId()-->Exception block-->", e);
        }
        return modelMap;

    }

    /**
     * This method is used to saveGroupAssociatedUserAndFunctionDetails
     * @param groupJsonArray
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/saveGroupAssociatedUserAndFunctionDetails", method = { RequestMethod.POST })
    @ResponseBody public
    Map<String, Object> saveGroupAssociatedUserAndFunctionDetails(String groupJsonArray) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> saveGroupAssociatedUserAndFunctionDetails()  ");
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            List<GroupDTO> groupMasterDetailsList = objectMapper.readValue(groupJsonArray,
                    new TypeReference<List<GroupDTO>>() {
                    });

            if (groupMasterDetailsList != null && !groupMasterDetailsList.isEmpty()) {

                GroupDTO groupDTO = groupMasterDetailsList.get(0);
                GroupMasterDetailsDTO groupMasterDetailsDTO = new GroupMasterDetailsDTO();
                if (groupDTO != null) {

                    groupMasterDetailsDTO.setAction(groupDTO.getAction());
                    groupMasterDetailsDTO.setCopyGroupId(groupDTO.getCopyGroupId());
                    groupMasterDetailsDTO.setServiceType(groupDTO.getServiceType());
                    groupMasterDetailsDTO.setGroupList(groupDTO.getGroupList());
                    groupMasterDetailsDTO.setGroupUserList(groupDTO.getGroupUserList());
                    groupMasterDetailsDTO.setGroupFunctionList(groupDTO.getModuleList());
                    groupMasterDetailsDTO.setRemovedList(groupDTO.getRemovedList());

                    groupUserSecurityService.saveGroupAssociatedUserAndFunctionDetails(groupMasterDetailsDTO);
                    modelMap.put("success", true);

                } else {
                    modelMap.put(MessageConstants.SUCCESS_KEY, false);
                    modelMap.put(MessageConstants.MESSAGE_KEY, "Unable to map JSON to DTO");

                }

            }

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +
                    "GroupUserSecurityController--> saveGroupAssociatedUserAndFunctionDetails()  -->Exception Block  ",
                    e);
            return getModelMapError(e.getMessage());
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> saveGroupAssociatedUserAndFunctionDetails()  ");
        return modelMap;
    }

    /**
     * This method is used to getAccessCodeList
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/getAccessCodeList", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> getAccessCodeList() {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->GroupUserSecurityController--> getAccessCodeList()  ");
            List<GenericLookUpDTO> list = new ArrayList<GenericLookUpDTO>();
            String[] codes = new String[] { "1", "2", "3", "4" };
            String[] names = new String[] { "FULL CONTROL", "QUERY/INSERT/UPDATE", "QUERY/INSERT", "QUERY" };
            for (int i = 0; i < codes.length; i++) {
                GenericLookUpDTO genericLookUpDTO = new GenericLookUpDTO();
                genericLookUpDTO.setCode(codes[i]);
                genericLookUpDTO.setName(names[i]);
                list.add(genericLookUpDTO);
            }

            modelMap.put("items", list);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->GroupUserSecurityController--> getAccessCodeList()  ");

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +" GroupUserSecurity--->getAccessCodeList--->Exception : {}", e);
        }

        return modelMap;
    }

    /**
     * This method is used to findGroupByName
     * @param code
     * @param name
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/findGroupByName", method = { RequestMethod.POST })
    @ResponseBody public
    Map<String, Object> findGroupByName(String code, String name) {
        Map<String, Object> resultMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        resultMap.put(MessageConstants.SUCCESS_KEY, true);
        try {
            List<GroupDTO> duplicateGroupList = groupUserSecurityService.findGroupByCodeAndName(code, name);
            StringBuilder finalErrorMsg = new StringBuilder();
            String groupCodeErrorMsg = "";
            String groupNameErrorMsg = "";
            int gCodeErrorCount = 0;
            int gNameErrorCount = 0;

            for (GroupDTO group : duplicateGroupList) {
                if (code.equalsIgnoreCase(group.getGroupCode())) {
                    groupCodeErrorMsg = MessageConstants.EXISTING_GROUPCODE_ERROR_MESSAGE;
                    gCodeErrorCount++;

                }
                if (name.equalsIgnoreCase(group.getGroupName())) {
                    groupNameErrorMsg = MessageConstants.EXISTING_GROUPNAME_ERROR_MESSAGE;
                    gNameErrorCount++;

                }
            }

            if (gCodeErrorCount > 0) {
                finalErrorMsg.append(groupCodeErrorMsg);
            }

            if (gNameErrorCount > 0) {
                if (gCodeErrorCount > 0) {
                    finalErrorMsg.append("<br><br>");
                }
                finalErrorMsg.append(groupNameErrorMsg);
            }

            if (gCodeErrorCount > 0 || gNameErrorCount > 0) {
                resultMap.put(MessageConstants.ERROR_KEY, finalErrorMsg);
                resultMap.put(MessageConstants.SUCCESS_KEY, false);
            }

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"GroupUserSecurityController--->findGroupByName--->Exception", e);
        }

        return resultMap;
    }

    /**
     * This method is used to getFunctionCodesAssociatedWithUserAndGroup
     * @param userId
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/getFunctionCodesAssociatedWithUserAndGroup", method = RequestMethod.POST)
    @ResponseBody public
    Map<String, Object> getFunctionCodesAssociatedWithUserAndGroup(String userId) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->Group User Security--> getFunctionCodesAssociatedWithUserAndGroup() ");
            List<GenericLookUpDTO> groupUserAssociationList = groupUserSecurityService
                    .getFunctionCodesAssociatedWithUserAndGroup(userId);
            if (groupUserAssociationList != null && !groupUserAssociationList.isEmpty()) {
                modelMap.put(MessageConstants.TOTALCOUNT_KEY, groupUserAssociationList.size());
                modelMap.put(MessageConstants.ITEMS_KEY, groupUserAssociationList);
                modelMap.put(MessageConstants.SUCCESS_KEY, true);

            } else {
                modelMap.put(MessageConstants.SUCCESS_KEY, true);
                modelMap.put(MessageConstants.MESSAGE_KEY,
                        "User does not privileges to do any operation on User and Group details, Please Use Group/User Security Screen");
            }
            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->Group User Security Controller--> getFunctionCodesAssociatedWithUserAndGroup() ");

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Home Controller-->getFunctionCodesAssociatedWithUserAndGroup()-->Exception block-->", e);
            return getModelMapError(e.getMessage());
        }

        return modelMap;
    }

}
