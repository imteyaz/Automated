package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.DelayReasonCodeDAO;
import com.cmc.dpw.minapro.admin.application.dto.DelayReasonCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DelayReasonCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * DelayReasonCode Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class DelayReasonCodeService {

    @Autowired
    private DelayReasonCodeDAO delayReasonCodeDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DelayReasonCodeService.class);

    /**
     * This method is used to get DelayReasonCode List 
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<DelayReasonCode> getDelayReasonCodeList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  DelayReasonCode service's getDelayReasonCodeList");
        delayReasonCodeDAO.setClazz(DelayReasonCode.class);
        return delayReasonCodeDAO.findAll();

    }

    /**
     * This method is used to search DelayReasonCode List
     * @return Map<String, Object> containing the search DelayReasonCode data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchDelayReasonCodeList(String delayReasonId, String description, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DelayReasonCode service's searchDelayReasonCodeList method");
        delayReasonCodeDAO.setClazz(DelayReasonCode.class);

        String[] requestParameters = { delayReasonId, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "In DelayReasonCode service searchDelayReasonCodes with delayReasonId: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCode service's searchDelayReasonCodeList method");
        return delayReasonCodeDAO.searchDelayReasonCodes(delayReasonId, description, start, limit);

    }

    /**
     * This method is used to create DelayReasonCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DelayReasonCode> containing created DelayReasonCode data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_DELAYREASONCODE_MASTER")
    public List<DelayReasonCode> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DelayReasonCode service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  delayReasonCode service's  create : {} ", data);
        List<DelayReasonCode> newDelayReasonCodes = new ArrayList<DelayReasonCode>();

        List<DelayReasonCode> list = util.getEntitiesFromDto(data,DelayReasonCodeDTO.class, DelayReasonCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        
        for (DelayReasonCode delayReasonCode : list) {

            Date currentDate = new Date();

            delayReasonCode.setCreatedDateTime(currentDate);
            delayReasonCode.setLastUpdatedDateTime(currentDate);
            delayReasonCode.setCreatedBy(userId.toString());
            delayReasonCode.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"delayReasonId property in delayReasonCode service create : {}",
                    delayReasonCode.getDelayReasonId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling delayReasonCode DAO findOne");

            DelayReasonCode alreadyDelayReasonCode = delayReasonCodeDAO.findOne(delayReasonCode.getDelayReasonId());

            if (alreadyDelayReasonCode == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling delayReasonCode DAO create");
                newDelayReasonCodes.add(delayReasonCodeDAO.create(delayReasonCode));
            } else {
                char isDeleted = alreadyDelayReasonCode.getIsDeleted();

                if (isDeleted == 'Y') {
                    delayReasonCode.setVersion(alreadyDelayReasonCode.getVersion());
                    delayReasonCode.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling delayReasonCode DAO update");
                    newDelayReasonCodes.add(delayReasonCodeDAO.update(delayReasonCode));
                }    else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null   
            }
         // end of for loop   
        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCode service's create method");
        return newDelayReasonCodes;
    }

    /**
     * This method is used to update DelayReasonCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<DelayReasonCode>
     */
    @Transactional
    @Manipulate(table = "MP_DELAYREASONCODE_MASTER")
    public List<DelayReasonCode> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DealyReasonCode service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  delayReasonCode  service's  update : {} ", data);
        List<DelayReasonCode> returnDelayReasonCodes = new ArrayList<DelayReasonCode>();

        List<DelayReasonCode> updatedDelayReasonCodes = util.getEntitiesFromDto(data,DelayReasonCodeDTO.class, DelayReasonCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DelayReasonCode delayReasonCode : updatedDelayReasonCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"delayReasonId property in delayReasonCode service update : {}",
                    delayReasonCode.getDelayReasonId());
            delayReasonCode.setLastUpdatedDateTime(currentDate);
            delayReasonCode.setLastUpdatedBy(userId.toString());
            returnDelayReasonCodes.add(delayReasonCodeDAO.update(delayReasonCode));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCode service's update method");
        return returnDelayReasonCodes;
    }

    /**
     * This method is used to delete DelayReasonCode
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_DELAYREASONCODE_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DelayReasonCode service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In delayReasonCode's service delete : {} ", data);

        List<DelayReasonCode> deletedDelayReasonCodes = util.getEntitiesFromDto(data,DelayReasonCodeDTO.class, DelayReasonCode.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (DelayReasonCode delayReasonCode : deletedDelayReasonCodes) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"delayReasonId property in delayReasonCode service delete : {}",
                    delayReasonCode.getDelayReasonId());
            delayReasonCode.setLastUpdatedDateTime(currentDate);
            delayReasonCode.setLastUpdatedBy(userId.toString());
            delayReasonCode.setIsDeleted('Y');
            delayReasonCodeDAO.delete(delayReasonCode);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCode service's delete method");
    }

}
