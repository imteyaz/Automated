package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.ActivityCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.ActivityCode;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * ActivityCode DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Repository
public class ActivityCodeDAO extends GenericDAO<ActivityCode> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityCodeDAO.class);

    /**
     * This method is used to searchActivityCodes
     * @param activityIdVal
     * @param activityTypeVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchActivityCodes(String activityIdVal, String activityTypeVal, int start, int limit) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering ActivityCode DAO's searchActivityCodes method");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(ActivityCode.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { activityIdVal, activityTypeVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchActivityCodes with activityId: {} , activityType : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(activityIdVal)) && activityIdVal != null) {
            likeValue = "";
            String activityId = likeValue.concat(percentage).concat(activityIdVal).concat(percentage);
            searchCriteria.add(Restrictions.like("activityId", activityId).ignoreCase());

        }

        if (!("".equalsIgnoreCase(activityTypeVal)) && activityTypeVal != null) {
            likeValue = "";
            String activityType= likeValue.concat(percentage).concat(activityTypeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("activityTypeId", activityType).ignoreCase());

        }
        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<ActivityCode> searchActivityCodes = (List<ActivityCode>) searchCriteria.list();
        List<ActivityCodeDTO> searchActivityCodesDtoList =  util.map(searchActivityCodes, ActivityCodeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("data: {}", searchActivityCodesDtoList);
        LOGGER.debug("totalCount: {}", totalRecords);

        resultMap.put("data", searchActivityCodesDtoList);
        resultMap.put("totalCount", totalRecords);

        for (ActivityCode activityCode : searchActivityCodes) {
            LOGGER.debug("activityId : {}", activityCode.getActivityId());

        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting ActiivtyDAO's searchActivityCode's method ");
        return resultMap;
    }
}
