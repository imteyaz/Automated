package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

import com.cmc.dpw.minapro.admin.application.entities.pks.BayPk;

/**
 * BayDTO holding the bay details for a vessel
 * 
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */

public class BayDTO implements Serializable {
    /**
     * Composite Primary key - vesselNo + section No + deckUnderdeck + bayOffset
     */
    private BayPk pk;
    private String vesselBayNo;
    private char isLogicalBay;
    private char isContainerRowPresent;
    private Date createdDateTime;
    private String createdBy;
    private Date lastUpdatedDateTime;
    private String lastUpdatedBy;
    private Integer version;
    private char isDeleted;
    private String tierTemplate;
    

    public BayPk getPk() {
        return pk;
    }

    public void setPk(BayPk pk) {
        this.pk = pk;
    }

    public String getVesselBayNo() {
        return vesselBayNo;
    }

    public void setVesselBayNo(String vesselBayNo) {
        this.vesselBayNo = vesselBayNo;
    }

    public char isLogicalBay() {
        return isLogicalBay;
    }

    public void setIsLogicalBay(char isLogicalBay) {
        this.isLogicalBay = isLogicalBay;
    }

    public char isContainerRowPresent() {
        return isContainerRowPresent;
    }

    public void setIsContainerRowPresent(char isContainerRowPresent) {
        this.isContainerRowPresent = isContainerRowPresent;
    }

    public String getDeckUnderDeck() {
        return pk.getDeckUnderDeck();
    }

    public void setDeckUnderDeck(String deckUnderDeck) {
        pk.setDeckUnderDeck(deckUnderDeck);
    }

    public Integer getBayOffset() {
        return pk.getBayOffset();
    }

    public void setBayOffset(Integer bayOffset) {
        pk.setBayOffset(bayOffset);
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getTierTemplate() {
        return tierTemplate;
    }

    public void setTierTemplate(String tierTemplate) {
        this.tierTemplate = tierTemplate;
    }

    public char getIsLogicalBay() {
        return isLogicalBay;
    }

    public char getIsContainerRowPresent() {
        return isContainerRowPresent;
    }
 
    
}
