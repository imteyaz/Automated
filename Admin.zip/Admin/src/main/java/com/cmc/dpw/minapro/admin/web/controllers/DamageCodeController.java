package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.DamageCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.DamageCodeService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/damageCode")
public class DamageCodeController {

    @Autowired
    private DamageCodeService damageCodeService;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageCodeController.class);
/**
 * This method searches for all the damageCodes matching the search criteria
 * as entered by the end user
 * @param damageCodePk
 * @param damageSeverityCode
 * @param start
 * @param limit
 * @return  Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String damageCodePk,
            @RequestParam(required = false) String damageSeverityCode,@RequestParam(required = false) String  damageTypeCode ,
            @RequestParam(required = false) String damageLocationCode, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageCodeController Seacrh DamageCode method");

        String[] requestParameters = { damageCodePk, damageSeverityCode ,damageTypeCode,damageLocationCode };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageCodeController-->Seacrh damageCodePk:{}, damageSeverityCode:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCodeController Seacrh DamageCode method");

            Map<String, Object> damageCodesMap = damageCodeService.searchDamageCodeList(damageCodePk,
                    damageSeverityCode,damageTypeCode,damageLocationCode, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCodeController Seacrh DamageCode method");
            return getMap(damageCodesMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DamageCodeController-->Seacrh DamageCode-->Catch Block :{}", e);
            return getModelMapError("Error retrieving DamageCodes from database.");
        }
    }

    /**
     * This method creates the DamageCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageCodeController create DamageCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<DamageCode> damageCodes = damageCodeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCodeController Create DamageCode method");
            return getMap(damageCodes);

        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError("Error trying to create damageCode due to following exception :{}" + cause.getMessage());
        
        } catch(ExistingRecordException e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create damageCode :{}" + e.getCustomErrorMessage());
            
        } catch (Exception e) {
        
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception", e);
            return getModelMapError("Error trying to create damageCode.");
        }
    }

    /**
     * This method updates the DamageCode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageCodeController Update DamageCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<DamageCode> damageCodes = damageCodeService.update(data, principal);

            return getMap(damageCodes);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DamageCodeController-->update DamageCode-->Catch Block :{}", e);
            return getModelMapError("Error trying to update damageCode. ");
        }
    }

    /**
     * This method deletes the DamageCode.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageCodeController Delete DamageCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            damageCodeService.delete(data, principal);
            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageCodeController Delete DamageCode method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DamageCodeController-->delete DamageCode-->Catch Block :{}", e);
            return getModelMapError("Error trying to delete damageCode.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param damageCodes
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<DamageCode> damageCodes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, damageCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> damageCodesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) damageCodesMap.get("totalCount");

        List<DamageCode> damageCodes = (List<DamageCode>) damageCodesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", damageCodes);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, damageCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
