package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.DamageLocation;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.DamageLocationService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/damageLocation")
public class DamageLocationController {

    @Autowired
    private DamageLocationService damageLocationService;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageLocationController.class);

    /**
     * This method searches for all the damageLocations matching the search criteria
     * as entered by the end user
     * 
     * @param damageLocationId
     * @param damageLocationName
     * @param make
     * @param model
     * @param damageLocationTypeId
     * @return  Map<String, Object> containing the data and success indicator.
     */   
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String damageLocationId,
            @RequestParam(required = false) String damageLocationDesc,
            @RequestParam(required = false) int start, @RequestParam(required = false) int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageLocationController Seacrh DamageLocation method");
     
        String[] requestParameters = { damageLocationId, damageLocationDesc };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DamageLocationController-->search damageLocationId:{},damageLocationName :{},make :{},damageLocationTypeId:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageLocationController Seacrh DamageLocation method");

            Map<String, Object> damageLocationsMap = damageLocationService.searchDamageLocationList(damageLocationId, damageLocationDesc, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocationController Seacrh DamageLocation method");
            return getMap(damageLocationsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DamageLocationController-->search DamageLocation-->Catch Block :{}", e);
            return getModelMapError("Error retrieving DamageLocations from database.");
        }
    }

    /**
     * This method creates the damageLocation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created damageLocation data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start> DamageLocationController> Create DamageLocation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Data{}", data);

        try {
            List<DamageLocation> damageLocations = damageLocationService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocationController Create DamageLocation method");
            return getMap(damageLocations);

        }   catch (DataIntegrityViolationException e) {
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create damageLocation due to following exception  :{}" + cause.getMessage());
            
        }   catch (ExistingRecordException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create damageLocation :" + e.getCustomErrorMessage());
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create damageLocation.");
        }

    }
    
    /**
     * This method updates the damageLocation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated damageLocation data and success indicator or
     * the error message and failure indicator.
     */  
    
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageLocationController Update DamageLocation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER,data);
        try {
            List<DamageLocation> damageLocations = damageLocationService.update(data, principal);
            return getMap(damageLocations);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update damageLocation. ");

        }
    }

    
    /**
     * This method deletes the damageLocation.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted damageLocation data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DamageLocationController Delete DamageLocation method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {

            damageLocationService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DamageLocationController Delete DamageLocation method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete damageLocation.");

        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param damageLocations List of damageLocations
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<DamageLocation> damageLocations) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put("data", damageLocations);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> damageLocationsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) damageLocationsMap.get("totalCount");

        List<DamageLocation> damageLocations = (List<DamageLocation>) damageLocationsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", damageLocations);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, damageLocations);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
