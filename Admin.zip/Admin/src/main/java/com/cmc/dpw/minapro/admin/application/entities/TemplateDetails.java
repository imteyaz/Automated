package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.cmc.dpw.minapro.admin.application.entities.pks.TemplateDetailsPk;


@Entity
@Table(name="MP_NUMSRSDTLS_SPM" , 
uniqueConstraints= @UniqueConstraint(columnNames = {"NUMSRS_ID", "SEQ_NO" , "LABEL"})
) 

public class TemplateDetails implements Serializable{

    private static final long serialVersionUID = -1427275763592689322L;

    @EmbeddedId
    private TemplateDetailsPk pk;
    
    @Column(name="LABEL")
    private String vesselLabel;
    
    @Column(name="CREATED_DATETIME", nullable=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDateTime;
    
    @Column(name="CREATED_BY")
    private String createdBy;
    
    @Column(name="LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDateTime;
    
    @Column(name="LAST_UPDATED_BY")
    private String lastUpdatedBy;
    
    @Column(name="VERSION", nullable=false)
    private Integer version;
    
    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;
    
    @Transient
    private Integer seqNo;
    
    @Transient
    private String headerId;
    

    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }
    
    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public TemplateDetailsPk getPk() {
        return pk;
    }

    public void setPk(TemplateDetailsPk pk) {
        this.pk = pk;
    }
  
    public String getVesselLabel() {
        return vesselLabel;
    }

    public void setVesselLabel(String vesselLabel) {
        this.vesselLabel = vesselLabel;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
}

   

