/*package com.cmc.dpw.minapro.admin.application.entities;

public class YardGroundView {

}
 */

package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_BLKAREA_YPM")
public class YardBlockArea implements Serializable {

    private static final long serialVersionUID = 3690528137029386485L;

    private Integer blkNo;
    private String blkType;
    private String blkId;

    private String tmpFlg;
    private String usrPpCd;
    private Integer tmnlNo;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String insUsrFlg;
    private String usrCd;
    private Date updDttm;
    private String updUsrFlg;
    private String txnCd;
    private Integer txnNo;
    private String typeInd;

    @Id
    @Column(name = "INT_BLK_NO")
    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    @Column(name = "BLK_TYPE")
    public String getBlkType() {
        return blkType;
    }

    public void setBlkType(String blkType) {
        this.blkType = blkType;
    }

    @Column(name = "BLK_ID")
    public String getBlkId() {
        return blkId;
    }

    public void setBlkId(String blkId) {
        this.blkId = blkId;
    }

    @Column(name = "TMPL_FLG")
    public String getTmpFlg() {
        return tmpFlg;
    }

    public void setTmpFlg(String tmpFlg) {
        this.tmpFlg = tmpFlg;
    }

    @Column(name = "USR_PP_CD")
    public String getUsrPpCd() {
        return usrPpCd;
    }

    public void setUsrPpCd(String usrPpCd) {
        this.usrPpCd = usrPpCd;
    }

    @Column(name = "INT_TMNL_NO")
    public Integer getTmnlNo() {
        return tmnlNo;
    }

    public void setTmnlNo(Integer tmnlNo) {
        this.tmnlNo = tmnlNo;
    }

    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Column(name = "ADT_INS_USR_CD")
    public String getInsUsrCd() {
        return insUsrCd;
    }

    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }

    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getInsUsrFlg() {
        return insUsrFlg;
    }

    public void setInsUsrFlg(String insUsrFlg) {
        this.insUsrFlg = insUsrFlg;
    }

    @Column(name = "ADT_UPD_USR_CD")
    public String getUsrCd() {
        return usrCd;
    }

    public void setUsrCd(String usrCd) {
        this.usrCd = usrCd;
    }

    @Column(name = "ADT_UPD_DTTM")
    public Date getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(Date updDttm) {
        this.updDttm = updDttm;
    }

    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdUsrFlg() {
        return updUsrFlg;
    }

    public void setUpdUsrFlg(String updUsrFlg) {
        this.updUsrFlg = updUsrFlg;
    }

    @Column(name = "ADT_TXN_CD")
    public String getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(String txnCd) {
        this.txnCd = txnCd;
    }

    @Column(name = "ADT_TXN_NO")
    public Integer getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(Integer txnNo) {
        this.txnNo = txnNo;
    }

    @Column(name = "AREA_TYPE_IND")
    public String getTypeInd() {
        return typeInd;
    }

    public void setTypeInd(String typeInd) {
        this.typeInd = typeInd;
    }

}
