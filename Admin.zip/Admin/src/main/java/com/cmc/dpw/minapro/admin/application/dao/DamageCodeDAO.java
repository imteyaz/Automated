package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.DamageCodeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageCode;
import com.cmc.dpw.minapro.admin.application.entities.DamageLocation;
import com.cmc.dpw.minapro.admin.domain.utils.Util;
/**
 * DamageCodeDAO
 * @author Imran Rawani
 * @since 2014-Dec
 *
 */
@Repository
public class DamageCodeDAO extends GenericDAO<DamageCode> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageCodeDAO.class);
    /**
     * This method is used to searchDamageCodes
     * @param damageCodeVal
     * @param damageSeverityCodeVal
     * @param damageLocationCodeVal 
     * @param damageTypeCodeVal 
     * @param start
     * @param limit
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchDamageCodes(String damageCodeVal, String damageSeverityCodeVal, String damageTypeCodeVal, String damageLocationCodeVal, int start,
            int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageCode DAO's searchDamageCodes method");
        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        Integer damageCodePresent = 0 ;
        Integer damageSeverityCodePresent = 0 ;
        Integer damageTypeCodePresent = 0 ;
        Integer damageLocationCodePresent = 0 ;

        Criteria searchCriteria = session.createCriteria(DamageCode.class, "dCode");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        String[] searchParameters = { damageCodeVal, damageSeverityCodeVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Processing searchEquipments with damageCode: {} , description : {}", searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        damageCodePresent = Util.addRestrictions(searchCriteria, "damageCodePk", damageCodeVal, false,damageCodePresent);
        damageSeverityCodePresent = Util.addRestrictions(searchCriteria, "damageSeverityCode", damageSeverityCodeVal, false,damageSeverityCodePresent);
        damageTypeCodePresent = Util.addRestrictions(searchCriteria, "damageTypeId", damageTypeCodeVal, false,damageTypeCodePresent);

        if ((damageLocationCodeVal != null)&& !( damageLocationCodeVal.isEmpty())) {
            searchCriteria.createAlias("dCode.actualDamageLocations", "dLocation");
            searchCriteria.add(Restrictions.eq("dLocation.damageLocationId", damageLocationCodeVal).ignoreCase());
            damageLocationCodePresent++;
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();
        String totalRecords = count.toString();

        LOGGER.debug("Count: {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        
        List<DamageCode> searchDamageCodes = null ;
        
        StringBuilder sql =  new StringBuilder("select d from DamageCode d left join fetch d.actualDamageLocations dl where d.isDeleted ='N' ") ;
        
        if(damageCodePresent==1){
            sql.append(" and lower(d.damageCodePk) like lower('%" + damageCodeVal + "%') ");
        }
        
        if(damageSeverityCodePresent==1){
            sql.append(" and lower(d.damageSeverityCode) like lower('%" + damageSeverityCodeVal + "%') ");   
        }
        
        if(damageTypeCodePresent==1){
            sql.append(" and lower(d.damageTypeId) like lower('%" + damageTypeCodeVal + "%') ");   
        }
        
        if(damageLocationCodePresent==1){
            sql.append(" and lower(dl.damageLocationId) like lower('%" + damageLocationCodeVal + "%') ");   
        }
        
            Query query = session.createQuery(sql.toString());
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<DamageCode> damageCodesList = query.list();

            searchDamageCodes = damageCodesList;

        for (DamageCode currentDamageCode : searchDamageCodes) {
            
            List<DamageLocation> damageLocations = (List) currentDamageCode.getActualDamageLocations();
            List<String> actualDamageLocationsList = new ArrayList<String>();

            for (DamageLocation currentDamageLocation : damageLocations) {
                String currentDamageLocationId = currentDamageLocation.getDamageLocationId();
                LOGGER.debug("currentDamageLocation: " + currentDamageLocationId);
                actualDamageLocationsList.add(currentDamageLocationId);
            }
            String allDamageLocations = StringUtils.join(actualDamageLocationsList, ',');

            currentDamageCode.setAllDamageLocations(allDamageLocations);
            currentDamageCode.setDamageLocationId(allDamageLocations);
            LOGGER.debug("******** damageCode : {}", currentDamageCode.getDamageCodePk());
            
        }
        List<DamageCodeDTO> searchDamageCodesDtoList =  util.map(searchDamageCodes, DamageCodeDTO.class);
        
        LOGGER.debug("******* data: {}", searchDamageCodesDtoList);
        LOGGER.debug("******* totalCount: {}", totalRecords);

        resultMap.put("data", searchDamageCodesDtoList);
        resultMap.put("totalCount", totalRecords);
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" exiting DamageCodeDAO's searchDamageCodes method ");
        return resultMap;
    }
}
