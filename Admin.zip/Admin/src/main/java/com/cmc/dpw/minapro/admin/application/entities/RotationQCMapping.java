package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.cmc.dpw.minapro.admin.application.entities.pks.RotationQCPk;

/**
 * RotationQCMapping POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "RotationQCMapping")
@Table(name = "MP_ROTATION_QC_MAPPING")
public class RotationQCMapping  extends Audit  implements Serializable {

    private static final long serialVersionUID = 1L;

    private RotationQCPk rotationQcId;

    @EmbeddedId
    public RotationQCPk getRotationQcId() {
        return rotationQcId;
    }

    public void setRotationQcId(RotationQCPk rotationQcId) {
        this.rotationQcId = rotationQcId;
    }

}
