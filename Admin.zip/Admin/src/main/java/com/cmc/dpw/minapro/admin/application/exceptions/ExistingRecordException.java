package com.cmc.dpw.minapro.admin.application.exceptions;

public class ExistingRecordException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private final String customErrorMessage;

    public ExistingRecordException(String mssg) {
        this.customErrorMessage = mssg;
    }
   
    public String getCustomErrorMessage() {
        return customErrorMessage;
    }

}
