package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * AlertGroupAssociation POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "AlertGroupAssociation")
@Table(name = "MP_ALERT_ROLE_MAP")
public class AlertGroupAssociation implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer alertRoleId;
    private String alertCode;
    private Integer groupId;
    private String isActive;
    private String groupName ;
    private Role group ;
   
    
    @Id
    @Column(name = "ALERT_ROLE_ID", nullable = false)
    public Integer getAlertRoleId() {
        return alertRoleId;
    }
    public void setAlertRoleId(Integer alertRoleId) {
        this.alertRoleId = alertRoleId;
    }
    
    @Column(name = "ALERT_CODE", nullable = false)
    public String getAlertCode() {
        return alertCode;
    }
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    
    @Column(name = "GROUP_ID", nullable = false)
    public Integer getGroupId() {
        return groupId;
    }
    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
    
    @Column(name = "IS_ACTIVE", nullable = false)
    public String getIsActive() {
        return isActive;
    }
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }
 
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "GROUP_ID",insertable=false,updatable=false)
    public Role getGroup() {
        return group;
    }
    public void setGroup(Role group) {
        this.group = group;
    }
    
    @Transient
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
