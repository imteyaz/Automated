package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ValueObjcet holding the template header details
 * @author Imran Rawani
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateHeaderDTO extends AuditDTO implements Serializable{
   
    private static final long serialVersionUID = -7920596353659481286L;

    private String headerId;
    private String type;
    private String isDefault;
    private char isUsed;
    private Collection<TemplateDetailsDTO>  templateDetails = new ArrayList<TemplateDetailsDTO>();
   
    public Collection<TemplateDetailsDTO> getTemplateDetails() {
        return templateDetails;
    }

    public void setTemplateDetails(Collection<TemplateDetailsDTO> templateDetails) {
        this.templateDetails = templateDetails;
    }

    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }
    
    public char getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(char isUsed) {
        this.isUsed = isUsed;
    }

}
