package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * AuditDTO class containing the common fields for audit purpose
 * 
 * @author Imran Rawani
 * 
 */

public class AuditDTO implements Serializable {

    private static final long serialVersionUID = 3831897083980644770L;

    private Date createdDateTime;
    private String createdBy;
    private Date lastUpdatedDateTime;
    private String lastUpdatedBy;
    private Integer version;
    private char isDeleted;

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    protected void copy(final AuditDTO source) {
        this.createdBy = source.createdBy;
        this.version = source.version;
        this.createdDateTime = source.createdDateTime;
        this.isDeleted = source.isDeleted;
        this.lastUpdatedBy = source.lastUpdatedBy;
        this.lastUpdatedDateTime = source.lastUpdatedDateTime;
    }
}
