package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.DelayReasonCode;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.DelayReasonCodeService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/delayReasonCode")
public class DelayReasonCodeController {

    @Autowired
    private DelayReasonCodeService delayReasonCodeService;
        private static final Logger LOGGER = LoggerFactory.getLogger(DelayReasonCodeController.class);
    /**
     * This method searches for all the delayReasonCode matching the search criteria
     * as entered by the end user
     * @param delayReasonId
     * @param description
     * @param limit
     * @param start
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String delayReasonId,
            @RequestParam(required = false) String description, @RequestParam(required = false) int limit,
            @RequestParam(required = false) int start)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DelayReasonCodeController Search DelayReasonCode method");
        
        String[] requestParameters = { delayReasonId, description };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR +"DelayReasonCodeController-->Seacrh delayReasonId:{},description:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DelayReasonCodeController Search DelayReasonCode method");

            Map<String, Object> delayReasonCodesMap = delayReasonCodeService.searchDelayReasonCodeList(delayReasonId,
                    description, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCodeController Search DelayReasonCode method");
            return getMap(delayReasonCodesMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Search :{}", e);
            return getModelMapError("Error retrieving DelayReasonCodes from database.");
        }
    }
    
    /**
     * This method creates the delayreasoncode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal)  {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DelayReasonCodeController Create DelayReasonCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<DelayReasonCode> delayReasonCodes = delayReasonCodeService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCodeController Create DelayReasonCode method");
            return getMap(delayReasonCodes);

        } catch (DataIntegrityViolationException e) {

            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError("Error trying to create delayreasoncode due to following exception :{}" + cause.getMessage());
            
            
        }  catch (ExistingRecordException e){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create delayreasoncode :{}" + e.getCustomErrorMessage());
            
            
        } catch (Exception e) {
        
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create :{}", e);
            return getModelMapError("Error trying to create delayreasoncode.");
        }
    }

    /**
     * This method updates the delayreasoncode as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DelayReasonCodeController Update DelayReasonCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<DelayReasonCode> delayReasonCodes = delayReasonCodeService.update(data, principal);

            return getMap(delayReasonCodes);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update :{}", e);
            return getModelMapError("Error trying to update delayreasoncode. ");
        }
    }

    /**
     * This method deletes the delayreasoncode.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DelayReasonCodeController Delete DelayReasonCode method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            delayReasonCodeService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DelayReasonCodeController Delete DelayReasonCode method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete delayreasoncode.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param delay reason codes
     *            
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<DelayReasonCode> delayReasonCodes) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, delayReasonCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> delayReasonCodesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) delayReasonCodesMap.get("totalCount");

        List<DelayReasonCode> delayReasonCodes = (List<DelayReasonCode>) delayReasonCodesMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , delayReasonCodes);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, delayReasonCodes);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
