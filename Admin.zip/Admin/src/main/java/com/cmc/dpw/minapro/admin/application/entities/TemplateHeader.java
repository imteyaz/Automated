package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * ValueObjcet holding the template header details
 * @author Imran Rawani
 *
 */
@Entity
@Table(name= "MP_NUMSRSHDR_SPM")
public class TemplateHeader implements Serializable{
   
    private static final long serialVersionUID = -7920596353659481286L;

    @Id
    @Column(name="NUMSRS_ID")
    private String headerId;
    
    @Column(name="NUMSRS_TYPE")
    private String type;
    
    @Column(name="IS_DEFAULT")
    private String isDefault;
    
    @Column(name="CREATED_DATETIME", nullable=false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDateTime;
    
    @Column(name="CREATED_BY")
    private String createdBy;
    
    @Column(name="LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdatedDateTime;
    
    @Column(name="LAST_UPDATED_BY")
    private String lastUpdatedBy;
    
    @Column(name="VERSION", nullable=false)
    private Integer version;
    
    @Column(name = "ISDELETED", nullable = false)
    private char isDeleted;
    
    @Transient
    private char isUsed;
    
  /*  @OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
    // @MapsId("headerId")
     @JoinColumn(name = "NUMSRS_ID", referencedColumnName = "NUMSRS_ID", insertable = false, updatable = false)
    */
    @Transient
    private Collection<TemplateDetails>  templateDetails = new ArrayList<TemplateDetails>();
    
    
    @Transient
    private Collection<Bay>  bayList = new ArrayList<Bay>();
   
    public Collection<TemplateDetails> getTemplateDetails() {
        return templateDetails;
    }

    public void setTemplateDetails(Collection<TemplateDetails> templateDetails) {
        this.templateDetails = templateDetails;
    }

    public Collection<Bay> getBayList() {
        return bayList;
    }

    public void setBayList(Collection<Bay> bayList) {
        this.bayList = bayList;
    }

    public String getHeaderId() {
        return headerId;
    }

    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }
    
    public char getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(char isUsed) {
        this.isUsed = isUsed;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }
}
