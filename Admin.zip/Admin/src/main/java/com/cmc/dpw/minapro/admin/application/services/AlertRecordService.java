package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.AlertRecordDAO;
import com.cmc.dpw.minapro.admin.application.dto.AlertRecordDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertRecord;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Util;


/**
 * AlertRecord Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class AlertRecordService {

    @Autowired
    private AlertRecordDAO alertRecordDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRecordService.class);

    /**
     * This method is used to get AlertRecord List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<AlertRecord> getAlertRecordList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  AlertRecord service's getAlertRecordList");
        alertRecordDAO.setClazz(AlertRecord.class);
        return alertRecordDAO.findAll();

    }

    /**
     * This method is used to search AlertRecord List
     * @return Map<String, Object> containing the search AlertRecord data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchAlertRecordList(Map<String,Object> columnValuePairs) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertRecord service's searchAlertRecordList method");
        alertRecordDAO.setClazz(AlertRecord.class);
       

        String defaultFromTime = "00:00";
        String defaultToTime = "23:59";
        Date parsedFromDate = null;
        Date parsedToDate = null;
        
        String raisedDateFrom = (String) columnValuePairs.get("raisedDateFrom");
        String raisedTimeFrom = (String) columnValuePairs.get("raisedTimeFrom");
        String raisedDateTo = (String) columnValuePairs.get("raisedDateTo");
        String raisedTimeTo = (String) columnValuePairs.get("raisedTimeTo");
        
        if (!"".equalsIgnoreCase(raisedDateFrom) && raisedDateFrom != null) {
            String appendedFromDate = util.appendDateTime(raisedDateFrom, raisedTimeFrom, defaultFromTime);
            parsedFromDate = util.getParsedDateFromString(MessageConstants.DATE_TIME_FORMAT, appendedFromDate);
            LOGGER.debug("parsedFromDate :" + parsedFromDate);
        } else {
            parsedFromDate = null;
        }

        if (!"".equalsIgnoreCase(raisedDateTo) && raisedDateTo != null) {
            String appendedToDate = util.appendDateTime(raisedDateTo, raisedTimeTo, defaultToTime);
            parsedToDate = util.getParsedDateFromString(MessageConstants.DATE_TIME_FORMAT, appendedToDate);
            LOGGER.debug("parsedToDate :" + parsedToDate);
        } else {
            parsedToDate = null;
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRecord service's searchAlertRecordList method");
        return alertRecordDAO.searchAlertRecords(columnValuePairs,parsedFromDate,parsedToDate );
    }

    /**
     * This method is used to update AlertRecordList
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<AlertRecord>
     * @throws ExistingRecordException
     */
    @Transactional
    public List<AlertRecord> update(Object data, Principal principal) throws ExistingRecordException {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertRecord service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  alertRecord  service's  update : {} ", data);
        
        List<AlertRecord> returnAlertRecords = new ArrayList<AlertRecord>();
        alertRecordDAO.setClazz(AlertRecord.class);

        List<AlertRecord> updatedAlertRecords = util.getEntitiesFromDto(data, AlertRecordDTO.class,AlertRecord.class);

        for (AlertRecord alertRecord : updatedAlertRecords) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"getAlertRecordId property in alertRecord service update : {}", alertRecord.getAlertRecordId());
                    returnAlertRecords.add(alertRecordDAO.update(alertRecord));
            
        }

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting AlertRecord service's update method");
        return returnAlertRecords;
    }

}
