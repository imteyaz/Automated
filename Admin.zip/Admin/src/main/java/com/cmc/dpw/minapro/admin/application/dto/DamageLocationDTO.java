package com.cmc.dpw.minapro.admin.application.dto;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonAutoDetect;
/**
 * DamageLocationDTO POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@JsonAutoDetect
public class DamageLocationDTO extends AuditDTO implements Serializable {

    
    private static final long serialVersionUID = 1L;
    private String damageLocationId;
    private String damageLocationDescription;
    
    public String getDamageLocationId() {
        return damageLocationId;
    }
    public void setDamageLocationId(String damageLocationId) {
        this.damageLocationId = damageLocationId;
    }
    public String getDamageLocationDescription() {
        return damageLocationDescription;
    }
    public void setDamageLocationDescription(String damageLocationDescription) {
        this.damageLocationDescription = damageLocationDescription;
    }

    
}
