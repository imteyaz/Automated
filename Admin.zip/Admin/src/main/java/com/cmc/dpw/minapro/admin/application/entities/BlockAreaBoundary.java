package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MP_BLKAREABNDRY_YPM")
public class BlockAreaBoundary implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer blkNo;
    private Integer seqNo;
    private Integer xCoord;
    private Integer yCoord;
    private Integer verStamp;
    private String insUsrCd;
    private Date insDttm;
    private String extUsrFlg;

    private String updDttm;
    private String updExtUsrFlg;
    private Integer txnCd;
    private String txnNo;

    // @EmbeddedId

    @Id
    @Column(name = "INT_BLK_NO")
    public Integer getBlkNo() {
        return blkNo;
    }

    public void setBlkNo(Integer blkNo) {
        this.blkNo = blkNo;
    }

    @Column(name = "SEQ_NO")
    public Integer getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    @Id
    @Column(name = "X_COORD")
    public Integer getxCoord() {
        return xCoord;
    }

    public void setxCoord(Integer xCoord) {
        this.xCoord = xCoord;
    }

    @Id
    @Column(name = "Y_COORD")
    public Integer getyCoord() {
        return yCoord;
    }

    public void setyCoord(Integer yCoord) {
        this.yCoord = yCoord;
    }

    @Id
    @Column(name = "ADT_VER_STAMP")
    public Integer getVerStamp() {
        return verStamp;
    }

    public void setVerStamp(Integer verStamp) {
        this.verStamp = verStamp;
    }

    @Id
    @Column(name = "ADT_INS_USR_CD")
    public String getInsUsrCd() {
        return insUsrCd;
    }

    public void setInsUsrCd(String insUsrCd) {
        this.insUsrCd = insUsrCd;
    }

    @Id
    @Column(name = "ADT_INS_DTTM")
    public Date getInsDttm() {
        return insDttm;
    }

    public void setInsDttm(Date insDttm) {
        this.insDttm = insDttm;
    }

    @Id
    @Column(name = "ADT_INS_EXT_USR_FLG")
    public String getExtUsrFlg() {
        return extUsrFlg;
    }

    public void setExtUsrFlg(String extUsrFlg) {
        this.extUsrFlg = extUsrFlg;
    }

    @Id
    @Column(name = "ADT_UPD_DTTM")
    public String getUpdDttm() {
        return updDttm;
    }

    public void setUpdDttm(String updDttm) {
        this.updDttm = updDttm;
    }

    @Id
    @Column(name = "ADT_UPD_EXT_USR_FLG")
    public String getUpdExtUsrFlg() {
        return updExtUsrFlg;
    }

    public void setUpdExtUsrFlg(String updExtUsrFlg) {
        this.updExtUsrFlg = updExtUsrFlg;
    }

    @Id
    @Column(name = "ADT_TXN_CD")
    public Integer getTxnCd() {
        return txnCd;
    }

    public void setTxnCd(Integer txnCd) {
        this.txnCd = txnCd;
    }

    @Id
    @Column(name = "ADT_TXN_NO")
    public String getTxnNo() {
        return txnNo;
    }

    public void setTxnNo(String txnNo) {
        this.txnNo = txnNo;
    }

}
