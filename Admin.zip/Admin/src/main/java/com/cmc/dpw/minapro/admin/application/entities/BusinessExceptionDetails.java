package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cmc.dpw.minapro.admin.application.entities.pks.BusinessExceptionDetailsPk;

@Entity
@Table(name="MP_BUSINESS_EXCEPTION_DETAIL") 
public class BusinessExceptionDetails implements Serializable{

    private static final long serialVersionUID = -1427275763592689322L;

    @EmbeddedId
    private BusinessExceptionDetailsPk pk;
    
    @Column(name="EXCEPTION_VALUE")
    private String exceptionValue;
    
    @Column(name="EXCEPTION_DESC")
    private String exceptionDesc;
    
    @Transient
    private String tempExceptionCode;

    public BusinessExceptionDetailsPk getPk() {
        return pk;
    }

    public void setPk(BusinessExceptionDetailsPk pk) {
        this.pk = pk;
    }

    public String getExceptionValue() {
        return exceptionValue;
    }

    public void setExceptionValue(String exceptionValue) {
        this.exceptionValue = exceptionValue;
    }

    public String getExceptionDesc() {
        return exceptionDesc;
    }

    public void setExceptionDesc(String exceptionDesc) {
        this.exceptionDesc = exceptionDesc;
    }

    public String getTempExceptionCode() {
        return tempExceptionCode;
    }

    public void setTempExceptionCode(String tempExceptionCode) {
        this.tempExceptionCode = tempExceptionCode;
    }
  
}

