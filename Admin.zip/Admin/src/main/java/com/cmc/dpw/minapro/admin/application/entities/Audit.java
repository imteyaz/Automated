package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

/**
 * Audit class containing the common fields of entity classes which is for audit purpose
 * 
 * @author Imran Rawani
 *
 */
@MappedSuperclass
public class Audit implements Serializable {

    private static final long serialVersionUID = 3831897083980644770L;

    private Date createdDateTime;
    private String createdBy;
    private Date lastUpdatedDateTime;
    private String lastUpdatedBy;
    private Integer version;
    private char isDeleted;


    @Column(name = "CREATED_DATETIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    @Column(name = "CREATED_BY")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "LAST_UPDATED_DATETIME")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    @Column(name = "LAST_UPDATED_BY")
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @Version
    @Column(name = "VERSION", nullable = false)
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Column(name = "ISDELETED", nullable = false)
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    protected void copy(final Audit source) {
        this.createdBy = source.createdBy;
        this.version = source.version;
        this.createdDateTime = source.createdDateTime;
        this.isDeleted = source.isDeleted;
        this.lastUpdatedBy = source.lastUpdatedBy;
        this.lastUpdatedDateTime = source.lastUpdatedDateTime;
    }
}
