package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.WeightageFactorDTO;
import com.cmc.dpw.minapro.admin.application.entities.WeightageFactor;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * WeightageFactor DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class WeightageFactorDAO extends GenericDAO<WeightageFactor> {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeightageFactorDAO.class);
    @Autowired
    private Util util;
/**
 * This method is used to search WeightageFactors
 * @param weightageFactorTypeVal
 * @param weightageFactorCriteriaVal
 * @param weightageFactorVal
 * @param weightageScoreVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchWeightageFactors(String weightageFactorTypeVal, String weightageFactorCriteriaVal, String weightageFactorVal,
            String weightageScoreVal, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering WeightageFactor DAO's searchWeightageFactors method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(WeightageFactor.class,"weightagefactor");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { weightageFactorTypeVal, weightageFactorCriteriaVal, weightageFactorVal, weightageScoreVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchWeightageFactors in WeightageFactor DAO with weightageFactorType: {} , weightageFactorCriteria : {} , weightageFactor : {} , weightageScore : {} , weightageFactorTypeId : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        Util.addRestrictions(searchCriteria, "pk.weightageType", weightageFactorTypeVal, false);
        Util.addRestrictions(searchCriteria, "pk.weightageCriteria", weightageFactorCriteriaVal, false);
        Util.addFloatRestrictions(searchCriteria, "weightageScore", weightageScoreVal, false);
        Util.addFloatRestrictions(searchCriteria, "weightageFactor", weightageFactorVal, false);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
       
        String totalRecords = count.toString();
        
        List<WeightageFactor> searchWeightageFactors = (List<WeightageFactor>) searchCriteria.list();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"data from DB: {}", searchWeightageFactors);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"total count of records matched with given search criteria  : {}", totalRecords);

      

        for (WeightageFactor weightageFactor : searchWeightageFactors) {

            weightageFactor.setType(weightageFactor.getPk().getWeightageType());
            weightageFactor.setCriteria(weightageFactor.getPk().getWeightageCriteria());
            
            String dummyId = weightageFactor.getType() + "-" + weightageFactor.getCriteria() ;
            weightageFactor.setId(dummyId);
            
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"weightageFactor Id  : {}", weightageFactor.toString());
            
        }
        
       
        List<WeightageFactorDTO> searchWeightageFactorsDtoList =  util.map(searchWeightageFactors, WeightageFactorDTO.class);
        
        resultMap.put("data", searchWeightageFactorsDtoList);
        resultMap.put("totalCount", totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting weightageFactorDAO's searchWeightageFactors method ");
        return resultMap;
    }
}
