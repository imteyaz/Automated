package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ActivityType POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "ActivityType")
@Table(name = "MP_ACTIVITYTYPES_MASTER")
public class ActivityType extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String activityTypeId;
    private String description;

    @Id
    @Column(name = "ACTIVITY_TYPE_ID", nullable = false)
    public String getActivityTypeId() {
        return activityTypeId;
    }

    public void setActivityTypeId(String activityTypeId) {
        this.activityTypeId = activityTypeId;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
