package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.codehaus.jackson.annotate.JsonIgnore;


/**
 * Role POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "Role")
@Table(name = "MP_GRPDTLS_AM")
public class Role implements Serializable {

    private static final long serialVersionUID = 1L;
    private int intUserGroupId;
    private String userGroupCd;
    private String sDesc;
    private String userGroupName;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String systemDefined ;

    private String srvTypeGroupCd;
    private char isDeleted;
    private Collection<User> actualUsers = new ArrayList<User>();
    private Integer version;
    private String createdBy;
    private String lastUpdatedBy;
    private Date createdDateTime;
    private Date lastUpdatedDateTime;

    @Version
    @Column(name = "VERSION", nullable = false)
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    @Column(name = "ISDELETED", nullable = false)
    public char getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    // @Transient
    // @ManyToMany(mappedBy="actualRoles")
    @JsonIgnore
    // @ManyToMany(fetch=FetchType.LAZY,mappedBy = "actualRoles")
    @ManyToMany(fetch = FetchType.LAZY)
    // @Cascade({CascadeType.SAVE_UPDATE})
    @JoinTable(name = "MP_USERGRP_A", joinColumns = @JoinColumn(name = "INT_USER_GRP_ID"), inverseJoinColumns = @JoinColumn(name = "INT_USER_ID"))
    public Collection<User> getActualUsers() {
        return actualUsers;
    }

    public void setActualUsers(Collection<User> actualUsers) {
        this.actualUsers = actualUsers;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "roleSequence")
    @SequenceGenerator(name = "roleSequence", sequenceName = "MP_GROUP_SEQ", allocationSize = 1, initialValue = 30)
    @Column(name = "INT_USER_GRP_ID", nullable = false)
    public int getIntUserGroupId() {
        return intUserGroupId;
    }

    public void setIntUserGroupId(int intUserGroupId) {
        this.intUserGroupId = intUserGroupId;
    }

    @Column(name = "USER_GRP_CD")
    public String getUserGroupCd() {
        return userGroupCd;
    }

    public void setUserGroupCd(String userGroupCd) {
        this.userGroupCd = userGroupCd;
    }

    @Column(name = "S_DESCR")
    public String getsDesc() {
        return sDesc;
    }

    public void setsDesc(String sDesc) {
        this.sDesc = sDesc;
    }

    @Column(name = "USER_GRP_NM")
    public String getUserGroupName() {
        return userGroupName;
    }

    public void setUserGroupName(String userGroupName) {
        this.userGroupName = userGroupName;
    }

    @Column(name = "ADT_INS_FUNCTION_CD")
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }

    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }

    @Column(name = "ADT_UPD_FUNCTION_CD")
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }

    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }

    @Column(name = "ADT_INS_USER_NM")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "ADT_UPD_USER_NM")
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @Column(name = "ADT_INS_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    @Column(name = "ADT_UPD_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    @Column(name = "SRV_TYPE_GRP_CD")
    public String getSrvTypeGroupCd() {
        return srvTypeGroupCd;
    }

    public void setSrvTypeGroupCd(String srvTypeGroupCd) {
        this.srvTypeGroupCd = srvTypeGroupCd;
    }

    @Column(name = "SYSTEM_DEFINED")
    public String getSystemDefined() {
        return systemDefined;
    }

    public void setSystemDefined(String systemDefined) {
        this.systemDefined = systemDefined;
    }
    
    

}
