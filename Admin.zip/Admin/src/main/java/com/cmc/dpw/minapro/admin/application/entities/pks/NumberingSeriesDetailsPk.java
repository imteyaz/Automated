package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * ValueObject holding the primary key for the Template details
 * @author Imran Rawani
 *
 */
@Embeddable
public class NumberingSeriesDetailsPk implements Serializable {
    
    private static final long serialVersionUID = 2454206915273897222L;

  
   
    private String headerId;
    private Integer seqNo;
    
    @Column(name="NUMSRS_ID")
    public String getHeaderId() {
        return headerId;
    }
    public void setHeaderId(String headerId) {
        this.headerId = headerId;
    }
    
    @Column(name="SEQ_NO")
    public Integer getSeqNo() {
        return seqNo;
    }
    public void setSeqNo(Integer seqNo) {
        this.seqNo = seqNo;
    }

    
}
