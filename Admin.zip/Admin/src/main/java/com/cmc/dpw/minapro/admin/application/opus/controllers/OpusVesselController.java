package com.cmc.dpw.minapro.admin.application.opus.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.entities.RotationControl;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselExceptionEntity;
import com.cmc.dpw.minapro.admin.application.opus.entities.OpusEquipmentDto;
import com.cmc.dpw.minapro.admin.application.opus.entities.OpusVesselDto;
import com.cmc.dpw.minapro.admin.application.opus.services.OpusVesselService;
import com.cmc.dpw.minapro.admin.application.services.EquipmentService;
import com.cmc.dpw.minapro.admin.application.services.RotationControlService;
import com.cmc.dpw.minapro.admin.application.services.VesselExceptionService;
import com.cmc.dpw.minapro.admin.application.services.VesselService;
import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

@Controller
public class OpusVesselController {

    @Autowired
    OpusVesselService opusVesselService;
    @Autowired
    VesselService atomVesselService;
    @Autowired
    RotationControlService atomRotationService;
    @Autowired
    EquipmentService atomEquipmentService;
    @Autowired
    VesselExceptionService vesselExceptionService;
    @Autowired
    private Util util;

    private static final Logger LOGGER = LoggerFactory.getLogger(OpusVesselController.class);

    Map<String, Vessel> vesselCache = null;
    Map<String, RotationControl> allRotationsCache = null;
    Map<String, RotationControl> berthedRotationsCache = null;
    Map<String, RotationControl> registeredRotationsCache = null;
    Map<String, Equipment> equipmentsCache = null;

    // Map<String, VesselExceptionEntity> vesselExceptionsCache = null;

    public void initializeCaches() {
        vesselCache = refreshVesselCache();
        allRotationsCache = refreshAllRotationsCache();
        berthedRotationsCache = refreshBerthedRotationsCache();
        registeredRotationsCache = refreshRegisteredRotationsCache();
        equipmentsCache = refreshEquipmentsCache();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "All caches initailized successfully ");
    }


    public void syncRegisteredRotations() {
        initializeCaches();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncRegisteredRotations--->START @-->"
                + new Date());

        List<OpusVesselDto> registeredRotationsList = opusVesselService.fetchRegisteredRotations();
        List<RotationControl> registeredRotationsToBeCreated = new ArrayList<RotationControl>();
        List<RotationControl> registeredRotationsToBeUpdated = new ArrayList<RotationControl>();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->registeredRotationsList from OPUS--->"
                + registeredRotationsList.size());

        // for each registered rotation, create rotation control and insert it if the vessel code already exits in
        // vessel master, else raise vessel exception

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "$$$$$$$$$$$$$$$$$$$$$$ Syncronizing Registered Rotations #####################");

        for (OpusVesselDto currentOpusRotation : registeredRotationsList) {

            clearExceptionsForRotation(Integer.parseInt(currentOpusRotation.getRotation()));

            String opusVesselCode = currentOpusRotation.getVesselCode();
            Vessel associatedVessel = null;

            if (vesselCache.containsKey(opusVesselCode)) {
                associatedVessel = vesselCache.get(opusVesselCode);
            } else {
                associatedVessel = atomVesselService.fineOne(0);
                raiseVesselException(currentOpusRotation, "Registered");
            }

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "currentOpusRotation--->" + currentOpusRotation);
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusVesselCode--->" + opusVesselCode);

            List<Equipment> assignedEquipments = new ArrayList<Equipment>();

            Integer opusRotationNo = Integer.parseInt(currentOpusRotation.getRotation());
            Date currentDate = new Date();
            RotationControl currentAtomRotationControl = null;

            if (allRotationsCache.containsKey(currentOpusRotation.getRotation())) {
                currentAtomRotationControl = allRotationsCache.get(currentOpusRotation.getRotation());
                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "rotation--->" + currentOpusRotation.getRotation()
                        + " found in allRotationsCache ! ");

            } else {
                currentAtomRotationControl = new RotationControl();
                currentAtomRotationControl.setCreatedBy("Admin App OPUS Scheduler");
                currentAtomRotationControl.setCreatedDateTime(currentDate);
                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "rotation--->" + currentOpusRotation.getRotation()
                        + "  not found in allRotationsCache, creating new one ! ");
            }
            
            
            String defaultBerthNo = MessageConstants.DEFAULT_BERTH_NO   ;
            String berthNo = currentOpusRotation.getBerthNo() ;
            
            if(berthNo!=null){
                currentAtomRotationControl.setBerthNo(berthNo);
            }
            else{
                currentAtomRotationControl.setBerthNo(defaultBerthNo);
            }
            
            

            currentAtomRotationControl.setRotationNumber(opusRotationNo);
            currentAtomRotationControl.setVoyageNo(currentOpusRotation.getVoyageNo());
            currentAtomRotationControl.setStatus('R');
            currentAtomRotationControl.setActualVessel(associatedVessel);
            currentAtomRotationControl.setTerminalId("T2");
            currentAtomRotationControl.setLastUpdatedBy("Admin App OPUS Scheduler");
            currentAtomRotationControl.setLastUpdatedDateTime(currentDate);
            currentAtomRotationControl.setIsDeleted('N');
            currentAtomRotationControl.setVesselNo(associatedVessel.getVesselNo());
            currentAtomRotationControl.setVesselCode(opusVesselCode);

            handleDateTimeConversion(currentAtomRotationControl, currentOpusRotation);

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "vesselNo--->" + associatedVessel.getVesselNo());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "VoyageNo--->" + currentOpusRotation.getVoyageNo());

            List<OpusEquipmentDto> equipmentsForCurrentRotation = fetchEquipmentsForRotation(currentOpusRotation
                    .getRotation());

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + equipmentsForCurrentRotation.size()
                    + "equipments found in OPUS for Rotation--->" + opusRotationNo);

            for (OpusEquipmentDto currentOpusEquipment : equipmentsForCurrentRotation) {

                String opusEquipmentId = currentOpusEquipment.getEquipmentId();

                if (equipmentsCache.containsKey(opusEquipmentId)) {
                    assignedEquipments.add(equipmentsCache.get(opusEquipmentId));
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                            + " found in equipmentsCache - hence assigning to rotation ! ");

                } else {
                    // raise vessel exception - equipment not found with ATOM

                    // clearExceptionsForRotation(currentAtomRotationControl.getRotationNumber());
                    LOGGER.error(MessageConstants.ERROR_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                            + "not found in equipmentsCache - raising Equipment Exception ! ");
                    raiseEquipmentException(currentAtomRotationControl, opusEquipmentId, opusVesselCode);

                }

            }
            currentAtomRotationControl.setActualEquipments(assignedEquipments);

            if (allRotationsCache.containsKey(currentOpusRotation.getRotation())) {
                registeredRotationsToBeUpdated.add(currentAtomRotationControl);
            } else {
                registeredRotationsToBeCreated.add(currentAtomRotationControl);
            }

            

        }

        atomRotationService.createRotationsFromOpus(registeredRotationsToBeCreated);
        atomRotationService.updateRotationsFromOpus(registeredRotationsToBeUpdated, "R");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncRegisteredRotations--->STOP @-->"
                + new Date());
    }

    private void handleDateTimeConversion(RotationControl currentAtomRotationControl, OpusVesselDto currentOpusRotation) {

        String dateInString = currentOpusRotation.getEtaDate() + "/" + currentOpusRotation.getEtaTime();

        Date parsedDate = util.getParsedDateFromString(MessageConstants.OPUS_DATE_TIME_FORMAT, dateInString);

        currentAtomRotationControl.setEtaDate(parsedDate);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "OpusVesselController--->syncRegisteredRotations--->handleDateTimeConversion successfully done for rotation"
                + currentOpusRotation.getRotation());

    }

    public static String convertListToString(List<String> list, String delimiter) {
        StringBuilder data = new StringBuilder();
        if (!CollectionUtils.isEmpty(list)) {
          for (String str : list) {
            if(data.length() > 0) {
              data.append(delimiter);
            }
            if(!StringUtils.isEmpty(str) && !str.trim().equalsIgnoreCase("null")) {
              data.append(str.trim());
            }
          }
        }
        return data.toString();
      }


    public void syncBerthedRotations() {

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncBerthedRotations--->START @-->"
                + new Date());

        List<RotationControl> berthedRotationsToBeUpdated = new ArrayList<RotationControl>();

        Set<String> registeredRotationsSet = registeredRotationsCache.keySet();

        List<String> registeredRotationsList = new ArrayList<String>(registeredRotationsSet);
       // String atomRegisteredRotations = StringUtils.arrayToCommaDelimitedString(registeredRotationsList.toArray());
        String atomRegisteredRotations = convertListToString(registeredRotationsList,"','");
        LOGGER.debug(MessageConstants.INFO_INDICATOR + "syncBerthedRotations -->B4 atomRegisteredRotations  found--->"
                + atomRegisteredRotations);
        atomRegisteredRotations="'"+atomRegisteredRotations+"'";
        
        LOGGER.debug(MessageConstants.INFO_INDICATOR + "syncBerthedRotations -->after   atomRegisteredRotations found--->"
                + atomRegisteredRotations);
        

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "syncBerthedRotations --> atomRegisteredRotations found--->"
                + atomRegisteredRotations);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "syncBerthedRotations --> No of atom Registered Rotations found--->" + registeredRotationsSet.size());

        if (!atomRegisteredRotations.isEmpty()) {

            List<OpusVesselDto> berthedRotations = opusVesselService.fetchBerthedRotations(atomRegisteredRotations);

            // for each berthed rotation, update existing rotation control if the vessel code already exits in
            // vessel master, else raise vessel exception

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                    + "$$$$$$$$$$$$$$$$$$$$$$ Syncronizing Berthed Rotations #####################");

            for (OpusVesselDto currentOpusBerthedRotation : berthedRotations) {

                clearExceptionsForRotation(Integer.parseInt(currentOpusBerthedRotation.getRotation()));

                String opusVesselCode = currentOpusBerthedRotation.getVesselCode();

                if (vesselCache.containsKey(opusVesselCode)) {

                    List<Equipment> assignedEquipments = new ArrayList<Equipment>();
                    Vessel associatedVessel = vesselCache.get(opusVesselCode);
                    Integer opusRotationNo = Integer.parseInt(currentOpusBerthedRotation.getRotation());
                    Date currentDate = new Date();

                    RotationControl currentAtomRotationControl = registeredRotationsCache
                            .get(currentOpusBerthedRotation.getRotation());
                    
                    
                    String defaultBerthNo = MessageConstants.DEFAULT_BERTH_NO  ;
                    String berthNo = currentOpusBerthedRotation.getBerthNo() ;
                    String berthSide = currentOpusBerthedRotation.getBerthSide();
                    String defaultBerthSide = "P" ;
                    
                    if(berthNo!=null){
                        currentAtomRotationControl.setBerthNo(berthNo);
                    }
                    else{
                        currentAtomRotationControl.setBerthNo(defaultBerthNo);
                    }
                    
                    if(berthSide!=null){
                        if("P".equalsIgnoreCase(berthSide) || "S".equalsIgnoreCase(berthSide)){
                            currentAtomRotationControl.setBerthSide(berthSide);
                        }else{
                            currentAtomRotationControl.setBerthSide(defaultBerthSide); 
                        }
                    }
                    else{
                        currentAtomRotationControl.setBerthSide(defaultBerthSide);
                    }
                    

                    currentAtomRotationControl.setRotationNumber(opusRotationNo);
                    currentAtomRotationControl.setVoyageNo(currentOpusBerthedRotation.getVoyageNo());
                    currentAtomRotationControl.setBerthSide(berthSide);
                    currentAtomRotationControl.setStatus('B');
                    currentAtomRotationControl.setActualVessel(associatedVessel);
                    currentAtomRotationControl.setTerminalId("T2");
                    currentAtomRotationControl.setLastUpdatedBy("Admin App OPUS Scheduler");
                    currentAtomRotationControl.setLastUpdatedDateTime(currentDate);
                    currentAtomRotationControl.setVesselNo(associatedVessel.getVesselNo());
                    currentAtomRotationControl.setVesselCode(opusVesselCode);

                    handleDateTimeConversion(currentAtomRotationControl, currentOpusBerthedRotation);

                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "currentOpusRotation--->"
                            + currentOpusBerthedRotation);
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusVesselCode--->" + opusVesselCode);
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "vesselNo--->" + associatedVessel.getVesselNo());
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "VoyageNo--->"
                            + currentOpusBerthedRotation.getVoyageNo());

                    List<OpusEquipmentDto> equipmentsForCurrentRotation = fetchEquipmentsForRotation(currentOpusBerthedRotation
                            .getRotation());

                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + equipmentsForCurrentRotation.size()
                            + "equipments found in OPUS for Rotation--->" + opusRotationNo);

                    for (OpusEquipmentDto currentOpusEquipment : equipmentsForCurrentRotation) {

                        String opusEquipmentId = currentOpusEquipment.getEquipmentId();
                        if (equipmentsCache.containsKey(opusEquipmentId)) {
                            assignedEquipments.add(equipmentsCache.get(opusEquipmentId));
                            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                                    + " found in equipmentsCache - hence assigning to rotation ! ");

                        } else {
                            // raise vessel exception - equipment not found with ATOM
                            LOGGER.error(MessageConstants.ERROR_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                                    + "not found in equipmentsCache - raising Equipment Exception ! ");
                            raiseEquipmentException(currentAtomRotationControl, opusEquipmentId, opusVesselCode);
                        }

                    }
                    currentAtomRotationControl.setActualEquipments(assignedEquipments);
                    berthedRotationsToBeUpdated.add(currentAtomRotationControl);


                } else {
                    // raise vessel exception - vessel not found with ATOM
                    raiseVesselException(currentOpusBerthedRotation, "Berthed");
                }

            }

            atomRotationService.updateRotationsFromOpus(berthedRotationsToBeUpdated, "B");
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncBerthedRotations--->STOP @-->"
                + new Date());
    }

    public void syncSailedRotations() {

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncSailedRotations--->START @-->"
                + new Date());

        List<RotationControl> sailedRotationsToBeUpdated = new ArrayList<RotationControl>();

        Set<String> berthedRotationsSet = berthedRotationsCache.keySet();
        List<String> sailedRotationsList = new ArrayList<String>();

        List<String> berthedRotationsList = new ArrayList<String>(berthedRotationsSet);
        String atomBerthedRotations = StringUtils.arrayToCommaDelimitedString(berthedRotationsList.toArray());
        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "syncSailedRotations --> atomBerthedRotations found--->"
                + atomBerthedRotations);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "syncSailedRotations --> No of atom berthed Rotations found--->" + berthedRotationsSet.size());


        if (!atomBerthedRotations.isEmpty()) {

            List<OpusVesselDto> sailedRotations = opusVesselService.fetchSailedRotations(atomBerthedRotations);

            // for each berthed rotation, update existing rotation control if the vessel code already exits in
            // vessel master, else raise vessel exception

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                    + "$$$$$$$$$$$$$$$$$$$$$$ Syncronizing Sailed Rotations #####################");

            for (OpusVesselDto currentOpusSailedRotation : sailedRotations) {

                String rotationNo = currentOpusSailedRotation.getRotation();
                sailedRotationsList.add(rotationNo);
                clearExceptionsForRotation(Integer.parseInt(rotationNo));

                String opusVesselCode = currentOpusSailedRotation.getVesselCode();

                if (vesselCache.containsKey(opusVesselCode)) {

                    Vessel associatedVessel = vesselCache.get(opusVesselCode);
                    Integer opusRotationNo = Integer.parseInt(currentOpusSailedRotation.getRotation());
                    Date currentDate = new Date();

                    RotationControl currentAtomRotationControl = berthedRotationsCache.get(currentOpusSailedRotation
                            .getRotation());
                    
                    
                    String defaultBerthNo = MessageConstants.DEFAULT_BERTH_NO  ;
                    String berthNo = currentOpusSailedRotation.getBerthNo() ;
                    
                    
                    if(berthNo!=null){
                        currentAtomRotationControl.setBerthNo(berthNo);
                    }
                    else{
                        currentAtomRotationControl.setBerthNo(defaultBerthNo);
                    }
                    

                    currentAtomRotationControl.setRotationNumber(opusRotationNo);
                    currentAtomRotationControl.setVoyageNo(currentOpusSailedRotation.getVoyageNo());
                    currentAtomRotationControl.setStatus('S');
                    currentAtomRotationControl.setActualVessel(associatedVessel);
                    currentAtomRotationControl.setTerminalId("T2");
                    currentAtomRotationControl.setLastUpdatedBy("Admin App OPUS Scheduler");
                    currentAtomRotationControl.setLastUpdatedDateTime(currentDate);
                    currentAtomRotationControl.setVesselNo(associatedVessel.getVesselNo());
                    currentAtomRotationControl.setVesselCode(opusVesselCode);

                    handleDateTimeConversion(currentAtomRotationControl, currentOpusSailedRotation);

                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "currentOpusRotation--->"
                            + currentOpusSailedRotation);
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusVesselCode--->" + opusVesselCode);
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "vesselNo--->" + associatedVessel.getVesselNo());
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "VoyageNo--->"
                            + currentOpusSailedRotation.getVoyageNo());

                    

                    sailedRotationsToBeUpdated.add(currentAtomRotationControl);

                    

                } else {
                    // raise vessel exception - vessel not found with ATOM
                    raiseVesselException(currentOpusSailedRotation, "Sailed");
                }

            }

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "sailedRotationsList size-->" + sailedRotationsList.size());
            for (String sailedRotation : sailedRotationsList) {
                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "removing rotation-->" + sailedRotation
                        + " from berthedRotationsCache");
                berthedRotationsCache.remove(sailedRotation);
            }

            List<RotationControl> stillBerthedRotationsToBeUpdated = new ArrayList<RotationControl>();

            for (Map.Entry<String, RotationControl> currentEntry : berthedRotationsCache.entrySet()) {

                String currentBerthedRotation = currentEntry.getKey();
                RotationControl currentBerthedRotationControl = currentEntry.getValue();
                String vesselCode = currentBerthedRotationControl.getActualVessel().getVesselCode();

                clearExceptionsForRotation(currentBerthedRotationControl.getRotationNumber());

                List<OpusEquipmentDto> equipmentsForBerthedRotation = fetchEquipmentsForRotation(currentBerthedRotation);
                List<Equipment> assignedEquipments = new ArrayList<Equipment>();

                LOGGER.debug(MessageConstants.DEBUG_INDICATOR + equipmentsForBerthedRotation.size()
                        + "equipments found in OPUS for Rotation--->"
                        + currentBerthedRotationControl.getRotationNumber().toString());

                for (OpusEquipmentDto currentOpusEquipment : equipmentsForBerthedRotation) {

                    String opusEquipmentId = currentOpusEquipment.getEquipmentId();
                    if (equipmentsCache.containsKey(opusEquipmentId)) {
                        assignedEquipments.add(equipmentsCache.get(opusEquipmentId));
                        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                                + " found in equipmentsCache - hence assigning to rotation ! ");

                    } else {
                        // raise vessel exception - equipment not found with ATOM

                        LOGGER.error(MessageConstants.ERROR_INDICATOR + "opusEquipmentId--->" + opusEquipmentId
                                + "not found in equipmentsCache - raising Equipment Exception ! ");

                        raiseEquipmentException(currentBerthedRotationControl, opusEquipmentId, vesselCode);

                    }

                }
                currentBerthedRotationControl.setActualEquipments(assignedEquipments);

                stillBerthedRotationsToBeUpdated.add(currentBerthedRotationControl);

            }

            atomRotationService.updateRotationsFromOpus(sailedRotationsToBeUpdated, "S");
            atomRotationService.updateRotationsFromOpus(stillBerthedRotationsToBeUpdated, "EQ");

        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->syncSailedRotations--->STOP @-->"
                + new Date());
    }

    public List<OpusEquipmentDto> fetchEquipmentsForRotation(String rotationNo) {

        return opusVesselService.fetchEquipmentsForRotation(rotationNo);

    }

    private Map<String, Vessel> refreshVesselCache() {

        Map<String, Vessel> vesselCache = new HashMap<String, Vessel>();

        if (atomVesselService != null) {

            List<Vessel> allAtomVessels = atomVesselService.loadVesselCache();

            for (Vessel currentAtomVessel : allAtomVessels) {

                String vesselCode = currentAtomVessel.getVesselCode();
                vesselCache.put(vesselCode, currentAtomVessel);

            }
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->refreshVesselCache--->size -->"
                + vesselCache.size());

        return vesselCache;

    }

    private Map<String, RotationControl> refreshAllRotationsCache() {

        Map<String, RotationControl> allRotationsCache = new HashMap<String, RotationControl>();

        if (atomRotationService != null) {

            List<RotationControl> allAtomRotations = atomRotationService.loadAllRotations();

            for (RotationControl currentAtomRotation : allAtomRotations) {

                String rotationNo = currentAtomRotation.getRotationNumber().toString();
                allRotationsCache.put(rotationNo, currentAtomRotation);

            }
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->allRotationsCache--->size -->"
                + allRotationsCache.size());

        return allRotationsCache;
    }

    private Map<String, RotationControl> refreshRegisteredRotationsCache() {

        Map<String, RotationControl> registeredRotationsCache = new HashMap<String, RotationControl>();
        if (atomRotationService != null) {

            List<RotationControl> registeredAtomRotations = atomRotationService.loadRegisteredRotations();

            for (RotationControl currentAtomRotation : registeredAtomRotations) {

                String rotationNo = currentAtomRotation.getRotationNumber().toString();
                registeredRotationsCache.put(rotationNo, currentAtomRotation);

            }
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->registeredRotationsCache--->size -->"
                + registeredRotationsCache.size());

        return registeredRotationsCache;
    }

    private Map<String, RotationControl> refreshBerthedRotationsCache() {

        Map<String, RotationControl> berthedRotationsCache = new HashMap<String, RotationControl>();

        if (atomRotationService != null) {

            List<RotationControl> berthedAtomRotations = atomRotationService.loadBerthedRotations();

            for (RotationControl currentAtomRotation : berthedAtomRotations) {

                String rotationNo = currentAtomRotation.getRotationNumber().toString();
                berthedRotationsCache.put(rotationNo, currentAtomRotation);

            }

        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->berthedRotationsCache--->size -->"
                + berthedRotationsCache.size());

        return berthedRotationsCache;
    }

    private Map<String, Equipment> refreshEquipmentsCache() {

        Map<String, Equipment> equipmentsCache = new HashMap<String, Equipment>();

        if (atomEquipmentService != null) {

            List<Equipment> equipments = atomEquipmentService.loadAllEquipments();

            for (Equipment currentEquipment : equipments) {

                String equipmentId = currentEquipment.getEquipmentId();
                equipmentsCache.put(equipmentId, currentEquipment);

            }
        }
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->equipmentsCache--->size -->"
                + equipmentsCache.size());

        return equipmentsCache;
    }


    private void clearExceptionsForRotation(Integer rotationNumber) {
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "OpusVesselController--->clearExceptionsForRotation--->START-->rotationNumber -->" + rotationNumber);
        vesselExceptionService.clearVesselExceptionsForRotation(rotationNumber);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "OpusVesselController--->clearExceptionsForRotation--->STOP-->rotationNumber -->" + rotationNumber);
    }

    private void raiseVesselException(OpusVesselDto opusRotation, String status) {
        String statusMessage = "This rotation is currently " + status
                + " in OPUS ; but it can not be berthed in ATOM until the vesselcode is defined in ATOM. ";
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->raiseVesselException--->START");

        String[] requestParameters = { opusRotation.getRotation(), opusRotation.getVesselCode(), status };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "OpusVesselController-->raiseVesselException Details--> Rotation:{},VesselCode :{},status :{}",
                requestParameters);

        VesselExceptionEntity vesselNotFoundException = new VesselExceptionEntity();
        Date currentDate = new Date();
        vesselNotFoundException.setCreatedBy("Admin App OPUS Scheduler");
        vesselNotFoundException.setCreatedDateTime(currentDate);
        vesselNotFoundException.setExceptionType("UNDEFINED_VESSEL_CODE");
        vesselNotFoundException.setRotation(Integer.parseInt(opusRotation.getRotation()));
        vesselNotFoundException.setDescription("OPUS Vessel Code -->" + opusRotation.getVesselCode()
                + " is not defined in ATOM. " + statusMessage);

        vesselNotFoundException.setVesselNo(0);
        vesselExceptionService.createVesselException(vesselNotFoundException);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->raiseVesselException--->END");
    }

    private void raiseEquipmentException(RotationControl atomRotationControl, String opusEquipmentId, String vesselCode) {
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->raiseEquipmentException--->START");

        Integer vesselNo = 0; // default code for undefined vessel codes
        String statusMessage = opusEquipmentId
                + " , which is not defined in ATOM. So, unable to assign this equipment to the rotation -->"
                + atomRotationControl.getRotationNumber();


        Vessel associatedVessel = vesselCache.get(vesselCode);

        if (associatedVessel != null) {
            vesselNo = associatedVessel.getVesselNo();
        }

        String[] requestParameters = { atomRotationControl.getRotationNumber().toString(), vesselCode,
                vesselNo.toString() };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "OpusVesselController-->raiseEquipmentException Details--> Rotation:{},VesselCode :{},vesselNo :{}",
                requestParameters);

        VesselExceptionEntity equipmentNotFoundException = new VesselExceptionEntity();

        
        Date currentDate = new Date();
        equipmentNotFoundException.setCreatedBy("Admin App OPUS Scheduler");
        equipmentNotFoundException.setCreatedDateTime(currentDate);
        equipmentNotFoundException.setExceptionType("UNDEFINED_EQUIPMENT");
        equipmentNotFoundException.setRotation(atomRotationControl.getRotationNumber());
        equipmentNotFoundException.setDescription("OPUS Vessel Code -->" + vesselCode + " is having Equipment Id --> "
                + statusMessage);
        equipmentNotFoundException.setVesselNo(vesselNo);
        equipmentNotFoundException.setEquipmentId(opusEquipmentId);

        vesselExceptionService.createVesselException(equipmentNotFoundException);

        
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "OpusVesselController--->raiseEquipmentException--->END");
    }
    
    public void syncEquipmentMappingsForRotations() {
    QueueUtil.publishToQueues("MP_ROTATION_QC_MAPPING");
    LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "syncEquipmentMappingsForRotations-->published equipment changes for all rotations" );
    }
}
