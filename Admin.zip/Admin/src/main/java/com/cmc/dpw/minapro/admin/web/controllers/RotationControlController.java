package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.RotationControl;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.services.RotationControlService;
import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;
import com.minapro.procserver.events.common.VesselBerthEvent;
import com.minapro.procserver.events.common.VesselSailEvent;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/rotationControl")
public class RotationControlController {

    @Autowired
    private RotationControlService rotationControlService;
    private static final Logger LOGGER = LoggerFactory.getLogger(RotationControlController.class);
    /**
     * This method searches for all the rotations matching the search criteria
     * as entered by the end user
     * @param equipmentId
     * @param etaDateFrom
     * @param etaDateTo
     * @param status
     * @param terminalId
     * @param vesselCode
     * @param etaTimeFrom
     * @param etaTimeTo
     * @param berthNo
     * @param start
     * @return  Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String rotationNumber,
            @RequestParam(required = false) String equipmentId, @RequestParam(required = false) String vesselCode,
            @RequestParam(required = false) String etaDateFrom, @RequestParam(required = false) String etaTimeFrom,
            @RequestParam(required = false) String etaDateTo, @RequestParam(required = false) String etaTimeTo,
            @RequestParam(required = false) String status, @RequestParam(required = false) String berthNo,
            @RequestParam(required = false) String terminalId, @RequestParam(required = false) int start,
            @RequestParam(required = false) int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start RotationControlController Search RotationControl method");
        
        String[] requestParameters = { rotationNumber, equipmentId, vesselCode, etaDateFrom, etaTimeFrom, etaDateTo,
                etaTimeTo, status };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"RotationControlController-->Seacrh-->Data--> rotationNumber:{},equipmentId:{},vesselCode:{},etaDateFrom:{},etaTimeFrom:{},etaDateTo:{},etaTimeTo:{},status:{}",
                requestParameters);

        try {
            Map<String, Object> rotationControlsMap = rotationControlService.searchRotationControlList(rotationNumber,
                    equipmentId, vesselCode, etaDateFrom, etaTimeFrom, etaDateTo, etaTimeTo, status, start, limit,
                    berthNo, terminalId);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RotationControlController Search RotationControl method");
            return getMap(rotationControlsMap);

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Exception-->Search", e);
            return getModelMapError("Error retrieving RotationControls from database.");
        }
    }

    /**
     * This method creates the Rotation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return   List<RotationControl> containing the created Rotation data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
         
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start RotationControlController Create RotationControl method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);

        try {
            List<RotationControl> newRotationControls = rotationControlService.create(data, principal);
            char isActive;
            VesselBerthEvent vb = new VesselBerthEvent();

            for (RotationControl rc : newRotationControls) {
                isActive = rc.getStatus();

                if (isActive == 'B' || isActive == 'b') {

                    rotationControlService.publishVesselEvent(rc, vb, MessageConstants.BIRTH_EVENT);

                }
            }

            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RotationControlController Create RotationControl method");
            return getMap(newRotationControls);

        } catch (ConstraintViolationException e) {
               
            SQLException cause = (SQLException) e.getCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ConstraintViolationException", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL + cause.getMessage());

        } catch (JDBCConnectionException e) {
            // Lost the connection
            SQLException cause = (SQLException) e.getCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"JDBCConnectionException", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL + cause.getMessage());
            
        } catch (DataIntegrityViolationException e) {
          
            SQLException cause = (SQLException) e.getRootCause();
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL + cause.getMessage());
            
        } catch (ExistingRecordException e){

            LOGGER.error(MessageConstants.ERROR_INDICATOR + MessageConstants.EXISTING_RECORD_EXCEPTION, e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL + e.getCustomErrorMessage());
            
            
        }   catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create :{}", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL);
        }

    }

    /**
     * This method updates the rotation as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<RotationControl> containing the updated rotation data and success indicator or
     * the error message and failure indicator.
     */  
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start RotationControlController Update RotationControl method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            List<RotationControl> updatedRotationControls = rotationControlService.update(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RotationControlController Update RotationControl method");

            Boolean isActiveModified;
            Boolean isQCModified;

            VesselBerthEvent vb = new VesselBerthEvent();
            VesselSailEvent vs = new VesselSailEvent();

            for (RotationControl rc : updatedRotationControls) {
                isActiveModified = rc.getIsActiveModified();
                isQCModified = rc.getIsQCModified();
                char status = rc.getStatus();

                if (isActiveModified) {
                    if (status == 'B' || status == 'b') {
                        rotationControlService.publishVesselEvent(rc, vb,MessageConstants.BIRTH_EVENT);
                    } else if ((status == 'S' || status == 's')|| (status == 'R' || status == 'r')) {
                        rotationControlService.publishVesselEvent(rc, vs, "Sail");
                    }

                }

                if (isQCModified && (status == 'B' || status == 'b')) {
                        QueueUtil.publishToQueues("MP_ROTATION_QC_MAPPING");
                }
            }

            return getMap(updatedRotationControls);

        } catch (ExistingRecordException e){

            LOGGER.error(MessageConstants.ERROR_INDICATOR + MessageConstants.EXISTING_RECORD_EXCEPTION, e);
            return getModelMapError(MessageConstants.UPDATE_ROTATIONCONTROL + e.getCustomErrorMessage());
            
            
        }   catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update :{}", e);
            return getModelMapError(MessageConstants.UPDATE_ROTATIONCONTROL);
        }
    }
    
    /**
     * This method deletes the rotation.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted rotation data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start RotationControlController Delete RotationControl method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + MessageConstants.DATA_LOGGER, data);
        try {
            rotationControlService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RotationControlController Delete RotationControl method");
            return modelMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete :{}", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL);
        }
    }

    /**
     * This method used to refreshCache rotationControl
     * @param rotationNumber
     * @param vesselCode
     * @return Map<String, Object> containing the refreshCache rotation data and success indicator or
     * the error message and failure indicator.
     */
    @RequestMapping(value = "/refreshCache.action")
    @ResponseBody public
    Map<String, Object> refreshRotationCache(@RequestParam String rotationNumber, @RequestParam String vesselCode)  {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start RotationControlController refreshCache RotationControl method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"RotationControlController-->refreshCache RotationControl:{}", rotationNumber);
        try {
            rotationControlService.refreshCache(rotationNumber, vesselCode);
            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting RotationControlController refreshCache RotationControl method");
            return modelMap;

        } catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->refreshCache", e);
            return getModelMapError(MessageConstants.CREATE_ROTATIONCONTROL);
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> containing the rotation data and success indicator or
     * the error message and failure indicator.
     */
    private Map<String, Object> getMap(List<RotationControl> rotationControls) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        modelMap.put(MessageConstants.DATA_KEY, rotationControls);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);
        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> rotationControlsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) rotationControlsMap.get("totalCount");

        List<RotationControl> rotationControls = (List<RotationControl>) rotationControlsMap.get("data");

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , totalRecords);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR , rotationControls);

        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, rotationControls);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);
        modelMap.put(MessageConstants.ERROR_KEY, true);

        return modelMap;
    }

}
