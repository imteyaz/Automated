package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.VesselInfoDTO;
import com.cmc.dpw.minapro.admin.application.entities.Bay;
import com.cmc.dpw.minapro.admin.application.entities.BayRow;
import com.cmc.dpw.minapro.admin.application.entities.BayTier;
import com.cmc.dpw.minapro.admin.application.entities.Cell;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselSection;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Vessel DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class VesselDAO extends GenericDAO {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselDAO.class);
/**
 * This method is used to search Vessels
 * @param vesselNo
 * @param vesselCode
 * @param vesselNameVal
 * @param vesselTypeVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchVessels(String vesselNo, String vesselCode, String vesselNameVal,
            String vesselTypeVal, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Vessel DAO's searchVessels method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();
        String percentage = "%";
        String likeValue = "";

        Criteria searchCriteria = session.createCriteria(Vessel.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { vesselCode, vesselNameVal, vesselNo, vesselTypeVal };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchVessels in Vessel DAO with vesselId: {} , vesselName : {} , make : {} , model : {} , vesselTypeId : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        if (!("".equalsIgnoreCase(vesselCode)) && vesselCode != null) {
            likeValue = "";
            String vesselCodeVal = likeValue.concat(percentage).concat(vesselCode).concat(percentage);
            searchCriteria.add(Restrictions.like("vesselCode", vesselCodeVal).ignoreCase());
        }

        if (!("".equalsIgnoreCase(vesselNo)) && vesselNo != null) {
            likeValue = "";
            String vesselNoVal = likeValue.concat(percentage).concat(vesselNo).concat(percentage);
            searchCriteria.add(Restrictions.like("vesselNo", vesselNoVal).ignoreCase());
        }

        if (!("".equalsIgnoreCase(vesselNameVal)) && vesselNameVal != null) {
            likeValue = "";
            String vesselName = likeValue.concat(percentage).concat(vesselNameVal).concat(percentage);
            searchCriteria.add(Restrictions.like("vesselName", vesselName).ignoreCase());
        }

        if (!("".equalsIgnoreCase(vesselTypeVal)) && vesselTypeVal != null) {
            likeValue = "";
            String vesselType = likeValue.concat(percentage).concat(vesselTypeVal).concat(percentage);
            searchCriteria.add(Restrictions.like("vesselType", vesselType).ignoreCase());
        }

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug("******count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Vessel> searchVessels = (List<Vessel>) searchCriteria.list();
        List<VesselInfoDTO> searchVesselsDtoList =  util.map(searchVessels, VesselInfoDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug("******* data from DB: {}", searchVesselsDtoList);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchVesselsDtoList);
        resultMap.put("totalCount", totalRecords);

        for (Vessel vessel : searchVessels) {
            LOGGER.debug(" ********* vessel No  : {}", vessel.getVesselNo());
        }

        LOGGER.debug("********* exiting vesselDAO's searchVessels method ");
        return resultMap;
    }

    /**
     * This method is used to createVessel
     * @param vesselInfo
     * @param sectionList
     * @param bayList
     * @param bayRowList
     * @param bayTierList
     * @param cellList
     */
    public void createVessel(Vessel vesselInfo, List<VesselSection> sectionList, List<Bay> bayList,
            List<BayRow> bayRowList, List<BayTier> bayTierList, List<Cell> cellList) {
        
        Date currentDate = new Date();

        Vessel createdVessel = null;

        if (vesselInfo != null) {
            vesselInfo.setCreatedDateTime(currentDate);
            vesselInfo.setLastUpdatedDateTime(currentDate);

            createdVessel = (Vessel) save(vesselInfo);
        }

        Integer vesselNo = createdVessel.getVesselNo();
        LOGGER.debug("get vesselNo", vesselNo);
        if (sectionList != null) {

            for (VesselSection currentSection : sectionList) {
                currentSection.getPk().setVesselNo(vesselNo);
                currentSection.setCreatedDateTime(currentDate);
                currentSection.setLastUpdatedDateTime(currentDate);
                save(currentSection);
            }

        }

        if (bayList != null) {
            for (Bay currentBay : bayList) {
                currentBay.getPk().setVesselNo(vesselNo);
                currentBay.setCreatedDateTime(currentDate);
                currentBay.setLastUpdatedDateTime(currentDate);

                try {
                    save(currentBay);

                } catch (Exception e) {
                    LOGGER.error(MessageConstants.ERROR_INDICATOR +"VeeselDAO-->createVessel --> Exception",e);
                    LOGGER.warn(MessageConstants.WARN_INDICATOR+"Error trying to save currentBay : {}", e.getMessage());
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR +" Stacktrace : {}", e.getStackTrace());

                }
            }

        }

        if (bayRowList != null) {

            for (BayRow currentBayRow : bayRowList) {
                currentBayRow.getPk().setVesselNo(vesselNo);
                currentBayRow.setCreatedDateTime(currentDate);
                currentBayRow.setLastUpdatedDateTime(currentDate);
                save(currentBayRow);
            }
        }

        if (bayTierList != null) {
            int index = 0;
            for (BayTier currentBayTier : bayTierList) {
                currentBayTier.getPk().setVesselNo(vesselNo);
                currentBayTier.setCreatedDateTime(currentDate);
                currentBayTier.setLastUpdatedDateTime(currentDate);
                save(currentBayTier);

                Map savedBayTier = new HashMap();
                savedBayTier.put(index, currentBayTier.getPk());
                LOGGER.debug("create vessel", index);
                index++;
            }
        }

        if (cellList != null) {

            for (Cell currentCell : cellList) {
                currentCell.getPk().setVesselNo(vesselNo);
                currentCell.setCreatedDateTime(currentDate);
                currentCell.setLastUpdatedDateTime(currentDate);
                save(currentCell);
            }
        }

    }

    /**
     * This method is used to save edited vessel
     * @param vesselInfo
     * @param sectionList
     * @param bayList
     * @param bayRowList
     * @param bayTierList
     * @param cellList
     */
    public void saveEditedVessel(Vessel vesselInfo, List<VesselSection> sectionList, List<Bay> bayList,
            List<BayRow> bayRowList, List<BayTier> bayTierList, List<Cell> cellList) {
        
        Date currentDate = new Date();

        List<VesselSection> delSectionList = new ArrayList<VesselSection>();
        List<Bay> delBayList = new ArrayList<Bay>();
        List<BayRow> delBayRowList = new ArrayList<BayRow>();
        List<BayTier> delBayTierList = new ArrayList<BayTier>();
        List<Cell> delCellList = new ArrayList<Cell>();

        Vessel updatedVessel = null;

        if (vesselInfo != null) {

            updatedVessel = (Vessel) update(vesselInfo);
        }

        Integer vesselNo = updatedVessel.getVesselNo();

        if (sectionList != null && !sectionList.isEmpty()) {

            for (VesselSection currentSection : sectionList) {
                currentSection.getPk().setVesselNo(vesselNo);
                currentSection.setLastUpdatedDateTime(currentDate);

                char toBeDeleted = currentSection.getIsDeleted();

                if (toBeDeleted == 'Y') {
                    // hardDelete(currentSection); // cant delete in this order as it has got child records
                    delSectionList.add(currentSection);

                } else if (toBeDeleted == 'N') {

                    saveOrupdate(currentSection);
                }

            }

        }
        if (bayList != null && !bayList.isEmpty()) {
            int bayindex = 0;
            for (Bay currentBay : bayList) {
                currentBay.getPk().setVesselNo(vesselNo);
                currentBay.setLastUpdatedDateTime(currentDate);

                try {

                    char toBeDeleted = currentBay.getIsDeleted();

                    if (toBeDeleted == 'Y') {

                        delBayList.add(currentBay);

                    } else if (toBeDeleted == 'N') {

                        saveOrupdate(currentBay);
                    }

                    LOGGER.debug("bayindex successful : " + bayindex);
                } catch (Exception e) {
                    
                    LOGGER.error(MessageConstants.ERROR_INDICATOR +"get vessel No --> Exception",e);
                    LOGGER.warn(MessageConstants.WARN_INDICATOR+"Error trying to update currentBay : {}", e.getMessage());
                    LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"Exception Stacktrace : {}", e.getStackTrace());


                    LOGGER.debug("bayindex failed: " + bayindex);
                }
                bayindex++;
            }

        }

        if (bayRowList != null & !bayRowList.isEmpty()) {

            for (BayRow currentBayRow : bayRowList) {
                currentBayRow.getPk().setVesselNo(vesselNo);
                currentBayRow.setLastUpdatedDateTime(currentDate);

                char toBeDeleted = currentBayRow.getIsDeleted();

                if (toBeDeleted == 'Y') {

                    delBayRowList.add(currentBayRow);

                }   else if (toBeDeleted == 'N') {

                    saveOrupdate(currentBayRow);
                }

            }
        }

        if (bayTierList != null & !bayTierList.isEmpty()) {
            for (BayTier currentBayTier : bayTierList) {
                currentBayTier.getPk().setVesselNo(vesselNo);
                currentBayTier.setLastUpdatedDateTime(currentDate);

                char toBeDeleted = currentBayTier.getIsDeleted();

                if (toBeDeleted == 'Y') {

                    delBayTierList.add(currentBayTier);

                }     else if (toBeDeleted == 'N') {

                    saveOrupdate(currentBayTier);
                }

            }
        }

        if (cellList != null && !cellList.isEmpty()) {
            new HashSet<Cell>();

            for (Cell currentCell : cellList) {
                currentCell.getPk().setVesselNo(vesselNo);

                currentCell.setLastUpdatedDateTime(currentDate);
                char toBeDeleted = currentCell.getIsDeleted();

                if (toBeDeleted == 'Y') {

                    delCellList.add(currentCell);

                }   else if (toBeDeleted == 'N') {


                    saveOrupdate(currentCell);

                }

            }
        }

        // now iterating through the delLists in reverse order and deleting them

        deleteRows(delSectionList, delBayList, delBayRowList, delBayTierList, delCellList);

    }

    /**
     * This method is used to delete Rows
     * @param delSectionList
     * @param delBayList
     * @param delBayRowList
     * @param delBayTierList
     * @param delCellList
     * @return
     */
    private boolean deleteRows(List<VesselSection> delSectionList, List<Bay> delBayList, List<BayRow> delBayRowList,
            List<BayTier> delBayTierList, List<Cell> delCellList) {
        
        boolean result = false;
        
        if (delCellList != null && !delCellList.isEmpty()) {

            for (Cell currentCell : delCellList) {
                hardDelete(currentCell);
            }
        }

        if (delBayTierList != null && !delBayTierList.isEmpty()) {

            for (BayTier currentBayTier : delBayTierList) {
                hardDelete(currentBayTier);
            }
        }

        if (delBayRowList != null && !delBayRowList.isEmpty()) {

            for (BayRow currentBayRow : delBayRowList) {
                hardDelete(currentBayRow);
            }
        }

        if (delBayList != null && !delBayList.isEmpty()) {

            for (Bay currentBay : delBayList) {
                hardDelete(currentBay);
            }
        }

        if (delSectionList != null && !delSectionList.isEmpty()) {

            for (VesselSection currentSection : delSectionList) {
                hardDelete(currentSection);
            }
        }
        result = true;
        return result;

    }

    /**
     * This method is used to delete Vessel by vesselNo
     * @param vesselArray
     * @return
     */
    public boolean deleteVesselByvesselNo(String[] vesselArray) {
        
        Session session = getCurrentSession();

        if (vesselArray.length > 0) {

            for (String currentVesselId : vesselArray) {

                Integer vesselId = Integer.parseInt(currentVesselId);

                String vesselSql = "delete from Vessel where int_vsl_no = " + vesselId;

                String sectionSql = "delete from VesselSection where int_vsl_no = " + vesselId;

                String baySql = "delete from Bay where int_vsl_no = " + vesselId;

                String bayRowSql = "delete from BayRow where int_vsl_no = " + vesselId;

                String bayTierSql = "delete from BayTier where int_vsl_no = " + vesselId;

                String cellSql = "delete from Cell where int_vsl_no = " + vesselId;

                Query delVesselquery = session.createQuery(vesselSql);

                Query delSectionQuery = session.createQuery(sectionSql);

                Query delBayquery = session.createQuery(baySql);

                Query delBayRowquery = session.createQuery(bayRowSql);

                Query delBayTierquery = session.createQuery(bayTierSql);

                Query delCellquery = session.createQuery(cellSql);

                int deletedCellRows = delCellquery.executeUpdate();
                int deletedBayTierRows = delBayTierquery.executeUpdate();
                int deletedBayRowsCount = delBayRowquery.executeUpdate();
                int deletedBayRows = delBayquery.executeUpdate();
                int deletedSectionRows = delSectionQuery.executeUpdate();
                int deletedVesselRows = delVesselquery.executeUpdate();

                LOGGER.debug("deletedVesselRows : " + deletedVesselRows);
                LOGGER.debug("deletedSectionRows : " + deletedSectionRows);
                LOGGER.debug("deletedBayRows : " + deletedBayRows);
                LOGGER.debug("deletedBayRowsCount : " + deletedBayRowsCount);
                LOGGER.debug("deletedBayTierRows : " + deletedBayTierRows);
                LOGGER.debug("deletedCellRows : " + deletedCellRows);

            }
        }

        return true;

    }

    public Vessel findVesselByVesselNo(String vesselNo) {

        return (Vessel) findOne(vesselNo);

    }
    
    public List<Vessel> loadAllVessels() {

        Session session = getCurrentSession();

        Criteria fetchCriteria = session.createCriteria(Vessel.class);
        fetchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        fetchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        return (List<Vessel>) fetchCriteria.list();

    }

}
