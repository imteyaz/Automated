package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.PinningStationDAO;
import com.cmc.dpw.minapro.admin.application.dto.PinningStationDTO;
import com.cmc.dpw.minapro.admin.application.entities.PinningStation;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;

/**
 * PinningStation Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class PinningStationService {

    @Autowired
    private PinningStationDAO pinningStationDAO;
    @Autowired
    private com.cmc.dpw.minapro.admin.domain.utils.Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(PinningStationService.class);

    /**
     * This method is used to get PinningStation List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<PinningStation> getPinningStationList() {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  PinningStation service's getPinningStationList");
        pinningStationDAO.setClazz(PinningStation.class);
        return pinningStationDAO.findAll();

    }

    /**
     * This method is used to search PinningStation List
     * @return Map<String, Object>
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchPinningStationList(String pinningStationId, String terminalId,
            String availability, int start, int limit) {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStation service's searchPinningStationList method");
        pinningStationDAO.setClazz(PinningStation.class);

        String[] requestParameters = { pinningStationId, terminalId, availability };
        LOGGER.debug( MessageConstants.DEBUG_INDICATOR +
                "In PinningStation service searchPinningStations with pinningStationId: {} , terminalId : {} , availability : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStation service's searchPinningStationList method");
        return pinningStationDAO.searchPinningStations(pinningStationId, terminalId, availability, start, limit);

    }
    
    /**
     * This method is used to create PinningStation
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<PinningStation> containing created PinningStation data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_PINNINGSTATION_MASTER")
    public List<PinningStation> create(Object data, Principal principal) throws ExistingRecordException {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStation service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  pinningStation service's  create : {} ", data);
        List<PinningStation> newPinningStations = new ArrayList<PinningStation>();

        List<PinningStation> list = util.getEntitiesFromDto(data, PinningStationDTO.class,PinningStation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);
        for (PinningStation pinningStation : list) {

            Date currentDate = new Date();
            pinningStation.setCreatedDateTime(currentDate);
            pinningStation.setLastUpdatedDateTime(currentDate);
            pinningStation.setCreatedBy(userId.toString());
            pinningStation.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"PinningStation Id property in pinningStation service's create : {}",
                    pinningStation.getPinningStationId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling pinningStation DAO findOne");

            PinningStation alreadyPinningStation = pinningStationDAO.findOne(pinningStation.getPinningStationId());

            if (alreadyPinningStation == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling pinningStation DAO");
                newPinningStations.add(pinningStationDAO.create(pinningStation));
            } else {
                char isDeleted = alreadyPinningStation.getIsDeleted();

                if (isDeleted == 'Y') {
                    pinningStation.setVersion(alreadyPinningStation.getVersion());
                    pinningStation.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling pinningStation DAO update");
                    newPinningStations.add(pinningStationDAO.update(pinningStation));
                }  else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
             // end of else - entity not null
            }
         // end of for loop
        } 
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStation service's create method");
        return newPinningStations;
    }

    /**
     * This method is used to update PinningStation
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  List<PinningStation> containing updated PinningStation data
     */
    @Transactional
    @Manipulate(table = "MP_PINNINGSTATION_MASTER")
    public List<PinningStation> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStation service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  pinningStation  service's  update : {} ", data);
        List<PinningStation> returnPinningStations = new ArrayList<PinningStation>();

        List<PinningStation> updatedPinningStations = util.getEntitiesFromDto(data, PinningStationDTO.class,PinningStation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (PinningStation pinningStation : updatedPinningStations) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"pinningStationId property in pinningStation service update : {}",
                    pinningStation.getPinningStationId());
            pinningStation.setLastUpdatedDateTime(currentDate);
            pinningStation.setLastUpdatedBy(userId.toString());
            returnPinningStations.add(pinningStationDAO.update(pinningStation));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStation service's update method");
        return returnPinningStations;
    }

    /**
     * This method is used to delete PinningStation
     * @param data The json data coming from the UI 
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_PINNINGSTATION_MASTER")
    public void delete(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering PinningStation service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In pinningStation's service delete : {} ", data);

        List<PinningStation> deletedPinningStations = util.getEntitiesFromDto(data, PinningStationDTO.class,PinningStation.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (PinningStation pinningStation : deletedPinningStations) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"pinningStationId property in pinningStation service delete : {}",
                    pinningStation.getPinningStationId());
            pinningStation.setLastUpdatedDateTime(currentDate);
            pinningStation.setLastUpdatedBy(userId.toString());
            pinningStation.setIsDeleted('Y');
            pinningStationDAO.delete(pinningStation);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting PinningStation service's delete method");
    }

}
