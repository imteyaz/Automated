package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.DamageTypeDTO;
import com.cmc.dpw.minapro.admin.application.entities.DamageType;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * DamageType DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class DamageTypeDAO extends GenericDAO<DamageType> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(DamageTypeDAO.class);
/**
 * This method is used to search DamageTypes
 * @param damageTypeIdVal
 * @param damageTypeNameVal
 * @param makeVal
 * @param modelVal
 * @param damageTypeTypeIdVal
 * @param start
 * @param limit
 * @return Map<String, Object> 
 */
    public Map<String, Object> searchDamageTypes(String damageTypeIdVal, String damageTypeDescVal, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DamageType DAO's searchDamageTypes method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(DamageType.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { damageTypeIdVal, damageTypeDescVal};
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchDamageTypes in DamageType DAO with damageTypeId: {} , damageTypeName : {} , make : {} , model : {} , damageTypeTypeId : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));
        
        Util.addRestrictions(searchCriteria, "damageTypeId", damageTypeIdVal, false);
        Util.addRestrictions(searchCriteria, "damageTypeDescription", damageTypeDescVal, false);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<DamageType> searchDamageTypes = (List<DamageType>) searchCriteria.list();
        List<DamageTypeDTO> searchDamageTypesDtoList =  util.map(searchDamageTypes, DamageTypeDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"data from DB: {}", searchDamageTypesDtoList);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchDamageTypesDtoList);
        resultMap.put("totalCount", totalRecords);

        for (DamageType damageType : searchDamageTypes) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"damageType Id  : {}", damageType.getDamageTypeId());
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"exiting damageTypeDAO's searchDamageTypes method ");
        return resultMap;
    }
}
