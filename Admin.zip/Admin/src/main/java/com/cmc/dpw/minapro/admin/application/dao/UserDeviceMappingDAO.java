package com.cmc.dpw.minapro.admin.application.dao;

import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.entities.UserDeviceMapping;


/**
 * UserDeviceMappingDAO DAO class.
 * 
 */
@Repository
public class UserDeviceMappingDAO extends GenericDAO<UserDeviceMapping>{
    
}
