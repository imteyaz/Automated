package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.GenericDAO;
import com.cmc.dpw.minapro.admin.application.dao.VesselDAO;
import com.cmc.dpw.minapro.admin.application.dto.VesselDTO;
import com.cmc.dpw.minapro.admin.application.dto.VesselInfoDTO;
import com.cmc.dpw.minapro.admin.application.entities.Bay;
import com.cmc.dpw.minapro.admin.application.entities.BayRow;
import com.cmc.dpw.minapro.admin.application.entities.BayTier;
import com.cmc.dpw.minapro.admin.application.entities.Cell;
import com.cmc.dpw.minapro.admin.application.entities.Vessel;
import com.cmc.dpw.minapro.admin.application.entities.VesselSection;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Vessel Service
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class VesselService {

    @Autowired
    private VesselDAO vesselDAO;
    @Autowired
    private GenericDAO genericDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(VesselService.class);

    /**
     * This method is used to get Vessel List
     * 
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Vessel> getVesselList() {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "START-->getVesselList-->VesselService");
        vesselDAO.setClazz(Vessel.class);
        return vesselDAO.findAll();

    }

    /**
     * This method is used to search Vessel List
     * 
     * @return Map<String, Object> containing the search Vessel data and success indicator or the error message and
     *         failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchVesselList(String vesselNo, String vesselCode, String vesselName,
            String vesselType, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "START-->searchVesselList-->VesselService");
        vesselDAO.setClazz(Vessel.class);

        String[] requestParameters = { vesselNo, vesselCode, vesselName, vesselType };
        LOGGER.debug(MessageConstants.INFO_INDICATOR + "START-->VesselService()", requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting-->searchVesselList-->VesselService");

        return vesselDAO.searchVessels(vesselNo, vesselCode, vesselName, vesselType, start, limit);
    }

    /**
     * This method is used to create Vessel
     * 
     * @param data
     *            The json data coming from the UI
     * @param principal
     *            The java.security.Principal containing logged in user details
     * @return List<Vessel> containing created Vessel data
     * @throws ExistingRecordException
     */
    @Transactional
    public List<Vessel> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR + "START-->VesselService--> create");
        LOGGER.debug(MessageConstants.INFO_INDICATOR + "Data", data);

        List<Vessel> newVessels = new ArrayList<Vessel>();
        List<Vessel> list = util.getEntitiesFromDto(data, VesselInfoDTO.class, Vessel.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Vessel vessel : list) {

            Date currentDate = new Date();
            vessel.setCreatedDateTime(currentDate);
            vessel.setLastUpdatedDateTime(currentDate);
            vessel.setCreatedBy(userId.toString());
            vessel.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.INFO_INDICATOR + "CURRENT VesselNo", vessel.getVesselNo());

            Vessel alreadyVessel = (Vessel) vesselDAO.findOne(vessel.getVesselNo());

            if (alreadyVessel == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR
                        + "No existing vessel found with same vesselno; hnece creating new vessel");
                newVessels.add((Vessel) vesselDAO.create(vessel));
            } else {

                char isDeleted = alreadyVessel.getIsDeleted();

                if (isDeleted == 'Y') {
                    vessel.setVersion(alreadyVessel.getVersion());
                    vessel.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR + "updating already existing vessel for vessel no :{}",
                            vessel.getVesselNo());
                    newVessels.add((Vessel) vesselDAO.update(vessel));
                } else {
                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }

                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting-->create-->VesselService");
        return newVessels;
    }

    /**
     * This method is used to update Vessel
     * 
     * @param data
     *            The json data coming from the UI
     * @param principal
     *            The java.security.Principal containing logged in user details
     * @return List<Vessel> containing updated Vessel data
     */
    @Transactional
    public List<Vessel> update(Object data, Principal principal) {
        /**
         * This method is used to update Vessel
         * 
         * @param data
         *            The json data coming from the UI
         * @return returnVessels
         */
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Start-->update-->VesselService");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "Data", data);
        List<Vessel> returnVessels = new ArrayList<Vessel>();

        List<Vessel> updatedVessels = util.getEntitiesFromDto(data, VesselInfoDTO.class, Vessel.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Vessel vessel : updatedVessels) {

            Date currentDate = new Date();
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "current vessel no being sent for update",
                    vessel.getVesselNo());
            vessel.setLastUpdatedDateTime(currentDate);
            vessel.setLastUpdatedBy(userId.toString());
            returnVessels.add((Vessel) vesselDAO.update(vessel));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting-->update-->VesselService");
        return returnVessels;
    }

    /**
     * This method is used to delete Vessel
     * 
     * @param data
     *            The json data coming from the UI
     */
    @Transactional
    public void delete(Object data, Principal principal) {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Start-->delete-->VesselService");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "Data", data);

        List<Vessel> deletedVessels = util.getEntitiesFromDto(data, VesselInfoDTO.class, Vessel.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Vessel vessel : deletedVessels) {
            Date currentDate = new Date();
            LOGGER.debug("***********Vessel no property in vessel service delete : {}", vessel.getVesselNo());
            vessel.setLastUpdatedDateTime(currentDate);
            vessel.setLastUpdatedBy(userId.toString());
            vessel.setIsDeleted('Y');
            vesselDAO.delete(vessel);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR + "Exiting-->delete-->VesselService");
    }

    @Transactional
    public void createVessel(Vessel vesselInfo, List<VesselSection> sectionList, List<Bay> bayList,
            List<BayRow> bayRowList, List<BayTier> bayTierList, List<Cell> cellList) {

        vesselDAO.createVessel(vesselInfo, sectionList, bayList, bayRowList, bayTierList, cellList);
    }

    @Transactional
    public void saveEditedVessel(Vessel vesselInfo, List<VesselSection> sectionList, List<Bay> bayList,
            List<BayRow> bayRowList, List<BayTier> bayTierList, List<Cell> cellList) {

        vesselDAO.saveEditedVessel(vesselInfo, sectionList, bayList, bayRowList, bayTierList, cellList);
    }

    @Transactional
    public void deleteVesselByvesselNo(String[] vesselArray) {
        vesselDAO.deleteVesselByvesselNo(vesselArray);

    }

    /**
     * 
     * @param vesselNo
     * @return VesselDTO
     */
    @SuppressWarnings("unchecked")
    @Transactional
    public VesselDTO editVessel(String vesselNo) {
        VesselDTO vDto = new VesselDTO();

        Integer intVesselNo = Integer.parseInt(vesselNo);

        Vessel editVessel = (Vessel) vesselDAO.findOne(intVesselNo);

        List<VesselSection> section = (List<VesselSection>) genericDAO.findByPropertyValue(VesselSection.class,
                MessageConstants.PK_VESSELNO, intVesselNo, false);

        List<Bay> bay = (List<Bay>) genericDAO.findByPropertyValue(Bay.class, MessageConstants.PK_VESSELNO,
                intVesselNo, false);

        List<BayRow> bayRow = (List<BayRow>) genericDAO.findByPropertyValue(BayRow.class, MessageConstants.PK_VESSELNO,
                intVesselNo, false);

        List<BayTier> bayTier = (List<BayTier>) genericDAO.findByPropertyValue(BayTier.class,
                MessageConstants.PK_VESSELNO, intVesselNo, false);

        List<Cell> cell = (List<Cell>) genericDAO.findByPropertyValue(Cell.class, MessageConstants.PK_VESSELNO,
                intVesselNo, false);

        vDto.setVesselInfo(editVessel);
        vDto.setSectionList(section);
        vDto.setBayList(bay);
        vDto.setBayRowList(bayRow);
        vDto.setBayTierList(bayTier);
        vDto.setCellList(cell);

        return vDto;

    }

    /**
     * This method is used to validate vessel no
     * 
     * @param vesselNo
     * @return Map<String, Object>
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Map<String, Object> validateVesselNo(String vesselNo) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        List<Vessel> duplicateRotationVessels = genericDAO.findByPropertyValue(Vessel.class, "vesselCode", vesselNo,
                true);

        if (duplicateRotationVessels != null && !duplicateRotationVessels.isEmpty()) {
            modelMap.put(MessageConstants.SUCCESS_KEY, false);
            modelMap.put("mssg", MessageConstants.EXISTING_ROTATIONID_ERROR_MESSAGE);
        } else {
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
        }
        return modelMap;
    }

    /**
     * This method is used to validate vessel name
     * 
     * @param vesselNameVal
     * @return modelMap
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Map<String, Object> validateVesselName(String vesselNameVal) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        List<Vessel> duplicateVesselNameList = genericDAO.findByPropertyValue(Vessel.class, "vesselName",
                vesselNameVal, true);

        if (duplicateVesselNameList != null && !duplicateVesselNameList.isEmpty()) {
            modelMap.put(MessageConstants.SUCCESS_KEY, false);
            modelMap.put("mssg", MessageConstants.EXISTING_VESSELNAME_ERROR_MESSAGE);
        } else {
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
        }
        return modelMap;
    }

    @Transactional(readOnly = true)
    public List<Vessel> loadVesselCache() {
        vesselDAO.setClazz(Vessel.class);
        return vesselDAO.loadAllVessels();

    }
    
    @Transactional(readOnly = true)
    public Vessel fineOne(Integer vslNo) {
        vesselDAO.setClazz(Vessel.class);
        return (Vessel) vesselDAO.findOne(vslNo);

    }
    

}
