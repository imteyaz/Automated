package com.cmc.dpw.minapro.admin.application.entities.pks;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UserGroupId implements Serializable {

    private int intUserId;
    private int intUserGroupId;
    
    public UserGroupId() {
    }

    @Column(name = "INT_USER_ID")
    public int getIntUserId() {
        return intUserId;
    }

    public void setIntUserId(int intUserId) {
        this.intUserId = intUserId;
    }

    @Column(name = "INT_USER_GRP_ID")
    public int getIntUserGroupId() {
        return intUserGroupId;
    }

    public void setIntUserGroupId(int intUserGroupId) {
        this.intUserGroupId = intUserGroupId;
    }
}
