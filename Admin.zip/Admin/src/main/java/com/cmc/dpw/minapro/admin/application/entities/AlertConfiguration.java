package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
/**
 * AlertConfiguration POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Entity(name = "AlertConfiguration")
@Table(name = "MP_ALERT_CONFIGURATION_MASTER")
public class AlertConfiguration implements Serializable {
   
    private static final long serialVersionUID = 1L;
    private String alertCode;
    private String alertText;
    private String description;
    private char severity;
    private char soundRequired;
    private String subscribers;
    private String keys;
    private String expiryTime ;
    private List<AlertGroupAssociation> alertsubscribersMap = new ArrayList<AlertGroupAssociation>();
    private Collection<AlertParameterAssociation> alertKeysMap = new ArrayList<AlertParameterAssociation>();
     
    @OneToMany(fetch=FetchType.EAGER)
    @JoinColumn(name = "ALERT_CODE", referencedColumnName = "ALERT_CODE",insertable = false, updatable = false)
    public List<AlertGroupAssociation> getAlertsubscribersMap() {
        return alertsubscribersMap;
    }
    public void setAlertsubscribersMap(List<AlertGroupAssociation> alertsubscribersMap) {
        this.alertsubscribersMap = alertsubscribersMap;
    }
    
   
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "ALERT_CODE", referencedColumnName = "ALERT_CODE", insertable = false, updatable = false)
    @LazyCollection(LazyCollectionOption.FALSE)
    public Collection<AlertParameterAssociation> getAlertKeysMap() {
        
        return alertKeysMap;
    }
    public void setAlertKeysMap(Collection<AlertParameterAssociation> alertKeysMap) {
        this.alertKeysMap = alertKeysMap;
    }
    
    @Id
    @Column(name = "ALERT_CODE", nullable = false)
    public String getAlertCode() {
        return alertCode;
    }
   
    public void setAlertCode(String alertCode) {
        this.alertCode = alertCode;
    }
    
    @Column(name = "ALERT_TEXT", nullable = false)
    public String getAlertText() {
        return alertText;
    }
    public void setAlertText(String alertText) {
        this.alertText = alertText;
    }
    
    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    
    @Column(name = "SEVERITY", nullable = false)
    public char getSeverity() {
        return severity;
    }
    public void setSeverity(char severity) {
        this.severity = severity;
    }
    
    @Column(name = "SOUND_REQUIRED", nullable = false)
    public char getSoundRequired() {
        return soundRequired;
    }
    public void setSoundRequired(char soundRequired) {
        this.soundRequired = soundRequired;
    }
    
    @Transient
    public String getSubscribers() {
        return subscribers;
    }
    
    public void setSubscribers(String subscribers) {
        this.subscribers = subscribers;
    }
    
    @Transient
    public String getKeys() {
        return keys;
    }
    public void setKeys(String keys) {
        this.keys = keys;
    }
    
    @Column(name = "EXPIRY_TIME")
    public String getExpiryTime() {
        return expiryTime;
    }
    public void setExpiryTime(String expiryTime) {
        this.expiryTime = expiryTime;
    }
    
    
}
