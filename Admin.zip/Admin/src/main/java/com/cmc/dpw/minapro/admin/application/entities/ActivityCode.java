package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ActivityCode POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "ActivityCode")
@Table(name = "MP_ACTIVITY_MASTER")
public class ActivityCode extends Audit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String activityId;
    private String description;
    private String activityTypeId;
    private String terminalId;

    @Id
    @Column(name = "ACTIVITY_ID", nullable = false)
    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "ACTIVITY_TYPE_ID", nullable = false)
    public String getActivityTypeId() {
        return activityTypeId;
    }

    public void setActivityTypeId(String activityTypeId) {
        this.activityTypeId = activityTypeId;
    }

    @Column(name = "TERMINAL_ID", nullable = false)
    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }


}
