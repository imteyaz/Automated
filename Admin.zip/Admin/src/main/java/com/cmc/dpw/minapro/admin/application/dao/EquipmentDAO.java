package com.cmc.dpw.minapro.admin.application.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.EquipmentDTO;
import com.cmc.dpw.minapro.admin.application.entities.Equipment;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Equipment DAO class.
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class EquipmentDAO extends GenericDAO<Equipment> {

    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(EquipmentDAO.class);

    /**
     * This method is used to search Equipments
     * 
     * @param equipmentIdVal
     * @param equipmentNameVal
     * @param makeVal
     * @param modelVal
     * @param equipmentTypeIdVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchEquipments(String equipmentIdVal, String equipmentNameVal, String makeVal,
            String modelVal, String equipmentTypeIdVal, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR + "Entering Equipment DAO's searchEquipments method");

        Map<String, Object> resultMap = new HashMap<String, Object>();

        Session session = getCurrentSession();

        Criteria searchCriteria = session.createCriteria(Equipment.class);
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String[] searchParameters = { equipmentIdVal, equipmentNameVal, makeVal, modelVal, equipmentTypeIdVal };
        LOGGER.debug(
                MessageConstants.DEBUG_INDICATOR
                        + "Processing searchEquipments in Equipment DAO with equipmentId: {} , equipmentName : {} , make : {} , model : {} , equipmentTypeId : {} ",
                searchParameters);

        searchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        Util.addRestrictions(searchCriteria, "equipmentId", equipmentIdVal, false);
        Util.addRestrictions(searchCriteria, "make", makeVal, false);
        Util.addRestrictions(searchCriteria, "model", modelVal, false);
        Util.addRestrictions(searchCriteria, "equipmentName", equipmentNameVal, false);
        Util.addRestrictions(searchCriteria, "equipmentTypeId", equipmentTypeIdVal, false);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "count of records matched with given search criteria : {}",
                count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<Equipment> searchEquipments = (List<Equipment>) searchCriteria.list();
        List<EquipmentDTO> searchEquipmentsDtoList = util.map(searchEquipments, EquipmentDTO.class);
        String totalRecords = count.toString();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "data from DB: {}", searchEquipmentsDtoList);
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR
                + "total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", searchEquipmentsDtoList);
        resultMap.put("totalCount", totalRecords);

        for (Equipment equipment : searchEquipments) {

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "equipment Id  : {}", equipment.getEquipmentId());
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR + "exiting equipmentDAO's searchEquipments method ");
        return resultMap;
    }

    public List<Equipment> loadAllEquipments() {

        Session session = getCurrentSession();

        Criteria fetchCriteria = session.createCriteria(Equipment.class);
        fetchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);
        fetchCriteria.add(Restrictions.eq("isDeleted", 'N'));

        return (List<Equipment>) fetchCriteria.list();

    }
}
