package com.cmc.dpw.minapro.admin.web.controllers;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.application.services.RollbackRotationService;
import com.cmc.dpw.minapro.admin.application.services.UserMonitoringService;
import com.cmc.dpw.minapro.admin.domain.utils.QueueUtil;
import com.minapro.procserver.events.common.LogoutEvent;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/userMonitoring")
public class UserMonitoringController {

    @Autowired
    private UserMonitoringService userMonitoringService;
    private static final Logger LOGGER = LoggerFactory.getLogger(UserMonitoringController.class);
    /**
     * This method searches for all the userMonitorings matching the search criteria
     * as entered by the end userMonitoring
     * @param userName
     * @param equipmentId
     * @param accountStatus
     * @param deviceId
     * @param loginStatus
     * @param roles
     * @param limit
     * @param start
     * @return Map<String, Object> containing the data and success indicator.
     */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String userId,
            @RequestParam(required = false) String userName, @RequestParam(required = false) String deviceId,
            @RequestParam(required = false) String equipmentId, @RequestParam(required = false) String loginStatus,
            @RequestParam(required = false) String accountStatus, @RequestParam(required = false) String roles,
            @RequestParam(required = false) int limit, @RequestParam(required = false) int start) {
       

        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start UserMonitoringController Search UserMonitoring method");
        String[] requestParameters = { userName, deviceId, equipmentId };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Inside UserMonitoring Controller's searchUserMonitorings with userMonitoringName: {} , firstName : {}, lastName : {} ",
                requestParameters);

        try {
            Map<String, Object> userMonitoringsMap = userMonitoringService.searchUserMonitoringList(userId, userName, deviceId, equipmentId,
                    loginStatus, accountStatus, roles, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting UserMonitoringController Search UserMonitoring method");
            return getMap(userMonitoringsMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +" Generic Exception-->Search", e);
            return getModelMapError("Error retrieving UserMonitorings from database.");
        }
    }

   

    /**
     *Generates modelMap to return in the modelAndView
     *@param get roles
     *@return Map<String, Object> modelMap
     */
    @RequestMapping(value = "/getRoles")
    @ResponseBody public
    Map<String, Object> getRoles() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start UserMonitoringController getRoles UserMonitoring method");

        try {

            Map<String, Object> resultMap = userMonitoringService.getRoles();
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiitng UserMonitoringController getRoles UserMonitoring method");
            return resultMap;

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->getRoles", e);
            return getModelMapError("Error trying to fetch roles");
        }
    }
    
    /**
     * This method is used to logout forcibly
     * @param userMonitoringName
     * @return  Map<String, Object> 
     */
    @RequestMapping(value = "/forceLogout")
    @ResponseBody public
    Map<String, Object> logoutUserForcibly (String userNames) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start UserMonitoringController logoutUserMonitoringForcibly UserMonitoring method");
        
        String[] userNameArray = userNames.split(",");
        
        int exceptionsCount =0;
        for(String currentUserName : userNameArray){
            LogoutEvent logoutEvent = new LogoutEvent();
            logoutEvent.setUserID(currentUserName);
            Date currentDate = new Date();
            logoutEvent.setTimeStamp(currentDate.toString());
            
            try {
                QueueUtil.publishToQueues("ADMIN_NOTIF", logoutEvent);
                

            } catch (Exception e) {
                exceptionsCount++ ;
                LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->logoutUserForcibly" + currentUserName, e);
                return getModelMapError("Error trying to logout User forcibly : " + e.getMessage());
            }
        }
        Map<String, Object> resultMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        resultMap.put(MessageConstants.SUCCESS_KEY, true);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiitng UserMonitoringController logoutUserForcibly method");
       
        if(exceptionsCount>0){
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"logoutUserForcibly --> exceptionsCount" + exceptionsCount);
            
        }
        return resultMap;
        
    }

  
    private Map<String, Object> getMap(Map<String, Object> userMonitoringsMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) userMonitoringsMap.get("totalCount");

        List<User> userMonitorings = (List<User>) userMonitoringsMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", userMonitorings);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, userMonitorings);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.ERROR_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }
    //tariq
   
   
    @RequestMapping(value = "/clearcacheforceLogout", method = RequestMethod.POST)
    @ResponseBody public
    Map<String, Object> ClearCacheforcelogout() {
   // Map<String, Object> ClearCacheforcelogout(String rotation) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->UserMonitoringController--> ClearCacheforcelogout() ");

            modelMap= userMonitoringService.ClearCacheforcelogout();
            modelMap.put(MessageConstants.SUCCESS_KEY, true);  
            modelMap.put("deletedcount", modelMap.get("deletedcount"));

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->UserMonitoringController--> ClearCacheforcelogout() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.FAILURE_STATUS);
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"UserMonitoringController-->Exception block-->", e);
        }
        return modelMap;

    }
   
}
