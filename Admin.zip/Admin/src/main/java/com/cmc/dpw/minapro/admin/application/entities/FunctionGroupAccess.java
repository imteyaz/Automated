package com.cmc.dpw.minapro.admin.application.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.cmc.dpw.minapro.admin.application.entities.pks.FunctionGroupId;


/**
 * FunctionGroupAccess POJO
 * @author Imran Rawani
 * @since 2014-Dec
 */

@Entity(name = "FunctionGroupAccess")
@Table(name = "MP_FUNCTIONGRPACCESS_A")
public class FunctionGroupAccess implements Serializable {

    private static final long serialVersionUID = 1L;
    private FunctionGroupId functionGroupId;
    private Integer accessCode;
    private String adtInsFunctionCd;
    private String adtUpdFunctionCd;
    private String createdBy;
    private String lastUpdatedBy;
    private Date createdDateTime;
    private Date lastUpdatedDateTime;

    @EmbeddedId
    public FunctionGroupId getFunctionGroupId() {
        return functionGroupId;
    }

    public void setFunctionGroupId(FunctionGroupId functionGroupId) {
        this.functionGroupId = functionGroupId;
    }

    @Column(name = "MENU_CD")
    public Integer getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(Integer accessCode) {
        this.accessCode = accessCode;
    }

    @Column(name = "ADT_INS_FUNCTION_CD")
    public String getAdtInsFunctionCd() {
        return adtInsFunctionCd;
    }

    public void setAdtInsFunctionCd(String adtInsFunctionCd) {
        this.adtInsFunctionCd = adtInsFunctionCd;
    }

    @Column(name = "ADT_UPD_FUNCTION_CD")
    public String getAdtUpdFunctionCd() {
        return adtUpdFunctionCd;
    }

    public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
        this.adtUpdFunctionCd = adtUpdFunctionCd;
    }

    @Column(name = "ADT_INS_USER_NM")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Column(name = "ADT_UPD_USER_NM")
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    @Column(name = "ADT_INS_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    @Column(name = "ADT_UPD_DTTM")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

}
