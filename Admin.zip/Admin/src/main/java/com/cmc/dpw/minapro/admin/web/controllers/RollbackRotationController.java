package com.cmc.dpw.minapro.admin.web.controllers;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.services.RollbackRotationService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/RollbackRotation")
public class RollbackRotationController {

    @Autowired
    private RollbackRotationService rollbackrotationService;
    private static final Logger LOGGER = LoggerFactory.getLogger(RollbackRotationController.class);

    @RequestMapping(value = "/processRollback", method = RequestMethod.GET)
    @ResponseBody public
    Map<String, Object> rollbackRotation(String rotation) {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"START-->RollbackRotationController--> rollbackRotation() ");

            modelMap= rollbackrotationService.rollbackRotation(rotation);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);  
             modelMap.put("deletedcount", modelMap.get("deletedcount"));

            LOGGER.info(MessageConstants.INFO_INDICATOR +"END-->RollbackRotationController--> rollbackRotation() ");
        } catch (Exception e) {
            modelMap.put(MessageConstants.STATUS_KEY, MessageConstants.FAILURE_STATUS);
            modelMap.put(MessageConstants.ERROR_KEY, e.getMessage());

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"rollbackRotation-->Exception block-->", e);
        }
        return modelMap;

    }

   
}
