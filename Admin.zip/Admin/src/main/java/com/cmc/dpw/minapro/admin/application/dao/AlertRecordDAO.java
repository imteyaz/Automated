package com.cmc.dpw.minapro.admin.application.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.AlertRecordDTO;
import com.cmc.dpw.minapro.admin.application.entities.AlertRecord;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * AlertRecord DAO class.
 * @author Imran Rawani
 * @since 2014-Dec
 */
@Repository
public class AlertRecordDAO extends GenericDAO<AlertRecord> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlertRecordDAO.class);
    @Autowired
    private Util util;
    /**
     * This method is used to search Alert Records
     * @param Map<String,Object> columnValuePairs
     * @return Map<String, Object> 
     */
    public Map<String, Object> searchAlertRecords(Map<String,Object> columnValuePairs,Date parsedFromDateVal,Date parsedToDateVal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering AlertRecord DAO's searchAlertRecords method");

        Map<String, Object> resultMap = new HashMap<String, Object>();
        
        
        String alertCode = (String) columnValuePairs.get("alertCode");
        String alertText = (String) columnValuePairs.get("alertText");
        String status = (String) columnValuePairs.get("status");
        String raisedBy = (String) columnValuePairs.get("raisedBy");
        String limitVal = (String) columnValuePairs.get("limit");
        String startVal = (String) columnValuePairs.get("start");
        

        Session session = getCurrentSession();
        String likeValue = "";
        int i = 0;

        Criteria searchCriteria = session.createCriteria(AlertRecord.class, "alertRecord");
        searchCriteria.setResultTransformer(Criteria.ROOT_ENTITY);

        String parsedFromDate = "";
        if (parsedFromDateVal != null) {
            parsedFromDate = parsedFromDateVal.toString();
        }
        
        
        String[] searchParameters = { alertCode, alertText, status, raisedBy, parsedFromDate };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +
                "Processing searchAlertRecords in AlertRecord DAO with alertCode: {} , alertText : {} , status : {} , raisedBy : {} ,raisedFromDate : {} ",
                searchParameters);

        searchCriteria.addOrder(Order.desc(MessageConstants.RAISEDDATE));
       
        i =  Util.addRestrictions(searchCriteria, "alertCode", alertCode, false,i);
        i =  Util.addRestrictions(searchCriteria, "alertText", alertText, false,i);
        i =  Util.addRestrictions(searchCriteria, "status", status, false,i);
        i =  Util.addRestrictions(searchCriteria, "raisedBy", raisedBy, false,i);

        if (parsedFromDateVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.ge(MessageConstants.RAISEDDATE, parsedFromDateVal));
            i++;
        }

        if (parsedToDateVal != null) {
            likeValue = "";
            searchCriteria.add(Restrictions.le(MessageConstants.RAISEDDATE, parsedToDateVal));
            i++;
        }
       Integer start =  Integer.parseInt(startVal) ;
       Integer limit =  Integer.parseInt(limitVal) ;
        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+"count of records matched with given search criteria : {}", count);

        searchCriteria.setProjection(null);

        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);
        searchCriteria.addOrder(Order.desc("raisedDateTime")) ;

        List<AlertRecord> searchAlertRecords = null;

        if (i == 0) {
            Query query = session
                    .createQuery("select distinct r from AlertRecord r order by r.raisedDateTime desc");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<AlertRecord> alertRecordList = query.list();

            LOGGER.debug("currentAlertRecord using HQL");

            for (AlertRecord currentAlertRecord : alertRecordList) {

                LOGGER.debug("currentAlertRecord :" + currentAlertRecord.getAlertRecordId()  );

            }
            searchAlertRecords = alertRecordList;
        } else {

            searchAlertRecords = (List<AlertRecord>) searchCriteria.list(); 
            LOGGER.debug("######Criteria executing#############");
        }

        String totalRecords = count.toString();
        List<AlertRecordDTO> alertRecordsDtoList =  util.map(searchAlertRecords, AlertRecordDTO.class);


        LOGGER.debug("******* data from DB: {}", searchAlertRecords);
        LOGGER.debug("******* total count of records matched with given search criteria  : {}", totalRecords);

        resultMap.put("data", alertRecordsDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" Searching Alert Records..following records found : ");

        for (AlertRecord currentAlertRecord : searchAlertRecords) {

            currentAlertRecord.getAlertRecordId();

            LOGGER.debug("###################");
         
        }

        LOGGER.debug(MessageConstants.DEBUG_INDICATOR+" exiting alertRecordDAO's searchAlertRecords method ");
        return resultMap;
    }
  
   
   

    
}


