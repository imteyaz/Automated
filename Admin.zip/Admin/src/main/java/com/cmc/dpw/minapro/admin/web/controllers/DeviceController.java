package com.cmc.dpw.minapro.admin.web.controllers;

import java.security.Principal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.entities.Device;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.application.exceptions.InvalidValueException;
import com.cmc.dpw.minapro.admin.application.services.DeviceService;

/**
 * Controller - Spring
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Controller
@RequestMapping(value = "/device")
public class DeviceController {

    @Autowired
    private DeviceService deviceService;
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceController.class);
/**
 * This method searches for all the device matching the search criteria
 * as entered by the end user
 * @param deviceId
 * @param ipAddress
 * @param equipmentId
 * @param make
 * @param model
 * @param limit
 * @param start
 * @return Map<String, Object> containing the data and success indicator.
 */
    @RequestMapping(value = "/view.action")
    @ResponseBody public
    Map<String, Object> view(@RequestParam(required = false) String deviceId,
            @RequestParam(required = false) String ipAddress, @RequestParam(required = false) String equipmentId,
            @RequestParam(required = false) String make, @RequestParam(required = false) String model,
            @RequestParam(required = false) int limit, @RequestParam(required = false) int start) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DeviceController Seacrh Device method");

        String[] requestParameters = { deviceId, ipAddress, equipmentId, make, model };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"DeviceController-->Seacrh deviceId:{},ipAddress:{}, equipmentId:{},make:{},model:{}",
                requestParameters);

        try {
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering DeviceController Seacrh Device method");

            Map<String, Object> devicesMap = deviceService.searchDeviceList(deviceId, ipAddress, equipmentId, make,
                    model, start, limit);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DeviceController Seacrh Device method");
            return getMap(devicesMap);

        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DeviceController-->Seacrh Device-->Catch Block :{}", e);
            return getModelMapError("Error retrieving Devices from database.");
        }
    }

    /**
     * This method creates the device as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the created user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/create.action")
    @ResponseBody public
    Map<String, Object> create(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DeviceController Create Device method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<Device> devices = deviceService.create(data, principal);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DeviceController Create Device method");
            return getMap(devices);

        } catch (DataIntegrityViolationException e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"DataIntegrityViolationException", e);
            SQLException cause = (SQLException) e.getRootCause();
            return getModelMapError("Error trying to create device due to following exception :{}" + cause.getMessage());
            
        }catch (ExistingRecordException e){
            
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"ExistingRecordException", e);
            return getModelMapError("Error trying to create device :{}" + e.getCustomErrorMessage());
            
        }catch (Exception e) {
            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Create", e);
            return getModelMapError("Error trying to create device.");
        }
    }

    /**
     * This method updates the device as entered by the end user.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the updated user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/update.action")
    @ResponseBody public
    Map<String, Object> update(@RequestBody Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DeviceController Update Device method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            List<Device> devices = deviceService.update(data, principal);

            return getMap(devices);

        }catch (InvalidValueException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"-->update-->InvalidValueException", e);
            return getModelMapError("Error trying to update device :" + e.getCustomErrorMessage());
            
        }catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Update", e);
            return getModelMapError("Error trying to update device. ");
        }
    }

    /**
     * This method deletes the device.
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return  Map<String, Object> containing the deleted user data and success indicator or
     * the error message and failure indicator.
     */ 
    @RequestMapping(value = "/delete.action")
    @ResponseBody public
    Map<String, Object> delete(@RequestBody Object data, Principal principal)  {
       
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Start DeviceController Delete Device method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +  MessageConstants.DATA_LOGGER, data);
        try {

            deviceService.delete(data, principal);

            Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
            modelMap.put(MessageConstants.SUCCESS_KEY, true);
            LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting DeviceController Delete Device method");
            return modelMap;

        }catch (InvalidValueException e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"-->delete-->InvalidValueException", e);
            return getModelMapError("Error trying to delete device :" + e.getCustomErrorMessage());
            
        } catch (Exception e) {

            LOGGER.error(MessageConstants.ERROR_INDICATOR +"Generic Exception-->Delete", e);
            return getModelMapError("Error trying to delete device.");
        }
    }

    /**
     * Generates modelMap to return in the modelAndView
     * 
     * @param contacts
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getMap(List<Device> devices) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);

        modelMap.put(MessageConstants.DATA_KEY, devices);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    private Map<String, Object> getMap(Map<String, Object> devicesMap) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        String totalRecords = (String) devicesMap.get("totalCount");

        List<Device> devices = (List<Device>) devicesMap.get("data");

        LOGGER.debug("***********totalRecords : {}", totalRecords);
        LOGGER.debug("***********data : {}", devices);
        modelMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);
        modelMap.put(MessageConstants.DATA_KEY, devices);
        modelMap.put(MessageConstants.SUCCESS_KEY, true);

        return modelMap;
    }

    /**
     * Generates modelMap to return in the modelAndView in case of exception
     * 
     * @param msg
     *           
     * @return Map<String, Object> modelMap
     */
    private Map<String, Object> getModelMapError(String msg) {

        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_TWO);
        modelMap.put(MessageConstants.MESSAGE_KEY, msg);
        modelMap.put(MessageConstants.SUCCESS_KEY, false);

        return modelMap;
    }

}
