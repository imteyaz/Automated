package com.cmc.dpw.minapro.admin.application.interfaces;

import java.util.List;

import com.cmc.dpw.minapro.admin.application.entities.Equipment;

public interface IEquipmentDAO {

    public List<Equipment> getEquipments();

    public void deleteEquipment(int id);

    public Equipment saveEquipment(Equipment equipment);

}
