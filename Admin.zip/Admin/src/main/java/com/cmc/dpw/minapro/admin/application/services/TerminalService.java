package com.cmc.dpw.minapro.admin.application.services;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dao.TerminalDAO;
import com.cmc.dpw.minapro.admin.application.dto.TerminalDTO;
import com.cmc.dpw.minapro.admin.application.entities.Terminal;
import com.cmc.dpw.minapro.admin.application.exceptions.ExistingRecordException;
import com.cmc.dpw.minapro.admin.domain.utils.Manipulate;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * Terminal Service
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Service
public class TerminalService {

    @Autowired
    private TerminalDAO terminalDAO;
    @Autowired
    private Util util;
    private static final Logger LOGGER = LoggerFactory.getLogger(TerminalService.class);

    /**
     * This method is used to get Terminal List
     * @return List<T>
     */
    @Transactional(readOnly = true)
    public List<Terminal> getTerminalList() {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering  Terminal service's getTerminalList");
        terminalDAO.setClazz(Terminal.class);
        return terminalDAO.findAll();
    }

    /**
     * This method is used to search Terminal List
     * @return Map<String, Object> containing the search Terminal data and success indicator or
     * the error message and failure indicator.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> searchTerminalList(String terminalId, String description, int start, int limit) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Terminal service's searchTerminalList method");
        terminalDAO.setClazz(Terminal.class);

        String[] requestParameters = { terminalId, description };
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In Terminal service searchActivityCodeswith terminalId: {} , description : {}",
                requestParameters);
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Terminal service's searchTerminalList method");
        return terminalDAO.searchTerminals(terminalId, description, start, limit);

    }

    /**
     * This method is used to create Terminal
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Terminal> containing created Terminal data
     * @throws ExistingRecordException
     */
    @Transactional
    @Manipulate(table = "MP_TERMINAL_MASTER")
    public List<Terminal> create(Object data, Principal principal) throws ExistingRecordException {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Terminal service's create method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  terminal service's  create : {} ", data);

        List<Terminal> newTerminals = new ArrayList<Terminal>();
        List<Terminal> list = util.getEntitiesFromDto(data, TerminalDTO.class,Terminal.class);

        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Terminal terminal : list) {

            Date currentDate = new Date();

            terminal.setCreatedDateTime(currentDate);
            terminal.setLastUpdatedDateTime(currentDate);
            terminal.setCreatedBy(userId.toString());
            terminal.setLastUpdatedBy(userId.toString());
            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"terminalId property in terminal service create : {}", terminal.getTerminalId());
            LOGGER.info(MessageConstants.INFO_INDICATOR +"caling terminal DAO findOne");

            Terminal alreadyTerminal = terminalDAO.findOne(terminal.getTerminalId());

            if (alreadyTerminal == null) {
                LOGGER.info(MessageConstants.INFO_INDICATOR +"caling terminal DAO create");
                newTerminals.add(terminalDAO.create(terminal));
            } else {

                char isDeleted = alreadyTerminal.getIsDeleted();

                if (isDeleted == 'Y') {
                    terminal.setVersion(alreadyTerminal.getVersion());
                    terminal.setIsDeleted('N');
                    LOGGER.info(MessageConstants.INFO_INDICATOR +"caling terminal DAO update");
                    newTerminals.add(terminalDAO.update(terminal));
                } else {

                    throw new ExistingRecordException(MessageConstants.EXISTING_RECORD_EXCEPTION_MESSAGE);
                }
                // end of else - entity not null
            }
            // end of for loop
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Terminal service's create method");
        return newTerminals;
    }

    /**
     * This method is used to update Terminal
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     * @return List<Terminal> containing updated Terminal data
     */
    @Transactional
    @Manipulate(table = "MP_TERMINAL_MASTER")
    public List<Terminal> update(Object data, Principal principal) {
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Terminal service's update method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In  terminal  service's  update : {} ", data);

        List<Terminal> returnTerminals = new ArrayList<Terminal>();

        List<Terminal> updatedTerminals = util.getEntitiesFromDto(data, TerminalDTO.class,Terminal.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Terminal terminal : updatedTerminals) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"terminalId property in terminal service update : {}", terminal.getTerminalId());
            terminal.setLastUpdatedDateTime(currentDate);
            terminal.setLastUpdatedBy(userId.toString());
            returnTerminals.add(terminalDAO.update(terminal));
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Terminal service's update method");
        return returnTerminals;
    }

    /**
     *This method is used to delete Terminal
     * @param data The json data coming from the UI
     * @param principal The java.security.Principal containing logged in user details
     */
    @Transactional
    @Manipulate(table = "MP_TERMINAL_MASTER")
    public void delete(Object data, Principal principal) {
        
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Entering Terminal service's delete method");
        LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"In terminal's service delete : {} ", data);

        List<Terminal> deletedTerminals = util.getEntitiesFromDto(data, TerminalDTO.class,Terminal.class);
        Integer userId = util.getUserIdFromPrincipal(principal);

        for (Terminal terminal : deletedTerminals) {

            Date currentDate = new Date();

            LOGGER.debug(MessageConstants.DEBUG_INDICATOR +"terminalId property in terminal service delete : {}", terminal.getTerminalId());
            terminal.setLastUpdatedDateTime(currentDate);
            terminal.setLastUpdatedBy(userId.toString());
            terminal.setIsDeleted('Y');
            terminalDAO.delete(terminal);
        }
        LOGGER.info(MessageConstants.INFO_INDICATOR +"Exiting Terminal service's delete method");
    }

}
