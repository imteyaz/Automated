package com.cmc.dpw.minapro.admin.application.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cmc.dpw.minapro.admin.application.common.MessageConstants;
import com.cmc.dpw.minapro.admin.application.dto.UserDTO;
import com.cmc.dpw.minapro.admin.application.entities.Device;
import com.cmc.dpw.minapro.admin.application.entities.Role;
import com.cmc.dpw.minapro.admin.application.entities.User;
import com.cmc.dpw.minapro.admin.domain.utils.Util;

/**
 * UserMonitoringDAO
 * 
 * @author Imran Rawani
 * @since 2014-Dec
 * 
 */
@Repository
public class UserMonitoringDAO extends GenericDAO<User> {

    @Autowired
    private Util util;
  
    Map<String, Object> resultMap = new HashMap<String, Object>();
    private static final Logger LOGGER = LoggerFactory.getLogger(UserMonitoringDAO.class);

    /**
     * This method is used to search UserMonitorings
     * 
     * @param accountStatusVal
     * @param loginStatusVal
     * @param equipmentIdVal
     * @param deviceIdVal
     * @param userNameVal
     * @param userIdVal
     * @param accountStatusVal
     * @param roleVal
     * @param start
     * @param limit
     * @return Map<String, Object>
     */
    public Map<String, Object> searchUserMonitorings(String userIdVal, String userNameVal, String deviceIdVal,
            String equipmentIdVal, String loginStatusVal, String accountStatusVal, String roleVal, int start, int limit) {

        LOGGER.info(MessageConstants.INFO_INDICATOR
                + "Entering into UserMonitoring DAO's searchUserMonitoring's method.......");
        Session session = getCurrentSession();
        Integer i = 0;

        Criteria searchCriteria = session.createCriteria(User.class, "usser");
        searchCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

        if (!("".equalsIgnoreCase(roleVal)) && roleVal != null) {
            searchCriteria.createAlias("usser.actualRoles", "role");
            searchCriteria.add(Restrictions.eq("role.userGroupName", roleVal));
            i++;
        }

        if (!("".equalsIgnoreCase(deviceIdVal)) && deviceIdVal != null) {
            searchCriteria.createAlias("usser.userDevice", "device");
            searchCriteria.add(Restrictions.eq("device.deviceId", deviceIdVal));
            i++;
        }

        if (!("".equalsIgnoreCase(equipmentIdVal)) && equipmentIdVal != null) {
            searchCriteria.createAlias("usser.userDevice", "device");
            searchCriteria.add(Restrictions.eq("device.equipmentId", equipmentIdVal));
            i++;
        }

        if (!("".equalsIgnoreCase(userIdVal)) && userIdVal != null) {
            searchCriteria.add(Restrictions.eq("userId", Integer.parseInt(userIdVal)));
            i++;
        }

        i = Util.addRestrictions(searchCriteria, "userName", userNameVal, false, i);
        i = Util.addRestrictions(searchCriteria, "loginStatus", loginStatusVal, false, i);
        i = Util.addRestrictions(searchCriteria, "accountStatus", accountStatusVal, false, i);

        Criteria totalCriteria = searchCriteria;

        totalCriteria.setProjection(Projections.projectionList().add(Projections.rowCount()));
        Long count = (Long) totalCriteria.uniqueResult();

        String totalRecords = count.toString();

        LOGGER.debug("******** count: {}", count);

        searchCriteria.setProjection(null);
        searchCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        searchCriteria.setFirstResult(start);
        searchCriteria.setMaxResults(limit);

        List<User> searchUsers = null;

        if (i == 0) {
            Query query = session.createQuery("select distinct u from User u");
            query.setMaxResults(limit);
            query.setFirstResult(start);

            List<User> userMonitoringList = query.list();

            searchUsers = userMonitoringList;
        } else {

            searchUsers = (List<User>) searchCriteria.list();
        }

        for (User user : searchUsers) {

            List<String> assignedRoles = new ArrayList<String>();
            StringBuilder roleNames = new StringBuilder();
            Collection<Role> actualRoles = user.getActualRoles();
            int roleCount = actualRoles.size();
            int j = 0;
            for (Role currentRole : actualRoles) {
                j++;
                String roleId = String.valueOf(currentRole.getIntUserGroupId());
                assignedRoles.add(roleId);
                roleNames.append(currentRole.getUserGroupName());

                if (roleCount != j) {
                    roleNames.append(',');
                }
            }
            user.setRoles(assignedRoles);
            user.setStringRoles(roleNames.toString());

            user.setDefaultLanguage(user.getLanguage().getLanguageCode());

            Device device = user.getUserDevice();
            if (device != null) {
                user.setDeviceId(device.getDeviceId());
                user.setEquipmentId(device.getEquipmentId());
            }

            LOGGER.debug("***** userMonitoring ID: {}", user.getUserId());
        }

        List<UserDTO> searchUserMonitoringsDtoList = util.map(searchUsers, UserDTO.class);

        LOGGER.debug("******* data:{}", searchUserMonitoringsDtoList);
        LOGGER.debug("******** total Records: {} ", totalRecords);

        resultMap.put(MessageConstants.DATA_KEY, searchUserMonitoringsDtoList);
        resultMap.put(MessageConstants.TOTALCOUNT_KEY, totalRecords);

        LOGGER.debug("***** Exiting from UserMonitoring DAO's searchUserMonitoring's method......");

        return resultMap;

    }
      public Map<String, Object>  ClearCacheforcelogout() {
        Map<String, Object> modelMap = new HashMap<String, Object>(MessageConstants.HASH_LENGTH_THREE);
        Session session = getCurrentSession();
        String MP_USER_DEVICE_MAPPING_SQL="DELETE FROM MP_USER_DEVICE_MAPPING";
        String MP_USERDTLS_AM_SQL="UPDATE MP_USERDTLS_AM SET LOGIN_STS = 'N'";
        SQLQuery delMP_USER_DEVICE_MAPPING_SQL = session.createSQLQuery(MP_USER_DEVICE_MAPPING_SQL);
        SQLQuery updMP_USERDTLS_AM_SQL = session.createSQLQuery(MP_USERDTLS_AM_SQL);
        int deletedUSER_DEVICE_MAPPINGRows = delMP_USER_DEVICE_MAPPING_SQL.executeUpdate();
        int updatedUSERDTLSRows = updMP_USERDTLS_AM_SQL.executeUpdate();
      
                String msg="Please find the deleted and updated records count below : </br></br> "
                        + deletedUSER_DEVICE_MAPPINGRows+"  records deleted from  table USER_DEVICE_MAPPING. </br>"
                        + updatedUSERDTLSRows+"  records updated in    table MP_USERDTLS_AM.</br>"
                        ;
                modelMap.put("deletedcount", msg);  
                
                LOGGER.debug("deletedUSER_DEVICE_MAPPINGRows : " + deletedUSER_DEVICE_MAPPINGRows);
                LOGGER.debug("updatedUSERDTLSRows : " + updatedUSERDTLSRows);
        return modelMap;

    }


}
