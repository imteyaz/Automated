Modules.admin.application_monitoring.change_log.childGridPanel = function() {
	var changeLogchildGridStoreObj = {
		model : 'changeLogChildGridModel',
		url : 'changeLog/getchangeLogChildGridData',
		paging : true,
		queryTypeCmc : 'remote',
		listeners : {
			beforeload : function() {
                this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
				var limitVal = Ext.getCmp(
						Modules.CompIds.changeLogChildGridId)
						.getComponent('centerGridPagingToolBarItemId')
						.getComponent('perPageCombo').getValue();
				if (!limitVal) {
					limitVal = Modules.GlobalVars.recordsPerPageGrid;
				}
				this.proxy.extraParams.limit = limitVal;
				this.pageSize = limitVal;
			}
		}
	};

	var getSearchObject = function(){
		var searchObj = Ext.getCmp(Modules.CompIds.changeLogFormId).getForm().getValues(false,true);
		searchObj.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
		return searchObj;
	};	
	
	var childGridObj = {
		xtype : 'cmcgrid',
		id : Modules.CompIds.changeLogChildGridId,
		storeObjCmc : changeLogchildGridStoreObj,
		height : 180,
		//width : 1248,
		showPagingBarCmc : true,
		showLeftExtraTbarCmc : true,
		showExtraTbarCmc : true,
	    popUpWinFuncCmc: Modules.admin.application_monitoring.change_log.childGridEditWin,//Window function which will return the object of pop-up window
		popUpWinIdCmc: 'NonOceanChangeLogChildGridWindowID',//Id of the pop-up window
		popUpCellIndexCmc:0,//This is the column index at which the icon will appear. It can be ignored if the column index is 1

		viewConfig : {
			stripeRows : true
		},
		setLeftExtraTbarFuncCmc : function() {
			var buttonArray = [];
			return buttonArray;
		},
		setExtraTbarFuncCmc : function() {
			var buttonArray = [ '->', {
				xtype : 'button',
				iconCls : "excel",
				tooltip: Modules.Msgs.excelReportToolTip,
//				disabled: true,
				handler : function() {
					
					var grid = Ext.getCmp(Modules.CompIds.changeLogChildGridId);
					if (grid.getStore().getCount() > 0) {
						
					    var record=Ext.getCmp( Modules.CompIds.changeLogParentGridId).getSelectionModel().getLastSelected();
		                var changeSeqNo=record.data.changeSeqNo;
						Ext.cmc.Exporter.exportToXls(grid,{'changeSeqNo' : changeSeqNo} ,'changeLog/getChangeLogChildDetailsExport');
						
					}else{
						Ext.MessageBox.show({
							msg: Modules.Msgs.emptyGrid,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});	
					}	            
					}	
			},
			{
				xtype : 'button',
				iconCls : "report",
//					disabled: true,
				tooltip: Modules.Msgs.pdfReportToolTip,	
				handler:function(){
					var grid = Ext.getCmp(Modules.CompIds.changeLogChildGridId);
					if (grid.getStore().getCount() > 0) {
					var record=Ext.getCmp( Modules.CompIds.changeLogParentGridId).getSelectionModel().getLastSelected();
	                var changeSeqNo=record.data.changeSeqNo;
					Ext.cmc.Exporter.exportToPdf(grid,{'changeSeqNo' : changeSeqNo} ,'changeLog/getChangeLogChildDetailsExport');
					}else{
						Ext.MessageBox.show({
							 msg: Modules.Msgs.emptyGrid,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});	
					}
					}											
			}];
			return buttonArray;
		},

		setGridColumnsFuncCmc : function() {
			var colsArr2 = [
					{
						xtype : 'actioncolumn',
						width : 30,
						sortable : false,
						hideable : false,
						align : 'center',
						items : [ {
							icon : 'resources/images/editView.jpg',
							tooltip : Modules.LblsAndTtls.tooltip.openPopupWin,
							handler : function() {
								return true;
							}
						} ]
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.fieldName,
						dataIndex : 'fieldName',
						//hideable : false,
						width : 150,
						 tdCls:'custom-column' ,
						readOnly :true						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.oldValue,
						dataIndex : 'oldValue',
						width : 150,
						 tdCls:'custom-column' ,
						readOnly :true
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.newValue,
						dataIndex : 'newValue',
						width : 150,
						 tdCls:'custom-column' ,
						readOnly :true						
					}

			];
			return colsArr2;
		}

	};
	return childGridObj;
};
