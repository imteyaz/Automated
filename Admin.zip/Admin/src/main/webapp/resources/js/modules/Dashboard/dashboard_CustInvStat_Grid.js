Modules.Dashboard.customerInvStatGrid = function() {
	
	var dbCustomerInvStatStoreObj = {
			model : 'DashboardCustInvStatModel',
			url : 'retrieveDashboardCustomerInvStatGrid',
			paging : true,
			queryTypeCmc : 'remote',
			listeners:{
				beforeload:function(){
					//for sending selected values to controller
					var selCmpCd = Ext.getCmp('headerCompanyComboID').getValue();
					var selCustomerCd = Ext.getCmp('dbCustInvStatCustomerId').getValue();
					var userType = Modules.GlobalVars.loginUserTypeCode;
					var userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.cmpnyCode = selCmpCd;
					this.proxy.extraParams.selCustomerCd = selCustomerCd;
					this.proxy.extraParams.userTyp = userType;
					this.proxy.extraParams.userId = userId;
					this.proxy.extraParams.parameterValue = Modules.GlobalVars.maxLimitRecords;
					//End of sending selected values to controller
					
					//for grid pagination limit val change
					var limitVal = Ext.getCmp('DbCustomerInvStatGridId').getComponent('centerGridPagingToolBarItemId').getComponent('perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
					//End of grid pagination limit val change
					
				},
			    load : function(store, records, success, eOpts ) {
			        if(success==true){
			        var count = records.length;
			        if (count >= 0) {
			        if(!Ext.getCmp('dbCustInvStatFormId').getCollapsed()){
			        Ext.getCmp('dbCustInvStatFormId').collapse( Ext.Component.DIRECTION_TOP );
			        }   
			        }
			    	}
			    	}
			}
		};

	var grid = {
		xtype : 'cmcgrid',
		id : 'DbCustomerInvStatGridId',
		//title : 'Customer Rating',
		storeObjCmc : dbCustomerInvStatStoreObj,
		//height:175,
		preventHeader:true,
		showCountColumnCmc : false,// Make it true to show counts as first
		// column else ignore
		showCountColumnCmc : false,
		showSelModelCmc : false,
		showPagingBarCmc : true,// Make it true to have paging else
		showTotalCountCmc : true,
		showExtraTbarCmc : true,
		setExtraTbarFuncCmc : function() {},
		showLeftExtraTbarCmc : true,
		setLeftExtraTbarFuncCmc : function() {},
		setGridColumnsFuncCmc : function() {
			var colsArr = [{
				xtype : 'actioncolumn',
				width : 20,
				sortable: false,
				hideable : false,
				items :[{
						icon: 'resources/images/editView.jpg',	
						tooltip: 'Open Popup window',
						handler: function() {
						return true;
							}	
						}]
					},
					{
						header : "Customer",
						dataIndex : 'customerCd',
						align : 'left',
						width : 75,
						hideable : false
					},{
						header : 'Invoice Type',
						dataIndex : 'invType',
						align : 'left',
						hideable : false,
						width : 120
					},
					{
						header : "Currency",
						dataIndex : 'currency',
						align : 'left',
						width : 65,
						hideable : false
					}, 
					{
			            text: 'Invoices Sent',
			            columns: [{
			                text     : 'Today',
			                columns: [{
				                text     : 'Count',
				                width    : 75,
				                sortable : true,
				                dataIndex: 'countToday',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+value+'</u>';
									
					            }
				            },
				            {
				                text     : 'Amount',
				                width    : 90,
				                sortable : true,
				                dataIndex: 'amountToday',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+Ext.cmc.CurrencyRenderer(value)+'</u>';
								
				            }

				            }]
			            }, {
			                text     : 'Yesterday',
			                columns: [{
				                text     : 'Count',
				                width    : 75,
				                sortable : true,
				                dataIndex: 'countYesterday',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+value+'</u>';
									
					            }
				            },
				            {
				                text     : 'Amount',
				                width    : 90,
				                sortable : true,
				                dataIndex: 'amountYesterday',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+Ext.cmc.CurrencyRenderer(value)+'</u>';
								
				            }
				            }]
			            }, {
			                text     : 'Past Week(Last 7 days)',
			                columns: [{
				                text     : 'Count',
				                width    : 75,
				                sortable : true,
				                dataIndex: 'countPastWeek',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+value+'</u>';
								
				            }
				            },
				            {
				                text     : 'Amount',
				                width    : 90,
				                sortable : true,
				                dataIndex: 'amountPastWeek',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+Ext.cmc.CurrencyRenderer(value)+'</u>';
								
				            }
				            }]
			            }, {
			                text     : 'Past Month(Last 30 days)',
			                columns: [{
				                text     : 'Count',
				                width    : 75,
				                sortable : true,
				                dataIndex: 'countPastMonth',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+value+'</u>';
								
				            }
				            },
				            {
				                text     : 'Amount',
				                width    : 90,
				                sortable : true,
				                dataIndex: 'amountPastMonth',
				                align : 'right',
				                renderer: function (value, metaData, record, row, col, store, gridView) {
									return '<u class = \'x-grid-column-underline\'>'+Ext.cmc.CurrencyRenderer(value)+'</u>';
								
				            }
				            }]
			             }]
			        }];
			return colsArr;
		},
		listeners: {
			 cellclick : function( cellModel, td, cellIndex, record, tr, rowIndex, e, eOpts){
				 var columnNameIndx = cellModel.getGridColumns()[cellIndex].dataIndex;
					var gridRecord = this.getSelectionModel().getLastSelected();
					if(columnNameIndx == "countToday" || columnNameIndx == "amountToday" ||
							columnNameIndx == "countYesterday" || columnNameIndx == "amountYesterday" ||
							columnNameIndx == "countPastWeek" || columnNameIndx == "amountPastWeek" ||
							columnNameIndx == "countPastMonth" || columnNameIndx == "amountPastMonth" ){
						
						if (Ext.getCmp('customerInvoiceStatusTabParentPanelId')) {
							Ext.getCmp('customerInvoiceStatusTabParentPanelId').close();
						}
						var panelObj = {
								panelFunc : Modules.customer_invoice.customer_invoice_status.customerInvoiceStatustabparentpanel,
								panelId : 'customerInvoiceStatusTabParentPanelId',
								parentTabPanelId : Modules.CompIds.viewportParentTabPanelId
							};
							Modules.GlobalFuncs.addPanelToTabPanel(panelObj);
							
					    var taskPanelAdd = new Ext.util.DelayedTask(function() {	
					    	var custmrInvoiceStatusForm = Ext.getCmp('customerInvoiceStatusTabParentPanelId').down('cmcform');
					    	
					    	var formFieldVaues = {};
					    	formFieldVaues.customer = gridRecord.get('customerCd');
					    	formFieldVaues.invoiceType = gridRecord.get('prfEstmInd');
					    	formFieldVaues.invoiceStatus = ['F'];
					    	
							if(columnNameIndx == "countToday" || columnNameIndx == "amountToday"){
								formFieldVaues.invoiceFromDate= Ext.Date.add(new Date());
								formFieldVaues.invoiceToDate= Ext.Date.add(new Date());
							}
							else if(columnNameIndx == "countYesterday" || columnNameIndx == "amountYesterday"){
								formFieldVaues.invoiceFromDate= Ext.Date.add(new Date(), Ext.Date.DAY, -1);
								formFieldVaues.invoiceToDate= Ext.Date.add(new Date(), Ext.Date.DAY, -1);
							}
							else if(columnNameIndx == "countPastWeek" || columnNameIndx == "amountPastWeek"){
								formFieldVaues.invoiceFromDate= Ext.Date.add(new Date(), Ext.Date.DAY, -7);
								formFieldVaues.invoiceToDate= Ext.Date.add(new Date(), Ext.Date.DAY, -1);
							}
							else if(columnNameIndx == "countPastMonth" || columnNameIndx == "amountPastMonth"){
								formFieldVaues.invoiceFromDate= Ext.Date.add(new Date(), Ext.Date.DAY, -30);
								formFieldVaues.invoiceToDate= Ext.Date.add(new Date(), Ext.Date.DAY, -1);
							}
							

							custmrInvoiceStatusForm.getForm().setValues(formFieldVaues);
							
							Ext.getCmp('customerinvoice_finalize').disable();
					    	Ext.getCmp('customerinvoice_reverse').disable(); 
					    	
					    	Ext.getCmp(Modules.CompIds.customerInvoiceStatusGridId).getStore().removeAll();
					    	Ext.getCmp(Modules.CompIds.customerInvoiceStatusGridId).getStore().loadPage(1,{
					    		callback: function(records, operation, success) {
					    			if(success == true)
					    			{
					    				var count = Ext.getCmp(Modules.CompIds.customerInvoiceStatusGridId).getStore().getCount();
					    				if(count == 0){
					    					Ext.MessageBox.show({
					    						title: '',
					    						msg: Modules.Msgs.noDataInGrid,
					    						buttons: Ext.MessageBox.OK,
					    						icon:Ext.MessageBox.INFO
					    					});
					    				}
					    			}
					    		}
					    	});	
							
						});
					    taskPanelAdd.delay(60);
					}
			 }
		},
		viewConfig : {
			emptyText: 'There are no records to display',
			stripeRows : true
		},
		popUpWinFuncCmc: Modules.Dashboard.customerInvStatView,//Window function which will return the object of pop-up window
		popUpWinIdCmc: Modules.CompIds.viewCustomerReconWinObjOneId,//Id of the pop-up window
		popUpCellIndexCmc:0//This is the column index at which the icon will appear. It can be ignored if the column index is 1
	};

	return grid;
	
};