function validateVesselNo(vesselNo){
	
	var networkIssueErrMssg = showNetworkIssueErrMssg("VesselNo") ; //"Error connecting to server...please try again" ;
	$('#VesselNoMssgSection').empty();	
Ext.Ajax.request({
url:'checkVesselNo',
params:{
	'vesselNo' : vesselNo //selectedRecord.data.vesselNo,
},
method:'POST',
success : function(response) {
	var responseTxt=Ext.decode(response.responseText);
	var success = responseTxt.success;
	var error = responseTxt.mssg;
	var availlableVesselNoMssg = "This Vessel Name is available."
		
		if(success){
			enableContinueBtn();
			//createErrorMssg("VesselNoMssgSection","popupVesselNo",availlableVesselNoMssg);
		}
		else{
				if ($('#popupContinueBtn').hasClass("secondary disabled")) {
				} else {
					$('#popupContinueBtn').addClass("secondary disabled");
				}
				createErrorMssg("VesselNoMssgSection", "popupVesselNo", error);
		}

	
},
failure:function(response){

	if($('#popupContinueBtn').hasClass("secondary disabled")){
		
	}
	else{
	$('#popupContinueBtn').addClass("secondary disabled");
	}
	createErrorMssg("VesselNoMssgSection","popupVesselNo",networkIssueErrMssg);
	
}
});
}

function validateVesselName(vesselName){
	
	var networkIssueErrMssg = showNetworkIssueErrMssg("vesselName") ;//"Error connecting to server...please try again";
	
	$('#vesselNameMssgSection').empty();	
	
Ext.Ajax.request({
url:'checkVesselName',
params:{
	'vesselName' : vesselName //selectedRecord.data.vesselNo,
},
method:'POST',
success : function(response) {
	var responseTxt =Ext.decode(response.responseText);
	var success = responseTxt.success;
	var error = responseTxt.mssg;
	
	var availlableNameMssg = "This Vessel Name is available."
	
	if(success){
		enableContinueBtn();
		//createErrorMssg("vesselNameMssgSection","popupvesselName",availlableNameMssg);
	}
	else{
		if($('#popupContinueBtn').hasClass("secondary disabled")){
			
		}
		else{
		$('#popupContinueBtn').addClass("secondary disabled");
		}
		createErrorMssg("vesselNameMssgSection","popupvesselName",error);
		
	}
	
},
failure:function(response){

	if($('#popupContinueBtn').hasClass("secondary disabled")){
		
	}
	else{
	$('#popupContinueBtn').addClass("secondary disabled");
	}
	createErrorMssg("vesselNameMssgSection","popupvesselName",networkIssueErrMssg);
	
}
});
}
function createErrorMssg(mssgDivId,fieldName,ErrorMssg) { 
	var errorMssgDiv = '#' + mssgDivId ;
	var inValidIconSection = 'inValidIconSection4' + fieldName ;
	var inValidMssgSection  = "inValidMssgSection4" + fieldName ;
	$(errorMssgDiv).empty();
	if($('#' + inValidIconSection).length == 0) { 
		var inValidIconDiv = document.createElement('div');
		$(inValidIconDiv).attr("id",inValidIconSection) ; //.addClass("invalidIconImage")
		$(errorMssgDiv).append(inValidIconDiv);
	}
	if($('#' + inValidMssgSection).length == 0) { 
		var inValidMssgDiv = document.createElement('div');
		$(inValidMssgDiv).attr("id",inValidMssgSection) ; //.addClass("validIconImage")
		var txt = document.createTextNode(ErrorMssg);
		$(inValidMssgDiv).append(txt) ;
		$(errorMssgDiv).append(inValidMssgDiv);
	}
}

$(document).on('keyup','#popupVesselNo',function(e){
	var vesselNo = $('#popupVesselNo').val();
	var blankErrorMssg = "This field is mandatory" ;
	//var valid = vesselNo.match(/^[\d]{1,10}$/);
	var valid = vesselNo.match(/^[a-z\d]{1,10}$/i);
	var invalidErrorMssg = "You must only enter alphanumeric value upto 10 characters" ;
	if (valid == null) {
		if(vesselNo.length!=0){
			$('#VesselNoMssgSection').empty();
			if($('#popupContinueBtn').hasClass("secondary disabled")){
			}
			else{
			$('#popupContinueBtn').addClass("secondary disabled");
			}
			createErrorMssg("VesselNoMssgSection","popupVesselNo",invalidErrorMssg);
		}
		//error = true ;
		else{
		$('#VesselNoMssgSection').empty();	
		if($('#popupContinueBtn').hasClass("secondary disabled")){
		}
		else{
		$('#popupContinueBtn').addClass("secondary disabled");
		}
		createErrorMssg("VesselNoMssgSection","popupVesselNo",blankErrorMssg);
		}
	}
	
	else{
		
		$('#VesselNoMssgSection').empty();
		//validateVesselNo(vesselNo);
	}
}); 

$(document).on('blur','#popupVesselNo',function(e){
	var vesselNoError = $("#VesselNoMssgSection").children().length;
	if(vesselNoError==0){
		var vesselNo = $('#popupVesselNo').val();
		validateVesselNo(vesselNo);
	}
	
});

$(document).on('keyup','#popupvesselName',function(e){
	
	var vesselNameVal = $('#popupvesselName').val();
	
	var blankErrorMssg = "This field is mandatory" ;
	
	var valid = vesselNameVal.match(/^[a-z\-_.\s\d]{3,25}$/i);
	//var valid = vesselNameVal.match(/^[a-zA-Z]+$/);
	
	
	var invalidErrorMssg = showVesselNameErrorMssg("Vessel Name",3,25);
	
	if (valid == null) {
		$('#vesselNameMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		
		if(vesselNameVal.length!=0){
			
			createErrorMssg("vesselNameMssgSection","popupvesselName",invalidErrorMssg);
				
		}
		//error = true ;
		else{
		createErrorMssg("vesselNameMssgSection","popupvesselName",blankErrorMssg);
		}
	}
	
	else{
		$('#vesselNameMssgSection').empty();
		//validateVesselName(vesselNameVal);
				
		}
		
	//enableResetBtn();
});
$(document).on('blur','#popupvesselName',function(e){
	
	var vesselNameError = $("#vesselNameMssgSection").children().length;
	if(vesselNameError==0){
		var vesselNameVal = $('#popupvesselName').val();
		validateVesselName(vesselNameVal);
	}
});

function enableContinueBtn(){
	$('#popupContinueBtn').addClass("secondary disabled");//.prop("disabled","true")
	var error = false ;
	var vesselNo = $('#popupVesselNo').val().length;
	var vesselName = $('#popupvesselName').val().length;
	var maxrRows = $('#popupMaxrows').val().length;
	var length = $('#popuplength').val().length; 
	var width = $('#popupwidth').val().length;  
	var teuCapacity = $('#popupteuCapacity').val().length;  
	var vesselType = $('#popupvesselType').val().length; 
	var height = $('#popupheight').val().length; 
	var vesselNoError = $("#VesselNoMssgSection").children().length;
	var vesselNameError = $("#vesselNameMssgSection").children().length;
	var maxRowsError = $("#MaxrowsMssgSection").children().length;
	var lengthError = $("#lengthMssgSection").children().length;
	var widthError = $("#widthMssgSection").children().length;
	var teuCapacityError = $("#teuCapacityMssgSection").children().length;
	var vesselTypeError = $("#vesselTypeMssgSection").children().length;
	var heightError = $("#heightMssgSection").children().length;
	if(((vesselNo!=0 && vesselName!= 0 )&& (length!=0 && width!= 0 )) && ((teuCapacity!=0 && vesselType!= 0 ) && (height!=0 && maxrRows!=0))){
		if(((vesselNoError==0 && vesselNameError== 0 )&& (lengthError==0 && widthError== 0 )) && ((teuCapacityError==0 && vesselTypeError== 0 )&& (heightError==0 && maxRowsError==0))){
			$('#popupContinueBtn').removeClass("secondary disabled");//.removeAttr("disabled")
		}
	
	}
}

$(document).on('click', '#popupContinueBtn', function() {
	var btnContinue = this ;
	var isDisabled = $(btnContinue).hasClass("secondary disabled");
	if(!isDisabled){
		var vesselNo = $('#popupVesselNo').val();
		var vesselName = $('#popupvesselName').val();
		//var sectionNo = $('#popupsectionNo').val();
		var vesselType = $('#popupvesselType').val();
		var length = $('#popuplength').val();
		var width = $('#popupwidth').val();
		var teuCapacity = $('#popupteuCapacity').val();
		var motherFeeder = $('#popupmotherFeederInd').val();
		var height =  $('#popupheight').val();
		var maxRows =  $('#popupMaxrows').val();
		$('#vessel_no').val(vesselNo);
		$('#vessel_name').val(vesselName);
		//$('#sect_start').val(sectionNo);
		$('#maxRows').val(maxRows);
		$('#vesselType').val(vesselType);
		$('#length').val(length);
		$('#width').val(width);
		$('#teuCapacity').val(teuCapacity);
		$('#motherFeeder').val(motherFeeder);
		$('#height').val(height);
		 /* = $('#popupvesselType').val();
		  = $('#popuplength').val();
		  = $('#popupwidth').val();
		var  = $('#popupteuCapacity').val();
		var  = $('#popupmotherFeederInd').val();
		  */
		$('#DvesselNo').val(vesselNo);
		$('#DvesselName').val(vesselName);
		$('#DmaxRows').val(maxRows);
//		$('#DSectionNoStart').val(sectionNo);
		$("#screen_headings").text("Bay Definition");
		$('.simplemodal-close').click();
		/*$(".x-viewport body").css("overflow","scroll !important");
		$("#centerPanelId").css("height","auto !important");*/
	}
});

$(document).on('click', '#editpopuUpCancelBtn', function() {
	close();
});
$(document).on('click', '#popuUpCancelBtn', function() {
	close();
});

$(document).on('click', '#markAgain', function() {
	var isMarkAgainCLicked = true ;
	$('html,body').css('cursor','crosshair');
});

// Extra fields validation

$(document).on('keyup','#popupvesselType',function(e){
	var vesselType = $('#popupvesselType').val();
	var blankErrorMssg = "This field is mandatory" ;
	//var valid = vesselNo.match(/^[\d]{1,10}$/);
	var valid = vesselType.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "You must only enter alphabets upto 2 characters" ;
	if (valid == null) {
		if(vesselType.length!=0){
			$('#vesselTypeMssgSection').empty();
			if($('#popupContinueBtn').hasClass("secondary disabled")){
			}
			else{
			$('#popupContinueBtn').addClass("secondary disabled");
			}
			createErrorMssg("vesselTypeMssgSection","popupvesselType",invalidErrorMssg);
			
		}
		//error = true ;
		else{
		$('#vesselTypeMssgSection').empty();	
		if($('#popupContinueBtn').hasClass("secondary disabled")){
		}
		else{
		$('#popupContinueBtn').addClass("secondary disabled");
		}
		createErrorMssg("vesselTypeMssgSection","popupvesselType",blankErrorMssg);
		}
	}
	else{
		$('#vesselTypeMssgSection').empty();
		if(vesselType.length!=0){
		if(vesselType.length >2){
			if($('#popupContinueBtn').hasClass("secondary disabled")){
			}
			else{
			$('#popupContinueBtn').addClass("secondary disabled");
			}
			createErrorMssg("vesselTypeMssgSection","popupvesselType",invalidErrorMssg);
		}
		else{
			enableContinueBtn();
		}
		}
		/*
		else{
			$('#VesselNoMssgSection').empty();		
			createErrorMssg("VesselNoMssgSection","popupVesselNo",blankErrorMssg);
		}*/
	
	}
	//enableResetBtn();
}); 

$(document).on('keyup','#popuplength',function(e){
	var lengthVal = $('#popuplength').val();
	var blankErrorMssg = "This field is mandatory" ;
	//var valid = lengthVal.match(/^[\d]{1,4}$/);
	var valid = lengthVal.match(/^\d{1,4}(\.\d{1,2})?$/);
	
	//var valid = lengthVal.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "You must only enter numbers upto 4 digits, excluding optional 2 decimal places. " ;
	if (valid == null) {
		$('#lengthMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		if(lengthVal.length!=0){
			createErrorMssg("lengthMssgSection","popuplength",invalidErrorMssg);
		}
		//error = true ;
		else{
		createErrorMssg("lengthMssgSection","popuplength",blankErrorMssg);
		}
	}
	else{
		$('#lengthMssgSection').empty();
		enableContinueBtn();
		}
	//enableResetBtn();
});

$(document).on('keyup','#popupwidth',function(e){
	var widthVal = $('#popupwidth').val();
	var blankErrorMssg = "This field is mandatory" ;
	//var valid = widthVal.match(/^[\d]{1,3}$/);
	var valid = widthVal.match(/^\d{1,3}(\.\d{1,2})?$/);
	//var valid = widthVal.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "You must only enter numbers upto 3 digits, excluding optional 2 decimal places." ;
	if (valid == null) {
		$('#widthMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		if(widthVal.length!=0){
			createErrorMssg("widthMssgSection","popupwidth",invalidErrorMssg);
		}
		//error = true ;
		else{
		createErrorMssg("widthMssgSection","popupwidth",blankErrorMssg);
		}
	}
	else{
		$('#widthMssgSection').empty();
		enableContinueBtn();
				
		}
	//enableResetBtn();
}); 
$(document).on('keyup','#popupMaxrows',function(e){
	var Maxrows = $('#popupMaxrows').val();
	var blankErrorMssg = "This field is mandatory" ;
	var valid = (Maxrows.match(/^[\d]{1,5}$/)) && (Number(Maxrows)<=99);
	//var valid = teuCapacityVal.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "Max rows should be a number and cannot be greater than 99" ;
	if (!valid) {
		$('#MaxrowsMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		if(Maxrows.length>0){
			createErrorMssg("MaxrowsMssgSection","popupMaxrows",invalidErrorMssg);
		}
		//error = true ;
		else{
		createErrorMssg("MaxrowsMssgSection","popupMaxrows",blankErrorMssg);
		}
	}
	else{
		$('#MaxrowsMssgSection').empty();
		enableContinueBtn();
		}
		
	//enableResetBtn();
});
$(document).on('keyup','#popupteuCapacity',function(e){
	var teuCapacityVal = $('#popupteuCapacity').val();
	var blankErrorMssg = "This field is mandatory" ;
	var valid = teuCapacityVal.match(/^[\d]{1,5}$/);
	//var valid = teuCapacityVal.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "You must only enter numbers upto 5 digits" ;
	if (valid == null) {
		$('#teuCapacityMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		if(teuCapacityVal.length!=0){
			createErrorMssg("teuCapacityMssgSection","popupteuCapacity",invalidErrorMssg);
		}
		//error = true ;
		else{
		createErrorMssg("teuCapacityMssgSection","popupteuCapacity",blankErrorMssg);
		}
	}
	else{
		$('#teuCapacityMssgSection').empty();
		enableContinueBtn();
		}
		
	//enableResetBtn();
}); 

$(document).on('keyup','#popupheight',function(e){
	var heightVal = $('#popupheight').val();
	var blankErrorMssg = "This field is mandatory" ;
	//var valid = heightVal.match(/^[\d]{1,3}$/);
	var valid = heightVal.match(/^\d{1,3}(\.\d{1,2})?$/);
	//var valid = heightVal.match(/^[a-zA-Z]+$/);
	var invalidErrorMssg = "You must only enter numbers upto 3 digits, excluding optional 2 decimal places." ;
	if (valid == null) {
		$('#heightMssgSection').empty();
		$('#popupContinueBtn').addClass("secondary disabled");
		if(heightVal.length!=0){
			createErrorMssg("heightMssgSection","popupheight",invalidErrorMssg);
		}
		//error = true ;
		else{
		createErrorMssg("heightMssgSection","popupheight",blankErrorMssg);
		}
	}
	else{
		$('#heightMssgSection').empty();
		enableContinueBtn();
		}
	//enableResetBtn();
}); 

function getTemplateHeadersOrDetails(entityName,filterColumnName,filterColumnVal,queryColumnName,query,start,limit){
	var responseData;

	Ext.Ajax.request({
		async:false,
	url: '../common/getForeignKeys',
	timeout: 600000,
	params:{
		'start' : start ,
		'limit' : limit,
		'entityName' : entityName,
		'query' : query,
		'columnName' : queryColumnName,
		'filterColumnName' : filterColumnName,
		'filterColumnVal' : filterColumnVal
		},
	method:'POST',
	success : function(response) {
		var msg=Ext.decode(response.responseText);
		var error = msg.message;
		responseData = msg;
		/*if(msg.success==true){
			Ext.MessageBox.show({
				msg: "data received successfully", //Modules.Msgs.saveSuccess,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});		
			
		}else{
			Ext.MessageBox.show({
				msg: error,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});											
		}*/
	},

	failure:function(response){
		Ext.MessageBox.show({
			msg: "Error in Connection...Please try again.",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});
		
	}
	});
	return responseData;
	}


$(document).on('click','#templateHeaders',function(e){
	
	getTemplateHeadersOrDetails('TemplateHeader','type','','headerId','',0,100);
	//getTemplateHeadersOrDetails(entityName,filterColumnName,filterColumnVal,queryColumnName,query,start,limit);
});

$(document).on('click','#templateDetails',function(e){
	
	getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',3,'pk.headerId','',0,100);
	//getTemplateHeadersOrDetails(entityName,filterColumnName,filterColumnVal,queryColumnName,query,start,limit);
});
