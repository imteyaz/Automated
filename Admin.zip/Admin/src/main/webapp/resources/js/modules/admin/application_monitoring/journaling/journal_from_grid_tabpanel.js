Ext.QuickTips.init();
Modules.admin.journal.tabpanel = function() {
		var storeObj = {
			model : 'Journal',
			url : 'journal/getJournalDtls',
			paging : true,
			queryTypeCmc : 'remote',
			listeners : {
				beforeload : function() {
					//var companyCode=Modules.GlobalVars.selectedCompanyCode;
					
					var searchObj = Ext.getCmp(Modules.CompIds.journalTabPanelId).down('#queryForm').getForm().getValues(false,true);
					
					Ext.apply(this.proxy.extraParams,searchObj);
					this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.language = Modules.GlobalVars.userLocale;
					var limitVal = Ext.getCmp(Modules.CompIds.journalGridId).getComponent(
							'centerGridPagingToolBarItemId').getComponent(
							'perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				}
			}
		};
		var getSearchObject = function(count){
			var searchObj = Ext.getCmp(Modules.CompIds.journalTabPanelId).down('#queryForm').getForm().getValues(false,true);
			searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
			searchObj.limit = count;
			searchObj.page = 1;
			return searchObj;
		};
		var grid = {
			xtype : 'cmcgrid',
			id : Modules.CompIds.journalGridId,
			storeObjCmc : storeObj,
			showPagingBarCmc : true,
			showExtraTbarCmc : true,
			setExtraTbarFuncCmc : function() {
				var buttonArray = [{
					xtype : "button",
					iconCls : "excel",
					//disabled : true,
					tooltip: Modules.Msgs.excelReportToolTip,
					handler:function(){
						var grid = Ext.getCmp(Modules.CompIds.journalGridId);
						var count = grid.getStore().getTotalCount();
						var searchObj = getSearchObject(count);
						if (Ext.getCmp(Modules.CompIds.journalGridId).getStore().getCount() > 0){
							Ext.cmc.Exporter.exportToXls(grid, searchObj,'journal/getJournalExport');
						}
						else{
							Ext.MessageBox.show({
                                title: '',
                                msg: Modules.Msgs.emptyGrid,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					}
				},{
					xtype : "button",
					iconCls : "report",
					tooltip: Modules.Msgs.pdfReportToolTip,
					handler:function(){
						var grid = Ext.getCmp(Modules.CompIds.journalGridId);
						var count = grid.getStore().getTotalCount();
						var searchObj = getSearchObject(count);
						if (Ext.getCmp(Modules.CompIds.journalGridId).getStore().getCount() > 0){
							Ext.cmc.Exporter.exportToPdf(grid, searchObj,'journal/getJournalExport');
						}
						else{
							Ext.MessageBox.show({
                                title: '',
                                msg: Modules.Msgs.emptyGrid,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					  }
				}];
				return buttonArray;
			},
			setGridColumnsFuncCmc : function() {
				var colsArr = [
				    {
						xtype : 'actioncolumn',
						width : 20,
						sortable: false,
						items :[{
							icon: 'resources/images/editView.jpg',
			                tooltip: Modules.LblsAndTtls.tooltip.openPopupWin,
			                handler: function(){
			                	return true;
			                }
						}]
					}, {
						header:Modules.admin.journal.labels.dateOrTime,
						dataIndex:'dateOrTime',
						readOnly : true,
						width : 180,
						tdCls:'custom-column',
						renderer: Ext.util.Format.dateRenderer(Modules.GlobalVars.dateTimeFormatGlobal)
					}, {
						header:Modules.admin.journal.labels.userID,
						dataIndex:'userId',
						width: 120,
						readOnly : true,
						tdCls:'custom-column',
						renderer : 'uppercase'
						
					}, {
						header:Modules.admin.journal.labels.ediPartnerOrModule,
						dataIndex:'eDIPartnerOrModule',
						width: 150,
						tdCls:'custom-column',
						readOnly : true
					}, {
						header:Modules.admin.journal.labels.action,
						dataIndex:'action',
						readOnly : true,
						tdCls:'custom-column',
						width : 150
					}, {
						header:Modules.admin.journal.labels.fieldName,
						dataIndex:'feildName',
						readOnly : true,
						tdCls:'custom-column',
						width : 200
						
					}, {
						header:Modules.admin.journal.labels.loadReferenceNumber,
						dataIndex:'loadRefNo',
						width: 150,
						readOnly : true,
						tdCls:'custom-column',
						listeners: {
							render: function(c) {
								 Ext.QuickTips.register({
									target: c.getEl(),
									text:'Load Reference Number'
								});
							}
						}
						
					}, {
						header:Modules.admin.journal.labels.invoiceNoOrUnitID,
						dataIndex:'unitId',
						readOnly : true,
						tdCls:'custom-column',
						width : 180
					}, {
						header:Modules.admin.journal.labels.oldValue,
						dataIndex:'oldValue',
						readOnly : true,
						tdCls:'custom-column',
						width : 105
						
					}, {
						header:Modules.admin.journal.labels.newValue,
						dataIndex:'newValue',
						readOnly : true,
						tdCls:'custom-column',
						width : 100
						
					}
				];
				return colsArr;
			},
			viewConfig : {
				stripeRows : true,
				//emptyText: Modules.Msgs.noDataInGrid,
				 listeners : {
		            	
				}
			},
			popUpWinFuncCmc: Modules.admin.journal.popupGridWindow,
	        popUpWinIdCmc: Modules.CompIds.popupCustomerRateQueryId,
	        popUpCellIndexCmc: 0
		};
		return grid;
};
