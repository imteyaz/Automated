	
Modules.admin.auditlog.from= function() {
	Ext.QuickTips.init();

	Ext.apply(Ext.form.field.VTypes, {
        daterange: function(val, field) {
            var date = field.parseDate(val);

            if (!date) {
                return false;
            }
            if (field.startDateField && (!this.dateRangeMax || (date.getTime() != this.dateRangeMax.getTime()))) {
                var start = field.up('form').down('#' + field.startDateField);
                start.setMaxValue(date);
                start.validate();
                this.dateRangeMax = date;
            }
            else if (field.endDateField && (!this.dateRangeMin || (date.getTime() != this.dateRangeMin.getTime()))) {
                var end = field.up('form').down('#' + field.endDateField);
                end.setMinValue(date);
                end.validate();
                this.dateRangeMin = date;
            }
            /*
             * Always return true since we're only using this vtype to set the
             * min/max allowed values (these are tested for after the vtype test)
             */
            return true;
        }
	});
	
	var userIdStore={
			model: 'AuditUserIdDTO',
			queryTypeCmc:'remote',
			url:'auditLog/getUserId', //?userId=3&serviceType=HRBA', TODO
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userName = Modules.GlobalVars.loginUserTypeCode;
				}
			}
	};
	
	 
	var moduleNameStore={
			model: 'AuditLogModuleNameModel',
			queryTypeCmc:'remote',
			url:'auditLog/getModules', //?userId=3&serviceType=HRBA', TODO
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.moduleName = Modules.GlobalVars.loginUserTypeCode;
				}
			}
	};
	var functionNameStore={
			model: 'AuditLogFunctionNameModel',
			queryTypeCmc:'remote',
			url:'auditLog/getFunctionNames', //?userId=3&serviceType=HRBA', TODO
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.functionDesc = Modules.GlobalVars.loginUserTypeCode;
				}
			}
	};
	var applnServerNameStore={
			model: 'AuditLogApplnServerNameModel',
			queryTypeCmc:'remote',
			url:'auditLog/getApplnServerName', //?userId=3&serviceType=HRBA', TODO
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.applnServerName = Modules.GlobalVars.loginUserTypeCode;
				}
			}
	};
	var form = {
		xtype: 'cmcform',
		title: Modules.admin.auditlog.labels.formTitle,
		itemId: 'queryForm',
		width: 1000,
		height: 160,
		plugins:[{ ptype: 'saveretrievecriteria',screenId:Modules.CompIds.auditLogTabPanelId}],
		bodyStyle: 'background-color: #FFFFFF',
		listeners:{},
		showFieldsetCmc: false,
		tbar:[{
			text:Modules.LblsAndTtls.clearActionTtl,
			xtype:"button",
			iconCls:"clear",
			handler:function(){
				this.ownerCt.ownerCt.getForm().reset();
	            Ext.getCmp(Modules.CompIds.auditLogQueryGridId).resetDataCmc();
			}
		},{
			xtype: "button",
			text:Modules.LblsAndTtls.retrieveActionTtl,
			iconCls:"retrieve",
			getValidationMsg : function(){
				var form =  this.up('form');
				var searchObj =form.getForm().getValues(false,true);
				if(Modules.GlobalFuncs.isEmptyObj(searchObj)){
					return Modules.contract.customer_rate_query.messages.enterCriteria;
				}
				return '';
			},
			handler:function(){

				if(Modules.GlobalVars.selectedCompanyCode != null){	
					var errorMsg = this.getValidationMsg();
					if(!Ext.isEmpty(errorMsg)){
						Ext.MessageBox.show({
                            msg: errorMsg,
                            buttons: Ext.MessageBox.OK,
                            icon:Ext.MessageBox.ERROR
                       });
					}else{
						var form =  this.up('form');
						if(form.isValid()){
							form.collapse();
							Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getStore().removeAll();
							var store =Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getStore(); 
							store.removeAll();
							store.proxy.extraParams ={};
							store.loadPage(1,{
								callback: function(records, operation, success) {
			                         if(success == true)
			                         {
			                        	 var count = Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getStore().getCount();
				                            if(count == 0){
				            	            	Ext.MessageBox.show({
				                                     msg: Modules.Msgs.noDataInGrid,
				                                     buttons: Ext.MessageBox.OK,
				                                     icon:Ext.MessageBox.INFO
				                                });
				                            }
				                            else{
				                            }
			                         }
								}
							});
						
						}else{
							Ext.MessageBox.show({
								msg: 'Please correct the highlighted errors',
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.ERROR
							});
						}
						
					}
				}
				else{
					Ext.MessageBox.show({
                        msg: Modules.Msgs.ValidationCorrectValue,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                   });
				}
			}			
		},{
			xtype:"tbfill"
		}],
		
		setFormItemsFuncCmc: function () {
			var itemsArr = [];
			/*var userName = {
					xtype: 'cmccombobox',
					name: 'userName',
					fieldLabel: Modules.admin.auditlog.labels.userId,
					storeObjCmc: userIdStore,
					width: 185,
					labelWidth: 85,
					triggerAction: 'all',
					selectOnTab: true,
					typeAhead: true,
					labelAlign:"left",
					displayField: 'userName',
					valueField: 'userName',
					matchFieldWidth: false,
					paging:true,
					validateSuccessFuncCmc : function(serverRespOjbData) {
						Ext.getCmp("userNameId").setValue(serverRespOjbData.userId);
						return true;
					},
					listConfig: {
						width: 320,
						loadingText:Modules.Msgs.loading,
						height: 300,
						deferEmptyText: false,
						emptyText: Modules.Msgs.noComboValueFound,
						getInnerTpl: function () {
							return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="150px" align="left">{userName}</td><td width="170px" align="left">{fullName}</td></tr></table>';
						}
					}
				};*/
			
			var userName=Modules.LovFactory.getUserNameLov({
				name: 'userName',
				width: 300,
				labelWidth: 85,
				valueField: 'userId'
			});
			
			var moduleName = {
					xtype: 'cmccombobox',
					name: 'moduleName',
					fieldLabel : Modules.admin.auditlog.labels.moduleName,
					storeObjCmc: moduleNameStore,
					width: 250,
					labelWidth: 85,
					triggerAction: 'all',
					selectOnTab: true,
					typeAhead: true,
					labelAlign:"left",
					displayField: 'moduleName',
					valueField: 'moduleCode',
					matchFieldWidth: false,
					paging:true,
					columnsCmc:[{
							header:'Code',
							width:100,
							dataIndex:'moduleCode'
						},{
							header:'Description',
							width:200,
							dataIndex:'moduleName'
						}]
					
				};
			var functionName = {
					xtype: 'cmccombobox',
					name: 'functionName',
					fieldLabel : Modules.admin.auditlog.labels.functionName ,
					storeObjCmc: functionNameStore,
					width: 300,
					labelWidth: 85,
					triggerAction: 'all',
					selectOnTab: true,
					typeAhead: true,
					labelAlign:"left",
					displayField: 'functionName',
					valueField: 'functionCode',
					matchFieldWidth: false,
					paging:true,
					columnsCmc:[{
							header:'Code',
							width:200,
							dataIndex:'functionCode'
						},{
							header:'Name',
							width:200,
							dataIndex:'functionName'
						},{
							header:'Description',
							width:200,
							dataIndex:'functionDesc'
						}]
					
				};
			var applnServeName = {
					xtype: 'cmccombobox',
					name: 'hostname',
					fieldLabel : Modules.admin.auditlog.labels.applnServeName ,
					listeners: {
						render: function(c) {
							 Ext.QuickTips.register({
								target: c.getEl(),
								text:'Application Server Name'
							});
						}
					},
					storeObjCmc: applnServerNameStore,
					width: 250,
					labelWidth: 110,
					triggerAction: 'all',
					selectOnTab: true,
					typeAhead: true,
					labelAlign:"left",
					displayField: 'hostname',
					valueField: 'hostname',
					matchFieldWidth: false,
					paging:true,
					 columnsCmc:[{
							header:'Host',
							width:200,
							dataIndex:'hostname'
						}]
				};
			
			var fromDate = {
					xtype: 'cmcdatefield',
					width:250,
					labelWidth: 85,
					itemId: 'validFromDate',
					name:'validFromDate',
					labelAlign:"left",
					fieldLabel: Modules.admin.auditlog.labels.startDate,
					vtype: 'daterange',
					endDateField: 'validToDate'//, // id of the toDate field
					//valuesAsStringCmc:false
				};
			var toDate = {
					xtype: 'cmcdatefield',
					width:250,
					labelWidth: 85,
					itemId: 'validToDate',
					name: 'validToDate',
					labelAlign:"right",
				//	disabled:true,
					fieldLabel: Modules.admin.auditlog.labels.endDate,
					vtype: 'daterange',
					startDateField: 'validFromDate'//,// id of the fromDate field
					//valuesAsStringCmc:true
				};

			var radioGroup ={
					  xtype: 'fieldset',
					  width:250,
					  height: 40,
					  collapsble :true,
					  defaults: {
				            labelStyle: 'padding-left:4px;'
				      },
				      items: [{
				            xtype: 'radiogroup',
				            items: [
				                {boxLabel: 'Open Sessions', name: 'session', inputValue: 'O', checked: true},				                	
				                {boxLabel: 'All Sessions', name: 'session', inputValue: 'A' }
				            ],
				        listeners:{
				        	change : function(group,newValue,oldValue,ops){
				        		
				        		if(newValue.session == 'O'){
				        			//this.up('cmcform').down('#validToDate').disable();
				        		}else{
				        			//this.up('cmcform').down('#validToDate').enable();
				        		}
				        		
				        	}
				        }
				        }
				        ]
			};
			
			var container1 = {
					xtype: 'container',
					layout: 'hbox',
					labelAlign:"left",
					margin: '10px 10px 10px 10px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [userName]
			};
			
			var container2 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '10px 10px 10px 10px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [moduleName,functionName]
			};
			var container3 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '10px 10px 10px 10px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [fromDate,toDate]
			};
			var container4 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '10px 10px 10px 10px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [radioGroup,applnServeName]
			};
			
		    var itemsArr = [container1,container2,container3];
			return itemsArr;
			
		}
	};
	return form;
};
	