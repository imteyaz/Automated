
Ext.QuickTips.init();
Modules.admin.internalAdmin.databaseErrorLog.Grid = function() {

		var storeObj = {
			model : 'ErrorLogDTO',
			url : 'getDatabaseErrorLogdtls',
			paging : true,
			queryTypeCmc : 'remote',
			listeners : {
				beforeload : function() {
					var userName=Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogUserNameId).getValue();
					var errorLogDate=Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogErroLogDateId).getRawValue();
					var hostName=Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogHostNameId).getValue();
					var errorFnDes=Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogErrFnDesId).getValue();
					if(userName==null){
						userName='null';
					}
					if(!errorLogDate){
						errorLogDate='null';
					}
					if(!hostName){
						hostName='null';
					}
					if(!errorFnDes){
						errorFnDes='null';
					}				
					this.proxy.extraParams.userName = userName;
					this.proxy.extraParams.errorLogDate = errorLogDate;
					this.proxy.extraParams.hostName = hostName;
					this.proxy.extraParams.errorFnDes = errorFnDes;
					this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
					
					var limitVal = Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getComponent(
							'centerGridPagingToolBarItemId').getComponent(
							'perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				}
			}
		};
		
		var grid = {
			xtype : 'cmcgrid',
			id : Modules.CompIds.internalAdminDatabaseErrorLogGridId,
			storeObjCmc : storeObj,
			showPagingBarCmc : true,
			showExtraTbarCmc : true,
			popUpWinFuncCmc: Modules.admin.internalAdmin.databaseErrorLog.popupDatabaseErrorLogGrid,
	        popUpWinIdCmc: 'internalAdminDatabaseErrorPopupWindowId',
	        popUpCellIndexCmc: 0,
			setExtraTbarFuncCmc : function() {
				var buttonArray = [ {
					xtype : "button",
					iconCls : "excel",
					id : Modules.CompIds.internalAdminDatabaseErrLogExcelReportId,
					tooltip: Modules.Msgs.excelReportToolTip,
					handler:function(){
						var grid = Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId);
						var searchObj = getSearchObject();
						if (Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getStore().getCount() > 0){
							Ext.cmc.Exporter.exportToXls(grid, searchObj,'getDatabaseErrorQueryExport');
						}
						else{
							Ext.MessageBox.show({
                                title: '',
                                msg: Modules.Msgs.emptyGrid,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					}
				},{
					xtype : "button",
					iconCls : "report",
					id : Modules.CompIds.internalAdminDatabaseErrLogPDFReportId,
					tooltip: Modules.Msgs.pdfReportToolTip,
					handler:function()
					  {
						var grid = Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId);
						var searchObj = getSearchObject();
						
						if (Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getStore().getCount() > 0){
							Ext.cmc.Exporter.exportToPdf(grid, searchObj,'getDatabaseErrorQueryExport');
						}
						else{
							Ext.MessageBox.show({
                                title: '',
                                msg: Modules.Msgs.emptyGrid,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}

					  }
				}];
				return buttonArray;
			},
			setGridColumnsFuncCmc : function() {
				var colsArr = [
				    {
						xtype : 'actioncolumn',
						width : 20,
						sortable: false,
						hideable: false,
						items :[{
							icon: 'resources/images/editView.jpg',
			                handler: function(){
			                	
			                	return true;
			                }
						}]
					},
					{
						header:Modules.LblsAndTtls.errorLogDate+"<span style='color: red'>*</span>",
						dataIndex:'errorLogDate',
						readOnly : true,
						renderer : 'uppercase',
						hideable : false,
						tdCls:'custom-column'
					},
					{
						header:Modules.LblsAndTtls.userName+"<span style='color: red'>*</span>",
						dataIndex:'userName',
						width: 150,
						readOnly : true,
						hideable : false,
						tdCls:'custom-column'
						
					},{
						header:Modules.LblsAndTtls.hostName+"<span style='color: red'>*</span>",
						dataIndex:'hostName',
						readOnly : true,
						width: 200,
						hideable : false,
						tdCls:'custom-column'

					},
					{
						header:Modules.LblsAndTtls.errorFnDescription+"<span style='color: red'>*</span>",
						dataIndex:'errorFnDes',
						width: 250,
						readOnly : true,
						hideable : false,
						tdCls:'custom-column'
						
					},
					{
						header:Modules.LblsAndTtls.errorPosition,
						dataIndex:'errorPosition',
						align: 'right',
						width: 100,
						readOnly : true,
						tdCls:'custom-column'
						
					},
					{
						header:Modules.LblsAndTtls.errorDescription,
						dataIndex:'description',
						width: 300,
						readOnly : true,
						tdCls:'custom-column'
					}
				];
				return colsArr;
			}
		};
		return grid;
};

var getSearchObject = function(){
	var searchObj = Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrLogPanelId).down('#'+Modules.CompIds.internalAdminDatabaseErrorLogFormId).getForm().getValues(false,true);
	searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
	return searchObj;
}
