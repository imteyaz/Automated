$(document).ready(function(){
	 function twodigits(n) {
         return n > 9 ? "" + n : "0" + n;
     }
	 
var cell_spm = data.cellList,
bayrow_spm = data.bayRowList,
sect_spm = data.sectionList,
bay_spm = data.bayList,
bay_start = 1;
//VSL View
var deck_bay_array=[],
	bay_array=[],
	underdeck_bay_array=[],
	bay_tuple={},
	cells_bay=[],
	bayRows_bay=[],
	cells_bay_data=[],
	bayRows_bay_data=[],
	id_saved;
	/*cells={};*/

$("#vessel_details_head").text(data.vesselInfo.vesselName + "  ----   " + data.vesselInfo.vesselCode);
var maxRows = data.vesselInfo.maxRows;
var getTemplateDetails = function(templateHeaderVal,id){
	if(templateHeaderVal == null){  // will never be null
	}else{
	var TemplateDetails ={};
	TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
	$("#tbody"+id).empty();
 	for(var t=TemplateDetails.data.length-1;t>=0;t--){
 		$("#tbody"+id).append("<tr><th rowspan='1' scope='row' style=''>" + TemplateDetails.data[t].vesselLabel+ "</th></tr>");
 	}
 	$("#tbody"+id+" tr").each(function(e) {
         for (var x = 0; x < maxRows; x++) {
             $(this).append("<td></td>");
         }
     });
	}
 };
 var getTierCount = function(templateHeaderVal){
	 var TemplateDetails ={};
	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
	 return TemplateDetails.data.length;
 };
for(var i = 0; i<sect_spm.length;i++){
	if(sect_spm[i]["deckOrUnderDeck"] === "D"){
	$("#deck_row").append("<table class='deck'  style='border-bottom:2px solid red;float:left;margin-right:10px'><tbody><tr id='"+sect_spm[i]["pk"]["sectionNo"]+""+sect_spm[i]["deckOrUnderDeck"]+"'></tr></tbody></table>");
	}
	if(sect_spm[i]["deckOrUnderDeck"] === "U"){
	$("#underdeck_row").append("<table class='underdeck'  style='border-bottom:2px solid red;float:left;margin-right:10px'><tbody><tr id='"+sect_spm[i]["pk"]["sectionNo"]+""+sect_spm[i]["deckOrUnderDeck"]+"'></tr></tbody></table>");
	}
	}
	for(var j = 0; j<bay_spm.length;j++){
	$("#"+bay_spm[j]["pk"]["sectionNo"]+bay_spm[j]["pk"]["deckUnderDeck"]).append("<td id='"+bay_spm[j]["pk"]["sectionNo"]+""+bay_spm[j]["pk"]["bayOffset"]+""+bay_spm[j]["pk"]["deckUnderDeck"]+"' data-sectno='"+bay_spm[j]["pk"]["sectionNo"]+"' data-deck_name='"+bay_spm[j]["pk"]["deckUnderDeck"]+"' data-bay_offset='"+bay_spm[j]["pk"]["bayOffset"]+"' data-template='"+bay_spm[j]["tierTemplate"]+"' contenteditable=false data-fortyfooter='" + bay_spm[j]["isLogicalBay"] + "'>" +bay_spm[j]["vesselBayNo"]+"</td>");
	}
	
	

	$($("#deck_row").find("[data-fortyfooter='Y']")).addClass("fortyFooterLeft fortyfooter");

	$($("#underdeck_row").find("[data-fortyfooter='Y']")).addClass("fortyFooterLeft fortyfooter");

	
	for( var p=0;p<bayrow_spm.length; p++){
		id_saved= (bayrow_spm[p]["pk"]["sectionNo"]).toString() + bayrow_spm[p]["pk"]["bayOffset"] + bayrow_spm[p]["pk"]["deckUnderDeck"] ;
		//console.log(id_saved);
		$("#"+id_saved).css("background","pink");
	}
	
for(var d=0;d<data.bayList.length;d++){
	var sect_no,d_ud;
	sect_no		 = data.bayList[d].pk.sectionNo;
	d_ud		 = data.bayList[d].pk.deckUnderDeck;
	bayOffset	 = data.bayList[d].pk.bayOffset;
	for(var s=0;s<cell_spm.length;s++){
		if(sect_no === cell_spm[s].pk.sectionNo && d_ud === cell_spm[s].pk.deckUnderDeck && bayOffset ===  cell_spm[s].pk.bayOffset){
			cells_bay.push(cell_spm[s]);
		}
	}
	for(var s=0;s<bayrow_spm.length;s++){
		if(sect_no === bayrow_spm[s].pk.sectionNo && d_ud === bayrow_spm[s].pk.deckUnderDeck && bayOffset ===  bayrow_spm[s].pk.bayOffset){
			bayRows_bay.push(bayrow_spm[s]);
		}
	}
	cells_bay_data.push(cells_bay);
	bayRows_bay_data.push(bayRows_bay);
	cells_bay=[];
	bayRows_bay=[];
}
for (var t=0;t<data.bayList.length;t++){
	bay_tuple={};
	bay_tuple["sectionNo"]= data.bayList[t].pk.sectionNo;
	bay_tuple["deckUnderDeck"]= data.bayList[t].pk.deckUnderDeck;
	bay_tuple["vesselBayNo"]= data.bayList[t].vesselBayNo;
	bay_tuple["bayOffset"]= data.bayList[t].pk.bayOffset;
	bay_tuple["tierTemplate"]= data.bayList[t].tierTemplate;
	bay_tuple["cells"]= cells_bay_data[t];
	bay_tuple["bayRows"]= bayRows_bay_data[t];
	bay_array.push(bay_tuple);
	if(bay_tuple["deckUnderDeck"] === "D"){
		deck_bay_array.push(bay_tuple);
	}else if(bay_tuple["deckUnderDeck"] ==="U"){
		underdeck_bay_array.push(bay_tuple);
	}
}
/*var bay_array_combined = $.map(deck_bay_array, function(v, i) { return [v, underdeck_bay_array[i]]; });*/
/*for(var i=0;i<=sect_spm.length;i++){
	$("#bays_images").append('<div class="bay_view" id="'+twodigits(bay_start)+'">'
			+'<div id="'+twodigits(bay_start)+'D" ></div>'
			+'<div id="'+twodigits(bay_start)+'U" ></div></div>');
	bay_start = bay_start + 2;
}*/

for(var i=0;i<bay_array.length;i++){
	$("#bays_images").append('<div class="bay_view" id="'+bay_array[i].vesselBayNo+'">'
			+'<div id="'+bay_array[i].vesselBayNo+'D" ></div>'
			+'<div id="'+bay_array[i].vesselBayNo+'U" ></div></div>');
	
}


for(var i=0;i<bay_array.length;i++){
	if(bay_array[i].tierTemplate == null || bay_array[i].cells == 0){
		$("#"+bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck).remove();
	}
	else{
	var id = bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck;
	if(id[2]==="D"){
		$("#"+id).append('<div style="margin-top: 4%;height:auto;overflow-x: auto;">'
				+'<h1  class="bay_no_h1" style="text-align: center">'+bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck+'</h1>'
				+'<table id="table'+id+'" class="mytable">'
				+'<col><col><colgroup span="3"></colgroup><thead>'
				+'<tr class="tier_value"><th scope="col"></th></tr></thead>'
				+'<tbody id="tbody'+bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck+'"></tbody></table></div>');
	}
	else{
		$("#"+id).append('<div style="margin-top: 4%;height:auto;overflow-x: auto;">'
				+'<table id="table'+id+'" class="mytable">'
				+'<col><col><colgroup span="3"></colgroup><thead style="display:none;">'
				+'<tr class="tier_value"><th scope="col"></th></tr></thead>'
				+'<tbody id="tbody'+bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck+'"></tbody>'
				+'<col><col><colgroup span="3"></colgroup><tfoot>'
				+'<tr class="tier_value"><th scope="col"></th></tr></tfoot></table>'
				+'<h1  class="bay_no_h1" style="text-align: center">'+bay_array[i].vesselBayNo+bay_array[i].deckUnderDeck+'</h1></div>');
	}
	
	getTemplateDetails(bay_array[i].tierTemplate,id);
	var tiers_no =Number(getTierCount(bay_array[i].tierTemplate));
	if(bay_array[i].cells.length === 0){
		$("#"+id).hide();
	}
	else{
		for(var k=0;k<bay_array[i].cells.length;k++){
			$($("#table"+id)[0].rows[(Number(tiers_no)-(Number(bay_array[i].cells[k]["pk"]["tierOffset"])))].cells[(Number((bay_array[i].cells[k]["pk"]["rowOffset"]))+1)]).addClass("selected");
			 }
	}
	}
	 $("#"+id+" tr").each(function(){
		 if($(this).find('td.selected').length === 0){
			$(this)[0].hidden=true;
		 }
	 });
}
if(maxRows % 2 === 0){
	 maxRows = Number(maxRows) + 1;
}
var maxRowsValue = maxRows-1;
$(".tier_value").show();
for(var i=0;i<maxRows;i++){
	//$(".tier_offset").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+i+'</th>');
	if(maxRowsValue>=0){
		$(".tier_value").append('<th colspan="1" scope="colgroup" style="text-align:center">'+twodigits(maxRowsValue)+'</th>');
		maxRowsValue = maxRowsValue -2;
	}
}
for(var i=1;i<maxRows;i=i+2){
		$(".tier_value").append('<th colspan="1" scope="colgroup" style="text-align:center">'+twodigits(i)+'</th>');
}
$(".bay_view").each(function(){
	if($(this).children().length == 0){
		$(this).css("height","0px");
		$(this).css("width","0px");
	}
});
$(".bay_view").each(function(){
	if(($(this).children().first().html() == "") && ($(this).children().last().html() == "")){
		$(this).css("height","0px");
		$(this).css("width","0px");
	}
});

//$('.bay_view').children().attr("class","drawn");

});
