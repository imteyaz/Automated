Ext.QuickTips.init();
Modules.admin.auditlog.popupGridWindow = function(myStoreObj,rowIndex,record)
{
	
	var win = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:'NonOceanAuditLogGridWindowID',//Give some id to window
		gridCompCmc:Ext.getCmp(Modules.CompIds.auditLogQueryGridId),
		title:'Audit Log Record View',
		editableCmc:false,//Set this to false if all the fields should be readOnly
		saveUrlCmc:'',
		saveOrDoneBtnValidateHandlerFuncCmc:'',
		saveExtraParamsCmc:'',
		setFormItemsFuncCmc:function(){
		   
				   var userId =
				   {
						   	xtype: 'cmctextfield',
							name: 'userName',
							fieldLabel: Modules.admin.auditlog.labels.userId,
							width: 150,
							labelWidth: 80,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							readOnly : true
				   };
				   var moduleName =
				   {
						   	xtype: 'cmctextfield',
							name: 'moduleName',
							fieldLabel:Modules.admin.auditlog.labels.moduleName,
							width: 150,
							labelWidth: 80,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							readOnly : true
				   };
				   var functionName =
				   {
						   	xtype: 'cmctextfield',
							name: 'functionName',
							fieldLabel: Modules.admin.auditlog.labels.functionName,
							width: 150,
							labelWidth: 85,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							readOnly : true
				   };
				   var applnServeName =
				   {
						   	xtype: 'cmctextfield',
							name: 'hostName',
							fieldLabel: Modules.admin.auditlog.labels.applnServeName,
							width: 250,
							labelWidth: 110,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							readOnly : true,
							listeners: {
								 render: function(c) {
									  Ext.QuickTips.register({
										target: c.getEl(),
										text: 'Application Server Name'
									  });
									},
				                    select: function () {
				                    	
				                    }
				                }	
				   };
				  
				   var fromDate =
				   {
						   	xtype: 'cmcdatefield',
							name: 'startDate',
							fieldLabel:Modules.admin.auditlog.labels.startDate,
							width:150,
							labelWidth: 80,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							format:Modules.GlobalVars.dateTimeFormatGlobal,
							readOnly : true
				   };
				   var toDate =
				   {
						   	xtype: 'cmcdatefield',
							name: 'exitDate',
							fieldLabel: Modules.admin.auditlog.labels.endDate,
							width:150,
							labelWidth: 85,
							labelAlign:"left",
							margin : '5px 0px 5px 15px',
							labelSeparator:'',
							format:Modules.GlobalVars.dateTimeFormatGlobal,
							readOnly : true
				   };
				   
				  
				    var anotherLayout = [{
				    	 xtype:'container',
				    	 layout:'column',
				    	 defaults:{
				    		 margin : '15px 10px 0px 15px'
				    	 },
				    	 items:[
				    	   {
				    		   columnWidth:.5,
				    		   xtype:'container',
				    		   layout:'form',
				    		   items:[userId,moduleName,fromDate]
				    	   },
				    	   {
				    		   columnWidth:.5,
				    		   xtype:'container',
				    		   layout:'form',
				    		   items:[functionName,toDate]
				    	   }
				    	 ]
				    	
				    }];
				return anotherLayout;			 
			   }
	});	

	return win;//Returning the window object ultimately from the funciton
	
	
	
	   
	};