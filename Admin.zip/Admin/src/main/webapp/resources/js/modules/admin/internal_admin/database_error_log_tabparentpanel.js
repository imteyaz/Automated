Modules.admin.internalAdmin.databaseErrorLog.tabparentpanel = function(menu) {
	var panel={
			xtype:'cmctabparentpanel',
			title:'Database Error Log', 
			id:Modules.CompIds.internalAdminDatabaseErrLogPanelId,
			/*clearBtnObjCmc:{
				id: 'oceanClearButton',
				handler:function(){
				return true;
				}
			},
			retrieveBtnObjCmc:{
				handler:function(){
					Ext.getCmp('invoiceGridId').getStore().load();
					Ext.getCmp('dummyInvoiceGridId').getStore().load();
					return true;
				}
			},*/
			showNorthItemCmc:true,
			setNorthItemFuncCmc:Modules.admin.internalAdmin.databaseErrorLog.form,
			setCenterItemFuncCmc:Modules.admin.internalAdmin.databaseErrorLog.Grid
			
	};	
	return panel;
};
