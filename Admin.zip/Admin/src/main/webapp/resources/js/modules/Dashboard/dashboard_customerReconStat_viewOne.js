/**
 * Customer Recon Stat View One
 */

Modules.Dashboard.customerReconStatViewOne = function(myStoreObj,rowIndex,record)
{
	var viewCustomerReconStatGridOne = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:Modules.CompIds.viewCustomerReconWinObjOneId,//Give some id to window
		gridCompCmc:Ext.getCmp('DbCustomerReconStatGridOneId'),//Pass the component of grid at which this window will be opened
		title:'Customer Reconciliation Status View',
		editableCmc:false,//Set this to false if all the fields should be readOnly
		height : 370,
		width: 550,
		setFormItemsFuncCmc:function(){//This function should return the form items.
						 
			var itemsArr = [];
				   
				   var customerCd ={
							xtype: 'cmctextfield',
							id: 'customerCd',
							name: customerCd,
							fieldLabel: 'Customer',
							width:200,
							labelWidth:85,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true
						
					};
				
				   var currency ={
							xtype: 'cmctextfield',
							id: 'currency',
							name: currency,
							fieldLabel: 'Currency',
							width:200,
							labelWidth:85,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true						
					};
				   
				   var zeroRtdEvntCntWithDlvryDt ={
							xtype: 'cmctextfield',
							id: 'zeroRtdEvntCntWithDlvryDt',
							name: zeroRtdEvntCntWithDlvryDt,
							fieldLabel: 'Zero Rated Event Count With Delivery Date',
							width:400,
							labelWidth:250,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true							
					};
				
				   var count1Day ={
						   xtype: 'cmcnumberfield',
							id: 'count1Day',
							name: 'count1Day',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'					
					};
				   var amount1Day ={
						   xtype: 'cmcnumberfield',
							id: 'amount1Day',
							name: 'amount1Day',
							forcePrecision: true, 
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Amount'				
					};
				   var count2_5Days ={
						   xtype: 'cmcnumberfield',
							id: 'count2_5Days',
							name: 'count2_5Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'						
					};
				   var amount2_5Days ={
						   xtype: 'cmcnumberfield',
							id: 'amount2_5Days',
							name: 'amount2_5Days',
							forcePrecision: true, 
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Amount'					
					};
				   var count6_15Days ={
						   xtype: 'cmcnumberfield',
							id: 'count6_15Days',
							name: 'count6_15Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'					
					};
				   var amount6_15Days ={
						   xtype: 'cmcnumberfield',
							id: 'amount6_15Days',
							forcePrecision: true, 
							name: 'amount6_15Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Amount'
						
					};
				   var count16_30Days ={
						   xtype: 'cmcnumberfield',
							id: 'count16_30Days',
							name: 'count16_30Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'				
					};
				   var amount16_30Days ={
						   xtype: 'cmcnumberfield',
							id: 'amount16_30Days',
							name: 'amount16_30Days',
							forcePrecision: true, 
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Amount'				
					};
				   var countG30Days ={
						   xtype: 'cmcnumberfield',
							id: 'countG30Days',
							name: 'countG30Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'						
					};
				   var amountG30Days ={
						   xtype: 'cmcnumberfield',
							id: 'amountG30Days',
							forcePrecision: true, 
							name: 'amountG30Days',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Amount'					
					};
				   
				   	
				
				   var sendMsgContainer={
						   xtype:'container',
						   layout:'vbox',
						   items:[customerCd,currency,zeroRtdEvntCntWithDlvryDt]
				   };
				   
				   var tablePanle = {
						   layout: {
						        type: 'table',
						        columns: 3
						    },
						    width:500,
						    defaults: {
						        // applied to each contained panel
						        bodyStyle: 'padding:20px',
						        width:90,
								labelWidth:100,
								labelAlign:"left",
								margin : '5px 50px 5px 30px',
								labelSeparator:'',
								readOnly:true,
								hideLabel:true
						    },
						    items: [
						            {xtype:'label',text:'Days'},{xtype:'label',text:'Count'},{xtype:'label',text:'Amount'},
						            {xtype:'cmctextfield',value:'1'},count1Day,amount1Day,
						            {xtype:'cmctextfield',value:'2-5 '},count2_5Days,amount2_5Days,
						            {xtype:'cmctextfield',value:'6-15'},count6_15Days,amount6_15Days,
						            {xtype:'cmctextfield',value:'16-30'},count16_30Days,amount16_30Days,
						            {xtype:'cmctextfield',value:'>30'},countG30Days,amountG30Days,
						            ]
						    }; 	
						   itemsArr = [sendMsgContainer,tablePanle];
					return itemsArr;			 
		   }
  });
  return viewCustomerReconStatGridOne;
  };
	
	
