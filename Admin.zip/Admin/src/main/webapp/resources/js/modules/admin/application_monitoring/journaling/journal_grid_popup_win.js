Ext.QuickTips.init();
Modules.admin.journal.popupGridWindow = function()
{		
	var win = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:Modules.CompIds.popupCustomerRateQueryId,//Give some id to window
		gridCompCmc:Ext.getCmp(Modules.CompIds.journalGridId),//Pass the component of grid at which this window will be opened
		title:Modules.LblsAndTtls.JournalGridTtl,
		editableCmc:false,//Set this to false if all the fields should be readOnly
//		saveUrlCmc:'',//Put the URL for save here if the window will save data to server. If no URL specified then data will be saved to grid locally
		saveOrDoneBtnValidateHandlerFuncCmc:'',//This should be a function specified in instance. It will be called in save or done button handler and will be used for instance specific validations like duplication check. It should return true or false for sure.
		saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server if requried
		width:800,
		setFormItemsFuncCmc:function(){
			   var itemsArr = [];
			   
			   var dateOrTime =
			   {
					   	xtype: 'cmcdatefield',
						name: 'dateOrTime',
						fieldLabel: Modules.admin.journal.labels.dateOrTime,
						width:250,
						labelWidth:85,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true,
						format:Modules.GlobalVars.dateTimeFormatGlobal
			   };
			   var userId =
			   {
					   	xtype: 'cmctextfield',
						name: 'userId',
						fieldLabel:Modules.admin.journal.labels.userID,
						width:210,
						labelWidth:75,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			   var eDIPartnerOrModule =
			   {
					   	xtype: 'cmctextfield',
						name: 'eDIPartnerOrModule',
						fieldLabel: Modules.admin.journal.labels.ediPartnerOrModule,
						width:250,
						labelWidth:125,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			   var action =
			   {
					   	xtype: 'cmctextfield',
						name: 'action',
						fieldLabel: Modules.admin.journal.labels.action,
						width:250,
						labelWidth:85,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			  
			   var fieldName =
			   {
					   	xtype: 'cmctextfield',
						name: 'feildName',
						fieldLabel: Modules.admin.journal.labels.fieldName,
						width:250,
						labelWidth:76,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			   var loadRefNo =
			   {
					   	xtype: 'cmctextfield',
						name: 'loadRefNo',
						fieldLabel: Modules.admin.journal.labels.loadReferenceNumber,
						width:250,
						labelWidth:76,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true,
						listeners: {
							render: function(c) {
								 Ext.QuickTips.register({
									target: c.getEl(),
									text:'Load Reference Number'
								});
							}
						}
			   };
			   var invoiceNoORUnitId =
			   {
					   	xtype: 'cmctextfield',
						name: 'unitId',
						fieldLabel: Modules.admin.journal.labels.invoiceNoOrUnitID,
						width:250,
						labelWidth:125,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true,
						listeners: {
							render: function(c) {
								 Ext.QuickTips.register({
									target: c.getEl(),
									text:'Invoice Number / Unit ID'
								});
							}
						}
			   };
			   var oldValue =
			   {
					   	xtype: 'cmctextfield',
						name: 'oldValue',
						fieldLabel: Modules.admin.journal.labels.oldValue,
						width:250,
						labelWidth:76,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			   var newValue =
			   {
					   	xtype: 'cmctextfield',
						name: 'newValue',
						fieldLabel: Modules.admin.journal.labels.newValue,
						width:250,
						labelWidth:76,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true
			   };
			   
			    var anotherLayout = [{
			    	 xtype:'container',
			    	 layout:'column',
			    	 defaults:{
			    		 margin : '15px 0px 0px 15px'
			    	 },
			    	 items:[
			    	   {
			    		   columnWidth:.5,
			    		   xtype:'container',
			    		   layout:'form',
			    		   items:[dateOrTime,eDIPartnerOrModule,fieldName,invoiceNoORUnitId,oldValue]
			    	   },
			    	   {
			    		   columnWidth:.5,
			    		   xtype:'container',
			    		   layout:'form',
			    		   items:[userId,action,loadRefNo,newValue]
			    	   }
			    	 ]
			    	
			    }];
			return anotherLayout;}
		});	
		return win;//Returning the window object ultimately from the funciton
	
};