
Modules.admin.user_admin.group_user_security.southGrid = function (mergeObj) {
	var buttons=mergeObj.buttons;
	
	var userFormObject = {
			xtype: 'cmcform',
			bodyStyle: 'background-color: #FFFFFF',
			title: 'User Query Parameters',
			showFieldsetCmc: false,
			collapsible : true,
			collapsed : true,
			region:'north',
			height:80,
			width : 1000,
			itemId : 'userSearchFormItemId',
			setFormItemsFuncCmc: function () {
				var itemsArr = [];
				
				var userNameField = {
						xtype : 'cmctextfield',
						width:200,
						name : 'userNameField',
						itemId:'userNameField',
						labelWidth : 70,
						labelAlign:"right",
						fieldLabel : 'User Name'
					};
				
				var fullNameField = {
						xtype : 'cmctextfield',
						width:350,
						name : 'fullNameField',
						itemId:'fullNameField',
						labelWidth : 70,
						labelAlign:"right",
						fieldLabel : 'Full Name'
					};
				
				
				
				
				var statusStore={
						model: 'GenericLookUpDTO',
						fields: ['code', 'name'],
						queryTypeCmc:'local',			
						data :[
							   {"code":"A", "name":"ACTIVE"},
							   {"code":"D", "name":"INACTIVE"}
							 ]		
					};
				
				var statusField = {
						xtype: 'cmccombobox',
						fieldLabel: 'Status',
						name : 'statusField',
						itemId:'statusField',
						width: 150,
						labelWidth: 45,
						labelAlign:"right",
						storeObjCmc: statusStore,
					    queryMode: 'local',
					    hideTrigger:false,
					    typeAhead:false,
					    paging: false,
						selectOnTab: false,
					    displayField: 'name',
					    valueField: 'code',
						matchFieldWidth: false,
						listConfig: {
							width: 250,
							loadingText: Modules.Msgs.loading,
							height: 300,
							deferEmptyText: false,
							emptyText: Modules.Msgs.noComboValueFound,
							getInnerTpl: function () {
								return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="150px" align="left">{name}</td> </tr></table>';
							}
						}
					};
				
				var userFilterField= {
				    	xtype: "button",
						text:'Filter',
						itemId : 'filter',
						name : 'filter',
						icon : 'resources/images/filter.png',
						width: 85,
						handler:function(){
							var searchObj=this.up('#userSearchFormItemId').getForm().getValues(false,false);
							var store=Ext.getCmp('AdminUserGridId').getStore();
							store.proxy.extraParams={};
							Ext.apply(store.proxy.extraParams,searchObj);
							store.loadPage(1);
						}
				};
				
				var container1 = {
						xtype: 'container',
						layout: 'hbox',
						labelAlign:"left",
						margin: '10px 10px 10px 0px',
						defaults:{
							margin:'0px 30px 0px 0px'
						},
						items : [userNameField,fullNameField,statusField,userFilterField]
				};	
				var itemsArr = [container1];
				return itemsArr;
			}
		};
	
	
	
	
	Modules.admin.user_admin.group_user_security.reloadGrids = function(){							
		Ext.getCmp('AdminUserGridId').resetDataCmc();
	};
	var userGridStore = {
		model: 'UserModel',
		autoLoad : true,
		url: 'admin/getUserDtls',
		paging : true,
		queryTypeCmc : 'remote',
		listeners : {
			beforeload : function() {
					this.proxy.extraParams.companyCode=Modules.GlobalVars.selectedCompanyCode;
				    this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
				    this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.userType = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
					var limitVal = Ext.getCmp('AdminUserGridId').getComponent('centerGridPagingToolBarItemId').getComponent('perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				
			}
		}
	};
	var userGrid = {
		xtype: 'cmcgrid',
		storeObjCmc: userGridStore,
		title: 'User Details',
		id: 'AdminUserGridId',
		showPagingBarCmc: true,
		minHeight: 80,
		region:'center',
		showLeftExtraTbarCmc : true,
		showExtraTbarCmc : true,
		showSelModelCmc:true,
		showTotalSelectedCmc:true,
		showTotalCountCmc : true,

		viewConfig : {
			stripeRows : true
		},
		listeners : {
			cellclick : function(viewObj, td, cellIndex, record, tr, rowIndex,eventObj) {
				if (cellIndex == '1' && buttons.indexOf("AUMMDU")>= 0) { 
					var body = Ext.getBody();
					body.mask(Modules.Msgs.processing);
						Ext.Ajax.request({
							url : 'oceanUserManagement/getOceanUserDetails',
							params : {
								userId : record.get('userId')//,
								//serviceType : record.get('serviceTypeGroupCode')			
							},
							timeout : 120000,
							success : function(response) {
								body.unmask();
								//if success == true
								var responseData = Ext.decode(response.responseText);
								if(responseData.success == true){
									var window =	Modules.ocean.admin.user_admin.user_management.window({action : 'EDIT',record : responseData.items[0]});
									window.show();
								}
							},
							failure : function(response) {
								body.unmask();
							}
						});
					
				}
			}
		},
		setLeftExtraTbarFuncCmc : function() {
			var buttonArray = [{
				text : "Properties",
				iconCls : "properties",
				hidden : buttons.indexOf("AUMMDU")< 0,
                handler : function() {
                	var gridObj = Ext.getCmp('AdminUserGridId');
					if (gridObj.getStore().getCount() > 0){
						var sm = gridObj.getSelectionModel().getSelection();
						if(sm.length == 1){
							var selectedRecord =gridObj.getSelectionModel().getLastSelected();
							if(selectedRecord){
								Ext.getBody().mask(Modules.Msgs.processing);
								Ext.Ajax.request({
									url : 'oceanUserManagement/getOceanUserDetails',
									params : {
										userId : selectedRecord.data.userId//,
										//serviceType : selectedRecord.data.serviceTypeGroupCode			
									},
									timeout : 120000,
									success : function(response) {
										Ext.getBody().unmask();
										var responseData = Ext.decode(response.responseText);
										if(responseData.success == true){
											var window =	Modules.ocean.admin.user_admin.user_management.window({action : 'EDIT',record : responseData.items[0]});
											window.show();
										}
									},
									failure : function(response) {
										Ext.getBody().unmask();
									}
								});
							}
						} else if(sm.length > 1){
							Ext.MessageBox.show({
                                msg: 'Please select only one record.',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						} else {
							Ext.MessageBox.show({
                                msg: Modules.Msgs.selRecFrst,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					} else {
						Ext.MessageBox.show({
                            msg: Modules.Msgs.noRecordsPropeties,
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}
				}
			},{
				text : "New User",
				iconCls : "new_user",
				hidden : buttons.indexOf("AUMCRU")< 0,
                handler : function() {
                	var window =	Modules.ocean.admin.user_admin.user_management.window({action : 'ADD'});
                	window.show();
				}
			}, {
				text : "Delete User",
				iconCls : "delete_user",
				hidden : buttons.indexOf("AUMDLU")< 0,
				handler : function() {
					var gridObj = Ext.getCmp('AdminUserGridId');
					if (gridObj.getStore().getCount() > 0){
						var sm = gridObj.getSelectionModel().getSelection();
						if(sm.length == 1){
							var deleteMsg="This action deletes all the associations of the User and that information is unrecoverable. Do you want to continue?";
		                	Ext.Msg.confirm( Modules.Msgs.confirmTitle, deleteMsg, function( answer ) {
				                if( answer == "yes" ) {					                
				                	var selectedRecord =gridObj.getSelectionModel().getLastSelected();
									 if(selectedRecord){
										 	Ext.Ajax.request({
												url:'oceanUserManagement/deleteOceanUserDetails',
												params:{
													'userId' : selectedRecord.data.userId//,
													//serviceTypeCode : selectedRecord.data.serviceTypeGroupCode
												},
												method:'GET',
												success:function(response){
													var respObj			=	Ext.JSON.decode(response.responseText);
													if(respObj.status == 'success'){
												     Ext.getCmp('AdminUserGridId').getStore().remove(selectedRecord);
														Ext.MessageBox.show({
															msg: "Deleted successfully",
															buttons: Ext.MessageBox.OK,
															icon: Ext.MessageBox.INFO
														});
														
													}else if(respObj.status == 'failure'){
														Ext.MessageBox.show({
															msg: "Error : "+respObj.error,
															buttons: Ext.MessageBox.OK,
															icon: Ext.MessageBox.INFO
														});
													}
												},
												failure:function(){
												}
											});
									 }
				                }
		                	});					                					                	
		                } else if(sm.length > 1){
							Ext.MessageBox.show({
                                msg: 'Please select only one record.',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}  else {
		                	Ext.MessageBox.show({
                                msg: Modules.Msgs.selRecFrst,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
		                }				                
					}
					else{
						Ext.MessageBox.show({
                            msg: Modules.Msgs.noRecordsDelete,
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}						
				}
			
			} , {
				text : "Copy User",
				iconCls :  "copy_user",
				hidden : buttons.indexOf("AUMCOU")< 0,
				handler : function() {
					    var gridObj = Ext.getCmp('AdminUserGridId');
						var sm = gridObj.getSelectionModel().getSelection();
						if (gridObj.getStore().getCount() > 0){
							if(sm.length == 1){
			                	var selectedRecord =gridObj.getSelectionModel().getLastSelected();
								if(selectedRecord){
									Ext.getBody().mask(Modules.Msgs.processing);
									 Ext.Ajax.request({
										 url : 'oceanUserManagement/getOceanUserDetails',
										 params : {
											 userId : selectedRecord.data.userId//,
											 //serviceType : selectedRecord.data.serviceTypeGroupCode			
										 },
										 timeout : 120000,
										 success : function(response) {
											 Ext.getBody().unmask();
											 //if success == true
											 var responseData = Ext.decode(response.responseText);
											 if(responseData.success == true){
												 var window =	Modules.ocean.admin.user_admin.user_management.window({action : 'COPY',record : responseData.items[0]});
												 window.show();
											 }
										 },
										 failure : function(response) {
											 Ext.getBody().unmask();
										 }
									 });
								}
							}else if(sm.length > 1){
								Ext.MessageBox.show({
	                                msg: 'Please select only one record.',
	                                buttons: Ext.MessageBox.OK,
	    	                        icon: Ext.MessageBox.INFO
	                            });
							}  else {
			                	Ext.MessageBox.show({
	                                msg: Modules.Msgs.selRecFrst,
	                                buttons: Ext.MessageBox.OK,
	    	                        icon: Ext.MessageBox.INFO
	                            });
			                }
					}
				}
			} ];
			return buttonArray;
		},
		
		setGridColumnsFuncCmc: function () {
			var colsArr = [
			{
				header: 'User Name',
				width : 250,
				dataIndex: 'userName'
			},{
				header: 'Full Name',
				width : 250,
				dataIndex: 'userFullName'
			},{
				header: 'Status',
				width : 105,
				dataIndex: 'userStatus'
			},{
				header: 'User Description',
				width : 350,
				dataIndex: 'userDesc'
			}/*,{
				header: 'Service Type',
				width : 350,
				dataIndex:'serviceTypeGroupDescription'
			}*/];
			
			
			if(buttons.indexOf("AUMMDU")>= 0){
				colsArr.splice(0,0,{ // any queries contact Prasad
					xtype : 'actioncolumn',
					width : 30,
					sortable : false,
					hideable : false,
					align : 'center',
					items : [ {
						icon : 'resources/images/editView.jpg',
						tooltip : Modules.LblsAndTtls.tooltip.editWin,
						handler : function(grid, rowIndex, colIndex) {
							return true;
						}
					} ]
				});
			}
			
			
			
			
			return colsArr;
		}
	};
	//return userGrid;
	
	var  southUserContainer= {
			collapsible:false,
			xtype:'panel',
			height : 250,
			layout:'border',
			items:[userFormObject ,userGrid ]
		};
	return southUserContainer;
	
	
	

}; //EOF