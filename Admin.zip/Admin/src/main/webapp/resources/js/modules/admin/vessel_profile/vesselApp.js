	
Modules.GlobalFuncs.vesselAppStartup = function(userId){
	
	// Prepare menu
	Modules.GlobalVars.appVersion = '1.4.1';
	
	var preapareMenu = function(){
		
		Ext.getBody().mask('Preparing menu...');

	};
	
	var prepareViewport = function(staticJSON,mainData){
		
		staticJSON = staticJSON || [];
		mainData =  mainData || [];
		
		new Ext.Viewport({
			layout : "border",
			id: 'masterViewportId',
			items:[	{
				region: 'north',
				xtype: 'panel',
				layout:'column',
				height: 55,
				bodyCls : 'x-toolbar-sencha',
				items : staticJSON

			}, {
				xtype: "cmctabpanel",
				region: 'center',
				id:'centerPanelId',
				layout: 'fit',
				tbar : Ext.create('Ext.toolbar.Toolbar', {
					id : 'MainToolbarId',
					cls:'main-toolbar-headerbg',
					layout : {
						overflowHandler : 'Menu'
					},
					items : mainData // this will be menu
				}),
				listeners:{
					render:function(){
						showDashboardScreen();
					},
					tabchange:function(tab,newCard,oldCard){
						
					}
				},
				items : [ ]
			}
			]
		});
	};
	//Modules.GlobalVars.loginUserName = 'User 1';
	
	var headerMenu = [{
	    	   xtype: 'component',
	    	   cls: 'minapro-logo',
	    	   columnWidth:.65
	    	   },
	    	   {
	    		   xtype: 'image',
	    		   fieldLabel: 'DPW',
	    		   margins : '0 5 0 0',
	    		   cls: 'dpw-logo',
	    		  // columnWidth:.26
	    		   /*width: 50,  15px 46px 3px 51px
	    		       height: 50*/
	    		   },
	    	  {
		       xtype:'container',
		       layout:'column',
		       margin:'2px 0px 2px 0px',
		       columnWidth:.35,
		       defaults:{
		    	margin:'0px 5px 5px 0px'
		       },
		       items:[ {
				xtype : 'label',
				forId : 'versiodId',
				style:'color:#FFFFFF;',
				text :  'Version: '+Modules.GlobalVars.appVersion,
				margins : '0 5 0 0',
				columnWidth:.3
			},{
				xtype : 'label',
				forId : 'myFieldId',
				style:'color:#FFFFFF;',
				text : 'Welcome: '+Modules.GlobalVars.loginUserName,
				margins : '0 10 0 0',
				columnWidth:.36
			},{
        	   xtype: 'button',
        	   iconCls: 'help-icon',
        	   text:'Help',
        	   columnWidth:.15,
        	   handler: function() {
			    }
    	   },{
				xtype : "button",
				iconCls : "logout-icon",
				text:'Logout',
				columnWidth:.18,
				handler: function() {
					Ext.Msg.confirm('Logout', 'Are you sure you want to logout?', function(btn){
						if (btn === 'yes'){
							window.location =  contextPath + '/user/logout' ;
						}
					});
			    }
			}]}
			];
	
	prepareViewport(headerMenu);
	//loadUserDetails();

};