	
Modules.admin.internalAdmin.databaseErrorLog.form = function() {
	var hostStore={
			model: 'GenericLookUpDTO',
			queryTypeCmc:'remote',
			url:'getHostNameList', 
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
				}
			}
	};
	var ErrorFnDesStore={
			model: 'GenericLookUpDTO',
			queryTypeCmc:'remote',
			url:'getErrorFnDesList',
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
				}
			}
	};
	
	
	

	
	var form = {
		xtype: 'cmcform',
		title: Modules.ocean.internalAdminDatabaseErrorLogTtl,
		id: Modules.CompIds.internalAdminDatabaseErrorLogFormId,
		width: 1000,
		height: 120,
		bodyStyle: 'background-color: #FFFFFF',
		listeners:{
			afterrender:function(){
				Modules.GlobalFuncs.getDefaultCriteriaPopulate(Modules.GlobalVars.internalAdminDatabaseErrorLogScreenId);
			}
		},
		showFieldsetCmc: false,
		plugins:[{ ptype: 'saveretrievecriteria', screenId:Modules.GlobalVars.InternalAdminDatabaseErrorLogScreenId, index:3}],
		tbar:[{
			text:Modules.LblsAndTtls.clearActionTtl,
			xtype:"button",
			iconCls:"clear",
			id:Modules.CompIds.internalAdminDatabaseErrorLogClearActionId,
			handler:function(){
					this.ownerCt.ownerCt.getForm().reset();
		            Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).resetDataCmc();
			}
		},{
			xtype: "button",
			text:Modules.LblsAndTtls.retrieveActionTtl,
			iconCls:"retrieve",
			id:Modules.CompIds.internalAdminDatabaseErrorLogRertrieveActionId,
			getValidationMsg : function(){
				var form =  this.up('form');
				var searchObj =form.getForm().getValues(false,true);
				if(Modules.GlobalFuncs.isEmptyObj(searchObj)){
					return Modules.contract.customer_rate_query.messages.enterCriteria;
				}
				return '';
           },
			handler:function(){
				if(Modules.GlobalVars.selectedCompanyCode != null){	
					var errorMsg = this.getValidationMsg();
					if(!Ext.isEmpty(errorMsg)){
						Ext.MessageBox.show({
                            title: '',
                            msg: errorMsg,
                            buttons: Ext.MessageBox.OK,
                            icon:Ext.MessageBox.ERROR
                       });
					}
					else{
							Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getStore().removeAll();
							Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getStore().load({
								callback: function(records, operation, success) {
			                         if(success == true)
			                         {
			                        	 var count = Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId).getStore().getCount();
				                            if(count == 0){
				                            	Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrLogExcelReportId).disable();
				            	            	Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrLogPDFReportId).disable();
				            	            	Ext.MessageBox.show({
				                                     title: '',
				                                     msg: Modules.Msgs.noDataInGrid,
				                                     buttons: Ext.MessageBox.OK,
				                                     icon:Ext.MessageBox.INFO
				                                });
				                            }
				                            else{
				                            	Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrLogExcelReportId).enable();
				            	            	Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrLogPDFReportId).enable();
				                            }  
			                         }
								}
							});
					}
				}
				else{
					Ext.MessageBox.show({
                        title: '',
                        msg: Modules.Msgs.ValidationCorrectValue,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                   });
				}		
				}	
			
		},{
			xtype:"tbfill"
		}],
		
		setFormItemsFuncCmc: function () {
			var itemsArr = [];
		
			var userNameLOV = Modules.LovFactory.getUserNameLov({
				id: Modules.CompIds.internalAdminDatabaseErrorLogUserNameId,
				width: 300,
				name: 'userName',
				labelWidth: 180,
				labelAlign : 'left'
			});
			
			
			
			var hostCombo = {
					xtype: 'cmccombobox',
					id: Modules.CompIds.internalAdminDatabaseErrorLogHostNameId,
					name: 'hostName',
					storeObjCmc: hostStore,
					selectOnTab: true,
					width: 300,
					labelWidth: 150,
					labelAlign : 'left',
					fieldLabel: Modules.LblsAndTtls.hostName,
					maxLength: 40,
					displayField: 'name',
					valueField: 'name',
					matchFieldWidth: false,
					paging:true,
					columnsCmc:[
		                        {
		                        	header:'Name',
		                        	width:170,
		                        	dataIndex:'name'
		                        }]
				};
			var fromDate = {
					xtype: 'cmcdatefield',
					id: Modules.CompIds.internalAdminDatabaseErrorLogErroLogDateId,
					name: 'errorLogDate',
					fieldLabel: Modules.LblsAndTtls.errorLogDate,
					width: 300,
					labelWidth: 150,
					labelAlign : 'left'
				};
			
			var ErrorFnDesCombo = {
					xtype: 'cmccombobox',
					id: Modules.CompIds.internalAdminDatabaseErrorLogErrFnDesId,
					name: 'errorFnDes',
					fieldLabel: Modules.LblsAndTtls.errorFnDescription,
					storeObjCmc: ErrorFnDesStore,
					width: 400,
					labelWidth: 180,
					labelAlign : 'left',
					maxLength: 120,
					triggerAction: 'all',
					selectOnTab: true,
					typeAhead: true,
					allowBlank: true,
					displayField: 'name',
					valueField: 'name',
					matchFieldWidth: false,
					paging:true,
					columnsCmc:[
			                        {
			                        	header:'Name',
			                        	width:170,
			                        	dataIndex:'name'
			                        }]
				};
			
			var container1 = {
				xtype: 'container',
				layout: 'hbox',
				margin: '4px 4px 4px 4px',
				defaults:{
					margin:'0px 20px 0px 10px'
				},
				items: [fromDate,userNameLOV]
			};
			
			var container2 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '4px 4px 4px 4px',
					defaults:{
						margin:'0px 20px 0px 10px'
					},
					items: [hostCombo, ErrorFnDesCombo]
				};
			
			itemsArr = [container1,container2];
			return itemsArr;
		}
	};
	return form;
};