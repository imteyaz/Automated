
Modules.admin.user_admin.group_user_security.deniedMenuWindow = function (argObj) {
	
	Modules.admin.user_admin.group_user_security.deniedMenuForm=function(){
	var form={
		xtype: 'cmcform',
		itemId: 'deniedMenuQueryForm',
		width: 900,
		height: 80,
		bodyStyle: 'background-color: #FFFFFF',
		showFieldsetCmc: false,
		
		setFormItemsFuncCmc: function () {
			var itemsArr = [];
			
			var groupNameField = {
					xtype : 'cmctextfield',
					name : 'groupName',
					itemId : 'groupName',
					width: 400,
					labelWidth: 100,
					labelAlign:"right",
					fieldLabel : Modules.admin.user_admin.user_management.labels.groupName//'Group Name'
				};
			
			var serviceNameField = {
					xtype : 'cmctextfield',
					name : 'serviceTypeDesc',
					itemId : 'serviceTypeDesc',
					width: 400,
					labelWidth: 100,
					labelAlign:"right",
					fieldLabel : Modules.admin.user_admin.user_management.labels.serviceType//'Service Type'
				};
			
			
			var container1 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '5px 5px 5px 5px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [groupNameField]
			};	
			itemsArr = [container1];
			return itemsArr;
			
		}
	};
	return form;
	};	
	
	
	
	
	var win = Ext.create('Ext.cmc.Window', {
		height:600,
		width: 900,
		title: Modules.admin.user_admin.user_management.labels.groupToMenuAssociation,//'Group To Menu Association',
		id: 'DeniedMenuWindowId',
		modal :true,
		winFuncArgObjCmc:argObj,
		buttonAlign: "center",
		buttons: [{
		           xtype : 'button',
		           text : Modules.admin.user_admin.user_management.labels.ok,//'OK',
		           handler : function(){
		        	   
			        	var leftGridStore=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
                        var store=Ext.getCmp(Modules.CompIds.deniedMenuGridId).getStore();
                        var serviceTypeCode=argObj.record.serviceTypeCode;
                        var obj=Ext.getCmp(Modules.CompIds.groupWindowId).wingroupAssociatedObj;
                        var treeGrid=Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId);
        	    		var selectedRecord=treeGrid.getSelectionModel().getLastSelected().data;
                        // Updating grid store with selected access codes
		        	    leftGridStore.each(function(outerRecord,index,count){
		        	    	var record=store.findRecord('code',outerRecord.data.code);
		        	    	outerRecord.data.accessCode=record.data.accessCode;
		        	    });
		        	    
		        	    // Updateing javascript cache object with selected access codes is useful in case of EDIT and COPY
                          if(obj[serviceTypeCode] != undefined && obj[serviceTypeCode].moduleList != undefined)	{
		        	    	Ext.Array.each(obj[serviceTypeCode].moduleList,function(servObj,index,me){
								for(var array in servObj){
									if(array == selectedRecord.code){
                                           Ext.Array.each(servObj[array],function(object){
											var record=store.findRecord('code',object.code);
					        	    		object.accessCode=record.data.accessCode;
										});
									}
								}
		        	    	});
		        	        }
                          
                          
                          
                          
                        var funcAccessCodesObj=Ext.getCmp(Modules.CompIds.groupWindowId).funcAccessCodesObj;
                        var isExisted=false;

  			    		if(!funcAccessCodesObj[serviceTypeCode]){
  			    			funcAccessCodesObj[serviceTypeCode]={};
  			    		}
  			    		if(!funcAccessCodesObj[serviceTypeCode].moduleList){
  			    			funcAccessCodesObj[serviceTypeCode].moduleList =[];

  			    		}
  			    		
  			
                          
                          //Preparing associated functions
  			    		Ext.Array.each(funcAccessCodesObj[serviceTypeCode].moduleList,function(object,index,me){
  			    			 for (var prop in object) {
  			    				 if(prop && (prop == selectedRecord.code)){
  			    					 var temp=[];  //Updating cached object with new access codes
  			    					 store.each(function(record,index,count){
  			    						 temp.push(record.data);
  			    					 });
  			    					 object[selectedRecord.code]=temp;
  			    					 isExisted=true;
  			    					 break;
  			    				 }
  			    			   }
  			    			});
  			    		
  			    		if(!isExisted){  // If selected Module is not cached, then we will insert a new functionAccessCodeObject
							var module={};
		    			    var temp=[];
		    			    store.each(function(record,index,count){
		    						 temp.push(record.data);
		    					 });
	    					module[record.code]=temp;
	    					funcAccessCodesObj[serviceTypeCode].moduleList.push(module);
                         }
  			    	  win.close();
		        	  }
		        	  
		          }],
	    showNorthItemCmc: true,
		setNorthItemFuncCmc:Modules.admin.user_admin.group_user_security.deniedMenuForm,
		setCenterItemFuncCmc: Modules.admin.user_admin.group_user_security.deniedMenuGrid,
		listeners: {
			afterrender:function(){
				var me		=		this;
		        var form=me.child('#deniedMenuQueryForm');
		        form.getForm().setValues(argObj.record);

		        form.down('#groupName').setReadOnly(true);
	        //	form.down('#serviceTypeDesc').setReadOnly(true);
                var store=Ext.getCmp(Modules.CompIds.deniedMenuGridId).getStore();
	        	var leftGridStore=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
                var serviceTypeCode=argObj.record.serviceTypeCode;
                var obj=Ext.getCmp(Modules.CompIds.groupWindowId).wingroupAssociatedObj;
                var treeGrid=Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId);
	    		var selectedRecord=treeGrid.getSelectionModel().getLastSelected().data;
	         
	    		
	    		
	    		
	    	
	    		

	    		var modifiedFunctions=[];
				 leftGridStore.each(function(record,index,count){
					 modifiedFunctions.push(record.data);
				 });
				 
                 var funcAccessCodesObj=Ext.getCmp(Modules.CompIds.groupWindowId).funcAccessCodesObj;

                 if(funcAccessCodesObj[serviceTypeCode] != undefined && funcAccessCodesObj[serviceTypeCode].moduleList != undefined){
                	 
                	 var cachedFunctionArray=[];
                	 Ext.Array.each(funcAccessCodesObj[serviceTypeCode].moduleList,function(object,index,me){
		    			 for (var prop in object) {
		    				 if(prop && (prop == selectedRecord.code)){
		    					 cachedFunctionArray=object[prop];
		    					 break;
		    				 }
		    			   }
		    			}); 

                	 for(var i=0;i<modifiedFunctions.length;i++){
                		 var funObj=modifiedFunctions[i];
                		  for(var j=0;j<cachedFunctionArray.length;j++){
                			  if(cachedFunctionArray[j].code == funObj.code){
                				  funObj.accessCode=cachedFunctionArray[j].accessCode;
                			  }
                		  }
                	}
                 }
				//store.add([{code : 'FULL CONTROL' , name : 'Admin screen'},{code : 'QUERY' , name : 'SMC'}]);
				store.add(modifiedFunctions);
		        
            },
            beforeclose:function(){
			}
		}
	});
	return win;
} //End OF Window