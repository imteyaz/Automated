Modules.admin.application_monitoring.change_log.parentGridEditWin = function() {
	
       
	
	var win = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:'NonOceanChangeLogParentGridWindow',//Give some id to window
		gridCompCmc:Ext.getCmp(Modules.CompIds.changeLogParentGridId),//Pass the component of grid at which this window will be opened
		title:'Change Log Header Record View',  //
		editableCmc:false,//Set this to false if all the fields should be readOnly
		saveUrlCmc:'',//Put the URL for save here if the window will save data to server. If no URL specified then data will be saved to grid locally
		saveOrDoneBtnValidateHandlerFuncCmc:'',//This should be a function specified in instance. It will be called in save or done button handler and will be used for instance specific validations like duplication check. It should return true or false for sure.
		saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server if requried
		setFormItemsFuncCmc:function(){
			var itemsArr = [];
					
			
			var screenName = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogScreenNamePopId',
					fieldLabel:  Modules.admin.application_monitoring.change_log.labels.functionName,
					name:'functionName',
					width: 250,
					labelWidth: 85,
					labelAlign:"left",
					readOnly : true
			};
			
			
			
			var userName = {
					xtype: 'cmctextfield',
					id: 'Modules.CompIds.changeLogUserNamePopId',
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.userName,
					name: 'userName',
					width: 173,
					labelWidth: 85,
					labelAlign:"left",
					readOnly : true

				};
			var transInd = {
					xtype: 'cmctextfield',
					id: 'Modules.CompIds.changeLogTransIndPopId',
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.transInd,
					toolTipCmc : Modules.admin.application_monitoring.change_log.labels.transIndFullName,
					name: 'transInd',
					width: 180,
					labelWidth: 80,
					labelAlign:"left",
					readOnly : true

				};

			var logDateTime = {
					xtype: 'cmcdatefield',
					id: 'changeLogLogTimeDatePopId',
					name: 'logDateTime',
					width: 250,
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.logDateTime,
					format:Modules.GlobalVars.dateTimeFormatGlobal,
					labelAlign:"left",
					labelWidth: 85,
					readOnly : true
					
				};			
			
			var level1 = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel1PopId',
					fieldLabel : Modules.admin.application_monitoring.change_log.labels.level1,
					name: 'level1',
					width: 160,
					labelWidth: 60,
					readOnly : true

				};
			
			var level2 = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel2PopId',
					fieldLabel : Modules.admin.application_monitoring.change_log.labels.level2,
					name: 'level2',
					width: 160,
					labelWidth: 60,
					readOnly : true

				};
			
			var level3 = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel3PopId',
					fieldLabel : Modules.admin.application_monitoring.change_log.labels.level3,
					name: 'level3',
					width: 160,
					labelWidth: 60,
					readOnly : true

				};
			
			var level4 = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel4PopId',
					fieldLabel : Modules.admin.application_monitoring.change_log.labels.level4,
					name: 'level4',
					width: 160,
					labelWidth: 60,
					readOnly : true

				};
			
			var level1Data = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel1DataPopId',
					name: 'level1Value',
					width: 100,
					//labelWidth: 60,
					readOnly : true

				};
			
			var level2Data = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel2DataPopId',
					name: 'level2Value',
					width: 100,
					//labelWidth: 60,
					readOnly : true

				};
			
			var level3Data = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel3DataPopId',
					name: 'level3Value',
					width: 100,
					//labelWidth: 60,
					readOnly : true

				};
			
			var level4Data = {
					xtype: 'cmctextfield',
					id:'Modules.CompIds.changeLogLevel4DataPopId',
					name: 'level4Value',
					width: 170,
					//labelWidth: 60,
					readOnly : true

				};
						
			
			/**START Container..1 Component**/
			var container1 = {
				xtype: 'container',
				layout: 'hbox',
				margin: '4px 4px 4px 4px',
				defaults:{
					margin:'0px 10px 0px 17px'
				},
				items: [screenName]
			};
			
			/**START Container..2 Component**/		
			var container2 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '4px 4px 4px 4px',
					defaults:{
						margin:'0px 10px 0px 17px'
					},
					items: [userName,transInd]
				};
			
			/**START Container..3 Component**/		
			var container3 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '4px 4px 4px 4px',
					defaults:{
						margin:'0px 10px 0px 17px'
					},
					items: [logDateTime]
				};
			
			/**START Container..4 Component**/		
			var container4 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level1,level1Data]
				};
			var container5 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level2,level2Data]
				};
			var container6 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level3,level3Data]
				};
			var container7 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level4,level4Data]
				};
			
			var leftContainer = {
					xtype: 'container',
					layout: 'vbox',
					margin: '4px 4px 0px 4px',
					defaults:{
						margin:'0px 10px 0px 0px'
					},
					items: [container1,container2,container3]
				};
			
			var levelContainer = {
					xtype: 'container',
					layout: 'vbox',
					margin: '0px 0px 0px 0px',
					defaults:{
						margin:'0px 10px 0px 0px'
					},
					items: [container4,container5,container6,container7]
				};
			var mainContainer = {
					xtype: 'container',
					layout: 'hbox',
					margin: '0px 4px 4px 4px',
					defaults:{
						margin:'0px 20px 0px 0px'
					},
					items: [leftContainer,levelContainer]
				};
			
			itemsArr = [mainContainer];
			return itemsArr;
		}
	});	

	return win;//Returning the window object ultimately from the funciton

	


};
