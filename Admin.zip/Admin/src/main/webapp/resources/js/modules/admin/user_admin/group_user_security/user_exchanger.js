
Modules.admin.user_admin.group_user_security.user_exchanger_grid	=		function(){
	var panel	=	{
		xtype:'cmcpanelwithgridexchanger',
		id:Modules.CompIds.groupUserExchangerPanelId,
		width:700,
		height:200,
		btnWidthCmc:120, 
		btnCntrWidthCmc:120,
		leftGridTitleCmc : 'Assigned Users',
		btnTopMarginCmc:'100px 0px 5px 0px',
		modelKeyFields :['name'],
		setRightGridFuncCmc:function(){ 
			var store = {
				model: 'GenericLookUpDTO',
				url: 'admin/getGroupAvailableUserDetails',
				paging : true,
				queryTypeCmc : 'remote',
				listeners : {
					beforeload:function(){
						this.proxy.extraParams.limit = 100;
						this.pageSize = 100;
						
						var argObj=Ext.getCmp(Modules.CompIds.groupWindowId).winFuncArgObjCmc; //added by imran to get groupAvailableUserdetails instead of all users
						this.proxy.extraParams.groupId=argObj.record.groupId;
						
						var userField=Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).down('#userNameFilterItemId');
						if(userField){
							this.proxy.extraParams.searchUserName=userField.getValue();
						}
					}
				}
			}; 
			var grid = {
				xtype: 'cmcgrid',
				id : Modules.CompIds.groupUserExchangeRightGridId,
				storeObjCmc: store,
				title: 'All Users ',//Modules.admin.user_admin.user_management.labels.availableUsers,//'Available Users ',
				showPagingBarCmc : true,
				showLeftExtraTbarCmc:true,
				showExtraTbarCmc : true,
				addPagingComboCmc:false,
				paging : true,
				setLeftExtraTbarFuncCmc : function() {
					var searchFields=[{
						xtype : 'cmctextfield',
						name : 'userName',
						itemId : 'userNameFilterItemId',
						width:250,
						labelWidth:40,
						labelAlign:'right',
						fieldLabel : 'Name'
					}];
					return searchFields;
				},setExtraTbarFuncCmc : function() {
				    var buttonArray = [ {
				    	xtype: "button",
						text:'Filter',
						itemId : 'filter',
						name : 'filter',
						icon : 'resources/images/filter.png',
						width: 85,
						handler:function(){
							//var argObj=Ext.getCmp(Modules.CompIds.groupWindowId).winFuncArgObjCmc;
							//var avalUsersStore = Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore();
							//avalUsersStore.proxy.extraParams.groupId=argObj.record.groupId;
							//avalUsersStore.loadPage(1);
								Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore().loadPage(1);
							
							
						}}];
							return buttonArray;
						},
				setGridColumnsFuncCmc: function () {
					 var columns = [{
						header : Modules.admin.user_admin.user_management.labels.name,//'Name',
						flex :1,
						dataIndex : 'name'
					}]; 
					return columns;
				}
			}; 
			return grid;
		}
	}; 
	return panel; 
}//End Of Grid Exchanger Grid 