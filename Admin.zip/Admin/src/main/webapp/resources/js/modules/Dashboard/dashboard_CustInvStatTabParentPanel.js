Modules.Dashboard.customerInvoicStatParentPanel =  function(){
	var panel={
			xtype:'cmctabparentpanel',
			title:Modules.LblsAndTtls.custInvStatusTtl,
			id:'dbCustInvStatID',
			closable : false,
			_serviTypeGroup:'TTS',
			_functionCode : 'AAAX07',
			showNorthItemCmc:true,
			setNorthItemFuncCmc:Modules.Dashboard.CustomerInvoiceStatusForm,
			setCenterItemFuncCmc:Modules.Dashboard.customerInvStatGrid,
			listeners : {
				activate : function(panel) {
					Modules.GlobalVars.dashboardSelectedTabValue = Modules.LblsAndTtls.custInvStatusTtl;
					Modules.GlobalVars.functionCode = panel._functionCode;
					/*if(Ext.getCmp('dashboardCompanyId').getValue() == null)
					{
						 Ext.MessageBox.show({
						        title: 'Selection Error',
						        msg: 'Company code is mandatory field.',
						        buttons: Ext.MessageBox.OK,
						        icon: Ext.MessageBox.ERROR
						    }); 
						 Ext.getCmp('DbCustomerInvStatGridId').getStore().removeAll(); 
						
					}
					else
					{*/
						Ext.getCmp('DbCustomerInvStatGridId').getStore().loadPage(1); 
					//}
				}
			}
			/*setNorthItemFuncCmc:Modules.OceanInvoice.form,
			setCenterItemFuncCmc:Modules.OceanInvoice.tabpanel*/
	};

return panel;

};