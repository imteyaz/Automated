	
Modules.admin.journal.form = function() {
	var maxRecs = Modules.GlobalVars.maxLimitRecords;
	Ext.QuickTips.init();
	var form = {
		xtype: 'cmcform',
		title: 'Journaling',
		itemId: 'queryForm',
		id : Modules.CompIds.journalingFormId,
		width: 1000,
		height: 100,
		plugins:[{ ptype: 'saveretrievecriteria',screenId:Modules.CompIds.journalTabPanelId}],
		bodyStyle: 'background-color: #FFFFFF',
		listeners:{},
		showFieldsetCmc: false,
		tbar:[{
			text:Modules.LblsAndTtls.clearActionTtl,
			xtype:"button",
			iconCls:"clear",
			//tooltip: Modules.Msgs.clearBtnTooltip,
			handler:function(){
				this.ownerCt.ownerCt.getForm().reset();
	            Ext.getCmp(Modules.CompIds.journalGridId).resetDataCmc();
			}
		},{
			xtype: "button",
			text:Modules.LblsAndTtls.retrieveActionTtl,
			iconCls:"retrieve",
			//tooltip: Modules.Msgs.retrieveBtnTooltip,
			getValidationMsg : function(){
				var form =  this.up('form');
				var searchObj =form.getForm().getValues(false,true);
				
			    var isEmptyObj = function(obj) {
			          var empty = true;
			          for (var key in obj) {
			            if ( Ext.isEmpty(obj[key]) ){
			              continue;
			            }
			            empty = false;
			            break;
			          }
			          return empty;
			        };
			    
				if(isEmptyObj(searchObj)){
					return Modules.admin.journal.messages.enterCriteria;
				}
				return '';
			},
			handler:function(){

				if(Modules.GlobalVars.selectedCompanyCode != null){	
					
				    var errorMsg = this.getValidationMsg();
					if(!Ext.isEmpty(errorMsg)){
						Ext.MessageBox.show({
                            title: '',
                            msg: errorMsg,
                            buttons: Ext.MessageBox.OK,
                            icon:Ext.MessageBox.ERROR
                       });
					}
					else{
						Ext.getCmp(Modules.CompIds.journalingFormId).collapse();
							var searchGridStore = Ext.getCmp(Modules.CompIds.journalGridId).getStore();
							
							searchGridStore.removeAll();
							searchGridStore.proxy.extraParams={};
							searchGridStore.loadPage(1,{
								callback: function(records, operation, success) {
			                         if(success == true) {
			                        	 var count = Ext.getCmp(Modules.CompIds.journalGridId).getStore().getCount();
				                            if(count == 0){
				            	            	Ext.MessageBox.show({
				                                     msg: Modules.Msgs.noDataInGrid,
				                                     buttons: Ext.MessageBox.OK,
				                                     icon:Ext.MessageBox.INFO
				                                });
				                            }
				                            else{
				                            }
				                               
			                         }
								}
							});
					}
				}
				else{
					Ext.MessageBox.show({
                        title: '',
                        msg: Modules.Msgs.ValidationCorrectValue,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                   });
				}
			}			
		},{
			xtype:"tbfill"
		}],
		
		setFormItemsFuncCmc: function () {
			var itemsArr = [];
			
			var unitIDTxtFld = {
					xtype : 'cmctextfield',
					name : 'unitID',
					width:250,
					labelAlign:'left',
					labelWidth:50,
					fieldLabel : Modules.admin.journal.labels.unitID,
					itemId : 'journalUnitId'
			};
			var invoiceTxtFld = {
					xtype : 'cmctextfield',
					name : 'invoiceNo',
					labelAlign:'left',
					labelWidth:100,
					width:300,
					fieldLabel : Modules.admin.journal.labels.invoice,
					itemId : 'journalInvcNumId'
			};
			
			var loadRefNoTxtFld = {
					xtype : 'cmctextfield',
					name : 'loadRefNo',
					width:250,
					labelWidth:80,
					labelAlign:'left',
					fieldLabel : Modules.admin.journal.labels.loadReferenceNumber,
					listeners: {
						render: function(c) {
							 Ext.QuickTips.register({
								target: c.getEl(),
								text:'Load Reference Number'
							});
						}
					}
				};
			
			var container1 = {
					xtype : 'container',
					layout : 'hbox',
					//margin: '10px 10px 10px 10px',
					defaults:{
						margin:'5px 20px 0px 5px'
					},
					items : [ unitIDTxtFld, invoiceTxtFld,loadRefNoTxtFld ]
				};
			itemsArr = [ container1 ];
			return itemsArr;
			
		}
	};
	return form;
};
	