/**
 * Customer Invoice Status View
 */

Modules.Dashboard.customerInvStatView = function(myStoreObj,rowIndex,record)
{
	var viewCustomerInvStatGrid = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:Modules.CompIds.viewCustomerReconWinObjOneId,//Give some id to window
		gridCompCmc:Ext.getCmp('DbCustomerInvStatGridId'),//Pass the component of grid at which this window will be opened
		title:'Customer Invoice Status View',
		editableCmc:false,//Set this to false if all the fields should be readOnly
		height : 350,
		width: 600,
		setFormItemsFuncCmc:function(){//This function should return the form items.
						 
			 var itemsArr = [];
				   
				   var customerCd ={
							xtype: 'cmctextfield',
							id: 'customerCd',
							name: customerCd,
							fieldLabel: 'Customer',
							width:200,
							labelWidth:85,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true
						
					};
				   var invType ={
							xtype: 'cmctextfield',
							id: 'invType',
							name: invType,
							fieldLabel: 'Invoice Type',
							width:200,
							labelWidth:85,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true							
					};
				
				   var currency ={
							xtype: 'cmctextfield',
							id: 'currency',
							name: currency,
							fieldLabel: 'Currency',
							width:200,
							labelWidth:85,
							labelAlign:"left",
							margin : '5px 0px 5px 50px',
							labelSeparator:'',
							readOnly:true							
					};
				   
				  
				
				   var countToday ={
						   xtype: 'cmcnumberfield',
							id: 'countToday',
							name: 'countToday',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'				
					};
				   var amountToday ={
						   xtype: 'cmcnumberfield',
							id: 'amountToday',
							name: 'amountToday',
							fieldStyle: 'text-align: right;',
							forcePrecision: true, 
							fieldLabel: 'Amount'						
					};
				   var countYesterday ={
						   xtype: 'cmcnumberfield',
							id: 'countYesterday',
							name: 'countYesterday',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'						
					};
				   var amountYesterday ={
						   xtype: 'cmcnumberfield',
							id: 'amountYesterday',
							name: 'amountYesterday',
							fieldStyle: 'text-align: right;',
							forcePrecision: true, 
							fieldLabel: 'Amount'				
					};
				   var countPastWeek ={
						   xtype: 'cmcnumberfield',
							id: 'countPastWeek',
							name: 'countPastWeek',
							fieldStyle: 'text-align: right;',
							
							fieldLabel: 'Count'						
					};
				   var amountPastWeek ={
						   xtype: 'cmcnumberfield',
							id: 'amountPastWeek',
							name: 'amountPastWeek',
							fieldStyle: 'text-align: right;',
							forcePrecision: true, 
							fieldLabel: 'Amount'	
					};
				   var countPastMonth ={
						   xtype: 'cmcnumberfield',
							id: 'countPastMonth',
							name: 'countPastMonth',
							fieldStyle: 'text-align: right;',
							fieldLabel: 'Count'					
					};
				   var amountPastMonth ={
						   xtype: 'cmcnumberfield',
							id: 'amountPastMonth',
							name: 'amountPastMonth',
							fieldStyle: 'text-align: right;',
							forcePrecision: true, 
							fieldLabel: 'Amount'				
					};
				   	
				
				   var sendMsgContainer={
						   xtype:'container',
						   layout:'vbox',
						   items:[customerCd,invType,currency]
				   };				   
				   	   
				   var tablePanle = {
				   layout: {
				        type: 'table',
				        columns: 3
				    },
				    width:500,
				    defaults: {
				        // applied to each contained panel
				        bodyStyle: 'padding:20px',
				        width:90,
						labelWidth:100,
						labelAlign:"left",
						margin : '5px 50px 5px 30px',
						labelSeparator:'',
						readOnly:true,
						hideLabel:true
				    },
				    items: [
				            {xtype:'label',text:'Days'},{xtype:'label',text:'Count'},{xtype:'label',text:'Amount'},
				            {xtype:'cmctextfield',value:'Today '},countToday,amountToday,
				            {xtype:'cmctextfield',value:'Yesterday'},countYesterday,amountYesterday,
				            {xtype:'cmctextfield',value:'Past Week'},countPastWeek,amountPastWeek,
				            {xtype:'cmctextfield',value:'Past Month'},countPastMonth,amountPastMonth,
				            ]
				    }; 	
				   itemsArr = [sendMsgContainer,tablePanle];
					return itemsArr;			 		 
		   }
 });
 return viewCustomerInvStatGrid;
 };
	