Modules.admin.journal.tabparentpanel = function(menu) {
	var panel={
			xtype:'cmctabparentpanel',
			title:Modules.admin.journal.labels.tabTitle,//Modules.admin.journal.labels.formTitle,
			id:Modules.CompIds.journalTabPanelId,
			showNorthItemCmc:true,
			setNorthItemFuncCmc:Modules.admin.journal.form,
			setCenterItemFuncCmc:Modules.admin.journal.tabpanel,
			_functionCode : 'AOFX07'
			
	};	
	return panel;
};

