/*$(".deckdouble td").dblclick(function(){
	console.log("comng in doble click");
    $(this).addClass("selected440footer");
});

$('.deckdouble td').on('dblclick', function () {
	console.log("comng on doble click");
    $(this).addClass("selected440footer");
});*/

 function convertToSingleDigit(n) {
         return n > 9 ? "" + n :  n.charAt(1);
     }

 function twodigits(n) {
     return n > 9 ? "" + n : "0" + n;
 }
 

$(document).on('dblclick', '.deckdouble td , .underdeckdouble td', function() {
    //console.log("inside dbl");
	
	if(!($('#upgraderBtn').is(":visible"))){
		return false ;
	}
    
    if(!$(this).hasClass("fortyfooter") ){
	    $(this).toggleClass("selected440footer");
	    $(this).siblings().toggleClass("selected440footer");
    }
});


$(document).on('click', '#upgraderBtn', function() {
   // console.log("inside upgraderBtn click");
    var selected40 = $('.selected440footer').length ;
    
    if(selected40==0){
    	Ext.MessageBox.show({
			msg: "Please select atleast one twin bay by double clicking on it to upgrade it to 40 footer !",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});	
    	return false ;
    }
    Ext.getBody().mask("Upgrading the selected bays to 40 footer...this may take some time...please wait");
    
    for(var i=0;i<selected40 ;i=i+2){
    	$($('.selected440footer')[i]).addClass("fortyFooterLeft fortyfooter"); //toggleClass("selected440footer 40footerLeft");
    	$($('.selected440footer')[i]).removeAttr('contenteditable');
    	
    var deckIndicator =	$('.selected440footer')[i].dataset.deck_name ;
    
    if(deckIndicator=='D'){
    	var newId = $($('.selected440footer')[i]).attr("id").replace("0D","1D");
    	$($('.selected440footer')[i]).attr("id",newId);
    }
    else{
    	var newId = $($('.selected440footer')[i]).attr("id").replace("0U","1U");
    	$($('.selected440footer')[i]).attr("id",newId);
    }
    	
    	
    	var firstBayNo = $('.selected440footer')[i].innerHTML ;
    	var secondBayNo = $('.selected440footer')[i+1].innerHTML ;
    	var startBayNo = convertToSingleDigit(firstBayNo);
    	var fortyFooterBayNo = Number(startBayNo) + 1 ;
    	
    	$('.selected440footer')[i].innerHTML = twodigits(fortyFooterBayNo) ;
    	$($('.selected440footer')[i+1]).addClass("fortyFooterRight fortyfooter"); //toggleClass("selected440footer 40footerRight");
    	$($('.selected440footer')[i+1]).removeAttr('contenteditable');
    	$('.selected440footer')[i+1].innerHTML = ""; 
    	
    	window.setTimeout(showMaskMessage(firstBayNo,secondBayNo), 10000);

    	}
    $('.fortyFooterLeft').attr("data-bay_offset","1");
    $('.selected440footer').removeClass("selected440footer") ;
    Ext.getBody().unmask();
});


function showMaskMessage(bay1,bay2){
	
	Ext.getBody().mask("Merging bays " + bay1 +" and "+ bay2 + " !");
	 
}
