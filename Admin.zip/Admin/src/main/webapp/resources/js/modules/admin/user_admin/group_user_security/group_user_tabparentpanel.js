
Modules.admin.user_admin.group_user_security.tabparentpanel = function (mergeObj) {
	
	var panel={
			xtype:'cmctabparentpanel',
			title:'View/Manage Groups',
			id:'GroupUserSecuritytabpanelId',
			_functionCode : 'AAAX01',
			closable : true,
			showNorthItemCmc:false,
			showCenterItemCmc : true,
			showSouthItemCmc: false,
			//setNorthItemFuncCmc:Modules.admin.user_admin.group_user_security.northGrid,
			setCenterItemFuncCmc:Modules.admin.user_admin.group_user_security.northGrid,//Modules.admin.user_admin.group_user_security.southGrid,
			panelFuncArgObjCmc : mergeObj,
			applyExtraUserSecurity : function(accessCode){
				var parentPanel = this ;
				var editGroupButton = parentPanel.query('[iconCls=properties]');
				var newGroupButton = parentPanel.query('[iconCls=newGroup]');
				var deleteGroupButton = parentPanel.query('[iconCls=deleteGroup]');
				  
				if(accessCode==Modules.GlobalVars.QUERY){
					//8. Hide the editing button
					Ext.getCmp(Modules.CompIds.adminGroupGridId).columns[1].setVisible(false);
					editGroupButton[0].setVisible(false);
					newGroupButton[0].setVisible(false);
					deleteGroupButton[0].setVisible(false);
				}
				else if(accessCode==Modules.GlobalVars.QUERY_INSERT){
					//8. Hide the editing button
					Ext.getCmp(Modules.CompIds.adminGroupGridId).columns[1].setVisible(false);
					editGroupButton[0].setVisible(false);
					deleteGroupButton[0].setVisible(false);
				}
				
				else if(accessCode==Modules.GlobalVars.QUERY_INSERT_UPDATE){
					//8. Hide the editing button
					deleteGroupButton[0].setVisible(false);
				}
				
			}
	};	
	return panel;
	
}; //End Of Panel