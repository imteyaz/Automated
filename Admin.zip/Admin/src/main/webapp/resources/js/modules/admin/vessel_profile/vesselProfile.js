 /////VESSEL SCRIPT
 $(document).ready(function() {
     var section = [],
         section_script = [],
         bay_script = [],
         bay_html = [],
         current_working_Bay="", vsl_script = [],
         deck_ids= [],
         underdeck_ids = [],
         count = 1,
         count_sect_no = 0,
         underdeckcount = 1,
         maxRows,
         zeroRow,
         deckCount_no,
         underdeckCount_no,
         section_no_vsl,
         defaultDeckTemplate,
         defaultUnderDeckTemplate,
         vesselSaved=false,
 		 any_bay_saved = false;

     /**
      * Converts the given number into two digits by :
      * prepending 0 if number <9 
      * prepending "" if number >9 
      * @param {Number} a (e.g  0)
      * @return {Number} 0a  (e.g 08)
      */
     function twodigits(n) {
         return n > 9 ? "" + n : "0" + n;
     }
     
     
     //Generating the bays structure
     $("#section_label").hide();
     $("#sect_no").hide();
     $("#section_start_label").hide();
     $("#DSectionNoStart").hide();
     
     //Adding two deck bays ( ++ button)
     $("#addDeckbay").on("click", function() {
    	 var sect_start_no = $("#sect_start").val();   // hidden field - value hardcoded
    	 section_no_vsl = Number(count_sect_no) + Number(sect_start_no);   //  section_no_vsl used for giving id for different sections (0+120,1+120)
         $("#deckrow").append("<table class='deckdouble' id='" + section_no_vsl + "' style='border-bottom:2px solid red;float:left;margin-right:10px'><td id='" + section_no_vsl + "0D' data-template = '' data-sectno = '" + section_no_vsl + "' data-deck_name = 'D' data-bay_offset = '0' data-bay_no='" + twodigits(count) + "'>" + twodigits(count) + "</td><td id='" + section_no_vsl + "2D' data-template = '' data-deck_name = 'D' data-bay_offset = '2' data-sectno = '" + section_no_vsl + "' data-bay_no='" + twodigits(count + 2) + "'>" + twodigits(count = count + 2) + "</td></table>");
         count = count + 2;
         count_sect_no = Number(count_sect_no) + 1;
     });
     
     //Adding single deck bay ( + button)
     $("#addsingleDeckbay").on("click", function() {
    	 var sect_start_no = $("#sect_start").val();
         section_no_vsl = Number(count_sect_no) + Number(sect_start_no);
         $("#deckrow").append("<table class='decksingle' id='" + section_no_vsl + "' style='border-bottom:2px solid red;float:left;margin-right:10px'><td id='" + section_no_vsl + "1D' data-template = '' data-sectno = '" + section_no_vsl + "' data-deck_name = 'D' data-bay_offset = '1'   data-bay_no='" + twodigits(count) + "'>"  + twodigits(count) + "</td><td style='display:none;' ></td></table>");
         count = count + 2;
         count_sect_no = Number(count_sect_no) + 1;
     });
     
     //Adding two underdeck bays ( ++ button)
     $("#addunderDeckbay").on("click", function() {
    	 var sect_start_no = $("#sect_start").val();
    	 section_no_vsl = Number(count_sect_no) + Number(sect_start_no);
         $("#underdeckrow").append("<table class='underdeckdouble' id='" + section_no_vsl + "' style='border-bottom:2px solid red;float:left;margin-right:10px'><td id='" + section_no_vsl + "0U' data-template = '' data-sectno = '" + section_no_vsl + "' data-deck_name = 'U' data-bay_offset = '0'  data-bay_no='" + twodigits(underdeckcount) + "'>"  + twodigits(underdeckcount) + "</td><td id='" + section_no_vsl + "2U' data-template = '' data-deck_name = 'U' data-bay_offset = '2' data-sectno = '" + section_no_vsl + "' data-bay_no='" + twodigits(underdeckcount + 2) + "'>"   + twodigits(underdeckcount = underdeckcount + 2) + "</td></table>");
         count_sect_no = Number(count_sect_no) + 1;
         underdeckcount = underdeckcount + 2;
     });
     
   //Adding single underdeck bay ( + button)
     $("#addsingleunderDeckbay").on("click", function() {
    	 var sect_start_no = $("#sect_start").val();
         section_no_vsl = Number(count_sect_no) + Number(sect_start_no);
         $("#underdeckrow").append("<table class='underdecksingle' id='" + section_no_vsl + "'  style='border-bottom:2px solid red;float:left;margin-right:10px'><td id='" + section_no_vsl + "1U' data-template = '' data-sectno = '" + section_no_vsl + "' data-deck_name = 'U' data-bay_offset = '1' data-bay_no='" + twodigits(underdeckcount) + "'>"  + twodigits(underdeckcount) + "</td><td data-deck_name = 'U'  style='display:none;' ></td></table>");
         count_sect_no = Number(count_sect_no) + 1;
         underdeckcount = underdeckcount + 2;
     });
     
     //Remove deck/underdeck bays
     $("#removeDeckbay").click(function(){
    	 if($('#deckrow').children().last().attr('class') === "deckdouble" ){
    	 deckCount_no  = $(".deckdouble").length;
    	 if (deckCount_no >= 1) {
    	        $('.deckdouble:last').fadeOut().detach();
    	        	count = count - 4;
    	        	count_sect_no = Number(count_sect_no) - 1;
    	    }
     }
		else{
	Ext.MessageBox.show({
			msg: "Cannot remove, Please check whether the bay is twin bay or not",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});	
		}
     });
     $("#removesingleDeckbay").click(function(){
    	 if($('#deckrow').children().last().attr('class') === "decksingle" ){
    	 deckCount_no  = $(".decksingle").length;
    	 if (deckCount_no >= 1) {
    	        $('.decksingle:last').fadeOut().detach();
    	        count = count - 2;
    	        count_sect_no = Number(count_sect_no) - 1;
    	    }
    	 }
    		else{
    			Ext.MessageBox.show({
    					msg: "Unable to remove, Please check whether the bay you are trying to delete is 20 footer !",
    					buttons: Ext.MessageBox.OK,
    					icon: Ext.MessageBox.INFO
    				});	
    				}
     });
     $("#removeunderDeckbay").click(function(){
    	 if($('#underdeckrow').children().last().attr('class') === "underdeckdouble" ){
    	 underdeckCount_no  = $(".underdeckdouble").length;
    	 if (underdeckCount_no >= 1) {
    	        $('.underdeckdouble:last').fadeOut().detach();
    	        underdeckcount = underdeckcount - 4;
    	        count_sect_no = Number(count_sect_no) - 1;
    	    }
    	 }
    		else{
    			Ext.MessageBox.show({
    					msg: "Cannot remove, Please check whether the bay is twin bay or not",
    					buttons: Ext.MessageBox.OK,
    					icon: Ext.MessageBox.INFO
    				});	
    				}
     });
     $("#removesingleunderDeckbay").click(function(){
    	 if($('#underdeckrow').children().last().attr('class') === "underdecksingle" ){
    	 deckCount_no  = $(".underdecksingle").length;
    	 if (deckCount_no >= 1) {
    	        $('.underdecksingle:last').fadeOut().detach();
    	        underdeckcount = underdeckcount - 2;
    	        count_sect_no = Number(count_sect_no) - 1;
    	    }
    	 }
    		else{
    			Ext.MessageBox.show({
    					msg: "Cannot remove, Please check whether the bay is single bay or not",
    					buttons: Ext.MessageBox.OK,
    					icon: Ext.MessageBox.INFO
    				});	
    				}
     });
     var vsl_obj = {},
      save_table_details = true,
      saveDetails="";
     
     // commenting out below code as editing bay numbers should not be allowed !
      
   /*  $("#myVessel").on("focusout", "td", function(ev) {
    	 	if(($(this)[0].innerHTML) % 2 === 0 && ($(this)[0].innerHTML) % 2 != ""){
    	 		$("#generatevessel").hide();
    	 		 Ext.MessageBox.show({
    	 				msg: "Cannot change the bay to 40 footer bay by renaming it ; use upgrade button after selecting the appropriate bays",
    	 				buttons: Ext.MessageBox.OK,
    	 				icon: Ext.MessageBox.INFO
    	 			});	
    	 	}else{
    	 	}
     });*/
     
     //Generate the vessel bays structure
     $("#generatevessel").on("click", function() {
    	 $('.selected440footer').removeClass("selected440footer") ;
    	 
    	 maxRows = $("#maxRows").val();
    	 if(maxRows % 2 === 0){
    		 maxRows = Number(maxRows) + 1;
    	 }
    	 zeroRow = parseInt(maxRows/2);
    	 var maxRowsValue = maxRows-1;
    	 for(var i=0;i<maxRows;i++){
    		 if(i ===zeroRow ){
    			 $(".tier_offset").append('<th class="zeroth_row" colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+i+'</th>');
    	    	 	if(maxRowsValue>=0){
    	    	 		$(".tier_value").append('<th class="zeroth_row" colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(maxRowsValue)+'</th>');
    	    	 		maxRowsValue = maxRowsValue -2;
    	    	 	}
    		 }
    		 else{
    			 $(".tier_offset").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+i+'</th>');
    	    	 	if(maxRowsValue>=0){
    	    	 		$(".tier_value").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(maxRowsValue)+'</th>');
    	    	 		maxRowsValue = maxRowsValue -2;
    	    	 	}
    		 }
    	 	
    	 }
    	 for(var i=1;i<maxRows;i=i+2){
    			$(".tier_value").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(i)+'</th>');
    	}
    	 if($('#deckrow').children().length>3 ||$('#underdeckrow').children().length>3){
         $("#editvessel").show();	// no such button now
         var sect_start = $("#sect_start").val(),
             vessel_no = $("#vessel_no").val(),
             vessel_name = $("#vessel_name").val();
         $("#myVessel tr table").removeClass("edittable");
         $("#myVessel tr table tbody tr td").each(function(e) {
             $(this).addClass("final");
             $(this).css('background-color', 'red');
             $(this).removeAttr('contenteditable');
         });
         vsl_obj["vesselCode"] = vessel_no;
         vsl_obj["vesselName"] = vessel_name;
         vsl_obj["vesselType"] = $("#vesselType").val();
         vsl_obj["motherFeeder"] = $("#motherFeeder").val();
         vsl_obj["length"] = $("#length").val();
         vsl_obj["lengthUom"] = "M";
         vsl_obj["width"] = $("#width").val();
         vsl_obj["widthUom"] = "M";
         vsl_obj["teuCapacity"] = $("#teuCapacity").val();
         vsl_obj["height"] = $("#height").val();
         vsl_obj["isDeleted"] = "N";
         vsl_obj["maxRows"] = maxRows;
         vsl_script.push(vsl_obj);
         
     	$(".add_td").hide();
         $("#generatevessel").hide();
         $("#upgraderBtn").hide();
         save_table_details = true;
         saveDetails = true;
       //Begin of unnecessary code; used beofre introduction of templates in vessel profile
         
         var max_row_deck = $("#max_row_deck").val(),
             start_row_deck = $("#start_row_deck").val(),
             max_row_underdeck = $("#max_row_underdeck").val(),
             start_row_underdeck = $("#start_row_underdeck").val();
         if (max_row_deck > 15 || max_row_underdeck > 15) {
             alert("Max row UnderDeck/Deck value should not be greater than 15");
         } else {
             var tier_deck_no = (Number(max_row_deck) - 1) * 2 + Number(start_row_deck),
                 tier_underdeck_no = (Number(max_row_underdeck) - 1) * 2 + Number(start_row_underdeck),
                 tieroffset_deck_no,
                 tieroffset_underdeck_no;
             for (var q = 0; q < max_row_deck; q++) {
            	 tieroffset_deck_no = (Number(tier_deck_no) - 80)/2,
                 $("#deck_tbody").append("<tr><th rowspan='1' scope='rowgroup'>" + tieroffset_deck_no + "</th><th rowspan='1' scope='row' style='padding-left:10px'>" + twodigits(tier_deck_no) + "</th></tr>");
                 tier_deck_no = tier_deck_no - 2;
                 tieroffset_deck_no = tieroffset_deck_no - 1;
             }
             $("#deck_table tbody tr").each(function(e) {
                 for (var x = 0; x < maxRows; x++) {
                     $(this).append("<td></td>");
                 }
             });
             for (var q = 0; q < max_row_underdeck; q++) {
            	 tieroffset_underdeck_no = (Number(tier_underdeck_no) - 2)/2;
                 $("#underdeck_tbody").append("<tr><th rowspan='1' scope='rowgroup' style='padding-right:10px'>" + tieroffset_underdeck_no + "</th><th rowspan='1' scope='row' >" + twodigits(tier_underdeck_no) + "</th></tr>");
                 tier_underdeck_no = tier_underdeck_no - 2;
                 tieroffset_underdeck_no = tieroffset_underdeck_no - 1;
             }
             $("#underdeck_table tbody tr").each(function(e) {
                 for (var x = 0; x < maxRows; x++) {
                     $(this).append("<td></td>");
                 }
             });
             $("#table_details").hide();
             $(".legend-scale").show();
             $("#screen_headings").text("Bay Draw Screen");
         }
         
         //end of unnecessary code
         if (save_table_details === true) {
        	 saveDetails = true;
             $("#screen_headings").text("Bay Draw Screen");
         }
     }
    	 
    	 else{
    		 Ext.MessageBox.show({
 				msg: "Please add atleast one bay in deck or underDeck to generate Vessel Profile",
 				buttons: Ext.MessageBox.OK,
 				icon: Ext.MessageBox.INFO
 			});	
    		 $("#generatevessel").show();
    		 //$("#upgraderBtn").show();
    	 }
    	 var templateDeckHeaders = getTemplateHeadersOrDetails('TemplateHeader','type','TD','headerId','',0,100),
    	 	templateUnderDeckHeaders = getTemplateHeadersOrDetails('TemplateHeader','type','TU','headerId','',0,100);
    	 for(var t=0;t<templateDeckHeaders.data.length;t++){
    		 $("#deck_tier_template").append('<option value='+templateDeckHeaders.data[t].headerId+'>'+templateDeckHeaders.data[t].headerId+'</option>');
    		 if(templateDeckHeaders.data[t].isDefault=== "Y"){
    			 defaultDeckTemplate = templateDeckHeaders.data[t].headerId;
    		 }
    	 }
    	 for(var t=0;t<templateUnderDeckHeaders.data.length;t++){
    		 $("#underdeck_tier_template").append('<option value='+templateUnderDeckHeaders.data[t].headerId+'>'+templateUnderDeckHeaders.data[t].headerId+'</option>');
    		 if(templateUnderDeckHeaders.data[t].isDefault=== "Y" ){
    			 defaultUnderDeckTemplate = templateUnderDeckHeaders.data[t].headerId;
    		 }
    	 }
    	 getDeckTemplateDetails(defaultDeckTemplate);
    	 getUnderDeckTemplateDetails(defaultUnderDeckTemplate);
     });
     
     
     //Remove zeroth column in the deck/underdeck bay - table
     var check_remove_zero_deck = function(){
    	 if($("#row_zero").is(":checked")) {
    		 $("#deck_table thead tr th.zeroth_row").hide();
    		// $("#deck_table thead tr:nth-child(2) th:nth-child(zeroRow)").hide();
    		 $("#deck_table tbody tr").each(function(e) {
                 $(this)[0].childNodes[zeroRow+2].hidden = true;   // + 2 is to start form the original td in which one can draw(to exclude tier offset and value)
    			 $(this)[0].childNodes[zeroRow+2].innerText = "";
    			 $(this)[0].childNodes[zeroRow+2].className = "start";   // start is ithe default initial class for each td && final is initial in some way
             });
    	 }
    	 else{
    		 $("#deck_table thead tr th.zeroth_row").show();
    		// $("#deck_table thead tr:nth-child(2) th:nth-child(zeroRow)").show();
    		 $("#deck_table tbody tr").each(function(e) {
    			 $(this)[0].childNodes[zeroRow+2].hidden = false;
             });
    	 }
     };
     var check_remove_zero_underdeck = function(){
    	 if($("#row_zero").is(":checked")) {
    		 $("#underdeck_table thead tr th.zeroth_row").hide();
    	//	 $("#underdeck_table thead tr:nth-child(2) th:nth-child(zeroRow)").hide();
    		 $("#underdeck_table tbody tr").each(function(e) {
    			 $(this)[0].childNodes[zeroRow+2].hidden = true;
    			 $(this)[0].childNodes[zeroRow+2].innerText = "";
    			 $(this)[0].childNodes[zeroRow+2].className = "start";
             });
    	 }
    	 else{
    		 $("#underdeck_table thead tr th.zeroth_row").show();
    		// $("#underdeck_table thead tr:nth-child(2) th:nth-child(zeroRow)").show();
    		 $("#underdeck_table tbody tr").each(function(e) {
    			 $(this)[0].childNodes[zeroRow+2].hidden = false;
             });
    	 }
     };
     $('#row_zero').change(function() {
      	if($("#deck_table").css("display") === "table"){
      		check_remove_zero_deck();
      	}
      	else if($("#underdeck_table").css("display") === "table"){
      		check_remove_zero_underdeck();
      	}
    	
     });
     
     //Getting the template details and data based on the template selected
     var getDeckTemplateDetails = function(templateHeaderVal){
    	var TemplateDetails ={};
    	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
    	 $("#deck_tbody").empty();
     	//var template_deck_selected =  $("#deck_tier_template" ).val();
     	for(var t=TemplateDetails.data.length-1;t>=0;t--){
     		$("#deck_tbody").append("<tr><th rowspan='1' scope='rowgroup'>" + TemplateDetails.data[t].pk.offset + "</th><th rowspan='1' scope='row' style='padding-left:10px'>" + TemplateDetails.data[t].vesselLabel+ "</th></tr>");
     	}
     	$("#deck_table tbody tr").each(function(e) {
             for (var x = 0; x < maxRows; x++) {
                 $(this).append("<td></td>");
             }
         });
     };
     var getTierCount = function(templateHeaderVal){
    	 var TemplateDetails ={};
    	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
    	 return TemplateDetails.data.length;
     };
     var getUnderDeckTemplateDetails = function(templateHeaderVal){
     	var TemplateDetails ={};
     	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
     	 $("#underdeck_tbody").empty();
      	//var template_deck_selected =  $("#deck_tier_template" ).val();
      	for(var t=TemplateDetails.data.length-1;t>=0;t--){
      		$("#underdeck_tbody").append("<tr><th rowspan='1' scope='rowgroup'>" + TemplateDetails.data[t].pk.offset  + "</th><th rowspan='1' scope='row' style='padding-left:10px'>" + TemplateDetails.data[t].vesselLabel+ "</th></tr>");
      	}
      	$("#underdeck_tbody tr").each(function(e) {
              for (var x = 0; x < maxRows; x++) {
                  $(this).append("<td></td>");
              }
          });
      };
     $( "#deck_tier_template" ).change(function(e) {
    	var templateHeaderVal =  $( "#deck_tier_template" ).val();
    	if($( "#deck_tier_template" ).val() === "Default"){
    		getDeckTemplateDetails(defaultDeckTemplate);
    	}
    	else{
    		getDeckTemplateDetails(templateHeaderVal);	
    	}
    	check_remove_zero_deck();
    	});
     $( "#underdeck_tier_template" ).change(function(e) {
     	var templateHeaderVal =  $( "#underdeck_tier_template" ).val();
     	if($( "#underdeck_tier_template" ).val() === "Default"){
     		getUnderDeckTemplateDetails(defaultUnderDeckTemplate);
     	}
     	else{
     		getUnderDeckTemplateDetails(templateHeaderVal);	
     	}
     	check_remove_zero_underdeck();
     	});
     $("#bay_details").hide();   // not sure why and what its doing here ?
     
     //Click event of the bay 
     $("#myVessel").on("click", "td.final", function(ev) {
   	 if(!vesselSaved){
    	 if(saveDetails){  //always true now
    //	 if(bay_saved){
    	 select_allow= true;
             $("#pushvalues").show(); // save current bay
             $(this).css("background-color", "yellow");
             
             $("#bay_details").show(); // not being shown currently due to space issue
             var current_deck = $(this).attr("data-deck_name"),
                 current_sect_no = $(this).attr("data-sectno"),
                 current_bay_offset = $(this).attr("data-bay_offset");
             $("#sect_no").val(current_sect_no);
             $("#deck").val(current_deck);
             current_working_Bay = current_sect_no + current_bay_offset + current_deck;
             $(".bay_no_h1").text($(this)[0].innerHTML + "(" + current_deck + ")");
             
             /*if($(this).hasClass("fortyfooter") ){
            	 $(this).siblings().css("background-color", "yellow");
            	 if($(this).hasClass("fortyFooterLeft") ){ 
            		 $(".bay_no_h1").text($(this)[0].innerHTML + "(" + current_deck + ")");
            	 }
            	 else if($(this).hasClass("fortyFooterRight") ){
            		 $($(".bay_no_h1").text($(this)[0]).siblings()[0].innerHTML + "(" + current_deck + ")");
            		 
            	 }
            	 
             }
             else{
            	 $(".bay_no_h1").text($(this)[0].innerHTML + "(" + current_deck + ")");
             }*/
             
             
             
             $("#bay_offset").val(current_bay_offset);
             if (current_deck === "U") {
            	 $("#deck_tier_template").hide();
                 $("#underdeck_tier_template").show();
            	 if($("#underdeck_tier_template").val() !== "Default"){
                	 getUnderDeckTemplateDetails(defaultUnderDeckTemplate);
                	 $("#underdeck_tier_template").val("Default");
                 }
                 $("#underdeck_table").css("display", "table");
                 $("#deck_table").css("display", "none");
                 $("#underdeck_table tr td").each(function(e) {
                     $("#underdeck_table tr td").addClass("start");
                 });
                 $("#deck_table_div").hide();
                 $("#underdeck_table_div").show();
                 check_remove_zero_underdeck();
           		
             } else if (current_deck === "D") {
            	 $("#deck_tier_template").show();
                 $("#underdeck_tier_template").hide();
            	 if($("#deck_tier_template").val() !== "Default"){
                	 getDeckTemplateDetails(defaultDeckTemplate);
                	 $("#deck_tier_template").val("Default");
                 }
                 $("#deck_table").css("display", "table");
                 $("#underdeck_table").css("display", "none");
                 $("#deck_table tr td").each(function(e) {
                     $("#deck_table tr td").addClass("start");
                 });
                 $("#underdeck_table_div").hide();
                 $("#deck_table_div").show();
                 check_remove_zero_deck();
             }
     }
    	 
    	 //else condition never satisfied now due to removal of starting row/tier details 
    	 else{
    		 Ext.MessageBox.show({
  				msg: "Please save Deck and Underdeck details to proceed further",
  				buttons: Ext.MessageBox.OK,
  				icon: Ext.MessageBox.INFO
  			});	
    	 }
     }

     });

     //Verticals selection -- based on the verticals selected - marking will done
     var bayrow_spm_script = [],
         baytier_spm_script = [],
         cell_spm_script = [];
     $(".dropdown dt a").on('click', function () {
    	 $(this).toggleClass("down");
         $(".dropdown dd ul").slideToggle('fast');
     });
     $(".dropdown dd ul li a").on('click', function () {
         $(".dropdown dd ul").hide();
     });
     function getSelectedValue(id) {
          return $("#" + id).find("dt a span.value").html();
     }
     $(document).bind('click', function (e) {
         var $clicked = $(e.target);
     });
     $('.mutliSelect input[type="checkbox"]').on('click', function () {
         var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val();
             title = $(this).val() + " ,";
         if($(".hida").text() === "Select"){
      	   $(".hida").show();
         }
         if ($(this).is(':checked')) {
             var html = '<span title="' + title + '">' + title + '</span>';
             $('.multiSel').append(html);
             $(".hida").hide();
         } 
         else {
             $('span[title="' + title + '"]').remove();
             var ret = $(".hida");
             $('.dropdown dt a').append(ret);
         }
     });
     var verticals,
      verticals_selected= "",
      select_allow="",
      mouseDown = false,
 	  cb_unselected = $("#unselected_cb");
     $(".mytable").on("mousedown", "td", function(){ 
    	// bay_saved = false;
    	 if(select_allow){
    	 mouseDown = true;
    	 verticals = [];
    	 text_verticals=[];
    	 verticals_selected="";
    	 //need to confirm
    	 $(this).removeClass("45footer");
    	 $(this).removeClass("reefer");
    	 $(this).removeClass("empty");
    	 $('input[name="verticals"]:checked').each(function() {
    		 verticals.push(this.value);
    		 });
    	 if(cb_unselected.is(':checked')){  // unselect is entirely removing evrythinhg, not based on oother check boxes below
    		 $(this).removeClass("selected");
    		 $(this).removeClass("45footer");
    		 $(this).removeClass("reefer");
    		 $(this).removeClass("empty");
    		 $(this)[0].innerText="";
    	 }
    	 else{
    		 for(var i=0;i<verticals.length;i++){
        		 if(verticals[i][0] === "4"){
        			 verticals[i][0]= "45";
        			 text_verticals = text_verticals + " "+ verticals[i][0]+verticals[i][1]+ " "; 
        		 }
        		 else{ 
        			 text_verticals = text_verticals + " " + verticals[i][0]+ " "; 
        		 }
        		 verticals_selected = verticals_selected +" "+ verticals[i] + " ";
        		 
        	 }
        	 $(this).addClass(verticals_selected);
        	 $(this)[0].innerText=text_verticals;
        	 $(this).addClass("selected");
    	 }
    	 return false;  // no idea !
    	 }
     }); 
     $(".mytable").on("mouseover", "td", function() {
    	// bay_saved = false;
    	 if(select_allow){
    	 if(mouseDown===true){
    		 verticals = [];
        	 text_verticals=[];
        	 verticals_selected="";
        	 $(this).removeClass("45footer");
        	 $(this).removeClass("reefer");
        	 $(this).removeClass("empty");
        	 $('input[name="verticals"]:checked').each(function() {
        		 verticals.push(this.value);
        		 });
        	 if(cb_unselected.is(':checked')){
        		 $(this).removeClass("selected");
        		 $(this).removeClass("45footer");
        		 $(this).removeClass("reefer");
        		 $(this).removeClass("empty");
        		 $(this)[0].innerText="";
        	 }
        	 else{
        		 for(var i=0;i<verticals.length;i++){
            		 if(verticals[i][0] === "4"){
            			 verticals[i][0]= "45";
            			 text_verticals = text_verticals + " "+ verticals[i][0]+verticals[i][1]+ " "; 
            		 }
            		 else{ 
            			 text_verticals = text_verticals + " " + verticals[i][0]+ " "; 
            		 }
            		 verticals_selected = verticals_selected +" "+ verticals[i] + " ";
            	 }
            	 $(this).addClass(verticals_selected);
            	 $(this)[0].innerText=text_verticals;
            	 $(this).addClass("selected");
        	 }
    	 }
    	 }
     });
     $(document).mouseup(function () {
    	 mouseDown = false;
     });
     $("#remove_reefer").click(function() {
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
    	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
    		 Ext.MessageBox.show({
    				msg: "Bay once saved is not allowed to modify",
    				buttons: Ext.MessageBox.OK,
    				icon: Ext.MessageBox.INFO
    			});	
    	 }
    	 else{
    	 $(".mytable tr td").each(function(e) {
             $(this).removeClass("reefer");
             $(this).removeAttr('style');   // not sure why is it required
             $(this)[0].innerText= ($(this)[0].innerText).replace("r","");
         });
    	 }
     });
     $("#remove_empty").click(function() {
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
    	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
    		 Ext.MessageBox.show({
    				msg: "Bay once saved is not allowed to modify",
    				buttons: Ext.MessageBox.OK,
    				icon: Ext.MessageBox.INFO
    			});	
    	 }
    	 else{
         $(".mytable tr td").each(function(e) {
        	 $(this).removeClass("empty");
        	 $(this)[0].innerText= ($(this)[0].innerText).replace("e","");
         });
    	 }
     });
     $("#remove_45footer").click(function() {
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
    	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
    		 Ext.MessageBox.show({
    				msg: "Bay once saved is not allowed to modify",
    				buttons: Ext.MessageBox.OK,
    				icon: Ext.MessageBox.INFO
    			});	
    	 }
    	 else{
         $(".mytable tr td").each(function(e) {
            	 $(this).removeClass("45footer");
            	 $(this)[0].innerText= ($(this)[0].innerText).replace("45","");
         });
    	 }
     });
     var bayrow_obj_count = 0,
      current_bayrow_obj_script = [],
      baytier_obj_count = 0,
      current_baytier_obj_script = [],
      cell_obj_count = 0,
      current_cell_obj_script = [],
      current_bay_row= [],
      current_bay_tier= [],
      current_bay_cell= [];
     
     //Ssaving the current bay 
     $("#pushvalues").on('click', function() {
    	// bay_saved = true;
    	 any_bay_saved = true;
    	 select_allow= false;
    	var current_bayrow_obj_script= [];
     		current_baytier_obj_script= [];
     		current_cell_obj_script= [];
     		var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
     	$("#"+bay_sec_id).removeClass("final");
     	var deck_Or_underdeck="",deck_Or_underdeck_table="";
     	if($("#deck_table").css("display") === "table"){
     	deck_Or_underdeck = "#deck_table tr td";
     	deck_Or_underdeck_table = "#deck_table";
     	}
     	else if($("#underdeck_table").css("display") === "table"){
     	deck_Or_underdeck = "#underdeck_table tr td";
     	deck_Or_underdeck_table = "#underdeck_table";
     	}
     	$("#removeCurrentBay").show(); //not needed
     	if($("#deck_table_div").css( "display" ) === "block"){
     		$("#deck_table_div")[0].id = bay_sec_id +"deckbay" ;
     		 bay_html[bay_sec_id]= $("#"+bay_sec_id+"deckbay")[0].outerHTML; 
     		$("#"+bay_sec_id+"deckbay")[0].id = "deck_table_div";
     		if( $("#deck_tier_template").val() === "Default"){
     			$("#"+current_working_Bay)[0].dataset.template = defaultDeckTemplate;
         		$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount(defaultDeckTemplate);
     		}
     		else{
     			$("#"+current_working_Bay)[0].dataset.template = $("#deck_tier_template").val();
         		$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount($("#deck_tier_template").val());
     		}
     	}
     	if($("#underdeck_table_div").css( "display" ) === "block"){
     	$("#underdeck_table_div")[0].id = bay_sec_id +"underdeckbay" ;
     	 	bay_html[bay_sec_id] = $("#"+bay_sec_id+"underdeckbay")[0].outerHTML; 
     	$("#"+bay_sec_id+"underdeckbay")[0].id = "underdeck_table_div";
     	if( $("#underdeck_tier_template").val() === "Default"){
 			$("#"+current_working_Bay)[0].dataset.template = defaultUnderDeckTemplate;
     		$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount(defaultUnderDeckTemplate);
 		}
 		else{
 			$("#"+current_working_Bay)[0].dataset.template = $("#underdeck_tier_template").val();
     		$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount($("#underdeck_tier_template").val());
 		}
     	}
          $(deck_Or_underdeck).each(function(e) {
              var selectedElements = this;
              var row_offset = $($(deck_Or_underdeck_table)[0].tHead.rows[0].cells[this.cellIndex]).text();
              tier_offset = this.parentNode.cells[0].innerHTML;
              var row_no = $($(deck_Or_underdeck_table)[0].tHead.rows[1].cells[this.cellIndex]).text();
              tier_no = this.parentNode.cells[1].innerHTML;
            //selected cell
              if ($(selectedElements).hasClass('selected')) {
                  var bay_row_obj = {
                      "pk": {}
                  };
                  bay_row_obj["pk"]["sectionNo"] = $("#sect_no").val();
                  bay_row_obj["pk"]["deckUnderDeck"] = $("#deck").val();
                  bay_row_obj["pk"]["bayOffset"] = $("#bay_offset").val();
                  bay_row_obj["pk"]["rowOffset"] = row_offset;
                  bay_row_obj["vesselRowNo"] = row_no;
                  var bay_tier_obj = {
                      "pk": {}
                  };
                  bay_tier_obj["pk"]["sectionNo"] = $("#sect_no").val();
                  bay_tier_obj["pk"]["deckUnderDeck"] = $("#deck").val();
                  bay_tier_obj["pk"]["bayOffset"] = $("#bay_offset").val();
                  bay_tier_obj["pk"]["tierOffset"] = tier_offset;
                  bay_tier_obj["vesselTierNo"] = tier_no;
                  bay_tier_obj["tweenDeckFlag"] = "N"; 				 //hardcoded
                  bay_tier_obj["secondaryTierNo"] = twodigits(tier_no - 1);
                  var cell_obj = {
                      "pk": {}
                  };
                  cell_obj["pk"]["sectionNo"] = $("#sect_no").val();
                  cell_obj["pk"]["deckUnderDeck"] = $("#deck").val();
                  cell_obj["pk"]["bayOffset"] = $("#bay_offset").val();
                  cell_obj["pk"]["rowOffset"] = row_offset;
                  cell_obj["pk"]["tierOffset"] = tier_offset;
                  cell_obj["isAvialable"] = "N";
                  cell_obj["doorDirectionIndicator"] = "N";
                  cell_obj["hotSpotFlag"] = "N";
                  cell_obj["isDeleted"] = "N";
                  cell_obj["reeferTypeFlag"] = "N";
                  cell_obj["onlyEmptyContainerAllowedFlag"] = "N";
                  cell_obj["allowed45Flag"] = "N";
                  
                  if($(selectedElements).hasClass("reefer")){
                 	 cell_obj["reeferTypeFlag"] = "Y";
                  }
                   if($(selectedElements).hasClass("45footer")){
                 	 cell_obj["allowed45Flag"] = "Y";
                  }
                   if($(selectedElements).hasClass("empty")){
                 	 cell_obj["onlyEmptyContainerAllowedFlag"] = "Y";
                  }
                  current_bayrow_obj_script.push(bay_row_obj);
                  current_baytier_obj_script.push(bay_tier_obj);
                  current_cell_obj_script.push(cell_obj);
                  bayrow_spm_script.push(bay_row_obj);
                  baytier_spm_script.push(bay_tier_obj);
                  cell_spm_script.push(cell_obj);
                  bayrow_obj_count++;        //not needed -- old code
                  baytier_obj_count++; 	  //not needed -- old code
                  cell_obj_count++;			//not needed -- old code
              }
          });
          
          //just to confirm
          	current_bay_row[bay_sec_id]	= "";
  			current_bay_tier[bay_sec_id] ="";
			current_bay_cell[bay_sec_id] ="";
			if(current_cell_obj_script.length>0){
				current_bay_row[bay_sec_id]	=buildUniqueData(current_bayrow_obj_script);
	    		current_bay_tier[bay_sec_id] =buildUniqueData(current_baytier_obj_script);
				current_bay_cell[bay_sec_id] = current_cell_obj_script;
			 	$("#"+current_working_Bay).removeClass("final");
		     	$("#"+current_working_Bay).addClass("saved");
		     	$("#"+current_working_Bay).css("background-color","green");
				Ext.MessageBox.show({
					msg: $("#bayNoId").text() + " bay saved successfully.",
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.INFO
				});
			}
			else{
				 var vslMsg="Do you want to save an empty bay ?";
		 			Ext.Msg.confirm('',vslMsg, function (answer) {
		 				if (answer == "yes") {
		 					$("#"+current_working_Bay).addClass("final");
		 					current_bay_row[bay_sec_id]	=buildUniqueData(current_bayrow_obj_script);
		 		    		current_bay_tier[bay_sec_id] =buildUniqueData(current_baytier_obj_script);
		 					current_bay_cell[bay_sec_id] = current_cell_obj_script;
		 				 	$("#"+current_working_Bay).removeClass("final");
		 			     	$("#"+current_working_Bay).addClass("saved");
		 			     	$("#"+current_working_Bay).css("background-color","green");
		 					Ext.MessageBox.show({
		 						msg: $("#bayNoId").text() + " bay saved successfully.",
		 						buttons: Ext.MessageBox.OK,
		 						icon: Ext.MessageBox.INFO
		 					});
		 				}
		 				else{
		 					select_allow= true;
		 				}
		 			});	
			}
			
			
     });
     
     //Click event for the saved bay
     $("#myVessel").on("click", "td.saved", function(ev) {
    	 if(!vesselSaved){
    	 select_allow= true;
    	  var current_deck = $(this).attr("data-deck_name"),
          current_sect_no = $(this).attr("data-sectno"),
          current_bay_offset = $(this).attr("data-bay_offset");
      $("#sect_no").val(current_sect_no);
      $("#deck").val(current_deck);
      current_working_Bay = current_sect_no + current_bay_offset + current_deck;
      $(".bay_no_h1").text($(this)[0].innerHTML + "(" + current_deck + ")");
      $("#bay_offset").val(current_bay_offset);
      if (current_deck === "U") {
    	  $("#deck_tier_template").hide();
          $("#underdeck_tier_template").show();
         	 getUnderDeckTemplateDetails($(this)[0].dataset.template);
         	 $("#underdeck_tier_template").val($(this)[0].dataset.template);
          $("#underdeck_table").css("display", "table");
          $("#deck_table").css("display", "none");
          $("#underdeck_table tr td").each(function(e) {
              $("#underdeck_table tr td").addClass("start");
          });
          $("#deck_table_div").hide();
          $("#underdeck_table_div").show();
          check_remove_zero_underdeck();
      } else if (current_deck === "D") {
    	  $("#deck_tier_template").show();
          $("#underdeck_tier_template").hide();
          	 getDeckTemplateDetails($(this)[0].dataset.template);
          	 $("#deck_tier_template").val($(this)[0].dataset.template);
          $("#deck_table").css("display", "table");
          $("#underdeck_table").css("display", "none");
          $("#deck_table tr td").each(function(e) {
              $("#deck_table tr td").addClass("start");
          });
          $("#underdeck_table_div").hide();
          $("#deck_table_div").show();
          check_remove_zero_deck();
      }
  	if($(this).hasClass("saved")){  // not required
			 $(".mytable tr td").each(function(e) {
	             $(this).removeClass("selected");
	             $(this).removeClass("reefer");
	             $(this).removeClass("empty");
	             $(this).removeClass("45footer");
	             $(this).removeAttr('style');
	            $(this)[0].innerText= "";
	         });
			 var max_tiers_deck = Number($(this)[0].dataset.maxtiers)+1,
				 max_tiers_underdeck= Number($(this)[0].dataset.maxtiers)+1;
			    if (current_deck === "D") {
			for( var k=0;k<(current_bay_cell[$(this)[0].id]).length; k++){
				$($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
				 if(current_bay_cell[$(this)[0].id][k].reeferTypeFlag==="Y"){
 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "r";
 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " reefer";
      }
 if(current_bay_cell[$(this)[0].id][k].onlyEmptyContainerAllowedFlag==="Y"){
	 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "e";
	 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " empty"; 
 }
 if(current_bay_cell[$(this)[0].id][k].allowed45Flag==="Y"){
	 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "45";
	 $(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(max_tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " 45footer";
}
			}
		}
			    else if (current_deck === "U") {
						for( var k=0;k<(current_bay_cell[$(this)[0].id]).length; k++){
							$($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
							 if(current_bay_cell[$(this)[0].id][k].reeferTypeFlag==="Y"){
								 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "r";
								 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " reefer";
							 }
			 if(current_bay_cell[$(this)[0].id][k].onlyEmptyContainerAllowedFlag==="Y"){
				 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "e";
				 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " empty"; 
			 }
			 if(current_bay_cell[$(this)[0].id][k].allowed45Flag==="Y"){
				 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML+ "45";
				 $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[max_tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " 45footer";
			}
						}
					}
		} 
  	$(this).css("background-color", "orange");
     }
     });
     
     //reset the current bay
     $("#reset_bay").on('click', function() {
    	 
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
    	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
    		 Ext.MessageBox.show({
    				msg: "Bay once saved is not allowed to reset",
    				buttons: Ext.MessageBox.OK,
    				icon: Ext.MessageBox.INFO
    			});	
    	 }
    	 else{
    	     if ($("#deck_table_div").css("display") === "block") {
                 bay_html.pop($("#deck_table_div")[0].outerHTML);			//!!! no affect; inocreect; but not affecting currenlty any other code as while saving the named index is rest to empty array and no fresh data is pushed !
             }
             if ($("#underdeck_table_div").css("display") === "block") {
                 bay_html.pop($("#underdeck_table_div")[0].outerHTML);
             }
             $(".mytable tr td").each(function(e) {
            	 if($(this).hasClass("selected")){
             		$(this).removeClass("selected");
             		$(this).addClass("deleted"); // !!! not needed
             	}
                 $(this).removeClass("reefer");
                 $(this).removeClass("empty");
                 $(this).removeClass("45footer");
                 $(this).removeAttr('style');
                 $(this)[0].innerText= "";
             });
             $("#pushvalues").show(); // save current bay - not needed
             
             // !!!   removing from the arrays which does not have unique data ; also logic below will only work for last saved bay
             
             bayrow_spm_script.splice(bayrow_spm_script.length - current_bayrow_obj_script.length, current_bayrow_obj_script.length);
             baytier_spm_script.splice(baytier_spm_script.length - current_baytier_obj_script.length, current_baytier_obj_script.length);
             cell_spm_script.splice(cell_spm_script.length - current_cell_obj_script.length, current_cell_obj_script.length);
    	 }
     });
     
     //function to generrate the unique values from the passed array - not working as expected
     var unique = function(list) {
         var result = [];
         $.each(list, function(i, e) {
             if ($.inArray(e, result) == -1) result.push(e);
         });
         return result;
     };
     
     //function to generrate the unique values from the passed array ; ( cannot explain)
     var buildUniqueData = function(data) {
         if (data.length === 0) {
             return [];
         } else {
             var items = data,
                 elems = [],
                 groups = [];
             for (var i = 0; i < items.length; i++) {
                 Array.prototype.push.call(elems, items[i]);
             }
             groups.push(groupBy(elems, function(item) {
                 return item;
             }));
             groupBy(groups, function(array) {
                 for (var i = 0; i < array.length; i++) {
                     var obj = array[i].slice();
                     Object.keys(obj).map(function(p) {
                         var length = obj.length;
//                         if (obj[p].hasOwnProperty("quantity")) {
//                             obj[p].quantity = length;
//                         }
                         groups[i] = obj[p];
                     });
                 }
             });

             function groupBy(array, f) {
                 var groups = {};
                 array.forEach(function(o) {
                     var group = JSON.stringify(f(o));
                     groups[group] = groups[group] || [];
                     groups[group].push(o);
                 });
                 return Object.keys(groups).map(function(group) {
                     return groups[group];
                 });
             }
             return groups;
         }
     };
     
     //Pusing the entire data to the server 
     var saveVessel = function() {
    	 vesselSaved = true;
			$("#screen_headings").text("Vessel Profile Screen");
	    	 $("#vesselInfo").show();
	    	 $(".mytable_div").css("display", "block !important");
	    	 var bay_row=[];
	    	 var bay_tier=[];
	    	 var bay_cell=[];
	    	 $("#myVessel tr table").each(function(e) {
	             var bayno1 = this.childNodes[0].childNodes[0].childNodes[0].innerText;
	             var bayno2 = this.childNodes[0].childNodes[0].childNodes[1].innerText;
	             
	            /* var bayno1 = this.childNodes[0].childNodes[0].childNodes[0].dataset.bay_no;
	             var bayno2 = this.childNodes[0].childNodes[0].childNodes[1].dataset.bay_no;*/
	             
	             var tierTemplate1 = this.childNodes[0].childNodes[0].childNodes[0].dataset.template;
	             var tierTemplate2 = this.childNodes[0].childNodes[0].childNodes[1].dataset.template;
	             
	             var sect_obj = {
	                     "pk": {}
	                 },
	                 bay_obj = {
	                     "pk": {}
	                 },
	                 bay_obj1 = {
	                     "pk": {}
	                 };

	             sect_obj["sectionType"] = "T";
	             sect_obj["hatchlessFlag"] = "N";
	             sect_obj["distanceFromFore"] = 848.00;
	             sect_obj["distanceFromForeUOM"] = "FT";
	             sect_obj["bayNote"] = " ";
	             sect_obj["isDeleted"] = "N";
	             
	             var is40Footer = $(this.childNodes[0].childNodes[0].childNodes[0]).hasClass("fortyfooter") ;
	             
	             if(is40Footer){
	            	 bay_obj["isLogicalBay"] = "Y";
	             }
	             else{
	            	  bay_obj["isLogicalBay"] = "N";
	             }
	             bay_obj["isContainerRowPresent"] = "Y";
	             
	             bay_obj1["isLogicalBay"] = "N";
	             bay_obj1["isContainerRowPresent"] = "Y";
	             
	             if (bayno2 === "") {
	                 section.push([bayno1, sect_start]);
	                 if  ($(this).attr('class') === "deckdouble" || $(this).attr('class') === "decksingle" ) {
	                     sect_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     sect_obj["deckOrUnderDeck"] = "D";
	                     
	                     bay_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj["pk"]["deckUnderDeck"] = "D";
	                     bay_obj["pk"]["bayOffset"] = 1;
	                     bay_obj["vesselBayNo"] = bayno1;
	                     bay_obj["tierTemplate"] = tierTemplate1;
	                     
	                     section_script.push(sect_obj);
	                     bay_script.push(bay_obj);
	                     
	                 } else if ($(this).attr('class') === "underdeckdouble" || $(this).attr('class') === "underdecksingle") {
	                     sect_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     sect_obj["deckOrUnderDeck"] = "U";
	                     
	                     bay_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj["pk"]["deckUnderDeck"] = "U";
	                     bay_obj["pk"]["bayOffset"] = 1;
	                     bay_obj["vesselBayNo"] = bayno1;
	                     bay_obj["tierTemplate"] = tierTemplate1;
	                     
	                     section_script.push(sect_obj);
	                     bay_script.push(bay_obj);
	                 }

	             } else {
	                 section.push([bayno1, bayno2, sect_start]);
	                 if ($(this).attr('class') === "deckdouble" || $(this).attr('class') === "decksingle" ) {
	                     sect_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     sect_obj["deckOrUnderDeck"] = "D";
	                     
	                     bay_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj["pk"]["deckUnderDeck"] = "D";
	                     bay_obj["pk"]["bayOffset"] = 0;
	                     bay_obj["vesselBayNo"] = bayno1;
	                     bay_obj["tierTemplate"] = tierTemplate1;
	                     
	                     bay_obj1["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj1["pk"]["deckUnderDeck"] = "D";
	                     bay_obj1["pk"]["bayOffset"] = 2;
	                     bay_obj1["vesselBayNo"] = bayno2;
	                     bay_obj1["tierTemplate"] = tierTemplate2;
	                     
	                     section_script.push(sect_obj);
	                     
	                     bay_script.push(bay_obj);
	                     bay_script.push(bay_obj1);
	                     
	                 } else if ($(this).attr('class') === "underdeckdouble" || $(this).attr('class') === "underdecksingle") {
	                     sect_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     sect_obj["deckOrUnderDeck"] = "U";
	                     bay_obj["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj["pk"]["deckUnderDeck"] = "U";
	                     bay_obj["pk"]["bayOffset"] = 0;
	                     bay_obj["vesselBayNo"] = bayno1;
	                     bay_obj["tierTemplate"] = tierTemplate1;
	                     bay_obj1["pk"]["sectionNo"] = $(this).attr('id');
	                     bay_obj1["pk"]["deckUnderDeck"] = "U";
	                     bay_obj1["pk"]["bayOffset"] = 2;
	                     bay_obj1["vesselBayNo"] = bayno2;
	                     bay_obj1["tierTemplate"] = tierTemplate2;
	                     section_script.push(sect_obj);
	                     bay_script.push(bay_obj);
	                     bay_script.push(bay_obj1);
	                 }
	             }
	         });
	    	 $("#myVessel tr table tbody tr td").each(function(e) {
	    		 if(current_bay_cell[$(this)[0].id] === undefined){
	    		 }else{
	    			 for(var b=0;b<current_bay_row[$(this)[0].id].length;b++){
	    				 bay_row.push(current_bay_row[$(this)[0].id][b]);
	    			 }
	    			 for(var b=0;b<current_bay_tier[$(this)[0].id].length;b++){
	    				 bay_tier.push(current_bay_tier[$(this)[0].id][b]);
	    			 }
	    			 for(var b=0;b<current_bay_cell[$(this)[0].id].length;b++){
	    				 bay_cell.push(current_bay_cell[$(this)[0].id][b]);
	    			 }
	    		 }
	    		 });
	    	$("#myVessel tr#deckrow table tbody tr td ").each(function(e) {
	    		 deck_ids.push($(this)[0].id);
	    	 });
	    	 $("#myVessel tr#underdeckrow table tbody tr td ").each(function(e) {
	    		 underdeck_ids.push($(this)[0].id);
	    	 });
	    	 var arrayCombined = $.map(deck_ids, function(v, i) { return [v, underdeck_ids[i]]; });
	    	 $("#underdeck_table").css("background","red !important");
	    	 $("#underdeck_table").css("left","0px !important");
	    	 $("#deck_table").css("left","0px !important");
	    	 for(var d=0; d<=arrayCombined.length;d++){
	    		 if(bay_html[arrayCombined[d]] === undefined){
	    			 bay_html[arrayCombined[d]] = "";
	    		 }
	    		 if(bay_html[arrayCombined[d+1]] === undefined){
	    			 bay_html[arrayCombined[d+1]] = "";
	    		 }
	    		 $("#bays_images").append('<div class="bays" style="float:left;padding-top:4%;width:45%;"><div>'+bay_html[arrayCombined[d]]+'</div><div>'+bay_html[arrayCombined[++d]]+'</div></div>');
	    	 }
	    	// $(".mytable_div").css("width", "575px");
	    	 $(".mytable_div").css("margin","10px");
	    	 var vessel_json;
	         vessel_json = {
	             "vesselInfo": vsl_obj,
	             "sectionList": unique(section_script),
	             "bayList": unique(bay_script),
	             "bayRowList": bay_row,
	             "bayTierList": bay_tier,
	             "cellList": bay_cell
	         };
	         var vesselData = JSON.stringify(vessel_json);
	         saveVesselProfile(vesselData);
	         $(".vessel_verticals").hide();
	         $(".remove_vessel_verticals").hide();
	         $(".mytable td").css("width", "35px");
	         $(".mytable td").css("height", "35px");
	         $('#unMarkBtnSection').hide();
	         $('#bay_details').hide();	
     };
     
     $("#getvalues").on('click', function() {
    	 if(!any_bay_saved){
    		var msg = "None of the bay is saved. Are you sure you want to save the vessel without saving any bay?";
				Ext.Msg.confirm('',msg, function (answer) {
					if (answer == "yes") {
						saveVessel();	
						}
					else{
					
					}
				});	
    	 }
    	 else{
    		 var all_bay_saved="";
    		 var unsavedbays="";
    		 $("#myVessel tr table tbody tr td").each(function(e) {
    			 if($(this).css("display")==="none"){
    				 
    			 }
    			 else{
    			 if($(this)[0].className === "saved"){
    			}
    			else{
    				unsavedbays= unsavedbays +" "+ ($(this)[0].innerText +" " + ($(this)[0].id).slice(-1))+ ",";
    			}
    		 }
    		 });
    		 if(all_bay_saved){
    			 saveVessel();
    			 
			 	
    		 }
    		 else{
    			 var vslMsg;
    			 if(unsavedbays.length>0){
    				 vslMsg =unsavedbays +" bays are not saved. </br></br> Unsaved bay data will be lost. Are you sure - you want to save the vessel anyway ?";	 
    			 }
    			 else{
    				 vslMsg ="All the bays are saved.Click Yes to save the vessel.";
    			 }
    	 			Ext.Msg.confirm('',vslMsg, function (answer) {
    	 				if (answer == "yes") {
    	 					saveVessel();
    	 				}
    	 				else{
    	 					
    	 				}
    	 			});	    			 
    		 }
    		 $("#vesselDetails_code").val($("#vessel_no").val());
			 $("#vesselDetails_name").val($("#vessel_name").val());
	 		 $("#vesselDetails").show();
    	 }
    
     });
     
     //Clearing the complete vessel
     $("#clearVessel").click(function(){
    	 $("#myVessel tr table tbody tr td").each(function(e) {
	    		 if(current_bay_cell[$(this)[0].id] === undefined){
	    		 }else{
	    			 current_bay_row[$(this)[0].id] = [];
	    			 current_bay_tier[$(this)[0].id] = [];
	    			 current_bay_cell[$(this)[0].id]= [];
	    			 bay_row = [];
	    			 bay_tier = [];
	    			 bay_cell = [];
	    			 bay_html = [];
	    		 }
	    		 $(this).removeClass("saved");
	    		 if($(this).hasClass("final")){
	    		 }
	    		 else{
	    			 $(this).addClass("final");
	    		 }
	    		 $(this).css("background-color","red");
	    		 $(".mytable tr td").each(function(e) {
	                 $(this).removeClass("selected");
	                 $(this).removeClass("reefer");
	                 $(this).removeClass("empty");
	                 $(this).removeClass("45footer");
	                 $(this).removeAttr('style');
	                 $(this)[0].innerText= "";
	             });
     });
     });
     
     //Close the page
     $("#close_vessel").click(function(){
    	 if(vesselSaved){
    		 close();
    	 }
    	 else{
    		 var vslMsg="Vessel data will be lost. Do you want to close the application?";
 			Ext.Msg.confirm('',vslMsg, function (answer) {
 				if (answer == "yes") {
 				close();
 				}
 				else{
 					
 				}
 			});	
    	 }
     });
 });