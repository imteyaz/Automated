
Modules.admin.user_admin.group_user_security.deniedMenuGrid = function () {
	var cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
		clicksToMoveEditor: 1,
        clicksToEdit:1
        
	});
	
	 Ext.define('FunctionAccessCodeAssociation', {
	     extend: 'Ext.data.Model',
	     fields: [
	         {name: 'code', type: 'string'},
	         {name: 'name',  type: 'string'},
	         {name: 'accessCode',type: 'string'}
	     ]
	 });
	var DeniedMenuGridStore = {
		    model: 'FunctionAccessCodeAssociation',
            queryTypeCmc:'local',
            data : []
	};
	var accessCombo=Ext.create('Ext.cmc.ComboBox', {
               storeObjCmc: {
	               model: 'GenericLookUpDTO',
	               data: [{'code' : '1','name' : 'FULL CONTROL'},{'code' : '2','name' : 'QUERY/INSERT/UPDATE'},{'code' : '3','name' : 'QUERY/INSERT'},{'code' : '4','name' : 'QUERY'}],
	   			   queryTypeCmc:'local'
	           },
	           displayField: 'name',
               valueField: 'code',
               queryMode: 'local',
		       allowBlank: false,
		       paging: false,
			   editable :false,
               listConfig: {
            	    loadingText: Modules.Msgs.loading,
					emptyText: Modules.Msgs.noComboValueFound,
					getInnerTpl: function() {
						return '<table class="boldtable"><tr><td colspan="2" height="4"></td></tr><tr valign="top"><td width="250px" align="left">{name}</td></tr></table>';
					}
				}
		});
	var groupGrid = {
		xtype: 'cmcgrid',
		height: 250,
		id : Modules.CompIds.deniedMenuGridId,
		storeObjCmc: DeniedMenuGridStore,
		plugins: [cellEditing],			
        viewConfig : {
			stripeRows : true
		},
		selModel: {
            selType: 'cellmodel'
        },
    	statefulCmc:false, 
    	setGridColumnsFuncCmc: function () {
			var colsArr = [{
				header: Modules.admin.user_admin.user_management.labels.type,//'Type',
				hideable : false,
                width : 200,
				dataIndex: 'accessCode',
				editor : accessCombo,
	            renderer: function (value) {
                    var store = accessCombo.getStore();
                    if (store.findExact('code', value) > -1) {
                        value = store.getAt(store.findExact('code', value)).get('name');
                    }
                    return value;
                }
			},{
				header: Modules.admin.user_admin.user_management.labels.functionName,//'Function Name',
				width : 300,
				dataIndex: 'name'
			
			}];
			return colsArr;
		}
	}
	return groupGrid;
	} //EOF