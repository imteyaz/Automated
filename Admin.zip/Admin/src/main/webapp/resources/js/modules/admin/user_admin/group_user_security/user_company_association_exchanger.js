
Modules.admin.user_admin.group_user_security.user_company_association_grid	= function(){
	var panel	=	{
		xtype:'cmcpanelwithgridexchanger',
		addDefaultColumnCmc:true,
		width:700,
		height:200,
		region:'center',
		btnTopMarginCmc:'50px 0px 5px 0px',
		modelKeyFields :['name'],
		setRightGridFuncCmc:function(){ 
			var store = {
				model: 'GenericLookUpDTO',
				url: 'commonLov/getCompaniesByServiceType',
				paging : true,
				queryTypeCmc : 'remote',
				listeners : {
					beforeload:function(){
						var form = Ext.getCmp(Modules.CompIds.oceanUserManagementWindowId).down('#OceanUserManagementForm');
						var userid = form.down('#userId').getValue();
						this.proxy.extraParams.userId = userid;
						this.proxy.extraParams.limit = 100;
						this.pageSize = 100;
					}
				},
				autoLoad : true
			}; 
			var grid = {
				xtype: 'cmcgrid',
				id :'companyGrid',
				storeObjCmc: store,
				title:'List of Companies ',
				showPagingBarCmc : true,
				addPagingComboCmc:false,
				paging:true,
				setGridColumnsFuncCmc: function () {
					 var columns = [{
						header : 'Name',
						flex :1,
						dataIndex : 'name'
					}]; 
					return columns;
				}
			}; 
			return grid;
		}
	}; 
	return panel; 
};//End Of Grid Exchanger Grid 