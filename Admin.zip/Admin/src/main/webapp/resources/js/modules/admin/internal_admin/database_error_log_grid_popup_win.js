/**
 * 
 */
Ext.QuickTips.init();
Modules.admin.internalAdmin.databaseErrorLog.popupDatabaseErrorLogGrid = function(myStoreObj,rowIndex,record)
{
	var win = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:'internalAdminDatabaseErrorPopupWindowId',//Give some id to window
		gridCompCmc:Ext.getCmp(Modules.CompIds.internalAdminDatabaseErrorLogGridId),//Pass the component of grid at which this window will be opened
		title:'Database Error Log',
		editableCmc:false,//Set this to false if all the fields should be readOnly
		saveOrDoneBtnValidateHandlerFuncCmc:'',//This should be a function specified in instance. It will be called in save or done button handler and will be used for instance specific validations like duplication check. It should return true or false for sure.
		saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server if requried
		width:800,
		setFormItemsFuncCmc:function(){
			  var itemsArr = [];
			   var errorLogDate =
			   {
					   	xtype: 'cmctextfield',
						name: 'errorLogDate',
						fieldLabel: 'Error Log Date',
						width:220,
						labelWidth:100,
						labelAlign:"left",
						margin : '5px 0px 5px 15px'
			   };
			   
			   var userName =
			   {
					   	xtype: 'cmctextfield',
						name: 'userName',
						fieldLabel: 'User Name',
						width:210,
						labelWidth:85,
						labelAlign:"left",
						margin : '5px 0px 5px 15px'
			   };
			   
			   var errorDes =
			   {
					   	xtype: 'cmctextfield',
						name: 'description',
						fieldLabel: 'Error Description',
						width:500,
						labelWidth:100,
						labelAlign:"left",
						margin : '5px 0px 5px 15px'
			   };
			   
			   var hostName =
			   {
					   	xtype: 'cmctextfield',
						name: 'hostName',
						fieldLabel: 'Host Name',
						width:210,
						labelWidth:80,
						labelAlign:"left",
						margin : '5px 0px 5px 15px'
			   };
			   var errorFnDes =
			   {
					   	xtype: 'cmctextfield',
						name: 'errorFnDes',
						fieldLabel: 'Error Fn Des',
						width:670,
						labelWidth:100,
						labelAlign:"left",
						margin : '5px 0px 5px 15px',
						labelSeparator:'',
						readOnly : true,
						listeners: {
				render: function(c) {
					 Ext.QuickTips.register({
						target: c.getEl(),
						text:'Error Function Description'
					});
				}
			}
			   };
			   var errorPosition =
			   {
					   	xtype: 'cmctextfield',
						name: 'errorPosition',
						fieldLabel: 'Error Position',
						width:155,
						labelWidth:85,
						labelAlign:"left",
						margin : '5px 0px 5px 15px'
			   };
			   
			  
			   
			    var anotherLayout = [{
			    	 xtype:'container',
			    	 layout:'column',
			    	 defaults:{
			    		 margin : '15px 0px 0px 15px'
			    	 },
			    	 items:[
			    	   {
			    		   columnWidth:.5,
			    		   xtype:'container',
			    		   layout:'form',
			    		   items:[ errorLogDate,userName,hostName]
			    	   },
			    	   {
			    		   columnWidth:.5,
			    		   xtype:'container',
			    		   layout:'form',
			    		   items:[ errorDes, errorPosition,errorFnDes]		
			    	   }
			    	 ]
			    	
			    }];
			return anotherLayout;}
		});	
		return win;//Returning the window object ultimately from the funciton
	
};