Modules.admin.auditlog.tabparentpanel = function(menu) {
	var panel={
			xtype:'cmctabparentpanel',
			title:menu.text,
			id:Modules.CompIds.auditLogTabPanelId,
			showNorthItemCmc:true,
			setNorthItemFuncCmc:Modules.admin.auditlog.from,
			setCenterItemFuncCmc:Modules.admin.auditlog.tabpanel
			
	};	
	return panel;
};

