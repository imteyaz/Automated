Modules.Dashboard.CustomerReconStatusForm = function(){
	var custLovValidate = "success";
	var selectedCmpCd = '';
	var testStore		=		{
			model: 'GenericSuplrCustmerLookUpDTO',
			url:'getCustomers',
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					selectedCmpCd = Ext.getCmp('headerCompanyComboID').getValue();
					var userType = Modules.GlobalVars.loginUserTypeCode;
					var userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.cmpnyCode = selectedCmpCd;
					this.proxy.extraParams.userTyp = userType;
					this.proxy.extraParams.userId = userId;
				}
			},
			paging:true
		};

	//var ediFormObj = function() {
		var form = {
			xtype : 'cmcform',
			id : 'dbCustRecoStatFormId',
			width: 1050,
			height:95,
			bodyStyle: 'background-color: #FFFFFF', 
			showFieldsetCmc : false,
			//margin : '4px 0px 4px 100px',
			//width : '900',
			collapsible:true,
			tbar:[{
				text:"Clear",
				xtype:"button",
				iconCls:"clear",
				//tooltip: Modules.Msgs.clearBtnTooltip,
				handler:function(){
					Ext.getCmp('dbCustRecoStatFormId').getForm().reset();
					custLovValidate = "success";
					Ext.getCmp('DbCustomerReconStatGridOneId').getStore().loadPage(1);
					Ext.getCmp('DbCustomerReconStatGridTwoId').getStore().load({callback: function(records, operation, success) {
					    if(success == true)
				    	{
				    	var count = Ext.getCmp('DbCustomerReconStatGridTwoId').getStore().getCount();
						   if(count == 0)
							   Ext.MessageBox.show({
							        title: '',
							        msg: Modules.Msgs.noRecordsInGrid,
							        buttons: Ext.MessageBox.OK,
							        icon:Ext.MessageBox.INFO
							    }); 
				    	}
			   }});
				}
			},{ xtype: "button",
				text:"Retrieve",
				itemId:'retrieveBtn',
				iconCls:"retrieve",
				//tooltip: Modules.Msgs.retrieveBtnTooltip,
				handler:function(){
					var cmpCd = Ext.getCmp('headerCompanyComboID').getValue();
					if(cmpCd==null)
						{
						  Ext.MessageBox.show({
						        title: '',
						        msg: 'Company code is mandatory field.',
						        buttons: Ext.MessageBox.OK,
						        icon: Ext.MessageBox.ERROR
						    }); 
						}
					else
						{ 
						if((Ext.getCmp('dbCustReconStatCustomerId').getValue()) == null)
							{
							   custLovValidate="success";
							}
							
						if(custLovValidate=="success")
							{
							//this.up('form').collapse();
								Ext.getCmp('DbCustomerReconStatGridOneId').getStore().load({callback: function(records, operation, success) {
								    if(success == true)
							    	{
							    	var count = Ext.getCmp('DbCustomerReconStatGridOneId').getStore().getCount();
									   if(count == 0)
										   Ext.MessageBox.show({
										        title: '',
										        msg: Modules.Msgs.noRecordsInGrid,
										        buttons: Ext.MessageBox.OK,
										        icon:Ext.MessageBox.INFO
										    }); 
							    	}
						   }});
								Ext.getCmp('DbCustomerReconStatGridTwoId').getStore().load({callback: function(records, operation, success) {
								    if(success == true)
							    	{
							    	var count = Ext.getCmp('DbCustomerReconStatGridTwoId').getStore().getCount();
									   if(count == 0)
										   Ext.MessageBox.show({
										        title: '',
										        msg: Modules.Msgs.noRecordsInGrid,
										        buttons: Ext.MessageBox.OK,
										        icon:Ext.MessageBox.INFO
										    }); 
							    	}
						   }});
							}
						}
				}
				
			}],
			setFormItemsFuncCmc : function() {
				var itemsArr = [];
				var customerCombo				=		{
						xtype: 'cmccombobox',
						fieldLabel:Modules.LblsAndTtls.customerTtl,
						displayField: 'code',
						storeObjCmc: testStore,
						valueField: 'code',
						labelWidth: 53,
						labelAlign:"left",
						width: 160,
						id: 'dbCustReconStatCustomerId',
						name: 'dbCustomerName',
						matchFieldWidth: false,
				        margins : '0px 4px 0px 0px',
						paging:true,
						validateUrlCmc:'customerComboValidate',
						//alert(selectedCmpCd),
						//validateParamsCmc:{'cmpnyCode':selectedCmpCd},
						validateParamsCmc:[{name:'cmpnyCode', id:'headerCompanyComboID'},{name:'userTyp', val:Modules.GlobalVars.loginUserTypeCode},{name:'userId', val:Modules.GlobalVars.loginUserId}],

						validateSuccessFuncCmc:function(serverRespOjbData){
							//Modules.GlobalVars.dashboardValdidateSuccess="success";
							custLovValidate = "success";
							var customerName = serverRespOjbData.name;
							Ext.getCmp('dbCustomerCodeDescId').setValue(customerName);
							return true;
						},
						validateFailFuncCmc:function(){
							//Modules.GlobalVars.dashboardValdidateSuccess="fail";
							custLovValidate = "fail";
							Ext.getCmp('dbCustomerCodeDescId').setValue("");
							return true;
						},												
						listConfig: {
							width: 700,
							loadingText: 'Loading...',
							height: 300,
							deferEmptyText: false,
							emptyText: 'No Values Found!',
							getInnerTpl: function () {
								return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td><td width="150px" align="left">{addr_1}</td><td width="70px" align="left">{addr_2}</td><td width="100px" align="left">{city_nm}</td><td width="50px" align="left">{state_cd}</td><td width="50px" align="left">{cntry_cd}</td><td width="50px" align="left">{po_box}</td><td width="150px" align="left">{rmrk}</td> </tr></table>';
							}
						},
						listeners : {
							focus : function() {
								/*selectedCmpCd = Ext.getCmp('dashboardCompanyId').getValue();
								Ext.getCmp('dashboardCompanyId').setReadOnly(true);*/
							}
						}
				};
				var customerDesc = {
						xtype : 'cmctextfield',
						id : 'dbCustomerCodeDescId',
						name : 'dbCustomerCodeDesc',
						width : 330,
						readOnly:true
						};
				
				
				/** START Container..1 Component* */
				var container1 = {
						xtype : 'container',
						layout : 'hbox',
						margin : '10px 0px 4px 2px',
						/*defaults : {
							margin : '0px 10px 0px 50px'
						},*/
						items : [customerCombo, customerDesc]
				};
				itemsArr = [ container1];
				return itemsArr;
			},
			listeners:{
				render: function(panel){
					
	    			Ext.Ajax.request({
	                    url: 'getDefaultSaveSearchStatusMonitor',
	                    params: {
	                        userId: Modules.GlobalVars.loginUserId,
	                        screenId: 'me.screenId',
	                        serviceType: Modules.GlobalVars.selectedServiceTypeCode,
	                        companyCode: Modules.GlobalVars.selectedCompanyCode
	                    },
	                    method: 'GET',
	                    success: function (response) {
	                        var temp = Ext.decode(response.responseText);

	                        if (temp.totalCount > 0) {
	                            var searchCriteria = temp.items[0].searchCriteriaData || temp.items[0].searchCriteria;
	                            var criteriaObject = Ext.decode(decodeURIComponent(searchCriteria));
	                            try{
	                            	
	                            	if(typeof criteriaObject == "string"){
	                            		
	                            		criteriaObject = Ext.JSON.decode(criteriaObject);
	                            	}
	                            }catch(e){}
	                            
	                            panel.down('#dbCustReconStatCustomerId').setValue(criteriaObject.customerCode);
	                            panel.down('#dbCustomerCodeDescId').setValue(criteriaObject.customerNm);
	                            
	                    }
	                }
	               });
				}
					
				
			}

		};
		//return form;
	//};
	/*var ediWindow = Ext.create('Ext.cmc.Window', {
		id : 'ediWindowId',
		height : 350,
		width : 1350,
		title  : 'Edi Error MEssage',
		x : 200,
		y : 10,
		
		setCenterItemFuncCmc : ediFormObj
		//setSouthItemFuncCmc : ediFormObj

	});
	ediWindow.show();
	return ediWindow;*/
	return form;
};