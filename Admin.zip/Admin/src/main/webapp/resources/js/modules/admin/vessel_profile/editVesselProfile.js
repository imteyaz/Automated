$(document).ready(function(){
	 function twodigits(n) {
         return n > 9 ? "" + n : "0" + n;
     }
var vesselSaved = false,defaultDeckTemplate,defaultUnderDeckTemplate;	 
var sect_spm=[],bay_spm=[];
sect_spm = data.sectionList;
bay_spm = data.bayList;
cell_spm = data.cellList;
var del_bayrow_obj_script=[],
del_baytier_obj_script=[],
del_cell_obj_script=[],
current_del_bayrow_obj_script=[],
current_del_baytier_obj_script=[],
current_del_cell_obj_script=[],
bay_script=[];
/*currentbay_template,
currentdeckbay_html,
currentunderdeckbay_html;*/

var maxRows = data.vesselInfo.maxRows;
if(maxRows % 2 === 0){
	 maxRows = Number(maxRows) + 1;
}
var maxRowsValue = maxRows-1,
	zeroRow = parseInt(maxRows/2);
//tier(row) values from 24 to 0

for(var i=0;i<maxRows;i++){
	if(i === zeroRow){
		$(".tier_offset").append('<th class="zeroth_row" colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+i+'</th>');
		if(maxRowsValue>=0){
			$(".tier_value").append('<th class="zeroth_row" colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(maxRowsValue)+'</th>');
			maxRowsValue = maxRowsValue -2;
		}
	}
	else{
		$(".tier_offset").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+i+'</th>');
		if(maxRowsValue>=0){
			$(".tier_value").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(maxRowsValue)+'</th>');
			maxRowsValue = maxRowsValue -2;
		}
	}
	
}
//tier(row) values from 0 to 23
for(var i=1;i<maxRows;i=i+2){
		$(".tier_value").append('<th colspan="1" scope="colgroup" style="padding-bottom: 10px;">'+twodigits(i)+'</th>');
}
var templateDeckHeaders = getTemplateHeadersOrDetails('TemplateHeader','type','TD','headerId','',0,100),
	templateUnderDeckHeaders = getTemplateHeadersOrDetails('TemplateHeader','type','TU','headerId','',0,100);
for(var t=0;t<templateDeckHeaders.data.length;t++){
 $("#deck_tier_template").append('<option value='+templateDeckHeaders.data[t].headerId+'>'+templateDeckHeaders.data[t].headerId+'</option>');
 if(templateDeckHeaders.data[t].isDefault=== "Y"){
	 defaultDeckTemplate = templateDeckHeaders.data[t].headerId;
 }
}
for(var t=0;t<templateUnderDeckHeaders.data.length;t++){
 $("#underdeck_tier_template").append('<option value='+templateUnderDeckHeaders.data[t].headerId+'>'+templateUnderDeckHeaders.data[t].headerId+'</option>');
 if(templateUnderDeckHeaders.data[t].isDefault=== "Y" ){
	 defaultUnderDeckTemplate = templateUnderDeckHeaders.data[t].headerId;
 }
}

for(var i = 0; i<sect_spm.length;i++){
if(sect_spm[i]["deckOrUnderDeck"] === "D"){
$("#deck_row").append("<table class='deck'  style='border-bottom:2px solid red;float:left;margin-right:10px'><tbody><tr id='"+sect_spm[i]["pk"]["sectionNo"]+""+sect_spm[i]["deckOrUnderDeck"]+"'></tr></tbody></table>");
}
if(sect_spm[i]["deckOrUnderDeck"] === "U"){
$("#underdeck_row").append("<table class='underdeck'  style='border-bottom:2px solid red;float:left;margin-right:10px'><tbody><tr id='"+sect_spm[i]["pk"]["sectionNo"]+""+sect_spm[i]["deckOrUnderDeck"]+"'></tr></tbody></table>");
}
}
for(var j = 0; j<bay_spm.length;j++){
$("#"+bay_spm[j]["pk"]["sectionNo"]+bay_spm[j]["pk"]["deckUnderDeck"]).append("<td id='"+bay_spm[j]["pk"]["sectionNo"]+""+bay_spm[j]["pk"]["bayOffset"]+""+bay_spm[j]["pk"]["deckUnderDeck"]+"' data-sectno='"+bay_spm[j]["pk"]["sectionNo"]+"' data-deck_name='"+bay_spm[j]["pk"]["deckUnderDeck"]+"' data-bay_offset='"+bay_spm[j]["pk"]["bayOffset"]+"' data-template='"+bay_spm[j]["tierTemplate"]+"' data-modified='' contenteditable=false data-fortyfooter='" + bay_spm[j]["isLogicalBay"] + "'>" + bay_spm[j]["vesselBayNo"]+"</td>");
}

$($("#deck_row").find("[data-fortyfooter='Y']")).addClass("fortyFooterLeft fortyfooter");

$($("#underdeck_row").find("[data-fortyfooter='Y']")).addClass("fortyFooterLeft fortyfooter");


$("#myVessel tr table tbody tr td").each(function(e) {
	for( var p=0;p<cell_spm.length; p++){
		if((Number(cell_spm[p]["pk"]["sectionNo"])) === Number((($(this)[0].id).slice(0,-1)).slice(0,-1)) 
				&& ($(this)[0].id).slice(-1) === (cell_spm[p]["pk"]["deckUnderDeck"])
				&& Number((($(this)[0].id).slice(0,-1)).slice(-1)) === (Number(cell_spm[p]["pk"]["bayOffset"])))
			{
				$("#"+$(this)[0].id).css("background","pink");
			}
	}
});
var getDeckTemplateDetails = function(templateHeaderVal){
	var TemplateDetails ={};
	TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
/*	if(currentbay_template === templateHeaderVal ){
		$("#deck_table").html(currentdeckbay_html);
	}else{*/
		 $("#deck_tbody").empty();
		 	//var template_deck_selected =  $("#deck_tier_template" ).val();
		 	for(var t=TemplateDetails.data.length-1;t>=0;t--){
		 		$("#deck_tbody").append("<tr><th rowspan='1' scope='rowgroup'>" + TemplateDetails.data[t].pk.offset + "</th><th rowspan='1' scope='row' style='padding-left:10px'>" + TemplateDetails.data[t].vesselLabel+ "</th></tr>");
		 	}
		 	$("#deck_table tbody tr").each(function(e) {
		         for (var x = 0; x < maxRows; x++) {
		             $(this).append("<td></td>");
		         }
		     });
	//}
 	
 };
 var getTierCount = function(templateHeaderVal){
	 var TemplateDetails ={};
	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
	 return TemplateDetails.data.length;
 };
 var getUnderDeckTemplateDetails = function(templateHeaderVal){
  	var TemplateDetails ={};
  	 TemplateDetails = getTemplateHeadersOrDetails('TemplateDetails','pk.headerId',templateHeaderVal,'pk.headerId','',0,100);
  /*	if(currentbay_template === templateHeaderVal ){
  		$("#underdeck_table").html(currentunderdeckbay_html);
  	}
  	else{*/
  		 $("#underdeck_tbody").empty();
  	   	//var template_deck_selected =  $("#deck_tier_template" ).val();
  	   	for(var t=TemplateDetails.data.length-1;t>=0;t--){
  	   		$("#underdeck_tbody").append("<tr><th rowspan='1' scope='rowgroup'>" + TemplateDetails.data[t].pk.offset  + "</th><th rowspan='1' scope='row' style='padding-left:10px'>" + TemplateDetails.data[t].vesselLabel+ "</th></tr>");
  	   	}
  	   	$("#underdeck_tbody tr").each(function(e) {
  	           for (var x = 0; x < maxRows; x++) {
  	               $(this).append("<td></td>");
  	           }
  	       });
  	//}
  	
   };
   $( "#deck_tier_template").change(function(e) {
   	var templateHeaderVal =  $( "#deck_tier_template" ).val();
   	if($( "#deck_tier_template" ).val() === "Default"){
   		getDeckTemplateDetails(defaultDeckTemplate);
   	}
   	else{
   		getDeckTemplateDetails(templateHeaderVal);	
   	}
   	check_remove_zero_deck();
   	});
    $( "#underdeck_tier_template").change(function(e) {
    	var templateHeaderVal =  $( "#underdeck_tier_template" ).val();
    	if($( "#underdeck_tier_template" ).val() === "Default"){
    		getUnderDeckTemplateDetails(defaultUnderDeckTemplate);
    	}
    	else{
    		getUnderDeckTemplateDetails(templateHeaderVal);	
    	}
    	check_remove_zero_underdeck();
    	});
 $("#myVessel").on("click", "td", function(ev) {
	 $("#template_selects").show();  // !! redundant
	 if(!vesselSaved){
	 $(this).css("background-color","yellow");
	 select_allow = true;
	 var template =$(this)[0].dataset.template;
	 var tiers_deck,tiers_underdeck;
	 current_bayrow_obj_script=[];
	 current_baytier_obj_script=[];
	 current_cell_obj_script=[];
	 current_del_bayrow_obj_script=[];
	 current_del_baytier_obj_script=[];
	 current_del_cell_obj_script=[];
	 $(".mytable tr td").each(function(e) {
         $(this).removeClass("selected");
         $(this).removeClass("reefer");
         $(this).removeClass("empty");
         $(this).removeClass("45footer");
         $(this).removeClass("deleted");
         $(this).removeAttr('style');
         $(this)[0].innerText= "";
     });
  	var current_deck = $(this).attr("data-deck_name"),
		current_sect_no = $(this).attr("data-sectno"),
		current_bay_offset = $(this).attr("data-bay_offset");
  	$("#bay_no").val($(this).text());
  	$("#sect_no").val(current_sect_no);
  	$("#bay_offset").val(current_bay_offset);
  	$("#deck").val(current_deck);
  	$(".bay_no_h1").text($(this)[0].innerHTML + "(" + current_deck + ")");
	 if(current_deck ==="D"){
		 $(".mytable").css("display","block");
		 $("#deck_tier_template").show();
         $("#underdeck_tier_template").hide();
		 if(template === "null" || template === ""){
			 $( "#deck_tier_template").val("Default");
			 getDeckTemplateDetails(defaultDeckTemplate);
		 }else{
			 $( "#deck_tier_template").val(template);
			 getDeckTemplateDetails(template);
		 }
		if($( "#deck_tier_template").val() === "Default"){
			tiers_deck = Number(getTierCount(defaultDeckTemplate))+1;
		}else{
			 tiers_deck = Number(getTierCount($( "#deck_tier_template").val()))+1;
		}
		 
	 	 $("#deck_table_div").show();
	 		 $("#underdeck_table_div").hide();
	 		check_remove_zero_deck();
	 }
	 else if(current_deck==="U"){
		 $(".mytable").css("display","block");
		 $("#deck_tier_template").hide();
         $("#underdeck_tier_template").show();
		 if(template == "null" || template == ""){
			 $( "#underdeck_tier_template").val("Default");
			 getUnderDeckTemplateDetails(defaultUnderDeckTemplate);
		 }else{
			 $( "#underdeck_tier_template").val(template);
			 getUnderDeckTemplateDetails(template);
		 }
		 if($( "#underdeck_tier_template").val() === "Default"){
			 tiers_underdeck = Number(getTierCount(defaultUnderDeckTemplate))+1;
			}else{
				tiers_underdeck = Number(getTierCount($( "#underdeck_tier_template").val()))+1;
			}
	 	$("#deck_table_div").hide();
	 		 $("#underdeck_table_div").show();
	 		check_remove_zero_underdeck();
	 }
  	if($(this).hasClass("edited")){
  		$(this).css('background-color','orange');
  	   if (current_deck === "D") {
			for( var k=0;k<(current_bay_cell[$(this)[0].id]).length; k++){
				if(current_bay_cell[$(this)[0].id][k]["isDeleted"] === "N"){
					$($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
					 if(current_bay_cell[$(this)[0].id][k].reeferTypeFlag==="Y"){
	$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "r";
	$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " reefer";
	     }
	if(current_bay_cell[$(this)[0].id][k].onlyEmptyContainerAllowedFlag==="Y"){
		 $(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "e";
		 $(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " empty"; 
	}
	if(current_bay_cell[$(this)[0].id][k].allowed45Flag==="Y"){
		 $(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].innerHTML + "45";
		 $(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className =$(($("#deck_table")[0].rows[(tiers_deck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"])))].cells[(Number(((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]))[0].className + " 45footer";
	}
				}	
				}
				
		}
			    else if (current_deck === "U") {
						for( var k=0;k<(current_bay_cell[$(this)[0].id]).length; k++){
							if(current_bay_cell[$(this)[0].id][k]["isDeleted"] === "N"){	
							$($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
							 if(current_bay_cell[$(this)[0].id][k].reeferTypeFlag==="Y"){
								 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "r";
								 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " reefer";
							 }
			 if(current_bay_cell[$(this)[0].id][k].onlyEmptyContainerAllowedFlag==="Y"){
				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "e";
				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " empty"; 
			 }
			 if(current_bay_cell[$(this)[0].id][k].allowed45Flag==="Y"){
				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].innerHTML+ "45";
				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number((current_bay_cell[$(this)[0].id])[k]["pk"]["tierOffset"]))].cells[((Number((current_bay_cell[$(this)[0].id])[k]["pk"]["rowOffset"]))+2)])[0].className + " 45footer";
			}
						}
			    }
					}
	 } else{
  	for( var k=0;k<cell_spm.length; k++){
  		if( (Number(cell_spm[k]["pk"]["sectionNo"]) === Number(current_sect_no)) && (cell_spm[k]["pk"]["deckUnderDeck"] === "D") && (Number(cell_spm[k]["pk"]["bayOffset"]) === Number(current_bay_offset)) ){
  			 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
   			$($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)]).attr("version",cell_spm[k]["version"]); // not in use currently
   			if(cell_spm[k]["reeferTypeFlag"]==="Y"){
   				 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "r";
 				 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " reefer";
   								 }
   				 if(cell_spm[k]["onlyEmptyContainerAllowedFlag"]==="Y"){
   					 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML =$($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "e";
   					 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " empty"; 
   				 }
   				 if(cell_spm[k]["allowed45Flag"]==="Y"){
   					 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML =$($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML+ "45";
   					 $($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className =$($("#deck_table")[0].rows[tiers_deck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " 45footer";
   				 }
			 }
  		 if( (Number(cell_spm[k]["pk"]["sectionNo"]) === Number(current_sect_no)) && (cell_spm[k]["pk"]["deckUnderDeck"] === "U") && (Number(cell_spm[k]["pk"]["bayOffset"]) === Number(current_bay_offset)) ){
  			 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)]).addClass("selected");
  			$($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)]).attr("version",cell_spm[k]["version"]);
  			if(cell_spm[k]["reeferTypeFlag"]==="Y"){
  				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "r";
				 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " reefer";
  								 }
  				 if(cell_spm[k]["onlyEmptyContainerAllowedFlag"]==="Y"){
  					 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML =$($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML + "e";
  					 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className = $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " empty"; 
  				 }
  				 if(cell_spm[k]["allowed45Flag"]==="Y"){
  					 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML =$($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].innerHTML+ "45";
  					 $($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className =$($("#underdeck_table")[0].rows[tiers_underdeck-(Number(cell_spm[k]["pk"]["tierOffset"]))].cells[((Number(cell_spm[k]["pk"]["rowOffset"]))+2)])[0].className + " 45footer";
  				 }
  		}
  	}
  	}
  	//if(!($(this).hasClass("edited"))){
  	if(current_deck === "D"){
  		deck_Or_underdeck = "#deck_table tr td";
     	deck_Or_underdeck_table = "#deck_table";
     	currentBayTemplate = $(this)[0].dataset.template;
     	$("#deck_table tr td").each(function(e) {
	         var selectedElements = this;
	         var row_offset = $($("#deck_table")[0].tHead.rows[0].cells[this.cellIndex]).text();
	         tier_offset = this.parentNode.cells[0].innerHTML;
	         var row_no = $($("#deck_table")[0].tHead.rows[1].cells[this.cellIndex]).text();
	         tier_no = this.parentNode.cells[1].innerHTML;
	       //selected cell
	          if ($(selectedElements).hasClass('selected')) {
	             var del_bay_row_obj = {
	                 "pk": {}
	             };
	             del_bay_row_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_row_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_row_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_row_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_row_obj["pk"]["rowOffset"] = row_offset;
	             del_bay_row_obj["vesselRowNo"] = row_no;
	             del_bay_row_obj["isDeleted"] = "Y";
	             var del_bay_tier_obj = {
	                 "pk": {}
	             };
	             del_bay_tier_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_tier_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_tier_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_tier_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_tier_obj["pk"]["tierOffset"] = tier_offset;
	             del_bay_tier_obj["vesselTierNo"] = tier_no;
	             del_bay_tier_obj["tweenDeckFlag"] = "N";
	             del_bay_tier_obj["secondaryTierNo"] = twodigits(tier_no - 1);
	             del_bay_tier_obj["isDeleted"] = "Y";
	             var del_cell_obj = {
	                 "pk": {}
	             };
	             del_cell_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_cell_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_cell_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_cell_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_cell_obj["pk"]["rowOffset"] = row_offset;
	             del_cell_obj["pk"]["tierOffset"] = tier_offset;
	             del_cell_obj["isAvialable"] = "N";
	             del_cell_obj["doorDirectionIndicator"] = "N";
	             del_cell_obj["hotSpotFlag"] = "N";
	             del_cell_obj["isDeleted"] = "Y";
	             del_cell_obj["reeferTypeFlag"] = "N";
	             del_cell_obj["onlyEmptyContainerAllowedFlag"] = "N";
	             del_cell_obj["allowed45Flag"] = "N";
	             if($(selectedElements).hasClass("reefer")){
	            	 del_cell_obj["reeferTypeFlag"] = "Y";
	             }
	              if($(selectedElements).hasClass("45footer")){
	            	  del_cell_obj["allowed45Flag"] = "Y";
	             }
	              if($(selectedElements).hasClass("empty")){
	            	  del_cell_obj["onlyEmptyContainerAllowedFlag"] = "Y";
	             }
	              current_del_bayrow_obj_script.push(del_bay_row_obj);
	              current_del_baytier_obj_script.push(del_bay_tier_obj);
	              current_del_cell_obj_script.push(del_cell_obj);
	         }
	  	});
  		}
  	else if(current_deck === "U"){
  		deck_Or_underdeck = "#underdeck_table tr td";
     	deck_Or_underdeck_table = "#underdeck_table";
     	currentBayTemplate = $(this)[0].dataset.template;
     	$("#underdeck_table tr td").each(function(e) {
	         var selectedElements = this;
	         var row_offset = $($("#underdeck_table")[0].tHead.rows[0].cells[this.cellIndex]).text();
	         tier_offset = this.parentNode.cells[0].innerHTML;
	         var row_no = $($("#underdeck_table")[0].tHead.rows[1].cells[this.cellIndex]).text();
	         tier_no = this.parentNode.cells[1].innerHTML;
	       //selected cell
	          if ($(selectedElements).hasClass('selected')) {
	             var del_bay_row_obj = {
	                 "pk": {}
	             };
	             del_bay_row_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_row_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_row_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_row_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_row_obj["pk"]["rowOffset"] = row_offset;
	             del_bay_row_obj["vesselRowNo"] = row_no;
	             del_bay_row_obj["isDeleted"] = "Y";
	             var del_bay_tier_obj = {
	                 "pk": {}
	             };
	             del_bay_tier_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_tier_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_tier_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_tier_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_tier_obj["pk"]["tierOffset"] = tier_offset;
	             del_bay_tier_obj["vesselTierNo"] = tier_no;
	             del_bay_tier_obj["tweenDeckFlag"] = "N";
	             del_bay_tier_obj["secondaryTierNo"] = twodigits(tier_no - 1);
	             del_bay_tier_obj["isDeleted"] = "Y";
	             var del_cell_obj = {
	                 "pk": {}
	             };
	             del_cell_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_cell_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_cell_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_cell_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_cell_obj["pk"]["rowOffset"] = row_offset;
	             del_cell_obj["pk"]["tierOffset"] = tier_offset;
	             del_cell_obj["isAvialable"] = "N";
	             del_cell_obj["doorDirectionIndicator"] = "N";
	             del_cell_obj["hotSpotFlag"] = "N";
	             del_cell_obj["isDeleted"] = "Y";
	             del_cell_obj["reeferTypeFlag"] = "N";
	             del_cell_obj["onlyEmptyContainerAllowedFlag"] = "N";
	             del_cell_obj["allowed45Flag"] = "N";
	             if($(selectedElements).hasClass("reefer")){
	            	 del_cell_obj["reeferTypeFlag"] = "Y";
	             }
	              if($(selectedElements).hasClass("45footer")){
	            	  del_cell_obj["allowed45Flag"] = "Y";
	             }
	              if($(selectedElements).hasClass("empty")){
	            	  del_cell_obj["onlyEmptyContainerAllowedFlag"] = "Y";
	             }
	              current_del_bayrow_obj_script.push(del_bay_row_obj);
	              current_del_baytier_obj_script.push(del_bay_tier_obj);
	              current_del_cell_obj_script.push(del_cell_obj);
	         }
	  	});
  	}
  	//}
 }
	 else{
		 Ext.MessageBox.show({
				msg:"Vessel already saved successfully.Can't make changes now. Please re-edit the vessel by reopening it.",
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});
	 }
/*	 currentdeckbay_html =$("#deck_table").html();
	 currentunderdeckbay_html =$("#underdeck_table").html();
	 currentbay_template = $(this)[0].dataset.template;*/
   });
 $(".dropdown dt a").on('click', function () {
     $(this).toggleClass("down");
     $(".dropdown dd ul").slideToggle('fast');
 });

 $(".dropdown dd ul li a").on('click', function () {
     $(".dropdown dd ul").hide();
 });

 function getSelectedValue(id) {
      return $("#" + id).find("dt a span.value").html();
 }

 $(document).bind('click', function (e) {
 });


 $('.mutliSelect input[type="checkbox"]').on('click', function () {
   if($(".hida").text() === "Select"){
	   $(".hida").show();
   }
     var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val();
         title = $(this).val() + " ,";
     if ($(this).is(':checked')) {
         var html = '<span title="' + title + '">' + title + '</span>';
         $('.multiSel').append(html);
         $(".hida").hide();
     } 
     else {
         $('span[title="' + title + '"]').remove();
         var ret = $(".hida");
         $('.dropdown dt a').append(ret);
         
     }
 });
 var verticals,
  verticals_selected= "",
  select_allow="",
  mouseDown = false,
  cb_unselected = $("#unselected_cb");
 $(".mytable").on("mousedown", "td", function(){ 
	 if(select_allow){
	 mouseDown = true;
	 verticals = [];
	 text_verticals=[];
	 verticals_selected="";
	 $(this).removeClass("45footer");
	 $(this).removeClass("reefer");
	 $(this).removeClass("empty");
	 $('input[name="verticals"]:checked').each(function() {
		 verticals.push(this.value);
		 });
	 if(cb_unselected.is(':checked')){
		 if($(this).hasClass("selected")){
			 $(this).addClass("deleted");
		 }
		 $(this).removeClass("selected");
		 $(this).removeClass("45footer");
		 $(this).removeClass("reefer");
		 $(this).removeClass("empty");
		 $(this)[0].innerText="";
	 }
	 else{
		 for(var i=0;i<verticals.length;i++){
    		 if(verticals[i][0] === "4"){
    			 verticals[i][0]= "45";
    			 text_verticals = text_verticals + " "+ verticals[i][0]+verticals[i][1]+ " "; 
    		 }
    		 else{ 
    			 text_verticals = text_verticals + " " + verticals[i][0]+ " "; 
    		 }
    		 verticals_selected = verticals_selected +" "+ verticals[i] + " ";
    		 
    	 }
    	 $(this).addClass(verticals_selected);
    	 $(this)[0].innerText= text_verticals;
    	 $(this).addClass("selected");
    	 if($(this).hasClass("deleted")){
			 $(this).removeClass("deleted");
		 }
    	
	 }
	 return false;
	 }
 }); 
 
 $(".mytable").on("mouseover", "td", function() {
	 if(select_allow){
	 if(mouseDown===true){
		 verticals = [];
    	 text_verticals=[];
    	 verticals_selected="";
    	 $(this).removeClass("45footer");
    	 $(this).removeClass("reefer");
    	 $(this).removeClass("empty");
    	 $('input[name="verticals"]:checked').each(function() {
    		 verticals.push(this.value);
    		 });
    	 if(cb_unselected.is(':checked')){
    		 if($(this).hasClass("selected")){
    			 $(this).addClass("deleted");
    		 }
    		 $(this).removeClass("selected");
    		 $(this).removeClass("45footer");
    		 $(this).removeClass("reefer");
    		 $(this).removeClass("empty");
    		
    		 $(this)[0].innerText="";
    	 }
    	 else{
    		 for(var i=0;i<verticals.length;i++){
        		 if(verticals[i][0] === "4"){
        			 verticals[i][0]= "45";
        			 text_verticals = text_verticals + " "+ verticals[i][0]+verticals[i][1]+ " "; 
        		 }
        		 else{ 
        			 text_verticals = text_verticals + " " + verticals[i][0]+ " "; 
        		 }
        		 verticals_selected = verticals_selected +" "+ verticals[i] + " ";
        		 
        	 }
        	 $(this).addClass(verticals_selected);
        	 $(this)[0].innerText=text_verticals;
        	 $(this).addClass("selected");
        	 if($(this).hasClass("deleted")){
    			 $(this).removeClass("deleted");
    		 }
    	 }
	 }
	 }
 });
 $(document).mouseup(function () {
	 mouseDown = false;
 });
     var  buildUniqueData = function(data) {
  if(data.length=== 0){
  return [];
  }else{
	var items = data, elems = [], groups = [];
	for( var i = 0; i < items.length; i++ ) {
		Array.prototype.push.call( elems, items[i] );
	}
	groups.push( groupBy( elems, function( item ) {
		return item;
	} ) );
	groupBy( groups, function( array ) {
		for( var i = 0; i < array.length; i++ ) {
			var obj = array[i].slice();
			Object.keys( obj ).map( function( p ) {
				var length = obj.length;
				if( obj[p].hasOwnProperty( "quantity" ) ) {
					obj[p].quantity = length;
				}
				groups[i] = obj[p];
			} );
		}
	} );
	function groupBy( array, f ) {
		var groups = {};
		array.forEach( function( o ) {
			var group = JSON.stringify( f( o ) );
			groups[group] = groups[group] || [];
			groups[group].push( o );
		} );
		return Object.keys( groups ).map( function( group ) {
			return groups[group];
		} );
	}
	return groups;
	}
};
  var current_bayrow_obj_script =[],
  current_baytier_obj_script=[],
  current_cell_obj_script=[],
  current_bayrow_obj_script_templ =[],
  current_baytier_obj_script_templ=[],
  current_cell_obj_script_templ=[];
  var current_bay_row= [];
  var current_bay_tier= [];
  var current_bay_cell= [];
$("#pushvalues").click(function(){
	if(vesselSaved){
		Ext.MessageBox.show({
			msg:"Vessel already saved successfully.Can't make changes now. Please re-edit the vessel by reopening it.",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});
	}
	else{
		var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
		current_bayrow_obj_script=[];
		 current_baytier_obj_script=[];
		 current_cell_obj_script=[];
		var current_deck = $("#deck").val();
		
	  	 $(deck_Or_underdeck).each(function(e) {
	         var selectedElements = this;
	         var row_offset = $($(deck_Or_underdeck_table)[0].tHead.rows[0].cells[this.cellIndex]).text();
	         tier_offset = this.parentNode.cells[0].innerHTML;
	         var row_no = $($(deck_Or_underdeck_table)[0].tHead.rows[1].cells[this.cellIndex]).text();
	         tier_no = this.parentNode.cells[1].innerHTML;
	       //selected cell
	         if ($(selectedElements).hasClass('selected')) {
	             var bay_row_obj = {
	                 "pk": {}
	             };
	             bay_row_obj["pk"]["vesselNo"] =data.vesselInfo.vesselNo;
	             bay_row_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             bay_row_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             bay_row_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             bay_row_obj["pk"]["rowOffset"] = row_offset;
	             bay_row_obj["vesselRowNo"] = row_no;
	             bay_row_obj["isDeleted"] = "N";
	             var bay_tier_obj = {
	                 "pk": {}
	             };
	             bay_tier_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             bay_tier_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             bay_tier_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             bay_tier_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             bay_tier_obj["pk"]["tierOffset"] = tier_offset;
	             bay_tier_obj["vesselTierNo"] = tier_no;
	             bay_tier_obj["tweenDeckFlag"] = "N";
	             bay_tier_obj["secondaryTierNo"] = twodigits(tier_no - 1);
	             bay_tier_obj["isDeleted"] = "N";
	             var cell_obj = {
	                 "pk": {}
	             };
	             cell_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             cell_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             cell_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             cell_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             cell_obj["pk"]["rowOffset"] = row_offset;
	             cell_obj["pk"]["tierOffset"] = tier_offset;
	             cell_obj["isAvialable"] = "N";
	             cell_obj["doorDirectionIndicator"] = "N";
	             cell_obj["hotSpotFlag"] = "N";
	             cell_obj["isDeleted"] = "N";
	             cell_obj["reeferTypeFlag"] = "N";
	             cell_obj["onlyEmptyContainerAllowedFlag"] = "N";
	             cell_obj["allowed45Flag"] = "N";
	             if($(selectedElements).hasClass("reefer")){
	            	 cell_obj["reeferTypeFlag"] = "Y";
	             }
	              if($(selectedElements).hasClass("45footer")){
	            	 cell_obj["allowed45Flag"] = "Y";
	             }
	              if($(selectedElements).hasClass("empty")){
	            	 cell_obj["onlyEmptyContainerAllowedFlag"] = "Y";
	             }
	             current_bayrow_obj_script.push(bay_row_obj);
	             current_baytier_obj_script.push(bay_tier_obj);
	             current_cell_obj_script.push(cell_obj);
	         }
	     	
	         else if ($(selectedElements).hasClass('deleted')) {
	             var del_bay_row_obj = {
	                 "pk": {}
	             };
	             del_bay_row_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_row_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_row_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_row_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_row_obj["pk"]["rowOffset"] = row_offset;
	             del_bay_row_obj["vesselRowNo"] = row_no;
	             del_bay_row_obj["isDeleted"] = "Y";
	             var del_bay_tier_obj = {
	                 "pk": {}
	             };
	             del_bay_tier_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_bay_tier_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_bay_tier_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_bay_tier_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_bay_tier_obj["pk"]["tierOffset"] = tier_offset;
	             del_bay_tier_obj["vesselTierNo"] = tier_no;
	             del_bay_tier_obj["tweenDeckFlag"] = "N";
	             del_bay_tier_obj["secondaryTierNo"] = twodigits(tier_no - 1);
	             del_bay_tier_obj["isDeleted"] = "Y";
	             var del_cell_obj = {
	                 "pk": {}
	             };
	             del_cell_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
	             del_cell_obj["pk"]["sectionNo"] = $("#sect_no").val();
	             del_cell_obj["pk"]["deckUnderDeck"] = $("#deck").val();
	             del_cell_obj["pk"]["bayOffset"] = $("#bay_offset").val();
	             del_cell_obj["pk"]["rowOffset"] = row_offset;
	             del_cell_obj["pk"]["tierOffset"] = tier_offset;
	             del_cell_obj["isAvialable"] = "N";
	             del_cell_obj["doorDirectionIndicator"] = "N";
	             del_cell_obj["hotSpotFlag"] = "N";
	             del_cell_obj["isDeleted"] = "Y";
	             del_cell_obj["reeferTypeFlag"] = "N";
	             del_cell_obj["onlyEmptyContainerAllowedFlag"] = "N";
	             del_cell_obj["allowed45Flag"] = "N";
	             if($(selectedElements).hasClass("reefer")){
	            	 del_cell_obj["reeferTypeFlag"] = "Y";
	             }
	              if($(selectedElements).hasClass("45footer")){
	            	  del_cell_obj["allowed45Flag"] = "Y";
	             }
	              if($(selectedElements).hasClass("empty")){
	            	  del_cell_obj["onlyEmptyContainerAllowedFlag"] = "Y";
	             }
	             del_bayrow_obj_script.push(del_bay_row_obj);
	             del_baytier_obj_script.push(del_bay_tier_obj);
	             del_cell_obj_script.push(del_cell_obj);
	         }
	  	});
	  	if(current_deck === "D"){
	  		deck_Or_underdeck = "#deck_table tr td";
	     	deck_Or_underdeck_table = "#deck_table";
	     	current_del_bayrow_obj_script =buildUniqueData(current_del_bayrow_obj_script);
	     	current_del_baytier_obj_script =buildUniqueData(current_del_baytier_obj_script);
		  	 if($("#deck_tier_template").val() !== currentBayTemplate){
		  		 for(var i=0;i<current_bayrow_obj_script.length;i++){
		  			for(var j=0;j<current_del_bayrow_obj_script.length;j++){
if((current_bayrow_obj_script[i].pk.rowOffset === current_del_bayrow_obj_script[j].pk.rowOffset) && (current_bayrow_obj_script[i].pk.tierOffset === current_del_bayrow_obj_script[j].pk.tierOffset) ){
	current_del_bayrow_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		for(var i=0;i<current_baytier_obj_script.length;i++){
		  			for(var j=0;j<current_del_baytier_obj_script.length;j++){
if((current_baytier_obj_script[i].pk.rowOffset === current_del_baytier_obj_script[j].pk.rowOffset) && (current_baytier_obj_script[i].pk.tierOffset === current_del_baytier_obj_script[j].pk.tierOffset) ){
	current_del_baytier_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		for(var i=0;i<current_cell_obj_script.length;i++){
		  			for(var j=0;j<current_del_cell_obj_script.length;j++){
if((current_cell_obj_script[i].pk.rowOffset === current_del_cell_obj_script[j].pk.rowOffset) && (current_cell_obj_script[i].pk.tierOffset === current_del_cell_obj_script[j].pk.tierOffset) ){
	current_del_cell_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		current_bayrow_obj_script = current_bayrow_obj_script.concat(current_del_bayrow_obj_script);
		  		current_baytier_obj_script = current_baytier_obj_script.concat(current_del_baytier_obj_script);
		  		current_cell_obj_script = current_cell_obj_script.concat(current_del_cell_obj_script);
		  	 }
	     	if( $("#deck_tier_template").val() === "Default"){
     			$("#"+bay_sec_id)[0].dataset.template = defaultDeckTemplate;
     			$("#"+bay_sec_id)[0].dataset.modified = "Y";
         		//$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount(defaultDeckTemplate);
     		}
     		else{
     			$("#"+bay_sec_id)[0].dataset.template = $("#deck_tier_template").val();
     			$("#"+bay_sec_id)[0].dataset.modified = "Y";
         	//	$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount($("#deck_tier_template").val());
     		}
	  		}
	  	else if(current_deck === "U"){
	  		deck_Or_underdeck = "#underdeck_table tr td";
	     	deck_Or_underdeck_table = "#underdeck_table";
	     	current_del_bayrow_obj_script =buildUniqueData(current_del_bayrow_obj_script);
	     	current_del_baytier_obj_script =buildUniqueData(current_del_baytier_obj_script);
		  	 if($("#underdeck_tier_template").val() !== currentBayTemplate){
		  		 for(var i=0;i<current_bayrow_obj_script.length;i++){
		  			for(var j=0;j<current_del_bayrow_obj_script.length;j++){
if((current_bayrow_obj_script[i].pk.rowOffset === current_del_bayrow_obj_script[j].pk.rowOffset) && (current_bayrow_obj_script[i].pk.tierOffset === current_del_bayrow_obj_script[j].pk.tierOffset) ){
	current_del_bayrow_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		for(var i=0;i<current_baytier_obj_script.length;i++){
		  			for(var j=0;j<current_del_baytier_obj_script.length;j++){
if((current_baytier_obj_script[i].pk.rowOffset === current_del_baytier_obj_script[j].pk.rowOffset) && (current_baytier_obj_script[i].pk.tierOffset === current_del_baytier_obj_script[j].pk.tierOffset) ){
	current_del_baytier_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		for(var i=0;i<current_cell_obj_script.length;i++){
		  			for(var j=0;j<current_del_cell_obj_script.length;j++){
if((current_cell_obj_script[i].pk.rowOffset === current_del_cell_obj_script[j].pk.rowOffset) && (current_cell_obj_script[i].pk.tierOffset === current_del_cell_obj_script[j].pk.tierOffset) ){
	current_del_cell_obj_script.splice(j, 1);
}
		  			}
		  		 }
		  		current_bayrow_obj_script = current_bayrow_obj_script.concat(current_del_bayrow_obj_script);
		  		current_baytier_obj_script = current_baytier_obj_script.concat(current_del_baytier_obj_script);
		  		current_cell_obj_script = current_cell_obj_script.concat(current_del_cell_obj_script);
		  	 }
	     	if( $("#underdeck_tier_template").val() === "Default"){
	 			$("#"+bay_sec_id)[0].dataset.template = defaultUnderDeckTemplate;
	 			$("#"+bay_sec_id)[0].dataset.modified = "Y";					//!!!! Not sure on what basis  modified is marked as y !
	     		//$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount(defaultUnderDeckTemplate);
	 		}
	 		else{
	 			$("#"+bay_sec_id)[0].dataset.template = $("#underdeck_tier_template").val();
	 			$("#"+bay_sec_id)[0].dataset.modified = "Y";
	     		//$("#"+current_working_Bay)[0].dataset.maxtiers = getTierCount($("#underdeck_tier_template").val());
	 		}
	  	}
	  	 	current_bay_row[bay_sec_id]	= "";
	 		current_bay_tier[bay_sec_id] ="";
	 		current_bay_cell[bay_sec_id] ="";
	 		/*for(var i=0;i<current_cell_obj_script.length-1;i++){
	 			for(var j=i;j<current_cell_obj_script.length-1;j++){
if ( current_cell_obj_script[i].pk.rowOffset ===  current_cell_obj_script[j].pk.rowOffset && current_cell_obj_script[i].pk.tierOffset ===  current_cell_obj_script[j].pk.tierOffset  ) {
	current_cell_obj_script = current_cell_obj_script
    .filter(function (el) {
             return (el.pk.rowOffset !== current_cell_obj_script[i].pk.rowOffset && el.pk.tierOffset !== current_cell_obj_script[i].pk.tierOffset && el.isDeleted !== "Y");
            }); 			    
	console.log(current_cell_obj_script[i]);
	 			  }
	 			}
	 		}*/
	  	if(current_cell_obj_script.length>0){
	 		current_bay_row[bay_sec_id]	=buildUniqueData(current_bayrow_obj_script);
	 		current_bay_tier[bay_sec_id] =buildUniqueData(current_baytier_obj_script);
	 		current_bay_cell[bay_sec_id] = buildUniqueData(current_cell_obj_script);
	     	 $("#"+bay_sec_id).addClass("edited");
	 	  	$("#"+bay_sec_id).css('background-color','green');
	 	  	Ext.MessageBox.show({
	 			msg: $("#bayNoId").text() +" bay saved successfully.",
	 			buttons: Ext.MessageBox.OK,
	 			icon: Ext.MessageBox.INFO
	 		});
	 	  	select_allow= false;
		}
		else{
			var vslMsg="Do you want to save an empty bay ?";
 			Ext.Msg.confirm('',vslMsg, function (answer) {
 				if (answer == "yes") {
 					current_bay_row[bay_sec_id]	=buildUniqueData(current_bayrow_obj_script);
 			 		current_bay_tier[bay_sec_id] =buildUniqueData(current_baytier_obj_script);
 			 		current_bay_cell[bay_sec_id] = buildUniqueData(current_cell_obj_script);
 			     	 $("#"+bay_sec_id).addClass("edited");
 			 	  	$("#"+bay_sec_id).css('background-color','green');
 			 	  	Ext.MessageBox.show({
 			 			msg: $("#bayNoId").text() +" bay saved successfully.",
 			 			buttons: Ext.MessageBox.OK,
 			 			icon: Ext.MessageBox.INFO
 			 		});
 			 	  	select_allow= false;
 				}
 				else{
 					$("#"+bay_sec_id).removeClass("edited");
 					$("#"+bay_sec_id).css('background-color','yellow');
 					 select_allow= true;
 				}
 			});	
			
		}
	  	
	}
	
});
var check_remove_zero_deck = function(){
	if($("#row_zero").is(":checked")) {
		 $("#deck_table thead tr th.zeroth_row").hide();
		// $("#deck_table thead tr:nth-child(2) th:nth-child(zeroRow)").hide();
		 $("#deck_table tbody tr").each(function(e) {
            $(this)[0].childNodes[zeroRow+2].hidden = true;
			 $(this)[0].childNodes[zeroRow+2].innerText = "";
			 $(this)[0].childNodes[zeroRow+2].className = "start deleted";
        });
	 }
	 else{
		 $("#deck_table thead tr th.zeroth_row").show();
		// $("#deck_table thead tr:nth-child(2) th:nth-child(zeroRow)").show();
		 $("#deck_table tbody tr").each(function(e) {
			 $(this)[0].childNodes[zeroRow+2].hidden = false;
        });
	 }
};
var check_remove_zero_underdeck = function(){
	if($("#row_zero").is(":checked")) {
		$("#underdeck_table thead tr th.zeroth_row").hide();
		// $("#underdeck_table thead tr:nth-child(2) th:nth-child(zeroRow)").hide();
		 $("#underdeck_table tbody tr").each(function(e) {
			 $(this)[0].childNodes[zeroRow+2].hidden = true;
			 $(this)[0].childNodes[zeroRow+2].innerText = "";
			 $(this)[0].childNodes[zeroRow+2].className = "start deleted";
         });
	 }
	 else{
		 $("#underdeck_table thead tr th.zeroth_row").show();
		// $("#underdeck_table thead tr:nth-child(2) th:nth-child(zeroRow)").show();
		 $("#underdeck_table tbody tr").each(function(e) {
			 $(this)[0].childNodes[zeroRow+2].hidden = false;
         });
	 }
};
$('#row_zero').change(function() {
  	if($("#deck_table_div").css("display") === "block"){
  		check_remove_zero_deck();
  	}
  	else if($("#underdeck_table_div").css("display") === "block"){
  		check_remove_zero_underdeck();
  	}
 });
$("#remove_reefer").click(function() {
	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
 	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
 		 Ext.MessageBox.show({
 				msg: "Bay once saved is not allowed to modify",
 				buttons: Ext.MessageBox.OK,
 				icon: Ext.MessageBox.INFO
 			});	
 	 }
 	 else{
	 $(".mytable tr td").each(function(e) {
       $(this).removeClass("reefer");
       $(this).removeAttr('style');
       $(this)[0].innerText= ($(this)[0].innerText).replace("r","");
   });
 	 }
});
	 $("#remove_empty").click(function() {
		 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
	    	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
	    		 Ext.MessageBox.show({
	    				msg: "Bay once saved is not allowed to modify",
	    				buttons: Ext.MessageBox.OK,
	    				icon: Ext.MessageBox.INFO
	    			});	
	    	 }
	    	 else{
        $(".mytable tr td").each(function(e) {
       	 $(this).removeClass("empty");
       	 $(this)[0].innerText= ($(this)[0].innerText).replace("e","");
        });
	    	 }
    });
    $("#remove_45footer").click(function() {
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
     	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
     		 Ext.MessageBox.show({
     				msg: "Bay once saved is not allowed to modify",
     				buttons: Ext.MessageBox.OK,
     				icon: Ext.MessageBox.INFO
     			});	
     	 }
     	 else{
        $(".mytable tr td").each(function(e) {
           	 $(this).removeClass("45footer");
           	 $(this)[0].innerText= ($(this)[0].innerText).replace("45","");
        });
     	 }
    });
    $("#reset_bay").on('click', function() {
    	 var bay_sec_id = $("#sect_no").val()+$("#bay_offset").val()+$("#deck").val();
     	 if($("#"+bay_sec_id)[0].style.backgroundColor==="green"){
     		 Ext.MessageBox.show({
     				msg: "Bay once saved is not allowed to reset",
     				buttons: Ext.MessageBox.OK,
     				icon: Ext.MessageBox.INFO
     			});	
     	 }
     	 else{
        $(".mytable tr td").each(function(e) {
        	if($(this).hasClass("selected")){
        		$(this).removeClass("selected");
        		$(this).addClass("deleted");
        	}
            $(this).removeClass("reefer");
            $(this).removeClass("empty");
            $(this).removeClass("45footer");
            $(this).removeAttr('style');
            $(this)[0].innerText= "";
        });
     	 }
    });
    $("#close_vessel").click(function(){
   	 if(vesselSaved){
   		 close();
   	 }
   	 else{
   		 var vslMsg="Vessel data will be lost. Do you want to close the application?";
			Ext.Msg.confirm('',vslMsg, function (answer) {
				if (answer == "yes") {
				close();
				}
				else{
					
				}
			});	
   	 }
    });
    var vessel_json;
    var unique = function(list) {
        var result = [];
        $.each(list, function(i, e) {
            if ($.inArray(e, result) == -1) result.push(e);
        });
        return result;
    };
    $("#getvalues").on('click', function() { // save vessel
		var bay_row=[];
   	 var bay_tier=[];
   	 var bay_cell=[];
   	$("#myVessel tr table tbody tr td").each(function(e) {
   	 var bayno_val = $(this)[0].innerHTML,
   	 	template_val= $(this)[0].dataset.template,
   	 	bay_offset_val =$(this)[0].dataset.bay_offset ,
   	 	deck_name_val = $(this)[0].dataset.deck_name,
   	 	section_no_val = $(this)[0].dataset.sectno;
   	if($(this)[0].dataset.modified === "Y"){
   	var bay_obj = {
            "pk": {}
        };
        bay_obj["bayOffset"] = bay_offset_val;
        bay_obj["deckUnderDeck"] = deck_name_val;
        bay_obj["isContainerRowPresent"] = "N";
  		bay_obj["isDeleted"]="N";
  		bay_obj["isLogicalBay"]="N";
		bay_obj["pk"]["bayOffset"] = bay_offset_val;
  		bay_obj["pk"]["deckUnderDeck"]= deck_name_val;
  		bay_obj["pk"]["sectionNo"]= section_no_val;
  		bay_obj["pk"]["vesselNo"] = data.vesselInfo.vesselNo;
  		bay_obj["tierTemplate"] =template_val;
  		bay_obj["vesselBayNo"] =bayno_val;
  		bay_script.push(bay_obj);
   	}
    });
		 $("#myVessel tr table tbody tr td").each(function(e) {
	    		 if(current_bay_cell[$(this)[0].id] === undefined){
	    		 }else{
	    			 for(var b=0;b<current_bay_row[$(this)[0].id].length;b++){
	    				 bay_row.push(current_bay_row[$(this)[0].id][b]);			// !!! no need to iterate - concat can be used instead
	    			 }
	    			 for(var b=0;b<current_bay_tier[$(this)[0].id].length;b++){
	    				 bay_tier.push(current_bay_tier[$(this)[0].id][b]);
	    			 }
	    			 for(var b=0;b<current_bay_cell[$(this)[0].id].length;b++){
	    				 bay_cell.push(current_bay_cell[$(this)[0].id][b]);
	    			 }
	    		 }
	    		 });
		  var bayrow_result = [];
		  var baytier_result = [];
		for (var i = 0; i < buildUniqueData(del_bayrow_obj_script).length; i++) {
		    var inRow = checkInBayRow(buildUniqueData(del_bayrow_obj_script)[i]);
		    if (! inRow) {
		    	bayrow_result.push(buildUniqueData(del_bayrow_obj_script)[i]);
		    	};
		}
		function checkInBayRow(obj) {
		    for (var i = 0 ; i < bay_row.length; i++) {
		        if ((obj.pk.sectionNo === bay_row[i].pk.sectionNo) && (obj.pk.deckUnderDeck === bay_row[i].pk.deckUnderDeck) && (obj.pk.bayOffset === bay_row[i].pk.bayOffset) && (obj.pk.rowOffset === bay_row[i].pk.rowOffset)) {
		            return true;
		        }
		    }
		    return false;
		}
		for (var i = 0; i < buildUniqueData(del_baytier_obj_script).length; i++) {
		    var inTier = checkInBayTier(buildUniqueData(del_baytier_obj_script)[i]);
		    if (! inTier) {
		    	baytier_result.push(buildUniqueData(del_baytier_obj_script)[i]);
		    	};
		}
		function checkInBayTier(obj) {
		    for (var i = 0 ; i < bay_tier.length; i++) {
		        if ((obj.pk.sectionNo === bay_tier[i].pk.sectionNo) && (obj.pk.deckUnderDeck === bay_tier[i].pk.deckUnderDeck) && (obj.pk.bayOffset === bay_tier[i].pk.bayOffset) && (obj.pk.tierOffset === bay_tier[i].pk.tierOffset)) {
		            return true;
		        }
		    }
		    return false;
		}
		for(var b=0;b<bayrow_result.length;b++){
			bay_row.push(bayrow_result[b]);
		 }
		for(var b=0;b<baytier_result.length;b++){
			bay_tier.push(baytier_result[b]);
			
		 }
		for(var b=0;b<del_cell_obj_script.length;b++){
			 bay_cell.push(del_cell_obj_script[b]);
		 }
		 var vsl_obj=data.vesselInfo;
		 vessel_no = $("#vessel_no").val(),
        vessel_name = $("#vessel_name").val();
        vsl_obj["vesselCode"] = vessel_no;
        vsl_obj["vesselName"] = vessel_name;
        vsl_obj["vesselType"] = $("#vesselType").val();
        vsl_obj["motherFeeder"] = $("#motherFeeder").val();
        vsl_obj["length"] = $("#length").val();
        vsl_obj["lengthUom"] = "M";
        vsl_obj["width"] = $("#width").val();
        vsl_obj["widthUom"] = "M";
        vsl_obj["teuCapacity"] = $("#teuCapacity").val();
        vsl_obj["height"] = $("#height").val();
        vsl_obj["isDeleted"] = "N";
        vsl_obj["maxRows"] = maxRows;
        vessel_json = {
        		"vesselInfo": vsl_obj,
                "sectionList": [],
                "bayList": unique(bay_script),
                "bayRowList": bay_row,
                "bayTierList": bay_tier,
                "cellList":buildUniqueData(bay_cell)
            };
       var vesselData = JSON.stringify(vessel_json);
       saveEditedVesselProfile(vesselData);
         vesselSaved = true;
         select_allow = false;
    });
 });
