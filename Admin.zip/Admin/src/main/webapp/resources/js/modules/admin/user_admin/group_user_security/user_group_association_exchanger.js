
Modules.admin.user_admin.group_user_security.user_group_association_grid	=		function(){
	var panel	=	{
		xtype:'cmcpanelwithgridexchanger',
		width:700,
		height:200,
		btnWidthCmc:100, 
		btnCntrWidthCmc:120,
		btnTopMarginCmc:'50px 0px 5px 0px',
		region:'center',
		modelKeyFields :['groupName'],
		setRightGridFuncCmc:function(){ 
			var store = {
				model: 'GroupModel',
				url: 'oceanUserManagement/getGroupDtlsForUser',
				paging : true,
				queryTypeCmc : 'remote',
				listeners : {
					beforeload:function(){
						var form = Ext.getCmp(Modules.CompIds.oceanUserManagementWindowId).down('#OceanUserManagementForm');
						var userid = form.down('#userId').getValue();
						this.proxy.extraParams.userId = userid;
						this.proxy.extraParams.limit = 100;
						this.pageSize = 100;
					}
				},
				autoLoad : true
			}; 
			var grid = {
				xtype: 'cmcgrid',
				id:'groupGrid',
				storeObjCmc: store,
				title:'List of Groups ',
				showPagingBarCmc : true,
				addPagingComboCmc:false,
				paging : true,
				setGridColumnsFuncCmc: function () {
					 var columns = [{
						header : 'Group Name',
						flex :1,
						dataIndex : 'groupName'
					}]; 
					return columns;
				}
			}; 
			return grid;
		}
	}; 
	return panel; 
};//End Of Grid Exchanger Grid 