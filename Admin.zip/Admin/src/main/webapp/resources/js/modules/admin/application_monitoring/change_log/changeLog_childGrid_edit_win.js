Modules.admin.application_monitoring.change_log.childGridEditWin = function() {
	var win = Ext.create('Ext.cmc.GridPopUpWindow', {
		id:'NonOceanChangeLogChildGridWindowID',//Give some id to window
		gridCompCmc:Ext.getCmp(Modules.CompIds.changeLogChildGridId),//Pass the component of grid at which this window will be opened
		title:'Change Log Details Record View',
		editableCmc:false,//Set this to false if all the fields should be readOnly
		saveUrlCmc:'',//Put the URL for save here if the window will save data to server. If no URL specified then data will be saved to grid locally
		saveOrDoneBtnValidateHandlerFuncCmc:'',//This should be a function specified in instance. It will be called in save or done button handler and will be used for instance specific validations like duplication check. It should return true or false for sure.
		saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server if requried
		setFormItemsFuncCmc:function(){

            var itemsArr = [];
            
            var fieldName = {
					xtype : 'cmctextfield',
					name : 'fieldName',
					fieldLabel :Modules.admin.application_monitoring.change_log.labels.fieldName,					
					labelAlign : "left",
					labelSeparator : '',
					readOnly :true
					
				};
            var oldValue = {
					xtype : 'cmctextfield',					
					name : 'oldValue',
					fieldLabel : Modules.admin.application_monitoring.change_log.labels.oldValue,					
					labelAlign : "left",
					labelSeparator : '',
					readOnly :true
					
				};
            var newValue = {
					xtype : 'cmctextfield',					
					name : 'newValue',
					fieldLabel :Modules.admin.application_monitoring.change_log.labels.newValue,				
					labelAlign : "left",
					labelSeparator : '',
					readOnly :true
					
				};

 

            var container1 = {
					xtype : 'container',
                    layout: 'hbox',
					margin: '5px 5px 5px 5px',
					defaults:{
						margin:'0px 5px 0px 10px'
					},
					items : [fieldName,oldValue,newValue]
				};
			

		
		itemsArr = [ container1];
            return itemsArr;
        
		}
	});	

	return win;//Returning the window object ultimately from the funciton
  

   

  

};