Modules.admin.application_monitoring.change_log.parentPanel = function(menu) {
	var panel={
			xtype:'cmctabparentpanel',
			title:'Change Log',
			id:'changeLogPanelId',
			showNorthItemCmc:true,
			showSouthItemCmc:true,
			setNorthItemFuncCmc:Modules.admin.application_monitoring.change_log.form,
			setCenterItemFuncCmc:Modules.admin.application_monitoring.change_log.parentGridPanel,
			setSouthItemFuncCmc:Modules.admin.application_monitoring.change_log.childGridPanel
			/*
			clearBtnObjCmc:{
				handler:function(){	       	 	
					//Ext.getCmp(Modules.CompIds.transportationEventFormId).getForm().reset();
					//Ext.getCmp(Modules.CompIds.transportLoadRefId).setReadOnly(false);					
					//Ext.getCmp(Modules.CompIds.transportEvntGridId).getStore().removeAll();	 		            
				}				
			},			
			retrieveBtnObjCmc:{
				handler:function(){
					
				}
			},
			saveBtnObjCmc:{
				handler:function(){
					
				}
			}*/
			
	};	
	return panel;
};

