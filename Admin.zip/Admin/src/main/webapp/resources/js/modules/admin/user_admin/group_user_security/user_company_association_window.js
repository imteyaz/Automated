
Modules.admin.user_admin.group_user_security.panel = function (argObj) {
	var panel = Ext.create('Ext.Panel', {
		height:500,
		width: 780,
		title: 'Company',
		id: Modules.CompIds.userToComapnyAssociationWindowId,
		openModeCmc:'ADD',
		buttonAlign: "center",
		modal :true,
		showNorthItemCmc: true,
		buttonAlign: "center",
		layout:'border',
		items:[Modules.admin.user_admin.group_user_security.user_company_association_grid()]
	});
	return panel;
}; //End OF Window