
Modules.admin.user_admin.group_user_security.function_exchanger_grid	=		function(){
	var panel	=	{
		xtype:'cmcpanelwithgridexchanger',
		id:Modules.CompIds.groupFunctionExchangerPanelId,
		width:700,
		height:300,
		btnWidthCmc:120, 
		btnCntrWidthCmc:120,
		btnTopMarginCmc:'50px 0px 5px 0px',
		leftGridTitleCmc : 'Assigned Functions',
		setRightGridFuncCmc:function(){ 
			var store = {
				model: 'GenericLookUpDTO',
				url: 'admin/getAvailableFunctionDetailsByModuleId'
			}; 
			var grid = {
				xtype: 'cmcgrid',
				id : Modules.CompIds.groupFunctionExchangeRightGridId,
				storeObjCmc: store,
				title: Modules.admin.user_admin.user_management.labels.listOfFunctions,//'List of Functions ',
				setGridColumnsFuncCmc: function () {
					 var columns = [{
						header : Modules.admin.user_admin.user_management.labels.name,//'Name',
						flex :1,
						dataIndex : 'name'
					}]; 
					return columns;
				}
			}; 
			return grid;
		}
	}; 
	return panel; 
}//End Of Grid Exchanger Grid 