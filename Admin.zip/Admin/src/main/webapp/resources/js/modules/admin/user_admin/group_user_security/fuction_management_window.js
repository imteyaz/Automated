
Modules.admin.user_admin.group_user_security.functonManagementWindow = function (argObj) {
	
	Modules.admin.user_admin.group_user_security.functionForm=function(){
	var form={
		xtype: 'cmcform',
		itemId: 'functionQueryForm',
		width: 900,
		height: 70,
		bodyStyle: 'background-color: #FFFFFF',
		showFieldsetCmc: false,
		collapsible : true,
		collapsed : true,
	    setFormItemsFuncCmc: function () {
			var itemsArr = [];
			
			var groupNameField = {
					xtype : 'cmctextfield',
					name : 'groupName',
					itemId : 'groupName',
					width: 400,
					labelWidth: 100,
					labelAlign:"right",
					fieldLabel : Modules.admin.user_admin.user_management.labels.groupName//'Group Name'
				};
			
			var serviceNameField = {
					xtype : 'cmctextfield',
					name : 'serviceTypeDesc',
					itemId : 'serviceTypeDesc',
					width: 400,
					labelWidth: 100,
					labelAlign:"right",
					fieldLabel : Modules.admin.user_admin.user_management.labels.serviceType//'Service Type'
				};
			
			
			var container1 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '5px 5px 5px 5px',
					defaults:{
						margin:'0px 5px 0px 5px'
					},
					items : [groupNameField]
			};	
			itemsArr = [container1];
			return itemsArr;
			
		}
	};
	return form;
	}	
	
	
	var win = Ext.create('Ext.cmc.Window', {
		height:600,
		width: 900,
		title: Modules.admin.user_admin.user_management.labels.groupToFunctionAssociation,//'Group To Function Association',
		id: Modules.CompIds.functionWindowId,
		modal :true,
		showNorthItemCmc: true,
		showSouthItemCmc:true,
		showExtraTbarCmc:true,	
		setExtraTbarFuncCmc : function(){
			var buttons=[
							{   xtype : "button",
								text : Modules.admin.user_admin.user_management.labels.deniedMenus,//"Denied Menus",
								iconCls : "sub-main-folder",
                                handler : function() {
                                	var openWindow=false;
            			    		var obj=Ext.getCmp(Modules.CompIds.groupWindowId).wingroupAssociatedObj;
                                    var serviceTypeCode=argObj.record.serviceTypeCode;
            			        	var leftGridStore=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});

                                	var treeGrid=Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId);
             			    		var selectedRecord=treeGrid.getSelectionModel().getLastSelected();
             			    		 
             			    		
             			    		  
             	                        
             	                        //Preparing associated functions
             			    		 if (selectedRecord != undefined) {
             			    			     record=selectedRecord.data;
             			    		         var modifiedFunctions = leftGridStore.collect('code');
             			    		         if (modifiedFunctions.length != 0) {
             			                        if(argObj.action == 'COPY' || argObj.action == 'EDIT'){
             			                        	openWindow = true;
             			                        	
             			                        }else{
             			                        	if(obj[serviceTypeCode] != undefined){
             			                        
             			                        	 Ext.Array.each(obj[serviceTypeCode].moduleList, function (object, index, me) {
                         			    		         for (var prop in object) {
                         			    		             if (prop && (prop == record.code)) {
                         			    		                 openWindow = true;
                         			    		                 break;
                         			    		             }
                         			    		         }
                         			    		     });
             			                    		
             			                        	}
                			    		       }

             			    		         }
             			    		    
             			    		  if (openWindow) {
             			    		         var window = Modules.admin.user_admin.group_user_security.deniedMenuWindow(argObj);
             			    		         window.show();
             			    		     } else {
             			    		         Ext.MessageBox.show({
             			    		             msg: Modules.admin.user_admin.group_user_security.messages.noFunctionAssociatedWithGroup,
             			    		             buttons: Ext.MessageBox.OK,
             			    		             icon: Ext.MessageBox.INFO
             			    		         });
             			    		     }
             			    		 }else{

         			    		         Ext.MessageBox.show({
         			    		             msg: Modules.admin.user_admin.group_user_security.messages.noFunctionAssociatedWithGroup,
         			    		             buttons: Ext.MessageBox.OK,
         			    		             icon: Ext.MessageBox.INFO
         			    		         });
         			    		     
             			    			 
             			    		 }
             				    		
             				    		
             				    		  
							       
									
									
								}
							}
								
						];
		return buttons;
		},

		buttonAlign: "center",
		buttons: [
		          {
		        	   xtype : 'button',
			           text : Modules.admin.user_admin.user_management.labels.apply,//'Apply',
			           handler : function(){
			        	   
			          var functionEl= this.getEl();
			          functionEl.mask("Applying changes locally...");
			        	   
					    var form=win.child('#functionQueryForm');
                        var serviceTypeCode=argObj.record.serviceTypeCode;
			        	var leftGridStore=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
			            var rightGridStore  = Ext.getCmp(Modules.CompIds.groupFunctionExchangeRightGridId).getStore();		
                        var obj=Ext.getCmp(Modules.CompIds.groupWindowId).wingroupAssociatedObj;
			    		var removedObj=Ext.getCmp(Modules.CompIds.groupWindowId).removedFunObj;
			    		
			    		// Validation check
			    		// If any module doesn't have children, Just return
			    		
			    		if(leftGridStore.getCount() == 0 && rightGridStore.getCount() == 0){
			    			return; // don't execute below statements, because selected module does not have any functions to assoicate with group
			    		}
			    		
			    		
			    		

			    		if(!obj[serviceTypeCode]){
			    			obj[serviceTypeCode]={};
			    			removedObj[serviceTypeCode]={};
			    		}
			    		if(!obj[serviceTypeCode].moduleList){
				    		obj[serviceTypeCode].moduleList =[];
				    		removedObj[serviceTypeCode].moduleList =[];

			    		}
			    		
				        var treeGrid=Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId);
			    		var record=treeGrid.getSelectionModel().getLastSelected().data;
                        var isNew=true;
                        
                        //Preparing associated functions
			    		Ext.Array.each(obj[serviceTypeCode].moduleList,function(object,index,me){
			    			 for (var prop in object) {
			    				 if(prop && (prop == record.code)){
			    					 isNew=false;
			    					// object[record.code]=leftGridStore.collect('code'); //convert to array of objects
			    					 var temp=[];
			    					 leftGridStore.each(function(record,index,count){
			    						 temp.push(record.data);
			    					 });
			    					 object[record.code]=temp;
			    					 break;
			    				 }
			    			   }
			    			});
			    		
			    	
			    		 
			    		
						if(isNew){
							var module={};
                          //  module[record.code]=leftGridStore.collect('code'); //convert to array of objects
                             var temp=[];
	    					 leftGridStore.each(function(record,index,count){
	    						 temp.push(record.data);
	    					 });
	    					module[record.code]=temp;
                            obj[serviceTypeCode].moduleList.push(module);
						}
                        if(argObj.action == 'COPY' || argObj.action == 'EDIT'){
							// collecting initial function
							
						//	var modifiedFunctions=leftGridStore.collect('code');  //convert to array of objects
                        	var modifiedFunctions=[];
                        	var modifiedCodes=[];
	    					 leftGridStore.each(function(record,index,count){
	    						 modifiedFunctions.push(record.data);
	    						 modifiedCodes.push(record.data.code);
	    					 });
	    					var initalFunctionArray=Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId).initialFunctions;
							//var tempArray=Ext.Array.clone(initalFunctionArray);
							if(initalFunctionArray){
								var diffArray=Ext.Array.difference(initalFunctionArray,modifiedCodes);
								//var diffArray=tempArray; //TO DO  need to optimized
								/*	Ext.Array.each(initalFunctionArray,function(val, index, me){
										 for(var i=0; i<modifiedFunctions.length; i++) {
										        if(modifiedFunctions[i].code == val) {
										        	tempArray.splice(index, 1);
										        	break;
										        }
										    }
								}); */
							}
							
							isNew=true;  // checking for removal functions
							Ext.Array.each(removedObj[serviceTypeCode].moduleList,function(object,index,me){
				    			 for (var prop in object) {
				    				 if(prop && (prop == record.code)){
				    					 isNew=false;
				    					 object[record.code]=diffArray;
				    					 break;
				    				 }
				    			   }
				    			});
							
							if(isNew){
								var tempObj={};
								tempObj[record.code]=diffArray;
	                            removedObj[serviceTypeCode].moduleList.push(tempObj);
							}
							
                         }
                        functionEl.unmask();
                        Ext.MessageBox.show({
							title : Modules.Msgs.changesSavedLocallyHeader,//'No Records found',
							msg : Modules.Msgs.changesSavedLocallyMssg,//'No records matching the search criteria were found ',//
							buttons : Ext.MessageBox.OK,
							icon : Ext.MessageBox.INFO
						});
                        
						}
			        	  
			          },{
				           xtype : 'button',
				           text : Modules.admin.user_admin.user_management.labels.close,//'Close',
				           handler : function(){
				        	   win.close();
				           }
				        	  
				          }],
		setNorthItemFuncCmc:Modules.admin.user_admin.group_user_security.functionForm,
		setCenterItemFuncCmc: Modules.admin.user_admin.group_user_security.moduleTreeGrid,
		setSouthItemFuncCmc:Modules.admin.user_admin.group_user_security.function_exchanger_grid,
		listeners: {
			afterrender:function(){
				    var me		=		this;
			        var form=me.child('#functionQueryForm');
			        form.getForm().setValues(argObj.record);

			        form.down('#groupName').setReadOnly(true);
		        	//form.down('#serviceTypeDesc').setReadOnly(true);

			        /* Ext.getCmp(Modules.CompIds.groupFunctionTreeGridId).getStore().load({
							params:{
								serviceType : argObj.record.serviceTypeCode
							}
						});*/
			       
				},		
	
			beforeclose:function(){
			}
		}
	});
	return win;
} //End OF Window