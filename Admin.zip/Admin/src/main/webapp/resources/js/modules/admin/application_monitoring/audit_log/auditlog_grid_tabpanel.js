Ext.QuickTips.init();
Modules.admin.auditlog.tabpanel = function() {

		var storeObj = {
			model : 'AuditLogQuery',
			url : 'auditLog/getAuditLogQuery',
			paging : true,
			queryTypeCmc : 'remote',
			listeners : {
				beforeload : function() {
					
					var searchObj = Ext.getCmp(Modules.CompIds.auditLogTabPanelId).down('#queryForm').getForm().getValues(false);
					Modules.GlobalFuncs.deleteEmptyProperties(searchObj);
					this.proxy.extraParams = {
							companyCode : Modules.GlobalVars.selectedCompanyCode
					};
					
					Ext.apply(this.proxy.extraParams,searchObj);
					this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
					var limitVal = Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getComponent(
							'centerGridPagingToolBarItemId').getComponent(
							'perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				}
			}
		};
		var getSearchObject = function(){
			var searchObj = Ext.getCmp(Modules.CompIds.auditLogTabPanelId).down('#queryForm').getForm().getValues(false);
			Modules.GlobalFuncs.deleteEmptyProperties(searchObj);
			searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
			searchObj.maxLimitRecords= Modules.GlobalVars.maxLimitRecords;
			return searchObj;
		};
		var grid = {
			xtype : 'cmcgrid',
			id : Modules.CompIds.auditLogQueryGridId,
			storeObjCmc : storeObj,
			showPagingBarCmc : true,
			showExtraTbarCmc : true,
			popUpWinFuncCmc: Modules.admin.auditlog.popupGridWindow,//Window function which will return the object of pop-up window
			popUpWinIdCmc: 'NonOceanAuditLogGridWindowID',//Id of the pop-up window
			popUpCellIndexCmc:0,
			setExtraTbarFuncCmc : function() {
				var buttonArray = [{
					xtype : "button",
					iconCls : "excel",
					tooltip: Modules.Msgs.excelReportToolTip,
					handler:function(){
						var grid = Ext.getCmp(Modules.CompIds.auditLogQueryGridId);
						var searchObj = getSearchObject();
						if (Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getStore().getCount() > 0){
							Ext.cmc.Exporter.exportToXls(grid, searchObj,'auditLog/getAuditLogQueryExport');
						}
						else{
							Ext.MessageBox.show({
                                msg: 'No Records to Export',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					}
				},{
					xtype : "button",
					iconCls : "report",
					tooltip: Modules.Msgs.pdfReportToolTip,
					handler:function(){
						var grid = Ext.getCmp(Modules.CompIds.auditLogQueryGridId);
						var searchObj = getSearchObject();
						if(Ext.getCmp(Modules.CompIds.auditLogQueryGridId).getStore().getCount() > 0){
						  Ext.cmc.Exporter.exportToPdf(grid, searchObj,'auditLog/getAuditLogQueryExport');
						}
						else{
							Ext.MessageBox.show({
                                msg: 'No Records to Export',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
							});
						}
					  }
				}];
				return buttonArray;
			},
			setGridColumnsFuncCmc : function() {
				var colsArr = [
				    {
						xtype : 'actioncolumn',
						width : 20,
						sortable: false,
						items :[{
							icon: 'resources/images/editView.jpg',
			                tooltip:Modules.LblsAndTtls.tooltip.openPopupWin,
			                handler: function(){
			                	return true;
			                }
						}]
					},
					/*{
						header:Modules.admin.auditlog.labels.applnServeName,
						dataIndex:'hostName',
						width: 200,
						readOnly : true,
						tooltip :'Application Server Name',
						renderer : 'uppercase'
					},
					*/{
						header:'User Name',
						dataIndex:'userName',
						width: 200,
						readOnly : true,
						 tdCls:'custom-column' 
						
					},{
						header:Modules.admin.auditlog.labels.moduleName,
						dataIndex:'moduleName',
						width: 200,
						readOnly : true,
						 tdCls:'custom-column' 
					},
					{
						header:Modules.admin.auditlog.labels.functionName,
						dataIndex:'functionName',
						width: 300,
						readOnly : true,
						 tdCls:'custom-column' 
						
					},
					{
						header:Modules.admin.auditlog.labels.validFrom,
						dataIndex:'startDate',
						width: 200,
						readOnly : true,
						 tdCls:'custom-column' ,
						renderer: Ext.util.Format.dateRenderer(Modules.GlobalVars.dateTimeFormatGlobal)
						
					},
					{
						header:Modules.admin.auditlog.labels.validTo,
						dataIndex:'exitDate',
						width: 200,
						 tdCls:'custom-column' ,
						readOnly : true,
						renderer: Ext.util.Format.dateRenderer(Modules.GlobalVars.dateTimeFormatGlobal)
						
					}
				];
				return colsArr;
			},
			viewConfig : {
				stripeRows : true,
				emptyText: Modules.Msgs.noDataInGrid
			}
		};
		return grid;
};
