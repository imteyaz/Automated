
Modules.admin.user_admin.group_user_security.groupWindow = function (argObj) {
	if(argObj.record != undefined){
		argObj.record.serviceTypeCode='TTS'; // Hardcoding service type because earlier fucntionality has been implemented based on service type, Now service types has been removed from application, To keep logic as it was, service type is hardcoded.because service type does not have value anymore	
	}else{
		 argObj.record={serviceTypeCode : 'TTS',serviceTypeDesc : 'Transportation And Technical Services' }
        // win.winFuncArgObjCmc.record=argObj.record;
	}
	
	
	var ModuleObj={};
    var groupDtlsObj={};
    var removedFunObj={};
    var funcAccessCodesObj={};
	Modules.admin.user_admin.group_user_security.groupForm=function(){
		
		
		 var serviceStore = Ext.create('Ext.data.Store', {
		     model: 'GenericLookUpDTO',
		     proxy: {
		         type: 'ajax',
		         url: 'admin/getServiceTypeDtls',
		         reader: {
		             type: 'json',
		             root: 'items'
		         }
		     }
		 });
		
	var form={
		xtype: 'cmcform',
		itemId: 'groupQueryForm',
		width: 900,
		height: 110,
		bodyStyle: 'background-color: #FFFFFF',
		showFieldsetCmc: false,
		requiredField : '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>',
	    setFormItemsFuncCmc: function () {
			var groupCodeField = {
					xtype : 'cmctextfield',
					name : 'groupCode',
				    labelAlign:"left",
                    itemId : 'groupCode',
					fieldLabel : Modules.admin.user_admin.user_management.labels.groupCode,//'Group Code',
					width : 350,
					labelWidth : 110,
					afterLabelTextTpl: form.requiredField
				};
			var groupNameField = {
					xtype : 'cmctextfield',
					name : 'groupName',
					itemId : 'groupName',
                    fieldLabel : Modules.admin.user_admin.user_management.labels.groupName,//'Group Name',
                    width : 350,
                    labelWidth : 110,
					afterLabelTextTpl: form.requiredField
				};
			var groupDescField = {
					xtype : 'cmctextfield',
					name : 'groupDesc',
					itemId : 'groupDesc',
				    labelAlign:"left",
				    width : 350,
				    labelWidth : 110,
					fieldLabel : Modules.admin.user_admin.user_management.labels.groupDesc//'Group Description'
				};
			
			var groupIdhiddenField = {
					xtype : 'hiddenfield',
					name : 'groupId',
					itemId : 'groupId'
				};
			
			
			var serviceTypeCombo={
				xtype : 'combobox',
				name : 'serviceTypeCode',
				itemId : 'serviceTypeCode',
				fieldLabel : Modules.admin.user_admin.user_management.labels.serviceType,//'Service Type',
				store : serviceStore,
				displayField : 'name',
				valueField : 'code',
				width : 400,
				labelWidth : 150,
				afterLabelTextTpl: form.requiredField,
				editable : false,
				allowBlank : false,
				labelSeparator : '',
				listeners : {
					select : function(combo, records) {
		               var rightGridStore  = Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore();
			           var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupUserExchangerPanelId).getGridsStoreFuncCmc({type:'left'});


		               if(rightGridStore.getCount()!=0 && leftGridStore.getCount()!=0){
		            	   Ext.Msg.show({
								title : 'Status',
								msg : Modules.admin.user_admin.group_user_security.messages.changeServiceType,
								buttons : Ext.Msg.YESNO,
								icon : Ext.Msg.QUESTION,
								callback : function(buttonId,text) {
									if (buttonId == 'yes') {
										
										var form=win.child('#groupQueryForm');
							            form.down('#groupName').setValue("");
									    form.down('#groupCode').setValue("");
									    form.down('#groupDesc').setValue("");
									    leftGridStore.removeAll();
										
										 var record={serviceTypeCode : records[0].data.code,serviceTypeDesc : records[0].data.name }
				                         win.winFuncArgObjCmc.record=record;
				                          
				                          rightGridStore.load({
				    							params:{
				    								action : argObj.action,
				    								serviceType : records[0].data.code
				    							}
				    						});
										
									}else{
										
									}
								}
							});		               
		            	   }else{
		            		   
		            		   var record={serviceTypeCode : records[0].data.code,serviceTypeDesc : records[0].data.name }
		                       win.winFuncArgObjCmc.record=record;
		            		   
		            		   rightGridStore.load({
	    							params:{
	    								action : argObj.action,
	    								serviceType : records[0].data.code
	    							}
	    						});
		            		   
		            	   }

						
						
						
				    /*       var gridExchanger =win.down('cmcpanelwithgridexchanger');
		                   var rightGridStore  = Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore();		
				           var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupUserExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
				           leftGridStore.removeAll();
				
				

				if(win.wingroupAssociatedObj[this.getValue()] && win.wingroupAssociatedObj[this.getValue()].groupUserList.length > 0 ){
					
					rightGridStore.on('load',function(){
						gridExchanger.autoSelectValuesFnCmc('code',win.wingroupAssociatedObj[this.getValue()].groupUserList);
					},this,{single:true});
				}
				 if(win.winFuncArgObjCmc && win.winFuncArgObjCmc.action == 'ADD' ){
                    	   
                          var form=win.child('#groupQueryForm');
                          var record={serviceTypeCode : records[0].data.code,serviceTypeDesc : records[0].data.name }
                          win.winFuncArgObjCmc.record=record;
                          
                          rightGridStore.load({
    							params:{
    								action : argObj.action,
    								serviceType : records[0].data.code
    							}
    						});
                        	
                        }else if(argObj && argObj.action == 'EDIT'){}else if(argObj && argObj.action == 'COPY'){}
			        	
			        
						
					*/}
				}
			};
			
			
			var container1 = {
					xtype: 'container',
					layout: 'hbox',
					labelAlign:"left",
					margin: '10px 10px 10px 0px',
					defaults:{
						margin:'0px 30px 0px 0px'
					},
					items : [groupCodeField,groupNameField]
			};
			
			var container2 = {
					xtype: 'container',
					layout: 'hbox',
					labelAlign:"left",
					margin: '10px 10px 10px 0px',
					defaults:{
						margin:'0px 30px 0px 0px'
					},
					items : [groupDescField]
			};
			
			var layout = [container1,container2];
		return layout;	
			
			
			
		}
	};
	return form;
	}	;
	
	
	
	
	var win = Ext.create('Ext.cmc.Window', {
		height:600,
		width: 900,
		title: Modules.admin.user_admin.user_management.labels.groupToUserAssociation,//'Group To User Association',
		id: Modules.CompIds.groupWindowId,
		modal :true,
		winFuncArgObjCmc: argObj, //argObj || {}, // cached objects for group  details
		wingroupAssociatedObj :  ModuleObj, //wingroupAssociatedObj || {}, // cached object for full group,user,functon,denied options
		groupDtlsObj : groupDtlsObj, // groupDtlsObj || {}, // cached object service type to group details
		removedFunObj : removedFunObj, //removedFunObj || {},  // cached object for removed function details
		funcAccessCodesObj : funcAccessCodesObj,// funcAccessCodesObj || {},  // cached object for functions,denied menu details
		buttonAlign: "center",
		getFunctonAccessObjArray : function(searchedKey){
			var matchedArray=[];
			
			 if(win.funcAccessCodesObj){
					for(var serviceType in win.funcAccessCodesObj){
						var servObj=win.funcAccessCodesObj[serviceType];
						for(var array in servObj){
							Ext.Array.each(servObj[array],function(val){
								if(typeof val === 'object'){
									for(var key in val){
										if(key == searchedKey){
											matchedArray=val[key];
											break;
										}
									}
								}});		
							 
						}
					}
					
				}
			return matchedArray;
			
		},
		buttons: [
		  {
			xtype : "button",
			text : Modules.admin.user_admin.user_management.labels.save,//"Save",
			handler : function() {
				
		        var form=win.child('#groupQueryForm');
                var groupName= form.down('#groupName').getValue();
                var groupDesc= form.down('#groupDesc').getValue();
		        var groupCode= form.down('#groupCode').getValue();
		        var serviceTypeCode='TTS';
		        
		    /*
		     * 
		       var serviceTypeCode=null;
	            if(argObj && argObj.action == 'ADD'){
			        serviceTypeCode= form.down('#serviceTypeCode').getValue();
                 }else{
	            	serviceTypeCode=argObj.record.serviceTypeCode;

	             }

		        
		        if(Ext.isEmpty(serviceTypeCode)){
		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.requiredServiceType,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else   */ 
		        	
		        	
		        	if(Ext.isEmpty(groupCode)){

		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.requiredGroupCode,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else if(Ext.isEmpty(groupName)){
		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.requiredGroupName,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else if(groupCode.length>10){

		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.maxGroupCode,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else if(groupName.length>30){

		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.maxGroupName,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else if(groupDesc.length>50){

		        	Ext.MessageBox.show({
                        msg : Modules.admin.user_admin.group_user_security.messages.maxGroupDesc,
		        		buttons : Ext.MessageBox.OK,
		        		icon : Ext.MessageBox.INFO
		        	});
		        	
		        }else {
		        	
		        	 if(argObj.action == 'ADD' || argObj.action == 'COPY'){
		        		 Ext.Ajax.request({
		        			    url : 'admin/findGroupByName',
								method:'POST',
								params : {'code' : groupCode, 'name' : groupName},
								success : function(response) {
									var msg=Ext.decode(response.responseText);
									var error = msg.errorMsg;
									if(msg.success==false){
										Ext.MessageBox.show({
											msg: error,
											buttons: Ext.MessageBox.OK,
											icon: Ext.MessageBox.INFO
										});		
									}else{
										win.saveGroupData(form,groupName,groupDesc,groupCode,serviceTypeCode);
									}
								}
							});
		        		 
		        	 }else{
		        		 win.saveGroupData(form,groupName,groupDesc,groupCode,serviceTypeCode);
				     }
		        	
		        	
		        	
		        	
		        }
		        
		        
		        
		      }
		}],
        saveGroupData : function(form,groupName,groupDesc,groupCode,serviceTypeCode){
        	//Checking for duplicate group existed or not
        	
			        	
						var el= this.getEl();
			            el.mask("Saving Group Details...");
						
				    	var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupUserExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
	                     if(!win.wingroupAssociatedObj[serviceTypeCode]){
					    	win.wingroupAssociatedObj[serviceTypeCode]={};
			    		}

				        win.wingroupAssociatedObj[serviceTypeCode].groupUserList =[];
				        
				        win.wingroupAssociatedObj[serviceTypeCode].groupUserList = leftGridStore.collect('code');
				        
				        // COPY GROUP , NEED TO USE EXISTING GROUP ID
				       var copyGroupId=null;
				        if(argObj.action == 'EDIT'){
				        	copyGroupId=argObj.record.groupId;
				        }else if(argObj.action == 'COPY'){
				        	copyGroupId=argObj.record.groupId;
				        	argObj.record.groupId=null;  
	                    }
				        	
				        
				        //Applying accessCodes for functons Object
				         if(win.wingroupAssociatedObj){
							for(var serviceType in win.wingroupAssociatedObj){
								var servObj=win.wingroupAssociatedObj[serviceType];
								for(var array in servObj){
									Ext.Array.each(servObj[array],function(val){
										if(typeof val === 'object'){
											for(var key in val){
												var accessArray=win.getFunctonAccessObjArray(key);
												Ext.Array.each(val[key],function(item){
													for(var i=0;i<accessArray.length;i++){
														if(accessArray[i].code == item.code){
															item.accessCode == accessArray[i].accessCode;
															break;
														}
													}
													});
											}
										}
										      
												
											});		
									 
								}
							}
							
						}
				        
				        
				         var paramObj={}; // Preparing complete Master Object
			        	paramObj.groupUserList =[];
						paramObj.moduleList =[];
						paramObj.groupList =[];
						paramObj.removedList =[];
						
						paramObj.action=argObj.action;
						paramObj.copyGroupId=copyGroupId;// represents action type i.e ADD or EDIT or COPY
						paramObj.serviceType=serviceTypeCode;
						
				        if(win.wingroupAssociatedObj){
							for(var serviceType in win.wingroupAssociatedObj){
								var servObj=win.wingroupAssociatedObj[serviceType];
								for(var array in servObj){
									Ext.Array.each(servObj[array],function(val){
										if(typeof val === 'string'){
											 paramObj[array].push({ // for user association
													associateId : val,
													groupId : argObj.record.groupId
												});
										}else if(typeof val === 'object'){
											for(var key in val){
												Ext.Array.each(val[key],function(item){
														paramObj[array].push({  // for function association
															associateId : item.code,
															groupId : argObj.record.groupId,
															accessCode : Ext.isEmpty(item.accessCode)?null : item.accessCode
														});
													
													
												});
												
											}
										}
										      
												
											});		
									 
								}
							}
							
						}
				        
				        
				        var formValues =form.getForm().getValues(false,true);
			            if(!win.groupDtlsObj[serviceTypeCode]){
			            	win.groupDtlsObj[serviceTypeCode]={};
			             }
			            
			            if(argObj.record.groupId && argObj.action == 'EDIT'){
			            	formValues.groupId=argObj.record.groupId;
			            	formValues.serviceTypeCode=argObj.record.serviceTypeCode;
			              }
			            if(argObj.action == 'COPY'){
			            	formValues.serviceTypeCode=argObj.record.serviceTypeCode;
			            	}
			            
			            win.groupDtlsObj[serviceTypeCode]=formValues;
				        
				        
				        if(win.groupDtlsObj){
							for(var serviceType in win.groupDtlsObj){
								var groupObj=win.groupDtlsObj[serviceType];
								paramObj.groupList.push(groupObj);
							}

						}
				        
				        
				        // Preparing removed  functions array
				        if(win.removedFunObj){
							for(var serviceType in win.removedFunObj){
								var servObj=win.removedFunObj[serviceType];
								for(var array in servObj){
									Ext.Array.each(servObj[array],function(val){
										for(var key in val){
											Ext.Array.each(val[key],function(item){
												//removedList
												paramObj.removedList.push({  
													associateId : item,
													groupId : argObj.record.groupId
												});
											});
										}
									});
								}
							}
							
				        }
				        
				        
				      
				       if(paramObj.moduleList != undefined){
				    	   for(var i=0;i<paramObj.moduleList.length;i++){
				    		  var object=paramObj.moduleList[i];
				    		  
				    	   }
				    	   
				       }
				       
				        
				       
				        var saveData = {groupJsonArray : Ext.encode([paramObj])};
						Ext.Ajax.request({
							url : 'admin/saveGroupAssociatedUserAndFunctionDetails',
							method:'POST',
							params : saveData,
							success : function(response) {
								var msg=Ext.decode(response.responseText);
								var error = msg.message;
								el.unmask();
								if(msg.success==true){
									Ext.MessageBox.show({
										msg: Modules.Msgs.saveSuccess,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.INFO
									});		
									win.close();
								}else{
									Ext.MessageBox.show({
										msg: error,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.INFO
									});											
								}
								
							},
							failure : function(response) {	
								el.unmask();
							}
						});
				        
				
        	
        	
        	
        		
        	
        	
        	
        },
    	showExtraTbarCmc:true,	
		setExtraTbarFuncCmc : function(){
			var buttons=[
							{   xtype : "button",
								text : Modules.admin.user_admin.user_management.labels.functionButton,//"Function",
								iconCls : "sub-main-folder",
                                handler : function() {
							        var form=win.child('#groupQueryForm');
							        var groupName= form.down('#groupName').getValue();
							        /**
							         *  var serviceTypeCode= form.down('#serviceTypeCode').getValue();
							        if(Ext.isEmpty(serviceTypeCode)){
							        	Ext.MessageBox.show({
                                            msg : Modules.admin.user_admin.group_user_security.messages.requiredServiceType,
							        		buttons : Ext.MessageBox.OK,
							        		icon : Ext.MessageBox.INFO
							        	});
							        	
							        }else
							         * 
							         */
							        	
							        if(Ext.isEmpty(groupName)){
							        	Ext.MessageBox.show({
                                            msg : Modules.admin.user_admin.group_user_security.messages.requiredGroupName,
							        		buttons : Ext.MessageBox.OK,
							        		icon : Ext.MessageBox.INFO
							        	});
							        	
							        }else{
							        	win.winFuncArgObjCmc.record.groupName=groupName;
							        	var window=Modules.admin.user_admin.group_user_security.functonManagementWindow(win.winFuncArgObjCmc);
					                	window.show();	
							        }
							        
							      }
							}
								
						];
		return buttons;
		},
	    showNorthItemCmc: true,
		setNorthItemFuncCmc:Modules.admin.user_admin.group_user_security.groupForm,
		setCenterItemFuncCmc: Modules.admin.user_admin.group_user_security.user_exchanger_grid,
		listeners: {
			afterrender:function(){
				        var me		=		this;
				        var form=me.child('#groupQueryForm');
				       if(argObj && argObj.action == 'EDIT'){
				        	var formData=form.getForm().getValues(false,false);
				        	form.getForm().setValues(argObj.record);
				        	//form.down('#serviceTypeCode').setValue(argObj.record.serviceTypeDesc);
                            form.down('#groupCode').setReadOnly(true);
				        	form.down('#groupName').setReadOnly(true);
				        //	form.down('#serviceTypeCode').setReadOnly(true);

				        	
				        	Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore().load({
								params:{
									action : argObj.action,
									groupId : argObj.record.groupId,
									serviceType : argObj.record.serviceTypeCode
								}
							});
				        	Ext.Ajax.request({
								url:'admin/getGroupAssociatedUserDetails',
								params:{
									action : argObj.action,
									groupId : argObj.record.groupId,
									serviceType : argObj.record.serviceTypeCode
								},
								method:'GET',
								success:function(response){
									var respObj			=	Ext.JSON.decode(response.responseText);
									var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupUserExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
									leftGridStore.add(respObj);	
								},
								failure:function(){
								}
							}); 
				        	
				        }else if(argObj && argObj.action == 'COPY'){
				        	var formData=form.getForm().getValues(false,false);
				        //	form.down('#serviceTypeCode').setValue(argObj.record.serviceTypeDesc);
				        //	form.down('#serviceTypeCode').setReadOnly(true);
				        	
				        	
				        	
				        	Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore().load({
								params:{
									action : argObj.action,
									groupId : argObj.record.groupId,
									serviceType : argObj.record.serviceTypeCode
								}
							});
				        	Ext.Ajax.request({
								url:'admin/getGroupAssociatedUserDetails',
								params:{
									action : argObj.action,
									groupId : argObj.record.groupId,
									serviceType : argObj.record.serviceTypeCode
								},
								method:'GET',
								success:function(response){
									var respObj			=	Ext.JSON.decode(response.responseText);
									var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupUserExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
									leftGridStore.add(respObj);	
								},
								failure:function(){
								}
							}); 

				        }else if(argObj && argObj.action == 'ADD'){
				        	
				        win.winFuncArgObjCmc.record={serviceTypeCode : 'TTS',serviceTypeDesc : 'Transportation And Technical Services' }	;
                        Ext.getCmp(Modules.CompIds.groupUserExchangeRightGridId).getStore().load({
    							params:{
    								action : 'ADD',
    								serviceType : 'TTS'
    							}
    						});
				        	
				        }
					
				},		
	
			beforeclose:function(){
				Ext.getCmp(Modules.CompIds.adminGroupGridId).getStore().reload();
             }
		}
	});
	return win;
} //End OF Window