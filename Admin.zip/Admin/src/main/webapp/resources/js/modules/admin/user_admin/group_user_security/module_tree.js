
Modules.admin.user_admin.group_user_security.moduleTreeGrid		=		function(){
	
	var argObj=Ext.getCmp(Modules.CompIds.groupWindowId).winFuncArgObjCmc;
	
	var funcMgmtModuleTreeGrid = {
        xtype: 'cmctree',
		height:200,
		selectedModuleId : '',
		initialFunctions : [], // using to hold initially associtated function list wiht respect to module
		id : Modules.CompIds.groupFunctionTreeGridId,
        storeObjCmc:{
			model:'GenericLookUpDTO',
			url:' admin/getModuleDetails',
			params : {
				serviceType : argObj.record.serviceTypeCode
			},
			autoLoad : false
		},
        setTreeColumnsFuncCmc: function () {
            var colsArr = [{
                xtype: 'treecolumn',
				header: Modules.admin.user_admin.user_management.labels.moduleName,//'Module Name',
                dataIndex: 'name',
                width : 600
            }];
            return colsArr;
        },
		listeners: {
			selectionchange: function (me, selected, eOpts ) {
			var record=selected[0].data;
			var gridExchanger =Ext.getCmp(Modules.CompIds.functionWindowId).down('cmcpanelwithgridexchanger');
            var rightGridStore  = Ext.getCmp(Modules.CompIds.groupFunctionExchangeRightGridId).getStore();		
            var leftGridStore=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
			var getFromDB=true;

            
    		var obj=Ext.getCmp(Modules.CompIds.groupWindowId).wingroupAssociatedObj;	
    		leftGridStore.removeAll();
		    
		    if(obj[argObj.record.serviceTypeCode] && obj[argObj.record.serviceTypeCode].moduleList  && obj[argObj.record.serviceTypeCode].moduleList.length > 0 ){
				Ext.Array.each(obj[argObj.record.serviceTypeCode].moduleList,function(object,index,me){
				    			 for (var prop in object) {
				    				 if(prop && (prop == record.code)){
				    					 getFromDB=false;
				    					 rightGridStore.on('load',function(){
				    						 var modifiedCodes=[];
				    						 var funObjArray=object[prop];
				    						 for(var i=0;i<funObjArray.length;i++){
						    					 modifiedCodes.push(funObjArray[i].code);
                                             }
				    						 gridExchanger.autoSelectValuesFnCmc('code',modifiedCodes);
				    						},this,{single:true});
				    					 break;
				    				 }
				    			   }
				    			});
				}
			
			var groupRecord=Ext.getCmp(Modules.CompIds.groupWindowId).winFuncArgObjCmc.record;
			
			 if(argObj && (argObj.action == 'EDIT' || argObj.action == 'COPY' ) && getFromDB){ // only first time clicking on Module tree 
					Ext.getCmp(Modules.CompIds.groupFunctionExchangeRightGridId).getStore().load({
						params:{
							moduleId : selected[0].data.code,
							groupId : groupRecord.groupId,
							serviceType : groupRecord.serviceTypeCode
						}
					});
		        	Ext.Ajax.request({
						url:'admin/getAssociatedFunctionDetailsByModuleId',
						params:{
							moduleId : selected[0].data.code,
							groupId : groupRecord.groupId,
							serviceType : groupRecord.serviceTypeCode
	                           },
						method:'GET',
						success:function(response){
							var respObj			=	Ext.JSON.decode(response.responseText);
						//	funcMgmtModuleTreeGrid.initialFunctions=[];
							Ext.Array.each(funcMgmtModuleTreeGrid.initialFunctions,function(val){
								funcMgmtModuleTreeGrid.initialFunctions.pop();
							});
                            Ext.Array.each(respObj,function(val){
                           	funcMgmtModuleTreeGrid.initialFunctions.push(val.code)
						    });


							var leftGridStore	=	Ext.getCmp(Modules.CompIds.groupFunctionExchangerPanelId).getGridsStoreFuncCmc({type:'left'});
							leftGridStore.removeAll();
							leftGridStore.add(respObj);	
						},
						failure:function(){
						}
					}); 
					
					
				}else{
				
				rightGridStore.load({
					   params:{
							moduleId : selected[0].data.code,
							groupId : groupRecord.groupId,
							serviceType : groupRecord.serviceTypeCode
						}
					});
				
				
				
				// below code is only for getting initial functions for EDIT and COPY Scenerio
				// we are using below AJAX call for  collecting removed functions only
				if(argObj && argObj.action != 'ADD'){
					
					Ext.Ajax.request({
						url:'admin/getAssociatedFunctionDetailsByModuleId',
						params:{
							moduleId : selected[0].data.code,
							groupId : groupRecord.groupId,
							serviceType : groupRecord.serviceTypeCode
	                           },
						method:'GET',
						success:function(response){
							var respObj			=	Ext.JSON.decode(response.responseText);
							Ext.Array.each(funcMgmtModuleTreeGrid.initialFunctions,function(val){
								funcMgmtModuleTreeGrid.initialFunctions.pop();
							});
	                        Ext.Array.each(respObj,function(val){
	                        	funcMgmtModuleTreeGrid.initialFunctions.push(val.code)
							});


						}
					}); 
				}
            	
        	}
			
      	
			}
		}
    }
    return funcMgmtModuleTreeGrid;

}//End Of Grid 