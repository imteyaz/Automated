	
Modules.admin.application_monitoring.change_log.form = function() {	
	Ext.QuickTips.init();
	/* Below code is the Advance VType validation for Date */	
	Ext.apply(Ext.form.field.VTypes, {
        daterange: function(val, field) {
            var date = field.parseDate(val);

            if (!date) {
                return false;
            }
            if (field.startDateField && (!this.dateRangeMax || (date.getTime() != this.dateRangeMax.getTime()))) {
                var start = field.up('form').down('#' + field.startDateField);
                start.setMaxValue(date);
                start.validate();
                this.dateRangeMax = date;
            }
            else if (field.endDateField && (!this.dateRangeMin || (date.getTime() != this.dateRangeMin.getTime()))) {
                var end = field.up('form').down('#' + field.endDateField);
                end.setMinValue(date);
                end.validate();
                this.dateRangeMin = date;
            }
            /*
             * Always return true since we're only using this vtype to set the
             * min/max allowed values (these are tested for after the vtype test)
             */
            return true;
        }
	});	
	
	var transIndStore={
			model: 'AuditLogModuleNameModel',
			queryTypeCmc:'remote',
			url:'changeLog/getTransIndLOV', //?userId=3&serviceType=HRBA',
			paging:true,
			listeners : {
				beforeload:function(){						
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
				}
			}
	};
	
	var userIdStore={
			model: 'AuditUserIdDTO',
			queryTypeCmc:'remote',
			url:'auditLog/getUserId',
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userName = Modules.GlobalVars.loginUserTypeCode;
				}
			}
	};
	
	var form = {
		xtype: 'cmcform',
		title: Modules.admin.application_monitoring.change_log.labels.formTitle,
		id: Modules.CompIds.changeLogFormId,
		plugins:[{ ptype: 'saveretrievecriteria',screenId:Modules.GlobalVars.changeLogScreenId, index:3}],
		width: 1000,
		height: 170,
		bodyStyle: 'background-color: #FFFFFF',		
		showFieldsetCmc: false,		
		tbar:[{
			text:"Clear",
			xtype:"button",
			iconCls:"clear",
			handler:function(){
				this.ownerCt.ownerCt.getForm().reset();
				Ext.getCmp(Modules.CompIds.changeLogScreenNameId).setValue(null);
				Ext.getCmp(Modules.CompIds.changeLogFormId).getForm().reset();
			    Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().removeAll();
			    Ext.getCmp(Modules.CompIds.changeLogChildGridId).getStore().removeAll();
			}
		},{
			xtype: "button",
			text:"Retrieve",
			iconCls:"retrieve",
		    handler:function()
			{
			if(Modules.GlobalVars.selectedCompanyCode != null){
                var ScreenId=Ext.getCmp(Modules.CompIds.changeLogScreenNameId).getValue();
				if(Ext.isEmpty(ScreenId)){
				Ext.MessageBox.show({
                    title: '',
                    msg: 'Screen Name is mandatory',
                    buttons: Ext.MessageBox.OK,
                    icon:Ext.MessageBox.ERROR
               });
			}
			else
			{										
				        Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().removeAll();
				        Ext.getCmp(Modules.CompIds.changeLogChildGridId).getStore().removeAll();			   
						Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().load({
							callback: function(records, operation, success) {
		                         if(success == true)
		                         {
		                        	 var count = Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().getCount();
			                            if(count == 0){
			                            	     Ext.MessageBox.show({
			                                     title: '',
			                                     msg: Modules.Msgs.noDataInGrid,
			                                     buttons: Ext.MessageBox.OK,
			                                     icon:Ext.MessageBox.INFO
			                                });
			                            }
			                            else{
			                            	
			                            }
			                               
		                         }
							}
						});	
			}
			}
			else{
				Ext.MessageBox.show({
                    title: '',
                    msg: Modules.Msgs.ValidationCorrectValue,
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
               });
			}
			}		
		},{
			xtype:"tbfill"
		}],
		
		setFormItemsFuncCmc: function () {
			var itemsArr = [];						
			
			var screenName = Modules.LovFactory.getScreenNameLov({
				fieldLabel: Modules.admin.application_monitoring.change_log.labels.screenName,
				id:Modules.CompIds.changeLogScreenNameId,
				name:'functionName',
				width: 200,
				labelWidth: 100,
				//labelAlign:"left",
				afterLabelTextTpl : requiredField,
				listeners: {
					select:function(combo,record,eOpts){
						if(record != undefined && record != null && record.length != 0){
							Ext.getCmp('changeLogScreenDescriptionId').setValue(record[0].getData().name);
						}						
					},
					change:function(){
						if(Ext.isEmpty(this.getValue())){
							Ext.getCmp('changeLogScreenDescriptionId').reset();
						}
					}
                }
			});
			
			var screenDesc = {
					xtype: 'cmctextfield',
					name: 'screenDescription',
					id:'changeLogScreenDescriptionId',
					width: 180,
					readOnly : true
			};
			
			var userName = {
					xtype: 'cmccombobox',
					id: Modules.CompIds.changeLogUserNameId,
					name: 'userName',
					storeObjCmc: userIdStore,
					selectOnTab: true,
					width: 200,
					labelWidth: 90,
					labelAlign:"left",
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.userName,
					displayField: 'userName',
					valueField: 'userName',
					matchFieldWidth: false,
					paging:true,					
					validateSuccessFuncCmc:function(serverRespOjbData){
						return true;
					},
					validateFailFuncCmc:function(){
						return true;
					},
					columnsCmc:[{
						header:'User Name',
						width:100,
						dataIndex:'userName'
					},{
						header:'Full Name',
						width:200,
						dataIndex:'fullName'
					}]
				};
			var transInd = {
					xtype: 'cmccombobox',
					id: Modules.CompIds.changeLogTransIndId,
					toolTipCmc : Modules.admin.application_monitoring.change_log.labels.transIndFullName,
					name: 'transInd',
					storeObjCmc: transIndStore,
					selectOnTab: true,
					width: 180,
					labelWidth: 80,
					labelAlign:"left",
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.transInd,
					displayField: 'moduleName',
					valueField: 'moduleName',
					matchFieldWidth: false,
					paging:true,
					validateUrlCmc:'changeLog/validateTransIndLOV',					
					validateParamsCmc:[{name:'cmpnyCode', id:'headerCompanyComboID'},{name:'userTyp', val:Modules.GlobalVars.loginUserTypeCode},
					                   {name:'userId', val:Modules.GlobalVars.loginUserId}],
					validateSuccessFuncCmc:function(serverRespOjbData){
						return true;
					},
					validateFailFuncCmc:function(){
						return true;
					},		
					listConfig: {
						width: 250,
						loadingText: Modules.Msgs.loading,
						height: 300,
						deferEmptyText: false,
						emptyText: Modules.Msgs.noComboValueFound,
						getInnerTpl: function () {
							return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="150px" align="left">{moduleName}</td></tr></table>';
						}
					}
				};
			var fromDate = {
					xtype: 'cmcdatefield',
					itemId: 'changeLogFromDateId',
					name: 'fromDate',
					width: 200,
					labelWidth: 90,
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.fromDate,
					labelAlign:"left",
					vtype: 'daterange',
					endDateField: 'changeLogToDateId' // id of the toDate field
				};
			var toDate = {
					xtype: 'cmcdatefield',
					itemId: 'changeLogToDateId',
					name: 'toDate',
					width: 180,
					fieldLabel: Modules.admin.application_monitoring.change_log.labels.toDate,
					labelAlign:"left",
					labelWidth: 80,
					vtype: 'daterange',
					startDateField: 'changeLogFromDateId' // id of the fromDate field
				};			
			
			var level1 = Modules.LovFactory.getLevel1Lov({
				fieldLabel: Modules.admin.application_monitoring.change_log.labels.level1,
				id:Modules.CompIds.changeLogLevel1Id,
				name: 'level1',
				width: 160,
				labelWidth: 60,
				listeners: {
					select:function(combo,record,eOpts){
						if(record != undefined && record != null && record.length != 0){
							Modules.GlobalVars.changeLogLevel1Value = record[0].getData().code;
						}						
					}
                }
			});
			
			var level2 = Modules.LovFactory.getLevel2Lov({
				fieldLabel: Modules.admin.application_monitoring.change_log.labels.level2,
				id:Modules.CompIds.changeLogLevel2Id,
				name: 'level2',
				width: 160,
				labelWidth: 60,
				listeners: {
					select:function(combo,record,eOpts){
						if(record != undefined && record != null && record.length != 0){
							Modules.GlobalVars.changeLogLevel2Value = record[0].getData().code;
						}						
					}
                }
			});
			
			var level3 = Modules.LovFactory.getLevel3Lov({
				fieldLabel: Modules.admin.application_monitoring.change_log.labels.level3,
				id:Modules.CompIds.changeLogLevel3Id,
				name: 'level3',
				width: 160,
				labelWidth: 60,
				listeners: {
					select:function(combo,record,eOpts){
						if(record != undefined && record != null && record.length != 0){
							Modules.GlobalVars.changeLogLevel3Value = record[0].getData().code;
						}						
					}
                }
			});
			
			var level4 = Modules.LovFactory.getLevel4Lov({
				fieldLabel: Modules.admin.application_monitoring.change_log.labels.level4,
				id:Modules.CompIds.changeLogLevel4Id,
				name: 'level4',
				width: 160,
				labelWidth: 60,
				listeners: {
					select:function(combo,record,eOpts){
						if(record != undefined && record != null && record.length != 0){
							Modules.GlobalVars.changeLogLevel4Value = record[0].getData().code;
						}						
					}
                }
			});
			
			var level1Data = Modules.LovFactory.getLevel1ValueLov({
				id:Modules.CompIds.changeLogLevel1DataId,
				name: 'level1Value',
				width: 100
			});
			var level2Data = Modules.LovFactory.getLevel2ValueLov({
				id:Modules.CompIds.changeLogLevel2DataId,
				name: 'level2Value',
				width: 100
			});
			var level3Data = Modules.LovFactory.getLevel3ValueLov({
				id:Modules.CompIds.changeLogLevel3DataId,
				name: 'level3Value',
				width: 100
				
			});
			var level4Data = Modules.LovFactory.getLevel4ValueLov({
				id:Modules.CompIds.changeLogLevel4DataId,
				name: 'level4Value',
				width: 100
			});			
			
			/**START Container..1 Component**/
			var container1 = {
				xtype: 'container',
				layout: 'hbox',
				margin: '4px 4px 4px 4px',
				defaults:{
					margin:'0px 10px 0px 10px'
				},
				items: [screenName,screenDesc]
			};
			
			/**START Container..2 Component**/		
			var container2 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '4px 4px 4px 4px',
					defaults:{
						margin:'0px 10px 0px 17px'
					},
					items: [userName,transInd]
				};
			
			/**START Container..3 Component**/		
			var container3 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '4px 4px 4px 4px',
					defaults:{
						margin:'0px 10px 0px 17px'
					},
					items: [fromDate,toDate]
				};
			
			/**START Container..4 Component**/		
			var container4 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level1,level1Data]
				};
			var container5 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level2,level2Data]
				};
			var container6 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level3,level3Data]
				};
			var container7 = {
					xtype: 'container',
					layout: 'hbox',
					margin: '2px 2px 2px 2px',
					defaults:{
						margin:'0px 10px 0px 10px'
					},
					items: [level4,level4Data]
				};
			
			var leftContainer = {
					xtype: 'container',
					layout: 'vbox',
					margin: '4px 4px 0px 4px',
					defaults:{
						margin:'0px 10px 0px 0px'
					},
					items: [container1,container2,container3]
				};
			
			var levelContainer = {
					xtype: 'container',
					layout: 'vbox',
					margin: '0px 0px 0px 0px',
					defaults:{
						margin:'0px 10px 0px 0px'
					},
					items: [container4,container5,container6,container7]
				};
			var mainContainer = {
					xtype: 'container',
					layout: 'hbox',
					margin: '0px 4px 4px 4px',
					defaults:{
						margin:'0px 20px 0px 0px'
					},
					items: [leftContainer,levelContainer]
				};
			
			itemsArr = [mainContainer];
			return itemsArr;
		}
	};
	return form;
};