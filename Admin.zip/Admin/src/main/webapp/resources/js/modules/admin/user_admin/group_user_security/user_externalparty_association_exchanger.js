
Modules.admin.user_admin.group_user_security.user_externalparty_association_grid	= function(){
	var panel	=	{
		xtype:'cmcpanelwithgridexchanger',
		width:700,
		height:200,
		btnWidthCmc:100, 
		region:'center', 
		btnCntrWidthCmc:120,
		btnTopMarginCmc:'50px 0px 5px 0px',
		modelKeyFields :['companyCode', 'partyCode'],
		setRightGridFuncCmc:function(){ 
			var store = {
				model: 'ExternalPartyDTO',
				url: 'commonLov/getExternalPartyLOV',
				paging : true,
				queryTypeCmc : 'remote',
				proxyConfig : {actionMethods : {read   : 'POST'}}, 
				listeners : {
					beforeload : function() {
						this.proxy.extraParams.limit = 100;
						this.pageSize = 100;
						var partyField=Ext.getCmp('externalPartyGridId').down('#partyFilterItemId');
						if(partyField){
							this.proxy.extraParams.partyCode=partyField.getValue();
						}
						
					}
			    }
			}; 
			var grid = {
				xtype: 'cmcgrid',
				storeObjCmc: store,
				id :'externalPartyGridId',
				title:'List of Parties',
				showPagingBarCmc : true,
				showLeftExtraTbarCmc:true,
				showExtraTbarCmc : true,
				addPagingComboCmc:false,
				paging : true,
				setLeftExtraTbarFuncCmc : function() {
					var searchFields=[{
						xtype : 'cmctextfield',
						name : 'partyCode',
						itemId : 'partyFilterItemId',
						width:250,
						labelWidth:60,
						labelAlign:'right',
						fieldLabel : 'Party Code'
					}];
					return searchFields;
				},setExtraTbarFuncCmc : function() {
				    var buttonArray = [ {
				    	xtype: "button",
						text:'Filter',
						itemId : 'filter',
						name : 'filter',
						icon : 'resources/images/filter.png',
						width: 85,
						handler:function(){
						//	var partyField=Ext.getCmp('externalPartyGridId').down('#partyFilterItemId');
						//	if(!Ext.isEmpty(partyField.getValue())){
							Ext.getCmp('externalPartyGridId').getStore().loadPage(1);
						//	}
							
						}}];
							return buttonArray;
						},
				setGridColumnsFuncCmc: function () {
					 var columns = [{
						header : 'Company Code',
						flex :1,
						dataIndex : 'companyCode'
					},{
						header : 'Party Code',
						flex :1,
						dataIndex : 'partyCode'
					}]; 
					return columns;
				}
			}; 
			return grid;
		}
	}; 
	return panel; 
};//End Of Grid Exchanger Grid 