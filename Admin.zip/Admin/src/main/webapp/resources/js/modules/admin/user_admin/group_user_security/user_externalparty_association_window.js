
Modules.admin.user_admin.group_user_security.externalpartypanel = function (argObj) {
	//var modifiedExternalPartyCodes=[];
	//var isFirstTime=true;
	var panel = Ext.create('Ext.Panel', {
		height:500,
		width: 980,
		title: 'External Party',
		id: 'userToExternalPartyAssociationWindowId',
		//winFuncArgObjCmc:argObj,
		openModeCmc:'ADD',
		buttonAlign: "center",
		modal :true,
		showNorthItemCmc: true,
		buttonAlign: "center",
		layout:'border',
		disabled : true,
		
		items:[Modules.admin.user_admin.group_user_security.user_externalparty_association_grid()],
		listeners: {
			beforeactivate:function(panel){
				var companyStore = Ext.getCmp('userToComapnyAssociationWindowId').down('#leftGridPanelWithGridExchangerItemId').getStore();
				if(companyStore.getCount() > 0 ) {
					var form = Ext.getCmp(Modules.CompIds.oceanUserManagementWindowId).down('#OceanUserManagementForm');
					var usertype = form.down('#UserTypeCodeId').getValue();
					var userid = form.down('#userId').getValue();
					var companyStore = Ext.getCmp('userToComapnyAssociationWindowId').down('#leftGridPanelWithGridExchangerItemId').getStore();
					var companyCodeArr = [];
				
					companyStore.each(function(rec){
						companyCodeArr.push(rec.get('code')
						);
					});
					if(usertype == 'C' || usertype  == 'S' || usertype  == 'A') {
						var el=Ext.getCmp(Modules.CompIds.oceanUserManagementWindowId).getEl();
						el.mask('Loading External Party..');	
						var gridExchangerExternalParty = Ext.getCmp('userToExternalPartyAssociationWindowId').down('cmcpanelwithgridexchanger');
						var rightGridStoreExternalParty = Ext.getCmp('externalPartyGridId').getStore();
						var leftGridExternalParty		=		gridExchangerExternalParty.query('#leftGridPanelWithGridExchangerItemId')[0];
		        		var leftGridStoreExternalParty  =		leftGridExternalParty.getStore();
						var totalRecords=[];
						
						if(argObj.action == 'ADD') {/*
							leftGridStoreExternalParty.each(function(record){
								totalRecords.push(record);
							});
							//isFirstTime = false;
						*/} else if(argObj.action == 'EDIT' || argObj.action == 'COPY') {/*
							if(argObj.record.externalPartyDtls && argObj.record.externalPartyDtls.length > 0) {
								if(modifiedExternalPartyCodes.length == 0 && isFirstTime) {
									isFirstTime=false;
									modifiedExternalPartyCodes=argObj.record.externalPartyDtls;
									leftGridStoreExternalParty.insert(0, modifiedExternalPartyCodes);
								}
								//totalRecords = modifiedExternalPartyCodes;
					    	}
						*/}
						
						//leftGridStoreExternalParty.removeAll();
						
					//	rightGridStoreExternalParty.on('load',function(){
		        	//		gridExchangerExternalParty.autoSelectByIgnoringDuplicateValuesFnCmc(totalRecords,isFirstTime);
		        	//		isFirstTime = false;
		        	//	},this,{single:true});
						
						
						Ext.getCmp('externalPartyGridId').getStore().proxy.extraParams = {
							companyCode:companyCodeArr,
							userType:usertype,
							userId:userid};
						Ext.getCmp('externalPartyGridId').getStore().load({callback : function(records, options, success) {el.unmask()}});
						}
				} else {
				//	Ext.Msg.alert('Information', 'Please associate companies to the user first');
					return false;
				}
				
			},
			beforedeactivate : function(panel) {
				if(argObj.action == 'EDIT' || argObj.action == 'COPY') {/*
					modifiedExternalPartyCodes = [];
					var gridExchangerExternalParty = Ext.getCmp('userToExternalPartyAssociationWindowId').down('cmcpanelwithgridexchanger');
					var leftGridExternalParty		=		gridExchangerExternalParty.query('#leftGridPanelWithGridExchangerItemId')[0];
					var leftGridStoreExternalParty  =		leftGridExternalParty.getStore();
					leftGridStoreExternalParty.each(function(rec){
						modifiedExternalPartyCodes.push(rec);
					});
				*/}
			}
		}
	});
	return panel;
}; //End OF Window