
Modules.admin.user_admin.group_user_security.northGrid = function (mergeObj) {
	var buttons=mergeObj.buttons;
	var groupFormObject = {
			xtype: 'cmcform',
			bodyStyle: 'background-color: #FFFFFF',
			showFieldsetCmc: false,
			title: 'Search Groups',//'Group Query Parameters',
			collapsible : false,
			collapsed : false,
			region:'north',
			height:80,
			width : 1000,
			itemId : 'groupSearchFormItemId',
			setFormItemsFuncCmc: function () {
				var itemsArr = [];
				
				var groupCodeField = {
						xtype : 'cmctextfield',
						name : 'groupCodeField',
						itemId:'groupCodeField',
						width:200,
						labelWidth : 80,
						labelAlign:"right",
						fieldLabel : 'Group Code'
					};
				var groupNameField = {
						xtype : 'cmctextfield',
						name : 'groupNameField',
						itemId:'groupNameField',
						width:200,
						labelWidth : 80,
						labelAlign:"right",
						fieldLabel : 'Group Name'
					};
				
			/*	var groupDescField = {
						xtype : 'cmctextfield',
						name : 'groupDescField',
						itemId:'groupDescField',
						width:300,
						labelWidth : 100,
						labelAlign:"right",
						fieldLabel : 'User'
					};*/
				
				var userNamefield = {
						xtype : 'cmctextfield',
						name : 'userNamefield',
						itemId:'userNamefield',
						width:300,
						labelWidth : 100,
						labelAlign:"right",
						fieldLabel : 'UserName'
					};
				
				var groupFilterField= {
				    	xtype: "button",
						text:'Filter',
						itemId : 'filter',
						name : 'filter',
						icon : 'resources/images/filter.png',
						width: 85,
						handler:function(){
							var searchObj=this.up('#groupSearchFormItemId').getForm().getValues(false,false);
							var store=Ext.getCmp(Modules.CompIds.adminGroupGridId).getStore();
							Ext.apply(store.proxy.extraParams,searchObj);
							store.loadPage(1);
						}
				};
				var container1 = {
						xtype: 'container',
						layout: 'hbox',
						labelAlign:"left",
						margin: '10px 10px 10px 0px',
						defaults:{
							margin:'0px 30px 0px 0px'
						},
						items : [groupNameField,userNamefield,groupFilterField]//groupCodeField,
				};	
				var itemsArr = [container1];
				return itemsArr;
			}
		};
	
	
	
	

	var groupGridStore = {
		model: 'GroupModel', //'GroupModel',  
		autoLoad : true,
		url: 'admin/getGroupDtls',
		paging : true,
		queryTypeCmc : 'remote',
		id : 'manageGroupGridStore',
		listeners : {
			beforeload : function() {
					this.proxy.extraParams.companyCode=Modules.GlobalVars.selectedCompanyCode;
				    this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
					var limitVal = Ext.getCmp(Modules.CompIds.adminGroupGridId).getComponent('centerGridPagingToolBarItemId').getComponent('perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				
			}
		}
	};
	
	
	
	
	var groupGrid = {
		xtype: 'cmcgrid',
		minHeight: 80,
		region:'center',
		storeObjCmc: groupGridStore,
		title: Modules.admin.user_admin.user_management.labels.groupDetails,//,'Group Details',
		id: Modules.CompIds.adminGroupGridId,
		showPagingBarCmc : true,
		showTotalSelectedCmc:true,
		showTotalCountCmc : true,
		showLeftExtraTbarCmc : true,
		showExtraTbarCmc : true,
		showSelModelCmc:true,
		statefulCmc:false,
		viewConfig : {
			stripeRows : true
		},
		listeners : {
			cellclick : function(viewObj, td, cellIndex, record, tr, rowIndex,eventObj) {
				if (cellIndex == '1' && buttons.indexOf("AUMMDG")>= 0) {    	
					var window=Modules.admin.user_admin.group_user_security.groupWindow({action : 'EDIT',record : record.data});
	            	window.show();
				}
				
			}
		},
		setLeftExtraTbarFuncCmc : function() {
			var buttonArray = [{
				text : "Edit Group",//Modules.admin.user_admin.user_management.labels.properties,//"Properties",
				iconCls : "properties",
				hidden : buttons.indexOf("AUMMDG")< 0,
				handler : function() {
					var gridObj = Ext.getCmp(Modules.CompIds.adminGroupGridId);
					if (gridObj.getStore().getCount() > 0){
						var sm = gridObj.getSelectionModel().getSelection();
						if(sm.length == 1){
						//	var selectedRecord =gridObj.getSelectionModel().getLastSelected();  removed because of bug in extjs, not returning correct record
							
							var selectedRecord = sm[0];
						 	var window=Modules.admin.user_admin.group_user_security.groupWindow({action : 'EDIT',record : selectedRecord.data});
			            	window.show();
						}else if(sm.length > 1){
							Ext.MessageBox.show({
                                msg: 'Please select only one record.',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						} else {
							Ext.MessageBox.show({
                                msg: Modules.Msgs.selRecFrst,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					}else {
						Ext.MessageBox.show({
                            msg: Modules.Msgs.noRecordsPropeties,
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}
				}
			},{
				text : Modules.admin.user_admin.user_management.labels.newGroup,//"New Group",
				iconCls : "newGroup",
				hidden : buttons.indexOf("AUMCRG")< 0,
				handler : function() {
					var window=Modules.admin.user_admin.group_user_security.groupWindow({action : 'ADD'});
                	window.show();
				}
			},{
				text : Modules.admin.user_admin.user_management.labels.deleteGroup,//"Delete Group",
				iconCls : "deleteGroup",
				hidden : buttons.indexOf("AUMDLG")< 0,
				handler : function() {
					var gridObj = Ext.getCmp(Modules.CompIds.adminGroupGridId);
					if (gridObj.getStore().getCount() > 0){
						var sm = gridObj.getSelectionModel().getSelection();
						if(sm.length >= 1){
							var deleteMsg="This action deletes the Group and all associations will be removed. Do you want to continue?";
							Ext.Msg.confirm('',deleteMsg, function (answer) {
								if (answer == "yes") {
									// var selectedRecord =gridObj.getSelectionModel().getLastSelected();  // removed because of bug in extjs, not returning correct record
									 
									// var selectedRecord = sm[0];
									
									/*var selectedRows = Ext.getCmp('equipmentMasterGridId').getSelectionModel().getSelection();   
									equipmentStore.remove(selectedRows);*/
									var systemDefinedMsg="This action can not be performed as following groups are system defined and hence can not be deleted : ";
									var sysGroupsArray = [] ;
									var grpIdArray= [];
									for(i=0;i<sm.length;i++){
										var grpId = sm[i].data.groupId ;
										grpIdArray[i]=grpId ;
										
										var grpName = sm[i].data.groupName ;
										var systemDefined = sm[i].data.systemDefined ; 
										if(systemDefined=='Y'){
											sysGroupsArray.push(grpName);
										}
										
									}
									var sysGroups = sysGroupsArray.join(); 
									
									if(sysGroups){
										Ext.MessageBox.show({
											title :'System Defined Groups can not be deleted',
											msg: systemDefinedMsg + sysGroups ,
											buttons: Ext.MessageBox.OK,
											icon: Ext.MessageBox.INFO
										});
										return false;
									}
									
									 if(grpIdArray){
										 Ext.Ajax.request({
												url:'admin/deleteGroupByGroupId',
												params:{
													'groupId' : grpIdArray,//selectedRecord.data.groupId,
													'serviceType' : "TTS"//selectedRecord.data.serviceTypeCode//Modules.GlobalVars.selectedServiceTypeCode
												},
												method:'GET',
												success:function(response){
													var respObj			=	Ext.JSON.decode(response.responseText);
													if(respObj.status == 'success'){
												     Ext.getCmp(Modules.CompIds.adminGroupGridId).getStore().remove(sm);
														Ext.MessageBox.show({
															msg: Modules.admin.user_admin.group_user_security.messages.deletedSuccessfully,
															buttons: Ext.MessageBox.OK,
															icon: Ext.MessageBox.INFO
														});
														
														var grpStore = Ext.StoreManager.lookup('manageGroupGridStore') ;
														grpStore.load();
														
													}else if(respObj.status == 'failure'){
														Ext.MessageBox.show({
															msg: "Error : "+respObj.error,
															buttons: Ext.MessageBox.OK,
															icon: Ext.MessageBox.INFO
														});
													}
												},
												failure:function(){
												}
											}); 
										 
									 }
								}
							});
							
						 	
						}/*else if(sm.length > 1){
							Ext.MessageBox.show({
                                msg: 'Please select only one record.',
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}*/ else {
							Ext.MessageBox.show({
                                msg: Modules.Msgs.selRecFrst,
                                buttons: Ext.MessageBox.OK,
    	                        icon: Ext.MessageBox.INFO
                            });
						}
					}else {
						Ext.MessageBox.show({
                            msg: 'Grid is empty',
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}
					
					
					
					
					
				}
			}, {
				text : Modules.admin.user_admin.user_management.labels.copyGroup,//"Copy Group",
				iconCls : "copyGroup",
				hidden : buttons.indexOf("AUMCOG")< 0,
				handler : function() {
					var gridObj = Ext.getCmp(Modules.CompIds.adminGroupGridId);
					if (gridObj.getStore().getCount() > 0){
						var sm = gridObj.getSelectionModel().getSelection();
							if(sm.length == 1){
								var selectedRecord =gridObj.getSelectionModel().getLastSelected();
								 if(selectedRecord){
									    var window=Modules.admin.user_admin.group_user_security.groupWindow({action : 'COPY',record : selectedRecord.data});
						            	window.show();
								}
							}else if(sm.length > 1){
								Ext.MessageBox.show({
	                                msg: 'Please select only one record.',
	                                buttons: Ext.MessageBox.OK,
	    	                        icon: Ext.MessageBox.INFO
	                            });
							}  else {
			                	Ext.MessageBox.show({
	                                msg: Modules.Msgs.selRecFrst,
	                                buttons: Ext.MessageBox.OK,
	    	                        icon: Ext.MessageBox.INFO
	                            });
			                }
						}else {
							Ext.MessageBox.show({
	                            msg: 'Grid is empty',
	                            buttons: Ext.MessageBox.OK,
		                        icon: Ext.MessageBox.INFO
	                        });
						}
					}
			}];
			return buttonArray;
		},
		setGridColumnsFuncCmc: function () {
			
			var colsArr = [{
				header:  Modules.admin.user_admin.user_management.labels.groupCode,//'Group Code',
				hideable : false,
                width : 200,
				dataIndex: 'groupCode'
			},{
				header: Modules.admin.user_admin.user_management.labels.groupName,//'Group Name',
				hideable : false,
                width : 250,
				dataIndex: 'groupName'
			},{
				header: Modules.admin.user_admin.user_management.labels.groupDesc,//'Group Description',
				width : 350,
				dataIndex: 'groupDesc'
			}];
			if(buttons.indexOf("AUMMDG")>= 0){
				colsArr.splice(0,0,{
					xtype : 'actioncolumn',
					width : 25,
					sortable : false,
					hideable : false,
					items : [ {
						icon : 'resources/images/editView.jpg',
						tooltip : Modules.LblsAndTtls.tooltip.openPopupWin,
						handler : function() {
							return true;
						}
					} ]
	            });
			}
			return colsArr;
		}
	}
	
	
	var  northGroupContainer= {
			collapsible:false,
			//autoScroll:true,
			xtype:'panel',
			height : 250,
			layout:'border',
			items: [
				    groupFormObject , 
			        groupGrid
		        ]
			};
	
	return northGroupContainer;
	
	
	
	//return groupGrid;
	}; //EOF