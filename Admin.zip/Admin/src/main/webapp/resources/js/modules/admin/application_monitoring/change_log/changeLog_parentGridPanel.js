Modules.admin.application_monitoring.change_log.parentGridPanel = function() {
	
	var changeLogParentGridStoreObj = {
		model : 'changeLogParentGridModel',
		url : 'changeLog/getChangeLogParentGridData',
		paging : true,
		queryTypeCmc : 'remote',
		listeners : {
			beforeload : function() {
				
				var searchObj = Ext.getCmp(Modules.CompIds.changeLogFormId).getForm().getValues(false,true);
				this.proxy.extraParams = {
						localeLang : Modules.GlobalVars.userLocale
				};
				
				Ext.apply(this.proxy.extraParams,searchObj);
				this.proxy.extraParams.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
				var limitVal = Ext.getCmp(Modules.CompIds.changeLogParentGridId).getComponent(
						'centerGridPagingToolBarItemId').getComponent(
						'perPageCombo').getValue();
				if (!limitVal) {
					limitVal = Modules.GlobalVars.recordsPerPageGrid;
				}
				this.proxy.extraParams.limit = limitVal;
				this.pageSize = limitVal;
			},
			load : function(store, records, success, eOpts ) {
				if(success==true){
					var count = records.length;
			        if (count != 0) {
			        if(!Ext.getCmp(Modules.CompIds.changeLogFormId).getCollapsed()){
			        Ext.getCmp(Modules.CompIds.changeLogFormId).collapse( Ext.Component.DIRECTION_TOP );
			        }   
			        }
			        
					var recordCount = records.length;
				    if(recordCount == 0){
    	            	Ext.MessageBox.show({
                             title: '',
                             msg: Modules.Msgs.noDataInGrid,
                             buttons: Ext.MessageBox.OK,
                             icon:Ext.MessageBox.INFO
                        });
                    }
                    else{
                    	Ext.getCmp(Modules.CompIds.changeLogParentGridId).getSelectionModel().select(records[0]);
                    	var childStore=Ext.getCmp(Modules.CompIds.changeLogChildGridId).getStore();
                    	childStore.load({params : {'changeSeqNo' : records[0].data.changeSeqNo}});
                    				                            	
                    }										
				}
			}	
		}
	};
	
	var getSearchObject = function(){
		var searchObj = Ext.getCmp(Modules.CompIds.changeLogFormId).getForm().getValues(false,true);	
		searchObj.localeLang = Modules.GlobalVars.userLocale;
		searchObj.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
		return searchObj;
	};	
	
	
	var parentGridObj = {
		xtype : 'cmcgrid',
		id : Modules.CompIds.changeLogParentGridId,
		storeObjCmc : changeLogParentGridStoreObj,
	    showPagingBarCmc : true,
	    showSelModelCmc : true,
	    showTotalSelectedCmc:true,
		showExtraTbarCmc : true,
	    popUpWinFuncCmc: Modules.admin.application_monitoring.change_log.parentGridEditWin,//Window function which will return the object of pop-up window
		popUpWinIdCmc: 'NonOceanChangeLogParentGridWindow',//Id of the pop-up window
		popUpCellIndexCmc:1,//This is the column index at which the icon will appear. It can be ignored if the column index is 1
	    setExtraTbarFuncCmc : function() {
			var buttonArray = [ '->', {
				xtype : 'button',
				iconCls : "excel",
				tooltip: Modules.Msgs.excelReportToolTip,
				handler:function(){
					var grid = Ext.getCmp(Modules.CompIds.changeLogParentGridId);
					var searchObj = getSearchObject();
					if (Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().getCount() > 0){
						Ext.cmc.Exporter.exportToXls(grid, searchObj,'changeLog/getChangeLogParentDetailsExport');					
					}
					else{
						Ext.MessageBox.show({
                            title: '',
                            msg: Modules.Msgs.emptyGrid,
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}										
				}		
			},
			{
				xtype : 'button',
				iconCls : "report",
				tooltip: Modules.Msgs.pdfReportToolTip,	
				handler:function(){
					var grid = Ext.getCmp(Modules.CompIds.changeLogParentGridId);
					var searchObj = getSearchObject();					
					if (Ext.getCmp(Modules.CompIds.changeLogParentGridId).getStore().getCount() > 0){
						Ext.cmc.Exporter.exportToPdf(grid, searchObj,'changeLog/getChangeLogParentDetailsExport');						
					}
					else{
						Ext.MessageBox.show({
                            title: '',
                            msg: Modules.Msgs.emptyGrid,
                            buttons: Ext.MessageBox.OK,
	                        icon: Ext.MessageBox.INFO
                        });
					}
				}							
			}];
			return buttonArray;
		},
		setGridColumnsFuncCmc : function() {
			var colsArr = [
{
	xtype : 'actioncolumn',
	width : 25,
	sortable : false,
	hideable : false,
	align : 'center',
	items : [ {
		icon : 'resources/images/editView.jpg',
		tooltip : Modules.LblsAndTtls.tooltip.openPopupWin,
		handler : function() {
			return true;
		}
	} ]
},
					{
						xtype : 'actioncolumn',
						width : 35,
						sortable : false,
						hideable : false,
						items : [ {
							icon: 'resources/images/relationView.jpg',
			                tooltip: 'Retrieve Child Records',
			                align : 'center',
							handler : function() {
								return true;
							}
						} ]
					},
					
					{
						header : Modules.admin.application_monitoring.change_log.labels.functionName,
						dataIndex : 'functionName',
						width : 250,
						 tdCls:'custom-column' ,
						readOnly : true
						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.userName,
						dataIndex : 'userName',
						width : 100,
						 tdCls:'custom-column' ,
						readOnly : true						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.transInd,
						tooltip : Modules.admin.application_monitoring.change_log.labels.transIndFullName,
						dataIndex : 'transInd',
						width : 100,
						 tdCls:'custom-column' ,
						readOnly : true						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level1,
						dataIndex : 'level1',
						width : 100,
						 tdCls:'custom-column' ,
						readOnly : true						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level1Value,
						dataIndex : 'level1Value',
						width : 100,
						readOnly : true,
						 tdCls:'custom-column' 
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level2,
						dataIndex : 'level2',
						width : 100,
						 tdCls:'custom-column' ,
						readOnly : true						
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level2Value,
						dataIndex : 'level2Value',
						width : 100,
						readOnly : true,
						tdCls:'custom-column' 
					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level3,
						dataIndex : 'level3',
						width : 100,
						readOnly : true,
						 tdCls:'custom-column' 

					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level3Value,
						dataIndex : 'level3Value',
						width : 100,
						readOnly : true,
						 tdCls:'custom-column' 

					}
					,
					{
						header : Modules.admin.application_monitoring.change_log.labels.level4,
						dataIndex : 'level4',
						width : 100,
						readOnly : true,
						 tdCls:'custom-column' 

					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.level4Value,
						dataIndex : 'level4Value',
						width : 100,
						readOnly : true,
						 tdCls:'custom-column' 

					},
					{
						header : Modules.admin.application_monitoring.change_log.labels.logDateTime,
						dataIndex : 'logDateTime',
						width : 150,
						readOnly : true,
						 tdCls:'custom-column' ,
						renderer: Ext.util.Format.dateRenderer(Modules.GlobalVars.dateTimeFormatGlobal)
					}
			];
			return colsArr;
		},
		viewConfig : {
			stripeRows : true
		},
		listeners : {			
			cellclick : function( grid, td, cellIndex, record, tr, rowIndex, e, eOpts){
				if(cellIndex == '2')
				{
					grid.getSelectionModel().select(record);
					var store=Ext.getCmp(Modules.CompIds.changeLogChildGridId).getStore();
					store.load({params : {'changeSeqNo' : record.data.changeSeqNo}});
				} 				   						
			}
		}
	};
	return parentGridObj;
};
