
Modules.admin.user_admin.group_user_security.grouppanel = function (argObj,userForm) {
	var panel = Ext.create('Ext.Panel', {
		height:450,
		width: 700,
		title: 'Group',
		id: 'userToGroupAssociationWindowId',
		winFuncArgObjCmc:argObj,
		openModeCmc:'ADD',
		buttonAlign: "center",
		modal :true,
		showNorthItemCmc: true,
		buttonAlign: "center",
		layout:'border',
		items:[Modules.admin.user_admin.group_user_security.user_group_association_grid()]
	});
	return panel;
}; //End OF Window