Modules.Master.GenericChecklistMaster.genericChecklistId
/************************************* Window title *************************************/

Modules.LblsAndTtls.myWindowName = 'My window';
Modules.LblsAndTtls.importErrorMsgWinTlt = 'Error Message Window';
Modules.LblsAndTtls.ocnCovusManifestAmtCurrencyTlt = 'Manifest Amount Details';
Modules.LblsAndTtls.accRecWinTitle='Account Recievable';
Modules.LblsAndTtls.ocnCovusBankDtlsTlt =  'Bank Details';
Modules.LblsAndTtls.accPayWinTitle='Account Payable'; 
Modules.LblsAndTtls.winInSupplierRemitAdvcTlt='Supplier Remittance Advice Message';
Modules.LblsAndTtls.srvcChrgeInvcWinTitle='Service Charge Invoice';
Modules.LblsAndTtls.truckInvcWinTitle='Truck Invoice';
Modules.LblsAndTtls.railInvcWinTitle='Rail Invoice';
Modules.LblsAndTtls.custrmInvcWinTitle='Customer Invoice';
Modules.LblsAndTtls.covusXmlWinTitle='Covus Xml Interface';
Modules.LblsAndTtls.CovusInvoiceDetailsTlt='Covus Invoice details';
Modules.LblsAndTtls.CovusInvoiceSubDetailsTlt='Covus Invoice Sub Details';
Modules.LblsAndTtls.CovusTaxDetailsTlt='Covus Tax Details';
Modules.LblsAndTtls.RailInvcRoutingDetailsTlt='Rail Invoice Routing Details';
Modules.LblsAndTtls.RailInvcEvntDtlsTlt='Rail Invoice Event Details';
Modules.LblsAndTtls.RailInvcDetailsTlt='Rail Invoice Details';
Modules.LblsAndTtls.ocnSupplierMasterContactPrsnDetails  =  'Contact Person Details';
Modules.LblsAndTtls.supplierEventStatusSummaryParentTabTlt = 'Supplier Event Status Summary';
Modules.LblsAndTtls.ocnCovusCargoDetailsTlt = 'Cargo Details';
Modules.LblsAndTtls.ocnCovusTaxDetailsTlt = 'Tax Details';
Modules.LblsAndTtls.ocnCovusInvcSubDetailsTlt = 'Invoice Sub Details';
Modules.LblsAndTtls.ocnCovusInvoiceDetailsTlt = 'Invoice  Details';
Modules.LblsAndTtls.ocnCovusBLHdrTlt = 'BL  Details';
Modules.LblsAndTtls.partyMsgTitle = 'Party Message';
Modules.LblsAndTtls.partyDtlsTitle = 'Party Details';
Modules.LblsAndTtls.oceanViewCovusXml = 'Covus Xml Interface';

Modules.LblsAndTtls.outSupplRemitAdvceInvcWinTitle='OUT SUPPLIER REMITTANCE ADVICE';

Modules.LblsAndTtls.oceanViewEventMessage = 'Event Message';

Modules.LblsAndTtls.customerRatesTtl='Customer Rates';
Modules.LblsAndTtls.OcnCstmrRatesParentPopup  = 'Ocean Customer Rates Hdr Add/Edit Window';
Modules.LblsAndTtls.OcnCstmrRatesChildPopup   = 'Ocean Customer Rates Details Add/Edit Window';

Modules.LblsAndTtls.cstmrRatesParentPopup   = 'Customer Rates Hdr Add/Edit Window';

Modules.LblsAndTtls.saveSearchCriteriaWindowTlt='Save Search Criteria';
Modules.LblsAndTtls.retrieveSearchCriteriaWindowTlt='Retrieve Search Criteria';
Modules.LblsAndTtls.specialMoveEntryDestinationStateProvinceId='Destination S/P';

Modules.LblsAndTtls.cstrRemitAdvcWinTitle = 'Customer Remittance Advice Message';
Modules.LblsAndTtls.outCstmrRemitAdvcwinTitle = 'Out Customer Remittance Advice Message';

Modules.LblsAndTtls.popupCstmrEvntStsSummGridTlt = 'Customer Event Status Summary Details';
Modules.LblsAndTtls.cstmrRatesCompositeWinTlt    = 'Composite Service Details';
Modules.LblsAndTtls.cstmrRatesMinLoadWinTlt=     'Minimum Load Details';
Modules.LblsAndTtls.cstmrRatesAgreedMileageWinTlt  = 'Agreed Mileage Details';
Modules.LblsAndTtls.customerDebtorPartyTlt = 'Customer Debtor Party Details';
Modules.LblsAndTtls.customerMasterTlt     =  'Customer Master';
Modules.LblsAndTtls.customerInvoiceStatusLabelTlt = 'Customer Invoice Status Ocean';
Modules.LblsAndTtls.OcnSupplrMasterDtlsGridPopup = 'Supplier Master Details';

Modules.LblsAndTtls.ocnSupplrMasterStsDtForContractId = 'Status Date for Contract Identification';

Modules.LblsAndTtls.ocnSupplrMasterAutomaticInvcSetup = 'Automatic Invoice Setup';
Modules.LblsAndTtls.ocnSupplrMasterRoundingCriteriaforRatePop  =  'Rounding Criteria For Rate';

Modules.LblsAndTtls.spplrEventStatusSummaryParentTabpanelTtl = 'Supplier Event Status Summary';
Modules.LblsAndTtls.ocnSpplrEventStatusSummaryTtl = 'Supplier Event Status Summary';

Modules.LblsAndTtls.ocnCustomerRatesTtl   =  'Customer Rates';
Modules.LblsAndTtls.ocnCustomerRatesDtlsTtl  = 'Customer Rates Details';
Modules.LblsAndTtls.ocnCstmrRateContractDtls = 'Customer Rates Contract Details';
Modules.LblsAndTtls.oceanCustomerRateQueryServiceParentTabpanelTtl = 'Ocean Customer Rate Query Service Code';
Modules.LblsAndTtls.supplierRateQueryServiceCodeParentTabpanelTtl = 'Supplier Rate Query Service Code';
Modules.contract.supplier.supplier_rate_query.screenTlt = 'Supplier Rate Query';
Modules.LblsAndTtls.oceanCstmrRatesDtlsCopyWinTlt='Customer Rates Details Copy Window';
Modules.LblsAndTtls.OcnSupplierEvntStsSummPopupTlt = 'Event Status Summary Details ';

Modules.LblsAndTtls.supplrMasterRoundingCriteriaforDistancePopTlt = 'Rounding Criteria For Distance';

Modules.LblsAndTtls.supplierMasterTtl = 'Supplier Master';
Modules.LblsAndTtls.supplrMasterHdrGridPopupTlt = 'Supplier Master Add/Edit Window';
Modules.LblsAndTtls.supplrMasterPaymntTermDtls  = 'Payment Term Add/Edit Window';
Modules.LblsAndTtls.supplrMasterStsDtForContractIdPop = 'Status Date for Contract Identification Add/Edit Window';
Modules.LblsAndTtls.supplrMasterAutomaticInvcSetupTlt = 'Automatic Invoice Setup Add/Edit Window';
Modules.LblsAndTtls.tooltip.editWin			=	'Edit Window';
Modules.LblsAndTtls.cstmrRatesMinLoadGridId = 'Minimum Load Details';
Modules.LblsAndTtls.cstmrRateAgreedMileageDtls = 'Agreed Mileage';
Modules.LblsAndTtls.cstmrRatesAgreedMileagePopupWin = 'Customer Rates Agreed Mileage';
Modules.LblsAndTtls.cstmrRatesFuelSurchrgPopupWin = 'Customer Rates Fuel Surcharge Add/Edit Window';
Modules.LblsAndTtls.cstmrRatesDetailsPopupWin     = 'Customer Rates Details Add/Edit Window';
Modules.LblsAndTtls.cstmrRatesMinLoadPopupWin     = 'Customer Rates Min Load Details ';

Modules.LblsAndTtls.cstmrRatesFuelSurchrgCopyWinTlt = 'Customer Rates Fuel Surcharge Copy/Paste Window';
Modules.LblsAndTtls.cstmrRatesDetailsCopyWinTlt     = 'Customer Rates Details Copy/Paste Window';

Modules.LblsAndTtls.cstmrRatesHdrPopupWin = 'Customer Rates Add/Edit Window';

Modules.LblsAndTtls.ocnSupplrMasterContactPersonDtls = 'Contact Person Details';
/************************************* End Window title ***********************************/





/************************************* Panel title ****************************************/
Modules.LblsAndTtls.myPanelName = 'My Panel';
Modules.LblsAndTtls.cstmrRateFuelSurchrg='Fuel Surcharge Details';
Modules.LblsAndTtls.cstmrRateContractDtls='Contract Details';
/************************************** End Panel title ***********************************/




/************************************* Other  and Grid Title ****************************************/

Modules.LblsAndTtls.InvoiceNumberTtl					=	'Invoice Number';
Modules.LblsAndTtls.DocumentReferenceTtl				=	'Document Reference';
Modules.LblsAndTtls.InvoiceAmountTtl					=	'Invoice Amount';

Modules.LblsAndTtls.PartNumberTtl						=	'Part Number';

/*************************************Date Time Field labels ****************************************/



/*************************************Start Field labels ****************************************/

Modules.LblsAndTtls.testComboFieldLabel 				=	'Skills';

Modules.LblsAndTtls.companyCodeTtl						=	'Company';
Modules.LblsAndTtls.purgeFrequencyTtl					=	'Purge Frequency';
Modules.LblsAndTtls.timeTtl								=	'Time';
Modules.LblsAndTtls.telephoneNbrLbl                     =   'Telephone No.';
Modules.LblsAndTtls.telephoneNbrFullLbl                 =   'Telephone Number';   
Modules.LblsAndTtls.ExtSupplierCodeAbbTlt = 'Ext Spplr Cd';
Modules.LblsAndTtls.ExtServiceCodeAbbTlt = 'Ext Srvc Code';
Modules.LblsAndTtls.ExtTransportModeAbb  = 'Ext Trnsprt Md';
Modules.LblsAndTtls.EventLoadRefAbb      = 'Evnt/Load Ref';
Modules.LblsAndTtls.TransferSequenceNOAbb = 'Trnsfr Seq No.';
Modules.LblsAndTtls.ConveyanceNameAbb     = 'Conveync Nm';
Modules.LblsAndTtls.consolidationIDAbbTlt = 'Cnsldtn ID';
Modules.LblsAndTtls.shipmentDateAbbTlt    = 'Shipmnt Date';
Modules.LblsAndTtls.ExtOriginFullLbl = 'External Origin';
Modules.LblsAndTtls.ExtOriginAbbLbl   = 'Ext Orgn';
Modules.LblsAndTtls.ExtOriginStateProvinceAbb = 'External Origin S/P';
Modules.LblsAndTtls.ExtOriginCountryAbbLbl = 'Ext Orgn Country';
Modules.LblsAndTtls.ExtOriginCountryFullLbl = 'External Origin Country';
Modules.LblsAndTtls.ExtOriginalOriginAbb  = 'Ext Orgnl Orgn';
Modules.LblsAndTtls.ExtOriginalOriginStateProvince = 'Ext Orgnl Orgn S/P';
Modules.LblsAndTtls.EvntMsgExtOriginalOriginCountryAbb = 'Ext Orgnl Orgn Cnrty';

Modules.LblsAndTtls.sailingToDate = 'Sailing to Date';
Modules.LblsAndTtls.sailingFrmDate = 'Sailing from Date';
Modules.LblsAndTtls.MessageTypeTlt=     'Msg Type';
Modules.LblsAndTtls.MessageTypeFullTlt=     'Message Type';
Modules.LblsAndTtls.SupplierCodeTlt=    'Supplier Code';
Modules.LblsAndTtls.ExtSupplierCodeTlt=    'Ext Supplier Code';
Modules.LblsAndTtls.CustomerCodeTlt=    'Customer';
Modules.LblsAndTtls.CustomerTlt     =    'Customer Code';
Modules.LblsAndTtls.MsgProcStatusTlt=   'Msg Proc Status';
Modules.LblsAndTtls.MsgProcStatusFullTlt=   'Message Processing Status';
Modules.LblsAndTtls.statusMonitorTlt=  'Status Monitor';
Modules.LblsAndTtls.statusMonitorOceanTlt=  'Status Monitoring And Control Ocean';
Modules.LblsAndTtls.DebtorSubLedgerCdFullTlt='Debtor Sub Ledger Code';
Modules.LblsAndTtls.srvCdTaxTypeFullTlt='Service Code Tax Type Indicator';

Modules.LblsAndTtls.uploadDownloadIndicatorTtl   =     'UL/DL Indicator';
Modules.LblsAndTtls.uploadDownloadIndicatorFullTtl   = 'Upload/Download Indicator';
Modules.LblsAndTtls.messageTransmissionStatusTtl =     'Msg Trns Status';
Modules.LblsAndTtls.messageTransmissionStatusFullTtl = 'Message Transmission Status';
Modules.LblsAndTtls.remittanceTypeTtl            =     'Remit Type';
Modules.LblsAndTtls.remittanceTypeFullTtl         =    'Remittance Type';
Modules.LblsAndTtls.partnerCodeTtl               =     'Partner Code';
Modules.LblsAndTtls.partnerTtl                   =     'Partner';
Modules.LblsAndTtls.partnerNameTtl               =     'Partner Name';
Modules.LblsAndTtls.address1Ttl               =   'Address1';
Modules.LblsAndTtls.address2Ttl               =   'Address2';
Modules.LblsAndTtls.cityTtl               =   'City';
Modules.LblsAndTtls.zipTtl               =   'Zip';
Modules.LblsAndTtls.telephoneTtl               =   'Telephone';
Modules.LblsAndTtls.alertEmailIdTtl               =   'Alert E-mail ID';
Modules.LblsAndTtls.emailAlertTtl               =   'E-mail Alert';
Modules.LblsAndTtls.singleRadiotTtl               =   'Single';
Modules.LblsAndTtls.onDatetTtl               =   'On Date';
Modules.LblsAndTtls.atTimetTtl               =   'At Time';
Modules.LblsAndTtls.timeFormattTtl               =   '24hh:mm:ss';
Modules.LblsAndTtls.multipleRadiotTtl               =   'Multiple';
Modules.LblsAndTtls.everyCombotTtl               =  'Every';
Modules.LblsAndTtls.onCombotTtl               =  'On';
Modules.LblsAndTtls.atTtl               =   'At';
Modules.LblsAndTtls.msgNameTtl               =   'Message Name';
Modules.LblsAndTtls.msgPerFileTtl               =   'Messages Per File';
Modules.LblsAndTtls.groupCodeTtl               =   'Group Code';
Modules.LblsAndTtls.groupNameTtl               =   'Group Name';
Modules.LblsAndTtls.companyCdTtl               =   'Company Code';
Modules.LblsAndTtls.rateTierCdTtl               =   'Rate Tier Code';
Modules.LblsAndTtls.plantNumTtl               =  'Plant Number';
Modules.LblsAndTtls.abnormalMvTypeTtl               =   'Abnormal Move Type';
Modules.LblsAndTtls.stateCntryCodeTtl               =   'State Country Code';
Modules.LblsAndTtls.orderTypeCodeTtl               =   'Order Type Code';
Modules.LblsAndTtls.shipmentTypeTtl               =   'Shipment Type';
Modules.LblsAndTtls.uomCodeTtl               =   'UOM Code';
Modules.LblsAndTtls.marketAreaTtl               =   'Market Area';
Modules.LblsAndTtls.locCodeTtl               =   'Location Code';
Modules.LblsAndTtls.serviceTaxTypeTtl               = 'Service Tax Type';
Modules.LblsAndTtls.makeModelCdTtl               = 'Make Model Code';
Modules.LblsAndTtls.ModelCdTtl               = 'Model Code';
Modules.LblsAndTtls.consolidationTypeTtl               ='Consolidation Type';
Modules.LblsAndTtls.currencyCodeTtl               ='Currency Code';
Modules.LblsAndTtls.rateBasisCdTtl               =   'Rate Basis Code';
Modules.LblsAndTtls.modelGroupTtl               = 'Model Group';
Modules.LblsAndTtls.timeZoneTtl               = 'Time Zone';
Modules.LblsAndTtls.cstmrPoBox           = 'Customer PO-Box';
Modules.LblsAndTtls.factorVal                    =         'Factor Value';
Modules.LblsAndTtls.factorType                   =         'Factor Type';
Modules.LblsAndTtls.factorRate                   =          'Factor Rate';
Modules.LblsAndTtls.cstmrCountryCdLbl     = 'Customer Country Code';
Modules.LblsAndTtls.cstmrCountryCdAbbLbl  = 'Cstmr Country Cd';
Modules.LblsAndTtls.SupplierTtl=    'Supplier';
Modules.LblsAndTtls.SupplierMandatoryTtl=    'Supplier<span style="color: red">*</span>';
Modules.LblsAndTtls.SupplierNameTtl=    'Supplier Name';
Modules.LblsAndTtls.SupplierAddr1Ttl=    'Supplier Addr Line1';
Modules.LblsAndTtls.SupplierAddr2Ttl=    'Supplier Addr Line2';
Modules.LblsAndTtls.SupplierCityTtl=    'Supplier City';
Modules.LblsAndTtls.SupplierCountryTtl=    'Supplier Country';
Modules.LblsAndTtls.SupplierStateTtl=    'Supplier State/Prov';
Modules.LblsAndTtls.SupplierZipCodeTtl=    'Supplier Zip Code';
Modules.LblsAndTtls.ExtSupplierCountryTtl=    'Ext Supplier Country';
Modules.LblsAndTtls.ExtSupplierStateTtl=    'Ext Supp State/Prov';

Modules.LblsAndTtls.apContactPersonNameTtl=    'Ap Contact Prsn Nm';
Modules.LblsAndTtls.apPhoneTtl=    'Ap Phone';
Modules.LblsAndTtls.SupplContactPersonNameTtl=    'Supp Contact Prsn Nm';
Modules.LblsAndTtls.SupplierPhoneTtl=    'Supplier Phone';

Modules.LblsAndTtls.customerTtl='Customer';
Modules.LblsAndTtls.ConsolidationNameAbb = 'Cnsldtn Type';
Modules.LblsAndTtls.ExtConsolidationNameAbb  = 'Ext Cnsldtn Type ';

Modules.LblsAndTtls.msgHdrIdTlt  =   'Msg Hdr ID';
Modules.LblsAndTtls.extCompanyTlt =   'Ext Company';
Modules.LblsAndTtls.msgControlRefTlt='Msg Ctrl No.';
Modules.LblsAndTtls.extCustomerCodeTlt='Ext Customer Code';
Modules.LblsAndTtls.invoiceNumberTlt='Invoice No.';
Modules.LblsAndTtls.invoiceNumberFullTlt='Invoice Number';
Modules.LblsAndTtls.msgConfirmedFlgTlt='Msg Confirmed Flag';
Modules.LblsAndTtls.invoiceAcceptFlgTlt='Invoice Accept Flag';
Modules.LblsAndTtls.msgTransDateTlt='Msg Trans Date';
Modules.LblsAndTtls.companyNameTlt='Company Name';
Modules.LblsAndTtls.paymentDocTlt='Payment Doc';
Modules.LblsAndTtls.paymentDocFullTlt='Payment Document';
Modules.LblsAndTtls.msgcontrolNoFromTlt='Msg Ctrl No. From';
Modules.LblsAndTtls.msgcontrolNoFromFullTlt='Message Control Number from';
Modules.LblsAndTtls.msgcontrolNoToTlt='Msg Ctrl No. To';
Modules.LblsAndTtls.msgcontrolNoToFullTlt='Message Control Number To';
Modules.LblsAndTtls.serviceCodeTlt='Service Code';
Modules.LblsAndTtls.serviceCodeTltMandatory='Service Code<span style="color: red">*</span>';
Modules.LblsAndTtls.customerCodeTlt='Customer';
Modules.LblsAndTtls.supplierCodeTlt='Supplier Code';
Modules.LblsAndTtls.originTlt='Origin';
Modules.LblsAndTtls.destinationTlt='Destination';
Modules.LblsAndTtls.shipRefNoTlt='Shipping Ref';
Modules.LblsAndTtls.shipRefNoFullTlt='Shipping Reference';
Modules.LblsAndTtls.eventLoadRefNoFullTlt='Event/Load Reference';
Modules.LblsAndTtls.shipRefFullTlt='Shipping Ref';
Modules.LblsAndTtls.transportModeTlt='Transport Mode';
Modules.LblsAndTtls.errorDescriptionTlt='Error Description';
Modules.LblsAndTtls.eventLoadRefTlt='Load Ref';
Modules.LblsAndTtls.eventLoadRefFullTlt='Load Reference';
Modules.LblsAndTtls.workOrderTlt='Work Order';
Modules.LblsAndTtls.unitIdTlt='Unit ID';
Modules.LblsAndTtls.unitIdTltMandatory='Unit ID<span style="color: red">*</span>';
Modules.LblsAndTtls.notUploadedTlt='Not Uploaded';
Modules.LblsAndTtls.upDownLoadDateTimeFromTlt='U/D D&T From';
Modules.LblsAndTtls.upDownLoadDateTimeFromFullTlt='Up/Down Loading Date & Time From ';
Modules.LblsAndTtls.upDownLoadDateTimeToTlt='U/D D&T To';
Modules.LblsAndTtls.upDownLoadDateTimeToFullTlt='Up/Down Loading Date & Time To';
Modules.LblsAndTtls.customerNameTlt='Customer Name';
Modules.LblsAndTtls.customerAddressTlt='Customer Address';
Modules.LblsAndTtls.customerTypeTlt = 'Customer Type';
Modules.LblsAndTtls.customerCityTlt='Customer City';
Modules.LblsAndTtls.customerRgnCodelbl = 'Customer Region Code';
Modules.LblsAndTtls.customerRgnCodeAbblbl = 'Cstmr Region Cd';
Modules.LblsAndTtls.customerStateProvinceTlt='Customer State/Prov';
Modules.LblsAndTtls.customerStateProvinceFull='Customer State/Province';
Modules.LblsAndTtls.extCustomerCountryTlt='Ext Customer Country';
Modules.LblsAndTtls.paymentDocumentNoTlt='Payment Doc No.';
Modules.LblsAndTtls.paymentDocumentNoFull='Payment Document Number';
Modules.LblsAndTtls.paymentDocTypeTlt='Payment Doc Type';
Modules.LblsAndTtls.paymentDocTypeFull='Payment Document Type';
Modules.LblsAndTtls.paymentDateTlt='Payment Date';
Modules.LblsAndTtls.currencyTlt='Currency';
Modules.LblsAndTtls.extCurrencyTlt='Ext Currency';
Modules.LblsAndTtls.extInvcCurrencyTlt='Ext Invc Currency';
Modules.LblsAndTtls.extInvcCurrencyFull='External Invoice Currency';
Modules.LblsAndTtls.invoiceAmountTlt='Invoice Amount';
Modules.LblsAndTtls.totalAmountTlt='Total Amount';
Modules.LblsAndTtls.remittanceTypeTlt='Remittance Type';
Modules.LblsAndTtls.itemNbrTlt='Item No.';
Modules.LblsAndTtls.itemNbrFullTlt='Item Number';
Modules.LblsAndTtls.techErrorCodeFullTlt='Technical Error Code';
Modules.LblsAndTtls.techErrorDescFullTlt='Technical Error Description';
Modules.LblsAndTtls.serviceGroupTlt='Service Group';
Modules.LblsAndTtls.submitAndReconcileTlt='Submit And Reconcile';

Modules.LblsAndTtls.pinvcTlt='PINVC';
Modules.LblsAndTtls.zerortTlt='ZERORT';
Modules.LblsAndTtls.recnclTlt='RECNCL';
Modules.LblsAndTtls.apprvTlt='APPRV';
Modules.LblsAndTtls.nochrgTlt='NOCHRG';

Modules.LblsAndTtls.msgHeaderIdTlt= 'Msg Hdr ID';
Modules.LblsAndTtls.fileControlNoTlt= 'File Ctrl No.';
Modules.LblsAndTtls.msgCreationDateTlt='Msg Creation Date & Time';
Modules.LblsAndTtls.transferSequenceNoTlt='Transfer Seq No.';
Modules.LblsAndTtls.noOfRecsTlt='No. of Recs';
Modules.LblsAndTtls.noOfErrRecsTlt='No. of Err Recs';
Modules.LblsAndTtls.noOfRecsUDTlt='No. of Recs U/D';

Modules.LblsAndTtls.msgStsIndi = 'Msg Status Ind';
Modules.LblsAndTtls.msgStsIndiFull = 'Message Status Indicator';

Modules.LblsAndTtls.accPayMsgHdrId='Msg Hdr ID';
Modules.LblsAndTtls.accPayMsgType= 'Msg Type';
Modules.LblsAndTtls.accPayPartnerCode= 'Partner Code';
Modules.LblsAndTtls.accPayCompany =  'Company';
Modules.LblsAndTtls.accPayExtCompany= 'Ext Company';
Modules.LblsAndTtls.accPayInvoiceNumber= 'Invoice Number';
Modules.LblsAndTtls.accPaySupplierCode= 'Supplier Code';
Modules.LblsAndTtls.accPayExtSupplierCode= 'Ext Supplier Code';
Modules.LblsAndTtls.accPaySpplrPymntInvcNo = 'Spplr Pymnt Invc No.';
Modules.LblsAndTtls.accPayDebtorPartyCode = 'Debtor Party Code';
Modules.LblsAndTtls.accPayDebtorPartyName = 'Debtor Party Name';
Modules.LblsAndTtls.accPayContactPersonName ='Contact Person Name' ;
Modules.LblsAndTtls.accPayInvoiceDate= 'Invoice Date';
Modules.LblsAndTtls.accPayInvoiceDuedate = 'Invoice Due Date';
Modules.LblsAndTtls.accPayCurrency = 'Currency';
Modules.LblsAndTtls.accPayExtCurrency = ' Ext Currency';
Modules.LblsAndTtls.accPayTotalAmount = 'Total Amount';
Modules.LblsAndTtls.accPayDocumentType= 'Document Type';
Modules.LblsAndTtls.accPayActualAccural=  'Actual/Accural';

Modules.LblsAndTtls.contactPrsnNmLbl = 'Contact Prsn Nm';


Modules.LblsAndTtls.contractIdTtl='Contract ID';
Modules.LblsAndTtls.validFromDateTlt='Valid from Date';
Modules.LblsAndTtls.validToDateTlt = 'Valid to Date';


Modules.LblsAndTtls.accRecCustomerCd='Customer Code';
Modules.LblsAndTtls.accRecExtCustomerCd ='Ext Customer Code';
Modules.LblsAndTtls.accRecReferInvcNo='Reference Invoice No.';
Modules.LblsAndTtls.accRecCreditDebit='Credit/Debit';
Modules.LblsAndTtls.accRecDebtorSubLedgerCd='Dbtr Sub Ledger Cd';


Modules.LblsAndTtls.truckInvoiceExtSupplrLb='Ext Supplier Code';
Modules.LblsAndTtls.truckInvoiceProductLb = 'Product ID';
Modules.LblsAndTtls.truckInvoiceProductDateLb='Product Date';
Modules.LblsAndTtls.truckInvoiceCreditNoteIndLb='Invc Credit Note Ind';

Modules.LblsAndTtls.railInvcEventLoadRef='Event/Load Ref#';
Modules.LblsAndTtls.railInvoiceExtConveyanceType='Ext Conveyance Type';
Modules.LblsAndTtls.railInvoiceTaxRegNo='Tax Reg No.';
Modules.LblsAndTtls.railInvoiceRefContractNo='Ref Contract No.';
Modules.LblsAndTtls.railInvoiceWayBillNo='Way Bill No.';
Modules.LblsAndTtls.railInvoiceExtCurrency='Ext Currency';
Modules.LblsAndTtls.railInvcExtOrigin='Ext Origin';
Modules.LblsAndTtls.railInvcOriginCity='Origin City';
Modules.LblsAndTtls.railInvcConveyanceId='Conveyance ID';
Modules.LblsAndTtls.railInvcExtOriginStateProvince='Ext Origin State/Prov';
Modules.LblsAndTtls.railInvcExtOriginCountry='Ext Origin Country';
Modules.LblsAndTtls.railInvcExtCompany='Ext Company';
Modules.LblsAndTtls.railInvcDestinationCity='Destination City';
Modules.LblsAndTtls.railInvcExtDestination='Ext Dest City';
Modules.LblsAndTtls.railInvcExtDestinations='Ext Dest';
Modules.LblsAndTtls.railInvcExtDestinationStateProvince = 'Ext Dest State/Prov';
Modules.LblsAndTtls.railInvcConsignee='Consignee';
Modules.LblsAndTtls.railInvcConsigner='Consigner';
Modules.LblsAndTtls.railInvcCompanyNm='Company Name';
Modules.LblsAndTtls.railInvcConsigneeNm='Consignee Name';
Modules.LblsAndTtls.railInvcConsignerNm='Consigner Name';
Modules.LblsAndTtls.railInvcCompanyAddress='Company Address';
Modules.LblsAndTtls.railInvcCompanyAddress2='Company Address2';
Modules.LblsAndTtls.railInvcConsignerAddress='Consigner Address';
Modules.LblsAndTtls.railInvcConsignerAddress2='Consigner Address2';
Modules.LblsAndTtls.railInvcConsigneeAddress='Consignee Address';
Modules.LblsAndTtls.railInvcConsigneeAddress2='Consignee Address2';
Modules.LblsAndTtls.railInvcCompanyCity='Company City';
Modules.LblsAndTtls.railInvcConsignerCity='Consigner City';
Modules.LblsAndTtls.railInvcConsigneeCity='Consignee City';
Modules.LblsAndTtls.railInvcExtCompanyStateProvince='Ext Cmpny State/Prov';
Modules.LblsAndTtls.railInvcConsignerStateProvince='Consigner State/Prov';
Modules.LblsAndTtls.railInvcConsigneeStateProvinceId='Consignee State/Prov';
Modules.LblsAndTtls.railInvcConsignerCountry='Consigner Country';
Modules.LblsAndTtls.railInvcConsigneeCountry='Consignee Country';
Modules.LblsAndTtls.railInvcExtCompanyCountry='Ext Cmpny Country';
Modules.LblsAndTtls.railInvcExtDestinationCountry='Ext Dest Country';

Modules.LblsAndTtls.srvcChrgInvoiceExtCmpny='Ext Company Code';

Modules.LblsAndTtls.inSupplierRemitAdvcExtCmpny='Ext Company';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrNmLb='Supplier Name';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrAddLb='Supplier Address';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrCityLb='Supplier City';
Modules.LblsAndTtls.inSupplierRemitAdvcExtSupplrStateProvLb='Ext Supplr State/Prov';
Modules.LblsAndTtls.inSupplierRemitAdvcExtSupplrCountry='Ext Supplier Country';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDocNo='Payment Doc No.';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDocType='Payment Doc Type';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDate='Payment Date';
Modules.LblsAndTtls.inSupplierRemitAdvcExtCurr='Ext Currency';
Modules.LblsAndTtls.inSupplierRemitAdvcTotalAmt='Total Amount';

Modules.LblsAndTtls.custmrInvcAddrLine1='Address Line1';
Modules.LblsAndTtls.custmrInvcAddrLine2='Address Line2';
Modules.LblsAndTtls.custmrInvcCity='City';
Modules.LblsAndTtls.custmrInvcZipPostalCd='Zip/Postal Code';
Modules.LblsAndTtls.custmrInvcStateProv='State/Province';
Modules.LblsAndTtls.custmrInvcExtStateProv='Ext State/Province';
Modules.LblsAndTtls.custmrInvcCountry='Country',
Modules.LblsAndTtls.custmrInvcExtCountry='External Country',
Modules.LblsAndTtls.custmrInvcExtCustmrCd='Ext Customer Code';
Modules.LblsAndTtls.custmrInvcExtCustmrCdFull='External Customer Code';
Modules.LblsAndTtls.refInvoiceNumberTlt='Ref Invoice Number';
Modules.LblsAndTtls.custmrInvcExtDocType='Ext Document Type';
Modules.LblsAndTtls.custmrInvcAmt='Invoice Amount';
Modules.LblsAndTtls.custmrInvcContactPerson='Contact Person';
Modules.LblsAndTtls.custmrPhone='Phone';
Modules.LblsAndTtls.custmrInvcProformalInd='Proforma/Estimate Ind';

Modules.LblsAndTtls.covusXmlInterfaceMsgHdrIdTool='Message Header ID';
Modules.LblsAndTtls.covusXmlInterfaceMsgTypeTool='Message Type';
Modules.LblsAndTtls.covusXmlInterfaceExtCmpnyTool='External Company';
Modules.LblsAndTtls.covusXmlInterfaceCreditNoteIndTool='Invoice Credit Note Indicator';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrTool='External Customer';
Modules.LblsAndTtls.covusXmlInterfaceRefInvoiceNumberTool='Reference Invoice Number';
Modules.LblsAndTtls.covusXmlInterfaceTotalInvcAmtTool='Total Invoice Amount';
Modules.LblsAndTtls.covusXmlInterfaceTotalSrvcAmtTool='Total Service Amount';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddTool='Debtor Party Address1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr2Tool='Debtor Party Address2';
Modules.LblsAndTtls.covusXmlInterfaceTaxRefNoTool='Tax Reference Number';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorStateCdTool='External Debtor State Code';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs1Tool='AR Address1';
Modules.LblsAndTtls.covusXmlInterfacePrfEstmTool='Proforma/Estimation Indicator';
Modules.LblsAndTtls.covusXmlInterfacePrfStsTool='Proforma Status';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs2Tool='AR Address2';
Modules.LblsAndTtls.covusXmlInterfaceExtARStateTool='External AR State';
Modules.LblsAndTtls.covusXmlInterfaceExtARCountryTool='External AR Country';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorCountryTool='External Debtor Country';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrStateTool='External Customer State';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrCountryTool='External Customer Country';
Modules.LblsAndTtls.covusXmlInterfaceCustmrAddr1Tool='Customer Address1';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr2Tool='Customer Address2';
Modules.LblsAndTtls.covusXmlInterfaceDebtorContactPrsnNmTool='Debtor Contact Person Name';
Modules.LblsAndTtls.covusXmlInterfaceDebtorTaxRefNoTool='Debtor Tax Reference Number';
Modules.LblsAndTtls.covusXmlInterfaceArContactPrsnNMCdTool='AR Contact Person Name';
Modules.LblsAndTtls.covusXmlInterfaceExtInvcCurrTool='External Invoice Currency';
Modules.LblsAndTtls.arCityNameLbl = 'AR City Name';
Modules.LblsAndTtls.customerAddress3Lbl = 'Customer Address3';
Modules.LblsAndTtls.TenderDateEstFlgFull = 'Tender Date Estd Flag';
Modules.LblsAndTtls.ShipmentDateEstimatedFlgFull = 'Shipment Date Estd Flag';
Modules.LblsAndTtls.DeliveryDateEstimatedFlgFull = 'Delivery Date Estd Flag';
Modules.LblsAndTtls.arStateCdLbl ='AR State Code';
Modules.LblsAndTtls.arCountryCdLbl ='AR Country Code';
Modules.LblsAndTtls.covusXmlInterfaceExtSupplrTool='External Supplier Code';
Modules.LblsAndTtls.ExtCurrToolTip='External Currency';
Modules.LblsAndTtls.apCmpAddrLine1ToolTip='Ap Company Address Line1';
Modules.LblsAndTtls.apCmpAddrLine2ToolTip='Ap Company Address Line2';
Modules.LblsAndTtls.apCmpCityNmToolTip='Ap Company City Name';
Modules.LblsAndTtls.apCmpStProvToolTip='Ap Company State/Province';
Modules.LblsAndTtls.apCmpCountryToolTip='Ap Company Country';
Modules.LblsAndTtls.apCmpZipPostalToolTip='Ap Company Zip Postal Code';
Modules.LblsAndTtls.apCmpStProvToolTip='External Ap Company State/Province';
Modules.LblsAndTtls.apCmpCountryProvToolTip='External Ap Company Country';
Modules.LblsAndTtls.ExtSupplrTool='External Supplier Code';
Modules.LblsAndTtls.SupplrAddrLine1Tool='Supplier Address Line1';
Modules.LblsAndTtls.SupplrAddrLine2Tool='Supplier Address Line2';
Modules.LblsAndTtls.SupplrStateTool='Supplier State/Province';
Modules.LblsAndTtls.SupplrZipCd='Supplier Zip/Postal Code';
Modules.LblsAndTtls.ExtSupplrCountryToolTip='External Supplier Country ';
Modules.LblsAndTtls.ExtSupplrStateToolTip='External Supplier State/Province';
Modules.LblsAndTtls.ApContactPrsnNmToolTip='Ap Contact Person Name';
Modules.LblsAndTtls.SupplrContactPrsnNmToolTip='Supplier Contact Person Name';
Modules.LblsAndTtls.PaymentDocNoToolTip='Payment Document Number';
Modules.LblsAndTtls.PaymentDocTypeToolTip='Payment Document Type';
Modules.LblsAndTtls.ExtInvcCurrTool='External Invoice Currency';
Modules.LblsAndTtls.ExtCustmrTool='External Customer';
Modules.LblsAndTtls.SpplrPymntInvTool=' Payment Invoice Number';
Modules.LblsAndTtls.SrvcCdTaxToolTip='Service Code/Tax Type Indicator';
Modules.LblsAndTtls.arContactPrsn='AR Contact Person';	
Modules.LblsAndTtls.arTelNbr='AR Telephone Nbr';
Modules.LblsAndTtls.arFaxNbr = 'AR Fax Number';
Modules.LblsAndTtls.arEmailId='AR Email ID';
Modules.LblsAndTtls.CstmrInvcTaxDetailsTlt='Customer Invoice Tax Details';
Modules.LblsAndTtls.CstmrInvcDetailsTlt='Customer Invoice Details';
Modules.LblsAndTtls.invcCopyCountAbbLbl = 'Invc Copy Count';
Modules.LblsAndTtls.invcCopyCountLbl   = 'Invoice Copy Count';
Modules.LblsAndTtls.OutSupplrRemitDetailsTlt='Out Supplier Remittance Advice Details';
Modules.LblsAndTtls.OutSupplrRemitPayDetailsTlt='Out Supplier Remittance Advice Unit Details';

Modules.LblsAndTtls.lumpsumUnitIndicatorFullLbl = 'Lumpsum Unit Indicator';

Modules.LblsAndTtls.OriginCountryTlt='Origin Country',
Modules.LblsAndTtls.EvntLoadRefTool='Event/Load Reference#';
Modules.LblsAndTtls.ExtConveyanceTypeTool='External Conveyance Type';
Modules.LblsAndTtls.TaxRegNoTool='Tax Registration Number';
Modules.LblsAndTtls.RefContractNoTool='Reference Contract Number';
Modules.LblsAndTtls.ExtOriginToolTip='External Origin';
Modules.LblsAndTtls.ExtOriginStateProvToolTip='External Origin State/Province';
Modules.LblsAndTtls.ExtOriginCountryToolTip='External Origin Country';
Modules.LblsAndTtls.ConsignerStateProvinceToolTip='Consigner State/Province';
Modules.LblsAndTtls.ConsigneeStateProvinceToolTip='Consignee State/Province';
Modules.LblsAndTtls.ExtCmpnyCountryToolTip='External Company Country';
Modules.LblsAndTtls.ExtDestCountryToolTip='External Destination Country';
Modules.LblsAndTtls.extDestCityFullTlt='External Destination City';
Modules.LblsAndTtls.extDestCitysFullTlt='External Destination';
Modules.LblsAndTtls.showErrorTlt='Error Correction';
Modules.LblsAndTtls.attributeTtl='Attribute';
Modules.LblsAndTtls.valueTlt='Value';
Modules.LblsAndTtls.refAttributeTlt='Ref Attribute';
Modules.LblsAndTtls.refAttributeFullTlt='Reference Attribute';
Modules.LblsAndTtls.refAttributeValueTlt='Ref Attribute Value';
Modules.LblsAndTtls.refAttributeValueFullTlt='Reference Attribute Value';
Modules.LblsAndTtls.errorDescTlt='Error Description';
Modules.LblsAndTtls.destinationCountry='Destination Country';

Modules.LblsAndTtls.ProformalIndToolTip='Proforma/Estimate Indicator';
Modules.LblsAndTtls.ExtDocTypeTool='External Document Type';
Modules.LblsAndTtls.ExtCustmrCdToolTip='External Customer';
Modules.LblsAndTtls.covusXmlInterfaceExtStateProvTool='External State/Province';
Modules.LblsAndTtls.ExtConsolidationName = 'Ext Consolidation Type';
Modules.LblsAndTtls.ExtConsolidationTypeFullLbl = 'External Consolidation Type';

Modules.LblsAndTtls.invcPrintTemplLbl ='Invc Print Templ';
Modules.LblsAndTtls.covusXmlInterfaceInvcPrntTemp='Invoice Print Template';
Modules.LblsAndTtls.covusXmlProfitLossLbs = 'Profit/Loss';
Modules.LblsAndTtls.covusXmlProfitLossFullLbs='Profit/Loss Center';
Modules.LblsAndTtls.covusXmlInterfacePrfSts='Prf Sts';
Modules.LblsAndTtls.covusXmlInterfaceTotalInvcAmt='Total Invoice Amt';
Modules.LblsAndTtls.covusXmlInterfaceFinCustmr='Fin Customer';
Modules.LblsAndTtls.covusXmlInterfaceTotalSrvcAmt='Total Service Amt';
Modules.LblsAndTtls.covusXmlPrfEstm='Prf Estm Ind';
Modules.LblsAndTtls.covusXmlInterfaceTotalTaxAmt='Total Tax Amount';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr='Debtor Party Addr1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr2='Debtor Party Addr2';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCity='Debtor City Name';
Modules.LblsAndTtls.covusXmlInterfaceTaxRef='Tax Ref No.';
Modules.LblsAndTtls.covusXmlInterfaceRemarks='Remarks';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCd='Debtor Party';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorStateCdId='Ext Debtor State Code';
Modules.LblsAndTtls.debtorState='Debtor State';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCountry='Debtor Country';
Modules.LblsAndTtls.ARAddrs1='AR Addrs1';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrCd='Ext Customer';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs2='AR Addr2';
Modules.LblsAndTtls.covusXmlInterfaceARCity='AR City';
Modules.LblsAndTtls.covusXmlInterfaceARState='AR State';
Modules.LblsAndTtls.covusXmlInterfaceARCountry='AR Country';
Modules.LblsAndTtls.covusXmlInterfaceARPostal='AR Postal';
Modules.LblsAndTtls.covusXmlInterfaceARFax='AR Fax';
Modules.LblsAndTtls.covusXmlInterfaceARTel='AR Tel';
Modules.LblsAndTtls.covusXmlInterfaceAREmail='AR E-mail';
Modules.LblsAndTtls.covusXmlInterfaceInvcCurr='Invoice Currency';

Modules.LblsAndTtls.EvntMsgExtOriginalOriginCountry = 'Ext Orgnl Orgn Cntry';

Modules.LblsAndTtls.invcCreditNoteIndLbl = 'Invc Credit Note Ind';

Modules.LblsAndTtls.text1Lbl = 'Text 1';
Modules.LblsAndTtls.text2Lbl = 'Text 2';
Modules.LblsAndTtls.text3Lbl ='Text 3';
Modules.LblsAndTtls.text4Lbl  =  'Text 4';
Modules.LblsAndTtls.text5Lbl  = 'Text 5';
Modules.LblsAndTtls.text6Lbl  = 'Text 6';
Modules.LblsAndTtls.text7Lbl  = 'Text 7';
Modules.LblsAndTtls.text8Lbl  = 'Text 8';
Modules.LblsAndTtls.text9Lbl  = 'Text 9';
Modules.LblsAndTtls.text10Lbl  = 'Text 10';

Modules.LblsAndTtls.backupCopyCount = 'Backup Copy Count ';

Modules.LblsAndTtls.covusXmlInterfaceBillType='Bill Type';
Modules.LblsAndTtls.covusXmlInterfaceInvcCopies='Invoice Copies';
Modules.LblsAndTtls.covusXmlInterfaceBackUpCopies='Backup Copies';
Modules.LblsAndTtls.covusXmlInterfaceInvcPrinter='Invoice Printer';
Modules.LblsAndTtls.covusXmlInterfaceBackUpPrinter='Backup Printer';
Modules.LblsAndTtls.covusXmlInterfaceEmailAddrs='E-mail Address';
Modules.LblsAndTtls.covusXmlInterfaceCCEmailAddr='CC E-mail Address';
Modules.LblsAndTtls.covusXmlInterfaceInvcReqFlg='Invoice Required Flag';
Modules.LblsAndTtls.covusXmlInterfaceBackUpReqFlg='Backup Required Flag';
Modules.LblsAndTtls.covusXmlInterfaceOrgFlg='Original Flag';
Modules.LblsAndTtls.invcPrinterCnfgpathlbl ='Invoice Printer CNFG Path';
Modules.LblsAndTtls.invcPrinterCnfgpathAbblbl ='Inv Prtr CNFG Pth';
Modules.LblsAndTtls.backUpPrinterCnfgpathlbl ='Backup Printer CNFG Path';
Modules.LblsAndTtls.backUpPrinterCnfgpathAbblbl ='Bkup Prntr CNFG Pth';
Modules.LblsAndTtls.totalInvcAmountManifestCurrLbl ='Total Invoice Amount Manifest Currency';
Modules.LblsAndTtls.totalInvcAmountManifestCurrAbbLbl = 'Inv Amt Manfst Curr';
Modules.LblsAndTtls.covusXmlInterfaceDebtorRemarks1='Debtor Remark1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorRemarks2='Debtor Remark2';
Modules.LblsAndTtls.covusXmlInterfaceDebtorSubLedger='Debtor SubLedger';
Modules.LblsAndTtls.covusXmlInterfaceCustomerSubLedger='Customer SubLedger';
Modules.LblsAndTtls.covusXmlInterfaceExtARState='Ext AR State';
Modules.LblsAndTtls.covusXmlInterfaceExtARCountry='Ext AR Country';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorCountryCd='Ext Debtor Country Code';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrState='Ext Customer State';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr1='Customer Addr1';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr2='Customer Addr2';
Modules.LblsAndTtls.covusXmlInterfaceCustmrCity='Customer City Name';
Modules.LblsAndTtls.covusXmlInterfaceCustmrState='Customer City State';
Modules.LblsAndTtls.covusXmlInterfaceCustmrCountry='Customer Country';
Modules.LblsAndTtls.covusXmlInterfaceCustomerPostalCd='Customer Postal Code';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPostalCd='Debtor Postal Code';
Modules.LblsAndTtls.covusXmlInterfaceDebtorContactPrsnNm='Dbtr Contact Prsn Nm';
Modules.LblsAndTtls.covusXmlInterfaceDebtorTaxRefNo='Debtor Tax Ref No.';
Modules.LblsAndTtls.covusXmlInterfaceBackUpPrinterPath='BackUp Printer Path';
Modules.LblsAndTtls.covusXmlInterfaceInvcPrinterPath='Invoice Printer Path';
Modules.LblsAndTtls.covusXmlInterfaceARContactPrsnNm='AR Contact Prsn Nm';
Modules.LblsAndTtls.covusXmlInterfaceExtInvcCurr='Ext Invoice Currency';


Modules.LblsAndTtls.POLStateFullTxt = 'Port Of Load State';
Modules.LblsAndTtls.extDestFullTlt='External Destination';
Modules.LblsAndTtls.extDestStateProvFullTlt='External Destination State/Province';
Modules.LblsAndTtls.destinationStateProvinceFullTlt='Destination State/Province';
Modules.LblsAndTtls.destinationStateProvinceTlt='Destination S/P';
Modules.LblsAndTtls.srvcTypeLbl='Service Type';
Modules.LblsAndTtls.srvcTypeLblTip='Service Type';
Modules.LblsAndTtls.srvcCdLbl='Service Code';
Modules.LblsAndTtls.srvcCdLblTip='Service Code';
Modules.LblsAndTtls.srvcDescLbl='Service Desc';
Modules.LblsAndTtls.srvcDescLblTip='Service Description1';
Modules.LblsAndTtls.srvcDesc2Lbl='Service Desc2';
Modules.LblsAndTtls.srvcDesc2LblTip='Service Description2';
Modules.LblsAndTtls.consolidationCatLbl='Consolidation Ctgry';
Modules.LblsAndTtls.consolidationCatLblTip='Consolidation Category';
Modules.LblsAndTtls.totalInvcAmtLocalCurrency = 'Total Invoice Amount Local Currency';
Modules.LblsAndTtls.totalInvcAmtLocalCurrencyAbbLbl = 'Invc Amt Local Curr';
Modules.LblsAndTtls.tariffTabParentPanel='Tariff Master';
Modules.LblsAndTtls.tariffCdLbl='Tariff Code';
Modules.LblsAndTtls.tariffDescLbl='Tariff Desc';
Modules.LblsAndTtls.tariffDescLblTip='Tariff Description';
Modules.LblsAndTtls.EffectiveDtLbl='Effective Date';
Modules.LblsAndTtls.EffectiveDtLblTip='Effective Date';
Modules.LblsAndTtls.tariffUnitRateLbl='Tariff Unit Rate';
Modules.LblsAndTtls.currencyLbl='Currency';
Modules.LblsAndTtls.LUInd     = 'L/U Ind ';
Modules.LblsAndTtls.tariffCurrCd  =  'Tariff Currency Code';
Modules.LblsAndTtls.tariffCurrCodeAbb='Tariff Curr Cd';
Modules.LblsAndTtls.editPurgeDaysTlt='Purging Days';
Modules.LblsAndTtls.editPurgeConfigurationGridTlt='Purge Configuration Grid Record';
Modules.LblsAndTtls.popupEventLogGridTlt='Event Log Grid Record';
Modules.LblsAndTtls.editTransportationEventGridTlt='Transportation Event Entry Grid Record';
Modules.LblsAndTtls.editTechnicalEventGridTlt='Technical Event Entry Grid Record';
Modules.LblsAndTtls.srvcMasterFileNmLbl='File Name';
Modules.LblsAndTtls.srvcMasterTemplateLbl='Template';
Modules.LblsAndTtls.compositeTlt             = 'Composite';
Modules.LblsAndTtls.minLoadTlt               =  'Min Load';
Modules.LblsAndTtls.agreedMileageTlt         =   'Agreed Mileage';
Modules.LblsAndTtls.auditExceptionTimeIntvlLbl='Time Interval';

Modules.LblsAndTtls.popupSupplrEvntStsSummGridTlt='Supplier Event Status Summary Details';

Modules.LblsAndTtls.StateLbl   = 'State';
Modules.LblsAndTtls.bankSeqNbrLbl ='Bank Sequence Number';
Modules.LblsAndTtls.bankAddressLbl ='Bank Address';
Modules.LblsAndTtls.statusMonitorSaveSearchNameTlt='Keyword<span style="color: red">*</span>' ;
Modules.LblsAndTtls.statusMonitorSaveSearchDescTlt='Description';
Modules.LblsAndTtls.statusMonitorSaveSearchDefaultFlagTlt='Default Criteria';
Modules.LblsAndTtls.popupStatusMonitorGridTlt='Status Monitor Grid Record';

Modules.LblsAndTtls.eventlogSaveSearchScreenTlt='Eventlog Save Search Screen';
Modules.LblsAndTtls.DocumentRefTtls='Document Reference';
Modules.LblsAndTtls.techErrorCodeTlt='Tech Error Code';
Modules.LblsAndTtls.techErrorDescTlt='Tech Error Description';
Modules.LblsAndTtls.refErrorCodeTlt='Reference Error Code';
Modules.LblsAndTtls.refErrorDescTlt='Reference Error Description';
Modules.LblsAndTtls.msgHderIdTlt='Message Header ID';
Modules.LblsAndTtls.filectrlNoTlt='File Control Number';
Modules.LblsAndTtls.msgcontrolNoFullTlt='Message Control Number';
Modules.LblsAndTtls.msgCreationDTTlt='Message Creation Date & Time';
Modules.LblsAndTtls.transferSeqNoFullTlt='Transfer Sequence Number';
Modules.LblsAndTtls.noOfRecsFullTlt='Number of Records';
Modules.LblsAndTtls.noOfErrorRecsFullTlt='Number of Error Records';
Modules.LblsAndTtls.noOfRecosUDFullTlt='Number of Records Uploaded & Downloaded';
Modules.LblsAndTtls.extCompanyFullTlt='External Company';
Modules.LblsAndTtls.savedOnDateTlt='Saved on Date';
Modules.LblsAndTtls.criteriaSavedTlt='Criteria Saved';
Modules.LblsAndTtls.msgControlRefFullTlt='Message Control Reference Number';
Modules.LblsAndTtls.saveSearchTlt =	'Save Search Criteria';
Modules.LblsAndTtls.errorCorrectionSearchReplaceTlt='Search & Replace';
Modules.LblsAndTtls.errorCorrectionAttributeNameTlt='Attribute Name';
Modules.LblsAndTtls.errorCorrectionFindTlt='Find';
Modules.LblsAndTtls.errorCorrectionReplaceTlt='Replace';
Modules.LblsAndTtls.errorCorrectionReplaceWithTlt='Replace With';
Modules.LblsAndTtls.errorCorrectionReplaceAllTlt='Replace All';
Modules.LblsAndTtls.errorCorrectionSearchReplaceTlt='Search & Replace';
Modules.LblsAndTtls.errorCorrectionSaveUpdateTlt='Save & Update Status';
Modules.LblsAndTtls.seqNo='Sequence Number';
Modules.LblsAndTtls.destStateProvFullTtl = 'Destination State Province';
Modules.LblsAndTtls.srvcLvlValidDt= 'Service Level Valid Dates';

Modules.LblsAndTtls.NoOfUnits = 'No. of Units';
Modules.LblsAndTtls.msgCntrlNbr = 'Msg Ctrl Nbr';

Modules.LblsAndTtls.apCmpAddrLine1Tlt='Ap Cmp Addr Line1';
Modules.LblsAndTtls.apCmpAddrLine2Tlt='Ap Cmp Addr Line2';
Modules.LblsAndTtls.apCmpCityNameTlt='Ap Cmp City Name';
Modules.LblsAndTtls.apCmpStatProvTlt='Ap Cmp State/Prov';
Modules.LblsAndTtls.apCmpCountryTlt='Ap Cmp Country';
Modules.LblsAndTtls.apCmpZipPostalCodeTlt='Ap Cmp Zip Code';
Modules.LblsAndTtls.extApCmpStatProvTlt='Ext Ap Cmp State/Prov';
Modules.LblsAndTtls.extApCmpCountryTlt='Ext Ap Cmp Country';

Modules.LblsAndTtls.externalCmpnyStProvFullLbl='External Company State/Province';

Modules.LblsAndTtls.displayPartner='Partner';
Modules.LblsAndTtls.displayMessageType='Message Type';
Modules.LblsAndTtls.displayNumberOfErrors='Number Of Error Messages';
Modules.LblsAndTtls.partnerRecordTtl='Partner View';

Modules.LblsAndTtls.makeCd='Make Code';
Modules.LblsAndTtls.loadReferenceTlt='Event/Load Ref';
Modules.LblsAndTtls.ConveyanceIdTlt='Conveyance ID';
Modules.LblsAndTtls.ConveyanceTypeTlt='Conveyance Type';
Modules.LblsAndTtls.cargoTypeTlt='Cargo Type';
Modules.LblsAndTtls.storageTypeTlt='Storage Type';
Modules.LblsAndTtls.modelLineTlt='Model Line';
Modules.LblsAndTtls.billOFLadingTlt='Bill Of Lading';

Modules.LblsAndTtls.conveyanceNameTlt='Conveyance Name';
Modules.LblsAndTtls.tenderDateTlt='Tender Date';
Modules.LblsAndTtls.shipmntDateTlt='Shipment Date';
Modules.LblsAndTtls.consolidationIDTlt='Consolidation ID';
Modules.LblsAndTtls.consolidationTypeTlt='Consolidation Type';
Modules.LblsAndTtls.transferSeqNbrTlt='Transfer Seq No.';
Modules.LblsAndTtls.requestDateTlt='Request Date';
Modules.LblsAndTtls.locationTlt='Location';
Modules.LblsAndTtls.shippingRefTlt='Shipping Ref';
Modules.LblsAndTtls.shippingRefFullTlt ='Shipping Reference';
Modules.LblsAndTtls.nbrOfVinTlt = 'Number of VIN';

Modules.LblsAndTtls.srvcCdDescAbbLbl = 'Srvc Code Desc';
Modules.LblsAndTtls.voyageNbr = 'Voyage Number';

Modules.LblsAndTtls.customerDebPrtyCustomer='Customer';
Modules.LblsAndTtls.customerDebPrtyCustomerName='Customer Name';
Modules.LblsAndTtls.customerDebPrtyDebtorParty='Debtor Party';
Modules.LblsAndTtls.customerDebPrtyDebtorPartyName='Debtor Party Name';
Modules.LblsAndTtls.customerDebPrtyTaxRefNo ='Tax Ref No.';
Modules.LblsAndTtls.customerDebPrtyAddress1 ='Address1';
Modules.LblsAndTtls.customerDebPrtyAddress2 ='Address2';
Modules.LblsAndTtls.customerDebPrtyCity ='City';
Modules.LblsAndTtls.customerDebPrtyStateProvince ='State/Province';
Modules.LblsAndTtls.customerDebPrtyCountry ='Country';
Modules.LblsAndTtls.customerDebPrtyZipPostalCode ='ZIP/Postal Code';
Modules.LblsAndTtls.customerDebPrtyTelephoneNo = 'Telephone No.';
Modules.LblsAndTtls.customerDebPrtyFaxNumber ='Fax Number';
Modules.LblsAndTtls.customerDebPrtyMobileNumber ='Mobile Number';
Modules.LblsAndTtls.customerDebPrtyEmailAddress ='E-mail Address';
Modules.LblsAndTtls.customerDebPrtyContactPersonName ='Contact Person Name';
Modules.LblsAndTtls.customerDebPrtySubLedgerCode ='Sub Ledger Code';
Modules.LblsAndTtls.customerDebPrtyRemark1 ='Remark1';
Modules.LblsAndTtls.customerDebPrtyRemark2 ='Remark2';

Modules.LblsAndTtls.countTlt               ='Count';
Modules.LblsAndTtls.NbrofUnits             = 'Nbr of Units';
Modules.LblsAndTtls.NbrofUnitsFullLbl      = 'Number of Units';
Modules.LblsAndTtls.customerDebPrtySendCustAccToCodaTtl= "Send Customer Accrual To CODA";
Modules.LblsAndTtls.customerDebPrtyWaitForAPApproveFlgTtl= "Download A/R To A/P";
Modules.LblsAndTtls.customerDebPrtyAutoApproveApplnAdviceFlgTtl= "Auto Approve in Application Advice";
Modules.LblsAndTtls.customerDebPrtySendCstmrInvcMsgFlgTtl= "Send Customer Invoice Message";

/************************************* End Field labels ****************************************/





Modules.LblsAndTtls.viaNoLbl						=		'VIA';
Modules.LblsAndTtls.oldViaLbl						=		'Old VIA';
Modules.LblsAndTtls.newViaLbl						=		'New VIA';
Modules.LblsAndTtls.ldgViaLbl						=		'Load VIA'; 
Modules.LblsAndTtls.dishViaLbl						=		'Dish VIA';

Modules.LblsAndTtls.voaLbl							=		'VOA';
Modules.LblsAndTtls.coaLbl							=		'COA';
Modules.LblsAndTtls.cfsLbl							=		'CFS';
Modules.LblsAndTtls.chaLbl							=		'CHA';

Modules.LblsAndTtls.clearActionTtl					=		'Clear';
Modules.LblsAndTtls.deleteActionTtl					=		'Delete';
Modules.LblsAndTtls.retrieveActionTtl				=		'Retrieve';
Modules.LblsAndTtls.pasteSucc						=		'Updated Successfully';
Modules.LblsAndTtls.addActionTtl					=		'Add';
Modules.LblsAndTtls.saveActionTtl					=		'Save';
Modules.LblsAndTtls.exitActionTtl					=		'Exit'; 
Modules.LblsAndTtls.modifyActionTtl                 =       'Modify';
Modules.LblsAndTtls.advanceSearchTtl                =       'Advance Search';
Modules.LblsAndTtls.keySearchTtl                    =       'Key Search';
Modules.LblsAndTtls.saveSearchCriteriaTtl           =       'Save Search Criteria';
Modules.LblsAndTtls.retrieveSearchCriteriaTtl       =       'Retrieve Search Criteria';
Modules.LblsAndTtls.viewTtl                         =       'View';
Modules.LblsAndTtls.uploadTtl                       =       'Upload';
Modules.LblsAndTtls.downloadTtl                     =       'Download';
Modules.LblsAndTtls.resendTtl                     =         'Resend';
Modules.LblsAndTtls.manualTtl                       =       'Manual';
Modules.LblsAndTtls.showErrorTtl                    =       'Show Errors';
Modules.LblsAndTtls.showEdiFileTtl                  =       'Show EDI File';
Modules.LblsAndTtls.populateSearchCriteriaTtl       =    'Populate Search Criteria';

Modules.LblsAndTtls.tooltip.openPopupWin			=	'Open Popup Window';
Modules.LblsAndTtls.tooltip.editWin					=	'Edit Window';
Modules.LblsAndTtls.tooltip.retrieveChildRecords	=	'Retrieve Child Records';



Modules.LblsAndTtls.applicationBerthingWinTtl		=		'Application For Berthing Request';
Modules.LblsAndTtls.transshipmentApprovalWindowTtl	= 		'Transshipment Approval';
Modules.LblsAndTtls.recordingHoldStatusWinTtl		=		'Recording Of Hold Status';
Modules.LblsAndTtls.arrNDepRecordingWinTtl     		=   	'Arrival And Departure Recording';
Modules.LblsAndTtls.containerDmgRecWinTtl 			=   	'Container Damage Recording';
Modules.LblsAndTtls.cancelContainerEntryWindowTtl	=		'Cancel Container Entry';
Modules.LblsAndTtls.cancelContainerExitWindowTtl	=		'Cancel Container Exit';
Modules.LblsAndTtls.changeOfVesselExportCtrWinTtl	=		'Change of Vessel Export Container';
Modules.LblsAndTtls.batchdDlyRecWinTtl     			= 		'Batch Delay Recording';
Modules.LblsAndTtls.viaGenerationWinTtl				=		'Via Generation';
Modules.LblsAndTtls.berthingUnberthingWinTtl		=		'Berthing/Unberthing Recording';
Modules.LblsAndTtls.cancelContainerEntryWinTtl		=   	'Cancel Container Entry';
Modules.LblsAndTtls.cancelContainerExitWinTtl		= 		'Cancel Container Exit';
Modules.LblsAndTtls.chngBaseStsImportCtrWinTtl		=		'Change Base Status For Import Container';
Modules.LblsAndTtls.chngBseStsInTCtnrsWinTtl 		= 		'Chng Base Status for Import & Transhipment Containers';
Modules.LblsAndTtls.removalOfHoldStswinTtl			=		'Removal Of Status';
Modules.LblsAndTtls.chngSealNoWinTtl     			= 		'Change Seal Number';
Modules.LblsAndTtls.changeContainerNumberWinTtl		=		'Change Container Number';
Modules.LblsAndTtls.createContainerWindowTtl		=   	'Add/Edit Container';
Modules.LblsAndTtls.portRotationWinTtl				=		'Ports Rotation';
Modules.LblsAndTtls.partyMasterWinTtl				=		'Party Master';

Modules.LblsAndTtls.vinCheckTtl = 'Vin Check';
Modules.LblsAndTtls.lengthTtl				=		'Length';
Modules.LblsAndTtls.widthTtl				=		'Width';
Modules.LblsAndTtls.heightTtl				=		'Height';
Modules.LblsAndTtls.weightTtl				=		'Weight';
Modules.LblsAndTtls.volumeTtl				=		'Volume';

Modules.LblsAndTtls.reference1Ttl				=		'Reference1';
Modules.LblsAndTtls.reference2Ttl				=		'Reference2';
Modules.LblsAndTtls.reference3Ttl				=		'Reference3';
Modules.LblsAndTtls.reference4Ttl				=		'Reference4';
Modules.LblsAndTtls.reference5Ttl				=		'Reference5';
Modules.LblsAndTtls.reference6Ttl				=		'Reference6';
Modules.LblsAndTtls.reference7Ttl				=		'Reference7';
Modules.LblsAndTtls.reference8Ttl				=		'Reference8';
Modules.LblsAndTtls.reference9Ttl				=		'Reference9';
Modules.LblsAndTtls.reference10Ttl				=		'Reference10';

Modules.LblsAndTtls.voyageMonitoringPanelTtl			 =   'Voyage Monitoring';
Modules.LblsAndTtls.consolidatedLoadListPanelTtl    	 =   'Consolidated Load List';
Modules.LblsAndTtls.consolidatedDischargeListPanelTtl    =   'Consolidated Discharge List';
Modules.LblsAndTtls.reeferConnDtlsPanelTtl				 =	 'Reefer Conn Details';
Modules.LblsAndTtls.ctrSrvcRecPanelTtl				     =   'Container Service Recording';
Modules.LblsAndTtls.ctrListPanelTtl                      =	 'Container List';
Modules.LblsAndTtls.containerHistoryTabParentPanelTtl	 = 'Container History';
Modules.LblsAndTtls.transporterDetailsSealNumbersPanelTtl=  'Transporter Details & Seal No.';
Modules.LblsAndTtls.entryPanelTtl						 =   'Entry';
Modules.LblsAndTtls.exitPanelTtl						 =   'Exit';
Modules.LblsAndTtls.reeferDtlsPanelTtl					 =   'Reefer Details';
Modules.LblsAndTtls.oogDtlsPanelTtl						 =   'OOG Details';
Modules.LblsAndTtls.partyDtlsTtl					     =	 'Party Details';

Modules.LblsAndTtls.vesselCodeLbl                   =       'Vessel Code';

Modules.LblsAndTtls.vslCallDtlsTtl					=		'Vessel Call Details';
Modules.LblsAndTtls.portRotationTtl					=		'Port Rotation';
Modules.LblsAndTtls.ctrDtlsTtl						=		'Container Details';
Modules.LblsAndTtls.draftDtlsTtl					=		'Draft Details';
Modules.LblsAndTtls.vesselDtlsTtl					=		'Vessel Details';
Modules.LblsAndTtls.queryParametersTtl				=		'Query Parameters';
Modules.LblsAndTtls.backToTownCtrIdentificationTtl	=		'Back To Town Container Identification';
Modules.LblsAndTtls.hzDtlsGridTtl					=		'Hazardous Details';
Modules.LblsAndTtls.tempRecDtlsGridTtl				=		'Temperature Record Details';
Modules.LblsAndTtls.markDeleteActionTtl 			= 		'Mark Delete';
Modules.LblsAndTtls.unmarkDeleteActionTtl 			= 		'UnMark Delete';
Modules.LblsAndTtls.vslOprtDtlsTtl					=		'VOA Details';
Modules.LblsAndTtls.damageDtlsGridTtl				=		'Damage Details';
Modules.LblsAndTtls.serviceDtlsGridTtl				=		'Service Details';
Modules.LblsAndTtls.connDisconnDtlsGridTtl			=		'Conn/Disconn Details';
Modules.LblsAndTtls.bdlDtlsGridCreatCtrTtl			=	    'Bundle Details';
Modules.LblsAndTtls.portsTtl			 			= 		'Ports';
Modules.LblsAndTtls.mapperTtl						=		'Mapper';
Modules.LblsAndTtls.trasmissionDtlsTtl				=		'Transmission Details';


Modules.LblsAndTtls.reqRegDttmLbl					=		'Appln Date';
Modules.LblsAndTtls.etbDttmLbl						=		'Expected Time of Berthing';
Modules.LblsAndTtls.atbDttmLbl						=		'Berth Time';
Modules.LblsAndTtls.atubDttmLbl						=		'Unberth Time';
Modules.LblsAndTtls.etuLbl							=		'ETU';
Modules.LblsAndTtls.frmDttmLbl 			  	        = 		'From Date';
Modules.LblsAndTtls.frmTmLbl 			  	        = 		'From Time';
Modules.LblsAndTtls.toDttmLbl 			  	    	= 		'To Date'; 
Modules.LblsAndTtls.toTmLbl 			  	    	= 		'To Time'; 
Modules.LblsAndTtls.arrivalDraftLbl				    =   	'Arrival Draft';
Modules.LblsAndTtls.anchorageDateLbl				=   	'Anchorage Date';
Modules.LblsAndTtls.vslAllfastDtLbl					=   	'Vsl All Fast Date';
Modules.LblsAndTtls.vslAshoreDtLbl					=   	'Vsl Ashore Date';
Modules.LblsAndTtls.tiedDtLbl						=   	'Tied Date';
Modules.LblsAndTtls.logDttmLbl						=	    'Log Dttm';
Modules.LblsAndTtls.apprvdDttmLbl					=	    'Apprvd Dttm';
Modules.LblsAndTtls.invoiceDttmLbl					=   	'Invoice Dttm';
Modules.LblsAndTtls.boeCstmrDttmLbl					=		'BEO/Cstmr Date';
Modules.LblsAndTtls.entryDttmLbl					=	    'Entry DTTM';
Modules.LblsAndTtls.exitDttmLbl						=	    'Exit DTTM';
Modules.LblsAndTtls.etaLbl							=		'ETA';
Modules.LblsAndTtls.etdLbl							=		'ETD';
Modules.LblsAndTtls.etbLbl							=		'ETB';
Modules.LblsAndTtls.ataDttmLbl						=		'ATA';
Modules.LblsAndTtls.atdDttmLbl						=		'ATD'; 
Modules.LblsAndTtls.tempRecDttmLbl					=	    'Temp Rec Dttm';
Modules.LblsAndTtls.connectionDttmLbl				=	    'Connection Dttm';
Modules.LblsAndTtls.disConnectionDttmLbl			=   	'Disconnection Dttm';
Modules.LblsAndTtls.applFromDateLbl					=		'Application Dates From';
Modules.LblsAndTtls.etaFromDateLbl					=		'ETA Dates From';
Modules.LblsAndTtls.etaToDateLbl			    	=		'To';
Modules.LblsAndTtls.lbrOnboardLbl					=		'Labour Onboard Date';
Modules.LblsAndTtls.lbrOffboardLbl					=		'Labour Offboard Date';
Modules.LblsAndTtls.arrCustomClrDtLbl				=		'Arrival Custom Clear Date';
Modules.LblsAndTtls.depCustomClrDtLbl				=		'Departure Custom Clear Date';
Modules.LblsAndTtls.actualDischargeOprnStartDtLbl	=		'Actual Discharge Oprn Start Date';
Modules.LblsAndTtls.actualDischargeOprnEndDtLbl		=		'Actual Discharge Oprn End Date';
Modules.LblsAndTtls.actualLoadOprnStartDtLbl		=		'Actual Load Oprn Start Date';
Modules.LblsAndTtls.actualLoadOprnEndDtLbl			=		'Actual Load Oprn End Date';
Modules.LblsAndTtls.getOpenTimeLbl					=		'Gate Open Tm';
Modules.LblsAndTtls.finalCutoffTimeLbl				=		'Final Cut Off Tm';
Modules.LblsAndTtls.forTruckFinalCutOffTimeLbl		=		'For Truck Final Cut Off Tm';
Modules.LblsAndTtls.recordingDttmLbl				=   	'Recording Dttm';
Modules.LblsAndTtls.berthingTimeLbl					=		'Berthing Time';
Modules.LblsAndTtls.unberthingTimeLbl				=		'Unberthing Time';
Modules.LblsAndTtls.dmgDt                           = 		'Dmg Date';
Modules.LblsAndTtls.rprDt                           = 		'Rpr Date';
Modules.LblsAndTtls.endDate                         = 		'End Date';

Modules.LblsAndTtls.phoneNbrLbl                     =  'Phone Number';

Modules.LblsAndTtls.emgncyFlgLbl					=		'Emergency Flag';
Modules.LblsAndTtls.flagLbl							=		'Flag';
Modules.LblsAndTtls.oogFlagLbl						=		'OOG Flag';
Modules.LblsAndTtls.dmgFlgLbl						=		'Dmg Flag';
Modules.LblsAndTtls.hzFlgLbl						=		'Hz Flag';
Modules.LblsAndTtls.brProcessFlgLbl					=		'BR Process Flag';
Modules.LblsAndTtls.holdFlagLbl						=		'Hold Flag';
Modules.LblsAndTtls.rfrOrderFlgCheckBoxLbl			=		'Reefer Order Flag';	
Modules.LblsAndTtls.rfrOprnFlgCheckBoxLbl			=		'Reefer Oprn Flag';
Modules.LblsAndTtls.ctrSrvIdLbl						=		'Ctr Srv ID';
Modules.LblsAndTtls.invcRqdFlgLbl					=		'Invc Rqd Flag';	
Modules.LblsAndTtls.splEqptFlgCheckBoxLbl			=		'Spl Eqpt Flag';
Modules.LblsAndTtls.sprdrRqrdoFlgCheckBoxLbl		=		'Sprdr Rqrdo Flag';
Modules.LblsAndTtls.primaryFlagLbl					=		'Primary Flag';
Modules.LblsAndTtls.appFlgLbl						=		'App Flag';
Modules.LblsAndTtls.rprFlg                          =   	'Rpr Flag';
Modules.LblsAndTtls.bdlFlgLbl						=		'BDl Flag';
Modules.LblsAndTtls.holdFlgLbl						=		'Hold Flag';
Modules.LblsAndTtls.drfPrintedFlgLbl				=		'Drf Printed Flag';
Modules.LblsAndTtls.drfApprovedFlgLbl				=		'Drf Approved Flag';
Modules.LblsAndTtls.invcGenFlgLbl		 			=		'Invc Gen Flag';
Modules.LblsAndTtls.primryFlgLbl				    =   	'Primry Flag';
Modules.LblsAndTtls.rfrFlgLbl						=		'Rfr Flag';

/************************************* Cd Field labels **************************************/
Modules.LblsAndTtls.isoCdLbl						=		'ISO Code';
Modules.LblsAndTtls.dptOrgnCdLbl					=		'Dpt Orgn Code';
Modules.LblsAndTtls.quayCdLbl						=		'Quay Code';
Modules.LblsAndTtls.dmgCdLbl                        =   	'Dmg Code';
Modules.LblsAndTtls.dmgSvrLbl                       =   	'Dmg Svrty Code';
Modules.LblsAndTtls.tmnlCdLbl						=		'Tmnl Code';
Modules.LblsAndTtls.vslCatCdLbl						=		'Vessel Catogery';
Modules.LblsAndTtls.ldTradeCdLbl					=		'Trade Code';
Modules.LblsAndTtls.routeCdLbl						=		'Route Code';
Modules.LblsAndTtls.vslCdLbl						=		'Vsl Code';
Modules.LblsAndTtls.srvCdLbl						=		'Service Code';
Modules.LblsAndTtls.cnsrtmCdLbl						=		'Consortium Code';
Modules.LblsAndTtls.invcPrtyCdLbl 			  		= 		'Invc Party Code';
Modules.LblsAndTtls.frmCtrSrvcCdLbl 			  	= 		'From Ctr Srvc Code'; 
Modules.LblsAndTtls.invcRqstCdLbl 			  	    = 		'Invc Rqst Code';
Modules.LblsAndTtls.toCtrSrvcCdLbl 			  	    = 		'To Ctr Srvc Code';
Modules.LblsAndTtls.dlyCdLbl         	   			= 		'Delay Code';
Modules.LblsAndTtls.reasonCdLbl						=		'Reason Code';
Modules.LblsAndTtls.cmdtCdLbl						=		'Cmdt Code';
Modules.LblsAndTtls.dmgSrvtCdLbl					=		'Dmg Srvt Code';
Modules.LblsAndTtls.unHzCodeLbl						=		'Un Hz Code';
Modules.LblsAndTtls.dmgCodeLbl						=		'Dmg Code';
Modules.LblsAndTtls.imoCodeLbl						=		'IMO Code';
Modules.LblsAndTtls.invcPtyCdLbl					=		'Invc Pty';
Modules.LblsAndTtls.depotCodeLbl					=		'Depot Code';
Modules.LblsAndTtls.depotOrgnCdLbl				    =	    'Depot Orgn Code';
Modules.LblsAndTtls.loadInstrCdLbl					=	    'Load Instr Code';
Modules.LblsAndTtls.imdgCdLbl						=		'IMDG Code';
Modules.LblsAndTtls.currencyCdLbl					=		'Currency Code';
Modules.LblsAndTtls.creditTermCdLbl					=		'Credit Term Code';
Modules.LblsAndTtls.bankCdLbl						=		'Bank Code';
Modules.LblsAndTtls.partyCdLbl						=		'Party Code';
Modules.LblsAndTtls.postCdLbl						=		'Post Code';
Modules.LblsAndTtls.blCompletionLbl					=		'Bill of Lading Completion';
Modules.LblsAndTtls.blCountFullLbl					=		'Bill of Lading Count';
Modules.LblsAndTtls.localAgentCdLbl					=		'Local Agent Code';

Modules.LblsAndTtls.rqstNoLbl						=		'Request No.';
Modules.LblsAndTtls.cstmLbl							=		'Consortium';
Modules.LblsAndTtls.windowLbl						=		'Window';
Modules.LblsAndTtls.lastPortLbl						=		'Last Port';
Modules.LblsAndTtls.nextPortLbl						=		'Next Port';
Modules.LblsAndTtls.dlbthIndLbl						=		'D/L/Bth Ind';
Modules.LblsAndTtls.inboundLbl						=		'Inbound';
Modules.LblsAndTtls.outboundLbl						=		'Outbound';
Modules.LblsAndTtls.maidenVoyLbl					=		'Maiden Voyage';
Modules.LblsAndTtls.berthSideLbl					=		'Berthing Side';
Modules.LblsAndTtls.dishVoyNoLbl					=		'Dish Voy No.';
Modules.LblsAndTtls.loadVoyNoLbl					=		'Load Voy No.';
Modules.LblsAndTtls.ispsLevelLbl					=		'ISPS Level';
Modules.LblsAndTtls.egmRotatonLbl					=		'EGM Rotation No.';
Modules.LblsAndTtls.igmRotationNoLbl				=		'IGM Rotation No.';
Modules.LblsAndTtls.exportBrCountLbl				=		'Export BR (Count)';
Modules.LblsAndTtls.exportBrTeuLbl					=		'Export BR (TEU)';
Modules.LblsAndTtls.terminalLbl						=		'Terminal';
Modules.LblsAndTtls.imoLbl							=		'IMO';
Modules.LblsAndTtls.callSignLbl						=		'Call Sign';
Modules.LblsAndTtls.arrFwdLbl						=		'Arrival Forward';
Modules.LblsAndTtls.arrAftLbl						=		'Arrival Aft';
Modules.LblsAndTtls.depFwdLbl						=		'Departure Forward';
Modules.LblsAndTtls.depAftLbl						=		'Departure Aft';
Modules.LblsAndTtls.loaLbl							=		'LOA';
Modules.LblsAndTtls.grtLbl							=		'GRT';
Modules.LblsAndTtls.nrtLbl							=		'NRT';
Modules.LblsAndTtls.deadWtLbl						=		'Dead Wt';
Modules.LblsAndTtls.portOfRegLbl					=		'Port Of Reg';
Modules.LblsAndTtls.vslTypeLbl						=		'Vsl Type';
Modules.LblsAndTtls.vslCgyLbl						=		'Vsl Category';
Modules.LblsAndTtls.vslAgentAddrLbl					=		'Vsl Agent Address';
Modules.LblsAndTtls.cgyLbl							=		'Category';
Modules.LblsAndTtls.ctrCountLbl						=		'Ctr Count';
Modules.LblsAndTtls.dishLdgIndLbl					=		'Dish Ldg Ind';
Modules.LblsAndTtls.portRotLbl						=		'Port Rotation'; 
Modules.LblsAndTtls.vesselCategoryLbl				=		'Vsl Category'; 
Modules.LblsAndTtls.requestStsLbl					=		'Request Sts'; 
Modules.LblsAndTtls.notArrivedCheckBoxLbl			=		'Not Arrived';
Modules.LblsAndTtls.arrivedCheckBoxLbl				=		'Arrived';
Modules.LblsAndTtls.berthedCheckBoxLbl				=		'Berthed';
Modules.LblsAndTtls.departedCheckBoxLbl				=		'Departed'; 
Modules.LblsAndTtls.voyRqstNoLbl					=		'Request No.';
Modules.LblsAndTtls.rqstStsLbl						=		'Rqst Sts';
Modules.LblsAndTtls.currentBerthLbl					=		'Current Berth';
Modules.LblsAndTtls.vslBeamLbl						=		'Beam';
Modules.LblsAndTtls.deadWtLbl						=		'Dwt'; 
Modules.LblsAndTtls.impUnitsLbl						=		'Import Units';
Modules.LblsAndTtls.expUnitsLbl						=		'Export Units';
Modules.LblsAndTtls.totalUnitsLbl					=		'Total Units';
Modules.LblsAndTtls.cntnrNoLbl              	    =       'Ctr No.'; 
Modules.LblsAndTtls.baseStsLbl						=		'Base Sts';
Modules.LblsAndTtls.feIndLbl						=		'F/E Ind';
Modules.LblsAndTtls.dishLdgBothIndLbl				=		'D/L/Both Ind';
Modules.LblsAndTtls.ctrSzLbl						=		'Size';
Modules.LblsAndTtls.ctrTypeLbl						=		'Type';
Modules.LblsAndTtls.containerHtLbl					=		'Height';
Modules.LblsAndTtls.frmEntryLbl						=		'From Entry';
Modules.LblsAndTtls.frmExitLbl						=		'From Exit';
Modules.LblsAndTtls.locIndLbl						=		'Loc Ind';
Modules.LblsAndTtls.toEntryMdLbl					=		'To Entry';
Modules.LblsAndTtls.toExitMdLbl						=		'To Exit';
Modules.LblsAndTtls.bdlIndLbl						=		'BDL Ind';
Modules.LblsAndTtls.fclLclIndLbl					=		'FCL/LCL Ind';
Modules.LblsAndTtls.entryMdLbl						=		'Entry Mode';
Modules.LblsAndTtls.exitModeLbl						=		'Exit Md';
Modules.LblsAndTtls.vslNmLbl		 				=		'Vsl Nm'; 
Modules.LblsAndTtls.srvcCmptDnLbl		 			=		'Srvc Work Copmletion Done'; 
Modules.LblsAndTtls.viewCmpltSrvcLbl		 		=		'View Complete Srvc';
Modules.LblsAndTtls.motherFeederIndLbl				=		'M/F Ind';
Modules.LblsAndTtls.diffInHrsLbl					=		'Diff(in hrs)';	
Modules.LblsAndTtls.totalWtLbl						=		'Total Wt(Mt)';
Modules.LblsAndTtls.vcnLbl							=		'VCN';
Modules.LblsAndTtls.vldtWtLbl						=		'Vldt Wt';
Modules.LblsAndTtls.demobilizationServiceLbl		=		'Demobilization Service';
Modules.LblsAndTtls.piolatageServReqLbl				=		'Pilotage Serv Req';
Modules.LblsAndTtls.piolatageRemrksLbl				=		'Pilotage Rmks';
Modules.LblsAndTtls.fromLocLbl						=		'From Loc';
Modules.LblsAndTtls.toLocLbl						=       'To Loc';
Modules.LblsAndTtls.ctgryLbl						=		'Category';
Modules.LblsAndTtls.podLbl 							=		'POD';
Modules.LblsAndTtls.fpdLbl							=		'FPD';
Modules.LblsAndTtls.cpLbl							=		'CP';
Modules.LblsAndTtls.customRefNoLbl					=		'Custom Ref No.';
Modules.LblsAndTtls.officersNmLbl					=		"Officer's Nm";
Modules.LblsAndTtls.relRemarksLbl					=		'Release Remarks';
Modules.LblsAndTtls.cntnrListLbl             		=  	 	'List Of Ctrs';
Modules.LblsAndTtls.holdRemarkLbl					=		'Hold Remark';
Modules.LblsAndTtls.loaLblm						    =		'LOA(m)';
Modules.LblsAndTtls.tmnlNmLbl						=		'Terminal Nm';
Modules.LblsAndTtls.beamLbl							=		'Beam';
Modules.LblsAndTtls.gtLbl						    =   	'GT';
Modules.LblsAndTtls.displacementLbl					=   	'Displacement';
Modules.LblsAndTtls.dmgSectLbl                      =   	'Dmg Sect';
Modules.LblsAndTtls.dmgSeqNoLbl                     =   	'Dmg Seq No.';
Modules.LblsAndTtls.dmgDescrLbl                     =   	'Dmg Desc';
Modules.LblsAndTtls.respPartyLbl                    =  	 	'Responsible Party';
Modules.LblsAndTtls.rprAmt                			= 		'Rpr Amt';
Modules.LblsAndTtls.rprDrtn               			= 		'Rpr Duration';
Modules.LblsAndTtls.cstmClNoLbl              		= 		'Custom Clearance No.';
Modules.LblsAndTtls.newPodLbl                		= 		'New POD';
Modules.LblsAndTtls.newFpdLbl                		= 		'New FPD';
Modules.LblsAndTtls.newExprtrLbl             		= 		'New Exporter';
Modules.LblsAndTtls.sealType1Lbl         			= 		'Seal Type1';
Modules.LblsAndTtls.sealType2Lbl         			= 		'Seal Type2';
Modules.LblsAndTtls.sealType3Lbl         			= 		'Seal Type3';
Modules.LblsAndTtls.sealNo1Lbl           			= 		'Seal No.1';
Modules.LblsAndTtls.sealNo2Lbl           			= 		'Seal No.2';
Modules.LblsAndTtls.sealNo3Lbl           			= 		'Seal No.3';
Modules.LblsAndTtls.newCtrNoLbl						=		'New Ctr No.';
Modules.LblsAndTtls.newBaseStsLbl					=		'New Base Sts';
Modules.LblsAndTtls.rstTypeLbl						=		'Rst Type';
Modules.LblsAndTtls.respondPtyRestowLbl				=		'Respond Pty For Restow';
Modules.LblsAndTtls.vslCellLocnLbl					=		'Vsl Cell Loc';
Modules.LblsAndTtls.newVslCellLocnLbl				=		'New Vsl Cell Loc';
Modules.LblsAndTtls.toVslCellLocnLbl				=		'To Vsl Cell Loc';
Modules.LblsAndTtls.currentLocIndLbl				=		'Cur Loc Ind';
Modules.LblsAndTtls.yardLocationLbl					=		'Yard Loc';
Modules.LblsAndTtls.reasonForCancellationLbl		=		'Cancellation Reason'; 
Modules.LblsAndTtls.arrDraftLbl						=		'Arr Draft';
Modules.LblsAndTtls.depDraftLbl						=		'Dep Draft';
Modules.LblsAndTtls.wharfMarkLbl					=		'Wharf Mark';                                                    
Modules.LblsAndTtls.berthNoLbl						=		'Berth No.';
Modules.LblsAndTtls.tmnlLbl							=		'Tmnl';//need to remove after testing
Modules.LblsAndTtls.fmMmLbl							=		'Fm Mm';
Modules.LblsAndTtls.toMmLbl							=		'To Mm';
Modules.LblsAndTtls.berthSidePsLbl					=		'Berthing Side P/S';
Modules.LblsAndTtls.berthingRmrksLbl				=		'Berthing Rmrks';
Modules.LblsAndTtls.unberthReasonLbl				=		'UnBerth Reason';
Modules.LblsAndTtls.unberthRmrksLbl					=		'UnBerth Rmrks';
Modules.LblsAndTtls.eqpIdLbl         	   			= 		'Equipment ID';
Modules.LblsAndTtls.dlyTypeLbl         	   			= 		'Delay Type';
Modules.LblsAndTtls.dlyDescLbl         	   			= 		'Delay Description';
Modules.LblsAndTtls.timeInMinLbl           			= 		'Duration In Minutes';
Modules.LblsAndTtls.noOfHatchLbl		  			= 		'No. Of Hatch';
Modules.LblsAndTtls.remarksLbl		       			= 		'Remarks';
Modules.LblsAndTtls.brNoLbl							=		'BR Number';
Modules.LblsAndTtls.polLbl							=		'POL';
Modules.LblsAndTtls.polDescLbl                      =       'POL Description';
Modules.LblsAndTtls.polBerthCodelbl                 =       'POL Berth Code';
Modules.LblsAndTtls.polPortCalllbl                  =       'POL Port Call';
Modules.LblsAndTtls.polAddress1lbl                  =       'POL Address 1';
Modules.LblsAndTtls.polAddress2lbl                  =       'POL Address 2';
Modules.LblsAndTtls.curStsLbl						=		'Cur Sts';
Modules.LblsAndTtls.sbNoLbl							=		'SB Number';
Modules.LblsAndTtls.curLocnLbl						=		'Cur Loc';
Modules.LblsAndTtls.excludeSlaveLbl					=		'Exclude Slave';
Modules.LblsAndTtls.notInPortLbl					=		'Not In Port';		
Modules.LblsAndTtls.inPortLbl						=		'In Port';
Modules.LblsAndTtls.inYardLbl						=		'In Yard';
Modules.LblsAndTtls.onVesselLbl						=		'On Vessel';
Modules.LblsAndTtls.manifestedLbl					=		'Manifested';
Modules.LblsAndTtls.dshdNotInYrdLbl					=		'Dshd Not In Yrd';
Modules.LblsAndTtls.dshdInYrdLbl					=		'Dshd In Yrd';		  
Modules.LblsAndTtls.ctrExtdTrmlLbl					=		'Ctr Extd Trml';
Modules.LblsAndTtls.hzCtrsLbl						=		'Hz Ctrs';
Modules.LblsAndTtls.rfrCtrsLbl						=		'Rfr Ctrs';
Modules.LblsAndTtls.oogCtrsLbl						=		'OOG Ctrs';
Modules.LblsAndTtls.mstrBndlLbl						=		'Master Bndl';	
Modules.LblsAndTtls.slaveBndlLbl					=		'Slave Bndl';
Modules.LblsAndTtls.mstrIndLbl						=		'Mstr Ind';
Modules.LblsAndTtls.slaveIndLbl						=		'Slave Ind';
Modules.LblsAndTtls.manifestedTotLbl				=		'Manifested Tot';
Modules.LblsAndTtls.totalManifestedLbl				=		'Total Manifested';		
Modules.LblsAndTtls.twentyTotLbl					=		"20' Tot";		
Modules.LblsAndTtls.twentyFullCntLbl				=		"20' Full Cnt";	
Modules.LblsAndTtls.twentyMtyCntLbl					=		"20' Mty Cnt";
Modules.LblsAndTtls.fourtyTotLbl					=		"40' Tot";		
Modules.LblsAndTtls.fourtyFullCntLbl				=		"40' Full Cnt";		
Modules.LblsAndTtls.fourtyMtyCntLbl					=		"40' Mty cnt";
Modules.LblsAndTtls.fourtyFiveTotLbl				=		"45' Tot";		
Modules.LblsAndTtls.fourtyFiveFullCntLbl			=		"45' Full Cnt";  
Modules.LblsAndTtls.fortyFiveMtyCntLbl				=		"45' Mty Cnt";
Modules.LblsAndTtls.exportLbl						=		'Export';
Modules.LblsAndTtls.importLbl						=		'Import';
Modules.LblsAndTtls.loadedTotLbl					=		'Loaded Tot';		
Modules.LblsAndTtls.restowLbl						=		'Restow';
Modules.LblsAndTtls.transhipmentLbl					=		'Transhipment';
Modules.LblsAndTtls.robLbl							=		'Rob';
Modules.LblsAndTtls.totlaDischargedLbl				=		'Total Discharged';
Modules.LblsAndTtls.pendingCtrLbl					=		'Pending Ctrs';
Modules.LblsAndTtls.statusLbl						=		'Status';
Modules.LblsAndTtls.newCpLbl						=		'New CP';
Modules.LblsAndTtls.descriptionLbl					=		'Description';
Modules.LblsAndTtls.boeCstmrRefLbl					=		'BOE/Cstmr Ref';
Modules.LblsAndTtls.pilotageSrvLbl					=		'Pilotage Service';
Modules.LblsAndTtls.pilotageRmrksLbl				=		'Pilotage Remarks';
Modules.LblsAndTtls.wrongCntrNoLbl					=		'Wrong Ctr No.';
Modules.LblsAndTtls.actualCntrNoLbl					=		'Actual Ctr No.';
Modules.LblsAndTtls.reasonLbl						=		'Reason';
Modules.LblsAndTtls.restowPtyLbl					=		'Restow Pty';
Modules.LblsAndTtls.catogeryLbl						=		'Catogery';
Modules.LblsAndTtls.tareWtMTLbl						=		'Tare Wt(MT)';
Modules.LblsAndTtls.bookingNoLbl					=		'Booking No.';
Modules.LblsAndTtls.cargoTypeLbl					=		'Cargo Type';
Modules.LblsAndTtls.lifeNoLbl						=		'Life No.';
Modules.LblsAndTtls.locationLbl						=		'Loc';
Modules.LblsAndTtls.locationNameLbl					=		'Loc Nm';
Modules.LblsAndTtls.curLocIndLbl					=		'Cur Loc Ind';
Modules.LblsAndTtls.bdlIdLbl						=		'Bdl ID';
Modules.LblsAndTtls.viewBundleLbl					=		'View Bundle Ctrs';
Modules.LblsAndTtls.rfrCheckBoxLbl					=		'Rfr';
Modules.LblsAndTtls.oogCheckBoxLbl					=		'OOG';
Modules.LblsAndTtls.hzCheckBoxLbl					=		'Hz';
Modules.LblsAndTtls.dmgCheckBoxLbl					=		'Dmg';
Modules.LblsAndTtls.holdCheckBoxLbl					=		'Hold';
Modules.LblsAndTtls.truckNoLbl						=		'Truck No.';
Modules.LblsAndTtls.driverNameLbl					=		'Driver Nm';
Modules.LblsAndTtls.truckEntryLbl					=		'Truck Entry';
Modules.LblsAndTtls.truckExitLbl					=		'Truck Exit';
Modules.LblsAndTtls.cstmSealLbl						=		'Cstm Seal';
Modules.LblsAndTtls.customSealNoLbl					=		'Cstm Seal No.';
Modules.LblsAndTtls.customSealTypeLbl				=		'Cstm Seal Type';
Modules.LblsAndTtls.linerSealLbl					=		'Liner Seal';
Modules.LblsAndTtls.linerSealNoLbl					=		'Liner Seal No.';
Modules.LblsAndTtls.linerSealTypeLbl				=		'Liner SealType';
Modules.LblsAndTtls.sipperSealLbl					=		'Shpr Seal';
Modules.LblsAndTtls.shipperSealNoLbl				=		'Shpr Seal No.';
Modules.LblsAndTtls.shipperSealTypeLbl				=		'Shpr Seal Type';
Modules.LblsAndTtls.originLbl						=		'Origin';													    
Modules.LblsAndTtls.destinationLbl					=		'Destination';
Modules.LblsAndTtls.drfNoLbl						=		'Drf No.';	
Modules.LblsAndTtls.exitMdLbl						=		'Exit Md';
Modules.LblsAndTtls.minTempNoLbl					=		'Min Temp';
Modules.LblsAndTtls.maxTempNoLbl					=		'Max Temp';
Modules.LblsAndTtls.setTempLbl						=		'Set Temp';	
Modules.LblsAndTtls.supplyAirTempLbl				=		'SupplyAir Temp';
Modules.LblsAndTtls.returnAirTempLbl				=		'ReturnAir Temp';
Modules.LblsAndTtls.tempMsrUnitLbl					=		'Temp Msr Unit';
Modules.LblsAndTtls.overHtNoLbl						=		'Over Ht'; 
Modules.LblsAndTtls.cargoHtNoLbl					=		'Cargo Ht';
Modules.LblsAndTtls.overLengthAftLbl				=		'OverLegth Aft';	
Modules.LblsAndTtls.overLengthForeLbl				=		'OverLegth Fore';
Modules.LblsAndTtls.overWidthLeftSideLbl			=		'OverWidth Left Side';
Modules.LblsAndTtls.overWidthRightSideLbl			=		'OverWidth Right Side';
Modules.LblsAndTtls.msrUnitLbl						=		'Msr Unit';													    
Modules.LblsAndTtls.dmgSecLbl						=		'Dmg Sec';
Modules.LblsAndTtls.dmgTypeLbl						=		'Dmg Type';													    
Modules.LblsAndTtls.remarkLbl						=		'Remark';
Modules.LblsAndTtls.mvmtRqrdLbl						=		'Mvmt Rqrd';
Modules.LblsAndTtls.srvWkCompLbl					=		'Srv Wk Comp';
Modules.LblsAndTtls.apprvdUserNmLbl					=		'Apprvd User Nm';
Modules.LblsAndTtls.serviceRemarkLbl				=		'Service Remark';
Modules.LblsAndTtls.actTempLbl						=		'Act Temp';
Modules.LblsAndTtls.tempUomLbl						=		'Temp UOM';
Modules.LblsAndTtls.userNmLbl						=		'User Nm';
Modules.LblsAndTtls.exporterLbl						=		'Exporter';
Modules.LblsAndTtls.dispMdLbl						=		'Disp Mode';
Modules.LblsAndTtls.cmdtLbl							=		'Commodity';
Modules.LblsAndTtls.uomLbl							=		'UOM';
Modules.LblsAndTtls.techDesrcLbl					=		'Tech Desc';
Modules.LblsAndTtls.slotsLbl						=		'No of Slots Avail';
Modules.LblsAndTtls.totHtLbl						=		'Total Height';
Modules.LblsAndTtls.rfrTyLbl					    =   	'Rfr Type';
Modules.LblsAndTtls.forthPortsWinTtl				=		'FOURTH PORTS Login';
Modules.LblsAndTtls.loginIdLbl						=		'Login ID';
Modules.LblsAndTtls.passwordLbl						=		'Password';
Modules.LblsAndTtls.okLbl							=		'OK';
Modules.LblsAndTtls.resetLbl						=		'Reset';
Modules.LblsAndTtls.forgotPassLbl					=		'Forgot Password';
Modules.LblsAndTtls.forgotPassWinTtl				=		'Forgot Password';
Modules.LblsAndTtls.emailIdLbl						=		'E-mail ID';
Modules.LblsAndTtls.changePassWinTtl				=		'Change Password';
Modules.LblsAndTtls.oldPasswordLbl					=		'Old Password';
Modules.LblsAndTtls.newPasswordLbl					=		'New Password';
Modules.LblsAndTtls.confirmNewPasswordLbl			=		'Confirm Password';
Modules.LblsAndTtls.portOrginialOrderLbl			=		'Original Order';
Modules.LblsAndTtls.portNewOrderLbl					=		'New Order';
Modules.LblsAndTtls.portCodeLbl						=		'Port Code';
Modules.LblsAndTtls.portNameLbl						=		'Port Name';
Modules.LblsAndTtls.delMarkedLbl					=		'Delete Marked';
Modules.LblsAndTtls.yesLbl							=		'Yes';
Modules.LblsAndTtls.noLbl							=		'No';
Modules.LblsAndTtls.dragReOrderLbl					=		'Drag and Drop to Reorganize';
Modules.LblsAndTtls.newLbl							=		'New';
Modules.LblsAndTtls.depotDestCdLbl					=		'Depot Dest Code';
Modules.LblsAndTtls.partyNmLbl						=		'Party Name';
Modules.LblsAndTtls.finacialIdLbl					=		'Financial ID';
Modules.LblsAndTtls.pcsPartyLbl						=		'Pcs Party';
Modules.LblsAndTtls.senderPartyLbl					=		'Sender Party';
Modules.LblsAndTtls.panNoLbl						=		'Pan No.';
Modules.LblsAndTtls.tanNoLbl						=		'Tan No.';
Modules.LblsAndTtls.residenceIndLbl					=		'Residence Ind';
Modules.LblsAndTtls.localAgentFlgLbl				=		'Local Agent Flag';
Modules.LblsAndTtls.taxExmptFlgLbl					=		'Tax Exmpt Flag';
Modules.LblsAndTtls.suspendFlgLbl					=		'Suspend Flag';
Modules.LblsAndTtls.invoiceAddrTtl					=		'Invoice Address';
Modules.LblsAndTtls.addressOneLbl					=		'Address';
Modules.LblsAndTtls.stateCountryLbl					=		'State,Country';
Modules.LblsAndTtls.telePhoneNo1Lbl					=		'Telephone Number1';
Modules.LblsAndTtls.telePhoneNo2Lbl					=		'Telephone Number2';
Modules.LblsAndTtls.faxNoLbl						=		'Fax Number';
Modules.LblsAndTtls.mobileNoLbl						=		'Mobile Number';
Modules.LblsAndTtls.financeEmailAddrLbl				=		'Finance E-mail Address';
Modules.LblsAndTtls.otherEmailAddrLbl				=		'Other E-mail Address';
Modules.LblsAndTtls.contactPsnAccLbl				=		'Contact Person Accounts';
Modules.LblsAndTtls.contactPsnOprnLbl				=		'Contact Person Operations';
Modules.LblsAndTtls.partyPaymentRmrksLbl			=		'Party/Payment Remark';
Modules.LblsAndTtls.emailFlgLbl						=		'E-mail';
Modules.LblsAndTtls.ediFlgLbl						=		'EDI';
Modules.LblsAndTtls.faxFlgLbl						=		'Fax';
Modules.LblsAndTtls.vslOprnAgentFlgLbl				=		'Vessel Operating Agent';
Modules.LblsAndTtls.chaCnFFlgLbl					=		'CHA/C&F';
Modules.LblsAndTtls.ctrOprnAgentFlgLbl				=		'Container Operating Agent';
Modules.LblsAndTtls.transporterFlgLbl				=		'Transporter';
Modules.LblsAndTtls.mloFlgLbl						=		'MLO';
Modules.LblsAndTtls.nvoccFlgLbl						=		'NVOCC';
Modules.LblsAndTtls.ctoFlgLbl						=		'Container Train Operator(CTO)';
Modules.LblsAndTtls.cfsFlgLbl						=		'Container Freight Station';
Modules.LblsAndTtls.importerFlgLbl					=		'Importer';
Modules.LblsAndTtls.exporterFlgLbl					=		'Exporter';
Modules.LblsAndTtls.bureaucrafFlgLbl				=		'Bureaucraf';
Modules.LblsAndTtls.financialDtlsTtl				=		'Financial Details';
Modules.LblsAndTtls.bankNmLbl						=		'Bank Name';
Modules.LblsAndTtls.bankAccNoLbl					=		'Bank Account Number';
Modules.LblsAndTtls.bankEmailAddrLbl				=		'Bank E-mail Address';
Modules.LblsAndTtls.documentRmrkLbl					=		'Document Remark';
Modules.LblsAndTtls.creditTermLbl					=		'Credit Term';
Modules.LblsAndTtls.bankGuaranteeLbl				=		'Bank Guarantee';
Modules.LblsAndTtls.creditLimitLbl					=		'Credit Limit';
Modules.LblsAndTtls.financialContractTtl			=		'Financial Contract';
Modules.LblsAndTtls.companyAddrTtl					=		'Company Address';
Modules.LblsAndTtls.msgConfirmedFlgFullTlt          =       'Message Confirmed Flag';
Modules.LblsAndTtls.invoiceAcceptFlgFullTlt         =       'Invoice Accept Flag';
Modules.LblsAndTtls.msgTransDateFullTlt             =       'Message Transaction Date';
Modules.LblsAndTtls.NonTaxableTlt                   =       'Non Taxable';
Modules.LblsAndTtls.misMatchReasonLbl               =       'Mismatch Reason';
Modules.LblsAndTtls.docRefNbrLbl                    =       'Document Reference Number';
Modules.LblsAndTtls.itemCdsiDescriptionLbl          =       'Item CDSI Description';
Modules.LblsAndTtls.itemCdsiDescription1Lbl         =        'Item CDSI Description1';
Modules.LblsAndTtls.itemCdsiDescription2Lbl         =        'Item CDSI Description2';
Modules.LblsAndTtls.itemCdsiInsidePkgLbl            =        'Item CDSI Inside Package';
/*********************************************************************************************************/
/*************************************===  End Generise Label and Titles  ===*****************************/
/*************************************************************************************By:- Ramanand kumar*/
//// restow,  rfr, oog, hz, dmg, hold,  curLocn, bdlId, imo, invcpty, invcRqdFlg.----> need to be discuss


/** tabs titles**/
Modules.LblsAndTtls.dashBoardTtl			        =		'Dashboard';
Modules.LblsAndTtls.custInvStatusTtl			    =		'Customer Invoice Status';
Modules.LblsAndTtls.custInvStatusOceanTtl			=		'Customer Invoice Status Ocean';
Modules.LblsAndTtls.custReconStatusTtl			    =	    'Customer Reconciliation Status';
Modules.LblsAndTtls.ediErrMessageTtl			    =	    'EDI Error Message';
Modules.LblsAndTtls.splMovesStatusTtl			    =	    'Special Moves Status';
Modules.LblsAndTtls.suppInvoiceStatusTtl			=	    'Supplier Invoice Status';
Modules.LblsAndTtls.suppReconStatusTtl			    =       'Supplier Reconciliation Status';
Modules.LblsAndTtls.oceanDBCustReconStatusTtl	    =       'Customer Reconciliation Status';
Modules.LblsAndTtls.swimPartnerDtlsTtl			    =       'SWIM-Partner Details';
Modules.LblsAndTtls.swimPartnerConfigTtl			=       'Partner Configuration';
Modules.LblsAndTtls.swimProcessAdminiStrationTtl    =       'Process Administration';
Modules.LblsAndTtls.swimSendMsgAgrmtDtlsTtl			=       'Send Message Agreement Details';
Modules.LblsAndTtls.swimSendMsgAgrmtConfigTtl		=       'Send Message Aggrement Configuration';
Modules.LblsAndTtls.swimGrpPartnerConfigTtl		    =       'Group Partner Mapping Configuration';
Modules.LblsAndTtls.swimGrpPartnerTabTtl			=       'Group Partner Mapping Configuration';
Modules.LblsAndTtls.pendingProformaStatusTtl        =       'Pending Proforma Tab Ocean';
Modules.LblsAndTtls.pendingFinalStatusTtl           =       'Pending Finalisation Ocean';
Modules.LblsAndTtls.exceptionsTabTtl                =       'Exceptions Ocean';
Modules.LblsAndTtls.ediErrorTabTtl                  =       'EDI Error Tab Ocean';
Modules.LblsAndTtls.ediErrorMesTtl                  =       'EDI Error Message Ocean';
Modules.LblsAndTtls.backGroundJobsGridRecordTtl		=		'Background Jobs';
Modules.LblsAndTtls.displayJobNameTlt				=		'Job Name';
Modules.LblsAndTtls.displayStartDateTlt				=		'Start Date';
Modules.LblsAndTtls.displayRepeatIntervalTlt		=		'Repeat Interval';
Modules.LblsAndTtls.displayStatusTlt				=		'Status';
Modules.LblsAndTtls.viewBackGroundJobsFormTlt		=		'Background Jobs';
Modules.LblsAndTtls.backGroundJobsComboTlt			=		'Job ID';
Modules.LblsAndTtls.backGroundJobsDescTlt			=		'Job Description';
Modules.LblsAndTtls.firstButtonTlt					=		'First';
Modules.LblsAndTtls.previousButtonTlt				=		'Previous';
Modules.LblsAndTtls.nextButtonTlt					=		'Next';
Modules.LblsAndTtls.lastButtonTlt					=		'Last';
Modules.LblsAndTtls.displayingRecordTlt				=		'Displaying Record';

Modules.LblsAndTtls.originLocStProv                 =     'Origin/Location State Province';
Modules.LblsAndTtls.originLocStProvAbb              =     'Origin/Loc. St/Prov';
Modules.LblsAndTtls.PriorityTlt                     =     'Priority';
Modules.LblsAndTtls.codeLbl                            =      'Code';
Modules.LblsAndTtls.podCodeLbl                      = 'POD Code';
Modules.LblsAndTtls.podDescLbl                      = 'POD Description';
Modules.LblsAndTtls.pfdDescLbl                      = 'PFD Description';
Modules.LblsAndTtls.fixedRate                        =    'Fixed Rate';
Modules.LblsAndTtls.variableCmp                      =    'Variable Components';
Modules.LblsAndTtls.variableCmp1                      =    'Variable Component';
Modules.LblsAndTtls.moveStatusTlt	                =     'Move Status';
Modules.LblsAndTtls.originStateProvince1Tlt          =    'Origin S/P';
Modules.LblsAndTtls.originStateProvinceFullTlt      =      'Origin State/Province';
Modules.LblsAndTtls.eventDateTlt                    =       'Event Date';
Modules.LblsAndTtls.supplierStatusTlt               =       'Supplier Status';
Modules.LblsAndTtls.customerStatusTlt               =       'Customer Status';
Modules.LblsAndTtls.moveReferenceTlt                =       'Move Ref';
Modules.LblsAndTtls.moveReferenceFullTlt            =       'Move Reference';
Modules.LblsAndTtls.requestorTlt                    =       'Requestor';
Modules.LblsAndTtls.customerReferenceTlt            =       'Customer Ref';
Modules.LblsAndTtls.customerReferenceFullTlt        =       'Customer Reference';
Modules.LblsAndTtls.departmentTlt                   =       'Department';
Modules.LblsAndTtls.blankTlt                        =       'Blank';
Modules.LblsAndTtls.sepcialMoveQueryTlt             =       'Special Move Query';
Modules.LblsAndTtls.statusMonitorAndControlTlt      =       'Status Monitoring and Control';
Modules.LblsAndTtls.tenderDateTlt                   =       'Tender Date';
Modules.LblsAndTtls.shipmentDateTlt                 =       'Shipment Date';
Modules.LblsAndTtls.deliveryDateTlt                 =       'Delivery Date';
Modules.LblsAndTtls.completionDateTlt               =       'Completion Date';
Modules.LblsAndTtls.makeTlt                         =       'Make';
Modules.LblsAndTtls.modelTlt                        =       'Model';
Modules.LblsAndTtls.modelYearTlt                    =       'Model Year';
Modules.LblsAndTtls.modelDescrptionTlt              =       'Model Description';
Modules.LblsAndTtls.modelDescrTlt       			=       'Model Desc';

Modules.LblsAndTtls.customerSalesRegionTlt          =       'Customer Sales Region';
Modules.LblsAndTtls.customerSalesRegionTltMandatory =       'Customer Sales Region<span style="color: red">*</span>';
Modules.LblsAndTtls.cstmrSalesRegnTlt     		    =       'Cust Sales Regn';
Modules.LblsAndTtls.customerSalesRegionPartTlt		=		'Customer Sales';
Modules.LblsAndTtls.rateTierTlt                     =        'Rate Tier';
Modules.LblsAndTtls.conveyanceTypeTlt               =         'Conveyance Type';
Modules.LblsAndTtls.orderTypeTlt                    =         'Order Type';
Modules.LblsAndTtls.abnormalMoveTypeTlt        	    =         'Abnormal Move';
Modules.LblsAndTtls.abnormalMoveTypeFullTlt         =         'Abnormal Move Type';
Modules.LblsAndTtls.abnorMoveTypeTlt            	=         'Ab Move Type';
Modules.LblsAndTtls.dealerCodeTlt                   =         'Dealer Code';
Modules.LblsAndTtls.originalOrginTlt                =         'Original Origin';                  
Modules.LblsAndTtls.finalDestinationTlt             =         'Final Destination';
Modules.LblsAndTtls.finalDestTlt            		=         'Final Dest';
Modules.LblsAndTtls.fuelSurchargeApplicableTlt      =         'Fuel Surcharge Applicable';
Modules.LblsAndTtls.fuelSurchargeApplicablePartTlt  =         'Fuel Surcharge';
Modules.LblsAndTtls.sepcialMoveEntryTlt             =         'Special Move Entry';
Modules.LblsAndTtls.popupspecialMoveQueryGridTlt	=		  'Special Move Query Grid Record';
Modules.LblsAndTtls.serviceType					    =		  'Service Type ID';
Modules.LblsAndTtls.additionalServicesCommentsTlt	=		'Additional Services/Comments';
Modules.LblsAndTtls.additionalServicesCommentsShortTlt	=		'Add Srvs/Comments';
Modules.LblsAndTtls.InsertActionTlt					=		'Insert';

Modules.LblsAndTtls.originAddrLine1 = 'Origin Address Line1';
Modules.LblsAndTtls.originAddrLine2 = 'Origin Address line2';

Modules.LblsAndTtls.mailingAddressLbl               = 'Mailing Address 1';
Modules.LblsAndTtls.mailingAddressAbbLbl            = 'Mailing Addr 1';

Modules.LblsAndTtls.mailingAddress2Lbl               = 'Mailing Address 2';
Modules.LblsAndTtls.mailingAddress2AbbLbl            = 'Mailing Addr 2';

Modules.LblsAndTtls.mailingAddress3Lbl               = 'Mailing Address 3';
Modules.LblsAndTtls.mailingAddress3AbbLbl            = 'Mailing Addr 3';

Modules.LblsAndTtls.mailingCityNmLbl                 = 'Mailing City Name';
Modules.LblsAndTtls.mailingCityNmAbbLbl                 = 'Mailing City Nm';

Modules.LblsAndTtls.mailingStateCdLbl                 = 'Mailing State Code';
Modules.LblsAndTtls.mailingCityNmAbbLbl                 = 'Mailing State Cd';

Modules.LblsAndTtls.mailingPoBoxLbl                 = 'Mailing PO-BOX';

Modules.LblsAndTtls.mailingCountryCdLbl                 = 'Mailing Cntry Cd';
Modules.LblsAndTtls.mailingCountryCdAbbLbl                 = 'Mailing Country Code';


Modules.LblsAndTtls.invcEmailAddressLbl               ='Invoice Email Address';
Modules.LblsAndTtls.invcEmailAddressAbb               = 'Invc Email Addr';
Modules.LblsAndTtls.totalInvcAmtCurrAbbLbl           =       'Invc Amt USD Curr'; 
Modules.LblsAndTtls.totalInvcAmtUsdCurrTlt             =       'Total Invc Amt Curr';
Modules.LblsAndTtls.totalInvcAmtCurrTltFull         =       'Total Invoice Amount USD Currency'; 
Modules.LblsAndTtls.copyFromActionTtl				=		'Copy';
Modules.LblsAndTtls.deSelectAllActionTtl			=		'De-select All';
Modules.LblsAndTtls.selectAllActionTtl				=		'Select All';
Modules.LblsAndTtls.eventStatusTtl					=		'Event Status Query';

Modules.LblsAndTtls.supplier						=		'Supplier';
Modules.LblsAndTtls.customer						=		'Customer';
Modules.LblsAndTtls.serviceType						=		'Service Type';
Modules.LblsAndTtls.serviceCode						=		'Service Code';
Modules.LblsAndTtls.Make							=		'Make';
Modules.LblsAndTtls.MakeMandatory					=		'Make Code<span style="color: red">*</span>';
Modules.LblsAndTtls.Model							=		'Model';

Modules.LblsAndTtls.ModelCode						=		'Model Code';
Modules.LblsAndTtls.ModelCodeMandatory				=		'Model Code<span style="color: red">*</span>';
Modules.LblsAndTtls.PartID                          =       'Part ID';
Modules.LblsAndTtls.orignLocCity                    =       'Origin/Location City';
Modules.LblsAndTtls.eventDateType                   =       'Event Date Type',
Modules.LblsAndTtls.ModelGroup						=		'Model Group';
Modules.LblsAndTtls.TransportMode					=		'Transport Mode';
Modules.LblsAndTtls.eventDate						=		'Event Date Type';
Modules.LblsAndTtls.consolidationType				=		'Consolidation Type';
Modules.LblsAndTtls.origin							=		'Origin';
Modules.LblsAndTtls.originStateProvince				=		'Origin State/Prov';
Modules.LblsAndTtls.destination						=		'Destination';
Modules.LblsAndTtls.destinationStateProvince		=		'Dest State/Prov';
Modules.LblsAndTtls.dealerCode						=		'Dealer Code';
Modules.LblsAndTtls.OrderType						=		'Order Type';
Modules.LblsAndTtls.shipmentType					=		'Shipment Type';
Modules.LblsAndTtls.AbnormalMoveType				=		'Abnormal Move Type';
Modules.LblsAndTtls.msgProStscode					=		'Msg Pro Sts Code';
Modules.LblsAndTtls.ConveyanceType					=		'Conveyance Type';
Modules.LblsAndTtls.unitId							=		'Unit ID';
Modules.LblsAndTtls.fromDate						=		'From Date';
Modules.LblsAndTtls.toDate							=		'To Date';
Modules.LblsAndTtls.consolidationId					=		'Consolidation ID';
Modules.LblsAndTtls.eventLoadReference				=		'Event/Load Ref';
Modules.LblsAndTtls.shippingReference				=		'Shipping Ref';
Modules.LblsAndTtls.originCity						=		'Origin City';
Modules.LblsAndTtls.destinationCity					=		'Destination City';
Modules.LblsAndTtls.transportCode					=		'Transport Code';
Modules.LblsAndTtls.workOrder						=		'Work Order';
Modules.LblsAndTtls.conveyanceName					=		'Conveyance Name';
Modules.LblsAndTtls.shipmentType					=		'Shipment Type';
Modules.LblsAndTtls.conveyanceId					=		'Conveyance ID';
Modules.LblsAndTtls.Blank							=		'Blank';

Modules.LblsAndTtls.OrginStateProvFullLbl           =       'Origin State/Province';
Modules.LblsAndTtls.OriginZIPPostalCodeAbbLbl       =       'Origin Z/P Code';

Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier';
Modules.LblsAndTtls.ratingDestTlt                   =       'Rating Destination';
Modules.LblsAndTtls.originalOriginTlt               =       'Original Origin';
Modules.LblsAndTtls.finalDestTlt                    =       'Final Destination'; 
Modules.LblsAndTtls.finDestTlt                    	=       'Final Dest'; 
Modules.LblsAndTtls.varianceEvntTlt                 =       'Variance Event';
Modules.LblsAndTtls.originStateProvinceTlt          =       'Origin State Prov';
Modules.LblsAndTtls.destinationStateProvinceTlt     =       'Dest State Prov';   
Modules.LblsAndTtls.destinationSPTlt				=		'Destination S/P';
Modules.LblsAndTtls.customerStatusTlt               =       'Customer Status';
Modules.LblsAndTtls.profitLossCenter				=		'Profit/Loss Center';
Modules.LblsAndTtls.DebtorParty						=		'Debtor Party';
Modules.LblsAndTtls.supplierStatus					=		'Supplier Status';
Modules.LblsAndTtls.customerStatus					=		'Customer Status';
Modules.LblsAndTtls.originalOrigin					=		'Original Origin';
Modules.LblsAndTtls.RatingDestination				=		'Rating Destination';
Modules.LblsAndTtls.finalDestination				=		'Final Destination';
Modules.LblsAndTtls.VarianceEvent					=		'Variance Event';
Modules.LblsAndTtls.ServiceGroup					=		'Service Group';

Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier';
Modules.LblsAndTtls.country                         =       'Country';
Modules.LblsAndTtls.exportTlt                       =       'Export';
Modules.LblsAndTtls.dutyPaidTlt                     =       'Duty Paid';
Modules.LblsAndTtls.tIBNbrTlt                       =       'TIB No.';
Modules.LblsAndTtls.tIBNbrFullTlt                   =       'TIB Number';
Modules.LblsAndTtls.tIBExpirationDate				=		'TIB Expire Date';
Modules.LblsAndTtls.tIBExpirationDateFullTlt        =       'TIB Expiration Date';
Modules.LblsAndTtls.requestPickUpDateTlt     	    =       'Pickup Date';
Modules.LblsAndTtls.requestPickUpDateFullTlt        =       'Requested Pickup Date';
Modules.LblsAndTtls.requestDeliveryDateTlt          =       'Delivery Date';
Modules.LblsAndTtls.requestDeliveryDateFullTlt      =       'Requested Delivery Date';
Modules.LblsAndTtls.pickupInfoTlt                   =       'Pickup Info';
Modules.LblsAndTtls.pickupInfoFullTlt               =       'Pickup Infomation';
Modules.LblsAndTtls.deliveryInfoTlt                 =		'Delivery Info';
Modules.LblsAndTtls.deliveryInfoFullTlt    			=		'Delivery Information';
Modules.LblsAndTtls.contactNameTlt 					=		'Contact Name';
Modules.LblsAndTtls.distanceTlt 					=		'Distance';
Modules.LblsAndTtls.destinationDetailsTLt           =       'Destination Details';
Modules.LblsAndTtls.originDetailsTLt                =       'Origin Details';
Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier';
Modules.LblsAndTtls.customerRatingTlt               =		'Customer Rating';
Modules.LblsAndTtls.supplierRatingTlt               =		'Supplier Rating';
Modules.LblsAndTtls.notChargeableTlt				=  		'Not Chargeable'; 
Modules.LblsAndTtls.expenseCodeTlt					=		'Expense Code';
Modules.LblsAndTtls.serviceAmountTlt				=		'Service Amount';
Modules.LblsAndTtls.taxAmountTlt					=		'Tax Amount';
Modules.LblsAndTtls.glCodeTlt						=		'GL Code';
Modules.LblsAndTtls.serviceDescriptionTlt			=		'Service Description';
Modules.LblsAndTtls.specialMoveQueryScreenIdTlt		=		'Special Move Query';
Modules.LblsAndTtls.notTaxableTlt                   =       'Not Taxable';
Modules.LblsAndTtls.markUpTlt                       =       'Mark Up';
Modules.LblsAndTtls.markUpCriteria                  =       'Mark Up Criteria';
Modules.LblsAndTtls.markUpVal                       =       'Mark Up Value';
Modules.LblsAndTtls.programTlt                      =       'Program';
Modules.LblsAndTtls.indexTlt                        =       'Index';
Modules.LblsAndTtls.invcdTlt                        =       'INVCD';
Modules.LblsAndTtls.rejectTlt                       =       'REJECT';

Modules.LblsAndTtls.SupplrEvntStsSummTlt            =       'Supplier Event Status Summary';
Modules.LblsAndTtls.SupplrInvcStsTtl                =       'Supplier Invoice Status';
Modules.LblsAndTtls.SupplrInvcStsOceanTtl           =       'Supplier Invoice Status Ocean';

Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary';
Modules.LblsAndTtls.serviceGroupCodeTlt				=		'Service Group Code';
Modules.LblsAndTtls.debatoryPartyCodeTlt			=       'Debtor Party Code';



Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary';

Modules.LblsAndTtls.CustomerRateQueryGridRecord     =       'Customer Rate Query Grid Record';
Modules.LblsAndTtls.CustomerRateQrySrvCd            =       'Customer Rate Query Service Code';
Modules.LblsAndTtls.Name            				=       'Name';
Modules.LblsAndTtls.ContractId            			=       'Contract ID';
Modules.LblsAndTtls.ServiceCode            			=       'Service Code';

Modules.LblsAndTtls.originLocationFullTtl           =       'Origin/Location';
Modules.LblsAndTtls.totalQtyFullTlt                 =       'Total Quantity';
Modules.LblsAndTtls.totalStrgQtyFullTlt             =       'Total Storage Quantity';
Modules.LblsAndTtls.totalSrvcAmtFullTlt             =       'Total Service Amount';
Modules.LblsAndTtls.totalTaxAmtFullTlt              =       'Total Tax Amount';
Modules.LblsAndTtls.srvcGrpCdFullTtl                =       'Service Group Code';
Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary';

Modules.LblsAndTtls.totalSrvcAmtAbb                 =       'Total Srvc Amt';

Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary';

Modules.LblsAndTtls.prevChrgdQtyTlt   			    =       'Prev Chrgd Qty';
Modules.LblsAndTtls.prevChrgdUomCodeTlt   			=       'Prev Chrgd UOM';
Modules.LblsAndTtls.quantityTlt   					=       'Quantity';
Modules.LblsAndTtls.storageQuantityTlt   			=       'Storage Quantity';
Modules.LblsAndTtls.storageUomCodeTlt   			=       'Storage UOM';

Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary';
Modules.LblsAndTtls.CustmrRateQueryGridTtl			=		'Customer Rate Query Grid Record';
Modules.Customer.CustomerRateVerificatoin.customerName =    'Customer Name';
Modules.Customer.CustomerRateVerificatoin.effectiveDate =   'Effective Date';
Modules.Customer.CustomerRateVerificatoin.originCity    =  'Origin City';
Modules.Customer.CustomerRateVerificatoin.partCode =        'Part Code';
Modules.Customer.CustomerRateVerificatoin.destination = 'Destination';
Modules.Customer.CustomerRateVerificatoin.distinationCity='Destination City';
Modules.Customer.CustomerRateVerificatoin.destinationStateProvince='Destination State/Province';
Modules.Customer.CustomerRateVerificatoin.modelYear='Model Year';
Modules.Customer.CustomerRateVerificatoin.originalOrigin = 'Original Origin';
Modules.LblsAndTtls.serviceGrpDescription                  =       'Service Group Description';
Modules.LblsAndTtls.serviceCdDescription                  	=       'Service Description';


/*********************************************************************************************/
     //  DYNAMIC MENU SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.headerCompany				    =	'Company';
Modules.LblsAndTtls.headerServiceType				=	'Service Type';
Modules.LblsAndTtls.headerLanguage					=	'Language';
Modules.LblsAndTtls.headerVersion				    =	'Version';
Modules.LblsAndTtls.headerWelcome				    =	'Welcome';
Modules.LblsAndTtls.headerHelp				        =	'Help';
Modules.LblsAndTtls.headerLogout			        =	'Logout';
Modules.LblsAndTtls.headerFAPS			            =	'FAPS';

/*********************************************************************************************/
//  DYNAMIC MENU SCREEN LABELS : END
/*********************************************************************************************/




/*********************************************************************************************/
//  CUSTOMER RATE QUERY SERVICE CODE SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.trnsptModeFull						=   'Transport Mode';
Modules.LblsAndTtls.serviceDescrFull				=	'Service Description';
Modules.LblsAndTtls.serviceDescr			         =	'Service Desc';
Modules.LblsAndTtls.trnsptMode				         =	'Trnspt Mode';
Modules.LblsAndTtls.originLocation					 =  'Origin/Location';
Modules.LblsAndTtls.makeCode			     	 	 =  'Make Code';
Modules.LblsAndTtls.partId				     	 	 =  'Part ID';
Modules.LblsAndTtls.originLocCity					 =  'Origin/Loc City';
Modules.LblsAndTtls.originLocStateProv	     	 	 =  'Origin/Loc State/Prov';
Modules.LblsAndTtls.destStateProv		     	 	 =  'Destination State/Prov';
Modules.LblsAndTtls.originalOrigin		     	 	 =  'Original Origin';
Modules.LblsAndTtls.finalDest			     	 	 =  'Final Destination';
Modules.LblsAndTtls.consolidationTypeCode     	 	 =  'Consolidation Type Code';
Modules.LblsAndTtls.markup				     	 	 =  'Mark Up';
Modules.LblsAndTtls.markupCriteria		     	 	 =  'Mark Up Criteria';
Modules.LblsAndTtls.markUpValue				     	 =  'Mark Up Value';
Modules.LblsAndTtls.factorValue				     	 =  'Factor Value';
Modules.LblsAndTtls.factorType			     	 	 =  'Factor Type';
Modules.LblsAndTtls.factorRate			     	 	 =  'Factor Rate';
Modules.LblsAndTtls.program				     	 	 =  'Program';
Modules.LblsAndTtls.index				     	 	 =  'Index';
Modules.LblsAndTtls.fixedRate			     	 	 =  'Fixed Rate';
Modules.LblsAndTtls.luInd				     	 	 =  'L/U Ind';
Modules.LblsAndTtls.tariffCurrCd		     	 	 =  'Tariff Currency Code';
Modules.LblsAndTtls.composite			     	 	 =  'Composite';
Modules.LblsAndTtls.nonTaxable			     	 	 =  'Non Taxable';
Modules.LblsAndTtls.priority			     	 	 =  'Priority';



/*********************************************************************************************/
//CUSTOMER RATE QUERY SERVICE CODE SCREEN LABELS : END
/*********************************************************************************************/




/*********************************************************************************************/
//EVENT STATUS QUERY SCREEN LABELS : BEGIN
/*********************************************************************************************/

Modules.LblsAndTtls.eventLoadRef		         =	'Event/Load Reference';
Modules.LblsAndTtls.originLocation		         =	'Origin Location';
Modules.LblsAndTtls.tenderRqstDt		         =	'Tender/Request Date';
Modules.LblsAndTtls.delivaryCmplDt		         =	'Delivery/Completion Date';
Modules.LblsAndTtls.storageQty			         =	'Storage Qty';
Modules.LblsAndTtls.storageUom			         =	'Storage UOM';
Modules.LblsAndTtls.previousChrgQty		         =	'Previous Charge Qty';
Modules.LblsAndTtls.previousChrgQuantity		 =	'Previous Charge Quantity';
Modules.LblsAndTtls.prevChrgUom			         =	'Previous Charge UOM';
Modules.LblsAndTtls.workOrderNumber		         =	'Work Order Number';
Modules.LblsAndTtls.copyBtnTtl			         =	'Copy';
Modules.LblsAndTtls.pasteBtnTtl			         =	'Paste';

Modules.LblsAndTtls.tenderRequestDt				 =  'Tender/Rqst Date';
Modules.LblsAndTtls.delivaryCmplDate		     =	'Dlvry/Cmpltn Date';
Modules.LblsAndTtls.cstmrSalesRgn			     =	'Customer Sales Rgn';
Modules.LblsAndTtls.prevChrgQty				     =	'Prev Charge Qty';
Modules.LblsAndTtls.previousChrgUom			     =	'Prev Charge UOM';
Modules.LblsAndTtls.wrkOrdrNbr					 =  'Work Order Number';	
Modules.LblsAndTtls.tdrRqstDt					 =  'Tdr/Rqst Date';	



/*********************************************************************************************/
//EVENT STATUS QUERY SCREEN LABELS : END
/*********************************************************************************************/
/*********************************************************************************************/
//QUARTZ JOB DETAILS SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.edi.SwimUI.quartz_job_dtls.labels.qrtzJobDtlsTtl	 			= 'Quartz Job Details';
Modules.edi.SwimUI.quartz_job_dtls.labels.taskDtlsTtl		 			= 'Task Details';
Modules.edi.SwimUI.quartz_job_dtls.labels.qrtzFiredTriggersDtlsTtl		= 'Quartz Fired Triggers';
Modules.edi.SwimUI.quartz_job_dtls.labels.qrtzTriggersDtlsTtl		 	=  Modules.edi.SwimUI.quartz_job_dtls.labels.qrtzJobDtlsTtl+' - UnRecoverable Jobs';
Modules.edi.SwimUI.quartz_job_dtls.labels.triggerGrp					= 'Trigger Group';
Modules.edi.SwimUI.quartz_job_dtls.labels.jobName						= 'Job Name';
Modules.edi.SwimUI.quartz_job_dtls.labels.triggerState					= 'Trigger State';
Modules.edi.SwimUI.quartz_job_dtls.labels.entryId						= 'Entry ID';
Modules.edi.SwimUI.quartz_job_dtls.labels.triggerName					= 'Trigger Name';
Modules.edi.SwimUI.quartz_job_dtls.labels.instanceName					= 'Instance Name';
Modules.edi.SwimUI.quartz_job_dtls.labels.state							= 'State';
Modules.edi.SwimUI.quartz_job_dtls.labels.taskId						= 'Task ID';
Modules.edi.SwimUI.quartz_job_dtls.labels.taskName						= 'Task Name';
Modules.edi.SwimUI.quartz_job_dtls.labels.status						= 'Status';
Modules.edi.SwimUI.quartz_job_dtls.labels.prgmName						= 'Program Name';

/*********************************************************************************************/
//QUARTZ JOB DETAILS SCREEN LABELS : END
/*********************************************************************************************/











/*********************************************************************************************/
//  CUSTOMER INVOICE ENTRY SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.cstmrInveEntryTtl				    =	'Customer Invoice Entry';
Modules.LblsAndTtls.finalizeActionTtl					= 	'Finalize';
Modules.LblsAndTtls.rejectActionTtl						=	'Reject';
Modules.LblsAndTtls.copyInvioceActionTtl				= 	'Copy Invoice';
Modules.LblsAndTtls.viewInvoiceActionTtl				=	'View Invoice';
Modules.LblsAndTtls.viewBackupActionTtl					= 	'View Backup';
Modules.LblsAndTtls.invoiceNumberGP						= 	'Invoice Number';
Modules.LblsAndTtls.invoiceRefNumberGP					= 	'Reference Invoice Number';
Modules.LblsAndTtls.invoiceDateGP						= 	'Invoice Date';
Modules.LblsAndTtls.invoiceDueDateGP					= 	'Invoice Due Date';
Modules.LblsAndTtls.currencyGP							= 	'Currency';
Modules.LblsAndTtls.profitLossCentreGP					= 	'Profit/Loss Center';
Modules.LblsAndTtls.printTemplateGP						= 	'Print Template';
Modules.LblsAndTtls.statusGP							= 	'Status';
Modules.LblsAndTtls.remarksGP							= 	'Remarks';
Modules.LblsAndTtls.docTypeGP							= 	'Document Type';
Modules.LblsAndTtls.invcTypeGP							= 	'Invoice Type';
Modules.LblsAndTtls.paymentDtlsGP						= 	'Payment Details';
Modules.LblsAndTtls.partyGP								= 	'Party';
Modules.LblsAndTtls.nameGP								= 	'Name';
Modules.LblsAndTtls.addLane1GP							= 	'Address Line 1';
Modules.LblsAndTtls.addLane2GP							= 	'Address Line 2';
Modules.LblsAndTtls.cityGP								= 	'City';
Modules.LblsAndTtls.stateProvGP							= 	'State/Prov';
Modules.LblsAndTtls.countryGP							= 	'Country';
Modules.LblsAndTtls.zipPostalCdGP						= 	'Zip/Postal Code';
Modules.LblsAndTtls.srvCodePG							= 	'Service Code';
Modules.LblsAndTtls.srvDescPG							= 	'Service Description';
Modules.LblsAndTtls.srvcGrpPG							= 	'Service Group';
Modules.LblsAndTtls.evntLdRefPG							= 	'Event/Load Reference';
Modules.LblsAndTtls.unitIdPG							= 	'Unit ID';
Modules.LblsAndTtls.convncIdPG							= 	'Conveyance ID';
Modules.LblsAndTtls.convncTypePG						= 	'Conveyance Type';
Modules.LblsAndTtls.convncNmPG							= 	'Conveyance Name';
Modules.LblsAndTtls.shipngRefNoPG						= 	'Shipping Ref No.';
Modules.LblsAndTtls.transptCdPG							= 	'Transport Code';
Modules.LblsAndTtls.makeCdPG							= 	'Make Code';
Modules.LblsAndTtls.modelCdPG							= 	'Model Code';
Modules.LblsAndTtls.modelGrpPG							= 	'Model Group';
Modules.LblsAndTtls.modelYearPG							= 	'Model Year';
Modules.LblsAndTtls.trnsptModePG						= 	'Transport Mode';
Modules.LblsAndTtls.rateTierPG							= 	'Rate Tier';
Modules.LblsAndTtls.wrkOrderPG							= 	'Work Order';
Modules.LblsAndTtls.partIdPG							= 	'Part ID';
Modules.LblsAndTtls.orgnLocPG							= 	'Origin/Location';
Modules.LblsAndTtls.orgnAdd1PG							= 	'Origin Address 1';
Modules.LblsAndTtls.orgnAdd2PG							= 	'Origin Address 2';
Modules.LblsAndTtls.orgnLocCtyPG						= 	'Origin/Location City';
Modules.LblsAndTtls.orgnLocStPPG						= 	'Origin/Location State/Prov';
Modules.LblsAndTtls.orgnZipPostalCdPG					= 	'Origin Zip/Postal Code';
Modules.LblsAndTtls.destCdPG							= 	'Destination Code';
Modules.LblsAndTtls.destAdd1PG							= 	'Destination Address 1';
Modules.LblsAndTtls.destAdd2PG							= 	'Destination Address 2';
Modules.LblsAndTtls.destCityPG							= 	'Destination City';
Modules.LblsAndTtls.destStateProvPG						= 	'Destination State/Prov';
Modules.LblsAndTtls.destZipPostalCdPG					= 	'Destination Zip/Postal Code';
Modules.LblsAndTtls.destCountryCdPG					    = 	'Destination Country Code';
Modules.LblsAndTtls.tndrReqDtPG							= 	'Tender/Request Date';
Modules.LblsAndTtls.shipntDtPG							= 	'Shipment Date';
Modules.LblsAndTtls.delCmpltDtPG						= 	'Delivery/Completion Date';
Modules.LblsAndTtls.origOrgPG							= 	'Original Origin';
Modules.LblsAndTtls.finalDestPG							= 	'Final Destination';
Modules.LblsAndTtls.dist2DestPG							= 	'Distance To Destination';
Modules.LblsAndTtls.valPG								= 	'Value';
Modules.LblsAndTtls.UomPG								= 	'UOM';
Modules.LblsAndTtls.ratingDestPG						= 	'Rating Destination';
Modules.LblsAndTtls.dist2RtngDestPG						= 	'Distance To Rating Destination';
Modules.LblsAndTtls.minNumPG							= 	'Minimum Number';
Modules.LblsAndTtls.prftLossCentPG						= 	'Profit/Loss Center';
Modules.LblsAndTtls.custSlsRgnPG						= 	'Customer Sales Region';
Modules.LblsAndTtls.shmntTypePG							= 	'Shipment Type';
Modules.LblsAndTtls.ordrTypPG							= 	'Order Type';
Modules.LblsAndTtls.abnrmMvTypePG						= 	'Abnormal Move Type';
Modules.LblsAndTtls.dlrCdPG								= 	'Dealer Code';
Modules.LblsAndTtls.suplrCdPG							= 	'Supplier Code';
Modules.LblsAndTtls.consolIdPG							= 	'Consolidation ID';
Modules.LblsAndTtls.consolTypePG						= 	'Consolidation Type';
Modules.LblsAndTtls.uom1PG								= 	'UOM 1';
Modules.LblsAndTtls.uom2PG								= 	'UOM 2';
Modules.LblsAndTtls.qntty1PG							= 	'Quantity 1';
Modules.LblsAndTtls.qntty2PG							= 	'Quantity 2';
Modules.LblsAndTtls.rtbsisPG							= 	'Rate Basis';
Modules.LblsAndTtls.ratePG								= 	'Rate';
Modules.LblsAndTtls.srvcAmtPG							= 	'Service Amount';
Modules.LblsAndTtls.taxTypChG							= 	'Tax Type';
Modules.LblsAndTtls.taxPercntChG						= 	'Tax Percentage';
Modules.LblsAndTtls.taxAmtChG							= 	'Tax Amount';
Modules.LblsAndTtls.custInvcEntryTotSrvcAmt				= 	'Total Service Amount';
Modules.LblsAndTtls.custInvcEntryTotTaxAmt				= 	'Total Tax Amount';
Modules.LblsAndTtls.custInvcEntryTotAmt					= 	'Total Amount';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormTtl			= 	Modules.LblsAndTtls.cstmrInveEntryTtl;
Modules.LblsAndTtls.cstmrInveEntryPopUpFormInvoiceTlt	=	'Invoice';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormCrdtNote		= 	'Credit Note';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormDbtNote		=	'Debit Note';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormDocTypeTtl	= 	'Document Type';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormInvcTypeTtl	= 	'Invoice Type';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormActual		=	'Actual';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormAcrual		=	'Accrual';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormPaymentDtlsTtl 	=	'Payment Details';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormCurrencyTtl 		= 	'Currency';
/*********************************************************************************************/
//CUSTOMER INVOICE ENTRY SCREEN LABELS : END
/*********************************************************************************************/




Modules.LblsAndTtls.cstmrSrvGrpConfigurationGridTlt =       'Customer Service Group Grid Configuration';

Modules.LblsAndTtls.cstmrSrvTypeConfigurationGridTlt=		'Customer Service Type Code Grid Configuration';

/*********************************************************************************************/
//Dashboard SCREEN LABELS : START
/*********************************************************************************************/

Modules.LblsAndTtls.InvLineItmAgngOnDueDate =       'Invoice Line Item Aging On Due Date';
Modules.LblsAndTtls.pastDueTlt =       'Past Due';
Modules.LblsAndTtls.amountTlt =       'Amount';
Modules.LblsAndTtls.dueIn0To5DaysTlt  =       'Due in 0-5 Days';
Modules.LblsAndTtls.dueIn6To15DaysTlt  =       'Due in 6-15 Days';
Modules.LblsAndTtls.dueIn16To30DaysTlt  =       'Due in 16-30 Days';
Modules.LblsAndTtls.dueInGrtrThan30DaysTlt  =       'Due in >30 Days';
Modules.LblsAndTtls.countTlt  =       'Count';
Modules.LblsAndTtls.exchangeRateLbl ='Exchange Rate';
Modules.LblsAndTtls.cstmrSrvTypeConfigurationGridTlt=		'Customer Service Type Code Grid Configuration';


/***********************************************************************/
//#CUSTOMER_RATE_QUERY
/***********************************************************************/

Modules.contract.customer_rate_query.labels.formTitle	=	'Customer Rate Query';
Modules.contract.customer_rate_query.labels.customer	=	'Customer';
Modules.contract.customer_rate_query.labels.customerCode=	'Customer Code';
Modules.contract.customer_rate_query.labels.companyCode =	'Company Code';
Modules.contract.customer_rate_query.labels.name		=	'Name';
Modules.contract.customer_rate_query.labels.customerName=	'Customer Name';
Modules.contract.customer_rate_query.labels.contractId	=	'Contract ID';
Modules.contract.customer_rate_query.labels.fromDate	=	'From Date'	;
Modules.contract.customer_rate_query.labels.toDate		=	'To Date';
Modules.contract.customer_rate_query.labels.validFrom	=	'Valid From';
Modules.contract.customer_rate_query.labels.validTo		=	'Valid To';







/***********************************************************************/
//#GENERAL_MASTERS
/***********************************************************************/
Modules.Masters.General_Master.labels.showPartnerBtn = 'Show Partners';
Modules.Masters.General_Master.labels.partnerGroupCode = 'Partner Group Code';
Modules.Masters.General_Master.labels.partnerGroupName = 'Partner Group Name';
Modules.Masters.General_Master.labels.code = 'Code';
Modules.Masters.General_Master.labels.description = 'Description';
Modules.Masters.General_Master.labels.cargoClass = 'Class';
Modules.Masters.General_Master.labels.printerPath ='Path';
Modules.Masters.General_Master.labels.groupCode ='Group Code';
Modules.Masters.General_Master.labels.defaultval ='Default';
Modules.Masters.General_Master.labels.pop='POP';
Modules.Masters.General_Master.labels.printType='Print Type';
Modules.Masters.General_Master.labels.tray='Tray';

/********* Customer Invoice Status ********/
Modules.LblsAndTtls.customerInvoiceFrmDateId='Invoice from Date';
Modules.LblsAndTtls.customerInvoiceToDateId='Invoice to Date';
Modules.LblsAndTtls.customerInvoiceActualTlt = 'Actual';
Modules.LblsAndTtls.customerInvoiceAccrualTlt = 'Accrual';
Modules.LblsAndTtls.customerInvoiceTypeTlt = 'Invoice Type';
Modules.LblsAndTtls.customerInvoiceProformaEvntTlt = 'Proforma';
Modules.LblsAndTtls.customerInvoiceRejectedEvntTlt = 'Rejected';
Modules.LblsAndTtls.customerInvoiceFinalEvntTlt = 'Final';
Modules.LblsAndTtls.customerInvoicePaidEvntTlt = 'Paid';
Modules.LblsAndTtls.customerInvoiceStatusTlt = 'Status';
Modules.LblsAndTtls.customerInvoiceEvntTlt = 'Invoice';
Modules.LblsAndTtls.customerInvoiceCreditEvntTlt = 'Credit';
Modules.LblsAndTtls.customerInvoiceDebitEvntTlt = 'Debit';
Modules.LblsAndTtls.customerInvoiceDocumentTypeTlt = 'Document Type';
Modules.LblsAndTtls.customerInvoiceNo = 'Invoice No.';
Modules.LblsAndTtls.customerInvoiceNoTlt = 'Invoice Number';
Modules.LblsAndTtls.customerInvoiceNoDateTlt = 'Invoice Date';
Modules.LblsAndTtls.customerInvoiceNoAmountTlt = 'Invoice Amount';
Modules.LblsAndTtls.customerInvoiceNoPaidAmountTlt = 'Paid Amount';
Modules.LblsAndTtls.customerInvoiceNoCurrencyTlt = 'Currency';
Modules.LblsAndTtls.customerInvoiceNoDueDateTlt = 'Due Date';
Modules.LblsAndTtls.customerInvoiceNoLstPaymentDateTlt = 'Last Payment Date';
Modules.LblsAndTtls.customerInvoiceNoInvoiceStatusTlt = 'Invoice Status';
Modules.LblsAndTtls.customerInvoicePrinterTtl = 'Invoice Printer';
Modules.LblsAndTtls.customerInvoiceBackUpPrinter = 'Backup Printer';
Modules.LblsAndTtls.customerInvoiceCopiesTtl = 'Invoice Copies';
Modules.LblsAndTtls.customerBackUpCopiesTtl = 'Backup Copies';
Modules.LblsAndTtls.customerCCMailTtl = 'CC-Mail ID';
Modules.LblsAndTtls.customerInvoiceViewTlt = 'View';
Modules.LblsAndTtls.customerInvoiceEmailTlt = 'E-mail';
Modules.LblsAndTtls.customerInvoicePrintTlt = 'Print';
Modules.LblsAndTtls.customerInvoiceBackUpTlt = 'Backup';
Modules.LblsAndTtls.typeTlt = 'Type';
Modules.LblsAndTtls.headerClauseTlt = 'Header Clause';
Modules.LblsAndTtls.rejectReasonTlt = 'Reject Reason';
Modules.LblsAndTtls.proformInvcNoTlt = 'Proforma Invoice Number';
Modules.LblsAndTtls.extProformaInvcNbrTlt ='External Proforma Invoice Number';
Modules.LblsAndTtls.extProformaInvcAbbLbl  =  'Ext Prf Invc Nbr';
Modules.LblsAndTtls.proformInvcNoAbbTlt = 'Proforma Invc Nbr';
/***********************************************************************/
//#TRANSPORT_MODE_MASTER
/***********************************************************************/
Modules.Masters.Transport_Mode_Master.labels.mode = 'Code';
Modules.Masters.Transport_Mode_Master.labels.description = 'Description';

/***********************************************************************/
//#CONVEYANCE_TYPE_MASTER
/***********************************************************************/
Modules.Masters.Conveyanca_Type_Master.labels.type ='Type';
Modules.Masters.Conveyanca_Type_Master.labels.description = 'Description';

/***********************************************************************/
//#PROFIT_LOSS_CENTRE_MASTER
/***********************************************************************/
Modules.Masters.Profit_Loss_Centre_Master.labels.centre = 'Center';
Modules.Masters.Profit_Loss_Centre_Master.labels.name = 'Name';

/***********************************************************************/
//#COUNTRY_MASTER
/***********************************************************************/
Modules.Masters.Country_Master.labels.code = 'Code';
Modules.Masters.Country_Master.labels.name = 'Name';
Modules.Masters.Country_Master.labels.regionCode = 'Region Code';

/***********************************************************************/
//#SERVICE_CODE_GLMAPPER
/***********************************************************************/
Modules.Masters.Service_Code_GlMapper.labels.serviceCode = 'Service Code';
Modules.Masters.Service_Code_GlMapper.labels.transportMode = 'Transport Mode';
Modules.Masters.Service_Code_GlMapper.labels.glCodeRevenueTransactions = 'GL Code(Revenue Transactions)';
Modules.Masters.Service_Code_GlMapper.labels.glCodeExpenseTransactions = 'GL Code(Expense Transactions)';

/***********************************************************************/
//#COMPANY_TAXTYPE_MAPPER
/***********************************************************************/
Modules.Masters.Company_TaxType_Mapper.labels.taxType = 'Tax Type';
Modules.Masters.Company_TaxType_Mapper.labels.glCodeRevenueTransactions = 'GL Code(Revenue Transactions)';
Modules.Masters.Company_TaxType_Mapper.labels.glCodeExpenseTransactions = 'GL Code(Expense Transactions)';

/***********************************************************************/
//#TAXTYPE_MASTER
/***********************************************************************/
Modules.Masters.TaxType_Master.labels.type = 'Type';
Modules.Masters.TaxType_Master.labels.description = 'Description';
Modules.Masters.TaxType_Master.labels.serviceAmount = 'Service Amount';
Modules.Masters.TaxType_Master.labels.taxType = 'Tax Type';

/***********************************************************************/
//# COMMON SCREEN LABELS 
/***********************************************************************/
Modules.Common_Operation.labels.clear = 'Clear';
Modules.Common_Operation.labels.retrieve = 'Retrieve';
Modules.Common_Operation.labels.saveSearchCriteria = 'Save Search Criteria';
Modules.Common_Operation.labels.retrieveSearchCriteria = 'Retrieve Search Criteria';
Modules.Common_Operation.labels.add = 'Add';
Modules.Common_Operation.labels.del = 'Delete';
Modules.Common_Operation.labels.copy = 'Copy';
Modules.Common_Operation.labels.paste = 'Paste';
Modules.Common_Operation.labels.save = 'Save';
Modules.Common_Operation.labels.close = 'Close';
Modules.Common_Operation.labels.saveGridState = 'Save Grid State';
Modules.Common_Operation.labels.resetGridState = 'Reset Grid State';
Modules.Common_Operation.labels.exportToExcel = 'Export to Excel';
Modules.Common_Operation.labels.exportToPDF = 'Export to PDF';
Modules.Common_Operation.labels.importFromExcel = 'Import From Excel';
Modules.Common_Operation.labels.queryParameters = 'Query Parameters';
Modules.Common_Operation.labels.recordView = 'Record View';

/***********************************************************************/
//#MASTER_TITLES
/***********************************************************************/
Modules.Master_Titles.labels.profitLossCentreMaster = 'Profit/Loss Center Master';
Modules.Master_Titles.labels.taxTypeMaster = 'Tax Type Master';
Modules.Master_Titles.labels.companyTaxTypeMapper = 'Company Tax Type Mapper';
Modules.Master_Titles.labels.glCodeMaster = 'GL Code Master';
Modules.Master_Titles.labels.serviceCodeGlMapper = 'Service Code GL Mapper';
Modules.Master_Titles.labels.invoicePrintTemplateMaster = 'Invoice Print Template Master';
Modules.Master_Titles.labels.rateTierMaster = 'Rate Tier Master';
Modules.Master_Titles.labels.conveyanceTypeMaster = 'Conveyance Type Master';
Modules.Master_Titles.labels.transportModeMaster = 'Transport Mode Master';
Modules.Master_Titles.labels.partMaster = 'Part Master';
Modules.Master_Titles.labels.modelGroupMaster = 'Model Group Master';
Modules.Master_Titles.labels.countryMaster = 'Country Master';
Modules.Master_Titles.labels.consolidationTypeMaster ='Consolidation Type Master';
Modules.Master_Titles.labels.stateProvinceMaster = 'State/Province Master';
Modules.Master_Titles.labels.transportModeMapper = 'Transport Mode Mapper';
Modules.Master_Titles.labels.makeMaster = 'Make Master';

Modules.Master_Titles.labels.freightTermMaster = 'Freight Term Master';
Modules.Master_Titles.labels.currencyMapper = 'Currency Code Mapper';
Modules.Master_Titles.labels.rateBasisMapper = 'Rate Basis Code Mapper';
Modules.Master_Titles.labels.uomMapper = 'UOM Code Mapper';
Modules.Master_Titles.labels.portTypeMaster = 'Port Type Master';
Modules.Master_Titles.labels.cargoTypeMaster = 'Cargo Type Master';
Modules.Master_Titles.labels.cargoClassMaster = 'Cargo Class Master';
Modules.Master_Titles.labels.companyMapper = 'Company Code Mapper';
Modules.Master_Titles.labels.regionMaster = 'Region Master';
Modules.Master_Titles.labels.vesselMaster = 'Vessel Master';
Modules.Master_Titles.labels.holidayMaster = 'Holiday Master';
Modules.Master_Titles.labels.serviceTypeMaster = 'Service Type Master';
Modules.Master_Titles.labels.exceptionTypeMaster = 'Exception Type Master';
Modules.Master_Titles.labels.printerMaster ='Printer Master';
Modules.Master_Titles.labels.orderTypeMaster ='Order Type Master';
Modules.Master_Titles.labels.partyTypeMaster ='Party Type Master';
Modules.Master_Titles.labels.locationMaster ='Location Master';
Modules.Master_Titles.labels.uomRateBasisMaster='UOM/Rate Basis Master';
Modules.Master_Titles.labels.portMaster='Port Master';
Modules.Master_Titles.labels.popMaster = 'POP Master';
Modules.Master_Titles.labels.countryStateCodeMapper = 'Country and State Code Mapper';
Modules.Master_Titles.labels.timeZoneMapper = 'Time Zone Mapper';
Modules.Master_Titles.labels.abnormalMoveTypeMaster = 'Abnormal Move Type Master';
Modules.Master_Titles.labels.commodityGroupMaster = 'Commodity Group Master';
Modules.Master_Titles.labels.fuelSurchargeIndexMaster ='Fuel Surcharge Index Master';
Modules.Master_Titles.labels.modelMaster = 'Model Master';
Modules.Master_Titles.labels.plantNameMapper = 'Plant Name Mapper';
Modules.Master_Titles.labels.consolidationTypeMapper = 'Consolidation Type Mapper';
Modules.Master_Titles.labels.modelGroupMapper = 'Model Group Mapper';
Modules.Master_Titles.labels.customerCodeMapper = 'Customer Code Mapper';
Modules.Master_Titles.labels.supplierCodeMapper = 'Supplier Code Mapper';
Modules.Master_Titles.labels.abnormalMoveTypeMapper = 'Abnormal Move Type Mapper';
Modules.Master_Titles.labels.rateTierMapper = 'Rate Tier Mapper';
Modules.Master_Titles.labels.makeModelCodeMapper = 'Make and Model Code Mapper';
Modules.Master_Titles.labels.serviceTaxMapper = 'Service Tax Mapper';
/***********************************************************************/
//#CUSTOMER_MASTER
/***********************************************************************/

Modules.contract.customer_master.labels.origin			='Origin/Location';
Modules.contract.customer_master.labels.destination		='Destination';
Modules.contract.customer_master.labels.statusDate		='Status Date';
Modules.contract.customer_master.labels.uom				='UOM';
Modules.contract.customer_master.labels.roundingCriteria='Rounding Criteria';
Modules.contract.customer_master.labels.value				='Value';
Modules.contract.customer_master.labels.minimumValue		='Minimum Value';
Modules.contract.customer_master.labels.customerCode='Customer';
Modules.contract.customer_master.labels.customerName='Customer Name';
Modules.contract.customer_master.labels.defaultCurrency='Default Currency';
Modules.contract.customer_master.labels.taxRefNo='Tax Ref No';
Modules.contract.customer_master.labels.fullTaxRefNo='Tax Reference Number';
Modules.contract.customer_master.labels.address1='Address 1';
Modules.contract.customer_master.labels.address2='Address 2';
Modules.contract.customer_master.labels.city='City';
Modules.contract.customer_master.labels.country='Country';
Modules.contract.customer_master.labels.postalCode='ZIP/Postal Code';
Modules.contract.customer_master.labels.telephoneNo='Telephone No.';
Modules.contract.customer_master.labels.fullTelephoneNo='Telephone Number';
Modules.contract.customer_master.labels.faxNumber='Fax Number';
Modules.contract.customer_master.labels.mobileNumber='Mobile Number';
Modules.contract.customer_master.labels.eMailAddress='E-Mail Address';
Modules.contract.customer_master.labels.contactPersonName1='Contact Person Name(1)';
Modules.contract.customer_master.labels.contactPersonName2='Contact Person Name(2)';
Modules.contract.customer_master.labels.subLedgerCode='Sub Ledger Code';
Modules.contract.customer_master.labels.sendEstmARMsgFlg='Send Customer Accrual to CODA';
Modules.contract.customer_master.labels.waitForAPAprroveFlg='Download A/R After A/P';
Modules.contract.customer_master.labels.waitForAPAprroveFlgFullLbl='Download Accounts Receivable After Accounts Payable';
Modules.contract.customer_master.labels.autoApproveApplnAdviceFlg='Auto Approve In Application Advice';
Modules.contract.customer_master.labels.sendCustInvoiceMsgFlg='Send Customer Invoice Message';
Modules.contract.customer_master.labels.ratingDestinationApplicableFlg='Rating Destination Applicable';
Modules.contract.customer_master.labels.financialCustomer='Financial ID';
Modules.contract.customer_master.labels.financialContractNo='Financial Contract No.';
Modules.contract.customer_master.labels.fullFinancialContractNo='Financial Contract Number';
Modules.contract.customer_master.labels.remarks1='Note';
Modules.contract.customer_master.labels.remarks2='Note 2';
Modules.contract.customer_master.labels.customerDetails='Customer Details';
Modules.contract.customer_master.labels.serviceType='Service Type';
Modules.contract.customer_master.labels.serviceCode='Service Code';
Modules.contract.customer_master.labels.origin='Origin/Location';
Modules.contract.customer_master.labels.destination='Destination';
Modules.contract.customer_master.labels.statusDate='Status Date';
Modules.contract.customer_master.labels.supplierCode='Supplier Code';
Modules.contract.customer_master.labels.unitOfMeasure='UOM';
Modules.contract.customer_master.labels.roundingType='Rounding Criteria';
Modules.contract.customer_master.labels.roundingValue='Value';
Modules.contract.customer_master.labels.minimumDistanceValue='Minimum Value';
Modules.contract.customer_master.labels.currencyCode='Currency Code';

Modules.Customer.CustomerRateVerificatoin.labels.OriginStateProv='Origin State/Prov'; 
Modules.Customer.CustomerRateVerificatoin.labels.consolidationType='ConslType Cd';
Modules.contract.customer_master.labels.defaultSupplierWinTtl='Default Supplier Grid Record';
Modules.contract.customer_master.labels.rateRoundingWinTtl = 'Rate Criteria Grid Record';
Modules.contract.customer_master.labels.distanceRoundingWinTtl = 'Distance Rounding Grid Record';
Modules.contract.customer_master.labels.statusDateWinTtl = 'Contract Identification Grid Record';
Modules.contract.customer_master.labels.customerMasterWinTtl = 'Customer Master Grid Record';
Modules.contract.customer_master.labels.financialDetailsTtl='Financial Details';
Modules.contract.customer_master.labels.ratingDetailsTtl='Rating Details';
Modules.contract.customer_master.labels.formTitle='Customer Master';
Modules.contract.customer_master.labels.submit='Submit';
Modules.contract.customer_master.labels.accrualInvoiceSetUp='Accrual and Invoice Set up';
/********************Ocean Customer Event Status Summary********************/
Modules.LblsAndTtls.custEventStatusSummaryParentTabpanelTtl = 'Ocean Customer Event Status Summary';
Modules.LblsAndTtls.pop='POP';
Modules.LblsAndTtls.freightTerm='Freight Term';
Modules.LblsAndTtls.vessel='Vessel';
Modules.LblsAndTtls.POR='POR';
Modules.LblsAndTtls.PFD='PFD';
Modules.LblsAndTtls.voyage='Voyage';
Modules.LblsAndTtls.blNum='BL Number';
Modules.LblsAndTtls.party='Party';
Modules.LblsAndTtls.chargCode='Charge Code';
Modules.LblsAndTtls.pol='POC';
Modules.LblsAndTtls.pod='POD';
Modules.LblsAndTtls.count='Count';
Modules.LblsAndTtls.totQnty='Total Quantity';
Modules.LblsAndTtls.maniFstCrncy='Manifest Currency';
Modules.LblsAndTtls.manifstCurncyCode='Manifest Currency Code';
Modules.LblsAndTtls.manifstCurncyCodeAbblbl='Manfst Currency Cd';
Modules.LblsAndTtls.servcAmntInvcCurncy='Service Amount Invoice Currency';
Modules.LblsAndTtls.invcCurncyCode='Invoice Currency Code';
Modules.LblsAndTtls.invcCurncyCodeAbbLbl='Invc Currency Cd';
Modules.LblsAndTtls.servcAmntUSDCurrency='Service Amount USD';
Modules.LblsAndTtls.srvcUomCdLbl ='Service UOM Code';
Modules.LblsAndTtls.sailingDate='Sailing Date';
Modules.LblsAndTtls.bLCompletionDatePrepaid='Prepaid';//BL completion Date (Prepaid)
Modules.LblsAndTtls.bLCompletionDateCollect='Collect';//BL completion Date (Collect)
Modules.LblsAndTtls.supplierStatus='Supplier Status';
Modules.LblsAndTtls.customerStatus='Customer Status';
Modules.LblsAndTtls.blCmplDate='BL Completion Date';
Modules.LblsAndTtls.popCurrency = 'POP Currency';
Modules.LblsAndTtls.popCurrencyCode = 'POP Currency Code';
Modules.LblsAndTtls.blCmpFlag = 'BL Completion';
/**** Ocean Supplier Rate Query Service Code****/
Modules.LblsAndTtls.oceanSupplierRateQueryServiceParentTabpanelTtl				= 'Supplier Rate Query Service Code';
Modules.LblsAndTtls.supplier													= 'Supplier';
Modules.LblsAndTtls.supName														= 'Supplier Name';
Modules.LblsAndTtls.startDate													= 'Start Date';
Modules.LblsAndTtls.endDate														= 'End Date';
Modules.LblsAndTtls.contractid													= 'Contract ID';
Modules.LblsAndTtls.chargeCode													= 'Charge Code';
Modules.LblsAndTtls.party														= 'Party';
Modules.LblsAndTtls.validFromDt													= 'Valid From Date';
Modules.LblsAndTtls.validToDt													= 'Valid To Date';
Modules.LblsAndTtls.pol															= 'POL';
Modules.LblsAndTtls.pod															= 'POD';
Modules.LblsAndTtls.cargoType													= 'Cargo Type';
Modules.LblsAndTtls.cargoClass													= 'Cargo Class';
Modules.LblsAndTtls.vesselType                                                  =  'Vessel Type';
Modules.LblsAndTtls.makeCode													= 'Make Code';
Modules.LblsAndTtls.model														= 'Model';
Modules.LblsAndTtls.polCity														= 'POL City';
Modules.LblsAndTtls.polStProv													= 'POL State';
Modules.LblsAndTtls.polCntry													= 'POL Country';
Modules.LblsAndTtls.polPoBox          											= 'POL PO-Box';
Modules.LblsAndTtls.podCity														= 'POD City';
Modules.LblsAndTtls.podStProv													= 'POD State';
Modules.LblsAndTtls.podCntry													= 'POD Country';
Modules.LblsAndTtls.por															= 'POR';
Modules.LblsAndTtls.porDescLbl                                                  = 'POR Description';    
Modules.LblsAndTtls.porAddress1Lbl                                              = 'POR Address 1';
Modules.LblsAndTtls.porAddress2Lbl                                              = 'POR Address 2';
Modules.LblsAndTtls.porBerthCdLbl                                               = 'POR Berth Code';
Modules.LblsAndTtls.porPortCallLbl                                              = 'POR Port Call';
Modules.LblsAndTtls.porCityLbl                                                  = 'POR City';
Modules.LblsAndTtls.porStateLbl                                                 = 'POR State';
Modules.LblsAndTtls.porCountryLbl                                               = 'POR Country';
Modules.LblsAndTtls.porPoBox          											= 'POR PO-Box';
Modules.LblsAndTtls.pfd															= 'PFD';
Modules.LblsAndTtls.steering													= 'Steering';
Modules.LblsAndTtls.hazardous													= 'Hazardous';
Modules.LblsAndTtls.handlindInd													= 'Handling Indicator';
Modules.LblsAndTtls.transferGear												= 'Transfer Gear';
Modules.LblsAndTtls.notChargeable												= 'Not Chargeable';
Modules.LblsAndTtls.factrVal													= 'Factor value';
Modules.LblsAndTtls.factType													= 'Factor Type';
Modules.LblsAndTtls.factRate													= 'Factor Rate';
Modules.LblsAndTtls.fixdRate													= 'Fixed Rate';
Modules.LblsAndTtls.tarrifRate													= 'Tariff Rate';
Modules.LblsAndTtls.luInd														= 'L/U Ind';
Modules.LblsAndTtls.tarrifCurncyInd												= 'Tariff Currency Code';
Modules.LblsAndTtls.priority													= 'Priority';
Modules.LblsAndTtls.seqNo														= 'Seq No.';
Modules.LblsAndTtls.DateExpiresLbl												= 'Date Expires';
Modules.LblsAndTtls.DateEffectiveLbl											= 'Date Effective';
Modules.LblsAndTtls.cargoCdsiDesclbl                                            = 'Cargo Cdsi Description'; 
Modules.LblsAndTtls.cargoCdsiDesc1lbl                                           = 'Cargo Cdsi Description1';
Modules.LblsAndTtls.cargoCdsiDesc2lbl                                           = 'Cargo Cdsi Description2';
Modules.LblsAndTtls.cargoCdsiInsidePkgLbl                                       = 'Cargo Cdsi Inside Package';
Modules.LblsAndTtls.cargoSrvAmtLocCurrencyLbl                                       = 'Service Amount Local currency';
Modules.LblsAndTtls.cargoSrvAmtManfstCurrencyLbl                                       = 'Service Amount Manifest currency';
Modules.LblsAndTtls.cargoChargeQuantityLbl                                       = 'Cargo Quantity';
Modules.LblsAndTtls.podPoboxlbl                                                 = 'POD PO-BOX';
Modules.LblsAndTtls.pfdAddress1Lbl                                              = 'PFD Address 1';
Modules.LblsAndTtls.pfdAddress2Lbl                                              = 'PFD Address 2';
/*** OCEAN - Customer Invoice Setup Screen ***/
	
/******************** Ocean Customer Service Group Setup ***************************/

Modules.contract.customer.oceanCstmrSrvGrpSetup.oceanCstmtSrvGrpSetupFormTtl='Customer Service Group Setup Ocean';
Modules.contract.customer.oceanCstmrSrvGrpSetup.popLabel='POP';
Modules.contract.customer.oceanCstmrSrvGrpSetup.popNameLabel='POP Name';
Modules.contract.customer.oceanCstmrSrvGrpSetup.partyLabel='Customer';
Modules.contract.customer.oceanCstmrSrvGrpSetup.partyNameLabel='Customer Name';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceGroupTlt='Service Group';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceGrpDesc='Service Group Description';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceType='Service Type';
Modules.contract.customer.oceanCstmrSrvGrpSetup.chargeCodeTlt='Service Code';
Modules.contract.customer.oceanCstmrSrvGrpSetup.chargeCodeDescTlt='Service Code Description';
Modules.contract.customer.oceanCstmrSrvGrpConfigurationGridTlt='Customer Service Group Setup Grid Record View';
Modules.contract.customer.oceancstmrSrvTypeConfigurationGridTlt='Customer Service Group Setup - Service Code Grid Record View';
Modules.LblsAndTtls.serviceCdDescFullLbl = 'Service Code Description';


Modules.Customer.CustomerRateVerificatoin.labels.OriginStateProv='Origin State/Prov';
Modules.Customer.CustomerRateVerificatoin.labels.consolidationType='Consldt Type Code';


/*** Supplier Invoice Status Labels and Titles***/
	
Modules.SpplrInvc.SupplrInvcSts.label.invoiceNo						= 'Invoice No.';
Modules.SpplrInvc.SupplrInvcSts.label.invcFrmDate					= 'Invoice From Date';
Modules.SpplrInvc.SupplrInvcSts.label.invcToDate					= 'Invoice To Date';
Modules.SpplrInvc.SupplrInvcSts.label.evntLdRef  					= 'Event/Load Reference';
Modules.SpplrInvc.SupplrInvcSts.label.cnvynce  					    = 'Conveyence ID';
Modules.SpplrInvc.SupplrInvcSts.label.shpRef     					= 'Shipping Reference';
Modules.SpplrInvc.SupplrInvcSts.label.proforma     					= 'Proforma';
Modules.SpplrInvc.SupplrInvcSts.label.rdyForRecnltn     			= 'Ready for Reconciliation';
Modules.SpplrInvc.SupplrInvcSts.label.undrInvgt     			    = 'Under Investigation';
Modules.SpplrInvc.SupplrInvcSts.label.apprvd         			    = 'Approved';
Modules.SpplrInvc.SupplrInvcSts.label.rejected         			    = 'Rejected';
Modules.SpplrInvc.SupplrInvcSts.label.paid          			    = 'Paid';
Modules.SpplrInvc.SupplrInvcSts.label.invoice          			    = 'Invoice';
Modules.SpplrInvc.SupplrInvcSts.label.credit          			    = 'Credit';
Modules.SpplrInvc.SupplrInvcSts.label.debit          			    = 'Debit';
Modules.SpplrInvc.SupplrInvcSts.label.pdf          			        = 'PDF';
Modules.SpplrInvc.SupplrInvcSts.label.excel          			    = 'Excel';
Modules.SpplrInvc.SupplrInvcSts.label.ascending          			= 'Ascending';
Modules.SpplrInvc.SupplrInvcSts.label.descending          			= 'Descending';
Modules.SpplrInvc.SupplrInvcSts.label.status          			    = 'Status';
Modules.SpplrInvc.SupplrInvcSts.label.docType          			    = 'Document Type';
Modules.SpplrInvc.SupplrInvcSts.label.rptoutput          			= 'Report Output';
Modules.SpplrInvc.SupplrInvcSts.label.sortOptns          			= 'Sort Options';
//Grid Labels
Modules.SpplrInvc.SupplrInvcSts.label.supplier					    = 'Supplier';
Modules.SpplrInvc.SupplrInvcSts.label.invcNo                        = 'Invoice Number';
Modules.SpplrInvc.SupplrInvcSts.label.invcDate                      = 'Invoice Date';
Modules.SpplrInvc.SupplrInvcSts.label.docType					    = 'Document Type';
Modules.SpplrInvc.SupplrInvcSts.label.invcAmt                       = 'Invoice Amount';
Modules.SpplrInvc.SupplrInvcSts.label.apprvdAmt                     = 'Approved Amount';
Modules.SpplrInvc.SupplrInvcSts.label.paidAmt                       = 'Paid Amount';
Modules.SpplrInvc.SupplrInvcSts.label.currency                      = 'Currency';
Modules.SpplrInvc.SupplrInvcSts.label.dueDate                       = 'Due Date';
Modules.SpplrInvc.SupplrInvcSts.label.lastPmtDate                   = 'Last Payment Date';
Modules.SpplrInvc.SupplrInvcSts.label.invcSts                       = 'Invoice Status';
Modules.SpplrInvc.SupplrInvcSts.label.suppledit                     = 'Supplier Record';

/*** Supplier Invoice Status Labels and Titles***/


/* START of Ocean Customer Invoice Generation Screen */
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.popAmounttooltip='Place Of Payment Amount';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.panelTitle='Generate Invoice Ocean';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.clear='Clear';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.retrieve='Retrieve';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.generate='Generate';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.keySearch='Key Search';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.advanceSearch='Advance Search';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.formTitle='Generate Invoice Ocean';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blNumber='BL Number';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.party='Customer';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.carrier='Supplier';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.chargeCode='Service Code';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pol='POL';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pod='POD';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pop='POP';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.por='POR';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pfd='PFD';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.freightTerms='Freight Terms';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvcGrpCd='Service Group Code';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipRefNbr='Ship Ref No.';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipRefNumber='Shipping Reference Number';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.sailFmDate='Sailing From Date';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.sailToDate='Sailing To Date';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCmplFmDate='BL Cmpl Fm Date';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCmplToDate='BL Cmpl To Date';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.localCurrency='Local Currency';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.voyage='Voyage';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.vessel='Vessel Name';

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCompletionDate='BL Completion Date';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.manifestCurncy='Manifest Currency';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.manifestAmount='Manifest Amount';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcCurrency='POP Currency';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcAmount='POP Amount';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.usdEqvlntAmount='USD Amount';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.gridPopWinTitle='Generate Invoice Grid Record';

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcNo='Invoice Number';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcStatus='Invoice Status';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.reject='Reject';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.finalise='Finalize';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.FinalizeWintitle='Customer Invoice Status';



Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.itemNumber='Item Number';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.vatApplFlg='VAT Appl. Flag';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.quantity='Quantity';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.rate='Rate';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.rateBasis='Rate Basis';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.chargeCodeDesc='Service Desc';

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.partyName='Customer Name';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.cargoClass='Cargo Class';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.cargoType='Cargo Type';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.commodityDesc='Commodity desc';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.rateOfExchng='ROE';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvGrpCdtooltip='Service Group';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.FailureWintitle='Invoice Generation Failed';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.FinalWintitle='Customer Finalized Invoices';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.Ok='Done';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.extPrfInvcNumber='External Invoice Number';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.partyName='Customer Name';




/* END of Ocean Customer Invoice Generation Screen */

/* START of Ocean Customer Print Template Screen */

//Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pop='POP';

/* END of Ocean Customer Print Template Screen */

/********************Start of Ocean Supplier Reconciliation********************************************/
Modules.ocean.supplier_invoice.supplier_reconciliation.supReconTabParentPaneltTtl='Supplier Reconciliation Ocean';
Modules.ocean.supplier_invoice.supplier_reconciliation.supReconTabPaneltTtl='Supplier Reconciliation';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.supplier='Supplier';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.supCode='Supplier Code';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.invcNum='Invoice Number';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.blNumber='BL Number';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.voyage='Voyage';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.pol='POL';
Modules.ocean.supplier_invoice.supplier_reconciliation.tooltip.pol='Port Of Load';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.pod='POD';
Modules.ocean.supplier_invoice.supplier_reconciliation.tooltip.pod='Port Of Discharge';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.por='POR';
Modules.ocean.supplier_invoice.supplier_reconciliation.tooltip.por='Place Of Receipt';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.pfd='PFD';
Modules.ocean.supplier_invoice.supplier_reconciliation.tooltip.pfd='Place of Final Delivery';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.serviceCode='Service Code';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.vessel='Vessel';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.freightTerms='Freight Terms';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.dueFmDate='Due From Date';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.dueToDate='Due To Date';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.advanceSearch='Advance Search';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.keySearch='Key Search';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.status='Status';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.readyForReconcile='Ready For Reconcile';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.rejected='Rejected';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.approved='Approved';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.undrInvst='Under Investigation';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.reconciled='Reconciled';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.details='Details';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.cargoType='Cargo Type';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.cargoClass='Cargo Class';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.supAmt='Supplier Amount';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.evntAmt='Event Amount';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.invcAmt='Invoice Amount';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.taxAmt='Tax Amount';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.totAmt='Total Amount';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.comment='Comment';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.mismatchReason='Mismatch Reason';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.makeCd='Make Code';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.modelCd='Model Code';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.pftLossCent='Profit/Loss Center';
Modules.ocean.supplier_invoice.supplier_reconciliation.dtlsTtl='Details';
Modules.ocean.supplier_invoice.supplier_reconciliation.labels.supLineItmDtls='Supplier Line Item Details';
Modules.ocean.supplier_invoice.supplier_reconciliation.matchEvntDtls='Matching Event Details';
/*****************************************************************/

/********************End of Ocean Supplier Reconciliation************************************************************/
//#EventRatingQuery_Ocean
/**********************************************************************************/
Modules.ocean.operations.event_details.event_rating_query.labels.formTitle = 'Event Query';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQuerySupplierPopup = 'Event Query Supplier Details';
Modules.ocean.operations.event_details.event_rating_query.labels.POP = 'POP';
Modules.ocean.operations.event_details.event_rating_query.labels.bLNumber = 'BL Number';
Modules.ocean.operations.event_details.event_rating_query.labels.freightTerm = 'Freight Term';
Modules.ocean.operations.event_details.event_rating_query.labels.vessel = 'Vessel';
Modules.ocean.operations.event_details.event_rating_query.labels.voyage = 'Voyage';
Modules.ocean.operations.event_details.event_rating_query.labels.party = 'Customer';
Modules.ocean.operations.event_details.event_rating_query.labels.partyName = 'Customer Name';
Modules.ocean.operations.event_details.event_rating_query.labels.POL = 'POL';
Modules.ocean.operations.event_details.event_rating_query.labels.POD = 'POD';
Modules.ocean.operations.event_details.event_rating_query.labels.POR = 'POR';
Modules.ocean.operations.event_details.event_rating_query.labels.PFD = 'PFD';
Modules.ocean.operations.event_details.event_rating_query.labels.sailingDate = 'Sailing Date';
//Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDatePrepaid = 'BL Completion Date (Prepaid)';
//Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDateCollect = 'BL Completion Date (Collect)';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDate = 'BL Cmpltn Date';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDateFull = 'BL Completion Date';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionFlg = 'BL Completion';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDatePrepaid = 'Prepaid Date';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDateCollect = 'Collect Date';
Modules.ocean.operations.event_details.event_rating_query.labels.postCollectChargeFlg='PCC';
Modules.ocean.operations.event_details.event_rating_query.labels.postCollectChargeFlgFull='Post Collect Charge';
Modules.ocean.operations.event_details.event_rating_query.labels.customerStatus = 'Customer Status';
Modules.ocean.operations.event_details.event_rating_query.labels.supplierStatus = 'Supplier Status';
Modules.ocean.operations.event_details.event_rating_query.labels.deleteBtn = 'Delete';
Modules.ocean.operations.event_details.event_rating_query.labels.copyBtn = 'Copy';
Modules.ocean.operations.event_details.event_rating_query.labels.saveBtn = 'Save';
Modules.ocean.operations.event_details.event_rating_query.labels.lineNumber = 'Line Number';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoClass = 'Cargo Class';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoType = 'Cargo Type';
Modules.ocean.operations.event_details.event_rating_query.labels.commodityDescriptionFull = 'Commodity Description';
Modules.ocean.operations.event_details.event_rating_query.labels.commodityDescription = 'Commodity Desc';
Modules.ocean.operations.event_details.event_rating_query.labels.chargeCode = 'Charge Code';
Modules.ocean.operations.event_details.event_rating_query.labels.chargeCodeDescriptionFull = 'Charge Code Description';
Modules.ocean.operations.event_details.event_rating_query.labels.chargeCodeDescription = 'Charge Code Desc';
Modules.ocean.operations.event_details.event_rating_query.labels.freightTerm = 'Freight Term';
Modules.ocean.operations.event_details.event_rating_query.labels.pop = 'POP';
Modules.ocean.operations.event_details.event_rating_query.labels.popDescription = 'POP Description';
Modules.ocean.operations.event_details.event_rating_query.labels.handlerIndication = 'Handler Indication';
Modules.ocean.operations.event_details.event_rating_query.labels.transferGear = 'Transfer Gear';
Modules.ocean.operations.event_details.event_rating_query.labels.SteeringLeftRight = 'Steering L/R';
Modules.ocean.operations.event_details.event_rating_query.labels.SteeringLeftRightFull = 'Steering Left/Right';
Modules.ocean.operations.event_details.event_rating_query.labels.hazardousYN = 'Hazardous(Y/N)';
Modules.ocean.operations.event_details.event_rating_query.labels.lineItemQuantity = 'Line Item Qty';
Modules.ocean.operations.event_details.event_rating_query.labels.lineItemQuantityFull = 'Line Item Quantity';
Modules.ocean.operations.event_details.event_rating_query.labels.rate = 'Rate';
Modules.ocean.operations.event_details.event_rating_query.labels.rateBasis = 'Rate Basis';
Modules.ocean.operations.event_details.event_rating_query.labels.manifestCurrency = 'Manifest Currency';
Modules.ocean.operations.event_details.event_rating_query.labels.manifestAmount = 'Manifest Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.exchangeRate = 'Exchange Rate';
Modules.ocean.operations.event_details.event_rating_query.labels.localCurrency = 'POP Currency';
Modules.ocean.operations.event_details.event_rating_query.labels.localAmount = 'POP Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.usdAmount = 'USD Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.localCurrencyFull = 'Place Of Payment Currency';
Modules.ocean.operations.event_details.event_rating_query.labels.localAmountFull = 'Place Of Payment Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.usdAmountFull = 'US Dollar Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoId = 'Cargo ID';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoBarcode = 'Cargo Barcode';
Modules.ocean.operations.event_details.event_rating_query.labels.make = 'Make';
Modules.ocean.operations.event_details.event_rating_query.labels.model = 'Model';
Modules.ocean.operations.event_details.event_rating_query.labels.modelName = 'Model Name';
Modules.ocean.operations.event_details.event_rating_query.labels.modelYear = 'Model Year';
Modules.ocean.operations.event_details.event_rating_query.labels.weight = 'Weight';
Modules.ocean.operations.event_details.event_rating_query.labels.weightUOM = 'Weight UOM';
Modules.ocean.operations.event_details.event_rating_query.labels.length = 'Length';
Modules.ocean.operations.event_details.event_rating_query.labels.dimensionUOM = 'Dimension UOM';
Modules.ocean.operations.event_details.event_rating_query.labels.width = 'Width';
Modules.ocean.operations.event_details.event_rating_query.labels.height = 'Height';
Modules.ocean.operations.event_details.event_rating_query.labels.volume = 'Volume';
Modules.ocean.operations.event_details.event_rating_query.labels.cube = 'Cube';
Modules.ocean.operations.event_details.event_rating_query.labels.quantity = 'Quantity';
Modules.ocean.operations.event_details.event_rating_query.labels.status = 'Status';
Modules.ocean.operations.event_details.event_rating_query.labels.invoiceNumber = 'Invoice Number';
Modules.ocean.operations.event_details.event_rating_query.labels.notChargable = 'Not Chargeable';
Modules.ocean.operations.event_details.event_rating_query.labels.glCode = 'GL Code';
Modules.ocean.operations.event_details.event_rating_query.labels.taxAmount = 'Tax Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.serviceAmount = 'Service Amount';
Modules.ocean.operations.event_details.event_rating_query.labels.currency = 'Currency';
Modules.ocean.operations.event_details.event_rating_query.labels.taxPercent = 'Tax%';
Modules.ocean.operations.event_details.event_rating_query.labels.taxType = 'Tax Type';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQueryCargoPopup = 'Event Query Cargo Details';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQueryPopup = 'Event Query View';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQuerytaxWin = 'Tax Details';
Modules.ocean.operations.event_details.event_rating_query.labels.custCargoGridTlt = 'Customer Cargo Details Grid Record';
Modules.ocean.operations.event_details.event_rating_query.labels.supCargoGridTlt = 'Supplier Cargo Details Grid Record';
Modules.ocean.operations.event_details.event_rating_query.labels.customerCargoDetailsTlt='Customer Cargo Details';
Modules.ocean.operations.event_details.event_rating_query.labels.supplierCargoDetailsTlt='Supplier Cargo Details';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingGridTlt='Event Query Grid Record';
Modules.ocean.operations.event_details.event_rating_query.labels.supplierDetails='Supplier Details';
Modules.ocean.operations.event_details.event_rating_query.labels.customerDetails='Customer Details';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoDetailsTlt = 'Cargo Details';
Modules.ocean.operations.event_details.event_rating_query.labels.serviceGroup='Service Group';
Modules.ocean.operations.event_details.event_rating_query.labels.shipmentRefNumber='Ship Ref Number';
Modules.ocean.operations.event_details.event_rating_query.labels.shipmentRefNumberFull='Shipment Reference Number';

/********************************************************************************/
//#SupplierLineItemStatus_Ocean
/**********************************************************************************/

Modules.supplier_invoice.supplier_line_item_status.labels.tabParentPanelLbl = 'Supplier Line Item Status';
Modules.supplier_invoice.supplier_line_item_status.labels.supplier = 'Supplier';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceNumber = 'Invoice Number';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceDate = 'Invoice Date';
Modules.supplier_invoice.supplier_line_item_status.labels.serviceCode = 'Service Code';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceAmount = 'Invoice Amount';
Modules.supplier_invoice.supplier_line_item_status.labels.approvedAmount = 'Approved Amount';
Modules.supplier_invoice.supplier_line_item_status.labels.paidAmount = 'Paid Amount';
Modules.supplier_invoice.supplier_line_item_status.labels.currency = 'Currency';
Modules.supplier_invoice.supplier_line_item_status.labels.unitId = 'Unit ID';
Modules.supplier_invoice.supplier_line_item_status.labels.loadReference = 'Load Reference';
Modules.supplier_invoice.supplier_line_item_status.labels.conveyanceId = 'Conveyance ID';
Modules.supplier_invoice.supplier_line_item_status.labels.partId = 'Part ID';
Modules.supplier_invoice.supplier_line_item_status.labels.deliveryCompletionDate = 'Delivery/Completion Date';
Modules.supplier_invoice.supplier_line_item_status.labels.dueDate = 'Due Date';
Modules.supplier_invoice.supplier_line_item_status.labels.lastPaymentDate = 'Last Payment Date';
//Modules.supplier_invoice.supplier_line_item_status.labels.supplier = 'Line Item Status';
Modules.supplier_invoice.supplier_line_item_status.labels.reason = 'Reason';
Modules.supplier_invoice.supplier_line_item_status.labels.formTitle = 'Supplier Line Item Status Ocean';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceFromDate = 'Invoice From Date';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceToDate = 'Invoice To Date';
Modules.supplier_invoice.supplier_line_item_status.labels.serviceType = 'Service Type';
Modules.supplier_invoice.supplier_line_item_status.labels.eventLoadReference = 'Event/Load Ref';
Modules.supplier_invoice.supplier_line_item_status.labels.shippingReference = 'Shipping Ref';
Modules.supplier_invoice.supplier_line_item_status.labels.proforma = 'Proforma';
Modules.supplier_invoice.supplier_line_item_status.labels.readyForReconciliation = 'Ready For Reconciliation';
Modules.supplier_invoice.supplier_line_item_status.labels.underInvestigation = 'Under Investigation';
Modules.supplier_invoice.supplier_line_item_status.labels.reconciled = 'Reconciled';
Modules.supplier_invoice.supplier_line_item_status.labels.approved = 'Approved';
Modules.supplier_invoice.supplier_line_item_status.labels.rejected = 'Rejected';
Modules.supplier_invoice.supplier_line_item_status.labels.paid = 'Paid';
Modules.supplier_invoice.supplier_line_item_status.labels.invoice = 'Invoice';
Modules.supplier_invoice.supplier_line_item_status.labels.creditNote = 'Credit Note';
Modules.supplier_invoice.supplier_line_item_status.labels.debitNote = 'Debit Note';
Modules.supplier_invoice.supplier_line_item_status.labels.lineItemStatus = 'Line Item Status';
Modules.supplier_invoice.supplier_line_item_status.labels.deleteBtn = 'Delete';
Modules.supplier_invoice.supplier_line_item_status.labels.supplierLineItemStatusPopWin = 'Supplier Line Item Status Details';







/*** OCEAN - Customer Invoice Setup Screen ***/
Modules.Ocean.CustInvcSetup.labels.formtitle 						= 'Customer Actual Invoice Setup Ocean';
Modules.Ocean.CustInvcSetup.labels.consolfrightTerms 				= 'Freight Terms';
Modules.Ocean.CustInvcSetup.labels.srvctype 						= 'Service Type';
Modules.Ocean.CustInvcSetup.labels.frghtterms 						= 'Freight Terms';
Modules.Ocean.CustInvcSetup.labels.acttrgpont 						= 'Trigger Status';
Modules.Ocean.CustInvcSetup.labels.trgpont 						    = 'Trigger Status';
Modules.Ocean.CustInvcSetup.labels.gnrttrgidntf 				    = 'Generation Trigger Identification';
Modules.Ocean.CustInvcSetup.labels.trgidntfgridrec 				    = 'Trigger Identification Grid Record';
Modules.Ocean.CustInvcSetup.labels.srvccode 						= 'Service Code';
Modules.Ocean.CustInvcSetup.labels.bl		 						= 'BL Number';
Modules.Ocean.CustInvcSetup.labels.voyage		 					= 'Voyage Number';
Modules.Ocean.CustInvcSetup.labels.crterm 						    = 'Credit Term(calender Days)';
Modules.Ocean.CustInvcSetup.labels.crtermonspplapprv 			    = 'Credit Term Based On Supplier Approval(BusinessDays)';
Modules.Ocean.CustInvcSetup.labels.actinvcgrpngcrt 			        = 'Actual Invoice Grouping Criteria';
Modules.Ocean.CustInvcSetup.labels.srvcgrpcd    			        = 'Service Group Code';
Modules.Ocean.CustInvcSetup.labels.srvcgrp       			        = 'Service Group';
Modules.Ocean.CustInvcSetup.labels.chrgcd              	            = 'Charge Code';
Modules.Ocean.CustInvcSetup.labels.pol              	            = 'POL';
Modules.Ocean.CustInvcSetup.labels.itmno							= 'Item No.';
Modules.Ocean.CustInvcSetup.labels.invccurr							= 'Invoice Currency';
Modules.Ocean.CustInvcSetup.labels.vesselCode						= 'Vessel Code';
Modules.Ocean.CustInvcSetup.labels.por              	            = 'POR';
Modules.Ocean.CustInvcSetup.labels.pop                              = 'POP';
Modules.Ocean.CustInvcSetup.labels.consolServiceCode              	= 'Service Code';
Modules.Ocean.CustInvcSetup.labels.intrvl              	            = 'Interval';
Modules.Ocean.CustInvcSetup.labels.lstexcutime						= 'Last Execution Time';
Modules.Ocean.CustInvcSetup.labels.nxtexcutime						= 'Next Execution Time';
Modules.Ocean.CustInvcSetup.labels.consolCargoGroup       	     	= 'Cargo Type';
Modules.Ocean.CustInvcSetup.labels.consolCargoClass                 = 'Cargo Class';
Modules.Ocean.CustInvcSetup.labels.autoapprove                  	= 'Auto Approve(Generate Final Invoice)';
Modules.Ocean.CustInvcSetup.labels.excstlist						= 'Exclude Customer List';
Modules.Ocean.CustInvcSetup.labels.serviceGroup                     ='Service Group';
Modules.Ocean.CustInvcSetup.labels.serviceCode                      ='Service Code';
Modules.Ocean.CustInvcSetup.labels.partyName       			        = 'Customer Name';
Modules.Ocean.CustInvcSetup.labels.popName       			        = 'POP Name';
Modules.Ocean.CustInvcSetup.labels.popNametoolTip       			= 'Place Of Payment City';
Modules.Ocean.CustInvcSetup.labels.poptoolTip       	            = 'Place Of Payment';
Modules.Ocean.CustInvcSetup.labels.invoiceLineItems       	        = 'Invoice Line Items';
Modules.Ocean.CustInvcSetup.labels.consolServiceTye       	        = 'Service Type';
//Modules.Ocean.CustInvcSetup.labels.orgnlorgn       	            = 'Original Origin';
//Modules.Ocean.CustInvcSetup.labels.fianldestination       	    = 'Final Destination';
//Modules.Ocean.CustInvcSetup.labels.conveyance       	            = 'Conveyance';
//Modules.Ocean.CustInvcSetup.labels.ldref       	                = 'Load Reference';
//Modules.Ocean.CustInvcSetup.labels.wrkorderno       	            = 'Work Order Number';
//Modules.Ocean.CustInvcSetup.labels.spplcd              	        = 'Supplier Code';
//Modules.Ocean.CustInvcSetup.labels.trprtmode              	    = 'Transport Mode';
//Modules.Ocean.CustInvcSetup.labels.csldtid              	        = 'Consolidation ID';
//Modules.Ocean.CustInvcSetup.labels.cnsdt       			        = 'Cnsldt';
//Modules.Ocean.CustInvcSetup.labels.afterGenerationFreq       		= 'No.of Days After Generation Frequency';



Modules.Ocean.CustInvcSetup.labels.serviceType                  	= 'Service Type';
Modules.Ocean.CustInvcSetup.labels.party		                  	= 'Customer';
Modules.Ocean.CustInvcSetup.labels.prntTmpltPrepaid                	= 'Print Template for Prepaid';
Modules.Ocean.CustInvcSetup.labels.prntTmpltCollect                	= 'Print Template for Collect';
Modules.Ocean.CustInvcSetup.labels.cstmrPrntTmpltWinTitle          	= 'Customer Print Template';

Modules.Ocean.CustInvcSetup.labels.customerCode						= 'Customer Code';
Modules.Ocean.CustInvcSetup.labels.popGrouping                      ='POR';
Modules.Ocean.CustInvcSetup.labels.pod                              ='POD';
Modules.Ocean.CustInvcSetup.labels.pfd                              ='PFD';
Modules.Ocean.CustInvcSetup.labels.carrierCodeGroup                  ='Supplier';
Modules.Ocean.CustInvcSetup.labels.cargoGroup                        ='Cargo Type';
Modules.Ocean.CustInvcSetup.labels.cargoCode                         ='Cargo Class';
Modules.Ocean.CustInvcSetup.labels.consolidation                     ='Consolidation';
Modules.Ocean.CustInvcSetup.labels.consolServiceGroup                ='Service Group';
Modules.Ocean.CustInvcSetup.labels.itemNumber                        ='Item No.';
Modules.Ocean.CustInvcSetup.labels.generationFrequency               ='Generation Frequency';
Modules.Ocean.CustInvcSetup.labels.Time                              ='Time';
Modules.Ocean.CustInvcSetup.labels.GenerationInterval                ='Generation Interval';
Modules.Ocean.CustInvcSetup.labels.GenerationTimeZone                ='Generation Time Zone';
Modules.Ocean.CustInvcSetup.labels.AutoAprove                        ='Auto Approve';
Modules.Ocean.CustInvcSetup.labels.Delta 	                         ='Delta Invoice';


/*** OCEAN - Customer Invoice Setup Screen ***/
	
/***********************************************************************/
//#NonOcean Supplier Remittance Details
/***********************************************************************/
Modules.supplierInvoice.supplierRemittanceDetails.tabParentPanelLbl='Supplier Remittance Details';
Modules.supplierInvoice.supplierRemittanceDetails.supplierCode='Supplier';
Modules.supplierInvoice.supplierRemittanceDetails.invcNumber='Invoice Number';
Modules.supplierInvoice.supplierRemittanceDetails.paymentFrmDt='Payment From Date';
Modules.supplierInvoice.supplierRemittanceDetails.paymentToDt='Payment To Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcFrmDt='Invoice From Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcToDt='Invoice To Date';
Modules.supplierInvoice.supplierRemittanceDetails.saveSearchCriteriaTtl='Save Search Criteria';
Modules.supplierInvoice.supplierRemittanceDetails.retrieveSearchCriteriaTtl= 'Retrieve Search Criteria';
Modules.supplierInvoice.supplierRemittanceDetails.serviceType='Service Type';
Modules.supplierInvoice.supplierRemittanceDetails.eventLoadRef='Event/Load Ref';
Modules.supplierInvoice.supplierRemittanceDetails.modeOfPaymnt='Mode of Payment';
Modules.supplierInvoice.supplierRemittanceDetails.paymntDoc='Payment Document';
Modules.supplierInvoice.supplierRemittanceDetails.unitId='Unit ID';
Modules.supplierInvoice.supplierRemittanceDetails.servcCode='Service Code';

Modules.supplierInvoice.supplierRemittanceDetails.shipReference='Shipping Reference';

Modules.supplierInvoice.supplierRemittanceDetails.pdfRadioBttn='PDF';
Modules.supplierInvoice.supplierRemittanceDetails.exlRadioBttn='Excel';
Modules.supplierInvoice.supplierRemittanceDetails.summaryRadioBttn='Summary';
Modules.supplierInvoice.supplierRemittanceDetails.DetailRadioBttn='Detail';
Modules.supplierInvoice.supplierRemittanceDetails.ascRadioBttn='Ascending';
Modules.supplierInvoice.supplierRemittanceDetails.DescRadioBttn='Descending';
Modules.supplierInvoice.supplierRemittanceDetails.reportOutputTtl='Report Output';
Modules.supplierInvoice.supplierRemittanceDetails.reportOptionsTtl='Report Options';
Modules.supplierInvoice.supplierRemittanceDetails.sortOptionsTtl='Sort Options';
Modules.supplierInvoice.supplierRemittanceDetails.invcDate='Invoice Date';

Modules.supplierInvoice.supplierRemittanceDetails.paymntDate='Payment Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcAmnt='Invoice Amount';
Modules.supplierInvoice.supplierRemittanceDetails.paidAmnt='Paid Amount';

Modules.supplierInvoice.supplierRemittanceDetails.currency='Currency';
Modules.supplierInvoice.supplierRemittanceDetails.partId='Part ID';
Modules.supplierInvoice.supplierRemittanceDetails.deliveryDate='Delivery Date';

Modules.supplierInvoice.supplierRemittanceDetails.apprvedAmnt='Approved Amount';

Modules.supplierInvoice.supplierRemittanceDetails.overdRejectCmmnt='Override/Rejected Comment';
Modules.supplierInvoice.supplierRemittanceDetails.parentGridWinTtl='Supplier Remittance Parent Details';
Modules.supplierInvoice.supplierRemittanceDetails.childGridWinTtl='Supplier Remittance Child Details';
Modules.supplierInvoice.supplierRemittanceDetails.report='Report';

Modules.supplierInvoice.supplierRemittanceDetails.suuplerCode='Supplier';
Modules.supplierInvoice.supplierRemittanceDetails.invcNumber='Invoice Number';
Modules.supplierInvoice.supplierRemittanceDetails.paymentFrmDt='Payment From Date';
Modules.supplierInvoice.supplierRemittanceDetails.paymentToDt='Payment To Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcFrmDt='Invoice From Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcToDt='Invoice To Date';
Modules.supplierInvoice.supplierRemittanceDetails.saveSearchCriteriaTtl='Save Search Criteria';
Modules.supplierInvoice.supplierRemittanceDetails.retrieveSearchCriteriaTtl= 'Retrieve Search Criteria';
Modules.supplierInvoice.supplierRemittanceDetails.serviceType='Service Type';
Modules.supplierInvoice.supplierRemittanceDetails.eventLoadRef='Event/Load Ref';
Modules.supplierInvoice.supplierRemittanceDetails.modeOfPaymnt='Mode of Payment';
Modules.supplierInvoice.supplierRemittanceDetails.paymntDoc='Payment Document';

Modules.LblsAndTtls.lineNbrTlt='Line Number';
Modules.LblsAndTtls.colSeqNbrTlt='Column Sequence Number';
Modules.LblsAndTtls.errMsgTlt='Error Message';


Modules.supplierInvoice.supplierRemittanceDetails.conveyanceId='Conveyance ID';
Modules.supplierInvoice.supplierRemittanceDetails.shipReference='Shipping Reference';
/*************************Customer Invoice Status For Ocean*****************/
Modules.LblsAndTtls.custmerInvcStsForOceanTtl			=	'Customer Invoice Status Ocean';
Modules.LblsAndTtls.custmerInvcStsForOceanCompanyLbl	=	'Company';	
Modules.LblsAndTtls.custmerInvcStsForOceanCustomerLbl	=	'Customer';
Modules.LblsAndTtls.custmerInvcStsForOceanDbtrPtyLbl	=	'Debtor Party';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcNoLbl		=	'Invoice No.';
Modules.LblsAndTtls.custmerInvcStsForOceanPrftLossLbl	=	'Profit/Loss';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcFrmDtLbl	=	'Invoice From Date';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcToDtLbl	=	'Invoice To Date';
Modules.LblsAndTtls.custmerInvcStsForOceanProfrmaLbl	=	'Proforma';
Modules.LblsAndTtls.custmerInvcStsForOceanRjctedLbl		=	'Rejected';
Modules.LblsAndTtls.custmerInvcStsForOceanFinalLbl		=	'Final';
Modules.LblsAndTtls.custmerInvcStsForOceanPaidLbl		=	'Paid';
Modules.LblsAndTtls.custmerInvcStsForOceanViewLbl		=	'View';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcLbl		=	'Invoice';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcPrntrLbl	=	'Invoice Printer';
Modules.LblsAndTtls.custmerInvcStsForOceanBckupPrntrLbl	=	'Backup Printer';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcCpsLbl	=	'Invoice Copies';
Modules.LblsAndTtls.custmerInvcStsForOceanEmailLbl		=	'E-Mail';
Modules.LblsAndTtls.custmerInvcStsForOceanPrintLbl		=	'Print';
Modules.LblsAndTtls.custmerInvcStsForOceanBckUpLbl		=	'Backup';
Modules.LblsAndTtls.custmerInvcStsForOceanBckUpCpsLbl	=	'Backup Copies';
Modules.LblsAndTtls.custmerInvcStsForOceanCcMailIdLbl	=	'CC-Mail ID';
Modules.LblsAndTtls.custmerInvcStsForOceanActualLbl		=	'Actual';
Modules.LblsAndTtls.custmerInvcStsForOceanAccuralLbl	=	'Accural';
Modules.LblsAndTtls.custmerInvcStsForOceanCreditLbl		=	'Credit';
Modules.LblsAndTtls.custmerInvcStsForOceanDebitLbl		=	'Debit';
Modules.LblsAndTtls.custmerInvcStsForOceanPdfLbl		=	'PDF';
Modules.LblsAndTtls.custmerInvcStsForOceanExcelLbl		=	'Excel';
Modules.LblsAndTtls.custmerInvcStsForOceanAscndngLbl	=	'Ascending';
Modules.LblsAndTtls.custmerInvcStsForOceanDescndngLbl	=	'Descending';
Modules.LblsAndTtls.custmerInvcStsForOceanPartyLbl		=	'Party'; 
Modules.LblsAndTtls.custmerInvcStsForOceanDcmntTpLbl	=	'Document Type';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcTpLbl		=	'Invoice Type';
Modules.LblsAndTtls.custmerInvcStsForOceanMnfstCrnLbl	=	'Manifest Currency';
Modules.LblsAndTtls.custmerInvcStsForOceanMnfstAmntLbl	=	'Manifest Amount';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcCrncyLbl	=	'Invoice Currency';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcAmntLbl	=	'Invoice Amount';	
Modules.LblsAndTtls.custmerInvcStsForOceanUsdEqAmntLbl	=	'USD Equivalent Amount';
Modules.LblsAndTtls.custmerInvcStsForOceanPaidAmountLbl	=	'Paid Amount';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcDtLbl		=	'Invoice Date';
Modules.LblsAndTtls.custmerInvcStsForOceanDueDtLbl		=	'Due Date';
Modules.LblsAndTtls.custmerInvcStsForOceanLstPymntDtLbl	=	'Last Payment Date';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcStsLbl	=	'Invoice Status';
Modules.LblsAndTtls.custmerInvcStsForOceanUsdEqAmntshortLbl	=	'USD Equivalent';
Modules.LblsAndTtls.cargoIdLbl = 'Cargo ID';
Modules.LblsAndTtls.cargoIdOrderNbrLbl = 'Cargo ID Order Number';
Modules.LblsAndTtls.cargoBarCdLbl  = 'Cargo Bar Code';
Modules.LblsAndTtls.taxTypeCdLbl = 'Tax Type Code';
Modules.LblsAndTtls.taxPercentageLbl = 'Tax Percentage';
Modules.LblsAndTtls.invoiceCurrenceCodeLbl = 'Invoice Currency';
Modules.LblsAndTtls.taxAmountLocalCurrencyLbl = 'Tax Amount';

Modules.supplierInvoice.supplierRemittanceDetails.pdfRadioBttn='PDF';
Modules.supplierInvoice.supplierRemittanceDetails.exlRadioBttn='Excel';
Modules.supplierInvoice.supplierRemittanceDetails.summaryRadioBttn='Summary';
Modules.supplierInvoice.supplierRemittanceDetails.DetailRadioBttn='Detail';
Modules.supplierInvoice.supplierRemittanceDetails.ascRadioBttn='Ascending';
Modules.supplierInvoice.supplierRemittanceDetails.DescRadioBttn='Descending';
Modules.supplierInvoice.supplierRemittanceDetails.reportOutputTtl='Report Output';
Modules.supplierInvoice.supplierRemittanceDetails.reportOptionsTtl='Report Options';
Modules.supplierInvoice.supplierRemittanceDetails.sortOptionsTtl='Sort Options';
Modules.supplierInvoice.supplierRemittanceDetails.invcDate='Invoice Date';

Modules.supplierInvoice.supplierRemittanceDetails.paymntDate='Payment Date';
Modules.supplierInvoice.supplierRemittanceDetails.invcAmnt='Invoice Amount';
Modules.supplierInvoice.supplierRemittanceDetails.paidAmnt='Paid Amount';

Modules.supplierInvoice.supplierRemittanceDetails.currency='Currency';
Modules.supplierInvoice.supplierRemittanceDetails.deliveryDate='Delivery Date';

Modules.supplierInvoice.supplierRemittanceDetails.apprvedAmnt='Approved Amount';


Modules.supplierInvoice.supplierRemittanceDetails.parentGridWinTtl='Supplier Remittance Parent Details';
Modules.supplierInvoice.supplierRemittanceDetails.childGridWinTtl='Supplier Remittance Child Details';
Modules.supplierInvoice.supplierRemittanceDetails.report='Report';


/*******************************************************************************************
*
*					Ocean Customer Master
*********************************************************************************************/
 Modules.LblsAndTtls.partyLbl			=		'Party';
 Modules.LblsAndTtls.partyMandatoryLbl			=		'Party<span style="color: red">*</span>';
 Modules.LblsAndTtls.summaryValueLbl			=		'Summary Value';
 
 /*******************************************************************************************
*
*					Supplier Rate Verification
*********************************************************************************************/
Modules.LblsAndTtls.carrierLbl			=		'Carrier';
Modules.LblsAndTtls.carrierNmLbl			=		'Carrier Name';
Modules.LblsAndTtls.chargeCodeLbl			=		'Charge Code';
Modules.LblsAndTtls.podLbl			=		'POD';
Modules.LblsAndTtls.polLbl			=		'POL';
Modules.LblsAndTtls.cargoTypeLbl			=		'Cargo Type';
Modules.LblsAndTtls.polCityLbl			=		'POL City';
Modules.LblsAndTtls.polStateLbl			=		'POL State';
Modules.LblsAndTtls.podCityLbl			=		'POD City';
Modules.LblsAndTtls.podStateLbl			=		'POD State';
Modules.LblsAndTtls.porLbl			=		'POR';
Modules.LblsAndTtls.pfdTlt			=		'PFD';
Modules.LblsAndTtls.steeringTlt			=		'Steering';
Modules.LblsAndTtls.hazardousLbl			=		'Hazardous';
Modules.LblsAndTtls.hndlingIndLbl			=		'Hndling Indicator';
Modules.LblsAndTtls.transfeGearLbl			=		'Transfer Gear';


//******supplier master ocean+ customer contract query ocean ***************************************************************************************************************************************
	
Modules.LblsAndTtls.supplierMasterSupplierDetails			='Supplier Details';
Modules.LblsAndTtls.supplierMasterPaymentDetails			='Payment Details';
Modules.LblsAndTtls.supplierMasterDateContractIdentification='Status Date For Contract Identification';
Modules.LblsAndTtls.supplierMasterSupplierInvoiceSetup='Supplier Automatic Invoice Setup';
Modules.LblsAndTtls.supplierMasterSupplierInvoiceSetupTitle='Supplier Automatic Invoice Ocean';
Modules.LblsAndTtls.supplierMasterRateRoundingCriteria='Rounding Criteria for Rate';

Modules.LblsAndTtls.supplierCd='Supplier Code';
Modules.LblsAndTtls.supplierNm='Supplier Name';
Modules.LblsAndTtls.defaultCurrency='Default Currency';
Modules.LblsAndTtls.taxRefNumber='Tax Ref Number';
Modules.LblsAndTtls.addrLineOne='Address Line 1';
Modules.LblsAndTtls.addrLineTwo='Address Line 2';
Modules.LblsAndTtls.city='City';
Modules.LblsAndTtls.stateProvince='State/Province';
Modules.LblsAndTtls.country='Country';
Modules.LblsAndTtls.zipPostalcd='Zip/Postal Code';
Modules.LblsAndTtls.telephoneNo='Telephone Nbr';
Modules.LblsAndTtls.faxNumber='Fax Number';
Modules.LblsAndTtls.mobilenumber='Mobile Number';
Modules.LblsAndTtls.emailAddress='E-mail Address';
Modules.LblsAndTtls.contactPersonNm='Contact Person';
Modules.LblsAndTtls.website='Website';
Modules.LblsAndTtls.financialId='Financial ID';
Modules.LblsAndTtls.calcTaxIfNotSentInMsg='Calculate Tax if not sent in Message';
Modules.LblsAndTtls.sendApMsgCoda='Send A/P Message to CODA';
Modules.LblsAndTtls.calcTaxIfNotSentThroughExcel='Calculate Tax if not sent through Excel';
Modules.LblsAndTtls.ignoreInvoiceDueDateFromMsg='Ignore Invoice Due Date from Message';
Modules.LblsAndTtls.shipmentDate='Shipment Date';
Modules.LblsAndTtls.partialPayment='Partial Payment';
Modules.LblsAndTtls.completionDate='Completion Date';
Modules.LblsAndTtls.createVarianceEvent='Create Variance Event';
Modules.LblsAndTtls.autoApprove='Auto Approve';
Modules.LblsAndTtls.remarksOne='Remarks 1';
Modules.LblsAndTtls.remarksTwo='Remarks 2';
Modules.LblsAndTtls.emailAddress = 'Email Address';
Modules.LblsAndTtls.ccEmailAddress = 'CC Email Address';
Modules.LblsAndTtls.SpplrMastercompletionDate = 'Delivery/Completion Date';
//'Supplier Automatic Invoice Setup'
Modules.LblsAndTtls.automaticInvoiceWinTtl='Supplier Automatic Invoice Setup';
Modules.LblsAndTtls.triggerStatus='Triggering Status';
Modules.LblsAndTtls.generateReconciledInv='Generate Reconciled Invoice';
Modules.LblsAndTtls.serviceCd='Service Code';

Modules.LblsAndTtls.oceanSpplrMasterTlt='Supplier Master Ocean';
//payment dtls
Modules.LblsAndTtls.chargeCd='Charge Code';
Modules.LblsAndTtls.payTermDays='Payment Term Days';
Modules.LblsAndTtls.payTermDaysSpplrMaster='Payment Term Days(Business /Calendar Days)';
Modules.LblsAndTtls.paymntTermDayAbb = 'Paymnt Term Days';
//rounding criteria rate
Modules.LblsAndTtls.roundingCriteriaByRate='Rate Rounding Criteria';
Modules.LblsAndTtls.serviceType='Service Type';
Modules.LblsAndTtls.currency='Currency';
Modules.LblsAndTtls.roundingCriteria='Rounding Criteria';

//'Status Date For Contract Identification'
Modules.LblsAndTtls.statusDtForContractIdentification='Status Date For Contract Identification';
Modules.LblsAndTtls.completionDt='Completion Date';

Modules.LblsAndTtls.pInvcFullLbl = 'Pending Invoice';
Modules.LblsAndTtls.zerortFullLbl  = 'Zero Rated'; 
Modules.LblsAndTtls.invcdFullLbl   = 'Invoiced'; 
Modules.LblsAndTtls.nochrgFullLbl   = 'Not Chargeable';
Modules.LblsAndTtls.apprvFullLbl   = 'Approved';
Modules.LblsAndTtls.renclFullLbl   = 'Reconciled';
Modules.LblsAndTtls.rejectFullLbl   = 'Rejected';

Modules.LblsAndTtls.supplierMaster='Supplier Master';
Modules.LblsAndTtls.value='Value';
Modules.LblsAndTtls.cstmrContractNbr = 'Customer Contract Number';
Modules.LblsAndTtls.podBerthCdLbl='POD Berth Code';
Modules.LblsAndTtls.podPortCallLbl = 'POD Port Call';
//ocean search form
Modules.LblsAndTtls.commodityDecsFull = 'Commodity Description';
Modules.LblsAndTtls.custContractOceanLbl='Customer Rate Query Ocean';
Modules.LblsAndTtls.companyLbl='Company';
Modules.LblsAndTtls.companyNmLbl='Company Name';
Modules.LblsAndTtls.popLbl='POP';
Modules.LblsAndTtls.popFullLbl='Place Of Payment';
Modules.LblsAndTtls.popDescFullLbl='Place Of Payment Description';
Modules.LblsAndTtls.popDescrLbl='POP Description';
Modules.LblsAndTtls.polFullLbl = 'Port Of Load';
Modules.LblsAndTtls.podFullLbl = 'Port Of Discharge';
Modules.LblsAndTtls.pfdFullLbl = 'Place Of Final Delivery';
Modules.LblsAndTtls.porFullLbl  =  'Place Of Receipt';
Modules.LblsAndTtls.partyLbl='Party';
Modules.LblsAndTtls.nameLbl='Name';
Modules.LblsAndTtls.nameMandatoryLbl='Name<span style="color: red">*</span>';
Modules.LblsAndTtls.contractIdLbl='Contract ID';
Modules.LblsAndTtls.contractIdMandatoryLbl='Contract ID<span style="color: red">*</span>';
Modules.LblsAndTtls.startDtLbl='Start Date';
Modules.LblsAndTtls.endDtLbl='End Date';
Modules.LblsAndTtls.validFromLbl='Valid From';
Modules.LblsAndTtls.validToLbl='Valid To';
Modules.LblsAndTtls.validFromMandatoryLbl='Valid From<span style="color: red">*</span>';
Modules.LblsAndTtls.validToMandatoryLbl='Valid To<span style="color: red">*</span>';
Modules.LblsAndTtls.oldContractIdLbl='Old Contract ID';
Modules.LblsAndTtls.oldContractIdMandatoryLbl='Old Contract ID<span style="color: red">*</span>';
Modules.LblsAndTtls.oceanCustmrRateQueryGridTtl			=		' Ocean Customer Rate Query Grid Record';	

Modules.LblsAndTtls.debtorPartyLbl='Debtor Party';
Modules.LblsAndTtls.debtorPartyNmLbl='Debtor Party Name';	
Modules.LblsAndTtls.debtorPartyNmAbb = 'Dbtr Party Nm';
Modules.LblsAndTtls.validFromDtLbl='Valid From Date';
Modules.LblsAndTtls.validToDtLbl='Valid To Date';

Modules.LblsAndTtls.increaseCriteriaLbl='Increase Criteria';
Modules.LblsAndTtls.increaseValueLbl='Increase Value';
Modules.LblsAndTtls.increaseCriteriaMandatoryLbl='Increase Criteria<span style="color: red">*</span>';
Modules.LblsAndTtls.increaseValueMandatoryLbl='Increase Value<span style="color: red">*</span>';
Modules.LblsAndTtls.copyContractWinLbl='Copy Contract Popup';	

Modules.LblsAndTtls.copyContractActionTtl='Copy Contract';	
//**********************************************************************************************************************************


//***************speicalmove entry button***************
Modules.LblsAndTtls.submitLbl='Submit';
Modules.LblsAndTtls.cancelLbl=	'Cancel';
Modules.LblsAndTtls.unLockLbl='(Un)lock';


/***********************************************************************/
//# CURRENCY_MAPPER
/***********************************************************************/
Modules.Masters.Currency_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Currency_Mapper.labels.externalCurrency = 'External Currency Code';
Modules.Masters.Currency_Mapper.labels.internalCurrency = 'Internal Currency Code';


/***********************************************************************/
//# RATE_BASIS_MAPPER
/***********************************************************************/
Modules.Masters.Rate_Basis_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Rate_Basis_Mapper.labels.externalRateBasis = 'External Rate Basis Code';
Modules.Masters.Rate_Basis_Mapper.labels.internalRateBasis = 'Internal Rate Basis Code';


/***********************************************************************/
//#TRANSPORT_MODE_MAPPER
/***********************************************************************/
Modules.Masters.Transport_Mode_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Transport_Mode_Mapper.labels.exterrnalTransportMode = 'External Transport Mode';
Modules.Masters.Transport_Mode_Mapper.labels.internalTransportMode = 'Internal Transport Mode';


/************************/
 //#UOM MAPPER
/************************************/
Modules.Masters.UOMCodeMapper.labels.partnerGroup ='Partner Group';
Modules.Masters.UOMCodeMapper.labels.externalUOMCode='External UOM Code';
Modules.Masters.UOMCodeMapper.labels.internalUOMCode ='Internal UOM Code';
/************************************/ 

//#PORT TYPE MASTER
/************************************/
Modules.Ocean.Masters.PortTypeMaster.labels.portTypeCode='Code';

Modules.Ocean.Masters.PortTypeMaster.labels.portTypeDesc='Description';

/***********************************/

//#CARGO TYPE MASTER
/**********************************/
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoTypeCode='Code';
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoClass='Class';
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoTypeDesc='Description';

/*********************************/





/***********************************************************************/
//#LOV's Factory for Ocean
/***********************************************************************/
Modules.ocean.lov_factory.labels.supplier='Supplier';
Modules.ocean.lov_factory.labels.pod='POD';
Modules.ocean.lov_factory.labels.podCountryCd='POD Country Code';
Modules.ocean.lov_factory.labels.polCountryCd='POL Country Code';
Modules.ocean.lov_factory.labels.por='POR';
Modules.ocean.lov_factory.labels.pfd='PFD';
Modules.ocean.lov_factory.labels.serviceCode='Service Code';
Modules.ocean.lov_factory.labels.customerCode='Customer';
Modules.ocean.lov_factory.labels.customerCode='Customer';
Modules.ocean.lov_factory.labels.modelCode='Model';
Modules.ocean.lov_factory.labels.makeCode='Make';
Modules.ocean.lov_factory.labels.party='Party';
Modules.ocean.lov_factory.labels.contractId='Contract ID';
Modules.ocean.lov_factory.labels.rateTier='Rate Tier';
Modules.ocean.lov_factory.labels.modelGrpCd='Model Group Code';


/***********************************************************************/
//# Customer Event Status Summary (Ocean)
/***********************************************************************/
Modules.LblsAndTtls.frieghtTermLbl = 'Freight Term';
Modules.LblsAndTtls.VesselLbl = 'Vessel';
Modules.LblsAndTtls.Voyage = 'Voyage';
Modules.LblsAndTtls.OcnCstmrEvntStsSummTlt = 'Customer Event Status Summary Details';
Modules.LblsAndTtls.servAmntManFstCrncyAbb='Srv Amt Manfst Curr';
Modules.LblsAndTtls.manifstCurncyCodeAbb='Manfst Curr Code';
Modules.LblsAndTtls.servcAmntInvcCurncyAbb='Srvc Amt Invc Curr';
Modules.LblsAndTtls.servAmntManFstCrncy  = 'Service Amount Manifest Currency';
Modules.LblsAndTtls.invcCurncyCodeAbb = 'Invc Curr Code';
Modules.LblsAndTtls.servcAmntUSDCurrencyAbb = 'Srvc Amt USD';

Modules.LblsAndTtls.pfdCityLbl  =  'PFD City';
Modules.LblsAndTtls.pfdStateLbl   = 'PFD State';
Modules.LblsAndTtls.pfdCountryLbl    = 'PFD Country';
Modules.LblsAndTtls.pfdPoBoxLbl         = 'PFD PO-BOX';
/***********************************************************************/
//#SHIPMENT_TYPE_MAPPER
/***********************************************************************/

Modules.Masters.Shipment_Type_Mapper.labels.shipmentTypeMapperTlt='Shipment Type Mapper';
Modules.Masters.Shipment_Type_Mapper.labels.partnerGroup='Partner Group';
Modules.Masters.Shipment_Type_Mapper.labels.ExternalShipmentType='External Shipment Type';
Modules.Masters.Shipment_Type_Mapper.labels.InternalShipmentType='Internal Shipment Type';


/***********************************************************************/
//#COMMODITY_MASTER
/***********************************************************************/

Modules.Ocean.Masters.Commodity_Master.labels.commodityMasterTlt='Commodity Master';
Modules.Ocean.Masters.Commodity_Master.labels.commodityCode='Code';
Modules.Ocean.Masters.Commodity_Master.labels.commodityDescription='Description';
Modules.Ocean.Masters.Commodity_Master.labels.commodityGroup='Group';


/***********************************************************************/
// #Supplier Rate Verification for Ocean
/***********************************************************************/
Modules.contract.supplier.oceansupplierRateVerification.labels.partyDetails='Party Details';
Modules.contract.supplier.oceansupplierRateVerification.labels.party='Customer';
Modules.contract.supplier.oceansupplierRateVerification.labels.contractId='Contract ID';
Modules.contract.supplier.oceansupplierRateVerification.labels.chargeCode='Service Code';
Modules.contract.supplier.oceansupplierRateVerification.labels.validFromDate='Valid From Date';
Modules.contract.supplier.oceansupplierRateVerification.labels.validToDate='Valid To Date';
Modules.contract.supplier.oceansupplierRateVerification.labels.pol='POL';
Modules.contract.supplier.oceansupplierRateVerification.labels.pod='POD';
Modules.contract.supplier.oceansupplierRateVerification.labels.cargoType='Cargo Type';
Modules.contract.supplier.oceansupplierRateVerification.labels.cargoClass='Cargo Class';
Modules.contract.supplier.oceansupplierRateVerification.labels.makeCode='Make Code';
Modules.contract.supplier.oceansupplierRateVerification.labels.model='Model';
Modules.contract.supplier.oceansupplierRateVerification.labels.polCity='POL City';
Modules.contract.supplier.oceansupplierRateVerification.labels.polState='POL State';
Modules.contract.supplier.oceansupplierRateVerification.labels.polCountry='POL Country';
Modules.contract.supplier.oceansupplierRateVerification.labels.podCity='POD City';
Modules.contract.supplier.oceansupplierRateVerification.labels.podState='POD State';
Modules.contract.supplier.oceansupplierRateVerification.labels.podCountry='POD Country';
Modules.contract.supplier.oceansupplierRateVerification.labels.por='POR';
Modules.contract.supplier.oceansupplierRateVerification.labels.pfd='PFD';
Modules.contract.supplier.oceansupplierRateVerification.labels.steering='Steering';
Modules.contract.supplier.oceansupplierRateVerification.labels.hazardous='Hazardous';
Modules.contract.supplier.oceansupplierRateVerification.labels.handlingInd='Handling Ind';
Modules.contract.supplier.oceansupplierRateVerification.labels.handlingIndFull='Handling Indicator';
Modules.contract.supplier.oceansupplierRateVerification.labels.transferGear='Transfer Gear';
Modules.contract.supplier.oceansupplierRateVerification.labels.notChargeable='Not Chargeable';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorVal='Factor Value';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorType='Factor Type';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorRate='Factor Rate';
Modules.contract.supplier.oceansupplierRateVerification.labels.fixedRate='Fixed Rate';
Modules.contract.supplier.oceansupplierRateVerification.labels.tariffRate='Tariff Rate';
Modules.contract.supplier.oceansupplierRateVerification.labels.uInd='L/U Ind';
Modules.contract.supplier.oceansupplierRateVerification.labels.tariffCurrencyCode='Tariff Currency';
Modules.contract.supplier.oceansupplierRateVerification.labels.tariffCurrencyCodeFull='Tariff Currency Code';
Modules.contract.supplier.oceansupplierRateVerification.labels.priority='Priority';
Modules.contract.supplier.oceansupplierRateVerification.labels.seqNo='Seq No.';
Modules.contract.supplier.oceansupplierRateVerification.labels.supplierRateVerification='Supplier Rate Verification';
Modules.contract.supplier.oceansupplierRateVerification.labels.carrier='Supplier';
Modules.contract.supplier.oceansupplierRateVerification.labels.carrierName='Supplier Name';
Modules.contract.supplier.oceansupplierRateVerification.labels.effectiveDate='Effective Date';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.chargeCode='Service Code';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.contractId='Contract ID';


/***********************************************************************/
//#Customer Rate Verification for Ocean
/***********************************************************************/
Modules.contract.customer.oceanCustomerRateVerification.labels.customerRateVerification 	= 'Customer Rate Verification';
Modules.contract.customer.oceanCustomerRateVerification.labels.splrCd						= 'Supplier Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.effectiveDate				= 'Effective Date';
Modules.contract.customer.oceanCustomerRateVerification.labels.chargeCode					= 'Service Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.pol							= 'POL';
Modules.contract.customer.oceanCustomerRateVerification.labels.pod							= 'POD';
Modules.contract.customer.oceanCustomerRateVerification.labels.makeCode						= 'Make Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.model						= 'Model';
Modules.contract.customer.oceanCustomerRateVerification.labels.por 							= 'POR';
Modules.contract.customer.oceanCustomerRateVerification.labels.pfd							= 'PFD';
Modules.contract.customer.oceanCustomerRateVerification.labels.party                        = 'Customer';
Modules.contract.customer.oceanCustomerRateVerification.labels.partyName                    = 'Customer Name';
Modules.contract.customer.oceanCustomerRateVerification.labels.pop                          = 'POP';
Modules.contract.customer.oceanCustomerRateVerification.labels.popName                      = 'POP Name';
Modules.contract.customer.oceanCustomerRateVerification.labels.frghtTerms                   = 'Freight Terms';
Modules.contract.customer.oceanCustomerRateVerification.labels.vslType                      = 'Vessel Type';
Modules.contract.customer.oceanCustomerRateVerification.labels.modelCd                      = 'Model Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.modelYr                      = 'Model Year';
Modules.contract.customer.oceanCustomerRateVerification.labels.modelGrpCd                   = 'Model Grp Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.contractId                   = 'Contract ID';
Modules.contract.customer.oceanCustomerRateVerification.labels.chrgCdDesc                   = 'Service Code Desc';
Modules.contract.customer.oceanCustomerRateVerification.labels.debtorPty                    = 'Debtor Party';
Modules.contract.customer.oceanCustomerRateVerification.labels.carrierCd                    = 'Supplier Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.rateTier                     = 'Rate Tier';
Modules.contract.customer.oceanCustomerRateVerification.labels.cargoClass                   = 'Cargo Class';
Modules.contract.customer.oceanCustomerRateVerification.labels.cargoType                    = 'Cargo Type';
Modules.contract.customer.oceanCustomerRateVerification.labels.cmdtyCd                      = 'Commodity Code';
Modules.contract.customer.oceanCustomerRateVerification.labels.cmdtyDesc                    = 'Commodity Description';
Modules.contract.customer.oceanCustomerRateVerification.labels.rateBasis                    = 'Rate Basis';
Modules.contract.customer.oceanCustomerRateVerification.labels.rate                         = 'Rate';
Modules.contract.customer.oceanCustomerRateVerification.labels.markUp                       = 'Mark Up';
Modules.contract.customer.oceanCustomerRateVerification.labels.dateEffective                = 'Date Effective';
Modules.contract.customer.oceanCustomerRateVerification.labels.dateExpires                  = 'Date Expires';
Modules.contract.customer.oceanCustomerRateVerification.labels.priority						= 'Priority';

/***********************************************************************/
//#LOV's Factory for Ocean
/***********************************************************************/
Modules.ocean.lov_factory.labels.supplier='Supplier';
Modules.ocean.lov_factory.labels.pod='POD';
Modules.ocean.lov_factory.labels.por='POR';
Modules.ocean.lov_factory.labels.pfd='PFD';
Modules.ocean.lov_factory.labels.serviceCode='Service Code';
Modules.ocean.lov_factory.labels.customerCode='Customer';


Modules.contract.supplier.oceansupplierRateVerification.labels.effectiveDate='Effective Date';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.supplierRateQuery='Supplier Rate Query Service Code';
Modules.LblsAndTtls.cargoType='Cargo Type';
Modules.LblsAndTtls.cargoClass='Cargo Class';
Modules.LblsAndTtls.pfdBerthCodelbl ='PFD Berth Code';
Modules.LblsAndTtls.pfdPortCall   = 'PFD Port Call';

Modules.LblsAndTtls.supplierInvoiceStausGridLbl		=		'Supplier Invoice Status Grid Record';
/***********************************************************************/
//#Customer Invoice Status for Ocean
/***********************************************************************/
Modules.LblsAndTtls.printTypeLbl					=		'Print';
Modules.LblsAndTtls.customerInvoiceStausGridLbl		=		'Customer Invoice Status Details';
Modules.contract.ocean_customer_master.labels.roundingCriteria='Rounding Criteria';
Modules.contract.ocean_customer_master.labels.partyType='Party Type';

Modules.LblsAndTtls.popupoceanCustomerRateQueryRecordViewGridTlt='Customer Rate Query Grid Record';
Modules.LblsAndTtls.popupoceanCustomerRateQueryPopWinRecordViewGridTlt='Customer Rate Query New Contract Grid Record';


/*********************************************************************/
//#Ocean Customer Reconcilation Tab DashBoard 
/*********************************************************************/
Modules.LblsAndTtls.custReconcilation.customer = 'Customer';
Modules.LblsAndTtls.custReconcilation.invcCurncy = 'Invoice Currency';
Modules.LblsAndTtls.custReconcilation.invcType = 'Invoice Type';
Modules.LblsAndTtls.custReconcilation.InvLineItmAgngOnDueDate = 'Invoice Line Item Aging(Days from Rejection)';
Modules.LblsAndTtls.custReconcilation.oneDay = '1 Day';
Modules.LblsAndTtls.custReconcilation.count = 'Count';
Modules.LblsAndTtls.custReconcilation.twoToFiveDays = '2-5 Days';
Modules.LblsAndTtls.custReconcilation.invcAmt = 'Invoice Amount';
Modules.LblsAndTtls.custReconcilation.InvLineItmAgngOnDaysFrmCreatn = 'Invoice Line Item Aging(Days from Creation)';


/***********************************************************************/
//#EVENT RATING QUERY
/***********************************************************************/
Modules.operations.event_details.event_rating_query.labels.servicecode = 'Service Code';
Modules.operations.event_details.event_rating_query.labels.shipmentDate = 'Shipment Date';
Modules.operations.event_details.event_rating_query.labels.deliveryCompletionDate = 'Dlvy/Cmpltn Date';
Modules.operations.event_details.event_rating_query.labels.modelYear = 'Model Year';
Modules.operations.event_details.event_rating_query.labels.partNumber = 'Part Number';
Modules.operations.event_details.event_rating_query.labels.storageQuantity = 'Storage Qty';
Modules.operations.event_details.event_rating_query.labels.quantity = 'Quantity';
Modules.operations.event_details.event_rating_query.labels.storageUom = 'Storage UOM';
Modules.operations.event_details.event_rating_query.labels.profitLossCenter = 'Profit/Loss Center';
Modules.operations.event_details.event_rating_query.labels.prevChargeQuantity = 'Prev Chrg Qty';
Modules.operations.event_details.event_rating_query.labels.prevChargeUom = 'Prev Chrg UOM';
Modules.operations.event_details.event_rating_query.labels.value = 'Value';
Modules.operations.event_details.event_rating_query.labels.uom = 'UOM';
Modules.operations.event_details.event_rating_query.labels.ratingDest = 'Rating Destination';
Modules.operations.event_details.event_rating_query.labels.notChargeable =  'Not Chargeable';
Modules.operations.event_details.event_rating_query.labels.glCode = 'GL Code';
Modules.operations.event_details.event_rating_query.labels.currency = 'Currency';
Modules.operations.event_details.event_rating_query.labels.serviceAmt = 'Service Amount';
Modules.operations.event_details.event_rating_query.labels.taxAmt = 'Tax Amount';
Modules.operations.event_details.event_rating_query.labels.totalAmt = 'Total Amount';
Modules.operations.event_details.event_rating_query.labels.servDescr='Srvc Description';
Modules.operations.event_details.event_rating_query.labels.invNumber = 'Invoice Number';
Modules.operations.event_details.event_rating_query.labels.servGroup = 'Service Group';
Modules.operations.event_details.event_rating_query.labels.debtorParty = 'Debtor Party';
Modules.operations.event_details.event_rating_query.labels.consolidationType = 'Cnsldtn Type';
Modules.operations.event_details.event_rating_query.labels.originStateProvince = 'Origin S/P';
Modules.operations.event_details.event_rating_query.labels.destinationStateProvince = 'Destination S/P';
Modules.operations.event_details.event_rating_query.labels.status='Status';
//Modules.operations.event_details.event_rating_query.labels.consolidationType='cnsldtn Type';

/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY   START
/***********************************************************************/

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.parentTabPanelTtl = 'Customer Invoice Entry';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cstmrinvEntryFormTtl = 'Customer Invoice Query Ocean';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cstmrinvEntryFormGPTtl = 'Invoice Header';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cstmrinvEntryFormPGTtl = 'Invoice Details';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cstmrinvEntryFormCHTtl = 'Cargo Details';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupWinTtl = 'Invoice Header';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.PGridPopupWinTtl = 'Invoice Details';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.CHGridPopupWinTtl = 'Cargo Details';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.statusForm = 'Status';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerComboTtl = 'Customer';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerNameTtl = 'Customer Name';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerCodeTtl = 'Customer';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceNumberGP = 'Invoice Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceDateGP = 'Invoice Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceDueDateGP = 'Invoice Due Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceCurrencyGP = 'Invoice Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.voyageNumberGP = 'Voyage Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popGP = 'POP';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popCurrencyGP = 'POP Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polGP = 'POL';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podGP = 'POD';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porGP = 'POR';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.contactPersonGP = 'Contact Person';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumberGP = 'BL Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumber = 'BL Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.profitLossGP = 'Profit/Loss Center';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.remarksGP = 'Remarks';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.printTemplateGP = 'Print Template';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.sailingDateGP = 'Sailing Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.statusGP = 'Invoice Status';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.paymentDtlsGP = 'Payment Details';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.partyGP = 'Party';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.nameGP = 'Name';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.addrLane1GP = 'Address Line1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.addrLane2GP = 'Address Line2';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.addrLane3GP = 'Address Line3';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cityGP = 'City';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.stateProvGP = 'State/Province';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.countryGP = 'Country';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.zipPostalCdGP = 'Zip/Postal Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceTypeGP = 'Invoice Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.docTypeGP = 'Document Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.freightTermsGP = 'Freight Terms';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceClause1GP = 'Invoice Clause1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceClause2GP = 'Invoice Clause2';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalInvcAmtGP = 'Total Invoice Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.refInvcNoGP = 'Reference Invoice Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.headerClause = 'Header Clause';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.proformaUserName = 'Proforma Created User Name';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.proformaDate = 'Proforma Created Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.finalizeUserName = 'Finalize Created User Name';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.finalizeDate = 'Finalize Created Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.extPrfInvcNo = 'External Proforma Invoice Number';
	
Modules.LblsAndTtls.BlTypeLbl = 'BL Type';
Modules.LblsAndTtls.commodityCodeLbl = 'Commodity Code';
Modules.LblsAndTtls.refInvcNbr   ='Ref Invc Nbr';
	
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.chargeCd = 'Service Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumber = 'BL Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blType = 'BL Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.descr = 'Service Description';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvGrpCd = 'Service Group Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvGrpCdPop = 'Service Grp Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.voyage = 'Voyage';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.vesselName = 'Vessel Name';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shippingRefNo = 'Shipping Reference Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shippingRefNoPop = 'Shipping Ref No.';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.transportCd = 'Transport Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.make = 'Make Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.model = 'Model Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.year = 'Model Year';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rateTier = 'Rate Tier';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polSI = 'POL SI';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pol = 'POL';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podSI = 'POD SI';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pod = 'POD';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shipmentDate = 'Shipment Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.por = 'POR';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfd = 'PFD';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shipmentType = 'Shipment Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.UOM = 'UOM';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.quantity = 'Service Unit Qty';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.itemQuantity = 'Item Quantity';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rateBasis = 'Rate Basis';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rate = 'Rate';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.supplier = 'Supplier';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.serviceAmt = 'Service Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestCrncy = 'Manifest Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestAmt = 'Manifest Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceCrncy = 'Invoice Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceAmt = 'Invoice Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.usdEqAmt = 'USD Equivalent Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.usdEqAmtPop = 'USD Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.vesselCode = 'Vessel Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invcItemSts = 'Invoice Item Status';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.serviceType = 'Service Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cargoClassCd = 'Cargo Class Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cargoTypeCd = 'Cargo Type Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.commodityCd = 'Commodity Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.commodityDesc = 'Commodity Description';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.commodityDes = 'Commodity Desc';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.itemNo = 'Item Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.vatFlg = 'Tax Service Flag';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.transType = 'Transaction Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.exchangeRate = 'Exchange Rate';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvUnitQty = 'Service Unit Quantity';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blcmpDate = 'BL Completion Date';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porBerthCd = 'POR Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porPortCall = 'POR Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polBerthCd = 'POL Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polPortCall = 'POL Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podBerthCd = 'POD Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podPortCall = 'POD Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfdBerthCd = 'PFD Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfdPortCall = 'PFD Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invcItemNo = 'Invoice Item Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.originalInvcNum = 'Original Invoice Number';

Modules.LblsAndTtls.paidAmtManifestCurrency ='Paid Amount Manifest Currency';
Modules.LblsAndTtls.paidAmtLocalCurrency    = 'Paid Amount Local Currency';
Modules.LblsAndTtls.paidAmtUsdCurrency      = 'Paid Amount USD';
Modules.LblsAndTtls.srvcUnitQtyLbl  ='Service Unit Quantity';
Modules.LblsAndTtls.taxServiceFlag   = 'Tax Service Flag';
Modules.LblsAndTtls.invcItemStsLbl ='Invoice Item Status';
Modules.LblsAndTtls.invcItemNbrLbl = 'Invoice Item Number';
Modules.LblsAndTtls.transactionTypeLbl = 'Transaction Type';
Modules.LblsAndTtls.billofLadingType = 'Bill of Lading Type';
Modules.LblsAndTtls.billIssueDate    = 'Bill Issue Date';
Modules.LblsAndTtls.transactionType = 'Trans Type';
Modules.LblsAndTtls.berthCodeLbl   =  'Berth Code';
Modules.LblsAndTtls.portCallLbl  = 'Port Call';
Modules.LblsAndTtls.cstmrVatNbr = 'Customer Vat Number';
Modules.LblsAndTtls.cstmrVatNbrAbbLbl  = 'Cstmr VAT Nbr';
Modules.LblsAndTtls.cstmrContactPrsn = 'Customer Contact Person';
Modules.LblsAndTtls.cstmrContactPrsnAbbLbl = 'Cstmr Contact Prsn'; 
Modules.LblsAndTtls.itemQtyLbl ='Item Quantity';
Modules.LblsAndTtls.originalInvcNbrLbl ='Original Invoice Number';
Modules.LblsAndTtls.originalInvcNbrShortLbl ='Original Invc Nbr';
Modules.LblsAndTtls.lineItemIdentifierLbl ='Line Item Identifier ';

Modules.LblsAndTtls.manifestCurrencyCdLbl = 'Manifest Currency Code';
Modules.LblsAndTtls.srvcAmtManifestCurrencyLbl = 'Service Amount Manifest Currency';
Modules.LblsAndTtls.srvcAmtLocalCurrencyLbl = 'Service Amount Local Currency';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cargoIdCh = 'Cargo ID';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.weightCh = 'Weight';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.weightUomCdCh = 'Weight UOM Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.lengthCh = 'Length';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.lengthUOMcdCh = 'Length UOM Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.widthCh = 'Width';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.heightCh = 'Height';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.volumeCh = 'Volume';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cubeCh = 'Cube';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.chrgQtyCh = 'Charge Quantity';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.tariffRateCh = 'Tariff Rate';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvAmtMnfstCrcnyCh = 'Service Amount Manifest Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestCrncyCdCh = 'Manifest Currency Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.exchgRateCh = 'Exchange Rate';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.localCrncyCh = 'Local Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.localCrncyCdCh = 'Local Currency Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.usdCrncyCh = 'USD Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.barCdCh = 'Bar Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.handlingIndCh = 'Handling Indicator';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.gearCh = 'Gear';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.steeringCh = 'Steering';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.hzrdsFlgCh = 'Hazardous Flag';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.uomCdCh = 'UOM Code';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.weightUomCdChs = 'Weight UOM Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.lengthUOMcdChs = 'Length UOM Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvAmtMnfstCrcnyChs = 'Manifest Crncy';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestCrncyCdChs = 'Manifest Crncy Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.localCrncyCdChs = 'Local Crncy Code';




Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxTypeTg = 'Tax Type';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxPercentTg = 'Tax Percentage';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvcAmtTg = 'Service Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxAmtTg = 'Tax Amount';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalSrvcAmtRF = 'Total Service Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalTaxAmtRF = 'Total Tax Amount';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalAmtRF = 'Total Amount';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupInvcRadio = 'Invoice';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupCrdtNoteRadio = 'Credit Note';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupDbtNoteRadio = 'Debit Note';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupActualRadio = 'Actual';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupAccrualRadio = 'Accrual';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.copyInvoiceTtl = 'Copy Invoice';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.copyInvcCompanyCode = 'Company Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.copyInvcCustomerInvcNo = 'Customer Invoce Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.copyInvcCustomerCode = 'Customer Code';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.editWindowToolTip = 'Edit Window';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvDescr = 'Service Desc';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invcItemStatus = 'Invc Item Sts';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invcItemNbr = 'Invc Item No.';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.servUnitQty = 'Srv Unit Qty';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blcmplDate = 'BL Cmpltn Date';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polToolTip = 'Port Of Load';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popToolTip = 'Place Of Payment';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podToolTip = 'Port Of Discharge';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfdToolTip = 'Place of Final Delivery';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porToolTip = 'Place of Receipt';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polSIToolTip = 'Port Of Load SI';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popcrncyToolTip = 'Place Of Payment Currency';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popcrncyCdToolTip = 'Place Of Payment Currency Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podSIToolTip = 'Port Of Discharge SI';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.portDetails = 'Port Details';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumberToolTip = 'Bill of Lading Number';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polBerthCodeToolTip='Port Of Load Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podBerthCodeToolTip='Port Of Discharge Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porBerthCodeToolTip='Place of Receipt Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfdBerthCodeToolTip='Place of Final Delivery Berth Code';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polPortCallToolTip='Port Of Load Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podPortCallToolTip='Port Of Discharge Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porPortCallToolTip='Place of Receipt Port Call';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfdPortCallToolTip='Place of Final Delivery Port Call';

/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY     END
/***********************************************************************/


Modules.Msgs.podTooltip='Port Of Discharge';
Modules.Msgs.polTooltip='Port Of Load';
Modules.Msgs.popTooltip='Port Of Payment';

/********************************************************************************/
//#CustomerLineItemStatus_Ocean
/**********************************************************************************/
Modules.ocean.customer_invoice.customer_line_item_status.labels.billNumber='Bill of Lading';
Modules.ocean.customer_invoice.customer_line_item_status.labels.billNumberFull='Bill of Lading Number';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceNumber='Invoice Number';
Modules.ocean.customer_invoice.customer_line_item_status.labels.chargeCode='Charge Code';
Modules.ocean.customer_invoice.customer_line_item_status.labels.cstmrCd='Party';
Modules.ocean.customer_invoice.customer_line_item_status.labels.dbtrPartyCd='Debtor Party';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceFromDate='From Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceToDate='To Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceFromDateFull='Invoice From Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceToDateFull='Invoice To Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.pop='POP';
Modules.ocean.customer_invoice.customer_line_item_status.labels.pol='POL';
Modules.ocean.customer_invoice.customer_line_item_status.labels.pod='POD';
Modules.ocean.customer_invoice.customer_line_item_status.labels.serviceType='Service Type';
Modules.ocean.customer_invoice.customer_line_item_status.labels.vessel='Vessel';
Modules.ocean.customer_invoice.customer_line_item_status.labels.shippingReference='Shipping Ref';
Modules.ocean.customer_invoice.customer_line_item_status.labels.documentReference='Document Ref';
Modules.ocean.customer_invoice.customer_line_item_status.labels.proformaText='Proforma';
Modules.ocean.customer_invoice.customer_line_item_status.labels.rejectedText='Rejected';
Modules.ocean.customer_invoice.customer_line_item_status.labels.finalText='Final';
Modules.ocean.customer_invoice.customer_line_item_status.labels.paidText='Paid';
Modules.ocean.customer_invoice.customer_line_item_status.labels.actualRadioButton='Actual';
Modules.ocean.customer_invoice.customer_line_item_status.labels.accuralRadioButton='Accural';
Modules.ocean.customer_invoice.customer_line_item_status.labels.ascendRadioButton='Ascending';
Modules.ocean.customer_invoice.customer_line_item_status.labels.descendRadioButton='Descending';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceText='Invoice';
Modules.ocean.customer_invoice.customer_line_item_status.labels.creditText='Credit Note';
Modules.ocean.customer_invoice.customer_line_item_status.labels.debitText='Debit Note';
Modules.ocean.customer_invoice.customer_line_item_status.labels.pdfRadioButton='PDF';
Modules.ocean.customer_invoice.customer_line_item_status.labels.excelRadioButton='Excel';
Modules.ocean.customer_invoice.customer_line_item_status.labels.statusFieldSet='Status';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceTypeFieldSet='Invoice Type';
Modules.ocean.customer_invoice.customer_line_item_status.labels.sortOptionsFieldSet='Sort Options';
Modules.ocean.customer_invoice.customer_line_item_status.labels.docTypeFieldSet='Document Type';
Modules.ocean.customer_invoice.customer_line_item_status.labels.reportOutputFieldSet='Report Output';
Modules.ocean.customer_invoice.customer_line_item_status.labels.company='Company';
Modules.ocean.customer_invoice.customer_line_item_status.labels.pop='POP';
Modules.ocean.customer_invoice.customer_line_item_status.labels.manifestCurrency='Manifest Currency';
Modules.ocean.customer_invoice.customer_line_item_status.labels.manifestAmount='Manifest Amount';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceCurrency='Invoice Currency';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceAmount='Invoice Amount';
Modules.ocean.customer_invoice.customer_line_item_status.labels.usdEquivalentAmount='USD Equiv Amt';
Modules.ocean.customer_invoice.customer_line_item_status.labels.paidAmount='Paid Amount';
Modules.ocean.customer_invoice.customer_line_item_status.labels.billCompletionDate='BL Completion Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceDate='Invoice Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.dueDate='Due Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.lastPaymentDate='Last Payment Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.lineItemStatus='Line Item Status';
Modules.ocean.customer_invoice.customer_line_item_status.labels.reason='Reason';
Modules.ocean.customer_invoice.customer_line_item_status.labels.usdEquivalentAmountFullLbl='USD Equivalent Amount';
Modules.ocean.customer_invoice.customer_line_item_status.labels.documentReferenceFullLbl='Document Reference Number';
Modules.ocean.customer_invoice.customer_line_item_status.labels.tarrifCurncyInd='Tariff Currency';
Modules.ocean.customer_invoice.customer_line_item_status.labels.shippingReferenceFullLbl='Shipping Reference Number';
Modules.ocean.customer_invoice.customer_line_item_status.labels.formTitle='Customer Line Item Status Ocean';
Modules.ocean.customer_invoice.customer_line_item_status.labels.gridRecords='Customer Line Item Status Grid Records';
Modules.ocean.customer_invoice.customer_line_item_status.labels.tabParentPanelLbl='Customer Line Item Status';
Modules.ocean.customer_invoice.customer_line_item_status.labels.proformaUserName='Proforma Created User Name';
Modules.ocean.customer_invoice.customer_line_item_status.labels.proformaDate='Proforma Created Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.finalizeUserName='Finalize Created User Name';
Modules.ocean.customer_invoice.customer_line_item_status.labels.finalizeDate='Finalize Created Date';
Modules.ocean.customer_invoice.customer_line_item_status.labels.headerClause='Header Clause';
Modules.ocean.customer_invoice.customer_line_item_status.labels.extPrfInvcNo='External Proforma Invoice Number';

/**
 * 
 *  Non ocean Customer Invoice entry screen labels
 * 
 * 
 */

Modules.customer_invoice.customer_invoice_entry.labels.GPGridTitle                   		=	'Invoice Header(s)';
Modules.customer_invoice.customer_invoice_entry.labels.PGGridTitle							=   'Invoice Details';
Modules.customer_invoice.customer_invoice_entry.labels.TaxDetailsTitle						= 	'Invoice Tax Details & Summary Report';
Modules.customer_invoice.customer_invoice_entry.labels.company_code							=	'Company Code';
Modules.customer_invoice.customer_invoice_entry.labels.customer_code						=	'Customer Code';
Modules.customer_invoice.customer_invoice_entry.labels.customerNameTlt						=	'Customer Name';
Modules.customer_invoice.customer_invoice_entry.labels.customer_invoice_number				=	"Customer Invoice Number";
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryTtl				    =	'Customer Invoice Entry';
Modules.customer_invoice.customer_invoice_entry.labels.finalizeActionTtl					= 	'Finalize';
Modules.customer_invoice.customer_invoice_entry.labels.rejectActionTtl						=	'Reject';
Modules.customer_invoice.customer_invoice_entry.labels.copyInvioceActionTtl					= 	'Copy Invoice';
Modules.customer_invoice.customer_invoice_entry.labels.viewInvoiceActionTtl					=	'View Invoice';
Modules.customer_invoice.customer_invoice_entry.labels.viewBackupActionTtl					= 	'View Backup';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceNumberGP						= 	'Invoice Number';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceRefNumberGP					= 	'Reference Invoice Number';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceDateGP						= 	'Invoice Date';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceDueDateGP						= 	'Invoice Due Date';
Modules.customer_invoice.customer_invoice_entry.labels.currencyGP							= 	'Currency';
Modules.customer_invoice.customer_invoice_entry.labels.profitLossCentreGP					= 	'Profit/Loss Center';
Modules.customer_invoice.customer_invoice_entry.labels.printTemplateGP						= 	'Print Template';
Modules.customer_invoice.customer_invoice_entry.labels.statusGP								= 	'Status';
Modules.customer_invoice.customer_invoice_entry.labels.remarksGP							= 	'Remarks';
Modules.customer_invoice.customer_invoice_entry.labels.docTypeGP							= 	'Document Type';
Modules.customer_invoice.customer_invoice_entry.labels.invcTypeGP							= 	'Invoice Type';
Modules.customer_invoice.customer_invoice_entry.labels.paymentDtlsGP						= 	'Payment Details';
Modules.customer_invoice.customer_invoice_entry.labels.partyGP								= 	'Party';
Modules.customer_invoice.customer_invoice_entry.labels.nameGP								= 	'Name';
Modules.customer_invoice.customer_invoice_entry.labels.addLane1GP							= 	'Address Line 1';
Modules.customer_invoice.customer_invoice_entry.labels.addLane2GP							= 	'Address Line 2';
Modules.customer_invoice.customer_invoice_entry.labels.cityGP								= 	'City';
Modules.customer_invoice.customer_invoice_entry.labels.stateProvGP							= 	'State/Province';
Modules.customer_invoice.customer_invoice_entry.labels.countryGP							= 	'Country';
Modules.customer_invoice.customer_invoice_entry.labels.zipPostalCdGP						= 	'Zip/Postal Code';
Modules.customer_invoice.customer_invoice_entry.labels.srvCodePG							= 	'Service Code';
Modules.customer_invoice.customer_invoice_entry.labels.srvDescPG							= 	'Service Desc';
Modules.customer_invoice.customer_invoice_entry.tooltip.srvDescPG							= 	'Service Description';
Modules.customer_invoice.customer_invoice_entry.tooltip.srvTypePG							= 	'Service Type';
Modules.customer_invoice.customer_invoice_entry.labels.srvcGrpPG							= 	'Service Group';
Modules.customer_invoice.customer_invoice_entry.labels.evntLdRefPG							= 	'Event/Load Ref';
Modules.customer_invoice.customer_invoice_entry.tooltip.evntLdRefPG							= 	'Event/Load Reference';
Modules.customer_invoice.customer_invoice_entry.labels.unitIdPG								= 	'Unit ID';
Modules.customer_invoice.customer_invoice_entry.labels.convncIdPG							= 	'Conveyance ID';
Modules.customer_invoice.customer_invoice_entry.labels.convncTypePG							= 	'Conveyance Type';
Modules.customer_invoice.customer_invoice_entry.labels.convncNmPG							= 	'Conveyance Nm';
Modules.customer_invoice.customer_invoice_entry.tooltip.convncNmPG							= 	'Conveyance Name';
Modules.customer_invoice.customer_invoice_entry.labels.shipngRefNoPG						= 	'Shipping Ref No.';
Modules.customer_invoice.customer_invoice_entry.tooltip.shipngRefNoPG						= 	'Shipping Reference Number';
Modules.customer_invoice.customer_invoice_entry.labels.storageTypePG						= 	'Storage Type';
Modules.customer_invoice.customer_invoice_entry.labels.cargoTypePG							= 	'Cargo Type';
Modules.customer_invoice.customer_invoice_entry.labels.modelLinePG							= 	'Model Line';
Modules.customer_invoice.customer_invoice_entry.labels.billOfLadingPG						= 	'Bill of Lading';
Modules.customer_invoice.customer_invoice_entry.labels.transptCdPG							= 	'Transport Code';
Modules.customer_invoice.customer_invoice_entry.labels.makeCdPG								= 	'Make Code';
Modules.customer_invoice.customer_invoice_entry.labels.modelCdPG							= 	'Model Code';
Modules.customer_invoice.customer_invoice_entry.labels.modelGrpPG							= 	'Model Group';
Modules.customer_invoice.customer_invoice_entry.labels.modelYearPG							= 	'Model Year';
Modules.customer_invoice.customer_invoice_entry.labels.trnsptModePG							= 	'Transport Mode';
Modules.customer_invoice.customer_invoice_entry.labels.rateTierPG							= 	'Rate Tier';
Modules.customer_invoice.customer_invoice_entry.labels.wrkOrderPG							= 	'Work Order';
Modules.customer_invoice.customer_invoice_entry.labels.partIdPG								= 	'Part ID';
Modules.customer_invoice.customer_invoice_entry.labels.orgnDtlsPG							= 	'Origin Details';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocPG							= 	'Origin/Location';
Modules.customer_invoice.customer_invoice_entry.labels.orgnAdd1PG							= 	'Origin Address 1';
Modules.customer_invoice.customer_invoice_entry.labels.orgnAdd2PG							= 	'Origin Address 2';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocCtyPG							= 	'Org/Loc City';
Modules.customer_invoice.customer_invoice_entry.tooltip.orgnLocCtyPG						= 	'Origin/Location City';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocStPPG							= 	'Org/Loc St/Prov';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocCntryPG						= 	'Origin Country';
Modules.customer_invoice.customer_invoice_entry.tooltip.orgnLocStPPG						= 	'Origin/Location State/Province';
Modules.customer_invoice.customer_invoice_entry.labels.orgnZipPostalCdPG					= 	'Org Zip/Pstl Code';
Modules.customer_invoice.customer_invoice_entry.tooltip.orgnZipPostalCdPG					= 	'Origin Zip/Postal Code';
Modules.customer_invoice.customer_invoice_entry.labels.destDetlsPG							= 	'Destination Details';
Modules.customer_invoice.customer_invoice_entry.labels.destCdPG								= 	'Destination Code';
Modules.customer_invoice.customer_invoice_entry.labels.destAdd1PG							= 	'Dest Addr 1';
Modules.customer_invoice.customer_invoice_entry.tooltip.destAdd1PG							= 	'Destination Address 1';
Modules.customer_invoice.customer_invoice_entry.labels.destAdd2PG							= 	'Dest Addr 2';
Modules.customer_invoice.customer_invoice_entry.tooltip.destAdd2PG							= 	'Destination Address 2';
Modules.customer_invoice.customer_invoice_entry.labels.destCityPG							= 	'Destination City';
Modules.customer_invoice.customer_invoice_entry.labels.destCityNamePG						= 	'Destination City Name';
Modules.customer_invoice.customer_invoice_entry.labels.destStateProvPG						= 	'Dest State/Prov';
Modules.customer_invoice.customer_invoice_entry.tooltip.destStateProvPG						= 	'Destination State/Province';
Modules.customer_invoice.customer_invoice_entry.labels.destCntryCdPG						= 	'Dest Country';
Modules.customer_invoice.customer_invoice_entry.tooltip.destCntryCdPG						= 	'Destination Country';
Modules.customer_invoice.customer_invoice_entry.labels.destZipPostalCdPG					= 	'Dest Zip/Pstl Code';
Modules.customer_invoice.customer_invoice_entry.tooltip.destZipPostalCdPG					= 	'Destination Zip/Postal Code';
Modules.customer_invoice.customer_invoice_entry.labels.tndrReqDtPG							= 	'Tndr/Req Date';
Modules.customer_invoice.customer_invoice_entry.tooltip.tndrReqDtPG							= 	'Tender/Request Date';
Modules.customer_invoice.customer_invoice_entry.labels.shipntDtPG							= 	'Shipment Date';
Modules.customer_invoice.customer_invoice_entry.labels.delCmpltDtPG							= 	'Del/Cmpl Date';
Modules.customer_invoice.customer_invoice_entry.tooltip.delCmpltDtPG						= 	'Delivery/Completion Date';
Modules.customer_invoice.customer_invoice_entry.labels.origOrgPG							= 	'Original Origin';
Modules.customer_invoice.customer_invoice_entry.labels.finalDestPG							= 	'Final Destination';
Modules.customer_invoice.customer_invoice_entry.labels.dist2DestAndRatingDestPG				= 	'Distance To Destination and Rating Destination';
Modules.customer_invoice.customer_invoice_entry.labels.dist2DestPG							= 	'Distance To Destination';
Modules.customer_invoice.customer_invoice_entry.labels.valPG								= 	'Value';
Modules.customer_invoice.customer_invoice_entry.labels.UomPG								= 	'UOM';
Modules.customer_invoice.customer_invoice_entry.tooltip.UomPG								= 	'Unit Of Measure';
Modules.customer_invoice.customer_invoice_entry.labels.ratingDestPG							= 	'Rating Destination';
Modules.customer_invoice.customer_invoice_entry.labels.dist2RtngDestPG						= 	'Distance To Rating Destination';
Modules.customer_invoice.customer_invoice_entry.labels.minNumPG								= 	'Minimum Number';
Modules.customer_invoice.customer_invoice_entry.labels.prftLossCentPG						= 	'Prft/Loss Cent';
Modules.customer_invoice.customer_invoice_entry.tooltip.prftLossCentPG						= 	'Profit/Loss Center';
Modules.customer_invoice.customer_invoice_entry.labels.custSlsRgnPG							= 	'Cstmr Sales Reg';
Modules.customer_invoice.customer_invoice_entry.tooltip.custSlsRgnPG						= 	'Customer Sales Region';
Modules.customer_invoice.customer_invoice_entry.labels.shmntTypePG							= 	'Shipment Type';
Modules.customer_invoice.customer_invoice_entry.labels.ordrTypPG							= 	'Order Type';
Modules.customer_invoice.customer_invoice_entry.labels.abnrmMvTypePG						= 	'Abnrml Mv Type';
Modules.customer_invoice.customer_invoice_entry.tooltip.abnrmMvTypePG						= 	'Abnormal Move Type';
Modules.customer_invoice.customer_invoice_entry.labels.dlrCdPG								= 	'Dealer Code';
Modules.customer_invoice.customer_invoice_entry.labels.suplrCdPG							= 	'Supplier Code';
Modules.customer_invoice.customer_invoice_entry.labels.consolIdPG							= 	'Consol ID';
Modules.customer_invoice.customer_invoice_entry.tooltip.consolIdPG							= 	'Consolidation ID';
Modules.customer_invoice.customer_invoice_entry.labels.consolTypePG							= 	'Consol Type';
Modules.customer_invoice.customer_invoice_entry.tooltip.consolTypePG						= 	'Consolidation Type';
Modules.customer_invoice.customer_invoice_entry.labels.srvcAmtQttyDtlsPG					= 	'Service Amount and Quantity Details';
Modules.customer_invoice.customer_invoice_entry.labels.uom1PG								= 	'UOM 1';
Modules.customer_invoice.customer_invoice_entry.tooltip.uom1PG								= 	Modules.customer_invoice.customer_invoice_entry.tooltip.UomPG + ' 1';
Modules.customer_invoice.customer_invoice_entry.labels.uom2PG								= 	'UOM 2';
Modules.customer_invoice.customer_invoice_entry.tooltip.uom2PG								= 	Modules.customer_invoice.customer_invoice_entry.tooltip.UomPG + ' 2';
Modules.customer_invoice.customer_invoice_entry.labels.qntty1PG								= 	'Quantity 1';
Modules.customer_invoice.customer_invoice_entry.labels.qntty2PG								= 	'Quantity 2';
Modules.customer_invoice.customer_invoice_entry.labels.rtbsisPG								= 	'Rate Basis';
Modules.customer_invoice.customer_invoice_entry.labels.itemNoPG								= 	'Item No.';
Modules.customer_invoice.customer_invoice_entry.labels.ratePG								= 	'Rate';
Modules.customer_invoice.customer_invoice_entry.labels.srvcAmtPG							= 	'Srvc Amount';
Modules.customer_invoice.customer_invoice_entry.tooltip.srvcAmtPG							= 	'Service Amount';
Modules.customer_invoice.customer_invoice_entry.labels.taxTypChG							= 	'Tax Type';
Modules.customer_invoice.customer_invoice_entry.labels.taxPercntChG							= 	'Tax Percentage';
Modules.customer_invoice.customer_invoice_entry.labels.taxAmtChG							= 	'Tax Amount';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotSrvcAmt				= 	'Total Service Amount';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotTaxAmt				= 	'Total Tax Amount';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotAmt					= 	'Total Amount';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormTtl			= 	Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryTtl;
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormInvoiceTlt	=	'Invoice';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormCrdtNote		= 	'Credit Note';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormDbtNote		=	'Debit Note';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormDocTypeTtl	= 	'Document Type';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormInvcTypeTtl	= 	'Invoice Type';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormActual		=	'Actual';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormAcrual		=	'Accrual';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormPaymentDtlsTtl 	=	'Payment Details';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormCurrencyTtl 		= 	'Currency';
Modules.LblsAndTtls.EventRating = 'Event Rating Query';
Modules.LblsAndTtls.EventRatingCustomerTaxDetailsTlt = 'Customer Tax Details';
Modules.LblsAndTtls.EventRatingSupplierTaxDetailsTlt = 'Supplier Tax Details';

/**
 * 
 *  Non ocean Supplier Rate Reconciliation screen labels
 * 
 * 
 */
Modules.contract.supplier.supRateRecon.labels.supRateReconTtl								=	'Supplier Rate Reconciliation';
Modules.contract.supplier.supRateRecon.labels.supplier										=	'Supplier';
Modules.contract.supplier.supRateRecon.labels.itemStatus									=	'Item Status';
Modules.contract.supplier.supRateRecon.labels.batchNumber									=	'Batch Number';
Modules.contract.supplier.supRateRecon.labels.effectiveDate									=	'Effective Date';
Modules.contract.supplier.supRateRecon.labels.customerCode									=	'Customer Code';
Modules.contract.supplier.supRateRecon.labels.srvCode										=	'Service Code';
Modules.contract.supplier.supRateRecon.labels.trnsptMode									=	'Transport Mode';
Modules.contract.supplier.supRateRecon.labels.rateTier										=	'Rate Tier';
Modules.contract.supplier.supRateRecon.labels.orgnLoc										=	'Origin/Location';
Modules.contract.supplier.supRateRecon.labels.dest											=	'Destination';
Modules.contract.supplier.supRateRecon.labels.convType										=	'Conveyance Type';
Modules.contract.supplier.supRateRecon.labels.makeCode										=	'Make Code';
Modules.contract.supplier.supRateRecon.labels.modelCode										=	'Model Code';
Modules.contract.supplier.supRateRecon.labels.modelYear										=	'Model Year';
Modules.contract.supplier.supRateRecon.labels.modelGrpCd									=	'Model Grp Code';
Modules.contract.supplier.supRateRecon.tooltip.modelGrpCd									=	'Model Group Code';
Modules.contract.supplier.supRateRecon.labels.partId										=	'Part ID';
Modules.contract.supplier.supRateRecon.labels.orgLocCity									=	'Orgn/Loc City';
Modules.contract.supplier.supRateRecon.tooltip.orgLocCity									=	'Origin/Location City';
Modules.contract.supplier.supRateRecon.labels.orgLocStProv									=	'Orgn/Loc St/Prov';
Modules.contract.supplier.supRateRecon.tooltip.orgLocStProv									=	'Origin/Location State/Province';
Modules.contract.supplier.supRateRecon.labels.orgLocCoun									=	'Origin Country';
Modules.contract.supplier.supRateRecon.labels.destCity										=	'Destination City';
Modules.contract.supplier.supRateRecon.labels.destStProv									=	'Dest St/Prov';
Modules.contract.supplier.supRateRecon.tooltip.destStProv									=	'Destination State/Province';
Modules.contract.supplier.supRateRecon.labels.destCoun										=	'Dest Country';
Modules.contract.supplier.supRateRecon.tooltip.destCoun										=	'Destination Country';
Modules.contract.supplier.supRateRecon.labels.origOrg										=	'Original Origin';
Modules.contract.supplier.supRateRecon.labels.finalDest										=	'Final Destination';
Modules.contract.supplier.supRateRecon.labels.consolTypeCd									=	'Consld Type Code';
Modules.contract.supplier.supRateRecon.tooltip.consolTypeCd									=	'Consolidation Type Code';
Modules.contract.supplier.supRateRecon.labels.accessryRef									=	'Accessory Ref';
Modules.contract.supplier.supRateRecon.tooltip.accessryRef									=	'Accessory Reference';
Modules.contract.supplier.supRateRecon.labels.modelLineRef									=	'Model Line Ref';
Modules.contract.supplier.supRateRecon.tooltip.modelLineRef									=	'Model Line Reference';
Modules.contract.supplier.supRateRecon.labels.makeRef										=	'Make Ref';
Modules.contract.supplier.supRateRecon.tooltip.makeRef										=	'Make Reference';
Modules.contract.supplier.supRateRecon.labels.plantRef										=	'Plant Ref';
Modules.contract.supplier.supRateRecon.tooltip.plantRef										=	'Plant Reference';
Modules.contract.supplier.supRateRecon.labels.noOfHrs										=	'Number of Hours';
Modules.contract.supplier.supRateRecon.labels.hrlyRate										=	'Hourly Rate';
Modules.contract.supplier.supRateRecon.labels.flatRate										=	'Flat Rate';
Modules.contract.supplier.supRateRecon.labels.fapsRate										=	'Faps Rate';
Modules.contract.supplier.supRateRecon.labels.errRson										=	'Error Reason';


/**
 * 
 *  Non ocean Customer Payment Details screen labels
 * 
 * 
 */

Modules.customer_invoice.customer_payment_dtls.labels.cstmrPaymntDtlsTtl					=	'Customer Payment Details';
Modules.customer_invoice.customer_payment_dtls.labels.debtorParty							=	'Debtor Pary';
Modules.customer_invoice.customer_payment_dtls.labels.paymentFromDate						= 	'Pmnt From Date';
Modules.customer_invoice.customer_payment_dtls.tooltip.paymentFromDate						= 	'Payment From Date';
Modules.customer_invoice.customer_payment_dtls.labels.paymentToDate							=	'Pmnt To Date';
Modules.customer_invoice.customer_payment_dtls.tooltip.paymentToDate						=	'Payment To Date';
Modules.customer_invoice.customer_payment_dtls.labels.invcNum								=	'Invoice Number';
Modules.customer_invoice.customer_payment_dtls.labels.invcFromDate							=	'Invoice From Date';
Modules.customer_invoice.customer_payment_dtls.labels.invcToDate							=	'Invoice To Date';
Modules.customer_invoice.customer_payment_dtls.labels.modeOfPayment							=	'Mode of Payment';
Modules.customer_invoice.customer_payment_dtls.labels.paymentDoc							=	'Pmnt Doc';
Modules.customer_invoice.customer_payment_dtls.tooltip.paymentDoc							=	'Payment Document';
Modules.customer_invoice.customer_payment_dtls.labels.unitId								=	'Unit ID';
Modules.customer_invoice.customer_payment_dtls.labels.srvType								=	'Service Type';
Modules.customer_invoice.customer_payment_dtls.labels.serviceCode							=	'Service Code';
Modules.customer_invoice.customer_payment_dtls.labels.evntLdRef								=	'Evnt/Ld Ref';
Modules.customer_invoice.customer_payment_dtls.tooltip.evntLdRef							=	'Event/Load Reference';
Modules.customer_invoice.customer_payment_dtls.labels.convyanceId							=	'Conveyance ID';
Modules.customer_invoice.customer_payment_dtls.labels.shippingRef							=	'Shipping Ref';
Modules.customer_invoice.customer_payment_dtls.tooltip.shippingRef							=	'Shipping Reference';
Modules.customer_invoice.customer_payment_dtls.labels.profitLossCentre						=	'Profit/Loss Center';
Modules.customer_invoice.customer_payment_dtls.labels.remitanceType							=	'Remittance Type'; 
Modules.customer_invoice.customer_payment_dtls.labels.docRef					     		=	'Doc Ref';
Modules.customer_invoice.customer_payment_dtls.tooltip.docRef					     		=	'Document Reference';
Modules.customer_invoice.customer_payment_dtls.labels.customer								=	'Customer';
Modules.customer_invoice.customer_payment_dtls.labels.invcDt								=	'Invoice Date';
Modules.customer_invoice.customer_payment_dtls.labels.paymentDt								=	'Payment Date';
Modules.customer_invoice.customer_payment_dtls.tooltip.paymentDt							=	'Payment Date';
Modules.customer_invoice.customer_payment_dtls.labels.paidAmt								=	'Paid Amount';
Modules.customer_invoice.customer_payment_dtls.labels.currency								=	'Currency';
Modules.customer_invoice.customer_payment_dtls.labels.serviceDesc							=	'Service Desc';
Modules.customer_invoice.customer_payment_dtls.tooltip.serviceDesc							=	'Service Description';
Modules.customer_invoice.customer_payment_dtls.labels.partId								=	'Part ID';
Modules.customer_invoice.customer_payment_dtls.labels.delCmpltDt							=	'Dlvry/CmplDt';
Modules.customer_invoice.customer_payment_dtls.tooltip.delCmpltDt							=	'Delivery/Completion Date';
Modules.customer_invoice.customer_payment_dtls.labels.advanceSearch							=	'Advance Search';
Modules.customer_invoice.customer_payment_dtls.labels.keySearch								=	'Key Search';
Modules.customer_invoice.customer_payment_dtls.labels.pmntHdr								=	'Payment Header(s)';
Modules.customer_invoice.customer_payment_dtls.labels.pmntDtls								=	'Payment Details';
			
/***********************************************************************/
//#Journal for Non Ocean
/***********************************************************************/
Modules.admin.journal.labels.formTitle	=	'Journal Log';
Modules.admin.journal.labels.tabTitle = 'Journaling';

Modules.admin.journal.labels.unitID	=	'Unit ID';
Modules.admin.journal.labels.invoice=	'Invoice Number';
Modules.admin.journal.labels.loadReferenceNumber =	'Load Ref No.';
Modules.admin.journal.labels.dateOrTime		=	'Date/Time';
Modules.admin.journal.labels.userID	=	'User ID';
Modules.admin.journal.labels.ediPartnerOrModule	=	'EDI Partner/Module';
Modules.admin.journal.labels.action	=	'Action'	;
Modules.admin.journal.labels.fieldName		=	'Field Name';
Modules.admin.journal.labels.invoiceNoOrUnitID	=	'Invoice/Unit ID';
Modules.admin.journal.labels.oldValue	=	'Old Value';
Modules.admin.journal.labels.newValue	=	'New Value';

Modules.LblsAndTtls.JournalGridTtl			=		'Journal Grid Record';



//Modules.LblsAndTtls.supplierInvcStsForOceanTtl			=	'Supplier Invoice Status For Ocean';



/***********************************************************************/
//#OCEAN SUPPLIER RATES
/***********************************************************************/

Modules.ocean.supplierRates.labels.formTtl='Supplier Rates';
Modules.ocean.supplierRates.labels.formValidFromDate='Valid From Date';
Modules.ocean.supplierRates.labels.formValidToDate='Valid To Date';
Modules.ocean.supplierRates.labels.remark='Remark';
Modules.ocean.supplierRates.labels.gridContrctId='Contract ID';
Modules.ocean.supplierRates.labels.gridSupplier='Supplier';
Modules.ocean.supplierRates.labels.gridSupplierName='Supplier Name';
Modules.ocean.supplierRates.labels.chargeCode='Service Code';
Modules.ocean.supplierRates.labels.effectiveDate='Effective Date';
Modules.ocean.supplierRates.labels.filter='Filter';
Modules.ocean.supplierRates.labels.party='Party';
Modules.ocean.supplierRates.labels.cargoClass='Cargo Class';
Modules.ocean.supplierRates.labels.cargoType='Cargo Type';
Modules.ocean.supplierRates.labels.seqno='Seq No.';
Modules.ocean.supplierRates.labels.priority='Priority';
Modules.ocean.supplierRates.labels.tariffCrncyCd='Tariff Currency Code';
Modules.ocean.supplierRates.labels.luInd='L/U Ind';
Modules.ocean.supplierRates.labels.tariffRate='Tariff Rate';
Modules.ocean.supplierRates.labels.fixedRate='Fixed Rate';
Modules.ocean.supplierRates.labels.factorRate='Factor Rate';
Modules.ocean.supplierRates.labels.factorType='Factor Type';
Modules.ocean.supplierRates.labels.factorValue='Factor Value';
Modules.ocean.supplierRates.labels.notChrgble='Not Chargeable';
Modules.ocean.supplierRates.labels.trnsfrGear='Transfer Gear';
Modules.ocean.supplierRates.labels.handlngInd='Handling Indicator';
Modules.ocean.supplierRates.labels.hazardous='Hazardous';
Modules.ocean.supplierRates.labels.steering='Steering';
Modules.ocean.supplierRates.labels.pfd='PFD';
Modules.ocean.supplierRates.labels.por='POR';
Modules.ocean.supplierRates.labels.podCntry='POD Country';
Modules.ocean.supplierRates.labels.podStateProv='POD State/Prov';
Modules.ocean.supplierRates.labels.podCity='POD City';
Modules.ocean.supplierRates.labels.polCntry='POL Country';
Modules.ocean.supplierRates.labels.polStateProv='POL State/Prov';
Modules.ocean.supplierRates.labels.polCity='POL City';
Modules.ocean.supplierRates.labels.model='Model';
Modules.ocean.supplierRates.labels.makeCode='Make Code';
Modules.ocean.supplierRates.labels.servLevelValDats='Service Level Valid Dates';
Modules.ocean.supplierRates.labels.queryParams='Query Parameters';
Modules.ocean.supplierRates.labels.pol='POL';
Modules.ocean.supplierRates.labels.pod='POD';
Modules.ocean.supplierRates.labels.polToolTip='Port Of Load';
Modules.ocean.supplierRates.labels.podTooltip='Port Of Discharge';
Modules.ocean.supplierRates.labels.luIndTooltip='Lumpsum/Unit Indicator';
Modules.ocean.supplierRates.labels.porTooltip='Place Of Receipt';
Modules.ocean.supplierRates.labels.PfdTooltip='Place of Final Delivery';
Modules.ocean.supplierRates.labels.polCityTooltip='Port Of Load City';
Modules.ocean.supplierRates.labels.podCityTooltip='Port Of Discharge City';
Modules.ocean.supplierRates.labels.seQNoTooltip='Sequence Number';

//#STATE PROVINCE MASTER
/**********************************/
Modules.Masters.State_Province_Master.labels.code='Code';
Modules.Masters.State_Province_Master.labels.name='Name';
Modules.Masters.State_Province_Master.labels.countryCode='Country Code';

/*********************************/

/***********************************************************************/
//#COMPANY_CODE_MAPPER
/***********************************************************************/
Modules.Masters.Company_Mapper.labels.partnerGroup= 'Partner Group';
Modules.Masters.Company_Mapper.labels.externalCompanyCode = 'External Company Code';
Modules.Masters.Company_Mapper.labels.internalCompanyCode = 'Internal Company Code';




/****************************************STAR of Ocean Customer Application Advice*******************************/

Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvTabTtl = 'Customer Application Advice';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvFormTtl = 'Customer Application Advice';
Modules.customer_invoice.customer_application_advice.labels.ocncstmrApplAdvFormTtl='Customer Application Advice Ocean';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvClearBtnTtl = 'Clear';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvRetrieveBtnTtl = 'Retrieve';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvPartyPayerTtl = 'Customer Payer';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvServiceCode = 'Service Code';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvServiceType = 'Service Type';
Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvInvoiceNumber = 'Invoice Number';

/***********************************************************************/
//# CHANGE LOG SCREEN
/***********************************************************************/
Modules.admin.application_monitoring.change_log.labels.formTitle = 'Change Log';
Modules.admin.application_monitoring.change_log.labels.screenName = 'Screen Name';
Modules.admin.application_monitoring.change_log.labels.userName = 'User Name';
Modules.admin.application_monitoring.change_log.labels.transInd = 'Trans Ind';
Modules.admin.application_monitoring.change_log.labels.fromDate = 'From Date';
Modules.admin.application_monitoring.change_log.labels.toDate = 'To Date';
Modules.admin.application_monitoring.change_log.labels.level1 = 'Level1';
Modules.admin.application_monitoring.change_log.labels.level2 = 'Level2';
Modules.admin.application_monitoring.change_log.labels.level3 = 'Level3';
Modules.admin.application_monitoring.change_log.labels.level4 = 'Level4';
Modules.admin.application_monitoring.change_log.labels.functionName = 'Screen Name';
Modules.admin.application_monitoring.change_log.labels.level1Value = 'Level1 Value';
Modules.admin.application_monitoring.change_log.labels.level2Value = 'Level2 Value';
Modules.admin.application_monitoring.change_log.labels.level3Value = 'Level3 Value';
Modules.admin.application_monitoring.change_log.labels.level4Value = 'Level4 Value';
Modules.admin.application_monitoring.change_log.labels.logDateTime = 'Log Date Time';
Modules.admin.application_monitoring.change_log.labels.fieldName = 'Field Name';
Modules.admin.application_monitoring.change_log.labels.oldValue = 'Old Value';
Modules.admin.application_monitoring.change_log.labels.newValue = 'New Value';

/***********************************************************************/
//#HOLIDAY_MASTER
/***********************************************************************/
Modules.Masters.Holiday_Master.labels.date = 'Date';
Modules.Masters.Holiday_Master.labels.description = 'Description';
Modules.Masters.Holiday_Master.labels.POP ='POP';
Modules.Masters.Holiday_Master.labels.country='Country';
/********************* Supplier Remittance Details Ocean ****************/

Modules.ocean.supplierInvoice.supplierRemittanceDetails.tabParentPanelLabel='Supplier Remittance Details Ocean';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.carrierCode='Supplier';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.paymentDocument='Payment Document';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.voyage='Voyage';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.blnumber='BL Number';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.tabParentPanelLbl='Ocean Supplier Remittance Details';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.chargeCode='Charge Code';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.pol='POL';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.pod='POD';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.por='POR';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.pfd='PFD';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.cargoClass='Cargo Class';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.cargoType='Cargo Type';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.vessel='Vessel';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.invoiceamount='Invoice Amount';
Modules.ocean.supplierInvoice.supplierRemittanceDetails.approvedamount='Approved Amount';


/*********************** START --Admin Module Labels************************

Modules.admin.user_admin.group_user_security.labels.groupCode='Group Code';

/******* User Management Labels ***********************/
Modules.admin.user_admin.user_management.labels.username='User Name';
Modules.admin.user_admin.user_management.labels.fullname='Full Name';
Modules.admin.user_admin.user_management.labels.userdscp='User Description';
Modules.admin.user_admin.user_management.labels.password='Password';
Modules.admin.user_admin.user_management.labels.confirmpwd='Confirm Password';
Modules.admin.user_admin.user_management.labels.user='User';
Modules.admin.user_admin.user_management.labels.accoutnstatus='Account Status';
Modules.admin.user_admin.user_management.labels.dftcmpy='Default Company';
Modules.admin.user_admin.user_management.labels.telphoneno='Telephone No.';
Modules.admin.user_admin.user_management.labels.mobiileno='Mobile No.';
Modules.admin.user_admin.user_management.labels.faxno='Fax Number';
Modules.admin.user_admin.user_management.labels.emailid='E-mail ID';
Modules.admin.user_admin.user_management.labels.dftlang='Default Language';
Modules.admin.user_admin.user_management.labels.timezone='Time Zone';
Modules.admin.user_admin.user_management.labels.windowtitle ='New User';


/******* User Management Labels ***********************/
Modules.ocean.admin.user_admin.user_management.labels.username='User Name';
Modules.ocean.admin.user_admin.user_management.labels.fullname='Full Name';
Modules.ocean.admin.user_admin.user_management.labels.userdscp='User Description';
Modules.ocean.admin.user_admin.user_management.labels.password='Password';
Modules.ocean.admin.user_admin.user_management.labels.confirmpwd='Confirm Password';
Modules.ocean.admin.user_admin.user_management.labels.user='User';
Modules.ocean.admin.user_admin.user_management.labels.accoutnstatus='Account Status';
Modules.ocean.admin.user_admin.user_management.labels.dftcmpy='Default Company';
Modules.ocean.admin.user_admin.user_management.labels.telphoneno='Telephone No.';
Modules.ocean.admin.user_admin.user_management.labels.mobiileno='Mobile No.';
Modules.ocean.admin.user_admin.user_management.labels.faxno='Fax Number';
Modules.ocean.admin.user_admin.user_management.labels.emailid='E-mail ID';
Modules.ocean.admin.user_admin.user_management.labels.dftlang='Default Language';
Modules.ocean.admin.user_admin.user_management.labels.timezone='Time Zone';
Modules.ocean.admin.user_admin.user_management.labels.dftpop='Associated POPs';
Modules.ocean.admin.user_admin.user_management.labels.dftservtype='Dft Service Type';
Modules.ocean.admin.user_admin.user_management.labels.dftport='Default Port';
Modules.ocean.admin.user_admin.user_management.labels.dftCustomer='Default Customer';
Modules.ocean.admin.user_admin.user_management.labels.dftCarrier='Default Carrier';

/*********************** END -- Admin Module Labels*************************/



Modules.ocean.contract.customer.customer_payment_details.CustomerPaymentDetailsForm='Customer Payment Details Ocean';
Modules.ocean.contract.customer.customer_payment_details.debtorParty='Debtor Party';
Modules.ocean.contract.customer.customer_payment_details.blNumber='BL Number';
Modules.ocean.contract.customer.customer_payment_details.InvoiceNumber='Invoice Number';
Modules.ocean.contract.customer.customer_payment_details.paymentFromDate='Pymnt From Dt';
Modules.ocean.contract.customer.customer_payment_details.paymentFromDatefullname='Payment From Date';
Modules.ocean.contract.customer.customer_payment_details.paymentToDate='Pymnt To Date';
Modules.ocean.contract.customer.customer_payment_details.paymentToDatefullname='Payment To Date';
Modules.ocean.contract.customer.customer_payment_details.modeofPayment='Mode of Payment';
Modules.ocean.contract.customer.customer_payment_details.invoiceFromDate='Invc From Date';
Modules.ocean.contract.customer.customer_payment_details.invoiceFromDatefullName='Invoice From Date';
Modules.ocean.contract.customer.customer_payment_details.invoiceToDate='Invoice To Date';
Modules.ocean.contract.customer.customer_payment_details.invoiceToDatefullName='Invoice to Date';
Modules.ocean.contract.customer.customer_payment_details.paymentDocument='Payment Doc';
Modules.ocean.contract.customer.customer_payment_details.paymentDocumentfullName='Payment Document';
Modules.ocean.contract.customer.customer_payment_details.serviceType='Service Type';
Modules.ocean.contract.customer.customer_payment_details.voyage='Voyage';
Modules.ocean.contract.customer.customer_payment_details.vessel='Vessel';
Modules.ocean.contract.customer.customer_payment_details.chargeCode='Charge Code';
Modules.ocean.contract.customer.customer_payment_details.shippingReference='Shipment Ref No.';
Modules.ocean.contract.customer.customer_payment_details.shippingReferencefull='Shipment Reference Number';
Modules.ocean.contract.customer.customer_payment_details.remittance='Remittance Type';

Modules.ocean.contract.customer.customer_payment_details.documentRef='Document Reference';
Modules.ocean.contract.customer.customer_payment_details.intPaymentNo='Int Payment No.';
Modules.ocean.contract.customer.customer_payment_details.companyCode='Company Code';
Modules.ocean.contract.customer.customer_payment_details.rfcInvNo='Rfc Invoice No.';




/***********************************************************************/
//#OCEAN SUPPLIER RATE QUERY
/***********************************************************************/
Modules.ocean.supplier_rate.supplier_rate_query.screenTlt='Supplier Rate Query';
Modules.ocean.supplier_rate.supplier_rate_query.screenOceanTlt='Supplier Rate Query Ocean';
Modules.LblsAndTtls.popupoceanSupplierRateQueryPopWinRecordViewGridTlt='Supplier Rate Query New Contract Grid Record';
Modules.ocean.contract.customer.customer_payment_details.documentRef='DocRef';
Modules.ocean.contract.customer.customer_payment_details.documentReference='Document Reference';
Modules.ocean.contract.customer.customer_payment_details.ReportOutput='Report Output';
Modules.ocean.contract.customer.customer_payment_details.pdfradioButton='PDF';
Modules.ocean.contract.customer.customer_payment_details.excelRadioButton='Excel';
Modules.ocean.contract.customer.customer_payment_details.summary='summary';
Modules.ocean.contract.customer.customer_payment_details.detail='Detail';
Modules.ocean.contract.customer.customer_payment_details.ReportOptions='Report Options';


Modules.ocean.contract.customer.customer_payment_details.ascending='Ascending';
Modules.ocean.contract.customer.customer_payment_details.descending='Descending';
Modules.ocean.contract.customer.customer_payment_details.SortOptions='Sort Options';
Modules.ocean.contract.customer.customer_payment_details.grid.customer='Customer';
Modules.ocean.contract.customer.customer_payment_details.grid.voyage='Voyage';
Modules.ocean.contract.customer.customer_payment_details.grid.invoiceNumber='Invoice No.';
Modules.ocean.contract.customer.customer_payment_details.grid.invoiceNumberTooltip='Invoice Number';
Modules.ocean.contract.customer.customer_payment_details.grid.invoiceDate='Invoice Date';
Modules.ocean.contract.customer.customer_payment_details.grid.modeOfPayment='Mode Of Payment';
Modules.ocean.contract.customer.customer_payment_details.grid.paymentDocument='Payment Document';
Modules.ocean.contract.customer.customer_payment_details.grid.paymentDate='Payment Date';
Modules.ocean.contract.customer.customer_payment_details.grid.paidAmount='Paid Amount';
Modules.ocean.contract.customer.customer_payment_details.grid.invoiceCurrency='Invoice Currency';
Modules.ocean.contract.customer.customer_payment_details.grid.remittanceType='Remittance Type';
Modules.ocean.contract.customer.customer_payment_details.grid.manifestCurrency='Manifest Currency';
Modules.ocean.contract.customer.customer_payment_details.grid.manifestAmount='Manifest Amount';
Modules.ocean.contract.customer.customer_payment_details.grid.invoiceAmount='Invoice Amount';
Modules.ocean.contract.customer.customer_payment_details.grid.usdEqvAmount='USD Equiv Amount';
Modules.ocean.contract.customer.customer_payment_details.grid.usdEqvAmountToolTip='USD Equivalent Amount';

/***********************************************************************/
//#Admin Audit Log ENTRY
/***********************************************************************/

Modules.admin.auditlog.labels.formTitle = 'Audit Log';
Modules.admin.auditlog.labels.userId = 'User ID';
Modules.admin.auditlog.labels.moduleName ='Module Name';
Modules.admin.auditlog.labels.startDate='Start Date';
Modules.admin.auditlog.labels.endDate ='Exit Date';
Modules.admin.auditlog.labels.functionName ='Function Name';
Modules.admin.auditlog.labels.applnServeName ='Appln Server Name';
Modules.admin.auditlog.labels.validFrom	=	'Start Date and Time';
Modules.admin.auditlog.labels.validTo	= 'Exit Date and Time';
Modules.LblsAndTtls.AuditLogQueryGridTtl = 'Audit Log Query Grid Record';

Modules.ocean.contract.customer.customer_payment_details.chaildgridBlnumber='BL Number';
Modules.ocean.contract.customer.customer_payment_details.chaildgridChargecode='Charge Code';
Modules.ocean.contract.customer.customer_payment_details.chaildgridChargeCodeDescription='Charge Code Description';
Modules.ocean.contract.customer.customer_payment_details.chaildgridFrightTerms='Freight Terms';
Modules.ocean.contract.customer.customer_payment_details.chaildgridVessel='Vessel';
Modules.ocean.contract.customer.customer_payment_details.chaildgridBlCompletiondate='BL Completion Date';
Modules.ocean.contract.customer.customer_payment_details.chaildgridPaidAmount='Paid Amount';
Modules.ocean.contract.customer.customer_payment_details.chaildgridInvoiceCurrency='Invoice Currency';
Modules.ocean.contract.customer.customer_payment_details.paymentHeaderDetails='Payment Header Details';

Modules.LblsAndTtls.blCount = 'BL Count';
Modules.ocean.customer_invoice.ApplicationAdviseOnHoldWinTitle = 'Customer Invoice Application Advice On Hold Ocean';
Modules.LblsAndTtls.processRejectionActionTtl ='Process Rejection';
Modules.LblsAndTtls.processRejectionRecordsToolTipTtl ='Process Rejection Records';
Modules.LblsAndTtls.vesselName = 'Vessel Name';
Modules.LblsAndTtls.modelCode = 'Model Code';
Modules.LblsAndTtls.modelGpCode = 'Model Gp Code';
Modules.LblsAndTtls.frieghtTerms = 'Freight Terms';
Modules.LblsAndTtls.polCD = 'POL CD';
Modules.LblsAndTtls.polCD = 'POD CD';
Modules.LblsAndTtls.BlCompletiondate = Modules.ocean.contract.customer.customer_payment_details.chaildgridBlCompletiondate;
Modules.LblsAndTtls.shipmentType = 'Shipment Type';

Modules.LblsAndTtls.podAddress1Lbl = 'POD Address1';
Modules.LblsAndTtls.podAddress2Lbl = 'POD Address2';
//#ORDER_TYPE_MASTER
/***********************************************************************/
Modules.Masters.Order_Type_Master.labels.customerCode = 'Customer Code';
Modules.Masters.Order_Type_Master.labels.customerName ='Customer Name';
Modules.Masters.Order_Type_Master.labels.code ='Code';
Modules.Masters.Order_Type_Master.labels.description = 'Description';



 // SUPPLIER INVOICE STAUS FOR OCEAN
/***********************************************************************/
Modules.LblsAndTtls.supplierInvcStsForOceanTtl			=	'Supplier Invoice Status Ocean';
Modules.LblsAndTtls.billNumberFullLbl					=	'Bill Number';
Modules.LblsAndTtls.billNumberLbl                   =    'Bill No.';
Modules.LblsAndTtls.billNbrLbl                        = 'Bill Nbr';
/****************Ocean Customer Rate Query Service Code *****************/
Modules.ocean.ocean_customer_rate_query_service_code.company = 'Company';
Modules.ocean.ocean_customer_rate_query_service_code.companyName = 'Company Name';
Modules.ocean.ocean_customer_rate_query_service_code.pop = 'POP';
Modules.ocean.ocean_customer_rate_query_service_code.popDescription='POP Name';
Modules.ocean.ocean_customer_rate_query_service_code.party='Party';
Modules.ocean.ocean_customer_rate_query_service_code.name='Party Name';
Modules.ocean.ocean_customer_rate_query_service_code.startDate = 'Start Date';
Modules.ocean.ocean_customer_rate_query_service_code.endDate = 'End Date';
Modules.ocean.ocean_customer_rate_query_service_code.contractId='Contract ID';
Modules.ocean.ocean_customer_rate_query_service_code.chargecode='Charge Code';
Modules.ocean.ocean_customer_rate_query_service_code.chargeDescription = 'Charge Code Desc';
Modules.ocean.ocean_customer_rate_query_service_code.carrier='Carrier';
Modules.ocean.ocean_customer_rate_query_service_code.polCd='POL CD';
Modules.ocean.ocean_customer_rate_query_service_code.podCd='POD CD';
Modules.ocean.ocean_customer_rate_query_service_code.makeCode='Make Code';
Modules.ocean.ocean_customer_rate_query_service_code.modelCode='Model Code';
Modules.ocean.ocean_customer_rate_query_service_code.modelYear='Model Year';
Modules.ocean.ocean_customer_rate_query_service_code.pol= 'POL';
Modules.ocean.ocean_customer_rate_query_service_code.pod = 'POD';
Modules.ocean.ocean_customer_rate_query_service_code.por = 'POR';
Modules.ocean.ocean_customer_rate_query_service_code.pfd = 'PFD';
Modules.ocean.ocean_customer_rate_query_service_code.freightTerms = 'Freight Terms';
Modules.ocean.ocean_customer_rate_query_service_code.cargoClass = 'Cargo Class';
Modules.ocean.ocean_customer_rate_query_service_code.cargoType = 'Cargo Type';
Modules.ocean.ocean_customer_rate_query_service_code.vesselType = 'Vessel Type';
Modules.ocean.ocean_customer_rate_query_service_code.commodityDescription = 'Commodity Desc';
Modules.ocean.ocean_customer_rate_query_service_code.commodityCode = 'Commodity Code';
Modules.ocean.ocean_customer_rate_query_service_code.rateBasis = 'Rate Basis';
Modules.ocean.ocean_customer_rate_query_service_code.rate = 'Rate';
Modules.ocean.ocean_customer_rate_query_service_code.currencyCode = 'Currency Code';
Modules.ocean.ocean_customer_rate_query_service_code.dateEffective = 'Date Effective';
Modules.ocean.ocean_customer_rate_query_service_code.dateExpires = 'Date Expires';
Modules.ocean.ocean_customer_rate_query_service_code.labels.customerRateQuery = 'Customer Rate Query Service Code Grid';
Modules.LblsAndTtls.oceanCustomerRateQueryServiceFormTtl = 'Ocean Customer Rate Query Service Code';
Modules.ocean.ocean_customer_rate_query_service_code.labels.portoolTip = 'Place Of Receipt';
Modules.ocean.ocean_customer_rate_query_service_code.labels.pfdtoolTip = 'Place of Final Delivery';

Modules.LblsAndTtls.customerContractQueryTlt='Customer Contract Query';
Modules.LblsAndTtls.customerContractQueryOceanTlt='Customer Contract Query Ocean';

Modules.ocean.ocean_customer_rate_query_service_code.labels.commoditytoolTip = 'Commodity Description';
Modules.ocean.ocean_customer_rate_query_service_code.labels.chargecodetoolTip = 'Charge code Description';
Modules.ocean.ocean_customer_rate_query_service_code.popNameDescriptionToolTip = 'Place Of Payment Name';


// # Internal Admin Database Error Log
Modules.ocean.internalAdminDatabaseErrorLogTtl  = 'Database Error Log';
Modules.LblsAndTtls.userName = 'User Name';
Modules.LblsAndTtls.hostName = 'Host Name';
Modules.LblsAndTtls.errorLogDate = 'Error Log Date';
Modules.LblsAndTtls.errorFnDes = 'Error Function Des';
Modules.LblsAndTtls.errorFnDescription = 'Error Function Description';
Modules.LblsAndTtls.errorPosition = 'Error Position';
Modules.LblsAndTtls.errorDescription = 'Error Description';

/***********************************************************************/
//#OCEAN SPPLIER AUTOMATIC INVOICE
/***********************************************************************/

Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.companyCode = 'Company Code';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.companyName = 'Company Name';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.generationFrequency = 'Generation Frequency';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.generationTime = 'Generation Time';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.intervel = 'Interval';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.serviceCode = 'Service Code';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.voyage = 'Voyage';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.currency = 'Currency';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.POLCode = 'POL Code';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.PODCode = 'POD Code';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.BLnumber = 'BL number';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.supplierCode = 'Supplier Code';
Modules.ocean.supplier_invoice.supplier_automatic_invoice.labels.vesselCode = 'Vessel Code';


/***********************************************************************/
//#Journal for Ocean
/***********************************************************************/
Modules.ocean.admin.ocean_journal.labels.formTitle	=	'Journal Log';

Modules.ocean.admin.ocean_journal.labels.itemno	=	'Item Number';
Modules.ocean.admin.ocean_journal.labels.invoice=	'Invoice Number';
Modules.ocean.admin.ocean_journal.labels.servicecd=	'Service Code';
Modules.ocean.admin.ocean_journal.labels.blno =	'Bill Number';
Modules.ocean.admin.ocean_journal.labels.dateOrTime		=	'Date/Time';
Modules.ocean.admin.ocean_journal.labels.userID	=	'User ID';
Modules.ocean.admin.ocean_journal.labels.ediPartnerOrModule	=	'EDI Partner/Module';
Modules.ocean.admin.ocean_journal.labels.action	=	'Action'	;
Modules.ocean.admin.ocean_journal.labels.fieldName		=	'Field Name';
Modules.ocean.admin.ocean_journal.labels.invoiceNo	=	'Invoice#';
Modules.ocean.admin.ocean_journal.labels.oldValue	=	'Old Value';
Modules.ocean.admin.ocean_journal.labels.newValue	=	'New Value';

Modules.LblsAndTtls.Ocean_JournalGridTtl			=		'Ocean Journal Grid Record';

/***********************************************************************/
//#UOM_RATEBASIS_MASTER
/***********************************************************************/
Modules.Masters.Uom_RateBasis_Master.labels.type = 'Type';
Modules.Masters.Uom_RateBasis_Master.labels.description = 'Description';
Modules.Masters.Uom_RateBasis_Master.labels.code = 'Code';
Modules.Masters.Uom_RateBasis_Master.labels.conversion = 'Conversion';
Modules.Masters.Uom_RateBasis_Master.labels.formula = 'Formula';

/*************************Ocean Customer Reconciliation *********************/
Modules.ocean.customer_invoice.customer_reconciliation.labels.tabParentPanelLbl = 'Customer Reconciliation Ocean';
Modules.ocean.customer_invoice.customer_reconciliation.labels.formLbl = 'Customer Reconciliation Ocean';
Modules.ocean.customer_invoice.customer_reconciliation.labels.pop = 'POP';
Modules.ocean.customer_invoice.customer_reconciliation.labels.blNumber = 'BL Number';
Modules.ocean.customer_invoice.customer_reconciliation.labels.freightTrms = 'Freight Terms';
Modules.ocean.customer_invoice.customer_reconciliation.labels.serviceType = 'Service Type';
Modules.ocean.customer_invoice.customer_reconciliation.labels.customer = 'Customer';
Modules.ocean.customer_invoice.customer_reconciliation.labels.supplier = 'Supplier';
Modules.ocean.customer_invoice.customer_reconciliation.labels.pol = 'POL';
Modules.ocean.customer_invoice.customer_reconciliation.labels.pod = 'POD';
Modules.ocean.customer_invoice.customer_reconciliation.labels.serviceGrpCd = 'Service Group';

Modules.ocean.customer_invoice.customer_reconciliation.labels.shippingRefNum = 'Ship Ref No.';
//Modules.ocean.customer_invoice.customer_reconciliation.labels.shippingRefNum = 'Ship Ref No.';

Modules.ocean.customer_invoice.customer_reconciliation.labels.por = 'POR';
Modules.ocean.customer_invoice.customer_reconciliation.labels.pfd = 'PFD';
Modules.ocean.customer_invoice.customer_reconciliation.labels.chargeCode = 'Service Code';
Modules.ocean.customer_invoice.customer_reconciliation.labels.wrkOrderNum = 'Work Order Number';
Modules.ocean.customer_invoice.customer_reconciliation.labels.sailingFmDt = 'Sailing from date';
Modules.ocean.customer_invoice.customer_reconciliation.labels.sailingToDt = 'Sailing to date';
Modules.ocean.customer_invoice.customer_reconciliation.labels.blCmpltFmDt = 'BL Cmpl Fm Date';
Modules.ocean.customer_invoice.customer_reconciliation.labels.blCmpltToDt = 'BL Cmpl To Date';
Modules.ocean.customer_invoice.customer_reconciliation.labels.voyage = 'Voyage';
Modules.ocean.customer_invoice.customer_reconciliation.labels.vessel = 'Vessel';
Modules.ocean.customer_invoice.customer_reconciliation.labels.rejectFromDate = 'Reject from date';
Modules.ocean.customer_invoice.customer_reconciliation.labels.rejectToDate = 'Reject to date';

/***********************************************************************/
//#PARTY_TYPE_MASTER
/***********************************************************************/
Modules.Masters.Part_Type_Master.labels.type = 'Type';
Modules.Masters.Part_Type_Master.labels.description = 'Description';
Modules.Masters.Part_Type_Master.labels.category = 'Category';


/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY-Consolidation   START
/***********************************************************************/

Modules.ocean.customer_invoice.ocean_customer_invoice_entry_consolidate.labels.parentTabPanelTtl = 'Customer Invoice Entry-Consolidation';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry_consolidate.labels.cstmrinvEntryFormTtl = 'Customer Invoice Query Consolidation Ocean';

/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY-Consolidation   END
/***********************************************************************/

/***********************************************************************/
//#Supplier Invoice Supplier Line Item Status for Ocean 
/***********************************************************************/
Modules.ocean.supplier_invoice.supplier_line_item_status.labels.tabParentPanelLbl = "Supplier Line Item Status";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.CountryTtl = 'Company';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.Carrier = 'Supplier';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoiceNumber = 'Invoice Number';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoiceFromDate = 'Invoice From Date';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoiceToDate = 'Invoice To Date';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.blNumber = 'BL Number';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.voyage = 'Voyage';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.chargeCode = 'Service Code';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.vessel = 'Vessel';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.pol = 'POL';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.pod = 'POD';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.profarma = 'Proforma';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.readyForReconcilation = 'Ready For Reconciliation';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.underInvestigation = 'Under Investigation';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.reconciled = 'Reconciled';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.approved = 'Approved';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.rejected = 'Rejected';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.paid = 'Paid';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoice = 'Invoice';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.creditNote = 'Credit Note';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.debitNote = 'Debit Note';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.pdf = 'PDF';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.excel = 'Excel';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.ascending = 'Ascending';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.descending = 'Descending';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.checkBoxGroupStatusTtl = 'Status';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.checkBoxGroupDocumentTypeTtl = 'Document Type';

Modules.ocean.supplier_invoice.supplier_line_item_status.label.radioGroupReportOutput = 'Report Output';
Modules.ocean.supplier_invoice.supplier_line_item_status.label.radioGroupSortOptions = 'Sort Options';


Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoiceDate = "Invoice Date";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.dueDate = "Due Date";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.invoiceAmount = "Invoice Amount";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.approvedAmount = "Approved Amount";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.paidAmount = "Paid Amount";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.currency = "Currency";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.deliveryCompletionDate = "Delivery/Completion Date";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.lastPaymentDate = "Last Payment Date";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.lineItemStatus = "Line Item Status";
Modules.ocean.supplier_invoice.supplier_line_item_status.label.reason = "Reason";
Modules.ocean.supplier_invoice.supplier_line_item_status.labels.oceansupplierLineItemStatusPopWin = 'Supplier Line Item Status Details';

Modules.LblsAndTtls.postalCodeLbl  =  'Postal Code';

Modules.ocean.master.genaralmaster.voyagemaster.voyageNumber='Voyage Number';
Modules.ocean.master.genaralmaster.voyagemaster.voyageCurrencyCode='Voyage Currency Code';
Modules.ocean.master.genaralmaster.voyagemaster.voyageCurrencyCodefull='Voyage Currency Code';
Modules.ocean.master.genaralmaster.voyagemaster.routCode='Route Code';
Modules.ocean.master.genaralmaster.voyagemaster.vesselCode='Vessel Code';
Modules.ocean.master.genaralmaster.voyagemaster.vesselName='Vessel Name';
Modules.ocean.master.genaralmaster.voyagemaster.originalSiteId='Original Site ID';
Modules.ocean.master.genaralmaster.voyagemaster.carriercodeCombo='Carrier Code';
Modules.ocean.master.genaralmaster.voyagemaster.currencyCodecombo='Currency Code';
Modules.ocean.master.genaralmaster.voyagemaster.exchangeRate='Exchange Rates';
Modules.ocean.master.genaralmaster.voyagemaster.portCodeCombo='Port Code';
Modules.Masters.location_master.labels.dealerFlag = 'Dealer Flag';
Modules.ocean.master.genaralmaster.voyagemaster.CarrierDetails='Carrier Details';
Modules.ocean.master.genaralmaster.voyagemaster.ports='Ports Details';
Modules.ocean.master.genaralmaster.voyagemaster.CurrencyDetails='Currency Details';
Modules.ocean.master.genaralmaster.voyagemaster.portsCurrencyDetails='Port Currency Details';
/***********************************************************************/
//#PORT_MASTER
/***********************************************************************/
Modules.Masters.Port_Master.labels.code = 'Code';
Modules.Masters.Port_Master.labels.name = 'Name';
Modules.Masters.Port_Master.labels.address1 = 'Address 1';
Modules.Masters.Port_Master.labels.address2 = 'Address 2';
Modules.Masters.Port_Master.labels.city = 'City';
Modules.Masters.Port_Master.labels.state = 'State';
Modules.Masters.Port_Master.labels.postalCode = 'Postal Code';
Modules.Masters.Port_Master.labels.country = 'Country';
Modules.Masters.Port_Master.labels.currency = 'Currency';
Modules.Masters.Port_Master.labels.orignalSite = 'Original Site';
Modules.Masters.Port_Master.labels.timeZone = 'Time Zone';
Modules.Masters.Port_Master.labels.responsibleOffice = 'Responsible Office';

// # Bank Details Master
Modules.Ocean.Masters.BankDetails_Master.labels.POP="POP";
Modules.Ocean.Masters.BankDetails_Master.labels.PrintingOrderOnInvoice="Printing Order On Invoice";
Modules.Ocean.Masters.BankDetails_Master.labels.BankDetails="Bank Details";
Modules.Ocean.Masters.BankDetails_Master.labels.Active="Active";
Modules.Ocean.Masters.BankDetails_Master.labels.ScreenTitle="Bank Details Master";



/***********************************************************************/
//#LOCATION_MASTER
/***********************************************************************/
Modules.Masters.location_master.labels.locationCode = 'Location Code';
Modules.Masters.location_master.labels.address1 = 'Address 1';
Modules.Masters.location_master.labels.address2 = 'Address 2';
Modules.Masters.location_master.labels.city = 'City';
Modules.Masters.location_master.labels.postalCode = 'Postal Code';
Modules.Masters.location_master.labels.stateProvince = 'State/Province';
Modules.Masters.location_master.labels.country = 'Country';
Modules.Masters.location_master.labels.dealerFlag = 'Dealer Flag';

/****************************************************************************
*			Start : Supplier Reconcilation Setup							*
*****************************************************************************/
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.formTtl	=	'Supplier Reconciliation Setup';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.supplierLbl	=	'Supplier';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.supplierNmLbl	=	'Supplier Name';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.matchingCriteriaTtl	=	'Matching Criteria';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.toleranceCriteriaTtl	=	'Tolerance Criteria';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.srvTypeLbl	=	'Service Type';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.srvCdLbl	=	'Service Code';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.currencyCdLbl	=	'Currency Code';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.fmRangeLbl	=	'From Range';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.toRangeLbl	=	'To Range';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.matchingCriteriaDtlsGridTtl	=	'Matching Criteria Details';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.polLbl	=	'POL';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.podLbl	=	'POD';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.vslCdLbl	=	'Vessel Code';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.voyageLbl	=	'Voyage';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.cargoTypeLbl	=	'Cargo Type';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.cargoClassLbl	=	'Cargo Class';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.plCenterLbl	=	'Profit/Loss Center';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.modelLbl	=	'Model';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.blNoLbl	=	'BL Number';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.priorityLbl	=	'Priority';
Modules.Ocean.supplier.supplier_reconcilation_setup.labels.cargoIdenNo='Cargo Identification Number';
/****************************************************************************
*			End : Supplier Reconcilation Setup							    *
*****************************************************************************/

/***********************************************************************/
//#CLAUSE_MASTER
/***********************************************************************/
Modules.Masters.ocean.Clause_Master.labels.popCountry = "POP Country";
Modules.Masters.ocean.Clause_Master.labels.payer = "Payer";
Modules.Masters.ocean.Clause_Master.labels.freightTerms = "Freight Terms";
Modules.Masters.ocean.Clause_Master.labels.invoiceCurrency = "Invoice Currency";
Modules.Masters.ocean.Clause_Master.labels.paymentMatched = "Payment Matched";
Modules.Masters.ocean.Clause_Master.labels.credit = "Credit";
Modules.Masters.ocean.Clause_Master.labels.portFrom = "Port From";
Modules.Masters.ocean.Clause_Master.labels.portTo = "Port To";
Modules.Masters.ocean.Clause_Master.labels.vatAmount = "VAT Amount";
Modules.Masters.location_master.labels.dealerFlag = 'Dealer Flag';



/***********************************************************************/
//# Ocean POP_MASTER
/***********************************************************************/
Modules.Ocean.Masters.POP_master.labels.popCode = 'POP Code';
Modules.Ocean.Masters.POP_master.labels.address1 = 'Address 1';
Modules.Ocean.Masters.POP_master.labels.address2 = 'Address 2';
Modules.Ocean.Masters.POP_master.labels.city = 'City';
Modules.Ocean.Masters.POP_master.labels.postalCode = 'Postal Code';
Modules.Ocean.Masters.POP_master.labels.stateProvince = 'State/Province';
Modules.Ocean.Masters.POP_master.labels.country = 'Country';
Modules.Ocean.Masters.POP_master.labels.prepaidContactName = 'Prepaid Contact Name';
Modules.Ocean.Masters.POP_master.labels.collectContactName = 'Collect Contact Name';
Modules.Ocean.Masters.POP_master.labels.currency = 'Currency';
Modules.Ocean.Masters.POP_master.labels.timeZone = 'Time Zone';
Modules.Ocean.Masters.POP_master.labels.registrationNo = 'Registration No';
Modules.Ocean.Masters.POP_master.labels.taxExemptionNo = 'Tax Exemption No';
Modules.Ocean.Masters.POP_master.labels.printTemplateCode = 'Print Template Code';
Modules.Ocean.Masters.POP_master.labels.popDesc = 'POP Description';
Modules.Ocean.Masters.POP_master.labels.emailAddr= 'Email Address';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.ParentPanelTmplt='Vendor Invoice Template';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.tabParentPanelTmplt='Vendor Invoice Template Ocean';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.vndrInvTempltForm='Vendor Invoice Template';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.supplier='Supplier';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.supplierName='Supplier Name';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.invcNumber='Invoice Number';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.invcDate='Invoice Date';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.currency='Currency';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.refInvcNum='Ref Invc Num';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.status='Status';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.docType='Document type';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.party='Party';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.paymentDetails='Payment Details';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.partyName='Party Name';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.addr1='Address Line 1';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.addr2='Address Line 2';

Modules.Masters.GeneralMasters.CompanyMaster.GridHeading='Contact Info';
Modules.Masters.GeneralMasters.CompanyMaster.APGridHeading='A/P Contact Info';
Modules.Masters.GeneralMasters.CompanyMaster.APGridHeadingFullName='Accounts Payable Contact Information';
Modules.Masters.GeneralMasters.CompanyMaster.ARGridHeading='A/R Contact Info';
Modules.Masters.GeneralMasters.CompanyMaster.ARGridHeadingFullName='Accounts Receivable Contact Information';

Modules.ocean.supplier_invoice.vendor_invoice_template.labels.city='City';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.state='State/Prov';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.cntry='Country';
Modules.ocean.supplier_invoice.vendor_invoice_template.labels.zipPostalCd='Zip/Postal Code';

Modules.ocean.supplier_invoice.vendor_invoice_template.labels.invcDueDate='Invoice Due Date';

/***********************************************************************/
//#COUNTRY_STATE_CODE_MAPPER
/***********************************************************************/
Modules.Masters.Country_State_Mapper.labels.partnerGroup= 'Partner Group';
Modules.Masters.Country_State_Mapper.labels.exterrnalCountryCode='External Country Code';
Modules.Masters.Country_State_Mapper.labels.exterrnalStateCode = 'External State Code';
Modules.Masters.Country_State_Mapper.labels.internalStateCode = 'Internal State Code';
Modules.Masters.Country_State_Mapper.labels.internalCountryCode ='Internal Country Code';

/**********Audit & Exception**************/
Modules.edi.swim_ui.audit_exception.labels.msgType = 'Message Type';
Modules.edi.swim_ui.audit_exception.labels.timeIntvl='Time Interval (Sec)';
Modules.edi.swim_ui.audit_exception.labels.msgStartStopDttm='Message Start/Stop Date Time';
Modules.edi.swim_ui.audit_exception.labels.userName='User Name';
Modules.edi.swim_ui.audit_exception.labels.status='Status';

/***********************************************************************/
//#Ocean General Clause master
/***********************************************************************/
Modules.CompIds.OceanGenaralClauseMasterTabpanelId = "Ocean General Clause Master Tabpanel ID";
Modules.CompIds.OceanGenaralClauseMasterTabParentpanelId ="Ocean General Clause Master Tab Parentpanel ID";

/***********************************************************************/
//#TIME_ZONE_MAPPER
/***********************************************************************/
Modules.Masters.Time_Zone_Mapper.labels.externalTimeZone = 'External Time Zone';
Modules.Masters.Time_Zone_Mapper.labels.internalTimeZone = 'Internal Time Zone';



Modules.LblsAndTtls.shipmentRefNoTlt='Ship Ref No.';
Modules.LblsAndTtls.shipmentRefNoFullTlt='Shipment Reference Number';

Modules.LblsAndTtls.shipmentRefNoLbl = 'Shipment Ref Nbr';
Modules.LblsAndTtls.shipmentRefNoFullLbl = 'Shipment Reference Number';


/***********************************************************************/
//#APPLICATION ADVICE ONHOLD
/***********************************************************************/

Modules.customer_invoice.application_advice_onHold.labels.customer = 'Customer';
Modules.customer_invoice.application_advice_onHold.labels.debtorParty = 'Debtor Party';
Modules.customer_invoice.application_advice_onHold.labels.serviceType = 'Service Type';
Modules.customer_invoice.application_advice_onHold.labels.serviceCode = 'Service Code';
Modules.customer_invoice.application_advice_onHold.labels.serviceGroupCode = 'Service Group Code';
Modules.customer_invoice.application_advice_onHold.labels.serviceGrpCode = 'Service Grp Code';
Modules.customer_invoice.application_advice_onHold.labels.invoiceNo = 'Invoice Number';
Modules.customer_invoice.application_advice_onHold.labels.profitLoss = 'Profit/Loss Center';
Modules.customer_invoice.application_advice_onHold.labels.origin = 'Origin';
Modules.customer_invoice.application_advice_onHold.labels.destination = 'Destination';
Modules.customer_invoice.application_advice_onHold.labels.unitId = 'Unit ID';
Modules.customer_invoice.application_advice_onHold.labels.eventLoadRef = 'Event/Load Reference';
Modules.customer_invoice.application_advice_onHold.labels.eventLdRef = 'Event/Load Ref';
Modules.customer_invoice.application_advice_onHold.labels.workOrder = 'Work Order';
Modules.customer_invoice.application_advice_onHold.labels.shippingRefNo = 'Shipping Reference No.';
Modules.customer_invoice.application_advice_onHold.labels.shipRefNo = 'Shipping Ref No.';
Modules.customer_invoice.application_advice_onHold.labels.conveyanceId = 'Conveyance ID';
Modules.customer_invoice.application_advice_onHold.labels.technicalDesc = 'Technical Description';
Modules.customer_invoice.application_advice_onHold.labels.techDesc = 'Technical Desc';
Modules.customer_invoice.application_advice_onHold.labels.invFromDate = 'Invoice From Date';
Modules.customer_invoice.application_advice_onHold.labels.invFmDate = 'Invc From Date';
Modules.customer_invoice.application_advice_onHold.labels.invToDate = 'Invoice To Date';
Modules.customer_invoice.application_advice_onHold.labels.dueFromDate = 'Due From Date';
Modules.customer_invoice.application_advice_onHold.labels.dueToDate = 'Due To Date';


Modules.customer_invoice.application_advice_onHold.labels.invoiceNumber = 'Invoice Number';
Modules.customer_invoice.application_advice_onHold.labels.documentType = 'Document Type';
Modules.customer_invoice.application_advice_onHold.labels.invoiceDate = 'Invoice Date';
Modules.customer_invoice.application_advice_onHold.labels.dueDate = 'Due Date';
Modules.customer_invoice.application_advice_onHold.labels.shipRefNo = 'Shipping Ref No.';
Modules.customer_invoice.application_advice_onHold.labels.loadRefNo = 'Load Reference Number';
Modules.customer_invoice.application_advice_onHold.labels.ldRefNo = 'Load Ref No.';
Modules.customer_invoice.application_advice_onHold.labels.conveyanceType = 'Conveyance Type';
Modules.customer_invoice.application_advice_onHold.labels.conveyanceName = 'Conveyance Name';
Modules.customer_invoice.application_advice_onHold.labels.conveyanceNm = 'Conveyance Nm';
Modules.customer_invoice.application_advice_onHold.labels.transportCode = 'Transport Code';
Modules.customer_invoice.application_advice_onHold.labels.makeCode = 'Make Code';
Modules.customer_invoice.application_advice_onHold.labels.modelCode = 'Model Code';
Modules.customer_invoice.application_advice_onHold.labels.modelGroupCode = 'Model Group Code';
Modules.customer_invoice.application_advice_onHold.labels.modelGroupCd = 'Model Grp Code';
Modules.customer_invoice.application_advice_onHold.labels.modelYear = 'Model Year';
Modules.customer_invoice.application_advice_onHold.labels.transportMode = 'Transport Mode';
Modules.customer_invoice.application_advice_onHold.labels.rateTierCode = 'Rate Tier Code';
Modules.customer_invoice.application_advice_onHold.labels.workOrderNo = 'Work Order No.';
Modules.customer_invoice.application_advice_onHold.labels.partId = 'Part ID';
Modules.customer_invoice.application_advice_onHold.labels.originCode = 'Origin Code';
Modules.customer_invoice.application_advice_onHold.labels.originAddress1 = 'Origin Address1';
Modules.customer_invoice.application_advice_onHold.labels.originAddress2 = 'Origin Address2';
Modules.customer_invoice.application_advice_onHold.labels.originCity = 'Origin City';
Modules.customer_invoice.application_advice_onHold.labels.originCityName = 'Origin City Name';
Modules.customer_invoice.application_advice_onHold.labels.originState = 'Origin State';
Modules.customer_invoice.application_advice_onHold.labels.originPOBox = 'Origin PO Box';
Modules.customer_invoice.application_advice_onHold.labels.destinationCode = 'Destination Code';
Modules.customer_invoice.application_advice_onHold.labels.destinationAddress1 = 'Destination Address1';
Modules.customer_invoice.application_advice_onHold.labels.destAddress1 = 'Dest Address1';
Modules.customer_invoice.application_advice_onHold.labels.destinationAddress2 = 'Destination Address2';
Modules.customer_invoice.application_advice_onHold.labels.destAddress2 = 'Dest Address2';
Modules.customer_invoice.application_advice_onHold.labels.destinationCity = 'Destination City';
Modules.customer_invoice.application_advice_onHold.labels.destinationState = 'Destination State';
Modules.customer_invoice.application_advice_onHold.labels.destinationPOBox = 'Destination PO Box';
Modules.customer_invoice.application_advice_onHold.labels.destPOBox = 'Dest PO Box';
Modules.customer_invoice.application_advice_onHold.labels.tenderRequestDate = 'Tender/Request Date';
Modules.customer_invoice.application_advice_onHold.labels.tenderRequestDt = 'Tndr/Rqst Date';
Modules.customer_invoice.application_advice_onHold.labels.shipmentDate = 'Shipment Date';
Modules.customer_invoice.application_advice_onHold.labels.deliveryDate = 'Delivery/Completion Date';
Modules.customer_invoice.application_advice_onHold.labels.deliveryDt = 'Dlvry/Cmpltn Dt';
Modules.customer_invoice.application_advice_onHold.labels.originalOrigin = 'Original Origin';
Modules.customer_invoice.application_advice_onHold.labels.finalDestination = 'Final Destination';
Modules.customer_invoice.application_advice_onHold.labels.itemDescription = 'Item Description';
Modules.customer_invoice.application_advice_onHold.labels.profitLossCenter = 'Profit/Loss Center';
Modules.customer_invoice.application_advice_onHold.labels.customerSalesRegion = 'Customer Sales Region';
Modules.customer_invoice.application_advice_onHold.labels.customerSalesRgn = 'Cstmr Sales Rgn';
Modules.customer_invoice.application_advice_onHold.labels.shipmentType = 'Shipment Type';
Modules.customer_invoice.application_advice_onHold.labels.orderType = 'Order Type';
Modules.customer_invoice.application_advice_onHold.labels.abnormalMoveType = 'Abnormal Move Type';
Modules.customer_invoice.application_advice_onHold.labels.abnormalMvType = 'Abnrml Mv Type';
Modules.customer_invoice.application_advice_onHold.labels.dealerCode = 'Dealer Code';
Modules.customer_invoice.application_advice_onHold.labels.supplier = 'Supplier';
Modules.customer_invoice.application_advice_onHold.labels.consolidationId = 'Consolidation ID';
Modules.customer_invoice.application_advice_onHold.labels.consolidationType = 'Consolidation Type';
Modules.customer_invoice.application_advice_onHold.labels.consType = 'Cnsldtn Type';
Modules.customer_invoice.application_advice_onHold.labels.technicalDescription = 'Technical Description';
Modules.customer_invoice.application_advice_onHold.labels.techDescription = 'Technical Desc';
Modules.customer_invoice.application_advice_onHold.labels.currency = 'Currency';
Modules.customer_invoice.application_advice_onHold.labels.invoiceAmount = 'Invoice Amount';


Modules.customer_invoice.application_advice_onHold.labels.windowTitle = 'Customer Application Advice On Hold';






Modules.LblsAndTtls.shipmentRefNoFullTlt='Shipment Reference Number';

/********************START of Non-Ocean Supplier Reconciliation********************************************/
Modules.supplier_invoice.supplier_reconciliation.supReconTabPaneltTtl='Supplier Reconciliation';
Modules.supplier_invoice.supplier_reconciliation.labels.advanceSearch='Advance Search';
Modules.supplier_invoice.supplier_reconciliation.labels.keySearch='Key Search';
Modules.supplier_invoice.supplier_reconciliation.labels.supplier='Supplier';
Modules.supplier_invoice.supplier_reconciliation.labels.supplierName='Supplier Name';
Modules.supplier_invoice.supplier_reconciliation.labels.invoiceNmbr='Invoice Number';
Modules.supplier_invoice.supplier_reconciliation.labels.origin='Origin';
Modules.supplier_invoice.supplier_reconciliation.labels.destination='Destination';
Modules.supplier_invoice.supplier_reconciliation.labels.unitId='Unit ID';
Modules.supplier_invoice.supplier_reconciliation.labels.conveyanceId='Conveyance ID';
Modules.supplier_invoice.supplier_reconciliation.labels.model='Model';
Modules.supplier_invoice.supplier_reconciliation.labels.dueFromDate='Due (From Date)';
Modules.supplier_invoice.supplier_reconciliation.labels.dueToDate='Due (To Date)';
Modules.supplier_invoice.supplier_reconciliation.labels.mismatchReason='Mismatch Reason';
Modules.supplier_invoice.supplier_reconciliation.labels.serviceType='Service Type';
Modules.supplier_invoice.supplier_reconciliation.labels.loadRefNo='Load Ref No';
Modules.supplier_invoice.supplier_reconciliation.labels.tndrReqDt 	= 	'Tndr/Req Date';
Modules.supplier_invoice.supplier_reconciliation.labels.tndrReqDtToolTip	= 	'Tender/Request Date';

Modules.supplier_invoice.supplier_reconciliation.labels.status='Status';
Modules.supplier_invoice.supplier_reconciliation.labels.readyForReconcile='Ready For Reconcile';
Modules.supplier_invoice.supplier_reconciliation.labels.rejected='Rejected';
Modules.supplier_invoice.supplier_reconciliation.labels.approved='Approved';
Modules.supplier_invoice.supplier_reconciliation.labels.undrInvst='Under Investigation';
Modules.supplier_invoice.supplier_reconciliation.labels.reconciled='Reconciled';
Modules.supplier_invoice.supplier_reconciliation.labels.details='Details';

Modules.supplier_invoice.supplier_reconciliation.labels.serviceCode='Service Code';
Modules.supplier_invoice.supplier_reconciliation.labels.eventLoadRef='Event/Load Reference';
Modules.supplier_invoice.supplier_reconciliation.labels.originLocation='Origin/Location';
Modules.supplier_invoice.supplier_reconciliation.labels.destinationCity='Destination City';
Modules.supplier_invoice.supplier_reconciliation.labels.shippingRef='Shipping Reference';
Modules.supplier_invoice.supplier_reconciliation.labels.make='Make';
Modules.supplier_invoice.supplier_reconciliation.labels.dtlsTtl='Details';
Modules.supplier_invoice.supplier_reconciliation.labels.oringLocation='Origin/Location';
Modules.supplier_invoice.supplier_reconciliation.labels.workOrder='Work Order';
Modules.supplier_invoice.supplier_reconciliation.labels.partNmbr='Part Number';
Modules.supplier_invoice.supplier_reconciliation.labels.invoiceAmount='Invoice Amount';
Modules.supplier_invoice.supplier_reconciliation.labels.consolicationId='Consolidation ID';
Modules.supplier_invoice.supplier_reconciliation.labels.supLineItmDtls='Supplier Line Item Details';
Modules.supplier_invoice.supplier_reconciliation.labels.matchEvntDtls='Matching Event Details';

/********************END of Non-Ocean Supplier Reconciliation********************************************/
Modules.LblsAndTtls.shipmentRefNoFullTlt='Shipment Reference Number';


// Market Area Mapper
Modules.Mappers.MarketArea.PartnerGroupCode = 'Partner Group';
Modules.Mappers.MarketArea.internalMarketAreaCountryCode = 'Internal Market Area/Country Code';
Modules.Mappers.MarketArea.externalMarketAreaCountryCode = 'External Market Area/Country Code';
Modules.Mappers.MarketArea.marketAreaMapper = 'Market Area Mapper';

/***********************************************************************/
//#FUEL_SURCHARGE_INDEX_MASTER
/***********************************************************************/
Modules.Masters.Fuel_Surcharge_Index_Master.labels.code = 'Index Code';
Modules.Masters.Fuel_Surcharge_Index_Master.labels.name = 'Index Name';
Modules.Masters.Fuel_Surcharge_Index_Master.labels.uom = 'UOM';
Modules.Masters.Fuel_Surcharge_Index_Master.labels.currency = 'Currency';

/***********************************************************************/
//#Supplier Rate Verification for Non-Ocean
/***********************************************************************/
Modules.contract.supplier.supplierRateVerification.labels.supplier='Supplier';
Modules.contract.supplier.supplierRateVerification.labels.supplierName='Supplier Name';
Modules.contract.supplier.supplierRateVerification.labels.effectiveDate='Effective Date';
Modules.contract.supplier.supplierRateVerification.labels.serviceCode='Service Code';
Modules.contract.supplier.supplierRateVerification.labels.customer='Customer';
Modules.contract.supplier.supplierRateVerification.labels.transportMode='Transport Mode';
Modules.contract.supplier.supplierRateVerification.labels.rateTier='Rate Tier';
Modules.contract.supplier.supplierRateVerification.labels.originCity='Origin City';
Modules.contract.supplier.supplierRateVerification.labels.originState='Origin State/Prov';
Modules.contract.supplier.supplierRateVerification.labels.originStateFull='Origin State/Province';
Modules.contract.supplier.supplierRateVerification.labels.origin='Origin';
Modules.contract.supplier.supplierRateVerification.labels.destination='Destination';
Modules.contract.supplier.supplierRateVerification.labels.destinationCity='Destination City';
Modules.contract.supplier.supplierRateVerification.labels.destinationState='Dest State/Prov';
Modules.contract.supplier.supplierRateVerification.labels.destinationStateFull='Destination State/Province';
Modules.contract.supplier.supplierRateVerification.labels.makeCode='Make Code';
Modules.contract.supplier.supplierRateVerification.labels.model='Model Code';
Modules.contract.supplier.supplierRateVerification.labels.modelGroupCode='Model Group';
Modules.contract.supplier.supplierRateVerification.labels.modelGroupCodeFull='Model Group Code';
Modules.contract.supplier.supplierRateVerification.labels.partCode='Part Code';
Modules.contract.supplier.supplierRateVerification.labels.conveyanceType='Conveyance Type';
Modules.contract.supplier.supplierRateVerification.labels.modelYear='Model Year';
Modules.contract.supplier.supplierRateVerification.labels.originalOrigin='Original Origin';
Modules.contract.supplier.supplierRateVerification.labels.finalDestination='Final Destination';
Modules.contract.supplier.supplierRateVerification.labels.consolidationType='Consolidation';
Modules.contract.supplier.supplierRateVerification.labels.consolidationTypeFull='Consolidation Type Code';
Modules.contract.supplier.supplierRateVerification.labels.partyDetails='Party Details';
Modules.contract.supplier.supplierRateVerification.labels.contractId='Contract ID';
Modules.contract.supplier.supplierRateVerification.labels.customerCode='Customer Code';
Modules.contract.supplier.supplierRateVerification.labels.originLocation='Origin/Location';
Modules.contract.supplier.supplierRateVerification.labels.originLocationCityFull='Origin/Location City';
Modules.contract.supplier.supplierRateVerification.labels.originLocationState='Origin State/Prov';
Modules.contract.supplier.supplierRateVerification.labels.originLocationCity='Origin City';
Modules.contract.supplier.supplierRateVerification.labels.originLocationStateFull='Origin/Location State/Province';
Modules.contract.supplier.supplierRateVerification.labels.notChargeable='Not Chargeable';
Modules.contract.supplier.supplierRateVerification.labels.program='Program';
Modules.contract.supplier.supplierRateVerification.labels.index='Index';
Modules.contract.supplier.supplierRateVerification.labels.eventDate='Event Date';
Modules.contract.supplier.supplierRateVerification.labels.uom='UOM';
Modules.contract.supplier.supplierRateVerification.labels.uomFull='Unit Of Measure';
Modules.contract.supplier.supplierRateVerification.labels.uomCodeFull='Unit Of Measure Code';
Modules.contract.supplier.supplierRateVerification.labels.fixedRate='Fixed Rate';
Modules.contract.supplier.supplierRateVerification.labels.variableComponent='Variable Component';
Modules.contract.supplier.supplierRateVerification.labels.tariffCode='Tariff Code';
Modules.contract.supplier.supplierRateVerification.labels.tariffUnitRate='Tariff Unit Rate';
Modules.contract.supplier.supplierRateVerification.labels.uInd='L/U Ind';
Modules.contract.supplier.supplierRateVerification.labels.tariffCurrencyCode='Tariff Currency';
Modules.contract.supplier.supplierRateVerification.labels.tariffCurrencyCodeFull='Tariff Currency Code';
Modules.contract.supplier.supplierRateVerification.labels.composite='Composite';
Modules.contract.supplier.supplierRateVerification.labels.nonTaxable='NonTaxable';
Modules.contract.supplier.supplierRateVerification.labels.priority='Priority';
Modules.contract.supplier.supplierRateVerification.labels.supplierRateVerification='Supplier Rate Verification';
Modules.contract.supplier.supplierRateVerification.labels.modelLine='Model Line';
Modules.contract.supplier.supplierRateVerification.labels.cargoType='Cargo Type';
Modules.contract.supplier.supplierRateVerification.labels.storageType='Storage Type';

/***********************************************************************/
//#NON OCEAN SPPLIER AUTOMATIC INVOICE SetUP
/***********************************************************************/

Modules.contract.supplier.supplier_auto_invoice.labels.companyCode = 'Company Code';
Modules.contract.supplier.supplier_auto_invoice.labels.companyName = 'Company Name';
Modules.contract.supplier.supplier_auto_invoice.labels.generationFrequency = 'Generation Frequency';
Modules.contract.supplier.supplier_auto_invoice.labels.generationTime = 'Generation Time';
Modules.contract.supplier.supplier_auto_invoice.labels.intervel = 'Interval';
Modules.contract.supplier.supplier_auto_invoice.labels.serviceType = 'Service Type';
Modules.contract.supplier.supplier_auto_invoice.labels.serviceCode = 'Service Code';
Modules.contract.supplier.supplier_auto_invoice.labels.tarrifCurrency = 'Tariff Currency';
Modules.contract.supplier.supplier_auto_invoice.labels.origin = 'Origin / Service Location';
Modules.contract.supplier.supplier_auto_invoice.labels.destination= 'Destination';
Modules.contract.supplier.supplier_auto_invoice.labels.loadReference = 'Load Reference';
Modules.contract.supplier.supplier_auto_invoice.supplierCode = 'Supplier Code';
Modules.contract.supplier.supplier_auto_invoice.labels.transportMode = 'Transport Mode';



/***********************************************************************/
//# Supplier Rates
/***********************************************************************/

Modules.lov_factory.labels.contractId='Contract Id';
Modules.lov_factory.labels.program='Program';
Modules.supplierRates.labels.formTtl='Supplier Rates';
Modules.supplierRates.labels.validfrmdate='Valid from Date';
Modules.supplierRates.labels.validToDate='Valid to Date';
Modules.supplierRates.labels.gridContrctId='Contract ID';
Modules.supplierRates.labels.Supplier='Supplier';
Modules.supplierRates.labels.supplierName='Supplier Name';
Modules.supplierRates.labels.remark='Remark';
Modules.supplierRates.labels.servLevelValDats='Service Level Valid dates';
Modules.supplierRates.labels.cnsolidatdFulSrChrgInvc='Consolidated Fuel Surcharge Invoice';
Modules.supplierRates.labels.srvCode='Service Code';
Modules.supplierRates.labels.customer='Customer';
Modules.supplierRates.labels.origin='Origin';
Modules.supplierRates.labels.seqno='Seq No';
Modules.supplierRates.labels.priority='Priority';
Modules.supplierRates.labels.eventdate='Event Date';
Modules.supplierRates.labels.index='Index';
Modules.supplierRates.labels.program='Program';
Modules.supplierRates.labels.notTaxable='Not Taxable';
Modules.supplierRates.labels.notChrgble='Not Chargeable';
Modules.supplierRates.labels.consoldtinType='Consolidation Type';
Modules.supplierRates.labels.modelGrp='Model Group';
Modules.supplierRates.labels.destCntry='Destination Country';
Modules.supplierRates.labels.destStateProv='Destination State/Prov';
Modules.supplierRates.labels.destCity='Destination City';
Modules.supplierRates.labels.orgCntry='Origin Country';
Modules.supplierRates.labels.orgStateProv='Origin State/Prov';
Modules.supplierRates.labels.orgCity='Origin City';
Modules.supplierRates.labels.destination='Destination';
Modules.supplierRates.labels.origin='Origin';
Modules.supplierRates.labels.profLossCntr='Profit/Loss Center';
Modules.supplierRates.labels.minload='Min Load';
Modules.supplierRates.labels.agreedMilage='Agreed Mileage';
Modules.supplierRates.labels.fuleSrvChrgDtls='Fuel Surcharge Details';
Modules.supplierRates.labels.srvChrgDtls='Service Charge Details';
Modules.supplierRates.labels.minLoadDtls='Minimum Load Details';
Modules.supplierRates.labels.agreedMilageDtls='Agreed Mileage Details';
Modules.supplierRates.labels.conType='Conveyance Type';
Modules.supplierRates.labels.conTypetooltip='Conv Type';

Modules.supplierRates.labels.tarifCrncyCdtooltip='Tariff Curncy';
Modules.supplierRates.labels.cargoType='Cargo Type';
Modules.supplierRates.labels.storageType='Storage Type';
Modules.supplierRates.labels.modelLine='Model Line';



/**************************************/
///// Trunk Move US Canada
/*************************************/
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.ParentPanelTmplt='Truck Invoice Entry(US/Canada)';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.truckInvoiceEntry='Truck Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.supplier='Supplier';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.supplierName='Supplier Name';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.invcNumber='Invoice Number';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.invcDate='Invoice Date';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.currency='Currency';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.refInvcNum='Reference Invoice Number';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.status='Status';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.docType='Document Type';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.party='Party';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.paymentDetails='Payment Details';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.partyName='Party Name';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.addr1='Address Line 1';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.addr2='Address Line 2';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.invcDueDate='Invoice Due Date';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.city='City';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.state='State/Province';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.cntry='Country';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.zipPostalCd='Zip/Postal Code';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.proId='PRO ID';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.proDate='PRO Date';
Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels.dtlsBtn = 'Details'

/********************************************/
///// Non Ocean SUPPLIER Invoice Entry Mexico
/********************************************/
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.ParentPanelTmplt='Truck Invoice Entry(Mexico)';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.truckInvoiceEntry='Truck Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.supplier='Supplier';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.supplierName='Supplier Name';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.invcNumber='Invoice Number';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.invcDate='Invoice Date';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.currency='Currency';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.refInvcNum='Reference Invoice Number';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.status='Status';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.docType='Document Type';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.party='Party';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.paymentDetails='Payment Details';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.partyName='Party Name';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.addr1='Address Line 1';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.addr2='Address Line 2';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.invcDueDate='Invoice Due Date';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.city='City';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.proId='PRO ID';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.proDate='PRO Date';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.state='State/Prov';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.cntry='Country';
Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels.zipPostalCd='Zip/Postal Code';
Modules.supplier_invoice.supplier_invoice_entry.rail_invoice_entry.labels.ParentPanelTmplt = 'Rail Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.ocean_invoice_entry.labels.ParentPanelTmplt = 'Ocean Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.general_invoice_entry.labels.ParentPanelTmplt = 'General Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.service_charge_invoice_entry.labels.ParentPanelTmplt = 'Service Charge Invoice Entry';
Modules.supplier_invoice.supplier_invoice_entry.uom = "Unit of Measure";
Modules.supplier_invoice.supplier_invoice_entry.fxtTrfUnitRt = 'Fixed Tariff Unit Rate';
Modules.supplier_invoice.supplier_invoice_entry.shpRef = 'Shipping Reference';

Modules.supplierRates.labels.destCitytooltip='Dest. City';
Modules.supplierRates.labels.consoldtinTypetooltip='Consl. Type';
Modules.supplierRates.labels.effectveDate='Effective Date';
Modules.supplierRates.labels.transprtMode='Transport Mode';
Modules.supplierRates.labels.rateTier='Rate Tier';
Modules.supplierRates.labels.conveynceType='Conveyance Type';
Modules.supplierRates.labels.makeCd='Make Code';
Modules.supplierRates.labels.modelcd='Model Code';
Modules.supplierRates.labels.modelYear='Model Year';
Modules.supplierRates.labels.modelGrp='Model Group';
Modules.supplierRates.labels.partId='Part ID';

Modules.supplierRates.labels.orgOrigin='Original Origin';
Modules.supplierRates.labels.finalDest='Final Destination';
Modules.supplierRates.labels.factorValue='Factor Value';
Modules.supplierRates.labels.factorType='Factor Type';
Modules.supplierRates.labels.factorRate='Factor Rate';
Modules.supplierRates.labels.uom='UOM';
Modules.supplierRates.labels.fixedRate='Fixed Rate';
Modules.supplierRates.labels.tariffCd='Tariff Code';


Modules.supplierRates.labels.tariffUnitRate='Tariff Unit rate';
Modules.supplierRates.labels.variablCmpnt='Variable Component';
Modules.supplierRates.labels.luInd='L/U Ind';
Modules.supplierRates.labels.tariffCrncyCd='Tariff Currency Code';
Modules.supplierRates.labels.composite='Composite';
Modules.supplierRates.labels.notTaxable='Not Taxable';
Modules.supplierRates.labels.destCntryTooltip='Dest Cntry';
Modules.supplierRates.labels.destStateTooltip='Dest State/Prov';
Modules.supplierRates.labels.orgStateTooltip='Org. State/Prov';
Modules.lov_factory.labels.partId='Part ID';
Modules.supplierRates.labels.compositeTotal='Total';
Modules.supplierRates.labels.composite = 'Composite';
Modules.supplierRates.labels.noOfVin='Number of VIN';
Modules.supplierRates.labels.distance='Distance';


Modules.supplier.supplier_reconcilation_setup.unitId='Unit ID';
Modules.supplier.supplier_reconcilation_setup.originLocation='Origin/Location';
Modules.supplier.supplier_reconcilation_setup.destination='Destination';
Modules.supplier.supplier_reconcilation_setup.shippingReference='Shipping Reference';
Modules.supplier.supplier_reconcilation_setup.eventLoadRef='Event/Load Reference';
Modules.supplier.supplier_reconcilation_setup.conveyanceId='Conveyance ID';
Modules.supplier.supplier_reconcilation_setup.partId='Part ID';


Modules.LocationCode.Mapper.Title='Location Code Mapper';
Modules.LocationCode.Mapper.externalCompanyCode='External Company Code';
Modules.LocationCode.Mapper.internalCompanyCode='Internal Company Code';
Modules.LocationCode.Mapper.externalLocationCode='External Location Code';
Modules.LocationCode.Mapper.internalLocationCode='Internal Location Code';

/***********************************************************************/
//#MODEL_MASTER
/***********************************************************************/
Modules.Masters.Model_Master.makeCode = 'Make Code';
Modules.Masters.Model_Master.labels.makeDescription = 'Make Description';
Modules.Masters.Model_Master.labels.code = 'Code';
Modules.Masters.Model_Master.labels.description = 'Description';


/*********************************************************************/
//#supplier Master
/*********************************************************************/
Modules.LblsAndTtls.supplrInvcMsgTlt = 'Supplier Invoice Message';
Modules.LblsAndTtls.reconcilationAndApprovalDtls = 'Reconciliation and Approval Details';
Modules.LblsAndTtls.supplierMasterPaymentTerm = 'Payment Terms';
Modules.LblsAndTtls.supplierMasterRateRoundingCriteriaDistance = 'Rounding Criteria for Distance';


/***********************************************************************/
//#PLANT_NAME_MAPPER
/***********************************************************************/
Modules.Masters.Plant_Name_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Plant_Name_Mapper.labels.externalPlantNumber = 'External Plant Number';
Modules.Masters.Plant_Name_Mapper.labels.internalPlantNumber = 'Internal Plant Number';


/************customer_line_item_status for Non-Ocean****************/
Modules.customer_invoice.customer_line_item_status.labels.customer='Customer';
Modules.customer_invoice.customer_line_item_status.labels.debtorParty='Debtor Party';
Modules.customer_invoice.customer_line_item_status.labels.invoiceNumber='Invoice Number';
Modules.customer_invoice.customer_line_item_status.labels.invoiceFromDate='Invoice from Date';
Modules.customer_invoice.customer_line_item_status.labels.invoiceToDate='Invoice to Date';
Modules.customer_invoice.customer_line_item_status.labels.serviceType='Service Type';
Modules.customer_invoice.customer_line_item_status.labels.serviceCode='Service Code';
Modules.customer_invoice.customer_line_item_status.labels.unitId='Unit ID';
Modules.customer_invoice.customer_line_item_status.labels.origin='Origin';
Modules.customer_invoice.customer_line_item_status.labels.destination='Destination';
Modules.customer_invoice.customer_line_item_status.labels.eventLoadReference='Event/Load Ref';
Modules.customer_invoice.customer_line_item_status.labels.eventLoadReferenceFull='Event/Load Reference';
Modules.customer_invoice.customer_line_item_status.labels.conveyanceId='Conveyance ID';
Modules.customer_invoice.customer_line_item_status.labels.shippingReference='Shipping Ref';
Modules.customer_invoice.customer_line_item_status.labels.shippingReferenceFull='Shipping Reference';
Modules.customer_invoice.customer_line_item_status.labels.profitLoss='Profit/Loss Center';
Modules.customer_invoice.customer_line_item_status.labels.documentReferenceFull='Document Reference';
Modules.customer_invoice.customer_line_item_status.labels.documentReference='Document Ref';
Modules.customer_invoice.customer_line_item_status.labels.documentType='Document Type';
Modules.customer_invoice.customer_line_item_status.labels.invoiceType='Invoice Type';
Modules.customer_invoice.customer_line_item_status.labels.invoiceStatus='Invoice Status';

Modules.customer_invoice.customer_line_item_status.labels.invoiceDate='Invoice Date';
Modules.customer_invoice.customer_line_item_status.labels.invoiceAmount='Invoice Amount';
Modules.customer_invoice.customer_line_item_status.labels.paidAmount='Paid Amount';
Modules.customer_invoice.customer_line_item_status.labels.currency='Currency';
Modules.customer_invoice.customer_line_item_status.labels.partId='Part ID';
Modules.customer_invoice.customer_line_item_status.labels.completionDate='Delivery Date';
Modules.customer_invoice.customer_line_item_status.labels.completionDateFull='Delivery/Completion Date';
Modules.customer_invoice.customer_line_item_status.labels.dueDate='Due Date';
Modules.customer_invoice.customer_line_item_status.labels.lastPaymentDate='Last Payment Date';
Modules.customer_invoice.customer_line_item_status.labels.lineItemStatus='Line Item Status';
Modules.customer_invoice.customer_line_item_status.labels.reason='Reason';

Modules.customer_invoice.customer_line_item_status.labels.gridRecords='Customer Line Item Status Grid Records';
Modules.customer_invoice.customer_line_item_status.labels.proformaText='Proforma';
Modules.customer_invoice.customer_line_item_status.labels.rejectedText='Rejected';
Modules.customer_invoice.customer_line_item_status.labels.finalText='Final';
Modules.customer_invoice.customer_line_item_status.labels.paidText='Paid';
Modules.customer_invoice.customer_line_item_status.labels.actualRadioButton='Actual';
Modules.customer_invoice.customer_line_item_status.labels.accuralRadioButton='Accrual';
Modules.customer_invoice.customer_line_item_status.labels.invoiceText='Invoice';
Modules.customer_invoice.customer_line_item_status.labels.creditText='Credit Note';
Modules.customer_invoice.customer_line_item_status.labels.debitText='Debit Note';
Modules.customer_invoice.customer_line_item_status.labels.statusFieldSet='Status';
Modules.customer_invoice.customer_line_item_status.labels.invoiceTypeFieldSet='Invoice Type';
Modules.customer_invoice.customer_line_item_status.labels.docTypeFieldSet='Document Type';
Modules.customer_invoice.customer_line_item_status.labels.formTitle='Customer Line Item Status';

/***********************************************************************/
//# Supplier Rate Query Service Code for Non-Ocean
/***********************************************************************/
Modules.contract.supplier.supplierRateQueryServiceCode.labels.supplier='Supplier';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.supplierName='Supplier Name';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.contractId='Contract ID';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.effectiveDate='Effective Date';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.serviceCode='Service Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.customer='Customer Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.transportMode='Transport Mode';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.rateTier='Rate Tier';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.origin='Origin/Location';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.destination='Destination';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.conveyanceType='Conveyance Type';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.makeCode='Make Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.model='Model Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.modelYear='Model Year';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.modelGroupCode='Model Group';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.modelGroupCodeFull='Model Group Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.partCode='Part ID';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originLocationCity='Origin/Loc City';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originLocationState='Origin/Loc S/P';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originLocationStateTooltip='Origin/Loc State/Prov';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.destinationCity='Destination City';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.destinationStateFullTooltip='Destination State/Prov';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.destinationStateFull='Destination S/P';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originCity='Origin City';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originState='Origin State/Prov';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.originalOrigin='Original Origin';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.finalDestination='Final Destination';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.consolidationType='Consolidation';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.consolidationTypeFullToolTip='Consolidation Type Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.consolidationTypeFull='Consolidation Cd';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.notChargeable='Not Chargeable';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.factorValue='Factor Value';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.factorType='Factor Type';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.factorRate='Factor Rate';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.program='Program';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.index='Index';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.eventDate='Event Date';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.uom='UOM';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.fixedRate='Fixed Rate';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.tariffCode='Tariff Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.tariffUnitRate='Tariff Unit Rate';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.uInd='L/U Ind';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.tariffCurrencyCode='Trf Currency Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.tariffCurrencyCodeTooltip='Tariff Currency Code';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.composite='Composite';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.nonTaxable='Non Taxable';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.priority='Priority';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.cargoType='Cargo Type';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.storageType='Storage Type';
Modules.contract.supplier.supplierRateQueryServiceCode.labels.modelLineCd='Model Line';

/***********************************************************************/
//#CONSOLIDATION_TYPE_MAPPER
/***********************************************************************/
Modules.Masters.Consolidation_Type_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Consolidation_Type_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Consolidation_Type_Mapper.labels.externalConsolidationTypeCode = 'External Consolidation Type Code';
Modules.Masters.Consolidation_Type_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Consolidation_Type_Mapper.labels.internalConsolidationTypeCode = 'Internal Consolidation Type Code';
	
	
	
Modules.LblsAndTtls.supplierRating = 'Supplier Rating';
Modules.LblsAndTtls.customerRating = 'Customer Rating';

Modules.Mappers.Application_Advice_Mapper.CompanyCode = 'Company Code';
Modules.Mappers.Application_Advice_Mapper.CustomerCode = 'Customer Code';
Modules.Mappers.Application_Advice_Mapper.errorDescription = 'Technical Error Description';
Modules.Mappers.Application_Advice_Mapper.onhold = 'On Hold';
Modules.Mappers.Application_Advice_Mapper.ScreenName = 'Appication Advice Mapper';

/***********************************************************************/
//#MODEL_GROUP_MAPPER
/***********************************************************************/
Modules.Masters.Model_Group_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Model_Group_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Model_Group_Mapper.labels.externalModelGroupCode = 'External Model Group Code';
Modules.Masters.Model_Group_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Model_Group_Mapper.labels.internalModelGroupCode = 'Internal Model Group Code';

/***********************************************************************/
//#CUSTOMER_MAPPER
/***********************************************************************/
Modules.Masters.Customer_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Customer_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Customer_Mapper.labels.externalCustomerCode = 'External Customer Code';
Modules.Masters.Customer_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Customer_Mapper.labels.internalCustomerCode = 'Internal Customer Code';



/***********************************************************************/
//#SUPPLIER RATE QUERY - NON OCEAN
/***********************************************************************/
Modules.contract.supplier.supplierRateQuery.labels.supplier='Supplier';
Modules.contract.supplier.supplierRateQuery.labels.supplierName='Supplier Name';
Modules.contract.supplier.supplierRateQuery.labels.contractId='Contract ID';
Modules.contract.supplier.supplierRateQuery.labels.companyCode='Company Code';
Modules.contract.supplier.supplierRateQuery.labels.validFromDate='Start Date';
Modules.contract.supplier.supplierRateQuery.labels.validToDate='End Date';




/***********************************************************************/
//#CUSTOMER_INVOICE_ENTRY_CONSOLIDATION
/***********************************************************************/
Modules.customer_invoice.customer_invoice_entry_consol.labels.cstmrInvcEntryConsolTtl = 'Customer Invoice Entry Consolidation';
Modules.customer_invoice.customer_invoice_entry_consol.labels.customer_code = 'Customer Code';
Modules.customer_invoice.customer_invoice_entry_consol.labels.customerNameTlt = 'Customer Name';
Modules.lov_factory.labels.serviceGrpCd='Service Group Code';



/***********************************************************************/
//#SUPPLIER_MAPPER
/***********************************************************************/
Modules.Masters.Supplier_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Supplier_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Supplier_Mapper.labels.externalSupplierCode = 'External Supplier Code';
Modules.Masters.Supplier_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Supplier_Mapper.labels.internalSupplierCode = 'Internal Supplier Code';
/***********************************************************************/
//#Customer Invoice Generation
/***********************************************************************/

Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.formTitle='Generate Invoice';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.supplier='Supplier';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.customer='Customer';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.debtorParty='Debtor Party';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvCode='Service Code';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvgrp='Service Group';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.conveyanceId='Conveyance ID';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.conveyanceType='Conveyance Type';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.conveyanceName='Conveyance Name';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.prftLosCntre='Profit/Loss Center';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.entLoadRef='Event/Load Reference';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.unitId='Unit ID';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.wrkOrder='Work Order';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipingRef='Shipping Reference';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.evntDate='Event Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.frmDate='From Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.toDate='To Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.origin='Origin';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.originCity='Origin City';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.originState='Origin State/Province';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.orgOrigin='Original Origin';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.dest='Destination';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.destCity='Destination City';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.destState='Destination State/Province';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.finalDest='Final Destination';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.generate='Generate';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.deliveryDate='Delivery Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipmentDate='Shipment Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.tenderDate='Tender Date';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.moveRef='Move Reference';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvDesc='Service Description';

Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.originStatetoolTip='Orgin St/Prov';

Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.destStateTooltip='Dest St/Prov';

/***********************************************************************/
//#ABNORMAL_MOVE_TYPE_MAPPER
/***********************************************************************/
Modules.Masters.Abnormal_Move_Type_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Abnormal_Move_Type_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Abnormal_Move_Type_Mapper.labels.externalAbnormalMoveType = 'External Abnormal Move Type';
Modules.Masters.Abnormal_Move_Type_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Abnormal_Move_Type_Mapper.labels.internalAbnormalMoveType = 'Internal Abnormal Move Type';

/* Outbound Message Mapper labels */
Modules.OutboundMessage.Mapper.CompanyCode = 'Company Code';
Modules.OutboundMessage.Mapper.outboundMessageMapper = 'Outbound Message Mapper';
Modules.OutboundMessage.Mapper.SupplierCode = 'Supplier Code';
Modules.OutboundMessage.Mapper.CustomerCode = 'Customer Code';
Modules.OutboundMessage.Mapper.MessageTypeCode = 'Message Type Code';


/***********************************************************************/
//#Supplier Payment Report
/***********************************************************************/
Modules.reports.supplier_payment.labels.companyCode = 'Company Code';
Modules.reports.supplier_payment.labels.companyName = 'Company Name';
Modules.reports.supplier_payment.labels.supplierCode = 'Supplier Code';
Modules.reports.supplier_payment.labels.supplierName = 'Supplier Name';
Modules.reports.supplier_payment.labels.paymentFromDate = 'Payment From Date';
Modules.reports.supplier_payment.labels.paymentToDate = 'Payment To Date';
Modules.reports.supplier_payment.labels.serviceCode = 'Service Code';
Modules.reports.supplier_payment.labels.invoice = 'Invoice';
Modules.reports.supplier_payment.labels.credit = 'Credit';
Modules.reports.supplier_payment.labels.debit = 'Debit';
/***********************************************************************/
//#Supplier Invoice Aging  Report
/***********************************************************************/
Modules.reports.supplier_invoice_aging.labels.companyCode = 'Company Code';
Modules.reports.supplier_invoice_aging.labels.companyName = 'Company Name';	
Modules.reports.supplier_invoice_aging.labels.supplierCode = 'Supplier Code';
Modules.reports.supplier_invoice_aging.labels.supplierName = 'Supplier Name';

/**************************************************************************/
//#CUSTOMER_ACCRUAL_AND_ACTUAL_INVOICE_SETUP
/**************************************************************************/
Modules.Contract.Customer.customer_invoice_setup.labels.serviceGroupCode='Service Group Code';
Modules.Contract.Customer.customer_invoice_setup.labels.serviceGroup='Service Group';
Modules.Contract.Customer.customer_invoice_setup.labels.serviceType='Service Type';
Modules.Contract.Customer.customer_invoice_setup.labels.serviceCode='Service Code';
Modules.Contract.Customer.customer_invoice_setup.labels.tariffCurrency='Tariff Currency';
Modules.Contract.Customer.customer_invoice_setup.labels.taxes='Taxes';
Modules.Contract.Customer.customer_invoice_setup.labels.documentType='Document Type';
Modules.Contract.Customer.customer_invoice_setup.labels.profitLossCentre='Profit/Loss Center';
Modules.Contract.Customer.customer_invoice_setup.labels.originServiceLocation='Origin/Service Location';
Modules.Contract.Customer.customer_invoice_setup.labels.destination='Destination';
Modules.Contract.Customer.customer_invoice_setup.labels.originalOrigin='Original Origin';
Modules.Contract.Customer.customer_invoice_setup.labels.finalDestination='Final Destination';
Modules.Contract.Customer.customer_invoice_setup.labels.conveyance='Conveyance';
Modules.Contract.Customer.customer_invoice_setup.labels.loadReference='Load Reference';
Modules.Contract.Customer.customer_invoice_setup.labels.workOrderNumber='Work Order Number';
Modules.Contract.Customer.customer_invoice_setup.labels.supplierCode='Supplier Code';
Modules.Contract.Customer.customer_invoice_setup.labels.transportMode='Transport Mode';
Modules.Contract.Customer.customer_invoice_setup.labels.consolidationId='Consolidation ID';
Modules.Contract.Customer.customer_invoice_setup.labels.afterGenerationFreq='No.of Days After Generation Frequency';
Modules.Contract.Customer.customer_invoice_setup.labels.generationFrequency='Generation Frequency';
Modules.Contract.Customer.customer_invoice_setup.labels.time='Time';
Modules.Contract.Customer.customer_invoice_setup.labels.autoAprove='Auto Approve (Generate Final Invoice)';
Modules.Contract.Customer.customer_invoice_setup.labels.consolidate='Consolidate';
Modules.Contract.Customer.customer_invoice_setup.labels.maximumLinesInInvoice='Maximum Lines in Invoice';
Modules.Contract.Customer.customer_invoice_setup.labels.printTemplate='Print Template';
Modules.Contract.Customer.customer_invoice_setup.labels.accrualTriggerPoint='Accrual Trigger Point';
Modules.Contract.Customer.customer_invoice_setup.labels.triggerPoint='Trigger Point';
Modules.Contract.Customer.customer_invoice_setup.labels.creditTerm='Credit Term (Calender Days)';
Modules.Contract.Customer.customer_invoice_setup.labels.creditTermBasedOnSupplierApproval='Credit Term Based On Supplier Approval (Business Days)';
Modules.Contract.Customer.customer_invoice_setup.labels.accrualGrpPopupWinTile='Accrual Grouping Criteria';

Modules.ConveyanceType.Mapper.ExternalConveyanceType='External Conveyance Type';
Modules.ConveyanceType.Mapper.InternalConveyanceType='Internal Conveyance Type';
Modules.ConveyanceType.Mapper.Screenname='Conveyance Type Mapper';




/***********************************************************************/
//#Tax Report
/***********************************************************************/
Modules.reports.tax_report.labels.companyCode = 'Company Code';
Modules.reports.tax_report.labels.companyName = 'Company Name';
Modules.reports.tax_report.labels.supplierCode = 'Supplier Code';
Modules.reports.tax_report.labels.supplierName = 'Supplier Name';
Modules.reports.tax_report.labels.fromDate = 'From Date';
Modules.reports.tax_report.labels.toDate = 'To Date';
Modules.reports.tax_report.labels.customerCode = 'Customer Code';
Modules.reports.tax_report.labels.customerName = 'Customer Name';
Modules.reports.tax_report.labels.taxType = 'Tax Type';
Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels.panelTitle='Generate Invoice';



/***********************************************************************/
//#Customer Revenue Report
/***********************************************************************/
Modules.reports.customer_revenue.labels.companyCode = 'Company Code';
Modules.reports.customer_revenue.labels.companyName = 'Company Name';
Modules.reports.customer_revenue.labels.srviceCode = 'Service Code';
Modules.reports.customer_revenue.labels.glCode = 'GL Code';
Modules.reports.customer_revenue.labels.fromDate = 'From Date';
Modules.reports.customer_revenue.labels.toDate = 'To Date';
Modules.reports.customer_revenue.labels.customerCode = 'Customer Code';
Modules.reports.customer_revenue.labels.customerName = 'Customer Name';
Modules.reports.customer_revenue.labels.taxType = 'Tax Type';
Modules.reports.customer_revenue.labels.customerRadio = 'Customer';
Modules.reports.customer_revenue.labels.glCodeRadio = 'GL Code';
Modules.reports.customer_revenue.labels.actual = 'Actual';
Modules.reports.customer_revenue.labels.accrual = 'Accrual';
Modules.reports.customer_revenue.labels.invoice = 'Invoice';
Modules.reports.customer_revenue.labels.credit = 'Credit Note';
Modules.reports.customer_revenue.labels.debit = 'Debit Note';

Modules.OrderType.Mapper.externalCustomerCode='External Customer Code';
Modules.OrderType.Mapper.internalCustomerCode='Internal Customer Code';
Modules.OrderType.Mapper.internalOrderType='Internal Order Type';
Modules.OrderType.Mapper.externalOrderType='External Order Type';
Modules.OrderType.Mapper.Screenname='Order Type Mapper';

/***********************************************************************/
//#RATE_TIER_MAPPER
/***********************************************************************/
Modules.Masters.Rate_Tier_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Rate_Tier_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Rate_Tier_Mapper.labels.externalRateTier = 'External Rate Tier';
Modules.Masters.Rate_Tier_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Rate_Tier_Mapper.labels.internalRateTier = 'Internal Rate Tier';

/***********************************************************************/
//#MAKE_MODEL_MAPPER
/***********************************************************************/
Modules.Masters.Make_Model_Mapper.labels.partnerGroup = 'Partner Group';
Modules.Masters.Make_Model_Mapper.labels.externalCompanyCode ='External Company Code';
Modules.Masters.Make_Model_Mapper.labels.externalMakeCode = 'External Make Code';
Modules.Masters.Make_Model_Mapper.labels.externalModelCode = 'External Model Code';
Modules.Masters.Make_Model_Mapper.labels.internalCompanyCode = 'Internal Company Code';
Modules.Masters.Make_Model_Mapper.labels.internalMakeCode = 'Internal Make Code';
Modules.Masters.Make_Model_Mapper.labels.internalModelCode = 'Internal Model Code';

/***********************************************************************/
//#Supplier Rate Report
/***********************************************************************/
Modules.reports.supplier_rate.labels.companyCode = 'Company Code';
Modules.reports.supplier_rate.labels.companyName = 'Company Name';
Modules.reports.supplier_rate.labels.supplierCode = 'Supplier Code';
Modules.reports.supplier_rate.labels.glCode = 'GL Code';
Modules.reports.supplier_rate.labels.fromDate = 'From Date';
Modules.reports.supplier_rate.labels.toDate = 'To Date';

Modules.Master.InvoiceChargeTypeMapper.screenName = 'Invoice Charge Type Mapper';
Modules.Master.InvoiceChargeTypeMapper.extChargeType = 'External Charge Type';
Modules.Master.InvoiceChargeTypeMapper.servCodeTaxtype = 'Service Code/Tax Type Indicator';
Modules.Master.InvoiceChargeTypeMapper.internalServiceCode = 'Internal Service Code';
Modules.Master.InvoiceChargeTypeMapper.internalTaxType = 'Internal Tax Type';

/**************************************************************************/
//#Fuel Surcharge Index Value Master
/**************************************************************************/
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.formTitle='Fuel Surcharge Index Value Master';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.fromDate='From Date';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.toDate='To Date';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.actualIndexValue='Actual Index Value';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.estimatedIndexValue='Estimated Index Value';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.comment='Comment';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.indexCode='Index Code';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.indexName='Index Name';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.uom='UOM';
Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster.labels.currency='Currency';


Modules.Master.TariffMaster.tariffCode='Tariff Code';
Modules.Master.TariffMaster.ScreenName='Tariff Master';
Modules.Master.TariffMaster.TariffDesc='Tariff Description';
Modules.Master.TariffMaster.effectiveDate='Effective Date';
Modules.Master.TariffMaster.Slab='Slab';
Modules.Master.TariffMaster.Cumulative='Cumulative';
Modules.Master.TariffMaster.Currency='Currency';
Modules.Master.TariffMaster.tariffUnitRate='Tariff Unit Rate';

/**************************************************************************/
//#Service Tax Mapper
/**************************************************************************/
Modules.Masters.Service_Tax_Mapper.labels.taxType='Tax Type';
Modules.Masters.Service_Tax_Mapper.labels.taxDescription='Tax Description';
Modules.Masters.Service_Tax_Mapper.labels.serviceCode='Service Code';
Modules.Masters.Service_Tax_Mapper.labels.effectiveDate='Effective Date';
Modules.Masters.Service_Tax_Mapper.labels.origin='Origin';
Modules.Masters.Service_Tax_Mapper.labels.originCity='Origin City';
Modules.Masters.Service_Tax_Mapper.labels.originStateProvince='Origin State/Province';
Modules.Masters.Service_Tax_Mapper.labels.originCountryCode='Origin Country Code';
Modules.Masters.Service_Tax_Mapper.labels.destination='Destination';
Modules.Masters.Service_Tax_Mapper.labels.destinationCity='Destination City';
Modules.Masters.Service_Tax_Mapper.labels.destinationStateProvince='Destination State/Province';
Modules.Masters.Service_Tax_Mapper.labels.destinationCountry='Destination Country Code';
Modules.Masters.Service_Tax_Mapper.labels.originalOrigin='Original Origin';
Modules.Masters.Service_Tax_Mapper.labels.finalDestination='Final Destination';
Modules.Masters.Service_Tax_Mapper.labels.partId='Part ID';
Modules.Masters.Service_Tax_Mapper.labels.trnsMode='Transport Mode';
Modules.Masters.Service_Tax_Mapper.labels.conveyanceType='Conveyance Type';
Modules.Masters.Service_Tax_Mapper.labels.rateTier='Rate Tier';
Modules.Masters.Service_Tax_Mapper.labels.make='Make Code';
Modules.Masters.Service_Tax_Mapper.labels.model='Model Code';
Modules.Masters.Service_Tax_Mapper.labels.modelYear='Model Year';
Modules.Masters.Service_Tax_Mapper.labels.supplier='Supplier';
Modules.Masters.Service_Tax_Mapper.labels.percentage='Percentage';
 
Modules.Master.ServiceMaster.serviceType='Service Type';
Modules.Master.ServiceMaster.serviceCode='Service Code';
Modules.Master.ServiceMaster.serviceDescription='Service Description';
Modules.Master.ServiceMaster.serviceDescription2='Service Description2';
Modules.Master.ServiceMaster.consolidationCategory='Consolidation Category';
Modules.Master.ServiceMaster.fuelSurchargeService='Fuel Surcharge Service';
Modules.Master.ServiceMaster.fuelSurchargeApplicable='Fuel Surcharge Applicable';
Modules.Master.ServiceMaster.taxApplicable='Tax Applicable';
Modules.Master.ServiceMaster.chargeCode='Charge Code';

Modules.Master.ServiceMaster.ScreenName='Service Master';

Modules.Master.ProfitLossCenterMaster.originalLocation='Origin/Location';
Modules.Master.ProfitLossCenterMaster.destination='Destination';
Modules.Master.ProfitLossCenterMaster.originalOrigin='Original Origin';
Modules.Master.ProfitLossCenterMaster.finalDestination='Final Destination';
Modules.Master.ProfitLossCenterMaster.profitLossCentre='Profit/Loss Center';
Modules.Master.ProfitLossCenterMaster.ScreenName='Profit/Loss Center Identification Master';
Modules.Master.ProfitLossCenterMaster.profitLossCentreName='Profit/Loss Center Name';





// START ADMIN GROUP DETAILS SCREEN LABELS

Modules.admin.user_admin.user_management.labels.groupCode='Group Code';
Modules.admin.user_admin.user_management.labels.groupName='Group Name';
Modules.admin.user_admin.user_management.labels.groupDesc='Group Description';
Modules.admin.user_admin.user_management.labels.serviceType='Service Type';
Modules.admin.user_admin.user_management.labels.groupToUserAssociation='Group To User Association';
Modules.admin.user_admin.user_management.labels.groupToFunctionAssociation='Group To Function Association';
Modules.admin.user_admin.user_management.labels.groupToMenuAssociation='Group To Menu Association';
Modules.admin.user_admin.user_management.labels.functionButton='Function';
Modules.admin.user_admin.user_management.labels.apply='Apply';
Modules.admin.user_admin.user_management.labels.close='Close';
Modules.admin.user_admin.user_management.labels.deniedMenus='Denied Menus';
Modules.admin.user_admin.user_management.labels.groupDetails='Group Details';
Modules.admin.user_admin.user_management.labels.properties='Properties';
Modules.admin.user_admin.user_management.labels.newGroup='New Group';
Modules.admin.user_admin.user_management.labels.deleteGroup='Delete Group';
Modules.admin.user_admin.user_management.labels.copyGroup='Copy Group';
Modules.admin.user_admin.user_management.labels.add='Add';
Modules.admin.user_admin.user_management.labels.addAll='Add All';
Modules.admin.user_admin.user_management.labels.remove='Remove';
Modules.admin.user_admin.user_management.labels.removeAll='Remove All';
Modules.admin.user_admin.user_management.labels.save='Save';
Modules.admin.user_admin.user_management.labels.availableUsers='Available Users';
Modules.admin.user_admin.user_management.labels.assignedValues='Assigned Values';
Modules.admin.user_admin.user_management.labels.listOfFunctions='List of Functions';
Modules.admin.user_admin.user_management.labels.type='Type';
Modules.admin.user_admin.user_management.labels.functionName='Function Name';
Modules.admin.user_admin.user_management.labels.ok='OK';
Modules.admin.user_admin.user_management.labels.moduleName='Module Name';
Modules.admin.user_admin.user_management.labels.name='Name';


//END ADMIN GROUP DETAILS SCREEN LABELS

Modules.Masters.Currency.CurrencyCode ='Currency Code';
Modules.Masters.Currency.CurrencyDescription='Currency Description';
Modules.Masters.Currency.CountryCode='Country Code';
Modules.Masters.Currency.EffectiveDate='Effective Date';
Modules.Masters.Currency.ExchangeRate='Exchange Rate';
Modules.Masters.Currency.ScreenName='Currency Code Master';
Modules.Masters.Currency.CurrencySymbol='Currency Symbol';

Modules.Master.Ocean.ProfitLossCenterMaster.pol='POL';
Modules.Master.Ocean.ProfitLossCenterMaster.pod='POD';
Modules.Master.Ocean.ProfitLossCenterMaster.por='POR';
Modules.Master.Ocean.ProfitLossCenterMaster.pfd='PFD';


Modules.Ocean.CustInvcSetup.labels.pop = 'POP';

Modules.Master.ServiceMaster.OceanScreenName='Charge Code Master';

Modules.contract.customer.customerdebtorparty.labels.panelTitle='Customer Debtor Party Details';
Modules.contract.customer.customerdebtorparty.labels.customer='Customer';
Modules.contract.customer.customerdebtorparty.labels.customerNm='Customer Name';
Modules.contract.customer.customerdebtorparty.labels.dbtrPartyCd='Debtor Party';
Modules.contract.customer.customerdebtorparty.labels.debtorPartyNm='Debtor Party Name';
Modules.contract.customer.customerdebtorparty.labels.taxRefNo='Tax Ref No';
Modules.contract.customer.customerdebtorparty.labels.address1='Address1';
Modules.contract.customer.customerdebtorparty.labels.address2='Address2';
Modules.contract.customer.customerdebtorparty.labels.city='City';
Modules.contract.customer.customerdebtorparty.labels.state='State/Province';
Modules.contract.customer.customerdebtorparty.labels.country='Country';
Modules.contract.customer.customerdebtorparty.labels.zip='Zip/Postal Code';
Modules.contract.customer.customerdebtorparty.labels.telephoneno='Telephone No.';
Modules.contract.customer.customerdebtorparty.labels.fax='Fax Number';
Modules.contract.customer.customerdebtorparty.labels.mobileNo='Mobile Number';
Modules.contract.customer.customerdebtorparty.labels.emailAddress='Email Address';
Modules.contract.customer.customerdebtorparty.labels.contactPsnNm='Contact Person Name';
Modules.contract.customer.customerdebtorparty.labels.subLedgerCode='Sub Ledger Code';
Modules.contract.customer.customerdebtorparty.labels.remarks1='Remarks1';
Modules.contract.customer.customerdebtorparty.labels.remarks2='Remarks2';
Modules.contract.customer.customerdebtorparty.labels.sendCustAccToCodaFlg='Send Customer Accural To CODA';
Modules.contract.customer.customerdebtorparty.labels.waitForAPApproveFlg='Download A/R To A/P';
Modules.contract.customer.customerdebtorparty.labels.autoApproveApplnAdviceFlg='Auto Approve in Application Advice';
Modules.contract.customer.customerdebtorparty.labels.sendCstmrInvcMsgFlg='Send Customer Invoice Message';

Modules.customer_invoice.customer_invoice_entry.labels.ConsolidateGridTitle = 'Consolidation Details';


Modules.Ocean.Masters.OceanCountryCodeRevenueMaster.countryCode='Country';
Modules.Ocean.Masters.OceanCountryCodeRevenueMaster.costCode='Cost Code';
Modules.Ocean.Masters.OceanCountryCodeRevenueMaster.revenueCode='Revenue Code';

/***********************************************************************/
//# CARGO Clause Revenue_MASTER
/***********************************************************************/
Modules.Masters.ocean.cargoClassRevenueMaster.labels.cargoClassCode = "Cargo Class Code";
Modules.Masters.ocean.cargoClassRevenueMaster.labels.revenueCode = "Revenue Code";
Modules.Masters.ocean.cargoClassRevenueMaster.labels.costCode = "Cost Code";
Modules.Masters.ocean.cargoClassRevenueMaster.labels.priority = "Priority";


//Parameter Master //
Modules.Masters.General_Master.labels.parameterDesc = 'Parameter Description';
Modules.Masters.General_Master.labels.parameterValue = 'Parameter Value';
Modules.Masters.General_Master.labels.parameterValInt = 'Integer(I)/Character(C)';

//Ocean View Voyage Master //
Modules.LblsAndTtls.voyageCurrencyCode = 'Voyage Currency Code';
Modules.LblsAndTtls.actionCode = 'Action Code';
Modules.LblsAndTtls.portCurrencyCd = 'Port Currency Code';
Modules.LblsAndTtls.portType = 'Port Type';
Modules.LblsAndTtls.recalcFlg = "Recalculate Flag";
Modules.LblsAndTtls.etaDt = "ETA Date";
Modules.LblsAndTtls.etdDt = "ETD Date";
Modules.LblsAndTtls.ataDt = "ATA Date";
Modules.LblsAndTtls.atdDt = "ATD Date";

Modules.LblsAndTtls.reference1Title				=		'Reference 1';
Modules.LblsAndTtls.reference2Title				=		'Reference 2';
Modules.LblsAndTtls.reference3Title				=		'Reference 3';
Modules.LblsAndTtls.reference4Title				=		'Reference 4';
Modules.LblsAndTtls.reference5Title				=		'Reference 5';
Modules.LblsAndTtls.reference6Title				=		'Reference 6';
Modules.LblsAndTtls.reference7Title				=		'Reference 7';
Modules.LblsAndTtls.reference8Title				=		'Reference 8';
Modules.LblsAndTtls.reference9Title				=		'Reference 9';
Modules.LblsAndTtls.reference10Title			=		'Reference 10';

Modules.LblsAndTtls.billPrinterCd 				= 'Bill Printer Code';
Modules.LblsAndTtls.billPrinterPath 			= 'Bill Printer Path';
Modules.LblsAndTtls.billPrinterTray 			= 'Bill Printer Tray';
Modules.LblsAndTtls.billCopyCount 				= 'Bill Copy Count';
Modules.LblsAndTtls.duplicateInvcCopyCount 		= 'Duplicate Invoice Copy Count';
Modules.LblsAndTtls.duplicateInvcCopyCountShort = 'Dup Invc Copy Ct';
Modules.LblsAndTtls.invcPrinterTray 			= 'Invoice Printer Tray';
Modules.ocean.supplier_invoice.supplier_line_item_status.labels.supplierLineItemStatusPopWin		=  'Supplier Line Item Status Ocean'
Modules.common.labels.emailWinTitle 			=	'Email Invoice/Bill';


Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.poptooltip='Place Of Payment';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.popCrncytooltip='Place Of Payment Currency';

Modules.LblsAndTtls.popCountryFullNameTitle='Place Of Payment Country';
Modules.LblsAndTtls.popCodeFullNameTitle='Place Of Payment Code';
Modules.LblsAndTtls.popDescFullNameTitle='Place Of Payment Description';


Modules.LblsAndTtls.seqNoFullName='Sequence Number';

Modules.LblsAndTtls.internalUOMCodeFullName='Internal Unit Of Measure Code';
Modules.LblsAndTtls.externalUOMCodeFullName='External Unit Of Measure Code';
Modules.LblsAndTtls.uomFullName = "Unit of Measure";
Modules.LblsAndTtls.teleNumberFullName= "Telephone Number";
Modules.LblsAndTtls.faxNumberFullName= "Fax Number";
Modules.LblsAndTtls.popFullName='Place Of Payment';
Modules.LblsAndTtls.popCountryFullName=Modules.LblsAndTtls.popFullName+' Country';
Modules.LblsAndTtls.popCountryCodeFullName=Modules.LblsAndTtls.popFullName+' Country Code';
Modules.LblsAndTtls.polCountryCodeFullName='Port Of Load Country Code';
Modules.LblsAndTtls.podCountryCodeFullName='Port Of Discharge Country Code';
Modules.LblsAndTtls.blNumberFullName='Bill Of Lading Number';
Modules.LblsAndTtls.regNumberFullName='Registration Number';
Modules.LblsAndTtls.TaxExemNumberFullName='Tax Exemption Number';
Modules.LblsAndTtls.APContactInfoFullName='Accounts Payable Contact Information';
Modules.LblsAndTtls.ARContactInfoFullName='Accounts Receivable Contact Information';
Modules.admin.application_monitoring.change_log.labels.transIndFullName="Transaction Indicator";

Modules.Msgs.podCodeTooltip = 'Port Of Discharge Code';
Modules.Msgs.polCodeTooltip = 'Port Of Load Code';




/***********************************************************************/
//# Start of DPW LABELS
/***********************************************************************/




Modules.Master.ActivityCodeMaster.activityId='Activity Id';
Modules.Master.ActivityCodeMaster.activityTypeId='Activity Type Id ';


Modules.Master.ActivityTypeMaster.activityTypeId='Activity Type Id';
Modules.Master.ActivityTypeMaster.description='Description';


Modules.Master.EquipmentMaster.equipmentId='Equipment Id';
Modules.Master.EquipmentMaster.equipmentName='Equipment Name';
Modules.Master.EquipmentMaster.make='Make';
Modules.Master.EquipmentMaster.model='Model';
Modules.Master.EquipmentMaster.equipmentTypeId='Equipment Type Id';


Modules.Master.DelayReasonCodeMaster.delayReasonId='Delay Reason Code';
Modules.Master.DelayReasonCodeMaster.description='Description ';


Modules.Master.UserMaster.userId='User Id';
Modules.Master.UserMaster.userName='User Name';


Modules.Master.RoleMaster.userName='User Name';
Modules.Master.RoleMaster.roleName='Role Name';

Modules.Master.PinningStationMaster.pinningStationId='Pinning Station Id';
Modules.Master.PinningStationMaster.terminalId='Terminal Id';
Modules.Master.PinningStationMaster.availability='Availability';

Modules.Master.MoveTypeMaster.moveTypeId='MoveType Id';
Modules.Master.MoveTypeMaster.moveTypeName=' Name';

Modules.Master.DirectionMaster.Id='direction Id';
Modules.Master.DirectionMaster.Name=' Name';

Modules.Master.ChecklistMaster.checklistId='Checklist Id';
Modules.Master.ChecklistMaster.checklistName='Checklist Name';

Modules.Master.QC_LaneMaster.laneId='Lane Id';
Modules.Master.QC_LaneMaster.availability='Availability';
Modules.Master.QC_LaneMaster.driveDirection='Drive Direction';


Modules.Master.TerminalMaster.terminalId='Terminal Id';
Modules.Master.TerminalMaster.terminalName='Terminal Name';

Modules.Master.LanguageMaster.languageId='Language Id';
Modules.Master.LanguageMaster.languageName='Language Name';

Modules.Master.DeviceMaster.deviceId='Device Id';
Modules.Master.DeviceMaster.ipAddress='IP Address';
Modules.Master.DeviceMaster.equipmentId='Equipment Id';
Modules.Master.DeviceMaster.make='Make';
Modules.Master.DeviceMaster.model='Model';

Modules.Master.DamageCodeMaster.damageCode='Damage Code';
Modules.Master.DamageCodeMaster.damageSeverityCode='Damage Severity Code';

Modules.Master.DamageSeverityMaster.damageSeverityCode='Damage Severity Code';
Modules.Master.DamageSeverityMaster.description='Description';

Modules.Master.TroubleShootAreaMaster.troubleShootAreaId='TroubleShoot Area Id';
Modules.Master.TroubleShootAreaMaster.terminalId='Terminal Id';
Modules.Master.TroubleShootAreaMaster.availability='Availability';

Modules.Master.ApplicationParameterMaster.parameterCode='Parameter Code';
Modules.Master.ApplicationParameterMaster.parameterValue='Parameter Value';

Modules.Master.UnplannedActivitiesMaster.unplannedActivitiesId='Unplanned Activities Id';
Modules.Master.UnplannedActivitiesMaster.unplannedActivitiesName='Unplanned Activities Name';

Modules.Master.ShiftMaster.shiftId='Shift Id';
Modules.Master.ShiftMaster.shiftName='Shift Name';

Modules.Master.AlertCodeMaster.alertCode='Alert Code';
Modules.Master.AlertCodeMaster.description='Description';

Modules.Master.DirectionMaster.directionId='Direction Id';
Modules.Master.DirectionMaster.description='Description';

Modules.Master.LanguageMaster.languageId='Language Id';
Modules.Master.LanguageMaster.description='Description';

Modules.Master.MoveTypeMaster.moveTypeId='MoveType Id';
Modules.Master.MoveTypeMaster.description='Description';

Modules.Master.TerminalMaster.terminalId='Terminal Id';
Modules.Master.TerminalMaster.description='Description';
/*
Modules.Master.RoleMaster.roleId='Role Id';
Modules.Master.RoleMaster.roleName='Role Name';*/


Modules.Master.UserMaster.userId='User Id';
Modules.Master.UserMaster.userName='User Name';
Modules.Master.UserMaster.firstName='First Name';
Modules.Master.UserMaster.lastName='Last Name';
Modules.Master.UserMaster.userDescription='User Description';
Modules.Master.UserMaster.accountStatus='Account Status';
Modules.Master.UserMaster.telephoneNo='Telephone No.';
Modules.Master.UserMaster.mobileNo='Mobile No.';
Modules.Master.UserMaster.faxNo='Fax No.';
Modules.Master.UserMaster.emailId='Email Id';
Modules.Master.UserMaster.defaultLanguage='Deafult Language';
Modules.Master.UserMaster.password='Password';
Modules.Master.UserMaster.roles='Roles';

Modules.Master.UserMaster.role='Role';

Modules.Master.UnitMaster.unitId="Unit ID";
Modules.Master.UnitMaster.unitName="Unit Name";


Modules.Master.GenericChecklistMaster.checkListId="CheckList ID";
Modules.Master.GenericChecklistMaster.checkListName="CheckList Name";

Modules.Master.GenericChecklistMaster.description="Description";
Modules.Master.GenericChecklistMaster.mandatory="Mandatory";
Modules.Master.GenericChecklistMaster.icon="Icon";
Modules.Master.GenericChecklistMaster.category="Category";
Modules.Master.GenericChecklistMaster.checkListHeader="CheckList Header";

Modules.Master.CheckListHeaderMaster.ChecklistHeaderId="CheckList Header ID";
Modules.Master.CheckListHeaderMaster.ChecklistHeaderName="CheckList Header Name";
Modules.Master.CheckListHeaderMaster.ChecklistHeaderType="CheckList Header Type";



Modules.Master.VesselMaster.vesselCode='Vessel Code';
Modules.Master.VesselMaster.vesselName='Vessel Name';
Modules.Master.VesselMaster.vesselType='Vessel Type';


Modules.Master.VesselMaster.vesselPopupTitle='Welcome to Vessel Profile Module';

Modules.Master.VesselMaster.vesselPopupHeader='Please Enter the following details (These details can not be modified later.)';


Modules.Master.RotationControlMaster.rotationNumber='Rotation Number';
Modules.Master.RotationControlMaster.equipmentId='Equipment (QC) Id';
Modules.Master.RotationControlMaster.vesselCode='Vessel Code';
Modules.Master.RotationControlMaster.etaDateFrom='ETA (From)';
Modules.Master.RotationControlMaster.etaDateTo='ETA (To)';
Modules.Master.RotationControlMaster.active='Status';


Modules.Master.YardBlockMaster.blockIdentifier='Block Identifier';
Modules.Master.YardBlockMaster.blockType= 'Block Type';
Modules.Master.YardBlockMaster.slotLength='Slot Length';
Modules.Master.YardBlockMaster.slotWidth='Slot Width';
Modules.Master.YardBlockMaster.noOfRows='Number of Rows';
Modules.Master.YardBlockMaster.interRowDistance='Inter Row Distance';
Modules.Master.YardBlockMaster.noOfSlots='Number of Slots';
Modules.Master.YardBlockMaster.interSlotDistance='Inter Slot Distance';
Modules.Master.YardBlockMaster.rowOrientation='Row Orientation';
Modules.Master.YardBlockMaster.rowSeries='Row Series';
Modules.Master.YardBlockMaster.slotSeries='Slot Series';
Modules.Master.YardBlockMaster.levelSeries='Level Series';
Modules.Master.YardBlockMaster.maxHeight='Maximum Stacking Height';
Modules.Master.YardBlockMaster.workingHeight='Working Stacking Height';
Modules.Master.YardBlockMaster.absoluteStackingHeight='Absolute Stacking Height';
Modules.Master.YardBlockMaster.laneLocation='Truck Lane Location';
Modules.Master.YardBlockMaster.laneIdentifierUpper='Truck Lane Identifier Upper';
Modules.Master.YardBlockMaster.laneIdentifierLower='Truck Lane Identifier Lower';


Modules.Master.DamageLocationMaster.damageLocationId='Damage Location Id';
Modules.Master.DamageLocationMaster.damageLocationDesc='Description';

Modules.Master.DamageTypeMaster.damageTypeId='Damage Type Id';
Modules.Master.DamageTypeMaster.damageTypeDesc='Description';

Modules.Master.VesselExceptionMaster.vesselExceptionId = 'Exception ID';
Modules.Master.VesselExceptionMaster.vesselName= 'Vessel' ;
Modules.Master.VesselExceptionMaster.rotation = 'Rotation';
Modules.Master.VesselExceptionMaster.exceptionType = 'Exception Type';

Modules.Master.DelayRecordingMaster.rotationNumber='Rotation Number';
Modules.Master.DelayRecordingMaster.equipmentId='Equipment Id';
Modules.Master.DelayRecordingMaster.delayReasonCode='Delay Code';
Modules.Master.DelayRecordingMaster.fromDate='ETA (From)';
Modules.Master.DelayRecordingMaster.toDate='ETA (To)';
Modules.Master.DelayRecordingMaster.status='Status';
Modules.Master.DelayRecordingMaster.mode='Mode';
Modules.Master.DelayRecordingMaster.terminalId='Terminal';

Modules.Master.TrailerMaster.trailerNo='Trailer Number';


Modules.Master.AlertConfigurationMaster.alertCode='Alert Code';
Modules.Master.AlertConfigurationMaster.alertText='Alert Text';
Modules.Master.AlertConfigurationMaster.description='Description';
Modules.Master.AlertConfigurationMaster.severity='Severity';
Modules.Master.AlertConfigurationMaster.soundRequired='Sound Required';
Modules.Master.AlertConfigurationMaster.subscribers='Subscribers';
Modules.Master.AlertConfigurationMaster.keyList='Available Keys';


Modules.Master.AlertRecordMaster.alertCode='Alert Code';
Modules.Master.AlertRecordMaster.alertText='Alert Text';
Modules.Master.AlertRecordMaster.raisedBy='Raised By';
Modules.Master.AlertRecordMaster.raisedDateFrom='Raised Date(From)';
Modules.Master.AlertRecordMaster.raisedDateTo='Raised Date(To)';
Modules.Master.AlertRecordMaster.status='Status';
Modules.Master.AlertRecordMaster.remarks='Remarks';


Modules.Master.WeightageFactorMaster.type='Type';
Modules.Master.WeightageFactorMaster.criteria='Criteria';
Modules.Master.WeightageFactorMaster.score='Score';
Modules.Master.WeightageFactorMaster.factor='Factor';


/*
Modules.Master.UserMaster.roleId='Role Id';
Modules.Master.UserMaster.userId='User Id';
Modules.Master.UserMaster.roleId='Role Id';
Modules.Master.UserMaster.userId='User Id';
Modules.Master.UserMaster.roleId='Role Id';
Modules.Master.UserMaster.userId='User Id';
Modules.Master.UserMaster.roleId='Role Id';
*/











/***********************************************************************/
//#  End of DPW LABELS
/***********************************************************************/

