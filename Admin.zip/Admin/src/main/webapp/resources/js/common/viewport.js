

Ext
		.onReady(function() {
			Ext.tip.QuickTipManager.init();
			var serviceComboObj = Ext.create('Ext.data.Store', {
			    fields: ['serviceCode', 'serviceName'],
			    data : [
			        {"serviceCode":"nonOceanCode", "serviceName":"NON OCEAN"},
			        {"serviceCode":"oceanCode", "serviceName":"OCEAN"}
			    ]
			});
			var companyStore		=		{
					model: 'Company',
					url:'getCompanyList',
					paging:true
				};
		
			var bottomToolbar = Ext.create('Ext.toolbar.Toolbar', {
				id : 'mainPan',
				height : 25,
				layout : 'fit',
				width : 1500,
				layout : {
					overflowHandler : 'Menu'
				}
			});
			new Ext.Viewport(
					{
						layout : "fit",
						items : [ {
							xtype : 'panel',
							layout : 'fit',
							 tbar: Ext.create('Ext.toolbar.Toolbar', {
						            layout: {
						                overflowHandler: 'Menu'
						            },
						            items: [{
										text : "Demo",
										iconCls : "main-folder",
										menu : [ {
											"text" : "Ocean Invoice",
											handler : function() {
												var panelObj = {
													panelFunc : Modules.OceanInvoice.tabparentpanel,
													panelId : 'OceanInvoiceParentTabPanelId',
													parentTabPanelId : Modules.CompIds.viewportParentTabPanelId
												};
												Modules.GlobalFuncs
														.addPanelToTabPanel(panelObj);
											}
										} ]
									},
									{
										text : "Contract",
										iconCls : "main-folder",
										menu : [ {
											"text" : "Supplier",
											"id" : "supllierId",
											menu : [ {
												text : "Supplier Master",
												handler : function() {

												}
											}, {
												text : "Supplier Rates",
												handler : function() {

												}
											} ]
										}, {
											"text" : "Customer",
											"id" : "customerId",
											menu : [ {
												text : "Customer Master",
												handler : function() {
                                                 Module.ScreenName.createCustomerMaster();
												}
											}, {
												text : "Customer Rates",
												handler : function() {
												}
											} ]
										} ]
									},
									{
										text : "Operations",
										iconCls : "main-folder",
										menu : [ {
											"text" : "Event Details",
											"iconCls" : "sub-main-folder",
											menu : [
													{
														text : "Event Rating Query",
														iconCls : "sub-main-folder",
														handler : function() {
															showEvenQueryRatingScreen();
														}
													},
													{
														text : "Event Status Query",
														iconCls : "sub-main-folder",
														handler : function() {

														}
												} ]
											} ]
									},
									{
										text : "Supplier invoice",
										iconCls : "main-folder"
									},
									{
										text : "Customer invoice",
										iconCls : "main-folder"
									},
									{
										text : "EDI",
										iconCls : "main-folder",
										menu:[{
											"text" : "Status Monitoring And Control",
											handler : function(){
												Ext.getCmp('hiddenStatus').setValue("add");
												var panelObj = {
														panelFunc:Modules.StatusMonitoringAndControlNonOcean.tabParentPanel,
														panelId:'statusMonitoringAndControlParentTabPanelId',
														parentTabPanelId:Modules.CompIds.viewportParentTabPanelId
													};
													Modules.GlobalFuncs.addPanelToTabPanel(panelObj);
											}
										},
										      {
												"text" : "Purge Details",
												handler : function(){
													var panelObj = {
															panelFunc:Modules.edi.purge_details.tabparentpanel,
															panelId:'purgeDetailsParentTabPanelId',
															parentTabPanelId:Modules.CompIds.viewportParentTabPanelId
														};
														Modules.GlobalFuncs.addPanelToTabPanel(panelObj);
												}
											},
											{
												text:"SWIM UI",
												menu:[{
													text:"Partner Details",
													handler:function()
													{
													var win = {
																panelFunc:Modules.edi.SwimUI.swimWin,
																panelId:'swimWinId',
																parentTabPanelId:Modules.CompIds.viewportParentTabPanelId 
													};
														Modules.GlobalFuncs.addPanelToTabPanel(win);  
																			
													}
												},
												{
													text:"Group Partner Mapping Configuration",
													handler:function()
													{
														var win = {
																panelFunc:Modules.edi.SwimUI.grpPartnerMappingWin,
																panelId:'grpPartnerMappingId',
																parentTabPanelId:Modules.CompIds.viewportParentTabPanelId															
														};
														Modules.GlobalFuncs.addPanelToTabPanel(win); 													
													}
												},
												{
													text:"Agreement Configuration",
													menu:[{
														text:"Send Message",
														handler:function()
														{
															var win = {
																	panelFunc:Modules.edi.SwimUI.sendMessageWin,
																	panelId:'sendMsgWinId',
																	parentTabPanelId:Modules.CompIds.viewportParentTabPanelId
															};
															Modules.GlobalFuncs.addPanelToTabPanel(win);  															
														}
													}]												
												},
												{
													text:" Background Jobs ",
													handler:function()
													{
														var win = {
																panelFunc:Modules.edi.SwimUI.backgroundJobswin,
																panelId:'backEndWinId',
																parentTabPanelId:Modules.CompIds.viewportParentTabPanelId															
														};
														Modules.GlobalFuncs.addPanelToTabPanel(win); 
													}
												},
												{
													text:"Logs",
													handler:function()
													{
														var win = {
																panelFunc:Modules.edi.SwimUI.logScreenWin,
																panelId:'logWinId',
																parentTabPanelId:Modules.CompIds.viewportParentTabPanelId
														};
														Modules.GlobalFuncs.addPanelToTabPanel(win);  													
													}
												},
												{
													text:"AutoReprocess Error Message",
													handler:function()
													{														
														var win=
																Modules.edi.SwimUI.autoReprocessErrorMsg();
															/*	panelFunc:Modules.edi.SwimUI.ErMsgWin,
																panelId:'autoReprocessErMsgWinId',
																parentTabPanelId:Modules.CompIds.viewportParentTabPanelId */														
														Modules.GlobalFuncs.addPanelToTabPanel(win);
														
													//	var win = Modules.edi.SwimUI.winObj;
													}
												}
												]											
											},
											{
											"text" : "Event Log",
											handler : function() {
												var panelObj = {
													panelFunc : Modules.edi.tabparentpanel,
													panelId : 'EventLogTabPanelId',
													parentTabPanelId : Modules.CompIds.viewportParentTabPanelId
												};
												Modules.GlobalFuncs
														.addPanelToTabPanel(panelObj);
											}
										}]
									}, 
									{
										"text" : "Admin",
										"id" : "AdminId",
										iconCls : "main-folder",
										menu : [
												{
													text : "User Admin",
													menu : [
															{
																"text" : "Group/User Security"
															},
															{
																text : "Function Management",
																handler : function() {
																	var win = Modules.test
																			.win();
																	// win.show();
																	// taskbarWindow(Ext.getCmp(Modules.CompIds.myWindowId).id,
																	// Ext.getCmp(Modules.CompIds.myWindowId).text)
																}
															}
														]
												},
												{
													text : "Application Monitoring",
													menu : [ {
														"text" : "Change Log"
													}, {
														"text" : "Journaling"
													}, {
														text : "Audit Log",
														handler : function() {

														}
													} ]
												},
												{
													text : "Internal Admin",
													menu : [
															{
																"text" : "Error Message Management"
															},
															{
																text : "Database Error Log",
																handler : function() {

																}
															} ]
												} ]
									}, 
									{
										text : "Master",
										iconCls : "main-folder",
										menu : [ {
											"text" : "Invoice Master Management",
											handler : function() {
											}
										},{
											"text" : "General Masters",
											handler : function() {
											}	
										},{
											"text" : "EDI Masters",
											handler : function() {
											}	
										},{
											"text" : "Ocean Masters",
											handler : function() {
											}	
										}]
									},
									{
										text : "Options",
										iconCls : "main-folder"
									}, {
										text : "Reports",
										iconCls : "main-folder"
									}, {
										text : "Help",
										iconCls : "main-folder"
									}, '->', {
										xtype :'combobox',
										id: 'serviceTypeComboId',
								        hideLabel: true,
								        store: serviceComboObj,
								        displayField: 'serviceName',
								        typeAhead: true,
								        queryMode: 'local',
								        triggerAction: 'all',
								        emptyText:'Service Type',
								        width:100
								    }, {
										xtype: 'cmccombobox',
										hideLabel: true,
										emptyText: 'Select Company',
										displayField: 'companyCode',
										storeObjCmc: companyStore,
										valueField: 'companyCode',
										id: 'serviceCompanyId',
										matchFieldWidth: false,
										paging:true,
										listConfig: {
											width: 400,
											loadingText: 'Loading...',
											height: 300,
											deferEmptyText: false,
											emptyText: 'No Values Found!',
											getInnerTpl: function () {
												return '<table><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="125px" align="left">{companyCode}</td><td width="125px" align="left">{companyName}</td> </tr></table>';
											}
										}
									},{
										xtype : 'label',
										forId : 'myFieldId',
										text : 'Welcome User : CMC',
										margins : '0 50 0 0'
									},{
										xtype : "button",
										text : "Logout",
										iconCls : "logout"
									}
									]
							}),
							items : [{
								xtype : 'tabpanel',
								id : Modules.CompIds.viewportParentTabPanelId,
								activeTab : 0,
								tabPosition : 'bottom',
								items : [{
									title: 'Dashboard',
							        xtype: 'cmctabparentpanel',
							        id:'NonOceanDashboardParentTabPanelId',
							       /* showNorthItemCmc:true,
							        setNorthItemFuncCmc:Modules.Dashboard.form,*/
									setCenterItemFuncCmc:Modules.Dashboard.tabpanel
							    }]
							}  ]
						} ]
					});

			Ext.getCmp('serviceTypeComboId').setValue('NON OCEAN');
		});
