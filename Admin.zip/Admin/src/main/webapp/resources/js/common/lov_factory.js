Modules.LovFactory = {
		
	//  DPW specific combobox code for static values
		
		getUserStatus : function () {
		//The data store containing the list of status
			var statusStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    data : [
			        {"abbr":"A", "name":"Active"},
			        {"abbr":"D", "name":"Disabled"}
			        //...
			    ]
			});
		
		return	Ext.create('Ext.form.ComboBox', {
		    fieldLabel: 'Choose Status',
		    name : 'Status',
		    store: statusStore,
		    queryMode: 'local',
		    displayField: 'name',
		    valueField: 'abbr'
		});
		
		
		},
		
		getBerthSideStore : function () {
			
			var berthStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			        {"abbr":"P", "name":"P"},
			        {"abbr":"S", "name":"S"}
			        //...
			    ]
			});
			
			return berthStore ;
			
			},
		
		getAvailabilityStore : function () {
		
		var AvailabilityStore = Ext.create('Ext.data.Store', {
		    fields: ['abbr', 'name'],
		    url:'',
		    data : [
		        {"abbr":"Y", "name":"Yes"},
		        {"abbr":"N", "name":"No"}
		        //...
		    ]
		});
		
		return AvailabilityStore ;
		
		},
		
		getSeverityStore : function () {
			
			var AvailabilityStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			         {"abbr":"C", "name":"Critical"},
			         {"abbr":"N", "name":"Normal"}
			        //...
			    ]
			});
			
			return AvailabilityStore ;
			
			},
		getAutomaticStore : function () {
			
			var automaticStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			        {"abbr":"M", "name":"Manual"},
			        {"abbr":"A", "name":"Automatic"}
			        //...
			    ]
			});
			
			return automaticStore ;
			
			},
			getAlerStatusStore : function () {
				
				var alerStatusStore = Ext.create('Ext.data.Store', {
				    fields: ['abbr', 'name'],
				    url:'',
				    data : [
				        {"abbr":"C", "name":"Closed"},
				        {"abbr":"O", "name":"Open"}
				        //...
				    ]
				});
				
				return alerStatusStore ;
				
				},
		
		
		getExceptionTypeStore : function () {
			
			var ExceptionTypeStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			        {"abbr":"BAY_MISSING", "name":"BAY_MISSING"},
			        {"abbr":"CELL_MISSING", "name":"CELL_MISSING"},
			        {"abbr":"UNDEFINED_EQUIPMENT", "name":"UNDEFINED_EQUIPMENT"},
			        {"abbr":"UNDEFINED_VESSEL_CODE", "name":"UNDEFINED_VESSEL_CODE"}
			        
			        //...
			    ]
			});
			
			return ExceptionTypeStore ;
			
			},
			
			/*getBusinessExceptionTypeStore : function () {
				
				var BusinessExceptionTypeStore = Ext.create('Ext.data.Store', {
				    fields: ['abbr', 'name'],
				    url:'',
				    data : [
				        {"abbr":"BAY_MISSING", "name":"CONTAINER DETAIL MISSING"},
				        {"abbr":"CELL_MISSING", "name":"CELL_MISSING"}
				        //...
				    ]
				});
				
				return BusinessExceptionTypeStore ;
				
				},*/
			
			
		
		getTypeStore : function () {
			
			var typeStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			        {"abbr":"TD", "name":"Tier Deck"},
			        {"abbr":"TU", "name":"Tier UnderDeck"}
			        //{"abbr":"RD", "name":"Row Deck"},
			     //   {"abbr":"RU", "name":"Row UnderDeck"}
			        //...td, tu, ru,rd
			    ]
			});
			
			return typeStore ;
			
			},
		
		getRotationStatusStore : function () {
			
			var RotationStatusStore = Ext.create('Ext.data.Store', {
			    fields: ['abbr', 'name'],
			    url:'',
			    data : [
			        {"abbr":"R", "name":"Registered"},    
			        {"abbr":"B", "name":"Berthed"},
			        {"abbr":"S", "name":"Sailed"}
			    ]
			});
			
			return RotationStatusStore ;
			
			},
			getCheckListHeaderTypeStore : function () {
				
				var checkListHeaderTypeStore = Ext.create('Ext.data.Store', {
				    fields: ['abbr', 'name'],
				    url:'',
				    data : [
				        {"abbr":"PRE OPERATIONAL", "name":"PRE OPERATIONAL"},    
				        {"abbr":"POST OPERATIONAL", "name":"POST OPERATIONAL"}
				    ]
				});
				
				return checkListHeaderTypeStore ;
				},
      
    //  DPW specific combobox code for dynamic values
				
    getComboBoxLov: function (config) {
        config = config || {};
        var currentModel = config.model ;
        var header=config.header;
        var currentDataIndex=config.dataIndex;
        var currentValueDataIndex=config.valueDataIndex;
        var currentAllowBlank = config.isNotRequired;
        var currentUrl = config.url ;
        var defaultUrl = 'common/getForeignKeys' ;
        var areMultipleColumns = config.areMultipleColumns ; 
        var columnsList ;
       // var selectedValue = config.value ;
        
        if(areMultipleColumns){
        	columnsList = config.columnsList ;
        }
        
        else {
        	columnsList = [{
		            header:header,                
		        	dataIndex:currentDataIndex,           
		        	width:200
                    }
        	];
        }
        
        var genericStore = Ext.apply({
            model: currentModel ,
            url:currentUrl || defaultUrl,            
            paging: config.paging || true,
            storeId : config.storeId
        },
        config.storeConfig || {});

        delete config.storeConfig;

        var combo =  Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: genericStore,
            //triggerAction: 'all',
            //typeAhead: true,
            paging: true,
            //selectOnTab: true,
            displayField: currentDataIndex,
            valueField: currentValueDataIndex || currentDataIndex,
            matchFieldWidth: true,
            hideTrigger : false,
            forceSelection:true,
            allowBlank : currentAllowBlank,
            columnsCmc:columnsList,
            listeners:{
            /*	beforequery:function(eventObj){
            		var query = eventObj.query ;
            		var store = eventObj.combo.getStore(); 
            		//replace this with store
            		store.proxy.extraParams.entityName = config.entity;
            		store.proxy.extraParams.columnName = config.property;
                    if(currentUrl){
                    	store.proxy.extraParams.checkEquality = config.checkEquality; 
                    	store.proxy.extraParams.orElseAnd = config.conditionToSearch;  
                    	store.proxy.extraParams.columnValuePairs = config.getColumnNameValuePairs(query,query);
                        
                    }else{
                    	store.proxy.extraParams.filterColumnName = config.filterColumnName;
                    	store.proxy.extraParams.filterColumnVal = config.filterColumnVal;
                    }
                    
                 
                    if(config.paging==false){
                    	store.proxy.extraParams.limit = 100000;
                    }
            	},*/
            	/*change: function(field, newValue, oldValue, eOpts ) {
					console.log("inside change event:");
					console.log("oldValue: " + oldValue);
					console.log("newValue:" + newValue);
					 var checkListHeaderGrid = Ext.getCmp('checkListHeaderMasterGridId');
                   if(checkListHeaderGrid) {
                   	
                   	if(field.dataIndex=="userGroupName"){
		    			  var selectedRows = Ext.getCmp('checkListHeaderMasterGridId').getSelectionModel().getSelection();
						   if(selectedRows[0].data.roleName==""){
						   		selectedRows[0].data.roleId = "" ;
							}
                   	}
                   }
				},
				blur: function(comp, event, eOpts ) {
					console.log("inside blur event:");
					console.log("comp.valueModels ; : " + comp.valueModels);
					console.log("comp.value : " + comp.value);
					console.log("comp.modified : " + comp.modified);
					 var checkListHeaderGrid = Ext.getCmp('checkListHeaderMasterGridId');
                   if(checkListHeaderGrid) {
                   	
                   	if(comp.dataIndex=="userGroupName"){
		    			  var selectedRows = Ext.getCmp('checkListHeaderMasterGridId').getSelectionModel().getSelection();
						   if(selectedRows[0].data.roleName==""){
						   		selectedRows[0].data.roleId = "" ;
							}
                   	}
                   }
				},
            	*/
            	
                select: function(f,r,i) {
                	/*console.log(arguments);
                    console.log( f);
            		console.log( r);
            		console.log( i);
            		console.log(r[0].data.unitId);*/
                }
           }
        }, config));
      
        return  combo ;
    },
    
    getFormComboBoxLov: function (config) {
        config = config || {};
        var currentModel = config.model ;
        var header=config.header;
        var currentDataIndex=config.dataIndex;
        var currentValueDataIndex=config.valueDataIndex;
        var currentAllowBlank = config.isNotRequired;
        var currentName = config.name ;
        var currentWidth = config.width ;
        var currentLabelWidth = config.labelWidth ;
        var currentFieldLabel = config.fieldLabel ;
        var currentUrl = config.url ;
        var defaultUrl = 'common/getForeignKeys' ;
        
        var genericStore = Ext.apply({
            model: currentModel ,
            url:currentUrl || defaultUrl,     
           // url:'common/getForeignKeys',            
            paging: true,
            storeId : config.storeId,
            listeners: {
                beforeload: function () {
                	this.proxy.extraParams.entityName = config.entity;
                    this.proxy.extraParams.columnName = config.property;
                    this.proxy.extraParams.filterColumnName = config.filterColumnName;
                    this.proxy.extraParams.filterColumnVal = config.filterColumnVal;
				}
            }

        },
        config.storeConfig || {});
        
        delete config.storeConfig;

        var genericFormCombo =  Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: genericStore,
            //triggerAction: 'all',
            //typeAhead: true,
            fieldLabel: currentFieldLabel,
            width: currentWidth,
		    labelWidth: currentLabelWidth,
            name: currentName ,
            paging: true,
            //selectOnTab: true,
            displayField: currentDataIndex,
            valueField: currentValueDataIndex || currentDataIndex,
           // matchFieldWidth: true,
            hideTrigger : false,
           // forceSelection:true,
            allowBlank : currentAllowBlank,
            validator : false,
            columnsCmc:[
			            {
			            header:header,                
			        	dataIndex:currentDataIndex,           
			        	width:200
	                    }
	                   ],
            listConfig: {
                loadingText: Modules.Msgs.loading,
                emptyText: Modules.Msgs.noComboValueFound
            }
        }, config)); 
        
        return genericFormCombo ;
    },
    
    // generic Form Combo Box with multi Column Search
    
    getMultiColumnSearchFormComboBoxLov: function (config) {
        config = config || {};
        var currentModel = config.model ;
        var header=config.header;
        var currentDataIndex=config.dataIndex;
        var currentValueDataIndex=config.valueDataIndex;
        var currentAllowBlank = config.isNotRequired;
        var currentName = config.name ;
        var currentWidth = config.width ;
        var currentLabelWidth = config.labelWidth ;
        var currentFieldLabel = config.fieldLabel ;
        var currentUrl = config.url ;
        var defaultUrl = 'common/getForeignKeys' ;
        
        var genericStore = Ext.apply({
            model: currentModel ,
            url:currentUrl || defaultUrl,            
            paging: config.paging || true,
            storeId : config.storeId,
        },
        config.storeConfig || {});
        
        delete config.storeConfig;

        var genericFormCombo =  Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: genericStore,
            //triggerAction: 'all',
            //typeAhead: true,
            fieldLabel: currentFieldLabel,
            width: currentWidth,
		    labelWidth: currentLabelWidth,
            name: currentName ,
            paging: true,
            //selectOnTab: true,
            displayField: currentDataIndex,
            valueField: currentValueDataIndex || currentDataIndex,
           // matchFieldWidth: true,
            hideTrigger : false,
           // forceSelection:true,
            allowBlank : currentAllowBlank,
            validator : false,
            columnsCmc:[
			            {
			            header:header,                
			        	dataIndex:currentDataIndex,           
			        	width:200
	                    }
	                   ],
            listConfig: {
                loadingText: Modules.Msgs.loading,
                emptyText: Modules.Msgs.noComboValueFound
            }
        }, config)); 
        
        return genericFormCombo ;
    },
    
    setFormBeforeQueryDetails: function(config,eventObj,searchColumnValuePairs,isMultiColumnSearch,filterColumnValuePairs,filterResults){
    	var query = eventObj.query ;
    	var store = eventObj.combo.getStore(); 
    	store.proxy.extraParams.entityName = config.entity;
    	store.proxy.extraParams.columnName = config.property;
    	if(isMultiColumnSearch){
    		store.proxy.extraParams.checkEquality = config.checkEquality; 
    		store.proxy.extraParams.orElseAnd = config.conditionToSearch;  
    		store.proxy.extraParams.columnValuePairs = searchColumnValuePairs;
    	    
    	}
    	if(filterResults){
    		store.proxy.extraParams.filterColumnValuePairs = filterColumnValuePairs ;
    	}
    	if(config.paging==false){
    		store.proxy.extraParams.limit = 100000;
    	}
    }
    
    
    
};

