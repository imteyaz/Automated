/***********************************************************************************************
	**Beginning of overriding of Grid Row Editing PlugIn
	**It has been overridden to tackle a bug related to clicksToMoveEditor
	**The aim of this override is to not allow editing of any other row when one row is already getting edited
**/
Ext.override(Ext.grid.plugin.RowEditing, {
	startEdit: function(record, columnHeader) {
		var me = this,
			editor = me.getEditor();
		/**Beginning override by Vivek**/
		//Following lines have been added to disallow moving of editor from one row to another
		if(me.editing){
			return false;
		}
		/**Ending override by Vivek**/
		if ((me.callParent(arguments) !== false) && (editor.beforeEdit() !== false)) {
			editor.startEdit(me.context.record, me.context.column);
			return true;
		}
		return false;
	}
});
/**
 * 
 */
Ext.override(Ext.form.field.Base,{
	formFieldCmc:true,
	labelSeparator:' ',
	labelAlign:'left'
});

/**Ending override of Grid Row Editing******************************************************************/
/***********************************************************************************************
	**Beginning of overriding of Grid Row Editor
	**It has been overridden to change the text of Save button and for not allowing it to be disabled on basis of form's validaity
	**Another override is disallowing checking of form's validity on change of field's value
**/
Ext.override(Ext.grid.RowEditor, {
	getFloatingButtons: function() {
		var me = this,
			cssPrefix = Ext.baseCSSPrefix,
			btnsCss = cssPrefix + 'grid-row-editor-buttons',
			plugin = me.editingPlugin,
			btns;

		if (!me.floatingButtons) {
			btns = me.floatingButtons = new Ext.Container({
				renderTpl: [
					'<div class="{baseCls}-ml"></div>',
					'<div class="{baseCls}-mr"></div>',
					'<div class="{baseCls}-bl"></div>',
					'<div class="{baseCls}-br"></div>',
					'<div class="{baseCls}-bc"></div>',
					'{%this.renderContainer(out,values)%}'
				],
				width: 200,
				renderTo: me.el,
				baseCls: btnsCss,
				layout: {
					type: 'hbox',
					align: 'middle'
				},
				defaults: {
					flex: 1,
					margins: '0 1 0 1'
				},
				items: [{
					itemId: 'update',
					xtype: 'button',
					handler: plugin.completeEdit,
					scope: plugin,
					/**Beginning override by Vivek**/
					/*
						**Overrides carried out are as following:
							**Changed the button text to OK
							**Commented the dependency of disabled on form valid
					*/
					//text: me.saveBtnText,
					text: 'OK',
					//disabled: !me.isValid,
					/**Ending override by Vivek**/
					minWidth: Ext.panel.Panel.prototype.minButtonWidth
				}, {
					xtype: 'button',
					handler: plugin.cancelEdit,
					scope: plugin,
					text: me.cancelBtnText,
					minWidth: Ext.panel.Panel.prototype.minButtonWidth
				}]
			});

			// Prevent from bubbling click events to the grid view
			me.mon(btns.el, {
				// BrowserBug: Opera 11.01
				//   causes the view to scroll when a button is focused from mousedown
				mousedown: Ext.emptyFn,
				click: Ext.emptyFn,
				stopEvent: true
			});
		}
		return me.floatingButtons;
	},
	setField: function(column) {
		var me = this,
			i,
			length, field;

		if (Ext.isArray(column)) {
			length = column.length;

			for (i = 0; i < length; i++) {
				me.setField(column[i]);
			}

			return;
		}

		// Get a default display field if necessary
		field = column.getEditor(null, {
			xtype: 'displayfield',
			// Override Field's implementation so that the default display fields will not return values. This is done because
			// the display field will pick up column renderers from the grid.
			getModelData: function() {
				return null;
			}
		});
		field.margins = '0 0 0 2';
		
		/**Beginning override by Vivek**/								
			/**
				**Override is as following:
					**Commented the below line in order to remove the check of validity of editor form on change of the field
			**/
		//me.mon(field, 'change', me.onFieldChange, me);
		/**Ending override by Vivek**/
		
		if (me.isVisible() && me.context) {
			if (field.is('displayfield')) {
				me.renderColumnData(field, me.context.record, column);
			} else {
				field.suspendEvents();
				field.setValue(me.context.record.get(column.dataIndex));
				field.resumeEvents();
			}
		}

		// Maintain mapping of fields-to-columns
		// This will fire events that maintain our container items
		
		me.columns.add(field.id, column);
		if (column.hidden) {
			me.onColumnHide(column);
		} else if (column.rendered) {
			// Setting after initial render
			me.onColumnShow(column);
		}
	}
});
/**Ending override of Grid Row Editor******************************************************************/


Ext.override(Ext.view.AbstractView, {
onRender: function() {
	var me = this;
	me.callOverridden(arguments);
	if (me.loadMask && Ext.isObject(me.store)) {
		me.setMaskBind(me.store);
	}
}
});
/****Ending of overriding onRender of AbstractView***********************************************************************/

/**
 * 
 */
Ext.override(Ext, {
	nsCmc: function(namespace) {
		if(!Ext.isEmpty(namespace)){
			Ext.ns(namespace);
			var ns = eval(namespace) ;
			Ext.applyIf(ns,{
				labels:{},
				messages:{}
			});
		}
		return ns;
	}
});




/******************* Override to set the invalid mark *******************/


/**** Added by Bhavesh to force Numberfield to show Precision
 * 
 *
 *To be used as
 * {
  xtype: 'numberfield',
  name:  'decimalsfield',
  forcePrecision: true,     #defaults to false
  decimalPrecision: 3       #defaults to 2
}
 */
Ext.override(Ext.form.NumberField, {
    forcePrecision : false,

    valueToRaw: function(value) {
        var me = this,
            decimalSeparator = me.decimalSeparator;
        value = me.parseValue(value);
        value = me.fixPrecision(value);
        value = Ext.isNumber(value) ? value : parseFloat(String(value).replace(decimalSeparator, '.'));
        if (isNaN(value))
        {
          value = '';
        } else {
          value = me.forcePrecision ? value.toFixed(me.decimalPrecision) : parseFloat(value);
          value = String(value).replace(".", decimalSeparator);
        }
        return value;
    }
});

Ext.override(Ext.form.TextArea,{
	//fieldStyle:'text-transform:uppercase',
	getValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
		if(Ext.isIE){
			val = (val && me.inputType!='password' && !me.lowerCaseCmc)?val.toUpperCase():val;
		}
		else{
			val = (val && me.inputType!='password' && !me.lowerCaseCmc)?val.toUpperCase():val;			
		}
		if(val){
			val = val.trim();
		}		
		return val;
	}
	
});						

Ext.override(Ext.data.reader.Reader,{
    read: function(response) {
        var data;

        if (response) {
        	if(response.responseText){
        		var respObj = Ext.decode(response.responseText);
        		if(respObj.success == false){
        			if(respObj.error== "RECORD_COUNT_EXCEED"){
        			Ext.Msg.show({
        				msg: Modules.Msgs.NarrowDownSearch,
        				title:Modules.Msgs.RowLimitExceeded,
        				buttons: Ext.MessageBox.OK,
        				icon: Ext.MessageBox.ERROR
        				}); 
        			}
        			else{
        				Ext.Msg.show({
            				msg: respObj.message,
            				buttons: Ext.MessageBox.OK,
            				icon: Ext.MessageBox.ERROR
            				}); 
        			}
        		}
        	}
            data = response.responseText ? this.getResponseData(response) : this.readRecords(response);
        }

        return data || this.nullResultSet;
    }
});

// Because of AJAX based validation on CmcComboBox reset  method of form  is failed to reset the cmccombobox
Ext.override(Ext.form.Basic,{
	reset : function(resetRecord){
		
		
		var formFields = this.getFields();
		formFields.each(function(field){
			if(field instanceof Ext.form.ComboBox){
				if(field.store && field.store.loading){
					//field.reset();
					field.setRawValue(undefined);
					field.store.on('load', function() {
						this.reset();
					},field,{single : true});
				}else{
					field.reset();
				}
			}
			else{
				field.reset();
			}
		});
	}
});

// Assign id so that this plugin can be accessible using getPlugin() method
Ext.override(Ext.grid.plugin.CellEditing,{
	pluginId : 'editorPlugin'
});

Ext.override(Ext.form.field.Number,{
	hideTrigger:false
});

Ext.override(Ext.form.TimeField,{
	hideTrigger:false
});

Ext.override(Ext.form.ComboBox,{
	hideTrigger:false,
	fieldCls:'lookUpClass',
	focusCls:'focusClass'
});

Ext.override(Ext.grid.column.Column, {
	    getColumnState: function () {
	        var me = this,
	            items = me.items.items,
	            iLen = items ? items.length : 0,
	            i, columns = [],
	            state = {};
	        
	        if(me.dataIndex){
	        	state.dataIndex = me.dataIndex; 
	        }

	        me.savePropsToState(['hidden', 'sortable', 'locked', 'flex', 'width'], state);
	        if (me.isGroupHeader) {
	            for (i = 0; i < iLen; i++) {
	                columns.push(items[i].getColumnState());
	            }
	            state.text = me.text || me.header;
	            if (columns.length) {
	                state.columns = columns;
	            }
	        } else if (me.isSubHeader && me.ownerCt.hidden) {
	            delete me.hidden;
	        }
	        if ('width' in state) {
	            delete state.flex;
	        }
	        return state;
	    }
		/*getStateId:function(){
			return this.dataIndex || this.id;
		}*/
	});

Ext.override(Ext.Editor, {
	 onFieldBlur : function(field, e) {
		 var me = this,
		 target;
		 if(me.allowBlur === true && me.editing && me.selectSameEditor !== true) {
		 me.completeEdit();
		 }
		 if (e && e.getTarget && Ext.fly(target = e.getTarget()).focusable()) {
		 target.focus();
		 }
	 }
		
});


//Restrict columnmove for enter header
Ext.grid.header.DropZone.prototype.onNodeDropOriginal = Ext.grid.header.DropZone.prototype.onNodeDrop;

Ext.override(Ext.grid.header.DropZone, {
	onNodeDrop : function(node, dragZone, e, data) {
		 var dragHeader = data.header,
		 dropLocation = data.dropLocation,
		 targetHeader = dropLocation.header,
		 fromCt = dragHeader.ownerCt,
		 localFromIdx = fromCt.items.indexOf(dragHeader),
		 toCt = targetHeader.ownerCt,
		 localToIdx = toCt.items.indexOf(targetHeader),
		 headerCt = this.headerCt,
		 fromIdx = headerCt.getHeaderIndex(dragHeader),
		 colsToMove = dragHeader.isGroupHeader ? dragHeader.query(':not([isGroupHeader])').length : 1,
		 toIdx = headerCt.getHeaderIndex(targetHeader),
		 groupCt,
		 scrollerOwner; 
		 
		 if(fromCt == toCt && !data.header.isGroupHeader)
		 Ext.grid.header.DropZone.prototype.onNodeDropOriginal.call(this,node, dragZone, e, data);
		 
	}
});

// Override to handel html tags from response for form.submit
Ext.override(Ext.data.Connection, {
    onUploadComplete: function (frame, options) {
        var me = this,
            response = {
                responseText: '',
                responseXML: null
            }, doc, contentNode;
        try {
            doc = frame.contentWindow.document || frame.contentDocument || window.frames[frame.id].document;
            if (doc) {
                if (Ext.isOpera && doc.location == 'about:blank') {
                    return;
                }
                if (doc.body) {
                    if ((contentNode = doc.body.firstChild) && /pre/i.test(contentNode.tagName)) {
                        response.responseText = contentNode.innerText;
                    } else if ((contentNode = doc.getElementsByTagName('textarea')[0])) {
                        response.responseText = contentNode.value;
                    } else {
                        response.responseText = doc.body.innerHTML || doc.body.textContent || doc.body.innerText;
                    }
                }
                response.responseXML = doc.XMLDocument || doc;
            }
        } catch (e) {}
        me.fireEvent('requestcomplete', me, response, options);
        Ext.callback(options.success, options.scope, [response, options]);
        Ext.callback(options.callback, options.scope, [options, true, response]);
        if (Ext.isOpera) {
            Ext.fly(frame).un(this.onUploadComplete, this);
        }
        setTimeout(function () {
            Ext.removeNode(frame);
        }, 100);
    }
}); 

/**
 * Fix for the issue
 * 
 * The issue is that when the window is closed and then re-opened for the second time then the focus and blur events don't fire.
 */
Ext.define('Ext.overrides.form.field.Base', {
	override: 'Ext.form.field.Base',
    applyRenderSelectors: function() {
        var me = this;

        me.callParent();

        // This is added here rather than defined in Ext.form.Labelable since inputEl isn't related to Labelable.
        // It's important to add inputEl to the childEls so it can be properly destroyed.
        me.addChildEls('inputEl');


        /**
         * @property {Ext.Element} inputEl
         * The input Element for this Field. Only available after the field has been rendered.
         */
        me.inputEl = me.el.getById(me.getInputId());
    }
});

Ext.override(Ext.form.ComboBox, {
	setReadOnly : function(readOnly){
		var me = this, old = me.readOnly;
		me.callParent(arguments);
		if (readOnly != old) {
			me.updateLayout();
		} 
		
		if(readOnly){
			Ext.form.ComboBox.prototype.setFieldStyle.call(this,'background:#C7C9BE;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.ComboBox.prototype.fieldStyle+';');
         }else{
        	 Ext.form.ComboBox.prototype.setFieldStyle.call(this,'background:#FDEEF4;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.ComboBox.prototype.fieldStyle+';'); 
         }
	}
});

Ext.override(Ext.data.proxy.Ajax, { timeout:1800000 });
Ext.override(Ext.Ajax,{ timeout:1800000 });

Ext.override(Ext.form.field.Number,{keyNavEnabled:false});


/**
 * This override is added by Bhavesh, to make selection and deselection faster in the grid
 */
Ext.override(Ext.selection.CheckboxModel,
			{
			selectAll : function(suppressEvent) {
				var me = this, 
				selections = me.store.getRange(),
				i = 0,
				len = selections.length,
				start = me.getSelection().length;
				
				me.bulkChange = true;
				me.preventFocus = true; // <- this code is added
				 
				for (; i < len; i++) {
					me.doSelect(selections[i], true, suppressEvent);
				}
				delete me.bulkChange;
				delete me.preventFocus;// <- this code is added
				
				me.maybeFireSelectionChange(me.getSelection().length !== start);
			},
			deselectAll : function(suppressEvent) {
					var me = this,
					selections = me.getSelection(),
					i = 0,
					len = selections.length,
					start = me.getSelection().length;
					
					me.bulkChange = true;
					me.preventFocus = true;// <- this code is added
					 
					for (; i < len; i++) {
						me.doDeselect(selections[i], suppressEvent);
					}
					delete me.bulkChange;
					delete me.preventFocus;// <- this code is added
					
					me.maybeFireSelectionChange(me.getSelection().length !== start);
				}
			});

// Fix the issue: 0 should not be taken by default for number field in gird
// Commentted the code as correpondig mapper should also hadle null parameters
/*Ext.data.Field.prototype.constructorOriginal = Ext.data.Field.prototype.constructor;  
Ext.override(Ext.data.Field,{
	constructor:function(config){
		config = config || {};
		if(config && (config.type == 'int' || config.type== 'float' || config.type == 'integer' || config.type == 'number')){
			config.useNull = true;
		}
		Ext.data.Field.prototype.constructorOriginal.call(this,config);
	}
});
*/


/**
 * Paging Memory Proxy, allows to use paging grid with in memory dataset
 */
Ext.define('Ext.ux.data.PagingMemoryProxy', {
    extend: 'Ext.data.proxy.Memory',
    alias: 'proxy.pagingmemory',
    alternateClassName: 'Ext.data.PagingMemoryProxy',

    read : function(operation, callback, scope){
        var reader = this.getReader(),
            result = reader.read(this.data),
            sorters, filters, sorterFn, records;

        scope = scope || this;
        // filtering
        filters = operation.filters;
        if (filters.length > 0) {
            //at this point we have an array of  Ext.util.Filter objects to filter with,
            //so here we construct a function that combines these filters by ANDing them together
            records = [];

            Ext.each(result.records, function(record) {
                var isMatch = true,
                    length = filters.length,
                    i;

                for (i = 0; i < length; i++) {
                    var filter = filters[i],
                        fn     = filter.filterFn,
                        scope  = filter.scope;

                    isMatch = isMatch && fn.call(scope, record);
                }
                if (isMatch) {
                    records.push(record);
                }
            }, this);

            result.records = records;
            result.totalRecords = result.total = records.length;
        }
        
        // sorting
        sorters = operation.sorters;
        if (sorters.length > 0) {
            //construct an amalgamated sorter function which combines all of the Sorters passed
            sorterFn = function(r1, r2) {
                var result = sorters[0].sort(r1, r2),
                    length = sorters.length,
                    i;
                
                    //if we have more than one sorter, OR any additional sorter functions together
                    for (i = 1; i < length; i++) {
                        result = result || sorters[i].sort.call(this, r1, r2);
                    }                
               
                return result;
            };
    
            result.records.sort(sorterFn);
        }
        
        // paging (use undefined cause start can also be 0 (thus false))
        if (operation.start !== undefined && operation.limit !== undefined) {
            result.records = result.records.slice(operation.start, operation.start + operation.limit);
            result.count = result.records.length;
        }

        Ext.apply(operation, {
            resultSet: result
        });
        
        operation.setCompleted();
        operation.setSuccessful();

        Ext.Function.defer(function () {
            Ext.callback(callback, scope, [operation]);
        }, 10);
    }
});


Ext.override(Ext.data.Store, {
	  
	/*  commitChanges: function()
	  {
	   
	    
	   
	    
	   
	  }, // commitChanges
	  
	  
*/
	 commitInserts: function()
	 {
		 Ext.each(this.getNewRecords(), function(rec) {
		      rec.commit();
		      rec.phantom = false;
		    });
	 },
	 commitUpdates: function()
	 {
		 Ext.each(this.getUpdatedRecords(), function(rec) {
		      rec.commit();
		    });
		 
	 },
	 commitDeletions: function()
	 {
		 this.removed = [];
	 },
	
	
	  rejectInserts: function()
	  {
	    this.remove(this.getNewRecords());
	  
	  },
	  rejectUpdates: function()
	  {
	    this.each( function(rec) {
	      rec.reject();
	    });
	    
	  } ,
	  rejectDeletions: function()
	  {
	    var rLength = this.removed.length;
	    for (var i = 0; i < rLength; i++) 
	    {
	      this.insert(this.removed[i].lastIndex || 0, this.removed[i]);
	    }
	    
	    this.removed = [];
	  },
	  
	  
	  onCreateRecords: function(records, operation, success) {
	        //console.log(records);
			var me = this ;
	        if(success==false){
				//me.rejectInserts();
	        	//rejectChanges();
	        }
			else{
				me.commitInserts();
			}
	    },

	    onUpdateRecords: function(records, operation, success) {
	        //console.log(records);
			var me = this ;
	        if(success==false){
	        	me.rejectUpdates();
	        	//me.rejectChanges();
	        }
			else{
				me.commitUpdates();
			}
	    },

	    onDestroyRecords: function(records, operation, success) {
	        //console.log(records);
			var me = this ;
	        if(success==false){
	        	me.rejectDeletions();
	        	//me.rejectChanges();
	        }
			else{
				me.commitDeletions();
			}
	    }
	  // rejectChanges
	  
	}); // Ext.data.Store