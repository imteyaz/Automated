Modules.CompIds.formRemovalOfHoldStatusFormId =	'formRemovalOfHoldStatusFormId';
Modules.CompIds.viewportParentTabPanelId = 'viewportParentTabPanelId';
Modules.CompIds.myWindowId = 'mywindowId';
Modules.CompIds.testComboId = 'myComboId';
Modules.CompIds.companyCodeComboId = 'companyCodeComboId';
Modules.CompIds.purgeFrequencyComboId = 'purgeFrequencyComboId';
Modules.CompIds.companyNameTextId = 'companyNameTextId';
Modules.CompIds.timeTextId = 'timeTextId';
Modules.CompIds.purgeDetailsGridId = 'purgeDetailsGridId';
Modules.CompIds.purgeMessageComboId = 'purgeMessageComboId';
Modules.CompIds.saveGridStateId = 'saveGridStateId';
Modules.CompIds.resetGridStateId = 'resetGridStateId';
Modules.CompIds.eventLogPdfReportId = 'eventLogPdfReportId';
Modules.CompIds.eventLogExcelReportId = 'eventLogExcelReportId';
Modules.CompIds.addRecordId = 'addRecordId';
Modules.CompIds.deleteRecordId = 'deleteRecordId';
Modules.CompIds.saveRecordId = 'saveRecordId';
Modules.CompIds.purgeDetailsFormId = 'purgeDetailsFormId';
Modules.CompIds.eventlogGridId='eventlogGridId';
Modules.CompIds.msgtypeId='msgtypeId';
Modules.CompIds.suppliercodeId='suppliercodeId';
Modules.CompIds.eventQueryFormId='eventQueryFormId';
Modules.CompIds.msgProStatusId='msgProStatusId';
Modules.CompIds.customercodeId='customercodeId';
Modules.CompIds.v_fromdateId='v_fromdateId';
Modules.CompIds.v_to_dateId='v_to_dateId';
Modules.CompIds.companyId='companyId';
Modules.CompIds.eventLogCompanyId='eventLogCompanyId';
Modules.CompIds.purgeDetailsGridCopyId='purgeDetailsGridCopyId';
Modules.CompIds.purgeDetailsGridPasteId='purgeDetailsGridPasteId';
Modules.CompIds.popupEventlogFormId='popupEventlogFormId';
Modules.CompIds.popupEventDateId='popupEventDateId';
Modules.CompIds.popupMsgTypeId='popupMsgTypeId';
Modules.CompIds.popupMsgProcStsId='popupMsgProcStsId';
Modules.CompIds.popupSupplCodeId='popupSupplCodeId';
Modules.CompIds.popupCustmrCodeId='popupCustmrCodeId';
Modules.CompIds.popupUnitId='popupUnitId';
Modules.CompIds.popupshipRefId='popupshipRefId';
Modules.CompIds.popupinvcNumId='popupinvcNumId';
Modules.CompIds.popupPayDocNumId='popupPayDocNumId';
Modules.CompIds.purgeFrequencyTextId='purgeFrequencyTextId';
Modules.CompIds.editPurgeMessageFormId='editPurgeMessageFormId';
Modules.CompIds.copyPurgeMessageComboId='copyPurgeMessageComboId';
Modules.CompIds.editPurgeDaysId='editPurgeDaysId';
Modules.CompIds.copyPurgeDaysId='copyPurgeDaysId';
Modules.CompIds.editPurgeMessageComboId='editPurgeMessageComboId';
Modules.CompIds.editPurgeGridWinId='editPurgeGridWinId';
Modules.CompIds.popupEventLogWinId='popupEventLogWinId';
Modules.CompIds.editPurgeGridWinSaveBtnId='editPurgeGridWinSaveBtnId';
Modules.CompIds.purgeDetailsCopyFieldSetId='purgeDetailsCopyFieldSetId';
Modules.CompIds.eventlogModalFormId='eventlogModalFormId';
Modules.CompIds.eventlogSaveSearchNameId='eventlogSaveSearchNameId';
Modules.CompIds.eventlogSaveSearchDescrpId='eventlogSaveSearchDescrpId';
Modules.CompIds.eventlogSaveSearchDefaultFlagId='eventlogSaveSearchDefaultFlagId';
Modules.CompIds.eventlogSaveSearchNmId='eventlogSaveSearchNmId';
Modules.CompIds.eventlogSaveSearchDscpId='eventlogSaveSearchDscpId';
Modules.CompIds.eventlogSaveSearchWinId='eventlogSaveSearchWinId';
Modules.CompIds.eventlogRetrieveSearchWinId='eventlogRetrieveSearchWinId';
Modules.CompIds.eventlogRetrieveSearchGridId='eventlogRetrieveSearchGridId';
Modules.CompIds.purgeExportPdfId='purgeExportPdfId';
Modules.CompIds.purgeExportExcelId='purgeExportExcelId';

Modules.CompIds.importErrorGrid = 'importErrorGridId';
Modules.CompIds.importErrorMsgWinId = 'importErrorMsgWinId';
/*-----Swim UI----------*/
Modules.CompIds.addPartnerRecordId= 'addPartnerRecordId';
Modules.CompIds.deletePartnerRecordId='deletePartnerRecordId';
Modules.CompIds.modifyPartnerRecordId='modifyPartnerRecordId';

Modules.CompIds.addGrpPartnerRecordId= 'addwGrpPartnerRecordId';
Modules.CompIds.deleteGrpPartnerRecordId= 'deletewGrpPartnerRecordId';

Modules.CompIds.autoReprcSaveId='autoReprcSaveId';
Modules.CompIds.autoReprcClearId='autoReprcClearId';
Modules.CompIds.autoReprcDeleteId='autoReprcDeleteId';
Modules.CompIds.autoReprcRetriveId='autoReprcRetriveId';
Modules.CompIds.updateStatus='updateStatus';
Modules.CompIds.autoReprcAddId='autoReprcAddId';

Modules.CompIds.viewJobsGridWinId='viewJobsGridWinId';
Modules.CompIds.uploadWindowId = 'importUploadWindowId';
/*--Swim UI Process Administration window--*/
Modules.CompIds.startPrtnrMsgId='startPrtnrMsgId';
Modules.CompIds.startAllPrtnrMsgsId='startAllPrtnrMsgsId';
Modules.CompIds.stopPrtnrMsgId='stopPrtnrMsgId';
Modules.CompIds.stopAllPrtnrMsgsId='stopAllPrtnrMsgsId';

/**Customer Invoice Entry */
Modules.CompIds.cstmrInveEntryTabPanelId 					= 'cstmrInveEntryTabPanelId';
Modules.CompIds.custInvcEntryFormId 						= 'custInvcEntryFormId';
Modules.CompIds.custInvcEntryFormcustomerId 				= 'custInvcEntryFormcustomerId';
Modules.CompIds.custInvcEntryFormcustNameId 				= 'custInvcEntryFormcustNameId';
Modules.CompIds.custInvcEntryGPGridId 						= 'custInvcEntryGPGridId';
Modules.CompIds.custInvcEntryAddRecordGPId 					= 'custInvcEntryAddRecordGPId';
Modules.CompIds.custInvcEntryDeleteRecordGPId 				= 'custInvcEntryDeleteRecordGPId';
Modules.CompIds.custInvcEntryCopyGPId 						= 'custInvcEntryCopyGPId';
Modules.CompIds.custInvcEntryPGridId 						= 'custInvcEntryPGGridId';
Modules.CompIds.custInvcEntryAddRecordPGId 					= 'custInvcEntryAddRecordPGId';
Modules.CompIds.custInvcEntryDeleteRecordPGId 				= 'custInvcEntryDeleteRecordPGId';
Modules.CompIds.custInvcEntryCopyPGId 						= 'custInvcEntryCopyPGId';
Modules.CompIds.cstmrInveEntryPGCGFormPanelId 				= 'cstmrInveEntryPGCGFormPanelId';
Modules.CompIds.custInvcEntryChGridId 						= 'custInvcEntryCGGridId';
Modules.CompIds.cstmrInvcEntryResultFormId 					= 'cstmrInvcEntryResultFormId';
Modules.CompIds.custInvcEntryTotSrvcAmtId 					= 'custInvcEntryTotSrvcAmtId';
Modules.CompIds.custInvcEntryTotTaxAmtId 					= 'custInvcEntryTotTaxAmtId';
Modules.CompIds.custInvcEntryTotAmtId 						= 'custInvcEntryTotAmtId';
Modules.CompIds.cstmrInvcEntryGPComboCurrencyId				= 'cstmrInvcEntryGPComboCurrencyId';
Modules.CompIds.cstmrInvcEntryGPComboCurrencyId				= 'cstmrInvcEntryGPComboCurrencyId';
Modules.CompIds.cstmrInvcEntryGPPrintTemplateId 			= 'cstmrInvcEntryGPPrintTemplateId';
Modules.CompIds.cstmrInvcEntryGPProfitLossId 				= 'cstmrInvcEntryGPProfitLossId';
Modules.CompIds.cstmrInvcEntryGPComboEvntStatusId			= 'cstmrInvcEntryGPComboEvntStatusId';
Modules.CompIds.cstmrInvcEntryGPComboStateProvinceId 		= 'cstmrInvcEntryGPComboStateProvinceId';
Modules.CompIds.cstmrInvcEntryPGComboSrvcCdComboId			= 'cstmrInvcEntryPGComboSrvcCdComboId';
Modules.CompIds.cstmrInvcEntryPGComboConvncTypeId			= 'cstmrInvcEntryPGComboConvncTypeId';
Modules.CompIds.cstmrInvcEntryPGComboMakeCdId 				= 'cstmrInvcEntryPGComboMakeCdId';
Modules.CompIds.cstmrInvcEntryPGComboModelCdId				= 'cstmrInvcEntryPGComboModelCdId';
Modules.CompIds.cstmrInvcEntryPGComboModelGrpId				= 'cstmrInvcEntryPGComboModelGrpId';
Modules.CompIds.cstmrInvcEntryPGComboTrnsptModeId	 		= 'cstmrInvcEntryPGComboTrnsptModeId';
Modules.CompIds.cstmrInvcEntryPGComboRateTierId				= 'cstmrInvcEntryPGComboRateTierId';
Modules.CompIds.cstmrInvcEntryPGComboOrgnLocId				= 'cstmrInvcEntryPGComboOrgnLocId';
Modules.CompIds.cstmrInvcEntryPGComboOrgnLocStPId 			= 'cstmrInvcEntryPGComboOrgnLocStPId';
Modules.CompIds.cstmrInvcEntryPGComboDestCdId				= 'cstmrInvcEntryPGComboDestCdId';
Modules.CompIds.cstmrInvcEntryPGComboDestStateProvId		= 'cstmrInvcEntryPGComboDestStateProvId';
Modules.CompIds.cstmrInvcEntryPGComboOrigOrgId		 		= 'cstmrInvcEntryPGComboOrigOrgId';
Modules.CompIds.cstmrInvcEntryPGComboFinalDestId			= 'cstmrInvcEntryPGComboFinalDestId';
Modules.CompIds.cstmrInvcEntryPGComboD2dUomId				= 'cstmrInvcEntryPGComboD2dUomId';
Modules.CompIds.cstmrInvcEntryPGComboRatingDestId	 		= 'cstmrInvcEntryPGComboRatingDestId';
Modules.CompIds.cstmrInvcEntryPGComboD2rUomId				= 'cstmrInvcEntryPGComboD2rUomId';
Modules.CompIds.cstmrInvcEntryPGComboPrftLossCentId			= 'cstmrInvcEntryPGComboPrftLossCentId';
Modules.CompIds.cstmrInvcEntryPGComboCustSlsRgnId	 		= 'cstmrInvcEntryPGComboCustSlsRgnId';
Modules.CompIds.cstmrInvcEntryPGComboShmntDtId				= 'cstmrInvcEntryPGComboShmntDtId';
Modules.CompIds.cstmrInvcEntryPGComboOrdrTypId				= 'cstmrInvcEntryPGComboOrdrTypId';
Modules.CompIds.cstmrInvcEntryPGComboAbnrmMvTypeId			= 'cstmrInvcEntryPGComboAbnrmMvTypeId';
Modules.CompIds.cstmrInvcEntryPGComboDlrCdId		 		= 'cstmrInvcEntryPGComboDlrCdId';
Modules.CompIds.cstmrInvcEntryPGComboSuplrCdId				= 'cstmrInvcEntryPGComboSuplrCdId';
Modules.CompIds.cstmrInvcEntryPGComboConsolTypeId			= 'cstmrInvcEntryPGComboConsolTypeId';
Modules.CompIds.cstmrInvcEntryPGComboUom1Id			 		= 'cstmrInvcEntryPGComboUom1Id';
Modules.CompIds.cstmrInvcEntryPGComboUom2Id					= 'cstmrInvcEntryPGComboUom2Id';
Modules.CompIds.cstmrInvcEntryPGComboRtbsisId				= 'cstmrInvcEntryPGComboRtbsisId';
Modules.CompIds.custInvcEntryPopUpFormId					= 'Modules.CompIds.custInvcEntryPopUpFormId';
Modules.CompIds.cstmrInveEntryPopUpFormInvoiceId			= 'cstmrInveEntryPopUpFormInvoiceId';
Modules.CompIds.cstmrInveEntryPopUpFormCrdtNoteId			= 'cstmrInveEntryPopUpFormCrdtNoteId';
Modules.CompIds.cstmrInveEntryPopUpFormActualId				= 'cstmrInveEntryPopUpFormActualId';
Modules.CompIds.cstmrInveEntryPopUpFormDbtNoteId			= 'cstmrInveEntryPopUpFormDbtNoteId';
Modules.CompIds.custInvcEntryFormCurrencyId					= 'custInvcEntryFormCurrencyId';
Modules.CompIds.custInvcEntryFormProfitLossCentId			= 'custInvcEntryFormProfitLossCentId';
Modules.CompIds.custInvcEntryFormPartyId					= 'custInvcEntryFormPartyId';
Modules.CompIds.custInvcEntryFormStateProvId				= 'custInvcEntryFormStateProvId';
Modules.CompIds.custInvcEntryPGPopUpFormId					= 'custInvcEntryPGPopUpFormId';
Modules.CompIds.custInvcEntryFormDistToDestuomId			= 'custInvcEntryFormDistToDestuomId';
Modules.CompIds.custInvcEntryFormDistToRatingDestUomId		= 'custInvcEntryFormDistToRatingDestUomId';
Modules.CompIds.custInvcEntryFormsrvCodeId					= 'custInvcEntryFormsrvCodeId';
Modules.CompIds.custInvcEntryFormConvncTypeId				= 'custInvcEntryFormConvncTypeId';
Modules.CompIds.custInvcEntryFormStorageTypeId				= 'custInvcEntryFormStorageTypeId';
Modules.CompIds.custInvcEntryFormCargoTypeId				= 'custInvcEntryFormCargoTypeId';
Modules.CompIds.custInvcEntryFormModelLineId				= 'custInvcEntryFormModelLineId';
Modules.CompIds.custInvcEntryFormMakeCdId					= 'custInvcEntryFormMakeCdId';
Modules.CompIds.custInvcEntryFormModelCdId					= 'custInvcEntryFormModelCdId';
Modules.CompIds.custInvcEntryFormModelGrpeId				= 'custInvcEntryFormModelGrpeId';
Modules.CompIds.custInvcEntryFormTrnsptModeId				= 'custInvcEntryFormTrnsptModeId';
Modules.CompIds.custInvcEntryFormRateTierId					= 'custInvcEntryFormRateTierId';
Modules.CompIds.custInvcEntryFormOrgnLocId					= 'custInvcEntryFormOrgnLocId';
Modules.CompIds.custInvcEntryFormOrgnLocStProvId			= 'custInvcEntryFormOrgnLocStProvId';
Modules.CompIds.custInvcEntryFormDestCdId					= 'custInvcEntryFormDestCdId';
Modules.CompIds.custInvcEntryFormDestStProvId				= 'custInvcEntryFormDestStProvId';
Modules.CompIds.custInvcEntryFormOrgorigId					= 'custInvcEntryFormOrgorigId';
Modules.CompIds.custInvcEntryFormFnalDestId					= 'custInvcEntryFormFnalDestId';
Modules.CompIds.custInvcEntryFormDatingDestId				= 'custInvcEntryFormDatingDestId';
Modules.CompIds.custInvcEntryFormPrftLossCenId				= 'custInvcEntryFormPrftLossCenId';
Modules.CompIds.custInvcEntryFormCustSalesRgnId				= 'custInvcEntryFormCustSalesRgnId';
Modules.CompIds.custInvcEntryFormShpmntTypeId				= 'custInvcEntryFormShpmntTypeId';
Modules.CompIds.custInvcEntryFormOrdrTypeId					= 'custInvcEntryFormOrdrTypeId';
Modules.CompIds.custInvcEntryFormAbnrmMvTypeId				= 'custInvcEntryFormAbnrmMvTypeId';
Modules.CompIds.custInvcEntryFormDlrCdId					= 'custInvcEntryFormDlrCdId';
Modules.CompIds.custInvcEntryFormSupCdId					= 'custInvcEntryFormSupCdId';
Modules.CompIds.custInvcEntryFormConsolTypeId				= 'custInvcEntryFormConsolTypeId';
Modules.CompIds.custInvcEntryFormUom1Id						= 'custInvcEntryFormUom1Id';
Modules.CompIds.custInvcEntryFormUom2Id						= 'custInvcEntryFormUom2Id';
Modules.CompIds.custInvcEntryFormRateBasisId				= 'custInvcEntryFormRateBasisId';

/*--------------Ocean Customer Event Status Summary----------------------------------*/
Modules.CompIds.custEventStatusSummaryAdvContainer='custEventStatusSummaryAdvContainer';
Modules.CompIds.custEventStatusSummaryFormId = 'custEventStatusSummaryFormId';
Modules.CompIds.custEventStatusSummaryParentTabpanelId= 'custEventStatusSummaryParentTabpanelId';
Modules.CompIds.custEventStatusSummaryGridId='custEventStatusSummaryGridId';
Modules.CompIds.custEventStatusSummaryGridAddBtnId='custEventStatusSummaryGridAddBtnId';
Modules.CompIds.custEventStatusSummaryGridPartyId='custEventStatusSummaryGridPartyId';
Modules.CompIds.custEventStatusSummaryGridCurncyId='custEventStatusSummaryGridCurncyId';
Modules.CompIds.custEventStatusSummaryGridSrvAmntUSDId='custEventStatusSummaryGridSrvAmntUSDId';
Modules.CompIds.custEventStatusSummaryGridInvcCrncyCdId='custEventStatusSummaryGridInvcCrncyCdId';
Modules.CompIds.custEventStatusSummaryGridServAmntInvcCrncyId='custEventStatusSummaryGridServAmntInvcCrncyId';
Modules.CompIds.custEventStatusSummaryGridManfestCrncyCdId='custEventStatusSummaryGridManfestCrncyCdId';
Modules.CompIds.custEventStatusSummaryGridSrvAmntManFestCrncyId='custEventStatusSummaryGridSrvAmntManFestCrncyId';
Modules.CompIds.custEventStatusSummaryGridTotQntyId='custEventStatusSummaryGridTotQntyId';
Modules.CompIds.custEventStatusSummaryGridCountId='custEventStatusSummaryGridCountId';
Modules.CompIds.custEventStatusSummaryGridPodId='custEventStatusSummaryGridPodId';
Modules.CompIds.custEventStatusSummaryGridPocId='custEventStatusSummaryGridPocId';
Modules.CompIds.custEventStatusSummaryGridChrgCodeId='custEventStatusSummaryGridChrgCodeId';
Modules.CompIds.custEventStatusSummaryGPopup='custEventStatusSummaryGPopup';
Modules.CompIds.ocnPinvcCstmrEvntstatusSummaryId  =  'ocnPinvcCstmrEvntstatusSummaryId';
Modules.CompIds.ocnZerortCstmrEvntstatusSummaryId = 'ocnZerortCstmrEvntstatusSummaryId';
Modules.CompIds.ocnInvcCstmrEvntstatusSummaryId = 'ocnInvcCstmrEvntstatusSummaryId';
Modules.CompIds.ocnRejectCstmrEvntstatusSummaryId= 'ocnRejectCstmrEvntstatusSummaryId';
Modules.CompIds.ocnNochrgCstmrEvntstatusSummaryId = 'ocnNochrgCstmrEvntstatusSummaryId';
Modules.CompIds.sailingFrmDateCstmrEvntStsSummaryId = 'sailingFrmDateCstmrEvntStsSummaryId';
Modules.CompIds.sailingTODateCstmrEvntStsSummaryId   = 'sailingTODateCstmrEvntStsSummaryId';
/*-----------------SwimUI (Status Monitoring ----Account Payable window)-------------*/
Modules.CompIds.accPayFormId ='accPayableFormId';
Modules.CompIds.editJobsFormId ='editJobsFormId';
Modules.CompIds.viewBackGroundJobsFormId = 'viewBackGroundJobsFormId';
Modules.CompIds.viewBackGroundJobsComboId = 'viewJobsId';
Modules.CompIds.viewBackGroundJobsDescId = 'backGroundJobDescId';
Modules.CompIds.viewBackGroundJobsGridId = 'viewBackGroundJobsGridId';
Modules.CompIds.firstButtonId='firstButtonId';
Modules.CompIds.previousButtonId='previousButtonId';
Modules.CompIds.nextButtonId='nextButtonId';
Modules.CompIds.lastButtonId='lastButtonId';


/*-------(Account Payable window-----form)---------*/
Modules.CompIds.accPayMsgHdrId='accPayMsgHdrId';
Modules.CompIds.accPayMsgTypeId='accPayMsgTypeId';
Modules.CompIds.accPayPartnrCdId='accPayPartnrCdId';
Modules.CompIds.accPayCompanyId	= 'accPayCompanyId';
Modules.CompIds.accPayExtCompanyId ='accPayExtCompanyId';
Modules.CompIds.accPayInvoiceNumberId = 'accPayInvoiceNumberId';
Modules.CompIds.accPaySupplierCdId = 'accPaySupplierCdId';
Modules.CompIds.accPayExtSupplierCdId = 'accPayExtSupplierCdId';
Modules.CompIds.accPaySpplrPymntInvcNoId = 'accPaySpplrPymntInvcNoId';
Modules.CompIds.accPayDebtorPartyCodeId = 'accPayDebtorPartyCodeId';
Modules.CompIds.accPayDebtorPartyNameId ='accPayDebtorPartyNameId';
Modules.CompIds.accPayContactPersonNameId ='accPayContactPersonNameId';
Modules.CompIds.accPayInvoiceDateId = 'accPayInvoiceDateId';
Modules.CompIds.accPayInvoiceDuedateId = 'accPayInvoiceDuedateId';
Modules.CompIds.accPayCurrencyId = 'accPayCurrencyId';
Modules.CompIds.accPayExtCurrencyId ='accPayExtCurrencyId';
Modules.CompIds.accPayTotalAmountId = 'accPayTotalAmountId';
Modules.CompIds.accPayDocumentTypeId = 'accPayDocumentTypeId';
Modules.CompIds.accPayActualId = 'accPayActualId';
 
/*----------End------------*/

Modules.CompIds.accPayableGridId='accPayableGridId';
Modules.CompIds.accPayableWindowId='accPayableWindowId';

/*----------------End of Account Payable Window-----------*/

/*-------------Account receivable----------*/
Modules.CompIds.accRecFormId='accRecFormId';
Modules.CompIds.accRecMsgHdrId ='accRecMsgHdrId';
Modules.CompIds.accRecCompanyId ='accRecCompanyId';
Modules.CompIds.accRecExtCompanyId = 'accRecExtCompanyId';
Modules.CompIds.accRecInvoiceNumberId = 'accRecInvoiceNumberId';
Modules.CompIds.accRecCustomerCdId = 'accRecCustomerCdId';
Modules.CompIds.accRecExtCustomerCdId = 'accRecExtCustomerCdId';
Modules.CompIds.accRecReferInvcNoId = 'accRecReferInvcNoId';
Modules.CompIds.accRecDebtorPartyCodeId = 'accRecDebtorPartyCodeId';
Modules.CompIds.accRecDebtorPartyNameId = 'accRecDebtorPartyNameId';
Modules.CompIds.accRecContactPersonNameId = 'accRecContactPersonNameId';
Modules.CompIds.accRecInvoiceDateId   = 'accRecInvoiceDateId';
Modules.CompIds.accRecInvoiceDuedateId = 'accRecInvoiceDuedateId';
Modules.CompIds.accRecCurrencyId   = 'accRecCurrencyId';
Modules.CompIds.accRecExtCurrencyId  = 'accRecExtCurrencyId';
Modules.CompIds.accRecTotalAmountId   = 'accRecTotalAmountId';
Modules.CompIds.accRecDocumentTypeId  = 'accRecDocumentTypeId';
Modules.CompIds.accRecActualId          = 'accRecActualId';
Modules.CompIds.accRecCreditDebitId    = 'accRecCreditDebitId';
Modules.CompIds.accRecDebtorSubLedgerCdId  = 'accRecDebtorSubLedgerCdId';

Modules.CompIds.accRecievableGridId = 'accRecievableGridId';
Modules.CompIds.accRecievableWindowId = 'accRecievableWindowId';

Modules.CompIds.truckInvoiceMsgHdrId='truckInvcMsgHdrId';
Modules.CompIds.truckInvoiceExtSupplrCdId='truckInvcExtSupplierCdId';
Modules.CompIds.truckInvoiceExtCompanyId='truckInvcExtCmpnyCdId';
Modules.CompIds.truckInvoiceInvoiceNumberId='truckInvcNumberId';
Modules.CompIds.truckInvoiceProductId='truckInvcProductId';
Modules.CompIds.truckInvoiceProductDateId='truckInvcProductDateId';
Modules.CompIds.truckInvoiceCreditNoteInd='truckInvcCreditNoteInd';
Modules.CompIds.truckInvoiceInvoiceDateId='truckInvcDateId';
Modules.CompIds.truckInvoiceInvoiceDuedateId='truckInvcDueDateId';
Modules.CompIds.truckInvoiceExtCurrencyId='truckInvcExtCurId';
Modules.CompIds.truckInvoiceTotalAmountId='truckInvcAmtId';
Modules.CompIds.truckInvoiceGridId='truckInvoiceGridId';
Modules.CompIds.truckInvoiceTaxGridId='truckInvoiceTaxGridId';


Modules.CompIds.railInvcWindowId='railInvcWindowId';
Modules.CompIds.railInvoiceFormId='railInvoiceFormId';
Modules.CompIds.railInvoiceGridId='viewRailInvoiceGridId';
Modules.CompIds.railInvoiceRoutingGridId='railInvoiceRoutingGridId';
Modules.CompIds.railInvoiceEvntDtlGridId='railInvoiceEvntDtlGridId';

Modules.CompIds.railInvoiceMsgHdrId='railInvoiceMsgHdrId';
Modules.CompIds.railInvoiceMsgTypeId='railInvoiceMsgTypeId';
Modules.CompIds.railInvoicePartnrCdId='railInvoicePartnrCdId';
Modules.CompIds.railInvoiceExtSupplrCdId='railInvoiceExtSupplrCdId';
Modules.CompIds.railInvoiceInvoiceNumberId='railInvoiceInvoiceNumberId';
Modules.CompIds.railInvoiceTotalAmountId='railInvoiceTotalAmountId';
Modules.CompIds.railInvoiceInvoiceDuedateId='railInvoiceInvoiceDuedateId';
Modules.CompIds.railInvoiceInvoiceDateId='railInvoiceInvoiceDateId';
Modules.CompIds.railInvoiceEventLoadRefId='railInvoiceEventLoadRefId';
Modules.CompIds.railInvoiceExtConveyanceTypeId='railInvoiceExtConveyanceTypeId';
Modules.CompIds.railInvoiceTaxRegNoId='railInvoiceTaxRegNoId';
Modules.CompIds.railInvoiceRefContractNoId='railInvoiceRefContractNoId';
Modules.CompIds.railInvoiceWayBillNoId='railInvoiceWayBillNoId';
Modules.CompIds.railInvoiceExtCurrId='railInvoiceExtCurrId';
Modules.CompIds.railInvcExtOriginId='railInvcExtOriginId';
Modules.CompIds.railInvcOriginCityId='railInvcOriginCityId';
Modules.CompIds.railInvcConveyanceId='railInvcConveyanceId';
Modules.CompIds.railInvcExtOriginStateProvinceId='railInvcExtOriginStateProvinceId';
Modules.CompIds.railInvcExtOriginCountryId='railInvcExtOriginCountryId';
Modules.CompIds.railInvcExtCompanyId='railInvcExtCompanyId';
Modules.CompIds.railInvcDestinationCityId='railInvcDestinationCityId';
Modules.CompIds.railInvcExtDestinationId='railInvcExtDestinationId';
Modules.CompIds.railInvcExtDestinationStateProvinceId='railInvcExtDestinationStateProvinceId';
Modules.CompIds.railInvcConsigneeId='railInvcConsigneeId';
Modules.CompIds.railInvcConsignerId='railInvcConsignerId';
Modules.CompIds.railInvcCompanyNmId='railInvcCompanyNmId';
Modules.CompIds.railInvcConsigneeNmId='railInvcConsigneeNmId';
Modules.CompIds.railInvcConsignerNmId='railInvcConsignerNmId';
Modules.CompIds.railInvcCompanyAddressId='railInvcCompanyAddressId';
Modules.CompIds.railInvcCompanyAddress2Id='railInvcCompanyAddress2Id';
Modules.CompIds.railInvcConsignerAddressId='railInvcConsignerAddressId';
Modules.CompIds.railInvcConsignerAddress2Id='railInvcConsignerAddress2Id';
Modules.CompIds.railInvcConsigneeAddressId='railInvcConsigneeAddressId';
Modules.CompIds.railInvcConsigneeAddress2Id='railInvcConsigneeAddress2Id';
Modules.CompIds.railInvcCompanyCityId='railInvcCompanyCityId';
Modules.CompIds.railInvcConsignerCityId='railInvcConsignerCityId';
Modules.CompIds.railInvcConsigneeCityId='railInvcConsigneeCityId';
Modules.CompIds.railInvcExtCompanyStateProvinceId='railInvcExtCompanyStateProvinceId';
Modules.CompIds.railInvcConsignerStateProvinceId='railInvcConsignerStateProvinceId';
Modules.CompIds.railInvcConsigneeStateProvinceId='railInvcConsigneeStateProvinceId';
Modules.CompIds.railInvcConsignerCountryId='railInvcConsignerCountryId';
Modules.CompIds.railInvcConsigneeCountryId='railInvcConsigneeCountryId';
Modules.CompIds.railInvcExtCompanyCountryId='railInvcExtCompanyCountryId';
Modules.CompIds.railInvcExtDestinationCountryId='railInvcExtDestinationCountryId';


Modules.CompIds.srvcChrgInvoiceFormId='srvcChrgInvoiceFormId';	
Modules.CompIds.srvcChrgInvoiceMsgHdrId='srvcChrgInvoiceMsgHdrId';
Modules.CompIds.srvcChrgMsgTypeId='srvcChrgMsgTypeId';
Modules.CompIds.srvcChrgPartnrCdId='srvcChrgPartnrCdId';
Modules.CompIds.srvcChrgInvoiceExtSupplrCdId='srvcChrgInvoiceExtSupplrCdId';
Modules.CompIds.srvcChrgInvoiceExtCmpnyId='srvcChrgInvoiceExtCmpny';
Modules.CompIds.srvcChrgInvoiceInvoiceNumberId='srvcChrgInvoiceInvoiceNumberId';
Modules.CompIds.srvcChrgInvoiceCreditNoteInd='srvcChrgInvoiceCreditNoteInd';
Modules.CompIds.srvcChrgeInvoiceDateId='srvcChrgeInvoiceDateId';
Modules.CompIds.srvcChrgeInvoiceTotalAmountId='srvcChrgeInvoiceTotalAmountId';
Modules.CompIds.srvcChrgInvoiceInvoiceDuedateId='srvcChrgInvoiceInvoiceDuedateId';
Modules.CompIds.srvcChrgeInvoiceExtCurrencyId='srvcChrgeInvoiceExtCurrencyId';

Modules.CompIds.srvcChrgeInvoiceTaxDtlsId='srvcChrgeInvoiceTaxDtls';
Modules.CompIds.srvcChrgeInvoiceGridId='srvcChrgeInvoiceGridId';


Modules.CompIds.inSupplierRemitAdvcDtlsId='inSupplierRemitAdvcGridId';
Modules.CompIds.inSupplierRemitAdvcFormId='inSupplierRemitAdvcFormId';
Modules.CompIds.winInSupplierRemitAdvcId='winInSupplierRemitAdvcId';
Modules.CompIds.inSupplierRemitAdvcMsgHdrId='inSupplierRemitAdvcMsgHdrId';
Modules.CompIds.inSupplierRemitAdvcMsgTypeId='inSupplierRemitAdvcMsgTypeId';
Modules.CompIds.inSupplierRemitAdvcPartnrCdId='inSupplierRemitAdvcPartnrCdId';
Modules.CompIds.inSupplierRemitAdvcExtCmpnyId='inSupplierRemitAdvcExtCmpnyId';
Modules.CompIds.inSupplierRemitAdvcExtSupplrCdId='inSupplierRemitAdvcExtSupplrCdId';
Modules.CompIds.inSupplierRemitAdvcSupplrNmId='inSupplierRemitAdvcSupplrNm';                                
Modules.CompIds.inSupplierRemitAdvcSupplrAddId='inSupplierRemitAdvcSupplrAddId';
Modules.CompIds.inSupplierRemitAdvcSupplrCityId='inSupplierRemitAdvcSupplrCityId';
Modules.CompIds.inSupplierRemitAdvcExtSupplrStateProvId='inSupplierRemitAdvcExtSupplrStateProvId';
Modules.CompIds.inSupplierRemitAdvcExtSupplrCountryId='inSupplierRemitAdvcExtSupplrCountryId';
Modules.CompIds.inSupplierRemitAdvcPaymntDocNo='inSupplierRemitAdvcPaymntDocNo';
Modules.CompIds.inSupplierRemitAdvcPaymntDocType='inSupplierRemitAdvcPaymntDocType';
Modules.CompIds.inSupplierRemitAdvcPaymntDate='inSupplierRemitAdvcPaymntDate';
Modules.CompIds.inSupplierRemitAdvcExtCurr='inSupplierRemitAdvcExtCurr';
Modules.CompIds.inSupplierRemitAdvcTotalAmt='inSupplierRemitAdvcTotalAmt';

/*-------------START of Supplier Remittance Advice Message Cancellation----------*/


Modules.CompIds.cinSuppRemitAdvcWindowId	=	'cinSuppRemitAdvcWindowId';
Modules.CompIds.cinSuppRemitAdvcFormId		=	'cinSuppRemitAdvcFormId';
Modules.CompIds.cinSuppRemitAdvcGridId		=	'cinSuppRemitAdvcGridId';


Modules.CompIds.custmrInvcFormId='customerInvoiceForm';
Modules.CompIds.custrmInvcWindowId='customerInvoiceWindow';
Modules.CompIds.custmrInvcGridId='custmrInvcGrid';
Modules.CompIds.custmrInvoiceTaxGridId='custmrInvoiceTaxGridDtls';

/*-------------END of Supplier Remittance Advice Message Cancellation----------*/


Modules.CompIds.custmrInvcMsgHdrId='custmrInvcMsgHdrId';
Modules.CompIds.custmrInvcMsgTypeId='custmrInvcMsgType';
Modules.CompIds.custmrInvcPartnrCdId='custmrInvcPartnrCd';
Modules.CompIds.custmrInvcExtCmpnyId='custmrInvcExtCmpnyId';
Modules.CompIds.custmrInvcCmpnyId='custmrInvcCmpnyId';
Modules.CompIds.custmrInvcAddrLine1Id='custmrInvcAddrLine1';
Modules.CompIds.custmrInvcAddrLine2Id='custmrInvcAddrLine2';
Modules.CompIds.custmrInvcCityId='custmrInvcCity';
Modules.CompIds.custmrInvcZipPostalCdId='custmrInvcZipPostalCd';
Modules.CompIds.custmrInvcStateProvId='custmrInvcStateProv';
Modules.CompIds.custmrInvcExtStateProvId='custmrInvcExtStateProv';
Modules.CompIds.custmrInvcCountryId='custmrInvcCountry';
Modules.CompIds.custmrInvcExtCountryId='custmrInvcExtCountry';
Modules.CompIds.custmrInvcCustomerId='custmrInvcCustomer';
Modules.CompIds.custmrInvcCustAddrLine1Id='custmrInvcCustAddrLine1';
Modules.CompIds.custmrInvcCustAddrLine2Id='custmrInvcCustAddrLine2';
Modules.CompIds.custmrInvcCustCityId='custmrInvcCustCity';
Modules.CompIds.custmrInvcCustZipPostalCdId='custmrInvcCustZipPostalCd';
Modules.CompIds.custmrCustInvcCustStateProvId='custmrCustInvcCustStateProv';
Modules.CompIds.custmrInvcCustomerExtStateProvId='custmrInvcCustomerExtStateProv';
Modules.CompIds.custmrInvcCustCountryId='custmrInvcCustCountry';
Modules.CompIds.custmrInvcCustExtCountryId='custmrInvcCustExtCountry';
Modules.CompIds.custmrInvcCurrencyId='custmrInvcCurrency';
Modules.CompIds.custmrInvcExtCurrencyId='custmrInvcExtCurrency';
Modules.CompIds.custmrInvcExtCustmrCd='custmrInvcExtCustmrCd';
Modules.CompIds.custmrInvceDate='custmrInvceDtId';
Modules.CompIds.custmrInvcInvcDueDt='custmrInvcInvcDueDt';
Modules.CompIds.custmrInvcInvoiceNumber='custmrInvcInvoiceNumber';
Modules.CompIds.custmrInvcRefInvoiceNumber='custmrInvcRefInvoiceNumber';
Modules.CompIds.custmrInvcDocType='custmrInvcDocType';
Modules.CompIds.custmrInvcExtDocType='custmrInvcExtDocType';
Modules.CompIds.custmrInvcAmt='custmrInvcAmt';
Modules.CompIds.custmrInvcContactPerson='custmrInvcContactPerson';
Modules.CompIds.custmrPhone='custmrPhone';
Modules.CompIds.custmrInvcProformalInd='custmrInvcProformalInd';

/*-------------START of Customer Remittance Advice ----------*/


Modules.CompIds.covusXmlInterfaceId='CovusXmlInterfaceFormId';
Modules.CompIds.covusXmlWindowId='CovusXmlInterfaceWinId';
Modules.CompIds.covusXmlInvcDtlTabPanelId='covusXmlInvcDtlTabPanel';

Modules.CompIds.cstrRemitAdvWindowId			=	'cstrRemitAdvWindowId';
Modules.CompIds.cstrRemitAdvcFormId				=	'cstrRemitAdvcFormId';
Modules.CompIds.cstrRemitAdvcMsgHdrId			=	'cstrRemitAdvcMsgHdrId';
Modules.CompIds.cstrRemitAdvcMsgTypeId			=	'cstrRemitAdvcMsgTypeId';
Modules.CompIds.cstrRemitAdvcPrtnrCodeId		=	'cstrRemitAdvcPrtnrCodeId';
Modules.CompIds.cstrRemitAdvcExtCompanyId		=	'cstrRemitAdvcExtCompanyId';
Modules.CompIds.cstrRemitAdvcExtCstmrCodeId		=	'cstrRemitAdvcExtCstmrCodeId';
Modules.CompIds.cstrRemitAdvcExtCstmrNameId		=	'cstrRemitAdvcExtCstmrNameId';
Modules.CompIds.cstrRemitAdvcCstmrAddrsId		=	'cstrRemitAdvcCstmrAddrsId';
Modules.CompIds.cstrRemitAdvcCstmrCityId		=	'cstrRemitAdvcCstmrCityId';
Modules.CompIds.cstrRemitAdvcCstmrStateId		=	'cstrRemitAdvcCstmrStateId';
Modules.CompIds.cstrRemitAdvcCstmrCntryId		=	'cstrRemitAdvcCstmrCntryId';
Modules.CompIds.cstrRemitAdvcPayDocId			=	'cstrRemitAdvcPayDocId';
Modules.CompIds.cstrRemitAdvcPayDocTypeId		=	'cstrRemitAdvcPayDocTypeId';
Modules.CompIds.cstrRemitAdvcPayDateId			=	'cstrRemitAdvcPayDateId';
Modules.CompIds.cstrRemitAdvcExtCurrencyId		=	'cstrRemitAdvcExtCurrencyId';
Modules.CompIds.cstrRemitAdvcTotalAmountId		=	'cstrRemitAdvcTotalAmountId';
Modules.CompIds.cstrRemitAdvcRemitTypeId		=	'cstrRemitAdvcRemitTypeId';



Modules.CompIds.covusInvoiceDtlsId='covusXmlInvoiceDtlId';
Modules.CompIds.covusInvoiceSubDtlsId='covusXmlInvoiceSubDtlsId';
Modules.CompIds.covusTaxDtlsId='covusXmlTaxDtlId';



Modules.CompIds.truckInvoiceMsgTypeId = 'truckInvoiceMsgTypeId';
Modules.CompIds.truckInvoicePartnrCdId = 'truckInvoicePartnrCdId';
Modules.CompIds.accRecPartnrCdId = 'accRecPartnrCdId';
Modules.CompIds.accRecMsgTypeId = 'accRecMsgTypeId';

/*-------------END of Customer Remittance Advice ----------*/


Modules.CompIds.covusXmlInterfaceMsgHdrId='covusXmlInterfaceMsgHdrId';
Modules.CompIds.covusXmlInterfaceMsgTypeId='covusXmlInterfaceMsgTypeId';
Modules.CompIds.covusXmlInterfacePartnrCdId='covusXmlInterfacePartnrCdId';
Modules.CompIds.covusXmlInterfaceExtCmpnyId='covusXmlInterfaceExtCmpnyId';
Modules.CompIds.covusXmlInterfaceInvcDate='covusXmlInterfaceInvcDate';
Modules.CompIds.covusXmlInterfaceCreditNoteInd='covusXmlInterfaceCreditNoteInd';
Modules.CompIds.covusXmlInterfaceExtCustmrCd='covusXmlInterfaceExtCustmrCd';
Modules.CompIds.covusXmlInterfaceInvcDueDt='covusXmlInterfaceInvcDueDt';
Modules.CompIds.covusXmlInterfaceInvcPrntTemp='covusXmlInterfaceInvcPrntTemp';
Modules.CompIds.covusXmlInterfaceProfitLossId='covusXmlInterfaceProfitLossId';
Modules.CompIds.covusXmlInterfacePrfStsId='covusXmlInterfacePrfStsId';
Modules.CompIds.covusXmlInterfaceTotalInvcAmtId='covusXmlInterfaceTotalInvcAmtId';
Modules.CompIds.covusXmlInterfaceFinCustmrId='covusXmlInterfaceFinCustmrId';
Modules.CompIds.covusXmlInterfaceRefInvoiceNumber='covusXmlInterfaceRefInvoiceNumber';
Modules.CompIds.covusXmlInterfaceTotalSrvcAmt='covusXmlInterfaceTotalSrvcAmt';
Modules.CompIds.covusXmlInterfaceInvoiceNumber='covusXmlInterfaceInvoiceNumber';
Modules.CompIds.covusXmlInterfacePrfEstmId='covusXmlInterfacePrfEstmId';
Modules.CompIds.covusXmlInterfaceTotalTaxAmtId='covusXmlInterfaceTotalTaxAmtId';
Modules.CompIds.covusXmlInterfaceDebtorPartyName='covusXmlInterfaceDebtorPartyName';
Modules.CompIds.covusXmlInterfaceCustDebtorPartyAddr1Id='covusXmlInterfaceCustDebtorPartyAddr1Id';


Modules.CompIds.covusXmlInterfaceDebtorPartyAddr2Id='covusXmlInterfaceDebtorPartyAddr2';
Modules.CompIds.covusXmlInterfaceDebtorCityId='covusXmlInterfaceDebtorCityId';
Modules.CompIds.covusXmlInterfaceTaxRefId='covusXmlInterfaceTaxRef';
Modules.CompIds.covusXmlInterfaceRemarks='covusXmlInterfaceRemarks';
Modules.CompIds.covusXmlInterfaceDebtorCdId='covusXmlInterfaceDebtorCdId';
Modules.CompIds.covusXmlInterfaceExtDebtorStateCdId='covusXmlInterfaceExtDebtorStateCdId';
Modules.CompIds.covusXmlInterfaceDebtorCountryId='covusXmlInterfaceDebtorCountryId';
Modules.CompIds.covusXmlInterfaceDebtorStateId='covusXmlInterfaceDebtorStateId';
Modules.CompIds.covusXmlInterfaceARAddrs1='covusXmlInterfaceARAddrs1';
Modules.CompIds.covusXmlInterfaceARAddrs2='covusXmlInterfaceARAddrs2';
Modules.CompIds.covusXmlInterfaceARCity='covusXmlInterfaceARCity';
Modules.CompIds.covusXmlInterfaceARState='covusXmlInterfaceARState';
Modules.CompIds.covusXmlInterfaceARCountry='covusXmlInterfaceARCountry';
Modules.CompIds.covusXmlInterfaceARPostal='covusXmlInterfaceARPostal';
Modules.CompIds.covusXmlInterfaceARFax='covusXmlInterfaceARFax';
Modules.CompIds.covusXmlInterfaceARTel='covusXmlInterfaceARTel';
Modules.CompIds.covusXmlInterfaceAREmail='covusXmlInterfaceAREmail';
Modules.CompIds.covusXmlInterfaceInvcCurrency='covusXmlInterfaceInvcCurrency';
Modules.CompIds.covusXmlInterfaceBillType='covusXmlInterfaceBillType';
Modules.CompIds.covusXmlInterfaceInvcCopies='covusXmlInterfaceInvcCopies';

/*-------------START of OutBound Customer Remittance Advice ----------*/


Modules.CompIds.covusInvcDtlParentId='covusInvcXmlDtlParentId';
Modules.CompIds.covusInvcSubDtlParentId='covusInvcXmlSubDtlParentId';
Modules.CompIds.covusTaxDtlParentId='covusXmlTaxDtlParentId';

Modules.CompIds.covusXmlInterfaceBackUpCopies='covusXmlInterfaceBackUpCopies';
Modules.CompIds.covusXmlInterfaceInvcPrinter='covusXmlInterfaceInvcPrinter';
Modules.CompIds.covusXmlInterfaceBackUpPrinter='covusXmlInterfaceBackUpPrinter';
Modules.CompIds.covusXmlInterfaceEmailAddrs='covusXmlInterfaceEmailAddrs';
Modules.CompIds.covusXmlInterfaceCCEmailAddr='covusXmlInterfaceCCEmailAddr';
Modules.CompIds.covusXmlInterfaceInvcReqFlg='covusXmlInterfaceInvcReqFlg';
Modules.CompIds.covusXmlInterfaceBackUpReqFlg='covusXmlInterfaceBackUpReqFlg';
Modules.CompIds.covusXmlInterfaceOriginalFlg='covusXmlInterfaceOriginalFlg';
Modules.CompIds.covusXmlInterfaceDebtorRemarks1='covusXmlInterfaceDebtorRemarks1';
Modules.CompIds.covusXmlInterfaceDebtorRemarks2='covusXmlInterfaceDebtorRemarks2';
Modules.CompIds.covusXmlInterfaceDebtorSubLedger='covusXmlInterfaceDebtorSubLedger';
Modules.CompIds.covusXmlInterfaceCustomerSubLedger='covusXmlInterfaceCustomerSubLedger';
Modules.CompIds.covusXmlInterfaceCompany='covusXmlInterfaceCompany';
Modules.CompIds.covusXmlInterfaceCustmr='covusXmlInterfaceCustmr';
Modules.CompIds.covusXmlInterfaceExtARState='covusXmlInterfaceExtARState';
Modules.CompIds.covusXmlInterfaceExtARCountry='covusXmlInterfaceExtARCountry';
Modules.CompIds.covusXmlInterfaceCompanyNm='covusXmlInterfaceCompanyNm';
Modules.CompIds.covusXmlInterfaceCustmrNm='covusXmlInterfaceCustmrNm';
Modules.CompIds.covusXmlInterfaceExtDebtorCountryCd='covusXmlInterfaceExtDebtorCountryCd';
Modules.CompIds.covusXmlInterfaceExtCustmrState='covusXmlInterfaceExtCustmrState';
Modules.CompIds.covusXmlInterfaceExtCustmrCountry='covusXmlInterfaceExtCustmrCountry';
Modules.CompIds.covusXmlInterfaceCustomerAddr1='covusXmlInterfaceCustomerAddr1';
Modules.CompIds.covusXmlInterfaceCustomerAddr2='covusXmlInterfaceCustomerAddr2';
Modules.CompIds.covusXmlInterfaceCustmrCity='covusXmlInterfaceCustmrCity';
Modules.CompIds.covusXmlInterfaceCustmrState='covusXmlInterfaceCustmrState';
Modules.CompIds.covusXmlInterfaceCustmrCountry='covusXmlInterfaceCustmrCountry';
Modules.CompIds.covusXmlInterfaceCustmrPostalCd='covusXmlInterfaceCustmrPostalCd';
Modules.CompIds.covusXmlInterfaceDebtorPostalCd='covusXmlInterfaceDebtorPostalCd';
Modules.CompIds.covusXmlInterfaceDebtorContactPrsnNm='covusXmlInterfaceDebtorContactPrsnNm';
Modules.CompIds.covusXmlInterfaceDebtorTaxRefNo='covusXmlInterfaceDebtorTaxRefNo';
Modules.CompIds.covusXmlInterfaceBackUpPrinterPath='covusXmlInterfaceBackUpPrinterPath';
Modules.CompIds.covusXmlInterfaceInvcPrinterPath='covusXmlInterfaceInvcPrinterPath';
Modules.CompIds.covusXmlInterfaceARContactPrsnNm='covusXmlInterfaceARContactPrsnNm';
Modules.CompIds.covusXmlInterfaceExtInvcCurr='covusXmlInterfaceExtInvcCurr';

/********************************* View Event Message*********************/
Modules.CompIds.eventMsgGridId='eventMessageGridId';
Modules.CompIds.eventMessageModalwindowFormid='eventMessageModalwindowFormid';

Modules.CompIds.evntMsgHdrId='EventMsgHdr';
Modules.CompIds.eventMsgExtCmpnyId='eventMsgExtCmpny';
Modules.CompIds.evntMsgExtSupplrCdId='evntMsgExtSupplrCdId';
Modules.CompIds.evntMsgExtSrvcCdId='evntMsgExtSrvcCdId';
Modules.CompIds.eventMsgSrvcTypeId='eventMsgSrvcType';
Modules.CompIds.evntMsgExtTransportModeId='evntMsgExtTransportModeId';
Modules.CompIds.evntMsgEventOrLoadRefId='evntMsgEventOrLoadRefId';
Modules.CompIds.workOrderId='workOrderId';
Modules.CompIds.eventMsgTransferSequenceNOId='eventMsgTransferSequenceNOId';
Modules.CompIds.eventMsgConveyanceId='eventMsgConveyanceId';

Modules.CompIds.evntMsgConveyanceNameId='evntMsgConveyanceNameId';
Modules.CompIds.evntMsgConsolidationId='evntMsgConsolidationId';
Modules.CompIds.evntMsgConsolidationTypeId='evntMsgConsolidationTypeId';
Modules.CompIds.evntMsgExtConsolidationTypeId='evntMsgExtConsolidationTypeId';
Modules.CompIds.evntMsgStatus='evntMsgStatus';
Modules.CompIds.eventMsgTenderDate='eventMsgTenderDate';
Modules.CompIds.eventMsgTenderDateEstFlg='eventMsgTenderDateEstFlg';
Modules.CompIds.evntMsgShipmentDate='evntMsgShipmentDate';
Modules.CompIds.ShipmentDateEstimatedFlgId='ShipmentDateEstimatedFlgId';
Modules.CompIds.evntMsgDeliveryDate='evntMsgDeliveryDate';

Modules.CompIds.DeliveryDateEstimatedFlgId='DeliveryDateEstimatedFlgId';
Modules.CompIds.ProfitLossCenterId='ProfitLossCenterId';
Modules.CompIds.NoOfUnitsId='NoOfUnitsId';
Modules.CompIds.MsgStatusIndicatorId='MsgStatusIndicatorId';
Modules.CompIds.ExtOriginId='ExtOriginId';
Modules.CompIds.ExtOriginStateProvinceId='ExtOriginStateProvinceId';
Modules.CompIds.ExtOriginCountryId='ExtOriginCountryId';
Modules.CompIds.ExtOriginalOriginId='ExtOriginalOriginId';


Modules.CompIds.ExtOriginalOriginStateProId='ExtOriginalOriginStateProId';
Modules.CompIds.ExtOriginalOriginCountryId='ExtOriginalOriginCountryId';
Modules.CompIds.OriginCityId='OriginCityId';
Modules.CompIds.OriginZIPPostalCodeId='OriginZIPPostalCodeId';
Modules.CompIds.OriginAddress1Id='OriginAddress1Id';
Modules.CompIds.OriginAddress2Id='OriginAddress2Id';
Modules.CompIds.OriginalOriginAddress1Id='OriginalOriginAddress1Id';
Modules.CompIds.OriginalOriginAddress2Id='OriginalOriginAddress2Id';
Modules.CompIds.OriginalOriginCityId='OriginalOriginCityId';
Modules.CompIds.OriginalOriginZIPPostalCodeId='OriginalOriginZIPPostalCodeId';




Modules.CompIds.outCstmrRemitAdvcWindowId			=	'outCstmrRemitAdvcWindowId';
Modules.CompIds.outCstmrRemitAdvcFormId				=	'outCstmrRemitAdvcFormId';
Modules.CompIds.outCstmrRemitAdvcGridId				=	'outCstmrRemitAdvcGridId';
Modules.CompIds.outCstmrRemitAdvcMsgHdrId			=	'outCstmrRemitAdvcMsgHdrId';
Modules.CompIds.outCstmrRemitAdvcExtCompanyId		=	'outCstmrRemitAdvcExtCompanyId';
Modules.CompIds.outCstmrRemitAdvcCompanyCodeId		=	'outCstmrRemitAdvcCompanyCodeId';
Modules.CompIds.outCstmrRemitAdvcCompanyNameId		=	'outCstmrRemitAdvcCompanyNameId';
Modules.CompIds.outCstmrRemitAdvcExtCstmrCodeId		=	'outCstmrRemitAdvcExtCstmrCodeId';
Modules.CompIds.outCstmrRemitAdvcCstmrNameId		=	'outCstmrRemitAdvcCstmrNameId';
Modules.CompIds.outCstmrRemitAdvcCstmrCodeId		=	'outCstmrRemitAdvcCstmrCodeId';
Modules.CompIds.outCstmrRemitAdvcPayDocNoId			=	'outCstmrRemitAdvcPayDocNoId';
Modules.CompIds.outCstmrRemitAdvcPayDocTypeId		=	'outCstmrRemitAdvcPayDocTypeId';
Modules.CompIds.outCstmrRemitAdvcPayDateId			=	'outCstmrRemitAdvcPayDateId';
Modules.CompIds.outCstmrRemitAdvcRemitTypeId		=	'outCstmrRemitAdvcRemitTypeId';
Modules.CompIds.outCstmrRemitAdvcInvoiceAmountId	=	'outCstmrRemitAdvcInvoiceAmountId';
Modules.CompIds.outCstmrRemitAdvcCurrencyId			=	'outCstmrRemitAdvcCurrencyId';
Modules.CompIds.outCstmrRemitAdvcExtInvcCurrencyId	=	'outCstmrRemitAdvcExtInvcCurrencyId';

/*-------------END of OutBound Customer Remittance Advice ----------*/


/*******************Ocean View Covus XML Interface***************************/

Modules.CompIds.oceanCovusXmlWindowId = 'oceanCovusXmlWindowId';
Modules.CompIds.oceanCovusXmlInterfaceTabPanelId = 'oceanCovusXmlInterfaceTabPanelId';

Modules.CompIds.oceanCovusXmlInterfaceMsgHdrId= 'oceanCovusXmlInterfaceMsgHdrId';
Modules.CompIds.oceanCovusXmlInterfaceMsgTypeId = 'oceanCovusXmlInterfaceMsgTypeId';
Modules.CompIds.oceanCovusXmlInterfaceCompanyCdId = 'oceanCovusXmlInterfaceCompanyCdId';
Modules.CompIds.oceanCovusXmlInterfaceCompanyNmId = 'oceanCovusXmlInterfaceCompanyNmId';
Modules.CompIds.oceanCovusXmlInterfaceInvcDateId = 'oceanCovusXmlInterfaceInvcDateId';
Modules.CompIds.oceanCovusXmlInterfaceInvcDueDateId = 'oceanCovusXmlInterfaceInvcDueDateId';
Modules.CompIds.oceanCovusXmlInterfaceInvcCrdNoteIndId= 'oceanCovusXmlInterfaceInvcCrdNoteIndId';
Modules.CompIds.oceanCovusXmlInterfaceProfitLossId = 'oceanCovusXmlInterfaceProfitLossId';
Modules.CompIds.oceanCovusXmlInterfaceInvcPrintTemplateId = 'oceanCovusXmlInterfaceInvcPrintTemplateId';
Modules.CompIds.oceanCovusXmlInterfacePerformaEstmdIndId = 'oceanCovusXmlInterfacePerformaEstmdIndId';
Modules.CompIds.oceanCovusXmlInterfacePerformaStsId = 'oceanCovusXmlInterfacePerformaStsId';
Modules.CompIds.oceanCovusXmlInterfaceRefInvcNbrId = 'oceanCovusXmlInterfaceRefInvcNbrId';

Modules.CompIds.oceanCovusXmlInterfaceInvcReqFlgId = 'oceanCovusXmlInterfaceInvcReqFlgId';
Modules.CompIds.oceanCovusXmlInterfaceProformaInvcNbrId = 'oceanCovusXmlInterfaceProformaInvcNbrId';
Modules.CompIds.oceanCovusXmlInterfaceExtProformaInvcNbrId = 'oceanCovusXmlInterfaceExtProformaInvcNbrId';
Modules.CompIds.oceanCovusXmlInterfacePopCdId = 'oceanCovusXmlInterfacePopCdId';
Modules.CompIds.oceanCovusXmlInterfaceRemarkId = 'oceanCovusXmlInterfaceRemarkId';
Modules.CompIds.oceanCovusXmlInterfaceCustomerCodeId = 'oceanCovusXmlInterfaceCustomerCodeId';
Modules.CompIds.oceanCovusXmlInterfaceCustomerNmId = 'oceanCovusXmlInterfaceCustomerNmId';
Modules.CompIds.oceanCovusXmlInterfaceCustomerTypeId = 'oceanCovusXmlInterfaceCustomerTypeId';
Modules.CompIds.oceanCovusXmlInterfaceCustomerAddrss1Id = 'oceanCovusXmlInterfaceCustomerAddrss1Id';
Modules.CompIds.oceanCovusXmlInterfaceCustomerAddrss2Id = 'oceanCovusXmlInterfaceCustomerAddrss2Id';
Modules.CompIds.oceanCovusXmlInterfaceCustomerAddrss3Id = 'oceanCovusXmlInterfaceCustomerAddrss3Id';
Modules.CompIds.oceanCovusXmlInterfaceCustomerCityFormId = 'oceanCovusXmlInterfaceCustomerCityFormId';

Modules.CompIds.oceanCovusXmlInterfaceCstmrRegionCdId = 'oceanCovusXmlInterfaceCstmrRegionCdId';
Modules.CompIds.oceanCovusXmlInterfaceCstmrStateCdId = 'oceanCovusXmlInterfaceCstmrStateCdId';
Modules.CompIds.oceanCovusXmlInterfaceCstmrCountryCdId = 'oceanCovusXmlInterfaceCstmrCountryCdId';
Modules.CompIds.oceanCovusXmlInterfaceCstmrPoBoxId = 'oceanCovusXmlInterfaceCstmrPoBoxId';
Modules.CompIds.oceanCovusXmlInterfaceCstmrVatNbrId = 'oceanCovusXmlInterfaceCstmrVatNbrId';
Modules.CompIds.oceanCovusXmlInterfaceCstmrContactPrsnId = 'oceanCovusXmlInterfaceCstmrContactPrsnId';
Modules.CompIds.oceanCovusXmlInterfaceArAddrss1Id= 'oceanCovusXmlInterfaceArAddrss1Id';
Modules.CompIds.oceanCovusXmlInterfaceArAddrss2Id = 'oceanCovusXmlInterfaceArAddrss2Id';
Modules.CompIds.oceanCovusXmlInterfaceARCityNmId = 'oceanCovusXmlInterfaceARCityNmId';
Modules.CompIds.oceanCovusXmlInterfaceARStateCdId= 'oceanCovusXmlInterfaceARStateCdId';
Modules.CompIds.oceanCovusXmlInterfaceARCountryCdId = 'oceanCovusXmlInterfaceARCountryCdId';
Modules.CompIds.oceanCovusXmlInterfaceARContactPrsnId = 'oceanCovusXmlInterfaceARContactPrsnId';
Modules.CompIds.oceanCovusXmlInterfaceARTelNbrId = 'oceanCovusXmlInterfaceARTelNbrId';
Modules.CompIds.oceanCovusXmlInterfaceARFaxbrId = 'oceanCovusXmlInterfaceARFaxbrId';
Modules.CompIds.oceanCovusXmlInterfaceAREmailId = 'oceanCovusXmlInterfaceAREmailId';

Modules.CompIds.oceanCovusXmlInterfaceInvcCopyCountId = 'oceanCovusXmlInterfaceInvcCopyCountId';
Modules.CompIds.oceanCovusXmlInterfaceBackupRqrdFlgId = 'oceanCovusXmlInterfaceBackupRqrdFlgId';
Modules.CompIds.oceanCovusXmlInterfaceBackupCopyCountId = 'oceanCovusXmlInterfaceBackupCopyCountId';
Modules.CompIds.oceanCovusXmlInterfaceInvcPrinterId = 'oceanCovusXmlInterfaceInvcPrinterId';
Modules.CompIds.oceanCovusXmlInterfacebackupPrinterId = 'oceanCovusXmlInterfacebackupPrinterId';
Modules.CompIds.oceanCovusXmlInterfaceEmailAddressId = 'oceanCovusXmlInterfaceEmailAddressId';
Modules.CompIds.oceanCovusXmlInterfaceCcEmailAddressId = 'oceanCovusXmlInterfaceCcEmailAddressId';
Modules.CompIds.oceanCovusXmlInterfaceOrgFlg = 'oceanCovusXmlInterfaceOrgFlg';
Modules.CompIds.oceanCovusXmlInterfaceInvcPrinterCnfgPathId = 'oceanCovusXmlInterfaceInvcPrinterCnfgPathId';
Modules.CompIds.oceanCovusXmlInterfaceBckpPrinterCnfgPathId = 'oceanCovusXmlInterfaceBckpPrinterCnfgPathId';
Modules.CompIds.oceanCovusXmlInterfaceTotalInvcAmtManifestCurrId = 'oceanCovusXmlInterfaceTotalInvcAmtManifestCurrId';
Modules.CompIds.oceanCovusXmlInterfaceManifestCurrId = 'oceanCovusXmlInterfaceManifestCurrId';
Modules.CompIds.oceanCovusXmlInterfaceLocalAmtCurrencyId ='oceanCovusXmlInterfaceLocalAmtCurrencyId';
Modules.CompIds.oceanCovusXmlInterfaceInvcCurrCdId ='oceanCovusXmlInterfaceInvcCurrCdId';
Modules.CompIds.oceanCovusXmlInterfaceExchangeRateId ='oceanCovusXmlInterfaceExchangeRateId';
Modules.CompIds.oceanCovusXmlInterfaceInvcAmtUSDCurrId = 'oceanCovusXmlInterfaceInvcAmtUSDCurrId';

Modules.CompIds.oceanCovusXmlInterfaceInvcEmailAddressId = 'oceanCovusXmlInterfaceInvcEmailAddressId';
Modules.CompIds.oceanCovusXmlInterfaceMailingAddress1Id = 'oceanCovusXmlInterfaceMailingAddress1Id';
Modules.CompIds.oceanCovusXmlInterfaceMailingAddress2Id = 'oceanCovusXmlInterfaceMailingAddress2Id';
Modules.CompIds.oceanCovusXmlInterfaceMailingAddress3Id = 'oceanCovusXmlInterfaceMailingAddress3Id';
Modules.CompIds.oceanCovusXmlInterfaceMailingCityNm = 'oceanCovusXmlInterfaceMailingCityNm';
Modules.CompIds.oceanCovusXmlInterfaceMailingStateCd = 'oceanCovusXmlInterfaceMailingStateCd';
Modules.CompIds.oceanCovusXmlInterfaceMailingPoBox = 'oceanCovusXmlInterfaceMailingPoBox';
Modules.CompIds.oceanCovusXmlInterfaceMailingCountryCd = 'oceanCovusXmlInterfaceMailingCountryCd';

Modules.CompIds.ocnCovusXmlBankDtlsId = 'ocnCovusXmlBankDtlsId';
Modules.CompIds.ocnCovusXmlBankDtlTabPanelId = 'ocnCovusXmlBankDtlTabPanelId';
Modules.CompIds.ocnCovusXmlBLHdrDtlsId   =  'ocnCovusXmlBLHdrDtlsId';
Modules.CompIds.ocnCovusXmlBLHdrTabPanelId = 'ocnCovusXmlBLHdrTabPanelId';
Modules.CompIds.ocnCovusXmlManifestAmtDtlsId = 'ocnCovusXmlManifestAmtDtlsId';
Modules.CompIds.ocnCovusXmlManifestAmtTabPanelId = 'ocnCovusXmlManifestAmtTabPanelId';
Modules.CompIds.oceanCovusXmlInterfaceBlHdrTabPanelId = 'oceanCovusXmlInterfaceBlHdrTabPanelId';
Modules.CompIds.ocnCovusXmlInvcDtlsId = 'ocnCovusXmlInvcDtlsId';
Modules.CompIds.ocnCovusXmlInvcSubDtlsId = 'ocnCovusXmlInvcSubDtlsId';
Modules.CompIds.ocnCovusXmlCargoDtlsTabPanelId = 'ocnCovusXmlCargoDtlsTabPanelId';
Modules.CompIds.ocnCovusXmlTaxDtlsTabPanelId = 'ocnCovusXmlTaxDtlsTabPanelId';
Modules.CompIds.ocnCovusXmlInvcDtlsTabPanelId = 'ocnCovusXmlInvcDtlsTabPanelId';
Modules.CompIds.ocnCovusXmlSubInvcDtlsTabPanelId = 'ocnCovusXmlSubInvcDtlsTabPanelId';
Modules.CompIds.ocnCovusXmlCargoDtlsId = 'ocnCovusXmlCargoDtlsId';
Modules.CompIds.ocnCovusXmlTaxDtlsId = 'ocnCovusXmlTaxDtlsId';
Modules.CompIds.ocenaCovusXmlInterfaceId = 'ocenaCovusXmlInterfaceId';


/****************************End Ocean View Covus XML *********************/



/************************ Ocean Event Message View Screen*******************/

Modules.CompIds.ocnEventMessageViewFormid = 'ocnEventMessageViewFormid';
Modules.CompIds.ocnEventMsgGridId         = 'ocnEventMsgGridId';
Modules.CompIds.ocnEventMsgType = 'ocnEventMsgType';
Modules.CompIds.ocnEvntMsgHdrId = 'ocnEvntMsgHdrId';
Modules.CompIds.ocnEventMsgCompanyId = 'ocnEventMsgCompanyId';
Modules.CompIds.ocnEventMsgSupplierId = 'ocnEventMsgSupplierId';
Modules.CompIds.ocnEventMsgBillNbrId = 'ocnEventMsgBillNbrId';
Modules.CompIds.ocnEventMsgVesselCdId = 'ocnEventMsgVesselCdId';
Modules.CompIds.ocnEventMsgVesselNmId = 'ocnEventMsgVesselNmId';
Modules.CompIds.ocnEventMsgblCmpFlagId = 'ocnEventMsgblCmpFlagId';
Modules.CompIds.ocnEventMsgVoyageNbrId = 'ocnEventMsgVoyageNbrId';
Modules.CompIds.ocnEventMsgshipmentRefNoId = 'ocnEventMsgshipmentRefNoId';
Modules.CompIds.ocnEventMsgCtrlNbrId = 'ocnEventMsgCtrlNbrId';
Modules.CompIds.ocnEventTransTypeId = 'ocnEventTransTypeId';
Modules.CompIds.ocnEventBillofLadingTypeId = 'ocnEventBillofLadingTypeId';
Modules.CompIds.ocnEventMsgBillOfIssueDtId = 'ocnEventMsgBillOfIssueDtId';
Modules.CompIds.ocnEventMsgProfitLossCenterId = 'ocnEventMsgProfitLossCenterId';
Modules.CompIds.ocnEventMsgNbrOfUnitsId = 'ocnEventMsgNbrOfUnitsId';
Modules.CompIds.ocnEventMsgStsIndId = 'ocnEventMsgStsIndId';

Modules.CompIds.ocnEventMsgPodCodeId = 'ocnEventMsgPodCodeId';
Modules.CompIds.ocnEventMsgPodDescId = 'ocnEventMsgPodDescId';
Modules.CompIds.ocnEventMsgPodAddrsId = 'ocnEventMsgPodAddrsId';
Modules.CompIds.ocnEventMsgPodAddrs2Id = 'ocnEventMsgPodAddrs2Id';
Modules.CompIds.ocnEventMsgPodCityId = 'ocnEventMsgPodCityId';
Modules.CompIds.ocnEventMsgPodStateId = 'ocnEventMsgPodStateId';
Modules.CompIds.ocnEventMsgPodCountryId = 'ocnEventMsgPodCountryId';
Modules.CompIds.ocnEventMsgPodPostalCodeId = 'ocnEventMsgPodPostalCodeId';
Modules.CompIds.ocnEventMsgPodBerthCodeId = 'ocnEventMsgPodBerthCodeId';
Modules.CompIds.ocnEventMsgPodPortCallId  = 'ocnEventMsgPodPortCallId';

Modules.CompIds.ocnEventMsgPorCodeId = 'ocnEventMsgPorCodeId';
Modules.CompIds.ocnEventMsgPorDescId = 'ocnEventMsgPorDescId';
Modules.CompIds.ocnEventMsgPorAddress1Id = 'ocnEventMsgPorAddrsId';
Modules.CompIds.ocnEventMsgPorAddress2Id = 'ocnEventMsgPorAddrs2Id';
Modules.CompIds.ocnEventMsgPorCityId = 'ocnEventMsgPorCityId';
Modules.CompIds.ocnEventMsgPorStateId = 'ocnEventMsgPorStateId';
Modules.CompIds.ocnEventMsgPorCountryId = 'ocnEventMsgPorCountryId';
Modules.CompIds.ocnEventMsgPorPostalCodeId = 'ocnEventMsgPorPostalCodeId';
Modules.CompIds.ocnEventMsgPorBerthCodeId = 'ocnEventMsgPorBerthCodeId';
Modules.CompIds.ocnEventMsgPorPortCallId  = 'ocnEventMsgPorPortCallId';

Modules.CompIds.ocnEventMsgPolCodeId = 'ocnEventMsgPolCodeId';
Modules.CompIds.ocnEventMsgPolDescId = 'ocnEventMsgPolDescId';
Modules.CompIds.ocnEventMsgPolAddress1Id = 'ocnEventMsgPolAddrsId';
Modules.CompIds.ocnEventMsgPolAddress2Id = 'ocnEventMsgPolAddrs2Id';
Modules.CompIds.ocnEventMsgPolCityId = 'ocnEventMsgPolCityId';
Modules.CompIds.ocnEventMsgPolStateId = 'ocnEventMsgPolStateId';
Modules.CompIds.ocnEventMsgPolCountryId = 'ocnEventMsgPolCountryId';
Modules.CompIds.ocnEventMsgPolPostalCodeId = 'ocnEventMsgPolPostalCodeId';
Modules.CompIds.ocnEventMsgPolBerthCodeId = 'ocnEventMsgPolBerthCodeId';
Modules.CompIds.ocnEventMsgPolPortCallId  = 'ocnEventMsgPolPortCallId';

Modules.CompIds.ocnEventMsgPfdCodeId = 'ocnEventMsgPfdCodeId';
Modules.CompIds.ocnEventMsgPfdDescId = 'ocnEventMsgPfdDescId';
Modules.CompIds.ocnEventMsgPfdAddress1Id = 'ocnEventMsgPfdAddrsId';
Modules.CompIds.ocnEventMsgPfdAddress2Id = 'ocnEventMsgPfdAddrs2Id';
Modules.CompIds.ocnEventMsgPfdCityId = 'ocnEventMsgPfdCityId';
Modules.CompIds.ocnEventMsgPfdStateId = 'ocnEventMsgPfdStateId';
Modules.CompIds.ocnEventMsgPfdCountryId = 'ocnEventMsgPfdCountryId';
Modules.CompIds.ocnEventMsgPfdPostalCodeId = 'ocnEventMsgPfdPostalCodeId';
Modules.CompIds.ocnEventMsgPfdBerthCodeId = 'ocnEventMsgPfdBerthCodeId';
Modules.CompIds.ocnEventMsgPfdPortCallId  = 'ocnEventMsgPfdPortCallId';



/*-------------START of OutBound Supplier Remittance Advice ----------*/

Modules.CompIds.outSupplRemitAdvcWindowId			=	'outSupplRemitAdvcWindowId';
Modules.CompIds.outSupplRemitAdvcFormId				=	'outSupplRemitAdvcFormId';
Modules.CompIds.outSupplRemitAdvcGridId				=	'outSupplRemitAdvcGridId';
Modules.CompIds.outSupplRemitAdvcDtlsGridId			=	'outSupplRemitAdvcDtlsGridId';
Modules.CompIds.outSupplRemitAdvcMsgHdrId			=	'outSupplRemitAdvcMsgHdrId';
Modules.CompIds.outSupplRemitAdvcMsgTypeId			=	'outSupplRemitAdvcMsgTypeId';
Modules.CompIds.outSupplRemitAdvcPartnrCdId			=	'outSupplRemitAdvcPartnrCdId';

Modules.CompIds.outSupplRemitAdvcExtCmpnyId			=	'outSupplRemitAdvcExtCmpnyId';
Modules.CompIds.outSupplRemitAdvcCompanyCodeId		=	'outSupplRemitAdvcCompanyCodeId';
Modules.CompIds.outSupplRemitAdvcCompanyNameId		=	'outSupplRemitAdvcCompanyNameId';
Modules.CompIds.outSupplRemitAdvcApCmpAddrLine1Id	=	'outSupplRemitAdvcApCmpAddrLine1Id';
Modules.CompIds.outSupplRemitAdvcApCmpAddrLine2Id	=	'outSupplRemitAdvcApCmpAddrLine2Id';
Modules.CompIds.outSupplRemitAdvcApCmpCityNameId	=	'outSupplRemitAdvcApCmpCityNameId';
Modules.CompIds.outSupplRemitAdvcApCmpStatProvId	=	'outSupplRemitAdvcApCmpStatProvId';
Modules.CompIds.outSupplRemitAdvcApCmpCountryId		=	'outSupplRemitAdvcApCmpCountryId';
Modules.CompIds.outSupplRemitAdvcApCmpZipPostalCodeId =	'outSupplRemitAdvcApCmpZipPostalCodeId';
Modules.CompIds.outSupplRemitAdvcExtApCmpStatProvId	=	'outSupplRemitAdvcExtApCmpStatProvId';

Modules.CompIds.outSupplRemitAdvcExtApCmpCountryId	=	'outSupplRemitAdvcExtApCmpCountryId';
Modules.CompIds.outSupplRemitAdvcSupplierCodeId	    =	'outSupplRemitAdvcSupplierCodeId';
Modules.CompIds.outSupplRemitAdvcExtSupplierCodeId	=	'outSupplRemitAdvcExtSupplierCodeId';
Modules.CompIds.outSupplRemitAdvcSupplierNameId	    =	'outSupplRemitAdvcSupplierNameId';
Modules.CompIds.outSupplRemitAdvcSupplierAddr1Id	=	'outSupplRemitAdvcSupplierAddr1Id';
Modules.CompIds.outSupplRemitAdvceSupplierAddr2Id	=	'outSupplRemitAdvceSupplierAddr2Id';
Modules.CompIds.outSupplRemitAdvcSupplierCityId	    =	'outSupplRemitAdvcSupplierCityId';
Modules.CompIds.outSupplRemitAdvcSupplierStateId	=	'outSupplRemitAdvcSupplierStateId';
Modules.CompIds.outSupplRemitAdvcSupplierCountryId	=	'outSupplRemitAdvcSupplierCountryId';
Modules.CompIds.outSupplRemitAdvcSupplierZipCodeId	=	'outSupplRemitAdvcSupplierZipCodeId';

Modules.CompIds.outSupplRemitAdvcExtSupplierCountryId   =	'outSupplRemitAdvcExtSupplierCountry';
Modules.CompIds.outSupplRemitAdvceExtSupplierStateId    =	'outSupplRemitAdvceExtSupplierState';
Modules.CompIds.outSupplRemitAdvcApContactPersonNameId	=	'outSupplRemitAdvcApContactPersonName';
Modules.CompIds.outSupplRemitAdvceInvoiceApPhoneId	    =	'outSupplRemitAdvceInvoiceApPhone';
Modules.CompIds.outSupplRemitAdvcContactPersonNameId	=	'outSupplRemitAdvcContactPersonName';
Modules.CompIds.outSupplRemitAdvcSupplierPhoneId	    =	'outSupplRemitAdvcSupplierPhone';
Modules.CompIds.outSupplrRemitAdvcPayDocNoId	        =	'outSupplrRemitAdvcPayDocNo';
Modules.CompIds.outSupplrRemitAdvcPayDocTypeId	        =	'outSupplrRemitAdvcPayDocType';
Modules.CompIds.outSupplrRemitAdvcPayDateId	            =	'outSupplrRemitAdvcPayDateId';
Modules.CompIds.outSupplrRemitAdvcInvoiceAmountId	    =	'outSupplrRemitAdvcInvoiceAmount';
Modules.CompIds.outSupplrRemitAdvcCurrencyId	        =	'outSupplrRemitAdvcCurrency';
Modules.CompIds.outSupplrRemitExtInvcCurrencyId	        =	'outSupplrRemitExtInvcCurrency';



/*-------------END of OutBound Supplier Remittance Advice ----------*/

/*----------------Service Master--------------------------*/
Modules.CompIds.srvcMasterPanel='ServiceMasterParentPanelId';
Modules.CompIds.SrvcMasterGrid='ServiceMasterGridId';
Modules.CompIds.srvcMasterClearId='ServiceMasterClearId';
Modules.CompIds.srvcMsterFormId='ServiceMasterFormId';
Modules.CompIds.excelExportReportId='excelExportReportId';
Modules.CompIds.excelImportReportId='excelImportReportId';
Modules.CompIds.srvcMasterAddRecordId='srvcMasterAddRecordId';
Modules.CompIds.srvcMasterdeleteRecordId='srvcMasterdeleteRecordId';

/*-----------------------Tariff Master------------------*/
Modules.CompIds.tariffMasterPanel='TariffMasterId';
Modules.CompIds.TariffMasterGrid='TariffMasterGridId';
Modules.CompIds.tariffMasterPanel='TariffMasterTabParentId';



Modules.CompIds.srvcMsterUploadFormId='srvcMsterUploadFormId';
Modules.CompIds.srvcMAsterTemplateId='srvcMAsterTemplateNm';
Modules.CompIds.srvcMAsterFileNmId='srvcMasterFileNmId';


Modules.CompIds.auditExceptionId='auditExceptionGridId';
Modules.CompIds.auditExceptionWindowId='auditExceptionWindowId';
Modules.CompIds.auditExceptionFormId='auditExceptionFormId';
Modules.CompIds.auditExceptionClearId='auditExceptionClearId';
Modules.CompIds.auditExceptionSaveId='auditExceptionSaveId';
Modules.CompIds.auditExceptionTimeIntvlId='auditExceptionTimeIntvlId';
Modules.CompIds.auditExcepMsgTypeId='auditExcepMsgTypeId';






Modules.CompIds.editPartnerFormId='editPartnerFormId';
Modules.CompIds.partnerWinId='partnerWinId';




/*----------------------View Customer Invoice--------------------------------*/
Modules.CompIds.cstmrInvcTaxDtlParentId='CustomerInvoiceTaxParentId';
Modules.CompIds.cstmrInvcDtlParentId='CustomerInvoiceParentDtls';
Modules.CompIds.cstmrInvcTabPanelId='CustomerInvoiceTabPanelId';

/*------------------------View OutSupplier Remittance---------------*/
Modules.CompIds.OutSupplrRemitPayParentId='OutSupplierRemitUnitParentId';
Modules.CompIds.OutSupplrRemitParentId='OutSupplrRemitParntDtlsId';
Modules.CompIds.outSupplrRemitTabPanelId='outSupplrRemitTabPanelId';


Modules.CompIds.viewSupplierInvStatGridId='viewSupplierInvStatGridId';
Modules.CompIds.viewSupplierInvWinObjId='viewSupplierInvWinObjId';
Modules.CompIds.viewSupplierReconWinObjId='viewSupplierReconWinObjId';
Modules.CompIds.viewSupplierReconStatGridId='viewSupplierReconStatGridId';
Modules.CompIds.viewCustomerReconStatGridOneId='viewCustomerReconStatGridOneId';
Modules.CompIds.viewCustomerReconWinObjOneId='viewCustomerReconWinObjOneId';
Modules.CompIds.viewCustomerReconStatGridTwoId='viewCustomerReconStatGridTwoId';
Modules.CompIds.viewCustomerReconWinObjTwoId='viewCustomerReconWinObjTwoId';
Modules.CompIds.viewCustomerInvStatGridId='viewCustomerInvStatGridId';
Modules.CompIds.viewSpclMovesStatusWinObjId='viewSpclMovesStatusWinObjId';
Modules.CompIds.viewSpclMovesStatusGridId='viewSpclMovesStatusGridId';
Modules.CompIds.viewOceanSupplierInvStatGridId='viewOceanSupplierInvStatGridId';
Modules.CompIds.viewOceanCustomerInvStatGridId='viewOceanCustomerInvStatGridId';
Modules.CompIds.viewOceanCustomerInvcWinObjOneId='viewOceanCustomerInvcWinObjOneId';
Modules.CompIds.viewOceanSupplierInvWinObjId='viewOceanSupplierInvWinObjId';
Modules.CompIds.viewOceanSupplierReconStatGridId='viewOceanSupplierReconStatGridId';
Modules.CompIds.viewOceanSupplierReconWinObjId='viewOceanSupplierReconWinObjId';
Modules.CompIds.serviceTypeId='serviceTypeId';
Modules.CompIds.supplierId='supplierId';
Modules.CompIds.customerId='customerId';
Modules.CompIds.serviceCodeId='serviceCodeId';
Modules.CompIds.makeId='makeId';
Modules.CompIds.modelId='modelId';
Modules.CompIds.modelGroupId='modelGroupId';
Modules.CompIds.transportModeId='transportModeId';
Modules.CompIds.eventDateId='eventDateId';
Modules.CompIds.consolidationTypeId='consolidationTypeId';
Modules.CompIds.originId='originId';
Modules.CompIds.originStateProvinceId='originStateProvinceId';
Modules.CompIds.destinationId='destinationId';
Modules.CompIds.eventStatusQueryDestinationId='eventStatusQueryDestinationId';
Modules.CompIds.destinationStateProvinceId='destinationStateProvinceId';
Modules.CompIds.dealerCodeId='dealerCodeId';
Modules.CompIds.orderTypeId='orderTypeId';
Modules.CompIds.shipmentTypeId='shipmentTypeId';
Modules.CompIds.abnormalMoveTypeId='abnormalMoveTypeId';
Modules.CompIds.profitLossCenterId='profitLossCenterId';
Modules.CompIds.conveyanceTypeId='conveyanceTypeId';
Modules.CompIds.unitId='unitId';
Modules.CompIds.fromDateId='fromDateId';
Modules.CompIds.toDateId='toDateId';
Modules.CompIds.consolidationId='consolidationId';
Modules.CompIds.eventLoadReferenceId='eventLoadReferenceId';
Modules.CompIds.shippingReferenceId='shippingReferenceId';
Modules.CompIds.originCityId='originCityId';
Modules.CompIds.destinationCityId='destinationCityId';
Modules.CompIds.transportCodeId='transportCodeId';
Modules.CompIds.workOrderId='workOrderId';
Modules.CompIds.conveyanceNameId='conveyanceNameId';
Modules.CompIds.conveyanceId='conveyanceId';
Modules.CompIds.blankId='blankId';
Modules.CompIds.eventStatusQueryFormId='eventStatusQueryFormId',
Modules.CompIds.eventStatusQueryGridId='eventStatusQueryGridId',
Modules.CompIds.queryGridModelId='queryGridModelId',
Modules.CompIds.queryGridOrderTypeId='queryGridOrderTypeId',
Modules.CompIds.eventRatingQueryMakeId='eventRatingQueryMakeId',
Modules.CompIds.queryGridModelGroupId='queryGridModelGroupId',
Modules.CompIds.queryModelGroupId='queryModelGroupId',
Modules.CompIds.queryGridConveyanceTypeId='queryGridConveyanceTypeId',
Modules.CompIds.queryConveyanceTypeId='queryConveyanceTypeId',
Modules.CompIds.queryGridShipmentTypeId='queryGridShipmentTypeId',
Modules.CompIds.queryShipmentTypeId='queryShipmentTypeId',
Modules.CompIds.queryGridOriginalOriginId='queryGridOriginalOriginId',
Modules.CompIds.queryOriginalOriginId='queryOriginalOriginId',
Modules.CompIds.queryGridFinalDestinationId='queryGridFinalDestinationId',
Modules.CompIds.queryFinalDestinationId='queryFinalDestinationId',
Modules.CompIds.queryGridPrevChargeUOMId='queryGridPrevChargeUOMId',
Modules.CompIds.queryPrevChargeUOMId='queryPrevChargeUOMId',
Modules.CompIds.queryGridPartNumberId='queryGridPartNumberId',
Modules.CompIds.queryPartNumberId='queryPartNumberId',
Modules.CompIds.queryGridStorageUOMId='queryGridStorageUOMId',
Modules.CompIds.queryStorageUOMId='queryStorageUOMId',
Modules.CompIds.queryGridCstmrSalesRgnId='queryGridCstmrSalesRgnId',
Modules.CompIds.queryCstmrSalesRgnId='queryCstmrSalesRgnId',
Modules.CompIds.queryGridProfitLossCenterId='queryGridProfitLossCenterId',
Modules.CompIds.queryProfitLossCenterId='queryProfitLossCenterId',
Modules.CompIds.eventQueryDeleteBtnId='eventQueryDeleteBtnId',
Modules.CompIds.eventQuerySaveBtnId='eventQuerySaveBtnId',
Modules.CompIds.eventQueryCopyBtnId='eventQueryCopyBtnId',
Modules.CompIds.eventQueryPasteBtnId='eventQueryPasteBtnId',
Modules.CompIds.queyGridSupplierId='queyGridSupplierId',
Modules.CompIds.querySupplierId='querySupplierId',
Modules.CompIds.queryGridCustomerId='queryGridCustomerId',
Modules.CompIds.queryCustomerId='queryCustomerId',
Modules.CompIds.queryGridDestinationId='queryGridDestinationId',
Modules.CompIds.queryDestinationId='queryDestinationId',
Modules.CompIds.queryGridDealerCodeId='queryGridDealerCodeId',
Modules.CompIds.queryDealerCodeId='queryDealerCodeId',
Modules.CompIds.queryGridMakeId='queryGridMakeId',
Modules.CompIds.queryMakeId='queryMakeId',
Modules.CompIds.queryModelId='queryModelId',
Modules.CompIds.queryGridTransportModeId='queryGridTransportModeId',
Modules.CompIds.queryTransportModeId='queryTransportModeId',
Modules.CompIds.queryGridConsolidationTypeId='queryGridConsolidationTypeId',
Modules.CompIds.queryConsolidationTypeId='queryConsolidationTypeId',
Modules.CompIds.queryOrderTypeId='queryOrderTypeId',
Modules.CompIds.queryGridAbnormalMoveTypeId='queryGridAbnormalMoveTypeId',
Modules.CompIds.queryAbnormalMoveTypeId='queryAbnormalMoveTypeId',
Modules.CompIds.queryGridDestinationStateProvinceId='queryGridDestinationStateProvinceId',
Modules.CompIds.queryDestinationStateProvinceId='queryDestinationStateProvinceId',
Modules.CompIds.eventStatusQueryCopyFormId='eventStatusQueryCopyFormId',
Modules.CompIds.eventStatusQueryGridPasteId='eventStatusQueryGridPasteId',
Modules.CompIds.eventStatusCopyWinObj='eventStatusCopyWinObj',
Modules.CompIds.evntStsQryAdvContainer='evntStsQryAdvContainer',
Modules.CompIds.eventQueryViewSaveBtnId='eventQueryViewSaveBtnId',
Modules.CompIds.viewEventStatusWinObjId='viewEventStatusWinObjId',

Modules.CompIds.popCopySupplierId='popCopySupplierId',
Modules.CompIds.popCopyCustomerId='popCopyCustomerId',
Modules.CompIds.popCopyShippingReferenceId='popCopyShippingReferenceId',
Modules.CompIds.popCopyDestinationId='popCopyDestinationId',
Modules.CompIds.popCopyDealerCodeId='popCopyDealerCodeId',
Modules.CompIds.popCopyTenderRequestDateId='popCopyTenderRequestDateId',
Modules.CompIds.popCopyShipmentDateId='popCopyShipmentDateId',
Modules.CompIds.popCopyShipmentTypeId='popCopyShipmentTypeId',
Modules.CompIds.popCopyDeliveryCompletionDate='popCopyDeliveryCompletionDate',
Modules.CompIds.popCopyMakeId='popCopyMakeId',
Modules.CompIds.popCopyModelId='popCopyModelId',
Modules.CompIds.popCopyModelYearId='popCopyModelYearId',
Modules.CompIds.popCopyModelGroupId='popCopyModelGroupId',
Modules.CompIds.popCopyTransportModeId='popCopyTransportModeId',
Modules.CompIds.popCopyConveyanceId='popCopyConveyanceId',
Modules.CompIds.popCopyConveyanceTypeId='popCopyConveyanceTypeId',
Modules.CompIds.popCopyConveyanceNameId='popCopyConveyanceNameId',
Modules.CompIds.popCopyConsolidationId='popCopyConsolidationId',
Modules.CompIds.popCopyConsolidationTypeId='popCopyConsolidationTypeId',
Modules.CompIds.popCopyTransportCodeId='popCopyTransportCodeId',
Modules.CompIds.popCopyCustomerSalesRegionId='popCopyCustomerSalesRegionId',
Modules.CompIds.popCopyShipmentTypeId='popCopyShipmentTypeId',
Modules.CompIds.popCopyOrderTypeId='popCopyOrderTypeId',
Modules.CompIds.popCopyAbnormalMoveTypeId='popCopyAbnormalMoveTypeId',
Modules.CompIds.popCopyAddressLine1dId='popCopyAddressLine1dId',
Modules.CompIds.popCopyAddressLine2dId='popCopyAddressLine2dId',
Modules.CompIds.popCopyCitydId='popCopyCitydId',
Modules.CompIds.popCopyStateProvincedId='popCopyStateProvincedId',
Modules.CompIds.popCopyZipPostalCddId='popCopyZipPostalCddId';
Modules.CompIds.popCopyOriginalOriginId='popCopyOriginalOriginId',
Modules.CompIds.popCopyFinalDestinationId='popCopyFinalDestinationId',
Modules.CompIds.popCopyWeightId='popCopyWeightId',
Modules.CompIds.popCopyLengthId='popCopyLengthId',
Modules.CompIds.popCopyWidthId='popCopyWidthId',
Modules.CompIds.popCopyHeightId='popCopyHeightId',
Modules.CompIds.popCopyVolumeId='popCopyVolumeId',
Modules.CompIds.popCopyQuantityId='popCopyQuantityId',
Modules.CompIds.popCopyStorageQtyId='popCopyStorageQtyId',
Modules.CompIds.popCopyStorageUOMId='popCopyStorageUOMId',
Modules.CompIds.popCopyPreviousChargeQtyId='popCopyPreviousChargeQtyId',
Modules.CompIds.popCopyPreviousChargeUOMCodeId='popCopyPreviousChargeUOMCodeId',
Modules.CompIds.popCopyProfitLossCenterId='popCopyProfitLossCenterId',
Modules.CompIds.popCopyPartNumberId='popCopyPartNumberId',
Modules.CompIds.popServiceTypeId='popServiceTypeId',
Modules.CompIds.popModelNameId='popModelNameId',
Modules.CompIds.popIntRequestNoId='popIntRequestNoId',
Modules.CompIds.popSequenceNoId='popSequenceNoId',
Modules.CompIds.popRateTierCodeId='popRateTierCodeId',
Modules.CompIds.popSupplierEventStatusCodeId='popSupplierEventStatusCodeId',
Modules.CompIds.popSupplierRatingSequenceNumberId='popSupplierRatingSequenceNumberId',
Modules.CompIds.popSupplierManRateFlagId='popSupplierManRateFlagId',
Modules.CompIds.popCustomerEventStatusCodeId='popCustomerEventStatusCodeId',
Modules.CompIds.popCustomerRatingSequenceNumberId='popCustomerRatingSequenceNumberId',
Modules.CompIds.popCustomerManRateFlagId='popCustomerManRateFlagId',
Modules.CompIds.popFuelSrChargeSrvFlagId='popFuelSrChargeSrvFlagId',
Modules.CompIds.popFuelSrChargeAppFlagId='popFuelSrChargeAppFlagId',
Modules.CompIds.popFuelSrChargeAppFlagId='popFuelSrChargeAppFlagId',
Modules.CompIds.popParentSequenceNoId='popParentSequenceNoId',
Modules.CompIds.popSupplierSrvInvAmtCrncyId='popSupplierSrvInvAmtCrncyId',
Modules.CompIds.popStatusId='popStatusId',








/*------------------------Transportation Event Entry---------------*/

Modules.CompIds.transportationEventFormId='transportationEventFormId';
Modules.CompIds.transportLoadRefId='transportLoadRefId';
Modules.CompIds.transportSupplierCodeId='transportSupplierCodeId';
Modules.CompIds.transportServiceCodeId='transportServiceCodeId';
Modules.CompIds.transportConveyanceId='transportConveyanceId';
Modules.CompIds.transportConveyTypeId='transportConveyTypeId';
Modules.CompIds.transportConveyNameId='transportConveyNameId';
Modules.CompIds.transportEvntTransportModeId='transportEvntTransportModeId';
Modules.CompIds.transportEvntOriginId='transportEvntOriginId';
Modules.CompIds.transportEvntOrignAddr1Id='transportEvntOrignAddr1Id';
Modules.CompIds.transportEvntOrignAddr2Id='transportEvntOrignAddr2Id';
Modules.CompIds.transportEvntOrignCityId='transportEvntOrignCityId';
Modules.CompIds.transportEvntOrignStateId='transportEvntOrignStateId';
Modules.CompIds.transportEvntOrignZipId='transportEvntOrignZipId';
Modules.CompIds.transportEvntOrignCntryId='transportEvntOrignCntryId';
Modules.CompIds.transportEvntDestnId='transportEvntDestnId';
Modules.CompIds.transportEvntDestnAddr1Id='transportEvntDestnAddr1Id';
Modules.CompIds.transportEvntDestnAddr2Id='transportEvntDestnAddr2Id';
Modules.CompIds.transportEvntDestnCityId='transportEvntDestnCityId';
Modules.CompIds.transportEvntDestnStateId='transportEvntDestnStateId';
Modules.CompIds.transportEvntDestnZipId='transportEvntDestnZipId';
Modules.CompIds.transportEvntDestnCntryId='transportEvntDestnCntryId';
Modules.CompIds.transportTenderDtId='transportTenderDtId';
Modules.CompIds.transportShipmntDtId='transportShipmntDtId';
Modules.CompIds.transportConsoldatnId='transportConsoldatnId';
Modules.CompIds.transportConsoldatnTypeId='transportConsoldatnTypeId';
Modules.CompIds.transportTrnsfrSeqNbrId='transportTrnsfrSeqNbrId';
Modules.CompIds.transportTenderTimeId='transportTenderTimeId';
Modules.CompIds.transportShipmentTimeId='transportShipmentTimeId';
Modules.CompIds.transportEvntGridId='transportEvntGridId';
Modules.CompIds.transportProfLosId='transportProfLosId';
Modules.CompIds.transportFormReqstNoId='transportFormReqstNoId';
Modules.CompIds.transportEventAddRecordId='transportEventAddRecordId';
Modules.CompIds.transportEventdeleteRecordId='transportEventdeleteRecordId';
Modules.CompIds.transportEventGridCopyId='transportEventGridCopyId';
Modules.CompIds.transportEventGridPasteId='transportEventGridPasteId';
Modules.CompIds.transportEventGridcustomerId='transportEventGridcustomerId';
Modules.CompIds.transportEventGridMakeId='transportEventGridMakeId';
Modules.CompIds.transportEventGridModelId='transportEventGridModelId';
Modules.CompIds.transportEventGridModelGroupId='transportEventGridModelGroupId';
Modules.CompIds.transportEventGridShipmentTypeId='transportEventGridShipmentTypeId';
Modules.CompIds.transportEventGridAbnormalMoveTypeId='transportEventGridAbnormalMoveTypeId';
Modules.CompIds.transportEventGridOrderTypeId='transportEventGridOrderTypeId';
Modules.CompIds.transportEventGridDealerCodeId='transportEventGridDealerCodeId';
Modules.CompIds.transportEventGridDestinationId='transportEventGridDestinationId';
Modules.CompIds.transportEventGridDstnStateId='transportEventGridDstnStateId';
Modules.CompIds.transportEventGridOrignalOrgnId='transportEventGridOrignalOrgnId';
Modules.CompIds.transportEventGridFinalDstnId='transportEventGridFinalDstnId';
Modules.CompIds.transportEventGridCstmrSalesRegnId='transportEventGridCstmrSalesRegnId';
Modules.CompIds.transportEventGridShpmntTypeId='transportEventGridShpmntTypeId';
Modules.CompIds.transportEventGridRateTierId='transportEventGridRateTierId';
Modules.CompIds.transportEventSaveRecordId='transportEventSaveRecordId';

Modules.CompIds.transportCopyFormId='transportCopyFormId';
Modules.CompIds.transportEventCopycustomerId='transportEventCopycustomerId';
Modules.CompIds.transportCopyVinCheckId='transportCopyVinCheckId';
Modules.CompIds.transportCopyUnitId='transportCopyUnitId';
Modules.CompIds.transportCopyShipmentDateId='transportCopyShipmentDateId';
Modules.CompIds.transportCopyDeliveryDateId='transportCopyDeliveryDateId';
Modules.CompIds.transportCopyMakeCodeId='transportCopyMakeCodeId';
Modules.CompIds.transportCopyGridModelId='transportCopyGridModelId';
Modules.CompIds.transportCopyModelDescrId='transportCopyModelDescrId';
Modules.CompIds.transportCopyGridModelGroupId='transportCopyGridModelGroupId';
Modules.CompIds.transportCopyModelYearId='transportCopyModelYearId';
Modules.CompIds.transportCopyRateTierId='transportCopyRateTierId';
Modules.CompIds.transportCopyShipRefId='transportCopyShipRefId';
Modules.CompIds.transportCopyTransportCodeId='transportCopyTransportCodeId';
Modules.CompIds.transportCopyShpmntTypeId='transportCopyShpmntTypeId';
Modules.CompIds.transportCopyAbnormalMoveTypeId='transportCopyAbnormalMoveTypeId';
Modules.CompIds.transportCopyOrderTypeId='transportCopyOrderTypeId';
Modules.CompIds.transportCopyCstmrSalesRegnId='transportCopyCstmrSalesRegnId';
Modules.CompIds.transportCopyDealerCodeId='transportCopyDealerCodeId';
Modules.CompIds.transportCopyDestinationId='transportCopyDestinationId';
Modules.CompIds.transportCopyDestAddr1Id='transportCopyDestAddr1Id';
Modules.CompIds.transportCopyDestAddr2Id='transportCopyDestAddr2Id';
Modules.CompIds.transportCopyDestCityId='transportCopyDestCityId';
Modules.CompIds.transportCopyDestStateId='transportCopyDestStateId';
Modules.CompIds.transportCopyDestZipId='transportCopyDestZipId';
Modules.CompIds.transportCopyDestCountryId='transportCopyDestCountryId';
Modules.CompIds.transportCopyOrignlOrignId='transportCopyOrignlOrignId';
Modules.CompIds.transportCopyFinalDestnId='transportCopyFinalDestnId';
Modules.CompIds.transportCopyWeightId='transportCopyWeightId';
Modules.CompIds.transportCopyLengthId='transportCopyLengthId';
Modules.CompIds.transportCopyWidthId='transportCopyWidthId';
Modules.CompIds.transportCopyHeightId='transportCopyHeightId';
Modules.CompIds.transportCopyVolumeId='transportCopyVolumeId';
Modules.CompIds.transportCopyRef1Id='transportCopyRef1Id';
Modules.CompIds.transportCopyRef2Id='transportCopyRef2Id';
Modules.CompIds.transportCopyRef3Id='transportCopyRef3Id';
Modules.CompIds.transportCopyRef4Id='transportCopyRef4Id';
Modules.CompIds.transportCopyRef5Id='transportCopyRef5Id';
Modules.CompIds.transportCopyRef6Id='transportCopyRef6Id';
Modules.CompIds.transportCopyRef7Id='transportCopyRef7Id';
Modules.CompIds.transportCopyRef8Id='transportCopyRef8Id';
Modules.CompIds.transportCopyRef9Id='transportCopyRef9Id';
Modules.CompIds.transportCopyRef10Id='transportCopyRef10Id';
Modules.CompIds.copyTransportEventWinId='copyTransportEventWinId';

Modules.CompIds.editTransportationEventFormId='editTransportationEventFormId';
Modules.CompIds.editTransportationGridWinId='editTransportationGridWinId';
Modules.CompIds.editTransportGridWinSaveBtnId='editTransportGridWinSaveBtnId';

Modules.CompIds.transportEditWinStatusId='transportEditWinStatusId';
Modules.CompIds.transportEditWinCustomerId='transportEditWinCustomerId';
Modules.CompIds.transportEditWinVinCheckId='transportEditWinVinCheckId';
Modules.CompIds.transportEditWinUnitId='transportEditWinUnitId';
Modules.CompIds.transportEditWinShipmentDateId='transportEditWinShipmentDateId';
Modules.CompIds.transportEditWinDeliveryDateId='transportEditWinDeliveryDateId';
Modules.CompIds.transportEditWinMakeId='transportEditWinMakeId';
Modules.CompIds.transportEditWinModelId='transportEditWinModelId';
Modules.CompIds.transportEditWinModelDescrId='transportEditWinModelDescrId';
Modules.CompIds.transportEditWinModelGroupId='transportEditWinModelGroupId';
Modules.CompIds.transportEditWinModelYearId='transportEditWinModelYearId';
Modules.CompIds.transportEditWinRateTierId='transportEditWinRateTierId';
Modules.CompIds.transportEditWinShipRefId='transportEditWinShipRefId';
Modules.CompIds.transportEditWinTransportCodeId='transportEditWinTransportCodeId'; 
Modules.CompIds.transportEditWinShpmntTypeId='transportEditWinShpmntTypeId';
Modules.CompIds.transportEditWinAbMoveTypeId='transportEditWinAbMoveTypeId';
Modules.CompIds.transportEditWinOrderTypeId='transportEditWinOrderTypeId';
Modules.CompIds.transportEditWinCstmrSalesRegnId='transportEditWinCstmrSalesRegnId';
Modules.CompIds.transportEditWinDealerCodeId='transportEditWinDealerCodeId';
Modules.CompIds.transportEditWinDestinationId='transportEditWinDestinationId';
Modules.CompIds.transportEditWinAddr1Id='transportEditWinAddr1Id';
Modules.CompIds.transportEditWinAddr2Id='transportEditWinAddr2Id';
Modules.CompIds.transportEditWinDestCityId='transportEditWinDestCityId';
Modules.CompIds.transportEditWinDestStateId='transportEditWinDestStateId';
Modules.CompIds.transportEditWinDestZipId='transportEditWinDestZipId';
Modules.CompIds.transportEditWinDestCountryId='transportEditWinDestCountryId';
Modules.CompIds.transportEditWinOrignlOrignId='transportEditWinOrignlOrignId';
Modules.CompIds.transportEditWinFinalDestnId='transportEditWinFinalDestnId';
Modules.CompIds.transportEditWinWeightId='transportEditWinWeightId';
Modules.CompIds.transportEditWinLengthId='transportEditWinLengthId';
Modules.CompIds.transportEditWinWidthId='transportEditWinWidthId';
Modules.CompIds.transportEditWinHeightId='transportEditWinHeightId';
Modules.CompIds.transportEditWinVolumeId='transportEditWinVolumeId';
Modules.CompIds.transportEditWinRef1Id='transportEditWinRef1Id';
Modules.CompIds.transportEditWinRef2Id='transportEditWinRef2Id';
Modules.CompIds.transportEditWinRef3Id='transportEditWinRef3Id';
Modules.CompIds.transportEditWinRef4Id='transportEditWinRef4Id';
Modules.CompIds.transportEditWinRef5Id='transportEditWinRef5Id';
Modules.CompIds.transportEditWinRef6Id='transportEditWinRef6Id';
Modules.CompIds.transportEditWinRef7Id='transportEditWinRef7Id';
Modules.CompIds.transportEditWinRef8Id='transportEditWinRef8Id';
Modules.CompIds.transportEditWinRef9Id='transportEditWinRef9Id';
Modules.CompIds.transportEditWinRef10Id='transportEditWinRef10Id';
Modules.CompIds.transportGridShipmntDtId='transportGridShipmntDtId';
Modules.CompIds.transportGridDeliveryDtId='transportGridDeliveryDtId';

/*------------------------Technical Event Entry---------------*/

Modules.CompIds.technicalFormReqstNoId='technicalFormReqstNoId';
Modules.CompIds.technicalEventFormId='technicalEventFormId';
Modules.CompIds.technicalWorkOrderId='technicalWorkOrderId';
Modules.CompIds.technicalSupplierCodeId='technicalSupplierCodeId';
Modules.CompIds.technicalServiceCodeId='technicalServiceCodeId';
Modules.CompIds.technicalEvntTransportModeId='technicalEvntTransportModeId';
Modules.CompIds.technicalConveyanceId='technicalConveyanceId';
Modules.CompIds.technicalConveyNameId='technicalConveyNameId';
Modules.CompIds.technicalRequestDtId='technicalRequestDtId';
Modules.CompIds.technicalRequestTimeId='technicalRequestTimeId';
Modules.CompIds.technicalProfLosId='technicalProfLosId';
Modules.CompIds.technicalConsoldatnId='technicalConsoldatnId';
Modules.CompIds.technicalConsoldatnTypeId='technicalConsoldatnTypeId';
Modules.CompIds.technicalEvntLocationId='technicalEvntLocationId';
Modules.CompIds.technicalEvntLocAddr1Id='technicalEvntLocAddr1Id';
Modules.CompIds.technicalEvntLocAddr2Id='technicalEvntLocAddr2Id';
Modules.CompIds.technicalEvntLocCityId='technicalEvntLocCityId';
Modules.CompIds.technicalEvntLocStateId='technicalEvntLocStateId';
Modules.CompIds.technicalEvntLocZipId='technicalEvntLocZipId';
Modules.CompIds.technicalEvntLocCntryId='technicalEvntLocCntryId';
Modules.CompIds.technicalEvntGridId='technicalEvntGridId';
Modules.CompIds.technicalEventGridPartId='technicalEventGridPartId';
Modules.CompIds.technicalEventAddRecordId='technicalEventAddRecordId';
Modules.CompIds.technicalEventdeleteRecordId='technicalEventdeleteRecordId';
Modules.CompIds.technicalEventGridCopyId='technicalEventGridCopyId';
Modules.CompIds.technicalEventGridPasteId='technicalEventGridPasteId';
Modules.CompIds.technicalEventGridMakeId='technicalEventGridMakeId';
Modules.CompIds.technicalEventGridcustomerId='technicalEventGridcustomerId';
Modules.CompIds.technicalEventGridModelId='technicalEventGridModelId';
Modules.CompIds.technicalEventGridModelGroupId='technicalEventGridModelGroupId';
Modules.CompIds.technicalEventGridCstmrSalesRegnId='technicalEventGridCstmrSalesRegnId';
Modules.CompIds.technicalEventGridPrevUOMId='technicalEventGridPrevUOMId';
Modules.CompIds.technicalEventGridStorUOMId='technicalEventGridStorUOMId';
Modules.CompIds.technicalEventGridRateTierId='technicalEventGridRateTierId';

Modules.CompIds.technicalCopyFormId='technicalCopyFormId';
Modules.CompIds.technicalEventCopycustomerId='technicalEventCopycustomerId';
Modules.CompIds.technicalCopyVinCheckId='technicalCopyVinCheckId';
Modules.CompIds.technicalCopyUnitId='technicalCopyUnitId';
Modules.CompIds.copyTechnicalEventWinId='copyTechnicalEventWinId';
Modules.CompIds.technicalCopyPartId='technicalCopyPartId';
Modules.CompIds.technicalCopyShipmentDateId='technicalCopyShipmentDateId';
Modules.CompIds.technicalCopyDeliveryDateId='technicalCopyDeliveryDateId';
Modules.CompIds.technicalCopyMakeCodeId='technicalCopyMakeCodeId';
Modules.CompIds.technicalCopyGridModelId='technicalCopyGridModelId';
Modules.CompIds.technicalCopyModelDescrId='technicalCopyModelDescrId';
Modules.CompIds.technicalCopyGridModelGroupId='technicalCopyGridModelGroupId';
Modules.CompIds.technicalCopyModelYearId='technicalCopyModelYearId';
Modules.CompIds.technicalCopyRateTierId='technicalCopyRateTierId';
Modules.CompIds.technicalCopyWeightId='technicalCopyWeightId';
Modules.CompIds.technicalCopyLengthId='technicalCopyLengthId';
Modules.CompIds.technicalCopyWidthId='technicalCopyWidthId';
Modules.CompIds.technicalCopyHeightId='technicalCopyHeightId';
Modules.CompIds.technicalCopyVolumeId='technicalCopyVolumeId';
Modules.CompIds.technicalCopyShipRefId='technicalCopyShipRefId';
Modules.CompIds.technicalCopyCstmrSalesRegnId='technicalCopyCstmrSalesRegnId';
Modules.CompIds.technicalCopyPrevChrgdQtyId='technicalCopyPrevChrgdQtyId';
Modules.CompIds.technicalEventCopyPrevUOMId='technicalEventCopyPrevUOMId';
Modules.CompIds.technicalCopyRef1Id='technicalCopyRef1Id';
Modules.CompIds.technicalCopyRef2Id='technicalCopyRef2Id';
Modules.CompIds.technicalCopyRef3Id='technicalCopyRef3Id';
Modules.CompIds.technicalCopyRef4Id='technicalCopyRef4Id';
Modules.CompIds.technicalCopyRef5Id='technicalCopyRef5Id';
Modules.CompIds.technicalCopyQtyId='technicalCopyQtyId';
Modules.CompIds.technicalCopyStoreQtyId='technicalCopyStoreQtyId';
Modules.CompIds.technicalCopyStoreUomCdId='technicalCopyStoreUomCdId';

Modules.CompIds.editTechnicalEventFormId='editTechnicalEventFormId';
Modules.CompIds.editTechnicalGridWinId='editTechnicalGridWinId';
Modules.CompIds.editTechnicalGridWinSaveBtnId='editTechnicalGridWinSaveBtnId';
Modules.CompIds.editTechnicalEventGridCustomerId='editTechnicalEventGridCustomerId';
Modules.CompIds.editTechnicalEventGridVinCheckId='editTechnicalEventGridVinCheckId';
Modules.CompIds.editTechnicalEventGridUnitId='editTechnicalEventGridUnitId';
Modules.CompIds.editTechnicalEventGridPartId='editTechnicalEventGridPartId';
Modules.CompIds.editTechnicalEventGridShipmentDateId='editTechnicalEventGridShipmentDateId';
Modules.CompIds.editTechnicalEventGridDeliveryDateId='editTechnicalEventGridDeliveryDateId';
Modules.CompIds.editTechnicalEventGridMakeCodeId='editTechnicalEventGridMakeCodeId';
Modules.CompIds.editTechnicalEventGridGridModelId='editTechnicalEventGridGridModelId';
Modules.CompIds.editTechnicalEventGridModelDescrId='editTechnicalEventGridModelDescrId';

Modules.CompIds.editTechnicalEventGridModelGroupId='editTechnicalEventGridModelGroupId';
Modules.CompIds.editTechnicalEventGridModelYearId='editTechnicalEventGridModelYearId';
Modules.CompIds.editTechnicalEventGridRateTierId='editTechnicalEventGridRateTierId';
Modules.CompIds.editTechnicalEventGridWeightId='editTechnicalEventGridWeightId';
Modules.CompIds.editTechnicalEventGridLengthId='editTechnicalEventGridLengthId';
Modules.CompIds.editTechnicalEventGridWidthId='editTechnicalEventGridWidthId';
Modules.CompIds.editTechnicalEventGridHeightId='editTechnicalEventGridHeightId';
Modules.CompIds.editTechnicalEventGridVolumeId='editTechnicalEventGridVolumeId';
Modules.CompIds.editTechnicalEventGridShipRefId='editTechnicalEventGridShipRefId';
Modules.CompIds.editTechnicalEventGridCstmrSalesRegnId='editTechnicalEventGridCstmrSalesRegnId';
Modules.CompIds.editTechnicalEventGridPrevChrgdQtyId='editTechnicalEventGridPrevChrgdQtyId';
Modules.CompIds.editTechnicalEventGridPrevUOMId='editTechnicalEventGridPrevUOMId';
Modules.CompIds.editTechnicalEventGridRef1Id='editTechnicalEventGridRef1Id';
Modules.CompIds.editTechnicalEventGridRef2Id='editTechnicalEventGridRef2Id';
Modules.CompIds.editTechnicalEventGridRef3Id='editTechnicalEventGridRef3Id';
Modules.CompIds.editTechnicalEventGridRef4Id='editTechnicalEventGridRef4Id';
Modules.CompIds.editTechnicalEventGridRef5Id='editTechnicalEventGridRef5Id';
Modules.CompIds.editTechnicalEventGridQtyId='editTechnicalEventGridQtyId';
Modules.CompIds.editTechnicalEventGridStoreQtyId='editTechnicalEventGridStoreQtyId';
Modules.CompIds.editTechnicalEventGridStoreUomCdId='editTechnicalEventGridStoreUomCdId';
Modules.CompIds.editTechnicalEventGridStatusId='editTechnicalEventGridStatusId';

/*---------------------Supplier Event Status Summary-------------------*/
Modules.CompIds.supplrEvntStatusGridId='supplrEventStatusGrid';
Modules.CompIds.supplrComboEvntStatusId='supplrComboBoxId';
Modules.CompIds.custmrComboEvntStatusId='custmrComboBoxId';
Modules.CompIds.dbtrPartyComboEvntStatusId='debtorPartyEvntStatus';
Modules.CompIds.SupplrEventStatusTabParentPanelId = 'SupplrEventStatusTabParentPanelId';
Modules.CompIds.ocnSupplrPaymntDtlsPopupChrgCodeId = 'ocnSupplrPaymntDtlsPopupChrgCodeId';
Modules.CompIds.ocnSupplrPaymntDtlsPopupServiceTypeId = 'ocnSupplrPaymntDtlsPopupServiceTypeId';

Modules.CompIds.srvcCdComboEvntStatusId='srvcCdComboEvntStatusSummaryId';
Modules.CompIds.srvcGroupCdComboEvntStatusId='srvcGroupCdComboEvntStatusId';
Modules.CompIds.UnitIdEvntStatusSummaryId='UnitIdEvntStatusSummaryId';
Modules.CompIds.pinvcEvntstatusSummaryId='pinvcEvntstatusSummaryId';
Modules.CompIds.zerortEvntstatusSummaryId='zerortEvntstatusSummaryId';
Modules.CompIds.recnclEvntstatusSummaryId='recnclEvntstatusSummaryId';
Modules.CompIds.apprvEvntstatusSummaryId='apprvEvntstatusSummaryId';
Modules.CompIds.nochrgEvntstatusSummaryId='nochrgEvntstatusSummaryId';
Modules.CompIds.makeSupplrEvntStatusId='makeSupplrEvntStatusId';
Modules.CompIds.modelSupplrEvntStatusId='modelSupplrEvntStatusId';
Modules.CompIds.modelGroupSupplrStatusId='modelGroupSupplrStatusId';
Modules.CompIds.SupplrStatusTransportModeId='SupplrStatusTransportModeId';
Modules.CompIds.supplrStatusConveyanceId='supplrStatusConveyanceId';
Modules.CompIds.supplrEvntStatusConveyanceTypeId='supplrEvntStatusConveyanceTypeId';
Modules.CompIds.supplrEvntConsolidationTypeId='supplrEvntConsolidationTypeId';
Modules.CompIds.supplrStatusShipmentRefId='supplrStatusShipmentRefId';
Modules.CompIds.supplrStatusWorkOrderId='supplrStatusWorkOrderId';
Modules.CompIds.supplrStatusRateTierId='supplrStatusRateTierId';
Modules.CompIds.supplrEvntShipmentTypeId='supplrEvntShipmentTypeId';
Modules.CompIds.supplrStatusConsolidationId='supplrStatusConsolidationId';
Modules.CompIds.supplrEvntProfitLossId='supplrEvntProfitLossId';
Modules.CompIds.supplrStatusEvntLoadId='supplrStatusEvntLoadId';
Modules.CompIds.supplrEvntStatusEventDateId='supplrEvntStatusEventDateId';
Modules.CompIds.supplrEvntStatusFrmDateId='supplrEvntStatusFrmDateId';
Modules.CompIds.supplrEvntStatusToDateId='supplrEvntStatusToDateId';
Modules.CompIds.supplrStatusRatingDestId='supplrStatusRatingDestId';
Modules.CompIds.supplrEvntStatusOriginId='supplrEvntStatusOriginId';
Modules.CompIds.SupplrEvntStatusOriginStateProvinceId='SupplrEvntStatusOriginStateProvinceId';
Modules.CompIds.supplrStatusOriginCityId='supplrStatusOriginCityId';
Modules.CompIds.supplrEvntStatusOriginalOriginId='supplrEvntStatusOriginalOriginId';
Modules.CompIds.supplrEvntStatusDestinationId='supplrEvntStatusDestinationId';
Modules.CompIds.supplrStatusOriginDestCityId='supplrStatusOriginDestCityId';
Modules.CompIds.supplrStsSummDestinationStateProvinceId='supplrStsSummDestinationStateProvinceId';
Modules.CompIds.supplrStsSummFinalDestId='supplrStsSummFinalDestId';
Modules.CompIds.supplrEvntStatusVarianceEvntId='supplrEvntStatusVarianceEvntId';
Modules.CompIds.SupplrStsSummAdvContainer='SupplrStsSummAdvContainer';
Modules.CompIds.SupplrStsSummaryFormId='SupplrStsSummaryFormId';
Modules.CompIds.supplrStsSummCstmrStsComboId='supplrStsSummCstmrStsComboId';
Modules.CompIds.supplrEvntStatusBlankId='supplrEvntStatusBlankId';
Modules.CompIds.supplrEvntStatusSrvcTypeId='supplrEvntStatusSrvcTypeId';
Modules.CompIds.popupSupplrEvntStsFormId='popupSupplrEvntStsFormId';
Modules.CompIds.popupSupplrEvntStsSummWinId='popupSupplrEvntStsSummWinId';
//Modules.CompIds.srvcCdComboEvntStatusId='srvcCdComboEvntStatusSummaryId';
Modules.CompIds.supplrEvntStsSummClearId='supplrEvntStsSummClearId';
Modules.CompIds.supplrStsSummHiddenCheckId='supplrStsSummHiddenCheckId';

/****************Customer Event Status Summary********************/ 
Modules.CompIds.CustmrStsEvntSummTabParentPanel='CustmrStsEvntSummTabParentPanel';
Modules.CompIds.custmrEvntStatusGridId='custmrEvntStatusGridId';
Modules.CompIds.supplrComboCustEvntStatusId='supplrComboCustEvntStatusId';
Modules.CompIds.custmrComboCstmrEvntStatusId='custmrComboCstmrEvntStatusId';
Modules.CompIds.dbtrPartyComboCstmrEvntStatusId='dbtrPartyComboCstmrEvntStatusId';
Modules.CompIds.srvcCdComboCstmrEvntStatusId='srvcCdComboCstmrEvntStatusId';
Modules.CompIds.custmrEvntStatusSrvcTypeId='custmrEvntStatusSrvcTypeId';
Modules.CompIds.srvcGroupCdComboCstmrEvntStatusId='srvcGroupCdComboCstmrEvntStatusId';
Modules.CompIds.UnitIdCstmrEvntStatusSummaryId ='UnitIdCstmrEvntStatusSummaryId';
Modules.CompIds.makeSupplrCstmrEvntStatusId='makeSupplrCstmrEvntStatusId';
Modules.CompIds.modelGroupCstmrStatusId='modelGroupCstmrStatusId';
Modules.CompIds.cstmrStatusTransportModeId='cstmrStatusTransportModeId';
Modules.CompIds.cstmrStatusConveyanceId='cstmrStatusConveyanceId';
Modules.CompIds.cstmrEvntStatusConveyanceTypeId='cstmrEvntStatusConveyanceTypeId';
Modules.CompIds.cstmrEvntConsolidationTypeId='cstmrEvntConsolidationTypeId';
Modules.CompIds.cstmrStatusEvntLoadId='cstmrStatusEvntLoadId';
Modules.CompIds.cstmrStatusWorkOrderId='cstmrStatusWorkOrderId';
Modules.CompIds.cstmrEvntShipmentTypeId='cstmrEvntShipmentTypeId';
Modules.CompIds.cstmrStatusRateTierId='cstmrStatusRateTierId';
Modules.CompIds.cstmrEvntStatusEventDateId='cstmrEvntStatusEventDateId';
Modules.CompIds.cstmrEvntStatusFrmDateId='cstmrEvntStatusFrmDateId';
Modules.CompIds.cstmrEvntStatusToDateId='cstmrEvntStatusToDateId';
Modules.CompIds.cstmrEvntStatusBlankId='cstmrEvntStatusBlankId';
Modules.CompIds.cstmrStsSummCstmrStsComboId='cstmrStsSummCstmrStsComboId';
Modules.CompIds.cstmrStatusRatingDestId='cstmrStatusRatingDestId';
Modules.CompIds.cstmrStatusOriginCityId='cstmrStatusOriginCityId';
Modules.CompIds.cstmrEvntStatusOriginStateProvinceId='cstmrEvntStatusOriginStateProvinceId';
Modules.CompIds.cstmrEvntStatusOriginalOriginId='cstmrEvntStatusOriginalOriginId';
Modules.CompIds.cstmrEvntStatusDestinationId='cstmrEvntStatusDestinationId';
Modules.CompIds.cstmrStatusOriginDestCityId='cstmrStatusOriginDestCityId';
Modules.CompIds.cstmrStsSummDestinationStateProvinceId='cstmrStsSummDestinationStateProvinceId';
Modules.CompIds.cstmrStsSummFinalDestId='cstmrStsSummFinalDestId';
Modules.CompIds.cstmrEvntStatusVarianceEvntId='cstmrEvntStatusVarianceEvntId';
Modules.CompIds.pinvcCstmrEvntstatusSummaryId='pinvcCstmrEvntstatusSummaryId';
Modules.CompIds.zerortCstmrEvntstatusSummaryId='zerortCstmrEvntstatusSummaryId';
Modules.CompIds.invcCstmrEvntstatusSummaryId='invcCstmrEvntstatusSummaryId';
Modules.CompIds.rejectEvntstatusSummaryId='rejectEvntstatusSummaryId';
Modules.CompIds.nochrgEvntstatusSummaryId='nochrgEvntstatusSummaryId';
Modules.CompIds.cstmrEvntStsSummSupplrStsId='cstmrEvntStsSummSupplrStsId';
Modules.CompIds.CstmrStsSummAdvContainer='CstmrStsSummAdvContainer';
Modules.CompIds.cstmrStatusShipmentRefId='cstmrStatusShipmentRefId';
Modules.CompIds.CstmrStsSummaryFormId='CstmrStsSummaryFormId';
Modules.CompIds.cstmrEvntStatusOriginId='cstmrEvntStatusOriginId';
Modules.CompIds.nochrgCstmrEvntstatusSummaryId='nochrgCstmrEvntstatusSummaryId';
Modules.CompIds.modelCustmrEvntStatusId='modelCustmrEvntStatusId';
Modules.CompIds.csmtrStatusConsolidationId='csmtrStatusConsolidationId';
Modules.CompIds.cstmrEvntProfitLossId='cstmrEvntProfitLossId';
Modules.CompIds.popupCstmrEvntStsFormId='popupCstmrEvntStsFormId';
Modules.CompIds.popupCstmrEvntStsSummWinId='popupCstmrEvntStsSummWinId';
Modules.CompIds.customerRateVerificationGridStoreId='customerRateGridStore';

Modules.CompIds.customerId='customerId';
Modules.CompIds.eventRatingQueryOriginStateProvinceId='eventRatingQueryOriginStateProvinceId';
Modules.CompIds.custRateVerificationModelId='custRateVerificationModelId';
Modules.CompIds.eventRatingQueryModelGroupId1='eventRatingQueryModelGroupId1';
Modules.CompIds.partCodeId1='partCodeId1';
Modules.CompIds.conveyanceTypeId1='conveyanceTypeId1';
Modules.CompIds.destinationStateProvinceId1='destinationStateProvinceId1';
Modules.CompIds.originalOriginId='originalOriginId';
Modules.CompIds.eventRatingQueryConsolidationTypeId='eventRatingQueryConsolidationTypeId';

/************* Customer Debtor Party Details ***********/
Modules.CompIds.CustomerDebtorPartyTabPanelId='customerDebtorPartyTabPanelId';
Modules.CompIds.customerDebtorPartyPopupWinId='customerDebtorPartyPopupWinId';
Modules.CompIds.popupCustomerDebtorPartyId='popupCustomerDebtorPartyId';
Modules.CompIds.customerDebtorPartyFormId='customerDebtorPartyFormId';
Modules.CompIds.addCustomerDebtorRecordId='addCustomerDebtorRecordId';

Modules.CompIds.deleteCustomerDebtorRecordId='deleteCustomerDebtorRecordId';

Modules.CompIds.cstmrDebtorPartyGridWinOrignStateId='cstmrDebtorPartyGridWinOrignStateId';

/**********************Customer Rates********************/
Modules.CompIds.cstmrRatesEffectiveDateId = 'contractDtlsEffectiveDtFilter';
Modules.CompIds.cstmrRatesCstmrNmId='cstmrRatesCstmrNmId';
Modules.CompIds.custmrComboCstmrRateId='custmrComboCstmrRateId';
Modules.CompIds.cstmrRatesValidToDateId='cstmrRatesValidToDateId';
Modules.CompIds.cstmrRatesValidFrmDateId='cstmrRatesValidFrmDateId';
Modules.CompIds.cstmrRatesContractId='cstmrRatesContractId';
Modules.CompIds.cstmrRateDbtrPartyComboId='cstmrRateDbtrPartyComboId';
Modules.CompIds.cstmrRatesDebtorPartyNmId='cstmrRatesDebtorPartyNmId';
Modules.CompIds.cstmrRatesRemarkId='cstmrRatesRemarkId';
Modules.CompIds.custmrRateFormId='custmrRateFormId';
Modules.CompIds.cstmrRatesAdvcSrchId='cstmrRatesAdvcSrchId';
Modules.CompIds.cstmrRatesHdrGridId='cstmrRatesHdrGridId';
//Modules.CompIds.deleteCustomerDebtorRecordId='deleteCustomerDebtorRecordId';
Modules.CompIds.cstmrRatesCompositeWinId='cstmrRatesCompositeWinId';
Modules.CompIds.cstmrRatesLoadWinId='cstmrRatesLoadWinId';
Modules.CompIds.custmrRateMinLoadGridId='custmrRateMinLoadGridId';
Modules.CompIds.cstmrRatesAgreedMileageWinId ='cstmrRatesAgreedMileageWinId';
//Modules.CompIds.cstmrRatesHdrGridId    = 'cstmrRatesHdrGridId';
Modules.CompIds.custmrRateFuelSurchrgGridId ='custmrRateFuelSurchrgGridId';
Modules.CompIds.intSplAgrmtNbrId   = 'intSplAgrmtNbrId';
Modules.CompIds.custmrRateDtlsGrid  = 'custmrRateDtlsGrid';
Modules.CompIds.custmrRateAgreedMileageGridId  = 'custmrRateAgreedMileageGridId';
Modules.CompIds.cstmrRatesHdrGridValidFrmDateId =  'cstmrRatesHdrGridValidFrmDateId';
Modules.CompIds.cstmrRatesHdrGridValidToDateId=  'cstmrRatesHdrGridValidToDateId';
Modules.CompIds.custmrHdrGridComboCstmrRateId  =  'custmrHdrGridComboCstmrRateId';
Modules.CompIds.cstmrRateHdrGridDbtrPartyComboId= 'cstmrRateHdrGridDbtrPartyComboId';
Modules.CompIds.cstmrRateRetrieveBtnId =  'cstmrRateRetrieveBtnId';
Modules.CompIds.cstmrRateDtlsMakeLovId = 'cstmrRateDtlsMakeLovId';
Modules.CompIds.cstmrRateModelLovId = 'cstmrRateModelLovId';
Modules.CompIds.cstmrRateValidFrmDt  = 'cstmrRateValidFrmDt';
Modules.CompIds.hdrGridContractId  =  'hdrGridContractId';
Modules.CompIds.srvcLvlValidDtId   =  'srvcLvlValidDtId';
Modules.CompIds.custmrRateCompositeGrid  =  'custmrRateCompositeGrid';
Modules.CompIds.cstmrRatesDetailsModelLinePopId =  'cstmrRatesDetailsModelLinePopId';
Modules.CompIds.cstmrRatesDetailsPopStorageTypeId = 'cstmrRatesDetailsPopStorageTypeId';

Modules.CompIds.cstmrRatesHdrGridAddEditWinId   =  'popupCstmrRatesParentId';
Modules.CompIds.cstmrRatesGridWinContractId   =   'popupCstmrRateContrctId';
Modules.CompIds.cstmrRatesHdrGridWinValidFrmDateId = 'popupcstmrRatesValidFrmDateId';
Modules.CompIds.cstmrRatesHdrGridWinValidToDateId   =  'popupcstmrRatesValidToDateId';
Modules.CompIds.cstmrRatesHdrPopWinCstmrId    =   'popupcustmrComboCstmrRateId';
Modules.CompIds.cstmrRatesHdrGridDbtrPartyNmId   =  'popupcstmrRateDbtrPartyComboId';
Modules.CompIds.cstmrRatesHdrGridCStmrNmId     =   'popupcstmrRatesCstmrNmId';
Modules.CompIds.cstmrRateHdrPopwinDbtrPartyId  =  'popupcstmrRatesDebtorPartyNmId';
Modules.CompIds.cstmrRatesHdrPopWinSrvcLvlValidDtId           =  'popupsrvcLvlValidDtId';
Modules.CompIds.cstmrRatesHdrPopWinRemarkId  = 'cstmrRatesPopWinRemarkId';

Modules.CompIds.cstmrRatesFuelSurchrgAddEditWinId = 'cstmrRatesFuelSurchrgAddEditWin';

Modules.CompIds.srvcCdComboCstmrRatessrchFrmId  =  'srvcCdComboCstmrRatessrchFrmId';
Modules.CompIds.originComboCstmrRatessrchFrmId = 'originComboCstmrRatessrchFrmId';
Modules.CompIds.destinationComboCstmrRatessrchFrmId = 'destinationComboCstmrRatessrchFrmId';

Modules.CompIds.cstmrRatesFuelSurchrgPopSrvcDecsId = 'cstmrRatesFuelSurchrgPopSrvcDecsId';
Modules.CompIds.cstmrRatesFuelSurchrgGridWinServiceCdId = 'cstmrRatesFuelSurchrgGridWinServiceCdId';
Modules.CompIds.cstmrRatesFuelSurchrgWinValidFrmDateId = 'cstmrRatesFuelSurchrgWinValidFrmDateId';
Modules.CompIds.cstmrRatesFuelSurchrgWinValidToDateId = 'cstmrRatesFuelSurchrgWinValidToDateId';
Modules.CompIds.cstmrRatesFuelSurchrgPopSupplierCdId= 'cstmrRatesFuelSurchrgPopSupplierCdId';
Modules.CompIds.cstmrRatesFuelSurchrgOrignPopId = 'cstmrRatesFuelSurchrgOrignPopId';
Modules.CompIds.cstmrRatesFuelSurchrgDestinationPopId= 'cstmrRatesFuelSurchrgDestinationPopId';
Modules.CompIds.cstmrRatesFuelSurchrgOriginCityId = 'cstmrRatesFuelSurchrgOriginCityId';
Modules.CompIds.cstmrRatesFuelSurchrgOriginStProvincePopId = 'cstmrRatesFuelSurchrgOriginStProvincePopId';
Modules.CompIds.cstmrRatesFuelSurchrgOriginCountryId = 'cstmrRatesFuelSurchrgOriginCountryId';
Modules.CompIds.cstmrRatesFuelSurchrgPopWinDestCityId = 'cstmrRatesFuelSurchrgPopWinDestCityId';
Modules.CompIds.cstmrRatesFuelSurchrgDestinationStProvincePopId = 'cstmrRatesFuelSurchrgDestinationStProvincePopId';
Modules.CompIds.cstmrRatesFuelSurchrgDestCountryPopId = 'cstmrRatesFuelSurchrgDestCountryPopId';
Modules.CompIds.cstmrRatesFuelSurchrgModelGrpPopId= 'cstmrRatesFuelSurchrgModelGrpPopId';
Modules.CompIds.cstmrRatesFuelSurchrgConsolidationTypePopId = 'cstmrRatesFuelSurchrgConsolidationTypePopId';
Modules.CompIds.cstmrRatesFuelSurchrgPopNotChargeableId = 'cstmrRatesFuelSurchrgPopNotChargeableId';
Modules.CompIds.cstmrRatesFuelSurchrgPopMarkupId = 'cstmrRatesFuelSurchrgPopMarkupId';
Modules.CompIds.cstmrRatesFuelSurchrgPopNotTaxableId = 'cstmrRatesFuelSurchrgPopNotTaxableId';
Modules.CompIds.cstmrRatesMarkupCriteriaPopup = 'cstmrRatesMarkupCriteriaPopup';
Modules.CompIds.cstmrRatesFuelSurchrgMarkUpCriteriaPopId = 'cstmrRatesFuelSurchrgMarkUpCriteriaPopId';
Modules.CompIds.cstmrRatesFuelSurchrgProgramCdPopId= 'cstmrRatesFuelSurchrgProgramCdPopId';
Modules.CompIds.cstmrRatesIndexCdPopupId  = 'cstmrRatesIndexCdPopupId';
Modules.CompIds.cstmrRatesEventDtPoupwin = 'cstmrRatesEventDtPoupwin';

Modules.CompIds.cstmrRatesDetailsAddEditWinId = 'cstmrRatesDetailsAddEditWinId';
Modules.CompIds.cstmrRatesDetailsPopSrvcDecsId = 'cstmrRatesDetailsPopSrvcDecsId';
Modules.CompIds.cstmrRatesDetailsPopSupplierCdId = 'cstmrRatesDetailsPopSupplierCdId';
Modules.CompIds.cstmrRatesDetailsGridPopupServiceCdId = 'cstmrRatesDetailsGridPopupServiceCdId';
Modules.CompIds.cstmrRatesDetailsWinValidFrmDateId = 'cstmrRatesDetailsWinValidFrmDateId';
Modules.CompIds.cstmrRatesDetailsWinValidToDateId = 'cstmrRatesDetailsWinValidToDateId';
Modules.CompIds.cstmrRatesDetailsPopTransportMdId = 'cstmrRatesDetailsPopTransportMdId';
Modules.CompIds.cstmrRatesDetailsOrignPopId = 'cstmrRatesDetailsOrignPopId';
Modules.CompIds.cstmrRatesDetailsPopRateTierId = 'cstmrRatesDetailsPopRateTierId';
Modules.CompIds.cstmrRatesDetailsDestinationPopId = 'cstmrRatesDetailsDestinationPopId';
Modules.CompIds.cstmrRatesDetailsConveyanceTypePopId = 'cstmrRatesDetailsConveyanceTypePopId';
Modules.CompIds.cstmrRatesDetailsMakePopId = 'cstmrRatesDetailsMakePopId';
Modules.CompIds.cstmrRatesDetailsModelGrpPopId = 'cstmrRatesDetailsModelGrpPopId';
Modules.CompIds.cstmrRatesDetailsModelPopId = 'cstmrRatesDetailsModelPopId';
Modules.CompIds.cstmrRatesDetailsModelYearId = 'cstmrRatesDetailsModelYearId';
Modules.CompIds.cstmrRatesDetailsOriginCityId = 'cstmrRatesDetailsOriginCityId';
Modules.CompIds.cstmrRatesDetailsPartCdPopId = 'cstmrRatesDetailsPartCdPopId';
Modules.CompIds.cstmrRatesDetailsOriginStProvincePopId = 'cstmrRatesDetailsOriginStProvincePopId';
Modules.CompIds.cstmrRatesDetailsOriginCountryId = 'cstmrRatesDetailsOriginCountryId';
Modules.CompIds.cstmrRatesDetailsDestinationStProvincePopId = 'cstmrRatesDetailsDestinationStProvincePopId';
Modules.CompIds.cstmrRatesDetailsPopWinDestCityId = 'cstmrRatesDetailsPopWinDestCityId';
Modules.CompIds.cstmrRatesDetailsDestCountryPopId = 'cstmrRatesDetailsDestCountryPopId';
Modules.CompIds.cstmrRatesDetailsOriginalOriginPopId = 'cstmrRatesDetailsOriginalOriginPopId';
Modules.CompIds.cstmrRatesDetailsConsolidationTypePopId = 'cstmrRatesDetailsConsolidationTypePopId';
Modules.CompIds.cstmrRatesFinalDestPopId = 'cstmrRatesFinalDestPopId';
Modules.CompIds.cstmrRatesDetailsPopNotChargeableId = 'cstmrRatesDetailsPopNotChargeableId';
Modules.CompIds.cstmrRatesDetailsPopMarkupId = 'cstmrRatesDetailsPopMarkupId';
Modules.CompIds.cstmrRatesMarkupCriteriaPopup = 'cstmrRatesMarkupCriteriaPopup';
Modules.CompIds.cstmrRatesDetailsMarkUpValPopId = 'cstmrRatesDetailsMarkUpValPopId';
Modules.CompIds.cstmrRatesDetailsFactorValPopId = 'cstmrRatesDetailsFactorValPopId';
Modules.CompIds.cstmrRatesDetailsFactorTypePopId = 'cstmrRatesDetailsFactorTypePopId';
Modules.CompIds.cstmrRatesDetailsFactorRatePopId = 'cstmrRatesDetailsFactorRatePopId';
Modules.CompIds.cstmrRatesDetailsUomPopId = 'cstmrRatesDetailsUomPopId';
Modules.CompIds.cstmrRatesDetailsFixedRatePopId = 'cstmrRatesDetailsFixedRatePopId';
Modules.CompIds.cstmrRatesDetailsTariffCdPopId = 'cstmrRatesDetailsTariffCdPopId';
Modules.CompIds.cstmrRatesDetailsTariffUnitRatePopId = 'cstmrRatesDetailsTariffUnitRatePopId';
Modules.CompIds.ctmrRatesLuIndPopup = 'ctmrRatesLuIndPopup';
Modules.CompIds.cstmrRatesTariffCurrencyCodePop = 'cstmrRatesTariffCurrencyCodePop';
Modules.CompIds.cstmrRatesDetailsNonTaxableId = 'cstmrRatesDetailsNonTaxableId';
Modules.CompIds.cstmrRatesMinLoadConveyanceTypeId = 'cstmrRatesMinLoadConveyanceTypeId';
Modules.CompIds.cstmrRatesMinLoadNbrOfVinPopId = 'cstmrRatesMinLoadNbrOfVinPopId';
Modules.CompIds.cstmrRatesMinLoadGridAddEditWinId = 'cstmrRatesMinLoadGridAddEditWinId';
Modules.CompIds.cstmrRatesDetailsCompositeId  = 'cstrmRatesContractDtlsCompositeFlgPopId';
Modules.CompIds.cstmrRatesDetailsPopCargoTypeId = 'cstmrRatesDetailsPopCargoTypeId';
Modules.CompIds.cstmrRatesAgreedMileageGridAddEditWinId = 'cstmrRatesAgreedMileageGridAddEditWinId';
Modules.CompIds.cstmrRatesAgreedMileageOriginPopId  = 'cstmrRatesAgreedMileageOriginPopId';
Modules.CompIds.cstmrRatesAgreedMileageDestinationPopId = 'cstmrRatesAgreedMileageDestinationPopId';
Modules.CompIds.cstmrRatesAgreedMileageDistancePopId  = 'cstmrRatesAgreedMileageDistancePopId';
Modules.CompIds.cstmrRatesAgreedMileageUomPopId  = 'cstmrRatesAgreedMileageUomPopId';
Modules.CompIds.cstmrRatesFuelSurchrgCopyPopSrvcDecsId = 'cstmrRatesFuelSurchrgCopyPopSrvcDecsId';

Modules.CompIds.cstmrRatesFuelSurchrgOriginCityCopyPopupId = 'cstmrRatesFuelSurchrgOriginCityCopyPopupId';
Modules.CompIds.cstmrRatesFuelSurchrgOriginStProvinceCopyPopupId = 'cstmrRatesFuelSurchrgOriginStProvinceCopyPopupId';
Modules.CompIds.cstmrRatesFuelSurchrgOriginCountryCopyPopupId = 'cstmrRatesFuelSurchrgOriginCountryCopyPopupId';

Modules.CompIds.cstmrRatesFuelSurchrgDestCityCopyPopupId = 'cstmrRatesFuelSurchrgDestCityCopyPopupId';
Modules.CompIds.cstmrRatesFuelSurchrgDestStProvCopyPopupId = 'cstmrRatesFuelSurchrgDestStProvCopyPopupId';
Modules.CompIds.cstmrRatesFuelSurchrgDestCountryCopyPopId = 'cstmrRatesFuelSurchrgDestCountryCopyPopId';

Modules.CompIds.cstmrRatesDetailsSrvcCdCopyPopId = 'cstmrRatesDetailsSrvcCdCopyPopId';
Modules.CompIds.cstmrRatesDetailsOriginCityCopyPopupId = 'cstmrRatesDetailsOriginCityCopyPopupId';
Modules.CompIds.cstmrRatesDetailsOriginStProvinceCopyPopId = 'cstmrRatesDetailsOriginStProvinceCopyPopId';
Modules.CompIds.cstmrRatesDetailsOriginCountryCopyPopupId = 'cstmrRatesDetailsOriginCountryCopyPopupId';
Modules.CompIds.cstmrRatesDtlsValidFrmDtCopyPopId = 'cstmrRatesDtlsValidFrmDtCopyPopId';
Modules.CompIds.cstmrRatesDetailsValidToDtCopyPopId = 'cstmrRatesDetailsValidToDtCopyPopId';
Modules.CompIds.cstmrRatesDetailsSupplierCdCopyPopId = 'cstmrRatesDetailsSupplierCdCopyPopId';
Modules.CompIds.cstmrRatesDetailsTransportMdCopyPopId = 'cstmrRatesDetailsTransportMdCopyPopId';
Modules.CompIds.cstmrRatesDetailRateTierPopupId = 'cstmrRatesDetailRateTierPopupId';
Modules.CompIds.cstmrRatesDetailsOrignCopyPopId = 'cstmrRatesDetailsOrignCopyPopId';
Modules.CompIds.cstmrRatesDetailsOriginStProvinceCopyPopId = 'cstmrRatesDetailsOriginStProvinceCopyPopId';
Modules.CompIds.cstmrRatesDetailsOriginCountryCopyPopupId = 'cstmrRatesDetailsOriginCountryCopyPopupId';
Modules.CompIds.cstmrRatesDetailsDestinationCopyPopId = 'cstmrRatesDetailsDestinationCopyPopId';
Modules.CompIds.cstmrRatesDetailsCopyPopDestCityId = 'cstmrRatesDetailsCopyPopDestCityId';
Modules.CompIds.cstmrRatesDetailsDestinationStProvinceCopyPopId = 'cstmrRatesDetailsDestinationStProvinceCopyPopId';
Modules.CompIds.cstmrRatesDetailsDestCountryCopyPopId = 'cstmrRatesDetailsDestCountryCopyPopId';
Modules.CompIds.cstmrRatesDetailsConveyanceTypeCopyPopId = 'cstmrRatesDetailsConveyanceTypeCopyPopId';
Modules.CompIds.cstmrRatesDetailsMakeCopyPopId = 'cstmrRatesDetailsMakeCopyPopId';
Modules.CompIds.cstmrRatesDetailsModelCopyPopId = 'cstmrRatesDetailsModelCopyPopId';
Modules.CompIds.cstmrRatesDetailsModelYearCopyPopId = 'cstmrRatesDetailsModelYearCopyPopId';
Modules.CompIds.cstmrRatesDetailsModelGrpCopyPopId = 'cstmrRatesDetailsModelGrpCopyPopId';
Modules.CompIds.cstmrRatesDetailsPartCdCopyPopId = 'cstmrRatesDetailsPartCdCopyPopId';
Modules.CompIds.cstmrRatesDetailsOriginalOriginCopyPopId = 'cstmrRatesDetailsOriginalOriginCopyPopId';
Modules.CompIds.cstmrRatesFinalDestCopyPopId = 'cstmrRatesFinalDestCopyPopId';
Modules.CompIds.cstmrRatesDetailsConsolidationTypeCopyPopId = 'cstmrRatesDetailsConsolidationTypeCopyPopId';


/******* Event Rating Query *****/
Modules.CompIds.eventRatingQueryFormId = 'eventRatingQueryFormId';
Modules.CompIds.eventRatingQueryCustGridId = 'evntRtngQryCustGridId';
Modules.CompIds.eventRatingQueryExprtExcelId = 'eventRatingQueryExprtExcelId';
Modules.CompIds.eventRatingQueryExprtPDFId = 'Modules.CompIds.eventRatingQueryExprtPDFId';
Modules.CompIds.eventRatingQueryGridCustomerId ='eventRatingQueryGridCustomerId';
Modules.CompIds.eventRatingQueryGridCustomerId2 ='eventRatingQueryGridCustomerId2';
Modules.CompIds.eventRatingQueryGridTrnspModeId = 'eventRatingQueryGridTrnspModeId';
Modules.CompIds.eventRatingQueryGridTrnspModeId2 = 'eventRatingQueryGridTrnspModeId2';
Modules.CompIds.eventRatingQueryGridMakeId = 'eventRatingQueryGridMakeId';
Modules.CompIds.eventRatingQueryGridMakeId2 = 'eventRatingQueryGridMakeId2';
Modules.CompIds.eventRatingQueryGridModelId =  'eventRatingQueryGridModelId';
Modules.CompIds.eventRatingQueryGridModelId2 =  'eventRatingQueryGridModelId2';
Modules.CompIds.eventRatingQueryGridModeGrpId = 'eventRatingQueryGridModeGrpId';
Modules.CompIds.eventRatingQueryGridModeGrpId2 = 'eventRatingQueryGridModeGrpId2';
Modules.CompIds.eventRatingQueryGridSuppPartNumId = 'eventRatingQueryGridSuppPartNumId';

Modules.CompIds.eventRatingQuerySuppGridId = 'evntRtngQrySuppGridId';
Modules.CompIds.eventRatingQuerySuppExprtExcelId = 'eventRatingQuerySuppExprtExcelId';
Modules.CompIds.eventRatingQuerySuppExprtPDFId = 'Modules.CompIds.eventRatingQuerySuppExprtPDFId';
Modules.CompIds.eventRatingQueryGridSuppCustomerId ='eventRatingQueryGridSuppCustomerId';
Modules.CompIds.eventRatingQueryGridSuppCustomerId2 ='eventRatingQueryGridSuppCustomerId2';
Modules.CompIds.eventRatingQueryGridSuppTrnspModeId = 'eventRatingQueryGridSuppTrnspModeId';
Modules.CompIds.eventRatingQueryGridSuppTrnspModeId2 = 'eventRatingQueryGridSuppTrnspModeId2';
Modules.CompIds.eventRatingQueryGridSuppMakeId = 'eventRatingQueryGridSuppMakeId';
Modules.CompIds.eventRatingQueryGridSuppMakeId2 = 'eventRatingQueryGridSuppMakeId2';
Modules.CompIds.eventRatingQueryGridSuppModelId =  'eventRatingQueryGridSuppModelId';
Modules.CompIds.eventRatingQueryGridSuppModelId2 =  'eventRatingQueryGridSuppModelId2';
Modules.CompIds.eventRatingQueryGridSuppModeGrpId = 'eventRatingQueryGridSuppModeGrpId';
Modules.CompIds.eventRatingQueryGridSuppModeGrpId2 = 'eventRatingQueryGridSuppModeGrpId2';

Modules.CompIds.eventRatingQuerySupplierId = 'eventRatingQuerySupplierId';
Modules.CompIds.eventRatingQueryCustomerId = 'eventRatingQueryCustomerId';
Modules.CompIds.eventRatingQueryDebtorPartyId = 'eventRatingQueryDebtorPartyId';
Modules.CompIds.eventRatingQueryServiceTypeId = 'eventRatingQueryServiceTypeId';
Modules.CompIds.eventRatingQueryServiceCodeId = 'eventRatingQueryServiceCodeId';
Modules.CompIds.eventRatingQueryServiceGroupId = 'eventRatingQueryServiceGroupId';
Modules.CompIds.eventRatingQueryUnitId = 'eventRatingQueryUnitId';
Modules.CompIds.eventRatingQueryMakeId = 'eventRatingQueryMakeId';
Modules.CompIds.eventRatingQueryModelId = 'eventRatingQueryModelId';
Modules.CompIds.eventRatingQueryModelGroupId = 'eventRatingQueryModelGroupId';
Modules.CompIds.eventRatingQueryTransportModeId = 'eventRatingQueryTransportModeId';
Modules.CompIds.eventRatingQueryConveyanceId = 'eventRatingQueryConveyanceId';
Modules.CompIds.eventRatingQueryConveyanceTypeId = 'eventRatingQueryConveyanceTypeId';
Modules.CompIds.eventRatingQueryConsolidationTypeId = 'eventRatingQueryConsolidationTypeId';
Modules.CompIds.eventRatingQueryConsolidationId = 'eventRatingQueryConsolidationId';
Modules.CompIds.eventRatingQueryProfitLossCenterId = 'eventRatingQueryProfitLossCenterId';
Modules.CompIds.eventRatingQueryEventLoadReferenceId = 'eventRatingQueryEventLoadReferenceId';
Modules.CompIds.eventRatingQueryShippingReferenceId = 'eventRatingQueryShippingReferenceId';
Modules.CompIds.eventRatingQueryWorkOrderId = 'eventRatingQueryWorkOrderId';
Modules.CompIds.eventRatingQueryShipmentTypeId = 'eventRatingQueryShipmentTypeId';
Modules.CompIds.eventRatingQueryRateTierId = 'eventRatingQueryRateTierId';
Modules.CompIds.eventRatingQueryEventDateId ='eventRatingQueryEventDateId';
Modules.CompIds.eventRatingQueryFromDateId = 'eventRatingQueryFromDateId';
Modules.CompIds.eventRatingQueryToDateId = 'eventRatingQueryToDateId';
Modules.CompIds.eventRatingQueryRatingBlankId = 'eventRatingQueryRatingBlankId';
Modules.CompIds.eventRatingQuerySupplierStatusId ='eventRatingQuerySupplierStatusId';
Modules.CompIds.eventRatingQueryCustomerStatusId = 'eventRatingQueryCustomerStatusId';
Modules.CompIds.eventRatingQueryOriginId = 'eventRatingQueryOriginId';
Modules.CompIds.eventRatingQueryOriginCityId = 'eventRatingQueryOriginCityId';
Modules.CompIds.eventRatingQueryOriginStateProvinceId = 'eventRatingQueryOriginStateProvinceId';
Modules.CompIds.eventRatingQueryOriginalOriginId ='eventRatingQueryOriginalOriginId';
Modules.CompIds.eventRatingQueryRatingDestinationId = 'eventRatingQueryRatingDestinationId';
Modules.CompIds.eventRatingQueryDestinationId ='eventRatingQueryDestinationId';
Modules.CompIds.eventRatingQueryDestinationCityId ='eventRatingQueryDestinationCityId';
Modules.CompIds.eventRatingQueryDestinationStateProvinceId = 'eventRatingQueryDestinationStateProvinceId';
Modules.CompIds.eventRatingQueryFinalDestinationId = 'eventRatingQueryFinalDestinationId';
Modules.CompIds.eventRatingQueryRatingVarianceEventId = 'eventRatingQueryRatingVarianceEventId';
Modules.CompIds.deleteCustomerDebtorRecordId='deleteCustomerDebtorRecordId';

Modules.CompIds.contractIdentificationGridId='contractIdentificationGridId';
Modules.CompIds.defaultSupplierGridId='defaultSupplierGridId';
Modules.CompIds.rateRoundingCriteriaGridId='rateRoundingCriteriaGridId';
Modules.CompIds.distanceRoundingCriteriaGridId='distanceRoundingCriteriaGridId';
Modules.CompIds.evntRtngQryGridDestinationId = 'evntRtngQryGridDestinationId';
Modules.CompIds.evntRtngQryDestinationId = 'evntRtngQryDestinationId';
Modules.CompIds.eventRatingQueryGridShpmntDateId = 'eventRatingQueryGridShpmntDateId';
Modules.CompIds.eventRatingQueryGridDlvryDateId = 'eventRatingQueryGridDlvryDateId';
Modules.CompIds.eventRatingQuerySupplierPopUpWinId = 'eventRatingQuerySupplierPopUpWinId';



Modules.CompIds.eventRatingQueryPopUnitId = 'eventRatingQueryPopUnitId';
Modules.CompIds.eventRatingQueryPopOriginLocation = 'eventRatingQueryPopOriginLocation';
Modules.CompIds.eventRatingQueryPopDestinationId = 'eventRatingQueryPopDestinationId';
Modules.CompIds.eventRatingQueryPopFromDateId = 'eventRatingQueryPopFromDateId';
Modules.CompIds.eventRatingQueryPopToDateId = 'eventRatingQueryPopToDateId';
Modules.CompIds.eventRatingQueryPopModelId = 'eventRatingQueryPopModelId';
Modules.CompIds.eventRatingQueryPopMakeId = 'eventRatingQueryPopMakeId';


Modules.CompIds.contactPrsnOceanSupplierMasterGridId  =  'contactPrsnOceanSupplierMasterGridId';
Modules.CompIds.oceanSupplrMasterContactPersonGridPopupId = 'oceanSupplrMasterContactPersonGridPopupId';
Modules.CompIds.ocnSupplrMasterContactPrsnEditPopId = 'ocnSupplrMasterContactPrsnEditPopId';

/** Customer Rate query screen */
Modules.CompIds.customerRateQueryTabPanelId='custRateQueryParentPanelId',
Modules.CompIds.customerRateQueryGridId='customerRateQueryGridId';
Modules.CompIds.popupCustomerRateQueryId='popupCustomerRateQueryId';
Modules.CompIds.oceanCustomerRateQueryGridId='oceanCustomerRateQueryGridId';

Modules.CompIds.customerRateQueryPopupWinId='customerRateQueryGridPopupWinId';
Modules.CompIds.customerRateQueryNonOceanGridPopUpId = 'customerRateQueryNonOceanGridPopUpId';

/** Customer Rate query service code screen*/
Modules.CompIds.CustomerRateQueryServCdParentTabPanelId='CustomerRateQueryServCdParentTabPanelId',
Modules.CompIds.customerRateQuerySrvCdGridId='customerRateQuerySrvCdGridId',
Modules.CompIds.customerRateQueryServCdPopupWinId='customerRateQueryServCdPopupWinId';
Modules.CompIds.popupCustomerRateQueryServCdId='popupCustomerRateQueryServCdId';
Modules.CompIds.custRateCustomerId='custRateCustomerId';
Modules.CompIds.custRateContractId='custRateContractId';
Modules.CompIds.custRateServiceCodeId='custRateServiceCodeId';
Modules.CompIds.custRatefrmDttm='custRatefrmDttm';
Modules.CompIds.custRateToDttm='custRateToDttm';
Modules.CompIds.custRateNameId='custRateNameId';
Modules.CompIds.custRateFormId='custRateFormId';
Modules.CompIds.custRateExcelReportId='custRateExcelReportId';
Modules.CompIds.custRatePdfReportId='custRatePdfReportId';
Modules.CompIds.customerRateQueryPopupWinId='customerRateQueryGridPopupWinId';
Modules.CompIds.customerRateVerificationGridStoreId='customerRateGridStore';
Modules.CompIds.customerRateQueryPopupWinId='customerRateQueryGridPopupWinId';
Modules.CompIds.customerRateverificationQueryPopupWinId='customerRateVerificationPopupWindowId';
Modules.CompIds.customerRateVerificationGridId='customerRate VerificationGridId';
Modules.CompIds.effectiveDateId='Effective Date Id';
Modules.CompIds.customerNameId='CustomerNameId';

Modules.CompIds.customerMasterPanelIdParentId='customerMasterPanelIdParentId';
Modules.CompIds.distanceRoundingCriteriaGridId='distanceRoundingCriteriaGridId';
Modules.CompIds.deleteRateRoundingRecordId='deleteRateRoundingRecordId';
Modules.CompIds.addRateRoundingRecordId='addRateRoundingRecordId';
Modules.CompIds.addDefaultSupplierRecordId='addDefaultSupplierRecordId';
Modules.CompIds.deleteDefaultSupplierRecordId='deleteDefaultSupplierRecordId';
Modules.CompIds.addDistanceRoundingRecordId='addDistanceRoundingRecordId';
Modules.CompIds.deleteDistanceRoundingRecordId='deleteDistanceRoundingRecordId';
Modules.CompIds.addContractIdentificationRecordId='addContractIdentificationRecordId';



/** Event Status Query screen*/
Modules.CompIds.eventStatusQueryPanelId='eventStatusQueryPanelId';
Modules.CompIds.eventStatusQueryExportPdfId='eventStatusQueryExportPdfId';
Modules.CompIds.eventStatusQueryExportExcelId='eventStatusQueryExportExcelId';
Modules.CompIds.popServiceCode='popServiceCode';
Modules.CompIds.popSupplierId='popSupplierId';
Modules.CompIds.popCustomerId='popCustomerId';
Modules.CompIds.popEventLoadReferenceId='popEventLoadReferenceId';
Modules.CompIds.popUnitId='popUnitId';
Modules.CompIds.popShippingReferenceId='popShippingReferenceId';
Modules.CompIds.popOriginLocation='popOriginLocation';
Modules.CompIds.popDestinationId='popDestinationId';
Modules.CompIds.popDealerCodeId='popDealerCodeId';
Modules.CompIds.popTenderRequestDateId='popTenderRequestDateId';
Modules.CompIds.popShipmentDateId='popShipmentDateId';
Modules.CompIds.popDeliveryCompletionDate='popDeliveryCompletionDate';
Modules.CompIds.popMakeId='popMakeId';
Modules.CompIds.popModelId='popModelId';
Modules.CompIds.popModelYearId='popModelYearId';
Modules.CompIds.popmodelGroupId='popmodelGroupId';
Modules.CompIds.popTransportModeId='popTransportModeId';
Modules.CompIds.popConveyanceId='popConveyanceId';
Modules.CompIds.popConveyanceTypeId='popConveyanceTypeId';
Modules.CompIds.popConveyanceNameId='popConveyanceNameId';
Modules.CompIds.popConsolidationId='popConsolidationId';
Modules.CompIds.popConsolidationTypeId='popConsolidationTypeId';
Modules.CompIds.popTransportCodeId='popTransportCodeId';
Modules.CompIds.popCustomerSalesRegionId='popCustomerSalesRegionId';
Modules.CompIds.popShipmentTypeId='popShipmentTypeId';
Modules.CompIds.popOrderTypeId='popOrderTypeId';
Modules.CompIds.popAbnormalMoveTypeId='popAbnormalMoveTypeId';
Modules.CompIds.popAddressLine1oId='popAddressLine1oId';
Modules.CompIds.popAddressLine2oId='popAddressLine2oId';
Modules.CompIds.popCityoId='popCityoId';
Modules.CompIds.popStateProvinceoId='popStateProvinceoId';
Modules.CompIds.popZipPostalCdoId='popZipPostalCdoId';
Modules.CompIds.popCountryoId='popCountryoId';
Modules.CompIds.popAddressLine1dId='popAddressLine1dId';
Modules.CompIds.popAddressLine2dId='popAddressLine2dId';
Modules.CompIds.popCitydId='popCitydId';
Modules.CompIds.popStateProvincedId='popStateProvincedId';
Modules.CompIds.popZipPostalCddId='popZipPostalCddId';
Modules.CompIds.popCountrydId='popCountrydId';
Modules.CompIds.popOriginalOriginId='popOriginalOriginId';
Modules.CompIds.popFinalDestinationId='popFinalDestinationId';
Modules.CompIds.popWeightId='popWeightId';
Modules.CompIds.popLengthId='popLengthId';
Modules.CompIds.popWidthId='popWidthId';
Modules.CompIds.popHeightId='popHeightId';
Modules.CompIds.popVolumeId='popVolumeId';
Modules.CompIds.popQuantityId='popQuantityId';
Modules.CompIds.popStorageQtyId='popStorageQtyId';
Modules.CompIds.popStorageUOMId='popStorageUOMId';
Modules.CompIds.popPreviousChargeQtyId='popPreviousChargeQtyId';
Modules.CompIds.popPreviousChargeUOMCodeId='popPreviousChargeUOMCodeId';
Modules.CompIds.popProfitLossCenterId='popProfitLossCenterId';
Modules.CompIds.popWorkOrderNumberId='popWorkOrderNumberId';
Modules.CompIds.popPartNumberId='popPartNumberId';




Modules.CompIds.serviceTypeForCustomerMaster='serviceTypeForCustomerMaster';

/*---------------------Customer Service Group Setup-------------------*/




Modules.CompIds.custSrvGrpSetupFormId='custSrvGrpSetupFormId';
Modules.CompIds.cstmrSrvGrpCustomerCode='cstmrSrvGrpCustomerCode';
Modules.CompIds.cstmrSrvGrpCustomerName='cstmrSrvGrpCustomerName';
Modules.CompIds.cstmrSrvGrpServiceGrpCode='cstmrSrvGrpServiceGrpCode';
Modules.CompIds.cstmrSrvGrpServiceGrpDesc='cstmrSrvGrpServiceGrpDesc';

Modules.CompIds.cstmrSrvGrpSetupGridId='cstmrSrvGrpSetupGridId';
Modules.CompIds.cstmrSrvGrpSetupAddRecordId='cstmrSrvGrpSetupAddRecordId';
Modules.CompIds.grpSetupSrvTypeGridId='grpSetupSrvTypeGridId';
Modules.CompIds.cstmrSrvGrpSetupdeleteRecordId='cstmrSrvGrpSetupdeleteRecordId';
Modules.CompIds.cstmrSrvGrpSetupGridCopyId='cstmrSrvGrpSetupGridCopyId';
Modules.CompIds.cstmrSetupGridcustomerId='cstmrSetupGridcustomerId';
Modules.CompIds.cstmrSetupGridSrvGrpCd='cstmrSetupGridSrvGrpCd';
Modules.CompIds.cstmrSetupGridCstmrName='cstmrSetupGridCstmrName';
Modules.CompIds.grpSetupSrvTypeGridServiceTypeId='grpSetupSrvTypeGridServiceTypeId';
Modules.CompIds.grpSetupSrvTypeGridServiceCodeId='grpSetupSrvTypeGridServiceCodeId';
Modules.CompIds.editCstmrSrvGrpGridFormId='editCstmrSrvGrpGridFormId';
Modules.CompIds.editCstmrSrvGrpGridWinId='editCstmrSrvGrpGridWinId';
Modules.CompIds.editCstmrSrvGrpGridWinSaveBtnId='editCstmrSrvGrpGridWinSaveBtnId';
Modules.CompIds.cstmrSrvTypeGridAddRecordId='cstmrSrvTypeGridAddRecordId';
Modules.CompIds.editCstmrSrvTypeCodeFormId='editCstmrSrvTypeCodeFormId';
Modules.CompIds.editCstmrSrvTypeGridWinId='editCstmrSrvTypeGridWinId';
Modules.CompIds.editCstmrSrvTypeGridWinSaveBtnId='editCstmrSrvTypeGridWinSaveBtnId';
Modules.CompIds.customerSrvGrpSetupCustomerId='customerSrvGrpSetupCustomerId';
Modules.CompIds.cstmrSrvGrpSetupServiceTypeId='cstmrSrvGrpSetupServiceTypeId';
Modules.CompIds.cstmrSrvGrpSetupServiceCodeId='cstmrSrvGrpSetupServiceCodeId';
Modules.CompIds.ediWinCustomerCdId='ediWinCustomerCdId';
Modules.CompIds.ediWinCustomerNameId='ediWinCustomerNameId';
Modules.CompIds.ediWinServiceGrpCodeId='ediWinServiceGrpCodeId';
Modules.CompIds.ediWinServiceGrpDescId='ediWinServiceGrpDescId';
Modules.CompIds.editCstmrSrvGrpWinStatusId='editCstmrSrvGrpWinStatusId';
Modules.CompIds.ediWinSrvTypeId='ediWinSrvTypeId';
Modules.CompIds.ediWinSrvCodeId='ediWinSrvCodeId';
Modules.CompIds.ediWinServiceDescId='ediWinServiceDescId';
Modules.CompIds.editCstmrSrvTypeWinStatusId='editCstmrSrvTypeWinStatusId';
Modules.CompIds.grpSetupSrvTypeGridServiceCodeDescId='grpSetupSrvTypeGridServiceCodeDescId';
Modules.CompIds.editCstmrSrvTypeWinCstmrId='editCstmrSrvTypeWinCstmrId';
Modules.CompIds.editCstmrSrvTypeWinSrvGrpCdId='editCstmrSrvTypeWinSrvGrpCdId';
Modules.CompIds.cstmrSrvGrpSetupDoneId='cstmrSrvGrpSetupDoneId';
Modules.CompIds.cstmrSrvTypewinDoneId='cstmrSrvTypewinDoneId';



Modules.CompIds.customerInvoiceSetupTabPanelId='customerInvoiceSetupTabPanelId';
Modules.CompIds.deleteContractIdentificationRecordId='deleteContractIdentificationRecordId';

Modules.CompIds.actualGroupingCriteriaGridId='actualGroupingCriteriaGridId';

Modules.CompIds.TriggerIdentificationGridId='TriggerIdentificationGridId';


Modules.CompIds.serviceTypeForCustomerInvoice='serviceTypeForCustomerInvoice';
Modules.CompIds.accurualTriggerPointForInvoice='accurualTriggerPointForInvoice';
Modules.CompIds.triggerPointForInvoice='triggerPointForInvoice';
Modules.CompIds.addCustomerInvoiceSetUpId='addCustomerInvoiceSetUpId';
Modules.CompIds.addActualInvoiceGroupingGrid='addActualInvoiceGroupingGrid';

/*** Customer Invoice Status Screen ***/
Modules.CompIds.custmrComboCustomerInvoiceId = 'customerInvoiceStatusId';
Modules.CompIds.dbtrPartyComboCustomerInvoiceId = 'dbtrPartyCustomerInvoiceId';
Modules.CompIds.customerInvoiceFrmDateId = 'customerInvoiceFrmDateId';
Modules.CompIds.customerInvoiceToDateId = 'customerInvoiceToDateId';
Modules.CompIds.customerInvoiceActualId = 'customerInvoiceActualId';
Modules.CompIds.customerInvoiceAccuralId = 'customerInvoiceAccuralId';
Modules.CompIds.customerInvoiceProformaId = 'customerInvoiceProformaId';
Modules.CompIds.customerInvoiceRejectedId = 'customerInvoiceRejectedId';
Modules.CompIds.customerInvoiceFinalId = 'customerInvoiceFinalId';
Modules.CompIds.customerInvoicePaidId = 'customerInvoicePaidId';
Modules.CompIds.customerInvoiceCreditId = 'customerInvoiceCreditId';
Modules.CompIds.customerInvoiceDebitId = 'customerInvoiceDebitId';
Modules.CompIds.customerInvoiceStatusGridId = 'customerInvoiceStatusGridId';
Modules.CompIds.customerInvoiceNoComboId = 'invoiceNoId';
Modules.CompIds.dbtrComboCustomerInvoiceId = 'dbtrComboCustomerInvoiceId';
Modules.CompIds.customerInvoiceStatusPopupWinId = 'customerInvoiceStatusPopupWinId';
Modules.CompIds.popupCustomerInvoiceStatusId = 'popupCustomerInvoiceStatusId';
Modules.CompIds.customerInvoiceStatusPrintPopupWinId = 'customerInvoiceStatusPrintPopupWinId';
Modules.CompIds.popupCustomerInvoiceStatusPrintId = 'popupCustomerInvoiceStatusPrintId';
Modules.CompIds.customerInvoiceBackUpFlgId= 'customerInvoiceBackUpFlgId';
Modules.CompIds.customerInvoiceFlgId= 'customerInvoiceFlgId';
Modules.CompIds.viewPrintId='viewPrintId';
Modules.CompIds.emailPrintId='emailPrintId';
Modules.CompIds.customerPrintId='customerPrintId';
Modules.CompIds.customerInvoicePrinterCd = 'customerInvoicePrinterCd';
Modules.CompIds.customerBackUpPrinterCd = 'customerBackUpPrinterCd';
Modules.CompIds.customerInvoiceCopiesId = 'customerInvoiceCopiesId';
Modules.CompIds.customerInvoiceBackUpCopiesId = 'customerInvoiceBackUpCopiesId';
Modules.CompIds.customerInvoiceCCMailId = 'customerInvoiceCCMailId';
Modules.CompIds.CustomerInvoiceSummaryFormId='customerInvoiceSummaryFormId';


/***************Customer Master***************/
Modules.CompIds.addCustomerMasterDerails='addCustomerMasterDerails';
Modules.CompIds.deleteCustomerMasterGridId='deleteCustomerMasterGridId';
Modules.CompIds.customerMasterGridId='customerMasterGridId';
Modules.CompIds.popupCustomerMasterFormId='popupCustomerMasterFormId';
Modules.CompIds.customerMasterFormId='customerMasterFormId';
Modules.CompIds.contractIdentificationPopUpFormId='contractIdentificationPopUpFormId';
Modules.CompIds.editWinStatusDateId='editWinStatusDateId';
Modules.CompIds.editWinDestinationId='editWinDestinationId';
Modules.CompIds.editWinOriginId='editWinOriginId';
Modules.CompIds.editWinsupplierId='editWinsupplierId';
Modules.CompIds.editDefaultSupplierGridWin='editDefaultSupplierGridWin';
Modules.CompIds.editContractIdentificationWinId='editContractIdentificationWinId';
Modules.CompIds.editDistanceRoundingWinId='editDistanceRoundingWinId';
Modules.CompIds.editRateRoundingWinId='editRateRoundingWinId';
Modules.CompIds.ediWinUOMId='ediWinUOMId';
Modules.CompIds.ediWinRoundingTypeId='ediWinRoundingTypeId';
Modules.CompIds.editWinRoundingValueId='editWinRoundingValueId';
Modules.CompIds.editWinMinDistValueId='editWinMinDistValueId';
Modules.CompIds.ediWinCurrencyId='ediWinCurrencyId';
Modules.CompIds.editTrnsTypeWinId='editTrnsTypeWinId';
Modules.CompIds.contractIdentificationWinDoneId='contractIdentificationWinDoneId';
Modules.CompIds.customerMasterWinDoneId='customerMasterWinDoneId';
Modules.CompIds.defaultSupplierWinDoneId='defaultSupplierWinDoneId';
Modules.CompIds.distanceCriteriaWinDoneId='distanceCriteriaWinDoneId';
Modules.CompIds.rateCriteriaWinDoneId='rateCriteriaWinDoneId';
Modules.CompIds.defaultSupplierPopUpFormId='defaultSupplierPopUpFormId';
Modules.CompIds.distanceCriteriaPopUpFormId='distanceCriteriaPopUpFormId';
Modules.CompIds.rateCriteriaPopUpFormId='rateCriteriaPopUpFormId';
Modules.CompIds.customerMasterPopUpFormId='customerMasterPopUpFormId';
Modules.CompIds.TriggerIdentificationGridDeleteId='TriggerIdentificationGridDeleteId';
Modules.CompIds.addActualGroupingCriteriaGridId='addActualGroupingCriteriaGridId';
Modules.CompIds.generationFrequencyForInvoice='generationFrequencyForInvoice';
Modules.CompIds.generationFrequencyForActualInvoice='generationFrequencyForActualInvoice';
Modules.CompIds.addActualInvoiceId='addActualInvoiceId';
Modules.CompIds.addInvoiceGroupingId='addInvoiceGroupingId';
Modules.CompIds.deleteActualInvoiceGroupingId='deleteActualInvoiceGroupingId';
Modules.CompIds.customerDetailsGridOrignStateId='customerDetailsGridOrignStateId';

Modules.CompIds.cstmrContractIdentificationOriginId='cstmrContractIdentificationOriginId';
Modules.CompIds.cstmrMasterDetailsGridOrignStateId='cstmrMasterDetailsGridOrignStateId';
Modules.CompIds.editStatusDtSrvTypeId='editStatusDtSrvTypeId';
Modules.CompIds.editStatusDtSrvCdId='editStatusDtSrvCdId';
Modules.CompIds.editStatusDtOriginId='editStatusDtOriginId';
Modules.CompIds.editStatusDtDestId='editStatusDtDestId';
Modules.CompIds.editStatusDtId='editStatusDtId';
Modules.CompIds.editWinDefaultSrvTypeId='editWinDefaultSrvTypeId';
Modules.CompIds.editRateRndSrvTypeId='editRateRndSrvTypeId';
Modules.CompIds.editRateRndCurrCdId='editRateRndCurrCdId';
Modules.CompIds.editcustomerMasterName='editcustomerMasterName';
Modules.CompIds.statusDateServiceTypeId='statusDateServiceTypeId';

/* Ocean Customer Invoice Generation */

Modules.CompIds.oceanCstmrInvcGenFormId='oceanCstmrInvcGenFormId';
Modules.CompIds.oceanCstmrInvcGenGridId='oceanCstmrInvcGenGridId';
Modules.CompIds.cstmrInvcGenAdvContainer='cstmrInvcGenAdvContainer';
Modules.CompIds.oceanCstmrInvcGenGridFormId='oceanCstmrInvcGenGridFormId';
Modules.CompIds.invcGenGridPopWinId='invcGenGridPopWinId';
Modules.CompIds.invcGenFinalizeWinGridId='invcGenGridPopWinId';







/***************Customer Master***************/





/******* Event Rating Query For Ocean*****/
Modules.CompIds.oceanEventRatingQueryCargoPopupId = 'oceanEventRatingQueryCargoPopupId';
Modules.CompIds.oceanEventRatingQueryAdvContainer = 'oceanEventRatingQueryAdvContainer';
Modules.CompIds.oceanEventRatingQueryFormId = 'oceanEventRatingQueryFormId';
Modules.CompIds.oceanEventRatingQueryPopupId = 'oceanEventRatingQueryPopupId';
Modules.CompIds.oceanEventRatingQueryTaxWinId = 'oceanEventRatingQueryTaxWinId';
Modules.CompIds.oceanEventRatingQueryPanelId = 'oceanEventRatingQueryPanelId';
Modules.CompIds.oceanEventRatingQueryPopupPanelId = 'oceanEventRatingQueryPopupPanelId';
Modules.CompIds.oceanEventRatingQueryTabPopupId = 'oceanEventRatingQueryTabPopupId';
Modules.CompIds.oceanEventRatingQueryPanelIdParentId='oceanEventRatingQueryPanelIdParentId';
Modules.CompIds.oceanEventRatingQueryCargoGridId='oceanEventRatingQueryCargoGridId';
Modules.CompIds.oceanEventRatingQueryGridId='oceanEventRatingQueryGridId';
Modules.CompIds.oceanEventRateQueryCustomerCargoGridId='oceanEventRateQueryCustomerCargoGridId';
Modules.CompIds.oceanEventRateQuerySupplierCargoGridId='oceanEventRateQuerySupplierCargoGridId';
Modules.CompIds.oceanEventRatingQueryPopUpWinId='oceanEventRatingQueryPopUpWinId';
Modules.CompIds.oceanEventRatingQueryCustomerCargoPopUpWinId='oceanEventRatingQueryCustomerCargoPopUpWinId';
Modules.CompIds.oceanEventRatingQuerySupplierCargoPopUpWinId='oceanEventRatingQuerySupplierCargoPopUpWinId';
Modules.CompIds.oceanEventRatingChildActionColId='oceanEventRatingChildActionColId';
Modules.CompIds.oceanEventRatingChildPopupColId='oceanEventRatingChildPopupColId';
Modules.CompIds.oceanEventRatingQueryPopId='oceanEventRatingQueryPopId';
Modules.CompIds.oceanEventRatingQueryPartyId='oceanEventRatingQueryPartyId';



/******* Supplier Line Item Status For NonOcean*****/
Modules.CompIds.supplierLineItemStatusTabParentId = 'supplierLineItemStatusTabParentId';
Modules.CompIds.supplierLineItemStatusFormId = 'supplierLineItemStatusFormId';
Modules.CompIds.suppListItemAdvContainer = 'suppListItemAdvContainer';




Modules.CompIds.actualInvoiceGroupingGridId='actualInvoiceGroupingGridId';

/**** Ocean Supplier Rate Query Service Code****/
Modules.CompIds.oceanSupplierRateQueryServiceParentTabpanelId					=	'oceanSupplierRateQueryServiceParentTabpanelId';
Modules.CompIds.oceanSupplierRateQueryServiceFormId								=	'oceanSupplierRateQueryServiceFormId';
Modules.CompIds.oceanSupplierRateQueryServiceSupId								=	'oceanSupplierRateQueryServiceSupId';
Modules.CompIds.oceanSupplierRateQueryServiceContractidId						=	'oceanSupplierRateQueryServiceContractidId';
Modules.CompIds.oceanSupplierRateQueryServiceChargeCdId							=	'oceanSupplierRateQueryServiceChargeCdId';
Modules.CompIds.oceanSupplierRateQueryServicePgId								=	'oceanSupplierRateQueryServicePgId';
Modules.CompIds.oceanSupplierRateQueryServicePGridId							=	'oceanSupplierRateQueryServicePGridId';
Modules.CompIds.oceanSupplierRateQueryServiceAddRecordPId						=	'oceanSupplierRateQueryServiceAddRecordPId';
Modules.CompIds.oceanSupplierRateQueryServiceDeleteRecordPId					=	'oceanSupplierRateQueryServiceDeleteRecordPId';
Modules.CompIds.oceanSupplierRateQueryServiceCopyRecordPId						=	'oceanSupplierRateQueryServiceCopyRecordPId';
Modules.CompIds.oceanSupplierRateQueryServiceChGridId							=	'oceanSupplierRateQueryServiceChGridId';
Modules.CompIds.oceanSupplierRateQueryServiceAddRecordChId						=	'oceanSupplierRateQueryServiceAddRecordChId';
Modules.CompIds.oceanSupplierRateQueryServiceDeleteRecordChId					=	'oceanSupplierRateQueryServiceDeleteRecordChId';
Modules.CompIds.oceanSupplierRateQueryServiceCopyRecordChId						=	'oceanSupplierRateQueryServiceCopyRecordChId';
Modules.CompIds.oceanSupplierRateQueryServiceChgridPanelId						=	'oceanSupplierRateQueryServiceChgridPanelId';
Modules.CompIds.oceanSupplierRateQueryServiceChGridPopupFormId					=	'oceanSupplierRateQueryServiceChGridPopupFormId';
Modules.CompIds.oceanSupplierRateQueryServicePGridPopupFormId					=	'oceanSupplierRateQueryServicePGridPopupFormId';
/*** Supplier Invoice Status Screen ***/
Modules.CompIds.supplierInvoiceStsFormId					   		= 'supplierInvoiceStsFormId';
Modules.CompIds.supplierInvoiceStsSupplrComboId 		   			= 'supplierInvoiceStsSupplrComboId';
Modules.CompIds.supplierInvoiceStsInvcNoComboId 		   			= 'supplierInvoiceStsInvcNoComboId';
Modules.CompIds.supplierInvoiceStsFrmDateId				   	    	= 'supplierInvoiceStsFrmDateId';
Modules.CompIds.supplierInvoiceStsToDateId                      	= 'supplierInvoiceStsToDateId';
Modules.CompIds.supplierInvoiceEvntLdRefId 					    	= 'supplierInvoiceStsEvntLdRefId';
Modules.CompIds.supplierInvoiceStsCnvynceId 						= 'supplierInvoiceStsCnvynceId';
Modules.CompIds.supplierInvoiceStsShpRefId 					    	= 'supplierInvoiceStsShpRefId';
Modules.CompIds.supplierInvoiceStsPrfmaId 					    	= 'supplierInvoiceStsPrfmaId';
Modules.CompIds.supplierInvoiceStsRdyForRcnltnId 			    	= 'supplierInvoiceStsRdyForRcnltnId';
Modules.CompIds.supplierInvoiceStsUndrInvgtId 		     	    	= 'supplierInvoiceStsUndrInvgtId';
Modules.CompIds.supplierInvoiceStsApprvdId				        	= 'supplierInvoiceStsApprvdId';
Modules.CompIds.supplierInvoiceStsRjctdId				        	= 'supplierInvoiceStsRjctdId';
Modules.CompIds.supplierInvoiceStsPaidId				        	= 'supplierInvoiceStsPaidId';
Modules.CompIds.supplierInvoiceStsInvoiceId				       	    = 'supplierInvoiceStsInvoiceId';
Modules.CompIds.supplierInvoiceStsCreditId				        	= 'supplierInvoiceStsCreditId';
Modules.CompIds.supplierInvoiceStsDebitId				        	= 'supplierInvoiceStsDebitId';
Modules.CompIds.supplierInvoiceStsPdfId				            	= 'supplierInvoiceStsPdfId';
Modules.CompIds.supplierInvoiceStsExcelId				        	= 'supplierInvoiceStsExcelId';
Modules.CompIds.supplierInvoiceStsAsdId				            	= 'supplierInvoiceStsAsdId';
Modules.CompIds.supplierInvoiceStsDsdId				            	= 'supplierInvoiceStsDsdId';
Modules.CompIds.supplierInvoiceStsGridId				        	= 'supplierInvoiceStsGridId';
Modules.CompIds.supplierInvoiceStsPopUpWinFormId					= 'supplierInvoiceStsPopUpWinFormId';
Modules.CompIds.supplierInvoiceStsPopUpWinSpplrId					= 'supplierInvoiceStsPopUpWinSpplrId';
Modules.CompIds.supplierInvoiceStsPopUpWinInvcNoId					= 'supplierInvoiceStsPopUpWinInvcNoId';
Modules.CompIds.supplierInvoiceStsPopUpWinInvcDtId					= 'supplierInvoiceStsPopUpWinInvcDtId';
Modules.CompIds.supplierInvoiceStsPopUpWinDocTypeId					= 'supplierInvoiceStsPopUpWinDocTypeId';
Modules.CompIds.supplierInvoiceStsPopUpWinInvcAmtId					= 'supplierInvoiceStsPopUpWinInvcAmtId';
Modules.CompIds.supplierInvoiceStsPopUpWinApprvdAmtId				= 'supplierInvoiceStsPopUpWinApprvdAmtId';
Modules.CompIds.supplierInvoiceStsPopUpWinPaidAmtId		    		= 'supplierInvoiceStsPopUpWinPaidAmtId';
Modules.CompIds.supplierInvoiceStsPopUpWinCurrencyId		    	= 'supplierInvoiceStsPopUpWinCurrencyId';
Modules.CompIds.supplierInvoiceStsPopUpWinDueDtId		        	= 'supplierInvoiceStsPopUpWinDueDtId';
Modules.CompIds.supplierInvoiceStsPopUpWinLstPmtAmtId		    	= 'supplierInvoiceStsPopUpWinLstPmtAmtId';
Modules.CompIds.supplierInvoiceStsPopUpWinInvcStsId		        	= 'supplierInvoiceStsPopUpWinInvcStsId';
Modules.CompIds.supplierInvoiceStsPopUpWinObjId				    	= 'supplierInvoiceStsPopUpWinObjId';
/*** Supplier Invoice Status Screen ***/

/*** OCEAN - Customer Invoice Setup Screen ***/
Modules.CompIds.oceanCustInvcSetupFormId					   		= 'oceanCustInvcSetupFormId';
Modules.CompIds.oceanCustInvcSetupPrtyComboId 		   		    	= 'oceanCustInvcSetupPrtyComboId';
Modules.CompIds.oceanCustInvcSetupPrtyNmId 		   		        	= 'oceanCustInvcSetupPrtyNmId';
Modules.CompIds.oceanCustInvcSetupPopComboId 		   		    	= 'oceanCustInvcSetupPopComboId';
Modules.CompIds.oceanCustInvcSetupPopNmId 		   		        	= 'oceanCustInvcSetupPopNmId';
Modules.CompIds.oceanCustInvcSetupSrvcTypeId 		   		    	= 'oceanCustInvcSetupSrvcTypeId';
Modules.CompIds.oceanCustInvcSetupActualTriggerPointId 		   		= 'oceanCustInvcSetupActualTriggerPointId';
Modules.CompIds.oceanCustInvcSetupTriggerPointId 		   	    	= 'oceanCustInvcSetupTriggerPointId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentificationGridId 		= 'oceanCustInvcSetupTrggerIdentificationGridId';
Modules.CompIds.oceanCustInvcSetupSrvcCdComboId 	            	= 'oceanCustInvcSetupSrvcCdComboId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridAddId 	    	= 'oceanCustInvcSetupTrggerIdentfGridAddId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridDelId 	    	= 'oceanCustInvcSetupTrggerIdentfGridDelId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridId 	        	= 'oceanCustInvcSetupActInvcGrpngGridId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridAddId 	    	= 'oceanCustInvcSetupActInvcGrpngGridAddId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridDelId 	    	= 'oceanCustInvcSetupActInvcGrpngGridDelId';
Modules.CompIds.oceanCustInvcSetupTabPanelId             	    	= 'oceanCustInvcSetupTabPanelId';

Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridPopUpId 	    	= 'oceanCustInvcSetupTrggerIdentfGridPopUpId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridservcTypeId 		= 'oceanCustInvcSetupTrggerIdentfGridservcTypeId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridservcCdId 		= 'oceanCustInvcSetupTrggerIdentfGridservcCdId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridactTrgPntId 		= 'oceanCustInvcSetupTrggerIdentfGridactTrgPntId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridtrgPntId 	    	= 'oceanCustInvcSetupTrggerIdentfGridtrgPntId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridcrdTrmId 	    	= 'oceanCustInvcSetupTrggerIdentfGridcrdTrmId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridcrdTrmApprId 		= 'oceanCustInvcSetupTrggerIdentfGridcrdTrmApprId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridfrghtTrmApprId	= 'oceanCustInvcSetupTrggerIdentfGridfrghtTrmApprId';
Modules.CompIds.oceanCustInvcSetupTrggerIdentfGridPopUpFormId 		= 'oceanCustInvcSetupTrggerIdentfGridPopUpFormId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpWinId 		= 'oceanCustInvcSetupActInvcGrpngGridPopUpWinId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpWinFormId	= 'oceanCustInvcSetupActInvcGrpngGridPopUpWinFormId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpsrvGrpCdId	= 'oceanCustInvcSetupActInvcGrpngGridPopUpsrvGrpCdId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpsrvTypeId 	= 'oceanCustInvcSetupActInvcGrpngGridPopUpsrvTypeId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpBlId     	= 'oceanCustInvcSetupActInvcGrpngGridPopUpBlId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpVygId    	= 'oceanCustInvcSetupActInvcGrpngGridPopUpVygId'; 
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpFrtTmsId 	= 'oceanCustInvcSetupActInvcGrpngGridPopUpFrtTmsId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpChrgCdId 	= 'oceanCustInvcSetupActInvcGrpngGridPopUpChrgCdId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpItmNoId  	= 'oceanCustInvcSetupActInvcGrpngGridPopUpItmNoId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpInvcCurId	= 'oceanCustInvcSetupActInvcGrpngGridPopUpInvcCurId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpPayerId  	= 'oceanCustInvcSetupActInvcGrpngGridPopUpPayerId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpMaxLinesInInvcId = 'oceanCustInvcSetupActInvcGrpngGridPopUpMaxLinesInInvcId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpPrntTempId   = 'oceanCustInvcSetupActInvcGrpngGridPopUpPrntTempId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpFreqSrvGrpCdId = 'oceanCustInvcSetupActInvcGrpngGridPopUpFreqSrvGrpCdId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpCstId    	= 'oceanCustInvcSetupActInvcGrpngGridPopUpCstId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpCompId   	= 'oceanCustInvcSetupActInvcGrpngGridPopUpCompId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpPopId    	= 'oceanCustInvcSetupActInvcGrpngGridPopUpPopId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpGnrtnFreqId  = 'oceanCustInvcSetupActInvcGrpngGridPopUpGnrtnFreqId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpTimeId       = 'oceanCustInvcSetupActInvcGrpngGridPopUpTimeId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpIntrvlId     = 'oceanCustInvcSetupActInvcGrpngGridPopUpIntrvlId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpLstExcuTimeId= 'oceanCustInvcSetupActInvcGrpngGridPopUpLstExcuTimeId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpAutoApprvId  = 'oceanCustInvcSetupActInvcGrpngGridPopUpAutoApprvId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopUpExCstListId  = 'oceanCustInvcSetupActInvcGrpngGridPopUpExCstListId';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopCarrierCodegroup='oceanCustInvcSetupActInvcGrpngGridPopCarrierCodegroup';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopinvoiceLineItems='oceanCustInvcSetupActInvcGrpngGridPopinvoiceLineItems';
Modules.CompIds.oceanCustInvcSetupActInvcGrpngGridPopConsolCarrierCodegroup='oceanCustInvcSetupActInvcGrpngGridPopConsolCarrierCodegroup';
/*** OCEAN - Customer Invoice Setup Screen ***/



/*** OCEAN - Customer Service Group Setup Screen ***/

Modules.CompIds.oceanCstmrSrvGrpSetupFormId='oceanCstmrSrvGrpSetupFormId';
Modules.CompIds.oceanCstmrSrvGrpSetupPopId='oceanCstmrSrvGrpSetupPopId';
Modules.CompIds.oceanCstmrSrvGrpPopName='oceanCstmrSrvGrpPopName';
Modules.CompIds.oceanCstmrSrvGrpSetupPartyId='oceanCstmrSrvGrpSetupPartyId';
Modules.CompIds.oceanCstmrSrvGrpPartyName='oceanCstmrSrvGrpPartyName';
Modules.CompIds.oceanCstmrSrvGrpSetupSrvGrpCode='oceanCstmrSrvGrpSetupSrvGrpCode';
Modules.CompIds.oceanCstmrSrvGrpServiceGrpDesc='oceanCstmrSrvGrpServiceGrpDesc';
Modules.CompIds.oceanCstmrSrvGrpSetupServTypeId='oceanCstmrSrvGrpSetupServTypeId';
Modules.CompIds.oceanCstmrSrvGrpSetupChargCodeId='oceanCstmrSrvGrpSetupChargCodeId';

Modules.CompIds.oceanCstmrSrvGrpSetupGridId='oceanCstmrSrvGrpSetupGridId';
Modules.CompIds.oceanCstmrSrvGrpSetupAddRecordId='oceanCstmrSrvGrpSetupAddRecordId';
Modules.CompIds.oceanCstmrSrvGrpSetupDeleteRecordId='oceanCstmrSrvGrpSetupDeleteRecordId';
Modules.CompIds.oceanCstmrSrvGrpSetupGridCopyId='oceanCstmrSrvGrpSetupGridCopyId';
Modules.CompIds.oceanCstmrSetupGridpartyId='oceanCstmrSetupGridpartyId';
Modules.CompIds.oceanCstmrSetupGridpartyNameId='oceanCstmrSetupGridpartyNameId';
Modules.CompIds.oceanCstmrSetupGridPopId='oceanCstmrSetupGridPopId';
Modules.CompIds.oceanCstmrSetupGridPopNameId='oceanCstmrSetupGridPopNameId';
Modules.CompIds.oceanCstmrSetupGridSrvGrpCd='oceanCstmrSetupGridSrvGrpCd';
Modules.CompIds.oceanCstmrSetupGridSrvGrpCdDesc='oceanCstmrSetupGridSrvGrpCdDesc';
Modules.CompIds.editOceanCstmrSrvGrpGridFormId='editOceanCstmrSrvGrpGridFormId';
Modules.CompIds.editOceanCstmrSrvGrpGridWinId='editOceanCstmrSrvGrpGridWinId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinPartyCdId='oceanediWinpartyCdId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinPartyNameId='oceanCstmrSrvGrpEdiWinPartyNameId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinPopCdId='oceanediWinPopCdId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinPopNameId='oceanCstmrSrvGrpEdiWinPopNameId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinSrvGrpCdId='oceanCstmrSrvGrpEdiWinSrvGrpCdId';
Modules.CompIds.oceanCstmrSrvGrpEdiWinSrvGrpDescId='oceanCstmrSrvGrpEdiWinSrvGrpDescId';
Modules.CompIds.editOceanCstmrSrvGrpWinStatusId='editOceanCstmrSrvGrpWinStatusId';
Modules.CompIds.editOceanCstmrSrvGrpGridWinSaveBtnId='editCstmrSrvGrpGridWinSaveBtnId';
Modules.CompIds.oceanCstmrSrvGrpSetupWinDoneId='oceanCstmrSrvGrpSetupWinDoneId';

Modules.CompIds.oceanCstmrSrvGrpSetupSrvTypeGridId='oceanCstmrSrvGrpSetupSrvTypeGridId';
Modules.CompIds.oceanCstmrSrvTypeGridAddRecordId='cstmrSrvTypeGridAddRecordId';
Modules.CompIds.oceanCstmrSrvTypeDeleteRecordId='oceanCstmrSrvTypeDeleteRecordId';
Modules.CompIds.oceanGrpSetupSrvTypeGridServiceTypeId='oceanGrpSetupSrvTypeGridServiceTypeId';
Modules.CompIds.oceanGrpSetupSrvTypeGridchargCodeId='oceanGrpSetupSrvTypeGridchargCodeId';
Modules.CompIds.oceanGrpSetupSrvTypeGridchargCodeDesc='oceanGrpSetupSrvTypeGridchargCodeDesc';
Modules.CompIds.editOceanCstmrSrvTypeGridWinId='editOceanCstmrSrvTypeGridWinId';
Modules.CompIds.editOceanCstmrSrvTypeCodeFormId='editOceanCstmrSrvTypeCodeFormId';
Modules.CompIds.editOceanCstmrSrvTypeWinPopId='editOceanCstmrSrvTypeWinPopId';
Modules.CompIds.editOceanCstmrSrvTypeWinSrvTypeId='editOceanCstmrSrvTypeWinSrvTypeId';
Modules.CompIds.editOceanCstmrSrvTypeWinPartyId='editOceanCstmrSrvTypeWinPartyId';
Modules.CompIds.editOceanCstmrSrvTypeWinSrvGrpCd='editOceanCstmrSrvTypeWinSrvGrpCd';
Modules.CompIds.editOceanCstmrSrvTypeWinChargCodeId='editOceanCstmrSrvTypeWinChargCodeId';
Modules.CompIds.editOceanCstmrSrvTypeWinChargCdDescId='editOceanCstmrSrvTypeWinChargCdDescId';
Modules.CompIds.editOceanCstmrSrvTypeWinStatusId='editOceanCstmrSrvTypeWinStatusId';
Modules.CompIds.editOceanCstmrSrvTypeWinSaveBtnId='editOceanCstmrSrvTypeWinSaveBtnId';
Modules.CompIds.oceanCstmrSrvTypewinDoneId='oceanCstmrSrvTypewinDoneId';


/*** NON-OCEAN - Supplier Remittance Details Screen ***/


Modules.CompIds.supplierRemittanceDetailsFormId='supplierRemittanceDetailsFormId';
Modules.CompIds.supplierRemittanceDetailsSupplierId='supplierRemittanceDetailsSupplierId';
Modules.CompIds.supplierRemittanceDetailsPaymentFromDtId='supplierRemittanceDetailsPaymentFromDtId';
Modules.CompIds.supplierRemittanceDetailsPaymentToDateId='supplierRemittanceDetailsPaymentToDateId';
Modules.CompIds.supplierRemittanceDetailsInvcNumberId='supplierRemittanceDetailsInvcNumberId';
Modules.CompIds.supplierRemittanceDetailsInvcFromDtId='supplierRemittanceDetailsInvcFromDtId';
Modules.CompIds.supplierRemittanceDetailsInvcToDateId='supplierRemittanceDetailsInvcToDateId';
Modules.CompIds.supplierRemittanceDetailsServiceTypeId='supplierRemittanceDetailsServiceTypeId';
Modules.CompIds.supplierRemittanceDetailsEvntLoadRefId='supplierRemittanceDetailsEvntLoadRefId';
Modules.CompIds.supplierRemittanceDetailsModeOfPaymntId='supplierRemittanceDetailsModeOfPaymntId';

Modules.CompIds.supplierRemittanceDetailsPaymntDocId='supplierRemittanceDetailsPaymntDocId';
Modules.CompIds.supplierRemittanceDetailsUnitId='supplierRemittanceDetailsUnitId';
Modules.CompIds.supplierRemittanceDetailsServCodeId='supplierRemittanceDetailsServCodeId';
Modules.CompIds.supplierRemittanceDetailsConveyanceId='supplierRemittanceDetailsConveyanceId';
Modules.CompIds.supplierRemittanceDetailsShipRefId='supplierRemittanceDetailsShipRefId';
Modules.CompIds.supplierRemittanceDetailsAdvContnerId='supplierRemittanceDetailsAdvContnerId';
Modules.CompIds.supplierRemittanceDetailsPdfRadioId='supplierRemittanceDetailsPdfRadioId';
Modules.CompIds.supplierRemittanceDetailsExlRadioId='supplierRemittanceDetailsExlRadioId';
Modules.CompIds.supplierRemittanceDetailsSummaryRadioId='supplierRemittanceDetailsSummaryRadioId';
Modules.CompIds.supplierRemittanceDetailsDetailRadioId='supplierRemittanceDetailsDetailRadioId';
Modules.CompIds.supplierRemittanceDetailsAscRadioId='supplierRemittanceDetailsAscRadioId';
Modules.CompIds.supplierRemittanceDetailsDescRadioId='supplierRemittanceDetailsDescRadioId';
Modules.CompIds.supplierRemittanceDetailsParGridId='supplierRemittanceDetailsParGridId';
Modules.CompIds.supplierRemittanceDetailsParGridsupplierId='supplierRemittanceDetailsParGridsupplierId';
Modules.CompIds.supplierRemittanceDetailsParGridInvcNbrId='supplierRemittanceDetailsParGridInvcNbrId';
Modules.CompIds.supplierRemittanceDetailsParGridInvcDtId='supplierRemittanceDetailsParGridInvcDtId';
Modules.CompIds.supplierRemittanceDetailsParGridModOfPaymntId='supplierRemittanceDetailsParGridModOfPaymntId';
Modules.CompIds.supplierRemittanceDetailsParGridPaymntDocId='supplierRemittanceDetailsParGridPaymntDocId';
Modules.CompIds.supplierRemittanceDetailsParGridPaymntDtId='supplierRemittanceDetailsParGridPaymntDtId';
Modules.CompIds.supplierRemittanceDetailsParGridInvcAmntId='supplierRemittanceDetailsParGridInvcAmntId';
Modules.CompIds.supplierRemittanceDetailsParGridPaidAmntId='supplierRemittanceDetailsParGridPaidAmntId';
Modules.CompIds.supplierRemittanceDetailsParGridCurencyId='supplierRemittanceDetailsParGridCurencyId';
Modules.CompIds.supplierRemittanceDetailsParGridEditWinFormId='supplierRemittanceDetailsParGridEditWinFormId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinSuplerId='supplrRemmtnceDtlsParntGrdEditWinSuplerId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinInvcNbrId='supplrRemmtnceDtlsParntGrdEditWinInvcNbrId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinInvcDateId='supplrRemmtnceDtlsParntGrdEditWinInvcDateId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinModOfPaymntId='supplrRemmtnceDtlsParntGrdEditWinModOfPaymntId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinPaymntDocId='supplrRemmtnceDtlsParntGrdEditWinPaymntDocId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinPaymntDtId='supplrRemmtnceDtlsParntGrdEditWinPaymntDtId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinInvcAmntId='supplrRemmtnceDtlsParntGrdEditWinInvcAmntId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinPaidAmntId='supplrRemmtnceDtlsParntGrdEditWinPaidAmntId';
Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinCurrncyId='supplrRemmtnceDtlsParntGrdEditWinCurrncyId';

Modules.CompIds.supplrRemmtnceDtlsParntGrdEditWinObjId='supplrRemmtnceDtlsParntGrdEditWinObjId';
Modules.CompIds.supplrRemmtnceDtlsChildGridId='supplrRemmtnceDtlsChildGridId';
Modules.CompIds.supplrRemmtnceDtlsChildGridOverdRejectId='supplrRemmtnceDtlsChildGridOverdRejectId';
Modules.CompIds.supplrRemmtnceDtlsChildGridServCodeId='supplrRemmtnceDtlsChildGridServCodeId';
Modules.CompIds.supplrRemmtnceDtlsChildGridUnitId='supplrRemmtnceDtlsChildGridUnitId';
Modules.CompIds.supplrRemmtnceDtlsChildGridShipRefId='supplrRemmtnceDtlsChildGridShipRefId';
Modules.CompIds.supplrRemmtnceDtlsChildGridEventLoadRefId='supplrRemmtnceDtlsChildGridEventLoadRefId';
Modules.CompIds.supplrRemmtnceDtlsChildGridConvynceId='supplrRemmtnceDtlsChildGridConvynceId';
Modules.CompIds.supplrRemmtnceDtlsChildGridPartId='supplrRemmtnceDtlsChildGridPartId';
Modules.CompIds.supplrRemmtnceDtlsChildGridDeliveryDateId='supplrRemmtnceDtlsChildGridDeliveryDateId';
Modules.CompIds.supplrRemmtnceDtlsChildGridInvcAmntId='supplrRemmtnceDtlsChildGridInvcAmntId';
Modules.CompIds.supplrRemmtnceDtlsChildGridApprvdAmntId='supplrRemmtnceDtlsChildGridApprvdAmntId';
Modules.CompIds.supplrRemmtnceDtlsChildGridPaidAmntId='supplrRemmtnceDtlsChildGridPaidAmntId';
Modules.CompIds.supplierRemittanceDetailsChildGridEditWinFormId='supplierRemittanceDetailsChildGridEditWinFormId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinServCodeId='supplrRemmtnceDtlsChildGrdEditWinServCodeId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinUnitId='supplrRemmtnceDtlsChildGrdEditWinUnitId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinShipRefId='supplrRemmtnceDtlsChildGrdEditWinShipRefId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinEventloadRefId='supplrRemmtnceDtlsChildGrdEditWinEventloadRefId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinConveyanceId='supplrRemmtnceDtlsChildGrdEditWinConveyanceId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinPartId='supplrRemmtnceDtlsChildGrdEditWinPartId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinDeliveryDateId='supplrRemmtnceDtlsChildGrdEditWinDeliveryDateId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinInvcAmntId='supplrRemmtnceDtlsChildGrdEditWinInvcAmntId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinApprvedAmntId='supplrRemmtnceDtlsChildGrdEditWinApprvedAmntId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinPaidAmntId='supplrRemmtnceDtlsChildGrdEditWinPaidAmntId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinCurencyId='supplrRemmtnceDtlsChildGrdEditWinCurencyId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinOvrdRejectId='supplrRemmtnceDtlsChildGrdEditWinOvrdRejectId';
Modules.CompIds.supplrRemmtnceDtlsChildGrdEditWinObjId='supplrRemmtnceDtlsChildGrdEditWinObjId';



/****************************************************************
*
*		OCean Customer Master
******************************************************************************************/
Modules.CompIds.oceanCustomerMasterPanelIdParentId	=	'oceanCustomerMasterPanelIdParentId';
Modules.CompIds.oceanCustomerMasterSearchFormId	=	'oceanCustomerMasterSearchFormId';
Modules.CompIds.ocaenCustomerCdId	=	'ocaenCustomerCdId';
Modules.CompIds.oceanCustomerMasterGridId	=	'oceanCustomerMasterGridId';
Modules.CompIds.saveOceanCustomerMasterDerailsGridId	=	'saveOceanCustomerMasterDerailsGridId';
Modules.CompIds.addOceanCustomerMasterDerailsGridId	=	'addOceanCustomerMasterDerailsGridId';
Modules.CompIds.deleteOceanCustomerMasterGridId	=	'deleteOceanCustomerMasterGridId';
Modules.CompIds.vatNoOceanCustomerMasterGridId	=	'vatNoOceanCustomerMasterGridId';
Modules.CompIds.ediPrtnrCdOceanCustomerMasterGridId	=	'ediPrtnrCdOceanCustomerMasterGridId';
Modules.CompIds.ptyNmOceanCustomerFromGridPopupWinId	=	'ptyNmOceanCustomerFromGridPopupWinId';
Modules.CompIds.ptyNm2OceanCustomerFromGridPopupWinId	=	'ptyNm2OceanCustomerFromGridPopupWinId';
Modules.CompIds.addr1OceanCustomerFromGridPopupWinId	=	'addr1OceanCustomerFromGridPopupWinId';
Modules.CompIds.addr2OceanCustomerFromGridPopupWinId	=	'addr2OceanCustomerFromGridPopupWinId';
Modules.CompIds.addr3OceanCustomerFromGridPopupWinId	=	'addr3OceanCustomerFromGridPopupWinId';
Modules.CompIds.oceanCustomerMasterPopUpFormId	=	'oceanCustomerMasterPopUpFormId';
Modules.CompIds.popupOceanCustomerMasterWindowId	=	'popupOceanCustomerMasterWindowId';
Modules.CompIds.oceanCustomerMasterWinDoneId	=	'oceanCustomerMasterWinDoneId';
Modules.CompIds.cityOceanCustomerFromGridPopupWinId	=	'cityOceanCustomerFromGridPopupWinId';
Modules.CompIds.stateProvinceOceanCustomerFromGridPopupWinId	=	'stateProvinceOceanCustomerFromGridPopupWinId';
Modules.CompIds.postalCdOceanCustomerFromGridPopupWinId	=	'postalCdOceanCustomerFromGridPopupWinId';
Modules.CompIds.countryCdOceanCustomerFromGridPopupWinId	=	'countryCdOceanCustomerFromGridPopupWinId';
Modules.CompIds.ptyNoOceanCustomerFromGridPopupWinId	=	'ptyNoOceanCustomerFromGridPopupWinId';
Modules.CompIds.salesRegCdOceanCustomerFromGridPopupWinId	=	'salesRegCdOceanCustomerMstrGridPopupWinId';
Modules.CompIds.salesOfficeOceanCustomerFromGridPopupWinId	=	'salesOfficeOceanCustomerFromGridPopupWinId';
Modules.CompIds.crncyCdOceanCustomerFromGridPopupWinId	=	'crncyCdOceanCustomerFromGridPopupWinId';
Modules.CompIds.vatNoOceanCustomerFromGridPopupWinId	=	'vatNoOceanCustomerFromGridPopupWinId';
Modules.CompIds.vatPrcntOceanCustomerFromGridPopupWinId	=	'vatPrcntOceanCustomerFromGridPopupWinId';
Modules.CompIds.ediPartnerCdOceanCustomerFromGridPopupWinId	=	'ediPartnerCdOceanCustomerFromGridPopupWinId';
Modules.CompIds.oceanCustomerMasterGridParentTabPanel	=	'oceanCustomerMasterGridParentTabPanel';
Modules.CompIds.oceanCustomerContractIdentificationGridId	=	'oceanCustomerContractIdentificationGridId';
Modules.CompIds.creditTermsLimitGridId	=	'oceanCustomerMasterCreditTermsLimitGridId';
Modules.CompIds.blCompletionOceanCustomerContractIdentificationGridId	=	'blCompletionOceanCustomerContractIdentificationGridId';
Modules.CompIds.serviceTypeOceanCustomerContractIdentificationGridId	=	'serviceTypeOceanCustomerContractIdentificationGridId';
Modules.CompIds.oceanContractIdentificationPopUpFormId	=	'oceanContractIdentificationPopUpFormId';
Modules.CompIds.serviceTypeoceanContractIdentificationPopUpFormId	=	'serviceTypeoceanContractIdentificationPopUpFormId';
Modules.CompIds.chargeCdOceanContractIdentificationPopUpFormId	=	'chargeCdOceanContractIdentificationPopUpFormId';
Modules.CompIds.blCompletionDateOceanContractIdentificationPopUpFormId	=	'blCompletionDateOceanContractIdentificationPopUpFormId';
Modules.CompIds.polOceanContractIdentificationPopUpFormId	=	'polOceanContractIdentificationPopUpFormId';
Modules.CompIds.podOceanContractIdentificationPopUpFormId	=	'podOceanContractIdentificationPopUpFormId';
Modules.CompIds.oceanEditContractIdentificationWinId	=	'oceanEditContractIdentificationWinId';
Modules.CompIds.oceanCstmrMstrEditPrintTemplateWinId	=	'oceanCstmrMstrEditPrintTemplateWinId';
Modules.CompIds.addOceanContractIdentificationRecordId	=	'addOceanContractIdentificationRecordId';
Modules.CompIds.deleteOceanContractIdentificationRecordId	=	'deleteOceanContractIdentificationRecordId';
Modules.CompIds.serviceTypeOceanValuesRoundingCriteriaGridId	=	'serviceTypeOceanValuesRoundingCriteriaGridId';
Modules.CompIds.summaryValueOceanValuesRoundingCriteriaGridId	=	'summaryValueOceanValuesRoundingCriteriaGridId';
Modules.CompIds.oceanValuesRoundingCriteriaGridId	=	'oceanValuesRoundingCriteriaGridId';
Modules.CompIds.addOceanValuesRoundingCriteriaGridId	=	'addOceanValuesRoundingCriteriaGridId';
Modules.CompIds.deleteOceanValuesRoundingCriteriaGridId	=	'deleteOceanValuesRoundingCriteriaGridId';
Modules.CompIds.roundingCriteriaForGridPopUpFormId	=	'roundingCriteriaForGridPopUpFormId';
Modules.CompIds.roundingCriteriaOceanValuesRoundingCriteriaGridId	=	'roundingCriteriaOceanValuesRoundingCriteriaGridId';
Modules.CompIds.serviceTypeRoundingCriteriaForGridPopUpFormId	=	'serviceTypeRoundingCriteriaForGridPopUpFormId';
Modules.CompIds.summaryValueRoundingCriteriaForGridPopUpFormId	=	'summaryValueRoundingCriteriaForGridPopUpFormId';
Modules.CompIds.roundingCriteriaRoundingCriteriaForGridPopUpFormId	=	'roundingCriteriaRoundingCriteriaForGridPopUpFormId';
Modules.CompIds.valueRoundingCriteriaForGridPopUpForm	=	'valueRoundingCriteriaForGridPopUpForm';
Modules.CompIds.editOceanValuesForRoundingCriteriaWinId	=	'editOceanValuesForRoundingCriteriaWinId';
Modules.CompIds.oceanValuesForRoundingCriteriaWinDoneId	=	'oceanValuesForRoundingCriteriaWinDoneId';
Modules.CompIds.partyTypeOceanCustomerMasterPartyGridId	=	'partyTypeOceanCustomerMasterPartyGridId';
Modules.CompIds.addOceanCustomerMasterPartyGridId	=	'addOceanCustomerMasterPartyGridId';
Modules.CompIds.deleteOceanCustomerMasterPartyGridId	=	'deleteOceanCustomerMasterPartyGridId';
Modules.CompIds.oceanCustomerMasterPartyGridId	=	'oceanCustomerMasterPartyGridId';
Modules.CompIds.partyTypePopUpFormId	=	'partyTypePopUpFormId';
Modules.CompIds.editWinPartyTypeId	=	'editWinPartyTypeId';
Modules.CompIds.editPartyTypeGridWin	=	'editPartyTypeGridWin';
Modules.CompIds.partyTyperWinDoneId	=	'partyTyperWinDoneId';
Modules.CompIds.typCreditTermGridId	=	'typCreditTermGridId';
Modules.CompIds.creditTermTypCreditTermGridId	=	'creditTermTypCreditTermGridId';
Modules.CompIds.creditLimitGridPopUpFormId	=	'creditLimitGridPopUpFormId';
Modules.CompIds.typeCreditTermLimitGridPopupWinId	=	'typeCreditTermLimitGridPopupWinId';
Modules.CompIds.creditTermCreditTermLimitPopupWinId	=	'creditTermCreditTermLimitPopupWinId';
Modules.CompIds.creditTermLtCreditTermLimitPopupWinId	=	'creditTermLtCreditTermLimitPopupWinId';
Modules.CompIds.creditTermLtUsdCreditTermLimitPopupWinId	=	'creditTermLtUsdCreditTermLimitPopupWinId';
Modules.CompIds.addCreditTermLimitPopupWinRecordId	=	'addCreditTermLimitPopupWinRecordId';
Modules.CompIds.deleteCreditTermLimitPopupWinId	=	'deleteCreditTermLimitPopupWinId';
Modules.CompIds.editpopupCreditTermLimitWinId	=	'editpopupCreditTermLimitWinId';
Modules.CompIds.oceanCustomerContactDetailsGridId = 'oceanCustomerContactDetailsGridId';
Modules.CompIds.addOceanContactDetailsRecordId = 'addOceanContactDetailsRecordId';
Modules.CompIds.ocnCstmrMstrContactDtlsPopUpWinId = 'ocnCstmrMstrContactDtlsPopUpWinId';
Modules.CompIds.ocnCstmrMstrVolvoMsgDtlsPopUpWinId = 'ocnCstmrMstrVolvoMsgDtlsPopUpWinId';
Modules.CompIds.oceanCustomerVolvoMsgDetailsGridId = 'oceanCustomerVolvoMsgDetailsGridId';
/****************************************************************************************************************************/

/****************************************************************
*
*		Supplier Rate Verification
******************************************************************************************/

Modules.CompIds.supplierRateVerificationPanelId	=	'supplierRateVerificationPanelId';
Modules.CompIds.supplierRateVerificationFormId	=	'supplierRateVerificationFormId';
Modules.CompIds.carrierSupplierRateVerificationFormId	=	'carrierSupplierRateVerificationFormId';
Modules.CompIds.carrierNmSupplierRateVerificationFormId	=	'carrierNmSupplierRateVerificationFormId';
Modules.CompIds.effectiveDateSupplierRateVerificationFormId	=	'effectiveDateSupplierRateVerificationFormId';
Modules.CompIds.chargeCodeSupplierRateVerificationFormId	=	'chargeCodeSupplierRateVerificationFormId';
Modules.CompIds.podSupplierRateVerificationFormId	=	'podSupplierRateVerificationFormId';
Modules.CompIds.polSupplierRateVerificationFormId	=	'polSupplierRateVerificationFormId';
Modules.CompIds.polCitySupplierRateVerificationFormId	=	'polCitySupplierRateVerificationFormId';
Modules.CompIds.polStateSupplierRateVerificationFormId	=	'polStateSupplierRateVerificationFormId';
Modules.CompIds.podCitySupplierRateVerificationFormId	=	'podCitySupplierRateVerificationFormId';
Modules.CompIds.podStateSupplierRateVerificationFormId	=	'podStateSupplierRateVerificationFormId';
Modules.CompIds.porSupplierRateVerificationFormId	=	'porSupplierRateVerificationFormId';
Modules.CompIds.pfdSupplierRateVerificationFormId	=	'pfdSupplierRateVerificationFormId';
Modules.CompIds.makeCodeSupplierRateVerificationFormId	=	'makeCodeSupplierRateVerificationFormId';
Modules.CompIds.cargoClassSupplierRateVerificationFormId	=	'cargoClassSupplierRateVerificationFormId';
Modules.CompIds.modelSupplierRateVerificationFormId	=	'modelSupplierRateVerificationFormId';
Modules.CompIds.steeringSupplierRateVerificationFormId	=	'steeringSupplierRateVerificationFormId';
Modules.CompIds.hazardusSupplierRateVerificationFormId	=	'hazardusSupplierRateVerificationFormId';
Modules.CompIds.hndlingIndicatorSupplierRateVerificationFormId	=	'hndlingIndicatorSupplierRateVerificationFormId';
Modules.CompIds.transferGearSupplierRateVerificationFormId	=	'transferGearSupplierRateVerificationFormId';
Modules.CompIds.partySupplierRateVerificationFormId	=	'partySupplierRateVerificationFormId';
Modules.CompIds.oceanSupplierRateVerificationGridId	=	'oceanSupplierRateVerificationGridId';
Modules.CompIds.addSupplierVerificationGridId	=	'addSupplierVerificationGridId';
Modules.CompIds.supplierRateverificationQueryPopupWinId	=	'supplierRateverificationQueryPopupWinId';
Modules.CompIds.oceanSupplierRateVerificationQueryPopupWinId	=	'oceanSupplierRateVerificationQueryPopupWinId';


/**********************Starting Id's For Customer Invoice Status  FOr Ocean**************/
Modules.CompIds.customerInvcStsOceanTabParentPanelId			=		'customerInvcStsOceanTabParentPanelId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormId		=		'customerInvcStsOceanTabParentPanelFormId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormClearId	=		'customerInvcStsOceanTabParentPanelFormClearId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormRtrveId	=		'customerInvcStsOceanTabParentPanelFormRtrveId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPrintId	=		'customerInvcStsOceanTabParentPanelFormPrintId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormCmpnyId	=		'customerInvcStsOceanTabParentPanelFormCmpnyId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormCstmrId	=		'customerInvcStsOceanTabParentPanelFormCstmrId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormDbtrPtyId	=		'customerInvcStsOceanTabParentPanelFormDbtrPtyId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormInvcNoId	=		'customerInvcStsOceanTabParentPanelFormInvcNoId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPrfTLosId	=		'customerInvcStsOceanTabParentPanelFormPrfTLosId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormFromDtId	=		'customerInvcStsOceanTabParentPanelFormFromDtId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormToDtId	=		'customerInvcStsOceanTabParentPanelFormToDtId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPrfrmaId	=		'customerInvcStsOceanTabParentPanelFormPrfrmaId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormRjctedId	=		'customerInvcStsOceanTabParentPanelFormRjctedId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormFinalId	=		'customerInvcStsOceanTabParentPanelFormFinalId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPaidId	=		'customerInvcStsOceanTabParentPanelFormPaidId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormViewId	=		'customerInvcStsOceanTabParentPanelFormViewId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormInvcId	=		'customerInvcStsOceanTabParentPanelFormInvcId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormInvcPrntId	=	'customerInvcStsOceanTabParentPanelFormInvcPrntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormBckUpPrntId	=	'customerInvcStsOceanTabParentPanelFormBckUpPrntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormInvcCpiesId	=	'customerInvcStsOceanTabParentPanelFormInvcCpiesId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormEmailId		=	'customerInvcStsOceanTabParentPanelFormEmailId';	
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPrintRadioId	=	'customerInvcStsOceanTabParentPanelFormPrintRadioId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormBackUpId		=	'customerInvcStsOceanTabParentPanelFormBackUpId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormBackUpCpsId	=	'customerInvcStsOceanTabParentPanelFormBackUpCpsId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormCcMailIdId	=	'customerInvcStsOceanTabParentPanelFormCcMailIdId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormActualId		=	'customerInvcStsOceanTabParentPanelFormActualId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormAccuralId		=	'customerInvcStsOceanTabParentPanelFormAccuralId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormInvcChkId		=	'customerInvcStsOceanTabParentPanelFormInvcChkId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormCreditId		=	'customerInvcStsOceanTabParentPanelFormCreditId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormDebitId		=	'customerInvcStsOceanTabParentPanelFormDebitId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormPdfId			=	'customerInvcStsOceanTabParentPanelFormPdfId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormExcelId		=	'customerInvcStsOceanTabParentPanelFormExcelId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormAscndingId	=	'customerInvcStsOceanTabParentPanelFormAscndingId';
Modules.CompIds.customerInvcStsOceanTabParentPanelFormDscndingId	=	'customerInvcStsOceanTabParentPanelFormDscndingId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridId			=	'customerInvcStsOceanTabParentPanelGridId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinPtyId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinPtyId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcNoId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcNoId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinDcTpeId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinDcTpeId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcTpeId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcTpeId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinMnfstCrncyId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinMnfstCrncyId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinMnfstAmntId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinMnfstAmntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcCrncyId	=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcCrncyId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcAmntId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcAmntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinUsdAmntId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinUsdAmntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinPaidAmntId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinPaidAmntId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcDtId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcDtId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinDueDtId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinDueDtId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinLstPayDtId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinLstPayDtId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrWinInvcStsId		=	'customerInvcStsOceanTabParentPanelGridEdtrWinInvcStsId';
Modules.CompIds.customerInvcStsOceanTabParentPanelGridEdtrFormId			=	'customerInvcStsOceanTabParentPanelGridEdtrFormId'; 


/**********************Starting Id's For Supplier Invoice Status  FOr Ocean**************/
Modules.CompIds.supplierInvcStsOceanTabParentPanelId			=		'supplierInvcStsOceanTabParentPanelId';


/***************************************/

Modules.CompIds.EventMsgType = 'EventMsgType';
Modules.CompIds.evntMsgPartnerCd = 'evntMsgPartnerCd';
Modules.CompIds.viewBillOfLaderId = 'viewBillOfLadingId';


/**********************Starting Id's For Customer Invoice Status  FOr Ocean**************/

//******supplier master ocean+ customer contract query ocean ***************************************************************************************************************************************
Modules.CompIds.supplierMasterPanelIdParentId='supplierMasterPanelIdParentId';
Modules.CompIds.supplierCdComboId='supplierCdComboId';
Modules.CompIds.supplierMasterGridId='supplierMasterGridId';
Modules.CompIds.paymentDetailsSupplierMasterGridId='paymentDetailsSupplierMasterGridId';
Modules.CompIds.statusDateSupplierMasterGridId='statusDateSupplierMasterGridId';
Modules.CompIds.automaticInvoiceSupplierMasterGridId='automaticInvoiceSupplierMasterGridId';
Modules.CompIds.rateRoundingCriteriaSupplierMasterGridId='rateRoundingCriteriaSupplierMasterGridId';
Modules.CompIds.oceanPaymntDtlsGridPopupId = 'oceanPaymntDtlsGridPopupId';
Modules.CompIds.ocnSupplrStsDtForContractIdPopupPolLovId = 'ocnSupplrStsDtForContractIdPopupPolLovId';
Modules.CompIds.ocnSupplrStsDtForContractIdPopupPodLovId = 'ocnSupplrStsDtForContractIdPopupPodLovId';
Modules.CompIds.ocnSupplrStsDtForContractIdGridPopupPolLovId = 'ocnSupplrStsDtForContractIdGridPopupPolLovId';
Modules.CompIds.ocnSupplrStsDtForContractIdGridPopupPodLovId = 'ocnSupplrStsDtForContractIdGridPopupPodLovId';
Modules.CompIds.oceanAutomaticInvcSetupGridPopupId = 'oceanAutomaticInvcSetupGridPopupId';
Modules.CompIds.ocnSupplrAutomaticInvcSetupPopupChrgCodeId = 'ocnSupplrAutomaticInvcSetupPopupChrgCodeId';
Modules.CompIds.ocnSupplrAutomaticInvcSetupPopupServiceTypeId= 'ocnSupplrAutomaticInvcSetupPopupServiceTypeId';
Modules.CompIds.oceanRoundingCriteriaGridPopupId= 'oceanRoundingCriteriaGridPopupId';
Modules.CompIds.ocnSupplrRoundingCriteriaForRatePopupServiceTypeId='ocnSupplrRoundingCriteriaForRatePopupServiceTypeId';
Modules.CompIds.ocnSupplrRoundingCriteriaForRatePopupCurrencyId='ocnSupplrRoundingCriteriaForRatePopupCurrencyId';

Modules.CompIds.rateCriteriaPopUpSupplierMasterFormId = 'rateCriteriaPopUpSupplierMasterFormId';
Modules.CompIds.roundingCriteriaWinCurrencySupMasterId = 'roundingCriteriaWinCurrencySupMasterId';
Modules.CompIds.roundingCriteriaWinServiceTypeSupMasterId = 'roundingCriteriaWinServiceTypeSupMasterId';
Modules.CompIds.roundingCriteriaWinValueSupMasterId = 'roundingCriteriaWinValueSupMasterId ';
Modules.CompIds.roundingCriteriaWinSupMasterId = 'roundingCriteriaWinSupMasterId ';

Modules.CompIds.oceanSupplrMasterStsDtForContrctIdGridPopupId = 'oceanSupplrMasterStsDtForContrctIdGridPopupId';
Modules.CompIds.ocnSupplrStsDtForContractIdGridPopupServiceTypeId = 'ocnSupplrStsDtForContractIdGridPopupServiceTypeId';
Modules.CompIds.ocnSupplrStsDtForContractIdGridPopupChrgCodeId = 'ocnSupplrStsDtForContractIdGridPopupChrgCodeId';


Modules.CompIds.roundinCriteriaActionColId = 'roundinCriteriaActionColId ';
Modules.CompIds.SupplrMasterDtlsGridPopSpplrCdId = 'SupplrMasterDtlsGridPopSpplrCdId';
//Modules.CompIds.deleteSupplierMasterPaymentDtlsId = 'deleteSupplierMasterPaymentDtlsId';
Modules.CompIds.automaticInvoicePopUpSupplierMasterFormId = 'automaticInvoicePopUpSupplierMasterFormId';

Modules.CompIds.chargeCdAutoInvSetupWinSupMasterId = 'chargeCdAutoInvSetupWinSupMasterId ';
Modules.CompIds.triggerStatusAutoInvSetupWinSupMasterId = 'triggerStatusAutoInvSetupWinSupMasterId ';
Modules.CompIds.genReconInvAutoInvSetupWinSupMasterId = 'genReconInvAutoInvSetupWinSupMasterId ';
Modules.CompIds.autoInvcSetupPopupWinSupMasterId = 'autoInvcSetupPopupWinSupMasterId'; 

Modules.CompIds.statusDatePopUpWinSupplierMasterFormId = 'statusDatePopUpWinSupplierMasterFormId'; 
Modules.CompIds.serviceTypeStatusDateWinSupMasterId = 'serviceTypeStatusDateWinSupMasterId'; 
Modules.CompIds.chargeCdStatusDateWinSupMasterId = 'chargeCdStatusDateWinSupMasterId'; 
Modules.CompIds.compltDtStatusDateWinSupMasterId = 'compltDtStatusDateWinSupMasterId'; 
Modules.CompIds.polStatusDateWinSupMasterId = 'polStatusDateWinSupMasterId'; 
Modules.CompIds.podStatusDateWinSupMasterId = 'podStatusDateWinSupMasterId'; 
Modules.CompIds.statusDateFormPopUpWinSupplierMasterFormId = 'statusDateFormPopUpWinSupplierMasterFormId'; 

Modules.CompIds.paymentDtlsFormPopUpWinSupplierMasterFormId = 'paymentDtlsFormPopUpWinSupplierMasterFormId'; 
Modules.CompIds.chargeCdPaymentDtlsWinSupMasterId = 'chargeCdPaymentDtlsWinSupMasterId'; 
Modules.CompIds.paymentTermDaysPaymentDtlsWinSupMasterId = 'paymentTermDaysPaymentDtlsWinSupMasterId'; 
Modules.CompIds.paymentDtlsPopUpWinSupplierMasterFormId = 'paymentDtlsPopUpWinSupplierMasterFormId'; 

Modules.CompIds.supplierMasterDtlsGridPopupId = 'supplierMasterDtlsGridPopupId'; 
Modules.CompIds.supplierCdSupplierDtlsWinSupMasterId = 'supplierCdSupplierDtlsWinSupMasterId'; 
Modules.CompIds.defaultCurrencySupplierDtlsWinSupMasterId = 'defaultCurrencySupplierDtlsWinSupMasterId'; 

Modules.CompIds.stateProvinceSupplierDtlsWinSupMasterId = 'stateProvinceSupplierDtlsWinSupMasterId'; 
Modules.CompIds.supplierNmSupplierDtlsWinSupMasterId = 'supplierNmSupplierDtlsWinSupMasterId'; 
Modules.CompIds.taxRefNumberSupplierDtlsWinSupMasterId = 'taxRefNumberSupplierDtlsWinSupMasterId'; 
Modules.CompIds.addrLineOneSupplierDtlsWinSupMasterId = 'addrLineOneSupplierDtlsWinSupMasterId'; 
Modules.CompIds.addrLineTwoSupplierDtlsWinSupMasterId = 'addrLineTwoSupplierDtlsWinSupMasterId'; 
Modules.CompIds.citySupplierDtlsWinSupMasterId = 'citySupplierDtlsWinSupMasterId'; 
Modules.CompIds.countrySupplierDtlsWinSupMasterId = 'countrySupplierDtlsWinSupMasterId'; 
Modules.CompIds.zipcdSupplierDtlsWinSupMasterId = 'zipcdSupplierDtlsWinSupMasterId'; 
Modules.CompIds.telNoSupplierDtlsWinSupMasterId = 'telNoSupplierDtlsWinSupMasterId'; 
Modules.CompIds.faxNumSupplierDtlsWinSupMasterId = 'faxNumSupplierDtlsWinSupMasterId'; 
Modules.CompIds.mobileSupplierDtlsWinSupMasterId = 'mobileSupplierDtlsWinSupMasterId'; 
Modules.CompIds.emailSupplierDtlsWinSupMasterId = 'emailSupplierDtlsWinSupMasterId'; 
Modules.CompIds.contPerNmSupplierDtlsWinSupMasterId = 'contPerNmSupplierDtlsWinSupMasterId'; 
Modules.CompIds.websiteSupplierDtlsWinSupMasterId = 'websiteSupplierDtlsWinSupMasterId'; 
Modules.CompIds.financialIdSupplierDtlsWinSupMasterId = 'financialIdSupplierDtlsWinSupMasterId'; 
Modules.CompIds.remksOneSupplierDtlsWinSupMasterId = 'remksOneSupplierDtlsWinSupMasterId'; 
Modules.CompIds.remksTwoSupplierDtlsWinSupMasterId = 'remksTwoSupplierDtlsWinSupMasterId'; 
Modules.CompIds.calcTaxNtSentMsgSupplierDtlsWinSupMasterId = 'calcTaxNtSentMsgSupplierDtlsWinSupMasterId'; 
Modules.CompIds.sendApMsgCodaSupplierDtlsWinSupMasterId = 'sendApMsgCodaSupplierDtlsWinSupMasterId'; 
Modules.CompIds.calcTaxNtSentExlSupplierDtlsWinSupMasterId = 'calcTaxNtSentExlSupplierDtlsWinSupMasterId'; 
Modules.CompIds.ignorInvDueDtFrmMsgSupplierDtlsWinSupMasterId = 'ignorInvDueDtFrmMsgSupplierDtlsWinSupMasterId'; 
Modules.CompIds.shipmentDtSupplierDtlsWinSupMasterId = 'shipmentDtSupplierDtlsWinSupMasterId'; 
Modules.CompIds.partialPaySupplierDtlsWinSupMasterId = 'partialPaySupplierDtlsWinSupMasterId'; 
Modules.CompIds.compltnDtSupplierDtlsWinSupMasterId = 'compltnDtSupplierDtlsWinSupMasterId'; 
Modules.CompIds.creatVarEvntSupplierDtlsWinSupMasterId = 'creatVarEvntSupplierDtlsWinSupMasterId'; 
Modules.CompIds.autoApproveSupplierDtlsWinSupMasterId = 'autoApproveSupplierDtlsWinSupMasterId'; 

Modules.CompIds.supplierDtlsPopUpWinSupplierMasterFormId = 'supplierDtlsPopUpWinSupplierMasterFormId';
Modules.CompIds.ocnSpplrMasterFormNameId = 'ocnSpplrMasterFormNameId';
//buttons all together
Modules.CompIds.addSupplierMasterDtlsId = 'addSupplierMasterDtlsId'; 
Modules.CompIds.deleteSupplierMasterDtlsId = 'deleteSupplierMasterDtlsId'; 
Modules.CompIds.saveSupplierMasterDtlsId = 'saveSupplierMasterDtlsId'; 

Modules.CompIds.saveSupplierMasterInvSetupId = 'saveSupplierMasterInvSetupId'; 
Modules.CompIds.addSupplierMasterInvSetupId = 'addSupplierMasterInvSetupId'; 
Modules.CompIds.deleteSupplierMasterInvSetupId = 'deleteSupplierMasterInvSetupId'; 

Modules.CompIds.saveSupplierMasterPaymentDtlsId = 'saveSupplierMasterPaymentDtlsId'; 
Modules.CompIds.addSupplierMasterPaymentDtlsId = 'addSupplierMasterPaymentDtlsId'; 
Modules.CompIds.deleteSupplierMasterPaymentDtlsId = 'deleteSupplierMasterPaymentDtlsId'; 

Modules.CompIds.saveSupplierMasterRateRoundingCriteriaId = 'saveSupplierMasterRateRoundingCriteriaId'; 
Modules.CompIds.addSupplierMasterRateRoundingCriteriaId = 'addSupplierMasterRateRoundingCriteriaId'; 
Modules.CompIds.addSpplrMasterRtRoundingCriteriaId     =  'addSpplrMasterRtRoundingCriteriaId';
Modules.CompIds.deleteSupplierMasterRateRoundingCriteriaId = 'deleteSupplierMasterRateRoundingCriteriaId'; 

Modules.CompIds.saveSupplierMasterStatusId = 'saveSupplierMasterStatusId'; 
Modules.CompIds.addSupplierMasterStatusId = 'addSupplierMasterStatusId'; 
Modules.CompIds.deleteSupplierMasterStatusId = 'deleteSupplierMasterStatusId'; 

Modules.CompIds.oceanSupplierMasterFormId = 'oceanSupplierMasterFormId';
//ocean

Modules.CompIds.oceanCustomerRateQueryTabPanelId = 'oceanCustomerRateQueryTabPanelId'; 

Modules.CompIds.oceanCustomerSearchFormId = 'oceanCustomerSearchFormId'; 
Modules.CompIds.oceanCustomerRateQueryPopupWinFormId = 'oceanCustomerRateQueryPopupWinFormId'; 

Modules.CompIds.oceanCustomerQryFrmCompanyId = 'oceanCustomerQryFrmCompanyId'; 
Modules.CompIds.oceanCustomerQryFrmPopId = 'oceanCustomerQryFrmPopId'; 
Modules.CompIds.oceanCustomerQryFrmPartyId = 'oceanCustomerQryFrmPartyId'; 
Modules.CompIds.oceanCustomerQryFrmContactIdId = 'oceanCustomerQryFrmContactIdId'; 
Modules.CompIds.oceanCustomerQryFrmCompanyNmId = 'oceanCustomerQryFrmCompanyNmId'; 
Modules.CompIds.oceanCustomerQryFrmPopDescrId = 'oceanCustomerQryFrmPopDescrId'; 
Modules.CompIds.oceanCustomerQryFrmNameId = 'oceanCustomerQryFrmNameId'; 
Modules.CompIds.oceanCustomerQryFrmStartDtId = 'oceanCustomerQryFrmStartDtId'; 
Modules.CompIds.oceanCustomerQryFrmEndDtId = 'oceanCustomerQryFrmEndDtId'; 
Modules.CompIds.oceanCustomerQryFrmContractId  = 'CustomerRateQueryOceanId';

Modules.CompIds.oceanCustomerRateQueryPopupWinId = 'oceanCustomerRateQueryPopupWinId'; 

Modules.CompIds.oceanCustomerCopyPopId = 'oceanCustomerCopyPopId'; 
Modules.CompIds.oceanCustomerCopyCompanyId = 'oceanCustomerCopyCompanyId'; 
Modules.CompIds.oceanCustomerCopyOldContractId = 'oceanCustomerCopyOldContractId'; 
Modules.CompIds.oceanCustomerCopyCompanyNmId = 'oceanCustomerCopyCompanyNmId'; 
Modules.CompIds.oceanCustomerCopyPopDescrId = 'oceanCustomerCopyPopDescrId'; 
Modules.CompIds.oceanCustomerRateQryPopupWinFormId = 'oceanCustomerRateQryPopupWinFormId'; 

Modules.CompIds.oceanCustContractPopUpId = 'oceanCustContractPopUpId'; 
//**********************************************************************************************************************************************


/** Customer Rate Verification **/

Modules.CompIds.cstmrRateVerificationFormOriginId='cstmrRateVerificationFormOriginId';

/**  Non-Ocean Customer Invoice Setup  **/

Modules.CompIds.actualGroupingCriteriaDefltSupplRecordId='actualGroupingCriteriaDefltSupplRecordId';
Modules.CompIds.customerMasterCustomercodeId='customerMasterCustomercodeId';
Modules.CompIds.customerMasterServiceTypeId='customerMasterServiceTypeId';
Modules.CompIds.oceanSupplierRateVerificationTabPanelId='oceanSupplierRateVerificationTabPanelId';

/***************************** Non-Ocean Supplier Remittance Details **********************************************/
Modules.CompIds.supplierRemittanceDetailsPanelId='supplierRemittanceDetailsPanelId';
Modules.CompIds.oceanSupplierRateAdvContainer='oceanSupplierRateAdvContainer';


/** Ocean Customer Rate Verification **/

Modules.CompIds.oceanCustomerRateVerificationTabPanelId 					= 'oceanCustomerRateVerificationTabPanelId';
Modules.CompIds.oceanCustomerRateVerificationFormId     					= 'oceanCustomerRateVerificationFormId';
Modules.CompIds.oceanCustomerRateVerificationFormSupplierId     			= 'oceanCustomerRateVerificationFormSupplierId';
Modules.CompIds.oceanCustomerRateVerificationFormEffectiveDateId     		= 'oceanCustomerRateVerificationFormEffectiveDateId';
Modules.CompIds.oceanCustomerRateVerificationFormChargeCodeId     		    = 'oceanCustomerRateVerificationFormChargeCodeId';
Modules.CompIds.oceanCustomerRateVerificationFormPartyId     		        = 'oceanCustomerRateVerificationFormPartyId';
Modules.CompIds.oceanCustomerRateVerificationFormPartyNmId     		        = 'oceanCustomerRateVerificationFormPartyNmId';
Modules.CompIds.oceanCustomerRateVerificationFormPopId     		        	= 'oceanCustomerRateVerificationFormPopId';
Modules.CompIds.oceanCustomerRateVerificationFormPopNmId     		        = 'oceanCustomerRateVerificationFormPopNmId';
Modules.CompIds.oceanCustomerRateVerificationFormFreightTrmsCodeId     		= 'oceanCustomerRateVerificationFormFreightTrmsCodeId';
Modules.CompIds.oceanCustomerRateVerificationFormVslTypeId     				= 'oceanCustomerRateVerificationFormVslTypeId';
Modules.CompIds.oceanCustomerRateVerificationFormPolId     				    = 'oceanCustomerRateVerificationFormPolId';
Modules.CompIds.oceanCustomerRateVerificationFormPodId     				    = 'oceanCustomerRateVerificationFormPodId';
Modules.CompIds.oceanCustomerRateVerificationFormMakeCdId     			    = 'oceanCustomerRateVerificationFormMakeCdId';
Modules.CompIds.oceanCustomerRateVerificationFormModelCdId     			    = 'oceanCustomerRateVerificationFormModelCdId';
Modules.CompIds.oceanCustomerRateVerificationFormRateTierId     			= 'oceanCustomerRateVerificationFormRateTierId';
Modules.CompIds.oceanCustomerRateVerificationFormModelGrpCdId     			= 'oceanCustomerRateVerificationFormModelGrpCdId';
Modules.CompIds.oceanCustomerRateVerificationFormPorCdId     			    = 'oceanCustomerRateVerificationFormPorId';
Modules.CompIds.oceanCustomerRateVerificationFormPfdCdId     			    = 'oceanCustomerRateVerificationFormPfdId';
Modules.CompIds.oceanCustomerRateVerificationFormAdvCntnrId     			= 'oceanCustomerRateVerificationFormAdvCntnrId';
Modules.CompIds.oceanCustomerRateVerificationFormModelYrId     			    = 'oceanCustomerRateVerificationFormModelYrId';
Modules.CompIds.oceanCustomerRateVerificationGridId     			        = 'oceanCustomerRateVerificationGridId';
Modules.CompIds.oceanCustomerRateVerificationPopWinId     			        = 'oceanCustomerRateVerificationPopWinId';

/** Ocean Customer Rate Verification **/


/**  Ocean Customer Invoice Generation  **/

Modules.CompIds.oceanCstmrInvcGenFormPopId='oceanCstmrInvcGenFormPopId';
Modules.CompIds.oceanCstmrInvcGenFormPartyId='oceanCstmrInvcGenFormPartyId';
Modules.CompIds.oceanCstmrInvcGenFormCarrierId='oceanCstmrInvcGenFormCarrierId';
Modules.CompIds.oceanCstmrInvcGenFormBLNumberId='oceanCstmrInvcGenFormBLNumberId';
Modules.CompIds.oceanCstmrInvcGenFormFreightTrmsId='oceanCstmrInvcGenFormFreightTrmsId';
Modules.CompIds.oceanCstmrInvcGenFormChargeCodeId='oceanCstmrInvcGenFormChargeCodeId';
Modules.CompIds.oceanCstmrInvcGenFormSrvGrpCodeId='oceanCstmrInvcGenFormSrvGrpCodeId';
Modules.CompIds.oceanCstmrInvcGenFormPolId='oceanCstmrInvcGenFormPolId';
Modules.CompIds.oceanCstmrInvcGenFormPodId='oceanCstmrInvcGenFormPodId';
Modules.CompIds.oceanCstmrInvcGenFormShipRefNumbrId='oceanCstmrInvcGenFormShipRefNumbrId';
Modules.CompIds.oceanCstmrInvcGenFormLocalCurrencyId='oceanCstmrInvcGenFormLocalCurrencyId';
Modules.CompIds.oceanCstmrInvcGenFormPorId='oceanCstmrInvcGenFormPorId';
Modules.CompIds.oceanCstmrInvcGenFormPfdId='oceanCstmrInvcGenFormPfdId';
Modules.CompIds.oceanCstmrInvcGenFormSailngFrmDtId='oceanCstmrInvcGenFormSailngFrmDtId';
Modules.CompIds.oceanCstmrInvcGenFormSailngToDtId='oceanCstmrInvcGenFormSailngToDtId';
Modules.CompIds.oceanCstmrInvcGenFormVoyageId='oceanCstmrInvcGenFormVoyageId';
Modules.CompIds.oceanCstmrInvcGenFormBlComplFromDtId='oceanCstmrInvcGenFormBlComplFromDtId';
Modules.CompIds.oceanCstmrInvcGenFormBlComplToDtId='oceanCstmrInvcGenFormBlComplToDtId';
Modules.CompIds.oceanCstmrInvcGenFormVesselId='oceanCstmrInvcGenFormVesselId';



Modules.CompIds.carrierNameSupplierRateVerificationFormId='carrierNameSupplierRateVerificationFormId';
Modules.CompIds.supNameSupplierRateQueryFormId='supNameSupplierRateQueryFormId';

Modules.CompIds.oceanSupplierRateVerificationFormId='oceanSupplierRateVerificationFormId';

/***Ocean Customer Invoice Status Screen ***/
Modules.CompIds.oceancustmrComboCustomerInvoiceId = 'customerInvoiceOceanStatusId';
Modules.CompIds.oceandbtrPartyComboCustomerInvoiceId = 'dbtrPartyCustomerInvoiceOceanId';
Modules.CompIds.oceancustomerInvoiceFrmDateId = 'customerInvoiceOceanFrmDateId';
Modules.CompIds.oceancustomerInvoiceToDateId = 'customerInvoiceOceanToDateId';
Modules.CompIds.oceancustomerInvoiceActualId = 'customerInvoiceOceanActualId';
Modules.CompIds.oceancustomerInvoiceAccuralId = 'customerInvoiceOceanAccuralId';
Modules.CompIds.oceancustomerInvoiceProformaId = 'customerInvoiceOceanProformaId';
Modules.CompIds.oceancustomerInvoiceRejectedId = 'customerInvoiceOceanRejectedId';
Modules.CompIds.oceancustomerInvoiceFinalId = 'customerInvoiceOceanFinalId';
Modules.CompIds.oceancustomerInvoicePaidId = 'customerInvoiceOceanPaidId';
Modules.CompIds.oceancustomerInvoiceCreditId = 'customerInvoiceOceanCreditId';
Modules.CompIds.oceancustomerInvoiceDebitId = 'customerInvoiceOceanDebitId';
Modules.CompIds.oceancustomerInvoiceStatusGridId = 'customerInvoiceOceanStatusGridId';
Modules.CompIds.oceancustomerInvoiceNoComboId = 'InvoiceOceanNoId';
Modules.CompIds.oceandbtrComboCustomerInvoiceId = 'dbtrComboCustomerInvoiceOceanId';
Modules.CompIds.oceancustomerInvoiceStatusPopupWinId = 'customerInvoiceOceanStatusPopupWinId';
Modules.CompIds.oceanpopupCustomerInvoiceStatusId = 'popupCustomerInvoiceOceanStatusId';
Modules.CompIds.oceancustomerInvoiceStatusPrintPopupWinId = 'customerInvoiceOceanStatusPrintPopupWinId';
Modules.CompIds.oceanpopupCustomerInvoiceStatusPrintId = 'popupCustomerInvoiceOceanStatusPrintId';
Modules.CompIds.oceancustomerInvoiceBackUpFlgId= 'customerInvoiceOceanBackUpFlgId';
Modules.CompIds.oceancustomerInvoiceFlgId= 'customerInvoiceOceanFlgId';
Modules.CompIds.oceanviewPrintId='viewPrintOceanId';
Modules.CompIds.oceanemailPrintId='emailPrintOceanId';
Modules.CompIds.oceancustomerPrintId='customerPrintId';
Modules.CompIds.oceancustomerInvoicePrinterCd = 'customerInvoiceOceanPrinterCd';
Modules.CompIds.oceancustomerBackUpPrinterCd = 'customerBackUpPrinterCdOceanId';
Modules.CompIds.oceancustomerInvoiceCopiesId = 'customerInvoiceOceanCopiesId';
Modules.CompIds.oceancustomerInvoiceBackUpCopiesId = 'customerInvoiceOceanBackUpCopiesId';
Modules.CompIds.oceancustomerInvoiceCCMailId = 'customerInvoiceOceanCCMailId';
Modules.CompIds.oceanCustomerInvoiceSummaryFormId='customerInvoiceOceanSummaryFormId';

Modules.CompIds.oceanSupplierRateVerificationFormId='oceanSupplierRateVerificationFormId';
Modules.CompIds.customerMasterCntryId='customerMasterCntryId';
Modules.CompIds.customerMasterCntryGridId='customerMasterCntryGridId';
Modules.CompIds.oceanCustomerPrintTemplateGridId = 'oceanCstmrMstrPrintTmpltGridId';
Modules.CompIds.addOceanPrintTemplateRecordId = 'addOceanPrintTemplateRecordId';


Modules.CompIds.oceanSupplierMstrSupplierLOVId = 'oceanSupplierMstrSupplierLOVId';
Modules.CompIds.oceanSupplierMasterGridId='oceanSupplierMasterGridId';
Modules.CompIds.paymentDetailsSOceanupplierMasterGridId='paymentDetailsSOceanupplierMasterGridId';
Modules.CompIds.statusDateOceanSupplierMasterGridId = 'statusDateOceanSupplierMasterGridId';
Modules.CompIds.oceanSupplrMstrAutomaticInvSetupGridId = 'oceanSupplrMstrAutomaticInvSetupGridId';



Modules.CompIds.oceanCustomerRateQueryGridPopUpId ='oceanCustomerRateQueryGridPopUpId';
/***Ocean Customer Invoice Entry Screen ***/

Modules.CompIds.oceanCstmrInvEntryTabPanelId = 'oceanCstmrInvEntryTabPanelId';

/***Ocean Customer Line Item Status***/
Modules.CompIds.oceanCustomerLineItemStatusTabParentId='oceanCustomerLineItemStatusTabParentId';
Modules.CompIds.customerNameFormId='customerNameFormId';



Modules.CompIds.ocnTotalInvcAmtCurrAccRecId = 'ocnTotalInvcAmtCurrAccRecId';
Modules.CompIds.ocnCstmrNmAccRecId  =  'ocnCstmrNmAccRecId';

//  Ocean Suplier Rates

Modules.CompIds.oceanSupplierRateFormId='oceanSupplierRateFormId';
Modules.CompIds.oceanSupplierRateFormValidFromDateId='oceanSupplierRateFormValidFromDateId';
Modules.CompIds.oceanSupplierRateFormValidToDateId='oceanSupplierRateFormValidToDateId';
Modules.CompIds.oceanSupplierRateFormSupplierNameId='oceanSupplierRateFormSupplierNameId';
Modules.CompIds.oceanSupplierRateFormSupplierId='oceanSupplierRateFormSupplierId';
Modules.CompIds.oceanSupplierRateFormContractId='oceanSupplierRateFormContractId';
Modules.CompIds.oceanSupplierRateFormRemarkId='oceanSupplierRateFormRemarkId';
Modules.CompIds.oceanSupplierRateRetriveGridId='oceanSupplierRateRetriveGridId';
Modules.CompIds.oceanSupplierRateRetriveGridContractId='oceanSupplierRateRetriveGridContractId';
Modules.CompIds.oceanSupplierRateRetriveGridSuplierId='oceanSupplierRateRetriveGridSuplierId';
Modules.CompIds.oceanSupplierRateRetriveGridSuplierNameId='oceanSupplierRateRetriveGridSuplierNameId';
Modules.CompIds.oceanSupplierRateRetriveGridValidFromDtId='oceanSupplierRateRetriveGridValidFromDtId';
Modules.CompIds.oceanSupplierRateRetriveGridValidToDtId='oceanSupplierRateRetriveGridValidToDtId';
Modules.CompIds.oceanSupplierRateRetriveGridServLevelValidDtsId='oceanSupplierRateRetriveGridServLevelValidDtsId';

Modules.CompIds.oceanSupplierRateRetriveGridRemarkId='oceanSupplierRateRetriveGridRemarkId';
Modules.CompIds.oceanSupplierRateChildGridId='oceanSupplierRateChildGridId';

Modules.CompIds.oceanSupplierRateChildGridChrgCodeId='oceanSupplierRateChildGridChrgCodeId';
Modules.CompIds.oceanSupplierRateChildGridpartyId='oceanSupplierRateChildGridpartyId';
Modules.CompIds.oceanSupplierRateChildGridvalidFrmDtId='oceanSupplierRateChildGridvalidFrmDtId';
Modules.CompIds.oceanSupplierRateChildGridvalidToDtId='oceanSupplierRateChildGridvalidToDtId';

Modules.CompIds.oceanSupplierRateChildGridCargoClsId='oceanSupplierRateChildGridCargoClsId';
Modules.CompIds.oceanSupplierRateChildGridCargoTypeId='oceanSupplierRateChildGridCargoTypeId';
Modules.CompIds.oceanSupplierRateChildGridMakeCodeId='oceanSupplierRateChildGridMakeCodeId';
Modules.CompIds.oceanSupplierRateChildGridModelId='oceanSupplierRateChildGridModelId';
Modules.CompIds.oceanSupplierRateChildGridpolCityId='oceanSupplierRateChildGridpolCityId';
Modules.CompIds.oceanSupplierRateChildGridPolStateId='oceanSupplierRateChildGridPolStateId';
Modules.CompIds.oceanSupplierRateChildGridPolCntryId='oceanSupplierRateChildGridPolCntryId';
Modules.CompIds.oceanSupplierRateChildGridPodCityId='oceanSupplierRateChildGridPodCityId';
Modules.CompIds.oceanSupplierRateChildGridPodStateId='oceanSupplierRateChildGridPodStateId';
Modules.CompIds.oceanSupplierRateChildGridPodStateId='oceanSupplierRateChildGridPodCntryId';
Modules.CompIds.oceanSupplierRateChildGridPorId='oceanSupplierRateChildGridPorId';
Modules.CompIds.oceanSupplierRateChildGridPfdId='oceanSupplierRateChildGridPfdId';
Modules.CompIds.oceanSupplierRateChildGridSteeringId='oceanSupplierRateChildGridSteeringId';
Modules.CompIds.oceanSupplierRateChildGridHazardousId='oceanSupplierRateChildGridHazardousId';
Modules.CompIds.oceanSupplierRateChildGridHandlingIndId='oceanSupplierRateChildGridHandlingIndId';
Modules.CompIds.oceanSupplierRateChildGridTrnsferGearId='oceanSupplierRateChildGridTrnsferGearId';
Modules.CompIds.oceanSupplierRateChildGridTrnsferGearId='oceanSupplierRateChildGridTrnsferGearId';
Modules.CompIds.oceanSupplierRateChildGridFactorValueId='oceanSupplierRateChildGridFactorValueId';
Modules.CompIds.oceanSupplierRateChildGridFactorTypeId='oceanSupplierRateChildGridFactorTypeId';
Modules.CompIds.oceanSupplierRateChildGridFactorRateId='oceanSupplierRateChildGridFactorRateId';
Modules.CompIds.oceanSupplierRateChildGridFixedRateId='oceanSupplierRateChildGridFixedRateId';
Modules.CompIds.oceanSupplierRateChildGridTariffRateId='oceanSupplierRateChildGridTariffRateId';
Modules.CompIds.oceanSupplierRateChildGridLuIndId='oceanSupplierRateChildGridLuIndId';
Modules.CompIds.oceanSupplierRateChildGridTariffCurncyCdId='oceanSupplierRateChildGridTariffCurncyCdId';
Modules.CompIds.oceanSupplierRateChildGridPriorityId='oceanSupplierRateChildGridPriorityId';
Modules.CompIds.oceanSupplierRateChildGridSeqNoId='oceanSupplierRateChildGridSeqNoId';
Modules.CompIds.oceanSupplierRateFormServLevelValDatsId='oceanSupplierRateFormServLevelValDatsId';
Modules.CompIds.oceanSupplierRateChildGridPolId='oceanSupplierRateChildGridPolId';

Modules.CompIds.oceanSupplierRateChildGridPodId='oceanSupplierRateChildGridPodId';
Modules.CompIds.oceanSupplierRateMiddleFormFilterId='oceanSupplierRateMiddleFormFilterId';
Modules.CompIds.oceanSupplierRatesPanelId='oceanSupplierRatesPanelId';


//Ocean Customer Application Advice
Modules.CompIds.ocnCstmrApplAdvcTabPanelId = 'ocnCstmrApplAdvcTabPanelId';
Modules.CompIds.ocnCstmrApplAdvcFormId = 'ocnCstmrApplAdvcFormId';

Modules.CompIds.ocnCstmrApplAdvcFormBlNumberId = 'ocnCstmrApplAdvcFormBlNumberId';
Modules.CompIds.ocnCstmrApplAdvcFormPartyId = 'ocnCstmrApplAdvcFormPartyId';
Modules.CompIds.ocnCstmrApplAdvcFormPartyPayerId = 'ocnCstmrApplAdvcFormPartyPayerId';
Modules.CompIds.ocnCstmrApplAdvcFormServiceCodeId = 'ocnCstmrApplAdvcFormServiceCodeId';
Modules.CompIds.ocnCstmrApplAdvcFormServiceTypeId = 'ocnCstmrApplAdvcFormServiceTypeId';
Modules.CompIds.ocnCstmrApplAdvcFormFrieghtTrmsId = 'ocnCstmrApplAdvcFormFrieghtTrmsId';
Modules.CompIds.ocnCstmrApplAdvcFormSrvcGrpCdId = 'ocnCstmrApplAdvcFormSrvcGrpCdId';
Modules.CompIds.ocnCstmrApplAdvcFormVoyageId = 'ocnCstmrApplAdvcFormVoyageId';
Modules.CompIds.ocnCstmrApplAdvcFormVesselId = 'ocnCstmrApplAdvcFormVesselId';
Modules.CompIds.ocnCstmrApplAdvcFormPOPId = 'ocnCstmrApplAdvcFormPOPId';
Modules.CompIds.ocnCstmrApplAdvcFormPOPDescId = 'ocnCstmrApplAdvcFormPOPDescId';
Modules.CompIds.ocnCstmrApplAdvcFormInvoiceNumberId = 'ocnCstmrApplAdvcFormInvoiceNumberId';
Modules.CompIds.ocnCstmrApplAdvcFormPOPInvcNumberId = 'ocnCstmrApplAdvcFormPOPInvcNumberId';
Modules.CompIds.ocnCstmrApplAdvcRejectBtnId = 'ocnCstmrApplAdvcRejectBtnId';
Modules.CompIds.ocnCstmrApplAdvcAcceptBtnId = 'ocnCstmrApplAdvcAcceptBtnId';
Modules.CompIds.ocnCstmrApplAdvcActionColId = 'ocnCstmrApplAdvcActionColId';
Modules.CompIds.ocnCstmrApplAdvcActionColPopUpWindwId ='ocnCstmrApplAdvcActionColPopUpWindwId';

Modules.CompIds.ocnCstmrApplAdvcGPPopUpWindowId = 'ocnCstmrApplAdvcGPPopUpWindowId';
Modules.CompIds.ocnCstmrApplAdvcPGridPopUpWindowId = 'ocnCstmrApplAdvcPGridPopUpWindowId';
Modules.CompIds.ocnCstmrApplAdvcChildGridPopUpWindowId = 'ocnCstmrApplAdvcChildGridPopUpWindowId';

Modules.CompIds.oceanSupplierRateChildGridPodId='oceanSupplierRateChildGridPodId';


/***************************Ocean Supplier Event Status Summary*******************************************/
Modules.CompIds.spplrEventStatusSummaryParentTabpanelId = 'spplrEventStatusSummaryParentTabpanelId';
Modules.CompIds.ocnSpplrEventStatusSummaryFormId  =  'ocnSpplrEventStatusSummaryFormId';
Modules.CompIds.ocnSupplrEventStatusSummaryAdvContainerId = 'ocnSupplrEventStatusSummaryAdvContainerId';
Modules.CompIds.oceanSpplrStsEvntSummPOPId = 'oceanSpplrStsEvntSummPOPId';
Modules.CompIds.oceanSpplrStsEvntSummbLNbrId  = 'oceanSpplrStsEvntSummbLNbrId';
Modules.CompIds.oceanSpplrStsEvntSummFrieghtTermId = 'oceanSpplrStsEvntSummFrieghtTermId';
Modules.CompIds.oceanSpplrStsEvntSummVesselId = 'oceanSpplrStsEvntSummVesselId';
Modules.CompIds.oceanSpplrStsEvntSummVoyageId = 'oceanSpplrStsEvntSummVoyageId';
Modules.CompIds.oceanSpplrStsEvntSummSupplierId  = 'oceanSpplrStsEvntSummSupplierId';
Modules.CompIds.oceanSpplrStsEvntSummPOLId= 'oceanSpplrStsEvntSummPOLId';
Modules.CompIds.ocnSupplierStsEvntSummPODId= 'ocnSupplierStsEvntSummPODId';
Modules.CompIds.oceanSupplrStsEvntSummPORId = 'oceanSupplrStsEvntSummPORId';
Modules.CompIds.oceanSpplrStsEvntSummPFDId= 'oceanSpplrStsEvntSummPFDId';
Modules.CompIds.ocnSpplrEvntStsSummCstmrStatusId = 'ocnSpplrEvntStsSummCstmrStatusId';
Modules.CompIds.ocnSpplrEvntStsSummSupplierStatusId = 'ocnSpplrEvntStsSummSupplierStatusId';
Modules.CompIds.ocnSpplrEvntStsSummPopUpWinId  = 'ocnSpplrEvntStsSummPopUpWinId';
Modules.CompIds.ocnPinvcEvntstatusSummaryId = 'ocnPinvcEvntstatusSummaryId';
Modules.CompIds.ocnZerortEvntstatusSummaryId = 'ocnZerortEvntstatusSummaryId';
Modules.CompIds.ocnRecnclEvntstatusSummaryId = 'ocnRecnclEvntstatusSummaryId';
Modules.CompIds.ocnApprvEvntstatusSummaryId = 'ocnApprvEvntstatusSummaryId';
Modules.CompIds.ocnNochrgEvntstatusSummaryId  =  'ocnNochrgEvntstatusSummaryId';
Modules.CompIds.ocnSupplrEventStatusSummaryGridId  =  'ocnSupplrEventStatusSummaryGridId';

/**********************End Ocn Supplr Evnt Sts Suum**********************************************************/

/****************************Ocean Customer Rates******************************/

Modules.CompIds.ocnCustmrRatesParentPanelId = 'ocnCustmrRatesParentPanelId';
Modules.CompIds.ocnCustmrRateFormId  = 'ocnCustmrRateFormId';
Modules.CompIds.ocnCstmrRatesValidFrmDateId = 'ocnCstmrRatesValidFrmDateId';
Modules.CompIds.ocnCstmrRatesValidToDateId   =  'ocnCstmrRatesValidToDateId';
Modules.CompIds.ocnSrvcLvlValidDtId    =  'ocnSrvcLvlValidDtId';
Modules.CompIds.ocnCstmrRatesRemarkId  =  'ocnCstmrRatesRemarkId';
Modules.CompIds.ocnCstmrRatesValidFrmDateId = 'ocnCstmrRatesValidFrmDateId';
Modules.CompIds.ocnCstmrRatesValidToDateId  =  'ocnCstmrRatesValidToDateId';
Modules.CompIds.ocnCstmrRatesPartyNmId     =  'ocnCstmrRatesPartyNmId';
Modules.CompIds.ocnCstmrRatesHdrGridId  = 'ocnCstmrRatesHdrGridId';
Modules.CompIds.ocnCstmrRateHdrGridContractId = 'ocnCstmrRateHdrGridContractId';
Modules.CompIds.ocnCstmrRatesHdrGridValidFrmDateId = 'ocnCstmrRatesHdrGridValidFrmDateId';
Modules.CompIds.ocnCstmrRatesHdrGridValidToDateId = 'ocnCstmrRatesHdrGridValidToDateId';
Modules.CompIds.ocnCstmrRatesAdvcSrchId = 'ocnCstmrRatesAdvcSrchId';
Modules.CompIds.ocnCstmrRatesEffectiveDateId = 'ocnCstmrRatesEffectiveDateId';
Modules.CompIds.ocnCstmrRatesDtlsParentPanelId = 'ocnCstmrRatesDtlsParentPanelId';
Modules.CompIds.ocnCstmrRatesDtlsGridId  = 'ocnCstmrRatesDtlsGridId';
Modules.CompIds.ocnCstmrRatesContractId =  'ocnCstmrRatesContractId';
Modules.CompIds.ocnCstmrRatesPartyCdId   =  'ocnCstmrRatesPartyCdId';
Modules.CompIds.ocnCstmrRatesGridAddEditWinId  =  'ocnCstmrRatesGridAddEditWinId';
Modules.CompIds.ocnCstmrRatesGridWinContractId  =  'ocnCstmrRatesGridWinContractId';
Modules.CompIds.ocnCstmrRatesParentGridWinValidFrmDateId = 'ocnCstmrRatesParentGridWinValidFrmDateId';
Modules.CompIds.ocnCstmrRatesParentGridWinValidToDateId  =  'ocnCstmrRatesParentGridWinValidToDateId';
Modules.CompIds.ocnCstmrRatesParentGridWinPartyCdId  =  'ocnCstmrRatesParentGridWinPartyCdId';
Modules.CompIds.ocnCstmrRatesParentGridWinPartyNmId  = 'ocnCstmrRatesParentGridWinPartyNmId';
Modules.CompIds.ocnCstmrRatesParentGridWinSrvcLvlValidDtId = 'ocnCstmrRatesParentGridWinSrvcLvlValidDtId';
Modules.CompIds.ocnCstmrRatesParentGridWinRemarkId   =  'ocnCstmrRatesParentGridWinRemarkId';
Modules.CompIds.ocnCstmrRatesDtlsGridAddEditWinId  =  'ocnCstmrRatesDtlsGridAddEditWinId';
Modules.CompIds.ocnCstmrRatesParentGridWinEffecDateId  = 'ocnCstmrRatesParentGridWinEffecDateId';
Modules.CompIds.ocnCstmrRatesParentGridWinExpireDateId = 'ocnCstmrRatesParentGridWinExpireDateId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinRateId = 'ocnCstmrRatesDtlsGridWinRateId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinCurrencyCdId  =  'ocnCstmrRatesDtlsGridWinCurrencyCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinRateBasisId   =  'ocnCstmrRatesDtlsGridWinRateBasisId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinPolId   =  'ocnCstmrRatesDtlsGridWinPolId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinPodId   =  'ocnCstmrRatesDtlsGridWinPodId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinPorId   =  'ocnCstmrRatesDtlsGridWinPorId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinPfdId   =  'ocnCstmrRatesDtlsGridWinPfdId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinTypeId = 'ocnCstmrRatesDtlsGridWinTypeId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinModelId = 'ocnCstmrRatesDtlsGridWinModelId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinMakeId  = 'ocnCstmrRatesDtlsGridWinMakeId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinVesselId  =  'ocnCstmrRatesDtlsGridWinVesselId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinCargoTypeId = 'ocnCstmrRatesDtlsGridWinCargoTypeId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinCargoClassId  = 'ocnCstmrRatesDtlsGridWinCargoClassId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinFrieghtTermId  =  'ocnCstmrRatesDtlsGridWinFrieghtTermId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinSpplrCdId = 'ocnCstmrRatesDtlsGridWinSpplrCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinsrvcCdDescId  = 'ocnCstmrRatesDtlsGridWinsrvcCdDescId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinsrvcCdId  = 'ocnCstmrRatesDtlsGridWinsrvcCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinPopId  =  'ocnCstmrRatesDtlsGridWinPopId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinCommodityCdId = 'ocnCstmrRatesDtlsGridWinCommodityCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridWinCommodityDescId =  'ocnCstmrRatesDtlsGridWinCommodityDescId';
Modules.CompIds.ocnCstmrRatesParentGridCopyWinExpireDateId = 'ocnCstmrRatesParentGridCopyWinExpireDateId';
Modules.CompIds.ocnCstmrRatesParentGridCopyWinEffecDateId = 'ocnCstmrRatesParentGridCopyWinEffecDateId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinCurrencyCdId = 'ocnCstmrRatesDtlsGridCopyWinCurrencyCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinRateId= 'ocnCstmrRatesDtlsGridCopyWinRateId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinRateBasisId = 'ocnCstmrRatesDtlsGridCopyWinRateBasisId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinCommodityDescId = 'ocnCstmrRatesDtlsGridCopyWinCommodityDescId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinCommodityCdId  =  'ocnCstmrRatesDtlsGridCopyWinCommodityCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinPfdId = 'ocnCstmrRatesDtlsGridCopyWinPfdId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinPorId = 'ocnCstmrRatesDtlsGridCopyWinPorId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinPodId = 'ocnCstmrRatesDtlsGridCopyWinPodId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinPolId = 'ocnCstmrRatesDtlsGridCopyWinPolId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinTypeId = 'ocnCstmrRatesDtlsGridCopyWinTypeId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinModelId = 'ocnCstmrRatesDtlsGridCopyWinModelId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinMakeId= 'ocnCstmrRatesDtlsGridCopyWinMakeId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinVesselId = 'ocnCstmrRatesDtlsGridCopyWinVesselId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinCargoTypeId = 'ocnCstmrRatesDtlsGridCopyWinCargoTypeId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinCargoClassId= 'ocnCstmrRatesDtlsGridCopyWinCargoClassId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinFrieghtTermId = 'ocnCstmrRatesDtlsGridCopyWinFrieghtTermId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinSpplrCdId = 'ocnCstmrRatesDtlsGridCopyWinSpplrCdId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinsrvcCdDescId = 'ocnCstmrRatesDtlsGridCopyWinsrvcCdDescId';
Modules.CompIds.ocnCstmrRatesDtlsGridCopyWinsrvcCdId = 'ocnCstmrRatesDtlsGridCopyWinsrvcCdId';
Modules.CompIds.ocnCstmrRatesDtlsPopGridCopyWinId= 'ocnCstmrRatesDtlsPopGridCopyWinId';
Modules.CompIds.ocnCustmrRateSrchFormId = 'ocnCustmrRateSrchFormId';

Modules.CompIds.oceanSupplierRateChildGridPodId='oceanSupplierRateChildGridPodId';

/*** START Change Log Screen for Non Ocean ***/

Modules.CompIds.changeLogFormId='changeLogFormId';
Modules.CompIds.changeLogScreenNameId='changeLogScreenNameId';
Modules.CompIds.changeLogUserNameId='changeLogUserNameId';
Modules.CompIds.changeLogTransIndId='changeLogTransIndId';
Modules.CompIds.changeLogLevel1Id='changeLogLevel1Id';
Modules.CompIds.changeLogLevel2Id='changeLogLevel2Id';
Modules.CompIds.changeLogLevel3Id='changeLogLevel3Id';
Modules.CompIds.changeLogLevel4Id='changeLogLevel4Id';
Modules.CompIds.changeLogLevel1DataId='changeLogLevel1DataId';
Modules.CompIds.changeLogLevel2DataId='changeLogLevel2DataId';
Modules.CompIds.changeLogLevel3DataId='changeLogLevel3DataId';
Modules.CompIds.changeLogLevel4DataId='changeLogLevel4DataId';
Modules.CompIds.changeLogParentGridId='changeLogParentGridId';
Modules.CompIds.changeLogChildGridId='changeLogChildGridId';
/*** END Change Log Screen for Non Ocean ***/

Modules.CompIds.oceanSupplierRateChildGridPodId='oceanSupplierRateChildGridPodId';
Modules.CompIds.editOceanSupplierRatesRetrvGridWinId='editOceanSupplierRatesRetrvGridWinId';

/** Customer Invoice Line Item Status for Ocean*/
Modules.CompIds.oceanCustomerLineItemStatusGridId='oceanCustomerLineItemStatusGridId';
Modules.CompIds.oceanCustomerLineItemStsGridPopForm='oceanCustomerLineItemStsGridPopForm';
Modules.CompIds.oceanCustomerLineItemStatusGridPopupId='oceanCustomerLineItemStatusGridPopupId';
Modules.CompIds.oceanCustomerLineItemStatusFormId='oceanCustomerLineItemStatusFormId';
Modules.CompIds.oceanCustomerInvoiceLineItemAdvContainer='oceanCustomerInvoiceLineItemAdvContainer';

Modules.CompIds.editOceanSupplierRatesChildGridWinId='editOceanSupplierRatesChildGridWinId';
Modules.CompIds.oceanSupplierRateChildGridAddId='oceanSupplierRateChildGridAddId';


Modules.CompIds.oceanCustomerPaymentDetailsFormId='oceanCustomerPaymentDetailsFormId';
Modules.CompIds.oceanCustomerPaymentDetailsAdvContainId='oceanCustomerPaymentDetailsAdvContainId';

Modules.CompIds.oceanCustomerPaymentDetailsParentGridId='oceanCustomrPaymentDetailsPaymentGridId';
Modules.CompIds.oceanCustomerPaymentDetailsChaildGridId='oceanCustomerPaymentDetailsChaildGridId';

/** Journal screen**/
Modules.CompIds.journalTabPanelId='journalParentPanelId',
Modules.CompIds.journalGridId='journalGridId';
Modules.CompIds.journalPopupWinId='journalGridPopupWinId';
Modules.CompIds.journalingFormId='journalingFormId';



/****** ocean supplier rate Query   ***/
Modules.CompIds.oceanSupplierRateQueryPopupWinId  =   'cceanSupplierRateQueryPopUpWinId';
Modules.CompIds.oceanSupplierRateQueryGridPopUpId ='oceanSupplierRateQueryGridPopUpId';
Modules.CompIds.oceanSupplierRateQueryPopupWinFormId = 'oceanSupplierRateQueryPopupWinFormId';


/***Admin Audit Log Screen ***/
Modules.CompIds.auditLogTabPanelId='auditLogParentPanelId';
Modules.CompIds.auditLogQueryGridId='auditLogQueryGridId';
Modules.CompIds.auditLogQueryPopupWinId='auditLogQueryGridPopupWinId';

//For Application Advice On Hold Start..
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormServiceTypeId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormServiceTypeId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormProfitLossId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormProfitLossId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormInvoiceNoId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormInvoiceNoId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormServiceGpCodeId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormServiceGpCodeId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormFreightTermsId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormFreightTermsId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormPOLId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormPOLId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormPODId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormPODId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormVoyageId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormVoyageId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormVesselId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormVesselId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormInvFromDateId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormInvFromDateId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormInvToDateId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormInvToDateId';

Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormChargeCodeId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormChargeCodeId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormDebtorPartyId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormDebtorPartyId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormPartyId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormPartyId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldGenFormPopId = 'oceanCstmrInvcApplicationAdviseOnHoldGenFormPopId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldClearId ='oceanCstmrInvcApplicationAdviseOnHoldClearId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldDeleteId ='oceanCstmrInvcApplicationAdviseOnHoldDeleteId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldPDFId='oceanCstmrInvcApplicationAdviseOnHoldPDFId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldExcelId = 'oceanCstmrInvcApplicationAdviseOnHoldExcelId';
Modules.CompIds.customerInvoiceApplicationAdviceOnHoldGridId ='customerInvoiceApplicationAdviceOnHoldGridId';
Modules.CompIds.oceanCstmrInvcApplicationAdviseOnHoldPopupWinId = 'oceanCstmrInvcApplicationAdviseOnHoldPopupWinId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldBLNumberId='oceanCstmrInvcApplicationAdviseOnHoldBLNumberId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldFreightTermsId='oceanCstmrInvcGenFormFreightTermsId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldPOLId='oceanCstmrInvcGenFormPOLId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldPODId='oceanCstmrInvcGenFormPODId';
Modules.CompIds.customerInvoiceApplicationAdviceOnHold = 'customerInvoiceApplicationAdviceOnHoldTabParentPanelId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldVoyageId='oceanCstmrInvcGenFormVoyageId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldVesselId='oceanCstmrInvcGenFormVesselId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldShippingRefNoId='oceanCstmrInvcGenFormShippingRefNoId';
Modules.CompIds.customerInvoiceApplicationAdviceOnHoldTechnicalDesId = 'customerInvoiceApplicationAdviceOnHoldTabTechnicalDesId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldDueFromDateId='oceanCstmrInvcGenFormDueFromDateId';
Modules.CompIds.oceanCstmrInvcApplicationAdviceOnHoldDueToDateId='oceanCstmrInvcGenFormDueToDateId';
Modules.CompIds.CustomerInvoiceApplicationAdviceOnHoldFormId = 'cusomerInvoiceApplicationAdviceOnHoldFromId';
Modules.CompIds.customerInvoiceApplicationAdviceOnHoldContainer ='cusomerInvoiceApplicationAdviceOnHoldContainer';
//For Application Advice On Hold End..



//For Internal Admin Database Error Log start.
Modules.CompIds.internalAdminDatabaseErrorLogUserNameId ='userNameId';
Modules.CompIds.internalAdminDatabaseErrorLogFormId = 'internalAdminDatabaseErrorLogFormId';
Modules.CompIds.internalAdminDatabaseErrorLogGridId = 'internalAdminDatabaseErrorLogGridId';

//For Internal Admin Database Error Log end.


/**********************Starting Id's For Supplier Invoice Status  FOr Ocean**************/
Modules.CompIds.supplierInvcStsOceanTabParentPanelId			=		'supplierInvcStsOceanTabParentPanelId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormId		=		'supplierInvcStsOceanTabParentPanelFormId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormClearId	=		'supplierInvcStsOceanTabParentPanelFormClearId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormRtrveId	=		'supplierInvcStsOceanTabParentPanelFormRtrveId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPrintId	=		'supplierInvcStsOceanTabParentPanelFormPrintId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormCmpnyId	=		'supplierInvcStsOceanTabParentPanelFormCmpnyId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormCstmrId	=		'supplierInvcStsOceanTabParentPanelFormCstmrId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormDbtrPtyId	=		'supplierInvcStsOceanTabParentPanelFormDbtrPtyId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormInvcNoId	=		'supplierInvcStsOceanTabParentPanelFormInvcNoId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPrfTLosId	=		'supplierInvcStsOceanTabParentPanelFormPrfTLosId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormFromDtId	=		'supplierInvcStsOceanTabParentPanelFormFromDtId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormToDtId	=		'supplierInvcStsOceanTabParentPanelFormToDtId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPrfrmaId	=		'supplierInvcStsOceanTabParentPanelFormPrfrmaId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormRjctedId	=		'supplierInvcStsOceanTabParentPanelFormRjctedId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormFinalId	=		'supplierInvcStsOceanTabParentPanelFormFinalId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPaidId	=		'supplierInvcStsOceanTabParentPanelFormPaidId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormViewId	=		'supplierInvcStsOceanTabParentPanelFormViewId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormInvcId	=		'supplierInvcStsOceanTabParentPanelFormInvcId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormInvcPrntId	=	'supplierInvcStsOceanTabParentPanelFormInvcPrntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormBckUpPrntId	=	'supplierInvcStsOceanTabParentPanelFormBckUpPrntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormInvcCpiesId	=	'supplierInvcStsOceanTabParentPanelFormInvcCpiesId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormEmailId		=	'supplierInvcStsOceanTabParentPanelFormEmailId';	
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPrintRadioId	=	'supplierInvcStsOceanTabParentPanelFormPrintRadioId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormBackUpId		=	'supplierInvcStsOceanTabParentPanelFormBackUpId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormBackUpCpsId	=	'supplierInvcStsOceanTabParentPanelFormBackUpCpsId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormCcMailIdId	=	'supplierInvcStsOceanTabParentPanelFormCcMailIdId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormActualId		=	'supplierInvcStsOceanTabParentPanelFormActualId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormAccuralId		=	'supplierInvcStsOceanTabParentPanelFormAccuralId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormInvcChkId		=	'supplierInvcStsOceanTabParentPanelFormInvcChkId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormCreditId		=	'supplierInvcStsOceanTabParentPanelFormCreditId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormDebitId		=	'supplierInvcStsOceanTabParentPanelFormDebitId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormPdfId			=	'supplierInvcStsOceanTabParentPanelFormPdfId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormExcelId		=	'supplierInvcStsOceanTabParentPanelFormExcelId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormAscndingId	=	'supplierInvcStsOceanTabParentPanelFormAscndingId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormDscndingId	=	'supplierInvcStsOceanTabParentPanelFormDscndingId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridId			=	'supplierInvcStsOceanTabParentPanelGridId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinPtyId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinPtyId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcNoId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcNoId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinDcTpeId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinDcTpeId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcTpeId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcTpeId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinMnfstCrncyId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinMnfstCrncyId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinMnfstAmntId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinMnfstAmntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcCrncyId	=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcCrncyId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcAmntId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcAmntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinUsdAmntId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinUsdAmntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinPaidAmntId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinPaidAmntId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcDtId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcDtId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinDueDtId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinDueDtId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinLstPayDtId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinLstPayDtId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrWinInvcStsId		=	'supplierInvcStsOceanTabParentPanelGridEdtrWinInvcStsId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelGridEdtrFormId			=	'supplierInvcStsOceanTabParentPanelGridEdtrFormId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormBLNumberId			=	'supplierInvcStsOceanTabParentPanelFormBLNumberId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormVoyageId			=	'supplierInvcStsOceanTabParentPanelFormVoyageId';
Modules.CompIds.supplierInvcStsOceanTabParentPanelFormVesselId			=	'supplierInvcStsOceanTabParentPanelFormVesselId';

/**********************Ending Id's For Supplier Invoice Status  FOr Ocean**************/

Modules.CompIds.oceansupplierComboSupplierInvoiceId = 'SupplierInvoiceOceanStatusId';
Modules.CompIds.oceandbtrPartyComboSupplierInvoiceId = 'dbtrPartySupplierInvoiceOceanId';
Modules.CompIds.oceanSupplierInvoiceFrmDateId = 'SupplierInvoiceOceanFrmDateId';
Modules.CompIds.oceanSupplierInvoiceToDateId = 'SupplierInvoiceOceanToDateId';
Modules.CompIds.oceanSupplierInvoiceActualId = 'SupplierInvoiceOceanActualId';
Modules.CompIds.oceanSupplierInvoiceAccuralId = 'SupplierInvoiceOceanAccuralId';
Modules.CompIds.oceanSupplierInvoiceProformaId = 'SupplierInvoiceOceanProformaId';
Modules.CompIds.oceanSupplierInvoiceRejectedId = 'SupplierInvoiceOceanRejectedId';
Modules.CompIds.oceanSupplierInvoiceFinalId = 'SupplierInvoiceOceanFinalId';
Modules.CompIds.oceanSupplierInvoicePaidId = 'SupplierInvoiceOceanPaidId';
Modules.CompIds.oceanSupplierInvoiceCreditId = 'SupplierInvoiceOceanCreditId';
Modules.CompIds.oceanSupplierInvoiceDebitId = 'SupplierInvoiceOceanDebitId';
Modules.CompIds.oceanSupplierInvoiceStatusGridId = 'SupplierInvoiceOceanStatusGridId';
Modules.CompIds.oceanSupplierInvoiceNoComboId = 'InvoiceOceanNoId';
Modules.CompIds.oceandbtrComboSupplierInvoiceId = 'dbtrComboSupplierInvoiceOceanId';
Modules.CompIds.oceanSupplierInvoiceStatusPopupWinId = 'SupplierInvoiceOceanStatusPopupWinId';
Modules.CompIds.oceanpopupSupplierInvoiceStatusId = 'popupSupplierInvoiceOceanStatusId';
Modules.CompIds.oceanSupplierInvoiceStatusPrintPopupWinId = 'SupplierInvoiceOceanStatusPrintPopupWinId';
Modules.CompIds.oceanpopupSupplierInvoiceStatusPrintId = 'popupSupplierInvoiceOceanStatusPrintId';
Modules.CompIds.oceanSupplierInvoiceBackUpFlgId= 'SupplierInvoiceOceanBackUpFlgId';
Modules.CompIds.oceanSupplierInvoiceFlgId= 'SupplierInvoiceOceanFlgId';
Modules.CompIds.oceanSupplierviewPrintId='viewSupplierPrintOceanId';
Modules.CompIds.oceanSupplieremailPrintId='emailSupplierPrintOceanId';
Modules.CompIds.oceanSupplierPrintId='SupplierPrintId';
Modules.CompIds.oceanSupplierInvoicePrinterCd = 'SupplierInvoiceOceanPrinterCd';
Modules.CompIds.oceanSupplierBackUpPrinterCd = 'SupplierBackUpPrinterCdOceanId';
Modules.CompIds.oceanSupplierInvoiceCopiesId = 'SupplierInvoiceOceanCopiesId';
Modules.CompIds.oceanSupplierInvoiceBackUpCopiesId = 'SupplierInvoiceOceanBackUpCopiesId';
Modules.CompIds.oceanSupplierInvoiceCCMailId = 'SupplierInvoiceOceanCCMailId';
Modules.CompIds.oceanSupplierInvoiceSummaryFormId='SupplierInvoiceOceanSummaryFormId';

Modules.CompIds.oceanSupplierInvoiceStsPopUpWinFormId					= 'oceanSupplierInvoiceStsPopUpWinFormId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinSpplrId					= 'oceanSupplierInvoiceStsPopUpWinSpplrId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinInvcNoId					= 'oceanSupplierInvoiceStsPopUpWinInvcNoId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinInvcDtId					= 'oceanSupplierInvoiceStsPopUpWinInvcDtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinDocTypeId					= 'oceanSupplierInvoiceStsPopUpWinDocTypeId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinInvcAmtId					= 'oceanSupplierInvoiceStsPopUpWinInvcAmtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinApprvdAmtId				= 'oceanSupplierInvoiceStsPopUpWinApprvdAmtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinPaidAmtId		    		= 'oceanSupplierInvoiceStsPopUpWinPaidAmtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinCurrencyId		    	= 'oceanSupplierInvoiceStsPopUpWinCurrencyId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinDueDtId		        	= 'oceanSupplierInvoiceStsPopUpWinDueDtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinLstPmtAmtId		    	= 'oceanSupplierInvoiceStsPopUpWinLstPmtAmtId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinInvcStsId		        	= 'oceanSupplierInvoiceStsPopUpWinInvcStsId';
Modules.CompIds.oceanSupplierInvoiceStsPopUpWinObjId				    	= 'oceanSupplierInvoiceStsPopUpWinObjId';


Modules.CompIds.oceanSupplierRateVerificationFormId='oceanSupplierRateVerificationFormId';
Modules.CompIds.SupplierMasterCntryId='SupplierMasterCntryId';
Modules.CompIds.SupplierMasterCntryGridId='SupplierMasterCntryGridId';
Modules.CompIds.oceanSupplierPrintTemplateGridId = 'oceanCstmrMstrPrintTmpltGridId';
Modules.CompIds.addOceanPrintTemplateRecordId = 'addOceanPrintTemplateRecordId';


Modules.CompIds.oceanSupplierMstrSupplierLOVId = 'oceanSupplierMstrSupplierLOVId';
Modules.CompIds.oceanSupplierMasterGridId='oceanSupplierMasterGridId';
Modules.CompIds.paymentDetailsSOceanupplierMasterGridId='paymentDetailsSOceanupplierMasterGridId';
Modules.CompIds.statusDateOceanSupplierMasterGridId = 'statusDateOceanSupplierMasterGridId';
Modules.CompIds.oceanSupplrMstrAutomaticInvSetupGridId = 'oceanSupplrMstrAutomaticInvSetupGridId';
Modules.CompIds.deleteOceanPrintTmpltRecordId = 'deleteOceanPrintTmpltRecordId';



Modules.CompIds.oceanSupplierRateQueryGridPopUpId ='oceanSupplierRateQueryGridPopUpId';
Modules.CompIds.supplierInvoiceOceanStsRdyForRcnltnId 			    	= 'supplierInvoiceOceanStsRdyForRcnltnId';
Modules.CompIds.supplierInvoiceOceanStsUndrInvgtId 		     	    	= 'supplierInvoiceOceanStsUndrInvgtId';
Modules.CompIds.supplierInvoiceOceanStsApprvdId				        	= 'supplierInvoiceOceanStsApprvdId';


Modules.CompIds.internalAdminDatabaseErrorLogClearActionId = 'internalAdminDatabaseErrorLogRetrieveId';
Modules.CompIds.internalAdminDatabaseErrorLogRertrieveActionId = 'internalAdminDatabaseErrorLogRertrieveActionId';
Modules.CompIds.internalAdminDatabaseErrorLogHostNameId = 'internalAdminDatabaseErrorLogHostNameId';
Modules.CompIds.internalAdminDatabaseErrorLogErrFnDesId = 'internalAdminDatabaseErrorLogErrFnDesId';
Modules.CompIds.internalAdminDatabaseErrorLogErroLogDateId = 'internalAdminDatabaseErrorLogErrLogDateId';
Modules.CompIds.internalAdminDatabaseErrLogExcelReportId ='internalAdminDatabaseErrLogExcelReportId';
Modules.CompIds.internalAdminDatabaseErrLogPDFReportId ='internalAdminDatabaseErrLogPDFReportId';
Modules.CompIds.internalAdminDatabaseErrLogPanelId ='internalAdminDatabaseErrorLogTabPanelId';





/**
 * 
 *  START Admin Module : Group User Security screen
 */

Modules.CompIds.groupUserExchangeRightGridId='groupUserExchangeRightGridId';
Modules.CompIds.groupUserExchangerPanelId='groupUserExchangerPanelId';
Modules.CompIds.groupFunctionExchangerPanelId='groupFunctionExchangerPanelId';
Modules.CompIds.groupFunctionExchangeRightGridId='groupFunctionExchangeRightGridId';
Modules.CompIds.groupFunctionTreeGridId='groupFunctionTreeGridId';
Modules.CompIds.groupWindowId='groupWindowId';
Modules.CompIds.adminGroupGridId='adminGroupGridId';
Modules.CompIds.functionWindowId='functionWindowId';
Modules.CompIds.deniedMenuGridId='deniedMenuGridId';

//Modules.CompIds.managegrouptabpanelId ='ManageGrouptabpanelId';


/**
 * 
 *  END Admin Module : Group User Security screen
 * 
 */




/******************Ocean Customer Rate Query Service Group *************/
Modules.CompIds.oceanCustomerRateQueryServiceCodeTabPanelId = 'oceanCustomerRateQueryServiceCodeTabPanelId';
Modules.CompIds.oceanCustomerRateQueryServiceGridId = 'oceanCustomerRateQueryServiceGridId';
Modules.CompIds.oceanCustomerRateQueryServiceGridPopupFormId = 'oceanCustomerRateQueryServiceGridPopupFormId';



/** Ocean Journal screen**/
Modules.CompIds.ocean_journalTabPanelId='oceanJournalParentPanelId',
Modules.CompIds.ocean_journalGridId='oceanJournalGridId';
Modules.CompIds.ocean_journalPopupWinId='oceanJournalGridPopupWinId';
/***Ocean Supplier Automatic Invoice  Status***/
Modules.CompIds.oceanSupplierAutomaticInvoiceFormId= 'oceanSupplierAutomaticInvoiceFormId';
Modules.CompIds.supplierAutomaticInvcOceanTabParentPanelId='supplierAutomaticoInvoiceOceanTabParentPanelId';
Modules.CompIds.oceanSupplierAutomaticInvoiceCompanyId='oceanSupplierAutomaticInvoiceCompanyId';
Modules.CompIds.oceanSupplierAutomaticInvoiceCompanyNameId='oceanSupplierAutomaticInvoiceCompanyNameId';

Modules.CompIds.oceanSupplierAutomaticInvoiceGenerationFrequencyId= 'oceanSupplierAutomaticInvoiceGenerationFrequencyId';
Modules.CompIds.oceanSupplierAutomaticInvoiceGenerationTimeId= 'oceanSupplierAutomaticInvoiceGenerationTimeId';
Modules.CompIds.oceanSupplierAutomaticInvoiceIntervelId = 'oceanSupplierAutomaticInvoiceIntervelId';
Modules.CompIds.oceanSupplierAutomaticInvoiceChargCodeId= 'oceanSupplierAutomaticInvoiceChargCodeId';
Modules.CompIds.oceanSupplierAutomaticInvoiceVoyageId= 'oceanSupplierAutomaticInvoiceVoyageId';
Modules.CompIds.oceanSupplierAutomaticInvoiceCurrencyId	= 'oceanSupplierAutomaticInvoiceCurrencyId';
Modules.CompIds.oceanSupplierAutomaticInvoicePOLCodeId= 'oceanSupplierAutomaticInvoicePOLCodeId';
Modules.CompIds.oceanSupplierAutomaticInvoicePODCodeId= 'oceanSupplierAutomaticInvoicePODCodeId';
Modules.CompIds.oceanSupplierAutomaticInvoiceBLNumId= 'oceanSupplierAutomaticInvoiceBLNumId';
Modules.CompIds.oceanSupplierAutomaticInvoiceSupplierCodeId	= 'oceanSupplierAutomaticInvoiceSupplierCodeId';
Modules.CompIds.oceanSupplierAutomaticInvoiceVesselCodeId= 'oceanSupplierAutomaticInvoiceVesselCodeId';


/************************************* Ocean Customer Reconciliation *************************************/
Modules.CompIds.oceanCustomerReconciliationTabParentId = 'oceanCustomerReconciliationTabParentId';
Modules.CompIds.oceanCustomerReconciliationFormId = 'oceanCustomerReconciliationFormId';
Modules.CompIds.oceanCustomerReconAdvContainer = 'oceanCustomerReconAdvContainer';
Modules.CompIds.oceanCustomerReconFormFreightTrmsId = 'oceanCustomerReconFormFreightTrmsId';
Modules.CompIds.oceanCustomerReconFormSailingFmDtId = 'oceanCustomerReconFormSailingFmDtId';
Modules.CompIds.oceanCustomerReconFormSailingToDtId = 'oceanCustomerReconFormSailingToDtId';
Modules.CompIds.oceanCustomerReconFormBLCmpltFmDtId = 'oceanCustomerReconFormBLCmpltFmDtId';
Modules.CompIds.oceanCustomerReconFormBLCmpltToDtId = 'oceanCustomerReconFormBLCmpltToDtId';
Modules.CompIds.oceanCustomerReconFormPopId = 'oceanCustomerReconFormPopId';
Modules.CompIds.oceanCustomerReconFormPopDescId = 'oceanCustomerReconFormPopDescId';
Modules.CompIds.oceanCustomerReconReGenerateBtnId = 'oceanCustomerReconReGenerateBtnId';
Modules.CompIds.oceanCustomerReconNotChrgableBtnId = 'oceanCustomerReconNotChrgableBtnId';
Modules.CompIds.oceanCustomerReconReOpenBtnId = 'oceanCustomerReconReOpenBtnId';
Modules.CompIds.oceanCustomerReconPopUpWindowId = 'oceanCustomerReconPopUpWindowId';


/***Ocean Customer Invoice Entry Consolidation Screen ***/

Modules.CompIds.oceanCstmrInvEntryConsolTabPanelId = 'oceanCstmrInvEntryConsolTabPanelId';
Modules.CompIds.ocnCstmrInvEntryConsolFormCmpCodeId ='ocnCstmrInvEntryConsolFormCmpCodeId';
Modules.CompIds.ocnCstmrInvEntryConsolFormCmpNameId ='ocnCstmrInvEntryConsolFormCmpNameId';


//For Ocean Supplier Line Item Status
Modules.CompIds.oceanSupplierLineItemStsPrfmaId = 'oceanSupplierLineItemStsPrfmaId';
Modules.CompIds.oceanSupplierLineItemStsRdyForRcnltnId 	= 'oceanSupplierLineItemStsRdyForRcnltnId';
Modules.CompIds.oceanSupplierLineItemStsUndrInvgtId = 'oceanSupplierLineItemStsUndrInvgtId';
Modules.CompIds.oceanSupplierLineItemStsrcncldId = "oceanSupplierLineItemStsrcncldId";
Modules.CompIds.oceanSupplierLineItemStsApprvdId = 'oceanSupplierLineItemStsApprvdId';
Modules.CompIds.oceanSupplierLineItemStsRjctdId	= 'oceanSupplierLineItemStsRjctdId';
Modules.CompIds.oceanSupplierLineItemStsPaidId	= 'oceanSupplierLineItemStsPaidId';
Modules.CompIds.oceanSupplierLineItemStatusTabParentId = 'oceanSupplierLineItemStatusTabParentId';
Modules.CompIds.oceanSupplierLineItemStatusFormId = 'oceanSupplierLineItemStatusFormId';
Modules.CompIds.oceanSupplierLineItemStatusGridId = 'oceanSupplierLineItemStatusGridID';

Modules.CompIds.eventRatingQuerylLneNumberId='eventRatingQuerylLneNumberId';
Modules.CompIds.OceanGenaralVoyageMasterTabParentpanelId='OceanGenaralVoyageMasterTabParentpanelId';
Modules.CompIds.OceanGenaralVoyageMasterTabpanelId='OceanGenaralVoyageMasterTabpanelId';

/****************************************************************************************************
*			Start :	Ocean Supplier Reconcilation Setup
*****************************************************************************************************/
Modules.CompIds.oceanSupplierReconcilationSetupTabPanelId	=	'oceanSupplierReconcilationSetupTabPanelId';
Modules.CompIds.oceanSupplierReconcilationSetupFormId	=	'oceanSupplierReconcilationSetupFormId';
Modules.CompIds.oceanSupplierReconcilationSetupSupplierCdId	=	'oceanSupplierReconcilationSetupSupplierCdId';
Modules.CompIds.oceanSupplierReconcilationSetupSupplierNmId	=	'oceanSupplierReconcilationSetupSupplierNmId';
Modules.CompIds.oceanSupplierReconcilationsetupMatchnTolerancePanelId	=	'oceanSupplierReconcilationsetupMatchnTolerancePanelId';
Modules.CompIds.supplierReconcilationSetupMatchingGridId	=	'oceanSupplierReconcilationSetupMatchingGridId';
Modules.CompIds.supplierReconcilationSetupToleranceGridId	=	'supplierReconcilationSetupToleranceGridId';
Modules.CompIds.oceanSupplierReconcilSetupMatchingCriteriaGridDltsPanelId	=	'oceanSupplierReconcilSetupMatchingCriteriaGridDltsPanelId';
Modules.CompIds.oceanSupplierReconcilSetupMatchingCriteriaDtlsGridId	=	'oceanSupplierReconcilSetupMatchingCriteriaDtlsGridId';
Modules.CompIds.addOceanSupplierReconcilSetupMatchingCriteriaDtlsGridId='addOceanSupplierReconcilSetupMatchingCriteriaDtlsGridId';
Modules.CompIds.delOceanSupplierReconcilSetupMatchingCriteriaDtlsGridId='delOceanSupplierReconcilSetupMatchingCriteriaDtlsGridId';
Modules.CompIds.addSupplierReconcilationSetupMatchingGridId='addSupplierReconcilationSetupMatchingGridId';
Modules.CompIds.addSupplierReconcilationSetupToleranceGridId='addSupplierReconcilationSetupToleranceGridId';
Modules.CompIds.matchingCriteriaGridDtlsPopUpWinFormId='matchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.blNoExactMatchingCriteriaGridDtlsPopUpWinFormId='blNoExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.voyageExactMatchingCriteriaGridDtlsPopUpWinFormId='voyageExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.vslCdExactMatchingCriteriaGridDtlsPopUpWinFormId='vslCdExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.polExactMatchingCriteriaGridDtlsPopUpWinFormId='polExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.podExactMatchingCriteriaGridDtlsPopUpWinFormId='podExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.cargoTypeExactMatchingCriteriaGridDtlsPopUpWinFormId='cargoTypeExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.cargoClssExactMatchingCriteriaGridDtlsPopUpWinFormId='cargoClssExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.plCenterExactMatchingCriteriaGridDtlsPopUpWinFormId='plCenterExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.modelExactMatchingCriteriaGridDtlsPopUpWinFormId='modelExactMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.priorityMatchingCriteriaGridDtlsPopUpWinFormId='priorityMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.blNoMinMatchingCriteriaGridDtlsPopUpWinFormId='blNoMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.voyageMinMatchingCriteriaGridDtlsPopUpWinFormId='voyageMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.vslCdMinMatchingCriteriaGridDtlsPopUpWinFormId='vslCdMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.polMinMatchingCriteriaGridDtlsPopUpWinFormId='polMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.podMinMatchingCriteriaGridDtlsPopUpWinFormId='podMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.cargoTypeMinMatchingCriteriaGridDtlsPopUpWinFormId='cargoTypeMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.cargoClssMinMatchingCriteriaGridDtlsPopUpWinFormId='cargoClssMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.plCenterMinMatchingCriteriaGridDtlsPopUpWinFormId='plCenterMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.modelMinMatchingCriteriaGridDtlsPopUpWinFormId='modelMinMatchingCriteriaGridDtlsPopUpWinFormId';
Modules.CompIds.matchingCriteriaGridDtlsGridPopUpWinId='matchingCriteriaGridDtlsGridPopUpWinId';
Modules.CompIds.matchingCriteriaGridPopUpWinId='matchingCriteriaGridPopUpWinId';
Modules.CompIds.toleranceCriteriaGridPopUpWinFormId='toleranceCriteriaGridPopUpWinFormId';
Modules.CompIds.currencyCdToleranceCriteriaGridPopUpWinFormId='currencyCdToleranceCriteriaGridPopUpWinFormId';
Modules.CompIds.fmRangeToleranceCriteriaGridPopUpWinFormId='fmRangeToleranceCriteriaGridPopUpWinFormId';
Modules.CompIds.toRangeToleranceCriteriaGridPopUpWinFormId='toRangeToleranceCriteriaGridPopUpWinFormId';
Modules.CompIds.toleranceCriteriaGridPopUpWinId='toleranceCriteriaGridPopUpWinId';
/****************************************************************************************************
*			End :	Ocean Supplier Reconcilation Setup
*****************************************************************************************************/
Modules.CompIds.vndrInvcTempltTabPanelId='vndrInvcTempltTabPanelId';
Modules.CompIds.vndrInvcTempltGPGridId='vndrInvcTempltGPGridId';

Modules.CompIds.OceanCompanyMastertabparentpanelID='OceangeneralMasterscompanyMasterTabParentPanelId';

Modules.CompIds.oceanSupplierRateFormValidToDateFormId='oceanSupplierRateFormValidToDateFormId';
Modules.CompIds.oceanSupplierRateFormValidFromDateFormId='oceanSupplierRateFormValidFromDateFormId';
Modules.CompIds.CompanyMastertabparentpanelID='companyMasterTabParentPanelId';
Modules.CompIds.TariffMastertabparentpanelID='tariffMasterTabParentPanelId';


Modules.CompIds.ocnAccPayTotalInvcAmtCurrId = 'ocnAccPayTotalInvcAmtCurrId';
Modules.CompIds.ocnCstmrNmAccPayId          = 'ocnCstmrNmAccPayId';

Modules.CompIds.oceanSuplierRateschildGridFormId='oceanSuplierRateschildGridFormId';
Modules.CompIds.oceanSupplierRateFormRetrveBtnId='oceanSupplierRateFormRetrveBtnId';


Modules.CompIds.applicationAdviceOnHold = 'applicationAdviceOnHold';



/********************************START :Non-Ocean Supplier Reconcilation**************************/
Modules.CompIds.suplierInvoice.supplierReconciliationParentTabId='supplierReconciliationParentTabId';	
Modules.CompIds.suplierInvoice.supplierReconciliationFormId='supplierReconciliationFormId';
Modules.CompIds.suplierInvoice.supplierReconciliationClearBtnId='supplierReconciliationClearBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationRetrieveBtnId='supplierReconciliationRetrieveBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationAdvncSrchContainerId='supplierReconciliationAdvncSrchContainerId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormSuppLOVId='supplierReconciliationFormSuppLOVId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormSuppNameId='supplierReconciliationFormSuppNameId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormOriginId='supplierReconciliationFormOriginId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormDestinationId='supplierReconciliationFormDestinationId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormUnitId='supplierReconciliationFormUnitId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormCoveyanceId='supplierReconciliationFormCoveyanceId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormModelId='supplierReconciliationFormModelId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormDueFmDateId='supplierReconciliationFormDueFmDateId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormDueToDateId='supplierReconciliationFormDueToDateId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormMismatchReasonId='supplierReconciliationFormMismatchReasonId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormSrvcTypeId='supplierReconciliationFormSrvcTypeId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormSrvcCodeId='supplierReconciliationFormSrvcCodeId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormLoadRefNoId='supplierReconciliationFormLoadRefNoId';

Modules.CompIds.suplierInvoice.supplierReconciliationFormReadyForReconId='supplierReconciliationFormReadyForReconId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormRejectedId='supplierReconciliationFormRejectedId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormAprvdId='supplierReconciliationFormAprvdId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormUndrInvstId='supplierReconciliationFormUndrInvstId';
Modules.CompIds.suplierInvoice.supplierReconciliationFormReconciledId='supplierReconciliationFormReconciledId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridId='supplierReconciliationGridId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridReconcileBtnId='supplierReconciliationGridReconcileBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationDetailsBtnGridId='supplierReconciliationDetailsBtnGridId';

Modules.CompIds.suplierInvoice.supplierReconciliationGridReconcileBtnId='supplierReconciliationGridReconcileBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridRcnclWithEvntBtnId='supplierReconciliationGridRcnclWithEvntBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridRcnclWithSuppBtnId='supplierReconciliationGridRcnclWithSuppBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridRejctBtnId='supplierReconciliationGridRejctBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridAcceptBtnId='supplierReconciliationGridAcceptBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridSaveBtnId='supplierReconciliationGridSaveBtnId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridMakeLOVId='supplierReconciliationGridMakeLOVId';
Modules.CompIds.suplierInvoice.supplierReconciliationGridModelLOVId='supplierReconciliationGridModelLOVId';

Modules.CompIds.suplierInvoice.supplierReconciliationDtlsWinId='supplierReconciliationDtlsWinId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormId='supplierReconciliationDtlsFormId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormUnitId='supplierReconciliationDtlsFormUnitId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormOriginLocId='supplierReconciliationDtlsFormOriginLocId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormDestinatinId='supplierReconciliationDtlsFormDestinatinId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormEvntLdRefId='supplierReconciliationDtlsFormEvntLdRefId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormConveyanceId='supplierReconciliationDtlsFormConveyanceId';
Modules.CompIds.suplierInvoice.supplierReconciliationDtlsFormUnitId='supplierReconciliationDtlsFormUnitId';


/********************************END :Non-Ocean Supplier Reconcilation*****************************/

/****************************************************************************************************
*			 Supplier Rates
*****************************************************************************************************/

Modules.CompIds.supplierRatesFormId='supplierRatesFormId';
Modules.CompIds.supplierRatesFormRetrveBtnId='supplierRatesFormRetrveBtnId';
Modules.CompIds.supplierRateFormSupplierId='supplierRateFormSupplierId';
Modules.CompIds.supplierRatesFormSupplierNameId='supplierRatesFormSupplierNameId';
Modules.CompIds.supplierRatesFormValidFromDateId='supplierRatesFormValidFromDateId';
Modules.CompIds.supplierRatesFormValidFromDateFormId='supplierRatesFormValidFromDateFormId';
Modules.CompIds.supplierRatesFormValidToDateId='supplierRatesFormValidToDateId';
Modules.CompIds.supplierRatesFormValidToDateFormId='supplierRatesFormValidToDateFormId';
Modules.CompIds.supplierRatesFormContractId='supplierRatesFormContractId';
Modules.CompIds.supplierRatesContractGridId='supplierRatesContractGridId';
Modules.CompIds.supplierRateChildGridId='supplierRateChildGridId';
Modules.CompIds.supplierRatesContractGridContractId='supplierRatesContractGridContractId';
Modules.CompIds.supplierRatesContractGridSupplierCode='supplierRatesContractGridSupplierCode';
Modules.CompIds.supplierRatesContractGridSupplierName='supplierRatesContractGridSupplierName';
Modules.CompIds.supplierRatesContractGridValidFrmDtId='supplierRatesContractGridValidFrmDtId';
Modules.CompIds.supplierRatesContractGridValidToDtId='supplierRatesContractGridValidToDtId';
Modules.CompIds.supplierRatesContractGridRemarkId='supplierRatesContractGridRemarkId';
Modules.CompIds.supplierRatesContractGridSrvlevValidDtsId='supplierRatesContractGridSrvlevValidDtsId';
Modules.CompIds.supplierRatesContractGridCnsolidtdFulSurCrgId='supplierRatesContractGridCnsolidtdFulSurCrgId';
Modules.CompIds.supplierRateFuelSurChrgGridId='supplierRateFuelSurChrgGridId';
Modules.CompIds.supplierRatesFuelSrChrgGridAddId='supplierRatesFuelSrChrgGridAddId';
Modules.CompIds.supplierRatesFuelSrChrgGridSrvCodeId='supplierRatesFuelSrChrgGridSrvCodeId';
Modules.CompIds.supplierRatesFuelSrChrgGridCstmrId='supplierRatesFuelSrChrgGridCstmrId';
Modules.CompIds.supplierRatesFuelSrChrgGridValidFrmDtId='supplierRatesFuelSrChrgGridValidFrmDtId';
Modules.CompIds.supplierRatesFuelSrChrgGridValidToDtId='supplierRatesFuelSrChrgGridValidToDtId';
Modules.CompIds.supplierRatesFuelSrChrgGridOrginId='supplierRatesFuelSrChrgGridOrginId';
Modules.CompIds.supplierRatesFuelSrChrgGridDestinatnId='supplierRatesFuelSrChrgGridDestinatnId';
Modules.CompIds.supplierRatesFuelSrChrgGridOrgCityId='supplierRatesFuelSrChrgGridOrgCityId';
Modules.CompIds.supplierRatesFuelSrChrgGridOrgStateId='supplierRatesFuelSrChrgGridOrgStateId';
Modules.CompIds.supplierRatesFuelSrChrgGridOrgCntryId='supplierRatesFuelSrChrgGridOrgCntryId';
Modules.CompIds.supplierRatesFuelSrChrgGridDestId='supplierRatesFuelSrChrgGridDestId';
Modules.CompIds.supplierRatesFuelSrChrgGridDestStateId='supplierRatesFuelSrChrgGridDestStateId';
Modules.CompIds.supplierRatesFuelSrChrgGridDestCntryId='supplierRatesFuelSrChrgGridDestCntryId';
Modules.CompIds.supplierRatesFuelSrChrgGridModelGrpId='supplierRatesFuelSrChrgGridModelGrpId';
Modules.CompIds.supplierRatesFuelSrChrgGridConsoldtionTypeId='supplierRatesFuelSrChrgGridConsoldtionTypeId';
Modules.CompIds.supplierRatesFuelSrChrgGridNotChargbleId='supplierRatesFuelSrChrgGridNotChargbleId';
Modules.CompIds.supplierRatesFuelSrChrgGridnotTaxbleId='supplierRatesFuelSrChrgGridnotTaxbleId';
Modules.CompIds.supplierRatesFuelSrChrgGridPrgrmId='supplierRatesFuelSrChrgGridPrgrmId';
Modules.CompIds.supplierRatesFuelSrChrgGridindexId='supplierRatesFuelSrChrgGridindexId';
Modules.CompIds.supplierRatesFuelSrChrgGridEventDateId='supplierRatesFuelSrChrgGridEventDateId';
Modules.CompIds.supplierRatesFuelSrChrgGridProirityId='supplierRatesFuelSrChrgGridProirityId';
Modules.CompIds.supplierRatesFuelSrChrgGridSeqNoId='supplierRatesFuelSrChrgGridSeqNoId';
Modules.CompIds.suplierRateschildFormId='suplierRateschildFormId';
Modules.CompIds.suplierRateschildFormFilterId='suplierRateschildFormFilterId';
Modules.CompIds.supplierRatesChildGridAddId='supplierRatesChildGridAddId';
Modules.CompIds.supplierRatesChildGridSeqNoId='supplierRatesChildGridSeqNoId';
Modules.CompIds.supplierRatesChildGridPriorityId='supplierRatesChildGridPriorityId';
Modules.CompIds.supplierRatesChildGridNotTaxableId='supplierRatesChildGridNotTaxableId';
Modules.CompIds.supplierRatesChildGridCompositeId='supplierRatesChildGridCompositeId';
Modules.CompIds.supplierRatesChildGridTarffCrncyCdId='supplierRatesChildGridTarffCrncyCdId';
Modules.CompIds.supplierRatesChildGridLuIndId='supplierRatesChildGridLuIndId';
Modules.CompIds.supplierRatesChildGridTariffUnitRateId='supplierRatesChildGridTariffUnitRateId';
Modules.CompIds.supplierRatesChildGridTariffCdId='supplierRatesChildGridTariffCdId';
Modules.CompIds.supplierRatesChildGridFixedRateId='supplierRatesChildGridFixedRateId';
Modules.CompIds.supplierRatesChildGridUomId='supplierRatesChildGridUomId';
Modules.CompIds.supplierRatesChildGridFacorRateId='supplierRatesChildGridFacorRateId';
Modules.CompIds.supplierRatesChildGridFacorTypeId='supplierRatesChildGridFacorTypeId';
Modules.CompIds.supplierRatesChildGridFacorValueId='supplierRatesChildGridFacorValueId';
Modules.CompIds.supplierRatesChildGridNotChrgId='supplierRatesChildGridNotChrgId';
Modules.CompIds.supplierRatesChildGridConsoldtnTypeId='supplierRatesChildGridConsoldtnTypeId';
Modules.CompIds.supplierRatesChildGridFinalDestId='supplierRatesChildGridFinalDestId';
Modules.CompIds.supplierRatesChildGridOriginalOrgId='supplierRatesChildGridOriginalOrgId';
Modules.CompIds.supplierRatesChildGridDestCntryId='supplierRatesChildGridDestCntryId';
Modules.CompIds.supplierRatesChildGridDestStateId='supplierRatesChildGridDestStateId';
Modules.CompIds.supplierRatesChildGridDestCityId='supplierRatesChildGridDestCityId';
Modules.CompIds.supplierRatesChildGridOrgCntryId='supplierRatesChildGridOrgCntryId';
Modules.CompIds.supplierRatesChildGridOrgStateId='supplierRatesChildGridOrgStateId';
Modules.CompIds.supplierRatesChildGridOrgCityId='supplierRatesChildGridOrgCityId';
Modules.CompIds.supplierRatesChildGridDestId='supplierRatesChildGridDestId';
Modules.CompIds.supplierRatesChildGridPartId='supplierRatesChildGridPartId';
Modules.CompIds.supplierRatesChildGridModelgrpId='supplierRatesChildGridModelgrpId';
Modules.CompIds.supplierRatesChildGridModelYrId='supplierRatesChildGridModelYrId';
Modules.CompIds.supplierRatesChildGridModelCdId='supplierRatesChildGridModelCdId';
Modules.CompIds.supplierRatesChildGridMakeCdId='supplierRatesChildGridMakeCdId';
Modules.CompIds.supplierRatesChildGridCnvynceTypeId='supplierRatesChildGridCnvynceTypeId';
Modules.CompIds.supplierRatesChildGridOrginId='supplierRatesChildGridOrginId';
Modules.CompIds.supplierRatesChildGridRateTierId='supplierRatesChildGridRateTierId';
Modules.CompIds.supplierRatesChildGridTrnspModId='supplierRatesChildGridTrnspModId';
Modules.CompIds.supplierRatesChildGridValidToDtId='supplierRatesChildGridValidToDtId';
Modules.CompIds.supplierRatesChildGridValidFrmDtId='supplierRatesChildGridValidFrmDtId';
Modules.CompIds.supplierRatesChildGridCstmrId='supplierRatesChildGridCstmrId';
Modules.CompIds.supplierRatesChildGridSrvCodeId='supplierRatesChildGridSrvCodeId';
Modules.CompIds.editSupplierRatesChildGridWinId='editSupplierRatesChildGridWinId';
Modules.CompIds.editSupplierRatesPGridWinId='editSupplierRatesPGridWinId';
Modules.CompIds.editSupplierRatesFuelSrChrgGridWinId='editSupplierRatesFuelSrChrgGridWinId';

Modules.CompIds.supplierRatesFormCargoTypeId='supplierRatesFormCargoTypeId';
Modules.CompIds.supplierRatesFormStorageTypeId='supplierRatesFormStorageTypeId';
Modules.CompIds.supplierRatesFormModelLineId='supplierRatesFormModelLineId';
Modules.CompIds.supplierRatesAdvcSrchId='supplierRatesAdvcSrchId';
Modules.CompIds.supplierRatesFuelSrChrgGridCargoTypeId='supplierRatesFuelSrChrgGridCargoTypeId';
Modules.CompIds.supplierRatesFuelSrChrgGridStorageTypeId='supplierRatesFuelSrChrgGridStorageTypeId';
Modules.CompIds.supplierRatesFuelSrChrgGridModelLineId='supplierRatesFuelSrChrgGridModelLineId';

Modules.CompIds.supplierRatesChildGridCargoTypeId='supplierRatesChildGridCargoTypeId';
Modules.CompIds.supplierRatesChildGridStorageTypeId='supplierRatesChildGridStorageTypeId';
Modules.CompIds.supplierRatesChildGridModelLineId='supplierRatesChildGridModelLineId';


Modules.CompIds.supplierRateVerificationTabPanelId='supplierRateVerificationTabPanelId';
Modules.CompIds.supplierRateVerificationGridId='supplierRateVerificationGridId';
Modules.CompIds.supplierRateAdvContainer='supplierRateAdvContainer';
Modules.CompIds.SupplierRateVerificationFormId_supplier='SupplierRateVerificationFormId_supplier';
Modules.CompIds.SupplierRateVerificationFormId_supplierNm='SupplierRateVerificationFormId_supplierNm';
Modules.CompIds.SupplierRateVerificationFormId_effectiveDate='SupplierRateVerificationFormId_effectiveDate';
Modules.CompIds.SupplierRateVerificationFormId_serviceCode='SupplierRateVerificationFormId_serviceCode';


/***Customer Line Item Status***/
Modules.CompIds.customerLineItemStatusTabParentId='customerLineItemStatusTabParentId';
Modules.CompIds.customerLineItemStatusGridId='customerLineItemStatusGridId';
Modules.CompIds.customerLineItemStatusGridPopupId='customerLineItemStatusGridPopupId';
Modules.CompIds.customerLineItemStatusFormId='customerLineItemStatusFormId';
Modules.CompIds.customerInvoiceLineItemAdvContainer='customerInvoiceLineItemAdvContainer';
Modules.CompIds.customerLineItemStatusFromDateId='customerLineItemStatusFromDateId';
Modules.CompIds.customerLineItemStatusToDateId='customerLineItemStatusToDateId';

/***Supplier Automatic Invoice  Status***/
Modules.CompIds.supplierAutInvoiceFormId= 'supplierAutoInvoiceFormId';
Modules.CompIds.supplierAutoInvcTabParentPanelId='supplierAutoInvoiceTabParentPanelId';
Modules.CompIds.supplierAutoInvoiceCompanyId='supplierAutoInvoiceCompanyId';
Modules.CompIds.supplierAutoInvoiceCompanyNameId='supplierAutoInvoiceCompanyNameId';

Modules.CompIds.supplierAutomaticInvoiceGenerationFrequencyId= 'supplierAutomaticInvoiceGenerationFrequencyId';
Modules.CompIds.supplierAutomaticInvoiceGenerationTimeId= 'supplierAutomaticInvoiceGenerationTimeId';

/*** Admin Security **/
Modules.CompIds.oceanUserManagementWindowId='oceanUserManagementWindowId';

/******************Supplier Master************************************/


Modules.CompIds.supplrMasterAutomaticInvcPopupServiceTypeID = 'supplrMasterAutomaticInvcPopupServiceTypeID';

Modules.CompIds.supplierMasterTabparentpanelId = 'supplierMasterTabparentpanelId';

Modules.CompIds.supplierMasterFormId = 'supplierMasterFormId';
Modules.CompIds.supplierMstrSupplierLOVId = 'supplierMstrSupplierLOVId';
Modules.CompIds.supplrMasterFormNameId = 'supplrMasterFormNameId';
Modules.CompIds.supplierMasterParentGridId = 'supplierMasterParentGridId';
Modules.CompIds.paymentTermSupplierMasterGridId = 'paymentTermSupplierMasterGridId';
Modules.CompIds.statusDateForContractSupplierMasterGridId = 'statusDateForContractSupplierMasterGridId';
Modules.CompIds.supplrMstrAutomaticInvSetupGridId = 'supplrMstrAutomaticInvSetupGridId';
Modules.CompIds.rateRoundingCriteriaForRateSupplierMasterGridId = 'rateRoundingCriteriaForRateSupplierMasterGridId';
Modules.CompIds.rateRoundingCriteriaForDistanceSupplierMasterGridId = 'rateRoundingCriteriaForDistanceSupplierMasterGridId';
Modules.CompIds.supplierMasterHdrGridPopupWinId = 'supplierMasterHdrGridPopupWinId';
Modules.CompIds.SupplrMasterHdrPopupSpplrCdId   = 'SupplrMasterHdrPopupSpplrCdId';
Modules.CompIds.paymntTermDtlsPopupId           = 'paymntTermDtlsPopupId';
Modules.CompIds.supplrPaymntTermPopupSrvcCodeId = 'supplrPaymntTermPopupSrvcCodeId';
Modules.CompIds.supplrMasterPopupServiceTypeID  = 'supplrMasterPopupServiceTypeID';
Modules.CompIds.supplrMasterStsDtForContrctIdPopupId = 'supplrMasterStsDtForContrctIdPopupId';
Modules.CompIds.supplrStsDtForContractIdGridPopupOriginLovId = 'supplrStsDtForContractIdGridPopupOriginLovId';
Modules.CompIds.supplrStsDtForContractIdGridPopupDestLovId   =  'supplrStsDtForContractIdGridPopupDestLovId';
Modules.CompIds.supplrStsDtForContractIdGridPopupSrvcCodeId  = 'supplrStsDtForContractIdGridPopupSrvcCodeId';
Modules.CompIds.supplrMasterautomaticInvcSetupPopupId        = 'supplrMasterautomaticInvcSetupPopupId';
Modules.CompIds.supplrAutomaticInvcSetupPopupServiceCodeId   =  'supplrAutomaticInvcSetupPopupServiceCodeId';
Modules.CompIds.supplrRoundingCriteriaForRatePopupCurrencyId = 'supplrRoundingCriteriaForRatePopupCurrencyId';
Modules.CompIds.spplrMasterRoundingCriteriaGridPopupId       =  'spplrMasterRoundingCriteriaGridPopupId';
Modules.CompIds.spplrMasterRoundingCriteriaForDistanceGridPopupId  = 'spplrMasterRoundingCriteriaForDistanceGridPopupId';
Modules.CompIds.supplrMasterRoundingCriteriaForDistancePopUomId    = 'supplrMasterRoundingCriteriaForDistancePopUomId';


/****Reports Supplier Payment*****/
Modules.CompIds.supplierPaymentReportFormId= 'supplierPaymentReportFormId';
Modules.CompIds.supplierPaymentReportParentPanelId='supplierPaymentReportParentPanelId';
Modules.CompIds.supplierPaymentReportCompanyCodeId= 'supplierPaymentCompanyCodeId';
Modules.CompIds.supplierPaymentReportCompanyNameId= 'supplierPaymentCompanyNameId';
Modules.CompIds.supplierPaymentReportSupplierCodeId= 'supplierPaymentSupplierCodeId';
Modules.CompIds.supplierPaymentReportSupplierNameId= 'supplierPaymentSupplierNameId';
Modules.CompIds.supplierPaymentReportServiceCodeId= 'supplierPaymentServiceCodeId';
Modules.CompIds.supplierPaymentReportInvoiceId= 'supplierPaymentInvoiceId';
Modules.CompIds.supplierPaymentReportCreditId= 'supplierPaymentCreditId';
Modules.CompIds.supplierPaymentReportDebitId= 'supplierPaymentDebitId';
Modules.CompIds.supplierPaymentReportFromDateId= 'supplierPaymentFromDateId';
Modules.CompIds.supplierPaymentReportToDateId= 'supplierPaymentToDateId';
Modules.CompIds.supplierPaymentReportFornId= 'supplierPaymentReportFornId';
/******Supplier Invoice Aging Report******/
Modules.CompIds.supplierInvoiceAgingReportFormId= 'supplierInvoiceAgingReportFormId';
Modules.CompIds.supplierInvoiceAgingReportParentPanelId='supplierInvoiceAgingReportParentPanelId';
Modules.CompIds.supplierInvoiceAgingReportCompanyCodeId= 'supplierInvoiceAgingCompanyCodeId';
Modules.CompIds.supplierInvoiceAgingReportCompanyNameId= 'supplierInvoiceAgingCompanyNameId';
Modules.CompIds.supplierInvoiceAgingReportSupplierCodeId= 'supplierInvoiceAgingSupplierCodeId';
Modules.CompIds.supplierInvoiceAgingReportSupplierNameId= 'supplierInvoiceAgingSupplierNameId';
/**********************************/



Modules.CompIds.supplierRatesCompositeGridId='supplierRatesCompositeGridId';
Modules.CompIds.supplierRatesComositeGridAddId='supplierRatesComositeGridAddId';
Modules.CompIds.suplierRatesCompositeFormId='suplierRatesCompositeFormId';

Modules.CompIds.supplierRatesCompositeFrmTotalId='supplierRatesCompositeFrmTotalId';

Modules.CompIds.supplierRatesCompositeFrmTotalId='supplierRatesCompositeFrmTotalId';
Modules.CompIds.supplierRatesChildGridcompositeBtnId='supplierRatesChildGridcompositeBtnId';
Modules.CompIds.supplierRatesMinLoadGridId='supplierRatesMinLoadGridId';
Modules.CompIds.supplierRatesAgreedMilageGridAddId='supplierRatesAgreedMilageGridAddId';
Modules.CompIds.supplierRatesMinLoadGridAddId='supplierRatesMinLoadGridAddId';
Modules.CompIds.supplierRatesAgreedMilageGridId='supplierRatesAgreedMilageGridId';
Modules.CompIds.editSupplierRatesMinLoadWinId='editSupplierRatesMinLoadWinId';
Modules.CompIds.editSupplierRatesAgreedMilageWinId='editSupplierRatesAgreedMilageWinId';

/******Tax Report******/
Modules.CompIds.taxReportFormId= 'taxReportFormId';
Modules.CompIds.taxReportParentPanelId='taxReportParentPanelId';
Modules.CompIds.taxReportCompanyCodeId= 'taxReportCompanyCodeId';
Modules.CompIds.taxReportCompanyNameId= 'taxReportCompanyNameId';
Modules.CompIds.taxReportSupplierCodeId= 'taxReportSupplierCodeId';
Modules.CompIds.taxReportSupplierNameId= 'taxReportSupplierNameId';
Modules.CompIds.taxReportFromDateId= 'taxReportFromDateId';
Modules.CompIds.taxReportToDateId= 'taxReportToDateId';
Modules.CompIds.taxReportCustomerCodeId= 'taxReportCustomerCodeId';
Modules.CompIds.taxReportCustomerNameId= 'taxReportCustomerNameId';
Modules.CompIds.taxReportTaxTypeId= 'taxReportTaxTypeId';
/**********************************/

/****Customer Invoice Generate Accrual *****/
Modules.CompIds.customerInvGenerateAccrualFormId ='customerIvnoiceGenarateAccrualFormId';
Modules.CompIds.customerInvGenerateAccrualGridId ='customerInvGenerateAccrualGridId';
Modules.CompIds.customerInvGenerateAccrualFromDateId ='generateAccrualFromDateId';
Modules.CompIds.customerInvGenerateAccrualToDateId ='generateAccrualToDateId';
Modules.CompIds.customerInvGenerateAccrualContainerId ='customerInvGenerateAccrualContainerId';
Modules.CompIds.custInvcSetupActInvcGrpngGridPopUpWinFormId='custInvcSetupActInvcGrpngGridPopUpWinFormId';

Modules.CompIds.customerInvGenerateAccrualGridPopupId ='customerInvGenerateAccrualGridPopupId';


Modules.CompIds.customerInvGenerateAccrualGridPopupId ='customerInvGenerateAccrualGridPopupId';


Modules.CompIds.nonOceanSupplierRateQueryGridPopUpId = 'nonOceanSupplierRateQueryGridPopUpId';

Modules.CompIds.customerInvGenerateAccrualGridPopupId ='customerInvGenerateAccrualGridPopupId';


/****Customer Invoice Entry Consolidation *****/
Modules.CompIds.cstmrInvcEntryConsolTabPanelId = 'customerInvocieEntryConsolTabParentPanelId';

/****  Customer Accrual and Actual Invoice Setup ****/
Modules.CompIds.serviceTypeForCustomerInvoiceSetup='serviceTypeForCustomerInvoiceSetup';
Modules.CompIds.custInvcSetupTriggerIdentfGridPopUpFormId='custInvcSetupTriggerIdentfGridPopUpFormId';
Modules.CompIds.accrualGroupingCriteriaGridId='accrualGroupingCriteriaGridId';
Modules.CompIds.custInvcSetupAccrualGrpngGridPopUpWinFormId='custInvcSetupAccrualGrpngGridPopUpWinFormId';
Modules.CompIds.custInvcSetupAccrualInvcGrpngGridPopUpWinId='custInvcSetupAccrualInvcGrpngGridPopUpWinId';
Modules.CompIds.deleteAccrualGroupingRecordId='deleteAccrualGroupingRecordId';
Modules.CompIds.addAccrualGroupingCriteriaRecordId='addAccrualGroupingCriteriaRecordId';

/******************Customer Invoice Generation************************************/

Modules.CompIds.cstmrInvcGenFormId='cstmrInvcGenFormId';
Modules.CompIds.cstmrInvcGenGridId='cstmrInvcGenGridId';
Modules.CompIds.cstmrInvcGenNOAdvContainer='cstmrInvcGenNOAdvContainer';
Modules.CompIds.cstmrInvcGenFormSupplierId='cstmrInvcGenFormSupplierId';
Modules.CompIds.cstmrInvcGenFormCustomerId='cstmrInvcGenFormCustomerId';
Modules.CompIds.cstmrInvcGenFormDebtprPartyId='cstmrInvcGenFormDebtprPartyId';
Modules.CompIds.cstmrInvcGenFormSrvCodeId='cstmrInvcGenFormSrvCodeId';
Modules.CompIds.cstmrInvcGenFormSrvGrpId='cstmrInvcGenFormSrvGrpId';
Modules.CompIds.cstmrInvcGenFormConvnceIdId='cstmrInvcGenFormConvnceIdId';
Modules.CompIds.cstmrInvcGenFormConveyanceTypeId='cstmrInvcGenFormConveyanceTypeId';
Modules.CompIds.cstmrInvcGenFormConvnceNameId='cstmrInvcGenFormConvnceNameId';
Modules.CompIds.cstmrInvcGenFormProfitLossCntreId='cstmrInvcGenFormProfitLossCntreId';
Modules.CompIds.cstmrInvcGenFormEventloadRefId='cstmrInvcGenFormEventloadRefId';
Modules.CompIds.cstmrInvcGenFormShipingRefId='cstmrInvcGenFormShipingRefId';
Modules.CompIds.cstmrInvcGenFormWrkOrderId='cstmrInvcGenFormWrkOrderId';
Modules.CompIds.cstmrInvcGenFormUnitId='cstmrInvcGenFormUnitId';
Modules.CompIds.cstmrInvcGenFormEventDateId='cstmrInvcGenFormEventDateId';
Modules.CompIds.cstmrInvcGenFormFromDateId='cstmrInvcGenFormFromDateId';
Modules.CompIds.cstmrInvcGenFormToDateId='cstmrInvcGenFormToDateId';
Modules.CompIds.cstmrInvcGenFormDestId='cstmrInvcGenFormDestId';
Modules.CompIds.cstmrInvcGenFormOriginId='cstmrInvcGenFormOriginId';
Modules.CompIds.cstmrInvcGenFormOrgcityId='cstmrInvcGenFormOrgcityId';
Modules.CompIds.cstmrInvcGenFormOrgStateId='cstmrInvcGenFormOrgStateId';
Modules.CompIds.cstmrInvcGenFormOrgOriginId='cstmrInvcGenFormOrgOriginId';
Modules.CompIds.cstmrInvcGenFormDestCityId='cstmrInvcGenFormDestCityId';
Modules.CompIds.cstmrInvcGenFormDestStateId='cstmrInvcGenFormDestStateId';
Modules.CompIds.cstmrInvcGenFormFinalDestId='cstmrInvcGenFormFinalDestId';
Modules.CompIds.cstmrInvcGenGridId='cstmrInvcGenGridId';
Modules.CompIds.cstmrInvcGenGridWinId='cstmrInvcGenGridWinId';

/****Customer Invoice Reconsiliation *****/
Modules.CompIds.customerReconTabParentPanelId='customerInvoiceReconTabParentPanelId';
Modules.CompIds.customerReconsiliationFormId ='customerReconsiliationFormId';
Modules.CompIds.customerReconsiliationContainerId ='customerReconsiliationContainerId';
Modules.CompIds.customerReconsiliationGridId ='cstmrReconciliationGridId';
Modules.CompIds.customerRconsilitionFromDateId ='customerRecFromDateId';
Modules.CompIds.customerRconsilitionToDateId ='customerRecToDateId';
Modules.CompIds.customerReconPopUpWindowId ='customerReconsiliationPopUpWindowId';

/******Customer Revenue Report******/
Modules.CompIds.customerRevenueReportFormId= 'customerRevenueReportFormId';
Modules.CompIds.customerRevenueReportServiceCodeGridId= 'customerRevenueReportServiceCodeGridId';
Modules.CompIds.customerRevenueReportGLCodeGridId= 'customerRevenueReportGLCodeGridId';
Modules.CompIds.customerRevenueReportParentPanelId='customerRevenueReportParentPanelId';
Modules.CompIds.customerRevenueReportCompanyCodeId= 'customerRevenueReportCompanyCodeId';
Modules.CompIds.customerRevenueReportCompanyNameId= 'customerRevenueReportCompanyNameId';
Modules.CompIds.customerRevenueReportServiceCodeId= 'customerRevenueReportServiceCodeId';
Modules.CompIds.customerRevenueReportGlCodeId= 'customerRevenueReportGlCodeId';
Modules.CompIds.customerRevenueReportGlCodeRadioId= 'customerRevenueReportGlCodeRadioId';
Modules.CompIds.customerRevenueReportcustomerRadioId= 'customerRevenueReportcustomerRadioId';
Modules.CompIds.customerRevenueReportFromDateId= 'customerRevenueReportFromDateId';
Modules.CompIds.customerRevenueReportToDateId= 'customerRevenueReportToDateId';
Modules.CompIds.customerRevenueReportActualId= 'customerRevenueReportActualId';
Modules.CompIds.customerRevenueReportAccrualId= 'customerRevenueReportAccrualId';
Modules.CompIds.customerRevenueReportCustomerCodeId= 'customerRevenueReportCustomerCodeId';
Modules.CompIds.customerRevenueReportCustomerNameId= 'customerRevenueReportCustomerNameId';
Modules.CompIds.customerRevenueReportInvoiceId= 'customerRevenueReportInvoiceId';
Modules.CompIds.customerRevenueReportCreditId= 'customerRevenueReportCreditId';
Modules.CompIds.customerRevenueReportDebitId= 'customerRevenueReportDebitId';

/**********************************/
/******Supplier Rate Report******/
Modules.CompIds.supplierRateReportFormId= 'supplierRateReportFormId';
Modules.CompIds.supplierRateReportParentPanelId='supplierRateReportParentPanelId';
Modules.CompIds.supplierRateReportCompanyCodeId= 'supplierRateReportCompanyCodeId';
Modules.CompIds.supplierRateReportCompanyNameId= 'supplierRateReportCompanyNameId';
Modules.CompIds.supplierRateReportSupplierId= 'supplierRateReportSupplierId';
Modules.CompIds.supplierRateReportContractId= 'supplierRateReportContractId';
Modules.CompIds.supplierRateReportFromDateId= 'supplierRateReportFromDateId';
Modules.CompIds.supplierRateReportToDateId= 'supplierRateReportToDateId';
Modules.CompIds.supplierRateReportContractOriginId= 'supplierRateReportContractOriginId';
Modules.CompIds.supplierRateReportSupplierOriginId='supplierRateReportSupplierOriginId';
Modules.CompIds.supplierRateReportSupplierCodeGridId= 'supplierRateReportSupplierCodeGridId';
Modules.CompIds.supplierRateReportContractCodeGridId= 'supplierRateReportContractCodeGridId';
Modules.CompIds.supplierRateReportContractOriginGridId= 'supplierRateReportContractOriginGridId';
Modules.CompIds.supplierRateReportSupplierDestGridId= 'supplierRateReportSupplierDestGridId';

Modules.CompIds.fuelSurchargeIndexValueMasterPanelId='fuelSurchargeIndexValueMasterPanelId';

Modules.CompIds.nonOcnSupRecSetupToleranceid='nonOcnSupRecSetupToleranceid';
Modules.CompIds.NonOcnSupRecSetUpMatchingCriteriaDtlsId='NonOcnSupRecSetUpMatchingCriteriaDtlsId';
/**********************************/

Modules.CompIds.userToComapnyAssociationWindowId='userToComapnyAssociationWindowId';
Modules.CompIds.oceanJournalingFormId='oceanJournalingFormId';
Modules.CompIds.popupOceanJournalingId='popupOceanJournalingId';
Modules.CompIds.customerInvoiceSetUpFormId='customerInvoiceSetUpFormId';

/* Non-Ocean Customer Application Advice */
Modules.CompIds.CstmrApplAdvcTabPanelId='CstmrApplAdvcTabPanelId';
Modules.CompIds.CstmrApplAdvcFormId='CstmrApplAdvcFormId';
Modules.CompIds.CstmrApplAdvcFormPartyId='CstmrApplAdvcFormPartyId';
Modules.CompIds.CstmrApplAdvcFormServiceTypeId='CstmrApplAdvcFormServiceTypeId';
Modules.CompIds.CstmrApplAdvcFormServiceCodeId='CstmrApplAdvcFormServiceCodeId';
Modules.CompIds.CstmrApplAdvcFormInvoiceNumberId='CstmrApplAdvcFormInvoiceNumberId';
Modules.CompIds.CstmrApplAdvcActionColId='CstmrApplAdvcActionColId';
Modules.CompIds.CstmrApplAdvcActionColPopUpWindwId='CstmrApplAdvcActionColPopUpWindwId';
Modules.CompIds.CstmrApplAdvcGPPopUpWindowId='CstmrApplAdvcGPPopUpWindowId';
Modules.CompIds.CstmrApplAdvcGPPopUpWindowId='CstmrApplAdvcGPPopUpWindowId';
Modules.CompIds.CstmrApplAdvcRejectBtnId='CstmrApplAdvcRejectBtnId';
Modules.CompIds.CstmrApplAdvcAcceptBtnId='CstmrApplAdvcAcceptBtnId';
Modules.CompIds.CstmrApplAdvcPGridPopUpWindowId='CstmrApplAdvcPGridPopUpWindowId';
Modules.CompIds.CstmrApplAdvcChildGridPopUpWindowId='CstmrApplAdvcChildGridPopUpWindowId';

/* Ocean Supplier Remittance Details */
Modules.CompIds.ocnsupplierRemittanceDetailsPanelId='ocnsupplierRemittanceDetailsPanelId';
Modules.CompIds.ocnsupplrRemmtnceDtlsChildGridId='ocnsupplrRemmtnceDtlsChildGridId';
Modules.CompIds.ocnsupplierRemittanceDetailsFormId='ocnsupplierRemittanceDetailsFormId';
Modules.CompIds.ocnsupplierRemittanceDetailsPaymentFromDtId='ocnsupplierRemittanceDetailsPaymentFromDtId';
Modules.CompIds.ocnsupplierRemittanceDetailsPaymentToDateId='ocnsupplierRemittanceDetailsPaymentToDateId';
Modules.CompIds.ocnsupplierRemittanceDetailsInvcFromDtId='ocnsupplierRemittanceDetailsInvcFromDtId';
Modules.CompIds.ocnsupplierRemittanceDetailsInvcToDateId='ocnsupplierRemittanceDetailsInvcToDateId';
Modules.CompIds.ocnsupplierRemittanceDetailsAdvContnerId='ocnsupplierRemittanceDetailsAdvContnerId';
Modules.CompIds.ocnsupplrRemmtnceDtlsParntGrdEditWinPaymntDocId='ocnsupplrRemmtnceDtlsParntGrdEditWinPaymntDocId';
Modules.CompIds.ocnsupplrRemmtnceDtlsParntGrdEditWinPaymntDtId='ocnsupplrRemmtnceDtlsParntGrdEditWinPaymntDtId';
Modules.CompIds.ocnsupplierRemittanceDetailsParGridId='ocnsupplierRemittanceDetailsParGridId';

/* Fuel Surcharge Index Value Master */
Modules.CompIds.FuelSurchargeIndexValueMasterFormId='FuelSurchargeIndexValueMasterFormId';
Modules.CompIds.FuelSurchargeIndexValueMasterGridId='FuelSurchargeIndexValueMasterGridId';
Modules.CompIds.FuelSurchargeIndexValueMasterPopupFormId='FuelSurchargeIndexValueMasterPopupFormId';
Modules.CompIds.FuelSurchargeIndexValueMasterPopupWinId='FuelSurchargeIndexValueMasterPopupWinId';
Modules.GlobalVars.FuelSurchargeIndexValueMaster='FuelSurchargeIndexValueMaster';




/*******************Ocean View Covus XML Interface***************************/

Modules.CompIds.oceanViewCustomerInvcWindowId = 'oceanViewCustomerInvcWindowId';
Modules.CompIds.oceanViewCustomerInvcWindowIdTabPanelId = 'oceanViewCustomerInvcWindowId';

Modules.CompIds.oceanViewCustomerInvcWindowIdMsgHdrId= 'oceanViewCustomerInvcWindowIdMsgHdrId';
Modules.CompIds.oceanViewCustomerInvcWindowIdMsgTypeId = 'oceanViewCustomerInvcWindowIdMsgTypeId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCompanyCdId = 'oceanViewCustomerInvcWindowIdCompanyCdId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCompanyNmId = 'oceanViewCustomerInvcWindowIdCompanyNmId';
Modules.CompIds.oceanViewCustomerInvcWindowIdInvcDateId = 'oceanViewCustomerInvcWindowIdInvcDateId';
Modules.CompIds.oceanViewCustomerInvcWindowIdInvcDueDateId = 'oceanViewCustomerInvcWindowIdInvcDueDateId';
Modules.CompIds.oceanViewCustomerInvcWindowIdInvcNum = 'oceanViewCustomerInvcWindowIdInvcNum';
Modules.CompIds.oceanViewCustomerInvcWindowIdInvcCrdNoteIndId= 'oceanViewCustomerInvcWindowIdInvcCrdNoteIndId';
Modules.CompIds.oceanViewCustomerInvcWindowIdPrfStatusId= 'oceanViewCustomerInvcWindowIdPrfStatusId';
Modules.CompIds.oceanViewCustomerInvcWindowIdPopCdId = 'oceanViewCustomerInvcWindowIdPopCdId';
Modules.CompIds.oceanViewCustomerInvcWindowIdPopDescId = 'oceanViewCustomerInvcWindowIdPopDescId';
Modules.CompIds.oceanViewCustomerInvcWindowIdTotInvcAmtManfestCrncyId = 'oceanViewCustomerInvcWindowIdTotInvcAmtManfestCrncyId';
Modules.CompIds.oceanViewCustomerInvcWindowIdManfestCrncyCdId = 'oceanViewCustomerInvcWindowIdManfestCrncyCdId';

Modules.CompIds.oceanViewCustomerInvcWindowIdRefInvcNbrId = 'oceanViewCustomerInvcWindowIdRefInvcNbrId';

Modules.CompIds.oceanViewCustomerInvcWindowIdInvcExchangeRate = 'oceanViewCustomerInvcWindowIdInvcExchangeRate';
Modules.CompIds.oceanViewCustomerInvcWindowIdTotInvcAmtLocalCrncyId = 'oceanViewCustomerInvcWindowIdTotInvcAmtLocalCrncyId';
Modules.CompIds.oceanViewCustomerInvcWindowIdLocalCrncyCdId = 'oceanViewCustomerInvcWindowIdLocalCrncyCdId';
Modules.CompIds.oceanViewCustomerInvcWindowIdTotInvcAmtUsdCrncyId = 'oceanViewCustomerInvcWindowIdTotInvcAmtUsdCrncyId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerCodeId = 'oceanViewCustomerInvcWindowIdCustomerCodeId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerNmId = 'oceanViewCustomerInvcWindowIdCustomerNmId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerTypeId = 'oceanViewCustomerInvcWindowIdCustomerTypeId';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerAddrss1Id = 'oceanViewCustomerInvcWindowIdCustomerAddrss1Id';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerAddrss2Id = 'oceanViewCustomerInvcWindowIdCustomerAddrss2Id';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerAddrss3Id = 'oceanViewCustomerInvcWindowIdCustomerAddrss3Id';
Modules.CompIds.oceanViewCustomerInvcWindowIdCustomerCityFormId = 'oceanViewCustomerInvcWindowIdCustomerCityFormId';
Modules.CompIds.oceanViewCustomerInvcCstmrRegionCdId = 'oceanViewCustomerInvcCstmrRegionCdId';
Modules.CompIds.oceanViewCustomerInvcCstmrStateCdId = 'oceanViewCustomerInvcCstmrStateCdId';
Modules.CompIds.oceanViewCustomerInvcCstmrCountryCdId = 'oceanViewCustomerInvcCstmrCountryCdId';
Modules.CompIds.oceanViewCustomerInvcCstmrPoBoxId = 'oceanViewCustomerInvcCstmrPoBoxId';
Modules.CompIds.oceanViewCustomerInvcCstmrVatNbrId = 'oceanViewCustomerInvcCstmrVatNbrId';
Modules.CompIds.oceanViewCustomerInvcCstmrContactPrsnId = 'oceanViewCustomerInvcCstmrContactPrsnId';


/* ********* END ***************/

/*******************Ocean View Voyage Master Message***************************/
Modules.CompIds.oceanVoyageMasterViewWindowId = 'oceanVoyageMasterViewWindowId';
Modules.CompIds.ocenaVoyageMasterViewFormId = 'ocenaVoyageMasterViewFormId';
Modules.CompIds.oceanVoyageMasterMsgHdrId = 'oceanVoyageMasterMsgHdrId'; 
Modules.CompIds.oceanVoyageMasterMsgTypeId = 'oceanVoyageMasterMsgTypeId';
Modules.CompIds.oceanVoyageMasterCompanyCdId = 'oceanVoyageMasterCompanyCdId';
Modules.CompIds.oceanVoyageMasterCompanyNmId = 'oceanVoyageMasterCompanyNmId';
Modules.CompIds.oceanVoyageMasterVoyageNumberId = 'oceanVoyageMasterVoyageNumberId';
Modules.CompIds.oceanVoyageMasterVoyageCurrencyCd = 'oceanVoyageMasterVoyageCurrencyCd';
Modules.CompIds.oceanVoyageMasterRouteCdId = 'oceanVoyageMasterRouteCdId';
Modules.CompIds.oceanVoyageMasterVslCdId = 'oceanVoyageMasterVslCdId';
Modules.CompIds.oceanVoyageMasterVslNmId = 'oceanVoyageMasterVslNmId';
Modules.CompIds.oceanVoyageMasterOrgnlSiteId = 'oceanVoyageMasterOrgnlSiteId';
Modules.CompIds.oceanVoyageMasterorgnlactionCdId = 'oceanVoyageMasterorgnlactionCdId';
Modules.CompIds.ocnVoyageMessageSupplierGridId = 'ocnVoyageMessageSupplierGridId';
Modules.CompIds.ocnVoyageMessagePortDtlsTabPanelId = 'ocnVoyageMessagePortDtlsTabPanelId';
Modules.CompIds.ocnVoyageMasterMessagePortDtlsId = 'ocnVoyageMasterMessagePortDtlsId';
Modules.CompIds.ocnVoyageMessageCurrencyDtlsId = 'ocnVoyageMessageCurrencyDtlsId';
Modules.CompIds.ocnVoyageMessageCurrencyDtlsTabPanelId = 'ocnVoyageMessageCurrencyDtlsTabPanelId';
Modules.CompIds.ocnVoyageMessagePortExchangeDtlsTabPanelId = 'ocnVoyageMessagePortExchangeDtlsTabPanelId';
Modules.CompIds.ocnVoyageMasterMessagePortExchangeDtlsId = 'ocnVoyageMasterMessagePortExchangeDtlsId';
Modules.CompIds.oceanVoyageMessageSupplierDtlsTabPanelId = 'oceanVoyageMessageSupplierDtlsTabPanelId';
Modules.CompIds.oceanVoyageMasterVoyageCurrencyCdId = 'oceanVoyageMasterVoyageCurrencyCdId';

/************************ end *******************/

Modules.CompIds.invcGenFinalWinGridId='invcGenFinalWinGridId';
Modules.CompIds.invcGenFailureWinGridId = 'invcGenFailureWinGridId';

Modules.CompIds.customerDebtorPartyGridId='customerDebtorPartyGridId';

Modules.CompIds.customerDebtorPartyGridSaveId='customerDebtorPartyGridSaveId';
Modules.CompIds.customerDebtorPartyGridCustomerId='customerDebtorPartyGridCustomerId';
Modules.CompIds.customerDebtorPartyGridDbtrPartyCdId='customerDebtorPartyGridDbtrPartyCdId';

Modules.CompIds.oceanCovusXmlInterfacePrintTypeCdId='oceanCovusXmlInterfacePrintTypeCdId';
Modules.CompIds.oceanCovusXmlInterfaceBillPrinterCdId='oceanCovusXmlInterfaceBillPrinterCdId';
Modules.CompIds.oceanCovusXmlInterfaceBillPrinterPathId='oceanCovusXmlInterfaceBillPrinterPathId';
Modules.CompIds.oceanCovusXmlInterfaceBillPrintTrayId='oceanCovusXmlInterfaceBillPrintTrayId';
Modules.CompIds.oceanCovusXmlInterfaceBillCopyCountId='oceanCovusXmlInterfaceBillCopyCountId';
Modules.CompIds.oceanCovusXmlInterfaceDuplicateInvcCopyCountId='oceanCovusXmlInterfaceDuplicateInvcCopyCountPrintTypeCdId';
Modules.CompIds.oceanCovusXmlInterfaceInvcPrinterTrayId='oceanCovusXmlInterfaceInvcPrinterTrayId';
Modules.CompIds.oceanSupplierInvoiceStatusFormId='supplier_invoice_status_ocean-formId';

Modules.CompIds.ocnSpplrRatesAdvcSrchId = 'ocnSpplrRatesAdvcSrchId';

/*******************DPW component IDs***************************/
	
	
	
	Modules.CompIds.ActivityCodeMastertabparentpanelID='activityCodeMasterTabParentPanelId';
	Modules.CompIds.ActivityCodeMasterGrid='activityCodeMasterGridId';

	Modules.CompIds.ActivityTypeMastertabparentpanelID='activityTypeMasterTabParentPanelId';
	Modules.CompIds.ActivityTypeMasterGrid='activityTypeMasterGridId';
	
	
	Modules.CompIds.EquipmentMastertabparentpanelID='equipmentMasterTabParentPanelId';
	Modules.CompIds.EquipmentMasterGrid='equipmentMasterGridId';
	Modules.CompIds.EquipmentMasterForm='equipmentMasterFormId';
	
	Modules.CompIds.EditUserTabparentpanelID='editUserTabparentpanelID';
	
	
	Modules.CompIds.AddUserTabparentpanelID='addUserTabparentpanelID';
	
	Modules.CompIds.UserMastertabparentpanelID='userMasterTabParentPanelId';
	Modules.CompIds.UserMasterGrid='userMasterGridId';
	
	Modules.CompIds.UserMastertabparentpanelID_view='userMasterTabParentPanelId_view';
	Modules.CompIds.UserMasterGrid='userMasterGridId';
	
	Modules.CompIds.RoleMastertabparentpanelID='roleMasterTabParentPanelId';
	Modules.CompIds.RoleMasterGrid='roleMasterGridId';
	
	Modules.CompIds.PinningStationMastertabparentpanelID='pinningStationMasterTabParentPanelId';
	Modules.CompIds.PinningStationMasterGrid='pinningStationMasterGridId';
	
	Modules.CompIds.MoveTypeMastertabparentpanelID='moveTypeMasterTabParentPanelId';
	Modules.CompIds.MoveTypeMasterGrid='moveTypeMasterGridId';
	
	Modules.CompIds.DirectionMastertabparentpanelID='directionMasterTabParentPanelId';
	Modules.CompIds.DirectionMasterGrid='directionMasterGridId';
	
	Modules.CompIds.ChecklistMastertabparentpanelID='checklistMasterTabParentPanelId';
	Modules.CompIds.ChecklistMasterGrid='checklistMasterGridId'; 
	
	
	
	Modules.CompIds.CheckListHeaderMastertabparentpanelID='checkListHeaderMasterTabParentPanelId';
	Modules.CompIds.CheckListHeaderMasterGrid='checkListHeaderMasterGridId'; 
	
	//Modules.CompIds.GenericChecklistMastertabparentpanelID,
	
	Modules.CompIds.QC_LaneMastertabparentpanelID='QC_LaneMasterTabParentPanelId';
	Modules.CompIds.QC_LaneMasterGrid='QC_LaneMasterGridId';
	//Modules.CompIds.QC_LaneMasterForm='QC_LaneMasterFormId';
	
	Modules.CompIds.TerminalMastertabparentpanelID='terminalMasterTabParentPanelId';
	Modules.CompIds.TerminalMasterGrid='terminalMasterGridId';
	
	Modules.CompIds.LanguageMastertabparentpanelID='languageMasterTabParentPanelId';
	Modules.CompIds.LanguageMasterGrid='languageMasterGridId';
	
	Modules.CompIds.DeviceMastertabparentpanelID='deviceMasterTabParentPanelId';
	Modules.CompIds.DeviceMasterGrid='deviceMasterGridId';	
	//Modules.CompIds.DeviceMasterForm='deviceMasterFormId';
	
	Modules.CompIds.DamageCodeMastertabparentpanelID='damageCodeMasterTabParentPanelId';
	Modules.CompIds.DamageCodeMasterGrid='damageCodeMasterGridId';
	//Modules.CompIds.DamageCodeMasterForm='damageCodeMasterFormId';
	
	Modules.CompIds.DamageSeverityMastertabparentpanelID='damageSeverityMasterTabParentPanelId';
	Modules.CompIds.DamageSeverityMasterGrid='damageSeverityMasterGridId';
	//Modules.CompIds.DamageSeverityMasterForm='damageSeverityMasterFormId';
	
	Modules.CompIds.TroubleShootAreaMastertabparentpanelID='troubleShootAreaMasterTabParentPanelId';
	Modules.CompIds.TroubleShootAreaMasterGrid='troubleShootAreaMasterGridId';
	//Modules.CompIds.TroubleShootAreaMasterForm='troubleShootAreaMasterFormId';
	
	Modules.CompIds.DelayReasonCodeMastertabparentpanelID='delayReasonCodeMasterTabParentPanelId';
	Modules.CompIds.DelayReasonCodeMasterGrid='delayReasonCodeMasterGridId';
	//Modules.CompIds.DelayReasonCodeMasterForm='delayReasonCodeMasterFormId';
	
	Modules.CompIds.ApplicationParameterMastertabparentpanelID='applicationParameterMasterTabParentPanelId';
	Modules.CompIds.ApplicationParameterMasterGrid='applicationParameterMasterGridId';
	//Modules.CompIds.ApplicationParameterMasterForm='applicationParameterMasterFormId';
	
	Modules.CompIds.UnplannedActivitiesMastertabparentpanelID='unplannedActivitiesMasterTabParentPanelId';
	Modules.CompIds.UnplannedActivitiesMasterGrid='unplannedActivitiesMasterGridId';
	
	Modules.CompIds.ShiftMastertabparentpanelID='shiftMasterTabParentPanelId';
	Modules.CompIds.ShiftMasterGrid='shiftMasterGridId';
	
	Modules.CompIds.AlertCodeMastertabparentpanelID='alertCodeMasterTabParentPanelId';
	Modules.CompIds.AlertCodeMasterGrid='alertCodeMasterGridId';
	//Modules.CompIds.AlertCodeMasterForm='alertCodeMasterFormId';
	
	Modules.CompIds.DirectionMastertabparentpanelID='directionMasterTabParentPanelId';
	Modules.CompIds.DirectionMasterGrid='directionMasterGridId';
	
	Modules.CompIds.LanguageMastertabparentpanelID='languageMasterTabParentPanelId';
	Modules.CompIds.LanguageMasterGrid='languageMasterGridId';
	
	Modules.CompIds.MoveTypeMastertabparentpanelID='moveTypeMasterTabParentPanelId';
	Modules.CompIds.MoveTypeMasterGrid='moveTypeMasterGridId';
	
	Modules.CompIds.TerminalMastertabparentpanelID='terminalMasterTabParentPanelId';
	Modules.CompIds.TerminalMasterGrid='terminalMasterGridId';
	
	Modules.CompIds.RoleMastertabparentpanelID='roleMasterTabParentPanelId';
	Modules.CompIds.RoleMasterGrid='roleMasterGridId';
	
	Modules.CompIds.UserMastertabparentpanelID='userMasterTabParentPanelId';
	Modules.CompIds.UserMasterGrid='userMasterGridId'; 
	
	
	Modules.CompIds.UnitMastertabparentpanelID='unitMasterTabParentPanelId';
	Modules.CompIds.UnitMasterGrid='unitMasterGridId'; 
	//tariq
	Modules.CompIds.RollbackRotationMastertabparentpanelID='rollbackRotationMasterTabParentPanelId';
	//
	
	
	Modules.CompIds.ColorCodeMastertabparentpanelID='colorCodeMasterTabParentPanelId';
	Modules.CompIds.ColorCodeMasterGrid='colorCodeMasterGridId'; 
	
	
	Modules.CompIds.VesselMastertabparentpanelID='vesselMasterTabParentPanelId';
	Modules.CompIds.VesselMasterGrid='vesselMasterGridId'; 
	
	Modules.CompIds.RotationControlMastertabparentpanelID='rotationControlMasterTabParentPanelId';
	Modules.CompIds.RotationControlMasterGrid='rotationControlMasterGridId'; 
	
	Modules.CompIds.YardBlockMastertabparentpanelID='yardBlockMasterTabParentPanelId';
	Modules.CompIds.YardBlockMasterGrid='yardBlockMasterGridId'; 
	
	Modules.CompIds.DamageLocationMastertabparentpanelID='damageLocationMasterTabparentpanelId';
	Modules.CompIds.DamageTypeMastertabparentpanelID='damageTypeMasterTabparentpanelId';
	
	Modules.CompIds.VesselExceptionMastertabparentpanelID= 'vesselExceptionMasterTabparentpanelId';
	
	Modules.CompIds.DelayRecordingMastertabparentpanelID='delayRecordingMasterTabParentPanelId';
	Modules.CompIds.DelayRecordingMasterGrid='delayRecordingMasterGridId'; 
	
	Modules.CompIds.TrailerMastertabparentpanelID='trailerMasterTabParentPanelId';
	Modules.CompIds.TrailerMasterGrid='trailerMasterGridId';

	Modules.CompIds.AlertConfigurationMastertabparentpanelID='alertConfigurationMasterTabParentPanelId';
	Modules.CompIds.AlertConfigurationMasterGrid='alertConfigurationMasterGridId'; 
	
	Modules.CompIds.AlertRecordMastertabparentpanelID='alertRecordMasterTabParentPanelId';
	Modules.CompIds.AlertRecordMasterGrid='alertRecordMasterGridId'; 
	

	Modules.CompIds.WeightageFactorMastertabparentpanelID='weightageFactorMasterTabParentPanelId';
	Modules.CompIds.WeightageFactorMasterGrid='weightageFactorMasterGridId'; 
	
	Modules.CompIds.UserMonitortabparentpanelID='userMonitorTabParentPanelId';
	
	/************************ end *******************/