// ViewEventMessageWindow Labels

Modules.LblsAndTtls.MsgHdrIdLbl=     'Msg Hdr Id';
Modules.LblsAndTtls.MsgHdrIdFullLbl=     'Message Header Id';

Modules.LblsAndTtls.MsgTypeLbl=     'Msg Type';
Modules.LblsAndTtls.MsgTypedFullLbl=     'Message Type';

Modules.LblsAndTtls.PartnerCodeLbl=     'Partner Code';

Modules.LblsAndTtls.ExtCompany= 'Ext Company';
Modules.LblsAndTtls.ExtCompanyFullLbl='External Company';

Modules.LblsAndTtls.ExtSupplierCode= 'External Supplier Code';


Modules.LblsAndTtls.ExtServiceCode= 'External Service Code';
Modules.LblsAndTtls.ServiceType= 'Service Type';



Modules.LblsAndTtls.ExtTransportMode= 'Ext Transport Mode';
Modules.LblsAndTtls.ExtTransportModeFullLbl='External Transport Mode';

Modules.LblsAndTtls.EventLoadRef= 'Event/Load Ref';
Modules.LblsAndTtls.EventLoadRefFullLbl= 'Event/Load Reference#';


Modules.LblsAndTtls.WorkOrder= 'Work Order';


Modules.LblsAndTtls.TransferSequenceNO= 'Transfer Seq Nbr';
Modules.LblsAndTtls.TransferSequenceNOFullLbl= 'Transfer Sequence Number';

Modules.LblsAndTtls.ConveyanceId= 'Conveyance Id';

Modules.LblsAndTtls.ConveyanceName= 'Conveyance Name';

Modules.LblsAndTtls.ConsolidationId= 'Consolidation Id';

Modules.LblsAndTtls.ConsolidationName= 'Consolidation Type';

Modules.LblsAndTtls.ExtConsolidationType= 'Ext Consolidation Type';


Modules.LblsAndTtls.Status= 'Status';


Modules.LblsAndTtls.TenderDate= 'Tender Dt';
Modules.LblsAndTtls.TenderDateFullLbl= 'Tender Date';


Modules.LblsAndTtls.TenderDateEstFlg= 'Tender Dt Estd Flg';
Modules.LblsAndTtls.TenderDateEstFlgFullLbl= 'Tender Date Estimated Flag';

Modules.LblsAndTtls.ShipmentDate= 'Shipment Dt';
Modules.LblsAndTtls.ShipmentDateFullLbl= 'Shipment Date';


Modules.LblsAndTtls.ShipmentDateEstimatedFlg='Shipment Dt Estd Flg';
Modules.LblsAndTtls.ShipmentDateEstimatedFlgFullLbl= 'Shipment Date Estimated Flag';


Modules.LblsAndTtls.DeliveryDate= 'Delivery Dt';
Modules.LblsAndTtls.DeliveryDateFullLbl= 'Delivery Date';


Modules.LblsAndTtls.DeliveryDateEstimatedFlg= 'Delivery Dt Estd Flg';
Modules.LblsAndTtls.DeliveryDateEstimatedFlgFullLbl= 'Delivery Date Estimated Flag';



Modules.LblsAndTtls.ProfitLossCenter='Profit/Loss Center';

Modules.LblsAndTtls.NoOfUnits='Nbr Of Units';
Modules.LblsAndTtls.NoOfUnitsFullLbls='Number Of Units';

Modules.LblsAndTtls.MsgStatusIndicator='Msg Status Indi';
Modules.LblsAndTtls.MsgStatusIndicatorFullLbl='Message Status Indicator';


Modules.LblsAndTtls.ExtOrigin='Ext Origin';

Modules.LblsAndTtls.ExtOriginStateProvince='Ext Origin S/P';
Modules.LblsAndTtls.ExtOriginStateProvinceFullLbl='External Origin State/Province';



Modules.LblsAndTtls.ExtOriginCountry='Ext Origin Country';

Modules.LblsAndTtls.ExtOriginalOrigin='Ext Orgnl Origin';
Modules.LblsAndTtls.ExtOriginalOriginFullLbl='External Original Origin';

Modules.LblsAndTtls.ExtOriginalOriginStateProvince='ExtOrgnl Origin S/P';
Modules.LblsAndTtls.ExtOriginalOriginStateProvinceFullLbl='External Original Origin State/Province';


Modules.LblsAndTtls.ExtOriginalOriginCountry='ExtOrgnl Origin Country';
Modules.LblsAndTtls.ExtOriginalOriginCountryFullLbl='External Original Origin Country';






Modules.LblsAndTtls.OriginCity='Origin City';

Modules.LblsAndTtls.OriginZIPPostalCode='Origin Z/P ';
Modules.LblsAndTtls.OriginZIPPostalCodeFullLbl='Origin Zip/Postal Code';

Modules.LblsAndTtls.OriginAddress1='Origin Adrs 1';
Modules.LblsAndTtls.OriginAddress1FullLbl='Origin Address 1';

Modules.LblsAndTtls.OriginAddress2='Origin Adrs 2 ';
Modules.LblsAndTtls.OriginAddress2FullLbl='Origin Address 2 ';

Modules.LblsAndTtls.OriginalOriginAddress1='Orgnl Origin Adrs 1';
Modules.LblsAndTtls.OriginalOriginAddress1FullLbl='Original Origin Address 1';

Modules.LblsAndTtls.OriginalOriginAddress2='Orgnl Origin Adrs 2';
Modules.LblsAndTtls.OriginalOriginAddress2FullLbl='Original Origin Address 2';


Modules.LblsAndTtls.OriginalOriginCity='Orgnl Origin City';
Modules.LblsAndTtls.OriginalOriginCityFullLbl='Original Origin City';

Modules.LblsAndTtls.OriginalOriginZIPPostalCode='Orgnl Origin Z/P';
Modules.LblsAndTtls.OriginalOriginZIPPostalCodeFullLbl='Original Origin ZIP/Postal Code';

Modules.LblsAndTtls.extMakeCdFull='External Make Code';
Modules.LblsAndTtls.extModelCdFull='External Model Code';
Modules.LblsAndTtls.extModelGrpCdFull='External Model Group Code';
Modules.LblsAndTtls.extAbnormalMoveFull='External Abnormal Move Type';
Modules.LblsAndTtls.extOrderTypeFull='External Order Type';
Modules.LblsAndTtls.previousChrgQtyFull='Pervious Charge Quantity';
Modules.LblsAndTtls.previousChrgUOMCOdeFull='Previous Charge UOM Code';
Modules.LblsAndTtls.extStorageUOMCodeFull='External Storage UOM Code';
Modules.LblsAndTtls.extPreviousChrgUOMCodeFull='External Previous Charge UOM Code';
Modules.LblsAndTtls.extShipmentTypeCodeFull='External Shipment Type Code';
Modules.LblsAndTtls.extRtTrCdFull='External Rate Tier Code';
Modules.LblsAndTtls.extConveyanceTypeFull='External Conveyance Type';
Modules.LblsAndTtls.extDestinationFull='External Dsetination';
Modules.LblsAndTtls.extDestinationStFull='External Destination State/Province';
Modules.LblsAndTtls.extDestinationCountFull='External Destination Country';
Modules.LblsAndTtls.extFinalDestFul='External Final Destination';
Modules.LblsAndTtls.extFinalDestStFull='External Final Dsetination State/Province';
Modules.LblsAndTtls.extFinalDestCountFull='External Final Destination Country';













