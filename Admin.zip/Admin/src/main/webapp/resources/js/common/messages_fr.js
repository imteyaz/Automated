Modules.Msgs.serverError								=	'Server error. Please try later1';
Modules.Msgs.confirmationRequested						=	'Confirmation Requested1';
Modules.Msgs.clearConfirmation							=	'Are you sure you want to clear all the values?1';
Modules.Msgs.deleteConfirmation							=	'Are you sure you want to delete all the values?1';
Modules.Msgs.deleteMultiRecordsConfirmation				=	'Are you sure you want to delete the selected records?1';
Modules.Msgs.deleteSingleRecordConfirmation				=	'Are you sure you want to delete the selected record?1';
Modules.Msgs.unSavedDataLossConfirmation				=   'The unsaved data will be lost.Do you want to continue?1';
Modules.Msgs.deleteSwimPartnerConfirmation              =   'Send Message Agreements have Configured for this Partner. Do you Really Want To Delete?1';
Modules.Msgs.evntRtngQryReRateConfirmation1             =   'Number of Events Selected are 1';
Modules.Msgs.evntRtngQryReRateConfirmation2             =   '.Do You Wish to Continue?1';
Modules.Msgs.saveRecordConfirmation	                    =   'Modified changes will be lost. Do you wish to continue?1';
Modules.Msgs.loading									=	'Loading...1';
Modules.Msgs.processing									=	'Processing...1';
Modules.Msgs.warning									= 	'Warning1';
Modules.Msgs.confirm									= 	'Confirm1';
Modules.Msgs.markDelConfirmation						=	'Are you sure you want to mark selected records for delete?1';
Modules.Msgs.unmarkDelConfirmation						=	'Are you sure you want to un-mark selected records for delete?1';

Modules.Msgs.recordConfirmationTitle					=	'No Records Found1';
Modules.Msgs.recordConfirmationMsg						=	'No records were found for the query parameters provide1';

Modules.Msgs.queryTitles								=	'Query Parameters not provided1';
Modules.Msgs.queryMsg		           					=	'Please provide at least one query parameter to load list of values1';

Modules.Msgs.inValidFormTitle		    				=	'Invalid values1';
Modules.Msgs.inValidFormMsg		        				=	'Please correct the highlighted errors1';

Modules.Msgs.appDatetimeTitle		   					=	'Application Date Time Error1';
Modules.Msgs.appDatetimeMsg		        				=	'Application From Date-Time can not be greater than or equal to Application To Date-Time1';

Modules.Msgs.etaDatetimeTitle		    				=	'ETA Date Time Error1';
Modules.Msgs.etaDatetimeMsg		        				=	'ETA From Date-Time can not be greater than or equal to ETA To Date-Time1';

Modules.Msgs.singleSelectOnly							=	'Please select only one record for this action1';
Modules.Msgs.selectionError								=	'Selection Error1';
Modules.Msgs.selRecFrst									=	'Please select a record1';
Modules.Msgs.noRecsSelected								=	'No record selected1';
Modules.Msgs.noRecordsInGrid                            =   'No Results Found1';
Modules.Msgs.alreadyRunning								= 	'Selected Partner(s) are already in Running Status1';
Modules.Msgs.alreadyStopped								= 	'Selected Partner(s) are already in Stopped Status1';
Modules.Msgs.allalreadyRunning							= 	'Partner\'s are already in Running Status1';
Modules.Msgs.allalreadyStopped							= 	'Partner\'s are already in Stopped Status1';
Modules.Msgs.mixedStateStart							=	'Unable to Start...<br>Some Selected Partner\'s are in Stopped Status1';
Modules.Msgs.mixedStateStop								=	'Unable to Stop...<br>Some Selected Partner\'s are in Running Status1';
Modules.Msgs.formValidation			              		= 	'Mandatory fields need to be entered1';
Modules.Msgs.saveAddedRows			              		=	'Please save the added row(s)first then insert another1';
Modules.Msgs.ValidationNull								= 	'Mandatory fields should not be Empty1';
Modules.Msgs.noRecordsDelete							=	'There are no records to delete1';
Modules.Msgs.ValidationCorrectValue						=	'Please enter correct value1';
Modules.Msgs.noComboValueFound							=	'No Values Found !1';
Modules.Msgs.purgeDetailsQueryParameter					=	'Purge Configuration Details1';
Modules.Msgs.purgeDetailsTabTitle						=	'Purge Configuration1';
Modules.Msgs.eventLogQueryParameter						=	'Event Log1';
Modules.Msgs.clearBtnTooltip							=	'Clear Fields1';
Modules.Msgs.retrieveBtnTooltip							=	'Retrieve Details1';
Modules.Msgs.jobViewTooltip								=	'Job View1';
Modules.Msgs.saveBtnTooltip								=	'Update the Frequency Time Value1';
Modules.Msgs.gridAddBtnTooltip							=	'Add new Records1';
Modules.Msgs.gridDeleteBtnTooltip						=	'Delete Records1';
Modules.Msgs.gridModifyBtnTooltip						=	'Modify Records1';
Modules.Msgs.duplicateGridData							=	'Duplicate row exists for this parameter1';
Modules.Msgs.updtStatusBtnTooltip						=	'Update Status of EDI Messages1';
Modules.Msgs.noRecordsToUpdte							=	'There are no records to update the status1';
Modules.Msgs.errorUpdteSts								=	'Select only records whose msg proc sts is in MAPNOTEXST/SYSERROR/NOAGRMNT1';
Modules.Msgs.saveConfirmation							=	'Do you want to save the data ?1';
Modules.Msgs.noUpdatedValue								=	'Frequency and Time values are same for the Company1';
Modules.Msgs.nullFrequency								=	'PurgeFrequency is Empty1';
Modules.Msgs.wrongFrequency								=	'Incorrect PurgeFrequency Entered1';
Modules.Msgs.nullMsgType								=	'Message Type is Empty1';
Modules.Msgs.duplicateRecordTitle						=	'1';
Modules.Msgs.editingCurrentRecord						=	'Please finish editing the current record1';
Modules.Msgs.editingMode								=	'1';
Modules.Msgs.msgProcSts									=	'Message Processing Status1';
Modules.Msgs.nullValue									=	'1';
Modules.Msgs.failureTitle								=	'1';
Modules.Msgs.messageTitle								=	'1';
Modules.Msgs.confirmTitle								=	'1';
Modules.Msgs.editPurgeGridDataTitle						=	'Purging Days should be a Number1';
Modules.Msgs.popPurgeDaysZero							=	'Purging Days should > 01';
Modules.Msgs.emptyGrid									=	'The Grid is Empty1';
Modules.Msgs.excelReportToolTip							=	'Export to Excel1';
Modules.Msgs.pdfReportToolTip							=	'Export to PDF1';
Modules.Msgs.fileCreateSuccess							=	'Excel File Created Successfully1';
Modules.Msgs.noMatchingRecords							=	'No records for the matching criteria1';
Modules.Msgs.updateDB									=	'Updated Successfully1';
Modules.Msgs.nullValueField								=	'Null value exists1';
Modules.Msgs.PurgeFrequencyDescription					=	'<b>Monthly</b> � Purge the data at the end of every month.<br/><b>Weekly</b> � Purge the data at the end of the week.<br/>(Start of the week (Monday or Saturday) would be set as a parameter at company level.)<br/><b>Daily</b> � Purge the data daily.<br/><b>Bi Weekly</b> � Purge the data on 15th and month end.1';
Modules.Msgs.confirmationMsgToChangeDefault             =   'Default search criteria already exist. Do you want to make current search criteria as default?1';
Modules.Msgs.mandatoryStatus                            =	'Search Criteria Keyword is Mandatory Field1';
Modules.Msgs.internalError                              =   'Some internal error in processing the request1';
Modules.Msgs.savedMessage                               =   'The search criteria keyword saved1';
Modules.Msgs.searchCriteriaKeywordStatus                =	'The search criteria keyword is already exist, Please choose a different keyword1';
Modules.Msgs.selectOnlySingleRecord                     =   'Please select only one single record1';
Modules.Msgs.selectSingleRecord                         =   'Please select one single record1';
Modules.Msgs.selectRecords                              =   'Please select record(s)1';
Modules.Msgs.messageTypeNotEmpty                        =   'Message Type is mandatory field1';
Modules.Msgs.recordSelectSpecificU                      =	'Select records whose Msg Proc Sts is TOBEUPLD and U/D Indicator is U1';
Modules.Msgs.messageTypeDifferentNoSelect               =	'Can not select the records of different message type1';
Modules.Msgs.recordSelectSpecificD                      =	'Select records whose Msg Proc Sts is Error and U/D Indicator is D1';
Modules.Msgs.noUpdation                                 =   'No Updations1';
Modules.Msgs.noEdiFile                                  =   'No edi file available1';
Modules.Msgs.companyCodeMandatory                       =   'Company code is mandatory field1';
Modules.Msgs.gridSaveBtnTooltip							=	'Save the Modified Records1';
Modules.Msgs.noDataInGrid								=	'No Results Found1';
Modules.Msgs.gridPopupToolTip							=	'Popup window1';

Modules.Msgs.noRecordForGrid                            =   'No Records found for current criteria.1';
Modules.Msgs.fromDateMandatory                          =   'From date mandatory1';
Modules.Msgs.dateMandatory                              =   'Date mandatory1';
Modules.Msgs.TimeWithoutDateMandatory  					=	'Time with out date is not allowed1';
Modules.Msgs.searchCriteriaSaveToolTip                  =   'Search criteria will be saved 1';
Modules.Msgs.errorCorrectionUploadNotAllowed            =   'Upload not applicable for outbound message type1';
Modules.Msgs.errorCorrectionDownloadNotAllowed          =   'Download not applicable for inbound message type1';

Modules.Msgs.fromDateToDateValidation					=	'From Date is greater than To Date1';	


Modules.Msgs.noRecordForGrid                            =   'No Records found for current criteria1';
Modules.Msgs.invalidMsgType								=	'Message Type is Invalid1';
Modules.Msgs.duplicateMsgType							=	'Duplicate Message Type Entered1';
Modules.Msgs.gridCopyBtnTooltip							=	'Enter Record you want to Copy1';
Modules.Msgs.gridPasteBtnTooltip						=	'Paste Copied Record into Grid1';

Modules.Msgs.nullCopyFieldValue							=	'No Copied Data to Paste1';

Modules.Msgs.partnerViewToolTip							=	'Partner View1';

Modules.Msgs.invalidEvntLogFormData						=	'Invalid Data Entered1';

Modules.Msgs.sMsResendMessageTypeValidate				=   'Resend Not Applicable for Inbound Message Type1';
Modules.Msgs.sMsResendTransAndProcessValidate			=   'Select Only Records Whose Msg Trns Status is "MSGSENT" And Msg Proc Status is "DOWNLOADED" for Resend1';

Modules.Msgs.invalidEvntLogDateFormat					=	'Invalid Date Format1';
Modules.Msgs.deleteSuccess								=	'Deleted Successfully1';
Modules.Msgs.saveSuccess								=	'Saved Successfully1';
Modules.Msgs.evntLoadRef								=	'Event/Load Reference1';
Modules.Msgs.transferSeqNbr								=	'Transfer Sequence Number1';
Modules.Msgs.prevChrgdQty								=	'Previous Charged Quantity1';
Modules.Msgs.prevChrgdUomCd								=	'Previous Charged UOM Code1';
Modules.Msgs.storeUomCd									=	'Storage UOM Code1';


Modules.Msgs.copyFromBtnTooltip							=	'Copy From1';
Modules.Msgs.deSelectAllBtnTooltip						=	'DeSelect All Records1';
Modules.Msgs.selectAllBtnTooltip						=	'Select All Records1';



Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory1';
Modules.Msgs.customerMandatoryMsg 						= 	'Customer is mandatory1';



Modules.Msgs.ediFileNotExistMsg							=   'EDI File Doest Not Exist1';


Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory1';

Modules.Msgs.storageQtyMsg								=	'Storage Quantity is mandatory1';
Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory1';
Modules.Msgs.duplicateRecord							= 'Record already exists in Database1';



Modules.Msgs.nullCustmrCd						=	'Customer is Empty1';
Modules.Msgs.invalidCustmrCd					=	'Invalid Customer1';
Modules.Msgs.nullSrvGrpCd						=	'Service Group is Empty1';
Modules.Msgs.nullSrvGrpDesc						=	'Service Group Description is Empty1';
Modules.Msgs.nullSrvType						=	'Service Type is Empty1';
Modules.Msgs.nullSrvCd							=	'Service Code is Empty1';
Modules.Msgs.nullSrvCdDesc						=	'Service Code Description is Empty1';
Modules.Msgs.validateCustCodeSrvGrp				=	'Select a Customer and Service Group1';
Modules.Msgs.doneRecordConfirmation	            =   'Data has been modified.Do you want to update in Grid?1';
Modules.Msgs.noSearchCriteria					=	'Please enter at least one search criteria1';	
Modules.Msgs.invalidSearchData					=	'Search form contains invalid data1';	

/******* #CUSTOMER_RATE_QUERY ***********************/
Modules.contract.customer_rate_query.messages.enterCriteria = Modules.Msgs.noSearchCriteria;

Modules.Msgs.changesLostConfirmMsg				=	'Modified changes will be Lost. Do you wish to continue?1';
Modules.Msgs.amTypeMandatory					=	'Abnormal Move Type is mandatory1';
Modules.Msgs.fromDateMandatory					=	'From Date is mandatory1';
Modules.Msgs.toDateMandatory					=	'To Date is mandatory1';
Modules.Msgs.validatePartySrvGrp				=	'Please enter party and Service Group to add new Detail1';



/*** Starting of Ocean Customer Invoice Generation Screen ***/

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.blNumber = 'Bill of Lading Number1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.pol = 'Port of Load1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.pod = 'Port of Discharge1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.por = 'Port of Receipt1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.pfd = 'Port of Final Destination1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.pop = 'Place of Payment1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.shipRefNbr = 'Shipping Reference Number1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.blCmplFmDt = 'Bill of Lading Completion From Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.blCmplToDt = 'Bill of Lading Completion To Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.messages.blCmplDate = 'Bill of Lading Completion Date1';

/*** Ending of Ocean Customer Invoice Generation Screen ***/




/******* #EVENT_RATING_QUERY FOR OCEAN ***********************/

Modules.ocean.operations.event_details.event_rating_query.messages.popWindowToolTip = 'Single Record View1';


/***************#CUSTOMER_MASTER************************/
Modules.contract.customer_master.messages.selectCustomerMasterRecord='Please select a record from Customer Details Grid1';
//Modules.contract.supplier_master.messages.selectSupplierMasterRecord='Please select a record from Supplier Details Grid1';
Modules.Msgs.selectSupplierMasterRecord = 'Please select a record from Supplier Details Grid1';
/*******# Customer Invoice Entry ***********************/
Modules.Msgs.info='INFO1';
Modules.Msgs.userRestriction = 'User is restricted to enter only one Invoice at a time1';
Modules.Msgs.cutomerCodeMandatory = 'Customer Code is mandatory field1';
Modules.Msgs.prftLosCentSetupNotIdentfd = 'Profit/Loss centre setup Not Identified in the Profit/Loss centre Identification Master1';
Modules.Msgs.prftLosCentSetupNotMatch = 'Profit/Loss centre not matching with profit/loss centre setup1';
Modules.Msgs.invcSaveConfirmation = 'Invoice Will Generate With This  Amount. Do you Wish To Continue?1';
/*******# special move entry ***********************/


Modules.Msgs.cutomerMandatory				=		'Customer is mandatory1';
Modules.Msgs.supplierMandatory				=		'Supplier is mandatory1';
Modules.Msgs.departmentMandatory				=		'Department is mandatory1';
Modules.Msgs.phoneMandatory					=		'Phone is mandatory1';
Modules.Msgs.emailMandatory					=		'Email is mandatory1';
Modules.Msgs.orderTypeMandatory				=		'Order Type is mandatory1';
Modules.Msgs.abnormalMoveMandatory			=		'Abnormal Move is mandatory1';
Modules.Msgs.originMandatory					=		'Origin is mandatory1';
Modules.Msgs.destinationMandatory			=		'Destination is mandatory1';
Modules.Msgs.transportModeMandatory			=		'Transport Mode is mandatory1';
Modules.Msgs.conveyanceMandatory				=		'Conveyance Type is mandatory1';
Modules.Msgs.profitLossModeMandatory			=		'Profit/Loss Mode is mandatory1';
Modules.Msgs.serviceCodeMandatory			=		'Service Code is mandator1';
Modules.Msgs.noRecordInGridModeMandatory		=		'No records in the Grid1';
Modules.Msgs.unitIdMandatory					=		'UnitId is mandatory1';
Modules.Msgs.makeCodeMandatory				=		'Make is mandator1';
Modules.Msgs.modelMandatory					=		'Model is mandator1';
Modules.Msgs.customerSalesRGNMandatory		=		'Customer Sales RGN is mandator1';
Modules.Msgs.toDoCancelMessage				=       'To do CANCEL first UNLOCK the request.1';
Modules.Msgs.toDoCancelConfirmMessage		=	'You are trying to CANCEL. Do you want to Proceed?1';
Modules.Msgs.toDoUnLockConfirmMessage		=   'You are trying to Unlock.Do you want to Proceed?1';
Modules.Msgs.toDoLockConfirmMessage		    =   'You are trying to lock.Do you want to Proceed?1';
Modules.Msgs.toDoRateConfirmMessage		    =   'You are trying to Rate. Do you want to Proceed?1';
Modules.Msgs.serviceGroupCodeMandatoryMessage= 	'Service Group Code is Mandatory1';
Modules.Msgs.debtoryPartyCodeMessage		=	'Debtor Party Code is Mandatory1';
Modules.Msgs.supplierExpenseCodeCodeMandatory = 'Expense Code is Mandatory1';
Modules.Msgs.supplierCurrencyMandatory		  = 'Currency is Mandatory1';
Modules.Msgs.supplierServiceAmountMandatory   =   'Service Amount is Mandatory1';
Modules.Msgs.customerGLCodeCodeMandatory = 'GLCode is Mandatory1';
Modules.Msgs.customerCurrencyMandatory		  = 'Currency is Mandatory1';
Modules.Msgs.customerServiceAmountMandatory   =   'Service Amount is Mandatory1';
Modules.Msgs.customerRatingDetailsMandatory   =   'Customer rating details are Mandatory1';
Modules.Msgs.notEditableMsg					  =    'Update not allowed in this filed1';
Modules.Msgs.clearConfirmationMsg			  =    'You are trying to clear the data. You may loss the unsaved data.Do you want to continue?1';

/********************** Ocean Customer Service Group Setup ************************************/

Modules.Msgs.nullPopCd							=	'Pop Code is Empty1';
Modules.Msgs.invalidPartyCd						=	'Invalid Party1';
Modules.Msgs.validatePartyCodeSrvGrp			=	'Select a Party and Service Group1';
Modules.Msgs.nullChrgCd							=	'Service Code is Empty1';
Modules.Msgs.nullChrgCdDesc						=	'Service Code Description is Empty1';
Modules.Msgs.popCd								=	'Place of Payment Code1';
Modules.Msgs.popCdDesc							=	'Place of Payment City Name1';
Modules.Msgs.srvcGrpDesc						=	'Service Group Description1';


/***************************************************************
 * 
 * Messages for Customer Invoice Status
 * 
 ***************************************************************/
Modules.Msgs.noInvoiceSelectMsg					=	'No invoice is selected for Printing.1';
Modules.Msgs.selectInvoiceOrBackUpFlgMsg		=	'Please Select Invoice or BackUp Flag1';
Modules.Msgs.selectOneInvoiceAtOneTimeMsg		=	'Only one invoice can be viewed at a time.Please select only one record.1';
Modules.Msgs.cCMailIdMandatoryMsg				=	'CC Mail ID is mandatory.1';
Modules.Msgs.RecordUdatedSuccessMsg 			=	'Record Updated Successfully.1';
Modules.Msgs.invoicePrinterMandatoryMsg 		=	'Invoice Printer is mandatory.1';
Modules.Msgs.backUpPrinterMandatoryMsg			=	'BackUp Printer is mandatory.1';
Modules.Msgs.supplier_invoiceenterCriteria      =   'At least one of the status fields should be checked.1';
Modules.Msgs.supplier_invoicedocumententerCriteria     =   'At least one of the Document Type fields should be checked1';
Modules.Msgs.FileNotCreatedYet                  =   'File is not created Yet.1';
Modules.Msgs.ReverseForInvoiceType              =   'Reverse will be performed for invoice type as accrual.1';
Modules.Msgs.SupplierInvoiceDueDateMandatory    =  'Due Date is mandatory to SubmitReconcile the record.1';
Modules.Msgs.SupplierInvoiceSelectRecord        =  'Select atleast one record.1';
Modules.Msgs.SupplierInvoiceSelectRecProf       =  'Select only records whose invoice status as proforma.1';
Modules.Msgs.InvoiceDueDateMandatory            =  'Invoice Due Date is Mandatory.1';
Modules.Msgs.InvoiceDateGreatThanCurrent        = 'Invoice Due Date should be greater than Current Date.1';
Modules.Msgs.InvoiceGreatthanInvoiceDate        =  'Invoice Due Date should be greater than Invoice Date.1';

/****  Supplier Line Item Status Screen ****/

Modules.supplier_invoice.supplier_line_item_status.messages.eventLoadReference='Event/Load Reference1';
Modules.supplier_invoice.supplier_line_item_status.messages.shippimngReference='Shipping Reference1';

/***************************************************************
 * 
 * Messages for Customer Rate Query 
 * 
 ***************************************************************/
Modules.Msgs.anySingleQueryParamMandatoryMsg			=	'Atleast one query parameter should be entered.1';
Modules.Msgs.oldContractIdMandatory						=	'Old Contract ID is Mandatory1';
Modules.Msgs.newContractCreatedMsg						=	'New Contrates Created1';
Modules.Msgs.invalidOldContractIdMsg					=	'Old Contract ID is invalid1';
Modules.Msgs.srvEffDtEnableFlgInvalidMsg				=	'Copy of Service Level Valid Dates Flag Enabled Copy Contract Is Not Possible1';
Modules.Msgs.noProperDataMsg					=	'No proper data available1';
Modules.Msgs.retrieveWithOutSaving					=	'Modified changes will be lost.Do you wish to continue?1';


/***************************************************************
 * 
 * Messages for Ocean Customer Invoice Entry 
 * 
 ***************************************************************/
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.messages.partyCodeMandatory = 'Party is Mandatory1';



/************
 * 
 * Admin Group Screen Messages
 * 
 ****************/
Modules.admin.user_admin.group_user_security.messages.selectGroup='Please select a group1.';
Modules.admin.user_admin.group_user_security.messages.deleteGroupConfirmation='This action deletes the Group and all associations will be removed. Do you want  to continue1?';
Modules.admin.user_admin.group_user_security.messages.deletedSuccessfully='Deleted successfully1';
Modules.admin.user_admin.group_user_security.messages.selectGroupToDelete='Please select a group to delete1.';
Modules.admin.user_admin.group_user_security.messages.selectGroupToCopy='Please select a group to copy1.';
Modules.admin.user_admin.group_user_security.messages.changeServiceType='Are you sure you want to change the Service Type, Any modified data will be lost1?';
Modules.admin.user_admin.group_user_security.messages.requiredServiceType ='Service Type is Required1';
Modules.admin.user_admin.group_user_security.messages.requiredGroupCode ='Group Code is Required1';
Modules.admin.user_admin.group_user_security.messages.requiredGroupName='Group Name is Required1';
Modules.admin.user_admin.group_user_security.messages.maxGroupCode='The maximum length for Group Code is 101.';
Modules.admin.user_admin.group_user_security.messages.maxGroupName='The maximum length for Group Name is 301.';
Modules.admin.user_admin.group_user_security.messages.maxGroupDesc='The maximum length for Group Description is 301.';
Modules.admin.user_admin.group_user_security.messages.noFunctionAssociatedWithGroup='No Function has been associated with the group under the specified module1.';


