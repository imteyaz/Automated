/**
 * Author : Imran Rawani
 * 
 * contains common regular expressions used throughout the application.
 */

var mobileRegex = /^(\+97[\s]{0,1}[\-]{0,1}[\s]{0,1}1|0)(2|3|4|6|7|9|50|52|55|56)[\s]{0,1}[\-]{0,1}[\s]{0,1}[1-9]{1}[0-9]{6}$/ ;

var lastNameRegex =  /^[a-z\s.]{2,20}$/i ;

var firstNameRegex =  /^[a-z\s.]{2,20}$/i ;

var userNameRegex =  /^[a-z\d\-_.\s]{2,18}$/i  ;

var ipAddressRegex =  /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

var portNoRegex = /^[\d]{1,5}$/ ;  //	65535 

var hexaCodeRegex = /^#[0-9A-F]{6}$/i ; 

var sixDigit2DecimalRegex = /^[+-]?\d{1,4}(\.\d{1,2})?$/ ;  

var floatingRegex  = /^[+-]?\d+(\.\d+)?$/ ;

var expiryRegex = /^[\d]{1,20}$/ ;
		
/**
 * Author : Imran Rawani
 * 
 * contains common regular expressions used throughout the application for master screens
 */


var masterFieldRegex =  /^[a-z\d\-_.\s]{2,18}$/i  ;

var primarkKeyNoRegex = /^[\d]{1,10}$/ ;

var yardHeightRegex = /^[\d]{1,2}$/ ;

var seqNoRegex = /^[\d]{1,6}$/ ;

var vesselLabelRegex = /^[\d]{1,3}$/ ;

var alphaNumericRegex = /^[a-z\d]{1,20}$/i ; 