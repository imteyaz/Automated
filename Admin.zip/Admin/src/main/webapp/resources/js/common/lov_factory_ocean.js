Modules.ocean.LovFactory = {
	/**
	 * 
	 * @param config
	 * @returns
	 */
	getPolLov: function (config) {
		config = config || {};
		var polStoreConf = Ext.apply({
			model: 'genericPolList',
			url: 'commonOceanLov/getPortList',
			paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;				
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;
		
		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: polStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.LblsAndTtls.pol,
			displayField: 'portCode',
			valueField: 'portCode',
			matchFieldWidth: false,
			 columnsCmc:[{
					header:'Code',
					width:70,
					dataIndex:'portCode'
				},{
					header:'Description',
					width:100,
					dataIndex:'portName'
				},{
					header:'Address1',
					width:100,
					dataIndex:'addrs1'
				},{
					header:'Address2',
					width:100,
					dataIndex:'addrs2'
				},{
					header:'City',
					width:60,
					dataIndex:'cityName'
				},{
					header:'State',
					width:70,
					dataIndex:'stateCode'
				},{
					header:'Currency',
					width:80,
					dataIndex:'currencyCode'
				},{
					header:'Country',
					width:80,
					dataIndex:'cntryCd'
				},{
					header:'PIN',
					width:70,
					dataIndex:'poBox'
				}]
			/*listConfig: {
				width: 500,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{portCode}</td><td width="150px" align="left">{portName}</td><td width="150px" align="left">{addrs1}</td><td width="150px" align="left">{addrs2}</td><td width="150px" align="left">{cityName}</td><td width="150px" align="left">{stateCode}</td><td width="150px" align="left">{currencyCode}</td><td width="150px" align="left">{countryCode}</td><td width="150px" align="left">{poBox}</td></tr></table>';
				}
			}*/
		}, config));
	},
	/**
	 * 
	 * @param config
	 * @returns {Ext.cmc.ComboBox}
	 */
	getPopLov: function (config) {
		config = config || {};
		var popStoreConfig = Ext.apply({
			model: 'popList',
			url: 'commonOceanLov/getPopList',
			paging: true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;
		// for user security default POP value
		
		var userDefaultProperties=Modules.GlobalVars.userDefaultProperties;
		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: popStoreConfig,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.LblsAndTtls.pop,
			toolTipCmc:Modules.Ocean.CustInvcSetup.labels.poptoolTip, 
			displayField: 'popCode',
			valueField: 'popCode',
			matchFieldWidth: false,
			value : userDefaultProperties.defaultPopCode!= undefined ? userDefaultProperties.defaultPopCode : '',
					columnsCmc:[{
						header:'Pop Code',
						width:100,
						dataIndex:'popCode'
					},{
						header:'Pop Description',
						width:200,
						dataIndex:'popName'
					},{
						header:'Address1',
						width:200,
						dataIndex:'addrs1'
					},{
						header:'City',
						width:100,
						dataIndex:'cityName'
					},{
						header:'Country',
						width:100,
						dataIndex:'countryCode'
					},{
						header:'State',
						width:100,
						dataIndex:'stateCode'
					},{
						header:'Post',
						width:100,
						dataIndex:'poBox'
					}]			
			
		}, config));
	},
	
	getSupplierLov: function (config) {
		config = config || {};
		var supplierStoreConf = Ext.apply({
			model: 'OcnSuplrLookUpDTO',
			queryTypeCmc:'remote',
			url:'commonOceanLov/getOcnSupplierCode',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;

		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: supplierStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.ocean.lov_factory.labels.supplier,
			displayField: 'supplrCd',
			valueField: 'supplrCd',
			matchFieldWidth: false,
			columnsCmc:[{
					header:'Code',
					width:100,
					dataIndex:'supplrCd'
				},{
					header:'Name',
					width:150,
					dataIndex:'supplrNm'
				},{
					header:'Address 1',
					dataIndex:'addrs1'
				},{
					header:'City',
					width:100,
					dataIndex:'cityNm'
				},{
					header:'State',
					width:50,
					dataIndex:'stateCd'
				},{
					header:'Country',
					width:80,
					dataIndex:'countryCd'
				},{
					header:'PIN',
					width:50,
					dataIndex:'poBox'
				}]
		}, config));
	},
	
	getInvoiceNumberLOV: function (config) {
		config = config || {};
		var invoiceNumberStoreConf = Ext.apply({
			model: 'OcnInvoiceNumberLookUpDTO',
			queryTypeCmc:'remote',
			url:'commonOceanLov/getInvoiceNumbers',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
					//this.proxy.extraParams.cstmrCd = '00956';
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;
		
		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: invoiceNumberStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.customer_invoice.customer_application_advice.labels.cstmrApplAdvInvoiceNumber,
			displayField: 'invc_no',
			valueField: 'invc_no',
			matchFieldWidth: false,
			columnsCmc:[{
				header:'Invoice Number',
				width:150,
				dataIndex:'invc_no'
			},{
				header:'Invoice Credit Date',
				width:150,
				dataIndex:'invc_crdt_dttm'
			},{
				header:'Invoice Due Date',
				width:150,
				dataIndex:'invc_due_dttm'
			},{
				header:'Customer Code',
				width:150,
				dataIndex:'cstmr_cd'
			},{
				header:'Company Code',
				width:150,
				dataIndex:'cmpny_cd'
			}]
			/*listConfig: {
				width: 500,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{invc_no}</td><td width="150px" align="left">{invc_crdt_dttm}</td><td width="150px" align="left">{invc_due_dttm}</td><td width="150px" align="left">{cstmr_cd}</td><td width="150px" align="left">{cmpny_cd}</td></tr></table>';
				}
			}*/
		}, config));
	},
	
	getSupInvoiceNumberLOV: function (config) {
		config = config || {};
		var supInvoiceNumberStoreConf = Ext.apply({
			model: 'OcnInvoiceNumberLookUpDTO',
			queryTypeCmc:'remote',
			url:'commonOceanLov/getSupInvoiceNumberLOV',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;					
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;
		
		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: supInvoiceNumberStoreConf,
			selectOnTab: true,
			labelAlign: "left",			
			displayField: 'invc_no',
			valueField: 'invc_no',
			matchFieldWidth: false,
			listConfig: {
				width: 500,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{invc_no}</td><td width="150px" align="left">{invc_crdt_dttm}</td><td width="150px" align="left">{invc_due_dttm}</td><td width="150px" align="left">{supplier_cd}</td><td width="150px" align="left">{cmpny_cd}</td></tr></table>';
				}
			}
		}, config));
	},
	
	getServiceCodeLov: function (config) {
		config = config || {};
		var serviceCodeStoreConf = Ext.apply({
			model: 'GenericSrvcCodeLookUpDto',
			queryTypeCmc:'remote',
			url:'getServiceCodeDTOListLookUP',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
//					this.proxy.extraParams.serviceType = Modules.GlobalVars.selectedServiceTypeCode;
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;

		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: serviceCodeStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.ocean.lov_factory.labels.serviceCode,
			displayField: 'serviceCode',
			valueField: 'serviceCode',
			matchFieldWidth: false,
			columnsCmc:[
	                    {
	                    	header:'Service Code',
	                    	width:100,
	                    	dataIndex:'serviceCode'
	                    },{
	                    	header:'Service Description',
	                    	width:170,
	                    	dataIndex:'serviceDesc'
	                    }
	                    ]
			/*listConfig: {
				width: 300,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="3"></td><td height="3"></td></tr><tr valign="top"><td width="80px" align="left">{serviceCode}</td><td width="200px" align="left">{serviceDesc}</td></tr></table>';
				}
			}*/
		}, config));
	},
	getCustomerCodeLov: function (config) {
		config = config || {};
		var customerCodeStoreConf = Ext.apply({
			model: 'GenericSuplrCustmerLookUpDTO',
			queryTypeCmc:'remote',
			url:'getCustomers',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;

		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: customerCodeStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.ocean.lov_factory.labels.customerCode,
			displayField: 'code',
			valueField: 'code',
			matchFieldWidth: false,
			listConfig: {
				width: 500,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td><td width="150px" align="left">{addr_1}</td><td width="70px" align="left">{addr_2}</td><td width="100px" align="left">{city_nm}</td><td width="50px" align="left">{state_cd}</td><td width="50px" align="left">{cntry_cd}</td><td width="50px" align="left">{po_box}</td><td width="150px" align="left">{rmrk}</td> </tr></table>';
				}
			}
		}, config));
	},
	getModelCodeLov: function (config) {
		config = config || {};
		var modelCodeStoreConf = Ext.apply({
			model: 'ModelLookUpDTO',
			queryTypeCmc:'remote',
			url:'getModelCode',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.maxRecs = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;

		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: modelCodeStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.ocean.lov_factory.labels.modelCode,
			displayField: 'code',
			valueField: 'code',
			matchFieldWidth: false,
			listConfig: {
				width: 400,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="150px" align="left">{name}</td><td width="150px" align="left">{reference}</td> </tr></table>';
					}
			}
		}, config));
	},
	getMakeCodeLov: function (config) {
		config = config || {};
		var makeCodeStoreConf = Ext.apply({
			model: 'GenericLookUpDTO',
			queryTypeCmc:'remote',
			url:'getMakeCode',
			paging:true,
			listeners : {
				beforeload:function(){
					//for sending selected values to controller
					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.maxRecs = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.maxRecs = Modules.GlobalVars.maxLimitRecords;
				}
			}
		},
		config.storeConfig || {});
		delete config.storeConfig;

		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			storeObjCmc: makeCodeStoreConf,
			selectOnTab: true,
			labelAlign: "left",
			fieldLabel: Modules.ocean.lov_factory.labels.makeCode,
			displayField: 'code',
			valueField: 'code',
			matchFieldWidth: false,
			listConfig: {
				width: 500,
				loadingText: Modules.Msgs.loading,
				height: 300,
				deferEmptyText: false,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td></tr></table>';
				}
			}
		}, config));
	},
    getStateProvLov: function (config) {
        config = config || {};

        var stateProvStoreConf = Ext.apply({
    		model : 'StateProvinceLookUpDTO',
    		queryTypeCmc : 'remote',
    		url : 'commonLov/getStateProvinceLOV',
    		paging : true,
    		listeners : {
    			beforeload : function() {
    				this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                    this.proxy.extraParams.maxRecs = Modules.GlobalVars.maxLimitRecords;
    			}
    		}
    	},
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: stateProvStoreConf,
            triggerAction: 'all',
            typeAhead: true,
            paging: true,
            selectOnTab: true,
            labelAlign: "left",
            displayField: 'state_cd',
            valueField: 'state_cd',
            matchFieldWidth: false,
            columnsCmc:[{
    			header:'State Code',
    			width:80,
    			dataIndex:'state_cd'
    		},{
    			header:'State Name',
    			width:150,
    			dataIndex:'state_nm'
    		},{
    			header:'Country Code',
    			width:100,
    			dataIndex:'cntry_cd'
    		},{
    			header:'Country Name',
    			width:150,
    			dataIndex:'cntry_nm'
    		}]/*,
            listConfig: {
				loadingText: Modules.Msgs.loading,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{state_cd}</td><td width="90px" align="left">{state_nm}</td><td width="90px" align="left">{cntry_cd}</td><td width="100px" align="left">{cntry_nm}</td></tr></table>';
				}
			}*/
        }, config));
    },
    getServiceTypeLov: function (config) {
        config = config || {};

        var serviceTypeStoreConf = Ext.apply({
    		model : 'genericLookUp',
    		queryTypeCmc : 'remote',
    		url : 'commonOceanLov/getOceanServiceTypeCode',
    		paging : true,
    		listeners : {
    			beforeload : function() {
    				this.proxy.extraParams.srvcGrpCd = 'O';
    			}
    		}
    	},
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: serviceTypeStoreConf,
            triggerAction: 'all',
            typeAhead: true,
           paging: true,
          selectOnTab: true,
            displayField: 'code',
            valueField: 'code',
            matchFieldWidth: false,
            /*listConfig: {
				loadingText: Modules.Msgs.loading,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{code}</td><td width="90px" align="left">{name}</td></tr></table>';
				}
			}*/
            columnsCmc:[
                        {
                        	header:'Description',
                        	width:100,
                        	dataIndex:'name'
                        },{
                        	header:'Type',
                        	width:170,
                        	dataIndex:'code'
                        }
]
        }, config));
    },
    
    getPartyTypeLov: function (config) {
        config = config || {};

        var partyTypeStoreConf = Ext.apply({
    		model : 'GenericLookUpDTO',
    		queryTypeCmc : 'remote',
    		url : 'commonOceanLov/getPartyTypeCode',
    		paging : true,
    		listeners : {
    			beforeload : function() {
    				
    			}
    		}
    	},
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: partyTypeStoreConf,
            triggerAction: 'all',
            typeAhead: true,
            paging: true,
            selectOnTab: true,
            displayField: 'code',
            valueField: 'code',
            matchFieldWidth: false,
            listConfig: {
				loadingText: Modules.Msgs.loading,
				emptyText: Modules.Msgs.noComboValueFound,
				getInnerTpl: function () {
					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{code}</td><td width="90px" align="left">{name}</td></tr></table>';
				}
			}
        }, config));
    },
    
    getPrintTemplateLov: function (config) {
        config = config || {};

        var printTemplateStoreConf = Ext.apply({
    		model : 'GenericLookUpDTO',
    		queryTypeCmc : 'remote',
    		url : 'commonOceanLov/getPrintTemplateCode',
    		paging : true,
    		listeners : {
    			beforeload : function() {
    				this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
    				
    			}
    		}
    	},
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: printTemplateStoreConf,
            triggerAction: 'all',
            typeAhead: true,
            paging: true,
            selectOnTab: true,
            displayField: 'code',
            valueField: 'code',
            matchFieldWidth: false,
//            listConfig: {
//				loadingText: Modules.Msgs.loading,
//				emptyText: Modules.Msgs.noComboValueFound,
//				getInnerTpl: function () {
//					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{code}</td><td width="90px" align="left">{name}</td></tr></table>';
//				}
//			}
            columnsCmc:[{
				header:'Code',
				width:70,
				dataIndex:'code'
			},{
				header:'Name',
				width:100,
				dataIndex:'name'
			}]
            
            
        }, config));
    },
    
 

    //},
      /**
     * POD, PFD, PRD are using common URL
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getPodLov: function (config) {

        config = config || {};

        var podStoreConfig = Ext.apply({
            model: 'portList',
            url: 'commonOceanLov/getPortList',
            paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;				
				}
			}
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: podStoreConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.pod,
            displayField: 'portCode',
            valueField: 'portCode',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Code',
				width:70,
				dataIndex:'portCode'
			},{
				header:'Description',
				width:100,
				dataIndex:'portName'
			},{
				header:'Address1',
				width:100,
				dataIndex:'addrs1'
			},{
				header:'Address2',
				width:100,
				dataIndex:'addrs2'
			},{
				header:'City',
				width:60,
				dataIndex:'cityName'
			},{
				header:'State',
				width:60,
				dataIndex:'stateCode'
			},{
				header:'Currency',
				width:80,
				dataIndex:'currencyCode'
			},{
				header:'Country',
				width:80,
				dataIndex:'cntryCd'
			},{
				header:'PIN',
				width:70,
				dataIndex:'poBox'
			}]/*,
            listConfig: {
                width: 700,
                loadingText: Modules.Msgs.loading,
                height: 300,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	 return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{portCode}</td><td width="150px" align="left">{portName}</td><td width="150px" align="left">{addrs1}</td><td width="150px" align="left">{addrs2}</td><td width="60px" align="left">{cityName}</td><td width="50px" align="left">{stateCode}</td><td width="50px" align="left">{crncyCd}</td><td width="50px" align="left">{cntryCd}</td><td width="50px" align="left">{poBox}</td></tr></table>';
                	 }
            }*/
        }, config));
    },
    
    /**
     * POD, PFD, PRD are using common URL
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getPodCountryLov: function (config) {

        config = config || {};

        var podCountryStoreConfig = Ext.apply({
            model: 'portList',
            url: 'commonOceanLov/getPortCountryList',
            paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;				
				}
			}
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: podCountryStoreConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.podCountryCd,
            displayField: 'cntryCd',
            valueField: 'cntryCd',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Country Code',
				width:50,
				dataIndex:'cntryCd'
			}]
        }, config));
    },
    
    
    /**
     * POD, PFD, PRD are using common URL
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getPfdLov: function (config) {

        config = config || {};

        var pfdStoreConfig = Ext.apply({
            model: 'portList',
            url: 'commonOceanLov/getPortList',
            paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;				
				}
			}
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: pfdStoreConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.pfd,
            displayField: 'portCode',
            valueField: 'portCode',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Code',
				width:70,
				dataIndex:'portCode'
			},{
				header:'Description',
				width:100,
				dataIndex:'portName'
			},{
				header:'Address1',
				width:100,
				dataIndex:'addrs1'
			},{
				header:'Address2',
				width:100,
				dataIndex:'addrs2'
			},{
				header:'City',
				width:60,
				dataIndex:'cityName'
			},{
				header:'State',
				width:60,
				dataIndex:'stateCode'
			},{
				header:'Currency',
				width:80,
				dataIndex:'currencyCode'
			},{
				header:'Country',
				width:80,
				dataIndex:'countryCode'
			},{
				header:'PIN',
				width:70,
				dataIndex:'poBox'
			}]
         /*   listConfig: {
                width: 500,
                loadingText: Modules.Msgs.loading,
                height: 300,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	 return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{portCode}</td><td width="150px" align="left">{portName}</td><td width="150px" align="left">{addrs1}</td><td width="150px" align="left">{addrs2}</td><td width="60px" align="left">{cityName}</td><td width="50px" align="left">{stateCode}</td><td width="50px" align="left">{crncyCd}</td><td width="50px" align="left">{cntryCd}</td><td width="50px" align="left">{poBox}</td></tr></table>';
                	 }
            }*/
        }, config));
    },
    /**
     * POD, PFD, PRD are using common URL
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getPorLov: function (config) {

        config = config || {};

        var porStoreConfig = Ext.apply({
            model: 'portList',
            url: 'commonOceanLov/getPortList',
            paging:true,
			listeners : {
				beforeload:function(){
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;				
				}
			}
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: porStoreConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.por,
            displayField: 'portCode',
            valueField: 'portCode',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Code',
				width:70,
				dataIndex:'portCode'
			},{
				header:'Description',
				width:100,
				dataIndex:'portName'
			},{
				header:'Address1',
				width:100,
				dataIndex:'addrs1'
			},{
				header:'Address2',
				width:100,
				dataIndex:'addrs2'
			},{
				header:'City',
				width:60,
				dataIndex:'cityName'
			},{
				header:'State',
				width:60,
				dataIndex:'stateCode'
			},{
				header:'Currency',
				width:80,
				dataIndex:'currencyCode'
			},{
				header:'Country',
				width:80,
				dataIndex:'countryCode'
			},{
				header:'PIN',
				width:70,
				dataIndex:'poBox'
			}]
           /* listConfig: {
                width: 500,
                loadingText: Modules.Msgs.loading,
                height: 300,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	 return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{portCode}</td><td width="150px" align="left">{portName}</td><td width="150px" align="left">{addrs1}</td><td width="150px" align="left">{addrs2}</td><td width="60px" align="left">{cityName}</td><td width="50px" align="left">{stateCode}</td><td width="50px" align="left">{crncyCd}</td><td width="50px" align="left">{cntryCd}</td><td width="50px" align="left">{poBox}</td></tr></table>';
                	 }
            }*/
        }, config));
    },
    /**
     * POD, PFD, PRD are using common URL
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getChargeCodeLov: function (config) {

        config = config || {};

        var chargeCodeStoreConfig = Ext.apply({
            model: 'chargeCodeLov',
            url: 'commonOceanLov/getChargCodeList',
            paging: true,
            listeners: {
                beforeload: function () {
                    this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
//                    this.proxy.extraParams.servType = Modules.GlobalVars.selectedServiceTypeCode;
                    //					this.proxy.extraParams.serviceType = serviceTypeCode;
                }
            }
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: chargeCodeStoreConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.LblsAndTtls.chargCode,
            displayField: 'chargeCode',
            valueField: 'chargeCode',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Code',
				width:150,
				dataIndex:'chargeCode'
			},{
				header:'Description',
				width:150,
				dataIndex:'chargCodeDesc'
			},{
				header:'Service Type',
				width:150,
				dataIndex:'srvType'
			}]
          /*  listConfig: {
                width: 500,
                loadingText: Modules.Msgs.loading,
                height: 300,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{chargeCode}</td><td width="150px" align="left">{chargCodeDesc}</td><td width="150px" align="left">{srvType}</td></tr></table>';
                	 }
            }*/
        }, config));
    },
    /**
     * Freight Terms
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getFreightTermsLov: function (config) {

        config = config || {};

        var freighttrmsConfig = Ext.apply({
            model: 'freightTrmsLov',
            url: 'commonOceanLov/getFreightTrmsList',
            paging: true
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: freighttrmsConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.LblsAndTtls.freightTerm,
            displayField: 'freightTrmsCode',
            valueField: 'freightTrmsCode',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Code',
				width:100,
				dataIndex:'freightTrmsCode'
			},{
				header:'Description',
				width:100,
				dataIndex:'freightTrmsDesc'
			}]/*,
            listConfig: {
                width: 250,
                loadingText: Modules.Msgs.loading,
                height: 50,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	 return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{freightTrmsCode}</td><td width="150px" align="left">{freightTrmsDesc}</td></tr></table>';
                	 }
            }*/
        }, config));
    },
    /**
     * Freight Terms
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getSrvGrpLov: function (config) {

        config = config || {};

        var srvGrpConfig = Ext.apply({
            model: 'oceanSrvGrpLov',
            url: 'commonOceanLov/getOceanServGrpList',
            paging: true,
            listeners: {
                beforeload: function () {
                	var party;
                	var userType = Modules.GlobalVars.loginUserTypeCode;
					var userId = Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.userType = userType;
	                this.proxy.extraParams.userId = userId;
                    this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                    this.proxy.extraParams.party = party;
                  
                   
                    //					this.proxy.extraParams.serviceType = serviceTypeCode;
                }
            }
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: srvGrpConfig,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.LblsAndTtls.serviceGroupTlt,
            displayField: 'srvcGroupCd',
            valueField: 'srvcGroupCd',
            matchFieldWidth: false,
            listConfig: {
                width: 250,
                loadingText: Modules.Msgs.loading,
                height: 50,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	 return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{srvcGroupCd}</td><td width="150px" align="left">{srvcGroupDesc}</td><td width="100px" align="left">{partyCd}</td></tr></table>';
                	 }
            }
        }, config));
    }	,
    /**
     * ContractId
     * @param config
     * @returns {Ext.cmc.ComboBox}
     */
    getContractIdLov: function (config) {

        config = config || {};

        var contractIdStore = Ext.apply({
            model: 'OcnContractIDModel',
            url: 'commonOceanLov/getOcnContractIDList',
            paging: true,
            listeners: {
                beforeload: function () {
					this.proxy.extraParams.userType = Modules.GlobalVars.loginUserTypeCode;
	                this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                    this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                }
            }
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: contractIdStore,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.contractId,
            displayField: 'systemContractNo',
            valueField: 'systemContractNo',
            matchFieldWidth: false,          
            listConfig: {
                width: 400,
                loadingText: Modules.Msgs.loading,
                height: 50,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{systemContractNo}</td><td width="100px" align="left">{customerCode}</td><td width="100px" align="left">{validFromDate}</td><td width="100px" align="left">{validToDate}</td><td width="170px" align="left">{remark}</td> </tr></table>';
                	 }
            }
        }, config));
    },
    
    getOceanSupplierContractIdLov: function (config) {

        config = config || {};

        var contractIdStore = Ext.apply({
            model: 'OcnContractIDModel',
            url: 'commonOceanLov/getOcnSupplierContractIDList',
            paging: true,
            listeners: {
                beforeload: function () {
					this.proxy.extraParams.userType = Modules.GlobalVars.loginUserTypeCode;
	                this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                    this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                }
            }
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: contractIdStore,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.ocean.lov_factory.labels.contractId,
            displayField: 'systemContractNo',
            valueField: 'systemContractNo',
            matchFieldWidth: false,          
            listConfig: {
                width: 400,
                loadingText: Modules.Msgs.loading,
                height: 50,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{systemContractNo}</td><td width="100px" align="left">{customerCode}</td><td width="100px" align="left">{validFromDate}</td><td width="100px" align="left">{validToDate}</td><td width="170px" align="left">{remark}</td> </tr></table>';
                	 }
            }
        }, config));
    },
    
    getVessel:function(config)
	{

    	  var vesselStore =  Modules.GlobalFuncs.getStore(
					Ext.apply(
							{
								model: 'genericLookUp',
								url:'commonOceanLov/getVesselList',
								paging:true
							},
						config.storeConfig || {})
					);
    	  
    	  delete config.storeConfig;
    	  
    	  return new Ext.cmc.ComboBox(Ext.apply({
				storeObjCmc: Ext.apply(
						{
							model: 'genericLookUp',
							url:'commonOceanLov/getVesselList',
							paging:true
						},
				config.storeConfig || {}),
				selectOnTab: true,
				labelAlign:"left",
				fieldLabel: Modules.LblsAndTtls.VesselLbl,
				displayField: 'code',
			    valueField: 'code',
				matchFieldWidth: false,
			
				 columnsCmc:[{
						header:'Code',
						width:100,
						dataIndex:'code'
					},{
						header:'Name',
						width:250,
						dataIndex:'name'
					}]
			
			},config));
 	    	},
 	    	
 	   	getCstmrStatus:function(config)
		{
	    	  var cstmrStsStore =  Modules.GlobalFuncs.getStore(
						Ext.apply(
								{
									model: 'genericLookUp',
									url:'commonOceanLov/getCstmrStatus',
									paging:true
								},
							config.storeConfig || {})
						);
	    	  
	    	  delete config.storeConfig;
	    	  
	    	  return new Ext.cmc.ComboBox(Ext.apply({
					storeObjCmc: Ext.apply(
							{
								model: 'genericLookUp',
								url:'commonOceanLov/getCstmrStatus',
								paging:true
							},
						config.storeConfig || {}),
					selectOnTab: true,
					labelAlign:"left",
					fieldLabel:Modules.LblsAndTtls.customerStatusTlt,
					displayField: 'code',
				    valueField: 'code',
					matchFieldWidth: false,
					 columnsCmc:[{
							header:'Code',
							width:70,
							dataIndex:'code'
						},{
							header:'Description',
							width:100,
							dataIndex:'name'
						}]
					//validateUrlCmc:'',					
				/*	validateParamsCmc:[{name:'cmpnyCode', id:'headerCompanyComboID'},
					                   {name:'maxRecs', val:maxRecs},
//					                   {name:'userTyp', val:loginUserType},
//					                   {name:'userId', val:loginUserId}
					                   ],*/
				/*	validateSuccessFuncCmc:function(serverRespOjbData){	
						serviceTypeCode = "true";
						return true;
					},
					validateFailFuncCmc:function(){
						serviceTypeCode = "false";
						return true;
					},	*/	
					/*listConfig: {
						width: 500,
						loadingText: Modules.Msgs.loading,
						height: 300,
						deferEmptyText: false,
						emptyText: Modules.Msgs.noComboValueFound,
						getInnerTpl: function ()
						{
						return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="100px" align="left">{name}</td></tr></table>';
						}
					}*/
				},config));
	 	    	
		},
		
		getSupplierStatus:function(config)
		{

	    	  var supplrStsStore =  Modules.GlobalFuncs.getStore(
						Ext.apply(
								{
									model: 'genericLookUp',
									url:'commonOceanLov/getSpplrStatus',
									paging:true
								},
							config.storeConfig || {})
						);
	    	  
	    	  delete config.storeConfig;
	    	  
	    	  return new Ext.cmc.ComboBox(Ext.apply({
					storeObjCmc: Ext.apply(
							{
								model: 'genericLookUp',
								url:'commonOceanLov/getSpplrStatus',
								paging:true
							},
						config.storeConfig || {}),
					selectOnTab: true,
					labelAlign:"left",
					fieldLabel:Modules.LblsAndTtls.supplierStatusTlt,
					displayField: 'code',
				    valueField: 'code',
					matchFieldWidth: false,
				      columnsCmc:[{
							header:'Code',
							width:70,
							dataIndex:'code'
						},{
							header:'Description',
							width:100,
							dataIndex:'name'
						}]
					//validateUrlCmc:'',					
				/*	validateParamsCmc:[{name:'cmpnyCode', id:'headerCompanyComboID'},
					                   {name:'maxRecs', val:maxRecs},
//					                   {name:'userTyp', val:loginUserType},
//					                   {name:'userId', val:loginUserId}
					                   ],*/
				/*	validateSuccessFuncCmc:function(serverRespOjbData){	
						serviceTypeCode = "true";
						return true;
					},
					validateFailFuncCmc:function(){
						serviceTypeCode = "false";
						return true;
					},	*/	
					/*listConfig: {
						width: 500,
						loadingText: Modules.Msgs.loading,
						height: 300,
						deferEmptyText: false,
						emptyText: Modules.Msgs.noComboValueFound,
						getInnerTpl: function ()
						{
						return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="100px" align="left">{name}</td></tr></table>';
						}
					}*/
				},config));
	 	    	
			},
			
			getVoyage:function(config)
	    	{

		    	  var voyageStore =  Modules.GlobalFuncs.getStore(
							Ext.apply(
									{
										model: 'voyageModel',
										url:'commonOceanLov/getVoyageList',
										paging:true
									},
								config.storeConfig || {})
							);
		    	  
		    	  delete config.storeConfig;
		    	  
		    	  return new Ext.cmc.ComboBox(Ext.apply({
						storeObjCmc: Ext.apply(
								{
									model: 'voyageModel',
									url:'commonOceanLov/getVoyageList',
									paging:true
								},
							config.storeConfig || {}),
						selectOnTab: true,
						labelAlign:"left",
						fieldLabel:Modules.LblsAndTtls.Voyage,
						displayField: 'voyageNo',
					    valueField: 'voyageNo',
						matchFieldWidth: false,
						 columnsCmc:[{
								header:'Voyage',
								width:100,
								dataIndex:'voyageNo'
							},{
								header:'Currency',
								width:100,
								dataIndex:'voyageCurrencyCd'
							},
							{
								header:'Route Code',
								width:100,
								dataIndex:'routeCd'
							}]/*,
						listConfig: {
							width: 500,
							loadingText: Modules.Msgs.loading,
							height: 300,
							deferEmptyText: false,
							emptyText: Modules.Msgs.noComboValueFound,
							getInnerTpl: function ()
							{
							return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{voyageNo}</td><td width="100px" align="left">{voyageCurrencyCd}</td><td width="100px" align="left">{routeCd}</td></tr></table>';
							}
						}*/
					},config));
   	},
   	
   	getPartyLov:function(config)
   	{
        config = config || {};

        var partyLovStore = Ext.apply({
            model: 'PartyLov',
            url: 'commonOceanLov/getPartyList',
            paging: true,
            listeners: {
                beforeload: function () {
					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                }
            }
        },
        config.storeConfig || {});

        delete config.storeConfig;

        return Ext.create('Ext.cmc.ComboBox', Ext.apply({
            storeObjCmc: partyLovStore,
            selectOnTab: true,
            labelAlign: "left",
            fieldLabel: Modules.LblsAndTtls.partyGP,
            displayField: 'cstmrCd',
            valueField: 'cstmrCd',
            matchFieldWidth: false,
            columnsCmc:[{
				header:'Number',
				width:100,
				dataIndex:'cstmrCd'
			},{
				header:'Name',
				width:150,
				dataIndex:'cstmrNm'
			},{
				header:'Address1',
				width:150,
				dataIndex:'addr1'
			},{
				header:'City',
				width:100,
				dataIndex:'cityNm'
			},{
				header:'State',
				width:100,
				dataIndex:'stateCd'
			},{
				header:'Postal',
				width:100,
				dataIndex:'poBox'
			},{
				header:'Country',
				width:100,
				dataIndex:'countryCd'
			}]/*,
            listConfig: {
                width: 300,
                loadingText: Modules.Msgs.loading,
                height: 300,
                deferEmptyText: false,
                emptyText: Modules.Msgs.noComboValueFound,
                getInnerTpl: function () {
                	//return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="75px" align="left">{cstmrCd}</td><td width="75px" align="left">{cstmrNm}</td><td width="75px" align="left">{cstmrNm1}</td><td width="75px" align="left">{addr1}</td><td width="75px" align="left">{addr2}</td><td width="75px" align="left">{addr3}</td><td width="75px" align="left">{cityNm}</td><td width="75px" align="left">{stateCd}</td><td width="75px" align="left">{countryCd}</td><td width="75px" align="left">{poBox}</td></tr></table>';
                	return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="75px" align="left">{cstmrCd}</td><td width="175px" align="left">{cstmrNm}</td></tr></table>';
                	 }
            }*/
        }, config));
      },
     	getCargoTypeLov:function(config)
       	{
            config = config || {};

            var cargoTypeLovStore = Ext.apply({
                model: 'CargoTypeModel',
                url: 'commonOceanLov/getCargoTypeLOV',
                paging: true,
                listeners: {
                    beforeload: function () {
    					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                    }
                }
            },
            config.storeConfig || {});

            delete config.storeConfig;

            return Ext.create('Ext.cmc.ComboBox', Ext.apply({
                storeObjCmc: cargoTypeLovStore,
                selectOnTab: true,
                labelAlign: "left",
                fieldLabel: Modules.LblsAndTtls.cargoType,
                displayField: 'crgTypeCode',
                valueField: 'crgTypeCode',
                matchFieldWidth: false, 
                columnsCmc:[
                   		 {
                   		  header:'Code',	 
                   		  dataIndex:'crgTypeCode',
                   		  width:80
                   		 },
                   		 {
                   		  header:'Description',	 
                   		  dataIndex:'crgTypeDescr',
                   		  width:100
                   		 }
                   		 ]
                
            }, config));
       	},
     	getCargoClassLov:function(config)
       	{
            config = config || {};

            var cargoClassLovStore = Ext.apply({
                model: 'genericLookUp',
                url: 'commonOceanLov/getCargoClassLOV',
                paging: true,
                listeners: {
                    beforeload: function () {
    					this.proxy.extraParams.cmpnyCd = Modules.GlobalVars.selectedCompanyCode;
                    }
                }
            },
            config.storeConfig || {});

            delete config.storeConfig;

            return Ext.create('Ext.cmc.ComboBox', Ext.apply({
                storeObjCmc: cargoClassLovStore,
                selectOnTab: true,
                labelAlign: "left",
                fieldLabel: Modules.LblsAndTtls.cargoClass,
                displayField: 'code',
                valueField: 'code',
                matchFieldWidth: false, 
                columnsCmc:[{
        			header:'Cargo Class Code',
        			width:80,
        			dataIndex:'code'
        		},{
        			header:'Cargo Class Name',
        			width:150,
        			dataIndex:'name'
        		}]
               /* listConfig: {
                    width: 250,
                    loadingText: Modules.Msgs.loading,
                    height: 50,
                    deferEmptyText: false,
                    emptyText: Modules.Msgs.noComboValueFound,
                   
            ,
                    getInnerTpl: function () {
                    	return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="100px" align="left">{name}</td></tr></table>';
                    	 }
                }*/
            }, config));
       	} ,
       	
       getRoundingCriteriaLov:function(config)
       {
    	   config = config || {}; 
    	   
    	   var roundingCriteriaLovStore = Ext.apply({
			  fields:["value","text"],
			  data:[{"value":"U","text":"Up"},
					{"value":"D","text":"Down"},
					{"value":"N","text":"Nearest"}
				]
			},
           config.storeConfig || {});
    	   
    	   delete config.storeConfig;
    	   
    	  return Ext.create('Ext.cmc.ComboBox', Ext.apply({
			name : 'roundingType',
			displayField: 'text',
			storeObjCmc: roundingCriteriaLovStore,
			valueField: 'value',
			editable : false,
			labelAlign : 'left',
			hideTrigger:false,		
			matchFieldWidth: false,
			listConfig: {
				width: 250,
				loadingText: 'Loading...',
				height: 300,
				deferEmptyText: false,
				emptyText: 'No Values Found!',
				getInnerTpl: function() {
					return    '<table class="boldtable"><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="150px">{text}</td></tr></table>';
				}
			}

		}, config));
   	   
       },
       getSupplierContractIdLov: function (config) {

           config = config || {};

           var contractIdStore = Ext.apply({
               model: 'OcnSuplrCOntractIdLov',
               url: 'commonOceanLov/getOcnContractId',
               paging: true,
               listeners: {
                   beforeload: function () {
                    this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
                   }
               }
           },
           config.storeConfig || {});

           delete config.storeConfig;

           return Ext.create('Ext.cmc.ComboBox', Ext.apply({
               storeObjCmc: contractIdStore,
               selectOnTab: true,
               labelAlign: "left",
               fieldLabel: Modules.ocean.lov_factory.labels.contractId,
               displayField: 'contractId',
               valueField: 'contractId',
               matchFieldWidth: false,          
               listConfig: {
                   width: 250,
                   loadingText: Modules.Msgs.loading,
                   height: 50,
                   deferEmptyText: false,
                   emptyText: Modules.Msgs.noComboValueFound,
                   getInnerTpl: function () {
                	   return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{contractId}</td><td width="100px" align="left">{supplrCd}</td><td width="100px" align="left">{validFromDate}</td><td width="100px" align="left">{validToDate}</td><td width="170px" align="left">{remarks}</td> </tr></table>';
                   	 }
               }
           }, config));

       },
       getCommodityCodeLov: function (config) {
           config = config || {};

           var commodityCodeStoreConf = Ext.apply({
       		model : 'GenericLookUpDTO',
       		queryTypeCmc : 'remote',
       		url : 'commonOceanLov/getCommodityCode',
       		paging : true,
       		listeners : {
       			beforeload : function() {
       				
       			}
       		}
       	},
           config.storeConfig || {});

           delete config.storeConfig;

           return Ext.create('Ext.cmc.ComboBox', Ext.apply({
               storeObjCmc: commodityCodeStoreConf,
               triggerAction: 'all',
               typeAhead: true,
               paging: true,
               selectOnTab: true,
               displayField: 'code',
               valueField: 'code',
               matchFieldWidth: false,
               listConfig: {
   				loadingText: Modules.Msgs.loading,
   				emptyText: Modules.Msgs.noComboValueFound,
   				getInnerTpl: function () {
   					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{code}</td><td width="90px" align="left">{name}</td></tr></table>';
   				}
   			}
           }, config));
       },
       getRateTierLov: function (config) {
      		config = config || {};
      		var rateTierStoreConf = Ext.apply({
      			model: 'GenericLookUpDTO',
      			queryTypeCmc:'remote',
      			url:'commonOceanLov/getRateTierList',
      			paging:true,
      			listeners : {
      				beforeload:function(){
      					//for sending selected values to controller
      					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
      					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
      					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
      				}
      			}
      		},
      		config.storeConfig || {});
      		delete config.storeConfig;

      		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
      			storeObjCmc: rateTierStoreConf,
      			selectOnTab: true,
      			labelAlign: "left",
      			fieldLabel: Modules.ocean.lov_factory.labels.rateTier,
      			displayField: 'code',
      			valueField: 'code',
      			matchFieldWidth: false,
      			listConfig: {
      				width: 500,
      				loadingText: Modules.Msgs.loading,
      				height: 300,
      				deferEmptyText: false,
      				emptyText: Modules.Msgs.noComboValueFound,
      				getInnerTpl: function () {
      					return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td></tr></table>';
      				}
      			}
      		}, config));
      	},
      	getModelGrpCdLov: function (config) {
      		config = config || {};
      		var modelGrpCdStoreConf = Ext.apply({
      			model: 'GenericLookUpDTO',
      			queryTypeCmc:'remote',
      			url:'commonOceanLov/getModelGrpList',
      			paging:true,
      			listeners : {
      				beforeload:function(){
      					//for sending selected values to controller
      					this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
      					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
      					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
      				}
      			}
      		},
      		config.storeConfig || {});
      		delete config.storeConfig;

      		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
      			storeObjCmc: modelGrpCdStoreConf,
      			selectOnTab: true,
      			labelAlign: "left",
      			fieldLabel: Modules.ocean.lov_factory.labels.modelGrpCd,
      			displayField: 'code',
      			valueField: 'code',
      			matchFieldWidth: false,
      			listConfig: {
      				width: 500,
      				loadingText: Modules.Msgs.loading,
      				height: 300,
      				deferEmptyText: false,
      				emptyText: Modules.Msgs.noComboValueFound,
      				getInnerTpl: function () {
      					return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td></tr></table>';
      				}
      			}
      		}, config));
      	},
      	getExceptionTypeLOV: function (config) {
      		config = config || {};
      		var ExceptionTypeStoreConf = Ext.apply({
      			model: 'GenericLookUpDTO',
      			queryTypeCmc:'remote',
      			url:'commonOceanLov/getExceptionTypeLOV',
      			paging:true,
      			listeners : {
      				beforeload:function(){
      					//for sending selected values to controller
      				//	this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;
      					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
      					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
      				}
      			}
      		},
      		config.storeConfig || {});
      		delete config.storeConfig;

      		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
      			storeObjCmc: ExceptionTypeStoreConf,
      			selectOnTab: true,
      			labelAlign: "left",
      			fieldLabel: 'Exception Type',
      			displayField: 'code',
      			valueField: 'code',
      			matchFieldWidth: false,
      			listConfig: {
      				width: 500,
      				loadingText: Modules.Msgs.loading,
      				height: 300,
      				deferEmptyText: false,
      				emptyText: Modules.Msgs.noComboValueFound,
      				getInnerTpl: function () {
      					return '<table class = "boldtable"  width="100%"><tr><td width="100px" align="left">{code}</td><td width="275px" align="left">{name}</td></tr></table>';
      				}
      			}
      		}, config));
      	},

      	/**
    	 * 
    	 * @param config
    	 * @returns {Ext.cmc.ComboBox}
    	 */
    	getPopCountryLov: function (config) {
    		config = config || {};
    		var popCountryStoreConfig = Ext.apply({
    			model: 'popCntryList',
    			url: 'commonOceanLov/getPopCountryList',
    			paging: true,
    			listeners : {
      				beforeload:function(){
      					//for sending selected values to controller
      					this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;
      					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
      					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
      				}
      			}
    		},
    		config.storeConfig || {});
    		delete config.storeConfig;
    		
    		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
    			storeObjCmc: popCountryStoreConfig,
    			selectOnTab: true,
    			labelAlign: "left",
    			fieldLabel: Modules.LblsAndTtls.pop,
    			toolTipCmc:Modules.Ocean.CustInvcSetup.labels.poptoolTip, 
    			displayField: 'cntryCd',
    			valueField: 'cntryCd',
    			matchFieldWidth: false,    	
    			columnsCmc:[{
    				header:'Code',
    				width:150,
    				dataIndex:'cntryCd'
    			}]
//    			listConfig: {
//    				width: 220,
//    				loadingText: Modules.Msgs.loading,
//    				height: 300,
//    				deferEmptyText: false,
//    				emptyText: Modules.Msgs.noComboValueFound,
//    				getInnerTpl: function () {
//                        return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{cntryCd}</td></tr></table>';
//    				}
//    			}
    		}, config));
    	},
    	
    	
    	
    	/**
    	 * 
    	 * @param config
    	 * @returns {Ext.cmc.ComboBox}
    	 */
    	getCountryLov: function (config) {
    		config = config || {};
    		var getCountryLov = Ext.apply({
    			model: 'GenericLookUpDTO',
    			url: 'commonOceanLov/getCountryList',
    			paging: true,
    			listeners : {
      				beforeload:function(){
      					//for sending selected values to controller
      					/*this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
      					this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
      					this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;*/
      				}
      			}
    		},
    		config.storeConfig || {});
    		delete config.storeConfig;
    		
    		return Ext.create('Ext.cmc.ComboBox', Ext.apply({
    			storeObjCmc: getCountryLov,
    			selectOnTab: true,
    			labelAlign: "left",
    			fieldLabel: Modules.LblsAndTtls.custmrInvcCountry,
    	//		toolTipCmc:Modules.Ocean.CustInvcSetup.labels.poptoolTip, 
    			displayField: 'code',
    			valueField: 'code',
    			matchFieldWidth: false,  
    			columnsCmc:[
    			            {
    			            	header:'Country Code',
    		        			width:120,
    		        			dataIndex:'code'
    			            },
    			            {
    			            	header:'Country Name',
    		        			width:150,
    		        			dataIndex:'name'
    			            }
    			            ]
    			
    			/*listConfig: {
    				width: 300,
    				loadingText: Modules.Msgs.loading,
    				height: 300,
    				deferEmptyText: false,
    				emptyText: Modules.Msgs.noComboValueFound,
    				getInnerTpl: function () {
                        return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="100px" align="left">{code}</td><td width="100px" align="left">{name}</td></tr></table>';
    				}
    			}*/
    		}, config));
    	},
    	
    	
    	
    	getStateProvinceLov: function (config) {
            config = config || {};

            var stateProvinceStoreConf = Ext.apply({
        		model : 'StateProvinceLookUpDTO',
        		queryTypeCmc : 'remote',
        		url : 'getStateProvinceLOV',
        		paging : true,
        		listeners : {
        			
        		}
        	},
            config.storeConfig || {});

            delete config.storeConfig;

            return Ext.create('Ext.cmc.ComboBox', Ext.apply({
                storeObjCmc: stateProvinceStoreConf,
                triggerAction: 'all',
                typeAhead: true,
                paging: true,
                selectOnTab: true,
                labelAlign: "left",
                displayField: 'state_cd',
                valueField: 'state_cd',
                matchFieldWidth: false,
                columnsCmc:[{
        			header:'State Code',
        			width:80,
        			dataIndex:'state_cd'
        		},{
        			header:'State Name',
        			width:150,
        			dataIndex:'state_nm'
        		},{
        			header:'Country Code',
        			width:100,
        			dataIndex:'cntry_cd'
        		},{
        			header:'Country Name',
        			width:150,
        			dataIndex:'cntry_nm'
        		}],
                listConfig: {
    				loadingText: Modules.Msgs.loading,
    				emptyText: Modules.Msgs.noComboValueFound,
    				getInnerTpl: function () {
    					return '<table class="boldtable"><tr><td height="5"></td><td height="5"></td></tr><tr valign="top"><td width="50px" align="left">{state_cd}</td><td width="90px" align="left">{state_nm}</td><td width="90px" align="left">{cntry_cd}</td><td width="100px" align="left">{cntry_nm}</td></tr></table>';
    				}
    			}
            }, config));
        },
    	
    	
    	
        getOcnCurrencyCodeLov: function (config) {
            config = config || {};

            var currencyCodeStoreConf = Ext.apply({
                model: 'GenericLookUpDTO',
                queryTypeCmc: 'remote',
                url: 'commonOceanLov/getOcnCurrencyCodeLOV', //?userId=3&serviceType=HRBA',
                paging: true,
                listeners: {
                    beforeload: function () {
                        //for sending selected values to controller
                        this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
                        this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                    }
                }
            },
            config.storeConfig || {});

            delete config.storeConfig;

            return Ext.create('Ext.cmc.ComboBox', Ext.apply({
                storeObjCmc: currencyCodeStoreConf,
                triggerAction: 'all',
                typeAhead: true,
                paging: true,
                labelAlign: "left",
                selectOnTab: true,
                displayField: 'code',
                valueField: 'code',
                matchFieldWidth: false,
    			columnsCmc:[{
    				header:'Code',
    				width:100,
    				dataIndex:'code'
    			},{
    				header:'Name',
    				width:150,
    				dataIndex:'name'
    			}]
            }, config));
        },
        
        
        getPOLStateProv:function(config)
        {
           config = config || {};
           var polstateProvStore = Ext.apply({
        	   model:'portList',
        	   queryTypeCmc: 'remote',
               url: 'commonOceanLov/getPOLStateProvince', //?userId=3&serviceType=HRBA',
               paging: true,
               listeners: {
                   beforeload: function () {
                       //for sending selected values to controller
                	   this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
                       this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
                       this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                   }
               }
           },
           config.storeConfig || {});
           
           delete config.storeConfig;

           return Ext.create('Ext.cmc.ComboBox', Ext.apply({
               storeObjCmc: polstateProvStore,
               selectOnTab: true,
               labelAlign: "left",
               displayField: 'stateCode',
               valueField: 'stateCode',
               matchFieldWidth: false,
               columnsCmc:[{
   				header:'State Code',
   				width:50,
   				dataIndex:'stateCode'
   			}]
           }, config));
        }

   	
};	

