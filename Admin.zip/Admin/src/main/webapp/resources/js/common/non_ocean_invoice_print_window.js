/**
 * 
 */
Ext.ns('Modules.common.nonOcean');

Modules.common.nonOcean.InvoicePrintHelper= function(config){
	
	if(Ext.isEmpty(config)){
		return;
	}
	  var param = {
			  	 companyCd : Modules.GlobalVars.selectedCompanyCode,
				 cstmrCd   : config.cstmrCd,
				 dbtrPartyCd : '',
				 prfInvoices: Ext.JSON.encode(config.prfInvoices)
		 };
	  Ext.Ajax.request({
			url : 'nonOceanPrintEmailController/getPrintDetails',
			params :param,
			timeout : 120000,
			success : function(response) {
				 var temp= Ext.decode(response.responseText);
				 var emaildtls=temp.value;		
				 var params = {
						 prfInvoices : config.prfInvoices,
						 cstmrCd 	 : config.cstmrCd,							
						 emaildtls   : emaildtls
				 };
				Modules.common.nonOcean.InvoicePrintWindow(params).show(); 							 
												 
			},failure : function(){
			  var params = {
						 prfInvoices : prfInvoices,
						 cstmrCd     : config.cstmrCd					
				 };				 
				Modules.common.nonOcean.InvoicePrintWindow(params).show(); 	
			}
			});			
};

/**
 * @params config -> 
 * 
 * invoiceNumber- Array
 * party - String
 * pop - 
 */
Modules.common.nonOcean.InvoicePrintWindow = function (config) {
	
	var prfInvoices='',cstmrCd='';	
	var templateCd='';
	var emaildtls='';	
	
	if(config){
		prfInvoices = config.prfInvoices;
		cstmrCd     = config.cstmrCd;
		emaildtls   = config.emaildtls;
		}
	
	if(emaildtls){		
		if(emaildtls.invcTemplate !=null){
				templateCd=emaildtls.invcTemplate;
		}			
			
	}
    var FormObj = function () {
        var printForm = {
            xtype: 'cmcform',
            showFieldsetCmc: false,
            height: 270,
            width: 700,
            bbar: ['->', {
                    xtype: 'button',
                    text: 'Print',
                    iconCls: "print-type",
                    id:'nonOceanInvcprintbtnId',
                    validateData: function(){  
                    	     if(Ext.getCmp('nonOceanInvcPrintercdId').getValue() == ''  || Ext.getCmp('nonOceanInvcPrintercdId').getValue()==null){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.invcPrinterMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                      	 if(Ext.getCmp('nonOceanInvcOrginlCpyId').getValue() < 1  && Ext.getCmp('nonOceanInvcDuplCpyId').getValue() <1){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.invcCpiesMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }  
                    	 if(Ext.getCmp('nonOceanBackupFlg').getValue() == 'Y' || Ext.getCmp('nonOceanBackupFlg').getValue()== true){                    		 
                    		 if(Ext.getCmp('nonOceanBackupPrintercdId').getValue() == ''  || Ext.getCmp('nonOceanBackupPrintercdId').getValue()==null){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.backupPrnterMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                    		 if(Ext.getCmp('nonOceanBackupCpyId').getValue() < 1 ){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.bilCopiesMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   } 
                    	 }                    	 
                    	return true;                    	
                    },
                    handler: function () {		
                    	var form = this.up('cmcform').getForm();
                    	 var parenWindow = this.up('cmcwindow');
 		            	if(!form.isValid()){
 		            		Ext.MessageBox.show({ title : '',
 		        				msg : 'Invalid Form Data',
 		        				buttons:Ext.MessageBox.OK,
 		        				icon : Ext.MessageBox.ERROR
 							 });
 		        		return;
 		            	}
                    	if(Ext.getCmp('nonOceanInvcprintbtnId').validateData()){ 			    	
				    	
                    		var searchObj= form.getValues(false);
							var orginalFlg ='N';
							
							if(Ext.getCmp('nonOceanInvcOrginlCpyId').getValue() > 0){
								orginalFlg='Y';
							}						
							
				    		 var param = {	    
				    				 	invcPrintFlg:searchObj.invcPrintFlg,
				    				 	invcCopies:searchObj.invcCopies,
				    				 	invcBackupFlg:searchObj.invcBackupFlg,
				    				 	backupCopies:searchObj.backupCopies,
				    				 	invcPrinter:searchObj.invcPrinter,
				    				 	backupPrinter:searchObj.backupPrinter,
				    				 	dupInvcCpyCnt:searchObj.dupInvcCpyCnt,
				    				 	invcPrnterTray:searchObj.invcPrnterTray,
				    				 	backupPrnterTray:searchObj.backupPrnterTray,
				    				 	invcPrnterCnfgPath:searchObj.invcPrnterCnfgPath,
				    				 	backupPrnterCnfgPath:searchObj.backupPrnterCnfgPath,
				    				 	orginalFlg:orginalFlg,
				    				 	cstmrCd :cstmrCd,
										companyCd :Modules.GlobalVars.selectedCompanyCode,
										printMode :'P',
										printType:'INVOICE',	
							 			prfInvoices: Ext.JSON.encode(prfInvoices)
							 			
				    		 };				    		
				    			
						 Ext.Ajax.request({
							 	url : 'nonOceanPrintEmailController/SendEmailPrint',
								params :param,
								timeout : 120000,
								success : function(response) {
									var msg = Ext.decode(response.responseText);
									if (msg.success == true) {	
									 Ext.MessageBox.show({
						                        title: '',
							                        msg: 'Request for print is submitted',
							                        buttons: Ext.MessageBox.OK,
							                        icon: Ext.MessageBox.INFO
							                    });								 
									
									 parenWindow.close();
										
									
								}else{
									 Ext.MessageBox.show({
					                        title: '',
						                        msg: msg.message,
						                        buttons: Ext.MessageBox.OK,
						                        icon: Ext.MessageBox.INFO
						                    });
										
									}
								 
							}
							});
                    	
				    		 
				    	 }
                    }
                }
            ],

            setFormItemsFuncCmc: function () {
                var itemsArr = [];
              
                var invoiceCheckBox = {
                    xtype: 'cmccheckboxfield',
                    boxLabel: 'Invoice',
                    name: 'invcPrintFlg',
                    width: 80,
                    checked:true,
                    inputValue: 'Y' ,
                    readOnly: true
                };

                var backupCheckBox = {
                    xtype: 'cmccheckboxfield',
                    boxLabel: 'Backup',
                    name: 'invcBackupFlg',
                    width: 80,
                    inputValue: 'Y',
                    id:"nonOceanBackupFlg",
                    listeners : {										
						change : function(combo, newValue, oldValue, eOpts) {
							if(!Ext.isEmpty(newValue) && newValue ===true){
								this.up('cmcform').down('#backupFieldset').enable();
							}else{
								this.up('cmcform').down('#backupFieldset').disable();								
							}
						}
                    }                   
                };

                var invoicePrinterCombo =Modules.LovFactory.getPrinterCdLov({
                	labelWidth: 50,
                    labelAlign: "left",
                    width: 260,
                    name:"invcPrinter",
                    id:"nonOceanInvcPrintercdId",
                    fieldLabel: 'Printer'+ "<span style='color: red'>*</span>",
                    listeners :{
                    	select:function(combo, records, eOpt){
    						if(records && records[0]){    							
    							Ext.getCmp('nonOcnInvcCnfgPathId').setValue(records[0].get('printerCnfgPth'));    							
    						}                    	
                    }
                    }
                                                             
                   
                });
                var backupPrinterCombo =Modules.LovFactory.getPrinterCdLov({
                	labelWidth: 50,
                    labelAlign: "left",
                    width: 260,
                    name:"backupPrinter",
                    id:"nonOceanBackupPrintercdId",
                    fieldLabel: 'Printer'+ "<span style='color: red'>*</span>",
                    listeners :{
                    	select:function(combo, records, eOpt){
    						if(records && records[0]){    							
    							Ext.getCmp('nonOcnBackCnfgPathId').setValue(records[0].get('printerCnfgPth'));    							
    						}                    	
                    }
                    }                                                            
                   
                });              
                var invcTray = {
                    xtype: 'cmcnumberfield',
                    fieldLabel:'Tray',
                    name:'invcPrnterTray',
                    maxLength:2,
                    minValue:0,
                	width:80,
                	labelWidth:40
                };
                var backupTrayCombo = {
                        xtype: 'cmcnumberfield',
                        fieldLabel:'Tray',
                        name:'backupPrnterTray',
                        maxLength:2,
                        minValue:0,
                    	width:80,
                    	labelWidth:40
                    };
            	var templateCode= {
						xtype: 'cmctextfield',
                         fieldLabel: 'Template',
                         id:'nonOcnPrintTemplateId',
                         labelWidth: 50,
                         name:'invcTemplate',
                         labelAlign: "left",
                         width: 260,
                         value:templateCd,
						 readOnly: true
			 };  
               
            	var invccnfgPath = {
						xtype : 'cmctextfield',
						name : 'invcPrnterCnfgPath',
						id:'nonOcnInvcCnfgPathId',
						hidden : true,
						hideable : false
					};
            	var backupcnfgPath = {
						xtype : 'cmctextfield',
						name : 'backupPrnterCnfgPath',
						id:'nonOcnBackCnfgPathId',
						hidden : true,
						hideable : false
					};
                /**START Container..1 Component**/
                var invoiceContainer = {
                    xtype: 'fieldset',
                    title: 'Invoice',
                    itemId: 'invoiceFieldset',
                    margin: '1px 1px 10px 5px',
                    defaults: {
                        margin: '5px 10px 5px 5px'
                    },
                    items: [{xtype: 'container',
                            layout: 'hbox',
                            margin: '1px 1px 5px 5px',
                            defaults: {
                                margin: '5px 10px 5px 5px'
                            },
                            items: [templateCode,invoicePrinterCombo,invcTray,invccnfgPath]}, 
                        {
                            xtype: 'fieldset',
                            layout: 'hbox',
                            title: 'Copies',
                            margin: '1px 1px 10px 5px',
                            defaults: {
                                margin: '5px 10px 5px 5px'
                            },
                            items:[{
                            xtype: 'cmcnumberfield',
                            width: 135,
                            maxLength:2,
                            id:'nonOceanInvcOrginlCpyId',
                            name:"invcCopies",
                            value: 1,
                            minValue:0,
                            fieldLabel: 'No. of Originals'
                        },{
                            xtype: 'cmcnumberfield',
                            width: 135,
                            id:'nonOceanInvcDuplCpyId',
                            value: 1,
                            name:"dupInvcCpyCnt",
                            maxLength:2,
                            minValue:0,
                            fieldLabel: 'No. of Copies'
                        }]
                        }
                    ]
                };                
                var backupContainer = {
                    xtype: 'fieldset',
                    layout: 'hbox',
                    title: 'Backup',
                    disabled:true,
                    itemId: 'backupFieldset',
                    margin: '1px 1px 5px 5px',
                    defaults: {
                        margin: '5px 10px 5px 5px'
                    },
                    items: [ backupPrinterCombo,backupTrayCombo, {
                            xtype: 'cmcnumberfield',
                            width: 135,
                            id:'nonOceanBackupCpyId',
                            value: 1,
                            maxLength:2,
                            minValue:0,
                            name:"backupCopies",
                            fieldLabel: 'No. of Copies'
                        }
                    ]
                };              
                itemsArr = [{
                        xtype: 'container',
                        layout: 'hbox',
                        //title:'Print document',
                        margin: '1px 1px 5px 5px',
                        defaults: {
                            margin: '5px 10px 5px 5px'
                        },
                        items: [invoiceCheckBox, backupCheckBox,backupcnfgPath]
                    },
                    invoiceContainer,
                    backupContainer 
                    
                ];
                return itemsArr;

            }
        };
        return printForm;
    };

    var printWinObj = Ext.create('Ext.cmc.Window', {

        title: 'Print Invoice',
        height: 300,
        width: 710,
        modal: true,
        layout: 'fit',
        setCenterItemFuncCmc: FormObj
    });

    return printWinObj;

};