function taskbarWindow(windowID, text) {

    winj = windowID;

    Ext.getCmp(winj).on('close', function () {
        Ext.getCmp('idBottomBar' + windowID).destroy()
    });

    var funation_variable = "funct('" + windowID + "')";

    /* Ext.getCmp('mainPan').add({
        xtype: 'button',
        iconCls: 'delete',
        iconAlign: 'right',
        //cls:'my-background-hzctrsclass',
        id: 'idBottomBar' + windowID,
        html: text + '<img src="resources/images/delete.png" align="top" onClick=' + funation_variable + '>',
        handler: function (b) {
            buttonID = id;
            winID = windowID;
            Ext.getCmp(winID).toFront(true);
            if (Ext.getCmp(winID).isVisible() == false){
				//html: text + '<img src="resources/images/open.png" align="top" onClick=' + funation_variable + '>',
				Ext.getCmp(winID).show();
			}
        }
    }); */
	
	Ext.getCmp('mainPan').add({
		text:text,
		iconCls: 'taskbarDownArrow',
        iconAlign: 'right',
		id: 'idBottomBar' + windowID,
		handler: function (b) {
            //buttonID = id;
            winID = windowID;
            Ext.getCmp(winID).toFront(true);
            if (Ext.getCmp(winID).isVisible() == false){
				Ext.getCmp(winID).show();
			}
        }
	});	
	
}

function funct(winj) {
	Ext.getCmp(winj).toFront(true);
	if (Ext.getCmp(winj).isVisible() == false){
		Ext.getCmp(winj).show();	
	}
}