/*Modules.GlobalFuncs.heartBeat=function (){
	var runner = new Ext.util.TaskRunner();
//	var task = Ext.TaskManager.start({
	 var task = runner.newTask({
		 run: function () { 
		     Ext.Ajax.request({
	    		url : 'commonController/checkServerHeartBeat',
	    		params : {												
	    			userId : Modules.GlobalVars.loginUserId,
	    			userName : Modules.GlobalVars.loginUserName
	    		},
	    		timeout : 120000,
	    		method:'POST',
	    		success : function(response) {
					if (response.responseText) {
//							console.log("Heart is Beating....");
					}
	    		},
	    		failure : checkServerHeartBeatFailCallBckFn
	    	});
		 },
		 interval: (1000*60*Modules.GlobalVars.hearBeatTimeInterval)
	});
	 
	 task.start();
	 
	 var checkServerHeartBeatFailCallBckFn = function(response) { 
			task.stop();
			Ext.MessageBox.show({
				title: Modules.Msgs.info,
				msg: Modules.Msgs.serverNotResponding,
				buttons: Ext.Msg.OK,
				fn:function(){
					//task.start();
					window.onbeforeunload = function(){}
					window.location.reload();
				},
				icon: Ext.MessageBox.ERROR				
			});
	 };
				
}();
*/
/*
Ext.Ajax.on("beforerequest",function( conn, options, eOpts){
	
	 if(options.url){
		var myURL='';
		var arrayOfStrings = options.url.split('/');
		if(arrayOfStrings.length == 1){
		myURL=arrayOfStrings[0];
		}else if(arrayOfStrings.length > 1){
		myURL=arrayOfStrings[arrayOfStrings.length-1];
		}
		if(myURL.indexOf('get') != 0){  //.indexOf('get') == 0
			
			options.params = options.params || {};
			options.params.functionCode = Modules.GlobalVars.functionCode;
		}
	}
	
	
});
*/
Ext.Ajax.on("requestcomplete", function (conn, response, options) {


    function IsJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {

            if ((str.indexOf("<!DOCTYPE html>") != -1 || str.indexOf("<head>") != -1)  && str != {} && str != '') {
                //alert('You have been logged out due to inactivity or server restart');
    			Ext.getBody().mask();
    			Ext.MessageBox.show({
    				title: Modules.Msgs.info,
    				msg: Modules.Msgs.serverSessionTiimeOut,
    				buttons: Ext.Msg.OK,
    				fn:function(){
    					window.onbeforeunload = function(){};
    					window.location = contextPath + "/login?timeout" ;
    					//window.location.reload();
    				},
    				icon: Ext.MessageBox.ERROR				
    			});
    			Ext.getBody().mask();
				window.onbeforeunload = function(){};
				window.location = contextPath + "/login?timeout" ;
				//window.location.reload();
            }
        }
        return true;
    }
    


if(response.responseText && !IsJsonString(response.responseText)){	
	//alert('You have been logged out due to inactivity or server restart');
	window.onbeforeunload = function(){};
	window.location.reload();
}
});

Ext.Ajax.on('requestexception', function (ajax, response, options){
	
	 if(response.status == 302 ){
		Ext.getBody().mask();
		Ext.MessageBox.show({
			title: Modules.Msgs.info,
			msg: Modules.Msgs.serverSessionTiimeOut,
			buttons: Ext.Msg.OK,
			fn:function(){
				window.onbeforeunload = function(){};
				window.location = contextPath + "/login?timeout" ;
						//window.location.reload();
			},
			icon: Ext.MessageBox.ERROR				
		});
		Ext.getBody().mask();
	} else if(response.status == 0){
		window.location = contextPath + "/login?timeout" ;
		if(response.timedout === true && !Ext.isFunction(options.failure)){
			Ext.MessageBox.show({
				title: Modules.Msgs.info,
				msg: Modules.Msgs.serverRequestTimeOutError,
				buttons: Ext.Msg.OK,
				icon: Ext.MessageBox.ERROR				
			});
			
			return;
		}
	    /* Ext.Ajax.request({
	    		url : 'commonController/checkServerHeartBeat',
	    		params : {												
	    			userId : Modules.GlobalVars.loginUserId,
	    			userName : Modules.GlobalVars.loginUserName
	    		},
	    		timeout : 120000,
	    		method:'POST',
	    		success : function(response) {
	    			
					// Do nothing
	    		},
	    		failure : function(){
	    			
	    			Ext.getBody().mask();
	    			Ext.MessageBox.show({
	    				title: Modules.Msgs.info,
	    				msg: Modules.Msgs.serverSessionTiimeOut,
	    				buttons: Ext.Msg.OK,
	    				fn:function(){
	    					window.onbeforeunload = function(){};
	    					window.location.reload();
	    				},
	    				icon: Ext.MessageBox.ERROR				
	    			});
	    			Ext.getBody().mask();
	    		}
	    	});*/
	}else if(response.status == 403 ){
		Ext.MessageBox.show({
			title: Modules.Msgs.info,
			msg: Modules.Msgs.serverAccessDeniedError,
			buttons: Ext.Msg.OK,
			icon: Ext.MessageBox.ERROR				
		});
	}
});