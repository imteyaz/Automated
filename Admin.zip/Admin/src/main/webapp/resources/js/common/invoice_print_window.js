/**
 * 
 */
Ext.ns('Modules.common');

Modules.common.InvoicePrintHelper= function(config){
	 
	if(Ext.isEmpty(config)){
		return;
	}
	var param  = {
			 companyCd : Modules.GlobalVars.selectedCompanyCode,
			 cstmrCd   : config.party,	
			 pop	   : config.pop,
			 prfInvoices : config.prfInvoices,
			 emaildtls : {}
	};	
	if(config.isBulkPrinting){
		param.isBulkPrinting = config.isBulkPrinting;
		Modules.common.InvoicePrintWindow(param).show(); 	
	}else{
		Ext.getBody().mask(Modules.Msgs.loading);
		Ext.Ajax.request({
			url : 'invoicePrintEmailController/getEmailPrintDetails',
			params :param,
			timeout : 120000,
			success : function(response) {
				Ext.getBody().unmask();
				var temp= Ext.decode(response.responseText);
				var emaildtls=temp.value;
				var params = {
						prfInvoices : config.prfInvoices,
						party 		 : config.party,
						pop 	     : config.pop,
						emaildtls   : emaildtls
				};
				
				Modules.common.InvoicePrintWindow(params).show(); 							 
				
			},failure : function(){
				Ext.getBody().unmask();
				var params = {
						prfInvoices : prfInvoices,
						party 		 : config.party,
						pop 	     : config.pop					
				};				 
				Modules.common.InvoicePrintWindow(params).show(); 	
			}
		});			
	}
};

/**
 * @params config -> 
 * 
 * invoiceNumber- Array
 * party - String
 * pop - 
 */
Modules.common.InvoicePrintWindow = function (config) {
	 
	var prfInvoices,party,pop;
	var invcFlg=false;
	var billFlg=false;
	var templateCd='';
	var emaildtls='';
	var invcPrinter ='';
	var blPrinterCd ='';
	var invcTray ='';
	var billTray ='';
	var invcPrinterPath ='';
	var billPrinterPath ='';
	var invcPrinterPopCd ='';
	var billPrinterPopCd ='';
	
	if(config){
	prfInvoices = config.prfInvoices;
	party       = config.party;
	pop         = config.pop;
	emaildtls   = config.emaildtls;	
	}
	
	if(emaildtls){		
		if(emaildtls.invcFlg !=null && emaildtls.invcFlg==='Y'){
			invcFlg=true;
			if(emaildtls.invcTemplate !=null){
				templateCd=emaildtls.invcTemplate;
			}
			if(emaildtls.invcPrinter !=null){
				invcPrinter=emaildtls.invcPrinter;
				invcPrinterPath=emaildtls.invcPrnterCnfgPath;
			}
			if(emaildtls.invcPrnterTray !=null){
				invcTray=emaildtls.invcPrnterTray;
			}
		}
		if(emaildtls.bilFlg !=null && emaildtls.bilFlg==='Y'){
			billFlg=true;
			if(emaildtls.blPrinterCd !=null){
				blPrinterCd=emaildtls.blPrinterCd;
				billPrinterPath=emaildtls.blPrnterCnfgPath;
			}
			if(emaildtls.blPrinterTray !=null){
				billTray=emaildtls.blPrinterTray;
			}	
			
		}
		
		// In case of bulk printing
		/*
		 * 1. Invoice and Bill check should be checked
		 * 2. Templated code should be disabled
		 */
		if(config.isBulkPrinting){
			templateCd=undefined;
			billFlg=true;
			invcFlg=true;
		}
		
		
	}
    var FormObj = function () {
        var popupCustomerInvoiceStatusPrintForm = {
            xtype: 'cmcform',
            showFieldsetCmc: false,
            height: 270,
            width: 700,
            bbar: ['->', {
                    xtype: 'button',
                    text: 'Print',
                    iconCls: "print-type",
                    id:'invcprintbtnId',
                    validateData: function(){                    	
                    	 if(Ext.getCmp('invcPrintInvcFlgId').getValue() == false && 
				    			   Ext.getCmp('invcPrintBillFlgId').getValue()==false){
				    		   Ext.MessageBox.show({
			                        title: '',
			                        msg: Modules.Msgs.FlagMandatoryMsg,
			                        buttons: Ext.MessageBox.OK,
			                        icon: Ext.MessageBox.INFO
			                    });
							 return false;	
				    	   }			
                    	
                    	 
                    	 if(Ext.getCmp('invcPrintInvcFlgId').getValue() == true){ // For bulk printing PrintTemplateCode should not be sent                   		 
                    		 if( !config.isBulkPrinting && (Ext.getCmp('invcPrintInvcTemplateId').getValue() == ''  || Ext.getCmp('invcPrintInvcTemplateId').getValue()==null)){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.templtMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                    		 if(Ext.getCmp('invcPrintInvcPrntCdId').getValue() == ''  || Ext.getCmp('invcPrintInvcPrntCdId').getValue()==null){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.invcPrinterMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                      	 if(Ext.getCmp('invcPrintInvcOrginlCpyId').getValue() < 1  && Ext.getCmp('invcPrintInvcDuplCpyId').getValue() < 1){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.invcCpiesMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                    	 }
                    	
                    	 if(Ext.getCmp('invcPrintBillFlgId').getValue() == true){                    		 
                    		 if(Ext.getCmp('invcPrintBilPrntCdId').getValue() == ''  || Ext.getCmp('invcPrintBilPrntCdId').getValue()==null){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.bilPrnterMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }
                    		 if(Ext.getCmp('invcPrintBilCpysId').getValue() < 1 ){
  				    		   Ext.MessageBox.show({
  			                        title: '',
  			                        msg: Modules.Msgs.bilCopiesMandatoryMsg,
  			                        buttons: Ext.MessageBox.OK,
  			                        icon: Ext.MessageBox.INFO
  			                    });
  							 return false;	
  				    	   }                     	
                    	
                    	 }
                    	 
                    	return true;
                    	
                    },
                    handler: function () {		
                    	var form = this.up('cmcform').getForm();
                    	 var parenWindow = this.up('cmcwindow');
 		            	if(!form.isValid()){
 		            		Ext.MessageBox.show({ title : '',
 		        				msg : 'Invalid Form Data',
 		        				buttons:Ext.MessageBox.OK,
 		        				icon : Ext.MessageBox.ERROR
 							 });
 		        		return;
 		            	}
                    	if(Ext.getCmp('invcprintbtnId').validateData()){ 			    	
				    	
				    		 var invoiceflg;
							 var billflg;
							 var printType ;
									if(Ext.getCmp('invcPrintInvcFlgId').getValue()== true){
										invoiceflg='Y';							
									}else{
										invoiceflg='N';
									}
									if(Ext.getCmp('invcPrintBillFlgId').getValue()== true){
										billflg='Y';							
									}else{
										billflg='N';
									}
									if(Ext.getCmp('invcPrintInvcFlgId').getValue()== true && Ext.getCmp('invcPrintBillFlgId').getValue()==false){
										printType='INVOICE';
									}else if(Ext.getCmp('invcPrintInvcFlgId').getValue()== false && Ext.getCmp('invcPrintBillFlgId').getValue()==true){
										printType='BILL';
									}else {
										printType='INVOICE AND BILL';
									}
							var orginalFlg ='N';
							
							if(Ext.getCmp('invcPrintInvcOrginlCpyId').getValue() > 0){
								orginalFlg='Y';
							}
				    		 
				    		 var param = {
									 companyCd 		: Modules.GlobalVars.selectedCompanyCode,
									 cstmrCd  		: party,			 
									 invcPrintFlg 	: invoiceflg,
									 bilFlg			: billflg,
									 invcTemplate	: Ext.getCmp('invcPrintInvcTemplateId').getValue(),
									 orginalFlg		: orginalFlg,
									 printMode 		: 'P',
									 printType		: printType,
									 invcCopies		: Ext.getCmp('invcPrintInvcOrginlCpyId').getValue(),
									 invcPrinter	: Ext.getCmp('invcPrintInvcPrntCdId').getValue(),
									 blPrinterCd	: Ext.getCmp('invcPrintBilPrntCdId').getValue(),
									 blPrinterTray	: Ext.getCmp('invcPrintBilTrayId').getValue(),
									 blCpyCnt		: Ext.getCmp('invcPrintBilCpysId').getValue(),
									 dupInvcCpyCnt	: Ext.getCmp('invcPrintInvcDuplCpyId').getValue(),
							 		 invcPrnterTray	: Ext.getCmp('invcPrintInvcTrayId').getValue(),
							 		invcPrnterCnfgPath:invcPrinterPath,
							 		blPrnterCnfgPath: billPrinterPath,
							 		prfInvoices: Ext.JSON.encode(prfInvoices),
							 		invcPrinterPopCd : invcPrinterPopCd,
				    				billPrinterPopCd  : billPrinterPopCd
							 			
				    		 };				    		
				    		 Modules.GlobalFuncs.deleteEmptyProperties(param);
						 Ext.Ajax.request({
								url : 'invoicePrintEmailController/SendEmailPrint',
								params :param,
								timeout : 120000,
								success : function(response) {
									var msg = Ext.decode(response.responseText);
									if (msg.success == true) {	
									 Ext.MessageBox.show({
						                        title: '',
							                        msg: 'Request for print is submitted',
							                        buttons: Ext.MessageBox.OK,
							                        icon: Ext.MessageBox.INFO
							                    });
									 
									
									 parenWindow.close();
										
									
								}else{
									 Ext.MessageBox.show({
					                        title: '',
						                        msg: msg.message,
						                        buttons: Ext.MessageBox.OK,
						                        icon: Ext.MessageBox.INFO
						                    });
										
									}
								 
							}
							});
                    	
				    		 
				    	 }
                    }
                }
            ],

            setFormItemsFuncCmc: function () {
                var itemsArr = [];
                var invoicePrinterComboStore = {
                    model: 'invoicePrintLov',
                    url: 'invoicePrintEmailController/invoicePrintLov',
                    listeners: {
                        beforeload: function () {
//                        	this.proxy.extraParams.pop=pop;
                        	this.proxy.extraParams.printType='INVOICE';
                            this.proxy.extraParams.companyCd = Modules.GlobalVars.selectedCompanyCode;
                            this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
                            this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                        }
                    },
                    paging: true

                };
                var billPrinterComboStore = {
                        model: 'invoicePrintLov',
                        url: 'invoicePrintEmailController/invoicePrintLov',
                        listeners: {
                            beforeload: function () {
//                            	this.proxy.extraParams.pop=pop;
                            	this.proxy.extraParams.printType='BILL';
                                this.proxy.extraParams.companyCd = Modules.GlobalVars.selectedCompanyCode;
                                this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
                                this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                            }
                        },
                        paging: true

                    };
                var invoiceCheckBox = {
                    xtype: 'cmccheckboxfield',
                    boxLabel: 'Invoice',
                    name: 'invoice',
                    width: 80,
                    checked:invcFlg,
                    id:'invcPrintInvcFlgId',
                    inputValue: 'Y',
                    listeners : {										
						change : function(combo, newValue, oldValue, eOpts) {
							if(!Ext.isEmpty(newValue) && newValue ===true){
							     this.up('cmcform').down('#invoiceFieldset').enable();	
							     if(!config.isBulkPrinting && (emaildtls && emaildtls.invcTemplate !=null)){
							    		Ext.getCmp('invcPrintInvcTemplateId').setValue(emaildtls.invcTemplate);
									}
									if(emaildtls && emaildtls.invcPrinter !=null){
										Ext.getCmp('invcPrintInvcPrntCdId').setValue(emaildtls.invcPrinter);
									}
									if(emaildtls && emaildtls.invcPrnterCnfgPath != null){
										invcPrinterPath=emaildtls.invcPrnterCnfgPath;
									}
									if(emaildtls && emaildtls.invcPrnterTray !=null){
										Ext.getCmp('invcPrintInvcTrayId').setValue(emaildtls.invcPrnterTray);
									}
									Ext.getCmp('invcPrintInvcOrginlCpyId').setValue(1);
									Ext.getCmp('invcPrintInvcDuplCpyId').setValue(1);
								}else{
									this.up('cmcform').down('#invoiceFieldset').disable();	
									Ext.getCmp('invcPrintInvcPrntCdId').setValue('');
									Ext.getCmp('invcPrintInvcTrayId').setValue('');
									Ext.getCmp('invcPrintInvcTemplateId').setValue('');
									Ext.getCmp('invcPrintInvcOrginlCpyId').setValue('');
									Ext.getCmp('invcPrintInvcDuplCpyId').setValue('');
								}
						
                    }
                    }                    
                };          	

                var billCheckBox = {
                    xtype: 'cmccheckboxfield',
                    boxLabel: 'Bill',
                    name: 'bill',
                    id:'invcPrintBillFlgId',
                    checked:billFlg,
                    width: 80,
                    inputValue: 'Y',
                    listeners : {										
						change : function(combo, newValue, oldValue, eOpts) {
							if(!Ext.isEmpty(newValue) && newValue ===true){
								this.up('cmcform').down('#billFieldset').enable();
								if(emaildtls.blPrinterCd !=null){
									Ext.getCmp('invcPrintBilPrntCdId').setValue(emaildtls.blPrinterCd);
								}
								if(emaildtls.blPrnterCnfgPath != null){
									billPrinterPath=emaildtls.blPrnterCnfgPath;
								}
								if(emaildtls.blPrinterTray !=null){
									Ext.getCmp('invcPrintBilTrayId').setValue(emaildtls.blPrinterTray);
								}	
								Ext.getCmp('invcPrintBilCpysId').setValue(1);
							}else{
								this.up('cmcform').down('#billFieldset').disable();	
								Ext.getCmp('invcPrintBilPrntCdId').setValue('');
								Ext.getCmp('invcPrintBilTrayId').setValue('');
								Ext.getCmp('invcPrintBilCpysId').setValue('');
							}
						}
                    }                   
                };

                var invoicePrinterCombo = {
                    xtype: 'cmccombobox',
                    fieldLabel: 'Printer'+ "<span style='color: red'>*</span>",
                    displayField: 'code',
                    storeObjCmc: invoicePrinterComboStore,
                    valueField: 'code',
                    labelWidth: 50,
                    labelAlign: "left",
                    id:'invcPrintInvcPrntCdId',
                    width: 260,
                    name: 'invcPrinterCD',
                    matchFieldWidth: false,
                    margins: '0px 4px 0px 5px',
                    paging: true,                   
                    listeners: {
                    	select:function(combo, records, eOpt){
    						if(records && records[0]){    							
    							Ext.getCmp('invcPrintInvcTrayId').setValue(records[0].get('tray'));
    							invcPrinterPath=records[0].get('path');
    							invcPrinterPopCd=records[0].get('popCode');
    						}
    						
    					},
    					change:function(combo,newValue, oldValue, eOpts  ){
//    						this.getStore().load();
    						if(Ext.isEmpty(newValue)){
    							Ext.getCmp('invcPrintInvcTrayId').reset();
    							invcPrinterPopCd='';
    						}
    					},
    					afterrender : function(){
							this.setValue(invcPrinter);							
						}
                    	
                    },
                    columnsCmc:[
                                {
                                	header:'Printer Code',
                                	width:200,
                                	dataIndex:'code'
                                },
                                {
                                	header:'Path',
                                	width:300,
                                	dataIndex:'path'
                                },
                                {
                                	header:'Tray',
                                	width:90,
                                	dataIndex:'tray'
                                }
                                ]

                };

                var billPrinterCombo = {
                    xtype: 'cmccombobox',
                    fieldLabel: 'Printer',
                    displayField: 'code',
                    storeObjCmc: billPrinterComboStore,
                    valueField: 'code',
                    id:'invcPrintBilPrntCdId',
                    labelWidth: 50,
                    labelAlign: "left",
                    width: 260,
                    name: 'billPrinterCode',
                    margins: '0px 4px 0px 5px',
                    paging: true,
                    listeners: {
                    	select:function(combo, records, eOpt){
    						if(records && records[0]){    							
    							Ext.getCmp('invcPrintBilTrayId').setValue(records[0].get('tray'));
    							billPrinterPath=records[0].get('path');
    							billPrinterPopCd=records[0].get('popCode');
    						}
    						
    					},
    					change:function(combo,newValue, oldValue, eOpts  ){
//    						this.getStore().load();
    						if(Ext.isEmpty(newValue)){
    							Ext.getCmp('invcPrintBilTrayId').reset();
    							billPrinterPopCd='';
    						}
    					},
    					afterrender : function(){
							this.setValue(blPrinterCd);							
						}
                    },
                    columnsCmc:[
                                {
                                	header:'Printer Code',
                                	width:200,
                                	dataIndex:'code'
                                },
                                {
                                	header:'Path',
                                	width:300,
                                	dataIndex:'path'
                                },
                                {
                                	header:'Tray',
                                	width:90,
                                	dataIndex:'tray'
                                }
                                ]

                };
                var invcTrayCombo = {
                    xtype: 'cmctextfield',
                    fieldLabel:'Tray',
                    name:'invcTray',
                    id:'invcPrintInvcTrayId',
                	width:80,
                	labelWidth:40,
                	readOnly:true,
                	value:invcTray
                };
                var bilTrayCombo = {
                        xtype: 'cmctextfield',
                        fieldLabel:'Tray',
                        name:'invcTray',
                        id:'invcPrintBilTrayId',
                    	width:80,
                    	labelWidth:40,
                    	readOnly:true,
                    	value:billTray
                    };
               
                /**START Container..1 Component**/
                var invoiceContainer = {
                    xtype: 'fieldset',
//                    layout: 'hbox',
                    title: 'Invoice',
                    disabled:!(invcFlg),
                    itemId: 'invoiceFieldset',
                    margin: '1px 1px 10px 5px',
                    defaults: {
                        margin: '5px 10px 5px 5px'
                    },
                    items: [{xtype: 'container',
                            layout: 'hbox',
                            margin: '1px 1px 5px 5px',
                            defaults: {
                                margin: '5px 10px 5px 5px'
                            },
                            items: [
                            Modules.ocean.LovFactory.getPrintTemplateLov({
	                            width: 150,
	                            fieldLabel: 'Template',
	                            id:'invcPrintInvcTemplateId',
	                            value:(config.isBulkPrinting ? undefined : templateCd),	
	                            disabled:config.isBulkPrinting,
	                            validator:true,
	                            labelWidth: 60
                            }),
                        invoicePrinterCombo,invcTrayCombo
                        ]}, 
                        {
                            xtype: 'fieldset',
                            layout: 'hbox',
                            title: 'Copies',
                            margin: '1px 1px 10px 5px',
                            defaults: {
                                margin: '5px 10px 5px 5px'
                            },
                            items:[{
                            xtype: 'cmcnumberfield',
                            width: 135,
                            maxLength:2,
                            id:'invcPrintInvcOrginlCpyId',
                            value: 1,
                            minValue:0,
                            fieldLabel: 'No. of Originals'
                        },{
                            xtype: 'cmcnumberfield',
                            width: 135,
                            id:'invcPrintInvcDuplCpyId',
                            value: 1,
                            maxLength:2,
                            minValue:0,
                            fieldLabel: 'No. of Copies'
                        }]
                        },{
                        	xtype:'container',
                        	html:"<span style='color: red'>*For bulk printing Template will be taken from Party if defined or from POP otherwise</span>",
                        	hidden:!config.isBulkPrinting
                        }
                    ]
                };

                
                var billContainer = {
                    xtype: 'fieldset',
                    layout: 'hbox',
                    title: 'Bill',
                    disabled:!(billFlg),
                    itemId: 'billFieldset',
                    margin: '1px 1px 5px 5px',
                    defaults: {
                        margin: '5px 10px 5px 5px'
                    },
                    items: [ //billCheckBox,
                        
                        billPrinterCombo,bilTrayCombo, {
                            xtype: 'cmcnumberfield',
                            width: 135,
                            id:'invcPrintBilCpysId',
                            value: 1,
                            maxLength:2,
                            minValue:0,
                            fieldLabel: 'No. of Copies'
                        }
                    ]
                };              
                itemsArr = [{
                        xtype: 'container',
                        layout: 'hbox',
                        //title:'Print document',
                        margin: '1px 1px 5px 5px',
                        defaults: {
                            margin: '5px 10px 5px 5px'
                        },
                        items: [invoiceCheckBox, billCheckBox]
                    },
                    invoiceContainer,
                    billContainer 
                    
                ];
                return itemsArr;

            }
        };
        return popupCustomerInvoiceStatusPrintForm;
    };

    var popupCustomerInvoiceStatusPrintWinObj = Ext.create('Ext.cmc.Window', {

        title: 'Print Invoice/Bill',
        height: 320,
        width: 710,
        modal: true,
        layout: 'fit',
        setCenterItemFuncCmc: FormObj
    });

    return popupCustomerInvoiceStatusPrintWinObj;

};