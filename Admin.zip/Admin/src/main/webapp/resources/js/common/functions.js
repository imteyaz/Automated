/**
	**Following function is used to create a store
	**If all goes well it returns a store otherwise it returns an empty object with an alert message for developement purpose
	**It expects on object as a parameter having either model or fields and either url or data, else an empty object is returned
	**If the data is being read from local, then the queryTypeCmc = 'local' should be specified
**/
Modules.GlobalFuncs.getStore		=		function(argObj){
	
	if(!argObj){//Checking if any object has been passed or not to the function
		if(Modules.GlobalVars.distributionEnv){
			alert('Error: Store not created!!');
		}
		return {};
	}
	
	//Following is the object which would finally be passed while creating Ext.data.Store
	var configObj		=		{
		autoLoad:(argObj.autoLoad)?argObj.autoLoad:false//Setting autoLoad as per value passed to function
	};
	
	//Following if-else checks if either model or fields has been provided and attaches accordingly to the configObj
	if(argObj.model){
		configObj.model			=		argObj.model;
	}else if(argObj.fields){
		configObj.fields		=		argObj.fields;
	}else{
		if(Modules.GlobalVars.distributionEnv){
			alert('Error: Store not created!! No model or fields passed');
		}
		return {};
	}
	
	/*
		**Following is used to differentiate between local and remote store
		**If the store has to be local, argument object passed should contain a property as queryTypeCmc:'local'
		**If no queryTypeCmc is specified then it is assumed to be remote
		**If a store is local, then proxy details are not added to it
	*/
	if(!argObj.queryTypeCmc || argObj.queryTypeCmc=='remote'){
		
		if(!argObj.url){
			if(Modules.GlobalVars.distributionEnv){
				alert('Error: Store not created!! No Url passed');
			}
			return {};	
		}
		
		//Adding all proxy related details to it below
		configObj.proxy					=		{};
		configObj.proxy.type			=		'ajax';
		configObj.proxy.url				=		argObj.url;	
		configObj.proxy.reader			=		{};	
		configObj.proxy.reader.type		=		'json';	
		configObj.proxy.timeout       = 1800000;
		configObj.proxy.url				=		argObj.url;
		configObj.proxy.url				=		argObj.url;
		configObj.proxy.url				=		argObj.url;
		
		Ext.apply(configObj.proxy,argObj.proxyConfig || {});
	
	}else if(argObj.queryTypeCmc=='local'){
		if(!argObj.data){
			if(Modules.GlobalVars.distributionEnv){
				alert('Error: Store not created!! No Data passed');
			}
			return {};	
		}
		//Adding the data passed for the local store below
		configObj.data			=		argObj.data;
	}else{
		if(Modules.GlobalVars.distributionEnv){
			alert('Error: Store not created!! No Url or Data passed');
		}
		return {};	
	}
	
	//Following if statement adds the paging details to proxy
	if(argObj.paging){
		
		if(argObj.storeForComp=='grid'){
			configObj.pageSize		=		(Modules.GlobalVars && Modules.GlobalVars.recordsPerPageGrid)?Modules.GlobalVars.recordsPerPageGrid:25;
		}else if(argObj.storeForComp=='combo'){
			configObj.pageSize		=		(Modules.GlobalVars && Modules.GlobalVars.recordsPerPageCombo)?Modules.GlobalVars.recordsPerPageCombo:25;
		}
		
		if(!configObj.proxy){
			configObj.proxy			=		{};
		}
		
		if(!configObj.proxy.reader){
			configObj.proxy.reader	=		{};
		}
		
		if(!configObj.proxy.writer){
			configObj.proxy.writer	=		{};
		}
		//configObj.proxy.reader.root				=		'model.items';
		//configObj.proxy.reader.totalProperty	=		'model.totalCount';	
		configObj.proxy.reader.root				=		'data';
		configObj.proxy.reader.totalProperty	=		'totalCount';
		configObj.proxy.writer.root				=		'data';
		configObj.proxy.api = {
             read :  argObj.url	,
             create : argObj.insertUrl,
             update: argObj.updateUrl,
             destroy: argObj.deleteUrl,
         }; 
		// for remaining models also needs to configure?
	}
	
	if(argObj.extraParams){
		configObj.proxy.extraParams		=		argObj.extraParams;//extraParams has to be in object form - {k1:v1, k2:v2, k3:v3}		
	}
	
	if(argObj.listeners){
		configObj.listeners				=		argObj.listeners;//attaching the listeners
	}
	
	Ext.apply(configObj,argObj);
	//Creating the store below
	var storeObj						=		Ext.create('Ext.data.Store', configObj);
	
	/* //Attaching the listeners below
	if(argObj.beforeload){
		storeObj.on('beforeload', argObj.beforeload);
	}
	
	if(argObj.load){
		storeObj.on('load', argObj.load);
	} */
	storeObj.load = function(options){
		if(this.storeForComp === 'grid' && this.isLoading()){
			/*Ext.MessageBox.show({
		        msg : 'Previous request is in progress, Please wait ...',
				buttons : Ext.MessageBox.OK,
				icon : Ext.MessageBox.INFO
			}); */
			return false;
		}
		Ext.data.Store.prototype.load.call(this,options);
	};
	return storeObj;//returning the final store
};//EOF Modules.GlobalFuncs.getStore
/********************************************************************************************************/
/**
	**Following function is used to display parent panel in the tab
	**It expects an object as an argument having following properties:
		panelFunc:function creating the panel
		panelId:id of the paenl to be created and added to tabpanel
		panelFuncArgs:object which is passed as argument to the panel function. This can be put as {} if no arguments are there
		parentTabPanelId:id of the tab panel to which this panel will be added
	**If panelFunc and panelId are not passed then an alert error gets displayed and false is returned
	**If all goes well then the panel gets added to the main tab panel and is also activated
**/
Modules.GlobalFuncs.addPanelToTabPanel		=		function(argObj){
	
	if(!argObj){
		if(Modules.GlobalVars.distributionEnv){
			alert('No arguments passed to displayParentPanelTab function');
		}
		return false;
	}
	
	if(!argObj.panelFunc){
		if(Modules.GlobalVars.distributionEnv){
			alert('No panel function argument passed to displayParentPanelTab function');
		}
		return false;
	}
	
	if(!argObj.panelId){
		if(Modules.GlobalVars.distributionEnv){
			alert('No panel id argument passed to displayParentPanelTab function');
		}
		return false;
	}
	
	if(!argObj.parentTabPanelId){
		if(Modules.GlobalVars.distributionEnv){
			alert('No parent tabpanel id argument passed to displayParentPanelTab function');
		}		
		return false;
	}
	
	var panel = Ext.getCmp(argObj.panelId) || Ext.getCmp(argObj.parentTabPanelId).down('#'+argObj.panelId);
	if(panel){
		Ext.getCmp(argObj.parentTabPanelId).setActiveTab(panel);
		return true;
	}
	
	var isFromLink = true;
	
	if(argObj.panelFuncArgs && argObj.panelFuncArgs instanceof Ext.menu.Item){
		isFromLink = false;
	}
	
	var parentPanel = argObj.panelFunc((argObj.panelFuncArgs?argObj.panelFuncArgs:{}));
	if(parentPanel._accessCode == undefined){ // this condition becomes true, when screen opened from grid column hyperlink
		
		var functionList=Modules.GlobalVars.funAccessCodeObject;
		if(parentPanel._functionCode){
		for(var i=0;i<functionList.length;i++){
			var obj=functionList[i];
			if(obj.code && (parentPanel._functionCode === obj.code)){
				parentPanel._accessCode=obj.accessCode;
				break;
			}
				
			}
	}
	}
	
	if(parentPanel._functionCode && parentPanel._accessCode == undefined){
		Ext.MessageBox.show({
	        msg : 'You do not have access privilege to '+ parentPanel.title,
			buttons : Ext.MessageBox.OK,
			icon : Ext.MessageBox.INFO
		});
		
		return false;
		
	}
	
	Ext.getBody().mask(Modules.Msgs.loading);
	
//	var taskPanelAdd	=		new Ext.util.DelayedTask(function(){
		Ext.getBody().mask(Modules.Msgs.loading);
		var tab = argObj.panelFunc((argObj.panelFuncArgs?argObj.panelFuncArgs:{}));
		if(argObj.panelFuncArgs && argObj.panelFuncArgs.serviceType){
		tab._serviTypeGroup = argObj.panelFuncArgs && argObj.panelFuncArgs.serviceType;
		}
		if(argObj.panelFuncArgs && argObj.panelFuncArgs.accessCode){
		tab._accessCode = argObj.panelFuncArgs && argObj.panelFuncArgs.accessCode;
		}
		if(argObj.panelFuncArgs && argObj.panelFuncArgs.functionCode){
			tab._functionCode = argObj.panelFuncArgs && argObj.panelFuncArgs.functionCode;
		}
	
		Modules.GlobalVars.functionCode=tab._functionCode;
		Modules.GlobalVars.selectedServiceTypeCode = tab._serviTypeGroup;
		
		var addedPanel = Ext.getCmp(argObj.parentTabPanelId).add(tab);
		if(isFromLink){
			
			// Save search Criteria plugin should not load default value if screen is launched from hyperlink 
			try{
				addedPanel.down('form').getPlugin().loadDefault = false;
			}catch(e){
				//do nothing
			}
		}

	Ext.getCmp(argObj.parentTabPanelId).setActiveTab(addedPanel);
	Ext.getCmp(argObj.parentTabPanelId).doLayout();
	
	return addedPanel;
	
/*	var taskPanelAdd	=		new Ext.util.DelayedTask(function(){
		
		//Ext.getBody().unmask();
	});
	
	taskPanelAdd.delay(50);	*/	
};//EOF
/********************************************************************************************************/
/********************************************************************************************************/
/**
	**Following function is used to display window
	**It expects an object as an argument having following properties:
		winFunc:function creating and returning a window
		winId:id of the window created
		winFuncArgs:object which is passed as argument to the window function. This can be put as {} if no arguments are there or else ignored too
	**If winFunc and winId are not passed then an alert error gets displayed and false is returned
	**If all goes well then the window is displayed
**/
Modules.GlobalFuncs.displayWindow		=		function(argObj){
	
	if(!argObj){
		if(Modules.GlobalVars.distributionEnv){
			alert('No arguments passed to displayWindow function');
		}
		return false;
	}
	
	if(!argObj.winFunc){
		if(Modules.GlobalVars.distributionEnv){
			alert('No window function argument passed to displayWindow function');
		}
		return false;
	}
	
	if(!argObj.winId){
		if(Modules.GlobalVars.distributionEnv){
			alert('No window id argument passed to displayWindow function');
		}
		return false;
	}
	
	if(Ext.getCmp(argObj.winId)){
		if(!Ext.getCmp(argObj.winId).isVisible()){
			Ext.getCmp(argObj.winId).show();
		}
		Ext.getCmp(argObj.winId).toFront();
		return true;
	}
	
	Ext.getBody().mask(Modules.Msgs.loading);
	
	var taskWinDisplay	=		new Ext.util.DelayedTask(function(){
		var win			=		argObj.winFunc((argObj.winFuncArgs?argObj.winFuncArgs:{}));
		win.show();
		win.toFront();
	});	
	taskWinDisplay.delay(50);		
};//EOF
/********************************************************************************************************/
Modules.GlobalFuncs.getClearAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.clearActionTtl;
	argObj.iconCls		=		'clear';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		//Following dialog box seeks confirmation of the user before carrying out Clear task
		/*Ext.MessageBox.confirm(Modules.Msgs.confirmationRequested, Modules.Msgs.clearConfirmation, function(btn){
			if(btn=='yes'){//Checking if the user pressed YES button
				var finalRes		=		argObj.handlerFunc();
				return finalRes;
			}
		});*/
		var finalRes		=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getClearAction
/********************************************************************************************************/
Modules.GlobalFuncs.getDeleteAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.deleteActionTtl;
	argObj.iconCls		=		'delete';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		//Following dialog box seeks confirmation of the user before carrying out delete task
		Ext.MessageBox.confirm(Modules.Msgs.confirmationRequested, Modules.Msgs.deleteConfirmation, function(btn){
			if(btn=='yes'){//Checking if the user pressed YES button
				var finalRes		=		argObj.handlerFunc();
				return finalRes;
			}
		});	
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getDeleteAction
/********************************************************************************************************/
/**
	**Following function is used to mark records in a grid for delete
	**It expects the grid id to be sent to it else it displays an alert error message
	**This gridId should be sent as a property of argument object
**/
Modules.GlobalFuncs.getMarkDeleteAction	=	function(argObj){
	if(!argObj.gridId){
		if(Modules.GlobalVars.distributionEnv){
			alert('No grid id passed');
		}
		return false;
	}
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.markDeleteActionTtl;
	argObj.iconCls		=		'delete';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var grid		=		Ext.getCmp(argObj.gridId);
		if(!grid){
			return false;
		}
		if(!grid.getSelectionModel()){
			return false;
		}
		var selRecs		=		grid.getSelectionModel().getSelection();
		var selRecsLen	=		selRecs.length;
		if(!selRecsLen){
			Ext.MessageBox.show({
				title: Modules.Msgs.selRecFrst,
				msg: Modules.Msgs.noRecsSelected,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			});
			return false;
		}
		//Following dialog box seeks confirmation of the user before carrying out delete task
		Ext.MessageBox.confirm(Modules.Msgs.confirmationRequested, Modules.Msgs.markDelConfirmation, function(btn){
			if(btn=='yes'){//Checking if the user pressed YES button
				for(var i=0; i<selRecsLen; i++){
					var currentTrnsType		=		selRecs[i].get('trnsType');
					switch(currentTrnsType){
						case '':
							selRecs[i].set('trnsType','D');
						break;
						case 'I':
							selRecs[i].set('trnsType','DI');
						break;
						case 'U':
							selRecs[i].set('trnsType','DU');
						break;
					}
				}
				var finalRes		=		argObj.handlerFunc();
				return finalRes;
			}
		});	
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getDeleteAction
/********************************************************************************************************/
/**
	**Following function is used to unmark records in a grid for delete
	**It expects the grid id to be sent to it else it displays an alert error message
	**This gridId should be sent as a property of argument object
**/
Modules.GlobalFuncs.getUnMarkDeleteAction	=	function(argObj){
	if(!argObj.gridId){
		if(Modules.GlobalVars.distributionEnv){
			alert('No grid id passed');
		}
		return false;
	}
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.unmarkDeleteActionTtl;
	argObj.iconCls		=		'delete';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var grid		=		Ext.getCmp(argObj.gridId);
		if(!grid){
			return false;
		}
		if(!grid.getSelectionModel()){
			return false;
		}
		var selRecs		=		grid.getSelectionModel().getSelection();
		var selRecsLen	=		selRecs.length;
		if(!selRecsLen){
			Ext.MessageBox.show({
				title: Modules.Msgs.selRecFrst,
				msg: Modules.Msgs.noRecsSelected,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			});
			return false;
		}
		//Following dialog box seeks confirmation of the user before carrying out delete task
		Ext.MessageBox.confirm(Modules.Msgs.confirmationRequested, Modules.Msgs.unmarkDelConfirmation, function(btn){
			if(btn=='yes'){//Checking if the user pressed YES button
				for(var i=0; i<selRecs.length; i++){
					var currentTrnsType		=		selRecs[i].get('trnsType');
					switch(currentTrnsType){
						case 'D':
							selRecs[i].set('trnsType','');
						break;
						case 'DI':
							selRecs[i].set('trnsType','I');
						break;
						case 'DU':
							selRecs[i].set('trnsType','U');
						break;
					}
				}
				var finalRes		=		argObj.handlerFunc();
				return finalRes;
			}
		});	
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getDeleteAction
/********************************************************************************************************/
Modules.GlobalFuncs.getRetrieveAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.retrieveActionTtl;
	argObj.iconCls		=		'retrieve';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var finalRes	=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);
	return finalObj;
};//EOF Modules.GlobalFuncs.getRetrieveAction
/********************************************************************************************************/
Modules.GlobalFuncs.getAddAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.addActionTtl;
	argObj.iconCls		=		'add';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var finalRes	=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getAddAction
/********************************************************************************************************/
Modules.GlobalFuncs.getSaveAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.saveActionTtl;
	argObj.iconCls		=		'save';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var finalRes	=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getSaveAction
/********************************************************************************************************/
Modules.GlobalFuncs.getModifyAction = function(argObj){
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.modifyActionTtl;
	argObj.iconCls		=		'modify';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var finalRes	=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
	
};//EOF Modules.GlobalFuncs.getModifyAction
/********************************************************************************************************/
/********************************************************************************************************/
Modules.GlobalFuncs.getExitAction	=	function(argObj){
	
	argObj.text			=		argObj.text?argObj.text:Modules.LblsAndTtls.exitActionTtl;
	argObj.iconCls		=		'exit';
	argObj.handlerFunc	=		argObj.handler;
	argObj.handler		=		function(){
		var finalRes	=		argObj.handlerFunc();
		return finalRes;
	};	
	var finalObj		=		new Ext.Action(argObj);	
	return finalObj;
};//EOF Modules.GlobalFuncs.getSaveAction
/*************************************Compare Two Dates Function **************************************/
function compareTwoDates(startDate, startTime, endDate, endTime, dateSeparator, timeSeparator){
	var finalVal		=		false;
	
	if(!startDate || !endDate || !dateSeparator || !timeSeparator){
		return finalVal;
	}
	
	var startDateArr	=		startDate.split(dateSeparator);
	var endDateArr		=		endDate.split(dateSeparator);
	
	if(!startDateArr || !endDateArr){
		return finalVal;
	}
	
	if(startTime){
		var startTimeArr		=	startTime.split(timeSeparator);
		if(startTimeArr[0] && startTimeArr[1]){
			var startFullDate	=	new Date(startDateArr[2], (startDateArr[1]-1), startDateArr[0], startTimeArr[0], startTimeArr[1]);
		}else{
			var startFullDate	=	new Date(startDateArr[2], (startDateArr[1]-1), startDateArr[0]);
		}
	}else{
		var startFullDate		=	new Date(startDateArr[2], (startDateArr[1]-1), startDateArr[0]);
	}
	
	var startMs					=	startFullDate.getTime();
	
	if(endTime){
		var endTimeArr			=	endTime.split(timeSeparator);
		if(endTimeArr[0] && endTimeArr[1]){
			var endFullDate		=	new Date(endDateArr[2], (endDateArr[1]-1), endDateArr[0], endTimeArr[0], endTimeArr[1]);
		}else{
			var endFullDate		=	new Date(endDateArr[2], (endDateArr[1]-1), endDateArr[0]);
		}
	}else{
		var endFullDate	=	new Date(endDateArr[2], (endDateArr[1]-1), endDateArr[0]);
	}
	
	var endMs			=	endFullDate.getTime();
	
	if(endMs>=startMs){
		finalVal		=	true;
	}
	
	return finalVal;
}
/********************************************************************************************************/
/**
	**Following function is used to display/show grid editor window
	**It expects following arguments:
		**winConfigFunc - Name of function which will return the config object of grid editor window
		**winConfigFucnArgObj - Argument object which should be passed to winConfigFunc
		**openModeCmc - should be ADD or EDIT as per the case
		**winX - Any x cordinate which user wants to give to window. This will override everyother value
		**winY - Any y cordinate which user wants to give to window. This will override everyother value
		**editItmDblClckEventObj - It is the double click event object to be passed only in case of EDIT 
	**The function will display the window at the appropriate location
**/
Modules.GlobalFuncs.showGridEditorWin	=	function(argObj){
	
	//Checking below if the function which will return window config object has been passed or not
	if(!argObj.winConfigFunc){
		if(Modules.GlobalVars.distributionEnv){
			alert('No configuration function passed');
		}
		return false;
	}
	
	//Getting and storing the window config object below
	var winConfigObj	=		argObj.winConfigFunc(argObj.winConfigFucnArgObj?argObj.winConfigFucnArgObj:{});
	
	//Alert if no config object returned or if the config object does not have any gridId in it
	if(!winConfigObj || !winConfigObj.gridIdCmc){
		if(Modules.GlobalVars.distributionEnv){
			alert('No configuration object or grid passed for window to be created');
		}
		return false;
	}
	
	//Updating the openModeCmc of config object
	winConfigObj.openModeCmc	=	argObj.openModeCmc?argObj.openModeCmc:'ADD';
	
	/**
		**Beginning the code for dynamically assign X and Y to the new window
		**The code checks the mode first
			**If the mode is edit and itemdblclick event object has been passed then it takes the x and y from that event
			**For all other cases it will take the position of grid and assign x and y from it
		**Code will generate the dynamic x and y but will check if the x and y have been passed as an argument
		**If x and y have been passed as an argument as winX and winY then the code will apply them 
		**Else code will check if the dynamic x and y generated have values or not. If values are there then they are applied
		**NOTE - Currently, the value of X in case of dynamic will always come from grid position only in both ADD & EDIT
	**/
	var winDynamicX				=	'';
	var winDynamicY				=	'';
	
	var gridPosArr				=	Ext.getCmp(winConfigObj.gridIdCmc).getPosition();
	if(gridPosArr && gridPosArr[0] && gridPosArr[1]){
		winDynamicX				=	gridPosArr[0];
		winDynamicY				=	gridPosArr[1];
	}
	
	if(winConfigObj.openModeCmc.toUpperCase()=='EDIT' && argObj.editItmDblClckEventObj && argObj.editItmDblClckEventObj.getX && argObj.editItmDblClckEventObj.getY){
		//winDynamicX			=	argObj.editItmDblClckEventObj.getX();
		winDynamicY				=	argObj.editItmDblClckEventObj.getY();
	}
	
	if(argObj.winX){
		winConfigObj.x			=	argObj.winX;
	}else if(winDynamicX){
		winConfigObj.x			=	winDynamicX;
	}
	
	if(argObj.winY){
		winConfigObj.y			=	argObj.winY;
	}else if(winDynamicY){
		winConfigObj.y			=	winDynamicY;
	}
	
	/**Ending the code for dynamically assign X and Y to the new window**/
	
	Ext.getBody().mask(Modules.Msgs.loading);
	
	var taskWinDisplay	=		new Ext.util.DelayedTask(function(){
		var win			=		Ext.create('Ext.cmc.GridEditorWindow', winConfigObj);
		win.show();
		win.toFront();
	});	
	
	taskWinDisplay.delay(50);
	
};//EOF Modules.GlobalFuncs.showGridEditorWin
/********************************************************************************************************/
/**
	**Following function is used to get Delete Marked column for grid
	**It can be called without passing any argument
	**Though, if its passed an argument then all the properties passed in the argument get applied to the column returned
**/
Modules.GlobalFuncs.getDeleteMarkedCol	=	function(argObj){
	var colObj		=		{
		text:Modules.LblsAndTtls.delMarkedLbl,
		dataIndex:'trnsType',
		align:'center',
		width:70,
		renderer:function(value, metaData, record, rowIndex, colIndex, store, view){
			if(value=='D' || value=='DI' || value=='DU'){
				dispVal			=		Modules.LblsAndTtls.yesLbl;
				metaData.tdCls	=		'delMarkedCol';
			}else{
				dispVal	=	'';
			}
			return dispVal;
		}
	};
	if(argObj){
		Ext.apply(colObj, argObj);
	}
	return colObj;
};//EOF Modules.GlobalFuncs.showGridEditorWin

Modules.GlobalFuncs.getParamsObjFromIdNmVal	=	function(argObj){
	var finalObj		=		{};
	if(!argObj){
		return finalObj;
	}
	var rec				=		'';
	for(var i=0; i<argObj.length; i++){
		rec		=		argObj[i];
		if(rec.name && rec.id){
			if(!Ext.getCmp(rec.id)){
				if(Modules.GlobalVars.distributionEnv){
					alert('Error: component does not exist with the id passed to validate params function');
				}
				return {};
			}
			finalObj[rec.name]		=		(rec.raw)?Ext.getCmp(rec.id).getRawValue():Ext.getCmp(rec.id).getValue();
		}else if(rec.name && rec.val){
			finalObj[rec.name]		=		rec.val;
		}else{
			if(Modules.GlobalVars.distributionEnv){
				alert('Error: name, id or value not passed to validate params function');
			}
			return {};
		}
	}//End of for loop
	return finalObj;
};//EOF

Modules.GlobalFuncs.hideLoadingDiv    =    function(){

    if(document.getElementById && document.getElementById('loadingMsg')){
        var element    =    document.getElementById('loadingMsg');
        element.parentNode.removeChild(element);
    }
    if(document.getElementById && document.getElementById('loadingMsg')){
        document.getElementById('loadingMsg').style.visibility =    'hidden';
    }
    if(document.all && document.all.loadingMsg){
        document.all.loadingMsg.style.visibility    =    'hidden';
    }
    if(document.layers && document.loadingMsg){
        document.loadingMsg.visibility                =    'hidden';
    }
};

Modules.GlobalFuncs.getDefaultCriteriaPopulate = function(screenId) {
	Ext.Ajax.request({
		url : 'getDefaultSaveSearchStatusMonitor',
		params : {
			userId : Modules.GlobalVars.loginUserId,
			screenId : screenId,
			serviceType : Modules.GlobalVars.selectedServiceTypeCode,
			companyCode : Modules.GlobalVars.selectedCompanyCode
		},
		method : 'GET',
		success : function(response) {
			var temp = Ext.decode(response.responseText);

			if (temp.totalCount > 0) {
				var searchCriteria = temp.items[0].searchCriteriaData;
				if (searchCriteria) {
					var temp = searchCriteria.split(",");
					for ( var a = 0; a < temp.length; a++) {
						var required = temp[a].split(":");
						var id = required[0];
						if (id == 'statusMonitorFromTimeId'
								|| id == 'statusMonitorToTimeId'
								|| id == 'statusMonitorLoadTimeFromId'
								|| id == 'statusMonitorLoadTimeToId') {
							if (required[1].length > 0) {
								value = required[1] + ':' + required[2];
							} else {
								value = '';
							}
						} else
							var value = required[1];
						if (value == 'true')
							Ext.getCmp(id).setValue(true);
						if (value == 'false')
							Ext.getCmp(id).setValue(false);
						if (id == 'uploadDownLoadIndicatorId'
								&& value == 'null')
							Ext.getCmp('uploadDownLoadIndicatorId').setValue(
									false);
						else if (id == 'uploadDownLoadIndicatorId'
								&& value != 'null')
							Ext.getCmp('uploadDownLoadIndicatorId').setValue(
									true);
						if (id != 'uploadDownLoadIndicatorId') {
							if (value == 'null')
								Ext.getCmp(id).setValue("");
							else
								Ext.getCmp(id).setValue(value);
						}
					}
				}
			}

		},
		failure : function(response) {
		}
	});
};

Modules.GlobalFuncs.isEmptyObj = function(obj) {
	
	for ( var key in obj) {
		if (obj[key] instanceof Array) {
			var arr = obj[key];
			for ( var arrKey in arr) {
				if (!Ext.isEmpty(arr[arrKey])) {
					return false;
				}
			}
		} else if (!Ext.isEmpty(obj[key])) {
			return false;
		}
	}
	return true;
};
  

Modules.GlobalFuncs.stringToBooleanConvertor = function(v) {
	return (v === "Y" || v === true ) ? true : false;
};

Modules.GlobalFuncs.nullifyEmptyProperties = function(obj){
	if (!obj)return;
	
	for (key in obj) {
		if (Ext.isEmpty(obj[key])) {
			obj[key]=null;
		}
	}
};

Modules.GlobalFuncs.deleteEmptyProperties = function(obj){
	if (!obj)return;
	
	for (key in obj) {
		if (Ext.isEmpty(obj[key])) {
			delete obj[key];
		}
	}
};

/**
 * TODO: should be confuguration driven
 */
Ext.ns('Ext.cmc');
Ext.cmc.CurrencyRenderer = function(v){
	if(Ext.isEmpty(v)){
		return v;
	}
	else{
		 return Ext.util.Format.numberRenderer('0.00')(v);// Ext.util.Format.usMoney(v); JIRA 715
	}
};

Modules.GlobalFuncs.getDecimalFormater = function(precision){
	precision =  precision || 2;
	var fieldPattern = '';
	if(precision > 0){
		fieldPattern='.';
		for(var i=1; i<=precision; i++){
			fieldPattern=fieldPattern+"0";
		}
	}
	return Ext.util.Format.numberRenderer(fieldPattern);
};



Modules.GlobalFuncs.decimalTruncRenderer = function(formatter) { // formatter values should be numeric value eg : Modules.GlobalFuncs.decimalTruncRenderer(4)
	var precision=formatter;
    return function(v,metaData,record, rowIndex,colIndex,store,view ){
    	try{
    		    var value=v.toString();
        		var str="";
        		var prefix=value.substr(0,value.indexOf('.')+1);
        	    var varStr=value.substr(value.indexOf('.')+1);
        	    if(value.indexOf('.') == -1){
        	    	prefix=value+".";
        	    	for(var i=0; i<precision; i++){
        	    		str+="0";
        			}
        	    }else if(varStr.length == precision){
        	    	str=value.substr(value.indexOf('.')+1);
        	    }else if(varStr.length > precision){
        	    	str=varStr.substr(0,precision);
        	    }else if(varStr.length < precision){
        	    	str=varStr;
        	    	for(var i=str.length; i<precision; i++){
        	    		str+="0";
        			}
        	    }
        	     return (prefix+str);
               }catch(error){
            	   return value;
        	   }
               
        	}
   
};

/**
 * 
 */
Modules.GlobalFuncs.compareDateOnly = function(fromDateStr,toDateStr){
	
	if(fromDateStr && (fromDateStr.indexOf(':') > -1)){
		var fromDate = Ext.Date.clearTime(Ext.Date.parse(fromDateStr.trim(),Modules.GlobalVars.dateTimeFormatGlobal));
	}else{
		fromDate = Ext.Date.parse(fromDateStr.trim(),Modules.GlobalVars.dateFormatGlobal);
	}
	
	if(toDateStr && (toDateStr.indexOf(':') > -1)){
		var toDate = Ext.Date.clearTime(Ext.Date.parse(toDateStr.trim(),Modules.GlobalVars.dateTimeFormatGlobal));
	}else{
		toDate = Ext.Date.parse(toDateStr.trim(),Modules.GlobalVars.dateFormatGlobal);
	}
	
	return fromDate <= toDate;
};




Modules.GlobalFuncs.isObjectsEquals =  function objectEquals(x, y) {
    // if both are function
    if (x instanceof Function) {
        if (y instanceof Function) {
            return x.toString() === y.toString();
        }
        return false;
    }
    if (x === null || x === undefined || y === null || y === undefined) { return x === y; }
    if (x === y || x.valueOf() === y.valueOf()) { return true; }

    // if one of them is date, they must had equal valueOf
    if (x instanceof Date) { return false; }
    if (y instanceof Date) { return false; }

    // if they are not function or strictly equal, they both need to be Objects
    if (!(x instanceof Object)) { return false; }
    if (!(y instanceof Object)) { return false; }

    var p = Object.keys(x);
    return Object.keys(y).every(function (i) { return p.indexOf(i) !== -1; }) ?
            p.every(function (i) { return objectEquals(x[i], y[i]); }) : false;
};

Modules.GlobalFuncs.getSearchObject =  function (tabPanelId, qryFormItemId) {
	var searchObj = Ext.getCmp(tabPanelId).down('#'+qryFormItemId).getValues();	
	searchObj.userId = Modules.GlobalVars.loginUserId;
	searchObj.serviceType = Modules.GlobalVars.selectedServiceTypeCode,
	searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
	searchObj.maxLimitRecords = Modules.GlobalVars.maxLimitRecords;
	
	return searchObj;
};


