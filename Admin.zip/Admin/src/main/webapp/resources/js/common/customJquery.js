/*$(":checkbox").click(function() {
	console.log("coming inside");
    if(this.checked) {
        //Do stuff
    }
});

$(".onoffswitch-checkbox").change(function() {
	console.log("coming inside onoffswitch");
    if(this.checked) {
        //Do stuff
    }
});


$("input:checkbox[type=hidden]").bind("change", function() {
   
	console.log("coming inside hidden");
	
});


$('.onoffswitch').click(function() {
	console.log("coming inside onoffswitch label");
    if(this.checked) {
        //Do stuff
    }
});

$('.onoffswitch').bind("click", function() {
   
	console.log("coming inside hidden 123");
	
});*/

function updateModel(row){
	
	console.log("coming here record in updateModel");
	var alertConfigurationStore= Ext.getCmp('alertConfigurationMasterGridId').getStore();
	var divId = '#R' + row ;
	var currentRowChecked = $(divId).find('input:hidden'); // get all checkbox //:checked
	var checkedLength = currentRowChecked.length ;
	
	var activeRoles = "" ;
	var i = 0 ;
	var alertsubscribers = alertConfigurationStore.getAt(row).alertsubscribersMap();
	
	$(currentRowChecked).each(function( index, element ){
		i++ ;
		var cbVal = $(this).val() ;
		var isChecked = $(this).prop("checked") ;
		
		if(isChecked){
			alertsubscribers.getAt(index).set('isActive','Y');
			activeRoles  = activeRoles  + cbVal ; 
			if(i!= checkedLength){
				activeRoles  = activeRoles  + "," ;
			}
		}
		else{
			alertsubscribers.getAt(index).set('isActive','N');
		}
});
	alertConfigurationStore.getAt(row).set("subscribers",activeRoles);
}