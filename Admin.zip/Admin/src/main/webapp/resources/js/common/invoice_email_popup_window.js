/**
 * 
 */

Modules.common.validateField= function(records, FieldName, FieldValue, noWarning){	
	var record= records[0];
	if(records.length == 0){
		 Ext.MessageBox.show({
              title: '',
              msg: Modules.Msgs.selRecFrst,
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.INFO
          });
		 return false;
	 }	
	for(var j=0;j<records.length;j++){							 
		  if(record.get(FieldName) != records[j].get(FieldName) ){
			  if(!noWarning){
				  
			  Ext.MessageBox.show({
                  title: '',
                  msg: 'Please Select Invoices of Same '+FieldValue,
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.INFO
              });			
			  }
			 return false;
		  }
	}
	return true;
};

Modules.common.InvoiceEmailHelper= function(config){
	if(Ext.isEmpty(config)){
		return;
	}
		  var param = {
				  	 companyCd : Modules.GlobalVars.selectedCompanyCode,
					 cstmrCd   : config.party,	
					 pop	   : config.pop
			 };
		  Ext.Ajax.request({
				url : 'invoicePrintEmailController/getEmailPrintDetails',
				params :param,
				timeout : 120000,
				success : function(response) {
					 var temp= Ext.decode(response.responseText);
					 var emaildtls=temp.value;		
					 var params = {
							 prfInvoices : config.prfInvoices,
							 party 		 : config.party,
							 pop 	     : config.pop,
							 emaildtls   : emaildtls
					 };
					 
					 Modules.common.EmailWindow(params).show(); 									 
				},
				failure : function(){
				var params = {
							 prfInvoices : prfInvoices,
							 party 		 : config.party,
							 pop 	     : config.pop
					 };					 
					 Modules.common.EmailWindow(params).show();				 
				}
				});	
};





Modules.common.EmailWindow= function(config)
{
	
	var prfInvoices,party,pop;
	var invcFlg=false;
	var billFlg=false;
	var templateCd='';
	var emaildtls='';
	var mailId='';
	
	
	if(config){
	prfInvoices = config.prfInvoices;
	party       = config.party;
	pop         = config.pop;
	partyFlg    = config.partyFlg;
	emaildtls   = config.emaildtls;
	}
	if(emaildtls){		
		if(emaildtls.invcFlg !=null && emaildtls.invcFlg==='Y'){
			invcFlg=true;
			if(emaildtls.invcTemplate !=null){
				templateCd=emaildtls.invcTemplate;
				
			}
		}
		if(emaildtls.bilFlg !=null && emaildtls.bilFlg==='Y'){
			billFlg=true;
		}
			
		if(emaildtls.emailAddr !=null){
			mailId=emaildtls.emailAddr;
		}	
		
	}
	
	var FormObj =function(){
	var popupCustomerInvoiceStatusPrintForm = {
			   xtype:'cmcform',
			   showFieldsetCmc:false,
			   height : 195,
			   width: 480,
			   bbar:['->',{
					   xtype : 'button',
				       text : 'Send Mail',
				       iconCls : "resend",
				       handler : function(){	
				    	   var form = this.up('cmcform').getForm();
				    	   var parenWindow = this.up('cmcwindow');
	 		            	if(!form.isValid()){
	 		            		Ext.MessageBox.show({ title : '',
	 		        				msg : 'Invalid Form Data',
	 		        				buttons:Ext.MessageBox.OK,
	 		        				icon : Ext.MessageBox.ERROR
	 							 });
	 		        		return;
	 		            	}
				    	   var errFlg=false;
				    	   
				    		 if(Ext.getCmp('invcPrintEmailInvcFlgId').getValue() == true){   
					    	   if(Ext.getCmp('invcPrintEmailInvcTemplateId').getValue() == '' || Ext.getCmp('invcPrintEmailInvcTemplateId').getValue()== null){
					    		   Ext.MessageBox.show({
				                        title: '',
				                        msg: Modules.Msgs.templtMandatoryMsg,
				                        buttons: Ext.MessageBox.OK,
				                        icon: Ext.MessageBox.INFO
				                    });
					    		   errFlg=true;
								 return false;			    		   
					    		   
					    	   }
				    		 }
				    	   if(Ext.getCmp('invcPrintEmailToEmailAddressId').getValue() == '' || Ext.getCmp('invcPrintEmailToEmailAddressId').getValue()== null){
				    		   Ext.MessageBox.show({
			                        title: '',
			                        msg: Modules.Msgs.toMailIdMandatoryMsg,
			                        buttons: Ext.MessageBox.OK,
			                        icon: Ext.MessageBox.INFO
			                    });
				    		   errFlg=true;
							 return false;			    		   
				    		   
				    	   }
				    	   if(Ext.getCmp('invcPrintEmailInvcFlgId').getValue() == false && 
				    			   Ext.getCmp('invcPrintEmailBillFlgId').getValue()==false){
				    		   Ext.MessageBox.show({
			                        title: '',
			                        msg: Modules.Msgs.FlagMandatoryMsg,
			                        buttons: Ext.MessageBox.OK,
			                        icon: Ext.MessageBox.INFO
			                    });
				    		   errFlg=true;
							 return false;	
				    	   }				    	   
				    	 if(!errFlg)  {				    		 
				    		 var invoiceflg;
							 var billflg;
							 var printType ;
									if(Ext.getCmp('invcPrintEmailInvcFlgId').getValue()== true){
										invoiceflg='Y';							
									}else{
										invoiceflg='N';
									}
									if(Ext.getCmp('invcPrintEmailBillFlgId').getValue()== true){
										billflg='Y';							
									}else{
										billflg='N';
									}
									if(Ext.getCmp('invcPrintEmailInvcFlgId').getValue()== true && Ext.getCmp('invcPrintEmailBillFlgId').getValue()==false){
										printType='INVOICE';
									}else if(Ext.getCmp('invcPrintEmailInvcFlgId').getValue()== false && Ext.getCmp('invcPrintEmailBillFlgId').getValue()==true){
										printType='BILL';
									}else {
										printType='INVOICE AND BILL';
									}
									var orginalFlg ='N';
									
									 
				    		 
				    		 var param = {
									 companyCd : Modules.GlobalVars.selectedCompanyCode,
									 cstmrCd  : party,			 
									 invcPrintFlg : invoiceflg,
									 bilFlg: billflg,
									 invcTemplate:Ext.getCmp('invcPrintEmailInvcTemplateId').getValue(),
									 orginalFlg:'N',
									 printMode : 'E',
									 printType:printType,
									 emailAddr:Ext.getCmp('invcPrintEmailToEmailAddressId').getValue(),
									 ccMailId:Ext.getCmp('invcPrintEmailCCEmailAddressId').getValue(),
									 prfInvoices: Ext.JSON.encode(prfInvoices)
						 };									   
						
						 Ext.Ajax.request({
								url : 'invoicePrintEmailController/SendEmailPrint',
								params :param,
								timeout : 120000,
								success : function(response) {							
									var msg = Ext.decode(response.responseText);
									if (msg.success == true) {
										 Ext.MessageBox.show({
						                        title: '',
							                        msg: 'Email Sent Successfully',
							                        buttons: Ext.MessageBox.OK,
							                        icon: Ext.MessageBox.INFO
							                    });
										 parenWindow.close();
											
									
								}else{
									 Ext.MessageBox.show({
					                        title: '',
						                        msg: msg.message,
						                        buttons: Ext.MessageBox.OK,
						                        icon: Ext.MessageBox.INFO
						                    });
										
									}
								 
							}
							});
				    		 
				    	 }
				    
					}
			   }
			],
				
			   setFormItemsFuncCmc : function() {
				   var itemsArr = [];
				   	
					var invoiceCheckBox=
					{
						xtype:'cmccheckboxfield',
						boxLabel:'Invoice',
						name:'invoice',
						width:60,
						checked:invcFlg,
						id:'invcPrintEmailInvcFlgId',
						inputValue:'Y',
						  listeners : {										
								change : function(combo, newValue, oldValue, eOpts) {
									if(!Ext.isEmpty(newValue) && newValue ===true){	
										Ext.getCmp('invcPrintEmailInvcTemplateId').setReadOnly(false);
									   if(emaildtls && emaildtls.invcTemplate !=null){
									    		Ext.getCmp('invcPrintEmailInvcTemplateId').setValue(emaildtls.invcTemplate);
									    		
											}											
										}else{
											Ext.getCmp('invcPrintEmailInvcTemplateId').setValue('');	
											Ext.getCmp('invcPrintEmailInvcTemplateId').setReadOnly(true);
										}
								
		                    }
		                    }
						
					};
					
					var billCheckBox=
					{
							xtype:'cmccheckboxfield',
							boxLabel:'Bill',
							id:'invcPrintEmailBillFlgId',
							name:'bill',
							checked:billFlg,
							width:60,
							inputValue:'Y'
					};
					
					
			 var toMailTextField = {
					xtype : 'cmctextfield',
					name : 'toEmailAddress',
					id:'invcPrintEmailToEmailAddressId',
					fieldLabel : 'To' + "<span style='color: red'>*</span>",
					//vtype : 'email',
					width : 350,
					value:mailId,
					labelWidth : 30,
					labelAlign : "left",
					margin : '0px 9px 0px 20px',
					regex: /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;,.](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/,
					labelSeparator : ''

				};	   
				 var ccMailTextField ={
								xtype: 'cmctextfield',
								id: 'ccMailId',
								name: 'ccEmailAddress',
								id:'invcPrintEmailCCEmailAddressId',								
								fieldLabel: 'CC',//Modules.LblsAndTtls.customerCCMailTtl,
								//vtype: 'email',
								width:350,
								labelWidth:30,
								regex: /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;,.](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/,
								labelAlign:"left",
								margin : '0px 9px 0px 20px',
								labelSeparator:''
								
						};
													
					/**START Container..1 Component**/
					var container1 = {
							xtype : 'container',
							layout : 'hbox',
							margin : '1px 1px 20px 10px',
							defaults : {
								margin : '5px 10px 10px 5px'
							},
							items : [		                        {
	                            xtype: 'fieldset',
	                            layout: 'hbox',
	                            //title: 'Copies',
	                            margin: '1px 1px 10px 5px',
	                            defaults: {
	                                margin: '5px 10px 5px 5px'
	                            },
	                            items:[invoiceCheckBox,Modules.ocean.LovFactory.getPrintTemplateLov({
			                         fieldLabel: 'Template',
			                         id:'invcPrintEmailInvcTemplateId',
			                         width:200,
			                         value:templateCd,
			                         validator:true,
//			                         readOnly: templateFlg,
			                         labelWidth:60
			                     })]
	                        },billCheckBox]
					};
					
					var container2 = {
							xtype : 'container',
							layout : 'hbox',
							margin : '1px 1px 2px 1px',
							/*defaults : {
								margin : '0px 10px 0px 50px'
							},*/
							items : [toMailTextField]
					};
					
					var container3 = {
							xtype : 'container',
							layout : 'hbox',
							margin : '1px 1px 2px 1px',
							/*defaults : {
								margin : '0px 10px 0px 50px'
							},*/
							items : [ccMailTextField]
					};

					itemsArr = [container1,container2,container3];
					return itemsArr;
			 
			   },
			   listeners:{
				   render:function(){
					   if(emaildtls && emaildtls.invcFlg !=null && emaildtls.invcFlg==='Y' ){
						   if(emaildtls.invcTemplate !=null){
							   Ext.getCmp('invcPrintEmailInvcTemplateId').setValue(emaildtls.invcTemplate);
						   }				    		
				    		Ext.getCmp('invcPrintEmailInvcTemplateId').setReadOnly(false);
						}											
					else{
						Ext.getCmp('invcPrintEmailInvcTemplateId').setValue('');	
						Ext.getCmp('invcPrintEmailInvcTemplateId').setReadOnly(true);
					}
				   }
			   }
	   };
	   return popupCustomerInvoiceStatusPrintForm;
	   };
	
	   var popupCustomerInvoiceStatusPrintWinObj = Ext.create('Ext.cmc.Window', {
			 
			   	title:	Modules.common.labels.emailWinTitle,
			   	height : 205,
				width: 500,
				modal:true,
				setCenterItemFuncCmc :FormObj			 
			  });
	
	return popupCustomerInvoiceStatusPrintWinObj;
	   
};