/**
 * 
 */

Ext.ns('Modules.common.nonOcean');

Modules.common.nonOcean.InvoiceEmailHelper= function(config){
	if(Ext.isEmpty(config)){
		return;
	}
		  var param = {
				  	 companyCd : Modules.GlobalVars.selectedCompanyCode,
					 cstmrCd   : config.cstmrCd,
					 dbtrPartyCd : config.dbtrPtyCd,
					 prfInvoices: Ext.JSON.encode(config.prfInvoices)
			 };
		  Ext.Ajax.request({
				url : 'nonOceanPrintEmailController/getPrintDetails',
				params :param,
				timeout : 120000,
				success : function(response) {
					 var temp= Ext.decode(response.responseText);
					 var emaildtls=temp.value;		
					 var params = {
							 prfInvoices : config.prfInvoices,
							 cstmrCd 	 : config.cstmrCd,							
							 emaildtls   : emaildtls
					 };
					 
					 Modules.common.nonOcean.EmailWindow(params).show(); 									 
				},
				failure : function(){
				var params = {
							 prfInvoices : config.prfInvoices,
							 cstmrCd 	 : config.cstmrCd
					 };					 
					 Modules.common.nonOcean.EmailWindow(params).show();				 
				}
				});	
};





Modules.common.nonOcean.EmailWindow= function(config)
{	
	var prfInvoices='',cstmrCd='';	
	var templateCd='';
	var emaildtls='';
	var mailId='';
	var ccmailId='';
	var grid=Ext.getCmp(Modules.CompIds.customerInvoiceStatusGridId);
	if(grid){
		ccmailId=grid.ccmailId;
	}	
	if(config){
	prfInvoices = config.prfInvoices;
	cstmrCd     = config.cstmrCd;
	emaildtls   = config.emaildtls;
	}
	if(emaildtls){		
		if(emaildtls.invcTemplate !=null){
			templateCd=emaildtls.invcTemplate;
		}			
		if(emaildtls.emailAddr !=null){
			mailId=emaildtls.emailAddr;
		}			
	}	
	var FormObj =function(){
	var emailForm = {
			   xtype:'cmcform',
			   showFieldsetCmc:false,
			   height : 145,
			   width: 430,
			   bbar:['->',{
					   xtype : 'button',
				       text : 'Send Mail',
				       iconCls : "resend",
				       handler : function(){	
				    	   var form = this.up('cmcform').getForm();
				    	   var parenWindow = this.up('cmcwindow');
	 		            	if(!form.isValid()){
	 		            		Ext.MessageBox.show({ title : '',
	 		        				msg : 'Invalid Form Data',
	 		        				buttons:Ext.MessageBox.OK,
	 		        				icon : Ext.MessageBox.ERROR
	 							 });
	 		        		return;
	 		            	}
				    	   var errFlg=false;
				    	  
				    	   if(Ext.getCmp('nonOcnToEmailId').getValue() == '' || Ext.getCmp('nonOcnToEmailId').getValue()== null){
				    		   Ext.MessageBox.show({
			                        title: '',
			                        msg: Modules.Msgs.toMailIdMandatoryMsg,
			                        buttons: Ext.MessageBox.OK,
			                        icon: Ext.MessageBox.INFO
			                    });
				    		   errFlg=true;
							 return false;	
				    	   }				    	  			    	   
				    	 if(!errFlg)  {	
							 var param = {
									 companyCd : Modules.GlobalVars.selectedCompanyCode,
									 cstmrCd  : cstmrCd,	
									 invcPrintFlg:'Y',
									 orginalFlg:'N',
									 printMode : 'E',
									 printType:'INVOICE',
									 emailAddr:Ext.getCmp('nonOcnToEmailId').getValue(),
									 ccMailId:Ext.getCmp('nonOcnCCEmailId').getValue(),
									 prfInvoices: Ext.JSON.encode(prfInvoices)
						 };									   
						
						 Ext.Ajax.request({
								url : 'nonOceanPrintEmailController/SendEmailPrint',
								params :param,
								timeout : 120000,
								success : function(response) {							
									var msg = Ext.decode(response.responseText);
									if (msg.success == true) {
										 Ext.MessageBox.show({
						                        title: '',
							                        msg: 'Email Sent Successfully',
							                        buttons: Ext.MessageBox.OK,
							                        icon: Ext.MessageBox.INFO
							                    });
										 var grid= Ext.getCmp(Modules.CompIds.customerInvoiceStatusGridId);
										 grid.ccmailId=Ext.getCmp('nonOcnCCEmailId').getValue();
										 parenWindow.close();
										
									
								}else{
									 Ext.MessageBox.show({
					                        title: '',
						                        msg: msg.message,
						                        buttons: Ext.MessageBox.OK,
						                        icon: Ext.MessageBox.INFO
						                    });
										
									}
								 
							}
							});
				    		 
				    	 }
				    
					}
			   }
			],
				
			   setFormItemsFuncCmc : function() {
				   var itemsArr = [];
					
			 var toMailTextField = {
					xtype : 'cmctextfield',
					name : 'toEmailAddress',
					id:'nonOcnToEmailId',
					fieldLabel : 'To' + "<span style='color: red'>*</span>",
//					margin : '5px 10px 10px 5px',
					width : 350,
					value:mailId,
					labelWidth : 60,
					labelAlign : "left",
//					margin : '0px 9px 0px 20px',
					regex: /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;,.](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/,
					labelSeparator : ''

				};	   
				 var ccMailTextField ={
								xtype: 'cmctextfield',
								id: 'ccMailId',
								name: 'ccEmailAddress',
								id:'nonOcnCCEmailId',								
								fieldLabel: 'CC',//Modules.LblsAndTtls.customerCCMailTtl,
//								margin : '5px 10px 10px 5px',
								width:350,
								labelWidth:60,
								regex: /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;,.](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/,
								labelAlign:"left",
								value:ccmailId,
								labelSeparator:''
								
						};
													
				var templateCode= {
									xtype: 'cmctextfield',
			                         fieldLabel: 'Template',
			                         id:'nonOcnEmailTemplateId',
			                         width:200,
//			                         margin : '5px 10px 10px 5px',
			                         value:templateCd,
			                         labelWidth:60,
									 readOnly: true
									 };
				
				var container = {
						xtype : 'container',
						layout : 'vbox',
						margin : '0px 9px 0px 20px',
						/*defaults : {
							margin : '0px 10px 0px 50px'
						},*/
						items : [templateCode,toMailTextField,ccMailTextField]
				};
					itemsArr = [container];
					return itemsArr;
			 
			   }
	   };
	   return emailForm;
	   };
	
	   var emailWinObj = Ext.create('Ext.cmc.Window', {
			 
			   	title:'Email Invoice'	,
			   	height : 150,
				width: 450,
				modal:true,
				setCenterItemFuncCmc :FormObj			 
			  });
	
	return emailWinObj;
	   
};