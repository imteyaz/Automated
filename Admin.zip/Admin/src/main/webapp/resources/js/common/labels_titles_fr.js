
/************************************* Window title *************************************/

Modules.LblsAndTtls.myWindowName = 'My window1';

Modules.LblsAndTtls.accRecWinTitle='Account Recievable1';

Modules.LblsAndTtls.accPayWinTitle='Account Payable1'; 
Modules.LblsAndTtls.winInSupplierRemitAdvcTlt='Supplier Remittance Advice Message1';
Modules.LblsAndTtls.srvcChrgeInvcWinTitle='Service Charge Invoice1';
Modules.LblsAndTtls.truckInvcWinTitle='Truck Invoice1';
Modules.LblsAndTtls.railInvcWinTitle='Rail Invoice1';
Modules.LblsAndTtls.custrmInvcWinTitle='Customer Invoice1';
Modules.LblsAndTtls.covusXmlWinTitle='Covus Xml Interface1';
Modules.LblsAndTtls.CovusInvoiceDetailsTlt='Covus Invoice details1';
Modules.LblsAndTtls.CovusInvoiceSubDetailsTlt='Covus Invoice SubDetails1';
Modules.LblsAndTtls.CovusTaxDetailsTlt='Covus Tax Details1';
Modules.LblsAndTtls.RailInvcRoutingDetailsTlt='Rail Invoice Routing Details1';
Modules.LblsAndTtls.RailInvcEvntDtlsTlt='Rail Invoice Event details1';
Modules.LblsAndTtls.RailInvcDetailsTlt='Rail Invoice Details1';

Modules.LblsAndTtls.customerRatesTtl='Customer Rates1';

Modules.LblsAndTtls.saveSearchCriteriaWindowTlt='Save Search Criteria1';
Modules.LblsAndTtls.retrieveSearchCriteriaWindowTlt='Retrieve Search Criteria1';
Modules.LblsAndTtls.specialMoveEntryDestinationStateProvinceId='Destination S/P1';

Modules.LblsAndTtls.cstrRemitAdvcWinTitle = 'Customer Remittance Advice Message1';
Modules.LblsAndTtls.outCstmrRemitAdvcwinTitle = 'Out Customer Remittance Advice Message1';

Modules.LblsAndTtls.popupCstmrEvntStsSummGridTlt = 'Customer Event Status Summary Details1';
Modules.LblsAndTtls.cstmrRatesCompositeWinTlt    = 'Composite Service Details1';
Modules.LblsAndTtls.cstmrRatesMinLoadWinTlt=     'Minimum Load Details1';
Modules.LblsAndTtls.cstmrRatesAgreedMileageWinTlt  = 'Agreed Mileage Details1';
Modules.LblsAndTtls.customerDebtorPartyTlt = 'Customer Debtor Party Details1';
Modules.LblsAndTtls.customerMasterTlt     =  'Customer Master1';
Modules.LblsAndTtls.customerInvoiceStatusLabelTlt = 'Customer Invoice Status1';
Modules.LblsAndTtls.customerInvoiceStatusOceanLabelTlt = 'Customer Invoice Status For Ocean1';
Modules.LblsAndTtls.OcnSupplrMasterDtlsGridPopup = 'Supplier Master Details1';

Modules.LblsAndTtls.ocnSupplrMasterStsDtForContractId = 'Status Date for Contract Identification1';

Modules.LblsAndTtls.ocnSupplrMasterAutomaticInvcSetup = 'Automatic Invoice Setup1';
Modules.LblsAndTtls.ocnSupplrMasterRoundingCriteriaforRatePop  =  'Rounding Criteria For Rate1';

Modules.LblsAndTtls.spplrEventStatusSummaryParentTabpanelTtl = 'Ocean Supplier Event Status Summary';

Modules.LblsAndTtls.ocnCustomerRatesTtl   =  'Ocean Customer Rates';

/************************************* End Window title ***********************************/





/************************************* Panel title ****************************************/
Modules.LblsAndTtls.myPanelName = 'My panel1';
Modules.LblsAndTtls.cstmrRateFuelSurchrg='Fuel Surcharge Details1';
Modules.LblsAndTtls.cstmrRateContractDtls='Contract Details1';
/************************************** End Panel title ***********************************/




/************************************* Other  and Grid Title ****************************************/

Modules.LblsAndTtls.InvoiceNumberTtl					=	'Invoice Number1';
Modules.LblsAndTtls.DocumentReferenceTtl				=	'Document Reference1';
Modules.LblsAndTtls.InvoiceAmountTtl					=	'Invoice Amount1';

Modules.LblsAndTtls.PartNumberTtl						=	'Part Number1';

/*************************************Date Time Field labels ****************************************/



/*************************************Start Field labels ****************************************/

Modules.LblsAndTtls.testComboFieldLabel 				=	'Skills1';

Modules.LblsAndTtls.companyCodeTtl						=	'Company1';
Modules.LblsAndTtls.purgeFrequencyTtl					=	'Purge Frequency1';
Modules.LblsAndTtls.timeTtl								=	'Time1';

Modules.LblsAndTtls.MessageTypeTlt=     'Msg Type1';
Modules.LblsAndTtls.MessageTypeFullTlt=     'Message Type1';
Modules.LblsAndTtls.SupplierCodeTlt=    'Supplier Code1';
Modules.LblsAndTtls.ExtSupplierCodeTlt=    'Ext Supplier Code1';
Modules.LblsAndTtls.CustomerCodeTlt=    'Customer Code1';
Modules.LblsAndTtls.CustomerTlt     =    'Customer Code1';
Modules.LblsAndTtls.MsgProcStatusTlt=   'Msg Proc Status1';
Modules.LblsAndTtls.MsgProcStatusFullTlt=   'Message Processing Status1';
Modules.LblsAndTtls.statusMonitorTlt=  'Status Monitor1';
Modules.LblsAndTtls.DebtorSubLedgerCdFullTlt='Debtor Sub Ledger Code1';
Modules.LblsAndTtls.srvCdTaxTypeFullTlt='Service Code tax Type Indicator1';

Modules.LblsAndTtls.uploadDownloadIndicatorTtl   =     'U/D Indicator1';
Modules.LblsAndTtls.uploadDownloadIndicatorFullTtl   =     'Upload Download Indicator1';
Modules.LblsAndTtls.messageTransmissionStatusTtl =     'Msg Trns Status1';
Modules.LblsAndTtls.messageTransmissionStatusFullTtl = 'Message Transmission Status1';
Modules.LblsAndTtls.remittanceTypeTtl            =     'Remit Type1';
Modules.LblsAndTtls.remittanceTypeFullTtl         =    'Remittance Type1';
Modules.LblsAndTtls.partnerCodeTtl               =     'Partner Code1';
Modules.LblsAndTtls.partnerTtl               =     'Partner1';
Modules.LblsAndTtls.partnerNameTtl               =     'Partner Name1';
Modules.LblsAndTtls.address1Ttl               =   'Address11';
Modules.LblsAndTtls.address2Ttl               =   'Address21';
Modules.LblsAndTtls.cityTtl               =   'City1';
Modules.LblsAndTtls.zipTtl               =   'Zip1';
Modules.LblsAndTtls.telephoneTtl               =   'Telephone1';
Modules.LblsAndTtls.alertEmailIdTtl               =   'Alert Email ID1';
Modules.LblsAndTtls.emailAlertTtl               =   'Email Alert1';
Modules.LblsAndTtls.singleRadiotTtl               =   'Single1';
Modules.LblsAndTtls.onDatetTtl               =   'On Date1';
Modules.LblsAndTtls.atTimetTtl               =   'At Time1';
Modules.LblsAndTtls.timeFormattTtl               =   '24hh:mm:ss1';
Modules.LblsAndTtls.multipleRadiotTtl               =   'Multiple1';
Modules.LblsAndTtls.everyCombotTtl               =  'Every1';
Modules.LblsAndTtls.onCombotTtl               =  'On1';
Modules.LblsAndTtls.atTtl               =   'At1';
Modules.LblsAndTtls.msgNameTtl               =   'Message Name1';
Modules.LblsAndTtls.msgPerFileTtl               =   'Messages Per File1';
Modules.LblsAndTtls.groupCodeTtl               =   'Group Code1';
Modules.LblsAndTtls.groupNameTtl               =   'Group Name1';
Modules.LblsAndTtls.companyCdTtl               =   'Company Code1';
Modules.LblsAndTtls.rateTierCdTtl               =   'Rate Tier Code1';
Modules.LblsAndTtls.plantNumTtl               =  'Plant Number1';
Modules.LblsAndTtls.abnormalMvTypeTtl               =   'Abnormal Move Type1';
Modules.LblsAndTtls.stateCntryCodeTtl               =   'State Country Code1';
Modules.LblsAndTtls.orderTypeCodeTtl               =   'Order Type Code1';
Modules.LblsAndTtls.shipmentTypeTtl               =   'Shipment Type1';
Modules.LblsAndTtls.uomCodeTtl               =   'UOM Code1';
Modules.LblsAndTtls.marketAreaTtl               =   'Market Area1';
Modules.LblsAndTtls.locCodeTtl               =   'Location Code1';
Modules.LblsAndTtls.serviceTaxTypeTtl               = 'Service Tax Type1';
Modules.LblsAndTtls.makeModelCdTtl               = 'Make Model Code1';
Modules.LblsAndTtls.ModelCdTtl               = 'Model Code1';
Modules.LblsAndTtls.consolidationTypeTtl               ='Consolidation Type1';
Modules.LblsAndTtls.currencyCodeTtl               ='Currency Code1';
Modules.LblsAndTtls.rateBasisCdTtl               =   'Rate Basis Code1';
Modules.LblsAndTtls.modelGroupTtl               = 'Model Group1';

Modules.LblsAndTtls.factorVal                    =         'Factor Value1';
Modules.LblsAndTtls.factorType                   =         'Factor Type1';
Modules.LblsAndTtls.factorRate                   =          'Factor Rate1';

Modules.LblsAndTtls.SupplierTtl=    'Supplier1';
Modules.LblsAndTtls.SupplierNameTtl=    'Supplier Name1';
Modules.LblsAndTtls.SupplierAddr1Ttl=    'Supplier Addr Line11';
Modules.LblsAndTtls.SupplierAddr2Ttl=    'Supplier Addr Line21';
Modules.LblsAndTtls.SupplierCityTtl=    'Supplier City1';
Modules.LblsAndTtls.SupplierCountryTtl=    'Supplier Country1';
Modules.LblsAndTtls.SupplierStateTtl=    'Supplier Stat/Prov1';
Modules.LblsAndTtls.SupplierZipCodeTtl=    'Supplier Zip Cd1';
Modules.LblsAndTtls.ExtSupplierCountryTtl=    'Ext Supplier Country1';
Modules.LblsAndTtls.ExtSupplierStateTtl=    'Ext Supp Stat/Prov1';

Modules.LblsAndTtls.apContactPersonNameTtl=    'Ap Contact Prsn Nm1';
Modules.LblsAndTtls.apPhoneTtl=    'Ap Phone1';
Modules.LblsAndTtls.SupplContactPersonNameTtl=    'Supp Contact Prsn Nm1';
Modules.LblsAndTtls.SupplierPhoneTtl=    'Supplier Phone1';

Modules.LblsAndTtls.customerTtl='Customer1';

Modules.LblsAndTtls.msgHdrIdTlt  =   'Msg Hdr ID1';
Modules.LblsAndTtls.extCompanyTlt =   'Ext Company1';
Modules.LblsAndTtls.msgControlRefTlt='Msg Ctrl Ref Nbr1';
Modules.LblsAndTtls.extCustomerCodeTlt='Ext Customer Code1';
Modules.LblsAndTtls.invoiceNumberTlt='Invoice Nbr1';
Modules.LblsAndTtls.invoiceNumberFullTlt='Invoice Number1';
Modules.LblsAndTtls.msgConfirmedFlgTlt='Msg Confirmed Flg1';
Modules.LblsAndTtls.invoiceAcceptFlgTlt='Invoice Accept Flg1';
Modules.LblsAndTtls.msgTransDateTlt='Msg Trans Date1';
Modules.LblsAndTtls.companyNameTlt='Company Name1';
Modules.LblsAndTtls.paymentDocTlt='Payment Doc1';
Modules.LblsAndTtls.paymentDocFullTlt='Payment Document1';
Modules.LblsAndTtls.msgcontrolNoFromTlt='Msg Ctrl Nbr From1';
Modules.LblsAndTtls.msgcontrolNoFromFullTlt='Message Control Number from1';
Modules.LblsAndTtls.msgcontrolNoToTlt='Msg Ctrl Nbr To1';
Modules.LblsAndTtls.msgcontrolNoToFullTlt='Message Control Number to1';
Modules.LblsAndTtls.serviceCodeTlt='Service Code1';
Modules.LblsAndTtls.serviceCodeTltMandatory='Service Code<span style="color: red">*</span>1';
Modules.LblsAndTtls.customerCodeTlt='Customer Code1';
Modules.LblsAndTtls.supplierCodeTlt='Supplier Code1';
Modules.LblsAndTtls.originTlt='Origin1';
Modules.LblsAndTtls.destinationTlt='Destination1';
Modules.LblsAndTtls.shipRefNoTlt='Shipping Ref1';
Modules.LblsAndTtls.shipRefNoFullTlt='Shipping Reference1';
Modules.LblsAndTtls.shipRefFullTlt='Shipping Ref1';
Modules.LblsAndTtls.transportModeTlt='Transport Mode1';
Modules.LblsAndTtls.errorDescriptionTlt='Error Description1';
Modules.LblsAndTtls.eventLoadRefTlt='Load Ref1';
Modules.LblsAndTtls.eventLoadRefFullTlt='Load Reference1';
Modules.LblsAndTtls.workOrderTlt='Work Order1';
Modules.LblsAndTtls.unitIdTlt='Unit ID1';
Modules.LblsAndTtls.unitIdTltMandatory='Unit ID<span style="color: red">*</span>1';
Modules.LblsAndTtls.notUploadedTlt='Not Uploaded1';
Modules.LblsAndTtls.upDownLoadDateTimeFromTlt='U/D D&T From1';
Modules.LblsAndTtls.upDownLoadDateTimeFromFullTlt='Up/Down Loading Date & Time from 1';
Modules.LblsAndTtls.upDownLoadDateTimeToTlt='U/D D&T To1';
Modules.LblsAndTtls.upDownLoadDateTimeToFullTlt='Up/Down Loading Date & Time To1';
Modules.LblsAndTtls.customerNameTlt='Customer Name1';
Modules.LblsAndTtls.customerAddressTlt='Customer Address1';
Modules.LblsAndTtls.customerCityTlt='Customer City1';
Modules.LblsAndTtls.customerStateProvinceTlt='Customer State/Prov1';
Modules.LblsAndTtls.customerStateProvinceFull='Customer State/Province1';
Modules.LblsAndTtls.extCustomerCountryTlt='Ext Customer Country1';
Modules.LblsAndTtls.paymentDocumentNoTlt='Payment Doc Nbr1';
Modules.LblsAndTtls.paymentDocumentNoFull='Payment Document Number1';
Modules.LblsAndTtls.paymentDocTypeTlt='Payment Doc Type1';
Modules.LblsAndTtls.paymentDocTypeFull='Payment Document Type1';
Modules.LblsAndTtls.paymentDateTlt='Payment Date1';
Modules.LblsAndTtls.currencyTlt='Currency1';
Modules.LblsAndTtls.extCurrencyTlt='Ext Currency1';
Modules.LblsAndTtls.extInvcCurrencyTlt='Ext Invc Currency1';
Modules.LblsAndTtls.extInvcCurrencyFull='External Invoice Currency1';
Modules.LblsAndTtls.invoiceAmountTlt='Invoice Amount ($)1';
Modules.LblsAndTtls.totalAmountTlt='Total Amount($)1';
Modules.LblsAndTtls.remittanceTypeTlt='Remittance Type1';
Modules.LblsAndTtls.itemNbrTlt='Item Nbr1';
Modules.LblsAndTtls.itemNbrFullTlt='Item Number1';
Modules.LblsAndTtls.techErrorCodeFullTlt='Technical Error Code1';
Modules.LblsAndTtls.techErrorDescFullTlt='Technical Error Description1';
Modules.LblsAndTtls.serviceGroupTlt='Service Group1';

Modules.LblsAndTtls.pinvcTlt='PINVC1';
Modules.LblsAndTtls.zerortTlt='ZERORT1';
Modules.LblsAndTtls.recnclTlt='RECNCL1';
Modules.LblsAndTtls.apprvTlt='APPRV1';
Modules.LblsAndTtls.nochrgTlt='NOCHRG1';

Modules.LblsAndTtls.msgHeaderIdTlt= 'Msg Hdr ID1';
Modules.LblsAndTtls.fileControlNoTlt= 'File Ctrl Nbr1';
Modules.LblsAndTtls.msgCreationDateTlt='Msg Creation Date & Time1';
Modules.LblsAndTtls.transferSequenceNoTlt='Transfer Seq Nbr1';
Modules.LblsAndTtls.noOfRecsTlt='Nbr Of Recs1';
Modules.LblsAndTtls.noOfErrRecsTlt='Nbr Of Err Recs1';
Modules.LblsAndTtls.noOfRecsUDTlt='Nbr Of Recs U/D1';
Modules.LblsAndTtls.typeTlt = 'Type';

Modules.LblsAndTtls.accPayMsgHdrId='Msg Hdr ID1';
Modules.LblsAndTtls.accPayMsgType= 'Msg Type1';
Modules.LblsAndTtls.accPayPartnerCode= 'Partner Code1';
Modules.LblsAndTtls.accPayCompany =  'Company1';
Modules.LblsAndTtls.accPayExtCompany= 'Ext company1';
Modules.LblsAndTtls.accPayInvoiceNumber= 'Invoice Number1';
Modules.LblsAndTtls.accPaySupplierCode= 'Supplier Code1';
Modules.LblsAndTtls.accPayExtSupplierCode= 'Ext Supplier Code1';
Modules.LblsAndTtls.accPaySpplrPymntInvcNo = 'Spplr Pymnt Invc Nbr1';
Modules.LblsAndTtls.accPayDebtorPartyCode = 'Debtor Party Code1';
Modules.LblsAndTtls.accPayDebtorPartyName = 'Debtor Party Name1';
Modules.LblsAndTtls.accPayContactPersonName ='Contact Person Name' ;
Modules.LblsAndTtls.accPayInvoiceDate= 'Invoice Date1';
Modules.LblsAndTtls.accPayInvoiceDuedate = 'Invoice Due Date1';
Modules.LblsAndTtls.accPayCurrency = 'Currency1';
Modules.LblsAndTtls.accPayExtCurrency = ' Ext Currency1';
Modules.LblsAndTtls.accPayTotalAmount = 'Total Amount ($)1';
Modules.LblsAndTtls.accPayDocumentType= 'Document Type1';
Modules.LblsAndTtls.accPayActualAccural=  'Actual/Accural1';

Modules.LblsAndTtls.contractIdTtl='Contract ID1';
Modules.LblsAndTtls.validFromDateTlt='Valid From Date1';
Modules.LblsAndTtls.validToDateTlt = 'Valid To Date1';


Modules.LblsAndTtls.accRecCustomerCd='Customer Code1';
Modules.LblsAndTtls.accRecExtCustomerCd ='Ext Customer Code1';
Modules.LblsAndTtls.accRecReferInvcNo='Reference Invoice Nbr1';
Modules.LblsAndTtls.accRecCreditDebit='Credit/Debit1';
Modules.LblsAndTtls.accRecDebtorSubLedgerCd='Debtor SubLedger Cd1';


Modules.LblsAndTtls.truckInvoiceExtSupplrLb='Ext Supplier Code1';
Modules.LblsAndTtls.truckInvoiceProductLb = 'Product ID1';
Modules.LblsAndTtls.truckInvoiceProductDateLb='Product date1';
Modules.LblsAndTtls.truckInvoiceCreditNoteIndLb='Invc Credit Note Ind1';

Modules.LblsAndTtls.railInvcEventLoadRef='Event/Load Ref#1';
Modules.LblsAndTtls.railInvoiceExtConveyanceType='Ext Conveyance Type1';
Modules.LblsAndTtls.railInvoiceTaxRegNo='Tax Reg Nbr1';
Modules.LblsAndTtls.railInvoiceRefContractNo='Ref Contract Nbr1';
Modules.LblsAndTtls.railInvoiceWayBillNo='Way Bill Nbr1';
Modules.LblsAndTtls.railInvoiceExtCurrency='Ext Currency1';
Modules.LblsAndTtls.railInvcExtOrigin='Ext Origin1';
Modules.LblsAndTtls.railInvcOriginCity='Origin City1';
Modules.LblsAndTtls.railInvcConveyanceId='Conveyance ID1';
Modules.LblsAndTtls.railInvcExtOriginStateProvince='ExtOrigin State/Prov1';
Modules.LblsAndTtls.railInvcExtOriginCountry='ExtOrigin Country1';
Modules.LblsAndTtls.railInvcExtCompany='Ext Company1';
Modules.LblsAndTtls.railInvcDestinationCity='Destination City1';
Modules.LblsAndTtls.railInvcExtDestination='ExtDest City1';
Modules.LblsAndTtls.railInvcExtDestinationStateProvince = 'ExtDest State/Prov1';
Modules.LblsAndTtls.railInvcConsignee='Consignee1';
Modules.LblsAndTtls.railInvcConsigner='Consigner1';
Modules.LblsAndTtls.railInvcCompanyNm='Company Name1';
Modules.LblsAndTtls.railInvcConsigneeNm='Consignee Name1';
Modules.LblsAndTtls.railInvcConsignerNm='Consigner Name1';
Modules.LblsAndTtls.railInvcCompanyAddress='Company Address1';
Modules.LblsAndTtls.railInvcCompanyAddress2='Company Address21';
Modules.LblsAndTtls.railInvcConsignerAddress='Consigner Address1';
Modules.LblsAndTtls.railInvcConsignerAddress2='Consigner Address21';
Modules.LblsAndTtls.railInvcConsigneeAddress='Consignee Address1';
Modules.LblsAndTtls.railInvcConsigneeAddress2='Consignee Address21';
Modules.LblsAndTtls.railInvcCompanyCity='Company City1';
Modules.LblsAndTtls.railInvcConsignerCity='Consigner City1';
Modules.LblsAndTtls.railInvcConsigneeCity='Consignee City1';
Modules.LblsAndTtls.railInvcExtCompanyStateProvince='ExtCmpny State/Prov1';
Modules.LblsAndTtls.railInvcConsignerStateProvince='Consigner State/Prov1';
Modules.LblsAndTtls.railInvcConsigneeStateProvinceId='Consignee State/Prov1';
Modules.LblsAndTtls.railInvcConsignerCountry='Consigner Country1';
Modules.LblsAndTtls.railInvcConsigneeCountry='Consignee Country1';
Modules.LblsAndTtls.railInvcExtCompanyCountry='ExtCmpny Country1';
Modules.LblsAndTtls.railInvcExtDestinationCountry='ExtDest Country1';

Modules.LblsAndTtls.srvcChrgInvoiceExtCmpny='Ext Company Cd1';

Modules.LblsAndTtls.inSupplierRemitAdvcExtCmpny='Ext Company1';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrNmLb='Supplier Name1';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrAddLb='Supplier Address1';
Modules.LblsAndTtls.inSupplierRemitAdvcSupplrCityLb='Supplier City1';
Modules.LblsAndTtls.inSupplierRemitAdvcExtSupplrStateProvLb='Ext Supplr State/Prov1';
Modules.LblsAndTtls.inSupplierRemitAdvcExtSupplrCountry='Ext Supplier Country1';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDocNo='Payment Doc Nbr1';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDocType='Payment Doc Type1';
Modules.LblsAndTtls.inSupplierRemitAdvcPaymntDate='Payment Date1';
Modules.LblsAndTtls.inSupplierRemitAdvcExtCurr='Ext Currency1';
Modules.LblsAndTtls.inSupplierRemitAdvcTotalAmt='Total Amount($)1';

Modules.LblsAndTtls.custmrInvcAddrLine1='Address Line11';
Modules.LblsAndTtls.custmrInvcAddrLine2='Address Line21';
Modules.LblsAndTtls.custmrInvcCity='City1';
Modules.LblsAndTtls.custmrInvcZipPostalCd='Zip/Postal Code1';
Modules.LblsAndTtls.custmrInvcStateProv='State/Province1';
Modules.LblsAndTtls.custmrInvcExtStateProv='Ext State/Province1';
Modules.LblsAndTtls.custmrInvcCountry='Country',
Modules.LblsAndTtls.custmrInvcExtCountry='External Country',
Modules.LblsAndTtls.custmrInvcExtCustmrCd='Ext Customer Code1';
Modules.LblsAndTtls.custmrInvcExtCustmrCdFull='External Customer Code1';
Modules.LblsAndTtls.refInvoiceNumberTlt='Ref Invoice Number1';
Modules.LblsAndTtls.custmrInvcExtDocType='Ext Document Type1';
Modules.LblsAndTtls.custmrInvcAmt='Invoice Amount($)1';
Modules.LblsAndTtls.custmrInvcContactPerson='Contact Person1';
Modules.LblsAndTtls.custmrPhone='Phone1';
Modules.LblsAndTtls.custmrInvcProformalInd='Proforma/Estimate Ind1';

Modules.LblsAndTtls.covusXmlInterfaceMsgHdrIdTool='Message Header ID1';
Modules.LblsAndTtls.covusXmlInterfaceMsgTypeTool='Message Type1';
Modules.LblsAndTtls.covusXmlInterfaceExtCmpnyTool='External Company1';
Modules.LblsAndTtls.covusXmlInterfaceCreditNoteIndTool='Invoice Credit Note Indicator1';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrTool='External Customer1';
Modules.LblsAndTtls.covusXmlInterfaceRefInvoiceNumberTool='Reference Invoice Number1';
Modules.LblsAndTtls.covusXmlInterfaceTotalInvcAmtTool='Total Invoice Amount($)1';
Modules.LblsAndTtls.covusXmlInterfaceTotalSrvcAmtTool='Total Service Amount($)1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddTool='Debtor Party Address11';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr2Tool='Debtor Party Address21';
Modules.LblsAndTtls.covusXmlInterfaceTaxRefNoTool='Tax Reference Number1';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorStateCdTool='External Debtor State Code1';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs1Tool='AR Address11';
Modules.LblsAndTtls.covusXmlInterfacePrfEstmTool='Proforma/estimation Indicator1';
Modules.LblsAndTtls.covusXmlInterfacePrfStsTool='Proforma Status1';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs2Tool='AR Address21';
Modules.LblsAndTtls.covusXmlInterfaceExtARStateTool='External AR State1';
Modules.LblsAndTtls.covusXmlInterfaceExtARCountryTool='External AR Country1';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorCountryTool='External Debtor Country1';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrStateTool='External Customer State1';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrCountryTool='External Customer Country1';
Modules.LblsAndTtls.covusXmlInterfaceCustmrAddr1Tool='Customer Address11';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr2Tool='Customer Address21';
Modules.LblsAndTtls.covusXmlInterfaceDebtorContactPrsnNmTool='Debtor Contact Person Name1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorTaxRefNoTool='Debtor Tax Reference Number1';
Modules.LblsAndTtls.covusXmlInterfaceArContactPrsnNMCdTool='AR Contact Person Name1';
Modules.LblsAndTtls.covusXmlInterfaceExtInvcCurrTool='External Invoice Currency1';


Modules.LblsAndTtls.covusXmlInterfaceExtSupplrTool='External Supplier Code1';
Modules.LblsAndTtls.ExtCurrToolTip='External Currency1';
Modules.LblsAndTtls.apCmpAddrLine1ToolTip='Ap Company Address Line11';
Modules.LblsAndTtls.apCmpAddrLine2ToolTip='Ap Company Address Line21';
Modules.LblsAndTtls.apCmpCityNmToolTip='Ap Company City Name1';
Modules.LblsAndTtls.apCmpStProvToolTip='Ap Company State/Province1';
Modules.LblsAndTtls.apCmpCountryToolTip='Ap Company Country1';
Modules.LblsAndTtls.apCmpZipPostalToolTip='Ap Company Zip Postal Code1';
Modules.LblsAndTtls.apCmpStProvToolTip='External Ap Company State/Province1';
Modules.LblsAndTtls.apCmpCountryProvToolTip='External Ap Company Country1';
Modules.LblsAndTtls.ExtSupplrTool='External Supplier Code1';
Modules.LblsAndTtls.SupplrAddrLine1Tool='Supplier Address Line11';
Modules.LblsAndTtls.SupplrAddrLine2Tool='Supplier Address Line21';
Modules.LblsAndTtls.SupplrStateTool='Supplier State/Province1';
Modules.LblsAndTtls.SupplrZipCd='Supplier Zip/Postal Code1';
Modules.LblsAndTtls.ExtSupplrCountryToolTip='External Supplier Country 1';
Modules.LblsAndTtls.ExtSupplrStateToolTip='External Supplier State/Province1';
Modules.LblsAndTtls.ApContactPrsnNmToolTip='Ap Contact Person Name1';
Modules.LblsAndTtls.SupplrContactPrsnNmToolTip='Supplier Contact Person Name1';
Modules.LblsAndTtls.PaymentDocNoToolTip='Payment Document Number1';
Modules.LblsAndTtls.PaymentDocTypeToolTip='Payment Document Type1';
Modules.LblsAndTtls.ExtInvcCurrTool='External Invoice Currency1';
Modules.LblsAndTtls.ExtCustmrTool='External Customer1';
Modules.LblsAndTtls.SpplrPymntInvTool=' Payment Invoice Number1';
Modules.LblsAndTtls.SrvcCdTaxToolTip='Service Code/Tax Type Indicator1';
	

Modules.LblsAndTtls.CstmrInvcTaxDetailsTlt='Customer Invoice Tax Details1';
Modules.LblsAndTtls.CstmrInvcDetailsTlt='Customer Invoice Details1';

Modules.LblsAndTtls.OutSupplrRemitDetailsTlt='OutSupplier Remittance Advice Details1';
Modules.LblsAndTtls.OutSupplrRemitPayDetailsTlt='OutSupplier Remittance Advice Unit Details1';


Modules.LblsAndTtls.OriginCountryTlt='Origin Country',
Modules.LblsAndTtls.EvntLoadRefTool='Event/Load Reference#1';
Modules.LblsAndTtls.ExtConveyanceTypeTool='External Conveyance Type1';
Modules.LblsAndTtls.TaxRegNoTool='Tax Registration Number1';
Modules.LblsAndTtls.RefContractNoTool='Reference Contract Number1';
Modules.LblsAndTtls.ExtOriginToolTip='External Origin1';
Modules.LblsAndTtls.ExtOriginStateProvToolTip='External Origin State/Province1';
Modules.LblsAndTtls.ExtOriginCountryToolTip='External Origin Country1';
Modules.LblsAndTtls.ConsignerStateProvinceToolTip='Consigner State/Province1';
Modules.LblsAndTtls.ConsigneeStateProvinceToolTip='Consignee State/Province1';
Modules.LblsAndTtls.ExtCmpnyCountryToolTip='External Company Country1';
Modules.LblsAndTtls.ExtDestCountryToolTip='External Destination Country1';
Modules.LblsAndTtls.extDestCityFullTlt='External Destination City1';
Modules.LblsAndTtls.showErrorTlt='Error Correction1';
Modules.LblsAndTtls.attributeTtl='Attribute1';
Modules.LblsAndTtls.valueTlt='Value1';
Modules.LblsAndTtls.refAttributeTlt='Ref Attribute1';
Modules.LblsAndTtls.refAttributeFullTlt='Reference Attribute1';
Modules.LblsAndTtls.refAttributeValueTlt='Ref Attribute Value1';
Modules.LblsAndTtls.refAttributeValueFullTlt='Reference Attribute Value1';
Modules.LblsAndTtls.errorDescTlt='Error Description1';
Modules.LblsAndTtls.destinationCountry='Destination Country1';

Modules.LblsAndTtls.ProformalIndToolTip='Proforma/Estimate Indicator1';
Modules.LblsAndTtls.ExtDocTypeTool='External Document Type1';
Modules.LblsAndTtls.ExtCustmrCdToolTip='External Customer1';
Modules.LblsAndTtls.covusXmlInterfaceExtStateProvTool='External State/Province1';


Modules.LblsAndTtls.covusXmlInterfaceInvcPrntTemp='Invoice Print Template1';
Modules.LblsAndTtls.covusXmlProfitLossLbs = 'Profit/Loss1';
Modules.LblsAndTtls.covusXmlProfitLossFullLbs='Profit/Loss Center1';
Modules.LblsAndTtls.covusXmlInterfacePrfSts='Prf Sts1';
Modules.LblsAndTtls.covusXmlInterfaceTotalInvcAmt='Total Invoice Amt($)1';
Modules.LblsAndTtls.covusXmlInterfaceFinCustmr='Fin Customer1';
Modules.LblsAndTtls.covusXmlInterfaceTotalSrvcAmt='Total Service Amt($)1';
Modules.LblsAndTtls.covusXmlPrfEstm='Prf Estm Ind1';
Modules.LblsAndTtls.covusXmlInterfaceTotalTaxAmt='Total Tax Amount($)1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr='Debtor Party Addr11';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPartyAddr2='Debtor Party Addr21';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCity='Debtor City Name1';
Modules.LblsAndTtls.covusXmlInterfaceTaxRef='Tax Ref Nbr1';
Modules.LblsAndTtls.covusXmlInterfaceRemarks='Remarks1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCd='Debtor Party1';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorStateCdId='Ext Debtor State Cd1';
Modules.LblsAndTtls.debtorState='Debtor State1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorCountry='Debtor Country1';
Modules.LblsAndTtls.ARAddrs1='AR Addrs11';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrCd='Ext Customer1';
Modules.LblsAndTtls.covusXmlInterfaceARAddrs2='AR Addrs21';
Modules.LblsAndTtls.covusXmlInterfaceARCity='AR City1';
Modules.LblsAndTtls.covusXmlInterfaceARState='AR State1';
Modules.LblsAndTtls.covusXmlInterfaceARCountry='AR Country1';
Modules.LblsAndTtls.covusXmlInterfaceARPostal='AR Postal1';
Modules.LblsAndTtls.covusXmlInterfaceARFax='AR Fax1';
Modules.LblsAndTtls.covusXmlInterfaceARTel='AR Tel1';
Modules.LblsAndTtls.covusXmlInterfaceAREmail='AR Email1';
Modules.LblsAndTtls.covusXmlInterfaceInvcCurr='Invoice Currency1';


Modules.LblsAndTtls.covusXmlInterfaceBillType='Bill Type1';
Modules.LblsAndTtls.covusXmlInterfaceInvcCopies='Invoice Copies1';
Modules.LblsAndTtls.covusXmlInterfaceBackUpCopies='Back Up Copies1';
Modules.LblsAndTtls.covusXmlInterfaceInvcPrinter='Invoice Printer1';
Modules.LblsAndTtls.covusXmlInterfaceBackUpPrinter='Back Up Printer1';
Modules.LblsAndTtls.covusXmlInterfaceEmailAddrs='Email Address1';
Modules.LblsAndTtls.covusXmlInterfaceCCEmailAddr='CC Email Address1';
Modules.LblsAndTtls.covusXmlInterfaceInvcReqFlg='Invoice Required Flag1';
Modules.LblsAndTtls.covusXmlInterfaceBackUpReqFlg='BackUp Required Flag1';
Modules.LblsAndTtls.covusXmlInterfaceOrgFlg='Original Flag1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorRemarks1='DebtorRemark11';
Modules.LblsAndTtls.covusXmlInterfaceDebtorRemarks2='DebtorRemark21';
Modules.LblsAndTtls.covusXmlInterfaceDebtorSubLedger='Debtor SubLedger1';
Modules.LblsAndTtls.covusXmlInterfaceCustomerSubLedger='CustomerSubLedger1';
Modules.LblsAndTtls.covusXmlInterfaceExtARState='Ext AR State1';
Modules.LblsAndTtls.covusXmlInterfaceExtARCountry='Ext AR Country1';
Modules.LblsAndTtls.covusXmlInterfaceExtDebtorCountryCd='ExtDebtor Country Cd1';
Modules.LblsAndTtls.covusXmlInterfaceExtCustmrState='Ext Customer State1';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr1='Customer Addr11';
Modules.LblsAndTtls.covusXmlInterfaceCustomerAddr2='Customer Addr21';
Modules.LblsAndTtls.covusXmlInterfaceCustmrCity='Customer City Name1';
Modules.LblsAndTtls.covusXmlInterfaceCustmrState='Customer City State1';
Modules.LblsAndTtls.covusXmlInterfaceCustmrCountry='Customer Country1';
Modules.LblsAndTtls.covusXmlInterfaceCustomerPostalCd='Customer Postal Cd1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorPostalCd='Debtor Postal Code1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorContactPrsnNm='Dbtr Contact Prsn Nm1';
Modules.LblsAndTtls.covusXmlInterfaceDebtorTaxRefNo='Debtor Tax Ref Nbr1';
Modules.LblsAndTtls.covusXmlInterfaceBackUpPrinterPath='BackUp Printer Path1';
Modules.LblsAndTtls.covusXmlInterfaceInvcPrinterPath='Invoice Printer Path1';
Modules.LblsAndTtls.covusXmlInterfaceARContactPrsnNm='AR Contact Prsn Nm1';
Modules.LblsAndTtls.covusXmlInterfaceExtInvcCurr='Ext Invoice Currency1';

Modules.LblsAndTtls.extDestFullTlt='External Destination1';
Modules.LblsAndTtls.extDestStateProvFullTlt='External Destination State/Province1';
Modules.LblsAndTtls.destinationStateProvinceFullTlt='Destination State/Province1';
Modules.LblsAndTtls.destinationStateProvinceTlt='Destination S/P1';
Modules.LblsAndTtls.srvcTypeLbl='Service Type1';
Modules.LblsAndTtls.srvcTypeLblTip='Service Type1';
Modules.LblsAndTtls.srvcCdLbl='Service Code1';
Modules.LblsAndTtls.srvcCdLblTip='Service Code1';
Modules.LblsAndTtls.srvcDescLbl='Service Desc1';
Modules.LblsAndTtls.srvcDescLblTip='Service Description11';
Modules.LblsAndTtls.srvcDesc2Lbl='Service Desc21';
Modules.LblsAndTtls.srvcDesc2LblTip='Service Description21';
Modules.LblsAndTtls.consolidationCatLbl='Consolidation Ctgry1';
Modules.LblsAndTtls.consolidationCatLblTip='Consolidation Category1';

Modules.LblsAndTtls.tariffTabParentPanel='Tariff Master1';
Modules.LblsAndTtls.tariffCdLbl='Tariff Code1';
Modules.LblsAndTtls.tariffDescLbl='Tariff Desc1';
Modules.LblsAndTtls.tariffDescLblTip='Tariff Description1';
Modules.LblsAndTtls.EffectiveDtLbl='Effective Dt1';
Modules.LblsAndTtls.EffectiveDtLblTip='Effective Date1';
Modules.LblsAndTtls.tariffUnitRateLbl='Tariff Unit Rate1';
Modules.LblsAndTtls.currencyLbl='Currency1';
Modules.LblsAndTtls.LUInd     = 'L/U Ind 1';
Modules.LblsAndTtls.tariffCurrCd  =  'Tariff Currency Code1';
Modules.LblsAndTtls.editPurgeDaysTlt='Purging Days1';
Modules.LblsAndTtls.editPurgeConfigurationGridTlt='Purge Configuration Grid Record1';
Modules.LblsAndTtls.popupEventLogGridTlt='Event Log Grid Record1';
Modules.LblsAndTtls.editTransportationEventGridTlt='Transportation Event Entry Grid Record1';
Modules.LblsAndTtls.editTechnicalEventGridTlt='Technical Event Entry Grid Record1';
Modules.LblsAndTtls.srvcMasterFileNmLbl='File Name1';
Modules.LblsAndTtls.srvcMasterTemplateLbl='Template1';
Modules.LblsAndTtls.compositeTlt             = 'Composite1';
Modules.LblsAndTtls.minLoadTlt               =  'Min Load1';
Modules.LblsAndTtls.agreedMileageTlt         =   'Agreed Mileage1';
Modules.LblsAndTtls.auditExceptionTimeIntvlLbl='Time Interval1';

Modules.LblsAndTtls.popupSupplrEvntStsSummGridTlt='Supplier Event Status Summary Details1';


Modules.LblsAndTtls.statusMonitorSaveSearchNameTlt='Search Criteria Keyword<span style="color: red">*</span>' ;
Modules.LblsAndTtls.statusMonitorSaveSearchDescTlt='Search Criteria Description1';
Modules.LblsAndTtls.statusMonitorSaveSearchDefaultFlagTlt='Default Criteria1';
Modules.LblsAndTtls.popupStatusMonitorGridTlt='Status Monitor Grid Record1';

Modules.LblsAndTtls.eventlogSaveSearchScreenTlt='eventlogSaveSearchScreen1';
Modules.LblsAndTtls.DocumentRefTtls='Document Reference1';
Modules.LblsAndTtls.techErrorCodeTlt='Tech Error Code1';
Modules.LblsAndTtls.techErrorDescTlt='Tech Error Description1';
Modules.LblsAndTtls.refErrorCodeTlt='Reference Error Code1';
Modules.LblsAndTtls.refErrorDescTlt='Reference Error Description1';
Modules.LblsAndTtls.msgHderIdTlt='Message Header ID1';
Modules.LblsAndTtls.filectrlNoTlt='File Control Number1';
Modules.LblsAndTtls.msgcontrolNoFullTlt='Message Control Number1';
Modules.LblsAndTtls.msgCreationDTTlt='Message Creation Date & Time1';
Modules.LblsAndTtls.transferSeqNoFullTlt='Transfer Sequence Number1';
Modules.LblsAndTtls.noOfRecsFullTlt='Number Of Records1';
Modules.LblsAndTtls.noOfErrorRecsFullTlt='Number Of Error Records1';
Modules.LblsAndTtls.noOfRecosUDFullTlt='Number Of Records Uploaded & Downloaded1';
Modules.LblsAndTtls.extCompanyFullTlt='External Company1';
Modules.LblsAndTtls.savedOnDateTlt='Saved On Date1';
Modules.LblsAndTtls.criteriaSavedTlt='Criteria Saved1';
Modules.LblsAndTtls.msgControlRefFullTlt='Message Control Reference Number1';
Modules.LblsAndTtls.saveSearchTlt =	'Save Search Criteria1';
Modules.LblsAndTtls.errorCorrectionSearchReplaceTlt='Search & Replace1';
Modules.LblsAndTtls.errorCorrectionAttributeNameTlt='Attribute Name1';
Modules.LblsAndTtls.errorCorrectionFindTlt='Find1';
Modules.LblsAndTtls.errorCorrectionReplaceTlt='Replace1';
Modules.LblsAndTtls.errorCorrectionReplaceWithTlt='Replace With1';
Modules.LblsAndTtls.errorCorrectionReplaceAllTlt='Replace All1';
Modules.LblsAndTtls.errorCorrectionSearchReplaceTlt='Search and Replace1';
Modules.LblsAndTtls.errorCorrectionSaveUpdateTlt='Save and Update Status1';
Modules.LblsAndTtls.seqNo='Sequence Number1';
Modules.LblsAndTtls.destStateProvFullTtl = 'Destination State Province1';
Modules.LblsAndTtls.srvcLvlValidDt= 'Service Level Valid Dates1';

Modules.LblsAndTtls.apCmpAddrLine1Tlt='Ap Cmp Addr Line11';
Modules.LblsAndTtls.apCmpAddrLine2Tlt='Ap Cmp Addr Line21';
Modules.LblsAndTtls.apCmpCityNameTlt='Ap Cmp City Name1';
Modules.LblsAndTtls.apCmpStatProvTlt='Ap Cmp Stat/Prov1';
Modules.LblsAndTtls.apCmpCountryTlt='Ap Cmp Country1';
Modules.LblsAndTtls.apCmpZipPostalCodeTlt='Ap Cmp Zip Cd1';
Modules.LblsAndTtls.extApCmpStatProvTlt='Ext Ap Cmp Stat/Prov1';
Modules.LblsAndTtls.extApCmpCountryTlt='Ext Ap Cmp Country1';

Modules.LblsAndTtls.externalCmpnyStProvFullLbl='External Company State/Province1';

Modules.LblsAndTtls.displayPartner='Partner1';
Modules.LblsAndTtls.displayMessageType='Message Type1';
Modules.LblsAndTtls.displayNumberOfErrors='Number Of Errors1';
Modules.LblsAndTtls.partnerRecordTtl='Partner View1';

Modules.LblsAndTtls.makeCd='Make Code1';
Modules.LblsAndTtls.loadReferenceTlt='Event/Load Ref1';
Modules.LblsAndTtls.ConveyanceIdTlt='Conveyance ID1';
Modules.LblsAndTtls.ConveyanceTypeTlt='Conveyance Type1';
Modules.LblsAndTtls.conveyanceNameTlt='Conveyance Name1';
Modules.LblsAndTtls.tenderDateTlt='Tender Date1';
Modules.LblsAndTtls.shipmntDateTlt='Shipment Date1';
Modules.LblsAndTtls.consolidationIDTlt='Consolidation ID1';
Modules.LblsAndTtls.consolidationTypeTlt='Consolidation Type1';
Modules.LblsAndTtls.transferSeqNbrTlt='Transfer Seq Nbr1';
Modules.LblsAndTtls.requestDateTlt='Request Date1';
Modules.LblsAndTtls.locationTlt='Location1';
Modules.LblsAndTtls.shippingRefTlt='Shipping Ref1';
Modules.LblsAndTtls.shippingRefFullTlt ='Shipping Reference1';
Modules.LblsAndTtls.nbrOfVinTlt = 'Number of VIN1';


Modules.LblsAndTtls.customerDebPrtyCustomer='Customer1';
Modules.LblsAndTtls.customerDebPrtyCustomerName='Customer Name1';
Modules.LblsAndTtls.customerDebPrtyDebtorParty='Debtor Party1';
Modules.LblsAndTtls.customerDebPrtyDebtorPartyName='Debtor Party Name1';
Modules.LblsAndTtls.customerDebPrtyTaxRefNo ='Tax Ref No1';
Modules.LblsAndTtls.customerDebPrtyAddress1 ='Address11';
Modules.LblsAndTtls.customerDebPrtyAddress2 ='Address21';
Modules.LblsAndTtls.customerDebPrtyCity ='City1';
Modules.LblsAndTtls.customerDebPrtyStateProvince ='State/Province1';
Modules.LblsAndTtls.customerDebPrtyCountry ='Country1';
Modules.LblsAndTtls.customerDebPrtyZipPostalCode ='ZIP/Postal Code1';
Modules.LblsAndTtls.customerDebPrtyTelephoneNo = 'Telephone No.1';
Modules.LblsAndTtls.customerDebPrtyFaxNumber ='Fax Number1';
Modules.LblsAndTtls.customerDebPrtyMobileNumber ='Mobile Number1';
Modules.LblsAndTtls.customerDebPrtyEmailAddress ='E-mail Address1';
Modules.LblsAndTtls.customerDebPrtyContactPersonName ='Contact Person Name1';
Modules.LblsAndTtls.customerDebPrtySubLedgerCode ='Sub Ledger Code1';
Modules.LblsAndTtls.customerDebPrtyRemark1 ='Remark11';
Modules.LblsAndTtls.customerDebPrtyRemark2 ='Remark21';

Modules.LblsAndTtls.countTlt               ='Count1';

Modules.LblsAndTtls.customerDebPrtySendCustAccToCodaTtl= "Send Customer Accrual To CODA";
Modules.LblsAndTtls.customerDebPrtyWaitForAPApproveFlgTtl= "Download A/R To A/P";
Modules.LblsAndTtls.customerDebPrtyAutoApproveApplnAdviceFlgTtl= "Auto Approve in Application Advice";
Modules.LblsAndTtls.customerDebPrtySendCstmrInvcMsgFlgTtl= "Send Customer Invoice Message";

/************************************* End Field labels ****************************************/





Modules.LblsAndTtls.viaNoLbl						=		'VIA1';
Modules.LblsAndTtls.oldViaLbl						=		'Old VIA1';
Modules.LblsAndTtls.newViaLbl						=		'New VIA1';
Modules.LblsAndTtls.ldgViaLbl						=		'Load VIA1'; 
Modules.LblsAndTtls.dishViaLbl						=		'Dish Via1';

Modules.LblsAndTtls.voaLbl							=		'VOA1';
Modules.LblsAndTtls.coaLbl							=		'COA1';
Modules.LblsAndTtls.cfsLbl							=		'CFS1';
Modules.LblsAndTtls.chaLbl							=		'CHA1';

Modules.LblsAndTtls.clearActionTtl					=		'Clear1';
Modules.LblsAndTtls.deleteActionTtl					=		'Delete1';
Modules.LblsAndTtls.retrieveActionTtl				=		'Retrieve1';
Modules.LblsAndTtls.addActionTtl					=		'Add1';
Modules.LblsAndTtls.saveActionTtl					=		'Save1';
Modules.LblsAndTtls.exitActionTtl					=		'Exit1'; 
Modules.LblsAndTtls.modifyActionTtl                 =       'Modify1';
Modules.LblsAndTtls.advanceSearchTtl                =       'Advance Search1';
Modules.LblsAndTtls.keySearchTtl                    =       'Key Search1';
Modules.LblsAndTtls.saveSearchCriteriaTtl           =       'Save Search Criteria1';
Modules.LblsAndTtls.retrieveSearchCriteriaTtl       =        'Retrieve Search Criteria1';
Modules.LblsAndTtls.viewTtl                         =         'View1';
Modules.LblsAndTtls.uploadTtl                       =         'Upload1';
Modules.LblsAndTtls.downloadTtl                     =         'Download1';
Modules.LblsAndTtls.resendTtl                     =          'Resend1';
Modules.LblsAndTtls.manualTtl                       =         'Manual1';
Modules.LblsAndTtls.showErrorTtl                    =         'Show Errors1';
Modules.LblsAndTtls.showEdiFileTtl                  =         'Show EDI File1';
Modules.LblsAndTtls.populateSearchCriteriaTtl       =    'Populate Search Criteria1';




Modules.LblsAndTtls.applicationBerthingWinTtl		=		'Application For Berthing Request1';
Modules.LblsAndTtls.transshipmentApprovalWindowTtl	= 		'Transshipment Approval1';
Modules.LblsAndTtls.recordingHoldStatusWinTtl		=		'Recording Of Hold Status1';
Modules.LblsAndTtls.arrNDepRecordingWinTtl     		=   	'Arrival And Departure Recording1';
Modules.LblsAndTtls.containerDmgRecWinTtl 			=   	'Container Damage Recording1';
Modules.LblsAndTtls.cancelContainerEntryWindowTtl	=		'Cancel Container Entry1';
Modules.LblsAndTtls.cancelContainerExitWindowTtl	=		'Cancel Container Exit1';
Modules.LblsAndTtls.changeOfVesselExportCtrWinTtl	=		'Change of Vessel Export Container1';
Modules.LblsAndTtls.batchdDlyRecWinTtl     			= 		'Batch Delay Recording1';
Modules.LblsAndTtls.viaGenerationWinTtl				=		'Via Generation1';
Modules.LblsAndTtls.berthingUnberthingWinTtl		=		'Berthing/Unberthing Recording1';
Modules.LblsAndTtls.cancelContainerEntryWinTtl		=   	'Cancel Container Entry1';
Modules.LblsAndTtls.cancelContainerExitWinTtl		= 		'Cancel Container Exit1';
Modules.LblsAndTtls.chngBaseStsImportCtrWinTtl		=		'Change Base Status For Import Container1';
Modules.LblsAndTtls.chngBseStsInTCtnrsWinTtl 		= 		'Chng Base Status for Import & Transhipment Containers1';
Modules.LblsAndTtls.removalOfHoldStswinTtl			=		'Removal Of Status1';
Modules.LblsAndTtls.chngSealNoWinTtl     			= 		'Change Seal Number1';
Modules.LblsAndTtls.changeContainerNumberWinTtl		=		'Change Container Number1';
Modules.LblsAndTtls.createContainerWindowTtl		=   	'Add/Edit Container1';
Modules.LblsAndTtls.portRotationWinTtl				=		'Ports Rotation1';
Modules.LblsAndTtls.partyMasterWinTtl				=		'Party Master1';

Modules.LblsAndTtls.vinCheckTtl = 'Vin Check1';
Modules.LblsAndTtls.lengthTtl				=		'Length1';
Modules.LblsAndTtls.widthTtl				=		'Width1';
Modules.LblsAndTtls.heightTtl				=		'Height1';
Modules.LblsAndTtls.weightTtl				=		'Weight1';
Modules.LblsAndTtls.volumeTtl				=		'Volume1';

Modules.LblsAndTtls.reference1Ttl				=		'Reference11';
Modules.LblsAndTtls.reference2Ttl				=		'Reference21';
Modules.LblsAndTtls.reference3Ttl				=		'Reference31';
Modules.LblsAndTtls.reference4Ttl				=		'Reference41';
Modules.LblsAndTtls.reference5Ttl				=		'Reference51';

Modules.LblsAndTtls.voyageMonitoringPanelTtl			 =   'Voyage Monitoring1';
Modules.LblsAndTtls.consolidatedLoadListPanelTtl    	 =   'Consolidated Load List1';
Modules.LblsAndTtls.consolidatedDischargeListPanelTtl    =   'Consolidated Discharge List1';
Modules.LblsAndTtls.reeferConnDtlsPanelTtl				 =	 'Reefer Conn Details1';
Modules.LblsAndTtls.ctrSrvcRecPanelTtl				     =   'Container Service Recording1';
Modules.LblsAndTtls.ctrListPanelTtl                      =	 'Container list1';
Modules.LblsAndTtls.containerHistoryTabParentPanelTtl	 = 'Container History1';
Modules.LblsAndTtls.transporterDetailsSealNumbersPanelTtl=  'Transporter Details & Seal No1';
Modules.LblsAndTtls.entryPanelTtl						 =   'Entry1';
Modules.LblsAndTtls.exitPanelTtl						 =   'Exit1';
Modules.LblsAndTtls.reeferDtlsPanelTtl					 =   'Reefer Details1';
Modules.LblsAndTtls.oogDtlsPanelTtl						 =   'OOG Details1';
Modules.LblsAndTtls.partyDtlsTtl					     =	 'Party Details1';



Modules.LblsAndTtls.vslCallDtlsTtl					=		'Vessel Call Details1';
Modules.LblsAndTtls.portRotationTtl					=		'Port Rotation1';
Modules.LblsAndTtls.ctrDtlsTtl						=		'Container Details1';
Modules.LblsAndTtls.draftDtlsTtl					=		'Draft Details1';
Modules.LblsAndTtls.vesselDtlsTtl					=		'Vessel Details1';
Modules.LblsAndTtls.queryParametersTtl				=		'Query Parameters1';
Modules.LblsAndTtls.backToTownCtrIdentificationTtl	=		'Back To Town Container Identification1';
Modules.LblsAndTtls.hzDtlsGridTtl					=		'Hazardous Details1';
Modules.LblsAndTtls.tempRecDtlsGridTtl				=		'Temperature Record Details1';
Modules.LblsAndTtls.markDeleteActionTtl 			= 		'Mark Delete1';
Modules.LblsAndTtls.unmarkDeleteActionTtl 			= 		'UnMark Delete1';
Modules.LblsAndTtls.vslOprtDtlsTtl					=		'VOA Details1';
Modules.LblsAndTtls.damageDtlsGridTtl				=		'Damage Details1';
Modules.LblsAndTtls.serviceDtlsGridTtl				=		'Service Details1';
Modules.LblsAndTtls.connDisconnDtlsGridTtl			=		'Conn/Disconn Details1';
Modules.LblsAndTtls.bdlDtlsGridCreatCtrTtl			=	    'Bundle Details1';
Modules.LblsAndTtls.portsTtl			 			= 		'Ports1';
Modules.LblsAndTtls.mapperTtl						=		'Mapper1';
Modules.LblsAndTtls.trasmissionDtlsTtl				=		'Trasmission Details1';


Modules.LblsAndTtls.reqRegDttmLbl					=		'Appln Date1';
Modules.LblsAndTtls.etbDttmLbl						=		'Expected Time of Berthing1';
Modules.LblsAndTtls.atbDttmLbl						=		'Berth Time1';
Modules.LblsAndTtls.atubDttmLbl						=		'UnBerth Time1';
Modules.LblsAndTtls.etuLbl							=		'ETU1';
Modules.LblsAndTtls.frmDttmLbl 			  	        = 		'From Date1';
Modules.LblsAndTtls.frmTmLbl 			  	        = 		'From Time1';
Modules.LblsAndTtls.toDttmLbl 			  	    	= 		'To Date1'; 
Modules.LblsAndTtls.toTmLbl 			  	    	= 		'To Time1'; 
Modules.LblsAndTtls.arrivalDraftLbl				    =   	'Arrival Draft1';
Modules.LblsAndTtls.anchorageDateLbl				=   	'Anchorage Date1';
Modules.LblsAndTtls.vslAllfastDtLbl					=   	'Vsl All Fast Date1';
Modules.LblsAndTtls.vslAshoreDtLbl					=   	'Vsl Ashore Date1';
Modules.LblsAndTtls.tiedDtLbl						=   	'Tied Date1';
Modules.LblsAndTtls.logDttmLbl						=	    'Log Dttm1';
Modules.LblsAndTtls.apprvdDttmLbl					=	    'Apprvd Dttm1';
Modules.LblsAndTtls.invoiceDttmLbl					=   	'Invoice Dttm1';
Modules.LblsAndTtls.boeCstmrDttmLbl					=		'BEO/Cstmr Date1';
Modules.LblsAndTtls.entryDttmLbl					=	    'Entry DTTM1';
Modules.LblsAndTtls.exitDttmLbl						=	    'Exit DTTM1';
Modules.LblsAndTtls.etaLbl							=		'ETA1';
Modules.LblsAndTtls.etdLbl							=		'ETD1';
Modules.LblsAndTtls.etbLbl							=		'ETB1';
Modules.LblsAndTtls.ataDttmLbl						=		'ATA1';
Modules.LblsAndTtls.atdDttmLbl						=		'ATD1'; 
Modules.LblsAndTtls.tempRecDttmLbl					=	    'Temp Rec Dttm1';
Modules.LblsAndTtls.connectionDttmLbl				=	    'Connection Dttm1';
Modules.LblsAndTtls.disConnectionDttmLbl			=   	'Disconnection Dttm1';
Modules.LblsAndTtls.applFromDateLbl					=		'Application Dates From1';
Modules.LblsAndTtls.etaFromDateLbl					=		'ETA Dates From1';
Modules.LblsAndTtls.etaToDateLbl			    	=		'To1';
Modules.LblsAndTtls.lbrOnboardLbl					=		'Labour Onboard Date1';
Modules.LblsAndTtls.lbrOffboardLbl					=		'Labour Offboard Date1';
Modules.LblsAndTtls.arrCustomClrDtLbl				=		'Arrival Custom Clear Date1';
Modules.LblsAndTtls.depCustomClrDtLbl				=		'Departure Custom Clear Date1';
Modules.LblsAndTtls.actualDischargeOprnStartDtLbl	=		'Actual Discharge Oprn Start Date1';
Modules.LblsAndTtls.actualDischargeOprnEndDtLbl		=		'Actual Discharge Oprn End Date1';
Modules.LblsAndTtls.actualLoadOprnStartDtLbl		=		'Actual Load Oprn Start Date1';
Modules.LblsAndTtls.actualLoadOprnEndDtLbl			=		'Actual Load Oprn End Date1';
Modules.LblsAndTtls.getOpenTimeLbl					=		'Gate Open Tm1';
Modules.LblsAndTtls.finalCutoffTimeLbl				=		'Final Cut Off Tm1';
Modules.LblsAndTtls.forTruckFinalCutOffTimeLbl		=		'For Truck Final Cut Off Tm1';
Modules.LblsAndTtls.recordingDttmLbl				=   	'Recording Dttm1';
Modules.LblsAndTtls.berthingTimeLbl					=		'Berthing Time1';
Modules.LblsAndTtls.unberthingTimeLbl				=		'UnBerthing Time1';
Modules.LblsAndTtls.dmgDt                           = 		'Dmg Date1';
Modules.LblsAndTtls.rprDt                           = 		'Rpr Date1';
Modules.LblsAndTtls.endDate                         = 		'End Date1';


Modules.LblsAndTtls.emgncyFlgLbl					=		'Emergency Flag1';
Modules.LblsAndTtls.flagLbl							=		'Flag1';
Modules.LblsAndTtls.oogFlagLbl						=		'Oog Flg1';
Modules.LblsAndTtls.dmgFlgLbl						=		'Dmg Flg1';
Modules.LblsAndTtls.hzFlgLbl						=		'Hz Flg1';
Modules.LblsAndTtls.brProcessFlgLbl					=		'BR Process Flg1';
Modules.LblsAndTtls.holdFlagLbl						=		'Hold Flag1';
Modules.LblsAndTtls.rfrOrderFlgCheckBoxLbl			=		'ReeferOrder Flag1';	
Modules.LblsAndTtls.rfrOprnFlgCheckBoxLbl			=		'ReeferOprn Flag1';
Modules.LblsAndTtls.ctrSrvIdLbl						=		'Ctr Srv ID1';
Modules.LblsAndTtls.invcRqdFlgLbl					=		'Invc Rqd Flg1';	
Modules.LblsAndTtls.splEqptFlgCheckBoxLbl			=		'Spl Eqpt Flag1';
Modules.LblsAndTtls.sprdrRqrdoFlgCheckBoxLbl		=		'Sprdr Rqrdo Flag1';
Modules.LblsAndTtls.primaryFlagLbl					=		'Primary Flag1';
Modules.LblsAndTtls.appFlgLbl						=		'App Flg1';
Modules.LblsAndTtls.rprFlg                          =   	'Rpr Flg1';
Modules.LblsAndTtls.bdlFlgLbl						=		'BDl Flg1';
Modules.LblsAndTtls.holdFlgLbl						=		'Hold Flg1';
Modules.LblsAndTtls.drfPrintedFlgLbl				=		'Drf Printed Flg1';
Modules.LblsAndTtls.drfApprovedFlgLbl				=		'Drf Approved Flg1';
Modules.LblsAndTtls.invcGenFlgLbl		 			=		'Invc Gen Flg1';
Modules.LblsAndTtls.primryFlgLbl				    =   	'Primry Flag1';
Modules.LblsAndTtls.rfrFlgLbl						=		'Rfr Flg1';

/************************************* Cd Field labels **************************************/
Modules.LblsAndTtls.isoCdLbl						=		'ISO Cd1';
Modules.LblsAndTtls.dptOrgnCdLbl					=		'Dpt Orgn Cd1';
Modules.LblsAndTtls.quayCdLbl						=		'Quay Cd1';
Modules.LblsAndTtls.dmgCdLbl                        =   	'Dmg Cd1';
Modules.LblsAndTtls.dmgSvrLbl                       =   	'Dmg Svrty Cd1';
Modules.LblsAndTtls.tmnlCdLbl						=		'Tmnl Cd1';
Modules.LblsAndTtls.vslCatCdLbl						=		'Vessel Catogery1';
Modules.LblsAndTtls.ldTradeCdLbl					=		'Trade Cd1';
Modules.LblsAndTtls.routeCdLbl						=		'Route Cd1';
Modules.LblsAndTtls.vslCdLbl						=		'Vsl Cd1';
Modules.LblsAndTtls.srvCdLbl						=		'Service Cd1';
Modules.LblsAndTtls.cnsrtmCdLbl						=		'Consortium Cd1';
Modules.LblsAndTtls.invcPrtyCdLbl 			  		= 		'Invc Party Cd1';
Modules.LblsAndTtls.frmCtrSrvcCdLbl 			  	= 		'From Ctr Srvc Cd1'; 
Modules.LblsAndTtls.invcRqstCdLbl 			  	    = 		'Invc Rqst Cd1';
Modules.LblsAndTtls.toCtrSrvcCdLbl 			  	    = 		'To Ctr Srvc Cd1';
Modules.LblsAndTtls.dlyCdLbl         	   			= 		'Delay Cd1';
Modules.LblsAndTtls.reasonCdLbl						=		'Reason Cd1';
Modules.LblsAndTtls.cmdtCdLbl						=		'Cmdt Cd1';
Modules.LblsAndTtls.dmgSrvtCdLbl					=		'Dmg Srvt cd1';
Modules.LblsAndTtls.unHzCodeLbl						=		'Un Hz Cd1';
Modules.LblsAndTtls.dmgCodeLbl						=		'Dmg Cd1';
Modules.LblsAndTtls.imoCodeLbl						=		'IMO Cd1';
Modules.LblsAndTtls.invcPtyCdLbl					=		'Invc Pty1';
Modules.LblsAndTtls.depotCodeLbl					=		'Depot Cd1';
Modules.LblsAndTtls.depotOrgnCdLbl				    =	    'Depot Orgn Cd1';
Modules.LblsAndTtls.loadInstrCdLbl					=	    'Load Instr Cd1';
Modules.LblsAndTtls.imdgCdLbl						=		'IMDG Cd1';
Modules.LblsAndTtls.currencyCdLbl					=		'Currency Cd1';
Modules.LblsAndTtls.creditTermCdLbl					=		'Credit Term Cd1';
Modules.LblsAndTtls.bankCdLbl						=		'Bank Cd1';
Modules.LblsAndTtls.partyCdLbl						=		'Party Cd1';
Modules.LblsAndTtls.postCdLbl						=		'Post Cd1';
Modules.LblsAndTtls.localAgentCdLbl					=		'Local Agent Cd1';

Modules.LblsAndTtls.rqstNoLbl						=		'Request No1';
Modules.LblsAndTtls.cstmLbl							=		'Consortium1';
Modules.LblsAndTtls.windowLbl						=		'Window1';
Modules.LblsAndTtls.lastPortLbl						=		'Last Port1';
Modules.LblsAndTtls.nextPortLbl						=		'Next Port1';
Modules.LblsAndTtls.dlbthIndLbl						=		'D/L/Bth Ind1';
Modules.LblsAndTtls.inboundLbl						=		'Inbound1';
Modules.LblsAndTtls.outboundLbl						=		'Outbound1';
Modules.LblsAndTtls.maidenVoyLbl					=		'Maiden Voyage1';
Modules.LblsAndTtls.berthSideLbl					=		'Berthing Side1';
Modules.LblsAndTtls.dishVoyNoLbl					=		'Dish Voy No1';
Modules.LblsAndTtls.loadVoyNoLbl					=		'Load Voy No1';
Modules.LblsAndTtls.ispsLevelLbl					=		'ISPS Level1';
Modules.LblsAndTtls.egmRotatonLbl					=		'EGM Rotation No1';
Modules.LblsAndTtls.igmRotationNoLbl				=		'IGM Rotation No1';
Modules.LblsAndTtls.exportBrCountLbl				=		'Export BR (Count)1';
Modules.LblsAndTtls.exportBrTeuLbl					=		'Export BR (TEU)1';
Modules.LblsAndTtls.terminalLbl						=		'Terminal1';
Modules.LblsAndTtls.imoLbl							=		'IMO1';
Modules.LblsAndTtls.callSignLbl						=		'Call Sign1';
Modules.LblsAndTtls.arrFwdLbl						=		'Arrival Forward1';
Modules.LblsAndTtls.arrAftLbl						=		'Arrival Aft1';
Modules.LblsAndTtls.depFwdLbl						=		'Departure Forward1';
Modules.LblsAndTtls.depAftLbl						=		'Departure Aft1';
Modules.LblsAndTtls.loaLbl							=		'LOA1';
Modules.LblsAndTtls.grtLbl							=		'GRT1';
Modules.LblsAndTtls.nrtLbl							=		'NRT1';
Modules.LblsAndTtls.deadWtLbl						=		'Dead Wt1';
Modules.LblsAndTtls.portOfRegLbl					=		'Port Of Reg1';
Modules.LblsAndTtls.vslTypeLbl						=		'Vsl Type1';
Modules.LblsAndTtls.vslCgyLbl						=		'Vsl Category1';
Modules.LblsAndTtls.vslAgentAddrLbl					=		'Vsl Agent Address1';
Modules.LblsAndTtls.cgyLbl							=		'Category1';
Modules.LblsAndTtls.ctrCountLbl						=		'Ctr Count1';
Modules.LblsAndTtls.dishLdgIndLbl					=		'Dish Ldg Ind1';
Modules.LblsAndTtls.portRotLbl						=		'Port Rotation1'; 
Modules.LblsAndTtls.vesselCategoryLbl				=		'Vsl Category1'; 
Modules.LblsAndTtls.requestStsLbl					=		'Request Sts1'; 
Modules.LblsAndTtls.notArrivedCheckBoxLbl			=		'Not Arrived1';
Modules.LblsAndTtls.arrivedCheckBoxLbl				=		'Arrived1';
Modules.LblsAndTtls.berthedCheckBoxLbl				=		'Berthed1';
Modules.LblsAndTtls.departedCheckBoxLbl				=		'Departed1'; 
Modules.LblsAndTtls.voyRqstNoLbl					=		'Request No1';
Modules.LblsAndTtls.rqstStsLbl						=		'Rqst Sts1';
Modules.LblsAndTtls.currentBerthLbl					=		'Current Berth1';
Modules.LblsAndTtls.vslBeamLbl						=		'Beam1';
Modules.LblsAndTtls.deadWtLbl						=		'Dwt1'; 
Modules.LblsAndTtls.impUnitsLbl						=		'Import Units1';
Modules.LblsAndTtls.expUnitsLbl						=		'Export Units1';
Modules.LblsAndTtls.totalUnitsLbl					=		'Total Units1';
Modules.LblsAndTtls.cntnrNoLbl              	    =       'Ctr No1'; 
Modules.LblsAndTtls.baseStsLbl						=		'Base Sts1';
Modules.LblsAndTtls.feIndLbl						=		'F/E Ind1';
Modules.LblsAndTtls.dishLdgBothIndLbl				=		'D/L/Both Ind1';
Modules.LblsAndTtls.ctrSzLbl						=		'Size1';
Modules.LblsAndTtls.ctrTypeLbl						=		'Type1';
Modules.LblsAndTtls.containerHtLbl					=		'Height1';
Modules.LblsAndTtls.frmEntryLbl						=		'From Entry1';
Modules.LblsAndTtls.frmExitLbl						=		'From Exit1';
Modules.LblsAndTtls.locIndLbl						=		'Loc Ind1';
Modules.LblsAndTtls.toEntryMdLbl					=		'To Entry1';
Modules.LblsAndTtls.toExitMdLbl						=		'To Exit1';
Modules.LblsAndTtls.bdlIndLbl						=		'BDL Ind1';
Modules.LblsAndTtls.fclLclIndLbl					=		'FCL/LCL Ind1';
Modules.LblsAndTtls.entryMdLbl						=		'Entry Mode1';
Modules.LblsAndTtls.exitModeLbl						=		'Exit Md1';
Modules.LblsAndTtls.vslNmLbl		 				=		'Vsl Nm1'; 
Modules.LblsAndTtls.srvcCmptDnLbl		 			=		'Srvc Work Copmletion Done1'; 
Modules.LblsAndTtls.viewCmpltSrvcLbl		 		=		'View Complete Srvc1';
Modules.LblsAndTtls.motherFeederIndLbl				=		'M/F Ind1';
Modules.LblsAndTtls.diffInHrsLbl					=		'Diff(in hrs)1';	
Modules.LblsAndTtls.totalWtLbl						=		'Total Wt(Mt)1';
Modules.LblsAndTtls.vcnLbl							=		'VCN1';
Modules.LblsAndTtls.vldtWtLbl						=		'Vldt Wt1';
Modules.LblsAndTtls.demobilizationServiceLbl		=		'Demobilization Service1';
Modules.LblsAndTtls.piolatageServReqLbl				=		'Piolatage Serv Req1';
Modules.LblsAndTtls.piolatageRemrksLbl				=		'Piolatage Rmks1';
Modules.LblsAndTtls.fromLocLbl						=		'From Loc1';
Modules.LblsAndTtls.toLocLbl						=       'To Loc1';
Modules.LblsAndTtls.ctgryLbl						=		'Category1';
Modules.LblsAndTtls.podLbl 							=		'POD1';
Modules.LblsAndTtls.fpdLbl							=		'FPD1';
Modules.LblsAndTtls.cpLbl							=		'CP1';
Modules.LblsAndTtls.customRefNoLbl					=		'Custom Ref No1';
Modules.LblsAndTtls.officersNmLbl					=		"Officer's NM";
Modules.LblsAndTtls.relRemarksLbl					=		'Release Remarks1';
Modules.LblsAndTtls.cntnrListLbl             		=  	 	'List Of Ctrs1';
Modules.LblsAndTtls.holdRemarkLbl					=		'Hold Remark1';
Modules.LblsAndTtls.loaLblm						    =		'LOA(m)1';
Modules.LblsAndTtls.tmnlNmLbl						=		'Terminal Nm1';
Modules.LblsAndTtls.beamLbl							=		'Beam1';
Modules.LblsAndTtls.gtLbl						    =   	'GT1';
Modules.LblsAndTtls.displacementLbl					=   	'Displacement1';
Modules.LblsAndTtls.dmgSectLbl                      =   	'Dmg Sect1';
Modules.LblsAndTtls.dmgSeqNoLbl                     =   	'Dmg Seq No1';
Modules.LblsAndTtls.dmgDescrLbl                     =   	'Dmg Descr1';
Modules.LblsAndTtls.respPartyLbl                    =  	 	'Responisible Party1';
Modules.LblsAndTtls.rprAmt                			= 		'Rpr Amt1';
Modules.LblsAndTtls.rprDrtn               			= 		'Rpr Duration1';
Modules.LblsAndTtls.cstmClNoLbl              		= 		'Custom Clearance No1';
Modules.LblsAndTtls.newPodLbl                		= 		'New POD1';
Modules.LblsAndTtls.newFpdLbl                		= 		'New FPD1';
Modules.LblsAndTtls.newExprtrLbl             		= 		'New Exporter1';
Modules.LblsAndTtls.sealType1Lbl         			= 		'Seal Type11';
Modules.LblsAndTtls.sealType2Lbl         			= 		'Seal Type21';
Modules.LblsAndTtls.sealType3Lbl         			= 		'Seal Type31';
Modules.LblsAndTtls.sealNo1Lbl           			= 		'Seal No11';
Modules.LblsAndTtls.sealNo2Lbl           			= 		'Seal No21';
Modules.LblsAndTtls.sealNo3Lbl           			= 		'Seal No31';
Modules.LblsAndTtls.newCtrNoLbl						=		'New Ctr NO1';
Modules.LblsAndTtls.newBaseStsLbl					=		'New Base Sts1';
Modules.LblsAndTtls.rstTypeLbl						=		'Rst Type1';
Modules.LblsAndTtls.respondPtyRestowLbl				=		'Respond Pty for Restow1';
Modules.LblsAndTtls.vslCellLocnLbl					=		'Vsl Cell Loc1';
Modules.LblsAndTtls.newVslCellLocnLbl				=		'New Vsl Cell Loc1';
Modules.LblsAndTtls.toVslCellLocnLbl				=		'To Vsl Cell Loc1';
Modules.LblsAndTtls.currentLocIndLbl				=		'Cur Loc Ind1';
Modules.LblsAndTtls.yardLocationLbl					=		'Yard Loc1';
Modules.LblsAndTtls.reasonForCancellationLbl		=		'Cancellation Reason1'; 
Modules.LblsAndTtls.arrDraftLbl						=		'Arr Draft1';
Modules.LblsAndTtls.depDraftLbl						=		'Dep Draft1';
Modules.LblsAndTtls.wharfMarkLbl					=		'Whatf Mark1';                                                    
Modules.LblsAndTtls.berthNoLbl						=		'Berth No1';
Modules.LblsAndTtls.tmnlLbl							=		'Tmnl1';//need to remove after testing
Modules.LblsAndTtls.fmMmLbl							=		'Fm Mm1';
Modules.LblsAndTtls.toMmLbl							=		'To Mm1';
Modules.LblsAndTtls.berthSidePsLbl					=		'Berthing Side P/S1';
Modules.LblsAndTtls.berthingRmrksLbl				=		'Berthing Rmrks1';
Modules.LblsAndTtls.unberthReasonLbl				=		'UnBerth Reason1';
Modules.LblsAndTtls.unberthRmrksLbl					=		'UnBerth Rmrks1';
Modules.LblsAndTtls.eqpIdLbl         	   			= 		'Equipment ID1';
Modules.LblsAndTtls.dlyTypeLbl         	   			= 		'Delay Type1';
Modules.LblsAndTtls.dlyDescLbl         	   			= 		'Delay Description1';
Modules.LblsAndTtls.timeInMinLbl           			= 		'Duration In Minutes1';
Modules.LblsAndTtls.noOfHatchLbl		  			= 		'No Of Hatch1';
Modules.LblsAndTtls.remarksLbl		       			= 		'Remarks1';
Modules.LblsAndTtls.brNoLbl							=		'BR No1';
Modules.LblsAndTtls.polLbl							=		'POL1';
Modules.LblsAndTtls.curStsLbl						=		'Cur Sts1';
Modules.LblsAndTtls.sbNoLbl							=		'SB No1';
Modules.LblsAndTtls.curLocnLbl						=		'Cur Loc1';
Modules.LblsAndTtls.excludeSlaveLbl					=		'Exclude Slave1';
Modules.LblsAndTtls.notInPortLbl					=		'Not InPrt1';		
Modules.LblsAndTtls.inPortLbl						=		'In Port1';
Modules.LblsAndTtls.inYardLbl						=		'In Yard1';
Modules.LblsAndTtls.onVesselLbl						=		'On Vessel1';
Modules.LblsAndTtls.manifestedLbl					=		'Manifested1';
Modules.LblsAndTtls.dshdNotInYrdLbl					=		'Dshd Not In Yrd1';
Modules.LblsAndTtls.dshdInYrdLbl					=		'Dshd In Yrd1';		  
Modules.LblsAndTtls.ctrExtdTrmlLbl					=		'Ctr Extd Trml1';
Modules.LblsAndTtls.hzCtrsLbl						=		'Hz Ctrs1';
Modules.LblsAndTtls.rfrCtrsLbl						=		'Rfr Ctrs1';
Modules.LblsAndTtls.oogCtrsLbl						=		'Oog Ctrs1';
Modules.LblsAndTtls.mstrBndlLbl						=		'Master Bndl1';	
Modules.LblsAndTtls.slaveBndlLbl					=		'Slave Bndl1';
Modules.LblsAndTtls.mstrIndLbl						=		'Mstr Ind1';
Modules.LblsAndTtls.slaveIndLbl						=		'Slave Ind1';
Modules.LblsAndTtls.manifestedTotLbl				=		'Manifested Tot1';
Modules.LblsAndTtls.totalManifestedLbl				=		'Total Manifested1';		
Modules.LblsAndTtls.twentyTotLbl					=		"20' Tot";		
Modules.LblsAndTtls.twentyFullCntLbl				=		"20' Full Cnt";	
Modules.LblsAndTtls.twentyMtyCntLbl					=		"20' Mty Cnt";
Modules.LblsAndTtls.fourtyTotLbl					=		"40' Tot";		
Modules.LblsAndTtls.fourtyFullCntLbl				=		"40' Full Cnt";		
Modules.LblsAndTtls.fourtyMtyCntLbl					=		"40' Mty cnt";
Modules.LblsAndTtls.fourtyFiveTotLbl				=		"45' Tot";		
Modules.LblsAndTtls.fourtyFiveFullCntLbl			=		"45' Full Cnt";  
Modules.LblsAndTtls.fortyFiveMtyCntLbl				=		"45' Mty Cnt";
Modules.LblsAndTtls.exportLbl						=		'Export1';
Modules.LblsAndTtls.importLbl						=		'Import1';
Modules.LblsAndTtls.loadedTotLbl					=		'Loaded tot1';		
Modules.LblsAndTtls.restowLbl						=		'Restow1';
Modules.LblsAndTtls.transhipmentLbl					=		'Transhipment1';
Modules.LblsAndTtls.robLbl							=		'Rob1';
Modules.LblsAndTtls.totlaDischargedLbl				=		'Total Discharged1';
Modules.LblsAndTtls.pendingCtrLbl					=		'Pending Ctrs1';
Modules.LblsAndTtls.statusLbl						=		'Status1';
Modules.LblsAndTtls.newCpLbl						=		'New CP1';
Modules.LblsAndTtls.descriptionLbl					=		'Description1';
Modules.LblsAndTtls.boeCstmrRefLbl					=		'BOE/Cstmr Ref1';
Modules.LblsAndTtls.pilotageSrvLbl					=		'Pilotage Service1';
Modules.LblsAndTtls.pilotageRmrksLbl				=		'Pilotage Remarks1';
Modules.LblsAndTtls.wrongCntrNoLbl					=		'Wrong Ctr no1';
Modules.LblsAndTtls.actualCntrNoLbl					=		'Actual Ctr No1';
Modules.LblsAndTtls.reasonLbl						=		'Reason1';
Modules.LblsAndTtls.restowPtyLbl					=		'Restow Pty1';
Modules.LblsAndTtls.catogeryLbl						=		'Catogery1';
Modules.LblsAndTtls.tareWtMTLbl						=		'Tare Wt(MT)1';
Modules.LblsAndTtls.bookingNoLbl					=		'Booking No1';
Modules.LblsAndTtls.cargoTypeLbl					=		'Cargo Type1';
Modules.LblsAndTtls.lifeNoLbl						=		'Life No1';
Modules.LblsAndTtls.locationLbl						=		'Loc1';
Modules.LblsAndTtls.locationNameLbl					=		'Loc Nm1';
Modules.LblsAndTtls.curLocIndLbl					=		'Cur Loc Ind1';
Modules.LblsAndTtls.bdlIdLbl						=		'Bdl ID1';
Modules.LblsAndTtls.viewBundleLbl					=		'View Bundle Ctrs1';
Modules.LblsAndTtls.rfrCheckBoxLbl					=		'Rfr1';
Modules.LblsAndTtls.oogCheckBoxLbl					=		'Oog1';
Modules.LblsAndTtls.hzCheckBoxLbl					=		'Hz1';
Modules.LblsAndTtls.dmgCheckBoxLbl					=		'Dmg1';
Modules.LblsAndTtls.holdCheckBoxLbl					=		'Hold1';
Modules.LblsAndTtls.truckNoLbl						=		'Truck No1';
Modules.LblsAndTtls.driverNameLbl					=		'Driver Nm1';
Modules.LblsAndTtls.truckEntryLbl					=		'Truck Entry1';
Modules.LblsAndTtls.truckExitLbl					=		'Truck Exit1';
Modules.LblsAndTtls.cstmSealLbl						=		'Cstm Seal1';
Modules.LblsAndTtls.customSealNoLbl					=		'Cstm SealNo1';
Modules.LblsAndTtls.customSealTypeLbl				=		'Cstm SealType1';
Modules.LblsAndTtls.linerSealLbl					=		'Liner Seal1';
Modules.LblsAndTtls.linerSealNoLbl					=		'Liner SealNo1';
Modules.LblsAndTtls.linerSealTypeLbl				=		'Liner SealType1';
Modules.LblsAndTtls.sipperSealLbl					=		'Shpr Seal1';
Modules.LblsAndTtls.shipperSealNoLbl				=		'Shpr SealNo1';
Modules.LblsAndTtls.shipperSealTypeLbl				=		'Shpr SealType1';
Modules.LblsAndTtls.originLbl						=		'Origin1';													    
Modules.LblsAndTtls.destinationLbl					=		'Destination1';
Modules.LblsAndTtls.drfNoLbl						=		'Drf No1';	
Modules.LblsAndTtls.exitMdLbl						=		'Exit Md1';
Modules.LblsAndTtls.minTempNoLbl					=		'Min Temp1';
Modules.LblsAndTtls.maxTempNoLbl					=		'Max Temp1';
Modules.LblsAndTtls.setTempLbl						=		'Set Temp1';	
Modules.LblsAndTtls.supplyAirTempLbl				=		'SupplyAir Temp1';
Modules.LblsAndTtls.returnAirTempLbl				=		'ReturnAir Temp1';
Modules.LblsAndTtls.tempMsrUnitLbl					=		'Temp Msr Unit1';
Modules.LblsAndTtls.overHtNoLbl						=		'Over Ht1'; 
Modules.LblsAndTtls.cargoHtNoLbl					=		'Cargo Ht1';
Modules.LblsAndTtls.overLengthAftLbl				=		'OverLegth Aft1';	
Modules.LblsAndTtls.overLengthForeLbl				=		'OverLegth Fore1';
Modules.LblsAndTtls.overWidthLeftSideLbl			=		'OverWidth LeftSide1';
Modules.LblsAndTtls.overWidthRightSideLbl			=		'OverWidth RightSide1';
Modules.LblsAndTtls.msrUnitLbl						=		'Msr Unit1';													    
Modules.LblsAndTtls.dmgSecLbl						=		'Dmg Sec1';
Modules.LblsAndTtls.dmgTypeLbl						=		'Dmg Type1';													    
Modules.LblsAndTtls.remarkLbl						=		'Remark1';
Modules.LblsAndTtls.mvmtRqrdLbl						=		'Mvmt Rqrd1';
Modules.LblsAndTtls.srvWkCompLbl					=		'Srv Wk Comp1';
Modules.LblsAndTtls.apprvdUserNmLbl					=		'Apprvd User Nm1';
Modules.LblsAndTtls.serviceRemarkLbl				=		'Service Remark1';
Modules.LblsAndTtls.actTempLbl						=		'Act Temp1';
Modules.LblsAndTtls.tempUomLbl						=		'Temp UOM1';
Modules.LblsAndTtls.userNmLbl						=		'User Nm1';
Modules.LblsAndTtls.exporterLbl						=		'Exporter1';
Modules.LblsAndTtls.dispMdLbl						=		'Disp Mode1';
Modules.LblsAndTtls.cmdtLbl							=		'Commodity1';
Modules.LblsAndTtls.uomLbl							=		'UOM1';
Modules.LblsAndTtls.techDesrcLbl					=		'Tech Desrc1';
Modules.LblsAndTtls.slotsLbl						=		'No of Slots Avail1';
Modules.LblsAndTtls.totHtLbl						=		'Total Height1';
Modules.LblsAndTtls.rfrTyLbl					    =   	'Rfr Type1';
Modules.LblsAndTtls.forthPortsWinTtl				=		'FOURTH PORTS Login1';
Modules.LblsAndTtls.loginIdLbl						=		'Login ID1';
Modules.LblsAndTtls.passwordLbl						=		'Password1';
Modules.LblsAndTtls.okLbl							=		'OK1';
Modules.LblsAndTtls.resetLbl						=		'Reset1';
Modules.LblsAndTtls.forgotPassLbl					=		'Forgot Password1';
Modules.LblsAndTtls.forgotPassWinTtl				=		'Forgot Password1';
Modules.LblsAndTtls.emailIdLbl						=		'Email ID1';
Modules.LblsAndTtls.changePassWinTtl				=		'Change Password1';
Modules.LblsAndTtls.oldPasswordLbl					=		'Old Password1';
Modules.LblsAndTtls.newPasswordLbl					=		'NEW Password1';
Modules.LblsAndTtls.confirmNewPasswordLbl			=		'Confirm Password1';
Modules.LblsAndTtls.portOrginialOrderLbl			=		'Original Order1';
Modules.LblsAndTtls.portNewOrderLbl					=		'New Order1';
Modules.LblsAndTtls.portCodeLbl						=		'Port Code1';
Modules.LblsAndTtls.portNameLbl						=		'Port Name1';
Modules.LblsAndTtls.delMarkedLbl					=		'Delete Marked1';
Modules.LblsAndTtls.yesLbl							=		'Yes1';
Modules.LblsAndTtls.noLbl							=		'No1';
Modules.LblsAndTtls.dragReOrderLbl					=		'Drag and drop to reorganize1';
Modules.LblsAndTtls.newLbl							=		'New1';
Modules.LblsAndTtls.depotDestCdLbl					=		'Depot dest Cd1';
Modules.LblsAndTtls.partyNmLbl						=		'Party Name1';
Modules.LblsAndTtls.finacialIdLbl					=		'Financial ID1';
Modules.LblsAndTtls.pcsPartyLbl						=		'Pcs Party1';
Modules.LblsAndTtls.senderPartyLbl					=		'Sender Party1';
Modules.LblsAndTtls.panNoLbl						=		'Pan No1';
Modules.LblsAndTtls.tanNoLbl						=		'Tan No1';
Modules.LblsAndTtls.residenceIndLbl					=		'Residence Ind1';
Modules.LblsAndTtls.localAgentFlgLbl				=		'Local Agent Flg1';
Modules.LblsAndTtls.taxExmptFlgLbl					=		'Tax Exmpt Flg1';
Modules.LblsAndTtls.suspendFlgLbl					=		'Suspend Flg1';
Modules.LblsAndTtls.invoiceAddrTtl					=		'Invoice Address1';
Modules.LblsAndTtls.addressOneLbl					=		'Address1';
Modules.LblsAndTtls.stateCountryLbl					=		'State,Country1';
Modules.LblsAndTtls.telePhoneNo1Lbl					=		'Telephone Number11';
Modules.LblsAndTtls.telePhoneNo2Lbl					=		'Telephone Number21';
Modules.LblsAndTtls.faxNoLbl						=		'Fax Number1';
Modules.LblsAndTtls.mobileNoLbl						=		'Mobile Number1';
Modules.LblsAndTtls.financeEmailAddrLbl				=		'Finance E-mail Address1';
Modules.LblsAndTtls.otherEmailAddrLbl				=		'Other Email Address1';
Modules.LblsAndTtls.contactPsnAccLbl				=		'Contact Person Accounts1';
Modules.LblsAndTtls.contactPsnOprnLbl				=		'Contact Person Operations1';
Modules.LblsAndTtls.partyPaymentRmrksLbl			=		'Party/Payment Remark1';
Modules.LblsAndTtls.emailFlgLbl						=		'E-mail1';
Modules.LblsAndTtls.ediFlgLbl						=		'EDI1';
Modules.LblsAndTtls.faxFlgLbl						=		'Fax1';
Modules.LblsAndTtls.vslOprnAgentFlgLbl				=		'Vessel Operating Agent1';
Modules.LblsAndTtls.chaCnFFlgLbl					=		'CHA/C&F1';
Modules.LblsAndTtls.ctrOprnAgentFlgLbl				=		'Container Operating Agent1';
Modules.LblsAndTtls.transporterFlgLbl				=		'Transporter1';
Modules.LblsAndTtls.mloFlgLbl						=		'MLO1';
Modules.LblsAndTtls.nvoccFlgLbl						=		'NVOCC1';
Modules.LblsAndTtls.ctoFlgLbl						=		'Container Train Operator(CTO)1';
Modules.LblsAndTtls.cfsFlgLbl						=		'Container Freight Station1';
Modules.LblsAndTtls.importerFlgLbl					=		'Importer1';
Modules.LblsAndTtls.exporterFlgLbl					=		'Exporter1';
Modules.LblsAndTtls.bureaucrafFlgLbl				=		'Bureaucraf1';
Modules.LblsAndTtls.financialDtlsTtl				=		'Financial Details1';
Modules.LblsAndTtls.bankNmLbl						=		'Bank Name1';
Modules.LblsAndTtls.bankAccNoLbl					=		'Bank Account Number1';
Modules.LblsAndTtls.bankEmailAddrLbl				=		'Bank E-mail Address1';
Modules.LblsAndTtls.documentRmrkLbl					=		'Document Remark1';
Modules.LblsAndTtls.creditTermLbl					=		'Credit Term1';
Modules.LblsAndTtls.bankGuaranteeLbl				=		'Bank Guarantee1';
Modules.LblsAndTtls.creditLimitLbl					=		'Credit Limit1';
Modules.LblsAndTtls.financialContractTtl			=		'Financial Contract1';
Modules.LblsAndTtls.companyAddrTtl					=		'Company Address1';
Modules.LblsAndTtls.msgConfirmedFlgFullTlt          =       'Message Confirmed Flag1';
Modules.LblsAndTtls.invoiceAcceptFlgFullTlt         =       'Invoice Accept Flag1';
Modules.LblsAndTtls.msgTransDateFullTlt             =       'Message Transaction Date1';
Modules.LblsAndTtls.NonTaxableTlt                   =       'Non Taxable1';
/*********************************************************************************************************/
/*************************************===  End Generise Label and Titles  ===*****************************/
/*************************************************************************************By:- Ramanand kumar*/
//// restow,  rfr, oog, hz, dmg, hold,  curLocn, bdlId, imo, invcpty, invcRqdFlg.----> need to be discuss


/** tabs titles**/
Modules.LblsAndTtls.dashBoardTtl			        =		'Dashboard1';
Modules.LblsAndTtls.custInvStatusTtl			    =		'Customer Invoice Status1';
Modules.LblsAndTtls.custReconStatusTtl			    =	    'Customer Reconcilation Status1';
Modules.LblsAndTtls.ediErrMessageTtl			    =	    'EDI Error Message1';
Modules.LblsAndTtls.splMovesStatusTtl			    =	    'Special Moves Status1';
Modules.LblsAndTtls.suppInvoiceStatusTtl			=	    'Supplier Invoice Status1';
Modules.LblsAndTtls.suppReconStatusTtl			    =       'Supplier Reconcilation Status1';
Modules.LblsAndTtls.swimPartnerDtlsTtl			    =       'SWIM-Partner Details1';
Modules.LblsAndTtls.swimPartnerConfigTtl			=       'Partner Configuration1';
Modules.LblsAndTtls.swimProcessAdminiStrationTtl    =       'Process Administration1';
Modules.LblsAndTtls.swimSendMsgAgrmtDtlsTtl			=       'Send Message Agreement Details1';
Modules.LblsAndTtls.swimSendMsgAgrmtConfigTtl		=       'Send Message Aggrement Configuration1';
Modules.LblsAndTtls.swimGrpPartnerConfigTtl		    =       'Group partner mapping configuration1';
Modules.LblsAndTtls.swimGrpPartnerTabTtl			=       'Group partner mapping configuration1';
Modules.LblsAndTtls.backGroundJobsGridRecordTtl		=		'BackGround Jobs1';
Modules.LblsAndTtls.displayJobNameTlt				=		'Job Name1';
Modules.LblsAndTtls.displayStartDateTlt				=		'Start Date1';
Modules.LblsAndTtls.displayRepeatIntervalTlt		=		'Repeat Interval1';
Modules.LblsAndTtls.displayStatusTlt				=		'Status1';
Modules.LblsAndTtls.viewBackGroundJobsFormTlt		=		'BackGround Jobs1';
Modules.LblsAndTtls.backGroundJobsComboTlt			=		'Job ID1';
Modules.LblsAndTtls.backGroundJobsDescTlt			=		'Job Description1';
Modules.LblsAndTtls.firstButtonTlt					=		'First1';
Modules.LblsAndTtls.previousButtonTlt				=		'Previous1';
Modules.LblsAndTtls.nextButtonTlt					=		'Next1';
Modules.LblsAndTtls.lastButtonTlt					=		'Last1';
Modules.LblsAndTtls.displayingRecordTlt				=		'Displaying Record1';

Modules.LblsAndTtls.originLocStProv                 =     'Origin/Location State Province1';
Modules.LblsAndTtls.PriorityTlt                        =       'Priority1';

Modules.LblsAndTtls.fixedRate                        =    'Fixed Rate1';
Modules.LblsAndTtls.variableCmp                      =    'Variable Components1';
Modules.LblsAndTtls.moveStatusTlt	                =      'Move Status1';
Modules.LblsAndTtls.originStateProvince1Tlt          =      'Origin S/P1';
Modules.LblsAndTtls.originStateProvinceFullTlt      =      'Origin State/Province1';
Modules.LblsAndTtls.eventDateTlt                    =       'Event Date1';
Modules.LblsAndTtls.supplierStatusTlt               =       'Supplier Status1';
Modules.LblsAndTtls.customerStatusTlt               =       'Customer Status1';
Modules.LblsAndTtls.moveReferenceTlt                =       'Move Ref1';
Modules.LblsAndTtls.moveReferenceFullTlt            =       'Move Reference1';
Modules.LblsAndTtls.requestorTlt                    =       'Requestor1';
Modules.LblsAndTtls.customerReferenceTlt            =       'Customer Ref1';
Modules.LblsAndTtls.customerReferenceFullTlt        =       'Customer Reference1';
Modules.LblsAndTtls.departmentTlt                   =       'Department1';
Modules.LblsAndTtls.blankTlt                        =       'Blank1';
Modules.LblsAndTtls.sepcialMoveQueryTlt             =       'Special Move Query1';
Modules.LblsAndTtls.statusMonitorAndControlTlt      =       'Status Monitoring and Control1';
Modules.LblsAndTtls.tenderDateTlt                   =       'Tender Date1';
Modules.LblsAndTtls.shipmentDateTlt                 =       'Shipment Date1';
Modules.LblsAndTtls.deliveryDateTlt                 =       'Delivery Date1';
Modules.LblsAndTtls.completionDateTlt               =       'Completion Date1';
Modules.LblsAndTtls.makeTlt                         =       'Make1';
Modules.LblsAndTtls.modelTlt                        =       'Model1';
Modules.LblsAndTtls.modelYearTlt                    =       'Model Year1';
Modules.LblsAndTtls.modelDescrptionTlt              =       'Model Description1';
Modules.LblsAndTtls.modelDescrTlt       			=       'Model Descr1';

Modules.LblsAndTtls.customerSalesRegionTlt          =       'Customer Sales Region1';
Modules.LblsAndTtls.customerSalesRegionTltMandatory =       'Customer Sales Region<span style="color: red">*</span>1';
Modules.LblsAndTtls.cstmrSalesRegnTlt     		    =       'Cust Sales Regn1';
Modules.LblsAndTtls.customerSalesRegionPartTlt		=		'Customer Sales1';
Modules.LblsAndTtls.rateTierTlt                     =        'Rate Tier1';
Modules.LblsAndTtls.conveyanceTypeTlt               =         'Conveyance Type1';
Modules.LblsAndTtls.orderTypeTlt                    =         'Order Type1';
Modules.LblsAndTtls.abnormalMoveTypeTlt        	    =         'Abnormal Move1';
Modules.LblsAndTtls.abnormalMoveTypeFullTlt         =         'Abnormal Move Type1';
Modules.LblsAndTtls.abnorMoveTypeTlt            	=         'Ab Move Type1';
Modules.LblsAndTtls.dealerCodeTlt                   =         'Dealer Code1';
Modules.LblsAndTtls.originalOrginTlt                =         'Original Origin1';                  
Modules.LblsAndTtls.finalDestinationTlt             =         'Final Destination1';
Modules.LblsAndTtls.finalDestTlt            		=         'Final Dest1';
Modules.LblsAndTtls.fuelSurchargeApplicableTlt      =         'Fuel Surcharge Applicable1';
Modules.LblsAndTtls.fuelSurchargeApplicablePartTlt  =         'Fuel Surcharge1';
Modules.LblsAndTtls.sepcialMoveEntryTlt             =         'Special Move Entry1';
Modules.LblsAndTtls.popupspecialMoveQueryGridTlt	=		  'Special Move Query Grid Record1';
Modules.LblsAndTtls.serviceType					    =		  'Service Type Id1';
Modules.LblsAndTtls.additionalServicesCommentsTlt	=		'Additional Serivces/Comments1';
Modules.LblsAndTtls.InsertActionTlt					=		'Insert1';


Modules.LblsAndTtls.copyFromActionTtl				=		'Copy1';
Modules.LblsAndTtls.deSelectAllActionTtl			=		'DeSelect All1';
Modules.LblsAndTtls.selectAllActionTtl				=		'Select All1';
Modules.LblsAndTtls.eventStatusTtl					=		'Event Status Query1';

Modules.LblsAndTtls.supplier						=		'Supplier1';
Modules.LblsAndTtls.customer						=		'Customer1';
Modules.LblsAndTtls.serviceType						=		'Service Type1';
Modules.LblsAndTtls.serviceCode						=		'Service Code1';
Modules.LblsAndTtls.Make							=		'Make1';
Modules.LblsAndTtls.MakeMandatory					=		'Make<span style="color: red">*</span>1';
Modules.LblsAndTtls.Model							=		'Model1';

Modules.LblsAndTtls.ModelCode						=		'Model Code1';
Modules.LblsAndTtls.ModelCodeMandatory				=		'Model Code<span style="color: red">*</span>1';
Modules.LblsAndTtls.PartID                          =       'Part ID1';
Modules.LblsAndTtls.orignLocCity                    =       'Origin/Location City1';
Modules.LblsAndTtls.eventDateType                   =       'Event Date Type',
Modules.LblsAndTtls.ModelGroup						=		'Model Group1';
Modules.LblsAndTtls.TransportMode					=		'Transport Mode1';
Modules.LblsAndTtls.eventDate						=		'Event Date Type1';
Modules.LblsAndTtls.consolidationType				=		'Consolidation Type1';
Modules.LblsAndTtls.origin							=		'Origin1';
Modules.LblsAndTtls.originStateProvince				=		'Origin State/Prvnce1';
Modules.LblsAndTtls.destination						=		'Destination1';
Modules.LblsAndTtls.destinationStateProvince		=		'Dest St/Prvnce1';
Modules.LblsAndTtls.dealerCode						=		'Dealer Code1';
Modules.LblsAndTtls.OrderType						=		'Order Type1';
Modules.LblsAndTtls.shipmentType					=		'shipmentType1';
Modules.LblsAndTtls.AbnormalMoveType				=		'Abnormal Move Type1';
Modules.LblsAndTtls.msgProStscode					=		'MsgProStscode1';
Modules.LblsAndTtls.ConveyanceType					=		'Conveyance Type1';
Modules.LblsAndTtls.unitId							=		'Unit ID1';
Modules.LblsAndTtls.fromDate						=		'From Date1';
Modules.LblsAndTtls.toDate							=		'To Date1';
Modules.LblsAndTtls.consolidationId					=		'Consolidation ID1';
Modules.LblsAndTtls.eventLoadReference				=		'Event/Load Ref1';
Modules.LblsAndTtls.shippingReference				=		'Shipping Ref1';
Modules.LblsAndTtls.originCity						=		'Origin City1';
Modules.LblsAndTtls.destinationCity					=		'Destination City1';
Modules.LblsAndTtls.transportCode					=		'Transport Code1';
Modules.LblsAndTtls.workOrder						=		'Work Order1';
Modules.LblsAndTtls.conveyanceName					=		'Conveyance Name1';
Modules.LblsAndTtls.shipmentType					=		'Shipment Type1';
Modules.LblsAndTtls.conveyanceId					=		'Conveyance ID1';
Modules.LblsAndTtls.Blank							=		'Blank1';

Modules.LblsAndTtls.OrginStateProvFullLbl           =       'Origin State/Province1';

Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier1';
Modules.LblsAndTtls.ratingDestTlt                   =       'Rating Destination1';
Modules.LblsAndTtls.originalOriginTlt               =       'Original Origin1';
Modules.LblsAndTtls.finalDestTlt                    =       'Final Destination1'; 
Modules.LblsAndTtls.finDestTlt                    	=       'Final Dest1'; 
Modules.LblsAndTtls.varianceEvntTlt                 =       'Variance Event1';
Modules.LblsAndTtls.originStateProvinceTlt          =       'Origin State Prov1';
Modules.LblsAndTtls.destinationStateProvinceTlt     =       'Dest State Prov1';   
Modules.LblsAndTtls.destinationSPTlt				=		'Destination S/P'
Modules.LblsAndTtls.customerStatusTlt               =       'Customer Status1';
Modules.LblsAndTtls.profitLossCenter				=		'Profit/Loss Center',
Modules.LblsAndTtls.DebtorParty						=		'Debtor Party',
Modules.LblsAndTtls.supplierStatus					=		'Supplier Status',
Modules.LblsAndTtls.customerStatus					=		'Customer Status',
Modules.LblsAndTtls.originalOrigin					=		'Original Origin1';
Modules.LblsAndTtls.RatingDestination				=		'Rating Destination',
Modules.LblsAndTtls.finalDestination				=		'Final Destination',
Modules.LblsAndTtls.VarianceEvent					=		'Variance Event',
Modules.LblsAndTtls.ServiceGroup					=		'Service Group',

Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier1';
Modules.LblsAndTtls.country                         =       'Country1';
Modules.LblsAndTtls.exportTlt                       =       'Export ?1';
Modules.LblsAndTtls.dutyPaidTlt                     =       'Duty Paid ?1';
Modules.LblsAndTtls.tIBNbrTlt                       =       'TIB Nbr1';
Modules.LblsAndTtls.tIBNbrFullTlt                   =       'TIB Number1';
Modules.LblsAndTtls.tIBExpirationDate				=		'TIB Expire Date1';
Modules.LblsAndTtls.tIBExpirationDateFullTlt        =       'TIB Expiration Date1';
Modules.LblsAndTtls.requestPickUpDateTlt     	    =       'Pickup Date1';
Modules.LblsAndTtls.requestPickUpDateFullTlt        =       'Requested Pickup Date1';
Modules.LblsAndTtls.requestDeliveryDateTlt          =       'Delivery Date1';
Modules.LblsAndTtls.requestDeliveryDateFullTlt      =       'Requested Delivery Date1';
Modules.LblsAndTtls.pickupInfoTlt                   =       'Pickup Info1';
Modules.LblsAndTtls.pickupInfoFullTlt               =        'PickUp Infomation1';
Modules.LblsAndTtls.deliveryInfoTlt                 =		'Delivery Info1';
Modules.LblsAndTtls.deliveryInfoFullTlt    			=		'Delivery Infomation1';
Modules.LblsAndTtls.contactNameTlt 					=		'Contact Name1';
Modules.LblsAndTtls.distanceTlt 					=		'Distance1';
Modules.LblsAndTtls.destinationDetailsTLt           =       'Destination Details1';
Modules.LblsAndTtls.originDetailsTLt                =       'Origin Details1';
Modules.LblsAndTtls.rateTierTlt                     =       'Rate Tier1';
Modules.LblsAndTtls.customerRatingTlt               =		'Customer Rating1';
Modules.LblsAndTtls.supplierRatingTlt               =		'Supplier Rating1';
Modules.LblsAndTtls.notChargeableTlt				=  		'Not Chargeable1'; 
Modules.LblsAndTtls.expenseCodeTlt					=		'Expense Code1';
Modules.LblsAndTtls.serviceAmountTlt				=		'Service Amount($)1';
Modules.LblsAndTtls.taxAmountTlt					=		'Tax Amount($)1';
Modules.LblsAndTtls.glCodeTlt						=		'GL Code1';
Modules.LblsAndTtls.serviceDescriptionTlt			=		'Service Description1';
Modules.LblsAndTtls.specialMoveQueryScreenIdTlt		=		'specialMoveQuery1';
Modules.LblsAndTtls.notTaxableTlt                   =       'Not Taxable1';
Modules.LblsAndTtls.markUpTlt                       =       'Mark Up1';
Modules.LblsAndTtls.markUpCriteria                  =       'Mark Up Criteria1';
Modules.LblsAndTtls.markUpVal                       =       'Mark Up Value1';
Modules.LblsAndTtls.programTlt                      =       'Program1';
Modules.LblsAndTtls.indexTlt                        =       'Index1';
Modules.LblsAndTtls.invcdTlt                        =        'INVCD1';
Modules.LblsAndTtls.rejectTlt                       =        'REJECT1';

Modules.LblsAndTtls.SupplrEvntStsSummTlt            =       'Supplier Event Status Summary1';
Modules.LblsAndTtls.SupplrInvcStsTtl                =       'Supplier Invoice Status1';

Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary1';
Modules.LblsAndTtls.serviceGroupCodeTlt				=		'Service Group Code1';
Modules.LblsAndTtls.debatoryPartyCodeTlt			=       'Debtor Party Code1';



Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary1';

Modules.LblsAndTtls.CustomerRateQueryGridRecord     =       'Customer Rate Query Grid Record1';
Modules.LblsAndTtls.CustomerRateQrySrvCd            =       'Customer Rate Query Service Code1';
Modules.LblsAndTtls.Name            				=       'Name1';
Modules.LblsAndTtls.ContractId            			=       'Contract ID1';
Modules.LblsAndTtls.ServiceCode            			=       'Service Code1';

Modules.LblsAndTtls.originLocationFullTtl           =       'Origin/Location1';
Modules.LblsAndTtls.totalQtyFullTlt                 =       'Total Quantity1';
Modules.LblsAndTtls.totalStrgQtyFullTlt             =       'Total Storage Quantity1';
Modules.LblsAndTtls.totalSrvcAmtFullTlt             =       'Total Service Amount1';
Modules.LblsAndTtls.totalTaxAmtFullTlt              =       'Total Tax Amount1';
Modules.LblsAndTtls.srvcGrpCdFullTtl                =        'Service Group Code1';
Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary1';



Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary1';

Modules.LblsAndTtls.prevChrgdQtyTlt   			    =       'Prev Chrgd Qty1';
Modules.LblsAndTtls.prevChrgdUomCodeTlt   			=       'Prev Chrgd UOM Cd1';
Modules.LblsAndTtls.quantityTlt   					=       'Quantity1';
Modules.LblsAndTtls.storageQuantityTlt   			=       'Storage Quantity1';
Modules.LblsAndTtls.storageUomCodeTlt   			=       'Storage UOM Cd1';

Modules.LblsAndTtls.CustmrEvntStsSummTlt            =       'Customer Event Status Summary1';
Modules.LblsAndTtls.CustmrRateQueryGridTtl			=		'Customer Rate Query Grid Record1';
Modules.Customer.CustomerRateVerificatoin.customerName =    'Customer Name1';
Modules.Customer.CustomerRateVerificatoin.effectiveDate =   'Effective Date1';
Modules.Customer.CustomerRateVerificatoin.originCity    =  'Origin City1';
Modules.Customer.CustomerRateVerificatoin.partCode =        'Part Code1';
Modules.Customer.CustomerRateVerificatoin.destination = 'Destination1';
Modules.Customer.CustomerRateVerificatoin.distinationCity='Destination City1';
Modules.Customer.CustomerRateVerificatoin.destinationStateProvince='destinationStateProvince1';
Modules.Customer.CustomerRateVerificatoin.modelYear='Model Year1';
Modules.Customer.CustomerRateVerificatoin.originalOrigin = 'Original Origin1';
Modules.LblsAndTtls.serviceGrpDescription                  =       'Service Group Description1';
Modules.LblsAndTtls.serviceCdDescription                  	=       'Service Description1';


/*********************************************************************************************/
     //  DYNAMIC MENU SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.headerCompany				    =	'Company1';
Modules.LblsAndTtls.headerServiceType				=	'Service Type1';
Modules.LblsAndTtls.headerLanguage					=	'Language1';
Modules.LblsAndTtls.headerVersion				    =	'Version1';
Modules.LblsAndTtls.headerWelcome				    =	'Welcome1';
Modules.LblsAndTtls.headerHelp				        =	'Help1';
Modules.LblsAndTtls.headerLogout			        =	'Logout1';
Modules.LblsAndTtls.headerFAPS			            =	'FAPS1';

/*********************************************************************************************/
//  DYNAMIC MENU SCREEN LABELS : END
/*********************************************************************************************/




/*********************************************************************************************/
//  CUSTOMER RATE QUERY SERVICE CODE SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.trnsptModeFull						=   'Transport Mode1';
Modules.LblsAndTtls.serviceDescrFull				=	'Service Description1';
Modules.LblsAndTtls.serviceDescr			         =	'Service Descr1';
Modules.LblsAndTtls.trnsptMode				         =	'Trnspt Mode1';
Modules.LblsAndTtls.originLocation					 =  'Origin/Location1';
Modules.LblsAndTtls.makeCode			     	 	 =  'Make Code1';
Modules.LblsAndTtls.partId				     	 	 =  'Part ID1';
Modules.LblsAndTtls.originLocCity					 =  'Origin/Loc. City1';
Modules.LblsAndTtls.originLocStateProv	     	 	 =  'Origin/Loc. State/Prov.1';
Modules.LblsAndTtls.destStateProv		     	 	 =  'Destination State/Prov.1';
Modules.LblsAndTtls.originalOrigin		     	 	 =  'Original Origin1';
Modules.LblsAndTtls.finalDest			     	 	 =  'Final Destination1';
Modules.LblsAndTtls.consolidationTypeCode     	 	 =  'Consolidation Type Code1';
Modules.LblsAndTtls.markup				     	 	 =  'Mark Up1';
Modules.LblsAndTtls.markupCriteria		     	 	 =  'Mark Up Criteria1';
Modules.LblsAndTtls.markUpValue				     	 =  'Mark Up Value1';
Modules.LblsAndTtls.factorValue				     	 =  'Factor Value1';
Modules.LblsAndTtls.factorType			     	 	 =  'Factor Type1';
Modules.LblsAndTtls.factorRate			     	 	 =  'Factor Rate1';
Modules.LblsAndTtls.program				     	 	 =  'Program1';
Modules.LblsAndTtls.index				     	 	 =  'Index1';
Modules.LblsAndTtls.fixedRate			     	 	 =  'Fixed Rate1';
Modules.LblsAndTtls.luInd				     	 	 =  'L/U Ind1';
Modules.LblsAndTtls.tariffCurrCd		     	 	 =  'Tariff Currency Code1';
Modules.LblsAndTtls.composite			     	 	 =  'Composite1';
Modules.LblsAndTtls.nonTaxable			     	 	 =  'Non Taxable1';
Modules.LblsAndTtls.priority			     	 	 =  'Priority1';



/*********************************************************************************************/
//CUSTOMER RATE QUERY SERVICE CODE SCREEN LABELS : END
/*********************************************************************************************/




/*********************************************************************************************/
//EVENT STATUS QUERY SCREEN LABELS : BEGIN
/*********************************************************************************************/

Modules.LblsAndTtls.eventLoadRef		         =	'Event/Load Reference1';
Modules.LblsAndTtls.originLocation		         =	'Origin Location1';
Modules.LblsAndTtls.tenderRqstDt		         =	'Tender/Request Date1';
Modules.LblsAndTtls.delivaryCmplDt		         =	'Delivery/Completion Date1';
Modules.LblsAndTtls.storageQty			         =	'Storage Qty1';
Modules.LblsAndTtls.storageUom			         =	'Storage UOM1';
Modules.LblsAndTtls.previousChrgQty		         =	'Previous Charge Qty1';
Modules.LblsAndTtls.prevChrgUom			         =	'Previous Charge UOM1';
Modules.LblsAndTtls.workOrderNumber		         =	'Work Order Number1';
Modules.LblsAndTtls.copyBtnTtl			         =	'Copy1';
Modules.LblsAndTtls.pasteBtnTtl			         =	'Paste1';

Modules.LblsAndTtls.tenderRequestDt				 =  'Tender/Rqst Date1';
Modules.LblsAndTtls.delivaryCmplDate		     =	'Dlvry/Cmpltn Date1';
Modules.LblsAndTtls.cstmrSalesRgn			     =	'Customer Sales Rgn1';
Modules.LblsAndTtls.prevChrgQty				     =	'Prev Charge Qty1';
Modules.LblsAndTtls.previousChrgUom			     =	'Prev Charge UOM1';
Modules.LblsAndTtls.wrkOrdrNbr					 =  'Work Order Number1';	
Modules.LblsAndTtls.tdrRqstDt					 =  'Tdr/Rqst Dt1';	



/*********************************************************************************************/
//EVENT STATUS QUERY SCREEN LABELS : END
/*********************************************************************************************/












/*********************************************************************************************/
//  CUSTOMER INVOICE ENTRY SCREEN LABELS : BEGIN
/*********************************************************************************************/
Modules.LblsAndTtls.cstmrInveEntryTtl				    =	'Customer Invoice Entry1';
Modules.LblsAndTtls.finalizeActionTtl					= 	'Finalize1';
Modules.LblsAndTtls.rejectActionTtl						=	'Reject1';
Modules.LblsAndTtls.copyInvioceActionTtl				= 	'Copy Invoice1';
Modules.LblsAndTtls.viewInvoiceActionTtl				=	'View Invoice1';
Modules.LblsAndTtls.viewBackupActionTtl					= 	'View Backup1';
Modules.LblsAndTtls.invoiceNumberGP						= 	'Invoice Number1';
Modules.LblsAndTtls.invoiceRefNumberGP					= 	'Reference Invoice Number1';
Modules.LblsAndTtls.invoiceDateGP						= 	'Invoice Date1';
Modules.LblsAndTtls.invoiceDueDateGP					= 	'Invoice Due Date1';
Modules.LblsAndTtls.currencyGP							= 	'Currency1';
Modules.LblsAndTtls.profitLossCentreGP					= 	'Profit/Loss Centre1';
Modules.LblsAndTtls.printTemplateGP						= 	'Print Template1';
Modules.LblsAndTtls.statusGP							= 	'Status1';
Modules.LblsAndTtls.remarksGP							= 	'Remarks1';
Modules.LblsAndTtls.docTypeGP							= 	'Document Type1';
Modules.LblsAndTtls.invcTypeGP							= 	'Invoice Type1';
Modules.LblsAndTtls.paymentDtlsGP						= 	'Payment Details1';
Modules.LblsAndTtls.partyGP								= 	'Party1';
Modules.LblsAndTtls.nameGP								= 	'Name1';
Modules.LblsAndTtls.addLane1GP							= 	'Address Line 11';
Modules.LblsAndTtls.addLane2GP							= 	'Address Line 21';
Modules.LblsAndTtls.cityGP								= 	'City1';
Modules.LblsAndTtls.stateProvGP							= 	'State/Prov.1';
Modules.LblsAndTtls.countryGP							= 	'Country1';
Modules.LblsAndTtls.zipPostalCdGP						= 	'Zip/Postal Code1';
Modules.LblsAndTtls.srvCodePG							= 	'Service Code1';
Modules.LblsAndTtls.srvDescPG							= 	'Service Description1';
Modules.LblsAndTtls.srvcGrpPG							= 	'Service Group1';
Modules.LblsAndTtls.evntLdRefPG							= 	'Event/Load Reference1';
Modules.LblsAndTtls.unitIdPG							= 	'Unit Id1';
Modules.LblsAndTtls.convncIdPG							= 	'Conveyance Id1';
Modules.LblsAndTtls.convncTypePG						= 	'Conveyance Type1';
Modules.LblsAndTtls.convncNmPG							= 	'Conveyance Name1';
Modules.LblsAndTtls.shipngRefNoPG						= 	'Shipping Ref.No.1';
Modules.LblsAndTtls.transptCdPG							= 	'Transport Code1';
Modules.LblsAndTtls.makeCdPG							= 	'Make Code1';
Modules.LblsAndTtls.modelCdPG							= 	'Model Code1';
Modules.LblsAndTtls.modelGrpPG							= 	'Model Group1';
Modules.LblsAndTtls.modelYearPG							= 	'Model Year1';
Modules.LblsAndTtls.trnsptModePG						= 	'Transport Mode1';
Modules.LblsAndTtls.rateTierPG							= 	'Rate Tier1';
Modules.LblsAndTtls.wrkOrderPG							= 	'Work Order1';
Modules.LblsAndTtls.partIdPG							= 	'Part ID1';
Modules.LblsAndTtls.orgnLocPG							= 	'Origin/Location1';
Modules.LblsAndTtls.orgnAdd1PG							= 	'Origin Address 11';
Modules.LblsAndTtls.orgnAdd2PG							= 	'Origin Address 21';
Modules.LblsAndTtls.orgnLocCtyPG						= 	'Origin/Location City1';
Modules.LblsAndTtls.orgnLocStPPG						= 	'Origin/Location State/Prov.1';
Modules.LblsAndTtls.orgnZipPostalCdPG					= 	'Origin Zip/Postal Code1';
Modules.LblsAndTtls.destCdPG							= 	'Destination Code1';
Modules.LblsAndTtls.destAdd1PG							= 	'Destination Address 11';
Modules.LblsAndTtls.destAdd2PG							= 	'Destination Address 21';
Modules.LblsAndTtls.destCityPG							= 	'Destination City1';
Modules.LblsAndTtls.destStateProvPG						= 	'Destination State/Prov.1';
Modules.LblsAndTtls.destZipPostalCdPG					= 	'Destination Zip/Postal Code1';
Modules.LblsAndTtls.tndrReqDtPG							= 	'Tender/Request Date1';
Modules.LblsAndTtls.shipntDtPG							= 	'Shipment Date1';
Modules.LblsAndTtls.delCmpltDtPG						= 	'Delivery/Completion Date1';
Modules.LblsAndTtls.origOrgPG							= 	'Original Origin1';
Modules.LblsAndTtls.finalDestPG							= 	'Final Destination1';
Modules.LblsAndTtls.dist2DestPG							= 	'Distance To Destination1';
Modules.LblsAndTtls.valPG								= 	'Value1';
Modules.LblsAndTtls.UomPG								= 	'UOM1';
Modules.LblsAndTtls.ratingDestPG						= 	'Rating Destination1';
Modules.LblsAndTtls.dist2RtngDestPG						= 	'Distance To Rating Destination1';
Modules.LblsAndTtls.minNumPG							= 	'Minimum Number1';
Modules.LblsAndTtls.prftLossCentPG						= 	'Profit/Loss Center1';
Modules.LblsAndTtls.custSlsRgnPG						= 	'Customer Sales Region1';
Modules.LblsAndTtls.shmntTypePG							= 	'Shipment Type1';
Modules.LblsAndTtls.ordrTypPG							= 	'Order Type1';
Modules.LblsAndTtls.abnrmMvTypePG						= 	'Abnormal Move Type1';
Modules.LblsAndTtls.dlrCdPG								= 	'Dealer Code1';
Modules.LblsAndTtls.suplrCdPG							= 	'Supplier Code1';
Modules.LblsAndTtls.consolIdPG							= 	'Consolidation Id1';
Modules.LblsAndTtls.consolTypePG						= 	'Consolidation Type1';
Modules.LblsAndTtls.uom1PG								= 	'UOM 11';
Modules.LblsAndTtls.uom2PG								= 	'UOM 21';
Modules.LblsAndTtls.qntty1PG							= 	'Quantity 11';
Modules.LblsAndTtls.qntty2PG							= 	'Quantity 21';
Modules.LblsAndTtls.rtbsisPG							= 	'Rate Basis1';
Modules.LblsAndTtls.ratePG								= 	'Rate1';
Modules.LblsAndTtls.srvcAmtPG							= 	'Service Amount1';
Modules.LblsAndTtls.taxTypChG							= 	'Tax Type1';
Modules.LblsAndTtls.taxPercntChG						= 	'Tax Percentage1';
Modules.LblsAndTtls.taxAmtChG							= 	'Tax Amount1';
Modules.LblsAndTtls.custInvcEntryTotSrvcAmt				= 	'Total Service Amount1';
Modules.LblsAndTtls.custInvcEntryTotTaxAmt				= 	'Total Tax Amount1';
Modules.LblsAndTtls.custInvcEntryTotAmt					= 	'Total Amount1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormTtl			= 	Modules.LblsAndTtls.cstmrInveEntryTtl;
Modules.LblsAndTtls.cstmrInveEntryPopUpFormInvoiceTlt	=	'Invoice1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormCrdtNote		= 	'Credit Note1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormDbtNote		=	'Debit Note1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormDocTypeTtl	= 	'Document Type1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormInvcTypeTtl	= 	'Invoice Type1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormActual		=	'Actual1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormAcrual		=	'Acrual1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormPaymentDtlsTtl 	=	'Payment Details1';
Modules.LblsAndTtls.cstmrInveEntryPopUpFormCurrencyTtl 		= 	'Currency1';
/*********************************************************************************************/
//CUSTOMER INVOICE ENTRY SCREEN LABELS : END
/*********************************************************************************************/




Modules.LblsAndTtls.cstmrSrvGrpConfigurationGridTlt =       'Customer ServiceGroup Grid Configuration1';

Modules.LblsAndTtls.cstmrSrvTypeConfigurationGridTlt=		'Customer Service Type Code Grid Configuration1';

/*********************************************************************************************/
//Dashboard SCREEN LABELS : START
/*********************************************************************************************/

Modules.LblsAndTtls.InvLineItmAgngOnDueDate =       'Invoice Line Item Aging On Due Date1';
Modules.LblsAndTtls.pastDueTlt =       'Past Due1';
Modules.LblsAndTtls.amountTlt =       'Amount($)1';
Modules.LblsAndTtls.dueIn0To5DaysTlt  =       'Due in 0-5 Days1';
Modules.LblsAndTtls.dueIn6To15DaysTlt  =       'Due in 6-15 Days1';
Modules.LblsAndTtls.dueIn16To30DaysTlt  =       'Due in 16-30 Days1';
Modules.LblsAndTtls.dueInGrtrThan30DaysTlt  =       'Due in >30 Days1';
Modules.LblsAndTtls.countTlt  =       'Count1';
Modules.LblsAndTtls.cstmrSrvTypeConfigurationGridTlt=		'Customer Service Type Code Grid Configuration1';


/***********************************************************************/
//#CUSTOMER_RATE_QUERY
/***********************************************************************/

Modules.contract.customer_rate_query.labels.formTitle	=	'Customer Rate Query1';
Modules.contract.customer_rate_query.labels.customer	=	'Customer1';
Modules.contract.customer_rate_query.labels.customerCode=	'Customer Code1';
Modules.contract.customer_rate_query.labels.companyCode =	'Company Code1';
Modules.contract.customer_rate_query.labels.name		=	'Name1';
Modules.contract.customer_rate_query.labels.customerName=	'Customer Name1';
Modules.contract.customer_rate_query.labels.contractId	=	'Contract ID1';
Modules.contract.customer_rate_query.labels.fromDate	=	'From Date'	;
Modules.contract.customer_rate_query.labels.toDate		=	'To Date1';
Modules.contract.customer_rate_query.labels.validFrom	=	'Valid From1';
Modules.contract.customer_rate_query.labels.validTo		=	'Valid To1';







/***********************************************************************/
//#GENERAL_MASTERS
/***********************************************************************/

Modules.Masters.General_Master.labels.code = 'Code1';
Modules.Masters.General_Master.labels.description = 'Description1';
Modules.Masters.General_Master.labels.cargoClass = 'Class1';
Modules.Masters.General_Master.labels.printerPath ='Path1';

/********* Customer Invoice Status ********/
Modules.LblsAndTtls.customerInvoiceFrmDateId='Invoice From Date1';
Modules.LblsAndTtls.customerInvoiceToDateId='Invoice To Date1';
Modules.LblsAndTtls.customerInvoiceActualTlt = 'Actual1';
Modules.LblsAndTtls.customerInvoiceAccrualTlt = 'Accrual1';
Modules.LblsAndTtls.customerInvoiceTypeTlt = 'Invoice Type1';
Modules.LblsAndTtls.customerInvoiceProformaEvntTlt = 'Proforma1';
Modules.LblsAndTtls.customerInvoiceRejectedEvntTlt = 'Rejected1';
Modules.LblsAndTtls.customerInvoiceFinalEvntTlt = 'Final1';
Modules.LblsAndTtls.customerInvoicePaidEvntTlt = 'Paid1';
Modules.LblsAndTtls.customerInvoiceStatusTlt = 'Status1';
Modules.LblsAndTtls.customerInvoiceEvntTlt = 'Invoice1';
Modules.LblsAndTtls.customerInvoiceCreditEvntTlt = 'Credit1';
Modules.LblsAndTtls.customerInvoiceDebitEvntTlt = 'Debit1';
Modules.LblsAndTtls.customerInvoiceDocumentTypeTlt = 'Document Type1';
Modules.LblsAndTtls.customerInvoiceNo = 'Invoice No1';
Modules.LblsAndTtls.customerInvoiceNoTlt = 'Invoice Number1';
Modules.LblsAndTtls.customerInvoiceNoDateTlt = 'Invoice Date1';
Modules.LblsAndTtls.customerInvoiceNoAmountTlt = 'Invoice Amount1';
Modules.LblsAndTtls.customerInvoiceNoPaidAmountTlt = 'Paid Amount1';
Modules.LblsAndTtls.customerInvoiceNoCurrencyTlt = 'Currency1';
Modules.LblsAndTtls.customerInvoiceNoDueDateTlt = 'Due Date1';
Modules.LblsAndTtls.customerInvoiceNoLstPaymentDateTlt = 'Last Payment Date1';
Modules.LblsAndTtls.customerInvoiceNoInvoiceStatusTlt = 'Invoice Status1';
Modules.LblsAndTtls.customerInvoicePrinterTtl = 'Invoice Printer1';
Modules.LblsAndTtls.customerInvoiceBackUpPrinter = 'Back-Up Printer1';
Modules.LblsAndTtls.customerInvoiceCopiesTtl = 'Invoice Copies1';
Modules.LblsAndTtls.customerBackUpCopiesTtl = 'Back Up Copies1';
Modules.LblsAndTtls.customerCCMailTtl = 'CC-Mail ID1';
Modules.LblsAndTtls.customerInvoiceViewTlt = 'View1';
Modules.LblsAndTtls.customerInvoiceEmailTlt = 'Email1';
Modules.LblsAndTtls.customerInvoicePrintTlt = 'Print1';
Modules.LblsAndTtls.customerInvoiceBackUpTlt = 'Back Up1';

/***********************************************************************/
//#TRANSPORT_MODE_MASTER
/***********************************************************************/
Modules.Masters.Transport_Mode_Master.labels.mode = 'Mode1';
Modules.Masters.Transport_Mode_Master.labels.description = 'Description1';

/***********************************************************************/
//#CONVEYANCE_TYPE_MASTER
/***********************************************************************/
Modules.Masters.Conveyanca_Type_Master.labels.type ='Type1';
Modules.Masters.Conveyanca_Type_Master.labels.description = 'Description1';

/***********************************************************************/
//#PROFIT_LOSS_CENTRE_MASTER
/***********************************************************************/
Modules.Masters.Profit_Loss_Centre_Master.labels.centre = 'Centre1';
Modules.Masters.Profit_Loss_Centre_Master.labels.name = 'Name1';

/***********************************************************************/
//#COUNTRY_MASTER
/***********************************************************************/
Modules.Masters.Country_Master.labels.code = 'Code1';
Modules.Masters.Country_Master.labels.name = 'Name1';
Modules.Masters.Country_Master.labels.regionCode = 'Region Code1';

/***********************************************************************/
//#SERVICE_CODE_GLMAPPER
/***********************************************************************/
Modules.Masters.Service_Code_GlMapper.labels.serviceCode = 'Service Code1';
Modules.Masters.Service_Code_GlMapper.labels.transportMode = 'Transport Mode1';
Modules.Masters.Service_Code_GlMapper.labels.glCodeRevenueTransactions = 'GL Code(Revenue Transactions)1';
Modules.Masters.Service_Code_GlMapper.labels.glCodeExpenseTransactions = 'GL Code(Expense Transactions)1';

/***********************************************************************/
//#COMPANY_TAXTYPE_MAPPER
/***********************************************************************/
Modules.Masters.Company_TaxType_Mapper.labels.taxType = 'Tax Type1';
Modules.Masters.Company_TaxType_Mapper.labels.glCodeRevenueTransactions = 'GL Code(Revenue Transactions)1';
Modules.Masters.Company_TaxType_Mapper.labels.glCodeExpenseTransactions = 'GL Code(Expense Transactions)1';

/***********************************************************************/
//#TAXTYPE_MASTER
/***********************************************************************/
Modules.Masters.TaxType_Master.labels.type = 'Type1';
Modules.Masters.TaxType_Master.labels.description = 'Description1';
Modules.Masters.TaxType_Master.labels.serviceAmount = 'Service Amount1';
Modules.Masters.TaxType_Master.labels.taxType = 'Tax Type1';

/***********************************************************************/
//# COMMON SCREEN LABELS 
/***********************************************************************/
Modules.Common_Operation.labels.clear = 'Clear1';
Modules.Common_Operation.labels.retrieve = 'Retrieve1';
Modules.Common_Operation.labels.saveSearchCriteria = 'Save Search Criteria1';
Modules.Common_Operation.labels.retrieveSearchCriteria = 'Retrieve Search Criteria1';
Modules.Common_Operation.labels.add = 'Add1';
Modules.Common_Operation.labels.del = 'Delete1';
Modules.Common_Operation.labels.copy = 'Copy1';
Modules.Common_Operation.labels.paste = 'Paste1';
Modules.Common_Operation.labels.save = 'Save1';
Modules.Common_Operation.labels.saveGridState = 'Save Grid State1';
Modules.Common_Operation.labels.resetGridState = 'Reset Grid State1';
Modules.Common_Operation.labels.exportToExcel = 'Export To excel1';
Modules.Common_Operation.labels.exportToPDF = 'Export To PDF1';
Modules.Common_Operation.labels.importFromExcel = 'Import From Excel1';
Modules.Common_Operation.labels.queryParameters = 'Query Parameters1';
Modules.Common_Operation.labels.recordView = 'Record View1';

/***********************************************************************/
//#MASTER_TITLES
/***********************************************************************/
Modules.Master_Titles.labels.profitLossCentreMaster = 'Profit/Loss Centre Master1';
Modules.Master_Titles.labels.taxTypeMaster = 'Tax Type Master1';
Modules.Master_Titles.labels.companyTaxTypeMapper = 'Company Tax Type Mapper1';
Modules.Master_Titles.labels.glCodeMaster = 'GL Code Master1';
Modules.Master_Titles.labels.serviceCodeGlMapper = 'Service Code GL Mapper1';
Modules.Master_Titles.labels.invoicePrintTemplateMaster = 'Invoice Print Template Master1';
Modules.Master_Titles.labels.rateTierMaster = 'Rate Tier Master1';
Modules.Master_Titles.labels.conveyanceTypeMaster = 'Conveyance Type Master1';
Modules.Master_Titles.labels.transportModeMaster = 'Transport Mode Master1';
Modules.Master_Titles.labels.partMaster = 'Part Master1';
Modules.Master_Titles.labels.modelGroupMaster = 'Model Group Master1';
Modules.Master_Titles.labels.countryMaster = 'Country Master1';
Modules.Master_Titles.labels.consolidationTypeMaster ='Consolidation Type Master1';
Modules.Master_Titles.labels.stateProvinceMaster = 'State/Province Master1';
Modules.Master_Titles.labels.transportModeMapper = 'Transport Mode Mapper1';
Modules.Master_Titles.labels.makeMaster = 'Make Master1';

Modules.Master_Titles.labels.freightTermMaster = 'Freight Term Master1';
Modules.Master_Titles.labels.currencyMapper = 'Currency Mapper1';
Modules.Master_Titles.labels.rateBasisMapper = 'Rate Basis Mapper1';
Modules.Master_Titles.labels.uomMapper = 'UOM Mapper1';
Modules.Master_Titles.labels.portTypeMaster = 'Port Type Master1';
Modules.Master_Titles.labels.cargoTypeMaster = 'Cargo Type Master1';
Modules.Master_Titles.labels.cargoClassMaster = 'Cargo Class Master1';
Modules.Master_Titles.labels.companyMapper = 'Company Mapper1';
Modules.Master_Titles.labels.regionMaster = 'Region Master1';
Modules.Master_Titles.labels.vesselMaster = 'Vessel Master1';
Modules.Master_Titles.labels.holidayMaster = 'Holiday Master1';
Modules.Master_Titles.labels.serviceTypeMaster = 'Service Type Master1';
Modules.Master_Titles.labels.exceptionTypeMaster = 'Exception Type Master1';
Modules.Master_Titles.labels.printerMaster ='Printer Master1';
Modules.Master_Titles.labels.orderTypeMaster ='Order Type Master1';

/***********************************************************************/
//#CUSTOMER_MASTER
/***********************************************************************/

Modules.contract.customer_master.labels.origin			='Origin/Location1';
Modules.contract.customer_master.labels.destination		='Destination1';
Modules.contract.customer_master.labels.statusDate		='Status Date1';
Modules.contract.customer_master.labels.uom				='UOM1';
Modules.contract.customer_master.labels.roundingCriteria='Rounding Criteria1';
Modules.contract.customer_master.labels.value				='Value1';
Modules.contract.customer_master.labels.minimumValue		='Minimum Value1';
Modules.contract.customer_master.labels.customerCode='Customer1';
Modules.contract.customer_master.labels.customerName='Customer Name1';
Modules.contract.customer_master.labels.defaultCurrency='Default Currency1';
Modules.contract.customer_master.labels.taxRefNo='Tax Ref No1';
Modules.contract.customer_master.labels.address1='Address 11';
Modules.contract.customer_master.labels.address2='Address 21';
Modules.contract.customer_master.labels.city='City1';
Modules.contract.customer_master.labels.country='Country1';
Modules.contract.customer_master.labels.postalCode='ZIP/Postal Code1';
Modules.contract.customer_master.labels.telephoneNo='Telephone No1';
Modules.contract.customer_master.labels.faxNumber='Fax Number1';
Modules.contract.customer_master.labels.mobileNumber='Mobile Number1';
Modules.contract.customer_master.labels.eMailAddress='E-Mail Address1';
Modules.contract.customer_master.labels.contactPersonName1='Contact Person Name(1)1';
Modules.contract.customer_master.labels.contactPersonName2='Contact Person Name(2)1';
Modules.contract.customer_master.labels.subLedgerCode='Sub Ledger Code1';
Modules.contract.customer_master.labels.sendEstmARMsgFlg='Send Customer Accrual to CODA1';
Modules.contract.customer_master.labels.waitForAPAprroveFlg='Download A/R After A/P1';
Modules.contract.customer_master.labels.autoApproveApplnAdviceFlg='Auto Approve In Application Advice1';
Modules.contract.customer_master.labels.sendCustInvoiceMsgFlg='Send Customer Invoice Message1';
Modules.contract.customer_master.labels.ratingDestinationApplicableFlg='Rating Destination Applicable1';
Modules.contract.customer_master.labels.financialCustomer='Financial ID1';
Modules.contract.customer_master.labels.financialContractNo='Financial Contract No1';
Modules.contract.customer_master.labels.remarks1='Note 11';
Modules.contract.customer_master.labels.remarks2='Note 21';
Modules.contract.customer_master.labels.customerDetails='Customer Details1';
Modules.contract.customer_master.labels.serviceType='Service Type1';
Modules.contract.customer_master.labels.serviceCode='Service Code1';
Modules.contract.customer_master.labels.origin='Origin/Location1';
Modules.contract.customer_master.labels.destination='Destination1';
Modules.contract.customer_master.labels.statusDate='Status Date1';
Modules.contract.customer_master.labels.supplierCode='Supplier Code1';
Modules.contract.customer_master.labels.unitOfMeasure='UOM1';
Modules.contract.customer_master.labels.roundingType='Rounding Criteria1';
Modules.contract.customer_master.labels.roundingValue='Value1';
Modules.contract.customer_master.labels.minimumDistanceValue='Minimum Value1';
Modules.contract.customer_master.labels.currencyCode='Currency Code1';

Modules.Customer.CustomerRateVerificatoin.labels.OriginStateProv='Origin State/Prov1'; 
Modules.Customer.CustomerRateVerificatoin.labels.consolidationType='ConsldtTypeCode1';
Modules.contract.customer_master.labels.defaultSupplierWinTtl='Default Supplier Grid Record1';
Modules.contract.customer_master.labels.rateRoundingWinTtl = 'Rate Criteria Grid Record1';
Modules.contract.customer_master.labels.distanceRoundingWinTtl = 'Distance Rounding Grid Record1';
Modules.contract.customer_master.labels.statusDateWinTtl = 'Contract Identification Grid Record1';
Modules.contract.customer_master.labels.customerMasterWinTtl = 'Customer Master Grid Record1';
Modules.contract.customer_master.labels.financialDetailsTtl='Financial Details1';
Modules.contract.customer_master.labels.ratingDetailsTtl='Rating Details1';
/********************Ocean Customer Event Status Summary********************/
Modules.LblsAndTtls.custEventStatusSummaryParentTabpanelTtl = 'Customer Event Status Summary1';
Modules.LblsAndTtls.pop='POP1';
Modules.LblsAndTtls.freightTerm='Freight Term1';
Modules.LblsAndTtls.vessel='Vessel1';
Modules.LblsAndTtls.POR='POR1';
Modules.LblsAndTtls.PFD='PFD1';
Modules.LblsAndTtls.voyage='Voyage1';
Modules.LblsAndTtls.blNum='BL Number1';
Modules.LblsAndTtls.party='Party1';
Modules.LblsAndTtls.chargCode='Charge Code1';
Modules.LblsAndTtls.pol='POC1';
Modules.LblsAndTtls.pod='POD1';
Modules.LblsAndTtls.count='Count1';
Modules.LblsAndTtls.totQnty='Total Quantity1';
Modules.LblsAndTtls.servAmntManFstCrncy='Service Amount Manifest Currency1';
Modules.LblsAndTtls.manifstCurncyCode='Manifest Currency Code1';
Modules.LblsAndTtls.servcAmntInvcCurncy='Service Amount Invc Currency1';
Modules.LblsAndTtls.invcCurncyCode='Invoice Currency Code1';
Modules.LblsAndTtls.servcAmntUSDCurrency='ServiceAmount USD1';
Modules.LblsAndTtls.sailingDate='Sailing Date1';
Modules.LblsAndTtls.bLCompletionDatePrepaid='Prepaid1';//BL completion Date (Prepaid)
Modules.LblsAndTtls.bLCompletionDateCollect='Collect1';//BL completion Date (Collect)
Modules.LblsAndTtls.supplierStatus='Supplier Status1';
Modules.LblsAndTtls.customerStatus='Customer Status1';

/**** Ocean Supplier Rate Query Service Code****/
Modules.LblsAndTtls.oceanSupplierRateQueryServiceParentTabpanelTtl				= 'Supplier Rate Query Service Code1';
Modules.LblsAndTtls.supplier													= 'Supplier1';
Modules.LblsAndTtls.supName														= 'Supplier Name1';
Modules.LblsAndTtls.startDate													= 'Start Date1';
Modules.LblsAndTtls.endDate														= 'End Date1';
Modules.LblsAndTtls.contractid													= 'Contract Id1';
Modules.LblsAndTtls.chargeCode													= 'Charge Code1';
Modules.LblsAndTtls.party														= 'Party1';
Modules.LblsAndTtls.validFromDt													= 'Valid From Date1';
Modules.LblsAndTtls.validToDt													= 'Valid To Date1';
Modules.LblsAndTtls.pol															= 'POL1';
Modules.LblsAndTtls.pod															= 'POD1';
Modules.LblsAndTtls.cargoType													= 'Cargo Type1';
Modules.LblsAndTtls.cargoClass													= 'Cargo Class1';
Modules.LblsAndTtls.makeCode													= 'Make Code1';
Modules.LblsAndTtls.model														= 'Model1';
Modules.LblsAndTtls.polCity														= 'POL City1';
Modules.LblsAndTtls.polStProv													= 'POL State1';
Modules.LblsAndTtls.polCntry													= 'POL Country1';
Modules.LblsAndTtls.podCity														= 'POD City1';
Modules.LblsAndTtls.podStProv													= 'POD State1';
Modules.LblsAndTtls.podCntry													= 'POD Country1';
Modules.LblsAndTtls.por															= 'POR1';
Modules.LblsAndTtls.pfd															= 'PFD1';
Modules.LblsAndTtls.steering													= 'Steering1';
Modules.LblsAndTtls.hazardous													= 'Hazardous1';
Modules.LblsAndTtls.handlindInd													= 'Handling Indicator1';
Modules.LblsAndTtls.transferGear												= 'Transfer Gear1';
Modules.LblsAndTtls.notChargeable												= 'Not Chargeable1';
Modules.LblsAndTtls.factrVal													= 'Factor value1';
Modules.LblsAndTtls.factType													= 'Factor Type1';
Modules.LblsAndTtls.factRate													= 'Factor Rate1';
Modules.LblsAndTtls.fixdRate													= 'Fixed Rate1';
Modules.LblsAndTtls.tarrifRate													= 'Tariff Rate1';
Modules.LblsAndTtls.luInd														= 'L/U Ind1';
Modules.LblsAndTtls.tarrifCurncyInd												= 'Tariff Currency Code1';
Modules.LblsAndTtls.priority													= 'Priority1';
Modules.LblsAndTtls.seqNo														= 'Seq No1';
//Modules.LblsAndTtls.															= '1';
//Modules.LblsAndTtls.															= '1';


/*** OCEAN - Customer Invoice Setup Screen ***/
	
/******************** Ocean Customer Service Group Setup ***************************/

Modules.contract.customer.oceanCstmrSrvGrpSetup.oceanCstmtSrvGrpSetupFormTtl='Customer Service Group Setup1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.popLabel='POP1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.popNameLabel='POP Name1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.partyLabel='Customer1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.partyNameLabel='Customer Name1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceGroupTlt='Service Group1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceGrpDesc='Service Group Desc1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.serviceType='Service Type1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.chargeCodeTlt='Service Code1';
Modules.contract.customer.oceanCstmrSrvGrpSetup.chargeCodeDescTlt='Service Code Desc1';
Modules.contract.customer.oceanCstmrSrvGrpConfigurationGridTlt='Customer Service Group Setup1';
Modules.contract.customer.oceancstmrSrvTypeConfigurationGridTlt='Customer Service Group Setup1';



Modules.Customer.CustomerRateVerificatoin.labels.OriginStateProv='Origin State/Prov1';
Modules.Customer.CustomerRateVerificatoin.labels.consolidationType='ConsldtTypeCode1';


/*** Supplier Invoice Status Labels and Titles***/
	
Modules.SpplrInvc.SupplrInvcSts.label.invoiceNo						= 'Invoice No1';
Modules.SpplrInvc.SupplrInvcSts.label.invcFrmDate					= 'Invoice From Date1';
Modules.SpplrInvc.SupplrInvcSts.label.invcToDate					= 'Invoice To Date1';
Modules.SpplrInvc.SupplrInvcSts.label.evntLdRef  					= 'Event/Load Reference1';
Modules.SpplrInvc.SupplrInvcSts.label.cnvynce  					    = 'Conveyence Id1';
Modules.SpplrInvc.SupplrInvcSts.label.shpRef     					= 'Shipping Reference1';
Modules.SpplrInvc.SupplrInvcSts.label.proforma     					= 'Proforma1';
Modules.SpplrInvc.SupplrInvcSts.label.rdyForRecnltn     			= 'Ready For Reconciliation1';
Modules.SpplrInvc.SupplrInvcSts.label.undrInvgt     			    = 'Under Investigation1';
Modules.SpplrInvc.SupplrInvcSts.label.apprvd         			    = 'Approved1';
Modules.SpplrInvc.SupplrInvcSts.label.rejected         			    = 'Rejected1';
Modules.SpplrInvc.SupplrInvcSts.label.paid          			    = 'Paid1';
Modules.SpplrInvc.SupplrInvcSts.label.invoice          			    = 'Invoice1';
Modules.SpplrInvc.SupplrInvcSts.label.credit          			    = 'Credit1';
Modules.SpplrInvc.SupplrInvcSts.label.debit          			    = 'Debit1';
Modules.SpplrInvc.SupplrInvcSts.label.pdf          			        = 'PDF1';
Modules.SpplrInvc.SupplrInvcSts.label.excel          			    = 'Excel1';
Modules.SpplrInvc.SupplrInvcSts.label.ascending          			= 'Ascending1';
Modules.SpplrInvc.SupplrInvcSts.label.descending          			= 'Descending1';
Modules.SpplrInvc.SupplrInvcSts.label.status          			    = 'Status1';
Modules.SpplrInvc.SupplrInvcSts.label.docType          			    = 'Document Type1';
Modules.SpplrInvc.SupplrInvcSts.label.rptoutput          			= 'Report Output1';
Modules.SpplrInvc.SupplrInvcSts.label.sortOptns          			= 'Sort Options1';
//Grid Labels
Modules.SpplrInvc.SupplrInvcSts.label.supplier					    = 'Supplier1';
Modules.SpplrInvc.SupplrInvcSts.label.invcNo                        = 'Invoice Number1';
Modules.SpplrInvc.SupplrInvcSts.label.invcDate                      = 'Invoice Date1';
Modules.SpplrInvc.SupplrInvcSts.label.docType					    = 'Document Type1';
Modules.SpplrInvc.SupplrInvcSts.label.invcAmt                       = 'Invoice Amount1';
Modules.SpplrInvc.SupplrInvcSts.label.apprvdAmt                     = 'Approved Amount1';
Modules.SpplrInvc.SupplrInvcSts.label.paidAmt                       = 'Paid Amount1';
Modules.SpplrInvc.SupplrInvcSts.label.currency                      = 'Currency1';
Modules.SpplrInvc.SupplrInvcSts.label.dueDate                       = 'Due Date1';
Modules.SpplrInvc.SupplrInvcSts.label.lastPmtDate                   = 'Last Payment Date1';
Modules.SpplrInvc.SupplrInvcSts.label.invcSts                       = 'Invoice Status1';
Modules.SpplrInvc.SupplrInvcSts.label.suppledit                     = 'Supplier Record1';

/*** Supplier Invoice Status Labels and Titles***/


/* START of Ocean Customer Invoice Generation Screen */

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.panelTitle='Generate Invoice1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.clear='Clear1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.retrieve='Retrieve1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.generate='Generate1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.keySearch='Key Search1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.advanceSearch='Advance Search1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.formTitle='Generate Invoice1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blNumber='BL Number1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.party='Party1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.carrier='Carrier1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.chargeCode='Charge Code1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pol='POL1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pod='POD1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pop='POP1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.por='POR1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pfd='PFD1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.freightTerms='Freight Terms1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.srvcGrpCd='Service Group Code1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipRefNbr='Ship Ref Nbr1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.shipRefNumber='Shipping Reference Number1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.sailFmDate='Sailing From Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.sailToDate='Sailing To Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCmplFmDate='BL Cmpl Fm Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCmplToDate='BL Cmpl To Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.localCurrency='Local Currency1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.voyage='Voyage1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.vessel='Vessel1';

Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.blCompletionDate='BL Completion Date1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.manifestCurncy='Manifest Currency1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.manifestAmount='Manifest Amount1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcCurrency='Invoice Currency1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.invcAmount='Invoice Amount1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.usdEqvlntAmount='USD Equivalent Amount1';
Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.gridPopWinTitle='Generate Invoice Grid Record1';

/* END of Ocean Customer Invoice Generation Screen */

/* START of Ocean Customer Print Template Screen */

//Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice.labels.pop='POP1';

/* END of Ocean Customer Print Template Screen */



/********************************************************************************/
//#EventRatingQuery_Ocean
/**********************************************************************************/
Modules.ocean.operations.event_details.event_rating_query.labels.formTitle = 'Event Rating Query1';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQuerySupplierPopup = 'Event Rating Query Supplier Details1';
Modules.ocean.operations.event_details.event_rating_query.labels.POP = 'POP1';
Modules.ocean.operations.event_details.event_rating_query.labels.bLNumber = 'BL Number1';
Modules.ocean.operations.event_details.event_rating_query.labels.freightTerm = 'Freight Term1';
Modules.ocean.operations.event_details.event_rating_query.labels.vessel = 'Vessel1';
Modules.ocean.operations.event_details.event_rating_query.labels.voyage = 'Voyage1';
Modules.ocean.operations.event_details.event_rating_query.labels.party = 'Party1';
Modules.ocean.operations.event_details.event_rating_query.labels.POL = 'POL1';
Modules.ocean.operations.event_details.event_rating_query.labels.POD = 'POD1';
Modules.ocean.operations.event_details.event_rating_query.labels.POR = 'POR1';
Modules.ocean.operations.event_details.event_rating_query.labels.PFD = 'PFD1';
Modules.ocean.operations.event_details.event_rating_query.labels.sailingDate = 'Sailing Date1';
//Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDatePrepaid = 'BL Completion Date (Prepaid)1';
//Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDateCollect = 'BL Completion Date (Collect)1';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDatePrepaid = 'Prepaid Date1';
Modules.ocean.operations.event_details.event_rating_query.labels.bLCompletionDateCollect = 'Collect Date1';
Modules.ocean.operations.event_details.event_rating_query.labels.customerStatus = 'Customer Status1';
Modules.ocean.operations.event_details.event_rating_query.labels.supplierStatus = 'Supplier Status1';
Modules.ocean.operations.event_details.event_rating_query.labels.deleteBtn = 'Delete1';
Modules.ocean.operations.event_details.event_rating_query.labels.copyBtn = 'Copy1';
Modules.ocean.operations.event_details.event_rating_query.labels.saveBtn = 'Save1';
Modules.ocean.operations.event_details.event_rating_query.labels.lineNumber = 'Line Number1';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoClass = 'Cargo Class1';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoType = 'Cargo Type1';
Modules.ocean.operations.event_details.event_rating_query.labels.commodityDescription = 'Commodity Description1';
Modules.ocean.operations.event_details.event_rating_query.labels.chargeCode = 'Charge Code1';
Modules.ocean.operations.event_details.event_rating_query.labels.chargeCodeDescription = 'Charge Code Description1';
Modules.ocean.operations.event_details.event_rating_query.labels.frieghtTerm = 'Frieght Term1';
Modules.ocean.operations.event_details.event_rating_query.labels.pop = 'POP1';
Modules.ocean.operations.event_details.event_rating_query.labels.popDescription = 'POP Description1';
Modules.ocean.operations.event_details.event_rating_query.labels.handlerIndication = 'Handler Indication1';
Modules.ocean.operations.event_details.event_rating_query.labels.transferGear = 'Transfer Gear1';
Modules.ocean.operations.event_details.event_rating_query.labels.SteeringLeftRight = 'Steering Left/Right1';
Modules.ocean.operations.event_details.event_rating_query.labels.hazardousYN = 'Hazardous(Y/N)1';
Modules.ocean.operations.event_details.event_rating_query.labels.lineItemQuantity = 'Line Item Quantity1';
Modules.ocean.operations.event_details.event_rating_query.labels.rate = 'Rate1';
Modules.ocean.operations.event_details.event_rating_query.labels.rateBasis = 'Rate Basis1';
Modules.ocean.operations.event_details.event_rating_query.labels.manifestCurrency = 'Manifest Currency1';
Modules.ocean.operations.event_details.event_rating_query.labels.manifestAmount = 'Manifest Amount1';
Modules.ocean.operations.event_details.event_rating_query.labels.exchangeRate = 'Exchange Rate1';
Modules.ocean.operations.event_details.event_rating_query.labels.localCurrency = 'Local Currency1';
Modules.ocean.operations.event_details.event_rating_query.labels.localAmount = 'Local Amount1';
Modules.ocean.operations.event_details.event_rating_query.labels.usdAmount = 'USD Amount1';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoId = 'Cargo Id1';
Modules.ocean.operations.event_details.event_rating_query.labels.cargoBarcode = 'Cargo Barcode1';
Modules.ocean.operations.event_details.event_rating_query.labels.make = 'Make1';
Modules.ocean.operations.event_details.event_rating_query.labels.model = 'Model1';
Modules.ocean.operations.event_details.event_rating_query.labels.modelName = 'Model Name1';
Modules.ocean.operations.event_details.event_rating_query.labels.modelYear = 'Model Year1';
Modules.ocean.operations.event_details.event_rating_query.labels.weight = 'Weight1';
Modules.ocean.operations.event_details.event_rating_query.labels.weightUOM = 'Weight UOM1';
Modules.ocean.operations.event_details.event_rating_query.labels.length = 'Length1';
Modules.ocean.operations.event_details.event_rating_query.labels.dimensionUOM = 'Dimension UOM1';
Modules.ocean.operations.event_details.event_rating_query.labels.width = 'Width1';
Modules.ocean.operations.event_details.event_rating_query.labels.height = 'Height1';
Modules.ocean.operations.event_details.event_rating_query.labels.volume = 'Volume1';
Modules.ocean.operations.event_details.event_rating_query.labels.cube = 'Cube1';
Modules.ocean.operations.event_details.event_rating_query.labels.quantity = 'quantity1';
Modules.ocean.operations.event_details.event_rating_query.labels.status = 'Status1';
Modules.ocean.operations.event_details.event_rating_query.labels.invoiceNumber = 'Invoice Number1';
Modules.ocean.operations.event_details.event_rating_query.labels.notChargeable = 'Not Chargeable1';
Modules.ocean.operations.event_details.event_rating_query.labels.glCode = 'GL Code1';
Modules.ocean.operations.event_details.event_rating_query.labels.taxAmount = 'Tax Amount1';
Modules.ocean.operations.event_details.event_rating_query.labels.serviceAmount = 'Service Amount1';
Modules.ocean.operations.event_details.event_rating_query.labels.currency = 'Currency1';
Modules.ocean.operations.event_details.event_rating_query.labels.taxPercent = 'Tax%1';
Modules.ocean.operations.event_details.event_rating_query.labels.taxType = 'Tax Type1';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQueryCargoPopup = 'Event Rating Query Cargo Details1';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQueryPopup = 'Event Rating Query View1';
Modules.ocean.operations.event_details.event_rating_query.labels.eventRatingQuerytaxWin = 'Tax Details1';



/********************************************************************************/
//#SupplierLineItemStatus_Ocean
/**********************************************************************************/

Modules.supplier_invoice.supplier_line_item_status.labels.tabParentPanelLbl = 'Supplier Line Item Status1';
Modules.supplier_invoice.supplier_line_item_status.labels.supplier = 'Supplier1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceNumber = 'Invoice Number1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceDate = 'Invoice Date1';
Modules.supplier_invoice.supplier_line_item_status.labels.serviceCode = 'Service Code1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceAmount = 'Invoice Amount1';
Modules.supplier_invoice.supplier_line_item_status.labels.approvedAmount = 'Approved Amount1';
Modules.supplier_invoice.supplier_line_item_status.labels.paidAmount = 'Paid Amount1';
Modules.supplier_invoice.supplier_line_item_status.labels.currency = 'Currency1';
Modules.supplier_invoice.supplier_line_item_status.labels.unitId = 'Unit ID1';
Modules.supplier_invoice.supplier_line_item_status.labels.loadReference = 'Load Reference1';
Modules.supplier_invoice.supplier_line_item_status.labels.conveyanceId = 'Conveyance ID1';
Modules.supplier_invoice.supplier_line_item_status.labels.partId = 'Part ID1';
Modules.supplier_invoice.supplier_line_item_status.labels.deliveryCompletionDate = 'Delivery/Completion Date1';
Modules.supplier_invoice.supplier_line_item_status.labels.dueDate = 'Due Date1';
Modules.supplier_invoice.supplier_line_item_status.labels.lastPaymentDate = 'Last Payment Date1';
//Modules.supplier_invoice.supplier_line_item_status.labels.supplier = 'Line Item Status1';
Modules.supplier_invoice.supplier_line_item_status.labels.reason = 'Reason1';
Modules.supplier_invoice.supplier_line_item_status.labels.formTitle = 'Supplier Line Item Status1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceFromDate = 'Invoice From Date1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoiceToDate = 'Invoice To Date1';
Modules.supplier_invoice.supplier_line_item_status.labels.serviceType = 'Service Type1';
Modules.supplier_invoice.supplier_line_item_status.labels.eventLoadReference = 'Event/Load Ref1';
Modules.supplier_invoice.supplier_line_item_status.labels.shippingReference = 'Shipping Ref1';
Modules.supplier_invoice.supplier_line_item_status.labels.proforma = 'Proforma1';
Modules.supplier_invoice.supplier_line_item_status.labels.readyForReconciliation = 'Ready For Reconciliation1';
Modules.supplier_invoice.supplier_line_item_status.labels.underInvestigation = 'Under Investigation1';
Modules.supplier_invoice.supplier_line_item_status.labels.reconciled = 'Reconciled1';
Modules.supplier_invoice.supplier_line_item_status.labels.approved = 'Approved1';
Modules.supplier_invoice.supplier_line_item_status.labels.rejected = 'Rejected1';
Modules.supplier_invoice.supplier_line_item_status.labels.paid = 'Paid1';
Modules.supplier_invoice.supplier_line_item_status.labels.invoice = 'Invoice1';
Modules.supplier_invoice.supplier_line_item_status.labels.creditNote = 'Credit Note1';
Modules.supplier_invoice.supplier_line_item_status.labels.debitNote = 'Debit Note1';
Modules.supplier_invoice.supplier_line_item_status.labels.lineItemStatus = 'Line Item Status1';
Modules.supplier_invoice.supplier_line_item_status.labels.deleteBtn = 'Delete1';
Modules.supplier_invoice.supplier_line_item_status.labels.supplierLineItemStatusPopWin = 'Supplier Line Item Status Details1';







/*** OCEAN - Customer Invoice Setup Screen ***/
Modules.Ocean.CustInvcSetup.labels.formtitle 						= 'Customer Invoice Setup1';
Modules.Ocean.CustInvcSetup.labels.consolfrightTerms 						= 'Fright Terms1';
Modules.Ocean.CustInvcSetup.labels.srvctype 						= 'Service Type1';
Modules.Ocean.CustInvcSetup.labels.frghtterms 						= 'Freight Terms1';
Modules.Ocean.CustInvcSetup.labels.acttrgpont 						= 'Trigger Status1';
Modules.Ocean.CustInvcSetup.labels.trgpont 						    = 'Trigger Point1';
Modules.Ocean.CustInvcSetup.labels.gnrttrgidntf 				    = 'Genaration Trigger Identification1';
Modules.Ocean.CustInvcSetup.labels.trgidntfgridrec 				    = 'Trigger Identification Grid Record1';
Modules.Ocean.CustInvcSetup.labels.srvccode 						= 'Service Code1';
Modules.Ocean.CustInvcSetup.labels.bl		 						= 'BL Number1';
Modules.Ocean.CustInvcSetup.labels.voyage		 					= 'Voyage Number1';
Modules.Ocean.CustInvcSetup.labels.crterm 						    = 'Credit Term(calender Days)1';
Modules.Ocean.CustInvcSetup.labels.crtermonspplapprv 			    = 'Credit Term Based On Supplier Approval(BusinessDays)1';
Modules.Ocean.CustInvcSetup.labels.actinvcgrpngcrt 			        = 'Actual Invoice Grouping Criteria1';
Modules.Ocean.CustInvcSetup.labels.srvcgrpcd    			        = 'Service Group Code1';
Modules.Ocean.CustInvcSetup.labels.srvcgrp       			        = 'Service Group1';
Modules.Ocean.CustInvcSetup.labels.chrgcd              	            = 'Charge Code1';
Modules.Ocean.CustInvcSetup.labels.pol              	             = 'POL1';
Modules.Ocean.CustInvcSetup.labels.itmno							= 'Item No1';
Modules.Ocean.CustInvcSetup.labels.invccurr							= 'Invoice Currency1';
Modules.Ocean.CustInvcSetup.labels.vesselCode						= 'Vessel Code1';
Modules.Ocean.CustInvcSetup.labels.pop              	            = 'POP1';
Modules.Ocean.CustInvcSetup.labels.consolServiceCode              	 = 'Service Code1';
Modules.Ocean.CustInvcSetup.labels.intrvl              	            = 'Interval1';
Modules.Ocean.CustInvcSetup.labels.lstexcutime						= 'Last Execution Time1';
Modules.Ocean.CustInvcSetup.labels.nxtexcutime						= 'Next Execution Time1';
Modules.Ocean.CustInvcSetup.labels.consolCargoGroup       	     	= 'Cargo Type1';
Modules.Ocean.CustInvcSetup.labels.consolCargoClass                  = 'Cargo Class1';
Modules.Ocean.CustInvcSetup.labels.autoapprove                  	= 'AutoAprove(Genarate Final Invoice)1';
Modules.Ocean.CustInvcSetup.labels.excstlist						= 'Exclude Customer List1';
Modules.Ocean.CustInvcSetup.labels.serviceGroup                     ='Service Group1';
Modules.Ocean.CustInvcSetup.labels.serviceCode                       ='Service Code1';
Modules.Ocean.CustInvcSetup.labels.partyName       			        = 'Party Name1';
Modules.Ocean.CustInvcSetup.labels.popName       			            = 'Pop Name1';
Modules.Ocean.CustInvcSetup.labels.popNametoolTip       			        = 'Place Of Payment City1';
Modules.Ocean.CustInvcSetup.labels.poptoolTip       	        = 'Place Of Payment1';
//Modules.Ocean.CustInvcSetup.labels.orgnsrvloc       	            = 'Origin/Service Location1';
//Modules.Ocean.CustInvcSetup.labels.destination       	            = 'Destination1';
//Modules.Ocean.CustInvcSetup.labels.orgnlorgn       	                = 'Original Origin1';
//Modules.Ocean.CustInvcSetup.labels.fianldestination       	        = 'Final Destination1';
//Modules.Ocean.CustInvcSetup.labels.conveyance       	            = 'Conveyance1';
//Modules.Ocean.CustInvcSetup.labels.ldref       	                    = 'Load Reference1';
//Modules.Ocean.CustInvcSetup.labels.wrkorderno       	            = 'WorkOrder Number1';
//Modules.Ocean.CustInvcSetup.labels.spplcd              	            = 'Supplier Code1';
//Modules.Ocean.CustInvcSetup.labels.trprtmode              	        = 'Transport Mode1';
//Modules.Ocean.CustInvcSetup.labels.csldtid              	        = 'Consolidation Id1';
//Modules.Ocean.CustInvcSetup.labels.cnsdt       			            = 'Cnsldt1';
//Modules.Ocean.CustInvcSetup.labels.afterGenerationFreq       		= 'No.of days after Generation Frequency1';



Modules.Ocean.CustInvcSetup.labels.serviceType                  	= 'Service Type1';
Modules.Ocean.CustInvcSetup.labels.party		                  	= 'Party1';
Modules.Ocean.CustInvcSetup.labels.prntTmpltPrepaid                	= 'Print Template For Prepaid1';
Modules.Ocean.CustInvcSetup.labels.prntTmpltCollect                	= 'Print Template For Collect1';
Modules.Ocean.CustInvcSetup.labels.cstmrPrntTmpltWinTitle          	= 'Customer Print Template1';

Modules.Ocean.CustInvcSetup.labels.customerCode						= 'Customer Code1';

Modules.Ocean.CustInvcSetup.labels.pod                              ='POD1';
Modules.Ocean.CustInvcSetup.labels.pfd                              ='PFD1';
Modules.Ocean.CustInvcSetup.labels.carrierCodeGroup                  ='Carrier Code Group1';
Modules.Ocean.CustInvcSetup.labels.cargoGroup                        ='Cargo Type1';
Modules.Ocean.CustInvcSetup.labels.cargoCode                         ='Cargo Class1';
Modules.Ocean.CustInvcSetup.labels.consolidation                     ='Consolidation1';
Modules.Ocean.CustInvcSetup.labels.consolServiceGroup                ='Service Group1';
Modules.Ocean.CustInvcSetup.labels.itemNumber                        ='Item No1';
Modules.Ocean.CustInvcSetup.labels.generationFrequency               ='Generation Frequency1';
Modules.Ocean.CustInvcSetup.labels.Time                              ='Time1';
Modules.Ocean.CustInvcSetup.labels.GenerationInterval                ='Generation Interval1';
Modules.Ocean.CustInvcSetup.labels.GenerationTimeZone                ='Generation TimeZone1';
Modules.Ocean.CustInvcSetup.labels.AutoAprove                        ='Auto Aprove1';


/*** OCEAN - Customer Invoice Setup Screen ***/
	
/***********************************************************************/
//#NonOcean Supplier Remittance Details
/***********************************************************************/
Modules.supplierInvoice.supplierRemittanceDetails.tabParentPanelLbl='Supplier Remittance Details1';
Modules.supplierInvoice.supplierRemittanceDetails.supplierCode='Supplier1';
Modules.supplierInvoice.supplierRemittanceDetails.invcNumber='Invoice Number1';
Modules.supplierInvoice.supplierRemittanceDetails.paymentFrmDt='Payment From Date1';
Modules.supplierInvoice.supplierRemittanceDetails.paymentToDt='Payment To Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcFrmDt='Invoice From Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcToDt='Invoice To Date1';
Modules.supplierInvoice.supplierRemittanceDetails.saveSearchCriteriaTtl='Save Search Criteria1';
Modules.supplierInvoice.supplierRemittanceDetails.retrieveSearchCriteriaTtl= 'Retrieve Search Criteria1';
Modules.supplierInvoice.supplierRemittanceDetails.serviceType='Service Type1';
Modules.supplierInvoice.supplierRemittanceDetails.eventLoadRef='Event/Load Ref1';
Modules.supplierInvoice.supplierRemittanceDetails.modeOfPaymnt='Mode of Payment1';
Modules.supplierInvoice.supplierRemittanceDetails.paymntDoc='Payment Document1';
Modules.supplierInvoice.supplierRemittanceDetails.unitId='Unit ID1';
Modules.supplierInvoice.supplierRemittanceDetails.servcCode='Service Code1';

Modules.supplierInvoice.supplierRemittanceDetails.shipReference='Shipping Reference1';

Modules.supplierInvoice.supplierRemittanceDetails.pdfRadioBttn='PDF1';
Modules.supplierInvoice.supplierRemittanceDetails.exlRadioBttn='Excel1';
Modules.supplierInvoice.supplierRemittanceDetails.summaryRadioBttn='Summary1';
Modules.supplierInvoice.supplierRemittanceDetails.DetailRadioBttn='Detail1';
Modules.supplierInvoice.supplierRemittanceDetails.ascRadioBttn='Ascending1';
Modules.supplierInvoice.supplierRemittanceDetails.DescRadioBttn='Descending1';
Modules.supplierInvoice.supplierRemittanceDetails.reportOutputTtl='Report Output1';
Modules.supplierInvoice.supplierRemittanceDetails.reportOptionsTtl='Report Options1';
Modules.supplierInvoice.supplierRemittanceDetails.sortOptionsTtl='Sort Options1';
Modules.supplierInvoice.supplierRemittanceDetails.invcDate='Invoice Date1';

Modules.supplierInvoice.supplierRemittanceDetails.paymntDate='Payment Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcAmnt='Invoice Amount1';
Modules.supplierInvoice.supplierRemittanceDetails.paidAmnt='Paid Amount1';

Modules.supplierInvoice.supplierRemittanceDetails.currency='Currency1';
Modules.supplierInvoice.supplierRemittanceDetails.partId='Part ID1';
Modules.supplierInvoice.supplierRemittanceDetails.deliveryDate='Delivery Date1';

Modules.supplierInvoice.supplierRemittanceDetails.apprvedAmnt='Approved Amount1';

Modules.supplierInvoice.supplierRemittanceDetails.overdRejectCmmnt='Override/Rejected Comment1';
Modules.supplierInvoice.supplierRemittanceDetails.parentGridWinTtl='Supplier Remittance Parent Details1';
Modules.supplierInvoice.supplierRemittanceDetails.childGridWinTtl='Supplier Remittance Child Details1';
Modules.supplierInvoice.supplierRemittanceDetails.report='Report1';

Modules.supplierInvoice.supplierRemittanceDetails.suuplerCode='Supplier1';
Modules.supplierInvoice.supplierRemittanceDetails.invcNumber='Invoice Number1';
Modules.supplierInvoice.supplierRemittanceDetails.paymentFrmDt='Payment From Date1';
Modules.supplierInvoice.supplierRemittanceDetails.paymentToDt='Payment To Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcFrmDt='Invoice From Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcToDt='Invoice To Date1';
Modules.supplierInvoice.supplierRemittanceDetails.saveSearchCriteriaTtl='Save Search Criteria1';
Modules.supplierInvoice.supplierRemittanceDetails.retrieveSearchCriteriaTtl= 'Retrieve Search Criteria1';
Modules.supplierInvoice.supplierRemittanceDetails.serviceType='Service Type1';
Modules.supplierInvoice.supplierRemittanceDetails.eventLoadRef='Event/Load Ref1';
Modules.supplierInvoice.supplierRemittanceDetails.modeOfPaymnt='Mode of Payment1';
Modules.supplierInvoice.supplierRemittanceDetails.paymntDoc='Payment Document1';


Modules.supplierInvoice.supplierRemittanceDetails.conveyanceId='Conveyance ID1';
Modules.supplierInvoice.supplierRemittanceDetails.shipReference='Shipping Reference1';
/*************************Customer Invoice Status For Ocean*****************/
Modules.LblsAndTtls.custmerInvcStsForOceanTtl			=	'Customer Invoice Status For Ocean1';
Modules.LblsAndTtls.custmerInvcStsForOceanCompanyLbl	=	'Company1';	
Modules.LblsAndTtls.custmerInvcStsForOceanCustomerLbl	=	'Customer1';
Modules.LblsAndTtls.custmerInvcStsForOceanDbtrPtyLbl	=	'Debtor Party1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcNoLbl		=	'Invoice No1';
Modules.LblsAndTtls.custmerInvcStsForOceanPrftLossLbl	=	'Profit/Loss1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcFrmDtLbl	=	'Invoice From Date1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcToDtLbl	=	'Invoice To Date1';
Modules.LblsAndTtls.custmerInvcStsForOceanProfrmaLbl	=	'Profarma1';
Modules.LblsAndTtls.custmerInvcStsForOceanRjctedLbl		=	'Rejected1';
Modules.LblsAndTtls.custmerInvcStsForOceanFinalLbl		=	'Final1';
Modules.LblsAndTtls.custmerInvcStsForOceanPaidLbl		=	'Paid1';
Modules.LblsAndTtls.custmerInvcStsForOceanViewLbl		=	'View1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcLbl		=	'Invoice1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcPrntrLbl	=	'Invoice Printer1';
Modules.LblsAndTtls.custmerInvcStsForOceanBckupPrntrLbl	=	'Back-Up Printer1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcCpsLbl	=	'Invoice Copies1';
Modules.LblsAndTtls.custmerInvcStsForOceanEmailLbl		=	'E-Mail1';
Modules.LblsAndTtls.custmerInvcStsForOceanPrintLbl		=	'Print1';
Modules.LblsAndTtls.custmerInvcStsForOceanBckUpLbl		=	'Back-Up1';
Modules.LblsAndTtls.custmerInvcStsForOceanBckUpCpsLbl	=	'Back-Up Copies1';
Modules.LblsAndTtls.custmerInvcStsForOceanCcMailIdLbl	=	'CC-Mail Id1';
Modules.LblsAndTtls.custmerInvcStsForOceanActualLbl		=	'Actual1';
Modules.LblsAndTtls.custmerInvcStsForOceanAccuralLbl	=	'Accural1';
Modules.LblsAndTtls.custmerInvcStsForOceanCreditLbl		=	'Credit1';
Modules.LblsAndTtls.custmerInvcStsForOceanDebitLbl		=	'Debit1';
Modules.LblsAndTtls.custmerInvcStsForOceanPdfLbl		=	'PDF1';
Modules.LblsAndTtls.custmerInvcStsForOceanExcelLbl		=	'Excel1';
Modules.LblsAndTtls.custmerInvcStsForOceanAscndngLbl	=	'Ascending1';
Modules.LblsAndTtls.custmerInvcStsForOceanDescndngLbl	=	'Descending1';
Modules.LblsAndTtls.custmerInvcStsForOceanPartyLbl		=	'Party1'; 
Modules.LblsAndTtls.custmerInvcStsForOceanDcmntTpLbl	=	'Document Type1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcTpLbl		=	'Invoice Type1';
Modules.LblsAndTtls.custmerInvcStsForOceanMnfstCrnLbl	=	'Manifest Currency1';
Modules.LblsAndTtls.custmerInvcStsForOceanMnfstAmntLbl	=	'Manifest Amount1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcCrncyLbl	=	'Invoice Currency1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcAmntLbl	=	'Invoice Amount1';	
Modules.LblsAndTtls.custmerInvcStsForOceanUsdEqAmntLbl	=	'USD Equivalent Amount1';
Modules.LblsAndTtls.custmerInvcStsForOceanPaidAmountLbl	=	'Paid Amount1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcDtLbl		=	'Invoice Date1';
Modules.LblsAndTtls.custmerInvcStsForOceanDueDtLbl		=	'Due Date1';
Modules.LblsAndTtls.custmerInvcStsForOceanLstPymntDtLbl	=	'Last Payment Date1';
Modules.LblsAndTtls.custmerInvcStsForOceanInvcStsLbl	=	'Invoice Status1';
Modules.LblsAndTtls.custmerInvcStsForOceanUsdEqAmntshortLbl	=	'USD Equivalent1';

Modules.supplierInvoice.supplierRemittanceDetails.pdfRadioBttn='PDF1';
Modules.supplierInvoice.supplierRemittanceDetails.exlRadioBttn='Excel1';
Modules.supplierInvoice.supplierRemittanceDetails.summaryRadioBttn='Summary1';
Modules.supplierInvoice.supplierRemittanceDetails.DetailRadioBttn='Detail1';
Modules.supplierInvoice.supplierRemittanceDetails.ascRadioBttn='Ascending1';
Modules.supplierInvoice.supplierRemittanceDetails.DescRadioBttn='Descending1';
Modules.supplierInvoice.supplierRemittanceDetails.reportOutputTtl='Report Output1';
Modules.supplierInvoice.supplierRemittanceDetails.reportOptionsTtl='Report Options1';
Modules.supplierInvoice.supplierRemittanceDetails.sortOptionsTtl='Sort Options1';
Modules.supplierInvoice.supplierRemittanceDetails.invcDate='Invoice Date1';

Modules.supplierInvoice.supplierRemittanceDetails.paymntDate='Payment Date1';
Modules.supplierInvoice.supplierRemittanceDetails.invcAmnt='Invoice Amount1';
Modules.supplierInvoice.supplierRemittanceDetails.paidAmnt='Paid Amount1';

Modules.supplierInvoice.supplierRemittanceDetails.currency='Currency1';
Modules.supplierInvoice.supplierRemittanceDetails.deliveryDate='Delivery Date1';

Modules.supplierInvoice.supplierRemittanceDetails.apprvedAmnt='Approved Amount1';


Modules.supplierInvoice.supplierRemittanceDetails.parentGridWinTtl='Supplier Remittance Parent Details1';
Modules.supplierInvoice.supplierRemittanceDetails.childGridWinTtl='Supplier Remittance Child Details1';
Modules.supplierInvoice.supplierRemittanceDetails.report='Report1';


/*******************************************************************************************
*
*					Ocean Customer Master
*********************************************************************************************/
 Modules.LblsAndTtls.partyLbl			=		'Party1';
 Modules.LblsAndTtls.summaryValueLbl			=		'Summary Value1';
 
 /*******************************************************************************************
*
*					Supplier Rate Verification
*********************************************************************************************/
Modules.LblsAndTtls.carrierLbl			=		'Carrier1';
Modules.LblsAndTtls.carrierNmLbl			=		'Carrier Name1';
Modules.LblsAndTtls.chargeCodeLbl			=		'Charge Code1';
Modules.LblsAndTtls.podLbl			=		'POD1';
Modules.LblsAndTtls.polLbl			=		'POL1';
Modules.LblsAndTtls.cargoTypeLbl			=		'Cargo Type1';
Modules.LblsAndTtls.polCityLbl			=		'POL City1';
Modules.LblsAndTtls.polStateLbl			=		'POL State1';
Modules.LblsAndTtls.podCityLbl			=		'POD City1';
Modules.LblsAndTtls.podStateLbl			=		'POD State1';
Modules.LblsAndTtls.porLbl			=		'POR1';
Modules.LblsAndTtls.pfdTlt			=		'PFD1';
Modules.LblsAndTtls.steeringTlt			=		'Steering1';
Modules.LblsAndTtls.hazardousLbl			=		'Hazardous1';
Modules.LblsAndTtls.hndlingIndLbl			=		'Hndling Indicator1';
Modules.LblsAndTtls.transfeGearLbl			=		'Transfer Gear1';


//******supplier master ocean+ customer contract query ocean ***************************************************************************************************************************************
	
Modules.LblsAndTtls.supplierMasterSupplierDetails			='Supplier Details1';
Modules.LblsAndTtls.supplierMasterPaymentDetails			='Payment Details1';
Modules.LblsAndTtls.supplierMasterDateContractIdentification='Status Date For Contract Identification1';
Modules.LblsAndTtls.supplierMasterSupplierInvoiceSetup='Supplier Automatic Invoice Setup1';
Modules.LblsAndTtls.supplierMasterRateRoundingCriteria='Rounding Criteria For Rate1';

Modules.LblsAndTtls.supplierCd='Supplier Code1';
Modules.LblsAndTtls.supplierNm='Supplier Name1';
Modules.LblsAndTtls.defaultCurrency='Default Currency1';
Modules.LblsAndTtls.taxRefNumber='Tax Ref Number1';
Modules.LblsAndTtls.addrLineOne='Address Line 11';
Modules.LblsAndTtls.addrLineTwo='Address Line 21';
Modules.LblsAndTtls.city='City1';
Modules.LblsAndTtls.stateProvince='State/ Province1';
Modules.LblsAndTtls.country='Country1';
Modules.LblsAndTtls.zipPostalcd='Zip/Postal code1';
Modules.LblsAndTtls.telephoneNo='Telephone No1';
Modules.LblsAndTtls.faxNumber='Fax Number1';
Modules.LblsAndTtls.mobilenumber='Mobile number1';
Modules.LblsAndTtls.emailAddress='Email Address1';
Modules.LblsAndTtls.contactPersonNm='Contact Person1';
Modules.LblsAndTtls.website='Website1';
Modules.LblsAndTtls.financialId='Financial ID1';
Modules.LblsAndTtls.calcTaxIfNotSentInMsg='Calculate Tax if not sent in Message1';
Modules.LblsAndTtls.sendApMsgCoda='Send A/P Message to CODA1';
Modules.LblsAndTtls.calcTaxIfNotSentThroughExcel='Calculate Tax if not sent through Excel1';
Modules.LblsAndTtls.ignoreInvoiceDueDateFromMsg='Ignore Invoice Due Date from Message1';
Modules.LblsAndTtls.shipmentDate='Shipment Date1';
Modules.LblsAndTtls.partialPayment='Partial Payment1';
Modules.LblsAndTtls.completionDate='Completion Date1';
Modules.LblsAndTtls.createVarianceEvent='Create Variance Event1';
Modules.LblsAndTtls.autoApprove='Auto Approve1';
Modules.LblsAndTtls.remarksOne='Remarks 11';
Modules.LblsAndTtls.remarksTwo='Remarks 21';

//'Supplier Automatic Invoice Setup'
Modules.LblsAndTtls.automaticInvoiceWinTtl='Supplier Automatic Invoice Setup1';
Modules.LblsAndTtls.triggerStatus='Triggering Status1';
Modules.LblsAndTtls.generateReconciledInv='Generate Reconciled Invoice1';
Modules.LblsAndTtls.serviceCd='Service Code1';

//payment dtls
Modules.LblsAndTtls.chargeCd='Charge Code1';
Modules.LblsAndTtls.payTermDays='Payment Term Days1';
Modules.LblsAndTtls.paymntTermDayAbb = 'Paymnt Trm Days1';
//rounding criteria rate
Modules.LblsAndTtls.roundingCriteriaByRate='Rate Rounding Criteria1';
Modules.LblsAndTtls.serviceType='Service Type1';
Modules.LblsAndTtls.currency='Currency1';
Modules.LblsAndTtls.roundingCriteria='Rounding Criteria1';

//'Status Date For Contract Identification'
Modules.LblsAndTtls.statusDtForContractIdentification='Status Date For Contract Identification1';
Modules.LblsAndTtls.completionDt='Completion Date1';

Modules.LblsAndTtls.supplierMaster='Supplier Master1';
Modules.LblsAndTtls.value='Value1';

//ocean search form

Modules.LblsAndTtls.custContractOceanLbl='Customer Contract Query  For Ocean1';
Modules.LblsAndTtls.companyLbl='Company1';
Modules.LblsAndTtls.companyNmLbl='Company Name1';
Modules.LblsAndTtls.popLbl='POP1';
Modules.LblsAndTtls.popFullLbl='Place Of Payment1';
Modules.LblsAndTtls.popDescrLbl='POP Description1';
Modules.LblsAndTtls.polFullLbl = 'Place of Load1';
Modules.LblsAndTtls.podFullLbl = 'Place of Destination1';
Modules.LblsAndTtls.pfdFullLbl = 'Place of Final Destination1';
Modules.LblsAndTtls.porFullLbl  =  'Place of Receipt1';
Modules.LblsAndTtls.partyLbl='Party1';
Modules.LblsAndTtls.nameLbl='Name1';
Modules.LblsAndTtls.contractIdLbl='Contract Id1';
Modules.LblsAndTtls.startDtLbl='Start Date1';
Modules.LblsAndTtls.endDtLbl='End Date1';
Modules.LblsAndTtls.validFromLbl='Valid From1';
Modules.LblsAndTtls.validToLbl='Valid To1';
Modules.LblsAndTtls.oldContractIdLbl='Old Contract ID1';
Modules.LblsAndTtls.oceanCustmrRateQueryGridTtl			=		' Ocean Customer Rate Query Grid Record1';	

Modules.LblsAndTtls.debtorPartyLbl='Debtor Party1';
Modules.LblsAndTtls.debtorPartyNmLbl='Debtor Party Name1';	
Modules.LblsAndTtls.validFromDtLbl='Valid From Date1';
Modules.LblsAndTtls.validToDtLbl='Valid To Date1';

Modules.LblsAndTtls.increaseCriteriaLbl='Increase Criteria1';
Modules.LblsAndTtls.increaseValueLbl='Increase Value1';
Modules.LblsAndTtls.copyContractWinLbl='Copy Contract Popup For Ocean1';	

Modules.LblsAndTtls.copyContractActionTtl='Copy Contract1';	
//**********************************************************************************************************************************


//***************speicalmove entry button***************
Modules.LblsAndTtls.submitLbl='Submit1';
Modules.LblsAndTtls.cancelLbl=	'Cancel1';
Modules.LblsAndTtls.unLockLbl='(Un)lock1';


/***********************************************************************/
//# CURRENCY_MAPPER
/***********************************************************************/
Modules.Masters.Currency_Mapper.labels.partnerGroup = 'Partner Group1';
Modules.Masters.Currency_Mapper.labels.externalCurrency = 'External Currency Code1';
Modules.Masters.Currency_Mapper.labels.internalCurrency = 'Internal Currency Code1';


/***********************************************************************/
//# RATE_BASIS_MAPPER
/***********************************************************************/
Modules.Masters.Rate_Basis_Mapper.labels.partnerGroup = 'Partner Group1';
Modules.Masters.Rate_Basis_Mapper.labels.externalRateBasis = 'External Rate Basis Code1';
Modules.Masters.Rate_Basis_Mapper.labels.internalRateBasis = 'Internal Rate Basis Code1';


/***********************************************************************/
//#TRANSPORT_MODE_MAPPER
/***********************************************************************/
Modules.Masters.Transport_Mode_Mapper.labels.partnerGroup = 'Partner Group1';
Modules.Masters.Transport_Mode_Mapper.labels.exterrnalTransportMode = 'External Transport Mode1';
Modules.Masters.Transport_Mode_Mapper.labels.internalTransportMode = 'Internal Transport Mode1';


/************************/
 //#UOM MAPPER
/************************************/
Modules.Masters.UOMCodeMapper.labels.partnerGroup ='Partner Group1';
Modules.Masters.UOMCodeMapper.labels.externalUOMCode='External UOM Code1';
Modules.Masters.UOMCodeMapper.labels.internalUOMCode ='Internal UOM Code1';
/************************************/ 

//#PORT TYPE MASTER
/************************************/
Modules.Ocean.Masters.PortTypeMaster.labels.portTypeCode='Code1';

Modules.Ocean.Masters.PortTypeMaster.labels.portTypeDesc='Description1';

/***********************************/

//#CARGO TYPE MASTER
/**********************************/
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoTypeCode='Code1';
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoClass='Class1';
Modules.Ocean.Masters.CargoTypeMaster.labels.cargoTypeDesc='Description1';

/*********************************/





/***********************************************************************/
//#LOV's Factory for Ocean
/***********************************************************************/
Modules.ocean.lov_factory.labels.supplier='Supplier1';
Modules.ocean.lov_factory.labels.pod='POD1';
Modules.ocean.lov_factory.labels.por='POR1';
Modules.ocean.lov_factory.labels.pfd='PFD1';
Modules.ocean.lov_factory.labels.serviceCode='Service Code1';
Modules.ocean.lov_factory.labels.customerCode='Customer1';
Modules.ocean.lov_factory.labels.customerCode='Customer1';
Modules.ocean.lov_factory.labels.modelCode='Model1';
Modules.ocean.lov_factory.labels.makeCode='Make1';
Modules.ocean.lov_factory.labels.party='Party1';
Modules.ocean.lov_factory.labels.contractId='Contract ID1';



/***********************************************************************/
//# Customer Event Status Summary (Ocean)
/***********************************************************************/
Modules.LblsAndTtls.frieghtTermLbl = 'Frieght Term1';
Modules.LblsAndTtls.VesselLbl = 'Vessel1';
Modules.LblsAndTtls.Voyage = 'Voyage1';
Modules.LblsAndTtls.OcnCstmrEvntStsSummTlt = 'Customer Event Status Summary Details1';
Modules.LblsAndTtls.servAmntManFstCrncyAbb='Srv Amt Manfst Curr1';
Modules.LblsAndTtls.manifstCurncyCodeAbb='Manfst Curr Cd1';
Modules.LblsAndTtls.servcAmntInvcCurncyAbb='Srvc Amt Invc Curr1';
Modules.LblsAndTtls.invcCurncyCodeAbb = 'Invc Curr Cd1';
Modules.LblsAndTtls.servcAmntUSDCurrencyAbb = 'Srvc Amt USD1';


/***********************************************************************/
//#SHIPMENT_TYPE_MAPPER
/***********************************************************************/

Modules.Masters.Shipment_Type_Mapper.labels.shipmentTypeMapperTlt='Shipment Type Mapper1';
Modules.Masters.Shipment_Type_Mapper.labels.partnerGroup='Partner Group1';
Modules.Masters.Shipment_Type_Mapper.labels.ExternalShipmentType='External Shipment Type1';
Modules.Masters.Shipment_Type_Mapper.labels.InternalShipmentType='Internal Shipment Type1';


/***********************************************************************/
//#COMMODITY_MASTER
/***********************************************************************/

Modules.Ocean.Masters.Commodity_Master.labels.commodityMasterTlt='Commodity Master1';
Modules.Ocean.Masters.Commodity_Master.labels.commodityCode='Code1';
Modules.Ocean.Masters.Commodity_Master.labels.commodityDescription='Description1';
Modules.Ocean.Masters.Commodity_Master.labels.commodityGroup='Group1';


/***********************************************************************/
// #Supplier Rate Verification for Ocean
/***********************************************************************/
Modules.contract.supplier.oceansupplierRateVerification.labels.partyDetails='Party Details1';
Modules.contract.supplier.oceansupplierRateVerification.labels.party='Party1';
Modules.contract.supplier.oceansupplierRateVerification.labels.contractId='Contract Id1';
Modules.contract.supplier.oceansupplierRateVerification.labels.chargeCode='Charge Code1';
Modules.contract.supplier.oceansupplierRateVerification.labels.validFromDate='Valid From Date1';
Modules.contract.supplier.oceansupplierRateVerification.labels.validToDate='Valid To Date1';
Modules.contract.supplier.oceansupplierRateVerification.labels.pol='POL1';
Modules.contract.supplier.oceansupplierRateVerification.labels.pod='POD1';
Modules.contract.supplier.oceansupplierRateVerification.labels.cargoType='Cargo Type1';
Modules.contract.supplier.oceansupplierRateVerification.labels.cargoClass='Cargo Class1';
Modules.contract.supplier.oceansupplierRateVerification.labels.makeCode='Make Code1';
Modules.contract.supplier.oceansupplierRateVerification.labels.model='Model1';
Modules.contract.supplier.oceansupplierRateVerification.labels.polCity='POL City1';
Modules.contract.supplier.oceansupplierRateVerification.labels.polState='POL State1';
Modules.contract.supplier.oceansupplierRateVerification.labels.polCountry='POL Country1';
Modules.contract.supplier.oceansupplierRateVerification.labels.podCity='POD City1';
Modules.contract.supplier.oceansupplierRateVerification.labels.podState='POD State1';
Modules.contract.supplier.oceansupplierRateVerification.labels.podCountry='POD Country1';
Modules.contract.supplier.oceansupplierRateVerification.labels.por='POR1';
Modules.contract.supplier.oceansupplierRateVerification.labels.pfd='PFD1';
Modules.contract.supplier.oceansupplierRateVerification.labels.steering='Steering1';
Modules.contract.supplier.oceansupplierRateVerification.labels.hazardous='Hazardous1';
Modules.contract.supplier.oceansupplierRateVerification.labels.handlingInd='Handling Indicator1';
Modules.contract.supplier.oceansupplierRateVerification.labels.transferGear='Transfer Gear1';
Modules.contract.supplier.oceansupplierRateVerification.labels.notChargeable='Not Chargeable1';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorVal='Factor Value1';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorType='Factor Type1';
Modules.contract.supplier.oceansupplierRateVerification.labels.factorRate='Factor Rate1';
Modules.contract.supplier.oceansupplierRateVerification.labels.fixedRate='Fixed Rate1';
Modules.contract.supplier.oceansupplierRateVerification.labels.tariffRate='Tariff Rate1';
Modules.contract.supplier.oceansupplierRateVerification.labels.uInd='L/U Ind1';
Modules.contract.supplier.oceansupplierRateVerification.labels.tariffCurrencyCode='Tariff CurrencyCode1';
Modules.contract.supplier.oceansupplierRateVerification.labels.priority='Priority1';
Modules.contract.supplier.oceansupplierRateVerification.labels.seqNo='Seq No1';
Modules.contract.supplier.oceansupplierRateVerification.labels.supplierRateVerification='Supplier Rate Verification1';
Modules.contract.supplier.oceansupplierRateVerification.labels.carrier='Carrier1';
Modules.contract.supplier.oceansupplierRateVerification.labels.carrierName='Carrier Name1';
Modules.contract.supplier.oceansupplierRateVerification.labels.effectiveDate='Effective Date1';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.chargeCode='Charge Code1';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.contractId='Contract Id1';


/***********************************************************************/
//#LOV's Factory for Ocean
/***********************************************************************/
Modules.ocean.lov_factory.labels.supplier='Supplier1';
Modules.ocean.lov_factory.labels.pod='POD1';
Modules.ocean.lov_factory.labels.por='POR1';
Modules.ocean.lov_factory.labels.pfd='PFD1';
Modules.ocean.lov_factory.labels.serviceCode='Service Code1';
Modules.ocean.lov_factory.labels.customerCode='Customer1';


Modules.contract.supplier.oceansupplierRateVerification.labels.effectiveDate='Effective Date1';
Modules.contract.supplier.oceansupplierRateQueryServiceCode.labels.supplierRateQuery='Supplier Rate Query Service Code1';
Modules.LblsAndTtls.cargoType='Cargo Type1';
Modules.LblsAndTtls.cargoClass='Cargo Class1';




/***********************************************************************/
//#Customer Invoice Status for Ocean
/***********************************************************************/
Modules.LblsAndTtls.printTypeLbl					=		'Print Type1';
Modules.LblsAndTtls.customerInvoiceStausGridLbl		=		'Customer Invoice Status Grid Record1';
Modules.contract.ocean_customer_master.labels.roundingCriteria='Rounding Criteria1';
Modules.contract.ocean_customer_master.labels.partyType='Party Type1';

Modules.LblsAndTtls.popupoceanCustomerRateQueryRecordViewGridTlt='Ocean Customer Rate Qiery Grid Record1';
Modules.LblsAndTtls.popupoceanCustomerRateQueryPopWinRecordViewGridTlt='Customer Rate Query  New Contract Grid Record1';




/***********************************************************************/
//#EVENT RATING QUERY
/***********************************************************************/
Modules.operations.event_details.event_rating_query.labels.servicecode = 'Service Code1';
Modules.operations.event_details.event_rating_query.labels.shipmentDate = 'Shipment Date1';
Modules.operations.event_details.event_rating_query.labels.deliveryCompletionDate = 'Dlvy/Cmpltn Dt1';
Modules.operations.event_details.event_rating_query.labels.modelYear = 'Model Year1';
Modules.operations.event_details.event_rating_query.labels.partNumber = 'Part Number1';
Modules.operations.event_details.event_rating_query.labels.storageQuantity = 'Storage Qty1';
Modules.operations.event_details.event_rating_query.labels.quantity = 'Quantity1';
Modules.operations.event_details.event_rating_query.labels.storageUom = 'Storage UOM1';
Modules.operations.event_details.event_rating_query.labels.profitLossCenter = 'Profit/Loss Center1';
Modules.operations.event_details.event_rating_query.labels.prevChargeQuantity = 'Prev Chrg Qty1';
Modules.operations.event_details.event_rating_query.labels.prevChargeUom = 'Prev Chrg UOM1';
Modules.operations.event_details.event_rating_query.labels.value = 'Value1';
Modules.operations.event_details.event_rating_query.labels.uom = 'UOM1';
Modules.operations.event_details.event_rating_query.labels.ratingDest = 'Rating Destination1';
Modules.operations.event_details.event_rating_query.labels.notChargeable =  'Not Chargeable1';
Modules.operations.event_details.event_rating_query.labels.glCode = 'GL Code1';
Modules.operations.event_details.event_rating_query.labels.currency = 'Currency1';
Modules.operations.event_details.event_rating_query.labels.serviceAmt = 'Service Amount1';
Modules.operations.event_details.event_rating_query.labels.taxAmt = 'Tax Amount1';
Modules.operations.event_details.event_rating_query.labels.totalAmt = 'Total Amount1';
Modules.operations.event_details.event_rating_query.labels.servDescr='Srvc Description1';
Modules.operations.event_details.event_rating_query.labels.invNumber = 'Invoice Number1';
Modules.operations.event_details.event_rating_query.labels.servGroup = 'Service Group1';
Modules.operations.event_details.event_rating_query.labels.debtorParty = 'Debtor Party1';
Modules.operations.event_details.event_rating_query.labels.consolidationType = 'Cnsldtn Type1';
Modules.operations.event_details.event_rating_query.labels.originStateProvince = 'Origin S/P1';
Modules.operations.event_details.event_rating_query.labels.destinationStateProvince = 'Destination S/P1';
Modules.operations.event_details.event_rating_query.labels.status='Status1';
//Modules.operations.event_details.event_rating_query.labels.consolidationType='cnsldtn Type1';




/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY   START
/***********************************************************************/

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.parentTabPanelTtl = 'Customer Invoice Entry1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cstmrinvEntryFormTtl = 'Customer Invoice Entry1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupWinTtl = 'Customer Invoice Entry1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.PGridPopupWinTtl = 'Customer Invoice Entry1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerComboTtl = 'Customer1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerNameTtl = 'Customer Name1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.formCustomerCodeTtl = 'Customer Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceNumberGP = 'Invoice Number1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceDateGP = 'Invoice Date1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceDueDateGP = 'Invoice Due Date1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceCurrencyGP = 'Invoice CUrrency1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.voyageNumberGP = 'Voyage Number1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popGP = 'POP1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.popCurrencyGP = 'POP Currency1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polGP = 'POL1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podGP = 'POD1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.porGP = 'POR1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.contactPersonGP = 'Contact Person1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumberGP = 'BL Number1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.profitLossGP = 'Profit/Loss Center1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.remarksGP = 'Remarks1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.printTemplateGP = 'Print Template1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.sailingDateGP = 'Sailing Date1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.statusGP = 'Invoice Status1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.paymentDtlsGP = 'Payment Details1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.partyGP = 'Party1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.nameGP = 'Name1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.addrLane1GP = 'Address Line11';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.addrLane2GP = 'Address Line21';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cityGP = 'City1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.stateProvGP = 'State/Province1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.countryGP = 'Country1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.zipPostalCdGP = 'Zip/Postal Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceTypeGP = 'Invoice Type1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.docTypeGP = 'Document Type1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.freightTermsGP = 'Freight Terms1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceClause1GP = 'Invoice Clause11';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceClause2GP = 'Invoice Clause21';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.chargeCd = 'Charge Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.blNumber = 'BL Number1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.descr = 'Description1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvGrpCd = 'Service Group Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.voyage = 'Voyage1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.vesselName = 'Vessel Name1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shippingRefNo = 'Shipping Reference Number1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.transportCd = 'Transport Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.make = 'Make1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.model = 'Model1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.year = 'Year1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rateTier = 'Rate Tier1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.polSI = 'POL SI1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pol = 'POL1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.podSI = 'POD SI1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pod = 'POD1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shipmentDate = 'Shipment Date1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.por = 'POR1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.pfd = 'PFD1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.shipmentType = 'Shipment Type1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.UOM = 'UOM1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.quantity = 'Quantity1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rateBasis = 'Rate Basis1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.rate = 'Rate1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.carrier = 'Carrier1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.serviceAmt = 'Service Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestCrncy = 'Manifest Currency1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.manifestAmt = 'Manifest Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceCrncy = 'Invoice Currency1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.invoiceAmt = 'Invoice Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.usdEqAmt = 'USD Equivalent Amount1';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.lengthCh = 'Length1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.weightCh = 'Weight1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.heightCh = 'Height1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.breadthCh = 'Breadth1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.volumeCh = 'Volume1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cubeCh = 'Cube1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.chDimensions = 'Dimensions1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.commodityCdCh = 'Commodity Code1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.commodityDescrCh = 'Commodity Description1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cargoListCh = 'Cargo List1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.cargoClassCh = 'Cargo Class1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.autoCh = 'Auto1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.unitCh = 'Unit1';




Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxTypeTg = 'Tax Type1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxPercentTg = 'Tax Percentage1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.srvcAmtTg = 'Service Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.taxAmtTg = 'Tax Amount1';

Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalSrvcAmtRF = 'Total Service Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalTaxAmtRF = 'Total Tax Amount1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.totalAmtRF = 'Total Amount1';


Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupInvcRadio = 'Invoice1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupCrdtNoteRadio = 'Credit Note1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupDbtNoteRadio = 'Debit Note1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupActualRadio = 'Actual1';
Modules.ocean.customer_invoice.ocean_customer_invoice_entry.labels.GPGridPopupAccrualRadio = 'Accrual1';

/***********************************************************************/
//#OCEAN CUSTOMER INVOICE ENTRY     END
/***********************************************************************/


Modules.Msgs.podTooltip='Port of Destination1';
Modules.Msgs.polTooltip='Port of Loading1';

/********************************************************************************/
//#CustomerLineItemStatus_Ocean
/**********************************************************************************/

Modules.ocean.customer_invoice.customer_line_item_status.labels.tabParentPanelLbl = 'Customer Line Item Status1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.supplier = 'Customer1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceNumber = 'Invoice Number1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceDate = 'Invoice Date1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.serviceCode = 'Service Code1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceAmount = 'Invoice Amount1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.approvedAmount = 'Approved Amount1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.paidAmount = 'Paid Amount1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.currency = 'Currency1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.unitId = 'Unit ID1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.loadReference = 'Load Reference1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.conveyanceId = 'Conveyance ID1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.partId = 'Part ID1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.deliveryCompletionDate = 'Delivery/Completion Date1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.dueDate = 'Due Date1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.lastPaymentDate = 'Last Payment Date1';
//Modules.ocean.ocean.customer_invoice.customer_line_item_status.labels.supplier = 'Line Item Status1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.reason = 'Reason1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.formTitle = 'Customer Line Item Status1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceFromDate = 'Invoice From Date1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoiceToDate = 'Invoice To Date1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.serviceType = 'Service Type1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.eventLoadReference = 'Event/Load Ref1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.shippingReference = 'Shipping Ref1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.proforma = 'Proforma1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.readyForReconciliation = 'Ready For Reconciliation1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.underInvestigation = 'Under Investigation1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.reconciled = 'Reconciled1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.approved = 'Approved1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.rejected = 'Rejected1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.paid = 'Paid1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.invoice = 'Invoice1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.creditNote = 'Credit Note1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.debitNote = 'Debit Note1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.lineItemStatus = 'Line Item Status1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.deleteBtn = 'Delete1';
Modules.ocean.customer_invoice.customer_line_item_status.labels.customerLineItemStatusPopWin = 'Customer Line Item Status Details1';



/**
 * 
 *  Non ocean Customer Invoice entry screen labels
 * 
 * 
 */

Modules.customer_invoice.customer_invoice_entry.labels.company_code							=	"Company";
Modules.customer_invoice.customer_invoice_entry.labels.customer_code						=	"Customer Code";
Modules.customer_invoice.customer_invoice_entry.labels.customer_invoice_number				=	"Customer Invoice Number";
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryTtl				    =	'Customer Invoice Entry1';
Modules.customer_invoice.customer_invoice_entry.labels.finalizeActionTtl					= 	'Finalize1';
Modules.customer_invoice.customer_invoice_entry.labels.rejectActionTtl						=	'Reject1';
Modules.customer_invoice.customer_invoice_entry.labels.copyInvioceActionTtl					= 	'Copy Invoice1';
Modules.customer_invoice.customer_invoice_entry.labels.viewInvoiceActionTtl					=	'View Invoice1';
Modules.customer_invoice.customer_invoice_entry.labels.viewBackupActionTtl					= 	'View Backup1';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceNumberGP						= 	'Invoice Number1';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceRefNumberGP					= 	'Reference Invoice Number1';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceDateGP						= 	'Invoice Date1';
Modules.customer_invoice.customer_invoice_entry.labels.invoiceDueDateGP						= 	'Invoice Due Date1';
Modules.customer_invoice.customer_invoice_entry.labels.currencyGP							= 	'Currency1';
Modules.customer_invoice.customer_invoice_entry.labels.profitLossCentreGP					= 	'Profit/Loss Centre1';
Modules.customer_invoice.customer_invoice_entry.labels.printTemplateGP						= 	'Print Template1';
Modules.customer_invoice.customer_invoice_entry.labels.statusGP								= 	'Status1';
Modules.customer_invoice.customer_invoice_entry.labels.remarksGP							= 	'Remarks1';
Modules.customer_invoice.customer_invoice_entry.labels.docTypeGP							= 	'Document Type1';
Modules.customer_invoice.customer_invoice_entry.labels.invcTypeGP							= 	'Invoice Type1';
Modules.customer_invoice.customer_invoice_entry.labels.paymentDtlsGP						= 	'Payment Details1';
Modules.customer_invoice.customer_invoice_entry.labels.partyGP								= 	'Party1';
Modules.customer_invoice.customer_invoice_entry.labels.nameGP								= 	'Name1';
Modules.customer_invoice.customer_invoice_entry.labels.addLane1GP							= 	'Address Line 11';
Modules.customer_invoice.customer_invoice_entry.labels.addLane2GP							= 	'Address Line 21';
Modules.customer_invoice.customer_invoice_entry.labels.cityGP								= 	'City1';
Modules.customer_invoice.customer_invoice_entry.labels.stateProvGP							= 	'State/Prov.1';
Modules.customer_invoice.customer_invoice_entry.labels.countryGP							= 	'Country1';
Modules.customer_invoice.customer_invoice_entry.labels.zipPostalCdGP						= 	'Zip/Postal Code1';
Modules.customer_invoice.customer_invoice_entry.labels.srvCodePG							= 	'Service Code1';
Modules.customer_invoice.customer_invoice_entry.labels.srvDescPG							= 	'Service Description1';
Modules.customer_invoice.customer_invoice_entry.labels.srvcGrpPG							= 	'Service Group1';
Modules.customer_invoice.customer_invoice_entry.labels.evntLdRefPG							= 	'Event/Load Reference1';
Modules.customer_invoice.customer_invoice_entry.labels.unitIdPG								= 	'Unit Id1';
Modules.customer_invoice.customer_invoice_entry.labels.convncIdPG							= 	'Conveyance Id1';
Modules.customer_invoice.customer_invoice_entry.labels.convncTypePG							= 	'Conveyance Type1';
Modules.customer_invoice.customer_invoice_entry.labels.convncNmPG							= 	'Conveyance Name1';
Modules.customer_invoice.customer_invoice_entry.labels.shipngRefNoPG						= 	'Shipping Ref.No.1';
Modules.customer_invoice.customer_invoice_entry.labels.transptCdPG							= 	'Transport Code1';
Modules.customer_invoice.customer_invoice_entry.labels.makeCdPG								= 	'Make Code1';
Modules.customer_invoice.customer_invoice_entry.labels.modelCdPG							= 	'Model Code1';
Modules.customer_invoice.customer_invoice_entry.labels.modelGrpPG							= 	'Model Group1';
Modules.customer_invoice.customer_invoice_entry.labels.modelYearPG							= 	'Model Year1';
Modules.customer_invoice.customer_invoice_entry.labels.trnsptModePG							= 	'Transport Mode1';
Modules.customer_invoice.customer_invoice_entry.labels.rateTierPG							= 	'Rate Tier1';
Modules.customer_invoice.customer_invoice_entry.labels.wrkOrderPG							= 	'Work Order1';
Modules.customer_invoice.customer_invoice_entry.labels.partIdPG								= 	'Part ID1';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocPG							= 	'Origin/Location1';
Modules.customer_invoice.customer_invoice_entry.labels.orgnAdd1PG							= 	'Origin Address 11';
Modules.customer_invoice.customer_invoice_entry.labels.orgnAdd2PG							= 	'Origin Address 21';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocCtyPG							= 	'Origin/Location City1';
Modules.customer_invoice.customer_invoice_entry.labels.orgnLocStPPG							= 	'Origin/Location State/Prov.1';
Modules.customer_invoice.customer_invoice_entry.labels.orgnZipPostalCdPG					= 	'Origin Zip/Postal Code1';
Modules.customer_invoice.customer_invoice_entry.labels.destCdPG								= 	'Destination Code1';
Modules.customer_invoice.customer_invoice_entry.labels.destAdd1PG							= 	'Destination Address 11';
Modules.customer_invoice.customer_invoice_entry.labels.destAdd2PG							= 	'Destination Address 21';
Modules.customer_invoice.customer_invoice_entry.labels.destCityPG							= 	'Destination City1';
Modules.customer_invoice.customer_invoice_entry.labels.destStateProvPG						= 	'Destination State/Prov.1';
Modules.customer_invoice.customer_invoice_entry.labels.destZipPostalCdPG					= 	'Destination Zip/Postal Code1';
Modules.customer_invoice.customer_invoice_entry.labels.tndrReqDtPG							= 	'Tender/Request Date1';
Modules.customer_invoice.customer_invoice_entry.labels.shipntDtPG							= 	'Shipment Date1';
Modules.customer_invoice.customer_invoice_entry.labels.delCmpltDtPG							= 	'Delivery/Completion Date1';
Modules.customer_invoice.customer_invoice_entry.labels.origOrgPG							= 	'Original Origin1';
Modules.customer_invoice.customer_invoice_entry.labels.finalDestPG							= 	'Final Destination1';
Modules.customer_invoice.customer_invoice_entry.labels.dist2DestPG							= 	'Distance To Destination1';
Modules.customer_invoice.customer_invoice_entry.labels.valPG								= 	'Value1';
Modules.customer_invoice.customer_invoice_entry.labels.UomPG								= 	'UOM1';
Modules.customer_invoice.customer_invoice_entry.labels.ratingDestPG							= 	'Rating Destination1';
Modules.customer_invoice.customer_invoice_entry.labels.dist2RtngDestPG						= 	'Distance To Rating Destination1';
Modules.customer_invoice.customer_invoice_entry.labels.minNumPG								= 	'Minimum Number1';
Modules.customer_invoice.customer_invoice_entry.labels.prftLossCentPG						= 	'Profit/Loss Center1';
Modules.customer_invoice.customer_invoice_entry.labels.custSlsRgnPG							= 	'Customer Sales Region1';
Modules.customer_invoice.customer_invoice_entry.labels.shmntTypePG							= 	'Shipment Type1';
Modules.customer_invoice.customer_invoice_entry.labels.ordrTypPG							= 	'Order Type1';
Modules.customer_invoice.customer_invoice_entry.labels.abnrmMvTypePG						= 	'Abnormal Move Type1';
Modules.customer_invoice.customer_invoice_entry.labels.dlrCdPG								= 	'Dealer Code1';
Modules.customer_invoice.customer_invoice_entry.labels.suplrCdPG							= 	'Supplier Code1';
Modules.customer_invoice.customer_invoice_entry.labels.consolIdPG							= 	'Consolidation Id1';
Modules.customer_invoice.customer_invoice_entry.labels.consolTypePG							= 	'Consolidation Type1';
Modules.customer_invoice.customer_invoice_entry.labels.uom1PG								= 	'UOM 11';
Modules.customer_invoice.customer_invoice_entry.labels.uom2PG								= 	'UOM 21';
Modules.customer_invoice.customer_invoice_entry.labels.qntty1PG								= 	'Quantity 11';
Modules.customer_invoice.customer_invoice_entry.labels.qntty2PG								= 	'Quantity 21';
Modules.customer_invoice.customer_invoice_entry.labels.rtbsisPG								= 	'Rate Basis1';
Modules.customer_invoice.customer_invoice_entry.labels.ratePG								= 	'Rate1';
Modules.customer_invoice.customer_invoice_entry.labels.srvcAmtPG							= 	'Service Amount1';
Modules.customer_invoice.customer_invoice_entry.labels.taxTypChG							= 	'Tax Type1';
Modules.customer_invoice.customer_invoice_entry.labels.taxPercntChG							= 	'Tax Percentage1';
Modules.customer_invoice.customer_invoice_entry.labels.taxAmtChG							= 	'Tax Amount1';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotSrvcAmt				= 	'Total Service Amount1';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotTaxAmt				= 	'Total Tax Amount1';
Modules.customer_invoice.customer_invoice_entry.labels.custInvcEntryTotAmt					= 	'Total Amount1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormTtl			= 	Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryTtl;
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormInvoiceTlt	=	'Invoice1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormCrdtNote		= 	'Credit Note1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormDbtNote		=	'Debit Note1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormDocTypeTtl	= 	'Document Type1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormInvcTypeTtl	= 	'Invoice Type1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormActual		=	'Actual1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormAcrual		=	'Acrual1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormPaymentDtlsTtl 	=	'Payment Details1';
Modules.customer_invoice.customer_invoice_entry.labels.cstmrInveEntryPopUpFormCurrencyTtl 		= 	'Currency1';
Modules.LblsAndTtls.EventRating = 'Event Rating Query1';







//Modules.LblsAndTtls.supplierInvcStsForOceanTtl			=	'Supplier Invoice Status For Ocean1';



/***********************************************************************/
//#OCEAN SUPPLIER RATES
/***********************************************************************/

Modules.ocean.supplierRates.labels.formTtl='Supplier Rates1';
Modules.ocean.supplierRates.labels.formValidFromDate='Valid From Date1';
Modules.ocean.supplierRates.labels.formValidToDate='Valid To Date1';
Modules.ocean.supplierRates.labels.remark='Remark1';
Modules.ocean.supplierRates.labels.gridContrctId='Contract Id1';
Modules.ocean.supplierRates.labels.gridSupplier='Supplier1';
Modules.ocean.supplierRates.labels.gridSupplierName='Supplier Name1';
Modules.ocean.supplierRates.labels.chargeCode='Charge Code1';
Modules.ocean.supplierRates.labels.effectiveDate='Effective Date1';
Modules.ocean.supplierRates.labels.filter='Filter1';
Modules.ocean.supplierRates.labels.party='Party1';
Modules.ocean.supplierRates.labels.cargoClass='Cargo Class1';
Modules.ocean.supplierRates.labels.cargoType='Cargo type1';
Modules.ocean.supplierRates.labels.seqno='Seq No1';
Modules.ocean.supplierRates.labels.priority='Priority1';
Modules.ocean.supplierRates.labels.tariffCrncyCd='Tariff Currency Code1';
Modules.ocean.supplierRates.labels.luInd='L/U IND1';
Modules.ocean.supplierRates.labels.tariffRate='Tariff Rate1';
Modules.ocean.supplierRates.labels.fixedRate='Fixed Rate1';
Modules.ocean.supplierRates.labels.factorRate='Factor Rate1';
Modules.ocean.supplierRates.labels.factorType='Factor Type1';
Modules.ocean.supplierRates.labels.factorValue='Factor Value1';
Modules.ocean.supplierRates.labels.notChrgble='Not Chargeable1';
Modules.ocean.supplierRates.labels.trnsfrGear='Transfer Gear1';
Modules.ocean.supplierRates.labels.handlngInd='Handling Indicator1';
Modules.ocean.supplierRates.labels.hazardous='Hazardous1';
Modules.ocean.supplierRates.labels.steering='Steering1';
Modules.ocean.supplierRates.labels.pfd='PFD1';
Modules.ocean.supplierRates.labels.por='POR1';
Modules.ocean.supplierRates.labels.podCntry='POD Country1';
Modules.ocean.supplierRates.labels.podStateProv='POD State/Prov1';
Modules.ocean.supplierRates.labels.podCity='POD City1';
Modules.ocean.supplierRates.labels.polCntry='POL Country1';
Modules.ocean.supplierRates.labels.polStateProv='POL State/Prov1';
Modules.ocean.supplierRates.labels.polCity='POL City1';
Modules.ocean.supplierRates.labels.model='Model1';
Modules.ocean.supplierRates.labels.makeCode='Make Code1';
Modules.ocean.supplierRates.labels.servLevelValDats='Service Level Valid Dates1';

//#STATE PROVINCE MASTER
/**********************************/
Modules.Masters.State_Province_Master.labels.code='Code1';
Modules.Masters.State_Province_Master.labels.name='Name1';
Modules.Masters.State_Province_Master.labels.countryCode='Country Code1';

/*********************************/

/***********************************************************************/
//#COMPANY_CODE_MAPPER
/***********************************************************************/
Modules.Masters.Company_Mapper.labels.partnerGroup= 'Partner Group1';
Modules.Masters.Company_Mapper.labels.externalCompanyCode = 'External Company Code1';
Modules.Masters.Company_Mapper.labels.internalCompanyCode = 'Internal Company Code1';

/***********************************************************************/
//#HOLIDAY_MASTER
/***********************************************************************/
Modules.Masters.Holiday_Master.labels.date = 'Date1';
Modules.Masters.Holiday_Master.labels.description = 'Description1';

Modules.ocean.customer_invoice.ApplicationAdviseOnHoldWinTitle = 'Coustomer Invoice Application Advice On Hold';

/***********************************************************************/
//#ORDER_TYPE_MASTER
/***********************************************************************/
Modules.Masters.Order_Type_Master.labels.customerCode = 'Customer Code1';
Modules.Masters.Order_Type_Master.labels.customerName ='Customer Name1';
Modules.Masters.Order_Type_Master.labels.code ='Code1';
Modules.Masters.Order_Type_Master.labels.description = 'Description1';


//START ADMIN GROUP DETAILS SCREEN LABELS

Modules.admin.user_admin.user_management.labels.groupCode='Group Code1';
Modules.admin.user_admin.user_management.labels.groupName='Group Name1';
Modules.admin.user_admin.user_management.labels.groupDesc='Group Description1';
Modules.admin.user_admin.user_management.labels.serviceType='Service Type1';
Modules.admin.user_admin.user_management.labels.groupToUserAssociation='Group To User Association1';
Modules.admin.user_admin.user_management.labels.groupToFunctionAssociation='Group To Function Association1';
Modules.admin.user_admin.user_management.labels.groupToMenuAssociation='Group To Menu Association1';
Modules.admin.user_admin.user_management.labels.functionButton='Function1';
Modules.admin.user_admin.user_management.labels.apply='Apply1';
Modules.admin.user_admin.user_management.labels.close='Close1';
Modules.admin.user_admin.user_management.labels.deniedMenus='Denied Menus1';
Modules.admin.user_admin.user_management.labels.groupDetails='Group Details1';
Modules.admin.user_admin.user_management.labels.properties='Properties1';
Modules.admin.user_admin.user_management.labels.newGroup='New Group1';
Modules.admin.user_admin.user_management.labels.deleteGroup='Delete Group1';
Modules.admin.user_admin.user_management.labels.copyGroup='Copy Group1';
Modules.admin.user_admin.user_management.labels.add='ADD1';
Modules.admin.user_admin.user_management.labels.addAll='ADD ALL1';
Modules.admin.user_admin.user_management.labels.remove='REMOVE1';
Modules.admin.user_admin.user_management.labels.removeAll='REMOVE ALL1';
Modules.admin.user_admin.user_management.labels.save='Save1';
Modules.admin.user_admin.user_management.labels.availableUsers='Available Users1';
Modules.admin.user_admin.user_management.labels.assignedValues='Assigned Values1';
Modules.admin.user_admin.user_management.labels.listOfFunctions='List of Functions1';
Modules.admin.user_admin.user_management.labels.type='Type1';
Modules.admin.user_admin.user_management.labels.functionName='Function Name1';
Modules.admin.user_admin.user_management.labels.ok='OK1';
Modules.admin.user_admin.user_management.labels.moduleName='Module Name1';
Modules.admin.user_admin.user_management.labels.name='Name1';



//END ADMIN GROUP DETAILS SCREEN LABELS

