

//Following will hold the all the variables to be used across the application
Ext.ns('Modules.GlobalVars');

//Following will hold the all the functions to be used across the application
Ext.ns('Modules.GlobalFuncs');

/**
	**Following will hold the all the variables carrying values related to labels and titles
	**The main purpose of using this is to support l11n and i18n
	**This is not further divided as per the windows due to the reason that same labels/titles can be used acrossed multiple windows
	**Any variable added to this namespace should end with either Ttl or Lbl and should also have some indication about the purpose, for example
	Modules.LabelsAndTitles.viaFieldLabel = 'VIA';
**/
Ext.ns('Modules.LblsAndTtls');
Ext.ns('Modules.LblsAndTtls.tooltip');
Ext.nsCmc('Modules.contract.supplier.oceansupplierRateVerification');
Ext.nsCmc('Modules.ocean.lov_factory');
Ext.nsCmc('Modules.contract.supplier.oceansupplierRateQueryServiceCode');

/**
	**Following will hold the all the variables carrying values related to messages
	**The main purpose of using this is to support l11n and i18n
	**This is not further divided as per the windows due to the reason that same messages can be used acrossed multiple windows
	**Any variable added to this namespace should end with Msg and should also have some indication about the purpose
**/
Ext.ns('Modules.Msgs');

/**
	**Following will hold the all the variables carrying values related to components ids
	**The main purpose of using this is to maintain the uniqueness of each id in the application
	**Through out the application, in place of ids, only the corresponding variables should be used
	**Any variable added to this namespace should end with Id and should also have some indication about the purpose as well the window/form/grid whose part its supposed to be, for example, Modules.CompIds.viaNoVoyageMonitoringId	=	'viaNoVoyageMonitoringId';
	**Note that here the name of variable under the namespace could be same as its value. This way uniqueness would be easier to maintain as in the example above
**/

Ext.ns('Modules.CompIds');
//Following will be used for writing the names
Ext.ns('Modules.CompNames');

Ext.ns('Modules.LovFactory');
Ext.nsCmc('Modules.ocean.lov_factory');// for labels

//Following is used to hold the name of the edi module
Ext.ns('Modules.edi.purge_details');
Ext.ns('Modules.edi.eventlog');

Ext.ns('Modules.test');
Ext.ns('Modules.OceanInvoice');
Ext.ns('Modules.Dashboard');
Ext.ns('Modules.edi.SwimUI');
Ext.ns('Modules.edi.SwimUI.quartz_job_dtls');
Ext.ns('Modules.edi.SwimUI.quartz_job_dtls.labels');
Ext.ns('Modules.edi.swim_ui.audit_exception.labels');
Ext.ns('Modules.StatusMonitoringAndControlNonOcean');
Ext.ns('Modules.StatusMonitoringAndControlOcean');
Ext.ns('Modules.Masters');
Ext.ns('Modules.Masters.GeneralMasters');
Ext.ns('Modules.Masters.InvoiceMasterManagement');

Ext.ns('Modules.operations.event_details');
Ext.ns('Modules.operations.event_details.transportationEvent');
Ext.ns('Modules.operations.event_details.technicalEvent');
Ext.ns('Modules.operations.special_moves');
Ext.ns('Modules.customer.customer_rate_verificatoin');
Ext.nsCmc('Modules.contract.customer_rate_query');

Ext.ns('Modules.Contract.Customer.customer_rate');

Ext.nsCmc('Modules.contract.customer_master');
Ext.nsCmc('Modules.contract.customer_master.searchForm');
Ext.nsCmc('Modules.contract.customer_master.tabpanel');
Ext.nsCmc('Modules.contract.customer_master.tabparentpanel');
Ext.nsCmc('Modules.contract.customer_master.popupGridWindow');
Ext.nsCmc('Modules.contract.customer_master.contractIdentification.popupGridWindow');
Ext.nsCmc('Modules.contract.customer_master.defaultSupplier.popupGridWindow');
Ext.nsCmc('Modules.contract.customer_master.distanceRoundingCriteria.popupGridWindow');
Ext.nsCmc('Modules.contract.customer_master.rateRoundingCriteria.popupGridWindow');


Ext.ns('Modules.contract.customer.customerdebtorpartytabparentpanel');
Ext.ns('Modules.contract.customer.customer_debtor_party.popupGridWindow');

Ext.ns('Modules.contract.customer.customer_debtor_party.popupGridWindow');

Ext.ns('Modules.Customer.CustomerRateVerificatoin');
Ext.ns('Modules.contract.customer_rate_verificatoin');
Ext.ns('Modules.contract.customer_rate_verificatoin.popupGridWindow');



Ext.ns('Modules.contract.customer.customer_rate_query_service_code');




Ext.ns('Modules.contract');
Ext.ns('Modules.contract.customer');
Ext.ns('Modules.contract.customer.cstSrvGrpSetup');
Ext.ns('Modules.contract.customer.oceanCstmrSrvGrpSetup');
Ext.ns('Modules.supplierInvoice.supplierRemittanceDetails');



Ext.nsCmc('Modules.Contract.Customer.customer_invoice_setup');
Ext.ns('Modules.Contract.customer_invoice.customerInvoiceSetup');
Ext.ns('Modules.Contract.Customer.customer_invoice');
Ext.ns('Modules.Customer_Invoice_Entry');
Ext.nsCmc('Modules.Customer_Payment_Dtls');
Ext.nsCmc('Modules.customer_invoice.customer_payment_dtls.labels');
Ext.nsCmc('Modules.customer_invoice.customer_payment_dtls.tooltip');
Ext.nsCmc('Modules.customer_invoice.customer_payment_dtls.messages');
Ext.ns('Common.CustomerInvcEntry');
Ext.ns('Modules.ocean.oceansupplierratequeryservice');
Ext.nsCmc('Modules.Masters.General_Master');
Ext.ns('Modules.customer_invoice.customer_invoice_status.customerInvoiceStatusform');
Ext.ns('Modules.customer_invoice');
Ext.ns('Modules.customer_invoice.customer_invoice_status.popupGridWindow');
Ext.ns('Modules.customer_invoice.customer_invoice_status.popupPrintWindow');



Ext.nsCmc('Modules.ocean.customer_invoice.customer_invoice_status');

Ext.nsCmc('Modules.Ocean.Masters.CargoTypeMaster');
Ext.nsCmc('Modules.Ocean.Masters.PortTypeMaster');
Ext.nsCmc('Modules.Masters.Currency_Mapper');
Ext.nsCmc('Modules.Masters.Rate_Basis_Mapper');

Ext.nsCmc('Modules.Masters.Transport_Mode_Master');
Ext.nsCmc('Modules.Masters.Conveyanca_Type_Master');
Ext.nsCmc('Modules.Masters.Profit_Loss_Centre_Master');
Ext.nsCmc('Modules.Masters.Country_Master');
Ext.nsCmc('Modules.Masters.Service_Code_GlMapper');
Ext.nsCmc('Modules.Masters.Company_TaxType_Mapper');
Ext.nsCmc('Modules.Masters.TaxType_Master');
Ext.nsCmc('Modules.Common_Operation');
Ext.nsCmc('Modules.Master_Titles');
Ext.nsCmc('Modules.ocean.custEventStatusSummary');
Ext.nsCmc('Modules.Customer.CustomerRateVerificatoin.labels');

Ext.nsCmc('Modules.operations.event_details.event_rating_query');

Ext.nsCmc('Modules.contract.ocean_customer_master');
Ext.nsCmc('Modules.contract.ocean_customer_master.popupGridWindow');

Ext.nsCmc('Modules.ocean.supplier.supplier_rate_verificatoin');
Ext.nsCmc('Modules.supplier.supplier_rate_verificatoin');
Ext.nsCmc('Modules.supplier.supplier_rate_verificatoin.popupGridWindow');
Ext.nsCmc('Modules.ocean.supplier.supplier_rate_verificatoin');
Ext.nsCmc('Modules.contract.supplier.supplierRateVerification.labels');

Ext.nsCmc('Modules.ocean.contract.customer_rate_verificatoin');
Ext.nsCmc('Modules.contract.customer.oceanCustomerRateVerification');

Ext.nsCmc('Modules.contract.ocean_customer_master.oceanContractIdentification.popupGridWindow');
Ext.nsCmc('Modules.contract.ocean_customer_master.oceanValueRoundingCriteria.popupGridWindow');
Ext.nsCmc('Modules.contract.ocean_customer_master.partytype.popupGridWindow');
Ext.nsCmc('Modules.contract.ocean_customer_master.creditTermLimit.popupGridWindow');
Ext.nsCmc('Modules.contract.ocean_customer_master.oceanContactDetails');
Ext.nsCmc('Modules.contract.ocean_customer_master.oceanVolvoMsgDetails');

Ext.nsCmc('Modules.Ocean.customer_invoice.customer_invoice_generation.generate_invoice');


Ext.nsCmc('Modules.ocean.operations.event_details.event_rating_query');
Ext.nsCmc('Modules.ocean.operations.event_details.event_rating_query.tabpanel');
Ext.nsCmc('Modules.ocean.operations.event_details.event_rating_query.tabparentpanel');

Ext.nsCmc('Modules.supplier_invoice.supplier_line_item_status');


Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_status');
Ext.nsCmc('Modules.SpplrInvc.SupplrInvcSts.label');
Ext.nsCmc('Modules.Ocean.customer_invoice.customer_invoice_setup');
Ext.nsCmc('Modules.Ocean.CustInvcSetup.labels');


//******supplier master ocean+ customer contract query ocean ***************************************************************************************************************************************
	Ext.ns('Modules.contract.supplier_master');
	Ext.ns('Modules.contract.supplier_master.tabparentpanel');
	
	Ext.ns('Modules.ocean.contract.customer_rate_query');
	Ext.ns('Modules.contract.customer_master.tabpanel');
//**********************************************************************************************************************************
	Ext.nsCmc('Modules.Masters.Transport_Mode_Mapper');

	
	Ext.nsCmc('Modules.Masters.UOMCodeMapper'); 
	
	

	Ext.nsCmc('Modules.Masters.Shipment_Type_Mapper');
	Ext.nsCmc('Modules.Ocean.Masters.Commodity_Master');
	Ext.nsCmc('Modules.contract.supplier.oceansupplierRateVerification');
	
	Ext.ns('Modules.contract.ocean_customer_master.oceanPrintTemplate.popupGridWindow');
	
	
	Ext.nsCmc('Modules.ocean.customer_invoice.ocean_customer_invoice_entry');
	Ext.nsCmc('Modules.contract.supplier.supplierRates');
	Ext.nsCmc('Modules.ocean.supplierRates');
	Ext.nsCmc('Modules.ocean.supplierRateQuery');
	
	Ext.nsCmc('Modules.ocean.customer_invoice.customer_line_item_status');
	Ext.nsCmc('Modules.customer_invoice.customer_invoice_entry');
	Ext.nsCmc('Modules.customer_invoice.customer_invoice_entry.tooltip');
	Ext.nsCmc('Modules.Masters.State_Province_Master');
	Ext.nsCmc('Modules.Masters.Company_Mapper');
	Ext.nsCmc('Modules.Masters.Holiday_Master');
	Ext.nsCmc('Modules.Masters.Order_Type_Master');
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_reconciliation');
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_reconciliation.labels');
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_reconciliation.tooltip');
/*****************Ocean Event Details*******************/
	

	Ext.nsCmc('Modules.ocean.operations.event_details');
    Ext.nsCmc('Modules.ocean.contract.customer');

	Ext.nsCmc('Modules.ocean.operations.event_details.supplier_event_status_summary');

	
	Ext.nsCmc('Modules.Ocean.customer_invoice.customer_application_advice');
	Ext.nsCmc('Modules.customer_invoice.customer_application_advice.labels');

	Ext.ns('Modules.ocean.contract.customer.customer_payment_details');
	Ext.ns('Modules.ocean.contract.customer.customer_payment_details.grid');
	

	Ext.nsCmc('Modules.admin.application_monitoring.change_log');
	
	Ext.nsCmc('Modules.ocean.supplierInvoice.supplierRemittanceDetails');
	

/*****************Ocean Supplier Invoice Status*******************/
	
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_invoice_status');

	


/*****************Ocean Supplier Rate Query*******************/
	
	Ext.nsCmc('Modules.ocean.supplier_rate.supplier_rate_query');

	

	
	
	
	
	Ext.nsCmc('Modules.admin.user_admin.group_user_security');

	Ext.nsCmc('Modules.admin.journal');
	
	Ext.nsCmc('Modules.ocean.admin.ocean_journal');



	
	Ext.nsCmc('Modules.admin');
	Ext.nsCmc('Modules.admin.auditlog');
	
	Ext.nsCmc('Modules.customer_invoice.ApplicationAdviseOnHold');

	Ext.nsCmc('Modules.admin.internalAdmin.databaseErrorLog');
	
	Ext.nsCmc('Modules.ocean.ocean_customer_rate_query_service_code.ocean_customer_rate_query_service_parent_tab_panel');
	Ext.nsCmc('Modules.ocean.ocean_customer_rate_query_service_code');


	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_invoice_status');

	Ext.nsCmc('Modules.admin.user_admin.user_management');

	/*****************Ocean Supplier Automatic Invoice*******************/
	Ext.nsCmc('Modules.ocean.supplier_invoice');
	
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_automatic_invoice');
	
	Ext.nsCmc('Modules.Masters.Uom_RateBasis_Master');
	Ext.nsCmc('Modules.ocean.customer_invoice.customer_reconciliation');
	Ext.nsCmc('Modules.ocean.customer_invoice.customer_reconciliation.labels');
	Ext.nsCmc('Modules.Ocean.customer_invoice.customer_reconciliation.messages');
	Ext.nsCmc('Modules.Masters.Uom_RateBasis_Master');
	
	Ext.nsCmc('Modules.Masters.Part_Type_Master');
	
	Ext.nsCmc('Modules.ocean.customer_invoice.ocean_customer_invoice_entry_consolidate');
	
	/* Ocean Supplier Line Item Status */
	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_line_item_status');

	Ext.nsCmc('Modules.ocean.supplier_invoice.supplier_line_item_status.label');
	Ext.nsCmc('Modules.Masters.location_master');
	
	Ext.nsCmc('Modules.ocean.admin.user_admin.user_management');
	Ext.nsCmc('Modules.ocean.admin.user_admin.group_user_security');
	Ext.nsCmc('Modules.admin.user_admin.group_user_security.messages');
	Ext.nsCmc('Modules.Msgs.customer_invoice.customer_app_advc');
	Ext.ns('Modules.ocean.master.genaralmaster.voyagemaster');
	
	Ext.nsCmc('Modules.Masters.Port_Master');
	
	Ext.nsCmc('Modules.Ocean.Masters.BankDetails_Master');

/***********************************************************************
*			Start:Ocean Supplier Reconcilation Setup
************************************************************************/
	Ext.nsCmc('Modules.Ocean.supplier.supplier_reconcilation_setup');   
/***********************************************************************
*			End:Ocean Supplier Reconcilation Setup
************************************************************************/
	Ext.ns('Modules.ocean.master.genaralmaster.clausemaster');

Ext.nsCmc('Modules.Masters.ocean.Clause_Master.labels');

Ext.nsCmc('Modules.Ocean.Masters.POP_master');

Ext.nsCmc('Modules.ocean.supplier_invoice.vendor_invoice_template');
Ext.nsCmc('Modules.ocean.supplier_invoice.vendor_invoice_template.labels');

Ext.nsCmc('Modules.Masters.GeneralMasters.CompanyMaster');

Ext.nsCmc('Modules.Ocean.Master_Titles');

Ext.nsCmc('Modules.Masters.Country_State_Mapper.labels');


Ext.nsCmc('Modules.Masters.GeneralMasters.Ocean.CompanyMaster');

//Ext.nsCmc('Modules.Master.EquipmentMaster');
Ext.nsCmc('Modules.Masters.Time_Zone_Mapper');

Ext.nsCmc('Modules.Masters.Company');

Ext.nsCmc('Modules.Masters.Company.CompanyMaster');


Ext.nsCmc('Modules.Ocean.Dashboard');

Ext.nsCmc('Modules.customer_invoice.application_advice_onHold');

Ext.nsCmc('Modules.Ocean.Dashboard');

Ext.nsCmc('Modules.supplier_invoice.supplier_reconciliation');
Ext.nsCmc('Modules.CompIds.suplierInvoice');
Ext.nsCmc('Modules.supplier_invoice.supplier_reconciliation.labels');

Ext.nsCmc('Modules.Ocean.Dashboard');

Ext.nsCmc('Modules.contract.supplier.supplierRates');
Ext.nsCmc('Modules.supplierRates.labels');
Ext.nsCmc('Modules.lov_factory.labels');
Ext.nsCmc('Modules.customer_invoice.customer_application_advice');

Ext.nsCmc('Modules.Mappers.MarketArea');

Ext.nsCmc('Modules.Masters.Fuel_Surcharge_Index_Master');

Ext.nsCmc('Modules.customer_invoice.customer_line_item_status');
Ext.nsCmc('Modules.contract.supplier');

Ext.nsCmc('Modules.contract.supplier.supplier_auto_invoice');
Ext.nsCmc('Modules.contract.supplier.supplier_rate_query_service_code');

Ext.nsCmc('Modules.contract.supplier.supRateRecon.labels');
Ext.nsCmc('Modules.contract.supplier.supRateRecon.tooltip');
Ext.nsCmc('Modules.contract.supplier.supplier_auto_invoice');
Ext.nsCmc('Modules.supplier.supplier_reconcilation_setup'); 
Ext.nsCmc('Modules.contract.supplier.supplier_auto_invoice');

Ext.nsCmc('Modules.LocationCode.Mapper');
Ext.nsCmc('Modules.LocationCode.Mapper');


Ext.nsCmc('Modules.contract.supplier.supplierMaster');


Ext.nsCmc('Modules.Masters.Model_Master');


Ext.nsCmc('Modules.Masters.Plant_Name_Mapper');

Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.us_canada_truck_move.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.mexico_truck_move.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.rail_invoice_entry');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.ocean_invoice_entry');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.ocean_invoice_entry.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.service_charge_invoice_entry');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.service_charge_invoice_entry.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.general_invoice_entry');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.general_invoice_entry.labels');
Ext.nsCmc('Modules.supplier_invoice.supplier_invoice_entry.rail_invoice_entry.labels');
Ext.nsCmc('Modules.reports');
Ext.nsCmc('Modules.reports.supplier_payment');
Ext.nsCmc('Modules.customer_invoice.customer_line_item_status');
Ext.nsCmc('Modules.contract.supplier.supplierRateQueryServiceCode');
Ext.nsCmc('Modules.Masters.Consolidation_Type_Mapper');
Ext.nsCmc('Modules.Mappers.Application_Advice_Mapper');	
Ext.nsCmc('Modules.Masters.Model_Group_Mapper');	
Ext.nsCmc('Modules.customer_invoice.customer_invoice_generation');



Ext.nsCmc('Modules.customer_invoice.customer_invoice_entry_consol');
Ext.nsCmc('Modules.Customer_Invoice_Entry_Consol');


Ext.nsCmc('Modules.Masters.Customer_Mapper');
Ext.nsCmc('Modules.Masters.Supplier_Mapper');

Ext.nsCmc('Modules.customer_invoice.customer_invoice_generation.generate_invoice.labels');
Ext.nsCmc('Modules.customer_invoice.customer_invoice_generation.generate_invoice');
Ext.nsCmc('Modules.InvoiceMasterManagement.fuelSurchargeProgramMaster');

Ext.nsCmc('Modules.Masters.Supplier_Mapper');

Ext.nsCmc('Modules.customer_invoice.customer_reconsiliation');
Ext.nsCmc('Modules.Masters.Abnormal_Move_Type_Mapper');

Ext.nsCmc('Modules.contract.supplier.supplier_rate_query');
Ext.nsCmc('Modules.contract.supplier.supplierRateQuery');
Ext.nsCmc('Modules.OutboundMessage.Mapper');
Ext.nsCmc('Modules.reports.supplier_invoice_aging');
Ext.nsCmc('Modules.ConveyanceType.Mapper');
Ext.nsCmc('Modules.reports.tax_report');
Ext.nsCmc('Modules.reports.supplier_expense');
Ext.nsCmc('Modules.reports.fuel_surcharge');
Ext.nsCmc('Modules.reports.customer_revenue');
Ext.nsCmc('Modules.reports.supplier_expense');
Ext.nsCmc('Modules.reports.fuel_surcharge');
Ext.nsCmc('Modules.reports.vin_cost_revenue_history');
Ext.nsCmc('Modules.OrderType.Mapper');
Ext.nsCmc('Modules.Masters.Rate_Tier_Mapper');
Ext.nsCmc('Modules.Masters.Make_Model_Mapper');
Ext.nsCmc('Modules.reports.supplier_rate');
Ext.nsCmc('Modules.Master.InvoiceChargeTypeMapper');
Ext.nsCmc('Modules.InvoiceMasterManagement.fuelSurchargeIndexValueMaster');
Ext.nsCmc('Modules.Master.TariffMaster');
Ext.nsCmc('Modules.Masters.Service_Tax_Mapper');
Ext.nsCmc('Modules.Master.ServiceMaster');
Ext.nsCmc('Modules.LblsAndTtls.custReconcilation');
Ext.nsCmc('Modules.Master.ProfitLossCenterMaster');
Ext.nsCmc('Modules.Masters.Currency');
Ext.nsCmc('Modules.Master.Ocean.ProfitLossCenterMaster');
Ext.nsCmc('Common.CustomerInvcEntryConsol');

Ext.nsCmc('Modules.contract.customer.customerdebtorparty');

Ext.nsCmc('Modules.Ocean.Masters.OceanCountryCodeRevenueMaster');
Ext.nsCmc('Modules.Masters.ocean.cargoClassRevenueMaster.labels');
Ext.ns('Modules.edi.autoReprocessErrorMessage');
Ext.nsCmc('Modules.common');

Ext.nsCmc('Modules.ocean.ocean_customer_invoice.ocean_customer_invoice_consolidate');
Ext.nsCmc('Modules.ocean.ocean_customer_invoice.ocean_customer_invoice');


/*******************DPW component IDs***************************/
Ext.nsCmc('Modules.Common_Operation.labels');


Ext.nsCmc('Modules.Master.ActivityCodeMaster');
Ext.nsCmc('Modules.Master.ActivityTypeMaster');

Ext.ns('Modules.Master.EquipmentMaster');

Ext.nsCmc('Modules.Master.UserMaster');
Ext.nsCmc('Modules.Master.RoleMaster');
Ext.nsCmc('Modules.Master.PinningStationMaster');
Ext.nsCmc('Modules.Master.MoveTypeMaster');
Ext.nsCmc('Modules.Master.DirectionMaster');
Ext.nsCmc('Modules.Master.ChecklistMaster');
Ext.nsCmc('Modules.Master.QC_LaneMaster');
Ext.nsCmc('Modules.Master.TerminalMaster');
Ext.nsCmc('Modules.Master.LanguageMaster');
Ext.nsCmc('Modules.Master.DeviceMaster');
Ext.nsCmc('Modules.Master.DamageCodeMaster');
Ext.nsCmc('Modules.Master.DamageSeverityMaster');
Ext.nsCmc('Modules.Master.TroubleShootAreaMaster');
Ext.nsCmc('Modules.Master.DelayReasonCodeMaster');            
Ext.nsCmc('Modules.Master.ApplicationParameterMaster');
Ext.nsCmc('Modules.Master.UnplannedActivitiesMaster');
Ext.nsCmc('Modules.Master.ShiftMaster');
Ext.nsCmc('Modules.Master.AlertCodeMaster');
Ext.nsCmc('Modules.Master.DirectionMaster');
Ext.nsCmc('Modules.Master.LanguageMaster');
Ext.nsCmc('Modules.Master.MoveTypeMaster');
Ext.nsCmc('Modules.Master.TerminalMaster');
Ext.nsCmc('Modules.Master.RoleMaster');
Ext.nsCmc('Modules.Master.UserMaster');
Ext.nsCmc('Modules.Master.UnitMaster');
Ext.nsCmc('Modules.Master.GenericChecklistMaster');
Ext.nsCmc('Modules.Master.ColorCodeMaster');
Ext.nsCmc('Modules.Master.VesselMaster');
Ext.nsCmc('Modules.Master.CheckListHeaderMaster');
Ext.nsCmc('Modules.Master.RotationControlMaster');
Ext.nsCmc('Modules.Master.YardBlockMaster');
Ext.nsCmc('Modules.Master.DamageLocationMaster');
Ext.nsCmc('Modules.Master.DamageTypeMaster');
Ext.nsCmc('Modules.Master.TemplateMaster');
Ext.nsCmc('Modules.Master.VesselExceptionMaster');
Ext.nsCmc('Modules.Master.BusinessExceptionMaster');
Ext.nsCmc('Modules.Master.DelayRecordingMaster');
Ext.nsCmc('Modules.Master.TrailerMaster');
Ext.nsCmc('Modules.Master.AlertConfigurationMaster');
Ext.nsCmc('Modules.Master.RollbackRotation');

Ext.nsCmc('Modules.Master.AlertRecordMaster');
Ext.nsCmc('Modules.Master.WeightageFactorMaster');
Ext.nsCmc('Modules.Master.UserMonitor');


/************************ end *******************/