String.prototype.capitalize = function(input) {
	var tempString = input.charAt(0).toUpperCase() + input.slice(1);
	var finalString = tempString.replace(/([a-z])([A-Z])/g, '$1 $2');
    return finalString ;
}

function getDropDownList(name, id, optionList) {
    var combo = $("<select></select>").attr("id", id).attr("name", name);

    $.each(optionList, function (i, el) {
        combo.append("<option value= " + el +">" + el + "</option>");
    });

    return combo;
    // OR
  //  $("#SELECTOR").append(combo);
}

function maxWindow() {
    /*window.moveTo(0, 0);


    if (document.all) {
        top.window.resizeTo(screen.availWidth, screen.availHeight);
    }

    else if (document.layers || document.getElementById) {
        if (top.window.outerHeight < screen.availHeight || top.window.outerWidth < screen.availWidth) {
            top.window.outerHeight = screen.availHeight;
            top.window.outerWidth = screen.availWidth;
        }
    }*/
	var el = document.documentElement
	, rfs = // for newer Webkit and Firefox
	       el.requestFullScreen
	    || el.webkitRequestFullScreen
	    || el.mozRequestFullScreen
	    || el.msRequestFullScreen
	;
	if(typeof rfs!="undefined" && rfs){
	  rfs.call(el);
	} else if(typeof window.ActiveXObject!="undefined"){
	  // for Internet Explorer
	  var wscript = new ActiveXObject("WScript.Shell");
	  if (wscript!=null) {
	     wscript.SendKeys("{F11}");
	  }
	}
}


function addExtraCommonFields(){

var vesselTypeDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var vesselTypeLbl = document.createElement('label');
$(vesselTypeLbl).addClass("popupLabel").text("Vessel Type");
$(dt).append(vesselTypeLbl) ;

var vesselTypeField = document.createElement('input');
$(vesselTypeField).attr("id","popupvesselType");//.attr("autofocus"); 
$(vesselTypeField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","vesselTypeMssgSection").addClass("MssgSection") ;
$(dd).append(vesselTypeField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(vesselTypeDiv).append(dl) ;
$('#osx-modal-data').append(vesselTypeDiv);

var maxRowDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var lengthLbl = document.createElement('label');
$(lengthLbl).addClass("popupLabel").text("Max Rows");
$(dt).append(lengthLbl) ;

var maxRowsField = document.createElement('input');
$(maxRowsField).attr("id","popupMaxrows");//.attr("autofocus"); 
$(maxRowsField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","MaxrowsMssgSection").addClass("MssgSection") ;
$(dd).append(maxRowsField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(maxRowDiv).append(dl) ;
$('#osx-modal-data').append(maxRowDiv);

var lengthDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var lengthLbl = document.createElement('label');
$(lengthLbl).addClass("popupLabel").text("Length (meters)");
$(dt).append(lengthLbl) ;

var lengthField = document.createElement('input');
$(lengthField).attr("id","popuplength");//.attr("autofocus"); 
$(lengthField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","lengthMssgSection").addClass("MssgSection") ;
$(dd).append(lengthField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(lengthDiv).append(dl) ;
$('#osx-modal-data').append(lengthDiv);

var widthDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var widthLbl = document.createElement('label');
$(widthLbl).addClass("popupLabel").text("Width (meters)");
$(dt).append(widthLbl) ;

var widthField = document.createElement('input');
$(widthField).attr("id","popupwidth");//.attr("autofocus"); 
$(widthField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","widthMssgSection").addClass("MssgSection") ;
$(dd).append(widthField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(widthDiv).append(dl) ;
$('#osx-modal-data').append(widthDiv);


var heightDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var heightLbl = document.createElement('label');
$(heightLbl).addClass("popupLabel").text("Height (meters)");
$(dt).append(heightLbl) ;

var heightField = document.createElement('input');
$(heightField).attr("id","popupheight");//.attr("autofocus"); 
$(heightField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","heightMssgSection").addClass("MssgSection") ;
$(dd).append(heightField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(heightDiv).append(dl) ;
$('#osx-modal-data').append(heightDiv);



var teuCapacityDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var teuCapacityLbl = document.createElement('label');
$(teuCapacityLbl).addClass("popupLabel").text("Teu Capacity");
$(dt).append(teuCapacityLbl) ;

var teuCapacityField = document.createElement('input');
$(teuCapacityField).attr("id","popupteuCapacity");//.attr("autofocus"); 
$(teuCapacityField).attr("type","text");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","teuCapacityMssgSection").addClass("MssgSection") ;
$(dd).append(teuCapacityField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(teuCapacityDiv).append(dl) ;
$('#osx-modal-data').append(teuCapacityDiv);


var motherFeederIndDiv = document.createElement('div');
var dl = document.createElement("dl");
$(dl).addClass("staticHeight");
var dt = document.createElement("dt");
var dd = document.createElement("dd");
var motherFeederIndLbl = document.createElement('label');
$(motherFeederIndLbl).addClass("popupLabel").text("Mother/Feeder");
$(dt).append(motherFeederIndLbl) ;

var mfOptions = ["M","F"] ;

var motherFeederIndField = getDropDownList("mfSelect","mfSelect",mfOptions);//document.createElement('input');
$(motherFeederIndField).attr("id","popupmotherFeederInd");//.attr("autofocus"); 
$(motherFeederIndField).addClass("popupSelect");//.attr("min","1"); 
var errorMssgSpan = document.createElement('span');
$(errorMssgSpan).attr("id","motherFeederIndMssgSection").addClass("MssgSection") ;
$(dd).append(motherFeederIndField).append(errorMssgSpan) ;
$(dl).append(dt).append(dd) ;

$(motherFeederIndDiv).append(dl) ;
$('#osx-modal-data').append(motherFeederIndDiv);


}

function showvesselCreationPopup(title,content,vesselInfo){
	$('#osx-modal-title').html('');
	$('#osx-modal-data').html('');
	
	$('#osx-modal-title').css("color","black").html(title);
	/*var div = document.createElement('div');
	var lbl = document.createElement('label');
	$(lbl).text(title);
	$(div).append(lbl);
	$('#osx-modal-data').append(div).append("</br>");*/
	var divContent = document.createElement('div');
	var labelContent = document.createElement('label');
	$(labelContent).addClass("popupLabel").text(content);
	$(divContent).html(labelContent);
	$('#osx-modal-data').append(divContent).append("</br>");
	
	var VesselNoDiv = document.createElement('div');
	var dl = document.createElement("dl");
	$(dl).addClass("staticHeight");
	var dt = document.createElement("dt");
	var dd = document.createElement("dd");
	var VesselNoLbl = document.createElement('label');
	$(VesselNoLbl).addClass("popupLabel").text("Vessel Code");
	$(dt).append(VesselNoLbl) ; 
	
	var VesselNoField = document.createElement('input');
	$(VesselNoField).attr("id","popupVesselNo").attr("autofocus"); 
	$(VesselNoField).attr("type","text");
	//.attr("type","number").attr("min","1"); 
	var errorMssgSpan = document.createElement('span');
	$(errorMssgSpan).attr("id","VesselNoMssgSection").addClass("MssgSection") ;
	$(dd).append(VesselNoField).append(errorMssgSpan) ;
	$(dl).append(dt).append(dd) ;
		
	$(VesselNoDiv).append(dl) ;
	$('#osx-modal-data').append(VesselNoDiv);
	
	var vesselNameDiv = document.createElement('div');
	var dl = document.createElement("dl");
	$(dl).addClass("staticHeight");
	var dt = document.createElement("dt");
	var dd = document.createElement("dd");
	var vesselNameLbl = document.createElement('label');
	$(vesselNameLbl).addClass("popupLabel").text("Vessel Name");
	$(dt).append(vesselNameLbl) ;
	
	var vesselNameField = document.createElement('input');
	$(vesselNameField).attr("id","popupvesselName");//.attr("autofocus"); 
	$(vesselNameField).attr("type","text");//.attr("min","1"); 
	var errorMssgSpan = document.createElement('span');
	$(errorMssgSpan).attr("id","vesselNameMssgSection").addClass("MssgSection") ;
	$(dd).append(vesselNameField).append(errorMssgSpan) ;
	$(dl).append(dt).append(dd) ;
	
	$(vesselNameDiv).append(dl) ;
	$('#osx-modal-data').append(vesselNameDiv);
	
	/*var sectionNoDiv = document.createElement('div');
	var dl = document.createElement("dl");
	$(dl).addClass("staticHeight");
	var dt = document.createElement("dt");
	var dd = document.createElement("dd");
	var sectionNoLbl = document.createElement('label');
	$(sectionNoLbl).addClass("popupLabel").text("Section No. starts from");
	$(dt).append(sectionNoLbl) ;
	
	var sectionNoField = document.createElement('input');
	$(sectionNoField).attr("id","popupsectionNo");//.attr("autofocus"); 
	$(sectionNoField).attr("type","text");
	//.attr("type","number").attr("min","1"); 
	$(sectionNoField).attr("value","120");//.attr("min","1"); 
	var errorMssgSpan = document.createElement('span');
	$(errorMssgSpan).attr("id","sectionNoMssgSection").addClass("MssgSection") ;
	$(dd).append(sectionNoField).append(errorMssgSpan) ;
	$(dl).append(dt).append(dd) ;
		
	$(sectionNoDiv).append(dl) ;
	$('#osx-modal-data').append(sectionNoDiv);
	$(sectionNoDiv).hide();
	$(sectionNoLbl).hide();*/
	
	addExtraCommonFields() ;
	
	
	
	
	div = document.createElement('div');
	$(div).attr("id","formFooter");
	var dt = document.createElement('dt');
	$(dt).attr('style','position:relative;float:left');
	var inp = document.createElement('input');
	$(inp).attr('class','buttonControl').attr('type','button').attr('id','popupContinueBtn');
	$(inp).addClass("secondary disabled");
	$(inp).val('Continue');
	$(dt).append(inp);
	$(div).append(dt);
	
	dt = document.createElement('dt');
	$(dt).attr('style','position:relative;float:right');
	inp = document.createElement('input');
	$(inp).attr('class','buttonControl').attr('type','button').attr('id','popuUpCancelBtn').attr('style','position:relative;float:right');
	$(inp).val('Cancel');
	$(dt).append(inp);
	$(div).append(dt);
	$('#osx-modal-data').append(div);
	
	//$('#osx-container').attr('style','position: fixed; z-index: 1002; height: 124px; width: 450px; left: 449.5px; top: 0px;');
	$('#osx-container').attr('style','position: fixed; z-index: 1002; height: 124px; width: 563px; left:361px; top: 195px;');
	
	if(vesselInfo!=null){
		
		$("#popupvesselName").attr("disabled","disabled");
		$("#popupVesselNo").attr("disabled","disabled");
		$("#popupMaxrows").attr("disabled","disabled");
		$("#popupVesselNo").val(vesselInfo.vesselCode);
		$("#popupvesselName").val(vesselInfo.vesselName);
		$("#popupMaxrows").val(vesselInfo.maxRows);
		$("#popupvesselType").val(vesselInfo.vesselType);
		$("#popuplength").val(vesselInfo.length);
		$("#popupwidth").val(vesselInfo.width);
		$("#popupteuCapacity").val(vesselInfo.teuCapacity);
		$("#popupheight").val(vesselInfo.height);
		$("#popupmotherFeederInd").val(vesselInfo.motherFeeder);
		$('#popupContinueBtn').removeClass("secondary disabled");
		
	}
	
	$('#hiddenPopup').attr('overridOverlayClose',true).click();
	//$('#hiddenPopup').click();
}

function showCreateVesselProfile(){
	
	var win = window.open('vessel/addVesselProfile', '_blank');
	   if(win){
	       //Browser has allowed it to be opened
	       win.focus();
	   }else{
	       //Broswer has blocked it
	       alert('Please allow popups for this site');
	   }
}

function showEditVesselProfile(vesselNo){
	
	var win = window.open('vessel/editVesselProfile?vesselNo='+vesselNo, '_blank');
	   if(win){
	       //Browser has allowed it to be opened
	       win.focus();
	   }else{
	       //Broswer has blocked it
	       alert('Please allow popups for this site');
	   }
}

function showViewVesselProfile(vesselNo){
	
	var win = window.open('vessel/viewVesselProfile?vesselNo='+vesselNo, '_blank');
	   if(win){
	       //Browser has allowed it to be opened
	       win.focus();
	   }else{
	       //Broswer has blocked it
	       alert('Please allow popups for this site');
	   }
}



function saveVesselProfile(vesselData){
		/*var el= this.getEl();
	 el.mask("Saving Vessel Profile...");*/
	 
	Ext.getBody().mask("Saving Vessel Profile...");
	
Ext.Ajax.request({
	url:'CreateVesselProfile',
	timeout: 600000,
	params:{
		'vesselData' : vesselData //selectedRecord.data.vesselNo,
	},
	method:'POST',
	success : function(response) {
		var msg=Ext.decode(response.responseText);
		var error = msg.message;
	//	el.unmask();
		Ext.getBody().unmask(); 
		if(msg.success==true){
			Ext.MessageBox.show({
				msg: "Vessel Created successfully", //Modules.Msgs.saveSuccess,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});		
			//win.close();
		}else{
			Ext.MessageBox.show({
				msg: error,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});											
		}
		
	},
	
	failure:function(response){
	//	el.unmask();
		Ext.getBody().unmask(); 
		Ext.MessageBox.show({
			msg: "Error in Connection...Please try again.",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});
		
	}
});
}

function saveEditedVesselProfile(vesselData){
	/*var el= this.getEl();
 el.mask("Saving Vessel Profile...");*/
 
	Ext.getBody().mask("Updating Vessel...");

Ext.Ajax.request({
url:'saveEditedVessel',
timeout: 600000,
params:{
	'vesselData' : vesselData //selectedRecord.data.vesselNo,
},
method:'POST',
success : function(response) {
	var msg=Ext.decode(response.responseText);
	var error = msg.message;
	Ext.getBody().unmask(); 
//	el.unmask();
	if(msg.success==true){
		Ext.MessageBox.show({
			msg: "Vessel updated successfully",
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});		
		//win.close();
	}else{
		Ext.MessageBox.show({
			msg: error,
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.INFO
		});											
	}
	
},

failure:function(response){
//	el.unmask();
	Ext.getBody().unmask(); 
	Ext.MessageBox.show({
		msg: "Error in Connection...Please try again.",
		buttons: Ext.MessageBox.OK,
		icon: Ext.MessageBox.INFO
	});
	
}
});
}



function encryptPassword(passwordTxt,userObject){
	
	var iterationCount = 1000;
	var keySize = 128;
		
	var plaintext = passwordTxt ; 
    var passphrase = "2cmc0MERGES1tcs5" ;
    
    var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
    var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
    
    var aesUtil = new AesUtil(keySize, iterationCount);
    var ciphertext = aesUtil.encrypt(salt, iv, passphrase, plaintext);
    
    userObject.iv = iv ;
    userObject.salt = salt ;
    
    return ciphertext ;
    //console.log(passValue);
    //console.log(ciphertext);
	
}

function showPhoneErrorMssg(phoneOrFax){
	
	
	
	/*var errorMssg =  phoneOrFax + " number should be in one of the following formats :" +
	"+97150-3827741 , +97150 3827741 , 	0503827741,	050-3827741 .<br><br>" +
	"Accepted area codes are :<br> 02 - Abu Dhabi <br>" +
	"03 -  Al Ain <br>" +
	"04 -  Dubai <br>" +
	"06 -  Sharjah, Ajman and Umm al-Quwain <br>" +
	"07 -  Ras Al Khaimah <br>" +
	"09 -  Fujairah <br>" +
	"050 - Cell phones (Etisalat) <br>" +
	"052 - Cell phones (Du) <br>" +
	"055 -  Cell phones (Du) <br>" +
	"056 -  Cell phones (Etisalat) <br> "*/
	
	var errorMssg =  phoneOrFax + " number should be in one of the following formats :" +
	"+97150-3827741 , +97150 3827741 , 	0503827741,	050-3827741 .<br><br>" +
	"Accepted area codes are :<br> 02 - Abu Dhabi <br>" +
	"03 -  Al Ain <br>" +
	"04 -  Dubai <br>" +
	"06 -  Sharjah, Ajman and Umm al-Quwain <br>" +
	"07 -  Ras Al Khaimah <br>" +
	"09 -  Fujairah <br>" +
	"050/056 - Etisalat <br>" +
	"052/055 - Du <br>"  ;
	
	
	
	return errorMssg ;
	
	
}


function showNameErrorMssg(firstOrLastName,minLength,maxLength){
	
	var nameErrorMssg = firstOrLastName + " name can only contain alphabets,space & dot(.) and must be between " +
	minLength + " and " + maxLength + " characters (both inclusive).";
	
	return nameErrorMssg ;
	
}

function showUserNameErrorMssg(userName,minLength,maxLength){
	
	var userNameErrorMssg = userName + "  can only contain alphabets,digits,space,dash(-),hyphen(_) & dot(.) and must be between " +
	minLength + " and " +  maxLength + " characters (both inclusive).";
	
	return userNameErrorMssg ;
	
};

function showHexaCodeErrorMssg(hexaCode){//,minLength,maxLength){
	
	var hexaCodeErrorMssg = hexaCode + "  entered is invalid" ;
	
	return hexaCodeErrorMssg ;
	
};

function showIpAddressErrorMssg(ipAddress){//,minLength,maxLength){
	
	var ipAddressErrorMssg = ipAddress + "  can only contain numbers and should be in following format : X.X.X.X" +
	" where X is a number and each number can be written as 0 to 255 (e.g., 0.0.0.0 to 255.255.255.255)." ;
	
	return ipAddressErrorMssg ;
	
};

function showPortNoErrorMssg(portName,minVal,maxVal){
	
	var portNoErrorMssg = portName + " port can only contain numbers and must be between " +
	minVal + " and " +  maxVal + ".";
	
	return portNoErrorMssg ;
	
};

function showExpiryErrorMssg(minVal,maxVal){
	
	var expiryErrorMssg =  "Expiry time  can only contain numbers and must be between " +
	minVal + " and " +  maxVal + " digits.";
	
	return expiryErrorMssg ;
	
};


function showNumberOnlyErrorMssg(columnName,minVal,maxVal){
	
	var onlyNumberAllowedErrorMssg = columnName + "  can only contain numbers and must be between " +
	minVal + " and " +  maxVal + ".";
	
	return onlyNumberAllowedErrorMssg ;
	
};


function showFloatingNoErrorMssg(columnName,minVal,maxVal){
	
	var onlyFloatNumberAllowedErrorMssg = columnName + "  can only contain digits and decimal(.)" //numbers and must be between " +
	//minVal + " and " +  maxVal + ".";
	
	return onlyFloatNumberAllowedErrorMssg ;
	
};

function showNumberOnlyErrorMssgWithDigits(columnName,minValDigits,maxValDigits){
	
	var onlyNumberAllowedErrorMssg = columnName + "  can only contain numbers and must be between " +
	minValDigits + " and " +  maxValDigits + " digits.";
	
	return onlyNumberAllowedErrorMssg ;
	
};

function showMaxLengthErrorMssg(columnName,maxLength){
	
	var maxLengthErrorMssg = "  Max length for this field is " + 	maxLength ;
	
	return maxLengthErrorMssg ;
	
};


function showVesselNameErrorMssg(vesselName,minLength,maxLength){
	
	var vesselNameErrorMssg = vesselName + "  can only contain alphabets, space, - , _  & dot(.) and must be between " +
	minLength + " and " +  maxLength + " characters.";
	
	return vesselNameErrorMssg ;
	
};

function showDecimalErrorMssg(fieldName){
	
	var invalidErrorMssg = fieldName + "  can only contain numbers upto 4 digits , excluding optional 2 decimal places and minus symbol(-)" ;//+
	//minLength + " and " +  maxLength + " characters.";
	
	return invalidErrorMssg ;
	
};

function showAlphaNumericErrorMssg(fieldName,maxDigits){//,minLength,maxLength){
	
	var alphaNumericErrorMssg = fieldName + "  can only contain alphabets & numbers and should not have more than 20 characters." ;
	
	return alphaNumericErrorMssg ;
	
};



function showNetworkIssueErrMssg(fieldName){
"Error connecting to server to check whether this " + fieldName +" is available...please try after logging in again" ;

};

function doFailureProcessing(store,batch,opt){
	Ext.getBody().unmask();
    var msg = '';
   // console.log("faliure!!");
    if(batch.hasException){
        
        for(var i = 0; i < batch.exceptions.length; i ++ ){
            switch(batch.exceptions[i].action){
                case "destroy" : 
                    msg = msg + batch.exceptions[i].records.length + " Delete, ";
                    for(var j = 0; j < batch.exceptions[i].records.length; j ++ ){
                   	 batch.exceptions[i].records[j].set('isDeleted','N'); //data.isDeleted = 'N' ;//
                   }
                    //store.rejectChanges();
                    store.rejectDeletions();
                    break;
                case "update" : 
                    msg = msg + batch.exceptions[i].records.length + " Update, ";
                    //store.rejectChanges();
                    store.rejectUpdates();
                    break;
                case "create" : 
                    msg = msg + batch.exceptions[i].records.length + " Create, ";
                    break;
            }
        }
        
      
        
       /* Ext.MessageBox.show({
        	title: Modules.Msgs.saveResultTiltle, //"Save Results",
			msg: msg + Modules.Msgs.operationFailedMsg,             //
			buttons: Ext.MessageBox.OK,
			icon: Ext.MessageBox.ERROR
		});*/
        
    }
    else{
    	 Ext.MessageBox.show({
    		 	title:Modules.Msgs.saveResultTiltle, // "Save Results",
				msg: msg +Modules.Msgs.saveFailedMsg,             //
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			});
    }
   // store.load();
}



function doSuccessProcessing(store){
	Ext.getBody().unmask();
	Ext.MessageBox.show({
		title : Modules.Msgs.recordOperationSuccessTitle,
		msg:Modules.Msgs.recordOperationSuccessMsg , //'All changes saved successfully',             //
		buttons: Ext.MessageBox.OK,
		icon: Ext.MessageBox.INFO
	});
	store.load();
}


function checkIfEditFormExists(record){
	
	var addedPanel = Ext.getCmp(Modules.CompIds.EditUserTabparentpanelID);
	if(addedPanel){
		
		
		
		var confirmMssg ="You have already opened a tab to edit another user.You will lose any unsaved changes made to that user. Are you sure - you want to continue ?";
		Ext.Msg.confirm('',confirmMssg, function (answer) {
			if (answer == "yes") {
				
				record.data.oldPassword = record.data.password ;
				record.data.password = "";
				//Ext.getCmp(Modules.CompIds.EditUserTabparentpanelID).close();
				//showEditForm(record);
				var editForm = Ext.getCmp(Modules.CompIds.EditUserTabparentpanelID).down('#editForm').getForm();
				editForm.loadRecord(record);
				Ext.getCmp("centerPanelId").setActiveTab(addedPanel);
				
				}
		});	
	}
	
	else{
		showEditForm(record);
	}
}

function showEditForm(record){
	
	/*	var roles = record.data.roles ;
		var StringArrayRoles = roles.split(",");
		record.data.roles = StringArrayRoles ; */
		
		record.data.oldPassword = record.data.password ;
		record.data.password = "";
		
		//record.data.roles.toArray();
		
		var rolesData = undefined ;
	    Ext.Ajax.request({
			url : 'user/getRoles',
			method : 'GET',
			success : function(response) {
				var msg = Ext.decode(response.responseText);
				if (msg.success == true) {
					rolesData = msg.data ;
					
						var argObj = {
									panelFunc : Modules.Master.UserMaster.editUserTabparentpanel,
									panelId : Modules.CompIds.EditUserTabparentpanelID,
									parentTabPanelId : 'centerPanelId',
									
									panelFuncArgs : {text:'Edit User',rolesArray : rolesData}
							};
							var addedPanel =	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
							//var editUserForm = addedPanel.down('cmcform') ;
							
							if(addedPanel){
							var editUserForm  = addedPanel.down('#editForm').getForm();
							//
							
							var langRec = Ext.create('languageModelFK',
									{'languageCode':record.data.language.languageCode, // try using getter
									'languageName':record.data.language.languageName});
							
							var langField = Ext.getCmp(Modules.CompIds.EditUserTabparentpanelID).down('#editForm').getForm().findField('defaultLanguage');
							langStore = langField.getStore(); 
							langStore.add(langRec);
							// get the comoboReference.getSotore().add(langRec);
							editUserForm.loadRecord(record);
							}
							
					
				}else{
					Ext.MessageBox.show({
						msg : "Unable to fetch roles from DB !",//msg.errors,
						buttons : Ext.MessageBox.OK,
						icon : Ext.MessageBox.INFO
					});
				}
				//Ext.getBody().unmask();
				
			},
			failure : function(response) {
				
				Ext.MessageBox.show({
					msg : "Unable to connect to DB !",//msg.errors,
					buttons : Ext.MessageBox.OK,
					icon : Ext.MessageBox.INFO
				});
				
				//Ext.getBody().unmask();
			}
	    });
			
};

	function setBeforeQueryDetails(config,eventObj,searchColumnValuePairs,isMultiColumnSearch,filterColumnValuePairs,filterResults){
	var query = eventObj.query ;
	var store = eventObj.combo.getStore(); 
	//replace this with store
	store.proxy.extraParams.entityName = config.entity;
	store.proxy.extraParams.columnName = config.property;
	if(isMultiColumnSearch){
		store.proxy.extraParams.checkEquality = config.checkEquality; 
		store.proxy.extraParams.orElseAnd = config.conditionToSearch;  
		store.proxy.extraParams.columnValuePairs = searchColumnValuePairs;
	    
	}
	if(filterResults){
		store.proxy.extraParams.filterColumnValuePairs = filterColumnValuePairs ;
	}
	if(config.paging==false){
		store.proxy.extraParams.limit = 100000;
	}
	}
	
	
	function getNumberingSeriesHeadersOrDetails(entityName,filterColumnName,filterColumnVal,queryColumnName,query,start,limit){
		var responseData;

		Ext.Ajax.request({
			async:false,
		url: 'common/getForeignKeys',
		timeout: 600000,
		params:{
			'start' : start ,
			'limit' : limit,
			'entityName' : entityName,
			'query' : query,
			'columnName' : queryColumnName,
			'filterColumnName' : filterColumnName,
			'filterColumnVal' : filterColumnVal
			},
		method:'POST',
		success : function(response) {
			var msg=Ext.decode(response.responseText);
			var error = msg.message;
			responseData = msg;
			/*if(msg.success==true){
				Ext.MessageBox.show({
					msg: "data received successfully", //Modules.Msgs.saveSuccess,
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.INFO
				});		
				
			}else{
				Ext.MessageBox.show({
					msg: error,
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.INFO
				});											
			}*/
		},

		failure:function(response){
			Ext.MessageBox.show({
				msg: "Error in Connection...Please try again.",
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.INFO
			});
			
		}
		});
		return responseData;
		}