Modules.Msgs.serverError								=	'Server error. Please try later';
Modules.Msgs.serverNotResponding						=	'There is no response from the server';
Modules.Msgs.serverRequestTimeOutError					=	'Request timed out!';
Modules.Msgs.serverSessionTiimeOut						=	'Session timed out. You need to login again';
Modules.Msgs.serverAccessDeniedError					=	'Access Denied';
Modules.Msgs.noDataFoundError							=	'No data found';
Modules.Msgs.confirmationRequested						=	'Confirmation Requested';
Modules.Msgs.clearConfirmation							=	'Are you sure you want to clear all the values?';
Modules.Msgs.deleteConfirmation							=	'Are you sure you want to delete all the values?';
Modules.Msgs.deleteMultiRecordsConfirmation				=	'Are you sure you want to delete the selected records?';
Modules.Msgs.deleteSingleRecordConfirmation				=	'Are you sure you want to delete the selected record?';
Modules.Msgs.unSavedDataLossConfirmation				=   'The unsaved data will be lost.Do you want to continue?';
Modules.Msgs.deleteSwimPartnerConfirmation              =   'Send Message Agreements have Configured for this Partner. Do you Really Want To Delete?';
Modules.Msgs.evntRtngQryReRateConfirmation1             =   'Number of Events Selected are ';
Modules.Msgs.evntRtngQryReRateConfirmation2             =   '.Do You Wish to Continue?';
Modules.Msgs.saveRecordConfirmation	                    =   'You made some changes which will be lost if you navigate to other page without saving ! Below is the summary of changes : <br><br>' ;
Modules.Msgs.saveBeforeClosingConfirmation	            =   'You made some changes which will be lost if you close the tab without saving ! <br> Are you sure you want to close ?' ; 
Modules.Msgs.continueMsg		                        =   'Do you still want to continue ?'
Modules.Msgs.deleteRecordConfirmation	                =   'You deleted some records which will be lost if you navigate to other page without saving ! Do you still want to continue ?';
Modules.Msgs.selectionRecordConfirmation				=	'Selection will be lost. Do you wish to continue?';
Modules.Msgs.loading									=	'Loading...';
Modules.Msgs.processing									=	'Processing...';
Modules.Msgs.warning									= 	'Warning';
Modules.Msgs.confirm									= 	'Confirm';
Modules.Msgs.status										=	'Status';
Modules.Msgs.info										=	'Info';
Modules.Msgs.markDelConfirmation						=	'Are you sure you want to mark selected records for delete?';
Modules.Msgs.unmarkDelConfirmation						=	'Are you sure you want to un-mark selected records for delete?';

Modules.Msgs.RowLimitExceeded							=	'Row limit exceeded';
Modules.Msgs.NarrowDownSearch							=	'Narrow down your search criteria';
Modules.Msgs.recordConfirmationTitle					=	'No Records Found';

Modules.Msgs.NoRecordsToExport							= 	'No records to export';

Modules.Msgs.recordConfirmationMsg						=	'No records were found for the query parameters provide';

Modules.Msgs.queryTitles								=	'Query Parameters not provided';
Modules.Msgs.queryMsg		           					=	'Please provide at least one query parameter to load list of values';

Modules.Msgs.inValidFormTitle		    				=	'Invalid values';
Modules.Msgs.inValidFormMsg		        				=	'Please correct the highlighted errors';

Modules.Msgs.appDatetimeTitle		   					=	'Application Date Time Error';
Modules.Msgs.appDatetimeMsg		        				=	'Application From Date-Time can not be greater than or equal to Application To Date-Time';

Modules.Msgs.etaDatetimeTitle		    				=	'ETA Date Time Error';
Modules.Msgs.etaDatetimeMsg		        				=	'ETA From Date-Time can not be greater than or equal to ETA To Date-Time';

Modules.Msgs.singleSelectOnly							=	'Please select only one record for this action';
Modules.Msgs.selectionError								=	'Selection Error';
Modules.Msgs.selRecFrst									=	'Please select a record';
Modules.Msgs.noRecsSelected								=	'No record selected';
Modules.Msgs.noRecordsInGrid                            =   'No Results Found';
Modules.Msgs.alreadyRunning								= 	'Selected Partner(s) are already in Running Status';
Modules.Msgs.alreadyStopped								= 	'Selected Partner(s) are already in Stopped Status';
Modules.Msgs.allalreadyRunning							= 	'Partner\'s are already in Running Status';
Modules.Msgs.allalreadyStopped							= 	'Partner\'s are already in Stopped Status';
Modules.Msgs.mixedStateStart							=	'Unable to Start...<br>Some Selected Partner\'s are Already in Running Status';
Modules.Msgs.mixedStateStop								=	'Unable to Stop...<br>Some Selected Partner\'s are Already in Stopped Status';
Modules.Msgs.adtExcpAlreadyRunning						= 	'Selected Mesage(s) are already in Running Status';
Modules.Msgs.adtExcpAlreadyStopped						= 	'Selected Mesage(s) are already in Stopped Status';
Modules.Msgs.adtExcpMixedStateStart						=	'Unable to Start...<br>Some Selected Mesage\'s are already in Running Status';
Modules.Msgs.adtExcpMixedStateStop						=	'Unable to Stop...<br>Some Selected Mesage\'s are already in Stopped Status';
Modules.Msgs.adtExcpTimeIntrvlNotEmpty					=	'Time Interval Should not be Empty.It\'s minimum value should be 6';
Modules.Msgs.adtExcpTimeIntrvlMinVal					=   'Time Interval minimum value should be 6';
Modules.Msgs.adtExcpUpdateNotAllowed					=	'Update is not allowed when the Status of the message is in Running mode ';
Modules.Msgs.formValidation			              		= 	'Mandatory fields need to be entered';
Modules.Msgs.saveAddedRows			              		=	'Please save the added row(s)first then insert another';
Modules.Msgs.ValidationNull								= 	'Mandatory fields should not be Empty';
Modules.Msgs.noRecordsDelete							=	'There are no records to delete';
Modules.Msgs.ValidationCorrectValue						=	'Please enter correct value';
Modules.Msgs.noComboValueFound							=	'No Values Found !';
Modules.Msgs.purgeDetailsQueryParameter					=	'Purge Configuration Details';
Modules.Msgs.purgeDetailsTabTitle						=	'Purge Configuration';
Modules.Msgs.eventLogQueryParameter						=	'Event Log';
Modules.Msgs.clearBtnTooltip							=	'Clear Fields';
Modules.Msgs.retrieveBtnTooltip							=	'Retrieve Details';
Modules.Msgs.jobViewTooltip								=	'Job View';
Modules.Msgs.saveBtnTooltip								=	'Update the Frequency Time Value';
Modules.Msgs.gridAddBtnTooltip							=	'Add new Records';
Modules.Msgs.gridDeleteBtnTooltip						=	'Delete Records';
Modules.Msgs.gridModifyBtnTooltip						=	'Modify Records';
Modules.Msgs.duplicateGridData							=	'Duplicate row exists for this parameter';
Modules.Msgs.updtStatusBtnTooltip						=	'Update Status of EDI Messages';
Modules.Msgs.noRecordsToUpdte							=	'There are no records to update the status';
Modules.Msgs.errorUpdteSts								=	'Select only records whose msg proc sts is in MAPNOTEXST/SYSERROR/NOAGRMNT';
Modules.Msgs.saveConfirmation							=	'Do you want to save the data ?';
Modules.Msgs.noUpdatedValue								=	'Frequency and Time values are same for the Company';
Modules.Msgs.nullFrequency								=	'PurgeFrequency is Empty';
Modules.Msgs.wrongFrequency								=	'Incorrect PurgeFrequency Entered';
Modules.Msgs.nullMsgType								=	'Message Type is Empty';
Modules.Msgs.duplicateRecordTitle						=	'';
Modules.Msgs.editingCurrentRecord						=	'Please finish editing the current record';
Modules.Msgs.editingMode								=	'';
Modules.Msgs.msgProcSts									=	'Message Processing Status';
Modules.Msgs.nullValue									=	'';
Modules.Msgs.failureTitle								=	'';
Modules.Msgs.messageTitle								=	'';
Modules.Msgs.confirmTitle								=	'Confirm navigation to other page';
Modules.Msgs.confirmBeforeCloseTitle					=	'Confirm closing current tab';
Modules.Msgs.editPurgeGridDataTitle						=	'Purging Days should be a Number';
Modules.Msgs.popPurgeDaysZero							=	'Purging Days should > 0';
Modules.Msgs.emptyGrid									=	'The Grid is Empty';
Modules.Msgs.excelReportToolTip							=	'Export to Excel';
Modules.Msgs.pdfReportToolTip							=	'Export to PDF';
Modules.Msgs.fileCreateSuccess							=	'Excel File Created Successfully';
Modules.Msgs.noMatchingRecords							=	'No records for the matching criteria';
Modules.Msgs.updateDB									=	'Updated Successfully';
Modules.Msgs.nullValueField								=	'Null value exists';
Modules.Msgs.PurgeFrequencyDescription					=	'<b>Monthly</b> � Purge the data at the end of every month.<br/><b>Weekly</b> � Purge the data at the end of the week.<br/>(Start of the week (Monday or Saturday) would be set as a parameter at company level.)<br/><b>Daily</b> � Purge the data daily.<br/><b>Bi Weekly</b> � Purge the data on 15th and month end.<br/><b>On Demand</b> � System will not try to purge the messages.';
Modules.Msgs.confirmationMsgToChangeDefault             =   'Default search criteria already exist. Do you want to make current search criteria as default?';
Modules.Msgs.confirmationMsgToChangeCriteria            =   'Changes saved successfully';
Modules.Msgs.mandatoryStatus                            =	'Search Criteria Keyword is Mandatory Field';
Modules.Msgs.internalError                              =   'Some internal error in processing the request';
Modules.Msgs.savedMessage                               =   'The search criteria keyword saved';
Modules.Msgs.searchCriteriaKeywordStatus                =	'The search criteria keyword is already exist, Please choose a different keyword';
Modules.Msgs.selectOnlySingleRecord                     =   'Please select only one record';
Modules.Msgs.selectSingleRecord                         =   'Please select one single record';
Modules.Msgs.selectRecords                              =   'Please select record(s)';
Modules.Msgs.messageTypeNotEmpty                        =   'Message Type is mandatory field';
Modules.Msgs.recordSelectSpecificU                      =	'Select records whose Msg Proc Sts is TOBEUPLD and U/D Indicator is U';
Modules.Msgs.messageTypeDifferentNoSelect               =	'Can not select the records of different message type';
Modules.Msgs.recordSelectSpecificD                      =	'Select records whose Msg Proc Sts is Error and U/D Indicator is D';
Modules.Msgs.noUpdation                                 =   'No Updations';
Modules.Msgs.noEdiFile                                  =   'No edi file available';
Modules.Msgs.companyCodeMandatory                       =   'Company code is mandatory field';
Modules.Msgs.gridSaveBtnTooltip							=	'Save the Modified Records';
Modules.Msgs.noDataInGrid								=	'No records matching the search criteria were found';//'No Results Found';
Modules.Msgs.gridPopupToolTip							=	'Popup window';

Modules.Msgs.alertAssociatedToMultipleDelay			= 	'The following Delay Reason Codes are associated to some alert code - hence can not delete these codes ! Please unselect these records and try again !</br> </br> '	;
Modules.Msgs.alertAssociatedToSingleDelay 	        = 	 'The selected Delay Reason Code given below is associated to some alert code - hence can not delete it !</br> </br>'	;

Modules.Msgs.openDelaysForMultipleDelayCodes			= 	'The following Delay Reason Codes are having some delay records which are not closed - hence can not delete these codes ! Please unselect these records and try again !</br> </br> '	;
Modules.Msgs.openDelaysForSingleDelayCode 	        = 	 'The selected Delay Reason Code (given below) is having some delay records which are not closed - hence can not delete it !</br> </br>'	;
Modules.Msgs.openDelaysForSingleDelayCodeInMultipleRecords = 'Some of the selected Delay Reason Codes (given below) is having some delay records which are not closed - hence can not delete it !</br> </br>'	;

Modules.Msgs.validationErrorTitle						=	'Validation Failed !';

Modules.Msgs.recordOperationfailTitle	                =   'No Changes!';
Modules.Msgs.recordOperationfailMsg                     =   'No records were modified to save';

Modules.Msgs.recordOperationSuccessTitle                =    'Changes saved';
Modules.Msgs.recordOperationSuccessMsg                 =    'All changes saved successfully';

Modules.Msgs.saveResultTiltle                           =    'Save Results';

Modules.Msgs.operationFailedMsg							=     'operation failed !';
Modules.Msgs.saveFailedMsg									=    ' Unable to save changes.';
Modules.Msgs.alertWhendeleteRecords						=	 'Please select at least one record to delete!';

Modules.Msgs.defaultTemplateError						=	'For default template - the existing template details can neither be updated or deleted. Only addition of new record in template details can be done !';
Modules.Msgs.usedtemplateError							=	'This template is already used by some Vessel. Hence,no changes(update or delete) can be made now,except for addition of new template details !';

Modules.Msgs.defaultTemplateErrorTitle						=	'Alert for Default Template';
Modules.Msgs.usedtemplateErrorTitle							=	'Alert for Used Template';


Modules.Msgs.noRecordForGridTitle  						=	'No Records found' ;
Modules.Msgs.noRecordForGrid                            =   'No Records found for current criteria.';
Modules.Msgs.fromDateMandatory                          =   'From date mandatory';
Modules.Msgs.dateMandatory                              =   'Date mandatory';
Modules.Msgs.TimeWithoutDateMandatory  					=	'Time with out date is not allowed';
Modules.Msgs.searchCriteriaSaveToolTip                  =   'Search criteria will be saved ';
Modules.Msgs.errorCorrectionUploadNotAllowed            =   'Upload not applicable for outbound message type';
Modules.Msgs.errorCorrectionDownloadNotAllowed          =   'Download not applicable for inbound message type';

Modules.Msgs.fromDateToDateValidation					=	'From Date is greater than To Date';	
Modules.Msgs.noRecordsInGrid							= 	'No Records in Grid';
Modules.Msgs.startDateEndDateValidation					=	'Start Date is greater than End Date';
Modules.Msgs.endDateMandatoryMsg						=	'End Date is Mandatory';
Modules.Msgs.startDateMandatoryMsg						=	'Start Date is Mandatory';
Modules.Msgs.noRecordForGrid                            =   'No Records found for current criteria';
Modules.Msgs.invalidMsgType								=	'Message Type is Invalid';
Modules.Msgs.duplicateMsgType							=	'Duplicate Message Type Entered';
Modules.Msgs.gridCopyBtnTooltip							=	'Enter Record you want to Copy';
Modules.Msgs.gridPasteBtnTooltip						=	'Paste Copied Record into Grid';

Modules.Msgs.nullCopyFieldValue							=	'No Copied Data to Paste';

Modules.Msgs.partnerViewToolTip							=	'Partner View';

Modules.Msgs.invalidEvntLogFormData						=	'Invalid Data Entered';

Modules.Msgs.sMsResendMessageTypeValidate				=   'Resend Not Applicable for Inbound Message Type';
Modules.Msgs.sMsResendTransAndProcessValidate			=   'Select Only Records Whose Msg Trns Status is "MSGSENT" And Msg Proc Status is "DOWNLOADED" for Resend';

Modules.Msgs.invalidEvntLogDateFormat					=	'Invalid Date Format';
Modules.Msgs.deleteSuccess								=	'Deleted Successfully';
Modules.Msgs.saveSuccess								=	'Saved Successfully';
Modules.Msgs.evntLoadRef								=	'Event/Load Reference';
Modules.Msgs.transferSeqNbr								=	'Transfer Sequence Number';
Modules.Msgs.prevChrgdQty								=	'Previously Charged Quantity';
Modules.Msgs.prevChrgdUomCd								=	'Previously Charged Unit of Measure Code';
Modules.Msgs.storeUomCd									=	'Storage Unit of Measure Code';
Modules.Msgs.storageQuantity							=	'Storage Quantity';


Modules.Msgs.copyFromBtnTooltip							=	'Copy From';
Modules.Msgs.deSelectAllBtnTooltip						=	'DeSelect All Records';
Modules.Msgs.selectAllBtnTooltip						=	'Select All Records';



Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory';
Modules.Msgs.customerMandatoryMsg 						= 	'Customer is mandatory';



Modules.Msgs.ediFileNotExistMsg							=   'EDI File Doest Not Exist';


Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory';

Modules.Msgs.storageQtyMsg								=	'Storage Quantity is mandatory';
Modules.Msgs.quantityMsg								=	'Quantity is mandatory';
Modules.Msgs.SrvcGrpCdMsg								=   'Service Group Code is Mandatory';
Modules.Msgs.debtorPartyMsg								=   'Debtor Party is Mandatory';
Modules.Msgs.fromDateToDateMandatoryMsg					=	'From Date and To Date fields are Mandatory';
Modules.Msgs.duplicateRecord							= 'Record already exists in Database';

Modules.Msgs.selectOcnCustomerRatesRecord         =   'Please Select a Record from Customer Rates Header Grid';
Modules.Msgs.ratesMarkupFlagValidation            =   'MarkUp Criteria should be blank if Markup is not selected.';

Modules.Msgs.nullCustmrCd						=	'Customer is Empty';
Modules.Msgs.invalidCustmrCd					=	'Invalid Customer';
Modules.Msgs.nullSrvGrpCd						=	'Service Group is Empty';
Modules.Msgs.nullSrvGrpDesc						=	'Service Group Description is Empty';
Modules.Msgs.nullSrvType						=	'Service Type is Empty';
Modules.Msgs.nullSrvCd							=	'Service Code is Empty';
Modules.Msgs.nullSrvCdDesc						=	'Service Code Description is Empty';
Modules.Msgs.validateCustCodeSrvGrp				=	'Select a Customer and Service Group';
Modules.Msgs.doneRecordConfirmation	            =   'Data has been modified.Do you want to update in Grid?';
Modules.Msgs.noSearchCriteria					=	'Please enter at least one search criteria';
Modules.Msgs.deleteTheSpaceMessage				=	'Please delete the empty spaces';
Modules.Msgs.invalidSearchData					=	'Search form contains invalid data';	
Modules.Msgs.beforePageClose					=	'You are going to loose unsaved data';



Modules.Msgs.changesSavedLocallyHeader = 'Changes saved locally';
 
Modules.Msgs.changesSavedLocallyMssg = 'Changes made for the selected module have been saved locally.<br><br>These changes will actually be saved along with the group when<br>you click on save button on Group to User Association Window.';

Modules.Msgs.savingChanges = 'Saving changes';


Modules.admin.user_admin.group_user_security.messages.selectGroup='Please select a group.';
Modules.admin.user_admin.group_user_security.messages.deleteGroupConfirmation='This action deletes the Group and all associations will be removed. Do you want  to continue?';
Modules.admin.user_admin.group_user_security.messages.deletedSuccessfully='Deleted successfully';
Modules.admin.user_admin.group_user_security.messages.selectGroupToDelete='Please select a group to delete.';
Modules.admin.user_admin.group_user_security.messages.selectGroupToCopy='Please select a group to copy.';
Modules.admin.user_admin.group_user_security.messages.changeServiceType='Are you sure you want to change the Service Type, Any modified data will be lost?';
Modules.admin.user_admin.group_user_security.messages.requiredServiceType ='Service Type is Required';
Modules.admin.user_admin.group_user_security.messages.requiredGroupCode ='Group Code is Required';
Modules.admin.user_admin.group_user_security.messages.requiredGroupName='Group Name is Required';
Modules.admin.user_admin.group_user_security.messages.maxGroupCode='The maximum length for Group Code is 10.';
Modules.admin.user_admin.group_user_security.messages.maxGroupName='The maximum length for Group Name is 30.';
Modules.admin.user_admin.group_user_security.messages.maxGroupDesc='The maximum length for Group Description is 50.';
Modules.admin.user_admin.group_user_security.messages.noFunctionAssociatedWithGroup='No Function has been associated with the group under the specified module.<br> Please Click on apply after adding functions to the module.';



