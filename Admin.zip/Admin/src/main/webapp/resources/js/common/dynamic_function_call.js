
function showDashboardScreen() {
	
	//showAlertConfigurationMaster({});
	
   	Ext.getBody().unmask();
	return;

	var dashboradTabs=[];
	var array=[];
        for(var i=0;i<array.length;i++){
        	dashboradTabs.push(array[i].code);
        }
        var argObj = {
        		panelFunc : Modules.Dashboard.mainParentTabPanel,
        		panelId : 'dashboardParentTabPanelId',
        		parentTabPanelId : 'masterViewportId',
        		panelFuncArgs : {}
        };
        //Modules.GlobalFuncs.addPanelToTabPanel(panelObj);
        Ext.getBody().unmask();
       var tab = argObj.panelFunc((argObj.panelFuncArgs?argObj.panelFuncArgs:{}));
		tab._serviTypeGroup = argObj.panelFuncArgs && argObj.panelFuncArgs.serviceType;
		if(argObj.panelFuncArgs && argObj.panelFuncArgs.accessCode){
		tab._accessCode = argObj.panelFuncArgs && argObj.panelFuncArgs.accessCode;
		}
		if(argObj.panelFuncArgs && argObj.panelFuncArgs.functionCode){
			tab._functionCode = argObj.panelFuncArgs && argObj.panelFuncArgs.functionCode;
		}
	
		Modules.GlobalVars.functionCode=tab._functionCode;
		Modules.GlobalVars.selectedServiceTypeCode = tab._serviTypeGroup;
		Ext.getCmp(argObj.parentTabPanelId).add(tab);
		Ext.getCmp(argObj.parentTabPanelId).setActiveTab(Ext.getCmp(argObj.panelId));
		Ext.getCmp(argObj.parentTabPanelId).doLayout();
		
       	Modules.GlobalFuncs.hideLoadingDiv();



	
	
}

function showEquipmentMaster(){
	  var argObj = {
      		panelFunc : Modules.Master.EquipmentMaster.tabparentpanel,
      		panelId : Modules.CompIds.EquipmentMastertabparentpanelID,//'EquipmentMasterParentPanelId',
      		parentTabPanelId : 'centerPanelId',
      		
      		panelFuncArgs : {text:'Equipment Master',functionCode:'MS_EQ'}
      };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showDelayReasonCodeMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.DelayReasonCodeMaster.tabparentpanel,
    		panelId :  Modules.CompIds.DelayReasonCodeMastertabparentpanelID,//'DelayReasonCodeMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Delay Reason Code Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showQC_LaneMaster(){
	  var argObj = {
  		panelFunc : Modules.Master.QC_LaneMaster.tabparentpanel,
  		panelId : Modules.CompIds.QC_LaneMastertabparentpanelID, //'QC_LaneMasterParentPanelId',
  		parentTabPanelId : 'centerPanelId',
  		
  		panelFuncArgs : {text:'QC Lane Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showActivityCodeMaster(){
	  var argObj = {
		panelFunc : Modules.Master.ActivityCodeMaster.tabparentpanel,
		panelId : Modules.CompIds.ActivityCodeMastertabparentpanelID, //'ActivityCodeMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Activity Code Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showDeviceMaster(){
	  var argObj = {
		panelFunc : Modules.Master.DeviceMaster.tabparentpanel,
		panelId : Modules.CompIds.DeviceMastertabparentpanelID, //'DeviceMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Device Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showPinningStationMaster(){
	  var argObj = {
		panelFunc : Modules.Master.PinningStationMaster.tabparentpanel,
		panelId : Modules.CompIds.PinningStationMastertabparentpanelID, //'PinningStationMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Pinning Station Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showActivityTypeMaster(){
	  var argObj = {
		panelFunc : Modules.Master.ActivityTypeMaster.tabparentpanel,
		panelId : Modules.CompIds.ActivityTypeMastertabparentpanelID,//'ActivityTypeMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Activity Type Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showAlertCodeMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.AlertCodeMaster.tabparentpanel,
    		panelId : Modules.CompIds.AlertCodeMastertabparentpanelID, 	//'AlertCodeMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Alert Code Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showApplicationParameterMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.ApplicationParameterMaster.tabparentpanel,
    		panelId : Modules.CompIds.ApplicationParameterMastertabparentpanelID, 	//'ApplicationParameterMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Application Parameter Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showDamageCodeMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.DamageCodeMaster.tabparentpanel,
    		panelId : Modules.CompIds.DamageCodeMastertabparentpanelID, 	//'DamageCodeMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Damage Code Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showDamageSeverityMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.DamageSeverityMaster.tabparentpanel,
    		panelId : Modules.CompIds.DamageSeverityMastertabparentpanelID, //'DamageSeverityMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Damage Severity Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showTroubleShootAreaMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.TroubleShootAreaMaster.tabparentpanel,
    		panelId :  Modules.CompIds.TroubleShootAreaMastertabparentpanelID, 	//'TroubleShootAreaMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'TroubleShoot Area Master'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showDirectionMaster(){
	  var argObj = {
  		panelFunc : Modules.Master.DirectionMaster.tabparentpanel,
  		panelId : Modules.CompIds.DirectionMastertabparentpanelID, 	//'DirectionMasterParentPanelId',
  		parentTabPanelId : 'centerPanelId',
  		
  		panelFuncArgs : {text:'Direction Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showLanguageMaster(){
	  var argObj = {
  		panelFunc : Modules.Master.LanguageMaster.tabparentpanel,
  		panelId : Modules.CompIds.LanguageMastertabparentpanelID, 	//'LanguageMasterParentPanelId',
  		parentTabPanelId : 'centerPanelId',
  		
  		panelFuncArgs : {text:'Language Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showMoveTypeMaster(){
	  var argObj = {
  		panelFunc : Modules.Master.MoveTypeMaster.tabparentpanel,
  		panelId : Modules.CompIds.MoveTypeMastertabparentpanelID, //'MoveTypeMasterParentPanelId',
  		parentTabPanelId : 'centerPanelId',
  		
  		panelFuncArgs : {text:'Move Type Master'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showTerminalMaster(){
	  var argObj = {
		panelFunc : Modules.Master.TerminalMaster.tabparentpanel,
		panelId : Modules.CompIds.TerminalMastertabparentpanelID, //'TerminalMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Terminal Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showRoleMaster(){
	  var argObj = {
		panelFunc : Modules.Master.RoleMaster.tabparentpanel,
		panelId : Modules.CompIds.RoleMastertabparentpanelID,
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Role Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

// tariq

function rollBackRotation(){ 
	  var argObj = {
		//panelFunc :Modules.Master.UnitMaster.tabparentpanel,
		panelFunc :Modules.Master.RollbackRotation.tabparentpanel,
		panelId : Modules.CompIds.RollbackRotationMastertabparentpanelID,
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'RollBack Rotation'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
} 


//

function showAddUser(){
	var rolesData = undefined ;
    Ext.Ajax.request({
		url : 'user/getRoles',
		/*params : {
			'{"data"' : jsonDtlsArray + '}',
			//'companyCode' : Modules.GlobalVars.selectedCompanyCode
		},*/
		method : 'GET',
		success : function(response) {
			var msg = Ext.decode(response.responseText);
			if (msg.success == true) {
				rolesData = msg.data ;
				
				  var argObj = {
							panelFunc : Modules.Master.UserMaster.tabparentpanel,
							panelId : Modules.CompIds.UserMastertabparentpanelID,
							parentTabPanelId : 'centerPanelId',
							panelFuncArgs : {text:'Add User',rolesArray : rolesData}
					};
						 
				  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
				
			}else{
				Ext.MessageBox.show({
					msg : "Unable to fetch roles from DB !",//msg.errors,
					buttons : Ext.MessageBox.OK,
					icon : Ext.MessageBox.INFO
				});
			}
			//Ext.getBody().unmask();
			
		},
		failure : function(response) {
			
			Ext.MessageBox.show({
				msg : "Unable to connect to DB !",//msg.errors,
				buttons : Ext.MessageBox.OK,
				icon : Ext.MessageBox.INFO
			});
			
			//Ext.getBody().unmask();
		}
	});
	

}

function showViewUsers(){
	  var argObj = {
		panelFunc : Modules.Master.UserMaster.tabparentpanel.view,
		panelId : Modules.CompIds.UserMastertabparentpanelID_view,
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'View Users'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showUnitMaster(){
	  var argObj = {
		panelFunc :Modules.Master.UnitMaster.tabparentpanel,
		panelId : Modules.CompIds.UnitMastertabparentpanelID,
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Unit Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showColorCodeMaster(){
	  var argObj = {
		panelFunc : Modules.Master.ColorCodeMaster.tabparentpanel,
		panelId : Modules.CompIds.ColorCodeMastertabparentpanelID,
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Color Code Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showVesselMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.VesselMaster.tabparentpanel,
    		panelId : Modules.CompIds.VesselMastertabparentpanelID,//'VesselMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Vessel Master'}//,functionCode:'MS_VM'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showCheckListMaster(){
	  var argObj = {
  		panelFunc : Modules.Master.GenericChecklistMaster.tabparentpanel,
  		panelId : Modules.CompIds.ChecklistMastertabparentpanelID, 	//'VesselMasterParentPanelId',
  		parentTabPanelId : 'centerPanelId',
  		
  		panelFuncArgs : {text:'CheckList Master'}//,functionCode:'MS_VM'}
  };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showCheckListHeaderMaster(){
	  var argObj = {
		panelFunc : Modules.Master.CheckListHeaderMaster.tabparentpanel,
		panelId : Modules.CompIds.CheckListHeaderMastertabparentpanelID, 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'CheckList Header Master'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showRotationControlMaster(){
	  var argObj = {
		panelFunc : Modules.Master.RotationControlMaster.tabparentpanel,
		panelId : Modules.CompIds.RotationControlMastertabparentpanelID, 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Rotation Control Master'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showDamageLocationMaster(){
	  var argObj = {
		panelFunc : Modules.Master.DamageLocationMaster.tabparentpanel,
		panelId : Modules.CompIds.DamageLocationMastertabparentpanelID, 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Damage Location Master'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showDamageTypeMaster(){
	  var argObj = {
		panelFunc : Modules.Master.DamageTypeMaster.tabparentpanel,
		panelId : Modules.CompIds.DamageTypeMastertabparentpanelID, 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Damage Type Master'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showVesselExceptionMaster(){
	  var argObj = {
    		panelFunc : Modules.Master.VesselExceptionMaster.tabparentpanel,
    		panelId : Modules.CompIds.VesselExceptionMastertabparentpanelID,//'VesselExceptionMasterParentPanelId',
    		parentTabPanelId : 'centerPanelId',
    		
    		panelFuncArgs : {text:'Vessel Exception Master',functionCode:'MS_VEM'}
    };
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showYardBlockDefinition(){
	  var argObj = {
		panelFunc : Modules.Master.YardBlockMaster.tabparentpanel,
		panelId : Modules.CompIds.DamageTypeMastertabparentpanelID, 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Yard Block Definition'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showTemplateDetails(){ 
	  var argObj = {
		panelFunc : Modules.Master.TemplateMaster.tabparentpanel,
		panelId : 'TemplateDetailstabpanelId', 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Template Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showBusinessExceptionMaster(){ 
	  var argObj = {
		panelFunc : Modules.Master.BusinessExceptionMaster.tabparentpanel,
		panelId : 'BusinessExceptionDetailstabpanelId', 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Business Exception Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showTrailerMaster(){
	  var argObj = {
		panelFunc : Modules.Master.TrailerMaster.tabparentpanel,
		panelId : Modules.CompIds.TrailerMastertabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Trailer Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

/*function showNumberingSeriesDefinition(){ // for template master showNumberingSeriesDefinition
	  var argObj = {
		panelFunc : Modules.Master.TemplateMaster.tabparentpanel,// Modules.admin.numberingSeriesDefinitiontabparentpanel,
		panelId : 'TemplateDetailstabpanelId', 	//'VesselMasterParentPanelId',
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Template Master'}//,functionCode:'MS_VM'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}*/

function showGroupOrUserSecurityScreen(menu) {
	
	Ext.Ajax.request({
	    url: 'admin/getFunctionCodesAssociatedWithUserAndGroup',
	    method: 'POST',
	    params: {
	    	userId : Modules.GlobalVars.loginUserId
	    },
	    success: function(response){
	        var json = response.responseText;
	        var groupUserFunctionJSON = Ext.decode(json);
	        if(groupUserFunctionJSON !=undefined && groupUserFunctionJSON.success == true){
	        	var groupUserButtons=[];
	        	if(groupUserFunctionJSON.items){
	        		var array=groupUserFunctionJSON.items;
		 	        for(var i=0;i<array.length;i++){
		 	        	groupUserButtons.push(array[i].functionGroupId.functionCode);//.code);
		 	        }
	        	}
	        	var mergeObj={
	 	        		buttons : groupUserButtons,
	 	        		menu : menu
	 	        };
	 	        
	 	        
	 	       var panelObj = {
	 	    			panelFunc : Modules.admin.user_admin.group_user_security.tabparentpanel,
	 	    			panelId : 'GroupUserSecuritytabpanelId',
	 	    			parentTabPanelId : 'centerPanelId',//Modules.CompIds.viewportParentTabPanelId,
	 	    			panelFuncArgs : mergeObj
	 	    		};
	 	    		Modules.GlobalFuncs.addPanelToTabPanel(panelObj);
	        }else{
	        	Ext.MessageBox.show({
	                msg : groupUserFunctionJSON.message,
	        		buttons : Ext.MessageBox.OK,
	        		icon : Ext.MessageBox.INFO
	        	});
	        	
	        }
	       
	    }
	});
	

}

function showDelayRecordingMaster(){
	  var argObj = {
		panelFunc : Modules.Master.DelayRecordingMaster.tabparentpanel,
		panelId : Modules.CompIds.DelayRecordingMastertabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Delay Recording Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showAlertConfigurationMaster(){
	  var argObj = {
		panelFunc : Modules.Master.AlertConfigurationMaster.tabparentpanel,
		panelId : Modules.CompIds.AlertConfigurationMastertabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Alert Configuration Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}


function showAlertRecordMaster(){
	  var argObj = {
		panelFunc : Modules.Master.AlertRecordMaster.tabparentpanel,
		panelId : Modules.CompIds.AlertRecordMastertabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Alert Record Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showWeightageFactorMaster(){
	  var argObj = {
		panelFunc : Modules.Master.WeightageFactorMaster.tabparentpanel,
		panelId : Modules.CompIds.WeightageFactorMastertabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'Weightage Factor Master'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

function showUserMonitoring(){
	  var argObj = {
		panelFunc : Modules.Master.UserMonitor.tabparentpanel,
		panelId : Modules.CompIds.UserMonitortabparentpanelID, 	
		parentTabPanelId : 'centerPanelId',
		
		panelFuncArgs : {text:'User Monitoring'}
};
	  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
}

/*function showAddGroupScreen() {
	
	 var argObj = {
				panelFunc :Modules.admin.user_admin.group_user_security.manageGrouptabparentpanel,
				panelId : Modules.CompIds.groupWindowId,//Modules.CompIds.managegrouptabpanelId ,
				parentTabPanelId : 'centerPanelId',
				
				panelFuncArgs : {text:'Add Group'}
		};
			  Modules.GlobalFuncs.addPanelToTabPanel(argObj);
	
	

};*/

