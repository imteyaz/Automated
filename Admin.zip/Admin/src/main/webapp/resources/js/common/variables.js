Modules.GlobalVars.distributionEnv			=		false;
Modules.GlobalVars.recordsPerPageGrid		=		15;
Modules.GlobalVars.recordsPerPageCombo		=		5;
Modules.GlobalVars.maxLimitRecords			=		3000;
Modules.GlobalVars.gridMaxPagesize			=		300;
Modules.GlobalVars.maxPagesize 				= 		300;// Maximum of pagesize in grid paging bar 
Modules.GlobalVars.hearBeatTimeInterval		=		9;//Minutes
Modules.GlobalVars.dateSeparator			=		'/';//This is defined separately so that it can be passed to various functions which process dates
Modules.GlobalVars.timeSeparator			=		':';//This is defined separately so that it can be passed to various functions which process time
Modules.GlobalVars.dateFormatGlobal			=		'd'+Modules.GlobalVars.dateSeparator+'m'+Modules.GlobalVars.dateSeparator+'Y';
Modules.GlobalVars.timeFormatGlobal			=		'H'+Modules.GlobalVars.timeSeparator+'i';
Modules.GlobalVars.dateTimeFormatGlobal		=		 Modules.GlobalVars.dateFormatGlobal+' '+Modules.GlobalVars.timeFormatGlobal;
Modules.GlobalVars.selectedCompanyCode		=		 '';
Modules.GlobalVars.selectedCompanyDesc		=		 '';
Modules.GlobalVars.selectedServiceTypeCode	=		 '';
Modules.GlobalVars.loginUserId				=		 '';
Modules.GlobalVars.loginUserName			=		 '';
Modules.GlobalVars.loginUserTypeCode		=		 '';
Modules.GlobalVars.userAccessCode			=		 '';
Modules.GlobalVars.userDefaultProperties	=		 '';
Modules.GlobalVars.functionCode				=		 '';
Modules.GlobalVars.funAccessCodeObject		=		 [];
Modules.GlobalVars.gridStatObj				=		{}; // to get the persistad states of all grids
Modules.GlobalVars.afbGlobal				=		'AFB';
Modules.GlobalVars.feGlobal					=		'FE';
Modules.GlobalVars.dlbGlobal				=		'DLB';
Modules.GlobalVars.fliGlobal				=		'FLI';
Modules.GlobalVars.enGlobal					=		'EN';
Modules.GlobalVars.curGlobal				=		'CUR';
Modules.GlobalVars.exGlobal					=		'EX';
Modules.GlobalVars.dispGlobal				=		'DISP';
Modules.GlobalVars.umoGlobal				=		'UMO';
Modules.GlobalVars.rtuGlobal				=		'RTMU';
Modules.GlobalVars.bdlGlobal				=		'BDI';

Modules.GlobalVars.fileUploadSrvcCd         =       'uploadTemplateName';


Modules.GlobalVars.dashboardSelectedTabValue				=	'';
Modules.GlobalVars.dashboardValdidateSuccess				=	'success';
Modules.GlobalVars.dashboardToStatusMonitor                 =   0;
Modules.GlobalVars.statusMonitorRetrieveSearchToSaveSearch  =   0;
Modules.GlobalVars.swimSendMessageAgmntSave      =   '';
Modules.GlobalVars.swimPartnerConfigSave         =   '';
Modules.GlobalVars.swimGroupPartnerConfigSave    =   '';
Modules.GlobalVars.editPurgeGridSave			=	'';
Modules.GlobalVars.statusMonitorSaveSearchScreenTlt='statusMonitorSaveSearchScreen';
Modules.GlobalVars.eventlogSaveSearchScreenTlt='eventlogSaveSearchScreen';
Modules.GlobalVars.statusMonitorSaveSearchScreenCode='MX03';

Modules.GlobalVars.swimPartnerConfigSaveSearchScreenTlt = 'swimPartnerSaveSearchScreen';
Modules.GlobalVars.swimProcessAdministrationSaveSearchScreenTlt = 'swimProcsAdmnSaveSearchScreen';
Modules.GlobalVars.swimSendMsgConfigSaveSearchScreenTlt = 'swimSndMsgCfgSaveSearchScreen';
Modules.GlobalVars.swimGPMSaveSearchScreenTlt = 'swimGPMSaveSearchScreen';

Modules.GlobalVars.selectedJobcode			=		 '';
Modules.GlobalVars.backGroundJobsSaveSearchScreenTlt='backGroundJobsSaveSearchScreen';
Modules.GlobalVars.copyMessageTypeCombo		=		 'true';
Modules.GlobalVars.eventStatusQuerySaveScreenTlt='eventStatusQuerySaveScreenTlt';
//Modules.GlobalVars.statusMonitorRetrieveToSMC               =   'normal';

Modules.GlobalVars.supplrEvntStsSummSaveSearchScreenTlt   =  'supplrEvntStsSummSaveSearchId';
Modules.GlobalVars.custmrEvntStsSummSaveSearchScreenTlt   =   'custmrEvntStssummSaveSrchId';

Modules.GlobalVars.intSplAgrmntNbr   =0;

////==== Moddifyed=======
////==== Moddifyed
// Customer Service Group Setup
Modules.GlobalVars.custSrvGrpSetupScreenTlt='custSrvGrpSetupScreen';


Modules.GlobalVars.customerInvoiceGenerationScreenId='custmInvcGenScreenId';
Modules.GlobalVars.oceanCustomerApplicationAdviceScreenId='oceanCustomerApplicationAdviceScreenId';

Modules.GlobalVars.ocnIntSplAgrmntNbr  =0;

Modules.GlobalVars.supplierLineItemStsScreenId = 'supplierLineItemStsScreenId';

/************************** Ocean - Customer Service Group Setup **********************************/
Modules.GlobalVars.oceanCustSrvGrpSetupScreenTlt='oceanCustSrvGrpSetupScreen';
/************************** Supplier Remittance Details **********************************/
Modules.GlobalVars.supplierRemittanceDtlsScreenTlt='supplierRemittanceDtlsScreenTlt';

Modules.GlobalVars.oceanCstmrMstrScreen = 'oceanCstmrMstrScreen';
Modules.GlobalVars.oceanCstmrMstrContractIdentifiScreen = 'oceanCstmrMstrContractIdentifiScreen';
Modules.GlobalVars.oceanCstmrMstrFormScreen = 'oceanCstmrMstrFormScreen';


Modules.GlobalVars.suppEvntStatusSmryFlagForEvntRtngQry = '0';
Modules.GlobalVars.suppEvntStatusSmrySaveSearchScreenTlt = 'suppEvntStatusSmrySaveSearchScreenTlt';


Modules.GlobalVars.oceanSupplierRatesFormScreen = 'oceanSupplierRatesFormScreen';

Modules.GlobalVars.cstmrEvntStatusSmryFlagForEvntRtngQry = '0';

Modules.GlobalVars.changeLogScreenId = 'changeLogScreenId';
Modules.GlobalVars.oceanCstmrInvcApplicationAdviseOnHoldScreenId ='oceanCstmrInvcApplicationAdviseOnHoldScreenId';
Modules.GlobalVars.InternalAdminDatabaseErrorLogScreenId='InternalAdminDatabaseErrorLogScreenId';

Modules.GlobalVars.changeLogLevel1Value = '';
Modules.GlobalVars.changeLogLevel2Value = '';
Modules.GlobalVars.changeLogLevel3Value = '';
Modules.GlobalVars.changeLogLevel4Value = '';
Modules.GlobalVars.phoneNoRegEx = /[0-9 \- + ( )]/ ;
Modules.GlobalVars.multiEmailRegEx = /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+([;,.](([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})+)*$/;
Modules.GlobalVars.auditLogTabPanelId ='auditLogParentPanelId';
Modules.GlobalVars.oceanSupAutoInvcScreen = 'oceanSupAutoInvcScreen';
Modules.GlobalVars.oceanCustomerReconciliationScreenId = 'oceanCustomerReconciliationScreenId';
Modules.GlobalVars.oceanCustomerReconciliationPopUpScreenId = 'oceanCustomerReconciliationPopUpScreenId';
Modules.GlobalVars.vndrInvcTempltScreenId='vndrInvcTempltScreenId';
Modules.GlobalVars.decimalTextFieldRegEx = /[0-9 \.\-]/ ;



Modules.GlobalVars.applicationAdviseOnHoldScreenId = 'applicationAdviseOnHoldScreenId';


Modules.GlobalVars.ocnCstmrMstrContactDetailsScreenTlt='ocnCMContactDtlsSaveSearchScreen';
Modules.GlobalVars.ocnCstmrMstrVolvoMsgDetailsScreenTlt='ocnCMVolvoMsgDtlsSaveSearchScreen';

Modules.GlobalVars.supplierAutoInvcSetUpId='supplierAutoInvcSetupId';
Modules.GlobalVars.supplierRatesFormScreen='supplierRatesFormScreen';
Modules.GlobalVars.oceanSupplierAutomaticInvcSetUpId='oceanSupplierAutomaticInvcSetupId';
Modules.GlobalVars.supplierAutomaricInvcSetUpId='supplierAutomaticInvcSetupId';
Modules.GlobalVars.customerMasterId='customerMasterId';

Modules.GlobalVars.customerInvoiceGenerationNoScreenId='customerInvoiceGenerationNoScreenId';
Modules.GlobalVars.supplierPaymentReportId='supplierPaymentReportId';
Modules.GlobalVars.supplierInvoiceAgingReportId='supplierInvoiceAgingReportId';
Modules.GlobalVars.customerRevenueReportId='CustomerRevenueReportId';
Modules.GlobalVars.supplierRateReportId='SupplierRateReportId';
Modules.GlobalVars.customerratequeryRtngQry = '0';
Modules.GlobalVars.ocnEvntStatusSmryFlagForEvntRtngQry = '0';
Modules.GlobalVars.oceanPendingProformaGenerateInvoicFlg = '';
Modules.GlobalVars.nonOceanCustomerrateRtngQry = '';
Modules.GlobalVars.CustomerApplicationAdviceScreenId='CustomerApplicationAdviceScreenId';
Modules.GlobalVars.CstmrMstrContractIdentifiScreen='CstmrMstrContractIdentifiScreen';
Modules.GlobalVars.QUERY=4;
Modules.GlobalVars.QUERY_INSERT=3;
Modules.GlobalVars.QUERY_INSERT_UPDATE=2;
Modules.GlobalVars.FULL_CONTROL=1;



Modules.GlobalVars.winFuncArgObjCmc ;
Modules.GlobalVars.wingroupAssociatedObj;
Modules.GlobalVars.groupDtlsObj;
Modules.GlobalVars.removedFunObj;
Modules.GlobalVars.funcAccessCodesObj;


Modules.GlobalVars.selectedColor;


