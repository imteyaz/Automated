
Ext.define('CustomerInvoiceApplicationAdviseOnHoldModel', {
	extend : 'Ext.data.Model',
	fields : [
	{
		name : 'companyCd',
		type : 'string'
	},            
	{
		name : 'invcNo'
	},          
	{
		name : 'chargeCode',
		type : 'string'
	},          
	{
		name : 'party',
		type : 'string'
	},{
		name : 'partyName',
		type : 'string'
	},
	{
		name : 'prfInvNo',
		type : 'integer'
	},
	{
		name : 'invItemNo',
		type : 'integer'
	},
	{
		name : 'invType',
		type : 'string'
	},          
	{
		name : 'invNoDueDate',
		type : 'string'
	},          
	{
		name : 'serviceGroupCode',
		type : 'string'
	},          
	{
		name : 'bLNumber',
		type : 'string'
	},          
	{
		name : 'vessel',
		type : 'string'
	},          
	{
		name : 'vesselName',
		type : 'string'
	},          
	{
		name : 'shippingRefNo',
		type : 'string'
	},           
	{
		name : 'makeCode',
		type : 'string'
	},          
	{
		name : 'modelCode',
		type : 'string'
	},         
	{
		name : 'freightTerms',
		type : 'string'
	},        
	{
		name : 'polCode',
		type : 'string'
	},          
	{
		name : 'pol',
		type : 'string'
	},          
	{
		name : 'podCode',
		type : 'string'
	},          
	{
		name : 'pod',
		type : 'string'
	},         
	{
		name : 'blCmpltDttm',
		type : 'string'
	}, 
	{
		name : 'porCode',
		type : 'string'
	},    
	{
		name : 'pfdCode',
		type : 'string'
	},
	{
		name : 'manifestCurrency',
		type : 'string'
	},
	{
		name : 'manifestAmount',
		type : 'string'
	},         
	{
		name : 'invoiceCurrency',
		type : 'string'
	},{
		name : 'invoiceAmount',
		type : 'string'
	},{
		name : 'usdEqAmnt',
		type : 'string'
	},{
		name : 'summId',
		type : 'integer'
	},{
		name : 'invCreditNoteCode',
		type : 'string'
	}
	
	]
});


Ext.define('DummyModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'field1',
		type : 'string'
	},{
		name : 'field2',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	}]
});

Ext.define('SupRateQrySrvcDummyModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'contractid',
		type : 'string'		
	},{
		name : 'chargeCode',
		type : 'string'		
	},{
		name : 'party',
		type : 'string'
	},{
		name : 'validFromDt',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	}]
});
Ext.define('QuartzJobDtlsTaskDtlsGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'taskId', 			type : 'string'},
	          {name : 'taskNm',				type : 'string'},
	          {name : 'triggerState',		type : 'string'},
	          {name : 'enableFlg',			type : 'string'},
	          {name : 'prgmNm',				type : 'string'}
	          ]
});
Ext.define('QuartzFiredTriggersDtlsGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'entryId', 			type : 'string'},
	          {name : 'triggerName',		type : 'string'},
	          {name : 'instanceName',		type : 'string'},
	          {name : 'state',				type : 'string'}
	          ]
});
Ext.define('QuartzTriggersDtlsGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'triggerGroup',		type : 'string'},
	          {name : 'jobName',			type : 'string'},
	          {name : 'triggerState',		type : 'string'}
	          ]
});
Ext.define('SupplierRateReconciliationGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'cmpnyCd', 			type : 'string'},
	          {name : 'intSplAgmtNo',		type : 'string'},
	          {name : 'intBatchNo',			type : 'string'},
	          {name : 'seqNo',				type : 'string'},
	          {name : 'batchNo',			type : 'string'},
	          {name : 'supplierCd',			type : 'string'},
	          {name : 'cstmrCd',			type : 'string'},
	          {name : 'srvCd',				type : 'string'},
	          {name : 'effDate',			type : 'string'},
	          {name : 'trnsptMode',			type : 'string'},
	          {name : 'rateTierCd',			type : 'string'},	          
	          {name : 'originCd',			type : 'string'},
	          {name : 'destCd',				type : 'string'},
	          {name : 'conveyanceTypeCd',	type : 'string'},
	          {name : 'makeCd',				type : 'string'},
	          {name : 'modelCd',			type : 'string'},
	          {name : 'modelYear',			type : 'string'},
	          {name : 'modelGrpCd',			type : 'string'},
	          {name : 'partCd',				type : 'string'},
	          {name : 'originCityNm',		type : 'string'},
	          {name : 'originStateCd',		type : 'string'},
	          {name : 'originCntryCd',		type : 'string'},
	          {name : 'destCityNm',			type : 'string'},
	          {name : 'destStateCd',		type : 'string'},
	          {name : 'destCntryCd',		type : 'string'},
	          {name : 'originalOriginCd',	type : 'string'},
	          {name : 'finalDestCd',		type : 'string'},
	          {name : 'consolidationTypeCd',type : 'string'},
	          {name : 'supplierRateRef1',	type : 'string'},
	          {name : 'supplierRateRef2',	type : 'string'},
	          {name : 'supplierRateRef3',	type : 'string'},
	          {name : 'supplierRateRef4',	type : 'string'},
	          {name : 'noOfHrs',			type : 'string'},
	          {name : 'hourlyRate',			type : 'string'},
	          {name : 'varTrfUnitRate',		type : 'string'},
	          {name : 'fapsTrfUnitRate',	type : 'string'},
	          {name : 'itemSts',			type : 'string'},
	          {name : 'errMsgNo',			type : 'string'},
	          {name : 'errDescr',			type : 'string'},
	          {name : 'trfCrncyCd',			type : 'string'},
	          {name : 'transType', 			type : 'string'},
	          {name : 'splAgmtNo',			type : 'string'}
	          ]
});
Ext.define('CstmrPaymntDtlsPGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'intPaymntNo',			type : 'string'	},
	          {name : 'cstmrCd',				type : 'string'	},
	          {name : 'cstmrNm',				type : 'string'	},
	          {name : 'invcNo',					type : 'string'	},
	          {name : 'invcCrdtDttm',dateFormat:'d/m/Y',type:'date'},
	          {name : 'paymntDocType',			type : 'string'	},
	          {name : 'paymntDocNo',			type : 'string'	},
	          {name : 'paymntDttm',dateFormat:'d/m/Y',type:'date'},
	          {name : 'paidAmtInvcCrncy',		type : 'float'	},
	          {name : 'invcCrncyCd',			type : 'string'	},
	          {name : 'paymntCtgry',			type : 'string'	},
	          {name : 'customer',				type : 'string'	},
	          {name : 'cmpnyCd',				type : 'string'	},
	          {name : 'prfInvcNo',				type : 'string'	}	          
	         ]
});

Ext.define('CstmrPaymntDtlsChGrid', {
	extend : 'Ext.data.Model',
	fields : [{name : 'intPaymntNo',			type : 'string'	},
	          {name : 'itemNo',					type : 'string'	},
	          {name : 'prfInvcNo',				type : 'string'	},	          
	          {name : 'paidAmtInvcCrncy',		type : 'float'	},
	          {name : 'invcCrncyCd',			type : 'string'	},	          
	          {name : 'srvCd',					type : 'string'	},
	          {name : 'srvDescr',				type : 'string'	},
	          {name : 'srvType',				type : 'string'	},
	          {name : 'unitId',					type : 'string'	},
	          {name : 'toDttm',dateFormat:'d/m/Y',type:'date'},
	          {name : 'conveyanceId',			type : 'string'	},
	          {name : 'partCd',					type : 'string'	},
	          {name : 'docRefNo',				type : 'string'	},
	          {name : 'cmpnyCd',				type : 'string'	},
	          {name : 'customer',				type : 'string'	}
	         ]
});

Ext.define('CustInvcEntryGP', {
	extend : 'Ext.data.Model',
	fields : [{		
  		name : 'dfltPtyCrncyCd',
		type : 'string'	
	},{
		name : 'dfltSysCrncyCd',
		type : 'string'
	},{
		name : 'dfltCmpnyCrncyCd',
		type : 'string'
	},{
		name : 'cstmrAckRcvdFlg',
		type : 'string'
	},{
		name : 'appAdvcRejectFlg',
		type : 'string'
	},{
		name : 'totSrvcAmnt',
		type : 'string'
	},{
		name : 'totAmntSysCrncy',
		type : 'string'
	},{
		name : 'totAmntPtyCrncy',
		type : 'string'
	},{
		name : 'totAmntCmpnyCrncy',
		type : 'string'
	},{
		name : 'totTaxAmnt',
		type : 'string'
	},{
		name : 'totAmnt',
		type : 'string'
	},{
		name : 'prfInvcNo',
		type : 'string'
	},{
		name : 'custCode',
		type : 'string',
		mandatory:true
	},{
		name : 'custName',
		type : 'string'
	},{
		name : 'invcNum',
		type : 'string'
	},{
		name : 'invcDate',
		type:'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'invcDueDate',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){				
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'invcRefNum',
		type : 'string'
	},{
		name : 'currency',
		type : 'string'
	},{
		name : 'profitLossCentre',
		type : 'string'
	},{
		name : 'printTemplate',
		type : 'string',
		mandatory:true
	},{
		name : 'prfStatus',
		type : 'string'
	},{
		name : 'prfStatusDesc',
		type : 'string'
	},{
		name : 'remarks',
		type : 'string'
	},{
		name : 'docType',
		type : 'string'
	},{
		name : 'invcType',
		type : 'string'
	},{
		name : 'party',
		type : 'string',
		mandatory:true
	},{
		name : 'name',
		type : 'string',
		mandatory:true
	},{
		name : 'addLane1',
		type : 'string'
	},{
		name : 'addLane2',
		type : 'string'
	},{
		name : 'city',
		type : 'string'
	},{
		name : 'stateProv',
		type : 'string'
	},{
		name : 'country',
		type : 'string'
	},{
		name : 'zipPostalCd',
		type : 'string'
	},{
		name:'validated',
		type:'bool'
	},{
		name:'status',
		type:'string'
	},{
		name : 'version',
		type : 'integer'
	}]
});

Ext.define('CustInvcEntryPG', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'itemNumber',
		type : 'integer'
	},{
		name : 'prfInvcNo',
		type : 'string'
	},{
		name : 'totSrvAmtInvcCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtPtyCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtSysCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtCmpnyCrncy',
		type : 'string'
	},{
		name : 'summId',
		type : 'string'
	},{
		name : 'srvCode',
		type : 'string',
		mandatory:true
	},{
		name : 'srvType',
		type : 'string'
	},{
		name : 'srvDesc',
		type : 'string',
		mandatory:true
	},{
		name : 'srvcGrp',
		type : 'string',
		mandatory:true
	},{
		name : 'evntLdRef',
		type : 'string'
	},{
		name : 'unitId',
		type : 'string'
	},{
		name : 'convncId',
		type : 'string'
	},{
		name : 'convncType',
		type : 'string'
	},{
		name : 'convncNm',
		type : 'string'
	},{
		name : 'shipngRefNo',
		type : 'string'
	},{
		name : 'storageType',
		type : 'string'
	},{
		name : 'cargoType',
		type : 'string'
	},{
		name : 'modelLine',
		type : 'string'
	},{
		name : 'billOfLading',
		type : 'string'
	},{
		name : 'transptCd',
		type : 'string'
	},{
		name : 'makeCd',
		type : 'string'
	},{
		name : 'modelCd',
		type : 'string'
	},{
		name : 'modelGrp',
		type : 'string'
	},{
		name : 'modelYear',
		type : 'string'
	},{
		name : 'trnsptMode',
		type : 'string'
	},{
		name : 'rateTier',
		type : 'string'
	},{
		name : 'wrkOrder',
		type : 'string'
	},{
		name : 'partId',
		type : 'string'
	},{
		name : 'orgnLoc',
		type : 'string'
	},{
		name : 'orgnAdd1',
		type : 'string'
	},{
		name : 'orgnAdd2',
		type : 'string'
	},{
		name : 'orgnLocCty',
		type : 'string'
	},{
		name : 'orgnLocStP',
		type : 'string'
	},{
		name : 'orgnCntryCd',
		type : 'string'
	},{
		name : 'orgnZipPostalCd',
		type : 'string'
	},{
		name : 'destCd',
		type : 'string'
	},{
		name : 'destAdd1',
		type : 'string'
	},{
		name : 'destAdd2',
		type : 'string'
	},{
		name : 'destCity',
		type : 'string'
	},{
		name : 'destStateProv',
		type : 'string'
	},{
		name : 'destCntryCd',
		type : 'string'
	},{
		name : 'destZipPostalCd',
		type : 'string'
	},{
		name : 'tndrReqDt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){				
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'shipntDt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'delCmpltDt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'origOrg',
		type : 'string'
	},{
		name : 'finalDest',
		type : 'string'
	},{
		name : 'd2dval',
		type : 'string'
	},{
		name : 'd2dUom',
		type : 'string'
	},{
		name : 'ratingDest',
		type : 'string'
	},{
		name : 'd2rval',
		type : 'string'
	},{
		name : 'd2rUom',
		type : 'string'
	},{
		name : 'minNum',
		type : 'string'
	},{
		name : 'prftLossCent',
		type : 'string'
	},{
		name : 'custSlsRgn',
		type : 'string'
	},{
		name : 'shmntType',
		type : 'string'
	},{
		name : 'ordrTyp',
		type : 'string'
	},{
		name : 'abnrmMvType',
		type : 'string'
	},{
		name : 'dlrCd',
		type : 'string'
	},{
		name : 'suplrCd',
		type : 'string'
	},{
		name : 'consolId',
		type : 'string'
	},{
		name : 'consolType',
		type : 'string'
	},{
		name : 'uom1',
		type : 'string',
		mandatory:true
	},{
		name : 'qntty1',
		type : 'string'
	},{
		name : 'uom2',
		type : 'string'
	},{
		name : 'qntty2',
		type : 'string'
	},{
		name : 'rtbsis',
		type : 'string'
	},{
		name : 'rate',
	//	type : 'string',
		type : 'float',
		mandatory : true
		/*convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}*/
	},{
		name : 'srvcAmt',
	//	type : 'string',
		type : 'float',
		mandatory : true
		/*convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}*/
	},{
		name : 'oldSrvcAmt',
		type : 'String'
	},{
		name:'status',
		type:'string'
	},{
		name:'fuelSrchrgFlg',
		type:'string'
	},{
		name:'fixedTrfUnitRate',
		type:'string'
	},{
		name:'srvAmtPtyCrncy',
		type:'string'
	},{
		name:'srvAmtSysCrncy',
		type:'string'
	},{
		name:'srvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'taxAmtInvcCrncy',
		type:'string'
	},{
		name:'taxAmtPtyCrncy',
		type:'string'
	},{
		name:'taxAmtSysCrncy',
		type:'string'
	},{
		name:'taxAmtCmpnyCrncy',
		type:'string'
	},{
		name:'ptyCrncyExchngRate',
		type:'string'
	},{
		name:'sysCrncyExchngRate',
		type:'string'
	},{
		name:'cmpnyCrncyExchngRate',
		type:'string'
	},{
		name:'paidSrvAmtInvcCrncy',
		type:'string'
	},{
		name:'paidSrvAmtPtyCrncy',
		type:'string'
	},{
		name:'paidSrvAmtSysCrncy',
		type:'string'
	},{
		name:'paidSrvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'paidTaxAmtInvcCrncy',
		type:'string'
	},{
		name:'paidTaxAmtPtyCrncy',
		type:'string'
	},{
		name:'paidTaxAmtSysCrncy',
		type:'string'
	},{
		name:'paidTaxAmtCmpnyCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtInvcCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtPtyCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtSysCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'srvMsrType1',
		type:'string'
	},{
		name:'srvMsrType2',
		type:'string'
	},{
		name:'cstmrDeptNm',
		type:'string'
	},{
		name : 'totTaxAmtPerLineItem',
		type : 'float'
	},{
		name:'invcItemSts',
		type:'string'
	},{
		name:'validated',
		type:'bool'
	}],
	hasMany: {
       model:'CustInvcEntryCG', 
       name: 'customerInvoiceTaxDtlsDTO'
    }
});

Ext.define('CustInvcEntryCG', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'summId',
		type : 'string'
	},{
		name : 'revenCd',
		type : 'string'
	},{
		name : 'costCd',
		type : 'string'
	},{
		name : 'calOnSrvcAmtFlg',
		type : 'string'
	},{
		name : 'calOnTaxTypeCd',
		type : 'string'
	},{
		name : 'invcCrncyCd',
		type : 'string'
	},{
		name : 'taxTyp',
		type : 'string'
	},{
		name : 'taxPercnt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}
	},{
		name : 'srvcAmt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}
	},{
		name : 'taxAmt',
		type : 'string',
		convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}
	},{
		name:'status',
		type:'string'
	}],
	belongsTo: 'CustInvcEntryPG'
});

Ext.define('OceanSupplierReconciliationDtls', {
	extend : 'Ext.data.Model',
	fields : [
	    {name : 'pol', 				type : 'string'},
	    {name : 'pod', 				type : 'string'},
	    {name : 'blNum', 			type : 'string'},
	    {name : 'voyage', 			type : 'string'},
	    {name : 'vesselCd', 		type : 'string'},
		{name : 'evntAmt', 			type : 'string'},
		{name : 'taxAmt', 			type : 'string'},
		{name : 'totAmt', 			type : 'string'},
		{name : 'comment', 			type : 'string'}
	]
});

Ext.define('OceanSupplierReconciliation', {
	extend : 'Ext.data.Model',
	fields : [
		{name : 'companyCd', 		type : 'string'},
		{name : 'custCd', 			type : 'string'},
		{name : 'supCode', 			type : 'string'},
		{name : 'invcNum', 			type : 'string'},
		{name : 'serviceCode', 		type : 'string'},
		{name : 'blNum', 			type : 'string'},
		{name : 'blCmpltDttm', 		type : 'string'},
		{name : 'voyage', 			type : 'string'},
		{name : 'cargoType', 		type : 'string'},
		{name : 'cargoClass', 		type : 'string'},
		{name : 'freightTerms', 	type : 'string'},
		{name : 'pol', 				type : 'string'},
		{name : 'pod', 				type : 'string'},
		{name : 'por', 				type : 'string'},
		{name : 'pfd', 				type : 'string'},
		{name : 'vesselCd', 		type : 'string'},
		{name : 'vesselName', 		type : 'string'},
		{name : 'makeCd', 			type : 'string'},
		{name : 'modelCd', 			type : 'string'},
		{name : 'pftLossCent', 		type : 'string'},
		{name : 'supAmt', 			type : 'string'},
		{name : 'evntAmt', 			type : 'string'},
		{name : 'status', 			type : 'string'},
		{name : 'mismatchReason', 	type : 'string'},
		{name : 'dueFromDate', 		type : 'string'},
		{name : 'dueToDate', 		type : 'string'},
		{name : 'intBlNum', 		type : 'string'},
		{name : 'itemSeqNum ', 		type : 'string'},
		{name : 'itemNum', 			type : 'string'},
		{name : 'summId', 			type : 'string'},
		{name : 'prfInvcNum', 		type : 'string'},
		{name : 'invcItemNum', 		type : 'string'},
		{name : 'errNum', 			type : 'string'},
		{name : 'errDesc', 			type : 'string'},
		{name : 'partialPaymntFlg', type : 'string'},
		{name : 'invcAutoAprvFlg', 	type : 'string'},
		{name : 'invcCrdtNoteInd', 	type : 'string'},
		{name : 'transType', 		type : 'string'}
	]
});

/*Ext.define('User', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'deptno',
		type : 'integer'
	}, {
		name : 'dname',
		type : 'string'
	}, {
		name : 'loc',
		type : 'string'
	} ]
});*/

Ext.define('PurgeFrequency', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'description',
		type : 'string'
	}, {
		name : 'generationFrequency',
		type : 'string'
	}]
});

Ext.define('Purging', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'messageType',
		type : 'string'
	}, {
		name : 'purgingDays',
		type : 'integer'
	},{
		name : 'status',
	    type : 'string'
	},{
		name:'rno',
		type:'integer'
	},{
		name:'oldMsgVal',
		type:'string'
	}
	]
});


Ext.define('monthData',{
	extend:'Ext.data.Model',
	fields:[{
		name:'Month',
		type:'string'
	}]
});

Ext.define('everyModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'value',
		type:'string'
	},
	{
		name:'data',
		type:'string'
	}]
});



Ext.define('SwimPartnerDetails',{
	extend:'Ext.data.Model',
	fields : [{
		name:'intPrtnrCd',
		type:'integer'
	},{
		name:'partnerCd',
		type:'string'
	},{
		name:'partnerNm',
		type:'string'
	},{
		name:'address1',
		type:'string'
	},{
		name:'address2',
		type:'string'
	},{
		name:'city',
		type:'string'
	},{
		name:'country',
		type:'string'
	},{
		name:'zip',
		type:'string'
	},{
		name:'telephone',
		type:'string'
	},{
		name:'fax',
		type:'string'
	},{
		name:'contactEmailId',
		type:'string'
	},{
		name:'alertEmailId',
		type:'string'
	},{
		name:'alertEmailFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'repeatableJob',
		type:'string'
	},{
		name:'repetitionFrequency',
		type:'string'
	},{
		name:'strstartTime',
		type:'string'
	},{
		name:'singleOnDate',
		type:'string'
	},{
		name:'singleOnTime',
		type:'string'
	},{
		name:'year',
		type:'integer'
	},{
		name:'month',
		type:'integer'
	},{
		name:'weekDay',
		type:'integer'
	},{
		name:'day',
		type:'integer'
	},{
		name:'hour',
		type:'integer'
	},{
		name:'minute',
		type:'integer'
	},{
		name:'second',
		type:'integer'
	},{
		name:'interval',
		type:'integer'
	},{
		name : 'gridFrequencyValue',
		type : 'String'
	},{
		name : 'gridOnColumn',
		type : 'String'
	},{
		name : 'gridMonthColumn',
		type : 'String'
	},
	{
		name : 'gridOnTimeColumn',
		type : 'String'
	}
	]
});

Ext.define('SwimProcessAdminPartnerDetails',{
	extend:'Ext.data.Model',
	fields : [{
		name:'partnerCd',
		type:'string'
	},{
		name:'sendReceiveInd',
		type:'string'
	},{
		name:'msgEnableFlag',
		type:'string',
		convert:function(v){
			return (v === "Y") ? "Running" : "Stopped";
		}
	},{
		name:'lastReqDate',
		dateFormat:Modules.GlobalVars.dateFormatGlobal,
		type:'date'
	},{
		name:'lastReqTime',
		type : 'date',
		dateFormat:Modules.GlobalVars.timeFormatGlobal
	},{
		name:'userName',
		type:'string'
	}]
});

Ext.define('Event', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'lineNumber',
		type : 'string'
	}, {
		name : 'cargoClass',
		type : 'string'
	}, {
		name : 'cargoType',
		type : 'string'
	}  ,{
		name : 'chargeCode',
		type : 'string'
	}, {
		name : 'commodityDesc',
		type : 'string'
	}, {
		name : 'chargeCodeDesc',
		type : 'string'
	}, {
		name : 'freightTerm',
		type : 'string'
	}, {
		name : 'pop',
		type : 'string'
	}, {
		name : 'popDesc',
		type : 'string'
	}, {
		name : 'HandlingIndi',
		type : 'string'
	}, {
		name : 'transferGear',
		type : 'string'
	}, {
		name : 'steeringLeftOrRight',
		type : 'string'
	}, {
		name : 'lineItemQuantity',
		type : 'string'
	}, {
		name : 'rate',
		type : 'string'
	}, {
		name : 'rateBasis',
		type : 'string'
	}, {
		name : 'manifestCurrency',
		type : 'string'
	}, {
		name : 'manifestAmount',
		type : 'string'
	}, {
		name : 'exchageRate',
		type : 'string'
	}, {
		name : 'localCurrency',
		type : 'string'
	}, {
		name : 'localAmount',
		type : 'string'
	}, {
		name : 'usdAmount',
		type : 'string'
	}, {
		name : 'glCode',
		type : 'string'
	}, {
		name : 'taxAmount',
		type : 'string'
	}]
});

Ext.define('SuppCode', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'suppCode',
		type : 'string'
	}, {
		name : 'suppName',
		type : 'string'
	}]
});

Ext.define('CustCode', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'customerCode',
		type : 'string'
	}, {
		name : 'customerName',
		type : 'string'
	}]
});


Ext.define('roundingTypeModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'value',
		type:'string'
	},
	{
		name:'text',
		type:'string'
	}]
});

Ext.define('MsgProSts', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'msgProStscode',
		type : 'string'
	}, {
		name : 'msgProStsdes',
		type : 'string'
	}]
});
Ext.define('MessgeType', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'msgTypecode',
		type : 'string'
	}, {
		name : 'messageTypeDes',
		type : 'string'
	}]
});


Ext.define('EventGrid', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'eventLogID',
		type : 'integer'
	}, {
		name : 'eventDttm',
		type : 'string'
	}, {
		name : 'msgTypecode',
		type : 'string'
	}, {
		name : 'msgProcsts',
		type : 'string'
	}  ,{
		name : 'suppCode',
		type : 'string'
	}, {
		name : 'custCode',
		type : 'string'
	}, {
		name : 'unitId',
		type : 'string'
	},{
		name : 'shipRef',
		type : 'string'
	},{
		name : 'invNo',
		type : 'string'
	},{
		name : 'payDocno',
		type : 'string'
	},{
		name : 'itemNo',
		type : 'string'
	},{
		name : 'srvCode',
		type : 'string'
	}]
});

Ext.define('sendMsg',{
	extend:'Ext.data.Model',
	fields:[{
		name:'partnerCd',
		type:'string'	
	},
	{
		name:'messageName',
		type:'string'
	},
	{
		name:'noOfMsgPerFile',
		type:'integer'	
	},{
		name:'task_id',
		type:'integer'	
	},
	{
		name:'taskIntervel',
		type:'string'
	},
	{
		name:'lDesc',
		type:'string'	
	},{
		name:'taskName',
		type:'integer'	
	},
	{
		name:'programName',
		type:'string'
	},
	{
		name:'enableFlag',
		type:'string'	
	},
	{
		name:'programType',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rno',
		type:'string'
	}]
});


Ext.define('SwimGroupPartnerMap',{
	extend:'Ext.data.Model',
	fields : [{
		name:'groupCd',
		type:'string'
	},{
		name:'groupName',
		type:'string'
	},{
		name:'cmpnyCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'cstmrCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'abnrmlmvCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'crncyCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'conveyanceCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'ordCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'locCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'rateBasisCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'rateTierCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'shipmentCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'srvTaxCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'suppCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'trnsptCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'uomCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'makeModelCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'stCtyCd',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'plantRef',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'mrktArea',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'consolidationType',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'modelGroup',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'timeZone',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'status',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
	}]
});

Ext.define('SwimGrpPrtnrGridModel',{
	extend:'Ext.data.Model',
	fields : [{
		name:'partnerCd',
		type:'string'
	},{
		name:'associatedPrtnr',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	}]
});

Ext.define('backendJobs',{
	extend:'Ext.data.Model',
	fields:[{
		name:'jobName',
		type:'string'
	},
	{
		name:'startDate',
		type:'string'
	},
	{
		name:'repeatInterval',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	}]
});

Ext.define('errMsgModel',{
	extend:'Ext.data.Model',
	fields:[
	       {
		name:'frequencyCode',
		type:'string'
	},    
	{
		name:'companyCode',
		type:'string'
	},
	{
		name:'companyName',
		type:'string'
	},
	{
		name:'timeFirstRun',
		type:'string'
	},
	{
		name:'interval',
		type:'integer'
	},
	{
		name:'lastExecTime',
		type:'string'
	},
	{
		name:'nextExecTime',
		type:'string'
	},
	{
		name:'exclusionList',
		type:'string'
	}  
	]
});


Ext.define('autoReprcFreq', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'frequency',
		type : 'string'
	}, {
		name : 'freqname',
		type : 'string'

	}]
});


Ext.define('srvcTypeModel',{
	extend:'Ext.data.Model',
	fields:[
	 {
	    name:'serviceType',
	   	type:'string'
	 },
	 {
		 name:'srvcTypeNm',
		 type:'string'
		
	 }
	]
});


Ext.define('GenericLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'

	},{
		name : 'defaultFlag',
		type : 'string',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},{
		name : 'serviceTypeGroupCode',
		type : 'string'	
	},{
		name : 'accessCode',
		type : 'string'	
	},{
		name : 'exchangeRate',
		type : 'string'	
	}]
});

Ext.define('DashBoardEdiErrMsgs', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'partnerCode',
		type : 'string'
	}, {
		name : 'msgType',
		type : 'string'
	},{
		name : 'noOfErrs',
		type : 'integer'
	}
	]
});



Ext.define('PartnerCode', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'partnerCode',
		type : 'string'
	}, {
		name : 'partnerName',
		type : 'string'

	}]

});

Ext.define('GenericSuplrCustmerStatusLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'

	}]

});

Ext.define('srvcMasterStore',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'srvcType',
	        	type:'string'
	        },
	        {
	        	name:'srvcCd',
	        	type:'string'
	        },
	        {
	        	name:'srvcDesc',
	        	type:'string'
	        },
	        {
	        	name:'srvcDesc2',
	        	type:'string'
	        },
            {
	        	name:'consolidationCat',
	        	type:'string'
	        },
	        {
	        	name:'fuelSurchrgSrvc',
	    		type:'bool',convert:function(v)
	    		   {
	    			return (v === "Y" || v === true || v === "") ? true : false;
	    		   }
	        },
	        {
	        	name:'fuelSurchrgApp',
	    		type:'bool',convert:function(v)
	    		   {
	    			return (v === "Y" || v === true || v === "") ? true : false;
	    		   }
	        },
	        {
	    		name : 'status',
	    	    type : 'string'
	    	  }
	        ]
});


Ext.define('tariffMasterStore',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'tariffCd',
	        	type:'string'
	        },
	        {
	        	name:'tariffDesc',
	        	type:'string'
	        },
	        {
	        	name:'effectiveDt',
	        	type:'date'
	        },
	        {
	        	name:'tariffUnitRate',
	        	type:'string'
	        },
            {
	        	name:'currency',
	        	type:'string'
	        },
	        {
	        	name:'slab',
	    		type:'bool',convert:function(v)
	    		   {
	    			return (v === "Y" || v === true || v === "") ? true : false;
	    		   }
	        },
	        {
	        	name:'cmltv',
	    		type:'bool',convert:function(v)
	    		   {
	    			return (v === "Y" || v === true || v === "") ? true : false;
	    		   }
	        },
	        {
	    		name : 'status',
	    	    type : 'string'
	    	  }
	        ]
});




Ext.define('companyCdModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'companyName',
		type:'string'
	}]
});



Ext.define('statusMonitoringGridData', {
	extend : 'Ext.data.Model',
	fields : [  {
		name : 'messHdrId',
		type : 'int'

	},{
		name : 'fileContrlRefNo',
		type : 'string'

	} , {
		name : 'msgContrlRefNo',
		type : 'string'
	}, {
		name : 'msgSentRecDTMM',
		type : 'date',
		dateFormat:'Y-m-d H:i:s.u'/*,
		convert : function(value){
			if(!Ext.isEmpty(value)){
				var dateFormat=Ext.Date.parse(value,"Y-m-d H:i:s.u");
				return Ext.util.Format.date(dateFormat,"d/m/Y H:i:s");
			}
			else return null;
		}*/
	},{
		name : 'messTypeCode',
		type : 'string'

	}, {
		name : 'messUpDownLoad',
		type : 'string'
	}, {
		name : 'partnerCode', 
		type : 'string'

	},{
		name : 'companyCode',
		type : 'string'

	}, {
		name : 'invoiceNO',
		type : 'string'
	}, {
		name : 'extSRVCode',
		type : 'string'

	},{
		name : 'extSupplierCode',
		type : 'string'

	}, {
		name : 'extCustomerCode',
		type : 'string'
	}, {
		name : 'loadRefNO',
		type : 'string'

	},{
		name : 'workOrder',
		type : 'string'

	}, {
		name : 'paymentDocNo',
		type : 'string'
	}, {
		name : 'xfrSeqNo',
		type : 'string'

	},{
		name : 'extOriginCode',
		type : 'string'

	}, {
		name : 'extDestinCode',
		type : 'string'
	}, {
		name : 'shipngRefNO',
		type : 'string'

	},{
		name : 'messTransStatus',
		type : 'string'

	},{
		name : 'messProcessStatus',
		type : 'string'

	}, {
		name : 'noOfRecs',
		type : 'integer'
	}, {
		name : 'noOErrorRecs',
		type : 'integer'

	},{
		name : 'noOfErrorRecsUpDownLoad',
		type : 'integer'

	},{
		name : 'intFileNo',
		type : 'integer'

	}
	, {
		name : 'billNbr',
		type : 'string'
	}, {
		name : 'pop',
		type : 'string'

	},{
		name : 'voyage',
		type : 'string'

	},{
		name : 'sailingDate',
		type : 'string'

	},{
		name : 'freightTerm',
		type : 'string'

	}, {
		name : 'pol',
		type : 'string'
	}, {
		name : 'pod',
		type : 'string'

	}, {
		name : 'oceanShipmentRefNbr',
		type : 'string'
	}, {
		name : 'vessel',
		type : 'string'

	}, {
		name : 'customerName',
		type : 'string'

	}]

});

Ext.define('MessType', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'messCode',
		type : 'string'
	}, {
		name : 'messDes',
		type : 'string'
	}]
});

Ext.define('DashBoardSupplierRecnStat', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'invcStatus',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	},{
		name : 'currency',
		type : 'string'
	},
	{
		name : 'pastDueCount',
		type : 'integer'
	}, {
		name : 'pastDueAmount',
		type : 'float'
	},
	{
		name : 'due0_5DaysCount',
		type : 'integer'
	}, {
		name : 'due0_5DaysAmount',
		type : 'float'
	},{
		name : 'due6_15DaysCount',
		type : 'integer'
	}, {
		name : 'due6_15DaysAmount',
		type : 'float'
	},{
		name : 'due16_30DaysCount',
		type : 'integer'
	}, {
		name : 'due16_30DaysAmount',
		type : 'float'
	},{
		name : 'due30_DaysCount',
		type : 'integer'
	}, {
		name : 'due30_DaysAmount',
		type : 'float'
	}
	]
});

Ext.define('DashBoardSupplierInvStat', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'pymntTerm',
		type : 'integer'
	}, {
		name : 'status',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'count0_15Days',
		type : 'integer'
	}, {
		name : 'invAmnt0_15Days',
		type : 'float'
	}, {
		name : 'appvdAmnt0_15Days',
		type : 'float'
	}, {
		name : 'count16_30Days',
		type : 'integer'
	}, {
		name : 'invAmnt16_30Days',
		type : 'float'
	}, {
		name : 'appvdAmnt16_30Days',
		type : 'float'
	}, {
		name : 'count31_60Days',
		type : 'integer'
	}, {
		name : 'invAmnt31_60Days',
		type : 'float'
	}, {
		name : 'appvdAmnt31_60Days',
		type : 'float'
	}, {
		name : 'count61_180Days',
		type : 'integer'
	}, {
		name : 'invAmnt61_180Days',
		type : 'float'
	}, {
		name : 'appvdAmnt61_180Days',
		type : 'float'
	}, {
		name : 'invcItemstatus',
		type : 'string'
	}
	]
});

Ext.define('GenericSuplrCustmerLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'

	},{
		name : 'addr_1',
		type : 'string'
	},{
		name : 'addr_2',
		type : 'string'
	},{
		name : 'city_nm',
		type : 'string'
	},{
		name : 'state_cd',
		type : 'string'
	},{
		name : 'cntry_cd',
		type : 'string'
	},{
		name : 'po_box',
		type : 'string'
	},{
		name : 'rmrk',
		type : 'string'
	}]
});

Ext.define('GenericLocationLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'

	},{
		name : 'addr_1',
		type : 'string'
	},{
		name : 'addr_2',
		type : 'string'
	},{
		name : 'city_nm',
		type : 'string'
	},{
		name : 'state_cd',
		type : 'string'
	},{
		name : 'cntry_cd',
		type : 'string'
	},{
		name : 'po_box',
		type : 'string'
	},{
		name : 'rmrk',
		type : 'string'
	}]
});


Ext.define('ApplicationAdvice', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'unitId',
		type : 'string'
	}, {
		name : 'itemNo',
		type : 'string'

	},{
		name : 'documentRefNo',
		type : 'string'
	},{
		name : 'techErrorCode',
		type : 'string'
	},{
		name : 'techErrorDesc',
		type : 'string'
	},{
		name : 'refErrorCode',
		type : 'string'
	},{
		name : 'refErrorDesc',
		type : 'string'
	}]
});

Ext.define('StateProvinceLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'state_cd',
		type : 'string'
	}, {
		name : 'state_nm',
		type : 'string'

	},{
		name : 'cntry_cd',
		type : 'string'
	},{
		name : 'cntry_nm',
		type : 'string'
	}]
});




Ext.define('EventMsgDtls', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'customerCode',
		type : 'string'
	}, {
		name : 'unitId',
		type : 'string'
	}, {
		name : 'extCustomerCode',
		type : 'string'
	}, {
		name : 'partCode',
		type : 'string'
	}, {
		name : 'extMakeCode',
		type : 'string'
	}, {
		name : 'extModel',
		type : 'string'
	}, {
		name : 'extModelGroupCode',
		type : 'string'
	}, {
		name : 'extAbnormalMoveType',
		type : 'string'
	}, {
		name : 'extOrderType',
		type : 'string'
	}, {
		name : 'weight',
		type : 'float'
	}, {
		name : 'length',
		type : 'float'
	}, {
		name : 'width',
		type : 'float'
	},{
		name : 'height',
		type : 'float'
	}, {
		name : 'volume',
		type : 'float'
	}, {
		name : 'quantity',
		type : 'float'
	}, {
		name : 'storageQty',
		type : 'float'
	}, {
		name : 'storageUOMCode',
		type : 'string'
	}, {
		name : 'previousChrgQty',
		type : 'float'
	}, {
		name : 'previousChrgUOMCode',
		type : 'string'
	}, {
		name : 'extStorageUOMCode',
		type : 'string'
	}, {
		name : 'extPreviousChrgUOMCode',
		type : 'string'
	}, {
		name : 'shipmentType',
		type : 'string'
	}, {
		name : 'shippingReference',
		type : 'string'
	}, {
		name : 'transportCode',
		type : 'string'
	}, {
		name : 'customerSalesRegion',
		type : 'string'
	}, {
		name : 'extRateTierCode',
		type : 'string'
	}, {
		name : 'extConveyanceType',
		type : 'string'
	}, {
		name : 'extDestination',
		type : 'string'
	}, {
		name : 'extDestinationState',
		type : 'string'
	}, {
		name : 'extDestinationCountry',
		type : 'string'
	}, {
		name : 'extFinalDestination',
		type : 'string'
	}, {
		name : 'extFinalDestinationState',
		type : 'string'
	}, {
		name : 'extFinalDestinationCountry',
		type : 'string'
	}, {
		name : 'supplierRateSentFlg',
		type : 'bool',
		convert : function(v, record) {
			return (v === "Y" || v === true) ? true : false;
		}

	}, {
		name : 'supplierNotChargeableFlg',
		type : 'bool',
		convert : function(v, record) {
			return (v === "Y" || v === true) ? true : false;
		}
	}, {
		name : 'supplierServiceAmount',
		type : 'float'
	}, {
		name : 'extSupplierCurrencyCode',
		type : 'string'
	}, {
		name : 'supplierCurrencyCode',
		type : 'string'
	}, {
		name : 'customerRateSentFlg',
		type : 'bool',
		convert : function(v, record) {
			return (v === "Y" || v === true) ? true : false;
		}
	}, {
		name : 'customerNotChargeableFlg',
		type : 'bool',
		convert : function(v, record) {
			return (v === "Y" || v === true) ? true : false;
		}
	}, {
		name : 'customerServiceAmount',
		type : 'float'
	}, {
		name : 'extCustomerCurrencyCode',
		type : 'string'
	}, {
		name : 'customerCurrencyCode',
		type : 'string'
	}, {
		name : 'finalDestination',
		type : 'string'
	}, {
		name : 'finalDestinationAddress1',
		type : 'string'
	}, {
		name : 'finalDestinationAddress2',
		type : 'string'
	}, {
		name : 'finalDestinationCity',
		type : 'string'
	}, {
		name : 'finalDestinationZIP',
		type : 'string'
	}, {
		name : 'reference1',
		type : 'string'
	}, {
		name : 'reference2',
		type : 'string'
	}, {
		name : 'reference3',
		type : 'string'
	}, {
		name : 'reference4',
		type : 'string'
	}, {
		name : 'reference5',
		type : 'string'
	}, {
		name : 'reference6',
		type : 'string'
	}, {
		name : 'reference7',
		type : 'string'
	}, {
		name : 'reference8',
		type : 'string'
	}, {
		name : 'reference9',
		type : 'string'
	}, {
		name : 'reference10',
		type : 'string'
	}, {
		name : 'make',
		type : 'string'
	}, {
		name : 'modelCode',
		type : 'string'
	}, {
		name : 'modelName',
		type : 'string'
	}, {
		name : 'modelLine',
		type : 'string'
	}, {
		name : 'modelYear',
		type : 'string'
	}, {
		name : 'modelGroupCode',
		type : 'string'
	}, {
		name : 'shipmentType',
		type : 'string'
	}, {
		name : 'rateTier',
		type : 'string'
	}, {
		name : 'conveyanceType',
		type : 'string'
	}, {
		name : 'stroageType',
		type : 'string'
	}, {
		name : 'cargoType',
		type : 'string'
	}, {
		name : 'abnormalMoveType',
		type : 'string'
	}, {
		name : 'destination',
		type : 'string'
	},
	{
		name : 'destinationAddress1',
		type : 'string'
	}, {
		name : 'destinationAddress2',
		type : 'string'
	}, {
		name : 'destinationCity',
		type : 'string'
	}, {
		name : 'destinationState',
		type : 'string'
	}, {
		name : 'destinationCountry',
		type : 'string'
	}, {
		name : 'destinationZIP',
		type : 'string'
	}, {
		name : 'dealerCode',
		type : 'string'
	}, {
		name : 'orderType',
		type : 'string'
	}, {
		name : 'debtorParty',
		type : 'string'
	}, {
		name : 'extDealerCode',
		type : 'string'
	} ]
});



Ext.define('AccPayDtls',{
	extend:'Ext.data.Model',
	fields:[{
		name:'glCode',
		type:'string'
	},{
		name:'profitlossCenter',
		type:'string'
	},
	{
		name:'cutomerCode',
		type:'string'
	},{
		name:'externalCutomerCode',
		type:'string'
	},
	{
		name:'cutomerContactNo',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
	},
	{
		name:'serviceAmount',
		type:'float'
	},{
		name:'srvCdTaxType',
		type:'string'
	},{
		name:'srvTaxTypeCd',
		type:'string'
	},{
		name:'extSrvTaxTypeCd',
		type:'string'
	},{
		name:'srvTaxTypeCdDesc',
		type:'string'
	},{
		name:'documentType',
		type:'string'
		
	},
	{
		name:'creditdebit',
		type:'string'
	},
	{
		name:'originCd',
		type:'string'
	},
	{
		name:'extOrginCd',
		type:'string'
	},
	{
		name:'cusSubLedgerCd',
		type:'string'
	},
	{
		name:'supplierApprovedDate',
		type:'string'	
	},
	{
	    name:'pod',
        type:'string'		  
	},
	{
		name:'blNumber',
		type:'string'
	},
	{
		name:'tnxType',
		type:'string'
	},
	{
		name:'invcAmtUsdCurrency',
		type:'string'
	}
	]
});



Ext.define('AccRecDtls',{
	extend:'Ext.data.Model',
	fields:[{
		name:'glCode',
		type:'string'
	},{
		name:'profitlossCenter',
		type:'string'
	},
	{
		name:'supplierCode',
		type:'string'
	},{
		name:'externalSupplierCode',
		type:'string'
	},
	{
		name:'cutomerContactNo',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
	},
	{
		name:'serviceAmount',
		type:'float'
	},{
		name:'srvCdTaxType',
		type:'string'
	},{
		name:'srvTaxTypeCd',
		type:'string'
	},{
		name:'extSrvTaxTypeCd',
		type:'string'
	},{
		name:'srvTaxTypeCdDesc',
		type:'string'
	},{
		name:'documentType',
		type:'string'
		
	},
	{
		name:'creditdebit',
		type:'string'
	},
	{
		name:'originCd',
		type:'string'
	},
	{
		name:'extOrginCd',
		type:'string'
	},
	{
		name:'supplierInvoiceNo',
		type:'string'
	},
	{
	    name:'pod',
        type:'string'		  
	},
	{
		name:'blNumber',
		type:'string'
	},
	{
		name:'tnxType',
		type:'string'
	},
	{
		name:'invcAmtUsdCurrency',
		type:'string'
	},
	{
		name:'originalInvcNbr',
    	type:'string'
	}
	]
});



Ext.define('truckInvoiceDtls',{
	extend:'Ext.data.Model',
	fields:[
	{
	    name:'extInvcChargeType',
	    type:'string'
	},
	{
		name:'unitId',
		type:'string'
	},
	{
		name:'shipmentRef',
		type:'string'
	},
	{
		name:'transportCd',
		type:'string'
	},
	{
		name:'tenderDate',
		type:'string'
	},
	{
		name:'shipmentDate',
		type:'string'
	},
	{
		name:'deliveryDate',
		type:'string'
	},
	{
		name:'extDestination',
		type:'string'
	},
	{
		name:'invcAmt',
		type:'float'
	}],
	associations:[
	              {
            		type:'hasMany',
            	   	model:'truckInvoiceTaxDtls', 
            	   	name: 'taxdetails'
	              }
	              ]
	
	
});

Ext.define('truckInvoiceTaxDtls',{
	extend:'Ext.data.Model',
	fields:[
	{   
		 name:'extInvcChargeType',
		 type:'string'
	},
	{
		name:'taxAmt',
		type:'float'
	},
	{
		name:'totalAmt',
		type:'float'
	},
	{
		name:'taxRate',
		type:'float'
	},
	{
		name:'parentSeqId',
		type:'string'
	}]
});


Ext.define('railInvoiceDtls',{
	extend:'Ext.data.Model',
	fields:[
	{   
		 name:'extInvcChargeType',
		 type:'string'
	},
	{
		name:'invcAmt',
		type:'float'
	},
	{
		name:'srvcUomQuantity',
		type:'integer'
	},
	{
		name:'extUom',
		type:'float'
	},
	{
		name:'freightRate',
		type:'float'
	},
	{
		name:'extRateBasisCd',
		type:'string'
	}]
});


Ext.define('railInvoiceRouting',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'routingSeq',
	        	type:'string'
	        },
	        {
	        	name:'routingCarrierCd',
	        	type:'string'
	        },
	        {
	        	name:'routingCity',
	        	type:'string'
	        }
	       ]
});

Ext.define('railInvoiceEvntDtl',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'unitId',
	        	type:'string'
	        }
	       ]
});


Ext.define('outSupplRemitAdvcPayUnitDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'unitId',
	        	type:'string'
	        	
	        },
	        {
	        	name:'evntLoadRef',
	        	type:'string'
	        },
	        {
	        	name:'conveyanceId',
	        	type:'string'
	        	
	        },
	        {
	        	name:'srvcCd',
	        	type:'string'
	        	
	        },
	        {
	        	name:'extSrvcCd',
	        	type:'string'
	        	
	        },
	        {
	        	name:'paidAmt',
	        	type:'float'
	        	
	        }
	        ]
});

Ext.define('outSupplRemitAdvcPayDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'invcNumber',
	        	type:'string'
	        },
	        {
	        	name:'invcAmt',
	        	type:'float'
	        }
	        ]
});



Ext.define('srvcChrgeInvoiceDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'extInvcChargeType',
	        	type:'string'
	        },
	        {
	        	name:'unitId',
	        	type:'string'
	        },
	        {
	        	name:'extCustomerCd',
	        	type:'string'
	        },
	        {
	        	name:'workOrderNo',
	        	type:'string'
	        },
	        {
	        	name:'tenderDate',
	        	type:'string'
	        },
	        {
	        	name:'deliveryDate',
	        	type:'string'
	        },
	        {
	        	name:'extOriginCd',
	        	type:'string'
	        },
	        {
	        	name:'profitLossCenter',
	        	type:'string'
	        },	        
	        {
	        	name:'shippingRef',
	        	type:'string'
	        },
	        {
	        	name:'productionOrder',
	        	type:'string'
	        },
	        {
	        	name:'extMakeCd',
	        	type:'string'
	        },
	        {
	        	name:'extModelCd',
	        	type:'string'
	        },
	        {
	        	name:'makeCd',
	        	type:'string'
	        },
	        {
	        	name:'modelCd',
	        	type:'string'
	        },
	        {
	        	name:'modelYear',
	        	type:'string'
	        },
	        {
	        	name:'invcAmt',
	        	type:'float'
	        }
	       ],associations:[
	     	              {
	     	            		type:'hasMany',
	     	            	   	model:'truckInvoiceTaxDtls', 
	     	            	   	name: 'taxdetails'
	     		              }
	     		              ]
});



Ext.define('inSupplierRemitAdvcDtls',{
	extend :'Ext.data.Model',
	fields :[
	         {
		        name:'invoiceNumber',
		        type:'string'
	         },
	         {
	        	 name:'supplrPayInvcNo',
	        	 type:'string'
	         },
	         {
	        	 name:'totalAmt',
	        	 type:'float'
	         }]
});



Ext.define('custmrInvcDtls',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
			 name:'itemNo',
			 type:'integer'
		 },
		 {
			 name: 'fuelSurChrge', type: 'bool',convert:function(v)
			 {
	        	return (v === "Y" || v === true || v === "") ? true : false;
	         }
		 },
		
		 {
			 name:'unitId',
			 type:'string'
		 },
		 {
			name:'shippmentRef',
			type:'string'
		 },
		 {
			 name:'make',
			 type:'string'
		 },
		 {
			 name:'externalMake',
			 type:'string'
		 },
		 {
			name:'orderType',
			type:'string'
		 },
		 {
			 name:'extOrderType',
			 type:'string'
		 },
		 {
			 name:'cstrmSaleRegion',
			 type:'string'
		 },
		 {
			 name:'tenderDate',
			 type:'string'
		 },
		 {
			 name:'shippmentDate',
			 type:'string'
		 },
		 {
			 name:'deliveryDate',
			 type:'string'
		 },
		 {
			 name:'transportMode',
			 type:'string'
		 },
		 {
			 name:'extTransportMode',
			 type:'string'
		 },
		 {
			 name:'shipmentType',
			 type:'string'
		 },
		 {
			 name:'extShipmentType',
			 type:'string'
		 },
		 {
			 name:'conveyanceId',
			 type:'string'
		 },
		 {
			 name:'conveyanceType',
			 type:'string'
		 },
		 {
			 name:'extConveyanceType',
			 type:'string'
		 },
		 {
			 name:'supplierCd',
			 type:'string'
		 },
		 {
			 name:'extSupplierCd',
			 type:'string'
		 },
		 {
			 name:'extInvcChrgType',
			 type:'string'
		 },
		 {
			 name:'extOriginCd',
			 type:'string'
		 },
		 {
			 name:'origin',
			 type:'string'
		 },
		 {
			 name:'extOriginCountry',
			 type:'string'
		 },
		 {
			 name:'originCountry',
			 type:'string'
		 },
		 {
			 name:'extStateProv',
			 type:'string'
		 },
		 {
			 name:'originStateProv',
			 type:'string'
		 },
		 {
			 name:'originCity',
			 type:'string'
		 },
		 {
			 name:'originZipPostalCd',
			 type:'string'
		 },
		 {
			 name:'plantNo',
			 type:'string'
		 },
		 {
			 name:'extPlantNo',
			 type:'string'
		 },
		 {
			 name:'marketArea',
			 type:'string'
		 },
		 {
			 name:'extMarketArea',
			 type:'string'
		 },
		 {
			 name:'ref4',
			 type:'string'
		 },
		 {
			 name:'supplrInvcNumber',
			 type:'string'
		 },
		 {
			 name:'destination',
			 type:'string'
		 },
		 {
            name:'extDestination',
            type:'string'	
		 },
		 {
	        name:'destinationCity',
	        type:'string'	
		 },
		 {
		     name:'extDestStateProv',
		     type:'string'	
		 },
		 {
	        name:'destStateProv',
	        type:'string'	
		 },
		 {
	            name:'extDestCountry',
	            type:'string'	
		 },
		 {
	            name:'destZipPostalCd',
	            type:'string'	
		 },	 
		 {
	            name:'destCountry',
	            type:'string'	
		 },
		 {
	            name:'dealer',
	            type:'string'	
		 },
		 {
	            name:'extDealer',
	            type:'string'	
		 },
		 {
	            name:'extDealerCountry',
	            type:'string'	
		 },
		 {
	            name:'dealerCountry',
	            type:'string'	
		 },
		 {
	            name:'extDealerState',
	            type:'string'	
		 },
		 {
	            name:'dealerStateProv',
	            type:'string'	
		 },
		 {
	            name:'dealerAdd',
	            type:'string'	
		 },
		 {
	            name:'dealerZipCdPost',
	            type:'string'	
		 },
		 {
	            name:'dealerCity',
	            type:'string'	
		 },
		 {
	            name:'loadRefNo',
	            type:'string'	
		 },
		 {
	            name:'loadFactor',
	            type:'string'	
		 },
		 {
	            name:'srvcType',
	            type:'string'	
		 },
		 {
	            name:'srvcCd',
	            type:'string'	
		 },
		 {
			 name:'invcAmt',
			 type:'float'
		 },
		 {
			 name:'conveyanceType',
			 type:'string'

		 } ]
});



Ext.define('custmrInvcTaxDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
		        name:'extInvcChargeType',
		        type:'string'
	        },
	        {
			     name:'taxType',
			     type:'string'
		    },
		    {
			     name:'taxRate',
			     type:'integer'
		    },
		    {
			     name:'totalAmt',
			     type:'integer'
		    },
		    {
			     name:'taxAmt',
			     type:'integer'

		    }
	          ]


});


Ext.define('covusInvoiceDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'srvcCd',
	        	type:'string'
	        },
	        {
	        	name:'srvcType',
	        	type:'string'
	        },
	        {
	        	name:'srvcGrp',
	        	type:'string'	
	        },
	        {
	        	name: 'fuelSurChrge', type: 'bool',convert:function(v)
	        	   {
	        		return (v === "Y" || v === true || v === "") ? true : false;
	        	   }
	        },
	        {
	        	name:'srvcDesc',
	        	type:'string'
	        },
	        {
	        	name:'loadRefNo',
	        	type:'string'
	        },
	        {
	        	name:'conveyanceId',
	        	type:'string'
	        },
	        {
	        	name:'transportMode',
	        	type:'string'
	        },
	        {
	        	name:'workOrder',
	        	type:'string'
	        },
	        {
	        	name:'origin',
	        	type:'string'
	        },
	        {
	        	name:'originAddr1',
	        	type:'string'
	        },
	        {
	        	name:'originAddr2',
	        	type:'string'
	        },
	        {
	        	name:'originCity',
	        	type:'string'
	        },
	        {
	        	name:'originStateProv',
	        	type:'string'
	        },
	        {
	        	name:'originCountry',
	        	type:'string'
	        },
	        {
	        	name:'originZipPostalCd',
	        	type:'string'
	        },
	        {
	        	name:'dest',
	        	type:'string'
	        },
	        {
	        	name:'destAddrs1',
	        	type:'string'
	        },
	        {
	        	name:'destAddrs2',
	        	type:'string'
	        },
	        {
	        	name:'destCity',
	        	type:'string'
	        },
	        {
	        	name:'destStateProv',
	        	type:'string'
	        },
	        {
	        	name:'destCountry',
	        	type:'string'
	        },
	        {
	        	name:'destZipPostalCd',
	        	type:'string'
	        },
	        {
	        	name:'originalOrigin',
	        	type:'string'
	        },
	        {
	        	name:'finalDest',
	        	type:'string'
	        },
	        {
	        	name:'tenderDate',
	        	type:'string'
	        },
	        {
	        	name:'shipmentDt',
	        	type:'string'
	        },
	        {
	        	name:'deliveryDate',
	        	type:'string'
	        },
	        {
	        	name:'conveyanceType',
	        	type:'string'
	        },
	        {
	        	name:'conveyanceNm',
	        	type:'string'
	        },
	        {
	        	name:'consolidationId',
	        	type:'string'
	        },
	        {
	        	name:'consolidationType',
	        	type:'string'
	        },
	        {
	        	name:'unitId',
	        	type:'string'
	        },
	        {
	        	name:'shipmentRef',
	        	type:'string'
	        },
	        {
	        	name:'billOfLading',
	        	type:'string'
	        },
	        {
	        	name:'storageType',
	        	type:'string'
	        },
	        {
	        	name:'cargoType',
	        	type:'string'
	        },
	        {
	        	name:'makeCd',
	        	type:'string'
	        },
	        {
	        	name:'modelCd',
	        	type:'string'
	        },
	        {
	        	name:'modelLine',
	        	type:'string'
	        },
	        {
	        	name:'modelGrp',
	        	type:'string'
	        },
	        {
	        	name:'modelYr',
	        	type:'integer'
	        },
	        {
	        	name:'rateTier',
	        	type:'string'
	        },
	        {
	        	name:'transportCd',
	        	type:'string'
	        },
	        {
	        	name:'partId',
	        	type:'string'
	        },
	        {
	        	name:'profitLossCenter',
	        	type:'string'
	        },
	        {
	        	name:'custmrSalesRegion',
	        	type:'string'
	        },
	        {
	        	name:'shipmentType',
	        	type:'string'
	        },
	        {
	        	name:'orderType',
	        	type:'string'
	        },
	        {
	        	name:'abnormalMoveType',
	        	type:'string'
	        },
	        {
	        	name:'supplierCd',
	        	type:'string'
	        },
	        {
	        	name:'supplrNm',
	        	type:'string'
	        },
	        {
	        	name:'dealerCd',
	        	type:'string'
	        },
	        {
	        	name:'lineItemRemark',
	        	type:'string'
	        },
	        {
	        	name:'extService',
	        	type:'string'
	        },
	        {
	        	name:'extOriginCd',
	        	type:'string'
	        },
	        {
	        	name:'extStateProv',
	        	type:'string'
	        },
	        {
	        	name:'extOrgnCountry',
	        	type:'string'
	        },
	        {
	        	name:'extDest',
	        	type:'string'
	        },
	        {
	        	name:'extDestStProvnc',
	        	type:'string'
	        },
	        {
	        	name:'extDestCountry',
	        	type:'string'
	        },
	        {
	        	name:'extOriginalOrign',
	        	type:'string'
	        },
	        {
	        	name:'extFinalDest',
	        	type:'string'
	        },
	        {
	        	name:'extConveyanceType',
	        	type:'string'
	        },
	        {
	        	name:'extConsolidationType',
	        	type:'string'
	        },
	        {
	        	name:'extMake',
	        	type:'string'
	        },
	        {
	        	name:'extModel',
	        	type:'string'
	        },
	        {
	        	name:'extModelGrp',
	        	type:'string'
	        },
	        {
	        	name:'extRateTier',
	        	type:'string'
	        },
	        {
	        	name:'extTrnsptMode',
	        	type:'string'
	        },
	        {
	        	name:'extshipmentType',
	        	type:'string'
	        },
	        {
	        	name:'extOrderType',
	        	type:'string'
	        },
	        {
	        	name:'extAbnormalMoveType',
	        	type:'string'
	        },
	        {
	        	name:'extSupplrCd',
	        	type:'string'
	        },
	        {
	        	name:'extDealer',
	        	type:'string'
	        },
	        {
	        	name:'extUOM1',
	        	type:'string'
	        },
	        {
	        	name:'extUOM2',
	        	type:'string'
	        },
	        {
	        	name:'extRateBasis',
	        	type:'string'
	        },
	        {
	        	name:'extCurr',
	        	type:'string'
	        },
	        {
	        	name:'srvcGrpDesc',
	        	type:'string'
	        },
	        {
	        	name:'srvcDesc2',
	        	type:'string'
	        },
	        {
	        	name:'consolidationCategory',
	        	type:'string'
	        },
	        {
	        	name:'uom1',
	        	type:'string'
	        },
	        {
	        	name:'uom2',
	        	type:'string'
	        },
	        {
	        	name:'quantity1',
	        	type:'float'
	        },
	        {
	        	name:'quantity2',
	        	type:'float'
	        },
	        {
	        	name:'rateBasis',
	        	type:'string'
	        },
	        {
	        	name:'currency',
	        	type:'string'
	        },
	        {
	        	name:'trafficUnitRate',
	        	type:'float'
	        },
	        {
	        	name:'srvcAmt',
	        	type:'float'
	        },
	        {
	        	name:'taxAmt',
	        	type:'float'
	        },
	        {
	        	name:'totalAmt',
	        	type:'float'
	        }
	        ]
});


Ext.define('covusInvoiceSubDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'srvcCd',
	        	type:'string'
	        },
	        {
	        	name:'srvcType',
	        	type:'string'
	        },
	       	{
	        	name: 'fuelSurChrge', type: 'bool',convert:function(v)
	        	 {
	        	return (v === "Y" || v === true || v === "") ? true : false;
	             }
	        },
	        {
	        	name:'loadRefNo',
	        	type:'string'	
	        },
	        
	        {
	        	name : 'unitId',
	    		type : 'string'	
	        },
	        {
	        	name : 'srvcGrp',
	    		type : 'string'	
	        },
	        {
	        	name : 'srvcDesc',
	    		type : 'string'	
	        },
	        {
	        	name : 'transportMode',
	    		type : 'string'	
	        },
	        {
	        	name : 'workOrder',
	    		type : 'string'	
	        },
	        {
	        	name : 'origin',
	    		type : 'string'	
	        },
	        {
	        	name : 'originAddr1',
	    		type : 'string'	
	        },
	        {
	        	name : 'originAddr2',
	    		type : 'string'	
	        },
	        {
	        	name : 'originCity',
	    		type : 'string'	
	        },
	        {
	        	name : 'originStateProv',
	    		type : 'string'	
	        },
	        {
	        	name : 'originCountry',
	    		type : 'string'	
	        },
	        {
	        	name : 'originZipPostalCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'dest',
	    		type : 'string'	
	        },
	        {
	        	name : 'destAddrs1',
	    		type : 'string'	
	        },
	        {
	        	name : 'destAddrs2',
	    		type : 'string'	
	        },
	        {
	        	name : 'destCity',
	    		type : 'string'	
	        },
	        {
	        	name : 'destStateProv',
	    		type : 'string'	
	        },
	        {
	        	name : 'destCountry',
	    		type : 'string'	
	        },
	        {
	        	name : 'destZipPostalCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'originalOrigin',
	    		type : 'string'	
	        },
	        {
	        	name : 'finalDest',
	    		type : 'string'	
	        },
	        {
	        	name : 'tenderDate',
	    		type : 'string'	
	        },
	        {
	        	name : 'shipmentDt',
	    		type : 'string'	
	        },
	        {
	        	name : 'deliveryDate',
	    		type : 'string'	
	        },
	        {
	        	name : 'conveyanceType',
	    		type : 'string'	
	        },
	        {
	        	name : 'conveyanceNm',
	    		type : 'string'	
	        },
	        {
	        	name : 'consolidationId',
	    		type : 'string'	
	        },
	        {
	        	name : 'consolidationTypeCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'conveyanceId',
	    		type : 'string'	
	        },
	        {
	        	name : 'shipmentRef',
	    		type : 'string'	
	        },
	        {
	        	name : 'makeCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'modelCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'modelLine',
	    		type : 'string'	
	        },
	        {
	        	name : 'modelGrp',
	    		type : 'string'	
	        },
	        {
	        	name : 'modelYr',
	    		type : 'integer'	
	        },
	        {
	        	name : 'rateTier',
	    		type : 'string'	
	        },
	        {
	        	name : 'transportCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'partId',
	    		type : 'string'	
	        },
	        {
	        	name : 'profitLossCenter',
	    		type : 'string'	
	        },
	        {
	        	name : 'custmrSalesRegion',
	    		type : 'string'	
	        },
	        {
	        	name : 'shipmentType',
	    		type : 'string'	
	        },
	        {
	        	name : 'orderType',
	    		type : 'string'	
	        },
	        {
	        	name : 'abnormalMoveType',
	    		type : 'string'	
	        },
	        {
	        	name : 'supplierCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'supplrNm',
	    		type : 'string'	
	        },
	        {
	        	name : 'dealerCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'billOfLadin',
	    		type : 'string'	
	        },
	        {
	        	name : 'storageType',
	    		type : 'string'	
	        },
	        {
	        	name : 'cargoType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extService',
	    		type : 'string'	
	        },
	        {
	        	name : 'extOriginCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'extStateProv',
	    		type : 'string'	
	        },
	        {
	        	name : 'extOrgnCountry',
	    		type : 'string'	
	        },
	        {
	        	name : 'extDest',
	    		type : 'string'	
	        },
	        {
	        	name : 'extDestStProvnc',
	    		type : 'string'	
	        },
	        {
	        	name : 'extDestCountry',
	    		type : 'string'	
	        },
	        {
	        	name : 'extOriginalOrign',
	    		type : 'string'	
	        },
	        {
	        	name : 'extFinalDest',
	    		type : 'string'	
	        },
	        {
	        	name : 'extConveyanceType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extConsolidationType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extMake',
	    		type : 'string'	
	        },
	        {
	        	name : 'extModel',
	    		type : 'string'	
	        },
	        {
	        	name : 'extModelGrp',
	    		type : 'string'	
	        },
	        {
	        	name : 'extRateTier',
	    		type : 'string'	
	        },
	        {
	        	name : 'extTrnsptMode',
	    		type : 'string'	
	        },
	        {
	        	name : 'extshipmentType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extOrderType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extAbnormalMoveType',
	    		type : 'string'	
	        },
	        {
	        	name : 'extSupplrCd',
	    		type : 'string'	
	        },
	        {
	        	name : 'extDealer',
	    		type : 'string'	
	        },
	        {
	        	name : 'extUOM1',
	    		type : 'string'	
	        },
	        {
	        	name : 'extUOM2',
	    		type : 'string'	
	        },
	        {
	        	name : 'extRateBasis',
	    		type : 'string'	
	        },
	        {
	        	name : 'extCurr',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef1',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef2',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef3',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef4',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef5',
	    		type : 'string'	
	        },{
	        	name : 'eventRef6',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef7',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef8',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef9',
	    		type : 'string'	
	        },
	        {
	        	name : 'eventRef10',
	    		type : 'string'	
	        },
	        {
	        	name : 'srvcGrpDesc',
	    		type : 'string'	
	        },
	        {
	        	name : 'srvcDesc2',
	    		type : 'string'	
	        },
	        {
	        	name : 'consolidationCategory',
	    		type : 'string'	
	        },
	        {
	        	name : 'uom1',
	    		type : 'string'	
	        },
	        {
	        	name : 'uom2',
	    		type : 'string'	
	        },
	        {
	        	name : 'quantity1',
	    		type : 'float'	
	        },
	        {
	        	name : 'quantity2',
	    		type : 'float'	
	        },
	        {
	        	name : 'trafficUnitRate',
	    		type : 'float'	
	        },
	        {
	        	name : 'fixedTrafficUnitRate',
	    		type : 'float'	
	        },
	        {
	        	name : 'rateBasis',
	    		type : 'string'	
	        },
	        {
	        	name : 'currency',
	    		type : 'string'	
	        },
	        {
	        	name: 'varEvntFlg', type: 'bool',convert:function(v)
	        	{
	        	return (v === "Y" || v === true || v === "") ? true : false;
	             }
	        },
	        {
	        	name:'srvcAmt',
	        	type:'float'
	        }
	        ]
});


Ext.define('covusTaxDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'taxType',
	        	type:'string'
	        },
	        {
	        	name:'taxPercentage',
	        	type:'float'
	        },
	        {
	        	name:'currency',
	        	type:'string'	
	        },
	        { 
	        	name:'srvcAmt',
	        	type:'float'
	        	
	        },
	        {
	        	name:'taxAmt',
	        	type:'float'
	        },
	        {
	        	name:'extTaxType',
	        	type:'string'
	        },
	        {
	        	name:'extCurrency',
	        	type:'string'
	        }]
});




Ext.define('DashboardCustReconStatModel1', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'customerCd',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	},  {
		name : 'zeroRtdEvntCntWithDlvryDt',
		type : 'integer'
	}, {
		name : 'count1Day',
		type : 'integer'
	}, {
		name : 'amount1Day',
		type : 'float'
	}, {
		name : 'count2_5Days',
		type : 'integer'
	}, {
		name : 'amount2_5Days',
		type : 'float'
	}, {
		name : 'count6_15Days',
		type : 'integer'
	}, {
		name : 'amount6_15Days',
		type : 'float'
	}, {
		name : 'count16_30Days',
		type : 'integer'
	}, {
		name : 'amount16_30Days',
		type : 'float'
	}, {
		name : 'countG30Days',
		type : 'integer'
	}, {
		name : 'amountG30Days',
		type : 'float'
	}]
});

Ext.define('DashboardCustReconStatModel2', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'customerCd',
		type : 'string'
	}, {
		name : 'invType',
		type : 'String'
	},{
		name : 'prfEstmInd',
		type : 'String'
	},{
		name : 'currency',
		type : 'string'
	},   {
		name : 'count1Day',
		type : 'integer'
	}, {
		name : 'amount1Day',
		type : 'float'
	}, {
		name : 'count2_5Days',
		type : 'integer'
	}, {
		name : 'amount2_5Days',
		type : 'float'
	}, {
		name : 'count6_15Days',
		type : 'integer'
	}, {
		name : 'amount6_15Days',
		type : 'float'
	}, {
		name : 'count16_30Days',
		type : 'integer'
	}, {
		name : 'amount16_30Days',
		type : 'float'
	}, {
		name : 'countG30Days',
		type : 'integer'
	}, {
		name : 'amountG30Days',
		type : 'float'
	}]
});


Ext.define('DashboardCustInvStatModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'customerCd',
		type : 'string'
	},{
		name : 'customerName',
		type : 'string'
	}, {
		name : 'invType',
		type : 'String'
	},{
		name : 'prfEstmInd',
		type : 'String'
	},{
		name : 'currency',
		type : 'string'
	},   {
		name : 'countToday',
		type : 'integer'
	}, {
		name : 'amountToday',
		type : 'float'
	}, {
		name : 'countYesterday',
		type : 'integer'
	}, {
		name : 'amountYesterday',
		type : 'float'
	}, {
		name : 'countPastWeek',
		type : 'integer'
	}, {
		name : 'amountPastWeek',
		type : 'float'
	}, {
		name : 'countPastMonth',
		type : 'integer'
	}, {
		name : 'amountPastMonth',
		type : 'float'
	}]
});


Ext.define('CstmrRemittanceAdvice', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'invoiceNumber',
		type : 'string'
	}, {
		name : 'totalAmount',
		type : 'String'
	}]
});

Ext.define('DashboardSplMvsStatModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'customerCd',
		type : 'string'
	}, {
		name : 'satus',
		type : 'string'
	}, {
		name : 'count0_1Day',
		type : 'integer'
	}, {
		name : 'count2_5Days',
		type : 'integer'
	}, {
		name : 'count6_15Days',
		type : 'integer'
	}, {
		name : 'count16_30Days',
		type : 'integer'
	}, {
		name : 'count31_60Days',
		type : 'integer'
	}]
});



Ext.define('statusMonitorSaveSearchRetrieve', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'saveSearchKey',
		type : 'string'
	}, {
		name : 'saveSearchKeyDesc',
		type : 'string'
	}, {
		name : 'defaultFlag',
		type : 'string'
	}, {
		name : 'savedDate',
		type : 'string'
	}, {
		name : 'searchCriteria',
		type : 'string'
	}]
});


Ext.define('ModelGroup', {
	extend : 'Ext.data.Model',
	fields : [{name : 'modelGroupCode',type : 'string'},{name : 'modelGroupDesc',type : 'string'}]
});


Ext.define('auditExceptionModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'msgType',
		type:'string'
	},{
		name:'msgTypeName',
		type:'string'
	},
	{
		name:'timeIntvl',
		type:'integer'
	},
	{
		name:'startFlag',
		type:'string',
		convert:function(v){
			return (v === "Y") ? "Running" : "Stopped";
		}
	},
	{
		name:'msgStartDate',
		dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,
		type:'date'
	},
	{
		name:'userName',
		type:'string'
	}]
});


Ext.define('auditExceptionMsgCombo',{
	extend:'Ext.data.Model',
	fields:[{
		name:'msgType',
		type:'string'
	}]
});


Ext.define('outCstmrRemitAdviceDtls', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'invoiceNumber',
		type : 'string'
	},{
		name : 'documentReference',
		type : 'string'
	},{
		name : 'invoiceTotAmount',
		type : 'float'
	}]
});
Ext.define('generalMasterCompanyMaster', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'companyName',
		type : 'string'
	},{
		name : 'companyCode',
		type : 'string'
	},{
		name : 'defaultCurrency',
		type : 'string'
	},{
		name : 'name',
		type : 'string'
	}, {
		name : 'address1',
		type : 'string'
	}, {
		name : 'address2',
		type : 'string'
	}, {
		name : 'city',
		type : 'string'
	}, {
		name : 'state',
		type : 'string'
	}, {
		name : 'country',
		type : 'string'
	}, {
		name : 'postal',
		type : 'string'
	}, {
		name : 'teleNbr',
		type : 'string'
	}, {
		name : 'faxNbr',
		type : 'string'
	}, {
		name : 'email',
		type : 'string'
	}]
});


Ext.define('BackendJobsDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'jobName',
		type:'string'
	},
	{
		name:'startDate',
		type:'string'
	},
	{
		name:'repeatInterval',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	}]
});



Ext.define('errorCorrectionSMS',{
	extend:'Ext.data.Model',
	fields:[{
		name:'errorLogId',
		type:'integer'
	},
	{
		name:'msgHdrId',
		type:'integer'
	},
	{
		name:'partnerCode',
		type:'string'	
	},
	{
		name:'msgType',
		type:'string'
	},
	{
		name:'tupleSeqNo',
		type:'integer'
	},
	{
		name:'attributeName',
		type:'string'	
	},
	{
		name:'attributeValue',
		type:'string',
		convert:function(v){
			if(!Ext.isEmpty(v)){
				return v.toUpperCase();
			}
			else return v;
		}
	},
	{
		name:'errorDesc',
		type:'string'	
	},
	{
		name:'refAttributeName',
		type:'string'
	},
	{
		name:'refAttributeValue',
		type:'string'	
	},
	{
		name:'recSts',
		type:'string'
	},
	{
		name:'objName',
		type:'string'
	}]
});


Ext.define('ModelLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'

	},{
		name : 'reference',
		type : 'string'
	},{
		name : 'exchangeRate',
		type : 'string'	
	}]
});

Ext.define('EventStatusGridDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'serviceCode',
		type : 'string'
	}, {
		name : 'serviceType',
		type : 'string'
	}, {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'customer',
		type : 'string'
	}  ,{
		name : 'eventLoadReference',
		type : 'string'
	}, {
		name : 'unitId',
		type : 'string'
	}, {
		name : 'shippingReference',
		type : 'string'
	}, {
		name : 'originLocation',
		type : 'string'
	}, {
		name : 'destination',
		type : 'string'
	}, {
		name : 'dealerCode',
		type : 'string'
	}, {
		name : 'tenderRequestDate',
		type:'date',
		dateFormat:'d/m/Y H:i:s'
	//	dateFormat:'d/m/Y'
	}, {
		name : 'shipmentDate',
		type:'date',
		dateFormat:'d/m/Y H:i:s'
	//	dateFormat:'d/m/Y'
	}, {
		name : 'deliveryCompletionDate',
		type:'date',
		dateFormat:'d/m/Y H:i:s'
	//	dateFormat:'d/m/Y'
	}, {
		name : 'make',
		type : 'string'
	}, {
		name : 'model',
		type : 'string'
	},{
		name : 'modelName',
		type : 'string'
	},  {
		name : 'modelYear',
		type : 'string'
	}, {
		name : 'modelGroup',
		type : 'string'
	}, {
		name : 'transportMode',
		type : 'string'
	}, {
		name : 'conveyanceId',
		type : 'string'
	}, {
		name : 'conveyanceType',
		type : 'string'
	}, {
		name : 'conveyanceName',
		type : 'string'
	}, {
		name : 'consolidationId',
		type : 'string'
	}, {
		name : 'consolidationType',
		type : 'string'
	}, {
		name : 'transportCode',
		type : 'string'
	}, {
		name : 'customerSalesRegion',
		type : 'string'
	}, {
		name : 'shipmentType',
		type : 'string'
	}, {
		name : 'orderType',
		type : 'string'
	}, {
		name : 'abnormalMoveType',
		type : 'string'
	}, {
		name : 'addressLine1o',
		type : 'string'
	}, {
		name : 'addressLine2o',
		type : 'string'
	}, {
		name : 'cityo',
		type : 'string'
	}, {
		name : 'stateProvinceo',
		type : 'string'
	},{
		name : 'zipPostalCdo',
		type : 'string'
	}, {
		name : 'countryo',
		type : 'string'
	}, {
		name : 'addressLine1d',
		type : 'string'
	}, {
		name : 'addressLine2d',
		type : 'string'
	}, {
		name : 'cityd',
		type : 'string'
	}, {
		name : 'stateProvinced',
		type : 'string'
	}, {
		name : 'zipPostalCdd',
		type : 'string'
	}, {
		name : 'countryd',
		type : 'string'
	}, {
		name : 'originalOrigin',
		type : 'string'
	}, {
		name : 'finalDestination',
		type : 'string'
	}, {
		name : 'weight',
		type : 'string'
	}, {
		name : 'eventLength',
	//	mapping:'length',
		type : 'string'
	}, {
		name : 'width',
		type : 'string'
	}, {
		name : 'height',
		type : 'string'
	}, {
		name : 'volume',
		type : 'string'
	}, {
		name : 'quantity',
		type : 'string'
	}, {
		name : 'storageQty',
		type : 'string'
	}, {
		name : 'storageUOM',
		type : 'string'
	}, {
		name : 'previousChargeQty',
		type : 'string'
	}, {
		name : 'previousChargeUOMCode',
		type : 'string'
	}, {
		name : 'profitLossCenter',
		type : 'string'
	},{
		name : 'workOrderNumber',
		type : 'string'
	}, {
		name : 'partNumber',
		type : 'string'
	},
	{
		name : 'intRequestNo',
		type : 'string'
	},
	{
		name : 'sequenceNo',
		type : 'string'
	},
	{
		name : 'rateTierCode',
		type : 'string'
	},
	{
		name : 'supplierEventStatusCode',
		type : 'string'
	},
	{
		name : 'supplierRatingSequenceNumber',
		type : 'string'
	},
	{
		name : 'supplierManRateFlag',
		type : 'string'
	}, {
		name : 'customerEventStatusCode',
		type : 'string'
	},{
		name : 'customerRatingSequenceNumber',
		type : 'string'
	},
	{
		name : 'customerManRateFlag',
		type : 'string'
	}, {
		name : 'fuelSrChargeSrvFlag',
		type : 'string'
	},{
		name : 'fuelSrChargeAppFlag',
		type : 'string'
	},
	{
		name : 'parentIntRequestNo',
		type : 'string'
	}, {
		name : 'parentSequenceNo',
		type : 'string'
	}, {
		name : 'supplierSrvInvAmtCrncy',
		type : 'string'
	}, {
		name : 'storageType',
		type : 'string'
	}, {
		name : 'cargoType',
		type : 'string'
	}, {
		name : 'billOfLading',
		type : 'string'
	}, {
		name : 'modelLine',
		type : 'string'
	}]
});

Ext.define('EventStatusFormItemsDTO', {
	extend : 'Ext.data.Model',
	fields : [  {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'customer',
		type : 'string'
	},{
		name : 'serviceType',
		type : 'string'
	}, {
		name : 'serviceCode',
		type : 'string'
	}, {
		name : 'unitId',
		type : 'string'
	}, {
		name : 'make',
		type : 'string'
	}, {
		name : 'model',
		type : 'string'
	}, {
		name : 'modelGroup',
		type : 'string'
	}, {
		name : 'transportMode',
		type : 'string'
	}, {
		name : 'eventDate',
		type : 'string'
	}, {
		name : 'fromDate',
		type : 'string'
	}, {
		name : 'toDate',
		type : 'string'
	}, {
		name : 'blank',
		type : 'string'
	}, {
		name : 'consolidationId',
		type : 'string'
	}, {
		name : 'consolidationType',
		type : 'string'
	}, {
		name : 'eventLoadReference',
		type : 'string'
	}, {
		name : 'shippingReference',
		type : 'string'
	}, {
		name : 'origin',
		type : 'string'
	}, {
		name : 'originCity',
		type : 'string'
	}, {
		name : 'originStateProvince',
		type : 'string'
	}, {
		name : 'destination',
		type : 'string'
	}, {
		name : 'destinationCity',
		type : 'string'
	}, {
		name : 'destinationStateProvince',
		type : 'string'
	}, {
		name : 'dealerCode',
		type : 'string'
	}, {
		name : 'transportCode',
		type : 'string'
	}, {
		name : 'shipmentType',
		type : 'string'
	}, {
		name : 'orderType',
		type : 'string'
	}, {
		name : 'abnormalMoveType',
		type : 'string'
	}, {
		name : 'workOrder',
		type : 'string'
	}, {
		name : 'profitLossCenter',
		type : 'string'
	}, {
		name : 'conveyanceName',
		type : 'string'
	}, {
		name : 'conveyanceId',
		type : 'string'
	}, {
		name : 'conveyanceType',
		type : 'string'
	}]
});


Ext.define('transptEvntEntry',{
	extend:'Ext.data.Model',
	fields:[{
		name:'customerCode',
		type:'string'
	},
	{
    	name: 'vinCheck', type: 'bool',convert:function(v)
    	{
    	return (v === "Y" || v === true || v === "") ? true : false;
         }
    },	
	{
		name:'unitId',
		type:'string'	
	},
	{
		name:'shipmentDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'deliveryDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'make',
		type:'string'
	},
	{
		name:'modelCode',
		type:'string'
	},
	{
		name:'modelDescr',
		type:'string'
	},
	{
		name:'modelGroup',
		type:'string'
	},
	{
		name:'modelYear',
		type:'integer'
	},
	{
		name:'rateTier',
		type:'string'
	},
	{
		name:'shipRefrnc',
		type:'string'
	},
	{
		name:'transportCode',
		type:'string'
	},
	{
		name:'shipmentType',
		type:'string'
	},
	{
		name:'abnormalMvType',
		type:'string'
	},
	{
		name:'orderType',
		type:'string'
	},
	{
		name:'cstmrSaleRegn',
		type:'string'
	},
	{
		name:'dealerCode',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},
	{
		name:'destnAddr1',
		type:'string'
	},
	{
		name:'destnAddr2',
		type:'string'
	},
	{
		name:'destnCity',
		type:'string'
	},
	{
		name:'destnState',
		type:'string'
	},
	{
		name:'destnZipCode',
		type:'string'
	},
	{
		name:'destnCntry',
		type:'string'
	},
	{
		name:'originalOrigin',
		type:'string'
	},
	{
		name:'finalDestn',
		type:'string'
	},
	{
		name:'weight',
		type:'float',
		useNull:true
	},
	{
		name : 'transportLength',
		//mapping:'length',
		type:'float',
		useNull:true
	},
	{
		name:'width',
		type:'float',
		useNull:true
	},
	{
		name:'height',
		type:'float',
		useNull:true
	},
	{
		name:'volume',
		type:'float',
		useNull:true
	},
	{
		name:'reference1',
		type:'string'
	},
	{
		name:'reference2',
		type:'string'
	},
	{
		name:'reference3',
		type:'string'
	},
	{
		name:'reference4',
		type:'string'
	},
	{
		name:'reference5',
		type:'string'
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rqstNo',
		type:'integer'
	},
	{
		name:'seqNo',
		type:'integer'
	},
	{
		name:'modelLine',
		type:'string'
	},
	{
		name:'cargoType',
		type:'string'
	},
	{
		name:'reference6',
		type:'string'
	},
	{
		name:'reference7',
		type:'string'
	},
	{
		name:'reference8',
		type:'string'
	},
	{
		name:'reference9',
		type:'string'
	},
	{
		name:'reference10',
		type:'string'
	},
	{
		name:'supplierEvntStsCd',
		type:'string'
	},
	{
		name:'customerEvntStsCd',
		type:'string'
	},
	{
		name:'version',
		type:'integer'
	}]
});

Ext.define('technicalEvntEntry',{
	extend:'Ext.data.Model',
	fields:[{
		name:'customerCode',
		type:'string'
	},
	{
    	name: 'vinCheck', type: 'bool',convert:function(v)
    	{
    	return (v === "Y" || v === true || v === "") ? true : false;
         }
    },	
	{
		name:'unitId',
		type:'string'	
	},
	{
		name:'partNumber',
		type:'string'	
	},
	{
		name:'shipmentDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'deliveryDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'make',
		type:'string'
	},
	{
		name:'modelCode',
		type:'string'
	},
	{
		name:'modelDescr',
		type:'string'
	},
	{
		name:'modelGroup',
		type:'string'
	},
	{
		name:'modelYear',
		type:'integer',
		useNull:true
	},
	{
		name:'rateTier',
		type:'string'
	},
	{
		name:'weight',
		type:'float',
		useNull:true
			
	},
	{
		name : 'transportLength',
		//mapping:'length',
		type:'float',
		useNull:true
	},
	{
		name:'width',
		type:'float',
		useNull:true
	},
	{
		name:'height',
		type:'float',
		useNull:true
	},
	{
		name:'volume',
		type:'float',
		useNull:true
	},
	{
		name:'shipRefrnc',
		type:'string'
	},	
	{
		name:'cstmrSaleRegn',
		type:'string'
	},
	{
		name:'prevChrgdQty',
		type:'float',
		useNull:true
	},
	{
		name:'prevChrgdUomCd',
		type:'string'
	},		
	{
		name:'reference1',
		type:'string'
	},
	{
		name:'reference2',
		type:'string'
	},
	{
		name:'reference3',
		type:'string'
	},
	{
		name:'reference4',
		type:'string'
	},
	{
		name:'reference5',
		type:'string'
	},
	{
		name:'quantity',
		type:'float',
		useNull:true
	},
	{
		name:'storeQuantity',
		type:'float',
		useNull:true
	},
	{
		name:'storeUomCd',
		type:'string'
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rqstNo',
		type:'integer',
		useNull:true
	},
	{
		name:'seqNo',
		type:'integer',
		useNull:true
	},
	{
		name:'storageType',
		type:'string'
	},
	{
		name:'modelLine',
		type:'string'
	},
	{
		name:'cargoType',
		type:'string'
	},
	{
		name:'supplierEvntStsCd',
		type:'string'
	},
	{
		name:'customerEvntStsCd',
		type:'string'
	},
	{
		name:'version',
		type:'integer'
	}
	]
});


Ext.define('TransportEvntFormFields',{
	extend:'Ext.data.Model',
	fields:[{
		name:'loadReferenceNbr',
		type:'string'
	},	
	{
		name:'suupliercodeName',
		type:'string'	
	},
	{
		name:'trnprtEvntServiceCd',
		type:'string'	
	},
	{
		name:'conveyanceID',
		type:'string'
	},
	{
		name:'conveyanceType',
		type:'string'
	},
	{
		name:'conveyanceName',
		type:'string'
	},
	{
		name:'transportMode',
		type:'string'
	},
	{
		name:'rqst_dttm',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'ProfitLossCenter',
		type:'string'
	},
	{
		name:'consolidationID',
		type:'string'
	},
	{
		name:'consolidationType',
		type:'string'
	},
	{
		name:'transferSeqNbr',
		type:'string'
	},
	{
		name:'origin',
		type:'string'
	},	
	{
		name:'address1',
		type:'string'
	},
	{
		name:'address2',
		type:'string'
	},		
	{
		name:'city',
		type:'string'
	},
	{
		name:'originStateProvince',
		type:'string'
	},
	{
		name:'zipcode',
		type:'string'
	},
	{
		name:'country',
		type:'string'
	},
	{
		name:'int_rqst_no',
		type:'integer'
	}
	]
});


Ext.define('SupplrEvntStatusSummary',{
	extend:'Ext.data.Model',
	fields:[{
		name:'customer',
		type:'string'
	},
	{
		name:'supplier',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'
	},
	{
		name:'origin',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},
	{
		name:'count',
		type:'integer'
	},
	{
		name:'totalQuantity',
		type:'float',
		useNull:true
	},
	{
		name:'totalStorageQty',
		type:'float',
		useNull:true
	},
	{
		name:'currency',
		type:'string'
	},
	{
		name:'totalSrvcAmt',
		type:'float',
		useNull:true
	},
	{
		name:'totalTaxAmt',
		type:'float',
		useNull:true
	},
	{
	  name:'totalAmt',
	  type:'float',
		useNull:true
	}]
	
});

Ext.define('GenericDebtorPartyLookUpDto',{
	extend:'Ext.data.Model',
	fields:[
	{
		name:'dbtrPartyCd',
		type:'string'
	},
	{
		name:'dbtrPartyNm',
		type:'string'
	},
	{
		name:'addr1',
		type:'string'
	},
	{
		name:'addr2',
		type:'string'
	},
	{
		name:'city',
		type:'string'
		
	},
	{
		name:'state',
		type:'string'
	},
	{
		name:'country',
		type:'string'
	},
	{
		name:'po_box',
		type:'string'
	},
	{
		name:'cstmr_cd',
		type:'string'
	}]
	
});



Ext.define('CstmrRateDbtrParty',{
	extend:'Ext.data.Model',
	fields:[{
		name:'dbtrPartyNm',
		type:'string'
	},
	{
		name:'dbtrParty',
		type:'string'
	},
	{
		name:'addrs1',
		type:'string'
	},
	{
		name:'addrs2',
		type:'string'
	},
	{
		name:'city',
		type:'string'
	},
	{
		name:'state',
		type:'string'
	},
	{
		name:'country',
		type:'string'
	},
	{
		name:'po_box',
		type:'string'
	}
	]
});


Ext.define('GenericSrvcCodeLookUpDto',{
	extend:'Ext.data.Model',
	fields:[{
		        name:'serviceCode',
		        type:'string'
	        },
	        {
	        	name:'serviceDesc',
			    type:'string'
	        },
	        { 
	        	name:'uomCode',
			    type:'string'
	        },
	        {
	        	name:'serviceType',
			    type:'string'
	        },
	        {
	        	name:'fuelSrchrgFlg',
			    type:'string'
	        }]

});

Ext.define('specialMoveQueryGridData',{
	extend:'Ext.data.Model',
	fields:[{
		        name:'unitId',
		        type:'string'
	        },
	        {
	        	name:'originCode',
			    type:'string'
	        },
	        { 
	        	name:'destCode',
			    type:'string'
	        },
	        {
	        	name:'serviceCode',
			    type:'string'
	        },{
		        name:'supplierCode',
		        type:'string'
	        },
	        {
	        	name:'customerCode',
			    type:'string'
	        },
	        { 
	        	name:'moveRef',
			    type:'string'
	        },
	        {
	        	name:'shipingRef',
			    type:'string'
	        },
	        {
		        name:'rqstDate',
		        type : 'date',
				dateFormat:'Y-m-d H:i:s.u'/*,
				convert : function(value){
					if(!Ext.isEmpty(value)){
						var dateFormat=Ext.Date.parse(value,"Y-m-d H:i:s.u");
						return Ext.util.Format.date(dateFormat,"d/m/Y H:i:s");
					}
					else return null;
				}*/
	        },
	        {
	        	name:'fromDate',
	        	type : 'date',
				dateFormat:'Y-m-d H:i:s.u'
	        },
	        { 
	        	name:'toDate',
	        	type : 'date',
				dateFormat:'Y-m-d H:i:s.u'
	        },
	        {
	        	name:'makeCode',
			    type:'string'
	        },{
		        name:'modelCode',
		        type:'string'
	        },
	        {
	        	name:'modelYear',
			    type:'int',
			    convert:function(v)
	        	 {
			    	return v;
	        	 }
	        },
	        { 
	        	name:'customerSalesRGN',
			    type:'string'
	        },
	        {
	        	name:'rateTierCode',
			    type:'string'
	        },
	        { 
	        	name:'trnsptMode',
			    type:'string'
	        },
	        {
	        	name:'conveyanceId',
			    type:'string'
	        },{
		        name:'conveyanceTypeCode',
		        type:'string'
	        },
	        {
	        	name:'customerDeptName',
			    type:'string'
	        },
	        { 
	        	name:'orderTypeCode',
			    type:'string'
	        },
	        {
	        	name:'abnormalTypeCode',
			    type:'string'
	        },{
		        name:'dtlsRmrk',
		        type:'string'
	        },
	        {
	        	name:'fuelSrchrgApp',
	        	 type: 'bool',
	        	convert:function(v)
	        	 {

	        	
	        	return (v === "Y" || v === true || v === "") ? true : false;

	        		
	        		if(v=='Y'){
	        			return true;
	        		}
	        		else{
	        			return false;
	        		}
	        	//return (v === "Y" || v === true || v === "") ? true : false;

	             }
	        },
	        { 
	        	name:'originAdd1',
			    type:'string'
	        },
	        {
	        	name:'originAdd2',
			    type:'string'
	        },
	        {
		        name:'originCityName',
		        type:'string'
	        },
	        {
	        	name:'originStateCode',
			    type:'string'
	        },
	        { 
	        	name:'originPOBOX',
			    type:'string'
	        },
	        {
	        	name:'originCntryCode',
			    type:'string'
	        },{
		        name:'destAdd1',
		        type:'string'
	        },{
		        name:'destAdd2',
		        type:'string'
	        },
	        {
	        	name:'destCityName',
			    type:'string'
	        },
	        { 
	        	name:'destStateCode',
			    type:'string'
	        },
	        {
	        	name:'destPOBOX',
			    type:'string'
	        },{
		        name:'destCntryCode',
		        type:'string'
	        },
	        {
	        	name:'dealCode',
			    type:'int',
			    convert:function(v)
	        	 {
			    	 return v;
	        	 }
	        },
	        { 
	        	name:'originalOriginCode',
			    type:'string'
			   
	        },
	        {
	        	name:'finalDestCode',
			    type:'string'
	        },
	        {
		        name:'rqstCreateIntUserId',
		        type:'string'
	        },
	        {
	        	name:'companyCode',
			    type:'string'
	        },{
	        	name:'intRqstNbr',
			    type:'string'
	        }]


});



Ext.define('GenericSuplrCustomerDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'
	},{
		name : 'addr_1',
		type : 'string'
	},{
		name : 'addr_2',
		type : 'string'
	},{
		name : 'city_nm',
		type : 'string'
	},{
		name : 'state_cd',
		type : 'string'
	},{
		name : 'cntry_cd',
		type : 'string'
	},{
		name : 'po_box',
		type : 'string'
	},{
		name : 'rmrk',
		type : 'string'
	}]
});

	Ext.define('GenericSrvcGroupLookUpDto',{
		extend:'Ext.data.Model',
		fields:[
		        {
			       name:'srvcGroupCd',
			       type:'string'
		        },
		        {
			       name:'srvcGroupDesc',
			       type:'string'
		        },
		        {
		        	name:'custmrCd',
		        	type:'string'
		        }
		        ]
});




Ext.define('shipmentTypeStore',{
	extend:'Ext.data.Model',
	fields:[{
		        name:'value',
		        type:'string'
	        },
	        {
	        	name:'text',
			    type:'string'
	        }]

});


Ext.define('custmrEvntStsSumm',{
	extend:'Ext.data.Model',
	fields:[{
		name:'customer',
		type:'string'
	},
	{
		name:'supplier',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'
	},
	{
		name:'serviceDesc',
		type:'string'
	},
	{
		name:'origin',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},
	{
		name:'srvcGrpCd',
		type:'string'
	},
	{
		name:'debtorParty',
		type:'string'
	},
	{
		name:'count',
		type:'integer'
	},
	{
		name:'totalQuantity',
		type:'float',
		useNull:true
	},
	{
		name:'totalStorageQty',
		type:'float',
		useNull:true
	},
	{
		name:'currency',
		type:'string'
	},
	{
		name:'totalSrvcAmt',
		type:'float',
		  useNull:true
	},
	{
		name:'totalTaxAmt',
		type:'float',
		  useNull:true
	},
	{
	  name:'totalAmt',
	  type:'float',
	  useNull:true
	}]
});

Ext.define('CutomerRateQuery',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},	
	{
		name:'contractId',
		type:'string'	
	},
	{
		name:'customer',
		type:'string'
	},
	{
		name:'name',
		type:'string'
	},
	{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y'
	}]
});
Ext.define('CustRateVerificationDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'contractId',
		type : 'string'
	}, {
		name : 'serviceDescr',
		type : 'string'
	}, {
		name : 'debtorParty',
		type : 'string'
	}, {
		name : 'supplierCode',
		type : 'string'
	}, {
		name : 'transpMode',
		type : 'string'
	}, {
		name : 'rateTier',
		type : 'string'
	}, {
		name : 'originLocation',
		type : 'string'
	},

	{
		name : 'destination',
		type : 'string'
	}, {
		name : 'conveyanceType',
		type : 'string'
	}, {
		name : 'makeCode',
		type : 'string'
	}, {

		name : 'modelCode',
		type : 'string'
	}, {
		name : 'modelYear',
		type : 'string'
	}, 
	{
		name : 'modelGroupCode',
		type : 'string'
	},
	{

		name : 'partId',
		type : 'string'
	}, {
		name : 'originLocationCity',
		type : 'string'
	}, {
		name : 'originLocationStateProviance',
		type : 'string'
	}, {
		name : 'destinationCity',
		type : 'string'
	}, {
		name : 'destinationStateProviance',
		type : 'string'
	}, {
		name : 'originalOrigin',
		type : 'string'
	}, {
		name : 'finalDestination',
		type : 'string'
	}, {
		name : 'consolidationTypeCode',
		type : 'string'
	}, {
		name : 'notChargeble',
		type : 'string'
	}, {
		name : 'markUp',
		type : 'string'
	}, {
		name : 'markUpCriteria',
		type : 'string'
	}, {
		name : 'markUpValue',
		type : 'string'

	}, {
		name : 'factorValue',
		type : 'string'
	}, {
		name : 'factorType',
		type : 'string'
	}, {
		name : 'factorRate',
		type : 'string'
	}, {
		name : 'program',
		type : 'string'
	}, {
		name : 'index',
		type : 'string'
	}, {
		name : 'eventDate',
		type : 'string'
	}, {
		name : 'uom',
		type : 'string'
	}, {
		name : 'fixedRate',
		type : 'string'
	}, {
		name : 'tariffCode',
		type : 'string'
	}, {
		name : 'tariffUnitRate',
		type : 'string'
	}, {
		name : 'luInd',
		type : 'string'
	}, {
		name : 'tariffCrncCode',
		type : 'string'
	}, {
		name : 'composite',
		type : 'string'
	}, {
		name : 'nonTaxable',
		type : 'string'
	}, {
		name : 'priority',
		type : 'string'
	},
	
	{
		name : 'storage',
		type : 'string'
	},
	{
		name : 'cargoType',
		type : 'string'
	},
	{
		name : 'modelLine',
		type : 'string'
	}
	

	]

});
Ext.define('CustRateVerificationFormDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'selectedCmpCd',
		type:'string'
	},
	{
		name:'customer',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'	
	},
	{
		name:'supplierCode',
		type:'string'	
	},
	{
		name:'transportMode',
		type:'string'
	},
	{
		name:'rateTier',
		type:'string'
	},
	{
		name:'origin',
		type:'string'
	},
	{
		name:'originStatepro',
		type:'string'
	},
	{
		name:'make',
		type:'string'
	},
	{
		name:'model',
		type:'string'
	},
	{
		name:'modelGroup',
		type:'string'
	},
	{
		name:'partCode',
		type:'string'
	},
	{
		name:'conveyanceType',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},	
	{
		name:'destStateProv',
		type:'string'
	},
	{
		name:'originalOrigin',
		type:'string'
	},		
	{
		name:'finalDest',
		type:'string'
	},
	{
		name:'consolidationType',
		type:'string'
	},
	{
		name:'customerName',
		type:'string'
	},
	{
		name:'effectiveDate',
		type:'string'
	},
	{
		name:'originCity',
		type:'integer'
	},
	{
		name:'destinationCity',
		type:'string'
	},
	{
		name:'modelYear',
		type:'integer'
	},
	{
		name:'storage',
		type:'string'
	},
	{
		name:'cargoType',
		type:'string'
	},{
		name:'modelLine',
		type:'string'
	}
	]
});


Ext.define('ContractDtoModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'systemContractNo',
		type:'string'
	},	
	{
		name:'customerCode',
		type:'string'	
	},
	{
		name:'validFromDate',
		type:'string'
	},
	{
		name:'validToDate',
		type:'string'
	},
	{
		name:'remark',
		type:'string'
	}]
});

Ext.define('CustomerDebtorPartyDetails',{
	extend:'Ext.data.Model',
	fields : [{
		name:'companyCd',
		type:'string'
	},{
		name:'customer',
		mandatory:true,
		type:'string'
	},{
		name:'customerNm',
		type:'string'
	},{
		name:'dbtrPartyCd',
		mandatory:true,
		type:'string'
	},{
		name:'debtorPartyNm',
		type:'string'
	},{
		name:'taxRefNo',
		type:'string'
	},{
		name:'address1',
		type:'string'
	},{
		name:'address2',
		type:'string'
	},{
		name:'city',
		type:'string'
	},{
		name:'state',
		type:'string'
	},{
		name:'country',
		type:'string'
	},{
		name:'zip',
		type:'string'
	},{
		name:'telephoneno',
		type:'string'
	},{
		name:'fax',
		type:'string'
	},{
		name:'mobileNo',
		type:'string'
	},{
		name:'emailAddress',
		type:'string'
	},{
		name:'contactPsnNm',
		type:'string'
	},{
		name:'subLedgerCode',
		type:'string'
	},{
		name:'remarks1',
		type:'string'
	},{
		name:'remarks2',
		type:'string'
	},{
		name:'trnsType',
		type:'string'
			
	},{
		name:'sendCustAccToCodaFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'waitForAPApproveFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'autoApproveApplnAdviceFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'sendCstmrInvcMsgFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'sendCovusMessage',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'includeDetailsInConsolidateActualCovus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'includeDetailsInNonConsolidateActualCovus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'includeDetailsInConsolidateAccrualCovus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'includeDetailsInNonConsolidateAccrualCovus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	}			
	
	]
});



Ext.define('CutomerRateQueryServiceCd',{
	extend:'Ext.data.Model',
	fields:[{
		name:'contractId',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'
	},
	{
		name:'serviceDescr',
		type:'string'	
	},
	{
		name:'debtorParty',
		type:'string'	
	},
	{
		name:'supplierCode',
		type:'string'
	},
	{
		name:'transportMode',
		type:'string'
	},
	{
		name:'rateTier',
		type:'string'
	},
	{
		name:'originLocation',
		type:'string'
	},
	{
		name:'destinationCode',
		type:'string'
	},
	{
		name:'conveyanceType',
		type:'string'
	},
	{
		name:'makeCode',
		type:'string'
	},
	{
		name:'modelCode',
		type:'string'
	},
	{
		name:'modelYear',
		type:'string'
	},
	{
		name:'modelGroup',
		type:'string'
	},	
	{
		name:'partId',
		type:'string'
	},
	{
		name:'originCity',
		type:'string'
	},		
	{
		name:'originState',
		type:'string'
	},
	{
		name:'destinationCity',
		type:'string'
	},
	{
		name:'destinationState',
		type:'string'
	},
	{
		name:'originalOrigin',
		type:'string'
	},
	{
		name:'finalDestination',
		type:'string'
	},
	{
		name:'consolidationTypeCode',
		type:'string'
	},
	{
		name:'notChargeable',
		type:'string'
	},
	{
		name:'markup',
		type:'string'
	},
	{
		name:'markupCriteria',
		type:'string'
	},
	{
		name:'markupValue',
		type:'string'
	},
	{
		name:'factorValue',
		type:'string'
	},
	{
		name:'factorType',
		type:'string'
	},
	{
		name:'factorRate',
		type:'string'
	},
	{
		name:'program',
		type:'string'
	},
	{
		name:'index',
		type:'string'
	},
	{
		name:'eventDate',
		type:'string'
	},
	{
		name:'uomCode',
		type:'string'
	},
	{
		name:'fixedRate',
		type:'string'
	},
	{
		name:'tariffCode',
		type:'string'
	},
	{
		name:'tariffUnitRate',
		type:'string'
	},
	{
		name:'luInd',
		type:'string'
	},
	{
		name:'tariffCurrencyCode',
		type:'string'
	},
	{
		name:'composite',
		type:'string'
	},
	{
		name:'nonTaxable',
		type:'string'
	},
	{
		name:'priority',
		type:'string'
	},
	{
		name:'cargoType',
		type:'string'
	},
	{
		name:'storageType',
		type:'string'
	},
	{
		name:'modelLine',
		type:'string'
	}	
	]
});




Ext.define('custmrRateFuelSurchrgDtls',{
	extend:'Ext.data.Model',
	fields:[{
		name:'srvcCd',
		mandatory:true,
		type:'string'
	},
	{
		name:'srvcDesc',
		mandatory:true,
		type:'string'
	},
	{
	   name:'validFrmDt',
	   type:'date',
	   mandatory:true,
	   dateFormat:'d/m/Y'
	},
	{
		name:'validToDate',
		type:'date',
		mandatory:true,
		dateFormat:'d/m/Y'	
	},
	{
		name:'supplier',
		type:'string'
	},
	{
		name:'origin',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},
	{
		name:'originCity',
		type:'string'
	},
	{
		name:'originStProv',
		type:'string'
	},
	{
		name:'originCountry',
		type:'string'
	},
	{
		name:'destinationCity',
		type:'string'
	},
	{
		name:'destinationStProv',
		type:'string'
	},
	{
		name:'destinationCountry',
		type:'string'
	},
	{
		name:'modelGrp',
		type:'string'
	},
	{
		name:'consolidationType',
		type:'string'
	},
	{
		name:'notChrgble',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},
	{
		name:'notTaxable',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},
	{
		name:'markUp',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},
	{
		name:'markUpCriteria',
		type:'string'
	},
	{
		name:'markUpVal'
	},
	{
		name:'program',
		type:'string'
	},
	{
		name:'index',
		type:'string'
	},
	{
		name:'evntDt',
		type:'string'
		
	},
	{
		name:'priority',
		type:'integer'
	},
	{
		name:'seqNo',
		type:'integer'
	},
	{
		name:'transType',
		type:'string'
	},
	{
       	name:'specialAgrmtNo',
       	type:'integer'
	},
	{
		name:'companyCode',
		type:'string'
	},
	{
		name:'uom',
		type:'string'
	},
	{
		name:'currencyCd',
		type:'string'
	},
	{
		name:'contractId',
		type:'string'
	}
	]	
});

Ext.define('CustmrRateCompositeModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'srvcCd',
		      type:'string',
		      mandatory:true
	        },
	        {
	        	name:'srvcDesc',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'tariffCd',
	        	type:'string'
	        },
	        {
	        	name:'tariffCurrCd',
	        	type:'string'
	        },
	        {
	        	name:'tariffUnitRt'
	        },
	        {
	        	name:'luInd',
	        	type:'string'
	        },
	        {
	        	name:'profitLossCenter',
	        	type:'string'
	        },
	        {
	        	name:'transType',
	        	type:'string'
	        },
	        {
	        	name:'seqNo',
	        	type:'integer'	
	        },
	        {
	        	name:'specialAgrmtNo',
	        	type:'integer'
	        }
	        ],
	   	belongsTo: 'custmrRateDtls'

});
	
Ext.define('cstmrRateMinLoadModel',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
			 name:'conveyanceType',
			 type:'string'
		 },
		 {
			  name:'nbrOfVin',
			  mandatory:true
			// type:'integer'
		 },
		 {
				name:'transType',
				type:'string'
		 },
		 {
			 name:'specialAgrmtNo',
			 type:'integer'
		 },
		 {
			 name:'companyCode',
			 type:'string'
		 }
		]
		
});

Ext.define('cstmrRatesAgreedMileage',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
		   name:'origin',
		   type:'string',
		   mandatory:true
		 },
		 {
			 name:'destination',
		     type:'string',
		     mandatory:true
		 },
		 {
			 name:'distance',
			// type:'integer',
			 mandatory:true
		 },
		 {
			 name:'uom',
			 type:'string',
			 mandatory:true
		 },
		 {
			 name:'transType',
			 type:'string'
		 },
		 {
			 name:'specialAgrmtNo',
			 type:'integer'
		 },
		 {
			 name:'companyCode',
			 type:'string'
		 }
	    ]
	
});

Ext.define('custmrRateDtls',{
	extend:'Ext.data.Model',
	fields:[{
		     name:'specialAgrmtNo',
		     type:'string'
	        },
	        {
	        	name:'companyCode',
	        	type:'string'
	        },
	        {
	        	name:'transType',
	        	type:'string'
	        },
	        {
		name:'srvcCd',
		type:'string',
		mandatory:true
	},
	{
		name:'srvcDesc',
		type:'string',
		mandatory:true
	},
	{
		name:'validFrmDt',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},
	{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},
	{
		name:'supplier',
		type:'string'
		
	},
	{
		name:'trnsportMode',
		type:'string'
	},
	{
		name:'rateTier',
		type:'string'
	},
    {
		name:'origin_loc',
		type:'string'
	},
	{
		name:'destination',
		type:'string'
	},
	{
		name:'conveyanceType',
		type:'string'
	},
	{
		name:'makeCd',
		type:'string'
	},
	{
		name:'modelCd',
		type:'string'
	},
	{
		name:'modelLine',
		type:'string'
	},
	{
		name:'modelYr',
		type:'integer'
	},
	{
		name:'modelGrp',
		type:'string'
	},
	{
		name:'partID',
		type:'string'
	},
	{
		name:'origin_loc_city',
		type:'string'
	},
	{
		name:'origin_loc_St_Prov',
		type:'string'
	},
    {
		name:'origin_country',
		type:'string'
    },
    {
    	name:'dest_City',
		type:'string'
    },
    {
    	name:'dest_St_Prov',
		type:'String'
    },
    {
    	name:'dest_country',
		type:'string'
    },
    {
    	name:'finalDest',
    	type:'string'
    },
    {
    	name:'original_origin',
		type:'string'
    },
    {
    	name:'consolidationType',
		type:'string'
    },
    {
       name:'storageType',
       type:'string'
    },
    {
    	name:'cargoType',
    	type:'string'
    },
    {
    	name:'notChrgble',
    	type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
    },
    {
      name:'markUp',
      type:'bool',convert:function(v)
	   {
		return (v === "Y" || v === true || v === "") ? true : false;
	   }
    },
    {
    	name:'markUpCriteria',
    	type:'string'	
    },
    {
    	name:'markUpVal'
    },
    {
    	name:'factorVal'
    },
    {
    	name:'factorType',
    	type:'string'
    },
    {
    	name:'factorRate'
    },
    {
    	name:'uom',
    	type:'string'
    },
    {
    	name:'fixRate'
    },
    {
    	name:'tariffCd',
    	type:'string'
    },
    {
    	name:'tariffUnitRate'
    },
    {
    	name:'luInd',
    	type:'string'
    },
    {
    	name:'tariff_curr_cd',
    	type:'string'
    },
    {
    	name:'composite',
    	type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
    },
    {
    	name:'nonTaxable',
    	type:'bool',convert:function(v)
		   {
    		  	
			return (v === "Y" || v === true || v==="") ? true:false;
		   }
    },
    {
    	name:'priority',
    	type:'integer'
    },
    {
    	name:'seqNo',
    	type:'integer'
    },
    {
    	name:'status',
    	type:'string'
    }
	],
	associations:[
	              {
            		type:'hasMany',
            	   	model:'CustmrRateCompositeModel', 
            	   	name: 'cstmrRatesCompositeGrid'
	              }
	              ]
});

Ext.define('EventRatingQueryCopyModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'intRqstNum',
		type : 'integer'
	},{
		name : 'seq_no',
		type : 'integer'
	},{
		name : 'unit_id',
		type : 'string'
	}, {
		name : 'origin_cd',
		type : 'string'
	},{
		name : 'conveyance_id',
		type : 'string'
	},{
		name : 'srv_cd',
		type : 'string'
	},{
		name : 'cstmr_cd',
		type : 'string'
	},{
		name : 'fm_dttm',//shipment date
		//type:'string'
		type:'date',
		dateFormat:'d/m/Y H:i'
	},{
		name : 'to_dttm',
		//type:'string'
		type:'date',
		dateFormat:'d/m/Y H:i'
	},{
		name : 'supplier_not_chrgbl_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name : 'cost_cd',
		type : 'string'
	},{
		name : 'supplier_invc_crncy_cd',
		type : 'string'
	},{
		name : 'supplier_srv_amt_invc_crncy',
		type : 'string'
	},{
		name : 'supplier_evnt_sts_cd',
		type : 'string'
	},{
		name : 'cstmr_not_chrgbl_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name : 'revn_cd',
		type : 'string'
	},{
		name : 'cstmr_invc_crncy_cd',
		type : 'string'
	},{
		name : 'cstmr_srv_amt_invc_crncy',
		type : 'string'
	},{
		name : 'cstmr_evnt_sts_cd',
		type : 'string'
	}, {
		name : 'srv_descr',
		type : 'string'
	},{
		name : 'srv_grp_cd',
		type : 'string'
	},{
		name : 'dbtr_pty_cd',
		type : 'string'
	},{
		name : 'sup_srv_amt_invc_crncy_old',
		type : 'string',
		mapping : 'supplier_srv_amt_invc_crncy'
	},{
		name : 'cstmr_srv_amt_invc_crncy_old',
		type : 'string',
		mapping : 'cstmr_srv_amt_invc_crncy'
	},
	{
		name:'version',
		type:'integer'
	}]
});


Ext.define('EventRatingQueryModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'intRqstNum',
		type : 'integer'
	},{
		name : 'seq_no',
		type : 'integer'
	},{
		name : 'unit_id',
		type : 'string'
	}, {
		name : 'origin_cd',
		type : 'string'
	},{
		name : 'dest_cd',
		type : 'string'
	},{
		name : 'conveyance_id',
		type : 'string'
	},{
		name : 'conveyance_type_cd',
		type : 'string'
	},{
		name : 'rate_tier_cd',
		type : 'string'
	},{
		name : 'srv_cd',
		type : 'string'
	},{
		name : 'supplier_cd',
		type : 'string'
	},{
		name : 'cstmr_cd',
		type : 'string'
	},{
		name : 'fm_dttm',//shipment date
		//type:'string'
		type:'date',
		dateFormat:'d/m/Y H:i'
	},{
		name : 'to_dttm',
		//type:'string'
		type:'date',
		dateFormat:'d/m/Y H:i'
	},{
		name : 'trnspt_mode',
		type : 'string'
	},{
		name : 'make_cd',
		type : 'string'
	},{
		name : 'model_cd',
		type : 'string'
	},{
		name : 'modelLine',
		type : 'string'
	},{
		name : 'model_year',
		type : 'string'
	},{
		name : 'model_grp_cd',
		type : 'string'
	},{
		name : 'consolidation_id',
		type : 'string'
	},{
		name : 'consolidation_type_cd',
		type : 'string'
	},{
		name : 'part_cd',
		type : 'string'
	},{
		name : 'origin_city_nm',
		type : 'string'
	},{
		name : 'origin_state_cd',
		type : 'string'
	},{
		name : 'dest_city_nm',
		type : 'string'
	},{
		name : 'dest_state_cd',
		type : 'string'
	},{
		name : 'original_origin_cd',
		type : 'string'
	},{
		name : 'final_dest_cd',
		type : 'string'
	},{
		name : 'storageType',
		type : 'string'
	},{
		name : 'cargoType',
		type : 'String'
	},{
		name : 'billOfLading',
		type : 'string'
	},{
		name : 'chrg_qty',
		type : 'String'
	},{
		name : 'strg_qty',
		type : 'String'
	},{
		name : 'strg_uom_cd',
		type : 'string'
	},{
		name : 'cost_cntr_cd',
		type : 'string'
	},{
		name : 'prev_chrg_qty',
		type : 'string'
	},{
		name : 'prev_chrg_uom_cd',
		type : 'string'
	},{
		name : 'dist_qty',
		type : 'string'
	},{
		name : 'dist_uom_cd',
		type : 'string'
	}, {
		name : 'ratng_dest_cd',
		type : 'string'
	},{
		name : 'ratng_dist_qty',
		type : 'string'
	},{
		name : 'ratng_dist_uom_cd',
		type : 'string'
	},{
		name : 'supplier_not_chrgbl_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name : 'cost_cd',
		type : 'string'
	},{
		name : 'supplier_invc_crncy_cd',
		type : 'string'
	},{
		name : 'supplier_srv_amt_invc_crncy',
		type : 'string'
	},{
		name : 'sup_tot_tax_amt_invc_crncy',
		type : 'string'
	},{
		name : 'sup_tot_invc_amt_invc_crncy',
		type : 'string'
	},{
		name : 'supplier_evnt_sts_cd',
		type : 'string'
	},{
		name : 'supplier_invc_no',
		type : 'string'
	},{
		name : 'cstmr_not_chrgbl_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name : 'revn_cd',
		type : 'string'
	},{
		name : 'cstmr_invc_crncy_cd',
		type : 'string'
	},{
		name : 'cstmr_srv_amt_invc_crncy',
		type : 'string'
	},{
		name : 'cstmr_tot_tax_amt_invc_crncy',
		type : 'string'
	},{
		name : 'cstmr_tot_invc_amt_invc_crncy',
		type : 'string'
	},{
		name : 'cstmr_evnt_sts_cd',
		type : 'string'
	}, {
		name : 'srv_descr',
		type : 'string'
	},{
		name : 'srv_grp_cd',
		type : 'string'
	},{
		name : 'dbtr_pty_cd',
		type : 'string'
	},{
		name : 'cstmr_invc_no',
		type : 'string'
	},{
		name : 'sup_srv_amt_invc_crncy_old',
		type : 'string',
		mapping : 'supplier_srv_amt_invc_crncy'
	},{
		name : 'cstmr_srv_amt_invc_crncy_old',
		type : 'string',
		mapping : 'cstmr_srv_amt_invc_crncy'
	},{
		name : 'fuel_srchrg_srv_flg',
		type : 'string'
	},{
		name : 'ld_ref_no',
		type : 'string'
	},
	{
		name:'rqst_dttm',
		type : 'string'
		/*type:'date',
		dateFormat:'d/m/Y'*/
	},{
		name : 'fm_dttm_estm_flg',
		type : 'string'
	},{
		name : 'origin_cntry_cd',
		type : 'string'
	},{
		name : 'model_nm',
		type : 'string'
	},{
		name : 'shipment_type_cd',
		type : 'string'
	},{
		name : 'dest_addr_1',
		type : 'string'
	},{
		name : 'dest_addr_2',
		type : 'string'
	},{
		name : 'dest_po_box',
		type : 'string'
	},{
		name : 'dest_cntry_cd',
		type : 'string'
	},{
		name : 'to_dttm_estm_flg',
		type : 'string'
	},{
		name : 'fuel_srchrg_app_flg',
		type : 'string'
	},{
		name : 'supplier_ratng_seq_no',
		type : 'integer'
	},{
		name : 'supplier_composite_flg',
		type : 'string'
	},{
		name : 'supplier_tax_applbl_flg',
		type : 'string'
	},{
		name : 'supplier_ratng_err_msg_no',
		type : 'integer'
	},{
		name : 'supplier_man_rate_flg',
		type : 'string'
	},{
		name : 'parent_int_rqst_no',
		type : 'integer'
	},{
		name : 'parent_seq_no',
		type : 'integer'
	},{
		name : 'cstmr_ratng_seq_no',
		type : 'integer'
	},{
		name : 'cstmr_composite_flg',
		type : 'string'
	},{
		name : 'cstmr_tax_applbl_flg',
		type : 'string'
	},{
		name : 'cstmr_ratng_err_msg_no',
		type : 'integer'
	},{
		name : 'cstmr_man_rate_flg',
		type : 'string'
	},{
		name : 'supplier_prf_invc_no',
		type : 'integer'
	},{
		name : 'cstmr_prf_invc_no',
		type : 'integer'
	},{
		name : 'srvc_type',
		type : 'string'
	},
	{
		name:'version',
		type:'integer'
	}],
	associations :[{
	   	type:'hasMany',
	   	model:'eventRatingQryTaxwindowGridModel', 
	   	name: 'eventRatingQryTaxDtlsGridResult'
      },
      {
  	   	type:'hasMany',
  	   	model:'eventRatingQryTaxwindowGridModel', 
  	   	name: 'eventRatingQryCustmerTaxDtlsGridResult'
        }]
});

Ext.define('eventRatingQryTaxwindowGridModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'int_rqst_no',
		type : 'integer'
	},{
		name:'seq_no',
		type : 'integer'
	},{
		name:'user_rating_seq_no',
		type : 'integer'
	},{
		name:'tax_type_cd',
		type :'string'
	},{
		name:'cost_cd',
		type :'string'
	},{
		name:'tax_prcntg',
		type :'float'
	},{
		name:'cal_on_srv_amt_flg',
		type :'string'
	},{
		name:'cal_on_tax_type_cd',
		type :'string'
	},{
		name:'tax_amt_invc_crncy',
		type :'string'
	},{
		name:'invc_crncy_cd',
		type :'string'
	},{
		name:'srv_amt_invc_crncy',
		type :'string'
	},{
		name:'supp_flg',
		type :'string'
	},{
		name:'old_tax_prcntg',
		type :'float',
		mapping : 'tax_prcntg'
	},
	{
		name:'transType',
		type :'string'
	}
	]
});

Ext.define('ContractIdentification',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'customer'
	},{
		name:'serviceType',
		type:'string',
		mandatory: true
	},{
		name:'serviceCode',
		type:'string'	
	},{
		name:'origin',
		type:'string'
	},{
		name:'destination',
		type:'string'
	},{
		name:'statusDate',
		type:'string',
		mandatory:true
	},{
		name:'trnsType'
	}],
	belongsTo: 'CustomerMasterDetails'
});

Ext.define('DefaultSupplier',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'customer'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'supplierCode',
		type:'string',
		mandatory:true
	},{
		name:'trnsType'
	}],
	belongsTo: 'CustomerMasterDetails'
});
Ext.define('DistanceRoundingCriteria',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'customer'
	},{
		name:'unitOfMeasure',
		mandatory:true
	},{
		name:'roundingType',
		mandatory:true
	},{
		name:'roundingValue',
		type : 'float',
		mandatory:true,
		useNull : true
	},{
		name:'minimumDistanceValue',
		type : 'float',
		useNull : true
	},{
		name:'trnsType'
	}],
	belongsTo: 'CustomerMasterDetails'
});
Ext.define('RateRoundingCriteria',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'customer'
	},{
		name:'serviceType'
	},{
		name:'currencyCode',
		mandatory:true
	},{
		name:'roundingType',
		mandatory:true
	},{
		name:'roundingValue',
		type : 'float',
		mandatory:true,
		useNull : true
	},{
		name:'trnsType'
	}],
	belongsTo: 'CustomerMasterDetails'
});
Ext.define('CustomerMasterDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string',
		mandatory:true
	},{
		name:'customer',
		type:'string'
	},{
		name:'customerName',
		type:'string'
	},{
		name:'defaultCurrency',
		type:'string'
	},{
		name:'taxRefNo',
		type:'string'
	},{
		name:'address1',
		type:'string'
	},{
		name:'address2',
		type:'string'
	},{
		name:'city',
		type:'string'
	},{
		name:'state',
		type:'string'
	},{
		name:'country',
		type:'string'
	},{
		name:'postalCode',
		type:'string'
	},{
		name:'telephoneNo',
		type:'string'
	},{
		name:'faxNumber',
		type:'string'
	},{
		name:'mobileNumber',
		type:'string'
	},{
		name:'eMailAddress',
		type:'string'
	},{
		name:'contactPersonName1',
		type:'string'
	},{
		name:'contactPersonName2',
		type:'string'
	},{
		name:'subLedgerCode',
		type:'string'
	},{
		name:'sendEstmARMsgFlg'	,
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}	
	},{
		name:'waitForAPAprroveFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'autoApproveApplnAdviceFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'sendCustInvoiceMsgFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'financialCustomer',
		type:'string'
	},{
		name:'financialContractNo',
		type:'string'
	},{
		name:'ratingDestinationApplicableFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}		
	},{
		name:'remarks1',
		type:'string'
	},{
		name:'remarks2',
		type:'string'
	},{
		name:'trnsType',
		type:'string'
	},{
		name:'send_covus_msg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'incl_dtls_cnsldt_act_covus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'incl_dtls_non_cnsldt_act_covus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'incl_dtls_cnsldt_acrvl_covus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	},{
		name:'incl_dtls_non_cnsldt_acrvl_covus',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}			
	}],
	associations :[{
    	   	type:'hasMany',
    	   	model:'ContractIdentification', 
    	   	name: 'customerStatusDateGridResult'
	      },{
	    	type:'hasMany',
	    	model:'DefaultSupplier', 
	    	name: 'customerDefaultSupplierGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'DistanceRoundingCriteria', 
			name: 'customerDistanceRoundingCriteriaGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'RateRoundingCriteria', 
			name: 'customerRateRoundingCriteriaGridResult'	    	  
	      }
	      ]		    
});





Ext.define('cstmrRateHdrGridModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'companyCode',
	        	type:'string'
	        },
	        {
	        	name:'specialAgrmtNo',
	        	type:'integer'
	        },
	{
		name:'contractId',
		mandatory:true,
		type:'string'
	},
	{
		name:'validFrmDt',
		type:'date',
		mandatory:true,
		dateFormat:'d/m/Y'
	},
	{
		name:'validToDt',
		type:'date',
		mandatory:true,
		dateFormat:'d/m/Y'
	},
	{
		name:'cstmr',
		mandatory:true,
		type:'string'
	},
	{
		name:'cstmrNm',
		type:'string'
	},
	{
		name:'dbtrParty',
		mandatory:true,
		type:'string'
	},
	{
		name:'dbtrPartyNm',
		type:'string'
	},
	{
		name:'remark',
		type:'string'
	},
	{
		name:'srvcLvlValidDt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},
	{
		name:'transType',
		type:'string'
	},
	{
		name:'version',
		type:'integer'
	}
	]
});


Ext.define('CstmrSrvGrpGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCd',
		type:'string'
	},{
		name:'customerCd',
		type:'string',
		mandatory:true
	},	
	{
		name:'customerName',
		type:'string'	
	},
	{
		name:'srvGrpCd',
		type:'string',
		mandatory:true
	},
	{
		name:'srvGrpDesc',
		type:'string',
		mandatory:true
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rno',
		type:'string'
	},
	{
		name:'version',
		type:'integer'
	}],
	hasMany: {
	       model:'serviceTypeSrvGrpSetup', 
	       name: 'customerSrvTypeGridList'
	    }
	
	
});

Ext.define('serviceTypeSrvGrpSetup',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCd',
		type:'string'
	},{
		name:'customerCd',
		type:'string'
	},{
		name:'srvGrpCd',
		type:'string'	
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},
	{
		name:'serviceCode',
		type:'string',
		mandatory:true
	},
	{
		name:'serviceDesc',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rno',
		type:'string'
	}
	],
	belongsTo: 'CstmrSrvGrpGrid'
});

Ext.define('InvoiceNumberDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd',
		type : 'string'
	}, {
		name : 'customer',
		type : 'string'
	},{
		name : 'invcNo',
		type : 'string'
	},{
		name : 'dueDate',
		type : 'string'
	},
	{
		name:'creditDate',
		type : 'string'
	},
	{
		name:'proInvNumber',
		type : 'string'
	}]
});

Ext.define('SuppInvoiceEntryNumberDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'invcNum',
		type : 'string'
	}, {
		name : 'supplier',
		type : 'string'
	}]
});



Ext.define('specialMoveEntryGridData',{
	extend:'Ext.data.Model',
	fields:[{
		name:'serviceCode',
		type:'string'
	},	
	{
		name:'unitId',
		type:'string'	
	},
	{
		name:'make',
		type:'string'
	},
	{
		name:'model',
		type:'string'
	},
	{
		name:'modelYear',
		type:'string'
	}, {
		name:'shippingRef',
		type:'string'
	},	
	{
		name:'customerSalesRGN',
		type:'string'	
	},
	{
		name:'dealerCode',
		type:'string'
	},
	{
		name:'originalOrigin',
		type:'string'
	},
	{
		name:'finalDestination',
		type:'string'
	},
	{
		name:'rateTier',
		type:'string'
	},
	{
		name:'additionalServiceComments',
		type:'string'
	}, 
	{
		name:'supplierNoCharge',
		type: 'bool',
     	convert:function(v)
     	 {

     	return (v === "Y" || v === true || v === "") ? true : false;

     	
     	 }
	}, {
		name:'supplierExpenseCode',
		type:'string'
	},	
	{
		name:'supplierCurrency',
		type:'string'	
	},
	{
		name:'supplierServiceAmount',
		type : 'string'
		//type:'float'
	},
	{
		name:'supplierFuelSurChrge',
		type: 'bool',
     	convert:function(v)
     	 {

     	return (v === "Y" || v === true || v === "") ? true : false;

     	 }
		
	},
	{
		name:'supplierTaxAmount',
		type : 'string'
		//type:'float'
	},
	{
		name:'supplierTotalAmount',
		type : 'string'
		//type:'float'
	},
	{
		name:'supplierStatus',
		type:'string'
	},{
		name:'supplierInvoiceNumber',
		type:'string'
	},{
		name:'supplierPrfInvNbr',
		type:'string'
	},
	{
		name:'seqNbr',
		type:'string'
	}, 
	{
		name:'customerNoCharge',
		 type: 'bool',
     	convert:function(v)
     	 {

     	
     	return (v === "Y" || v === true || v === "") ? true : false;

     	
     	 }
	}
	,
	{
		name:'customerGLCode',
		type:'string'
	},
	{
		name:'customerCurrency',
		type:'string'
	},
	{
		name:'customerServiceAmount',
		type : 'string'
		//type:'float'
	}, 
	{
		name:'customerTaxAmount',
		type : 'string'
		//type:'float'
	}, {
		name:'customerTotalAmount',
		type : 'string'
		//type:'float'
	},	
	{
		name:'customerServiceDesc',
		type:'string'	
	},
	{
		name:'customerServiceGroupCode',
		type:'string'
	},
	{
		name:'customerDebtorPartyCode',
		type:'string'
	},
	{
		name:'customerStatus',
		type:'string'
	},
	{
		name:'customerInvoiceNumber',
		type:'string'
	},{
		name:'customerPrfInvNbr',
		type:'string'
	},
	{
		name:'status',
		type:'string'
	} ,
	{
		name:'customerSeqNbr',
		type:'int'
	},
	{
		name:'supplierSeqNbr',
		type:'int'
	},
	{
		name:'intRqstNbr',
		type:'int'
	},{
		name:'companyCode',
		type:'string'
	},{
		name:'chargeQuantity',
		type:'float'
	},{
		name:'serviceType',
		type:'string'
	},{
		name:'supplierManRateFlag',
		type:'string'
	},{
		name:'customerManRateFlag',
		type:'string'
	},
	{
		name : 'sup_srv_amt_invc_crncy_old',
		type : 'string',
		mapping : 'supplier_srv_amt_invc_crncy'
	},{
		name : 'cstmr_srv_amt_invc_crncy_old',
		type : 'string'
	},
	{
		name : 'supplierTaxFlag',
		type : 'string'
	},
	{
		name : 'supplierRatingERRNbr',
		type : 'integer'
		
	},{
		name : 'customerRatingERRNbr',
		type : 'integer'
		
	},{
		name : 'parentIntRqstNbr',
		type : 'string'
	},
	{
		name : 'parentSeqNbr',
		type : 'string'
	},
	{
		name:'fuelSurChargeSrvFlag',
		type: 'bool',
     	convert:function(v)
     	 {

     	return (v === "Y" || v === true || v === "") ? true : false;

     	
     	 }
	},{
		name:'fuelSurChargeAppFlag',
		type: 'bool',
     	convert:function(v)
     	 {
     	
     	return (v === "Y" || v === true || v === "") ? true : false;
     	 }
	},{
		name : 'supplier_composite_flg',
		type : 'string'
	},{
		name : 'cstmr_composite_flg',
		type : 'string'
	}
	],
	associations :[{
	   	type:'hasMany',
	   	model:'eventRatingQryTaxwindowGridModel', 
	   	name: 'eventRatingQryTaxDtlsGridResult'
      },
      {
  	   	type:'hasMany',
  	   	model:'eventRatingQryTaxwindowGridModel', 
  	   	name: 'eventRatingQryCustmerTaxDtlsGridResult'
        }]
});


Ext.define('programLoV',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
		   name:'fuelSurchrgPrgmNm',
		   type:'string'
	     },
	     {
	    	 name:'fuelSurchrgPrgm',
	    	 type:'string'
	     },
	     {
	    	 name:'uomCd',
	    	 type:'string'
	     },
	     {
	    	 name:'currencyCd',
	    	 type:'string'
	     }
	]
});


Ext.define('indexLov',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
		   name:'fuelSurchrgIndexPrgmNm',
		   type:'string'
		 },
		 {
			 name:'fuelSurchrgIndexCd',
			 type:'string'
		 },
		 {
	    	 name:'uomCd',
	    	 type:'string'
	     },
	     {
	    	 name:'currencyCd',
	    	 type:'string'
	     }
		 ]
});





Ext.define('CustomerInvoiceStatus',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCd'
	},{
		name:'customer'
	},{
		name:'cstmrNm'
	},{
		name:'invcNo'
	},{
		name:'dbtrPartyCd'
	},{
		name:'profitLossCenter'
	},{
		name:'invoiceFromDate',
		dateFormat:'d/m/Y',
		type:'date'
	},{
		name:'invoiceToDate',
		dateFormat:'d/m/Y',
		type:'date'
	},{
		name:'invoiceType'
	},{
		name:'proformaStatus'
	},{
		name:'documentType'
	},{
		name:'invoiceAmt'
	},{
		name:'paidAmt'
	},{
		name:'currency'
	},{
		name:'dueDate',
		dateFormat:'d/m/Y',
		type:'date'
	},{
		name:'lastPaymentDate',
		dateFormat:'d/m/Y',
		type:'date'
	},{
		name:'invoiceStatus'
	},{
		name:'creditDate',
		dateFormat:'d/m/Y',
		type:'date'
	},{
		name:'invoiceStatusDesc'
	},{
		name:'prfinvcno'
	},{
		name:'applnadvicerejectflg'
	},{
		name:'estmrvsdflg'
	},{
		name:'documentTypeDesc'
	},{
		name:'invoiceTypeDesc'
	},{
		name:'cnsldtflg'
	},{
		name:'printCnt'
	},{
		name:'emailCnt'
	},{
		name:'emailId'
	}
	
	]
});


Ext.define('printInvoiceStatusData', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'invcRepFile'
	}, {
		name : 'backRepFile'
	},{
		name : 'invcFileSts'
	},{
		name : 'bkupFileSts'
	},{
		name: 'prfinvcno'
	}]
});

Ext.define('cstmrPrintTmpltModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'customerCode',
		type :'string'
	},{
		name : 'printPrepaid',
		type :'string'
	},{
		name : 'printCollect',
		type :'string'
	},{
		name : 'transType',
		type :'string'
	}]
});


Ext.define('DummyModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'field1',
		type : 'string'
	},{
		name : 'field2',
		type : 'string'
	},{
		name : 'field3',
		type : 'string'
	}]
});


Ext.define('SupplrLookUpDTO', {
	extend : 'Ext.data.Model',
	fields : [ 
	          	{name : 'code',	type : 'string'},
	          	{name : 'name',	type : 'string'}
			 ]
	});

Ext.define('SupplierInvoiceStatus',{
	extend:'Ext.data.Model',
	fields:[{
		name:'supplier'
	},{
		name:'invcNo'
	},{
		name:'invcDate'
	},{
		name:'documentType'
	},{
		name:'invoiceAmt'
	},{
		name:'apprvdAmt'
	},{
		name:'paidAmt'
	},{
		name:'currency'
	},{
		name:'dueDate'
	},{
		name:'lastPaymentDate'
	},{
		name:'invoiceSts'
	}	
	]
});


Ext.define('SupplierMasterDetailsLookUp', {
	extend : 'Ext.data.Model',
	fields : [ 
	           {
		name : 'code',
		type : 'string'
	}, {
		name : 'name',
		type : 'string'
	}
	]
});
Ext.define('TriggerIdentifyDto', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'serviceType',
		type : 'string',
		  mandatory:true
	}, {
		name : 'serviceCode',
		type : 'string'
	}, {
		name : 'accurualTriggerPoint',
		type : 'string'
	}, {
		name : 'triggerPoint',
		type : 'string',
		mandatory:true
	}, {
		name : 'creditTerm',
		type : 'float'
	}, {
		name : 'creditSupplierAproval',
		type : 'string'
	}, {
		name : 'companyCode',
		type : 'string'
	}, {
		name : 'customerCode',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	} , {
		name : 'version',
		type : 'integer'
	}
	
	]
});
Ext.define('AccrualGroupingCriteriaDto',{
		extend:'Ext.data.Model',
		fields:[{	
				name : 'serviceGroupCode',
				type : 'string'	,
				mandatory:true
			},{	
				name : 'serviceGroup',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor
			},{		
				name : 'serviceType',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{		
				name : 'serviceCode',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{		
				name : 'tariffCurrency',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'taxes',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'documentType',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'profitLossCentre',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'originServiceLocation',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'destination',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'originalOrigin',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'finalDestination',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'conveyance',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'loadReference',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'workOrderNumber',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'supplierCode',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'transportMode',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'consolidationId',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'maximumLinesInInvoice',
				type : 'float'	
			},{	
				name : 'printTemplate',
				type : 'string'	,
				mandatory:true
			},{	
				name : 'consolidate',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'serviceGroup1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'serviceType1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'serviceCode1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'tariffCurrency1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'taxes1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'documentType1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'profitLossCentre1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'originServiceLocation1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'destination1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'originalOrigin1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'finalDestination1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'conveyance1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'loadReference1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'workOrderNumber1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'supplierCode1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'transportMode1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'consolidationId1',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor	
			},{	
				name : 'afterGenerationFreq',
				type : 'float'	,
				mandatory:true
			},{	
				name : 'generationFrequency',
				type : 'string'	,
				mandatory:true
			},{	
				name : 'time',
				type : 'string',
				mandatory:true
			},{	
				name : 'autoAprove',
				type : 'string',
				convert : Modules.GlobalFuncs.stringToBooleanConvertor
			},{
				name : 'companyCode',
				type : 'string'
			},{
				name : 'customerCode',
				type : 'string'
			}, {
				name : 'transType',
				type : 'string'
			}, {
				name : 'primaryCheck',
				type : 'string'
			}, {
				name : 'version',
				type : 'integer'
			}]
	}); 

Ext.define('parameterDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'paramnm'
	}, {
		name : 'paramvalue'
	},{
		name : 'paramRmrk'
	},{
		name : 'companyCd'
	}]
});

Ext.define('customerInvoicePrint', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'printerCd'
	}, {
		name : 'printerCnfgPth'
	},{
		name : 'companyCd'
	}]
});


Ext.define('customerEventLogDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'backUpCopyCount'
	}, {
		name : 'backUpRequiredFlg'
	},{
		name : 'ccEmailAddress'
	},{
		name : 'invcCopyCount'
	},{
		name : 'invcPrinterCD'
	},{
		name : 'backUpPrinterCD'
	},{
		name : 'invcRequiredFlg'
	},{
		name : 'prfinvcno'
	}]
});
Ext.define('supplierInvoiceStatusDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd'
	},{
		name : 'supplier'
	},{
		name : 'invoiceNumber'
	},{
		name : 'invoiceFromDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},{
		name : 'invoiceToDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},{
		name : 'documentType'
	},{
		name : 'invoiceType'
	},{
		name : 'invoiceAmt'
	},{
		name : 'paidAmt'
	},{
		name : 'approvedAmt'
	},{
		name : 'currency'
	},{
		name : 'dueDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},{
		name : 'lastPaymentDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},{
		name : 'invoiceStatusDesc'
	},{
		name : 'invoiceStatus'
	},{
		name : 'prfinvcno'
	},{
		name : 'supplierDocumentList'
	},{
		name : 'supplierInvoiceStatusList'
	},{
		name : 'ldRefNo'
	},{
		name : 'conveyanceId'
	},{
		name : 'shippingRefNo'
	},{
		name : 'refInvNo'
	},{
		name : 'reCalcDttmFlg'
	},{
		name : 'creditDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},{
		name : 'documentTypeDesc'
	},{
		name : 'crdtterm'
	},{
		name : 'supplierTemplateCd'
	}
	]
});



/**
 * 
 * 
 * Supplier Remittence Details screen MODELS
 * 
 */


Ext.define('SupplierRemitDtlsParentGridModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'paymentNumber',
		type:'string'
	},{
		name:'supplierID',
		type:'string'	
	},{
		name:'invoiceNumber',
		type:'string'
	},
	{
		name:'invoiceDate',dateFormat:'d/m/Y',type:'date'
	},{
		name:'payMode',
		type:'string'
	},{
		name:'payDocument',
		type:'string'
	},{
		name:'payDate',dateFormat:'d/m/Y',type:'date'
	},{
		name:'invoiceAmount',
		type:'float'
	},{
		name:'paidAmount',
		type:'float'
	},{
		name:'currency',
		type:'string'
	},{
		name:'supplierTemplateCode',
		type:'string'
	},{
		name:'proformaInvoiceNumber',
		type:'string'
	}]
});






Ext.define('SupplierRemitDtlsChildGridModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'serviceCode',
		type:'string'	
	},{
		name:'unitID',
		type:'string'
	},
	{
		name:'shippingRef',
		type:'string'
	},{
		name:'eventLoadRef',
		type:'string'
	},{
		name:'conveyanceID',
		type:'string'
	},{
		name:'partID',
		type:'string'
	},{
		name:'deliveryDate',dateFormat:'d/m/Y',type:'date'
	},{
		name:'invoiceAmount',
		type:'float'
	},{
		name:'approvedAmount',
		type:'float'
	},{
		name:'paidAmount',
		type:'float'
	},{
		name:'currency',
		type:'string'
	},{
		name:'overrideRejectComment',
		type:'string'
	}]
});


Ext.define('suppLineItemStatusModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'supplier',
		type:'string'
	}, {
		name : 'invoiceNumber',
		type:'string'
	},{
		name : 'invoiceDate'
	},{
		name : 'serviceCode',
		type:'string'
	},{
		name : 'invoiceAmount'/*,
		type:'float'*/
	},{
		name : 'approvedAmount'/*,
		type:'float'*/
	},{
		name : 'paidAmount'/*,
		type:'float'*/
	},{
		name : 'currency'
	},{
		name : 'unitId'
	},{
		name : 'loadReference'
	},{
		name : 'conveyanceId'
	},{
		name : 'partId'
	},{
		name : 'deliveryCompletionDate'
	},{
		name : 'dueDate'
	},{
		name : 'lastPaymentDate'
	},{
		name : 'lineItemStatus'
	},{
		name : 'reason'
	},{
		name : 'serviceType'
	},{
		name : 'companyCd'
	},{
		name : 'invcItemStatus'
	},{
		name : 'invcCrdtNoteInd'
	},{
		name : 'proformaInvoiceNo'
	},{
		name : 'itemNo'
	},{
		name : 'supplTemplateCode'
	}]
});

Ext.define('changeLogParentGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'functionName',
		type:'string'
	}, {
		name : 'userName',
		type:'string'
	},{
		name : 'transInd',
		type:'string'
	},{
		name : 'level1',
		type:'string'
	},{
		name : 'level1Value',
		type:'string'
	},{
		name : 'level2',
		type:'string'
	},{
		name : 'level2Value',
		type:'string'
	},{
		name : 'level3',
		type:'string'
	},{
		name : 'level3Value',
		type:'string'
	},{
		name : 'level4',
		type:'string'
	},{
		name : 'level4Value',
		type:'string'
	},{
		name : 'logDateTime',dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,type:'date'
	},{
		name : 'changeSeqNo',
		type : 'string'
	}]
});

Ext.define('changeLogChildGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'fieldName',
		type:'string'
	},{
		name : 'oldValue',
		type:'string'
	},{
		name : 'newValue',
		type:'string'
	}]
});


Ext.define('GroupModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'groupId',
		type : 'string'
	},{
		name : 'groupCode',
		type : 'string'
	},{
		name : 'groupName',
		type : 'string'
	},{
		name : 'groupDesc',
		type : 'string'
	},{
		name : 'serviceTypeCode',
		type : 'string'
	},{
		name : 'serviceTypeDesc',
		type : 'string'
	},{
		name : 'systemDefined',
		type : 'string'
	}
	]
});





Ext.define('UserModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'userName',
		type : 'string'
	},{
		name : 'userFullName',
		type : 'string'
	},{
		name : 'userStatus',
		type : 'string'
	},{
		name : 'userDesc',
		type : 'string'
	},{
		name : 'userId',
		type : 'string'
	},{
		name : 'serviceTypeGroupDescription',
		type : 'string'
	},{
		name : 'serviceTypeGroupCode',
		type : 'string'
	}]
});


Ext.define('Journal',{
	extend:'Ext.data.Model',
	fields:[{
		name:'dateOrTime',dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,type:'date'
	},	
	{
		name:'userId',
		type:'string'	
	},
	{
		name:'eDIPartnerOrModule',
		type:'string'
	},
	{
		name:'feildName',
		type:'string'
	},
	{
		name:'action',
		type:'string'
	},
	{
		name:'loadRefNo',
		type:'string'
	},
	{
		name:'unitId',
		type:'string'
	},
	{
		name:'oldValue',
		type:'string'
	},
	{
		name:'newValue',
		type:'string'
	}]
});

Ext.define('AuditUserIdDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'userName',
		type:'string'
	},	
	{
		name:'fullName',
		type:'string'	
	},	
	{
		name:'userId',
		type:'string'	
	}]
});

Ext.define('AuditLogModuleNameModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'moduleName',
		type:'string'
	},{
		name:'moduleCode',
		type:'string'
	}]
});
Ext.define('AuditLogFunctionNameModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'functionDesc',
		type:'string'
	},{
		name:'functionName',
		type:'string'
	},{
		name:'functionCode',
		type:'string'
	}]
});
Ext.define('AuditLogApplnServerNameModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'hostname',
		type:'string'
	}]
});
Ext.define('AuditLogQuery',{
	extend:'Ext.data.Model',
	fields:[{
		name:'hostName',
		type:'string'
	},	
	{
		name:'userId',
		type:'string'
	},
	{
		name:'userName',
		type:'string'
	},
	{
		name:'moduleName',
		type:'string'
	},
	{
		name:'moduleCode',
		type:'string'
	},
	{
		name:'functionName',
		type:'string'
	},
	{
		name:'functionCode',
		type:'string'
	},
	{
		name:'startDate',dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,type:'date'
	},
	{
		name:'exitDate',dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,type:'date'
	}]
});

Ext.define('ErrorLogDTO', {
	extend : 'Ext.data.Model',
				fields : [ {
					name : 'errorLogDate',
					type : 'string'
				},
				{
					name : 'userName',
					type : 'string'
				},
				           {
					name : 'hostName',
					type : 'string'
			
				},
				           {
					name : 'errorFnDes',
					type : 'string'
			
				},
				           {
					name : 'errorPosition',
					type : 'string'
			
				},
				           {
					name : 'description',
					type : 'string'
			
				}]
});




Ext.define('DefaultLanguageModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'languageCode',
		type:'string'
	},
	{
		name:'languageDesc',
		type:'string'
	}]
});

Ext.define('TimeZoneModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'timeZoneCode',
		type:'string'
	},
	{
		name:'timeZoneAlterStr',
		type:'string'
	}]
});

Ext.define('OceanJournal',{
	extend:'Ext.data.Model',
	fields:[{
		name:'dateOrTime',dateFormat:Modules.GlobalVars.dateTimeFormatGlobal,type:'date'
	},{
		name:'userId',
		type:'string'	
	},{
		name:'eDIPartnerOrModule',
		type:'string'
	},{
		name:'feildName',
		type:'string'
	},{
		name:'action',
		type:'string'
	},{
		name:'blNo',
		type:'string'
	},{
		name:'itemNo',
		type:'string'
	},{
		name:'oldValue',
		type:'string'
	},{
		name:'newValue',
		type:'string'
	},{
		name:'serviceCd',
		type:'string'
	},{
		name:'invoiceNo',
		type:'string'
	}]
});

Ext.define('ExternalPartyDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'partyCode',
		type:'string'
	},{
		name:'serviceTypeGroupCode',
		type:'string'
	}]
});

Ext.define('CustomerDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'customerCode',
		type:'string'
	},{
		name:'defaultFlag',
		type:'string',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},{
		name:'customerName',
		type:'string'
	}]
});

Ext.define('SupplierDTO',{
	extend:'Ext.data.Model',
	fields:[{
		name:'supplierCode',
		type:'string'
	},{
		name:'defaultFlag',
		type:'string',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},{
		name:'supplierName',
		type:'string'
	}]
});
Ext.define('CompanyMasterDTO',{
	extend:'Ext.data.Model',
	fields : [{
		name : 'companyName',
		type : 'string'
	},{
		name : 'companyCode',
		type : 'string'
	},{
		name : 'defaultCurrency',
		type : 'string'
	},{
		name : 'apName',
		type : 'string'
	}, {
		name : 'apAddress1',
		type : 'string'
	}, {
		name : 'apAddress2',
		type : 'string'
	}, {
		name : 'apCity',
		type : 'string'
	}, {
		name : 'apState',
		type : 'string'
	}, {
		name : 'apCountry',
		type : 'string'
	}, {
		name : 'apPostal',
		type : 'string'
	}, {
		name : 'apTeleNbr',
		type : 'string'
	}, {
		name : 'apFaxNbr',
		type : 'string'
	}, {
		name : 'apEmail',
		type : 'string'
	},{
		name : 'arName',
		type : 'string'
	}, {
		name : 'arAddress1',
		type : 'string'
	}, {
		name : 'arAddress2',
		type : 'string'
	}, {
		name : 'arCity',
		type : 'string'
	}, {
		name : 'arState',
		type : 'string'
	}, {
		name : 'arCountry',
		type : 'string'
	}, {
		name : 'arPostal',
		type : 'string'
	}, {
		name : 'arTeleNbr',
		type : 'string'
	}, {
		name : 'arFaxNbr',
		type : 'string'
	}, {
		name : 'arEmail',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	}]
});


Ext.define('supplierReconciliation', {
	extend : 'Ext.data.Model',
	fields : [
		{name : 'cmpny_cd', 		type : 'string'},
		{name : 'supplier_cd', 		type : 'string'},
		{name : 'invc_no', 			type : 'string'},
		{name : 'srv_cd', 			type : 'string',   mandatory : true},
		{name : 'unit_id', 			type : 'string'},
		{name : 'ld_ref_no', 		type : 'string'},
		{name : 'origin_cd', 		type : 'string'},
		{name : 'dest_cd', 			type : 'string'},
		{name : 'dest_city_nm', 	type : 'string'},
		{name : 'conveyance_id', 	type : 'string'},
		{name : 'shipng_ref_no', 	type : 'string'},
		{name : 'make_cd', 			type : 'string'},
		{name : 'model_cd', 		type : 'string'},
		{name : 'model_year', 		type : 'string'},
		{name : 'rate_tier_cd', 	type : 'string'},
		{name : 'wk_ord_no', 		type : 'string'},
		{name : 'part_cd', 			type : 'string'}, //Part number
		{name : 'ratng_dest_cd',	type : 'string'},
		{name : 'rqst_dttm', 		type:'date',dateFormat:'d/m/Y'}, //temder date
		{name : 'fm_dttm', 			type:'date',dateFormat:'d/m/Y'}, //shipment date
		{name : 'to_dttm', 			type:'date',dateFormat:'d/m/Y'}, //delivery date
		{name : 'srv_descr', 		type : 'string'},  //item description
		{name : 'cstmr_cd', 	    type : 'string'},
		{name : 'cost_cntr_cd', 	type : 'string'}, //profitloss center
		{name : 'shipmentType', 	type : 'string'},
		{name : 'orderType', 		type : 'string'},
		{name : 'abnormalMoveType',type : 'string'},
		{name : 'cstmrSalesRgn', 	type : 'string'},
		{name : 'finalDestination', type : 'string'},
		{name : 'dealer', 		    type : 'string'},
		{name : 'consolidation_id', type : 'string'},
		{name : 'srv_amt_invc_crncy', type : 'float',useNull:true}, //supplier amount
		{name : 'supplier_srv_amt_invc_crncy', type : 'float',useNull:true},  //Event amount
		{name : 'invc_item_sts',    type : 'string'},
		{name : 'mismatch_reason_cd',type : 'string'},
		{name : 'transType', 		type : 'string'},
		{name : 'prf_invc_no', 		type : 'integer'},
		{name : 'item_no', 		type : 'integer'},
		{name : 'summ_id', 			type : 'integer'},
		{name : 'srv_type', 		type : 'string'},
		{name : 'invc_crdt_note_ind',type : 'string'},
		{name : 'invc_due_dttm', 	type : 'string'},
		{name : 'supplier_template_cd', 	type : 'string'},
		{name : 'int_rqst_no', 		type : 'integer'},
		{name : 'seq_no', 			type : 'integer'},
		{name : 'supplier_ratng_seq_no', type : 'integer'},
		{name : 'partial_paymnt_flg', 	 type : 'string'},
		{name : 'invc_auto_approve_flg', type : 'string'},
		{name : 'invc_crncy_cd', 	type : 'string'},
		{name : 'load_flg', 	type : 'string'},
		{name : 'tax_amt_invc_crncy', 	type : 'float'},
		{name : 'tot_srv_amt_invc_crncy', 	type : 'float'},
		{name : 'apprv_srv_amt_invc_crncy', 	type : 'float'},
		{name : 'apprv_tax_amt_invc_crncy', 	type : 'float'},
		{name : 'apprv_tot_srv_amt_invc_crncy', 	type : 'float'},
		{name : 'sys_crncy_exchng_rate', 	type : 'float'},
		{name : 'pty_crncy_exchng_rate', 	type : 'float'},
		{name : 'cmpny_crncy_exchng_rate', 	type : 'float'},
		{name : 'man_rate_flg', 	 type : 'string'},
		{name : 'spl_agmt_no', type : 'string'},
		{name : 'comments', type : 'string'}
	]
});

Ext.define('supplierRateVerificationDTO',{
	extend:'Ext.data.Model',
	fields : [{
		name : 'contractId',
		type : 'string'
	},{
		name : 'customer',
		type : 'string'
	},{
		name : 'transportMode',
		type : 'string'
	},{
		name : 'transportMode',
		type : 'string'
	},{
		name : 'rateTier',
		type : 'string'
	},{
		name : 'origin',
		type : 'string'
	},{
		name : 'destination',
		type : 'string'
	},{
		name : 'conveyanceType',
		type : 'string'
	},{
		name : 'makeCode',
		type : 'string'
	},{
		name : 'model',
		type : 'string'
	},{
		name : 'modelYear',
		type : 'integer'
	},{
		name : 'modelGroupCode',
		type : 'string'
	},{
		name : 'partCode',
		type : 'string'
	},{
		name : 'originCity',
		type : 'string'
	},{
		name : 'originState',
		type : 'string'
	},{
		name : 'destinationCity',
		type : 'string'
	},{
		name : 'destinationState',
		type : 'string'
	},{
		name : 'originalOrigin',
		type : 'string'
	},{
		name : 'finalDestination',
		type : 'string'
	},{
		name : 'consolidationType',
		type : 'string'
	},{
		name : 'notChargeable',
		type : 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}		
	},{
		name : 'program',
		type : 'string'
	},{
		name : 'index',
		type : 'string'
	},{
		name : 'eventDate',
		type : 'string'
	},{
		name : 'uom',
		type : 'string'
	},{
		name : 'fixedRate',
		type : 'float'
	},{
		name : 'tariffCode',
		type : 'string'
	},{
		name : 'tariffUnitRate',
		type : 'float'
	},{
		name : 'luInd',
		type : 'string'
	},{
		name : 'tariffCurrencyCode',
		type : 'string'
	},{
		name : 'composite',
		type : 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}		
	},{
		name : 'nonTaxable',
		type : 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}		
	},{
		name : 'priority',
		type : 'string'
	},{
		name : 'cargoType',
		type : 'string'
	},{
		name : 'storageType',
		type : 'string'
	},{
		name : 'modelLine',
		type : 'string'
	},
	{
	   name:'originCountry',
	   type:'string'
	},
	{
		name:'destinationCountry',
		type:'string'
	}
	]
});

Ext.define('suplrContractIdLov',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'contractId'
		},
		{
		  name:'supplrCd'
		},
		{
			name:'validFromDate'
		},
		{
			name:'validToDate'
		},
		{
			name:'remarks'
		}
		]
});

Ext.define('SupplierRatescontractsGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCd',
		type:'string'
	},{
		name:'intcontractId',
		type:'string'
	},{
		name:'contractId',
		type:'string',
		mandatory:true
	},{
		name:'supplier',
		type:'string',
		mandatory:true	
	},{
		name:'supplierName',
		type:'string'
	},{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},{
		name:'remark',
		type:'string'
	},{
		name:'trnsType',
		type:'string'
	},{
		name:'srvEffeDtEnbFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'consolFuelChrgFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{	
		name : 'version',
		type : 'integer'	
	}
	]
,
	associations :[{
	   	type:'hasMany',
	   	model:'supplierRatesFuelSurChrgGrid', 
	   	name: 'fuelSurChrgChrgDtls'
      }, {
    	   	type:'hasMany',
      	   	model:'supplierRatesMinLoad', 
      	   	name: 'minloadDtls'
        },{
        	type:'hasMany',
      	   	model:'supplierRatesAgreedMilage', 
      	   	name: 'agreedMilageDtls'        	
        },
      {
  	   	type:'hasMany',
  	   	model:'supplierRatesChildGridId', 
  	   	name: 'childGridDtls'
    }
        ]
	
	
});
Ext.define('supplierRatesFuelSurChrgGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intcontractId'
	},{
			name:'contractId'
	},{
		name:'srvCode',
		mandatory:true
	},{
		name:'customer'
	},{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'origin'
	},{
		name:'destination'
	},{
		name:'orgCity'
	},{
		name:'orgStateProv'
	},{
		name:'orgCntry'
	},{
		name:'destCity'
	},{
		name:'destStateProv'
	},{
		name:'destCntry'
	},{
		name:'modelGrp'	
	},{
		name:'consoldtinType'
	},{
		name:'notChrgble',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'notTaxable',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'program'
	},{
		name:'uomCode'
	},{
		name:'currencyCode'
	},{
		name:'index'
	},{
		name:'eventdate'
	},{
		name:'priority'
	},{
		name:'seqNo',
		type:'integer'
	},{
		name:'trnsType'
	},{
		name:'cargoType'
	},{
		name:'storageType'
	},{
		name:'modelLine'
	}]
/*,
	belongsTo: 'SupplierRatescontractsGrid'*/
});
Ext.define('supplierRatesChildGridId',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intcontractId'
	},{
			name:'contractId'
	},{
		name:'srvCode',
		mandatory:true
	},{
		name:'customer'
	},{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'transprtMode'
	},{
		name:'rateTier'
	},{
		name:'origin'
	},{
		name:'destination'
	},{
		name:'conveynceType'
	},{
		name:'makeCd'
	},{
		name:'modelcd'
	},{
		name:'modelYear'
	},{
		name:'modelGrp'
	},{
		name:'partId'
	},{
		name:'orgCity'
	},{
		name:'orgStateProv'
	},{
		name:'orgCntry'
	},{
		name:'destCity'
	},{
		name:'destStateProv'
	},{
		name:'destCntry'
	},{
		name:'orgOrigin'	
	},{
		name:'finalDest'	
	},{
		name:'consoldtinType'
	},{
		name:'notChrgble',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}	
	},{
		name:'factorValue'
	},{
		name:'factorType'
	},{
		name:'factorRate'
	},{
		name:'uom'
//			,
//		mandatory:true
	},{
		name:'fixedRate'
	},{
		name:'tariffCd'
	},{
		name:'tariffUnitRate'
	},{
		name:'luInd'
	},{
		name:'tariffCrncyCd'
	},{
		name:'composite',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}	
	},{
		name:'notTaxable',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}	
	},{
		name:'priority'
	},{
		name:'seqNo',
		type:'integer'
	},{
		name:'trnsType'
	},{
		name:'cargoType'
	},{
		name:'storageType'
	},{
		name:'modelLine'
	}],
	hasMany: {
	       model:'supplierRatesComposite', 
	       name: 'compositeDtls'
	    }
/*,
	belongsTo: 'SupplierRatescontractsGrid'*/
});
Ext.define('fuelSrChrgPrgrmCdLov',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'progName'
		},
		{
		  name:'progCode'
		},
		{
			name:'uomCode'
		},
		{
			name:'currencyCode'
		},
		{
			name:'chargeMethod'
		}
		]
});



Ext.define('SupplierReconcileSetupQueryDTO',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'intReconcileNo',
	          type:'string'
	        },
	        
			
			{
	          name:'supplierCd',
	          type:'string'
	        },
			{
	          name:'srvType',
	          mandatory: true,
	          type:'string'
	        },
			{
	          name:'srvCd',
	          mandatory: true,
	          type:'string'
	        },
			{
	          name:'cmpnyCd',
	          type:'string'
	        },
 	        {
		     name : 'status',
		    type : 'string'
	         },
	         {
			    name : 'transType',
			    type : 'string'
		         }

	    
	        
	       ],
		   
		   associations :[{
	   	type:'hasMany',
	   	model:'SpplrReconileSetupTolerenceCriteriaDto', 
	   	name: 'toleranceList'
      },
      {
  	   	type:'hasMany',
  	   	model:'SpplrReconileSetupMatchCriteriaDtls', 
  	   	name: 'matchingCriteriaList'
        }]
});


Ext.define('SpplrReconileSetupTolerenceCriteriaDto',{
	extend:'Ext.data.Model',
	fields:[
 	         {
		name : 'intReconcileNo',
		type : 'string'
	}, {
		name : 'srvType',
		type : 'string'
	}, {
		name : 'srvCd',
		type : 'string'
	},
	{
		name : 'crncyCd',
		mandatory: true,
		type : 'string'
	}, {
		name : 'fmRange',
		mandatory: true,
		type : 'float'
	}, {
		name : 'toRange',
		mandatory: true,
		type : 'float'
	},
	{
		name : 'status',
		type : 'string'
	},
	{
	    name : 'cmpnyCd',
		type : 'string'
    },
   	{
    	name : 'transType',
    	type : 'string'
    },
    {
    	name:'version',
    	type:'integer'
    }
	       ],
		    belongsTo: 'SupplierReconcileSetupQueryDTO'
});

Ext.define('SpplrReconileSetupMatchCriteriaDtls',{
	extend:'Ext.data.Model',
	fields:[
 	        {
		name : 'intReconcileNo',
		type : 'string'
	}, {
		name : 'srvType',
		type : 'string'
	}, {
		name : 'srvCd',
		type : 'string'
	},

	{
		name : 'recPriority',
		mandatory: true,
		type : 'string'
	}, {
		name : 'unitId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'originLocation',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'destination',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'shippingReference',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'eventLoadRef',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'conveyanceId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'partId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minUnitId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minOriginLocation',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	
	, {
		name : 'minDestination',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	, {
		name : 'minShippingReference',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	, {
		name : 'minEventLoadRef',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	, {
		name : 'minConveyanceId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	, {
		name : 'minPartId',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		  name:'status',
		  type:'string'
	},
 	{
		name : 'cmpnyCd',
		type : 'string'
	},
	{
		name : 'transType',
		type : 'string'
	},
	{
		name:'workOrder',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'model',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'consolidationId',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor	
	},
	{
		name:'profitLoss',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'minprofitLoss',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'minconsolidationId',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'minmodel',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'minworkOrder',
		type:'bool',
		convert:Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name:'version',
		type:'integer'
	}
    ],
    belongsTo: 'SupplierReconcileSetupQueryDTO'
		   
});

Ext.define('CstmrApplcAdviceGP',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'cstmr_cd',
		  type:'string'
		},
		  {
			  name:'cstmrNm',
			  type:'string'
			},
		{
			name:'debtorParty',
			type :'string'
		},		
		{
			name:'invc_no',
			type :'string'
		},
		{
			name:'invc_crdt_dttm',
			//type:'string'
			type:'date',
			dateFormat:'Y-m-d H:i:s'
		},
		{
			name:'invc_crdt_note_ind',
			type:'string'
		},
		{
			name:'tot_invc_amt_local_crncy',
			type:'float'
		},
		{
			name:'local_crncy_cd',
			type:'string'
		},
		{
			name:'prf_invc_no',
			type:'integer'
		},
		{
			name:'cnsldt_flg',
			type:'string'
		},{
			name:'cstmr_ack_rcvd_flg',
			type:'string'
		},{
			name:'version',
			type:'integer'
		}
		]
});


Ext.define('supplierMasterDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		mandatory:true,
    	type:'string'
	},{
		name:'supplierName',
    	type:'string'
	},{
		name:'defaultCrncy',
		mandatory:true,
    	type:'string'
	},{
		name:'taxRefNum',
    	type:'string'
	},{
		name:'address1',
    	type:'string'
	},{
		name:'address2',
    	type:'string'
	},{
		name:'city',
    	type:'string'
	},{
		name:'state',
    	type:'string'
	},{
		name:'country',
    	type:'string'
	},{
		name:'postalCode',
    	type:'string'
	},{
		name:'telephone',
    	type:'string'
	},{
		name:'faxNum',
    	type:'string'
	},{
		name:'mobileNum',
    	type:'string'
	},{
		name:'emailId',
    	type:'string'
	},{
		name:'contactPrsn',
    	type:'string'
	},{
		name:'website',
    	type:'string'
	},{
		name:'financeId',
    	type:'string'
	},{
		name:'calTaxIfNotSntInMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'sendAPMsgToCoda',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'calTaxIfNotSntInExcel',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'ignoreInvDueDtFrmMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'shipmentDt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'partialPaymnt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'completionDt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'creatVrnceEvnt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'autoAprv',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'ratingDestination',
		type:'bool',
		convert:function(v)
		{
			return (v === "Y" || v === true || v === "") ? true : false;
		}
	},
	{
		name:'remark1',
    	type:'string'
	},{
		name:'remark2',
    	type:'string'
	},{
		name:'transType',
    	type:'string'
	}],
	associations :[{
	   	type:'hasMany',
	   	model:'supplierMasterPaymentTerm', 
	   	name: 'paymntTermGrid'
      },{
    	type:'hasMany',
    	model:'supplierMasterStatusDateCntrctIden', 
    	name: 'statusDateForIdentGrid'	    	  
      },{
  		type:'hasMany',
		model:'supplierMasterAutomaticInvoiceSetup', 
		name: 'automaticInvcSetupGrid'	    	  
      },{
  		type:'hasMany',
		model:'supplierMasterRateRoundingCriteriaForRate', 
		name: 'roundingCriteriaForRateGrid'	    	  
      },
      {
    	  type:'hasMany',
    	  model:'supplierMasterRateRoundingCriteriaForDistance',
    	  name:'roundingCriteriaForDistance'
      }
      ]	
	
});


Ext.define('supplierMasterPaymentTerm',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
	    type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceCode',
		type:'string'

	},{
		name:'paymentTrmDays',
		type:'integer'
	
	},{
		name:'transType',
		type:'string'
	},
	{
		name:'srvceType',
		type:'string'
	}],
	belongsTo: 'supplierMasterDetails'
});


Ext.define('supplierMasterStatusDateCntrctIden',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
	    type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},
	{
		name:'srvcCode',
		type:'string'

	},{
		name:'origin',
		type:'string'
	
	},
	{
		name:'destination',
		type:'string'
	
	},
	{
		name:'statusDate',
		type:'string',
		mandatory:true
	},
	{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'supplierMasterDetails'
});



Ext.define('supplierMasterAutomaticInvoiceSetup',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
	    type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'

	},{
		name:'triggerStatus',
		type:'string'
	
	},
	{
		name:'reconsldInvFlg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},
	{
		name:'srvceType',
		type:'string'
	},
	{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'supplierMasterDetails'
});

Ext.define('supplierMasterRateRoundingCriteriaForRate',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
		
	},{
		name:'currency',
		type:'string',
		mandatory:true	
	},{
		name:'roundingCriteria',
		type:'string',
		mandatory:true
	},{
		name:'value',
		type:'float',
		mandatory:true
	},{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'supplierMasterDetails'
});

Ext.define('supplierMasterRateRoundingCriteriaForDistance',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'uom',
		type:'string',
		mandatory:true
	},{
		name:'roundingCriteria',
		type:'string',
		mandatory:true
	},{
		name:'value',
		type:'float',
		useNull:true,
		mandatory:true
	},
	{
		name:'minValue',
		useNull:true,
		type:'float'
	},
	{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'supplierMasterDetails'
});

Ext.define('partCdLov',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'partDesc'
		},
		{
		  name:'partCode'
		}
		]
});

Ext.define('tariffCdLov',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'tarifffCode'
		},
		{
		  name:'tariffDesc'
		},
		{
		  name:'tariffCurncyCd'
		}
		
		]
});

Ext.define('supplierRatesComposite',{
	extend:'Ext.data.Model',
	fields:[
	    {
		name:'intcontractId'
	},{
		name:'seqNo'
	},{
		  name:'srvCode',
		  mandatory:true
		},
		{
		  name:'srvDesc'
		},
		{
		  name:'tariffCd'
		},
		{
		  name:'tariffCrncyCd'
		}, 
		{
		  name:'tariffUnitRate'
		},
		{
		  name:'luInd'
		},
		{
		  name:'profLossCntr'
		},{
			name:'trnsType',
			type:'string'
		}
		],
		belongsTo: 'supplierRatesChildGridId'
});

Ext.define('CstmrApplAdvcPGModel',{
	extend:'Ext.data.Model',
	fields:[
	    {
	    	name:'cstmr_item_ack_rcvd_flg',	    	      
	    	type:'string'
	    },
	    {
	    	name:'cstmr_evnt_ack_rcvd_flg',
	    	type:'string'
	    },
	    {
	    	name:'int_rqst_no',
	    	type:'string'
	    },
	    {
	    	name:'seq_no',
	    	type:'string'
	    },
	    {
	    	name:'cstmr_ratng_seq_no',
	    	type:'string'
	    },
	    {
	    	name:'invc_no',
	    	type:'string'
	    },
	    {
	    	name:'invc_crdt_note_ind',
	    	type:'string'
	    },
		{
			name:'prf_invc_no',
			type:'integer'
		},
		{
			name:'item_no',
			type:'string'
		},
		{
			name:'summ_id',
			type:'integer'
		},
		{
			name:'srv_amt_inv_crncy',
			type:'string'
		},
		{
			name:'model_year',
			type:'string'
		},
		{
			name:'min_ld_cnt',
			type:'string'
		},
		{
			name:'dist_qty',
			type:'string'
		},
		{
			name:'rating_dist_qty',
			type:'string'
		},
		{
			name:'srv_cd',
			type:'string'
		},
		{
			name:'srv_type',
			type:'string'
		},
		{
			name:'srv_descr',
			type:'string'
		},
		{
			name:'unit_id',
			type:'string'
		},
		{
			name:'shipng_ref_no',
			type:'string'
		},
		{
			name:'trnspt_cd',
			type:'string'
		},
		{
			name:'trnspt_mode',
			type:'string'
		},
		{
			name:'origin_cd',
			type:'string'
		},
		{
			name:'dest_cd',
			type:'string'
		},
		{
			name:'dest_city_nm',
			type:'string'
		},
		{
			name:'ratng_dest_cd',
			type:'string'
		},
		{
			name:'make_cd',
			type:'string'
		},
		{
			name:'model_cd',
			type:'string'
		},
		{
			name:'rate_tier_cd',
			type:'string'
		},
		{
			name:'ld_ref_no',
			type:'string'
		},
		{
			name:'wk_ord_no',
			type:'string'
		},
		{
			name:'dist_uom_cd',
			type:'string'
		},
		{
			name:'ratng_dist_uom_cd',
			type:'string'
		},
		{
			name:'conveyance_id',
			type:'string'
		},
		{
			name:'conveyance_type_cd',
			type:'string'
		},
		{
			name:'origin_city_nm',
			type:'string'
		},
		{
			name:'origin_state_cd',
			type:'string'
		},
		{
			name:'dest_state_cd',
			type:'string'
		},
		{
			name:'part_cd',
			type:'string'
		},
		{
			name:'cost_cntr_cd',
			type:'string'
		},
		{
			name:'cstmr_sales_rgn',
			type:'string'
		},
		{
			name:'shpmnt_type_cd',
			type:'string'
		},
		{
			name:'ord_type_cd',
			type:'string'
		},
		{
			name:'abnrmlmvtype_cd',
			type:'string'
		},
		{
			name:'supplier_cd',
			type:'string'
		},
		{
			name:'dealer_cd',
			type:'string'
		},
		{
			name:'original_origin_cd',
			type:'string'
		},
		{
			name:'final_dest_cd',
			type:'string'
		},
		{
			name:'fm_dttm',
			type:'string'
		},
		{
			name:'to_dttm',
			type:'string'
		},
		{
			name:'rqst_dttm',
			type:'string'
		},
		{
			name:'model_grp_cd',
			type:'string'
		},
		{
			name:'conveyance_nm',
			type:'string'
		},
		{
			name:'consolidation_id',
			type:'string'
		},
		{
			name:'consolidation_type_cd',
			type:'string'
		},
		{
			name:'srv_grp_cd',
			type:'string'
		},
		{
			name:'origin_addr_1',
			type:'string'
		},
		{
			name:'origin_addr_2',
			type:'string'
		},
		{
			name:'origin_po_box',
			type:'string'
		},
		{
			name:'dest_addr_1',
			type:'string'
		},
		{
			name:'dest_addr_2',
			type:'string'
		},
		{
			name:'dest_po_box',
			type:'string'
		},
		{
			name:'cmpny_cd',
			type:'string'
		},
		{
			name:'cstmr_cd',
			type:'string'
		},{
			name:'version',
			type:'integer'
		}
		],
		hasMany: {
		       model:'CstmrApplAdvcPGModel', 
		       name: 'cstmrApplAdvcChildGridResult'
		    }
});


Ext.define('ApplicationAdviceOnHoldModel',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'company',
		  type:'string'
		},		
		{
			name:'customer',
			type :'string'
		},		
		{
			name:'debtorParty',
			type :'string'
		},
		{
			name:'invoiceNumber',
			type :'string'
		},
		{
			name:'invoiceDate',
			type : 'string',
			/*convert : function(v) {
				if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
					v = new Date(v.split(' ')[0]);
				}
				return v;
			},*/
			dateFormat : 'd/m/Y'
				
		},
		{
			name:'dueDate',
			type : 'string',
			/*convert : function(v) {
				if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
					v = new Date(v.split(' ')[0]);
				}
				return v;
			},*/
			dateFormat : 'd/m/Y'
		},
		{
			name:'creditNoteIndicator',
			type :'string'
		},
		{
			name:'documentType',
			type :'string'
		},
		{
			name:'currency',
			type :'string'
		},
		
		{
			name:'prfInvcNo',
			type :'integer'
		},
		{
			name:'itemNo',
			type :'integer'
		},
		{
			name:'summId',
			type :'integer'
		},
		{
			name:'serviceType',
			type :'string'
		},
		{
			name:'serviceCode',
			type :'string'
		},
		{
			name:'serviceGroupCode',
			type :'string'
		},
		{
			name:'unitId',
			type :'string'
		},
		{
			name:'loadRefNo',
			type :'string'
		},
		{
			name:'conveyanceId',
			type :'string'
		},
		{
			name:'conveyanceType',
			type :'string'
		},
		{
			name:'conveyanceName',
			type :'string'
		},
		{
			name:'shippingRefNo',
			type :'string'
		},
		{
			name:'transportCode',
			type :'string'
		},
		{
			name:'makeCode',
			type :'string'
		},
		{
			name:'modelCode',
			type :'string'
		},
		{
			name:'modelGroupCode',
			type :'string'
		},
		{
			name:'modelYear',
			type :'integer'
		},
		{
			name:'transportMode',
			type :'string'
		},
		{
			name:'rateTierCode',
			type :'string'
		},
		{
			name:'workOrderNo',
			type :'string'
		},
		{
			name:'partId',
			type :'string'
		},
		{
			name:'originCode',
			type :'string'
		},
		{
			name:'originAddress1',
			type :'string'
		},
		{
			name:'originAddress2',
			type :'string'
		},
		{
			name:'originCity',
			type :'string'
		},
		{
			name:'originState',
			type :'string'
		},
		{
			name:'originPOBox',
			type :'string'
		},
		{
			name:'finalDestination',
			type :'string'
		},
		{
			name:'ratingDestination',
			type :'string'
		},
		{
			name:'itemDescription',
			type :'string'
		},
		{
			name:'profitLossCenter',
			type :'string'
		},
		{
			name:'customerSalesRegion',
			type :'string'
		},{
			name:'shipmentType',
			type :'string'
		},
		
		{
			name:'orderType',
			type :'string'
		},
		{
			name:'abnormalMoveType',
			type :'string'
		},
		{
			name:'dealerCode',
			type :'string'
		},
		{
			name:'supplier',
			type :'string'
		},
		{
			name:'consolidationId',
			type :'string'
		},
		{
			name:'consolidationType',
			type :'string'
		},
		{
			name:'destinationCode',
			type :'string'
		},
		{
			name:'destinationAddress1',
			type :'string'
		},
		{
			name:'destinationAddress2',
			type :'string'
		},
		{
			name:'destinationCity',
			type :'string'
		},
		{
			name:'destinationState',
			type :'string'
		},
		{
			name:'destinationPOBox',
			type :'string'
		},
		{
			name:'tenderRequestDate',
			type :'string',
			/*convert : function(v) {
				if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
					v = new Date(v.split(' ')[0]);
				}
				return v;
			},*/
			dateFormat : 'd/m/Y'
		},
		{
			name:'shipmentDate',
			type :'string',
			/*convert : function(v) {
				if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
					v = new Date(v.split(' ')[0]);
				}
				return v;
			},*/
			dateFormat : 'd/m/Y'
		},
		{
			name:'deliveryDate',
			type :'string',
			/*convert : function(v) {
				if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
					v = new Date(v.split(' ')[0]);
				}
				return v;
			},*/
			dateFormat : 'd/m/Y'
//			type:'date',
//			dateFormat:'d/m/Y'
		},
		{
			name:'originalOrigin',
			type :'string'
		},
		{
			name:'technicalDescription',
			type :'string'
		},
		{
			name:'invoiceAmount',
			type :'float'
		}]
});


Ext.define('supplierInvoiceEntryGPModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd',
		type : 'string'
	},{
		name : 'prfInvcNum',
		type : 'string'
	},
	 {
		name:'supplier',
		type:'string'	
	},
	 {
		name : 'supplierName',
		type : 'string'
	},{

		name : 'invcNum',
		type : 'string'
	}, {
		name : 'invcDate',		
		type:'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'invcDueDate',
		type:'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'refInvcNum',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	//dateFormat:'d/m/Y'
	}, {
		name : 'statusDscr',
		type : 'string'
	},{
		name : 'docType',
		type : 'string'
	},{
		name : 'party',
		type : 'string'
	}, {
		name : 'partyName',
		type : 'string'
	}, {
		name : 'addr1',
		type : 'string'
	}, {
		name : 'addr2',
		type : 'string'
	}, {
		name : 'city',
		type : 'string'
	}, {
		name : 'state',
		type : 'string'
	}, {
		name : 'cntry',
		type : 'string'
	}, {
		name : 'zipPostalCd',
		type : 'string'
	}, {
		name : 'proId',
		type : 'string'
	}, {
		name : 'proDate',
		type : 'string'
	}, 
{
		name : 'totInvcAmtInvcCrncy',
		type : 'float'
	},

{
		name : 'totInvcAmtSysCrncy',
		type : 'float'
	},
{
		name : 'totInvcAmtPtyCrncy',
		type : 'float'
	},
{
		name : 'totInvcAmtCmpnyCrncy',
		type : 'float'
	},
{
		name : 'supplierTemplateCd',
		type : 'string'
	},{
		name : 'transType',
		type : 'string'	
	 
	},
{
		name : 'defaultCompanyCurrencyCd',
		type : 'string'
	} ,
{
		name : 'defaultSysCurrencyCd',
		type : 'string'
	} ,
{
		name : 'defaultPtyCurrencyCd',
		type : 'string'
	} ,
{
		name : 'prfStatusCd',
		type : 'string'
	} ,
{
		name : 'recalcInvoiceDttmFlg',
		type : 'string'
	},{
		name : 'transType',
		type : 'string'		
	},{
		name : 'totSrvcAmnt',
		type : 'string'		
	},{
		name : 'totTaxAmnt',
		type : 'string'		
	},{
		name : 'totAmnt',
		type : 'string'		
	},{
		name : 'srvAmntInvcCurncy',
		type : 'float'		
	},{
		name : 'refCsnrCd',
		type : 'string'
		//mapping:'detail.a1'
	} ,
	{
		name : 'csnrName',
		type : 'string'
	},{
		name : 'csnrAdd1',
		type : 'string'		
	},{
		name : 'csnrAdd2',
		type : 'string'		
	},{
		name : 'csnrCity',
		type : 'string'		
	} ,
	{
		name : 'csnrState',
		type : 'string'
	} ,
	{
		name : 'csnrCountry',
		type : 'string'
	},{
		name : 'refCsneCd',
		type : 'string'		
	},{
		name : 'csneName',
		type : 'string'		
	},{
		name : 'csneAdd1',
		type : 'string'		
	},
	{
		name : 'csneAdd2',
		type : 'string'
	} ,
	{
		name : 'csneCity',
		type : 'string'
	},{
		name : 'csneState',
		type : 'string'		
	},{
		name : 'csneCountry',
		type : 'string'		
	},{
		name : 'companyAdd1',
		type : 'string'		
	},
	{
		name : 'companyAdd2',
		type : 'string'
	},{
		name : 'companyCity',
		type : 'string'		
	},{
		name : 'companyState',
		type : 'string'		
	},{
		name : 'companyCountry',
		type : 'string'		
	},{
		name : 'queryType',
		type : 'string'		
	},{
		name : 'oldPrfInvcNum',
		type : 'integer'		
	},{
		name : 'additionalUpdate',
		type : 'integer'		
	},{
		name : 'contactCd',
		type : 'string'		
	},{
		name : 'contactName',
		type : 'string'		
	},{
		name : 'communicationNbr',
		type : 'string'		
	},{
		name : 'contactInquiry_ref',
		type : 'string'		
	},{
		name : 'version',
		type : 'integer'		
	}],
	hasMany: [{
	    model:'supplierInvoiceEntryParentModel', 
	    name: 'dtlsList'
	 },
	 {
	    model:'railRoutingGridModel', 
	    name: 'additionalRoutingdtls'
	 }]
});


Ext.define('railRoutingGridModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'routingSeqCd',
		type : 'string'
	},{
		name : 'routingPtyCd',
		type : 'string'
	}, {
		name : 'routingCityName',
		type : 'string'
	}]
});



Ext.define('supplierInvoiceEntryParentModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'serviceCode',
		type : 'string'
	},{
		name : 'unitId',
		type : 'string'
	},
	 {
		name:'shippingReference',
		type:'string'	
	},{
		name : 'srvDesc',
		type : 'string'
	},
	 {
		name : 'transportCode',
		type : 'string'
	},{

		name : 'originCode',
		type : 'string'
	},
	{
		name:'supplierCode',
		type:'string'
	}, {
		name : 'invcItemStatus',
		type : 'string'
	},{

		name : 'paymentInvoiceNumber',
		type : 'string'
	},{
		name : 'docType',
		type : 'string'
	},{
		name : 'resultParam',
		type : 'string'
	},{
		name : 'trnsptMode',
		type : 'string'
	},{
		name : 'originalOriginCd',
		type : 'string'
	},{
		name : 'invcItemStatus'
	},{
		name : 'finalDestinationCd',
		type : 'string'
	},{
		name : 'srvType',
		type : 'string'
	},{
		name : 'sysCurrencyExchangeRate',
		type : 'float'
	},{
		name : 'ptyCurrencyExchangeRate',
		type : 'float'
	},{
		name : 'totalServiceAmount',
		type : 'float'
	},{
		name:'srvAmtPtyCrncy',
		type:'string'
	},{
		name:'srvAmtSysCrncy',
		type:'string'
	},{
		name:'srvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'taxAmtInvcCrncy',
		type:'string'
	},{
		name:'taxAmtPtyCrncy',
		type:'string'
	},{
		name:'taxAmtSysCrncy',
		type:'string'
	},{
		name:'taxAmtCmpnyCrncy',
		type:'string'
	},{
		name : 'totSrvAmtPtyCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtSysCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtCmpnyCrncy',
		type : 'string'
	},{
		name : 'cmpnyCode',
		type : 'string'
	},{
		name : 'invcDate',
		type : 'string'
	},{
		name : 'sqlMsg',
		type : 'string'
	},{
		name : 'cmpnyCurrencyExchangeRate',
		type : 'float'
	},
	{
		  name:'currency',
		  type : 'string'
		}, {
		name : 'destinationCode',
		type:'string'
	}, {
		name : 'tenderDate',
		type:'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	}, {
		name : 'shipmentDate',
		type:'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	}, {
		name : 'deliveryDate',
		type:'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	}, {
		name : 'quantity',
		type : 'string'
	}, {
		name : 'uom',
		type : 'string'	
	}, {
		name : 'invcDueDate',
		type:'string'
	}, {
		name : 'basis',
		type : 'string'	
	}, {
		name : 'rate',
		type : 'string'	
	}, {
		name : 'fixedTarrifUnitRate',
		type : 'string'	
	}, {
		name : 'serviceAmount',
		type : 'string'	
	},{
		name : 'transType',
		type : 'string'	
	}, {
		name : 'ratingDestination',
		type : 'string'	
	}, {
		name : 'make',
		type : 'string'	
	}, {
		name : 'model',
		type : 'string'	
	}, {
		name : 'year',
		type : 'string'	
	},
	{
		name:'remark',
		type:'string'
	}, {
		name : 'destinationCity',
		type:'string'
	}, {
		name : 'distanceToDestinationValue',
		type:'string'
	}, {
		name : 'distanceToDestinationUom',
		type:'string'
	}, {
		name : 'distanceToRatingDestinationValue',
		type:'string'
	}, {
		name : 'distanceToRatingDestinationUom',
		type:'string'
	}, {
		name : 'minimumNumber',
		type:'string'
	}, {
		name : 'loadReference',
		type:'string'
	}, {
		name : 'rateTier',
		type:'string'
	},{
		name : 'prfInvcNum',
		type : 'string'
	},{
		name : 'itemNumber',
		type : 'string'
	},{
		name : 'sumId',
		type : 'string'
	},{
		name : 'invoiceItemStatus',
		type : 'string'
	},{
		name : 'serviceType',
		type : 'string'
	},{
		name : 'fuelSurchargeFlg',
		type : 'string'
	},{
		name : 'transportMode',
		type : 'string'
	},{
		name : 'invoiceCurrencyCd',
		type : 'string'
	},{
		name : 'totSrvcAmtInvcCrncy',
		type : 'string'
	},{
		name : 'totSrvcAmtSysCrncy',
		type : 'float'
	},{
		name : 'totSrvcAmtPtyCrncy',
		type : 'float'
	},{
		name : 'totSrvcAmtCmpnyCrncy',
		type : 'float'
	},{
		name : 'srvcAmtSysCrncy',
		type : 'float'
	},{
		name : 'srvcAmtPtyCrncy',
		type : 'float'
	},{
		name : 'srvcAmtCmpnyCrncy',
		type : 'float'
	},{
		name : 'aprvSrvcAmtInvcCrncy',
		type : 'float'
	},{
		name : 'aprvTaxAmtInvcCrncy',
		type : 'float'
	},{
		name : 'aprvTotSrvcAmtInvcCrncy',
		type : 'float'
	},{
		name : 'sysCrncyExchngRate',
		type : 'string'
	},{
		name : 'ptyCrncyExchngRate',
		type : 'string'
	},{
		name : 'cmpnyCrncyExchngRate',
		type : 'string'
	},{
		name : 'railCar',
		type : 'string'
	},{
		name : 'conveyanceType',
		type : 'string'
	},{
		name : 'originCity',
		type : 'string'
	},{
		name : 'originState',
		type : 'string'
	},{
		name : 'destinationState',
		type : 'string'
	},{
		name : 'waybillNumber',
		type : 'string'
	},{
		name : 'perLoad',
		type : 'boolean'
	},{
		name : 'voyageNumber',
		type : 'string'
	},{
		name : 'vesselName',
		type : 'string'
	},{
		name : 'consolidationId',
		type : 'string'
	},{
		name : 'consolidationType',
		type : 'string'
	},{
		name : 'location',
		type : 'string'
	},{
		name : 'workOrder',
		type : 'string'
	},{
		name : 'completionDate',
		type : 'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	},{
		name : 'partId',
		type : 'string'
	},{
		name : 'customer',
		type : 'string'
	},{
		name : 'profitLossCenter',
		type : 'string'
	},{
		name : 'quantity1',
		type : 'string'
	},{
		name : 'uom1',
		type : 'string'
	},{
		name : 'quantity2',
		type : 'string'
	},{
		name : 'uom2',
		type : 'string'
	},{
		name : 'serviceDate',
		type : 'string'
	},{
		name : 'itemDescription',
		type : 'string'
	},{
		name : 'totTaxAmtPerLineItem',
		type : 'float'
	},{
		name:'invcItemSts',
		type:'string'
	},{
		name:'validated',
		type:'bool'
	},
	 {
		name : 'sumTaxAmtInvcCrncy',
		type : 'string'
	},
	 {
		name : 'originCountry',
		type : 'string'
	},
	 {
		name : 'missMatchReasonCode',
		type : 'string'
	},
	 {
		name : 'supplier',
		type : 'string'
	},{
		name : 'productionOrder',
		type : 'string'
		
	},{
		name : 'totSrvcAmt',
		type : 'float'
	},{
		name : 'totTaxAmt',
		type : 'float'
	}],
	hasMany: {
	    model:'supplierInvoiceEntryResultGridModel', 
	    name: 'taxDetails'
	 }
});



Ext.define('supplierInvoiceEntryResultGridModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'summId',
		type : 'string'
	},{
		name : 'revenCd',
		type : 'string'
	},{
		name : 'costCd',
		type : 'string'
	}, {
		name : 'taxTyp',
		type : 'string'
	},{
		name : 'taxPercnt',
		type : 'float'
	},
	 {
		name:'srvcAmt',
		type : 'float'
	},
	 {
		name : 'taxAmt',
		type : 'float'
	},{
		name : 'calOnTaxTypeCd',
		type : 'string'
	},
	 {
		name:'calOnSrvcAmtFlg',
		type:'string'	
	},
	 {
		name : 'sumTaxAmtInvcCrncy',
		type : 'string'
	},
	 {
		name : 'invcCrncyCd',
		type : 'string'
	}
	]
});

Ext.define('supplierRateQueryServiceCodeDTONonOcean',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'company',
		  type:'string'
		},
		{
			  name:'contractId',
			  type:'string'
		},
		{
			name:'supplier',
			type :'string'
		},		
		{
			name:'supplierName',
			type :'string'
		},
		{
			name:'validFromDate',
			type:'string'
		},
		{
			name:'validToDate',
			type:'string'
		},
		{
			name:'serviceCode',
			type:'string'
		},
		{
			name:'customerCode',
			type:'string'
		},
		{
			name:'transMode',
			type:'string'
		},
		{
			name:'origin',
			type:'string'
		},
		{
			name:'destination',
			type:'string'
		},
		{
			name:'rateTier',
			type:'string'
		},
		{
			name:'conveyanceType',
			type:'string'
		},
		{
			name:'makeCode',
			type:'string'
		},
		{
			name:'modelCode',
			type:'string'
		},
		{
			name:'modelYear',
			type:'string'
		},
		{
			name:'modelGroupCode',
			type:'string'
		},
		{
			name:'partId',
			type:'string'
		},
		{
			name:'originLocationCity',
			type:'string'
		},
		{
			name:'originLocationState',
			type:'string'
		},{
			name:'destinationCity',
			type:'string'
		},{
			name:'destinationState',
			type:'string'
		},{
			name:'originalOrigin',
			type:'string'
		},{
			name:'finalDestination',
			type:'string'
		},{
			name:'consolidationType',
			type:'string'
		},{
			name:'factorValue',
			type:'string'
		},{
			name:'factorType',
			type:'string'
		},{
			name:'factorRate',
			type:'string'
		},{
			name:'program',
			type:'string'
		},{
			name:'index',
			type:'string'
		},{
			name:'eventDate',
			type:'string'
		},{
			name:'uom',
			type:'string'
		},{
			name:'fixedRate',
			type:'string'
		},{
			name:'tariffCode',
			type:'string'
		},{
			name:'tariffRate',
			type:'string'
		},{
			name:'luInd',
			type:'string'
		},{
			name:'tariffCurrencyCode',
			type:'string'
		},{
			name:'composite',
			type:'string'
		},{
			name:'notChargeable',
			type:'string'
		},{
			name:'nonTaxable',
			type:'string'
		},{
			name:'priority',
			type:'string'
		},{
			name:'cargoType',
			type:'string'
		},{
			name:'storageType',
			type:'string'
		},{
			name:'modelLineCd',
			type:'string'
		}
		]
});

Ext.define('supplierRatesMinLoad',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intcontractId'
	},{
			name:'contractId'
	},{
		  name:'conveyanceType'
		},
		{
		  name:'vinNo',
		  mandatory: true,
		  type : 'integer'
		},{
			name:'trnsType',
			type:'string'
		}
		]/*,
		belongsTo: 'SupplierRatescontractsGrid'*/
});

Ext.define('supplierRatesAgreedMilage',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intcontractId'
	},{
			name:'contractId'
	},{
		  name:'origin',
		  mandatory: true
		},
		{
		  name:'destination',
		  mandatory: true
		}, {
		  name:'distance',
		  mandatory: true
		},
		{
		  name:'uom',
		  mandatory: true
		},{
			name:'trnsType',
			type:'string'
		}
		]/*,
		belongsTo: 'SupplierRatescontractsGrid'*/

});

Ext.define('CustomerInvGenerateAccrualModal', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCode',
		type : 'string'
	},{
		name : 'serviceCode',
		type : 'string'
	},{
		name : 'serviceDescription',
		type : 'string'
	},
	 {
		name:'supplier',
		type:'string'	
	},
	 {
		name : 'customer',
		type : 'string'
	},
	 {
		name : 'unitId',
		type : 'string'
	},
	 {
		name : 'moveReference',
		type : 'string'
	},
	 {
		name : 'workOrder',
		type : 'string'
	},
	 {
		name : 'origin',
		type : 'string'
	},
	 {
		name : 'destination',
		type : 'string'
	},
	 {
		name : 'tenderDate',
		type : 'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	},
	 {
		name : 'shipmentDate',
		type : 'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	},
	 {
		name : 'deliveryDate',
		type : 'string'/*,
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},
		dateFormat:'Y/m/d'*/
	},
	 {
		name : 'intReqNo'
	},
	 {
		name : 'seqNo'
	},
	 {
		name : 'shipTypeCd'
	}]

});



Ext.define('ServiceGrpCdModel',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'code',
		  type : 'string'
		},
		{
		  name:'desc',
		  type : 'string'
		}, 
		{
		  name:'customer',
		  type : 'string'
		}]
});

Ext.define('CustInvcEntryConsolPG', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'itemNumber',
		type : 'integer'
	},{
		name : 'prfInvcNo',
		type : 'string'
	},{
		name : 'totSrvAmtInvcCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtPtyCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtSysCrncy',
		type : 'string'
	},{
		name : 'totSrvAmtCmpnyCrncy',
		type : 'string'
	},{
		name : 'summId',
		type : 'string'
	},{
		name : 'srvCode',
		type : 'string',
		mandatory:true
	},{
		name : 'srvType',
		type : 'string'
	},{
		name : 'srvDesc',
		type : 'string',
		mandatory:true
	},{
		name : 'srvcGrp',
		type : 'string',
		mandatory:true
	},{
		name : 'evntLdRef',
		type : 'string'
	},{
		name : 'convncId',
		type : 'string'
	},{
		name : 'trnsptMode',
		type : 'string'
	},{
		name : 'wrkOrder',
		type : 'string'
	},{
		name : 'orgnLoc',
		type : 'string'
	},{
		name : 'orgnAdd1',
		type : 'string'
	},{
		name : 'orgnAdd2',
		type : 'string'
	},{
		name : 'orgnLocCty',
		type : 'string'
	},{
		name : 'orgnLocStP',
		type : 'string'
	},{
		name : 'orgnCntryCd',
		type : 'string'
	},{
		name : 'orgnZipPostalCd',
		type : 'string'
	},{
		name : 'destCd',
		type : 'string'
	},{
		name : 'destAdd1',
		type : 'string'
	},{
		name : 'destAdd2',
		type : 'string'
	},{
		name : 'destCity',
		type : 'string'
	},{
		name : 'destStateProv',
		type : 'string'
	},{
		name : 'destCntryCd',
		type : 'string'
	},{
		name : 'destZipPostalCd',
		type : 'string'
	},{
		name : 'origOrg',
		type : 'string'
	},{
		name : 'finalDest',
		type : 'string'
	},{
		name : 'prftLossCent',
		type : 'string'
	},{
		name : 'suplrCd',
		type : 'string'
	},{
		name : 'consolId',
		type : 'string'
	},{
		name : 'uom1',
		type : 'string',
		mandatory:true	
	},{
		name : 'qntty1',
		type : 'string'
	},{
		name : 'uom2',
		type : 'string'
	},{
		name : 'qntty2',
		type : 'string'
	},{
		name : 'rtbsis',
		type : 'string'
	},{
		name : 'rate',
		type : 'float',
		mandatory : true
//			,
//		convert:function(v){
//			if(!Ext.isEmpty(v)){
//				v = Ext.util.Format.number(v,'0.00');
//			}
//			return v;
//		}
	},{
		name : 'srvcAmt',
		type : 'float',
		mandatory : true
			/*,
		convert:function(v){
			if(!Ext.isEmpty(v)){
				v = Ext.util.Format.number(v,'0.00');
			}
			return v;
		}*/
	},{
		name : 'oldSrvcAmt',
		type : 'String'
	},{
		name:'status',
		type:'string'
	},{
		name:'fuelSrchrgFlg',
		type:'string'
	},{
		name:'fixedTrfUnitRate',
		type:'string'
	},{
		name:'srvAmtPtyCrncy',
		type:'string'
	},{
		name:'srvAmtSysCrncy',
		type:'string'
	},{
		name:'srvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'taxAmtInvcCrncy',
		type:'string'
	},{
		name:'taxAmtPtyCrncy',
		type:'string'
	},{
		name:'taxAmtSysCrncy',
		type:'string'
	},{
		name:'taxAmtCmpnyCrncy',
		type:'string'
	},{
		name:'ptyCrncyExchngRate',
		type:'string'
	},{
		name:'sysCrncyExchngRate',
		type:'string'
	},{
		name:'cmpnyCrncyExchngRate',
		type:'string'
	},{
		name:'paidSrvAmtInvcCrncy',
		type:'string'
	},{
		name:'paidSrvAmtPtyCrncy',
		type:'string'
	},{
		name:'paidSrvAmtSysCrncy',
		type:'string'
	},{
		name:'paidSrvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'paidTaxAmtInvcCrncy',
		type:'string'
	},{
		name:'paidTaxAmtPtyCrncy',
		type:'string'
	},{
		name:'paidTaxAmtSysCrncy',
		type:'string'
	},{
		name:'paidTaxAmtCmpnyCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtInvcCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtPtyCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtSysCrncy',
		type:'string'
	},{
		name:'paidTotSrvAmtCmpnyCrncy',
		type:'string'
	},{
		name:'srvMsrType1',
		type:'string'
	},{
		name:'srvMsrType2',
		type:'string'
	},{
		name:'cstmrDeptNm',
		type:'string'
	},{
		name : 'totTaxAmtPerLineItem',
		type : 'float'
	},{
		name:'invcItemSts',
		type:'string'
	},{
		name:'validated',
		type:'bool'
	},{
		name:'convncNm',
		type:'string'
	},{
		name:'oldSummId',
		type:'string'
	}
	],
	associations :[{
	   	type:'hasMany',
	   	model:'CustInvcEntryCG', 
	   	name: 'customerInvoiceTaxDtlsDTO'
      },
      {
  	   	type:'hasMany',
  	   	model:'CustInvcEntryConsolGroupPG', 
  	   	name: 'customerInvoiceEntryConsolGroupDtlsDTO'
        }]
	
});

Ext.define('CustInvcEntryConsolGroupPG', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'summId',
		type : 'integer'
	},{
		name : 'intRqstNo',
		type : 'integer'
	},{
		name : 'seqNo',
		type : 'integer'
	},{
		name : 'custRateSeqNo',
		type : 'integer'
	},{
		name : 'srvCode',
		type : 'string'
	},{
		name : 'srvType',
		type : 'string'
	},{
		name : 'srvcGrp',
		type : 'string'
	},{
		name : 'srvDesc',
		type : 'string'
	},{
		name : 'unitId',
		type : 'string'
	},{
		name : 'shipngRefNo',
		type : 'string'
	},{
		name : 'transptCd',
		type : 'string'
	},{
		name : 'trnsptMode',
		type : 'string'
	},{
		name : 'tndrReqDt',
		type:'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'shipntDt',
		type:'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'delCmpltDt',
		type:'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  Ext.Date.clearTime(Ext.Date.parse(v.split(' ')[0],'Y-m-d'));
			}
			return v;
		}
	},{
		name : 'orgnLoc',
		type : 'string'
	},{
		name : 'destCd',
		type : 'string'
	},{
		name : 'destCity',
		type : 'string'
	},{
		name : 'ratingDest',
		type : 'string'
	},{
		name : 'makeCd',
		type : 'string'
	},{
		name : 'modelCd',
		type : 'string'
	},{
		name : 'modelGrp',
		type : 'string'
	},{
		name : 'modelYear',
		type : 'string'
	},{
		name : 'rateTier',
		type : 'string'
	},{
		name : 'evntLdRef',
		type : 'string'
	},{
		name : 'wrkOrder',
		type : 'string'
	},{
		name : 'minNum',
		type : 'integer'
	},{
		name : 'd2dval',
		type : 'float'
	},{
		name : 'd2dUom',
		type : 'string'
	},{
		name : 'd2rval',
		type : 'float'
	},{
		name : 'd2rUom',
		type : 'string'
	},{
		name : 'convncId',
		type : 'string'
	},{
		name : 'convncNm',
		type : 'string'
	},{
		name : 'convncType',
		type : 'string'
	},{
		name : 'consolId',
		type : 'string'
	},{
		name : 'consolType',
		type : 'string'
	},{
		name : 'orgnAdd1',
		type : 'string'
	},{
		name : 'orgnAdd2',
		type : 'string'
	},{
		name : 'orgnLocCty',
		type : 'string'
	},{
		name : 'orgnLocStP',
		type : 'string'
	},{
		name : 'orgnCntryCd',
		type : 'string'
	},{
		name : 'orgnZipPostalCd',
		type : 'string'
	},{
		name : 'destAdd1',
		type : 'string'
	},{
		name : 'destAdd2',
		type : 'string'
	},{
		name : 'destStateProv',
		type : 'string'
	},{
		name : 'destCntryCd',
		type : 'string'
	},{
		name : 'destZipPostalCd',
		type : 'string'
	},{
		name : 'partId',
		type : 'string'
	},{
		name : 'prftLossCent',
		type : 'string',
		mandatory : true
	},{
		name : 'custSlsRgn',
		type : 'string'
	},{
		name : 'shmntType',
		type : 'string'
	},{
		name : 'ordrTyp',
		type : 'string'
	},{
		name : 'abnrmMvType',
		type : 'string'
	},{
		name : 'suplrCd',
		type : 'string'
	},{
		name : 'dlrCd',
		type : 'String'
	},{
		name:'origOrg',
		type:'string'
	},{
		name:'finalDest',
		type:'string'
	},{
		name:'qntty1',
		type:'string'
	},{
		name:'revenueCode',
		type:'string'
	},{
		name:'cstmrEvntAckRcvdFlg',
		type:'string'
	},{
		name:'evntMismatchRsnCd',
		type:'string'
	},{
		name:'varienceEntFlg',
		type:'float'
	},{
		name : 'srvcAmt',
		type : 'float'
//		convert:function(v){
//			if(!Ext.isEmpty(v)){
//				v = Ext.util.Format.number(v,'0.00');
//			}
//			return v;
//		}
	},{
		name:'srvAmtPtyCrncy',
		type:'float'
	},{
		name:'srvAmtSysCrncy',
		type:'float'
	},{
		name:'srvAmtCmpnyCrncy',
		type:'float'
	},{
		name:'sysCrncyExchngRate',
		type:'float'
	},{
		name:'ptyCrncyExchngRate',
		type:'float'
	},{
		name:'cmpnyCrncyExchngRate',
		type:'float'
	},{
		name:'status',
		type:'string'
	},{
		name:'validated',
		type:'bool'
	},{
		name:'storageType',
		type:'string'
	},{
		name:'billOfLading',
		type:'string'
	},{
		name:'cargoType',
		type:'string'
	},{
		name:'modelLine',
		type:'string'
	}],
	belongsTo: 'CustInvcEntryConsolPG'
});


Ext.define('CustomerInvoiceLineItemStatus',{
	extend:'Ext.data.Model',
	fields:[{
		  name:'customer',
		  type : 'string'
		},
		{
		  name:'customerName',
		  type : 'string'
		},
		{
		  name:'invoiceNumber',
		  type : 'string'
		}, 
		{
		  name:'invoiceDate',
		  type : 'string'
		},
		{
		  name:'documentType'
		},
		{
		  name:'invoiceType',
		  type : 'string'
		},
		{
		  name:'serviceCode',
		  type : 'string'
		},
		{
		  name:'invoiceAmount',
		  type : 'string'
		},
		{
		  name:'paidAmount',
		  type : 'string'
		},
		{
		  name:'currency',
		  type : 'string'
		},
		{
		  name:'unitId',
		  type : 'string'
		},
		{
		  name:'conveyanceId',
		  type : 'string'
		},
		{
		  name:'partId',
		  type : 'string'
		},
		{
		  name:'documentReference',
		  type : 'string'
		},
		{
		  name:'completionDate',
		  type : 'string'
		},
		{
		  name:'dueDate',
		  type : 'string'
		},
		{
		  name:'lastPaymentDate',
		  type : 'string'
		},
		{
		  name:'invoiceStatus',
		  type : 'string'
		},
		{
		  name:'reason',
		  type : 'string'
		},
		{
			name  : 'consolidatedFlag',
			type: 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}
		},
		{
			name  : 'proformaInvcNo',
			type : 'string'
		}
	]
});

Ext.define('cstmrInvcGenModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intReqNo'
	},{
		name:'seqNo'
	},{
		name:'shipTypeCd'	
	},{
		name:'srvCode'
	},{
		name:'srvDesc'
	},{
		name:'supplier'	
	},{
		name:'customer'
	},{
		name:'unitId'
	},{
		name:'moveRef'
	},{
		name:'workOrder'
	},{
		name:'origin'
	},{
		name:'dest'
	},{
		name:'tenderDate'
	},{
		name:'shipmentDate'
	},{
		name:'deliveryDate'
	}]
	
});
Ext.define('FuelSurchargeMasterGridDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'fromRange',
		type : 'float'
	}, {
		name : 'torange',
		type : 'float'
	}, {
		name : 'increaseDecrease',
		type : 'float'
	}, {
		name : 'companyCd',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	},
	{
		name : 'programCode',
		type : 'string'
	}, {
		name : 'programName',
		type : 'string'
	}, {
		name : 'uom',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'chargeMethod',
		type : 'string'
	} ,
	{
		name : 'status',
		type : 'string'
	}
	]

});


Ext.define('FuelSurchargeMasterFormDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'programCode',
		type : 'string'
	}, {
		name : 'programName',
		type : 'string'
	}, {
		name : 'uom',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'chargeMethod',
		type : 'string'
	} ,
	{
		name : 'companyCd',
		type : 'string'
	},
	{
		name : 'status',
		type : 'string'
	},{
		name : 'transType',
		type : 'string'
	}
	],
	associations :[{
	   	type:'hasMany',
	   	model:'FuelSurchargeMasterChildGridDTO', 
	   	name: 'fuelSurchargeProgramMasterResult'
      }]

});


Ext.define('FuelSurchargeMasterChildGridDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'fromRange',
		type : 'float',
		useNull:true
	}, {
		name : 'torange',
		type : 'float',
		useNull:true
	}, {
		name : 'increaseDecrease',
		type : 'float',
		useNull:true
	}, {
		name : 'companyCd',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	},{
		name : 'transType',
		type : 'string'
	},{
		name : 'programCode',
		type : 'string'
	},{
		name : 'companyCd',
		type : 'string'
	}],
	belongsTo: 'FuelSurchargeMasterFormDTO'
		});


Ext.define('CustomerReconciliationGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCode',
		type : 'string'
	},{
		name : 'customer',
		type : 'string'
	},{
		name : 'serviceCode',
		type : 'string'
	},{
		name : 'serviceDesc',
		type : 'string'
	},
	 {
		name : 'unitId',
		type : 'string'
	},
	 {
		name : 'eventLoadRef',
		type : 'string'
	},
	 {
		name : 'origin',
		type : 'string'
	},
	 {
		name : 'destination',
		type : 'string'
	},
	 {
		name : 'conveyanceId',
		type : 'string'
	}
	,
	 {
		name : 'conveyanceType',
		type : 'string'
	},
	 {
		name : 'shippingRef',
		type : 'string'
	},
	 {
		name : 'transportCode',
		type : 'string'
	},
	 {
		name : 'make',
		type : 'string'
	},
	 {
		name : 'model',
		type : 'string'
	}
	,
	 {
		name : 'modelGroupCode',
		type : 'string'
	}
	,
	 {
		name : 'year',
		type : 'string'
	}
	,
	 {
		name : 'rateTier',
		type : 'string'
	}
	,
	 {
		name : 'workOrder',
		type : 'string'
	},
	 {
		name : 'partId',
		type : 'string'
	},	
	 {
		name : 'tenderDate',
		type : 'string'
		/*convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		},*/
//		dateFormat:Modules.GlobalVars.dateFormatGlobal
	},
	 {
		name : 'shipmentDate',
		type : 'string'
		/*convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				date =  new Date(v.split(' ')[0]);
			}
			mon = date.getMonth()+1;
			v = date.getDate()+"/"+mon+"/"+date.getFullYear();
			return v;
		},*/
		
//		dateFormat:Modules.GlobalVars.dateFormatGlobal
	},
	 {
		name : 'deliveryDate',
		type : 'string'
//		convert:function(v){
//			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
//				v =  new Date(v.split(' ')[0]);
//			}
//			return v;
//		},
//		dateFormat:Modules.GlobalVars.dateFormatGlobal
	},
	 {
		name : 'profitLoss',
		type : 'string'
	},
	 {
		name : 'customerSalesReg',
		type : 'string'
	},
	 {
		name : 'shipTypeCd',
		type : 'string'
	},
	 {
		name : 'orderType',
		type : 'string'
	},
	 {
		name : 'abnormalMove',
		type : 'string'
	},
	 {
		name : 'dealorCode',
		type : 'string'
	},
	 {
		name : 'finalDestination',
		type : 'string'
	},{
		name : 'consolidationId',
		type : 'string'
	},{
		name : 'consolidationType',
		type : 'string'
	},{
		name : 'serviceAmount',
		type : 'string'
	},{
		name : 'comment',
		type : 'string'
	},
	 {
		name : 'intReqNo'
	},
	 {
		name : 'seqNo'
	},
	 {
		name : 'shipTypeCd'
	},
	{name : 'fualCharg'},
	{name : 'transportMode'},
	{name : 'originCity'},
	{name : 'originState'},
	{name : 'originCountry'},
	{name : 'destCity'},
	{name : 'destState'},
	{name : 'destCountry'},
	{name : 'originalOrigin'},
	{name : 'strgQty'},
	{name : 'strgUomCd'},
	{name : 'prevChrgQty'},
	{name : 'prevChrgUomCd'},
	{name : 'destAdd1'},
	{name : 'destAdd2'},
	{name : 'destPoBox'},
	{name : 'supplier'},
	{name : 'chargQty'},
	{name : 'cstmrRatingSeqNo'},
	{name : 'cstmrIntSplAgmtNo'},
	{name : 'cstmrManRateFlg'},
	{name : 'cstmrInvcCrncyCd'},
	{name : 'revnCd'},
	{name : 'srvGrpCd'},
	{name : 'dbtrPtyCd'},
	{name : 'srvType'},
	{name : 'cstmrSplAgmtNo'},
	{name : 'billOfLading'},
	{name : 'storageType'},
	{name : 'cargoType'},
	{name : 'modelLine'}
	]
});


Ext.define('supplierRateQueryDTONonOcean',{
	extend:'Ext.data.Model',

	fields:[{
		  name:'companyCode'
		},{
		  name:'contractId'
		}, {
		  name:'supplier'
		},{
		  name:'supplierName'
		},{
		  name:'validFromDate',
		  type : 'date',
		  dateFormat:'d/m/Y'
		},{
		  name:'validToDate',
		  type : 'date',
		  dateFormat:'d/m/Y'
		}
		]
});

	Ext.define('nonOceanSupplierRateQueryCopyContract',{
		extend:'Ext.data.Model',
		fields:[{
			name:'contractId',
			type:'string',
			mandatory:true
		},{
			name:'supplier',
			type:'string',
			mandatory:true	
		},{
			name:'name',
			type:'string',
			mandatory:true
		},{
			name:'dabtorParty',
			type:'string'
		},{
			name:'dabtorPartyName',
			type:'string'
		},{
			name:'validFromDt',
			dateFormat:'d/m/Y',
			type:'date',
			mandatory:true
		},{
			name:'validToDt',
			type:'date',
			mandatory:true
		},{
			name:'increaseCriteria',
			type:'string',
			mandatory:true
		},{
			name:'increaseValue',
			type:'integer',
			mandatory:true  
		},{
		  name:'invoiceNumber',
		  type : 'string'
		}, {
		  name:'invoiceDate',
		  type : 'string'

		},{
			name:'companyCode',
			type:'string'
		},{
			name:'serviceType',
			type:'string'
		},{
			name:'int_spl_agmt_no',
			type:'string'
		} ]
});

Ext.define('FuelSurchargeIndexValueDTO', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'indexCode',
		type : 'string'
	}, {
		name : 'indexName',
		type : 'string'
	}, {
		name : 'uomCode',
		type : 'string'
	}, {
		name : 'currencyCode',
		type : 'string'
	}, {
		name : 'fromDate',
		type : 'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'toDate',
		type : 'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'actualIndexValue',
		type : 'float',
		useNull : true
	}, {
		name : 'estimatedIndexValue',
		type : 'float',
		useNull : true
	}, {
		name : 'comment',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	}]

});

Ext.define('suppReconcliationTaxDetailsModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'taxType',
		type : 'string'
	}, {
		name : 'taxPrcntg',
		type : 'float'
	}]

});

Ext.define('TariffMasterSlabDetailsModel',{
	extend:'Ext.data.Model',

	fields:[
	    {
		  name:'fromUnit',
		  type : 'float',
		  useNull:true
		},
		{
		  name:'unitRate',
		  type : 'float',
		  useNull:true
		}, 
		{
		  name:'luInd'
		},
		{
		  name:'status'
		},
		{
		  name:'trnsType'
		}
		]

});

Ext.define('customerRateQueryNonOceanCopyContract',{
	extend:'Ext.data.Model',
	fields:[{
		name:'contractId',
		type:'string',
		mandatory:true
	},{
		name:'customer',
		type:'string',
		mandatory:true	
	}
	,{
		name:'name',
		type:'string',
		mandatory:true
	},{
		name:'dabtorParty',
		type:'string'
	},{
		name:'dabtorPartyName',
		type:'string'
	},{
		name:'validFromDt',
		dateFormat:'d/m/Y',
		type:'date',
		mandatory:true
	},{
		name:'validToDt',
		type:'date',
		mandatory:true
	},{
		name:'increaseCriteria',
		type:'string',
		mandatory:true
	},{
		name:'increaseValue',
		type:'string',
		mandatory:true
	},{
		name:'companyCode',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
	},{
		name:'int_spl_agmt_no',
		type:'string'
	} ]
});

Ext.define('modelLineList',{
	extend:'Ext.data.Model',
	fields:[{
	        	name:'code',
	        	type:'string'
	        },
	        {
	        	name:'name',
	        	type:'string'
	        }	     
	       ]	
});

Ext.define('storageTypeList',{
	extend:'Ext.data.Model',
	fields:[{
	        	name:'code',
	        	type:'string'
	        },
	        {
	        	name:'name',
	        	type:'string'
	        }	     
	       ]	
});

Ext.define('importErrorModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		        name:'lineNbr',
		        type:'integer'
	        },
	        {
	        	name:'colSeqNbr',
	        	type:'integer'
	        },
	        {
	        	name:'errorMsg',
	        	type:'string'
	        }
	        ]
});

Ext.define('TariffMasterDTO',{
	extend:'Ext.data.Model',
	fields:[
	        {
		        name:'tariffCode',
		        type:'string'
	        },
	        {
	        	name:'tariffDescription',
	        	type:'string'
	        },
	        {
	        	name:'effectiveDate',
	        	dateFormat:'d/m/Y',
	        	type:'date'
	        },
	        {
		        name:'tariffUnitRate',
		        type:'float'
	        },
	        {
	        	name:'currency',
	        	type:'string'
	        },
	        {
	        	name:'trnsType',
	        	type:'string'
	        },
	        {
	        	name:'slabFlag',
	        	type:'bool',convert:function(v)
	 		   {
	 			return (v === "Y" || v === true || v === "") ? true : false;
	 		   }
	        },
	        {
	        	name:'cumulativeFlag',
	        	type:'bool',convert:function(v)
	 		   {
	 			return (v === "Y" || v === true || v === "") ? true : false;
	 		   }
	        }
	        ],
	    	hasMany: [{
	    	    model:'TariffMasterSlabDetailsModel', 
	    	    name: 'slabDtlsList'
	    	 }]
});

Ext.define('TariffCodeModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		        name:'code',
		        type:'string'
	        },
	        {
	        	name:'name',
	        	type:'string'
	        },
            {
	        	name:'tariffCurrencyCd',
	        	type:'string'
	        }
           ]
});

