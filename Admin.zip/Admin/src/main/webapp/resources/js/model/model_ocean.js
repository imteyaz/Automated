/**
 * 
 */

Ext.define('genericLookUp',{
	extend:'Ext.data.Model',
	fields:[
	        {
		     name:'code',
		     type:'string'
	        },
	        {
	          name:'name',
	          type:'string'
	        }
	        ]
});

Ext.define('genericPolList',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'portCode',
	          type:'string'
	        },
	        {
	        	name:'portName',
	        	type:'string'
	        },
	        {
	        	name:'addrs1',
	        	type:'string'
	        },
	        {
	        	name:'addrs2',
	        	type:'string'
	        },
	        {
	        	name:'cityName',
	        	type:'string'
	        },
	        {
	        	name:'stateCode',
	        	type:'string'
	        },
	        {
	        	name:'poBox',
	        	type:'string'
	        },
	        {
	        	name:'currencyCode',
	        	type:'string'
	        },
	        {
	        	name:'countryCode',
	        	type:'string'
	        },
	        {
	        	name:'cntryCd',
	        	type:'string'
	        }
	        ]
});

Ext.define('OceanCstmrInvcGenModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'intBlNum',
		type :'string'
	},{
		name : 'itemSeqNum',
		type :'string'
	},{
		name : 'pop',
		type :'string'
	},{
		name : 'chargeCode',
		type :'string'
	},{
		name : 'chargeCodeDesc',
		type :'string'
	},{
		name : 'carrier',
		type :'string'
	},{
		name : 'party',
		type :'string'
	},{
		name : 'partyName',
		type :'string'
	},{
		name : 'freightTerms',
		type :'string'
	},{
		name : 'voyage',
		type :'string'
	},{
		name : 'vessel',
		type :'string'
	},{
		name : 'blNumber',
		type :'string'
	},{
		name : 'pol',
		type :'string'
	},{
		name: 'pod',
		type :'string'
	},{
		name : 'por',
		type :'string'
	},{
		name: 'pfd',
		type :'string'
	},{
		name : 'itemNumber',
		type :'string'
	},{
		name: 'cargoClass',
		type :'string'
	},{
		name : 'cargoType',
		type :'string'
	},{
		name: 'commodityDesc',
		type :'string'	
	},{
		name : 'vatApplFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name : 'quantity',
		type : 'float'
	},{
		name : 'rate',
		type :'float'
	},{
		name : 'rateBasis',
		type :'string'
	},{
		name : 'manifestCurrency',
		type :'string'
	},{
		name : 'manifestAmount',
		type :'double'
	},{
		name: 'invoiceCurrency',
		type :'string'
	},{
		name : 'invoiceAmount',
		type :'float'
	},{
		name: 'usdEqivlntAmnt',
		type :'float'
	},{
		name: 'serviceGroupCode',
		type :'string'
	},{
		name: 'rateOfExchng',
		type :'float'
		
		
	}]
});


Ext.define('popList',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'popCode',
	          type:'string'
	        },
	        {
		          name:'popName',
		          type:'string'
		    },
	        {
	        	name:'popNbr',
	        	type:'integer'
	        },
	        {
	        	name:'addrs1',
	        	type:'string'
	        },
	        {
	        	name:'addrs2',
	        	type:'string'
	        },
	        {
	        	name:'cityName',
	        	type:'string'
	        },
	        {
	        	name:'stateCode',
	        	type:'string'
	        },
	        {
	        	name:'poBox',
	        	type:'string'
	        },
	        {
	        	name:'countryCode',
	        	type:'string'
	        },
	        {
	        	name:'currencyCode',
	        	type:'string'
	        },
	        {
	        	name:'timezoneinfo',
	        	type:'string'
	        },
	        {
	        	name:'defaultFlag',
	        	type:'string',
	        	convert : Modules.GlobalFuncs.stringToBooleanConvertor
	        },
	        {
	        	name:'companyCode',
	        	type:'string'
	        },{
	        	name:'dfltPopFlg',
	        	type:'string'
	        }
	        
	       ]
	
});


Ext.define('popCntryList',{
	extend:'Ext.data.Model',
	fields:[
		        {
		        	name:'cntryCd',
		        	type:'string'
		        }
		       ]
	
});



Ext.define('portList',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'portCode',
	          type:'string'
	        },
	        {
	          name:'portName',
	          type:'string'
		    },
	        {
	        	name:'addrs1',
	        	type:'string'
	        },
	        {
	        	name:'addrs2',
	        	type:'string'
	        },
	        {
	        	name:'cityName',
	        	type:'string'
	        },
	        {
	        	name:'stateCode',
	        	type:'string'
	        },
	        {
	        	name:'poBox',
	        	type:'string'
	        },
	        {
	        	name:'cntryCd',
	        	type:'string'
	        },
	        {
	        	name:'crncyCd',
	        	type:'string'
	        },
	        {
	        	name:'defaultFlag',
	        	type:'string',
	        	convert : Modules.GlobalFuncs.stringToBooleanConvertor
	        },
	        {
	        	name:'companyCode',
	        	type:'string'
	        }
	       ]
	
});
Ext.define('chargeCodeLov',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'chargeCode',
	          type:'string'
	        },
	        {
	        	name:'chargCodeDesc',
	        	type:'string'
	        },
	        {
	        	name:'srvType',
	        	type:'string'
	        }
	       ]
	
});


Ext.define('voyageModel',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
		  name:'voyageNo',
		  type:'string'
		 },
		 {
		  name:'voyageCurrencyCd',
		  type:'string'
		 },
		 {
		  name:'routeCd',
		  type:'string'
		 }
		 ]
	
});

Ext.define('freightTrmsLov',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'freightTrmsCode',
	          type:'string'
	        },
	        {
	        	name:'freightTrmsDesc',
	        	type:'string'
	        }
	       ]
	
});


Ext.define('oceanSrvGrpLov',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'srvcGroupCd',
	          type:'string'
	        },
	        {
	        	name:'srvcGroupDesc',
	        	type:'string'
	        },
	        {
	        	name:'partyCd',
	        	type:'string'
	        }
	       ]
	
});

Ext.define('oceanCustomerMasterDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'partyNo',
		mandatory:true,
    	type:'string'
	},{
		name:'partyName',
		mandatory:true,
    	type:'string'
	},{
		name:'partyName2',
    	type:'string'
	},{
		name:'address1',
    	type:'string'
	},{
		name:'address2',
    	type:'string'
	},{
		name:'address3',
    	type:'string'
	},{
		name:'city',
    	type:'string'
	},{
		name:'state',
    	type:'string'
	},{
		name:'postalCode',
    	type:'string'
	},{
		name:'country',
    	type:'string'
	},{
		name:'mailingAddr1',
    	type:'string'
	},{
		name:'mailingAddr2',
    	type:'string'
	},{
		name:'mailingAddr3',
    	type:'string'
	},{
		name:'mailingCity',
    	type:'string'
	},{
		name:'mailingState',
    	type:'string'
	},{
		name:'mailingPostalCode',
    	type:'string'
	},{
		name:'mailingCountry',
    	type:'string'
	},{
		name:'salesRegionCd',
		mandatory:true,
    	type:'string'
	},{
		name:'salesOffice',
    	type:'string'
	},{
		name:'currencyCd',
    	type:'string'
	},{
		name:'vatPrcntg',
    	type:'float',
		useNull : true
	},{
		name:'vatNum',
		//mandatory:true,
    	type:'string'
	},{
		name:'ediPartnerCd',
		//mandatory:true,
    	type:'string'
	},{
		name:'downLdARafterAP',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'autoAprvInApplAdvc',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'sendCstmrInvcMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'financeID',
    	type:'string'
	},{
		name:'financeCntrctNo',
    	type:'string'
	},{
		name:'transType',
    	type:'string'
	},{
		name:'printTemplate',
    	type:'string'
	},{
		name:'sendMailFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'invoiceFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'billFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	}],
	associations :[/*{
    	   	type:'hasMany',
    	   	model:'oceanCstmrMstrContractIdentification', 
    	   	name: 'contractIdentificationGridResult'
	      },*/{
	    	type:'hasMany',
	    	model:'oceanRoundingCriteriaValue', 
	    	name: 'roundingCriteriaValueGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'oceanCustomerMasterPartyType', 
			name: 'partyTypeGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'oceanCstmrMasterCreditTermsAndLimit', 
			name: 'creditTermsLimitGridResult'	    	  
	      },
	      /*{
	         type:'hasMany',
			 model:'oceanCstmrMstrPrintTemplate', 
			 name: 'printTemplateGridResult'	    	  
		  },*/
	      {
		     type:'hasMany',
		     model:'oceanCstmrMstrContactDetails', 
			 name: 'contactDetailsGridResult'	    	  
		  },
		  {
			     type:'hasMany',
			     model:'oceanCstmrMstrVolvoMsgDetails', 
				 name: 'volvoMsgDetailsGridResult'	    	  
			  }
	   ]		    
});

/*Ext.define('oceanCstmrMstrContractIdentification',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'chargeCode',
		type:'string'	
	},{
		name:'pOL',
		type:'string'
	},{
		name:'pOD',
		type:'string'
	},{
		name:'bLDate',
		type:'string',
		mandatory:true
	},{
		name:'transType',
    	type:'string'
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});*/

Ext.define('oceanRoundingCriteriaValue',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'summaryValue',
		type:'string',
		mandatory:true
	},{
		name:'roundingCriteria',
		type:'string',
		mandatory:true
	},{
		name:'value',
		type : 'float',
		mandatory:true,
		useNull : true
	},{
		name:'transType',
    	type:'string'
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});

Ext.define('oceanCustomerMasterPartyType',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name:'partyType',
		type:'string',
		mandatory:true
	},{
		name:'transType',
    	type:'string'
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});

Ext.define('oceanCstmrMasterCreditTermsAndLimit',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name:'freightTerms',
		type:'string',
		mandatory:true
	},{
		name:'creditTermCB',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'creditTermDays',
		type : 'integer',
		//mandatory:true,
		useNull : true	
	},{
		name:'creditTermLimit',
		type : 'float',
		//mandatory:true,
		useNull : true
	},{
		name:'creditTermLimitUSD',
		type : 'float',
		//mandatory:true,
		useNull : true
	},{
		name:'edi_ins_flg',
		type : 'string'
	},{
		name:'transType',
    	type:'string'
	}],
	belongsTo: 'oceanCustomerMasterDetails'

});

/*Ext.define('oceanCstmrMstrPrintTemplate',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name : 'pop',
		type :'string'
	},{
		name : 'printPrepaid',
		type :'string',
		mandatory:true
	},{
		name : 'printCollect',
		type :'string',
		mandatory:true
	},{
		name:'transType',
    	type:'string'
	},{
		name:'dflt_print_templt_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});*/

Ext.define('oceanCstmrMstrContactDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name : 'contact_seq_no',
		type :'integer',
		mandatory:true,
		useNull : true
	},{
		name : 'name',
		type :'string'
	},{
		name : 'phone',
		type :'string'
	},{
		name:'fax',
    	type:'string'
	},{
		name : 'email',
		type :'string'
	},{
		name:'web',
    	type:'string'
	},{
		name:'transType',
    	type:'string'
	}/*,{
		name:'contactType',
    	type:'string'
	}*/,{
		name : 'bookingCnfrmFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'billFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name : 'noaFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'importDlvryFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},{
		name:'invoiceFlag',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});

Ext.define('oceanCstmrMstrVolvoMsgDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company'
	},{
		name:'partyNo'
	},{
		name : 'popCode',
		type :'string',
		mandatory:true
	},{
		name : 'freightTermCode',
		type :'string',
		mandatory:true
	},{
		name : 'documentType',
		type :'string',
		mandatory:true
	},{
		name:'volvoMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	}],
	belongsTo: 'oceanCustomerMasterDetails'
});

Ext.define('PartyLov',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'cstmrCd',
	          type:'string'
	        },
	        {
	        	name:'cstmrNm',
		        type:'string'	
	        },
	        {
	        	name:'cstmrNm1',
		        type:'string'
	        },
	        {
	        	name:'addr1',
		        type:'string'
	        },
	        {
	        	name:'addr2',
		        type:'string'
	        },
	        {
	        	name:'addr3',
		        type:'string'
	        },
	        { 
	        	name:'cityNm',
		        type:'string'
	        },
	        {
	        	name:'stateCd',
		        type:'string'
	        },
	        {
	        	name:'countryCd',
	        	type:'string'
	        },
	        {
	        	name:'poBox',
	        	type:'string'
	        }
	        ]
});


Ext.define('OceanCutomerRateQuery',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intSplAgmtNo',
		type:'string'
	},	
	        {
		name:'companyCode',
		type:'string'
	},	
	        {
		name:'popCode',
		type:'string'
	},	
	{
		name:'contractId',
		type:'string'	
	},
	{
		name:'party',
		type:'string'
	},{
		name:'supplier',
		type:'string'
	},
	{
		name:'name',
		type:'string'
	},
	{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y'/*,
		convert : function(value){
			if(!Ext.isEmpty(value)){
				//var dateFormat=Ext.Date.parse(value,"Y-m-d H:i:s.u");
				return Ext.util.Format.date(value,"d/m/Y");
			}
			else return null;
		}*/
	},
	{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y'/*,
		convert : function(value){
			if(!Ext.isEmpty(value)){
				//var dateFormat=Ext.Date.parse(value,"Y-m-d H:i:s.u");
				return Ext.util.Format.date(value,"d/m/Y");
			}
			else return null;
		}*/
	}]
});
Ext.define('oceanTriggerIdentification',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'serviceType',
	          type:'string',
	          defaultValue:'O'
	        },
	        {
	        	name:'pop',
	         	type:'string'
	        },
	        {
	        	name:'party',
	         	type:'string'
	        },
	        {
	        	name:'company',
	         	type:'string'
	        },
	        
	        {
	        	name:'serviceCode',
	        	type:'string',
	        	mandatory: true
	        },
	        {
	        	name:'frghtTerms',
	        	type:'string',
	        	mandatory: true
	        },
	        {
	        	name:'triggerStatus',
	        	type:'string'
	        },
	        {
	    		name:'transType',
	    		type:'string'
	    	}
	        
	        
	        ]
});
Ext.define('oceanCustomerActualInvoiceGrouping', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'serviceGroupCode',
		type : 'string',
		mandatory : true

	}, {
		name : 'transType',
		type : 'string'

	},

	{
		name : 'pop',
		type : 'string'

	},

	{
		name : 'serviceType',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor,
		defaultValue: true

	}, {
		name : 'blnumber',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'voyage',

		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor,
		defaultValue: true

	}, {
		name : 'invcCurr',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor,
		defaultValue: true
		

	}, {
		name : 'vesselCode',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'por',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'pol',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'pod',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'pfd',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'carrierCodegroup',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor,
		defaultValue: true

	}, {
		name : 'cargoType',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'cargoClass',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
			

	}, {
		name : 'srvGroup',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'srvcCode',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'frghtterms',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor,
		defaultValue: true

	}, {
		name : 'itemNo',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolidation',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolServiceGroup',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolFrightTerms',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolServiceCode',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	},

	{
		name : 'consolblnumber',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolvoyage',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolinvcCurr',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
		

	}, {
		name : 'consolvesselCode',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolpor',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},

	{
		name : 'consolpol',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'consolpod',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	}, {
		name : 'consolpfd',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},
	{
		name : 'consolcargoType',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'consolcargoClass',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	},  {
		name : 'consolItemNo',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	},{
		name : 'generationFrequency',
		type : 'string',
		mandatory : true
	}, {
		name : 'graceDays',
		type : 'string'
	},{
		name : 'time',
		type : 'date',
		dateFormat:Modules.GlobalVars.timeFormatGlobal
		//type : 'string',
		/*convert:function(v){
			if(Ext.isDate(v)){
				return Ext.util.Format.dateRenderer('H:i')(v);
			}
			return v;
		}*/
	}, {
		name : 'generationInterval',
		type:'integer'
	}, {
		name : 'generationTimeZone',
		type : 'string'
	},
	 {
		name : 'generationTimeZoneDummy',
		type : 'string'
	},{
		name : 'autoAprove',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'party',
		type : 'string'
	}, {
		name : 'company',
		type : 'string'
	}, {
		name : 'exlusionCustomerList',
		type : 'string'
	},
	
	{
		name : 'invoiceLineItems',
		type : 'string'
	},
	{
		name : 'consolServiceType',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}
	,
	{
		name : 'consolcarrierCodegroup',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},{
		name : 'delta',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	},{
		name : 'consolDelta',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor

	},  
	

	]
});

Ext.define('oceanCustomerInvoiceStatus',{
	extend:'Ext.data.Model',
	fields:[
	        {    
	name:'party',
	type:'string'
	          
},{    
	name:'partyName',
	type:'string'
	          
},
{
	name:'invcNo',
	type: 'string'
	
	          
},
{
	name:'documentType',
	
	type: 'string'
	          
},{
	name:'proformaStatus'
},
{
	name:'invoiceType',
	
	type: 'string'
	          
},
{
	name:'manifestCurrency',
	
	type: 'string'
	          
},
{
	name:'manifestAmount',
	type: 'float'
	          
},
{
	name:'invoiceCurrency',
	
	type: 'string'
	          
},
{
	name:'invoiceAmount',
	type: 'float'
	          
},
{
	name:'usdequiAmt',
	
	type: 'float'
	          
},
{
	name:'paidAmt'
//	type: 'float'
	          
 },
 {
	name:'invoiceDate',	
	dateFormat:'d/m/Y',
	type:'date'
	          
},
{
	name:'dueDate',
	dateFormat:'d/m/Y',
	type:'date'
	          
},
{
	name:'lastPaymentDate',
	dateFormat:'d/m/Y H:i:s',
	type:'date'
	          
},
{
	name:'invoiceStatus',
	type: 'string'
	          
},
{
	name:'prfinvcno',
	type: 'string'
	          
},{
	name:'applnadvicerejectflg'
},{
	name:'estmrvsdflg'
},{
	name:'documentTypeDesc'
},{
	name:'invoiceTypeDesc'
},{
	name:'pop'
},{
	name:'consolidatedFlag'
},{
	name:'supplier'
},{
	name:'voyage'
},{
	name:'headerClause',
	type:'string'	
},{
	name:'proformaInvoiceNO'
},{
	name:'proformaCreatedBy'
},{
	name:'proformaCreatedOn',
	dateFormat:'d/m/Y H:i:s',
	type:'date'
},{
	name:'finalizedCreatedBy'
},{
	name:'finalizedCreatedOn',
	dateFormat:'d/m/Y H:i:s',
	type:'date'
},{
	name:'misMatchReason',	
	type: 'string'
},{
	name:'refInvcNo',	
	type: 'string'
},{
	name:'printCnt'
},{
	name:'emailCnt'
},{
	name:'emailId'
}

]
});

Ext.define('OceanCustEventStatusSummary',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'supplierSts',
	        	type:'string'
	        },
	{
		name:'party',
		type:'string'
	},
	{
       name:'frieghtTerm',
       type:'string'
	},
	{
		name:'chargCode',
		type:'string' 	
	},
	{
		name:'pol',
		type:'string'
	},
	{
		name:'pod',
		type:'string'
	},
	{
		name:'count',
		type:'string'
	},
	{
		name:'totalQnty',
		type:'float'
		
	},
	{
		name:'servcAmntManFstCrncy',
		type:'float'
	},
	{
		name:'manifstCurncyCd',
		type:'string'
	},
	{
		name:'servAmntInvcCrncy',
		type:'float'
	},
	{
		name:'invcCurncyCd',
		type:'string'
	},
	{
		name:'servAmntUSD',
		type:'float'
	},
	{
		name:'customerNm',
		type:'string'
	},
	{
		name:'blNumber',
		type:'string'
	},
	{
		name:'vessel',
		type:'string'
			
	},
	{
		name:'voyage',
		type:'string'
	},
	{
		name:'por',
		type:'string'
	},
	{
		name:'pfd',
		type:'string'
	
	}
	]
});


Ext.define('OceanSupplrEventStatusSummary',{
	extend:'Ext.data.Model',
	fields:[{
		name:'party',
		type:'string'
	},{
		name:'supplier',
		type:'string'
	},
	{
		name:'chargCode',
		type:'string'	
	},{
		name:'pol',
		type:'string'
	},{
		name:'pod',
		type:'string'	
	},{
		name:'count',
		type:'integer'	
	},{
		name:'totalQnty',
		type:'float'
		
	},{
		name:'currency',
		type:'string'	
	},{
		name:'totalSrvcAmt',
		type:'float'	
	}
	]
});

Ext.define('GenericOceanSrvcGrpLookUpDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
		       name:'srvcGrpCd',
		       type:'string'
	        },
	        {
		       name:'srvcGrpDesc',
		       type:'string'
	        },
	        {
	        	name:'cstmrCd',
	        	type:'string'
	        }
	        ]
});
Ext.define('OceanCstmrSrvcGrpGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'cmpnyCd',
		type:'string'
	},{
		name:'cstmrCd',
		type:'string',
		mandatory:true
	},	
	{
		name:'cstmrName',
		type:'string'	
	},{
		name:'popCd',
		type:'string',
		mandatory:true
	},	
	{
		name:'popNm',
		type:'string'	
	},
	
	{
		name:'srvcGrpCd',
		type:'string',
		mandatory:true
	},
	{
		name:'srvcGrpDesc',
		type:'string',
		mandatory:true
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rno',
		type:'string'
	}],
	hasMany: {
	       model:'OceanSrvcGrpSrvcTypeGrid', 
	       name: 'cstmrSrvcTypeGridList'
	    }
	
	
});
Ext.define('OceanSrvcGrpSrvcTypeGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'cmpnyCd',
		type:'string'
	},{
		name:'cstmrCd',
		type:'string'
	},{
		name:'srvcGrpCd',
		type:'string'	
	},{
		name:'srvcType',
		type:'string',
		mandatory:true
	
	},{
		name:'popCd',
		type:'string'
	},
	{
		name:'srvcCd',
		type:'string',
		mandatory:true
	},
	{
		name:'srvcDesc',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	},
	{
		name:'rno',
		type:'string'
	}
	],
	belongsTo: 'OceanCstmrSrvcGrpGrid'
});
/*
Ext.define('OceanSrvcGrpSrvcTypeGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'cmpnyCd',
		type:'string'
	},{
		name:'cstmrCd',
		type:'string'
	},{
		name:'popCd',
		type:'string'
	},{
		name:'srvcGrpCd',
		type:'string'	
	},{
		name:'srvcType',
		type:'string',
		mandatory:true
	},{
		name:'srvcCd',
		type:'string',
		mandatory:true
	},{
		name:'srvcDesc',
		type:'string'	
	},
	{
		name:'status',
		type:'string'
	},{
		name:'rno',
		type:'string'
	}
	],
	belongsTo: 'OceanCstmrSrvcGrpGrid'
});*/

Ext.define('CargoTypeModel',{
	extend:'Ext.data.Model',
	fields:
		[
		 {
		  name:'crgTypeCode',
		  type:'string'
		 },
		 {
		  name:'crgTypeDescr',
		  type:'string'
		 }
		 ]
});



Ext.define('oceanSupplierMasterDetails',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		mandatory:true,
    	type:'string'
	},{
		name:'supplierName',
	//	mandatory:true,
    	type:'string'
	},{
		name:'defaultCrncy',
		mandatory:true,
    	type:'string'
	},{
		name:'taxRefNum',
    	type:'string'
	},{
		name:'address1',
    	type:'string'
	},{
		name:'address2',
    	type:'string'
	},{
		name:'city',
    	type:'string'
	},{
		name:'state',
    	type:'string'
	},{
		name:'country',
    	type:'string'
	},{
		name:'postalCode',
    	type:'string'
	},{
		name:'telephone',
	//	mandatory:true,
    	type:'string'
	},{
		name:'faxNum',
    	type:'string'
	},{
		name:'mobileNum',
    	type:'string'
	},/*{
		name:'emailId',
    	type:'string'
	},{
		name:'contactPrsn',
		mandatory:true,
    	type:'string'
	},*/{
		name:'website',
	//	mandatory:true,
    	type:'string'
	},{
		name:'financeId',
	//	mandatory:true,
    	type:'string'
	},{
		name:'calTaxIfNotSntInMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'sendAPMsgToCoda',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'calTaxIfNotSntInExcel',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'ignoreInvDueDtFrmMsg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'shipmentDt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'partialPaymnt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'completionDt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'creatVrnceEvnt',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'autoAprv',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
	},{
		name:'remark',
    	type:'string'
	},{
		name:'remarks',
    	type:'string'
	},{
		name:'transType',
    	type:'string'
	}],
	associations :[{
    	   	type:'hasMany',
    	   	model:'oceanSupplierMasterPaymentDeatils', 
    	   	name: 'paymntDtlsGridResult'
	      },{
	    	type:'hasMany',
	    	model:'oceanSupplierMasterStatusDateCntrctIden', 
	    	name: 'stsDateForIdentGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'oceanSupplierMasterAutomaticInvoiceSetup', 
			name: 'automaticInvcSetupGridResult'	    	  
	      },{
	  		type:'hasMany',
			model:'oceanSupplierMasterRateRoundingCriteria', 
			name: 'roundingCriteriaForRateGridResult'	    	  
	      },
	      {
	    	  type:'hasMany',
	    	  model:'oceanSupplierMasterContactPersonDtls',
	    	  name:'contactPersonDetails'
	      }
	      ]		    
});

Ext.define('oceanSupplierMasterContactPersonDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'company',
	        	type:'string'
	        },
	        {
	        	name:'supplierCd',
	        	type:'string'
	        },
	        {
		       name:'contactPrsnNm',
		       type:'string',
		       mandatory:true
	        },
	        {
	        	name:'emailId',
	        	type:'string'
	        },
	        {
	        	name:'phoneNbr',
	        	type:'string'
	        },
            {
			   name:'transType',
			   type:'string'
            }
	       ],
   belongsTo: 'oceanSupplierMasterDetails'
});

Ext.define('oceanSupplierMasterPaymentDeatils',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
	    type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'chargeCode',
		type:'string'
//		mandatory:true	
	},{
		name:'paymentTrmDays',
		type:'integer'
	
	},{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'oceanSupplierMasterDetails'
});

Ext.define('oceanSupplierMasterStatusDateCntrctIden',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'chargeCode',
		type:'string'
	//	mandatory:true	
	},{
		name:'pol',
		type:'string'
	//	mandatory:true
	},{
		name:'pod',
		type:'string'
	//	mandatory:true
	},{
		name:'cmpltionDt',
		type:'string',
		mandatory:true
		
	},{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'oceanSupplierMasterDetails'
});

Ext.define('oceanSupplierMasterAutomaticInvoiceSetup',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'chargeCode',
		type:'string'
//		mandatory:true	
	},{
		name:'triggerStatus',
		type:'string'
		
	},{
		name:'reconsldInvFlg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true || v === "") ? true : false;
		   }
		
	},{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'oceanSupplierMasterDetails'
});


Ext.define('oceanSupplierMasterRateRoundingCriteria',{
	extend:'Ext.data.Model',
	fields:[{
		name:'company',
		type:'string'
	},{
		name:'supplierCd',
		type:'string'
	},{
		name:'serviceType',
		type:'string',
		mandatory:true
	},{
		name:'currency',
		type:'string',
		mandatory:true	
	},{
		name:'roundingCriteria',
		type:'string',
		mandatory:true
	},{
		name:'value',
		type:'float',
		mandatory:true
	},{
		name:'transType',
		type:'string'
	}],
	belongsTo: 'oceanSupplierMasterDetails'
});




Ext.define('oceanCustomerRateQueryCopyContract',{
	extend:'Ext.data.Model',
	fields:[{
		name:'contractId',
		type:'string',
		mandatory:true
	},{
		name:'party',
		type:'string',
		mandatory:true	
	}
	,{
		name:'supplier',
		type:'string',
		mandatory:true	
	},{
		name:'name',
		type:'string',
		mandatory:true
	},{
		name:'dabtorParty',
		type:'string'
	},{
		name:'dabtorPartyName',
		type:'string'
	},{
		name:'validFromDt',
		dateFormat:'d/m/Y',
		type:'date',
		mandatory:true
	},{
		name:'validToDt',
		type:'date',
		mandatory:true
	},{
		name:'increaseCriteria',
		type:'string',
		mandatory:true
	},{
		name:'increaseValue',
		type:'string',
		mandatory:true
	},
	{
		name:'companyCode',
		type:'string'
	},{
		name:'serviceType',
		type:'string'
	},{
		name:'int_spl_agmt_no',
		type:'string'
	},{
		name:'cargoType',
		type:'string'
	},{
		name:'storageType',
		type:'string'
	},{
		name:'modelLineCd',
		type:'string'
	}]
});


Ext.define('OcnSuplrLookUpDTO',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'supplrCd',
		  type:'string'
		},
		{
		  name:'supplrNm',
		  type:'string'
		},
		{
			name:'addrs1',
			type:'string'
		},
		{
			name:'addrs2',
			type:'string'
		},
		{
			name:'cityNm',
			type:'string'
		},
		{
			name:'countryCd',
			type:'string'
		},
		{
			name:'stateCd',
			type:'string'
		},
		{
			name:'poBox',
			type:'string'	
		}
		]
});
Ext.define('oceanSuppLineItemStatusModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'carrier',
		type:'string'
	}, {
		name : 'invoiceNumber'
	},{
		name : 'invoiceDate'
	},{
		name : 'serviceCode'
	},{
		name : 'invoiceAmount'
	},{
		name : 'approvedAmount'
	},{
		name : 'paidAmount'
	},{
		name : 'currency'
	},{
		name : 'voyage'
	},{
		name : 'vessel'
	},{
		name : 'pol'
	},{
		name : 'pod'
	},{
		name : 'unitId'
	},{
		name : 'loadReference'
	},{
		name : 'conveyanceId'
	},{
		name : 'partId'
	},{
		name : 'deliveryCompletionDate'
	},{
		name : 'dueDate'
	},{
		name : 'lastPaymentDate'
	},{
		name : 'lineItemStatus'
	},{
		name : 'reason'
	},{
		name : 'serviceType'
	},{
		name : 'companyCd'
	},{
		name : 'invcItemStatus'
	},{
		name : 'invcCrdtNoteInd'
	},{
		name : 'proformaInvoiceNo'
	},{
		name : 'itemNo'
	},{
		name : 'supplTemplateCode'
	}]
});



Ext.define('OceanCstmrInvcEntryGPGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'custCode',
		type :'string'
	},{
		name : 'custName',
		type :'string'
	},{
		name : 'docType',
		type :'string'
	},{
		name : 'invcType',
		type :'string'
	},{
		name : 'invcNum',
		type :'string'
	},{
		name : 'invcDate',
	//	type : 'string'
		type : 'date',
		dateFormat:'d/m/Y',
		convert : function(value){
			if(!Ext.isEmpty(value)){
			//	var dateFormat=Ext.Date.parse(value,"Y-m-d");
				return value;//Ext.util.Format.date(dateFormat,"d/m/Y");
			}
			else return null;
		}
		
	},{
		name : 'invcDueDate',
	//	type : 'string',
		mandatory:true,
		type : 'date',
		dateFormat:'d/m/Y',
		convert : function(value){
			if(!Ext.isEmpty(value)){
			//	var dateFormat=Ext.Date.parse(value,"d/m/Y");
				return value;//Ext.util.Format.date(dateFormat,"d/m/Y");
			}
			else return null;
		}
	},{
		name : 'voyageNum',
		type :'string'
	},{
		name : 'carrier',
		type :'string'
	},{
		name : 'invcCurrency',
		type :'string'
	},{
		name : 'refInvcNo',
		type :'string'
	},{
		name: 'totalInvcAmt',
		type :'double'
	},{
		name : 'pop',
		type :'string'
	},{
		name: 'popCurrency',
		type :'string'
	
	},{
		name : 'contactPerson',
		type :'string'
	},{
		name : 'profitLoss',
		type :'string'
	},{
		name : 'printTemplate',
		type :'string'
	},{
		name: 'sailingDate',
	//	type :'string'
		type : 'date',
		dateFormat:'d/m/Y',
		convert : function(value){
			if(!Ext.isEmpty(value)){
			//	var dateFormat=Ext.Date.parse(value,"Y-m-d");
				return value;//Ext.util.Format.date(dateFormat,"d/m/Y");
			}
			else return null;
		}
		
	},{
		name : 'invcStatus',
		type :'string'
	},

	{
		name: 'addrLane1',
		type :'string'
	},{
		name : 'addrLane2',
		type :'string'
	},{
		name : 'addrLane3',
		type :'string'
	},{
		name : 'city',
		type :'string'
	},{
		name : 'stateProv',
		type :'string'
	},{
		name: 'country',
		type :'string'
	},{
		name : 'zipPostalCd',
		type :'string'
	},{
		name : 'prfInvcNo',
		type :'string'
	},{
		name : 'companyCode',
		type :'string'
	},{
		name: 'cstmrAckRcvdFlg',
		type :'string'
	},{
		name : 'consolFlg',
		type :'string'
	},{
		name : 'status',
		type :'string'
	},{
		name : 'appAdvcRejectFlg',
		type :'string'
	},{
		name : 'headerClause',
		type :'string'
	},{
		name : 'proformaUserName',
		type :'string'
	},{
		name : 'proformaDate',
		type :'string'
	},{
		name : 'finalizeUserName',
		type :'string'
	},{
		name : 'finalizeDate',
		type :'string'
	},{
		name : 'extPrfInvcNo',
		type :'string'
	},{
		name : 'dummyExchangeRate',
		type :'float'
	},{
		name : 'currencyFlag',
		type :'string'
	}]

});

Ext.define('oceanCstmrInvcEntryPGGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'chargeCd',
		type :'string',
		mandatory:true
	},{
		name : 'blNumber',
		type :'string'
	},{
		name : 'blType',
		type :'string'
	},{
		name : 'descr',
		type :'string'
	},{
		name : 'srvGrpCd',
		type :'string'
	},{
		name : 'freightTerms',
		type :'string'
	},{
		name : 'vesselCode',
		type :'string'
	},{
		name : 'shippingRefNo',
		type :'string'
	},{
		name : 'make',
		type :'string'
	},{
		name: 'model',
		type :'String'
	},{
		name : 'year',
		type :'integer'
	},{
		name : 'polSI',
		type :'string'
	},{
		name: 'pol',
		type :'string'
	},{
		name : 'podSI',
		type :'string'
	},{
		name: 'pod',
		type :'string'
	},{
		name: 'por',
		type :'string'
	},{
		name : 'pfd',
		type :'string'
	},{
		name : 'uom',
		type :'string'
	},{
		name: 'quantity',
		type :'string'
	},{
		name : 'rateBasis',
		type :'string'
	},{
		name: 'rate',
		type :'double'
	},{
		name : 'manifestCrncy',
		type :'string'
	},{
		name : 'manifestAmt',
		type :'double'
	},{
		name : 'invoiceCrncy',
		type :'string'
	},{
		name : 'invoiceAmt',
		type :'double'
	},{
		name: 'usdEqAmt',
		type :'double'
	},{
		name : 'remarks',
		type :'string'
	},{
		name : 'customerCode',
		type :'string'
	},{
		name : 'invcItemSts',
		type :'string'
	},{
		name : 'invcItemNo',
		type :'integer'
	},{
		name : 'serviceType',
		type :'string'
	},{
		name : 'cargoClassCd',
		type :'string'
	},{
		name : 'cargoTypeCd',
		type :'string'
	},{
		name : 'cmdtyCd',
		type :'string'
	},{
		name : 'cmdtyDesc',
		type :'string'
	},{
		name : 'itemNo',
		type :'integer'
	},{
		name : 'vatFlg',
		type :'string'
	},{
		name : 'transactionType',
		type :'string'
	},{
		name : 'exchangeRate',
		type :'float'
	},{
		name : 'srvUnitQty',
		type :'float'
	},{
		name : 'blCmpDate',
		type :'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		}
	},{
		name : 'porBerthCd',
		type :'string'
	},{
		name : 'porPortCall',
		type :'integer'
	},{
		name : 'polBerthCd',
		type :'string'
	},{
		name : 'polPortCall',
		type :'integer'
	},{
		name : 'podBerthCd',
		type :'string'
	},{
		name : 'podPortCall',
		type :'integer'
	},{
		name : 'pfdBerthCd',
		type :'string'
	},{
		name : 'pfdPortCall',
		type :'integer'
	},{
		name : 'prfInvcNo',
		type :'integer'
	},{
		name : 'summId',
		type :'integer'
	},{
		name : 'status',
		type :'string'
	},{
		name : 'itemSeqNo',
		type :'integer'
	},{
		name : 'voyageNum',
		type :'string'
	},{
		name : 'refSummId',
		type :'string'
	},{
		name : 'invStatus',
		type :'string'
	},{
		name : 'originalInvcNum',
		type :'string'
	}],
	associations :[{
	   	type:'hasMany',
	   	model:'oceanCstmrInvcEntryChGridModel', 
	    name: 'oceanCustomerInvoiceEntryDimensionsDTO'
      },
      {
  	   	type:'hasMany',
  	   	model:'oceanCstmrInvcEntryTaxGridModel', 
  	   	name: 'oceanCustomerInvoiceEntryTaxDetailsDTO'
       },
       {
  	   	type:'hasMany',
  	   	model:'oceanCstmrInvcEntryConsolChGridModel', 
  	   	name: 'oceanCustomerInvoiceEntryConsolDimensionsDTO'
       }]
});

Ext.define('oceanCstmrInvcEntryChGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'crg_id',
		type :'string'
	},{
		name : 'crg_wt',
		type :'float'
	},{
		name : 'crg_wt_uom_cd',
		type :'string'
	},{
		name : 'crg_len',
		type :'float'
	},{
		name : 'crg_len_uom_cd',
		type :'string'
	},{
		name : 'crg_wd',
		type :'float'
	},{
		name : 'crg_ht',
		type :'float'
	},{
		name : 'crg_vol',
		type :'float'
	},{
		name : 'crg_cube',
		type :'float'
	},{
		name : 'crg_qty',
		type :'float'
	},{
		name : 'crg_trf_rate',
		type :'float'
	},{
		name : 'crg_srv_amt_manfst_crncy',
		type :'float'
	},{
		name : 'crg_manfst_crncy_cd',
		type :'string'
	},{
		name : 'crg_exchng_rate',
		type :'float'
	},{
		name : 'crg_srv_amt_local_crncy',
		type :'float'
	},{
		name : 'crg_local_crncy_cd',
		type :'string'
	},{
		name : 'crg_srv_amt_usd_crncy',
		type :'float'
	},{
		name : 'crg_bar_cd',
		type :'string'
	},{
		name : 'handling_ind',
		type :'string'
	},{
		name : 'xfr_gear',
		type :'string'
	},{
		name : 'steering_ind',
		type :'string'
	},{
		name : 'hzrds_flg',
		type :'string'
	},{
		name : 'crg_uom_cd',
		type :'string'
	},{
		name : 'status',
		type :'string'
	},{
		name : 'itemSeqNo',
		type :'integer'
	}],
	belongsTo: 'oceanCstmrInvcEntryPGGridModel'
});

Ext.define('oceanCstmrInvcEntryConsolChGridModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'invStatus',
		type :'string'
	}, {
		name : 'blNumber',
		type :'string'
	},{
		name : 'blType',
		type :'string'
	},{
		name : 'voyageNum',
		type :'string'
	},{
		name : 'freightTerms',
		type :'string'
	},{
		name : 'vesselCode',
		type :'string'
	},{
		name : 'shippingRefNo',
		type :'string'
	},{
		name : 'make',
		type :'string'
	},{
		name: 'model',
		type :'string'
	},{
		name : 'year',
		type :'string'
	},{
		name : 'polSI',
		type :'string'
	},{
		name: 'pol',
		type :'string'
	},{
		name : 'podSI',
		type :'string'
	},{
		name: 'pod',
		type :'string'
	},{
		name: 'por',
		type :'string'
	},{
		name : 'pfd',
		type :'string'
	},{
		name : 'uom',
		type :'string'
	},{
		name: 'quantity',
		type :'float'
	},{
		name : 'rateBasis',
		type :'string'
	},{
		name: 'rate',
		type :'float'
	},{
		name : 'carrier',
		type :'string'
	},{
		name : 'manifestCrncy',
		type :'string'
	},{
		name : 'manifestAmt',
		type :'double'
	},{
		name : 'invoiceCrncy',
		type :'string'
	},{
		name : 'invoiceAmt',
		type :'double'
	},{
		name: 'usdEqAmt',
		type :'double'
	},{
		name : 'remarks',
		type :'string'
	},{
		name : 'customerCode',
		type :'string'
	},{
		name : 'invcItemSts',
		type :'string'
	},{
		name : 'invcItemNo',
		type :'string'
	},{
		name : 'serviceType',
		type :'string'
	},{
		name : 'cargoClassCd',
		type :'string'
	},{
		name : 'cargoTypeCd',
		type :'string'
	},{
		name : 'cmdtyCd',
		type :'string'
	},{
		name : 'cmdtyDesc',
		type :'string'
	},{
		name : 'itemNo',
		type :'string'
	},{
		name : 'vatFlg',
		type :'string'
	},{
		name : 'transactionType',
		type :'string'
	},{
		name : 'exchangeRate',
		type :'float'
	},{
		name : 'srvUnitQty',
		type :'float'
	},{
		name : 'blCmpDate',
		type :'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		}
	},{
		name : 'porBerthCd',
		type :'string'
	},{
		name : 'porPortCall',
		type :'string'
	},{
		name : 'polBerthCd',
		type :'string'
	},{
		name : 'polPortCall',
		type :'string'
	},{
		name : 'podBerthCd',
		type :'string'
	},{
		name : 'podPortCall',
		type :'string'
	},{
		name : 'pfdBerthCd',
		type :'string'
	},{
		name : 'pfdPortCall',
		type :'string'
	},{
		name : 'prfInvcNo',
		type :'string'
	},{
		name : 'summId',
		type :'string'
	},{
		name : 'status',
		type :'string'
	},{
		name : 'itemSeqNo',
		type :'integer'
	},{
		name : 'refSummId',
		type :'string'
	},{
		name : 'originalInvcNum',
		type :'string'
	}],
	belongsTo: 'oceanCstmrInvcEntryPGGridModel'
});

Ext.define('oceanCstmrInvcEntryConsolDeltaDtlsModel', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'invStatus',
		type :'string'
	}, {
		name : 'blNumber',
		type :'string'
	},{
		name : 'blType',
		type :'string'
	},{
		name : 'voyageNum',
		type :'string'
	},{
		name : 'freightTerms',
		type :'string'
	},{
		name : 'vesselCode',
		type :'string'
	},{
		name : 'shippingRefNo',
		type :'string'
	},{
		name : 'make',
		type :'string'
	},{
		name: 'model',
		type :'string'
	},{
		name : 'year',
		type :'string'
	},{
		name : 'polSI',
		type :'string'
	},{
		name: 'pol',
		type :'string'
	},{
		name : 'podSI',
		type :'string'
	},{
		name: 'pod',
		type :'string'
	},{
		name: 'por',
		type :'string'
	},{
		name : 'pfd',
		type :'string'
	},{
		name : 'uom',
		type :'string'
	},{
		name: 'quantity',
		type :'float'
	},{
		name : 'rateBasis',
		type :'string'
	},{
		name: 'rate',
		type :'float'
	},{
		name : 'carrier',
		type :'string'
	},{
		name : 'manifestCrncy',
		type :'string'
	},{
		name : 'manifestAmt',
		type :'double'
	},{
		name : 'invoiceCrncy',
		type :'string'
	},{
		name : 'invoiceAmt',
		type :'double'
	},{
		name: 'usdEqAmt',
		type :'double'
	},{
		name : 'remarks',
		type :'string'
	},{
		name : 'customerCode',
		type :'string'
	},{
		name : 'invcItemSts',
		type :'string'
	},{
		name : 'invcItemNo',
		type :'string'
	},{
		name : 'serviceType',
		type :'string'
	},{
		name : 'cargoClassCd',
		type :'string'
	},{
		name : 'cargoTypeCd',
		type :'string'
	},{
		name : 'cmdtyCd',
		type :'string'
	},{
		name : 'cmdtyDesc',
		type :'string'
	},{
		name : 'itemNo',
		type :'string'
	},{
		name : 'vatFlg',
		type :'string'
	},{
		name : 'transactionType',
		type :'string'
	},{
		name : 'exchangeRate',
		type :'float'
	},{
		name : 'srvUnitQty',
		type :'float'
	},{
		name : 'blCmpDate',
		type :'string',
		convert:function(v){
			if(!Ext.isEmpty(v) && !Ext.isDate(v)){
				v =  new Date(v.split(' ')[0]);
			}
			return v;
		}
	},{
		name : 'porBerthCd',
		type :'string'
	},{
		name : 'porPortCall',
		type :'string'
	},{
		name : 'polBerthCd',
		type :'string'
	},{
		name : 'polPortCall',
		type :'string'
	},{
		name : 'podBerthCd',
		type :'string'
	},{
		name : 'podPortCall',
		type :'string'
	},{
		name : 'pfdBerthCd',
		type :'string'
	},{
		name : 'pfdPortCall',
		type :'string'
	},{
		name : 'prfInvcNo',
		type :'string'
	},{
		name : 'summId',
		type :'string'
	},{
		name : 'status',
		type :'string'
	},{
		name : 'itemSeqNo',
		type :'integer'
	},{
		name : 'refSummId',
		type :'string'
	},{
		name : 'originalInvcNum',
		type :'string'
	}]
});

Ext.define('oceanCstmrInvcEntryTaxGridModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'taxType',
		type :'string'
	},{
		name : 'taxPercentage',
		type :'string',
		mandatory:true
	},{
		name : 'serviceAmt',
		type :'string'
	},{
		name : 'taxAmt',
		type :'string',
		mandatory:true
	}],
	belongsTo: 'oceanCstmrInvcEntryPGGridModel'
});


Ext.define('OcnSuplrCOntractIdLov',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'contractId'
		},
		{
		  name:'supplrCd'
		},
		{
			name:'validFromDate'
		},
		{
			name:'validToDate'
		},
		{
			name:'remarks'
		}
		]
});


Ext.define('oceanSupplierRatesRetrive',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCd',
		type:'string'
	},{
		name:'intcontractId',
		type:'string'
	},{
		name:'contractId',
		type:'string',
		mandatory:true
	},{
		name:'supplier',
		type:'string',
		mandatory:true	
	},{
		name:'supplierName',
		type:'string'
	},{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y',
		mandatory:true
	},{
		name:'remark',
		type:'string'
	},{
		name:'trnsType',
		type:'string'
	},{
		name:'srvEffeDtEnbFlg',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	}],
	hasMany: {
	       model:'oceanSupplierRatesDtlsGrid', 
	       name: 'suplierRateDtls'
	    }
	
});
Ext.define('oceanSupplierRatesDtlsGrid',{
	extend:'Ext.data.Model',
	fields:[{
		name:'intcontractId'
	},{
			name:'contractId'
	},{
		name:'chargeCode',
		mandatory:true
	},{
		name:'party'
	},{
		name:'validFromDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'validToDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name:'pol'
	},{
		name:'pod'
	},{
		name:'cargoType'
	},{
		name:'cargoClass'
	},{
		name:'makeCode'
	},{
		name:'model'
	},{
		name:'polCity'
	},{
		name:'polStateProv'
	},{
		name:'polCntry'
	},{
		name:'podCity'
	},{
		name:'podStateProv'
	},{
		name:'podCntry'
	},{
		name:'por'	
	},{
		name:'pfd'
	},{
		name:'notChrgble',
		type: 'bool',
     	convert:function(v){
     		return (v === "Y" || v === true || "") ? true : false;
     	}
	},{
		name:'factorValue'
	},{
		name:'factorType'
	},{
		name:'factorRate'
	},{
		name:'fixedRate'
	},{
		name:'tariffRate'
	},{
		name:'luInd'
	},{
		name:'tariffCrncyCd'
	},{
		name:'priority'
	},{
		name:'seqNo'
	},{
		name:'trnsType'
	}],
	belongsTo: 'oceanSupplierRatesRetrive'
});


Ext.define('ocnCstmrRateHdrGridModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'intSpecialAgrmtNo',
		      type:'integer'
	        },
	        {
	        	name:'contractId',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'validFrmDt',
	        	type:'date',
	        	mandatory:true,
	        	dateFormat:'d/m/Y'
	        },
	        {
	        	name:'validToDt',
	        	type:'date',
	        	mandatory:true,
	        	dateFormat:'d/m/Y'
	        },
	        {
	        	name:'party',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'partyNm',
	        	type:'string'
	        },
	        {
	        	name:'pop',
	        	type:'string'
	        },
	        {
	        	name:'remark',
	        	type:'string'
	        },
	        {
	        	name:'srvcLvlValidDt',
	        	type:'bool',
	         	convert:function(v)
	        	 {

	        	return (v === "Y" || v === true || v === "") ? true : false;

	        	
	        	 }
	        },
	        {
	        	name:'transType',
	    		type:'string'
	        },
	        {
	        	name:'companyCode',
	        	type:'string'
	        }
	        ]
});


Ext.define('ocnRateBasisModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'rateBasisDesc',
		      type:'string'
	        },
	        {
	        	name:'rateBasisCode',
	        	type:'string'
	        }
	        ]
});

Ext.define('ocnCstmrRateDtlsGridModel',{
	extend:'Ext.data.Model',
	fields:[
             {
	            name:'companyCode',
	            type:'string'
            },
	        {
	        	name:'seqno',
	        	type:'integer'
	        },
	        {
	        	name:'transType',
	        	type:'string'
	        },
	        {
	        	name:'intSpecialAgrmtNo',
	        	type:'integer'
	        },
	        {
	        	name:'pop',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'serviceCode',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'serviceCdDesc',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'supplier',
	        	type:'string'
	        },
	        {
	        	name:'freightTerm',
	        	type:'string'
	        },
	        {
	        	name:'cargoClass',
	        	type:'string'
	        },
	        {
	        	name:'cargoType',
	        	type:'string'
	        },
	        {
	        	name:'vesselType',
	        	type:'string'
	        },
	        {
	        	name:'make',
	        	type:'string'
	        },
	        {
	        	name:'model',
	        	type:'string'
	        },
	        {
	        	name:'type',
	        	type:'integer'
	        },
	        {
	        	name:'pol',
	        	type:'string'
	        },
	        {
	        	name:'pod',
	        	type:'string'
	        },
	        {
	        	name:'por',
	        	type:'string'
	        },
	        {
	        	name:'pfd',
	        	type:'string'
	        },
	        {
	        	name:'rateBasis',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'rate',
	        	type:'integer',
	        	mandatory:true
	        },
	        {
	        	name:'currencyCode',
	        	type:'string',
	        	mandatory:true
	        },
	        {
	        	name:'dateEffective',
	        	type:'date',
	        	dateFormat:'d/m/Y',
	        	mandatory:true
	        	 
	        },
	        {
	        	name:'dateExpires',
	        	type:'date',
	        	dateFormat:'d/m/Y',
	        	mandatory:true
	        },
	        {
	        	name:'priority',
	        	type:'integer'
	        },
	        {
	        	name:'seqno',
	        	type:'integer'
	        },
	        {
	        	name:'commodityCd',
	        	type:'string'
	        },
	        {
	        	name:'commodityDesc',
	        	type:'string'
	        }
	        ]
});

Ext.define('OcnContractIDModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'systemContractNo',
		type:'string'
	},	
	{
		name:'customerCode',
		type:'string'	
	},
	{
		name:'validFromDate',
		type:'string'
	},
	{
		name:'validToDate',
		type:'string'
	},
	{
		name:'remark',
		type:'string'
	}]
});


Ext.define('OceanSupplierRateQueryServiceCodeDTO',{
	extend : 'Ext.data.Model',
	fields:[{
		name : 'supplier'
	},{
		name: 'supplierName'
	},{
		name: 'chargeCode'
	},{
		name: 'contractId'
	},{
		name: 'polCode'
	},{
		name: 'podCode'
	},{
		name: 'cargoType'
	},{
		name: 'polCity'
	},{
		name: 'polState'
	},{
		name: 'podCity'
	},{
		name: 'podState'
	},{
		name: 'por'
	},{
		name: 'pfd'
	},{
		name: 'cargoClass'
	},{
		name: 'makeCode'
	},{
		name: 'modelCode'
	},{
		name: 'steering'
	},{
		name: 'hazardous'
	},{
		name: 'handlingIndicator'
	},{
		name: 'transferGear'
	},{
		name: 'party'
	},{
		name: 'validFromDate'
	},{
		name: 'validToDate'
	},{
		name: 'polCountry'
	},{
		name: 'podCountry'
	},{
		name: 'notChargeable'
	},{
		name: 'factorValue'
	},{
		name: 'factorType'
	},{
		name: 'factorRate'
	},{
		name: 'fixedRate'
	},{
		name: 'tariffRate'
	},{
		name: 'luInd'
	},{
		name: 'tariffCurrencyCode'
	},{
		name: 'priority'
	},{
		name: 'seqNo'
	}]
});

Ext.define('OceanSupplierRateVerificationDTO',{
	extend : 'Ext.data.Model',
	fields:[{
		name : 'carrier'
	},{
		name: 'carrierName'
	},{
		name: 'chargeCode'
	},{
		name: 'polCode'
	},{
		name: 'podCode'
	},{
		name: 'cargoType'
	},{
		name: 'polCity'
	},{
		name: 'polState'
	},{
		name: 'podCity'
	},{
		name: 'podState'
	},{
		name: 'por'
	},{
		name: 'pfd'
	},{
		name: 'cargoClass'
	},{
		name: 'makeCode'
	},{
		name: 'modelCode'
	},{
		name: 'steering'
	},{
		name: 'hazardous'
	},{
		name: 'handlingIndicator'
	},{
		name: 'transferGear'
	},{
		name: 'party'
	},{
		name: 'validFromDate'
	},{
		name: 'validToDate'
	},{
		name: 'type'
	},{
		name: 'polCountry'
	},{
		name: 'podCountry'
	},{
		name: 'notChargeable'
	},{
		name: 'factorValue'
	},{
		name: 'factorType'
	},{
		name: 'factorRate'
	},{
		name: 'fixedRate'
	},{
		name: 'tariffRate'
	},{
		name: 'luInd'
	},{
		name: 'tariffCurrencyCode'
	},{
		name: 'priority'
	},{
		name: 'seqNo'
	},{
		name: 'contractId'
	}]
});

Ext.define('OceanCustomerRateVerificationDTO',{
	extend : 'Ext.data.Model',
	fields:[{
		name : 'popCode'
	},{
		name : 'contractId'
	},{
		name: 'chrgCdDesc'
	},{
		name: 'debtorPty'
	},{
		name: 'carrierCd'
	},{
		name: 'rateTier'
	},{
		name: 'polCode'
	},{
		name: 'podCode'
	},{
		name: 'makeCode'
	},{
		name: 'modelCode'
	},{
		name: 'modelYr'
	},{
		name: 'modelGrpCd'
	},{
		name: 'por'
	},{
		name: 'pfd'
	},{
		name: 'freightTrmsCode'
	},{
		name: 'cargoClass'
	},{
		name: 'cargoType'
	},{
		name: 'vesselType'
	},{
		name: 'cmdtyCd'
	},{
		name: 'cmdtyDesc'
	},{
		name: 'rateBasis'
	},{
		name: 'rate'
	},{
		name: 'markUp'
	},{
		name: 'dateEffective'
	},{
		name: 'dateExpires'
	},{
		name: 'priority'
	}]
});

Ext.define('OceanSupplierRemitDtlsParentGridModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'paymentNumber',
		type:'string'
	},{
		name:'supplierID',
		type:'string'	
	},{
		name:'invoiceNumber',
		type:'string'
	},
	{
		name:'invoiceDate',
		type:'string'
	},{
		name:'payMode',
		type:'string'
	},{
		name:'payDocument',
		type:'string'
	},{
		name:'payDate',
		type:'string'
	},{
		name:'paidAmount',
		type:'float'
	},{
		name:'currency',
		type:'string'
	},{
		name: 'invoiceAmount',
		type:'string'
	},
	{
		name: 'prfinvoiceNumber',
		type: 'string'
	}]
});

Ext.define('OceanSupplierRemitDtlsChildGridModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'companyCode',
		type:'string'
	},{
		name:'serviceCode',
		type:'string'	
	},{
		name:'voyage',
		type:'string'
	},
	{
		name:'vessel',
		type:'string'
	},{
		name:'pol',
		type:'string'
	},{
		name:'pod',
		type:'string'
	},{
		name:'blno',
		type:'string'
	},{
		name:'deliveryDate',
		type:'string'
	},{
		name:'paidAmount',
		type:'float'
	},{
		name:'currency',
		type:'string'
	},{
		name:'overrideRejectComment',
		type:'string'
	},
	{
		name: 'invoicecurrency',
		type: 'string'
	},
	{
		name: 'approvedinvoicecurrency',
		type: 'string'
	}]

});



Ext.define('OcnInvoiceNumberLookUpDTO',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'invc_no',
		  type:'string'
		},
		{
		  name:'invc_crdt_dttm',
		  type :'string'
		},
		{
			name:'invc_due_dttm',
			type :'string'
		},
		{
			name:'cstmr_cd',
			type:'string'
		},
		{
			name:'supplier_cd',
			type:'string'
		},{
			name:'cmpny_cd',
			type:'string'
		}
		]
});

Ext.define('oceanCstmrApplcAdviceGP',{
	extend:'Ext.data.Model',
	fields:[
	    {
		  name:'cstmr_cd',
		  type:'string'
		},
		/*{
		  name:'partyPayer',
		  type :'string'
		},*/
		{
			name:'supplier_cd',
			type :'string'
		},
		{
			name:'voy_no',
			type:'string'
		},
		{
			name:'invc_no',
			type :'string'
		},
		{
			name:'invc_crdt_dttm',
			//type:'string'
			type:'date',
			dateFormat:'d/m/Y'
		},
		{
			name:'invc_crdt_note_ind',
			type:'string'
		},
		{
			name:'tot_invc_amt_local_crncy',
			type:'float'
		},
		{
			name:'local_crncy_cd',
			type:'string'
		},
		{
			name:'prf_invc_no',
			type:'integer'
		},
		{
			name:'cnsldt_flg',
			type:'string'
		},
		{
		  name:'cmpny_cd',
		  type:'string'
		},
		{
			name:'cstmr_nm',
			type :'string'
		},
		{
			name:'prf_sts',
			type:'string'
		},
		{
			name:'invc_due_dttm',
			type:'date',
			dateFormat:'d/m/Y'
		},
		{
			name:'ref_invc_no',
			type:'string'
		},
		{
			name:'dbtr_pty_addr_1',
			type:'string'
		},
		{
			name:'dbtr_pty_addr_2',
			type:'float'
		},
		{
			name:'dbtr_pty_addr_3',
			type:'string'
		},
		{
			name:'dbtr_city_nm',
			type:'string'
		},
		{
			name:'dbtr_state_cd',
			type:'string'
		},
		{
			name:'dbtr_cntry_cd',
			type:'string'
		},
		{
			name:'dbtr_po_box',
			type:'string'
		},
		{
			name:'cstmr_ack_rcvd_flg',
			type:'string'
		},
		{
			name:'prf_estm_ind',
			type:'string'
		},
		{
			name:'cost_cntr_cd',
			type:'string'
		},
		{
			name:'invc_print_templt_cd',
			type:'string'
		},
		{
			name:'pop_cd',
			type:'string'
		},
		{
			name:'cstmr_contact_prsn_nm',
			type:'string'
		},
		{
			name:'sailing_dttm',
			type:'date',
			dateFormat:'d/m/Y'
		}
		]
});

Ext.define('ocnCstmrApplAdvcPGModel',{
	extend:'Ext.data.Model',
	fields:[{
		name:'invc_no',
		type :'string'
	    },
		{
			name:'invc_crdt_note_ind',
			type:'string'
		},
	    {
		  name:'srv_type',
		  type:'string'
		},
		{
		  name:'srv_cd',
		  type :'string'
		},
		{
			name:'srv_grp_cd',
			type :'string'
		},
		{
			name:'bl_no',
			type:'string'
			//dateFormat:'d/m/Y'
		},
		{
			name:'vsl_nm',
			type:'string'
		},
		{
			name:'freightterm_cd',
			type:'string'
		},
		{
			name:'shipmnt_ref_no',
			type:'string'
		},
		{
		  name:'pol_cd',
		  type :'string'
		},
		{
			name:'pod_cd',
			type :'string'
		},
		{
			name:'por_cd',
			type:'string'
		},
		{
			name:'pfd_cd',
			type:'string'
		},
		{
			name:'make_cd',
			type:'string'
		},
		{
			name:'model_cd',
			type:'string'
		},
		{
			name:'model_year',
			type:'integer'
		},
		{
		  name:'bl_cmplt_dttm',
		  type :'date',
		  dateFormat:'d/m/Y'
		},
		{
			name:'manfst_crncy_cd',
			type:'string'
		},
		{
			name:'srv_amt_manfst_crncy',
			type:'float'
		},
		{
			name:'local_crncy_cd',
			type:'string'
		},
		{
			name:'srv_amt_local_crncy',
			type:'float'
		},
		{
			name:'srv_amt_usd_crncy',
			type:'float'
		},
		{
			name:'prf_invc_no',
			type:'integer'
		},
		{
			name:'invc_item_no',
			type:'integer'
		},
		{
			name:'summ_id',
			type:'integer'
		},
		{
			name:'cstmr_item_ack_rcvd_flg',
			type:'string'
		},
		{
			name:'cmpny_cd',
			type:'string'
		},
		{
			name:'cstmr_cd',
			type:'string'
		},
		{
			name:'srv_descr',
			type:'string'
		},
		{
			name:'int_bl_no',
			type:'integer'
		},
		{
			name:'item_seq_no',
			type:'integer'
		},{
			name:'cstmr_evnt_ack_rcvd_flg',
			type:'string'
		},{
			name:'status',
			type:'string'
		}
		
		],
		hasMany: {
		       model:'ocnCstmrApplAdvcPGModel', 
		       name: 'ocnCstmrApplAdvcChildGridResult'
		    }
});


Ext.define('OceanCustomerInvoiceLineItemStatus',{
	extend : 'Ext.data.Model',
	fields:[
		{ name : 'company',type:'string'},
		{ name : 'pop',type:'string'},
		{ name : 'serviceType',type:'string'},
		{ name : 'party',type:'string'},
		{ name : 'partyName',type:'string'},
		{ name : 'billNumber',type:'string'},
		{ name : 'invoiceNumber',type:'string'},
		{ name : 'voyage',type:'string'},
		{ name : 'chargeCode',type:'string'},
		{ name : 'pol',type:'string'},
		{ name : 'pod',type:'string'},
		{ name : 'documentReference',type:'string'},
		{ name : 'shippingReference',type:'string'},
		{ name : 'documentType',type:'string'},
		{ name : 'invoiceType',type:'string'},
		{ name : 'invoiceStatusDesc',type:'string'},
		{ name : 'invoiceStatus',type:'string'},	
		{ name : 'vessel',type:'string'},
		{ name : 'manifestCurrency',type:'string'},
		{ name : 'manifestAmount',type:'float',useNull : true},
		{ name : 'invoiceCurrency',type:'string'},
		{ name : 'invoiceAmount',type:'float',useNull : true},
		{ name : 'usdEquivalentAmount',type:'float'},
		{ name : 'paidAmount',type:'float',useNull : true},
		{ name : 'invoiceFromDate',dateFormat:'d/m/Y',type:'date'},
		{ name : 'lastPaymentDate',type:'string'},
		{ name : 'reason',type:'string'},
		{ name : 'invoiceToDate',dateFormat:'d/m/Y',type:'date'},	
		{ name : 'billCompletionDate',dateFormat:'d/m/Y',type:'date'},
		{ name : 'invoiceDate',dateFormat:'d/m/Y',type:'date'},
		{ name : 'dueDate',dateFormat:'d/m/Y',type:'date'},
		{name  : 'documentTypeDesc',type:'string'},
		{name  : 'invoiceTypeDesc',type:'string'},
		{
			name  : 'consolidatedFlag',
			type: 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}
		},
		{name  : 'proformaInvcNo'},
		{
			name : 'headerClause',
			type :'string'
		},{
			name : 'proformaUserName',
			type :'string'
		},{
			name : 'proformaDate',dateFormat:'d/m/Y H:i:s',type:'date'
		},{
			name : 'finalizeUserName',
			type :'string'
		},{
			name : 'finalizeDate',dateFormat:'d/m/Y H:i:s',type:'date'
		},{
			name : 'extPrfInvcNo',
			type :'string'
		}		
	]
});

Ext.define('supplierInvoiceStatusOceanDTO', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd'
	},{
		name : 'supplier'
	},{
		name : 'invoiceNumber'
	},{
		name : 'invoiceFromDate',
		type : 'date',
		dateFormat:'d/m/Y H:i:s'
	},{
		name : 'invoiceToDate',
		type : 'date',
		dateFormat:'d/m/Y H:i:s'
	},{
		name : 'documentType'
	},{
		name : 'invoiceType'
	},{
		name : 'invoiceAmt'
	},{
		name : 'paidAmt'
	},{
		name : 'approvedAmt'
	},{
		name : 'currency'
	},{
		name : 'dueDate',
		type : 'date',
		dateFormat:'d/m/Y H:i:s' 
	},{
		name : 'lastPaymentDate',
		type : 'date',
		dateFormat:'d/m/Y H:i:s'
	},{
		name : 'invoiceStatusDesc'
	},{
		name : 'invoiceStatus'
	},{
		name : 'prfinvcno'
	},{
		name : 'supplierDocumentList'
	},{
		name : 'supplierInvoiceStatusList'
	},{
		name : 'ldRefNo'
	},{
		name : 'conveyanceId'
	},{
		name : 'shippingRefNo'
	},{
		name : 'refInvNo'
	},{
		name : 'reCalcDttmFlg'
	},{
		name : 'creditDate',
		type : 'date',
		dateFormat:'d/m/Y H:i:s'
		
	},{
		name : 'documentTypeDesc'
	},{
		name : 'crdtterm'
	}
	
	]
});



Ext.define('CargoClassModel',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'code',
		      type:'string'
	        },
	        {
	        	name:'name',
	        	type:'string'
	        }
	        ]
});

Ext.define('OceanCustomerPaymentDetailsFormDto',{
	extend:'Ext.data.Model',
	fields:[
	
     {
        name : 'companyCd',
		type : 'string'
	   },

	{

		name : 'party',
		type : 'string'
	},{
		name:'blNumber',
		type:'string'
	},
	{
		name:'invoiceNumber',
		type:'string'
	},{
		name:'paymentFromDate',
		type:'string'	
	},{
		name:'paymentToDate',
		type:'string'
	},
	{
		name:'modeofPayment',
		type:'string'
	},{
		name:'invoiceFromDate',
		type:'string'	
	},{
		name:'invoiceToDate',
		type:'string'
	},
	{
		name:'paymentDocument',
		type:'string'
	},{
		name:'serviceType',
		type:'string'	
	},{
		name:'voyage',
		type:'string'
	},
	{
		name:'vessel',
		type:'string'
	},
	{
		name:'serviceCode',
		type:'string'
	},
	
	{
		name:'shippingReference',
		type:'string'
	}
	]
	
});
Ext.define('OceanCustomerPaymentDetailsHeaderDto',{
	extend:'Ext.data.Model',
	fields:[
 	    
	 {
		name : 'customer',
		type : 'string'
	},{
		name:'invoiceNumber',
		type:'string'
	},
	{
		name:'invoiceDate',dateFormat:'d/m/Y',type:'date'
	},{
		name:'modeOfPayment',
		type:'string'	
	},{
		name:'paymentDocument',
		type:'string'
	},
	{
		name:'paymentDate',dateFormat:'d/m/Y',type:'date'
	},{
		name:'paidAmount',
		type:'float',
		useNull : true
	},{
		name:'invoiceCurrency',
		type:'string'
	},
	{
		name:'remittanceType',
		type:'string'
	},{
		name:'manifestCurrency',
		type:'string'	
	},{
		name:'manifestAmount',
		type:'float',
		useNull : true
	},
	{
		name:'pop',
		type:'string'
	},
	{
		name:'usdEqvAmount',
		type:'float',
		useNull : true
	},
	{
		name:'intpaymentNo',
		type:'integer'
	},
	{
		name:'companyCode',
		type:'string'
	},
	{
		name:'rfcInvoiceNo',
		type:'string'
	},
	{
		name:'voyage',
		type:'string'
	}
	
	
	]
	
});



Ext.define('oceanCustomerPaymentDetailsChaildDto',{
	extend:'Ext.data.Model',
	fields:[
  {
       name:'blNo',
		type:'string'
	},
	 {
		name:'voyage',
		type:'string'	
	},
	 {
		name:'chargeCd',
		type:'string'	
	},{
		name:'chargeCdDes',
		type:'string'
	},
	{
		name:'freightTrms',
		type:'string'
	},{
		name:'vesselCd',
		type:'string'	
	},{
		name:'blcmplDate',dateFormat:'d/m/Y',type:'date'
	},
	{
		name:'paidAmt',type:'float',
		useNull : true
	},{
		name:'invCurncy',
		type:'string'	
	},
	
	{
		name:'detmanifestCurrency',
		type:'string'	
	},
	{
		name:'detmanifestAmount',type:'float',
		useNull : true
	},
	{
		name:'detusdEqvAmount',type:'float',
		useNull : true
	},
	{
		name:'detintpaymentNo',
		type:'string'	
	}
	
	
	
	
	]
});


Ext.define('OceanSuppLineItemStatusModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'carrier',
		type:'string'
	}, {
		name : 'invoiceNumber',
		type:'string'
	},{
		name : 'invoiceDate'
	},{
		name : 'dueDate'
	},{
		name : 'chargeCode',
		type:'string'
	},{
		name : 'invoiceAmount',
		type:'float'
	},{
		name : 'approvedAmount',
		type:'float'
	},{
		name : 'paidAmount',
		type:'float'
	},{
		name : 'currency'
	},{
		name : 'blNumber',
		type: 'string'
	},{
		name : 'voyage',
		type: 'string'
	},{
		name : 'vessel',
		type: 'string'
	},{
		name : 'deliveryCompletionDate'
	},{
		name : 'pol'
	},{
		name : 'pod'
	},{
		name : 'lastPaymentDate'
	},{
		name : 'lineItemStatus'
	},{
		name : 'reason'
	}]
});
Ext.define('ocnCstmrReconciliationModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd',
		type : 'string'
	},{
		name : 'cstmr_cd',
		type : 'string'
	},{
		name : 'cstmr_nm',
		type : 'string'
	},{

		name : 'supplier_cd',
		type : 'string'
	}, {
		name : 'pop',
		type : 'string'
	}, {
		name : 'srv_cd',
		type : 'string'
	}, {
		name : 'srv_descr',
		type : 'string'
	}, {
		name : 'voy_no',
		type : 'string'
	}, {
		name : 'vsl_cd',
		type : 'string'
	//dateFormat:'d/m/Y'
	}, {
		name : 'freightterm_cd',
		type : 'string'
	}, {
		name : 'bl_no',
		type : 'string'
	}, {
		name : 'pol_cd',
		type : 'string'
	}, {
		name : 'pod_cd',
		type : 'string'
	}, {
		name : 'por_cd',
		type : 'string'
	}, {
		name : 'pfd_cd',
		type : 'string'
	}, {
		name : 'shipmnt_ref_no',
		type : 'string'
	}, {
		name : 'bl_cmplt_dttm',
		type : 'date',
//		convert : function(v) {
//			/*if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
//				v = new Date(v.split(' ')[0]);
//			}*/
//			return v;
//		},
		dateFormat : 'd/m/Y'
	}, {
		name : 'sailing_dttm',
		type : 'date',
//		convert : function(v) {
//			/*if (!Ext.isEmpty(v) && !Ext.isDate(v)) {
//				v = new Date(v.split(' ')[0]);
//			}*/
//			return v;
//		},
		dateFormat : 'd/m/Y'
	}, {
		name : 'cst_item_srv_amt_manfst_crncy', //manifest Amount cst_item_srv_amt_local_crncy
		type : 'float'
	}, {
		name : 'cst_item_manfst_crncy_cd', //manifest currency code  cst_item_local_crncy_cd
		type : 'string'
	}, {
		name : 'cst_item_exchng_rate',
		type : 'float'
	}, {
		name : 'cst_item_srv_amt_local_crncy', //invoice amount
		type : 'float'
	}, {
		name : 'cst_item_local_crncy_cd',  //Invoice Currency  cst_item_srv_amt_usd_crncy
		type : 'string'
	}, {
		name : 'cst_item_srv_amt_usd_crncy',  //srv_amt_usd_crncy
		type : 'string'
	}, {
		name : 'cstmr_reject_reason',
		type : 'String'
	}, {
		name : 'int_bl_no',
		type : 'integer'
	}, {
		name : 'item_seq_no',
		type : 'integer'
	}, {
		name : 'cstmr_int_spl_agmt_no',
		type : 'integer'
	}, {
		name : 'cst_man_rate_flg',
		type : 'string'
	}, {
		name : 'contract_id',
		type : 'integer'
	}, {
		name : 'revn_cd',
		type : 'string'
	}, {
		name : 'srv_grp_cd',
		type : 'string'
	} ]
});
Ext.define('OceanEventRatingQuery',{
	extend : 'Ext.data.Model',
	fields : [
		{ name : 'lineNumber' , type : 'string'},
		{ name : 'intBlNumber' , type : 'string'},
		{ name : 'intItemNumber' , type : 'string'},
		{ name : 'blNumber' , type : 'string'},
		{ name : 'cargoClass' , type : 'string'},
		{ name : 'cargoType' , type : 'string'},
		{ name : 'lineItemQty' , type : 'float'},
		{ name : 'pop' , type : 'string'},
		{ name : 'popDesc' , type : 'string'},
		{ name : 'freightTerm' , type : 'string'},
		{ name : 'commodityDesc' , type : 'string'},
		{ name : 'chargeCode' , type : 'string'},
		{ name : 'chargeCodeDesc' , type : 'string'},
		{ name : 'make' , type : 'string'},
		{ name : 'model' , type : 'string'},
		{ name : 'modelName' , type : 'string'},
		{ name : 'modelYear' , type : 'string'},
		{ name : 'vessel' , type : 'string'},
		{ name : 'voyage' , type : 'string'},
		{ name : 'party' , type : 'string'},
		{ name : 'partyName' , type : 'string'},
		{ name : 'pol' , type : 'string'},
		{ name : 'pod' , type : 'string'},
		{ name : 'por' , type : 'string'},
		{ name : 'pfd' , type : 'string'},
		{ name : 'sailingDate' , type : 'string'},
		{ name : 'postCollectChargeFlg' , type : 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}			
		},
		{ name : 'blCompleteFlg' , type : 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}			
	     },
		{ name : 'blCompleteDate' , type : 'string'},
		{ name : 'custRate' , type : 'float'},
		{ name : 'custRateBasis' , type : 'string'},
		{ name : 'custManifestCurrency' , type : 'string'},
		{ name : 'custManifestAmount' , type : 'float'},
		{ name : 'custExchangeRate' , type : 'float'},
		{ name : 'custLocalCurrency' , type : 'string'},
		{ name : 'custLocalAmount' , type : 'float'},
		{ name : 'custUsdAmount' , type : 'float'},
		{ name : 'custNotChargeable' , type: 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}
		},
		{ name : 'custInvoiceNumber' , type : 'string'},
		{ name : 'custStatus' , type : 'string'},
		{ name : 'suppRate' , type : 'string'},
		{ name : 'suppRateBasis' , type : 'string'},
		{ name : 'suppManifestCurrency' , type : 'string'},
		{ name : 'suppManifestAmount' , type : 'string'},
		{ name : 'suppExchangeRate' , type : 'string'},
		{ name : 'suppLocalCurrency' , type : 'string'},
		{ name : 'suppLocalAmount' , type : 'string'},
		{ name : 'suppUsdAmount' , type : 'string'},
		{ name : 'suppNotChargeable' , type: 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}
		},
		{ name : 'suppInvoiceNumber' , type : 'string'},
		{ name : 'make' , type : 'string'},
		{ name : 'model' , type : 'string'},
		{ name : 'modelName' , type : 'string'},
		{ name : 'modelYear' , type : 'string'},		
		{ name : 'suppStatus' , type : 'string'},
		{ name : 'serviceGroup' , type : 'string'},
		{ name : 'shipmentRefNumber' , type : 'string'},
		{ name : 'consolidateFlg' , type : 'string'}]
});

Ext.define('OceanEventRatingCargoDetails',{
	extend : 'Ext.data.Model',
	fields :[
		{ name : 'cargoId' , type : 'string'},
		{ name : 'cargoBarcode' , type : 'string'},
		{ name : 'weight' , type : 'float'},	
		{ name : 'weightUom' , type : 'string'},
		{ name : 'cargoLength',mapping:'length' , type : 'float'},
		{ name : 'dimensionUom' , type : 'string'},
		{ name : 'width' , type : 'float'},
		{ name : 'height' , type : 'float'},
		{ name : 'volume' , type : 'float'},
		{ name : 'cube' , type : 'float'},
		{ name : 'quantity' , type : 'float'},
		{ name : 'handlingIndicator' , type : 'string'},
		{ name : 'transferGear' , type : 'string'},
		{ name : 'steering' , type : 'string'},
		{ name : 'hazardous' , type: 'bool',
	     	convert:function(v){
	     		return (v === "Y" || v === true || "") ? true : false;
	     	}
		}
	]
});

Ext.define('oceanCustomerRateQueryServiceCodeDTO', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'companyCode',
		type:'string'
	},{
		name : 'companyNm',
		type:'string'
	},{
		name : 'pop'
	},{
		name : 'popDesc',
		type:'string'
	},{
		name : 'party'
	},{
		name : 'partyName'
	},{
		name : 'contractId'
	},{
		name : 'chargeCode'
	},{
		name : 'startDate'
	},{
		name : 'endDate'
	},{
		name : 'chargeCodeDesc'
	},{
		name : 'polCd'
	},{
		name : 'podCd'
	},{
		name : 'makeCode'
	},{
		name : 'modelCd'
	},{
		name : 'modelYear'
	},{
		name : 'por'
	},{
		name : 'pfdCd'
	},{
		name : 'freightTerms'
	},{
		name : 'cargoClass'
	},{
		name : 'cargoType'
	},{
		name : 'vesselType'
	},{
		name : 'commodityDesc'
	},{
		name : 'commodityCode'
	},{
		name : 'tariffRate'
	},{
		name : 'rateBasis'
	},{
		name : 'trfCrncyCd'
	},{
		name : 'dateEffective'
	},{
		name : 'priority'
	},{
		name : 'dateExpires'
	},{
		name : 'carrier'
	}]

});


Ext.define('GenMasterCarrierDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'carrierCode',
	          type:'string'
	        }
	       ]
	
});
Ext.define('OcnGenMasterPortsDetailDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'portCode',
	          type:'string'
	        },
			
			{
	          name:'berthCode',
	          type:'string'
	        },
			{
	          name:'portType',
	          type:'string'
	        },
			{
	          name:'eta',
	          type:'string'
	        },
			{
	          name:'etd',
	          type:'string'
	        },
	        {
	    		name : 'atadttm',
	    		type : 'string'	    		

	    	},
	    	{
	    		name : 'atddtm',
	    		type : 'string'
	    		

	    	},
	    	
	    	{
	    		name : 'portCall',
	    		type : 'string'
	    		

	    	}
	    	
		
	       ]
	
});
Ext.define('OcnGenMasterVoyageCurrencyGridDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'currencyCode',
	          type:'string'
	        },
			
			{
	          name:'exchangeRate',
	          type:'float'
	        }
		
	       ]
	
});

Ext.define('VoyagePortsCurrencyGridDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'portCode',
	          type:'string'
	        },
			
			{
	          name:'currencyCode',
	          type:'string'
	        },
			{
	          name:'exchangeRate',
	          type:'float'
	        },
	        {
		         name:'portType',
		         type:'string'
		        }
		
	       ]
	
});
Ext.define('OceanVoyageMasterFormDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'voyageNumber',
	          type:'string'
	        },
			
			{
	          name:'voyageCurrencyCode',
	          type:'string'
	        },
			{
	          name:'routCode',
	          type:'string'
	        },
			
			
			
			{
	          name:'vesselCode',
	          type:'string'
	        },
			
			{
	          name:'vesselName',
	          type:'string'
	        },
			{
	          name:'originalSIte',
	          type:'string'
	        },
	        {
		     name:'companyCode',
		     type:'string'
		     }
			
	        
			
		
	       ]
	
});

Ext.define('ocnVndrInvcTemplateModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'companyCd',
		type : 'string'
	},{
		name : 'prfInvcNum',
		type : 'string'
	},
	 {
		name:'supplier',
		type:'string'	
	},
	 {
		name : 'supplierName',
		type : 'string'
	},{

		name : 'invcNum',
		type : 'string'
	}, {
		name : 'invcDate',
		type:'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'invcDueDate',
		type:'date',
		dateFormat:'d/m/Y'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'refInvcNum',
		type : 'string'
	}, {
		name : 'status',
		type : 'string',
		convert:function(v){
			
			if(v=='P'){				
				return "PROFORMA";
			}
			if(v=='S'){				
				return "READY FOR RECONCILE";
			}
			if(v=='R'){				
				return "RECONCILED";
			}
			if(v=='A'){				
				return "APPROVED";
			}
			if(v=='C'){				
				return "CANCELLED";
			}
			if(v=='U'){				
				return "UNDER INVESTIGATION";
			}
			if(v=='D'){				
				return "PAID";
			}
			return v;
		}
	//dateFormat:'d/m/Y'
	},{
		name : 'docType',
		type : 'string'
	},{
		name : 'party',
		type : 'string'
	}, {
		name : 'partyName',
		type : 'string'
	}, {
		name : 'addr1',
		type : 'string'
	}, {
		name : 'addr2',
		type : 'string'
	}, {
		name : 'city',
		type : 'string'
	}, {
		name : 'state',
		type : 'string'
	}, {
		name : 'cntry',
		type : 'string'
	}, {
		name : 'zipPostalCd',
		type : 'string'
	}, {
		name : 'srvAmntInvcCurncy',
		type : 'float'
	},{
		name : 'trnsType',
		type : 'string'
	}
	,{
		name : 'queryType',
		type : 'string'
	}
	],
	hasMany: {
	    model:'SupplierInvoiceVendorInvoiceTemplateModel', 
	    name: 'dtlsList'
	 }
});











Ext.define('GenMasterStampClauseModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'popCountryCode',
		type : 'string'
	},
	 {
		name:'customerCode',
		type:'string'	
	},
	 {
		name : 'customerName',
		type : 'string'
	},{

		name : 'freightTermCode',
		type : 'string'
	}, {
		name : 'currencyCode',
		type : 'string'
		
	}, {
		name : 'polCountryCode',
		type : 'string'
		
	}, {
		name : 'podCountryCode',
		type : 'string'
	}, {
		name : 'effectiveDateTime',
		type : 'string'
	}, {
		name : 'clause',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	}, {
		name : 'companyCd',
		type : 'string'
	} ]
});


Ext.define('GenMasterHeaderClauseModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'popCountryCode',
		type : 'string'
	},
	 {
		name:'customerCode',
		type:'string'	
	},
	 {
		name : 'customerName',
		type : 'string'
	},{

		name : 'freightTermCode',
		type : 'string'
	}, {
		name : 'creditTerm',
		type : 'string'
		
	}, {
		name : 'effectiveDateTime',
		type : 'string'
	}, {
		name : 'clause',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	}, {
		name : 'companyCd',
		type : 'string'
	} ]
});


Ext.define('GenMasterGeneralClauseModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'popCountryCode',
		type : 'string'
	},{

		name : 'freightTermCode',
		type : 'string'
	}, {
		name : 'creditTerm',
		type : 'string'
		
	}, {
		name : 'effectiveDateTime',
		type : 'string'
	}, {
		name : 'clause',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	}, {
		name : 'companyCd',
		type : 'string'
	} ]
});

Ext.define('GenMasterVatClauseModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'popCountryCode',
		type : 'string'
	},{

		name : 'freightTermCode',
		type : 'string'
	}, {
		name : 'vatAmount',
		type: 'boolean'
			/*,convert:function(v)
   	    {
   	     return (v === "Y" || v === true || v === "") ? true : false;
        }*/
		
	}, {
		name : 'effectiveDateTime',
		type : 'string'
	}, {
		name : 'clause',
		type : 'string'
	} , {
		name : 'transType',
		type : 'string'
	}, {
		name : 'companyCd',
		type : 'string'
	} ]
});

Ext.define('OcenSupplierReconcileSetupQueryDTO',{
	extend:'Ext.data.Model',
	fields:[
	        {
	          name:'intReconcileNo',
	          type:'string'
	        },
			
			{
	          name:'supplierCd',
	          type:'string'
	        },
			{
	          name:'srvType',
	          type:'string'
	        },
			{
	          name:'srvCd',
	          type:'string'
	        },
			{
	          name:'cmpnyCd',
	          type:'string'
	        },
 	        {
		      name : 'status',
		       type : 'string'
           	},
             {
		name : 'transType',
		type : 'string'
	  }
        
	         ],
      	
		  
		   associations :[{
	   	type:'hasMany',
	   	model:'OcnSpplrReconileSetupTolerenceCriteriaDto', 
	   	//name: 'OcnreconcilationTolerenceCriteriaGridResult',
	   	name:'ocnToleranceList'
   },
   {
	   	type:'hasMany',
	   	model:'OcnSpplrReconileSetupMatchCriteriaDtls', 
	   	//name: 'OcnreconcilationMatchCriteriaDtlsGridResult',
	   	name:'ocnMatchingCriteriaList'
     }]
      	
      	
	        
	       
	
});

Ext.define('OcnSpplrReconileSetupTolerenceCriteriaDto',{
	extend:'Ext.data.Model',
	fields:[
	        
	        {
	    		name : 'intReconcileNo',
	    		type : 'string'
	    	}, {
	    		name : 'srvType',
	    		mandatory: true,
	    		type : 'string'
	    	}, {
	    		name : 'srvCd',
	    		mandatory: true,
	    		type : 'string'
	    	},
	    	 {
	    		name : 'status',
	    		type : 'string'
	          	},
			{
	          name:'crncyCd',
	          type:'string'
	        },
			{
	          name:'fmRange',
	          type:'string'
	        },
			{
	          name:'toRange',
	          type:'string'
	        },
	        

		   {
		name : 'cmpnyCd',
		type : 'string'
         	},
         	{
        		name : 'transType',
        		type : 'string'
        	  }
	        
	        
	        ],
	        belongsTo: 'OcenSupplierReconcileSetupQueryDTO'
	        
	        
	        
	        
	     
});

Ext.define('OcnSpplrReconileSetupMatchCriteriaDtls',{
	extend:'Ext.data.Model',
	fields:[
	
	 {
		name : 'intReconcileNo',
		type : 'string'
	}, {
		name : 'srvType',
		mandatory : true,
		type : 'string'
	}, {
		name : 'srvCd',
		mandatory : true,
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	}, {
		name : 'recPriority',
		mandatory: true,
		type : 'string'
	}, {
		name : 'blNoFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, 
	 {
		name : 'cargoIdenNo',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, 
	{
		name : 'voyNoFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'vslCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'polCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'podCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'crgTypeCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'crgClassCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'costCntrCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'modelCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},

	 {
		name : 'minCargoIdenNo',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, 
	
	
	{
		name : 'minBlNoFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minVoyNoFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minVslCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minPolCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minPodCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minCrgTypeCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minCrgClassCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minCostCntrCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	}, {
		name : 'minModelCdFlg',
		type : 'bool',
		convert : Modules.GlobalFuncs.stringToBooleanConvertor
	},

	{
		name : 'cmpnyCd',
		type : 'string'
	}, {
		name : 'transType',
		type : 'string'
	}
		        
	        ],
	        belongsTo:'OcenSupplierReconcileSetupQueryDTO'
	       
});
Ext.define('SupplierInvoiceVendorInvoiceTemplateModel', {
	extend : 'Ext.data.Model',
	fields : [
	{
		name : 'chargeCode',
		type : 'string'
	},          
	{
		name : 'bLNumber',
		type : 'string'
	},   
	{
		name : 'voyageNo',
		type : 'string'
	},            
	{
		name : 'vesselCode',
		type : 'string'
	},          
	       
	{
		name : 'pol',
		type : 'string'
	},
	{
		name : 'polCity',
		type : 'string'
	},
	{
		name : 'polState',
		type : 'string'
	},
	{
		name : 'pod',
		type : 'string'
	},          
	{
		name : 'podCity',
		type : 'string'
	},          
	{
		name : 'podState',
		type : 'string'
	},          
	{
		name : 'blCmplDate',
		type : 'date',
		dateFormat:'d/m/Y'
	},          
	{
		name : 'rate',
		type : 'string'
	},          
	{
		name : 'quantity',
		type : 'string'
	},           
	{
		name : 'rateBasis',
		type : 'string'
	},          
	{
		name : 'serviceAmount',
		type : 'Float'
	},
	{
		name : 'summId',
		type : 'integer'
	},
	{
		name : 'trnsType',
		type : 'string'
	},
	{
		name : 'invcItemno',
		type : 'integer'
	},
	{
		name : 'invcItemStatus',
		type : 'string'
	}
	]
});

Ext.define('OceangeneralMasterCompanyMaster', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'companyName',
		type : 'string'
	},{
		name : 'companyCode',
		type : 'string'
	},{
		name : 'defaultCurrency',
		type : 'string'
	},{
		name : 'name',
		type : 'string'
	}, {
		name : 'address1',
		type : 'string'
	}, {
		name : 'address2',
		type : 'string'
	}, {
		name : 'city',
		type : 'string'
	}, {
		name : 'state',
		type : 'string'
	}, {
		name : 'country',
		type : 'string'
	}, {
		name : 'postal',
		type : 'string'
	}, {
		name : 'teleNbr',
		type : 'string'
	}, {
		name : 'faxNbr',
		type : 'string'
	}, {
		name : 'email',
		type : 'string'
	},{
		name : 'arname',
		type : 'string'
	}, {
		name : 'araddress1',
		type : 'string'
	}, {
		name : 'araddress2',
		type : 'string'
	}, {
		name : 'arcity',
		type : 'arstring'
	}, {
		name : 'arstate',
		type : 'string'
	}, {
		name : 'arcountry',
		type : 'string'
	}, {
		name : 'arpostal',
		type : 'string'
	}, {
		name : 'arteleNbr',
		type : 'string'
	}, {
		name : 'arfaxNbr',
		type : 'string'
	}, {
		name : 'aremail',
		type : 'string'
	},
	{
		name : 'status',
		type: 'string'
	}]
});

Ext.define('OceanDashBoardPendingFinalization', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'pop',
		type : 'string'
	},
	 {
		name : 'voyage',
		type : 'string'
	},
	{
		name : 'carrier',
		type : 'string'
	}, {
		name : 'payer',
		type : 'string'
	},{
		name : 'payerNm',
		type : 'string'
	},{
		name : 'documentType',
		type : 'string'
	},
	{
		name : 'exceptionType',
		type : 'string'
	},
	 {
		name : 'localCurrency',
		type : 'string'
	},
	{
		name : 'localAmount',
		type : 'float'
	},
	 {
		name : 'amountUSD',
		type : 'float'
	}
	,
	 {
		name : 'numberOfInvoices',
		type : 'float'
	}
	
	]
});


Ext.define('OceanDashBoardSupplierInvStat', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'pymntTerm',
		type : 'integer'
	}, {
		name : 'status',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	}, {
		name : 'count0_15Days',
		type : 'integer'
	}, {
		name : 'invAmnt0_15Days',
		type : 'float'
	}, {
		name : 'appvdAmnt0_15Days',
		type : 'float'
	}, {
		name : 'count16_30Days',
		type : 'integer'
	}, {
		name : 'invAmnt16_30Days',
		type : 'float'
	}, {
		name : 'appvdAmnt16_30Days',
		type : 'float'
	}, {
		name : 'count31_60Days',
		type : 'integer'
	}, {
		name : 'invAmnt31_60Days',
		type : 'float'
	}, {
		name : 'appvdAmnt31_60Days',
		type : 'float'
	}, {
		name : 'count61_180Days',
		type : 'integer'
	}, {
		name : 'invAmnt61_180Days',
		type : 'float'
	}, {
		name : 'appvdAmnt61_180Days',
		type : 'float'
	}
	]
});


Ext.define('oceanDashboardEDIErrorMsg', {
	extend : 'Ext.data.Model',
	fields : [{
		name : 'companyCode',
		type : 'string'
	},{
		name : 'popCode',
		type : 'string'
	},{
		name : 'tabValue',
		type : 'string'
	},{
		name : 'msgType',
		type : 'string'
	}, {
		name : 'noOfErrs',
		type : 'int'
	}, {
		name : 'limitValue',
		type : 'string'
	},{
		name : 'popNm',
		type : 'string'
	}
	]
});



Ext.define('OceanDashBoardPendingProformaTab', {
	extend : 'Ext.data.Model',
	fields : [ 
     {
	  name : 'companyCode',
	  type : 'string'
    },
	{
		name : 'blNumber',
		type : 'string'
	},
	{
		name : 'pop',
		type : 'string'
	},
	 {
		name : 'voyage',
		type : 'string'
	},
	{
		name : 'carrier',
		type : 'string'
	},
	 {
		name : 'payer',
		type : 'string'
	},
	{
		name : 'payerNm',
		type : 'string'
	},
	{
		name : 'exceptionType',
		type : 'string'
	},
	 {
		name : 'localCurrency',
		type : 'string'
	},
	{
		name : 'localAmount',
		type : 'float'
	},
	 {
		name : 'amountUSD',
		type : 'float'
	}
	,
	 {
		name : 'numberOfBLs',
		type : 'float'
	}
	
	]
});

Ext.define('OceanDashBoardAmendmentsTab', {
	extend : 'Ext.data.Model',
	fields : [ 
{
	  name : 'radioBtn',
	  type : 'bool'
  },
     {
	  name : 'companyCode',
	  type : 'string'
    },
	{
		name : 'pop',
		type : 'string'
	},
	 {
		name : 'voyage',
		type : 'string'
	},
	{
		name : 'carrier',
		type : 'string'
	},
	 {
		name : 'payer',
		type : 'string'
	},
	{
		name : 'partyName',
		type : 'string'
	},
	{
		name : 'amendmentCode',
		type : 'string'
	},
	{
		name : 'amendmentType',
		type : 'string'
	},
	 {
		name : 'localCurrency',
		type : 'string'
	},
	{
		name : 'localAmount',
		type : 'float'
	},
	 {
		name : 'amountUSD',
		type : 'float'
	}
	,
	 {
		name : 'numberOfBLs',
		type : 'float'
	},
	{
		name : 'billNumber',
		type : 'String'
	},
	{
		name : 'msg_hdr_id',
		type : 'integer'
	}, {
		name : 'defaultFlag',
		type : 'string'
	}
	
	
	]
});

Ext.define('OceanDashBoardAmendmentsHandleDtls', {
	extend : 'Ext.data.Model',
	fields : [ 
     {
	  name : 'companyCode',
	  type : 'string'
    },
	{
		name : 'lineItemStatus',
		type : 'string'
	},
	 {
		name : 'lineNumber',
		type : 'integer'
	},
	{
		name : 'blNumber',
		type : 'string'
	},
	 {
		name : 'voyage',
		type : 'string'
	},
	{
		name : 'partyCode',
		type : 'string'
	},
	{
		name : 'partyName',
		type : 'string'
	},
	{
		name : 'pol',
		type : 'string'
	},
	 {
		name : 'pod',
		type : 'string'
	},
	{
		name : 'por',
		type : 'string'
	},
	 {
		name : 'pfd',
		type : 'string'
	},
	 {
		name : 'sailingDate',
		type:'date',
		dateFormat:'d/m/Y'
	},
	{
		name : 'post_collect_chrg_flg',
		type:'bool',convert:function(v)
		   {
			return (v === "Y" || v === true) ? true : false;
		   }
	},
	{
		name : 'commodityDesc',
		type : 'string'
	}, {
		name : 'chargeCode',
		type : 'string'
	},
	{
		name : 'freightTerm',
		type : 'string'
	},
	{
		name : 'pop',
		type : 'string'
	}, {
		name : 'lineItemQtty',
		type : 'float'
	},
	{
		name : 'rate',
		type : 'float'
	},
	{
		name : 'rateBasis',
		type : 'string'
	}, {
		name : 'manifestCurrency',
		type : 'string'
	},
	{
		name : 'manifestAmount',
		type : 'float'
	},
	{
		name : 'exchangeRate',
		type : 'float'
	}, {
		name : 'popCurrency',
		type : 'string'
	},
	{
		name : 'popAmount',
		type : 'float'
	},
	{
		name : 'usdAmount',
		type : 'float'
	}, {
		name : 'invoiceNumber',
		type : 'string'
	},
	{
		name : 'status',
		type : 'string'
	},
	{
		name : 'invoiceCreatedBy',
		type : 'string'
	}, {
		name : 'invoiceStatusDate',
		type:'date',
		dateFormat:'d/m/Y'
	},{
		name : 'src_key',
		type:'int'
	},{
		name : 'indicator',
		type:'string'
	},{
		name : 'item_seq_no',
		type:'int'
	},{
		name : 'msg_hdr_id',
		type : 'int'
	},{
		name : 'evnt_status',
		type : 'String'
	},{
		name : 'msg_sts_ind',
		type : 'String'
	},{
		name : 'billStatus',
		type : 'string'
	}]
});
Ext.define('OceanDashBoardBusnExcpHandlingModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'blNumber',
		type : 'string'
	},
	 {
		name : 'originalPOD',
		type : 'string'
	},
	{
		name : 'originalPFD',
		type : 'string'
	},
	 {
		name : 'updatedPOD',
		type : 'string'
	}
	,
	{
		name : 'updatedPFD',
		type : 'string'
	},
	{
		name : 'localCurrency',
		type : 'string'
	},
	{
		name : 'localAmount',
		type : 'float'
	},
	{
		name : 'amountUSD',
		type : 'float'
	}
	,
	{
		name : 'msgHeader',
		type : 'string'
	}
		
	]
});


Ext.define('OceanDashBoardSupplierRecnStatusModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'supplier',
		type : 'string'
	}, {
		name : 'status',
		type : 'string'
	},{
		name : 'currency',
		type : 'string'
	},
	{
		name : 'pastDueCount',
		type : 'integer'
	}, {
		name : 'pastDueInvoiceAmount',
		type : 'float'
	}, {
		name : 'pastDueUsdAmount',
		type : 'float'
	},
	{
		name : 'due0_5DaysCount',
		type : 'integer'
	}, {
		name : 'due0_5DaysInvoiceAmount',
		type : 'float'
	},{
		name : 'due0_5DaysUsdAmount',
		type : 'float'
	},{
		name : 'due6_15DaysCount',
		type : 'integer'
	}, {
		name : 'due6_15DaysInvoiceAmount',
		type : 'float'
	}, {
		name : 'due6_15DaysUsdAmount',
		type : 'float'
	},{
		name : 'due16_30DaysCount',
		type : 'integer'
	}, {
		name : 'due16_30DaysInvoiceAmount',
		type : 'float'
	},{
		name : 'due16_30DaysUsdAmount',
		type : 'float'
	},{
		name : 'due30_DaysCount',
		type : 'integer'
	}, {
		name : 'due30_DaysInvoiceAmount',
		type : 'float'
	}, {
		name : 'due30_DaysUsdAmount',
		type : 'float'
	}
	]
});


Ext.define('popCountryList',{
	extend:'Ext.data.Model',
	fields:[{
	        	name:'countryCode',
	        	type:'string'
	        }
	       ]
	
});

Ext.define('OceanDashBoardCustRecnStatusModel', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'customerCd',
		type : 'string'
	},{
		name : 'customerName',
		type : 'string'
	}, {
		name : 'currency',
		type : 'string'
	},{
		name : 'invcType',
		type : 'string'
	},
	{
		name : 'pastDueCount',
		type : 'integer'
	}, {
		name : 'pastDueInvoiceAmount',
		type : 'float'
	},
	{
		name : 'due0_5DaysCount',
		type : 'integer'
	}, {
		name : 'due0_5DaysInvoiceAmount',
		type : 'float'
	},{
		name : 'due6_15DaysCount',
		type : 'integer'
	}, {
		name : 'due6_15DaysInvoiceAmount',
		type : 'float'
	},{
		name : 'due16_30DaysCount',
		type : 'integer'
	}, {
		name : 'due16_30DaysInvoiceAmount',
		type : 'float'
	},{
		name : 'due30_DaysCount',
		type : 'integer'
	}, {
		name : 'due30_DaysInvoiceAmount',
		type : 'float'
	}
	]
});
Ext.define('oceanCstmrGenFinalizeList',{
	extend:'Ext.data.Model',
	fields:[{
	        	name:'prfinvcno'
	        },
	        {
	        	name:'pop'
	        },
	        {
	        	name:'companyCd'
	        },{
	        	name:'customer'
	        },
	        {
	        	name:'invcNumber'
	        },
	        {
	        	name:'invcStatus'
	        },
	       {
	        	name:'profStatusDesc'
	        },{
	        	name:'party'
	        },{
	        	name:'extPrfInvcNumber'
	        },{
	        	name:'customerName'
	        },{
	        	name:'invcAmount'
	        },{
	        	name:'voyage'
	        }
	       ]
	
});

Ext.define('countryList',{
	extend : 'Ext.data.Model',
	fields:[{
		name:'countryCode',
		type:'string'
	},{
		name:'countryName',
		type:'string'
	}]
});

Ext.define('regionList',{
	extend : 'Ext.data.Model',
	fields:[{
		name:'regionCode',
		type:'string'
	},{
		name:'regionName',
		type:'string'
	}]
});

Ext.define('OcnEventMsgDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
	        	name:'srvcCd',
	        	type:'string'
	        },
	        {
	          name:'customerCode',
	          type:'string'
	        },
	        {
	        	name:'customerNm',
	        	type:'string'
	        },
	        {
	        	name:'addr1',
	        	type:'string'
	        },
	        {
	        	name:'addr2',
	        	type:'string'
	        },
	        {
	        	name:'addr3',
	        	type:'string'
	        },
	        {
	        	name:'city',
	        	type:'string'
	        },
	        {
	        	name:'state',
	        	type:'string'
	        },
	        {
	        	name:'country',
	        	type:'string'
	        },
	        {
	        	name:'postalCd',
	        	type:'string'
	        },
	        {
	        	name:'contactPerson',
	        	type:'string'
	        },
	        {
	        	name:'serviceDesc',
	        	type:'string'
	        },
	        {
	        	name:'quantity',
	        	type:'integer'
	        },
	        {
	        	name:'pop',
	        	type:'string'
	        },
	        {
	        	name:'popDesc',
	        	type:'string'
	        },
	        {
	        	name:'lineItem',
	        	type:'string'
	        },
	        {
	        	name:'lineItemQty',
	        	type:'string'
	        },
	        {
	        	name:'transferSeqNbr',
	        	type:'string'
	        },
	        {
	        	name:'cargoClass',
	        	type:'string'
	        },
	        {
	        	name:'cargoType',
	        	type:'string'
	        },
	        {
	        	name:'commodityCd',
	        	type:'string'
	        },
	        {
	        	name:'commodityDesc',
	        	type:'string'
	        },
	        {
	        	name:'cargoCount',
	        	type:'string'
	        },
	        {
	        	name:'srcKey1',
	        	type:'string'
	        },
	        {
	        	name:'srcKey2',
	        	type:'string'
	        },
	        {
	        	name:'acctCode',
	        	type:'string'
	        },
	        {
	        	name:'rateSentFlgSell',
	        	type:'string'
	        },
	        {
	        	name:'rateSell',
	        	type:'string'
	        },
	        {
	        	name:'rateBasisSell',
	        	type:'string'
	        },
	        {
	        	name:'manifestCurrSell',
	        	type:'string'
	        },
	        {
	        	name:'manifestAmtSell',
	        	type:'string'
	        },
	        {
	        	name:'exchangeRateSell',
	        	type:'string'
	        },
	        {
	        	name:'localCurrSell',
	        	type:'string'
	        },
	        {
	        	name:'localAmountSell',
	        	type:'string'
	        },
	        {
	        	name:'usdAmountSell',
	        	type:'string'
	        },
	        {
	        	name:'rateSentFlagBuy',
	        	type:'string'
	        },
	        {
	        	name:'rateSellBuy',
	        	type:'string'
	        },
	        {
	        	name:'rateBasisBuy',
	        	type:'string'
	        },
	        {
	        	name:'manifestCurrBuy',
	        	type:'string'
	        },
	        {
	        	name:'manifestAmtBuy',
	        	type:'string'
	        },
	        {
	        	name:'exchangeRateBuy',
	        	type:'string'
	        },
	        {
	        	name:'localCurrencyBuy',
	        	type:'string'
	        },
	        {
	        	name:'localAmtBuy',
	        	type:'string'
	        },
	        {
	        	name:'usdEquivalentAmtBuy',
	        	type:'string'
	        }, 
	        {
	        	name:'customerPayer',
	        	type:'string'
	        }, 
	        {
	        	name:'customerType',
	        	type:'string'
	        }, 
	        {
	        	name:'vatNbr',
	        	type:'string'
	        },
	        {
	        	name:'vatApplicableFlg',
	        	type:'string'
	        },
	        {
	        	name:'itemCdsiDesc',
	        	type:'string'
	        },
	        {
	        	name:'itemCdsiDesc1',
	        	type:'string'
	        },
	        {
	        	name:'itemCdsiDesc2',
	        	type:'string'
	        },
	        {
	        	name:'itemCdsiInsidePackage',
	        	type:'string'
	        },
	        {
	        	name:'postCollectChargeFlg',
	        	type:'string'
	        }
	       ]
});
Ext.define('portMsgDtls',{
	extend : 'Ext.data.Model',
	fields:[{
		name:'msgHdrId',
		type:'integer'
	},
	{
		name:'code',
		type:'string'
	},
	{
		name:'name',
		type:'string'
	},
	{
		name:'city',
		type:'string'
	},
	{
		name:'state',
		type:'string'
	},
	{
		name:'postalCode',
		type:'string'
	},
	{
		name:'country',
		type:'string'
	},
	{
		name:'currency',
		type:'string'
	},
	{
		name:'originalSite',
		type:'string'
	},
	{
		name:'timeZone',
		type:'string'
	},
	{
		name:'responsibleOffice',
		type:'string'
	},
	{
		name:'address1',
		type:'string'
	},
	{
		name:'address2',
		type:'string'
	}
	]

});


Ext.define('covusXmlBankDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		       name:'bankSeqNbr',
		       type:'string'
	        },
	        {
	        	name:'bankAddress',
	        	type:'string'
	        }
	        ]
});

Ext.define('covusXmlBLHdrDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'blNbr',
		      type:'string'
	        },
        	{
  		      name:'blType',
  		      type:'string'
  	        },
  	        {
  		      name:'supplierCd',
  		      type:'string'
  	        },
  	        {
  		      name:'supplierNm',
  		      type:'string'
  	        },
  	         {
  		      name:'vesselCd',
  		      type:'string'
  	        },
  	        {
  		      name:'vesselNm',
  		      type:'string'
  	        },
  	        {
  		      name:'voyageNbr',
  		      type:'string'
  	        },
  	        {
  	        	name:'shipmentRefNbr',
  	        	type:'string'
  	        },
  	        {
  	        	name:'txnType',
  	        	type:'string'
  	        },
  	        {
  	        	name:'cstmrVatNbr',
  	        	type:'string'
  	        },
  	        {
  	        	name:'cstmrContactNbr',
  	        	type:'string'
  	        }
	       ]
});

Ext.define('covusXmlManifestAmtDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'manifestCurrencyCd',
		      type:'string'
	        },
	        {
	        	name:'srvcAmtManifestCurrency',
	        	type:'float'
	        }
	        ]
});


Ext.define('covusXmlCargoDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'cargoId',
		      type:'string'
	        },
	        {
	        	name:'cargoIdOrderNbr',
	        	type:'integer'
	        },
	        {
	        	name:'cargoBarCd',
	        	type:'string'
	        },
	        {
	        	name:'storageQty',
	        	type:'float'
	        },
	        {
	        	name:'handlingInd',
	        	type:'string'
	        		
	        },
	        {
	        	name:'steering',
	        	type:'string'
	        },
	        {
	        	name:'hazardous',
        		type: 'bool',convert:function(v)
	        	 {
	        	return (v === "Y" || v === true || v === "") ? true : false;
	             }	
	        },
	        {
	        	name:'transferGear',
	        	type:'string'
	        },
	        {
	        	name:'cargoCdsiDesc',
	        	type:'string'
	        },
	        {
	        	name:'cargoCdsiDesc1',
	        	type:'string'
	        },
	        {
	        	name:'cargoCdsiDesc2',
	        	type:'string'
	        },
	        {
	        	name:'cargoCdsiInsidePkg',
	        	type:'string'
	        },
	        {
	        	name:'cargoServiceAmountLocalCurrency',
	        	type:'float'
	        },
	        {
	        	name:'cargoServiceAmountManifstCurrency',
	        	type:'float'
	        },
	        {
	        	name:'cargoQuantity',
	        	type:'float'
	        }
	        ]
});


Ext.define('covusXmlTaxDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'taxTypeCd',
		      type:'string'
	        },
	        {
	        	name:'taxPrcntg',
	        	type:'float'
	        },
	        {
	        	name:'invcCrncyCd',
	        	type:'string'
	        },
	        {
	        	name:'taxAmtLocalCrncy',
	        	type:'float'
	        } ]
});

Ext.define('covusXmlInvcSubDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'srvcCode',
		      type:'string'
	        },
	        {
			   name:'srvcType',
			   type:'string'
		    },
		    {
			   name:'srvcDesc',
			   type:'string'
		    },
		    {
			   name:'serviceGrpCd',
			   type:'string'
		    },
		    {
			   name:'frieghtTermCd',
			   type:'string'
		    },
		   /* {
			   name:'prfInvcNbr',
		       type:'integer'
		    },*/
		    {
			   name:'invcItemNbr',
			   type:'integer'
		    },
		    {
		    	name:'cargoClass',
		    	type:'string'
		    },
		    {
		    	name:'cargoType',
		    	type:'string'
		    },
		    {
		    	name:'cmdtCd',
		    	type:'string'
		    },
		    {
		    	name:'cmdtDesc',
		    	type:'string'
		    },
		    {
		    	name:'pod',
		    	type:'string'
		    },
		    {
		    	name:'podDesc',
		    	type:'string'
		    },
		    {
		    	name:'podBerthCode',
		    	type:'string'
		    },
		    {
		    	name:'podPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'podAddress1',
		    	type:'string'
		    },
		    {
		    	name:'podAddress2',
		    	type:'string'
		    },
		    {
		    	name:'podCity',
		    	type:'string'	
		    },
		    {
		    	name:'podState',
		    	type:'string'
		    },
		    {
		    	name:'podCountry',
		    	type:'string'
		    },
		    {
		    	name:'podPoBox',
		    	type:'string'
		    },
		    {
		    	name:'pfd',
		    	type:'string'
		    },
		    {
		    	name:'pfdDesc',
		    	type:'string'
		    },
		    {
		    	name:'pfdAddress1',
		    	type:'string'
		    },
		    {
		    	name:'pfdAddress2',
		    	type:'string'
		    },
		    {
		    	name:'pfdBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'pfdPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'pfdCity',
		    	type:'string'
		    },
		    {
		    	name:'pfdState',
		    	type:'string'
		    },
		    {
		    	name:'pfdCountry',
		    	type:'string'
		    },
		    {
		    	name:'pfdPobox',
		    	type:'string'	
		    },
		    {
		    	name:'pol',
		    	type:'string'
		    },
		    {
		    	name:'polDesc',
		    	type:'string'
		    },
		    {
		    	name:'polBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'polPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'polAddress1',
		    	type:'string'
		    },
		    {
		    	name:'polAddress2',
		    	type:'string'
		    },
		    {
		    	name:'polCity',
		    	type:'string'
		    },
		    {
		    	name:'polState',
		    	type:'string'
		    },
		    {
		    	name:'polCountry',
		    	type:'string'
		    },
		    {
		    	name:'polPOBox',
		    	type:'string'
		    },
		    {
		    	name:'por',
		    	type:'string'
		    },
		    {
		    	name:'porDesc',
		    	type:'string'
		    },
		    {
		    	name:'porBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'porPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'porAddress1',
		    	type:'string'
		    },
		    {
		    	name:'porAddress2',
		    	type:'string'
		    },
		    {
		    	name:'porCity',
		    	type:'string'
		    },
		    {
		    	name:'porState',
		    	type:'string'
		    },
		    {
		    	name:'porCountry',
		    	type:'string'
		    },
		    {
		    	name:'porPOBox',
		    	type:'string'
		    },
		    {
		    	name:'invcItemSts',
		    	type:'string'
		    },
		    {
		    	name:'makeCd',
		    	type:'string'
		    },
		    {
		    	name:'modelCd',
		    	type:'string'
		    },
		    {
		    	name:'modelYear',
		    	type:'integer'
		    },
		    {
		    	name:'mismatchReason',
		    	type:'string'
		    },
		    {
		    	name:'taxServiceFlg',
		    	type: 'bool',convert:function(v)
	        	 {
	        	return (v === "Y" || v === true || v === "") ? true : false;
	             }
		    },
		    {
		    	name:'itemQty',
		    	type:'float'
		    },
		    {
		    	name:'tariffRate',
		    	type:'float'
		    },
		    {
		    	name:'rateBasisCd',
		    	type:'string'
		    },
		    {
		    	name:'exchangeRate',
		    	type:'float'
		    },
		    {
		    	name:'remark',
		    	type:'string'
		    },
		    {
		    	name:'docRefNbr',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc1',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc2',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiInsidePackage',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmountManifestCurr',
		    	type:'float'
		    },
		    {
		    	name:'manifestCurrencyCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmtLocalCurrency',
		    	type:'float'
		    },
		    {
		    	name:'invcCurrencyCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmtUsdCurr',
		    	type:'float'
		    },
		    {
		    	name:'srvcUomCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcUnitQty',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtManifestCurrency',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtLocalCurrency',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtUsdCurrency',
		    	type:'float'
		    },
		    {
		    	name:'originalInvcNbr',
		    	type:'string'
		    },
		    {
		    	name:'lineItemIdentifier',
		    	type:'string'
		    }
	       ]
});


Ext.define('covusXmlInvcDtls',{
	extend:'Ext.data.Model',
	fields:[
	        {
		      name:'srvcCode',
		      type:'string'
	        },
	        {
			   name:'srvcType',
			   type:'string'
		    },
		    {
			   name:'srvcDesc',
			   type:'string'
		    },
		    {
			   name:'serviceGrpCd',
			   type:'string'
		    },
		    {
			   name:'frieghtTermCd',
			   type:'string'
		    },
		    /*{
			   name:'prfInvcNbr',
		       type:'integer'
		    },*/
		    {
			   name:'invcItemNbr',
			   type:'integer'
		    },
		    {
		    	name:'cargoClass',
		    	type:'string'
		    },
		    {
		    	name:'cargoType',
		    	type:'string'
		    },
		    {
		    	name:'cmdtCd',
		    	type:'string'
		    },
		    {
		    	name:'cmdtDesc',
		    	type:'string'
		    },
		    {
		    	name:'pod',
		    	type:'string'
		    },
		    {
		    	name:'podDesc',
		    	type:'string'
		    },
		    {
		    	name:'podBerthCode',
		    	type:'string'
		    },
		    {
		    	name:'podPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'podAddress1',
		    	type:'string'
		    },
		    {
		    	name:'podAddress2',
		    	type:'string'
		    },
		    {
		    	name:'podCity',
		    	type:'string'	
		    },
		    {
		    	name:'podState',
		    	type:'string'
		    },
		    {
		    	name:'podCountry',
		    	type:'string'
		    },
		    {
		    	name:'podPoBox',
		    	type:'string'
		    },
		    {
		    	name:'pfd',
		    	type:'string'
		    },
		    {
		    	name:'pfdDesc',
		    	type:'string'
		    },
		    {
		    	name:'pfdAddress1',
		    	type:'string'
		    },
		    {
		    	name:'pfdAddress2',
		    	type:'string'
		    },
		    {
		    	name:'pfdBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'pfdPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'pfdCity',
		    	type:'string'
		    },
		    {
		    	name:'pfdState',
		    	type:'string'
		    },
		    {
		    	name:'pfdCountry',
		    	type:'string'
		    },
		    {
		    	name:'pfdPobox',
		    	type:'string'	
		    },
		    {
		    	name:'pol',
		    	type:'string'
		    },
		    {
		    	name:'polDesc',
		    	type:'string'
		    },
		    {
		    	name:'polBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'polPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'polAddress1',
		    	type:'string'
		    },
		    {
		    	name:'polAddress2',
		    	type:'string'
		    },
		    {
		    	name:'polCity',
		    	type:'string'
		    },
		    {
		    	name:'polState',
		    	type:'string'
		    },
		    {
		    	name:'polCountry',
		    	type:'string'
		    },
		    {
		    	name:'polPOBox',
		    	type:'string'
		    },
		    {
		    	name:'por',
		    	type:'string'
		    },
		    {
		    	name:'porDesc',
		    	type:'string'
		    },
		    {
		    	name:'porBerthCd',
		    	type:'string'
		    },
		    {
		    	name:'porPortCall',
		    	type:'integer'
		    },
		    {
		    	name:'porAddress1',
		    	type:'string'
		    },
		    {
		    	name:'porAddress2',
		    	type:'string'
		    },
		    {
		    	name:'porCity',
		    	type:'string'
		    },
		    {
		    	name:'porState',
		    	type:'string'
		    },
		    {
		    	name:'porCountry',
		    	type:'string'
		    },
		    {
		    	name:'porPOBox',
		    	type:'string'
		    },
		    {
		    	name:'invcItemSts',
		    	type:'string'
		    },
		    {
		    	name:'makeCd',
		    	type:'string'
		    },
		    {
		    	name:'modelCd',
		    	type:'string'
		    },
		    {
		    	name:'modelYear',
		    	type:'integer'
		    },
		    {
		    	name:'mismatchReason',
		    	type:'string'
		    },
		    {
		    	name:'taxServiceFlg',
		    	type: 'bool',convert:function(v)
	        	 {
	        	return (v === "Y" || v === true || v === "") ? true : false;
	             }
		    },
		    {
		    	name:'itemQty',
		    	type:'float'
		    },
		    {
		    	name:'tariffRate',
		    	type:'float'
		    },
		    {
		    	name:'rateBasisCd',
		    	type:'string'
		    },
		    {
		    	name:'exchangeRate',
		    	type:'float'
		    },
		    {
		    	name:'remark',
		    	type:'string'
		    },
		    {
		    	name:'docRefNbr',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc1',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiDesc2',
		    	type:'string'
		    },
		    {
		    	name:'itemCdsiInsidePackage',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmountManifestCurr',
		    	type:'float'
		    },
		    {
		    	name:'manifestCurrencyCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmtLocalCurrency',
		    	type:'float'
		    },
		    {
		    	name:'invcCurrencyCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcAmtUsdCurr',
		    	type:'float'
		    },
		    {
		    	name:'srvcUomCd',
		    	type:'string'
		    },
		    {
		    	name:'srvcUnitQty',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtManifestCurrency',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtLocalCurrency',
		    	type:'float'
		    },
		    {
		    	name:'paidAmtUsdCurrency',
		    	type:'float'
		    }
	       ]
});




Ext.define('ocnCustInvcViewBLHdrDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'vesselCd',
		      type:'string'
	        },
        	{
  		      name:'vesselNm',
  		      type:'string'
  	        },
  	        {
  		      name:'supplier',
  		      type:'string'
  	        },
  	        {
  		      name:'supplierNm',
  		      type:'string'
  	        },
  	         {
  		      name:'blNumber',
  		      type:'string'
  	        },{
		      name:'blType',
		      type:'string'
	        },
        	{
  		      name:'transacType',
  		      type:'string'
  	        },
  	        {
  		      name:'ptyVatNum',
  		      type:'string'
  	        },
  	        {
  		      name:'ptyContactPrsnNum',
  		      type:'string'
  	        },
  	        {
  		      name:'voyage',
  		      type:'string'
  	        },
  	        {
  	        	name:'pfdCd',
  	        	type:'string'
  	        },
  	        {
  	        	name:'pfdAddress1',
  	        	type:'string'
  	        },
  	        {
  	        	name:'pfdAddress2',
  	        	type:'string'
  	        },
  	        {
  	        	name:'pfdCity',
  	        	type:'string'
  	        },
	        {
	        	name:'pfdState',
	        	type:'string'
	        },
	        {
	        	name:'pfdCountry',
	        	type:'string'
	        },
	        {
	        	name:'pfdPostalCode',
	        	type:'string'
	        },
	        {
	        	name:'pfdEta',
	        	type:'string'
	        },
	        {
	        	name:'pfdEtd',
	        	type:'string'
	        },
	        {
	        	name:'pfdBerthCd',
	        	type:'string'
	        },
	        {
	        	name:'pfdAtd',
	        	type:'string'
	        },
	        {
	        	name:'pfdAta',
	        	type:'string'
	        },
	        {
	        	name:'pfdPortCall',
	        	type:'string'
	        },
	        {
	        	name:'polCd',
	        	type:'string'
	        },
	        {
	        	name:'polAddress1',
	        	type:'string'
	        },
	        {
	        	name:'polAddress2',
	        	type:'string'
	        },
	        {
	        	name:'polCity',
	        	type:'string'
	        },
	        {
	        	name:'polState',
	        	type:'string'
	        },
	        {
	        	name:'polCountry',
	        	type:'string'
	        },
	        {
	        	name:'polPostalCode',
	        	type:'string'
	        },
	        {
	        	name:'polEta',
	        	type:'string'
	        },
	        {
	        	name:'polEtd',
	        	type:'string'
	        },
	        {
	        	name:'polBerthCd',
	        	type:'string'
	        },
	        {
	        	name:'polAtd',
	        	type:'string'
	        },
	        {
	        	name:'polAta',
	        	type:'string'
	        },
	        {
	        	name:'polPortCall',
	        	type:'string'
	        },
  	        {
  	        	name:'podCd',
  	        	type:'string'
  	        },
  	        {
  	        	name:'podAddress1',
  	        	type:'string'
  	        },
  	        {
  	        	name:'podAddress2',
  	        	type:'string'
  	        },
  	        {
  	        	name:'podCity',
  	        	type:'string'
  	        },
	        {
	        	name:'podState',
	        	type:'string'
	        },
	        {
	        	name:'podCountry',
	        	type:'string'
	        },
	        {
	        	name:'podPostalCode',
	        	type:'string'
	        },
	        {
	        	name:'podEta',
	        	type:'string'
	        },
	        {
	        	name:'podEtd',
	        	type:'string'
	        },
	        {
	        	name:'podBerthCd',
	        	type:'string'
	        },
	        {
	        	name:'podAtd',
	        	type:'string'
	        },
	        {
	        	name:'podAta',
	        	type:'string'
	        },
	        {
	        	name:'podPortCall',
	        	type:'string'
	        }
	        
	        ,
  	        {
  	        	name:'por',
  	        	type:'string'
  	        },
  	        {
  	        	name:'porDesc',
  	        	type:'string'
  	        },
  	        {
  	        	name:'porAddress1',
  	        	type:'string'
  	        },
  	        {
  	        	name:'porAddress2',
  	        	type:'string'
  	        },
	        {
	        	name:'porCity',
	        	type:'string'
	        },
	        {
	        	name:'porState',
	        	type:'string'
	        },
	        {
	        	name:'porCountry',
	        	type:'string'
	        },
	        {
	        	name:'porPostalCode',
	        	type:'string'
	        },
	        {
	        	name:'porEta',
	        	type:'string'
	        },
	        {
	        	name:'porEtd',
	        	type:'string'
	        },
	        {
	        	name:'porBerthCd',
	        	type:'string'
	        },
	        {
	        	name:'porAtd',
	        	type:'string'
	        },
	        {
	        	name:'porAta',
	        	type:'string'
	        },
	        {
	        	name:'porPortCall',
	        	type:'string'
	        },
	        {
	        	name:'tuppleSeq',
	        	type:'string'
	        }
	       ]
});


Ext.define('oCnViewCustInvcChrgeCdDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'srvcCd',
		      type:'string'
	        },
        	{
  		      name:'srvcDescr',
  		      type:'string'
  	        },
  	        {
  		      name:'srvcType',
  		      type:'string'
  	        },
  	        {
  		      name:'frghtTrmCd',
  		      type:'string'
  	        },
  	         {
  		      name:'crgoClsCd',
  		      type:'string'
  	        },{
		      name:'crgoTypeCd',
		      type:'string'
	        },
        	{
  		      name:'cmdtCd',
  		      type:'string'
  	        },
  	        {
  		      name:'cmdtDescr',
  		      type:'string'
  	        },
  	        {
  		      name:'itemNo',
  		      type:'string'
  	        },
  	        {
  		      name:'shipRefNum',
  		      type:'string'
  	        },
  	        {
  	        	name:'taxServiceFlg',
  	        	type:'string'
  	        },
  	        {
  	        	name:'itemCdsiDescr',
  	        	type:'string'
  	        },
  	        {
  	        	name:'itemCdsiDescr1',
  	        	type:'string'
  	        },
  	        {
  	        	name:'itemCdsiDescr2',
  	        	type:'string'
  	        },
	        {
	        	name:'itemCdsInsidePkg',
	        	type:'string'
	        },
	        {
	        	name:'itemQuantity',
	        	type:'string'
	        },
	        {
	        	name:'trfRate',
	        	type:'string'
	        },
	        {
	        	name:'rateBasisCd',
	        	type:'string'
	        },
	        {
	        	name:'srvAmtManCurncy',
	        	type:'string'
	        },
	        {
	        	name:'manfestCrncyCd',
	        	type:'string'
	        },
	        {
	        	name:'exchRate',
	        	type:'string'
	        },
	        {
	        	name:'srvAmtLocCurncy',
	        	type:'string'
	        },
	        {
	        	name:'localCrncyCd',
	        	type:'string'
	        },
	        {
	        	name:'srvAmtUsdCurncy',
	        	type:'string'
	        },
	        {
	        	name:'srvUnitQunatity1',
	        	type:'string'
	        },
	        {
	        	name:'srcKey',
	        	type:'string'
	        },
	        {
	        	name:'itemNo',
	        	type:'string'
	        },
	        {
	        	name:'freightTermCd',
	        	type:'string'
	        },
	        {
	        	name:'tuppleSeq',
	        	type:'string'
	        }
	       ]
});



Ext.define('OcnViewCustInvcCargoCdDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'crgwt',
		      type:'string'
	        },
        	{
  		      name:'wtUomCd',
  		      type:'string'
  	        },
  	        {
  		      name:'crgLength',
  		      type:'string'
  	        },
  	        {
  		      name:'crgLenUomCd',
  		      type:'string'
  	        },
  	         {
  		      name:'crgHgt',
  		      type:'string'
  	        },{
		      name:'crgVol',
		      type:'string'
	        },
        	{
  		      name:'crgCube',
  		      type:'string'
  	        },
  	        {
  		      name:'crgQty',
  		      type:'string'
  	        },
  	        {
  		      name:'crgTrfRt',
  		      type:'string'
  	        },
  	        {
  		      name:'crgMake',
  		      type:'string'
  	        },
  	        {
  	        	name:'crgModel',
  	        	type:'string'
  	        },
  	        {
  	        	name:'crgMdlYr',
  	        	type:'string'
  	        },
  	        {
  	        	name:'crgSrvAmtManCurncy',
  	        	type:'string'
  	        },
  	        {
  	        	name:'crgManfestCrncyCd',
  	        	type:'string'
  	        },
	        {
	        	name:'crgExchRate',
	        	type:'string'
	        },
	        {
	        	name:'crgSrvAmtLocCurncy',
	        	type:'string'
	        },
	        {
	        	name:'crgLocalCrncyCd',
	        	type:'string'
	        },
	        {
	        	name:'crgSrvAmtUsdCurncy',
	        	type:'string'
	        },
	        {
	        	name:'crgId',
	        	type:'string'
	        },
	        {
	        	name:'crgIdOrdrNo',
	        	type:'string'
	        },
	        {
	        	name:'crgCdsiDescr',
	        	type:'string'
	        },
	        {
	        	name:'crgCdsiDescr1',
	        	type:'string'
	        },
	        {
	        	name:'crgCdsiDescr2',
	        	type:'string'
	        },
	        {
	        	name:'crgCdsiInsidePkg',
	        	type:'string'
	        },
	        {
	        	name:'crgHndlngInd',
	        	type:'string'
	        },
	        {
	        	name:'crgXfrGear',
	        	type:'string'
	        },
	        {
	        	name:'crgStrngInd',
	        	type:'string'
	        },
	        {
	        	name:'crgHzrdsFlg',
	        	type:'string'
	        }
	        ,
	        {
	        	name:'crgUomCd',
	        	type:'string'
	        },
	        {
	        	name:'crgSrcKey',
	        	type:'string'
	        },
	        {
	        	name:'cargoQuantity',
	        	type:'float'
	        }
	       ]
});

Ext.define('ocnInvcGenFinalDto',{
	extend:'Ext.data.Model',
	fields:[
	        {
		     name:'invcNumber'
	        },
	        {
	          name:'extPrfInvcNumber'
	        },{
	        	name:'customer'
	        },{
	        	name:'prfinvcno'
	        },{
	        	name:'pop'
	        },{
	        	name:'party'
	        },{
	        	name:'customerName'
	        },{
	        	name:'invcAmount'
	        },{
	        	name:'voyage'
	        }
	        ]
});

Ext.define('OcnViewCustInvcManfstAmtDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'manfstCrncyCd',
		      type:'string'
	        },
        	{
  		      name:'srvcAmtManfstCrncy',
  		      type:'string'
  	        },
  	        {
  		      name:'exchRate',
  		      type:'string'
  	        }
	       ]
});


Ext.define('viewVoyageMasterSupplierDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'voyNo',
		      type:'string'
	        },
        	{
  		      name:'supplierCd',
  		      type:'string'
  	        },
  	        {
  		      name:'supplierNm',
  		      type:'string'
  	        },
  	        {
		      name:'actionCd',
		      type:'string'
	        },
  	        {
		      name:'tuppleSeq',
		      type:'string'
	        }
	       ]
});


Ext.define('viewVoyageMasterSupplierChildDtls',{
	extend : 'Ext.data.Model',
	fields:[
	        {
		      name:'msgHdrId',
		      type:'string'
	        },
        	{
  		      name:'voyNo',
  		      type:'string'
  	        },
  	        {
  		      name:'portCrncyCd',
  		      type:'string'
  	        },
  	        {
		      name:'exchngRt',
		      type:'string'
	        },
	        {
		      name:'portType',
		      type:'string'
	        },{
	    		name : 'recalcFlg',
	    		type: 'bool',
	         	convert:function(v){
	         		return (v === "Y" || v === true || "") ? true : false;
	         	}
	    	},
	        {
		      name:'portCd',
		      type:'string'
	        },
	        {
		      name:'berthCd',
		      type:'string'
	        },
        	{
  		      name:'portCall',
  		      type:'string'
  	        },
  	        {
  		      name:'etaDttm',
  		      type:'string'
  	        },
  	        {
		      name:'etdDttm',
		      type:'string'
	        },
	      	{
		      name:'ataDttm',
		      type:'string'
	        },
	        {
		      name:'atdDttm',
		      type:'string'
	        },
	        {
		      name:'actionCd',
		      type:'string'
	        }
  	        ]
});

Ext.define('invoicePrintLov', {
	extend : 'Ext.data.Model',
	fields : [ {
		name : 'code'
	}, {
		name : 'path'
	},{
		name : 'companyCode'
	},{
		name : 'popCode'
	}, {
		name : 'tray'
	}]
});
