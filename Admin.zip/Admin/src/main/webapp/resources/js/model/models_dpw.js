Ext.define('Communication', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'communicationId',  type: 'string'},
        {name: 'subject', type: 'string'},
        {name: 'details', type: 'string'},
        {name: 'status',  type: 'string'},
        {name: 'isReadMandatory', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'communicationId'/* ,
    validations : [
		{type:'presence',field:'communicationId'},
		{type:'length',field:'communicationId',min:0,max:50},
		{type:'presence',field:'communicationName'},
		{type:'length',field:'communicationName',min:0,max:100},
		{type:'presence',field:'make'},
		{type:'length',field:'make',min:0,max:50},
		{type:'presence',field:'model'},
		{type:'length',field:'model',min:0,max:50},
		{type:'presence',field:'communicationTypeId'},
		{type:'length',field:'communicationTypeId',min:0,max:10},
		{type:'presence',field:'terminalId'},
		{type:'length',field:'terminalId',min:0,max:50}
	 ]*/
});

Ext.define('WeightageFactor', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'pk',  type: 'auto'},   
		{name: 'id',  type: 'string'},
        {name: 'type',  type: 'string'},
        {name: 'criteria', type: 'string'},
        {name: 'weightageScore', type: 'string'},
        {name: 'weightageFactor',  type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'id'
    	 ,
    validations : [
		{type:'presence',field:'weightageScore'},
		{type:'length',field:'weightageScore',min:0,max:50},
		{type:'presence',field:'weightageFactor'},
		{type:'length',field:'weightageFactor',min:0,max:30},
		
	] 
});


Ext.define('AlertRemarks', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'alertRemarkId',  type: 'String'},
        {name: 'alertRecordId',  type: 'int'},
		{name: 'remarks',  type: 'string'},
        {name: 'createdBy',  type: 'int'},
        {name:'trnsType',type:'string'},      				
        /*{name: 'createdDateTime',  type: 'date' ,dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        			if(v!= null && v!=""){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			else{
        				return  Ext.Date.format(new Date(), 'd/m/Y H:i:s');
        			}
            }
        },*/
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        }
        /* 
         * {name: 'raisedDateTime', type: 'date',dateFormat:'d/m/Y H:i:s'}
        {name: 'isDeleted', type: 'string'}, */
        
		
       
    ],
    idProperty: 'alertRemarkId',
    /* validations : [
		{type:'presence',field:'rotationNumber'},
		{type:'length',field:'rotationNumber',min:0,max:10},
		{type:'presence',field:'berthNo'},
		{type:'presence',field:'equipmentId'},
		{type:'presence',field:'vesselCode'},
		{type:'presence',field:'etaDate'},
		{type:'presence',field:'terminalId'},
		{type:'presence',field:'status'}
		
	] */
});

Ext.define('AlertRecord', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'alertRecordId',  type: 'int'},
        {name: 'alertCode',  type: 'string'},
		{name: 'alertText',  type: 'string'},
        {name: 'raisedBy',  type: 'string'},
		{name: 'status',  type: 'string'},
		{name: 'remarks', type: 'string'},
        {name: 'version', type: 'int'},
        {name:'trnsType',type:'string'},  
        {name: 'allRemarks', type: 'auto'},
        {name: 'raisedDateTime',  type: 'date' ,dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        			if(v!= null && v!=""){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
            }
        }
        /* 
         * {name: 'raisedDateTime', type: 'date',dateFormat:'d/m/Y H:i:s'}
        {name: 'isDeleted', type: 'string'}, */
        
		
       
    ],
    idProperty: 'alertRecordId',
    /* validations : [
		{type:'presence',field:'rotationNumber'},
		{type:'length',field:'rotationNumber',min:0,max:10},
		{type:'presence',field:'berthNo'},
		{type:'presence',field:'equipmentId'},
		{type:'presence',field:'vesselCode'},
		{type:'presence',field:'etaDate'},
		{type:'presence',field:'terminalId'},
		{type:'presence',field:'status'}
		
	] */
});



Ext.define('AlertConfiguration', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'alertCode',  type: 'string'},
        {name: 'alertText', type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'severity',  type: 'string'},
        {name: 'soundRequired', type: 'string'},
        {name: 'subscribers', type: 'string'},
        {name: 'keys', type: 'string'},
        {name: 'expiryTime', type: 'string'}, 
        {name: 'alertKeysMap', type: 'auto'},
        {name: 'actualSubscribers', type: 'auto'},
        {name:'trnsType',type:'string'},  
        {name: 'alertsubscribersMap', type: 'auto'}, 
        
        
    ],
    idProperty: 'alertCode',
    validations : [
		{type:'presence',field:'alertCode'},
		{type:'length',field:'alertCode',min:0,max:30},
		{type:'presence',field:'alertText'},
		{type:'length',field:'alertText',min:0,max:500},
		{type:'length',field:'description',min:0,max:100},
		{type:'presence',field:'severity'},
		{type:'length',field:'severity',min:0,max:1},
		{type:'presence',field:'soundRequired'},
		{type:'length',field:'soundRequired',min:0,max:1},
		{type:'presence',field:'expiryTime'},
		{type:'length',field:'expiryTime',min:0,max:20}
		
		
	],
	 associations: [{
     	type: 'hasMany',
     	model: 'Subscribers',
     	name: 'alertsubscribersMap',//'actualNumSeriesDetails',
     	primaryKey:'alertCode',//'numSrsId',
     	foreignKey:'alertCode'//'numSrsId', 
     		/*,
     	foreignKey: 'numSrsId',           rule 3, 5 
         associationKey: 'numSrsId' */ /* rule 4, 5 */
     	}]
});


Ext.define('Subscribers', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'alertRoleId',  type: 'int'},
        {name: 'alertCode', type: 'string'},
        {name: 'groupId', type: 'int'},
        {name: 'groupName', type: 'string'},
        {name: 'isActive',  type: 'string'}
        ]/*,
        validations : [
               		{type:'presence',field:'alertCode'},
               		{type:'length',field:'alertCode',min:0,max:30},
               		{type:'presence',field:'alertText'},
               		{type:'length',field:'alertText',min:0,max:50},
               		{type:'presence',field:'severity'},
               		{type:'length',field:'severity',min:0,max:1},
               		{type:'presence',field:'soundRequired'},
               		{type:'length',field:'soundRequired',min:0,max:1}
               		
               	]*/
});

Ext.define('Trailer', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'trailerId',  type: 'string'},
        {name: 'trailerNo', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'trailerId',
    validations : [
		{type:'presence',field:'trailerNo'},
		{type:'length',field:'trailerNo',min:0,max:20}
	]
});


Ext.define('DelayRecording', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'delayRecordingId',  type: 'int'},
        {name: 'rotationNumber',  type: 'string'},
        {name: 'description',  type: 'string'},
        {name: 'mode',  type: 'string'},
        {name: 'equipmentId', type: 'string'},
        {name: 'vesselName', type: 'string'},
        {name:'delayCode', type:'string	' },
        {name: 'startUser', type: 'string'},
        {name: 'endUser', type: 'int'},
        {name: 'status',  type: 'string'},
        {name: 'terminalId',  type: 'string'},
        {name: 'toDate', type: 'date',dateFormat:'d/m/Y H:i:s',
		convert:function(v,record){
        			if(v!= null && v!=""){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
            }
        },
        
        {name: 'fromDate',  type: 'date' ,
        	dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        			if(v!= null && v!=""){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
            }
        },
		{name: 'remarks',  type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        },
        {
        	name:'allEquipments',
        	type:'string'
        }
       
    ],
    idProperty: 'delayRecordingId',
   /*  validations : [
		{type:'presence',field:'rotationNumber'},
		{type:'length',field:'rotationNumber',min:0,max:10},
		{type:'presence',field:'berthNo'},
		{type:'presence',field:'equipmentId'},
		{type:'presence',field:'vesselCode'},
		{type:'presence',field:'etaDate'},
		{type:'presence',field:'terminalId'},
		{type:'presence',field:'status'}
		
	] */
});


Ext.define('BusinessException', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'exceptionId',  type: 'string'},
        {name: 'exceptionType', type: 'string'},
        {name: 'exceptionDesc', type: 'string'},
        {name: 'cotainerId', type: 'string'},
        {name: 'rotationNo', type: 'string'},
        {name: 'functionCode', type: 'string'},
		{name: 'trnsType', type: 'string'},
		{name: 'createdBy', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        }                       
        ],
   	 	idProperty: 'exceptionId',
        associations: [{
        	type: 'hasMany',
        	model: 'BusinessExceptionDetails',
        	name: 'businessExceptionDetails',//'actualNumSeriesDetails',
        	primaryKey:'exceptionId',
        	foreignKey:'exceptionId'
        	}]
}); 

Ext.define('BusinessExceptionDetails', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'pk',  type: 'auto'},
        {name: 'exceptionValue', type: 'string'},
        {name: 'exceptionDesc', type: 'string'},
        {name: 'tempExceptionCode',  type: 'string'},
        {name: 'trnsType', type: 'string'},
		{name: 'createdBy', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        }                        
        ]
        //idProperty: 'rotationNumber',
}); 


Ext.define('VesselException', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'vesselExceptionId',  type: 'string'},
        {name: 'vesselNo', type: 'string'},
        {name: 'rotation', type: 'string'},
        {name: 'exceptionType',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'bay', type: 'string'},
        {name: 'row', type: 'string'},
        {name: 'tier', type: 'string'},
        {name: 'equipmentId', type: 'string'},
        {name: 'vesselName', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
        {name:'trnsType',type:'string' }
        	
    ],
    idProperty: 'vesselExceptionId',
    validations : [
		/* {type:'presence',field:'vesselExceptionId'},
		{type:'length',field:'vesselExceptionId',min:0,max:50},
		{type:'presence',field:'vesselExceptionName'},
		{type:'length',field:'vesselExceptionName',min:0,max:100},
		{type:'presence',field:'make'},
		{type:'length',field:'make',min:0,max:50},
		{type:'presence',field:'model'},
		{type:'length',field:'model',min:0,max:50},
		{type:'presence',field:'vesselExceptionTypeId'},
		{type:'length',field:'vesselExceptionTypeId',min:0,max:10},
		{type:'presence',field:'terminalId'},
		{type:'length',field:'terminalId',min:0,max:50 }*/
	]
});


Ext.define('DamageType', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageTypeId',  type: 'string'},
        {name: 'damageTypeDescription', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'damageTypeId',
    validations : [
		{type:'presence',field:'damageTypeId'},
		{type:'length',field:'damageTypeId',min:0,max:50},
		//{type:'presence',field:'damageTypeDescription'},
		{type:'length',field:'damageTypeDescription',min:0,max:100}
	]
});


Ext.define('DamageLocation', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageLocationId',  type: 'string'},
        {name: 'damageLocationDescription', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'damageLocationId',
    validations : [
		{type:'presence',field:'damageLocationId'},
		{type:'length',field:'damageLocationId',min:0,max:50},
		//{type:'presence',field:'damageLocationDescription'},
		{type:'length',field:'damageLocationDescription',min:0,max:100}
	]
});



Ext.define('NumSrsHeader', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'numSrsId',  type: 'string'},
        {name: 'numsrsType', type: 'string'},
        {name: 'trnsType', type: 'string'},
        
        {name: 'headerId', type: 'string'},
        {name: 'type', type: 'string'},
        {name: 'isDefault', type: 'string'},
        {name: 'isUsed', type: 'string'},
       // {name: 'bayList', type: 'auto'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'}
        
        ],
   	 	idProperty: 'headerId',//'numSrsId',
   	    validations : [
   	                {type:'presence',field:'headerId'},
   		    		{type:'presence',field:'type'},
   		    		{type:'presence',field:'isDefault'},
   		    		{type:'length',field:'headerId',min:0,max:10},
   		    		{type:'length',field:'type',min:0,max:10}
   	                   
   	          /*  {type:'presence',field:'numSrsId'},
	    		{type:'presence',field:'numsrsType'},
	    		{type:'length',field:'numSrsId',min:0,max:10},
	    		{type:'length',field:'numsrsType',min:0,max:10}*/
   		],
        associations: [{
        	type: 'hasMany',
        	model: 'NumberingSeriesDetails',
        	name: 'templateDetails',//'actualNumSeriesDetails',
        	primaryKey:'headerId',//'numSrsId',
        	foreignKey:'headerId'//'numSrsId', 
        		/*,
        	foreignKey: 'numSrsId',           rule 3, 5 
            associationKey: 'numSrsId' */ /* rule 4, 5 */
        	}]
}); 

Ext.define('NumberingSeriesDetails', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'id',  type: 'string'},
        {name: 'seqNo', type: 'string'},
        {name: 'vesselLabel', type: 'string'},
        {name: 'no20Ft',  type: 'string'},
        {name: 'no40Ft', type: 'string'},
        {name: 'trnsType', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'}
        ],
        //idProperty: 'rotationNumber',
        validations : [
    		//{type:'presence',field:'id'},
    		{type:'presence',field:'seqNo'},
    		{type:'presence',field:'vesselLabel'},
    		//{type:'presence',field:'no40Ft'},
    		//{type:'length',field:'numsrsId',min:0,max:10},
    		{type:'length',field:'seqNo',min:0,max:6},
    		{type:'length',field:'vesselLabel',min:0,max:3},
    		//{type:'length',field:'no40Ft',min:0,max:10}
    	]
}); 





Ext.define('RotationControl', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'rotationControlId',  type: 'string'},
        {name: 'rotationNumber',  type: 'string'},
        {name: 'isActiveModified',  type: 'boolean'},
        {name: 'isQCModified',  type: 'boolean'},
        {name: 'equipmentId', type: 'string'},
        {name:'actualEquipmentsList', type:'auto' },
        {name: 'vesselCode', type: 'string'},
        {name: 'vesselNo', type: 'int'},
        {name: 'berthNo',  type: 'string'},
        {name: 'terminalId',  type: 'string'},
        {name: 'errorCount',  type: 'int'},
        {name: 'voyageNo',  type: 'string'}, 
        {name: 'berthSide',  type: 'string'},
        {name: 'eta', type: 'date',dateFormat:'d/m/Y H:i:s'
        	
        },
        
        {name: 'etaDate',  type: 'date' ,
        	dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        			if(v!= null && v!=""){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
            }
        },
		{name: 'status',  type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        },
        {
        	name:'allEquipments',
        	type:'string'
        }
       
    ],
    idProperty: 'rotationControlId',
    validations : [
		{type:'presence',field:'rotationNumber'},
		{type:'length',field:'rotationNumber',min:0,max:10},
		{type:'presence',field:'berthNo'},
		{type:'presence',field:'equipmentId'},
		{type:'presence',field:'vesselCode'},
		{type:'presence',field:'etaDate'},
		{type:'presence',field:'terminalId'},
		{type:'presence',field:'status'},
		{type:'presence',field:'berthSide'}
		
		
	]
});


Ext.define('YardBlock', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'serialNo',  type: 'int'},
        {name: 'xPosition',  type: 'string'},
        {name: 'yPosition', type: 'string'},
        //{name: 'pk',  type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'serialNo'
    /*validations : [
		{type:'presence',field:'rotationNumber'},
		{type:'length',field:'rotationNumber',min:0,max:10},
		{type:'presence',field:'equipmentId'},
		{type:'presence',field:'vesselCode'},
		{type:'presence',field:'eta'},
		{type:'presence',field:'status'}
		
	]*/
});



Ext.define('ColorCode', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'colorCodeId',  type: 'string'},
        {name: 'itemName', type: 'string'},
        {name: 'itemGroup', type: 'string'},
        {name: 'hexaCode',  type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'colorCodeId',
    validations : [
		{type:'presence',field:'colorCodeId'},
		{type:'length',field:'colorCodeId',min:0,max:50},
		{type:'presence',field:'itemName'},
		{type:'length',field:'itemName',min:0,max:100},
		{type:'presence',field:'itemGroup'},
		{type:'length',field:'itemGroup',min:0,max:50},
		{type:'presence',field:'hexaCode'},
		{type:'length',field:'hexaCode',min:0,max:50}
	]
});


Ext.define('ActivityType', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'activityTypeId',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'activityTypeId',
    validations : [
           		
                {type:'presence',field:'activityTypeId'},
                {type:'length',field:'activityTypeId',min:0,max:50}
           	]
});



Ext.define('Equipment', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'equipmentId',  type: 'string'},
        {name: 'equipmentName', type: 'string'},
        {name: 'equipmentDescription', type: 'string'},
        {name: 'make',  type: 'string'},
        {name: 'model', type: 'string'},
        {name: 'equipmentTypeId', type: 'string'},
        {name: 'terminalId', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'pow', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'equipmentId',
    validations : [
		{type:'presence',field:'equipmentId'},
		{type:'length',field:'equipmentId',min:0,max:50},
		{type:'presence',field:'equipmentName'},
		{type:'length',field:'equipmentName',min:0,max:100},
		{type:'presence',field:'make'},
		{type:'length',field:'make',min:0,max:50},
		{type:'presence',field:'model'},
		{type:'length',field:'model',min:0,max:50},
		{type:'presence',field:'equipmentTypeId'},
		{type:'length',field:'equipmentTypeId',min:0,max:10},
		{type:'presence',field:'terminalId'},
		{type:'length',field:'terminalId',min:0,max:50}
	]
});


Ext.define('ActivityCode', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'activityId', type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'activityTypeId',  type: 'string'},
        {name: 'terminalId', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
     ],
     idProperty: 'activityId',
     validations : [
            		
                    {type:'presence',field:'activityId'},
                    {type:'length',field:'activityId',min:0,max:30},
            		{type:'presence',field:'activityTypeId'},
            		{type:'length',field:'activityTypeId',min:0,max:50},
            		{type:'presence',field:'terminalId'},
            		{type:'length',field:'terminalId',min:0,max:50}
            	]  
});



/*Ext.define('User', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'userId',   type: 'string'},
        {name: 'roleId', type: 'string'},
        {name: 'password', type: 'string'},
        {name: 'terminalId', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			else{
    				return "" ;
    			}
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			else{
        				return "" ;
        			}
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        } 
    ], 
    idProperty: 'userId',
    validations : [
           		
                {type:'presence',field:'userId'},
                {type:'length',field:'userId',min:0,max:30},
           		{type:'presence',field:'roleId'},
           		{type:'length',field:'roleId',min:0,max:30},
           		{type:'presence',field:'password'},
                {type:'length',field:'password',min:0,max:50},
           		{type:'presence',field:'terminalId'},
           		{type:'length',field:'terminalId',min:0,max:50}
           	],
});
*/

Ext.define('User', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'userId',   type: 'int'},
        {name: 'userName', type: 'string'},
        {name: 'firstName', type: 'string'},
        {name: 'lastName', type: 'string'},
        {name: 'userDescription', type: 'string'},
        {name: 'accountStatus', type: 'string'},
        {name: 'telephoneNo', type: 'string'},                         
        {name: 'mobileNo', type: 'string'},
    	{name: 'faxNo', type: 'string'}, 
    	{name: 'language', type: 'auto'},
        {name: 'defaultLanguage', type: 'string'},
		{name: 'roles', type: 'auto'},
		{name: 'password', type: 'string'},
		{name: 'actualRoles', type: 'auto'},
		{name: 'emailId', type: 'string'},
		{name: 'loginStatus', type: 'string'},
		{name: 'stringRoles', type: 'string'},
		{name: 'iv', type: 'string'},
		{name: 'salt', type: 'string'},
		{name: 'lastUpdatedBy', type: 'string'},
		{name: 'equipmentId', type: 'string'},
		{name: 'deviceId', type: 'string'},
		 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			else{
        				return "" ;
        			}
        		
            }
        },	
        {name: 'createdBy', type: 'string'},
        {name : 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
    			if(v!= null){
    			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
    			}
    			else{
    				return "" ;
    			}
    		
        }
    },	
       
        {name: 'lastLogin',
    	type: 'date',dateFormat:'d/m/Y H:i:s',
    	convert:function(v,record){
    			if(v!= null){
    			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
    			}
    			else{
    				return "" ;
    			}
    		
        }
    }	
		
         
    ], 
    validations : [
              		
                    {type:'presence',field:'userId'},
              		{type:'presence',field:'userName'},
              		{type:'presence',field:'firstName'},
              		{type:'presence',field:'lastName'},
              		{type:'presence',field:'password'},
              		{type:'presence',field:'accountStatus'},
              		{type:'presence',field:'defaultLanguage'},
              		{type:'presence',field:'roles'},
              		{type:'length',field:'telephoneNo',min:0,max:16},
              		{type:'length',field:'mobileNo',min:0,max:14},
              		{type:'length',field:'faxNo',min:0,max:16},
              		{type:'length',field:'emailId',min:0,max:43}
              	]
   // idProperty: 'userId'
   /* validations : [
           		
                {type:'presence',field:'userId'},
                {type:'length',field:'userId',min:0,max:30},
           		{type:'presence',field:'roleId'},
           		{type:'length',field:'roleId',min:0,max:30},
           		{type:'presence',field:'password'},
                {type:'length',field:'password',min:0,max:50},
           		{type:'presence',field:'terminalId'},
           		{type:'length',field:'terminalId',min:0,max:50}
           	]*/
});


Ext.define('Role', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'intUserGroupId', type: 'int'},
        {name: 'userGroupCd',  type: 'string'},
        {name: 'userGroupName', type: 'string'},
        {name: 'sDesc', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'systemDefined', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'intUserGroupId',
    validations : [
                {type:'presence',field:'userGroupCd'},
                {type:'length',field:'userGroupCd',min:0,max:10},
           		{type:'presence',field:'userGroupName'},
           		{type:'length',field:'userGroupName',min:0,max:4}
           		/*{type:'presence',field:'equipmentTypeId'},
           		{type:'length',field:'equipmentTypeId',min:1,max:4}*/
           	]
});


Ext.define('PinningStation', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'pinningStationId',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'terminalId',  type: 'string'},
        {name: 'availability', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
     ],
     idProperty: 'pinningStationId',
     validations : [
            		
                    {type:'presence',field:'pinningStationId'},
                    {type:'length',field:'pinningStationId',min:0,max:30},
                    {type:'presence',field:'terminalId'},
                    {type:'length',field:'terminalId',min:0,max:50},
                    {type:'presence',field:'availability'},
                    {type:'length',field:'availability',min:0,max:1}
            ] 
});


Ext.define('MoveType', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'moveTypeId',   type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'moveTypeId',
    validations : [
           		
                {type:'presence',field:'moveTypeId'},
                {type:'length',field:'moveTypeId',min:0,max:30}
            ]
});


Ext.define('Direction', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'directionId',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
        
    ],
    idProperty: 'directionId',
    validations : [
           		
                {type:'presence',field:'directionId'},
                {type:'length',field:'directionId',min:0,max:30}	
           	]
});

Ext.define('Checklist', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'checkListId',  type: 'string'},
        {name: 'checkListName', type: 'string'},
        {name: 'description', type: 'string'},
        
        {name: 'mandatory', type: 'string'},
        {name: 'icon', type: 'string'},
        {name: 'category', type: 'string'},
        {name: 'checkListHeaderId', type: 'string'},
        {name: 'checkListHeaderName', type: 'string'},
        
        {name: 'checkListheader', type: 'auto'}, 
        
        
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        /*{name: 'checkListName', type: 'string'},*/
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'checkListId',
    validations : [
           		
                {type:'presence',field:'checkListId'},
                {type:'length',field:'checkListId',min:0,max:38},
           		{type:'presence',field:'checkListName'},
           		{type:'length',field:'checkListName',min:0,max:100},
           		
           		//{type:'presence',field:'description'},
           		{type:'length',field:'description',min:0,max:250},
           		
	           	  {type:'presence',field:'mandatory'},
	              
	              {type:'presence',field:'icon'},
	              {type:'length',field:'icon',min:0,max:38},
	              
	              {type:'presence',field:'category'},
	              {type:'length',field:'category',min:0,max:38},
	              {type:'presence',field:'checkListHeaderName'},
	              {type:'length',field:'checkListHeaderName',min:0,max:38}
	
	           		
              ]
});


Ext.define('CheckListHeader', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'checkListHeaderId',  type: 'string'},
        {name: 'name', type: 'string'},
        {name: 'type', type: 'string'},
        {name: 'roleId', type: 'string'},
        {name: 'allRoles', type: 'string'},
        {name: 'roleName', type: 'string'},
       // {name: 'roleNameList', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        /*{name: 'checkListName', type: 'string'},*/
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'checkListHeaderId',
    validations : [
           		
                {type:'presence',field:'checkListHeaderId'},
                {type:'length',field:'checkListHeaderId',min:0,max:38},
           		{type:'presence',field:'name'},
           		{type:'length',field:'name',min:0,max:100},
           		{type:'presence',field:'type'},
           		{type:'length',field:'type',min:0,max:100}
           		//{type:'presence',field:'roleName'}
           		
           	]
});




Ext.define('QC_Lane', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'laneId',  type: 'string'}, 
        {name: 'laneDescription', type: 'string'},
        {name: 'availability',  type: 'string'},
        {name: 'driveDirection', type: 'string'},
        {name: 'terminalId', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
     ],
     idProperty: 'laneId',
     validations : [
            		
                    {type:'presence',field:'laneId'},
                    {type:'length',field:'laneId',min:0,max:30},
                    {type:'presence',field:'availability'},
                    {type:'length',field:'availability',min:0,max:1},
                    {type:'presence',field:'driveDirection'},
                    {type:'length',field:'driveDirection',min:0,max:30},
                    {type:'presence',field:'terminalId'},
                    {type:'length',field:'terminalId',min:0,max:50}
            	]
});


Ext.define('Terminal', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'terminalId',   type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
        
    ],
    idProperty: 'terminalId',
    validations : [
           		
                {type:'presence',field:'terminalId'},
                {type:'length',field:'terminalId',min:0,max:50}	
           	]
});


Ext.define('Language', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'languageId',  type: 'string'},
        {name: 'languageName', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        } 
    ],
    idProperty: 'languageId',
    validations : [
                {type:'presence',field:'languageId'},
                {type:'length',field:'languageId',min:0,max:4}
           	]
});


Ext.define('Device', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'deviceId', type: 'string'},
        {name: 'deviceDescription', type: 'string'},
        {name: 'ipAddress',  type: 'string'},
        {name: 'listeningPort', type: 'string'},
        {name: 'sendingPort',  type: 'string'},
        {name: 'equipmentId', type: 'string'},
        {name: 'make',  type: 'string'},
        {name: 'model', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
       // {name: 'versionLastUpdatedOn', type: 'string'},
        {name: 'osVersion', type: 'string'},
        {name: 'currentVersion', type: 'string'},
        {name: 'versionLastUpdatedOn',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        }, 
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
     ],
     idProperty: 'deviceId',
     validations : [
                    {type:'presence',field:'deviceId'},
                    {type:'length',field:'deviceId',min:0,max:30},
                    /*{type:'presence',field:'ipAddress'},
                    {type:'length',field:'ipAddress',min:0,max:30},
                    {type:'presence',field:'listeningPort'},
                    {type:'length',field:'listeningPort',min:0,max:5},
                    {type:'presence',field:'sendingPort'},
                    {type:'length',field:'sendingPort',min:0,max:5},*/
                    {type:'presence',field:'make'},
                    {type:'length',field:'make',min:0,max:50},
                    {type:'presence',field:'model'},
            		{type:'length',field:'model',min:0,max:50},
            		{type:'presence',field:'osVersion'},
            		{type:'length',field:'osVersion',min:0,max:20},
            		{type:'presence',field:'currentVersion'},
            		{type:'length',field:'currentVersion',min:0,max:20}
            	]
});


Ext.define('DamageCode', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageCodePk',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'damageSeverityCode',  type: 'string'},
        {name: 'terminalId',  type: 'string'},
        {name: 'damageTypeId',  type: 'string'},
        {name: 'allDamageLocations',  type: 'string'}, 
        {name: 'damageLocationId',  type: 'string'},  
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'damageCodePk',
    validations : [
                {type:'presence',field:'damageCodePk'},
                {type:'length',field:'damageCodePk',min:0,max:50},
           		{type:'presence',field:'damageSeverityCode'},
                {type:'length',field:'damageSeverityCode',min:0,max:50},
           		{type:'presence',field:'terminalId'},
           		{type:'length',field:'terminalId',min:0,max:50},
           		{type:'presence',field:'damageLocationId'},
           		{type:'length',field:'damageLocationId',min:0,max:50},
           		{type:'presence',field:'damageTypeId'},
           		{type:'length',field:'damageTypeId',min:0,max:50}
           		
           	]
});


Ext.define('DamageSeverity', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageSeverityCode', type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'damageSeverityCode',
    validations : [
                {type:'presence',field:'damageSeverityCode'},
                {type:'length',field:'damageSeverityCode',min:0,max:50}
           	]
});

Ext.define('TroubleShootArea', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'troubleShootAreaId',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'terminalId',  type: 'String'},
        {name: 'availability', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        } 
    ],
    idProperty: 'troubleShootAreaId',
    validations : [
           		
                {type:'presence',field:'troubleShootAreaId'},
                {type:'length',field:'troubleShootAreaId',min:0,max:50},
           		{type:'presence',field:'terminalId'},
                {type:'length',field:'terminalId',min:0,max:50},
           		{type:'presence',field:'availability'},
           		{type:'length',field:'availability',min:0,max:1}
           	]
});

Ext.define('DelayReasonCode', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'delayReasonId',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'delayType', type: 'string'},
        {name: 'subType', type: 'string'}, 
        {name: 'alertCode', type: 'string'},
        {name: 'machineStoppage', type: 'string'},
        {name: 'isDelayOpen', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'delayReasonId',
    validations : [
                {type:'presence',field:'delayReasonId'},
                {type:'length',field:'delayReasonId',min:0,max:100},
                {type:'presence',field:'delayType'},
                {type:'length',field:'delayType',min:0,max:50},
                {type:'presence',field:'subType'},
                {type:'length',field:'subType',min:0,max:20},
                {type:'presence',field:'machineStoppage'}
                
           	]
});

Ext.define('ApplicationParameter', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'parameterCode', type: 'string'},
        {name: 'parameterValue', type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'unitId', type: 'string'},
        {name: 'unitName', type: 'string'}, 
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'unit', type: 'auto'},
        
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ], 
    idProperty: 'parameterCode',
    validations : [
                {type:'presence',field:'parameterCode'},
                {type:'length',field:'parameterCode',min:0,max:100},
                {type:'presence',field:'parameterValue'},
                {type:'length',field:'parameterValue',min:0,max:2000},
                {type:'presence',field:'description'},
                {type:'length',field:'description',min:0,max:2000},
                {type:'presence',field:'unitId'},
           	]
});

Ext.define('UnplannedActivities', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'unplannedActivitiesId',   type: 'integer'},
        {name: 'unplannedActivitiesName', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'unplannedActivitiesId',
    validations : [
                {type:'presence',field:'unplannedActivitiesId'},
                {type:'length',field:'unplannedActivitiesId',min:0,max:4},
           		{type:'presence',field:'unplannedActivitiesName'},
           		{type:'length',field:'unplannedActivitiesName',min:0,max:4}
			]
});


 ;

Ext.define('Unit', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'unitId',   type: 'string'},
        {name: 'unitName', type: 'string'},
        {name: 'unitDescription', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'unitId',
    validations : [
                {type:'presence',field:'unitId'},
                {type:'length',field:'unitId',min:0,max:4},
           		{type:'presence',field:'unitName'},
           		{type:'length',field:'unitName',min:0,max:15}
			]
});


Ext.define('Shift', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'shiftId',  type: 'string'},
        {name: 'shiftName', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'shiftId',
    validations : [
                {type:'presence',field:'shiftId'},
                {type:'length',field:'shiftId',min:0,max:4},
           		{type:'presence',field:'shiftName'},
           		{type:'length',field:'shiftName',min:0,max:4}
			]
});

Ext.define('AlertCode', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'alertCodePK',  type: 'string'},
        {name: 'description', type: 'string'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'alertCodePK',
    validations : [
                {type:'presence',field:'alertCodePK'},
                {type:'length',field:'alertCodePK',min:0,max:50}
           	]
});

								          
Ext.define('Vessel', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'vesselNo',  type: 'int'},
        {name: 'vesselCode', type: 'string'},
        {name: 'vesselName', type: 'string'},
        {name: 'vesselType',  type: 'string'},
        {name: 'motherFeeder', type: 'auto'},
        {name: 'length', type: 'int'},
        {name: 'lengthUom', type: 'string'},
        {name: 'width', type: 'int'},
        {name: 'widthUom', type: 'string'},
        {name: 'height', type: 'int'},
        {name: 'teuCapacity', type: 'int'},
        {name: 'version', type: 'int'},
        {name: 'isDeleted', type: 'string'},
        {name: 'createdDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
    				return "" ;
    			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },                         
        {name: 'createdBy', type: 'string'},
    	 {name: 'lastUpdatedDateTime',
        	type: 'date',dateFormat:'d/m/Y H:i:s',
        	convert:function(v,record){
        		if(record.get('trnsType')!='I' && record.get('trnsType')!='U'){
        			if(v!= null){
        			return Ext.Date.format(new Date(v), 'd/m/Y H:i:s');
        			}
        			/*else{
        				return "" ;
        			}*/
        		}
        		else{
        			return v ;
        		}
            }
        },	
        {name: 'lastUpdatedBy', type: 'string'},
        {
        	name:'trnsType',
        	type:'string'				
        }
    ],
    idProperty: 'equipmentId',
    validations : [
	
	]
});


           //          Models for populating combobox  start
                     
                     
Ext.define('equipmentTypeIDModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'equipmentTypeId',  type: 'string'}
        ]                
}); 

Ext.define('terminalIDModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'terminalId',  type: 'string'}
        ]               
});


Ext.define('equipmentIDModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'equipmentId',  type: 'string'},
        {name: 'equipmentName',  type: 'string'}
        
        ]            
});

Ext.define('activityTypeIDModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'activityTypeId',  type: 'string'}
        ]             
});


Ext.define('damageSeverityCodeModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageSeverityCode',  type: 'string'},
        {name: 'description',  type: 'string'},
        
        ]              
});

Ext.define('roleIDModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'roleId',  type: 'string'}
        ]             
});

Ext.define('unitNameModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'unitName',  type: 'string'},
        {name: 'unitId',  type: 'string'}
        
        ]             
});

Ext.define('roleNameModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'userGroupName',  type: 'string'},
        {name: 'intUserGroupId',  type: 'int'}
        
        ]             
});

Ext.define('checkListHeaderIdModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'checkListHeaderId',  type: 'int'},
        {name: 'name',  type: 'string'},
        {name: 'type',  type: 'string'}
        
        ]         

});

Ext.define('vesselModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'vesselCode',  type: 'string'},
        {name: 'vesselName',  type: 'string'},
        {name: 'vesselNo',  type: 'int'}
        //{name: 'type',  type: 'string'}
        
        ]         

});

Ext.define('languageModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'languageName',  type: 'string'},
        {name: 'languageCode',  type: 'string'}
        ]         

});

Ext.define('terminalModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'terminalId',  type: 'string'},
        {name: 'description',  type: 'string'}
        ]         

});

Ext.define('rowSeriesFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'numSrsId',  type: 'string'},
        {name: 'numsrsType',  type: 'string'}
        ]         

});;


Ext.define('rowSeriesStartFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'numsrsId',  type: 'string'},
        {name: 'seqNo',  type: 'string'}
        ]         

});

Ext.define('truckLaneFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'truckLaneID',  type: 'string'},
        {name: 'descr',  type: 'string'},
        {name: 'tmnlNo',  type: 'int'}
        ]         

});

Ext.define('damageTypeModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageTypeId',  type: 'string'},
        {name: 'damageTypeDescription',  type: 'string'}
        ]               
});

Ext.define('damageLocationModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'damageLocationId',  type: 'string'},
        {name: 'damageLocationDescription',  type: 'string'}
        ]               
});


Ext.define('delayReasonCodeModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'delayReasonId',  type: 'string'},
        {name: 'description',  type: 'string'}
        ]               
});

Ext.define('rotationModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'rotationNumber',  type: 'string'},
        {name: 'berthNo',  type: 'string'}
        ]
});

Ext.define('userModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'userId',  type: 'string'},
        {name: 'userName',  type: 'string'}
        ]               
});

Ext.define('deviceModelFK', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'deviceId',  type: 'string'}
        ]               
});


//          Models for populating combobox  End