	
Modules.GlobalFuncs.appStartup = function(userId){
	// Prepare menu
	
var preapareMenu = function(){
		
		Ext.getBody().mask('Preparing menu...');

		Ext.Ajax.request({
			url : 'menuItem/list.action',
			method : 'POST',
			params : { userId : userId},
			success : function(response) {
				
				if(response.responseText){
					var dynamicJSON = response.responseText;
					Ext.getBody().mask('Loading dashboard ...');
					
					var jsonArray = Ext.decode(dynamicJSON);

				var mainData=  Ext.decode(jsonArray.menuObject);
				prepareViewport(headerMenu,mainData);
				
				Modules.GlobalVars.funAccessCodeObject=jsonArray.funActionObject;
				if(mainData.length==0)
				{
					Ext.MessageBox.show({
						title : "No Access",
						msg : "Sorry,You don't have access to any screen. ",
						buttons : Ext.MessageBox.OK,
						icon : Ext.MessageBox.INFO
					});
				}
				/*	var bottomToolbar = Ext.create('Ext.toolbar.Toolbar', {
						id : 'mainPan',
						height : 25,
						layout : 'fit',
						width : 1500,
						layout : {
							overflowHandler : 'Menu'
						}
					});
					
					
					Ext.Ajax.request({
						url : 'gridState/getAllGridState',
						method : 'POST',
						params : { userId : Modules.GlobalVars.loginUserId},
						success : function(response) {
								
							if(response.responseText){
								
								Modules.GlobalVars.gridStatObj = Ext.decode(response.responseText);  
							}
							prepareViewport(staticJSON,mainData);
							Ext.getBody().unmask(); 
							// Creatiion of Veiwport is done
						},
						failure : function() {
							prepareViewport(staticJSON,mainData);
							Ext.getBody().unmask(); 
						} 

					});*/
				}
			}
		});
		

	};
	
	
	
	
	
	var prepareViewport = function(staticJSON,mainData){
		
		staticJSON = staticJSON || [];
		mainData =  mainData || [];
		
		new Ext.Viewport({
			layout : "border",
			id: 'masterViewportId',
			items:[	{
				region: 'north',
				xtype: 'panel',
				layout:'column',
				height: 55,
				bodyCls : 'x-toolbar-sencha',
				items : staticJSON

			}, {
				xtype: "cmctabpanel",
				region: 'center',
				id:'centerPanelId',
				layout: 'fit',
				tbar : Ext.create('Ext.toolbar.Toolbar', {
					id : 'MainToolbarId',
					cls:'main-toolbar-headerbg',
					layout : {
						overflowHandler : 'Menu'
					},
					items : mainData // this will be menu [{text:'Name',items:[{text:'a'}]},{text:'Name1'}]
				}),
				listeners:{
					render:function(){
						showDashboardScreen();
					},
					tabchange:function(tab,newCard,oldCard){
						
					}
				},
				items : [ ]
			}
			]
		});
	};
	//Modules.GlobalVars.loginUserName = 'User 1';
	
	var headerMenu = [{
	    	   xtype: 'component',
	    	   iconCls: 'minapro-logo',
	    	   cls: 'minapro-logo',
	    	   columnWidth:.65
	    	   //height : 76
	    	   },
	    	   
	    	   {
	    		   xtype: 'image',
	    		   fieldLabel: 'DPW',
	    		   margins : '0 5 0 0',
	    		   cls: 'dpw-logo',
	    		  // columnWidth:.26
	    		   /*width: 50,  15px 46px 3px 51px
	    		       height: 50*/
	    		   },
	    	   	    	   	    	   
	    	   {
		       xtype:'container',
		       layout:'column',
		       margin:'2px 0px 2px 0px',
		       columnWidth:.35,
		       defaults:{
		    	margin:'0px 5px 5px 0px'
		       },
		       items:[ 

		               {
				xtype : 'label',
				forId : 'versiodId',
				style:'color:#FFFFFF;',
				text :  'Version: '+Modules.GlobalVars.appVersion,
				margins : '0 5 0 0',
				columnWidth:.3
			},{
				xtype : 'label',
				forId : 'myFieldId',
				style:'color:#FFFFFF;',
				text : 'Welcome: '+Modules.GlobalVars.loginUserName,
				margins : '0 10 0 0',
				columnWidth:.36
			},{
        	   xtype: 'button',
        	   iconCls: 'help-icon',
        	   text:'Help',
        	   columnWidth:.15,
        	   handler: function() {
        		/*   var win = window.open('vesselProfile.jsp', '_blank');
        		   if(win){
        		       //Browser has allowed it to be opened
        		       win.focus();
        		   }else{
        		       //Broswer has blocked it
        		       alert('Please allow popups for this site');
        		   }*/
        		   
			    }
    	   },{
				xtype : "button",
				iconCls : "logout-icon",
				text:'Logout',
				columnWidth:.18,
				handler: function() {
					Ext.Msg.confirm('Logout', 'Are you sure you want to logout?', function(btn){
						if (btn === 'yes'){
							window.location = 'user/logout' ;//'j_spring_security_logout' ; //'logout';  '/user/logout' ;
						}
					});
			    }
			}]}
			];
	
	
	//prepareViewport(headerMenu);
	//loadUserDetails();
	preapareMenu();

};