/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.ViaComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmcviacombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.viaNoLbl,
	displayField: 'viaNo',
	valueField:'intViaNo',
	paging:true,
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function() {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{viaNo}</td><td width="125px" align="left">{vslName}</td></tr><tr><td height="2"></td></tr><tr valign="top"><td align="left">{etaDttm}</td><td align="left">{etdDttm}</td></tr><tr><td height="2"></td></tr><tr valign="top"><td align="left">{dschVoyNo}</td><td align="left">{ldVoyNo}</td></tr><tr><td colspan="2" height="5"></td></tr></table>';
		}
	},
	validateUrlCmc:'lookup/validatevialookup',
	storeObjCmc:{},
	validateParamsCmc:{},
	valdidateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this; 
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'ViaNoComboModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'lookup/vialookup';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});