Ext.define('Ext.cmc.Displayfield', {
   
	extend: 'Ext.form.field.Display',
	
	alias: 'widget.cmcdisplayfield',//Defining the xtype
	
	/*Beginning of assigning values to already existing config options*/
	fieldStyle:'text-transform:uppercase',
	maxHeight:22,
	labelAlign:'right',	
	/*Ending of assigning values to already existing config options*/
	
	initComponent:function(){
		var me	=	this;
		me.callParent();//No arguments passed as per the docs in API		
	}
});