/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.CfsComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmccfscombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.cfsLbl,
	displayField:'cstmrCd',
	valueField:'cstmrCd',
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:100,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function() {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="40px">{cstmrCd}</td><td>{cstmrNm}</td></tr><tr><td height="5" colspan="2"></td></tr></table>';
		}
	},
	validateUrlCmc:'EntityLookup/validateDepotOpr',
	storeObjCmc:{},
	validateParamsCmc:{},
	valdidateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'CstmerDtlsComboModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'EntityLookup/getDepotOprs';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});