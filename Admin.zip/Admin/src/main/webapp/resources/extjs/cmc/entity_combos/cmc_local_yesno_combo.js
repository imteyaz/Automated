/*
	*Following file contains more than one version of the extended component of combobox
*/
Ext.define('Ext.cmc.LocalYesNoComboBox', {
   
	extend: 'Ext.cmc.ComboBox',
	alias: 'widget.cmclocalyesnocombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	queryMode: 'local',
	forceSelection:true,
	/*Beginning of assigning values to already existing validate config options*/
	validateOnBlur:false,
	/*Ending of assigning values to already existing validate config options*/
	/**Ending the setting of values for already existing configs**/
	storeObjCmc:{},
	validateParamsCmc:{},
	valdidateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	initComponent:function(){
		var me	=	this;
		var storeObjCmc		=		{
			model:'IntExtFxdDmModel',
			data:[
				{intFxdDomCd:'Y', extFxdDomCd:'Yes'},
				{intFxdDomCd:'N', extFxdDomCd:'No'}
			],
			queryTypeCmc:'local'
		};
		me.storeObjCmc		=		storeObjCmc;
		me.callParent();//No arguments passed as per the docs in API		
	}
});