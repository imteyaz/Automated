Ext.define('Ext.cmc.Button', {
   
	extend: 'Ext.Button',
	
	alias: 'widget.cmcbutton'
});
