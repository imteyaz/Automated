/*
	**Following component extends panel
	**It applies the border layout and has functions which can be used to add items in center, north, east, south and west regions
	**It also has buttons - Clear, Retrieve, Add, Delete, Save, Exit and ability to add extra tbar
	**The component can be further extended to get specific layouts, like - form-grid-form etc.
*/
Ext.define('Ext.cmc.TabParentPanel',{

	extend: 'Ext.panel.Panel',
	alias: 'widget.cmctabparentpanel',
	
	/***Beginning the config properties which already exist in the component**/
	layout:'border',
	closable:true,
	forceCloseCmc:false,// Need not to alert for modification
	/***Ending the config properties which already exist in the component**/
	
	/**
		**Beginning the list of new properties added
		**The following properties could be added in config object
			**But if config object is used then we need to call initConfig in the constructor
			**Calling initConfig object in the constructor generates the errors for some of the components, for example, grid with columnLines, title etc..
			**If initConfig is not used but properties are specified in the config object, then these properties don't get added to the component
			**Config object has not been properly integrated/removed from ExtJs 4 series. Its expected to be either completely integrated or may be even flushed out in ExtJs 5 version
			**The only loss of not using config and initConfig is that the accessor methods don't get created - get, set, reset, apply
			**If required these methods can also be created manually, otherwise the new properties can be changed directly too with caution
	**/
	
	clearBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getClearAction
	retrieveBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getRetrieveAction
	addBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getAddAction
	deleteBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getDeleteAction
	markDelBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getMarkDeleteAction
	unmarkDelBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getUnMarkDeleteAction
	saveBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getSaveAction
	
	showExtraTbarCmc:false,//Set it to true to add the extra tbar, like buttons for Reports etc..
	
	showCenterItemCmc:true,//Set this to false in order to stop displaying the center region though not advised to do so as center regions is a must with border layout
	
	showNorthItemCmc:false,//Set this to true in order to display the north item
	northHeightFactorCmc:0.2,//Provide the height factor for north region which will be multiplied with the panel height
	
	showEastItemCmc:false,//Set this to true in order to display the East item
	eastWidthFactorCmc:0.2,//Provide the width factor of east region which will be multiplied to the width of the panel
	
	showSouthItemCmc:false,//Comments same as north region above
	southHeightFactorCmc:0.2,
	
	showWestItemCmc:false,//Comments same as east region above
	westWidthFactorCmc:0.2,
	
	/*
		**Following is the property which is used to hold the argument object passed to the function creating the panel
		**This property can be used to be further passed to other functions so that they can access the arguments passed to panel function
		**Sample object which should be passed to it is as
			var obj	=	{'key1':'val1', 'key2':'val2', 'key3':'val3'};
		**Note that me.panelFuncArgObjCmc is passed as an argument only to those functions which are overridden by the instance
		**All other functions which are not supposed to be used by the instance, they can access this value without being passed as an argument
	*/
	panelFuncArgObjCmc:{},
	
	/**Ending the list of new properties added**/
	
	initComponent:function(){
		var me		=		this;
		me.setTbarFuncCmc();//Calling this function for setting TBar
		me.setItemsFuncCmc();//Calling this function for setting the Items
		me.callParent();//No arguments passed as per the docs in API
		/*
			**Below is the list of events to be associated with this component
			**These statments can be written either above or below callParent() statment
			**If written after the callParent() statment, then first the event associated with the instance created is called and then the one written in component
			**If written before callParent(), then first this component's method will be called and then the one written in instance's afterrender
		*/
		me.on('added', me.addedPanelFuncCmc);//Associating a function with the event
		//me.on('afterrender', me.afterRenderPanelFuncCmc);//Associating a function with the event
		
		me.on('render',me.applyUserSecurity);
		me.on('beforeclose',me.checkForGridDataModification);
	},
	// Applies user security based restrictions
	applyUserSecurity : function(parentPanel){
		var grids = parentPanel.query('cmcgrid');
		grids = grids.concat(parentPanel.query('grid'));
		
		if(parentPanel._accessCode == undefined){ // this condition becomes true, when screen opened from grid column hyperlink
			var functionList=Modules.GlobalVars.funAccessCodeObject
			if(parentPanel._functionCode){
			for(var i=0;i<functionList.length;i++){
				var obj=functionList[i];
				if(obj.code && (parentPanel._functionCode === obj.code)){
					parentPanel._accessCode=obj.accessCode;
					break;
				}
					
				}
		}
		}
		
		
		
		
		if(parentPanel._accessCode && parentPanel._accessCode == 4){
			
			
			//1. Disable the grid editing
			
			if (grids.length) {
				for (var i = 0, l = grids.length; i < l; i++) {
					grids[i].plugins && grids[i].getPlugin('editorPlugin') && (grids[i].getPlugin('editorPlugin').startEdit=Ext.emptyFn );
				}
			}
			
			//2. Hide Add buttons
			
			var addButtons = parentPanel.query('[iconCls=add]');
			if (addButtons.length) {
				for (var i = 0, l = addButtons.length; i < l; i++) {
					addButtons[i].setVisible(false);
				}
			}
			
			//3. Hide Delete buttons
			
			var deleteButtons = parentPanel.query('[iconCls=delete]');
			if (deleteButtons.length) {
				for (var i = 0, l = deleteButtons.length; i < l; i++) {
					deleteButtons[i].setVisible(false);
				}
			}
			
			//4. Hide Save button
			
			var saveButtons = parentPanel.query('[iconCls=save]');
			if (saveButtons.length) {
				for (var i = 0, l = saveButtons.length; i < l; i++) {
					saveButtons[i].setVisible(false);
				}
			}
			
			//5. Hide Import button
			
			var importButtons = parentPanel.query('[iconCls=upload]');
			if (importButtons.length) {
				for (var i = 0, l = importButtons.length; i < l; i++) {
					importButtons[i].setVisible(false);
				}
			}
			
          //6. Hide Copy button
			
			var copyButtons = parentPanel.query('[iconCls=copy_invoice]');
			if (copyButtons.length) {
				for (var i = 0, l = copyButtons.length; i < l; i++) {
					copyButtons[i].setVisible(false);
				}
			}
			
           //7. Hide Paste button
			
			var pasteButtons = parentPanel.query('[iconCls=paste]');
			if (pasteButtons.length) {
				for (var i = 0, l = pasteButtons.length; i < l; i++) {
					pasteButtons[i].setVisible(false);
				}
			}
			
			
		/*	//8. Hide the editing button
			
			if (grids.length) {
				for (var i = 0, l = grids.length; i < l; i++) {
					grids[i].columns[0].setVisible(false);
				}
			}*/
			
			
		}else if(parentPanel._accessCode && parentPanel._accessCode == 3){
			//QUERY/INSERT
			//1. Disable the grid editing
		//	var grids = parentPanel.query('cmcgrid');
			if (grids.length) {
				for (var i = 0, l = grids.length; i < l; i++) {
					
					if(grids[i].plugins && grids[i].getPlugin('editorPlugin')){
						grids[i].getPlugin('editorPlugin').on('beforeedit', function(editor,e,eOpts){
							if((e.record.data.trnsType && e.record.data.trnsType == 'I') || (e.record.data.transType && e.record.data.transType == 'I') || (e.record.data.status && e.record.data.status == 'I')){
								//return true;
							}else{
								return false;
							}
						});
					}
					//grids[i].getPlugin('editorPlugin') && (grids[i].getPlugin('editorPlugin').startEdit=Ext.emptyFn );
				}
			}
			
			/*//2. Hide the editing button
			
			if (grids.length) {
				for (var i = 0, l = grids.length; i < l; i++) {
					grids[i].columns[0].setVisible(false);
				}
			}*/
			

			var deleteButtons = parentPanel.query('[iconCls=delete]');
			if (deleteButtons.length) {
				for (var i = 0, l = deleteButtons.length; i < l; i++) {
					deleteButtons[i].setVisible(false);
				}
			}
			
		}else if(parentPanel._accessCode && parentPanel._accessCode == 2){
			
		//QUERY/INSERT/UPDATE/
			
		     //3. Hide Delete buttons
		//	var grids = parentPanel.query('cmcgrid');

			var deleteButtons = parentPanel.query('[iconCls=delete]');
			if (deleteButtons.length) {
				for (var i = 0, l = deleteButtons.length; i < l; i++) {
					deleteButtons[i].setVisible(false);
				}
			}
			
		}else if(parentPanel._accessCode && parentPanel._accessCode == 1){
			// FULL CONTROL ,QUERY/INSERT/UPDATE/DELETE
			
			//Nothing to do
		}
		
		if(parentPanel.applyExtraUserSecurity && parentPanel._accessCode){ 
			parentPanel.applyExtraUserSecurity(parentPanel._accessCode);
		}
		
	},
	
	setTbarFuncCmc:function(){
		
		var me		=		this;
		
		me.tbar		=		[];//Setting TBar to an empty array	
		
		/*if(me.title){
			var titleObj		=		{
				xtype:'tbtext',
				text:"<span style='font:italic bold 12px/30px Georgia, serif;'>"+me.title+"</span>"				
			};
			me.tbar[me.tbar.length]		=	titleObj;
			me.tbar[me.tbar.length]		=	'->';
		}*/
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.clearBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getClearAction(me.clearBtnObjCmc);
		}
		
		if(me.retrieveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getRetrieveAction(me.retrieveBtnObjCmc);
		}
		
		//me.tbar[me.tbar.length]	=	'->';//This line has been added to create the space after Retrieve button
		
		if(me.showExtraTbarCmc){
			var extraTbar		=		me.setExtraTbarFuncCmc(me.panelFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraTbar && extraTbar.length && extraTbar instanceof Array && Object.prototype.toString.call(extraTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraTbar);
			}
		}
		
		if(me.addBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getAddAction(me.addBtnObjCmc);
		}
		
		if(me.deleteBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getDeleteAction(me.deleteBtnObjCmc);
		}
		
		if(me.markDelBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getMarkDeleteAction(me.markDelBtnObjCmc);
		}
		
		if(me.unmarkDelBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getUnMarkDeleteAction(me.unmarkDelBtnObjCmc);
		}
		
		if(me.saveBtnObjCmc.handler){
			me.tbar[me.tbar.length]	=	'->';
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getSaveAction(me.saveBtnObjCmc);
		}
		
		
		if(!me.tbar.length){
			delete me.tbar;//Deleting the tbar if no buttons have been added so far
		}			
	},
	
	//Following function can be used to set the extra buttons in the tbar
	setExtraTbarFuncCmc:function(panelFuncArgObjCmc){
		//This function will carry the code of buttons specific to the panel
		//This function should return an array of button definitions including the spacers if required
		/*
			Example:
			[
				{
					text:'Report'
					handler:function(){}
				},
				{
					text:'Copy To All',
					handler:function(){}
				},
				'->'//Use only if the buttons need to be in the center of panel's tbar
			]
		*/
	},
	
	//Following function is used to set the items for the panel
	setItemsFuncCmc:function(){
		
		var me		=		this;//panel component being assigned ot variable me
		
		me.items	=		[];//Assigning an empty array to the items
		
		
		if(me.showCenterItemCmc){
			var centerObj				=	me.setCenterItemFuncCmc(me.panelFuncArgObjCmc);//Getting the object for the center region
			if(!centerObj.region){
				centerObj.region		=	'center';//Assigning the region as center if not already assigned
			}
			me.items[me.items.length]	=	centerObj;
		}
		
		if(me.showNorthItemCmc){
			var northObj				=	me.setNorthItemFuncCmc(me.panelFuncArgObjCmc);
			if(!northObj.region){
				northObj.region			=	'north';//Assigning the north region if not already assigned
			}
			if(!northObj.height){
				northObj.height			=	me.northHeightFactorCmc*me.height;//Assigning the height if not already given
			}
			if(!northObj.collapsible && typeof northObj.collapsible != 'boolean'){
				northObj.collapsible	=	true;//Setting the collapsible value to true here
			}
			me.items[me.items.length]	=	northObj;
		}
		
		if(me.showEastItemCmc){
			var eastObj					=	me.setEastItemFuncCmc(me.panelFuncArgObjCmc);
			if(!eastObj.region){
				eastObj.region			=	'east';//Assigning the east region if not already assigned
			}
			if(!eastObj.width){
				eastObj.width			=	me.eastWidthFactorCmc*me.width;//Assigning the width if not already assigned
			}
			if(!eastObj.collapsible && typeof eastObj.collapsible != 'boolean'){
				eastObj.collapsible	=	true;//Setting the collapsible value to true here
			}
			me.items[me.items.length]	=	eastObj;
		}
		
		if(me.showSouthItemCmc){
			var southObj				=	me.setSouthItemFuncCmc(me.panelFuncArgObjCmc);
			if(!southObj.region){
				southObj.region			=	'south';
			}
			if(!southObj.height){
				southObj.height			=	me.southHeightFactorCmc*me.height;
			}
			if(!southObj.collapsible && typeof southObj.collapsible != 'boolean'){
				southObj.collapsible	=	true;//Setting the collapsible value to true here
			}
			me.items[me.items.length]	=	southObj;
		}
		
		if(me.showWestItemCmc){
			
			var westObj					=	me.setWestItemFuncCmc(me.panelFuncArgObjCmc);
			if(!westObj.region){
				westObj.region			=	'west';
			}
			if(!westObj.width){
				westObj.width			=	me.westWidthFactorCmc*me.width;
			}
			if(!westObj.collapsible && typeof westObj.collapsible != 'boolean'){
				westObj.collapsible	=	true;//Setting the collapsible value to true here
			}
			if(!westObj.xtype){
				westObj.xtype			=	'panel';
			}
			
			me.items[me.items.length]	=	westObj;
		}
		
		if(!me.items.length){
			delete me.items;//Deleting items if no children added
		}
	},
	
	/*
		**Following function is used to get the center item for the panel
		**The function should return a component with properties specified as per the requirement
		**Region and height/widht could be ommitted
		**The code written in the function currently below is just for an example
	*/
	setCenterItemFuncCmc:function(panelFuncArgObjCmc){
		var me		=		this;
		var obj		=		{
			html:'I am in the center region',
			title:me.centerItemTitleCmc
		};
		return obj;
	},
	
	//Comments same as for center region
	setNorthItemFuncCmc:function(panelFuncArgObjCmc){
		var me		=		this;
		var obj		=		{
			html:'I am in the north region',
			title:me.northItemTitleCmc
		};
		return obj;
	},
	
	//Comments same as for center region
	setEastItemFuncCmc:function(panelFuncArgObjCmc){
		var me		=		this;
		var obj		=		{
			html:'I am in the east region',
			title:me.eastItemTitleCmc
		};
		return obj;
	},
	
	//Comments same as for center region
	setSouthItemFuncCmc:function(panelFuncArgObjCmc){
		var me		=		this;
		var obj		=		{
			html:'I am in the south region',
			title:me.southItemTitleCmc
		};
		return obj;
	},
	
	//Comments same as for center region
	setWestItemFuncCmc:function(panelFuncArgObjCmc){
		var me		=		this;
		var obj		=		{
			html:'I am in the west region',
			title:me.westItemTitleCmc
		};
		return obj;
	},
	
	/*
		**Following function has been created for being called at afterrender
		**This function unmask the body, as generally when a panel is displayed then body is masked with loading message
	*/
	/* afterRenderPanelFuncCmc:function(){
		Ext.getBody().unmask();
	} */
	/*
		**Function for unmasking has been changed from afterrender to added as the panel is added first to tabpanel after unmask needs to be done
	*/
	addedPanelFuncCmc:function(){
		Ext.getBody().unmask();
	},
	
	checkForGridDataModification: function(panel){
		
		if(this.forceCloseCmc) return true;// Close anyways
		
		var grids = panel.query('cmcgrid');
		grids = grids.concat(panel.query('grid'));
		grids=Ext.Array.unique(grids); // To remove duplicate records
		var isModified=false;
		var me =this;
		if (grids.length) {
			for (var i = 0, l = grids.length; i < l; i++) {
				var array=grids[i].getStore().getModifiedRecords();
				var delArray=grids[i].getStore().getRemovedRecords();
				if(array.length != 0 || delArray.length != 0 ){
					isModified=true;
					break;
				}
			}
		}
		if(isModified){
			Ext.MessageBox.confirm(Modules.Msgs.confirmBeforeCloseTitle, Modules.Msgs.saveBeforeClosingConfirmation, function (answer) {
                if (answer == "yes") {
                	me.forceCloseCmc=true;
                	me.close(); 
                }
            });
			return false;
		}
	}
});