/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.PolComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the Combobox
	alias: 'widget.cmcpolcombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.polLbl,
	displayField: 'portCD',
    valueField: 'portCD',
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function () {
				return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" 					align="left">{portCD}</td><td width="125px" align="left">{portNM}</td></tr></table>';
		}
	},
	validateUrlCmc:'EntityLookup/validateVoyPort',
	storeObjCmc:{},
	validateParamsCmc:{},
	valdidateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'PortComboModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'EntityLookup/getAllPorts';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});