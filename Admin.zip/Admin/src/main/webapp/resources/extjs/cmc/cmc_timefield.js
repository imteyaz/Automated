Ext.define('Ext.cmc.Timefield', {
   
	extend: 'Ext.form.field.Time',
	alias: 'widget.cmctimefield',
    
	/*Beginning of assigning values to already existing config options*/
    focusCls:'focusClass',
	format:'H:i',
	altFormats:'hi',
	increment:1,
	maxHeight:20,
	labelAlign:'right',
	fieldStyle:'text-transform:uppercase',
	/*Ending of assigning values to already existing config options*/
	
	initComponent:function(){
		var me	=	this;
		me.on('beforerender',me.beforeRenderFuncCmc);
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	beforeRenderFuncCmc:function(){
		var me		=		this;
		if(!me.allowBlank)
			me.labelStyle = 'color:#000000';	
		
		if(me.readOnly){
			me.fieldCls	=	'readOnlyClass';
		}		
	},
	setValue: function(val){
		if( !Ext.isEmpty(val) && !Ext.isDate(val)){
			var dateVal = new Date(val);
			if(isNaN(dateVal)){
				val = Ext.Date.parse(val, this.format);
			}else{
				val = dateVal;
			}
			Ext.form.field.Time.prototype.setValue.call(this,val);
		}else{
			Ext.form.field.Time.prototype.setValue.call(this,val);
		}
	},
	setReadOnly : function(val){
		Ext.form.field.Time.prototype.setReadOnly.call(this,val);
		if(val){
			Ext.form.field.Time.prototype.setFieldStyle.call(this,'background:#C7C9BE;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.form.field.Time.prototype.fieldStyle+';');
         }else{
        	 Ext.form.field.Time.prototype.setFieldStyle.call(this,'background:#FFFFFF;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.form.field.Time.prototype.fieldStyle+';');
         }
	}
	
	
});