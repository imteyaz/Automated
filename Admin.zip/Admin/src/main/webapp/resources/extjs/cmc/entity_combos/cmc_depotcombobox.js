/*
	*Following file contains more than one version of the extended entity component of combobox
	*This file Give The Default Value Of Deport Origin Combo Model 
	*Use for Deport use this
		*Use Store
			var deportStoreObj = {
				url: 'masterslookup/getdepotlist'
			};
	*and In ComboBox use this
		fieldLabel: Modules.LblsAndTtls.depotCodeLbl,
		storeObjCmc: deportStoreObj,
		validateParamsCmc:[{name:'depotCd', id:Modules.CompIds.deportId}],
		validateUrlCmc: 'masterslookup/validatedepot',
*/
Ext.define('Ext.cmc.entityCombos.DepotComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmcdepotcombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel: Modules.LblsAndTtls.depotCodeLbl,	
	displayField: 'depotCd',
	valueField:'depotCd',
	paging:true,
	matchFieldWidth:false,
	queryMode: 'remote',
	listConfig: {
		width: 250,
		loadingText: 'Loading...',
		height: 250,
		deferEmptyText: false,
		emptyText: 'No Values Found!',
		getInnerTpl: function () {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{depotCd}</td><td width="125px" align="left">{depotDescr}</td></tr></table>';
		}
	},
	validateUrlCmc:'masterslookup/validatedepot',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this; 
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'DepotCodeModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'masterslookup/getdepotlist';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});