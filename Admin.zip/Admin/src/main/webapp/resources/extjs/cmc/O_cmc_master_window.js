Ext.define('MetaModel', {/***Model for Grid***/
	extend: 'Ext.data.Model'
});

Ext.define('Ext.cmc.Master.Window_O',{
	extend: 'Ext.window.Window',
	alias: 'widget.cmcmasterwindow',
	showUrl:'',
	getretrieveUrl:'',
	getsaveUrl:'',
	getdeleteUrl:'',
	columnLength:'',
	getkeyFields:'',
	getdupCheckFields:'',
	getmasterQueryParamFields:'',
	metaStore:'',
	frame:false,
	width:1000,
	/***Beginning the config properties which already exist in the component**/
	onEsc:Ext.emptyFn,
	constrain:true,
	modal:true,
	autoScroll:true,
	tbar:[{
		text:"Clear",
		iconCls:"clear",
		handler:function(){
			var winMain = this.ownerCt.ownerCt;
			var getQueyForm = winMain.child('#masterQueryParamForm').getForm();
			var mainForm = Ext.ComponentQuery.query('[xtype=writerform]');
			var getMainForm = mainForm[0];
			
			getMainForm.onReset();	
			getQueyForm.reset();	
		}
	},{
		text:"Retrieve",
		iconCls:"retrieve",
		handler:function(){/***Retrieve the records according to the appropriate URL**/
			var winMain = this.ownerCt.ownerCt;
			var gridObj = winMain.child('#masterGrid');
			var form = winMain.child('#masterQueryParamForm').getForm();
			
			gridObj.getStore().loadPage(1,{params:form.getValues()}); 
			
			winMain.onConvert();
		}
	}],
	/* layout:{
		type:'table',
		columns:2
	}, */
	initComponent:function(){
		var me		=		this;
		me.callParent();//No arguments passed as per the docs in API
		me.on('boxready', me.boxReadyWinFuncCmc);//Associating a function with the event
	},
	boxReadyWinFuncCmc:function(me,width,height,eOpts ){
		var win = this;
		var gridObj = win.items.items[1];
		
	/***Setting the window position according to the resize***/
	
		var mainTabHeight = Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight();
		if(mainTabHeight > height){
			win.setPosition(this.x,120);
			
			win.setHeight(Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight()-70);
		}
		else if(mainTabHeight < height){
			win.setHeight(Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight()-70);
			win.setPosition(this.x,120);
		}
		
		Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).on('resize',function(){
			win.setHeight(Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight()-70);
		});
		
	/***Setting the window position according to the resize***/	
	
		var gridObj = this.child('#masterGrid');
		
		
		var deleteMenu = Ext.create('Ext.menu.Menu', {
			items: [{
				text: 'Delete',
				iconCls: 'edit',
				handler: function () {
					var getMainForm = Ext.ComponentQuery.query('[xtype=writerform]');
					var form = getMainForm[0].getForm();
					var body = Ext.getBody();
					body.mask(Modules.Msgs.processing);
					Ext.MessageBox.confirm(Modules.Msgs.confirmationRequested, Modules.Msgs.deleteConfirmation, function(btn){
						if(btn=='yes'){//Checking if the user pressed YES button
							form.submit({
								url:win.getdeleteUrl,
								method: 'POST',
								params:{
									trnsType:"D"
								},
								success: function (form, action) {
									var sm = gridObj.getSelectionModel();
									gridObj.getStore().remove(sm.getSelection());
									if (gridObj.getStore().getCount() > 0) {
										sm.select(0);
									}
									Ext.MessageBox.show({
										title: Modules.Msgs.DeleteInfo,
										msg: Modules.Msgs.DeleteInfoMsg,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.INFO
									});	
									body.unmask();
								},
								failure: function (form, action) {
									Modules.GlobalFuncs.displayFormErrors({
										form:form,
										responseText:action.response.responseText
									});
									body.unmask();
								 }
							});
						}
					}); 
				}
			}]
		});
		
		
		this.metaStore = Ext.create('Ext.data.Store', {/***Grid Store***/
			model: 'MetaModel',
			proxy: {
				type: 'ajax',
				url: '',
				reader: {
					type: 'json',
					totalProperty: 'totalCount',
					root: 'data',
					method:'POST'
				}
			},
			 pageSize: 25,
			listeners: {
				'beforeload':function(){
					var form = win.child('#masterQueryParamForm').getForm();
					
					this.proxy.url = win.getretrieveUrl;
				},
				'metachange': function(store, meta) {
					for(var i=0;i<meta.fields.length;i++){
						//meta.fields[i].flex=1;
						meta.fields[i].dataIndex = meta.fields[i].name;
						
						if(meta.fields[i].fldtype == 'cmccheckboxfield'){
							meta.fields[i].xtype = 'checkcolumn';
						} 
						
						if(meta.fields[i].fldhidden){
							meta.fields[i].hidden=true;
						}
						else{
							meta.fields[i].hidden=false;
						}
					}
					gridObj.reconfigure(store, meta.fields);/***Configuring columns dynamically***/ 
				}
			}
		});

		this.layout = "border";
		this.add({
			xtype:"form",
			collapsible: true,
			labelSeparator : '',
			height:65,
			region:"north",
			bodyPadding: 5,
			title:"Query Parameters",
			defaults:{
				margin:'2px 0px 0px 2px'
			},
			itemId: 'masterQueryParamForm',
			/* type:{
				layout:"table",
				columns:3
			},
			autoEl:{
				tag:"center"
			} */
			layout:"column"
		},{/***Dynamic adding of grid in the dynamic window***/
				title:this.title +" Details",
				xtype:"grid",
				itemId: 'masterGrid',
				height:380,
				border:false,
				width:800,
				region:"center",
				
				store: win.metaStore,
				autoScroll:true,
				cls: 'custom-dirty',//Applied cls to the dirty cell
				columns: [],
				listeners:{
					selectionchange: function(selModel, selected) {
						var getMainWin = this.ownerCt;
						getMainWin.child('#form').setActiveRecord(selected[0] || null);
						
						//var getFormItems = getMainWin.child('#form').items.items;
						var getFormItems = getMainWin.child('#form').getForm();
						
						var keyFieldLength  = getMainWin.getkeyFields.length;
						
						for(var i=0;i<getFormItems.getFields().items.length;i++){
							for(var j=0;j<keyFieldLength;j++){
								if(getFormItems.getFields().items[i].name==getMainWin.getkeyFields[j]){
									getFormItems.getFields().items[i].setDisabled(true);
								}
							} 
						}	
					},
					 itemcontextmenu: function (view, record, item, index, e) {
						//Following line has been added to ensure that record on which right click has been done also becomes the selected record
					
						e.stopEvent();
						deleteMenu.showAt(e.getXY());

					}
				},
				bbar: Ext.create('Ext.PagingToolbar', {
					store: win.metaStore,
					pageSize: 25,
					displayInfo: true,
					displayMsg: 'Displaying records {0} - {1} of {2}',
					emptyMsg: "No records to display"
				})
			},{
				itemId: 'form',
				width:300,
				height:380,
				region:"east",
				autoScroll:true,
				title:"Add/Edit",
				xtype: 'writerform',
				listeners: {
					create: function(form, data){
						
						var win = this.ownerCt;
						var getGrid = this.ownerCt.child('#masterGrid');
						/**********************CHECKING DUPLICATE FIELDS*****************************************/
					
						var finalRes = false;
						var matchedRecordIndex		=		getGrid.getStore().findBy(function(record){
							var flag=0;
							for(var i=0; i<win.getdupCheckFields.length; i++){
								if(record.get(win.getdupCheckFields[i])==data[win.getdupCheckFields[i]]){
									flag++;
									if(flag==win.getdupCheckFields.length){
										finalRes = true;
									}
									continue;
								}
							}
							return finalRes;
						});	 
						
						
						if(matchedRecordIndex!=-1){/**************Show message if there is duplicate record**************/
							Ext.MessageBox.show({
								title: 'Fatal',
								msg: 'The field which you entered is already existing',
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.ERROR
							});											
							return false;
						}
						else{
							var getFrm = this;
							var form = this.getForm();
							var body = Ext.getBody();
							
							body.mask(Modules.Msgs.saving);
							
							getGrid.getStore().insert(0, data);		// tobe removed
							body.unmask();
							getFrm.onReset();
							/*form.submit({
								url:win.getsaveUrl,
								method: 'POST',
								params:{
									trnsType:"I"
								},
								success: function (form, action) {
									getGrid.getStore().insert(0, data);		
									Ext.MessageBox.show({
										title: Modules.Msgs.SuccessInfo,
										msg: Modules.Msgs.SuccessInfoMsg,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.INFO
									});	
									body.unmask();
									getFrm.onReset();
								},
								failure: function (form, action) {
									Modules.GlobalFuncs.displayFormErrors({
									form:form,
									responseText:action.response.responseText
									});
									body.unmask();
								 }
							}); */
						}
					}
				}
			});/***Dynamic adding of grid in the dynamic window***/
		
		var gridObj = win.child('#masterGrid');
		gridObj.getStore().load({
			url: this.showUrl,
			callback:function(){
				win.getretrieveUrl = this.proxy.reader.metaData.retrieveUrl;
				win.getsaveUrl = this.proxy.reader.metaData.saveUrl;
				win.getdeleteUrl = this.proxy.reader.metaData.deleteUrl;
				win.columnLength = this.proxy.reader.metaData.fields.length;
				win.getkeyFields = this.proxy.reader.metaData.keyFields;
				win.getdupCheckFields = this.proxy.reader.metaData.dupCheckFields;
				var getQueryForm  =  win.child('#masterQueryParamForm');
				
				if(this.proxy.reader.metaData.queryFields==undefined){/********For hiding the Query fields**********/
					getQueryForm.setVisible(false);
				}
				if(this.proxy.reader.metaData.queryFields){/********For showing the Query fields**********/
					win.getmasterQueryParamFields = this.proxy.reader.metaData.queryFields;
					var queryLength = win.getmasterQueryParamFields.length;
				}
				
				var getForm  =  win.child('#form');
				var mainWindowWidth = screen.width;
				var mainWindowHeight = screen.height;
				
				var testLen=6;
				if(queryLength > 5){/*******Setting the query fields dynamically according to the response***********/
					var roundTotalLength = Math.ceil(parseInt(queryLength)/5)*5;
					var setHeightQuery = roundTotalLength/5;
					var setHeightQueryFinal = (setHeightQuery*24)+40;
					getQueryForm.setHeight(setHeightQueryFinal);	
					
					
					if(mainWindowWidth==1280 && mainWindowHeight==720){
						getForm.setHeight((getForm.getHeight() - setHeightQueryFinal)+20);
						gridObj.setHeight((gridObj.getHeight() - setHeightQueryFinal)+20);	
					}
					else{
						getForm.setHeight((getForm.getHeight() - setHeightQueryFinal)+60);	
						gridObj.setHeight((gridObj.getHeight() - setHeightQueryFinal)+60);	
					}
				}/*******Setting the query fields dynamically according to the response***********/
				
				
				/* for(var i=0;i<6;i++){
					
					getForm.add({
							labelWidth:80,
							xtype:"textfield",
							fieldLabel:"test "+i
						});
					
					
					getQueryForm.add({
							labelWidth:80,
							xtype:"textfield",
							fieldLabel:"test "+i
						});
						
				}     */
				var fldSet = getForm.add({
					xtype:"fieldset"
				});
				/* var dispFld=[];
				var valFld=[];
				var getTpl=[]; */
				for(var i=0;i<win.columnLength;i++){/*******Setting the grid columns & editing fields dynamically according to the response***********/
					var columnObj = gridObj.getStore().proxy.reader.metaData.fields[i];
					var getHidden;
					
					if(columnObj.fldhidden){
						getHidden=true;
					}
					else{
						getHidden=false;
					}
					if(columnObj.allowBlank==undefined)
						columnObj.allowBlank=true;
						
					if(columnObj.fldtype){	/*******Setting the grid columns dynamically according to the response***********/
						var setInputVal;
						if(columnObj.fldtype=="cmccheckboxfield"){
							setInputVal = "Y";
						}
						else{
							setInputVal = "";
						}
						fldSet.add({
							labelWidth:120,
							xtype:columnObj.fldtype,
							hidden:getHidden,
							fieldLabel:columnObj.text,
							name:columnObj.name,
							allowBlank:columnObj.allowBlank,
							inputValue:setInputVal
						});
					}/*******Setting the grid columns dynamically according to the response***********/
					
					if(columnObj.lookup){/*******Setting the editing fields dynamically according to the response***********/
						/* dispFld = columnObj.lookup.displayField;
						valFld = columnObj.lookup.valueField;
						
						
						getTpl[i] = function () {
							return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{' + valFld[i] + '}</td><td width="125px" align="left">{' + dispFld[i] + '}</td></tr><tr><td colspan="2" height="5"></td></tr></table>';
						} */
					
						var getKeyVals = columnObj.lookup.getParams;
						var keysArr = Ext.Object.getKeys(getKeyVals);
						var finalArr = [];
						var nameValObj = {};

						for(var k=0; k<keysArr.length; k++){
							nameValObj = {};
							nameValObj['name'] = keysArr[k];
							nameValObj['val'] = getKeyVals[keysArr[k]];
							finalArr[k] = nameValObj;
						} 
						
					/* 	listConfig: {
								width: 250,
								loadingText: 'Loading...',
								height: 200,
								deferEmptyText: false,
								emptyText: 'No Values Found!',
								getInnerTpl: function () {
									return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{' + columnObj.lookup.displayField + '}</td><td width="125px" align="left">{' + columnObj.lookup.valueField + '}</td></tr><tr><td colspan="2" height="5"></td></tr></table>
								}
							}  */
						
						Ext.define('comboModel', {/***Model for Combo***/
							extend: 'Ext.data.Model',
							"fields": [
									{
										"name": columnObj.lookup.valueField,
										"type": "string"
									},
									{
										"name": columnObj.lookup.displayField,
										"type": "string"
									}
								]
						});
						
						
						fldSet.add({
							fieldLabel:columnObj.text,
							xtype: 'cmccombobox',
							labelWidth:120,
							hidden:getHidden,
							name:columnObj.name,
							valueField: columnObj.lookup.valueField,
							displayField: columnObj.lookup.displayField,
							validateUrlCmc:columnObj.lookup.validateUrl,
							validateParamsCmc:finalArr, 
							storeObjCmc: {
								model: 'comboModel',
								url:columnObj.lookup.getUrl,
								extraParams:columnObj.lookup.getParams
							},
							listConfig: {
								width: 200,
								loadingText: 'Loading...',
								height: 200,
								deferEmptyText: false,
								emptyText: 'No Values Found!'
								//getInnerTpl:getTpl[i]
								/* getInnerTpl: function () {
									return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{' + columnObj.lookup.displayField + '}</td><td width="125px" align="left">{' + columnObj.lookup.valueField + '}</td></tr><tr><td colspan="2" height="5"></td></tr></table>
								} */
							}  
						});
					}/*******Setting the editing fields dynamically according to the response***********/
					
					for(var j=0;j<queryLength;j++){
						if(win.getmasterQueryParamFields[j]==columnObj.name){
							if(columnObj.fldtype){	
								getQueryForm.add({
									labelWidth:250,
									xtype:columnObj.fldtype,
									//hidden:getHidden,
									fieldLabel:columnObj.text,
									name:columnObj.name,
									allowBlank:columnObj.allowBlank
								});
							}
							if(columnObj.lookup){
								getQueryForm.add({
									fieldLabel:columnObj.text,
									xtype: 'cmccombobox',
									//labelWidth:55,
									name:columnObj.name,
									forceSelection:true,
									//hidden:getHidden,
									queryMode:'remote',
									valueField: columnObj.lookup.valueField,
									displayField: columnObj.lookup.displayField,
									validateUrlCmc:columnObj.lookup.validateUrl,
									validateParamsCmc:finalArr, 
									storeObjCmc: {
										model: 'comboModel',
										url:columnObj.lookup.getUrl,
										extraParams:columnObj.lookup.getParams
									}/* ,
									listConfig: {
										width: 250,
										loadingText: 'Loading...',
										height: 200,
										deferEmptyText: false,
										emptyText: 'No Values Found!',
										getInnerTpl: function () {
											return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{' + columnObj.lookup.displayField + '}</td><td width="125px" align="left">{' + columnObj.lookup.valueField + '}</td></tr><tr><td colspan="2" height="5"></td></tr></table>';
										}
									} */
								});
							}
						}  
					}
				} /*******Setting the grid columns & editing fields dynamically according to the response***********/
			}
		}); 
	},
	onConvert:function(){
		var gridModel = Ext.ModelManager.getModel('MetaModel');
		var len = gridModel.getFields().length;
		for(var j=0;j<len;j++){
			if(gridModel.getFields()[j].type.type=="bool"){
				gridModel.getFields()[j].convert = function(v){	
					return (v === "Y" || v === true) ? true : false;
				 }
			}
		}
	}
});
