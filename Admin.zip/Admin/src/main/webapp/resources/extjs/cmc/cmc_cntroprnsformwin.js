Ext.define('Ext.cmc.CntrOprnsFormWin', {
					
	extend: 'Ext.window.Window',
	alias: 'widget.cmccntroprnsformwin',
	
	height:300,
	width:600,
	constrain:true,
	autoScroll:true,
	modal:true,
	layout:'fit',
	buttonAlign:"center",
	gridIdCmc:'',//This will carry the id of the grid at which the window was invoked
	openModeCmc:'ADD',//This will take value either ADD/EDIT	
	
	closeOnSaveCmc:true,//This is used to decide that once record is saved successfully, then after that will the window be closed or form will be reset. In order to not to close window and reset the form, give value as false
	
	dateTimeFieldCntrArrCmc:'',//This should be an array containing the ids of all datetimefield objects present in the form. Note that the datefieldfield containers should have the same name as column data index in grid	
	
	cntrNoFieldIdCmc:'',//This will hold the id of container number
	saveUrlCmc:'',//This will hold the value of url which is to be called during save
	
	winFuncArgObjCmc:'',//This will hold the arguments object passed to this window	
		
	initComponent:function(){
		var me			=		this;
		me.items		=		[me.__getFormFuncCmc()];
		me.buttons			=		me.__getButtonsArrFuncCmc();		
		me.on('afterrender', me.afterRenderFuncCntrOprnsFormWinCmc);//Calling function before parent so that form gets loaded
		me.callParent();
	},
	
	setSaveBtnHandlerFuncCmc:'',//If required an instance can provide a function here which should return true/false and will be called during the execution of component's function
	__getSaveBtnHandlerFuncCmc:function(){
		var me			=		this;
		var btnObj		=		{
			handler:function(){
				var form		=		me.getComponent('cntrOprnsFormItemId').getForm();
				if(!form.isValid()){
					Ext.MessageBox.show({
						title: Modules.Msgs.inValidFormTitle,
						msg: Modules.Msgs.inValidFormMsg,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
					return false;
				}
				//Checking below if in all the date time fields, if time has been provided then date has been provided too
				if(!Modules.GlobalFuncs.checkDatePresenceWithTimeInAForm(me.getComponent('cntrOprnsFormItemId'))){
					return false;
				}
				//Calling the instance function if provided
				if(me.setSaveBtnHandlerFuncCmc && typeof me.setSaveBtnHandlerFuncCmc==='function'){
					var instanceFuncRes		=		me.setSaveBtnHandlerFuncCmc();
					if(!instanceFuncRes){
						return instanceFuncRes;
					}
				}
				form.submit({
					url:me.saveUrlCmc,
					success:function(form, action){
						Ext.MessageBox.show({
							title: Modules.Msgs.SuccessInfo,
							msg: Modules.Msgs.formSubmitSuccess,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
						var cntrNoObj		=		Ext.getCmp(me.cntrNoFieldIdCmc);
						var grid			=		Ext.getCmp(me.gridIdCmc);
						if(me.openModeCmc=='EDIT'){
							var rec			=		grid.getSelectionModel().getSelection()[0];
						}else{
							var rec			=		grid.getStore().findRecord(cntrNoObj.name, cntrNoObj.getValue());
						}
						if(rec){
							form.updateRecord(rec);
							if(me.dateTimeFieldCntrArrCmc && me.dateTimeFieldCntrArrCmc.length){
								for(var j=0; j<me.dateTimeFieldCntrArrCmc.length; j++){
									rec.set(Ext.getCmp(me.dateTimeFieldCntrArrCmc[j]).name, Ext.getCmp(me.dateTimeFieldCntrArrCmc[j]).getValueFuncCmc({
										type:'string'
									}));											
								}//End of for loop
							}
							grid.getStore().commitChanges();
						}	
						//Following code is used to check if the window is supposed to be closed on save or not
						if(me.closeOnSaveCmc){
							me.close();//Closing the window on save if closeOnSaveCmc is true
						}else{
							//Following operations are carried out if window is not supposed to be closed on save
							me.openModeCmc			=		'ADD';//Setting the openMode to  ADD
							form.reset();//reseting the form
							me.winFuncArgObjCmc		=		{};//Setting the arguments passed to empty object
							//Calling the instance function if provided
							if(me.setClearBtnHandlerFuncCmc && typeof me.setClearBtnHandlerFuncCmc==='function'){
								var instanceFuncRes		=		me.setClearBtnHandlerFuncCmc();
								if(!instanceFuncRes){
									return instanceFuncRes;
								}
							}
							//Following code has been written to focus the first field in form
							var fieldItems		=		form.getFields().items;
							var firstField		=		fieldItems[0];
							firstField.setDisabled(false);
							firstField.focus('',200);
						}
						return true;
					},
					failure:function(form, action){
						Modules.GlobalFuncs.displayFormErrors({
							form:form,
							responseText:action.response.responseText
						});
						return true;
					}
				});
				return true;
			}
		};
		return btnObj;
	},
	setClearBtnHandlerFuncCmc:'',//If required an instance can provide a function here which should return true/false and will be called after the component's function has been executed 
	__getClearBtnHandlerFuncCmc:function(){
		var me			=		this;
		var btnObj		=		{
			handler:function(){
				me.getComponent('cntrOprnsFormItemId').getForm().reset();//Reseting the form
				me.openModeCmc			=		'ADD';//Setting the openmode to ADD
				me.winFuncArgObjCmc		=		{};//Setting the arguments passed to empty object
				//Calling the instance function if provided
				if(me.setClearBtnHandlerFuncCmc && typeof me.setClearBtnHandlerFuncCmc==='function'){
					var instanceFuncRes		=		me.setClearBtnHandlerFuncCmc();
					if(!instanceFuncRes){
						return instanceFuncRes;
					}
				}
				return true;
			}
		};
		return btnObj;
	},
	setCloseBtnHandlerFuncCmc:'',//If required an instance can provide a function here which should return true/false and will be called before the component's function has been executed
	__getCloseBtnHandlerCmc:function(){
		var me			=		this;
		var btnObj		=		{
			handler:function(){
				if(me.setCloseBtnHandlerFuncCmc && typeof me.setCloseBtnHandlerFuncCmc==='function'){
					var instanceFuncRes		=		me.setCloseBtnHandlerFuncCmc();
					if(!instanceFuncRes){
						return instanceFuncRes;
					}
				}
				me.close();
				return true;
			}
		};
		return btnObj;
	},
	
	//Following function is used to get the array of button configs
	__getButtonsArrFuncCmc:function(){
		var me			=		this;
		var buttons		=		[
			Modules.GlobalFuncs.getSaveAction(me.__getSaveBtnHandlerFuncCmc()),
			Modules.GlobalFuncs.getClearAction(me.__getClearBtnHandlerFuncCmc()),
			Modules.GlobalFuncs.getCloseAction(me.__getCloseBtnHandlerCmc())
		];
		return buttons;
	},
	
	//Following function should be instantiated by the object. Function should return an array of items
	setFormItemsFuncCmc:'',
	
	//Following function is used to get the form config
	__getFormFuncCmc:function(){	
		
		var me			=		this;//This will hold the window object
		
		var formObj		=		{
			xtype:'cmcform',
			itemId:'cntrOprnsFormItemId',
			width:me.width-20,
			frame:true,
			setFormItemsFuncCmc:function(){				
				var itemsArr	=	me.setFormItemsFuncCmc(me.winFuncArgObjCmc);
				if(!itemsArr){
					itemsArr	=	[];
					return itemsArr;	
				}
				return itemsArr;	
			},
			listeners:{
				afterrender:function(){
					//Following code has been written to focus the first field in form
					var me				=		this;
					var fieldItems		=		me.getForm().getFields().items;
					var firstField		=		fieldItems[0];
					firstField.focus('',200);
				}
			}
		};
		return formObj;
	},//This function will return the form config which will be finally added to window item
	
	//Following function is called afterrender and is used to load the form with the selected grid record
	afterRenderFuncCntrOprnsFormWinCmc:function(){
		var me						=		this;
		var instanceCntrNoField		=		Ext.getCmp(me.cntrNoFieldIdCmc);//Fetching the container field
		/****Beginning the code to modify the container field****/
		instanceCntrNoField.xtype	=		'cmcvalidtextfield';//Setting the container type if not set to validtextfield
		var instanceValidateSuccessFunc		=		instanceCntrNoField.validateSuccessFuncCmc;//Setting success function a variable
		var instanceValidateFailFunc		=		instanceCntrNoField.validateFailFuncCmc;//Setting failure function to a variable
		//Redefining the success function below
		instanceCntrNoField.validateSuccessFuncCmc		=		function(serverRespOjbData){
			me.getComponent('cntrOprnsFormItemId').getForm().setValues(serverRespOjbData);//Setting the value to the form as received in response
			instanceCntrNoField.setDisabled(true);//Setting the container number as disabled
			if(instanceValidateSuccessFunc && typeof instanceValidateSuccessFunc === 'function'){
				var instanceFuncRes		=		instanceValidateSuccessFunc();//Callling the instance success function
				return instanceFuncRes;
			}
			return true;
		}
		//Redefining the fail function below
		instanceCntrNoField.validateFailFuncCmc		=		function(){
			//Following will reset the form fields except for container number
			Modules.GlobalFuncs.resetFormExceptFewFields({
				formPanel:me.getComponent('cntrOprnsFormItemId'),
				excludeArr:[instanceCntrNoField.name]
			});
			instanceCntrNoField.setDisabled(false);//Setting the container number as enabled
			Ext.MessageBox.show({
				title: Modules.Msgs.inValidFormTitle,
				msg: Modules.Msgs.inValidFormMsg,
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR,
				fn:function(){
					instanceCntrNoField.focus('', 50);
				}
			});
			if(instanceValidateFailFunc && typeof instanceValidateFailFunc === 'function'){//Calling the instance fail function
				var instanceFuncRes		=		instanceValidateFailFunc();
				return instanceFuncRes;
			}
			return true;
		}
		/****Ending the code to modify the container field****/
		if(me.openModeCmc.toUpperCase() == 'EDIT'){
			var formObj		=		me.getComponent('cntrOprnsFormItemId').getForm();
			var gridSelRec	=		Ext.getCmp(me.gridIdCmc).getSelectionModel().getSelection()[0];
			formObj.loadRecord(gridSelRec);
			if(me.dateTimeFieldCntrArrCmc && me.dateTimeFieldCntrArrCmc.length){
				for(var i=0; i<me.dateTimeFieldCntrArrCmc.length; i++){
					Ext.getCmp(me.dateTimeFieldCntrArrCmc[i]).setValueFuncCmc({
						objVal:gridSelRec.get(Ext.getCmp(me.dateTimeFieldCntrArrCmc[i]).name)
					});
				}//End of for loop
			}
			instanceCntrNoField.blurEventFuncCmc({
				forceFire:true
			});			
		}
		Ext.getBody().unmask();
	}//EOF afterRenderFuncCntrOprnsFormWinCmc	
});