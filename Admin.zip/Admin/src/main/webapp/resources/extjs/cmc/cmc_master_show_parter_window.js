Ext.cmc.Master.showPartnerWindow = function(partnerGroup) {

	if(!partnerGroup){
		return ;
	}
	/* **************** Form START******************* */
	var formFn = function() {
		var popupForm = {
			xtype : 'cmcform',
			showFieldsetCmc : false,
			height :40,
			width : 800,
			collapsible:false,
			setFormItemsFuncCmc : function() {
				var itemsArr = [];
				var container = {
					xtype : 'container',
					layout : 'hbox',
					defaults:{
						width : 400,
						xtype:'cmctextfield',
						readOnly:true,
						labelWidth:170,
						labelAign:'left'
					},
					items : [
					       {
							name:'partnerGroupCode',
							fieldLabel:Modules.Masters.General_Master.labels.partnerGroupCode,
							value:partnerGroup
					       },
					       {
					    	name:'partnerGroupName',
					    	itemId:'partnerGroupName',
							fieldLabel:Modules.Masters.General_Master.labels.partnerGroupName
					       }]
				};

				itemsArr = [ container ];
				return itemsArr;
			}
		};
		return popupForm;
	};
	/* **************** Form END******************* */
	/* **************** Grid START******************* */

	var getGrid = function() {

		var copyStore = {
			model : 'GenericLookUpDTO',
			url : 'commonLov/getPartnerCodeByGroup',			
			paging : true,
			queryTypeCmc : 'remote',
            listeners: {
                beforeload: function () {
                    //for sending selected values to controller									
                    this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
                    this.proxy.extraParams.userTyp = Modules.GlobalVars.loginUserTypeCode;
                    this.proxy.extraParams.userId = Modules.GlobalVars.loginUserId;
                    this.proxy.extraParams.partnerCode = partnerGroup;
                }
            }
		};


		var grid = {

			xtype : 'cmcgrid',
			storeObjCmc : copyStore,
			gridId:'showPartnerMasterGrid',
			showSelModelCmc : false,
			showCountColumnCmc : false,
			showPagingBarCmc : true,
			showTotalSelectedCmc : true,
			showTotalCountCmc : true,
			showLeftExtraTbarCmc : false,
			// setExtraTbarFuncCmc:true,
			showLeftExtraTbarFuncCmc : false,
			setGridColumnsFuncCmc : function() {
				var colsArr = [
						{
							header : Modules.LblsAndTtls.partnerCodeTtl,
							dataIndex : 'code',
							width:200
						},
						{
							header : Modules.LblsAndTtls.partnerNameTtl,
							dataIndex : 'name',
							width:200
						}];
				return colsArr;
			},
			listeners:{
				render:function(grid){
					var body = Ext.getBody();
					body.mask(Modules.Msgs.processing);
					Ext.Ajax.request({
						url : 'commonLov/getPartnerGroupName',
						method:'GET',
						params : {groupCode:partnerGroup},
						success : function(response) {
							var msg=Ext.decode(response.responseText);
							grid.up('cmcwindow').down('#partnerGroupName').setValue(msg.items);
							grid.store.load();
							Ext.getBody().unmask();
							
						},
						failure : function(response) {													
							Ext.getBody().unmask();
							grid.store.load();
						}
					});
					
				}
			}
		};
		return grid;
	};

	

	/* **************** Grid END******************* */

	var popupWinObj = Ext.create('Ext.cmc.Window', {
		title : 'List of Partners',
		height : 550,
		width : 850,
		x : 100,
		y : 50,
		modal : true,
		setCenterItemFuncCmc : getGrid,
		showNorthItemCmc : true,
		setNorthItemFuncCmc : formFn
	});
	return popupWinObj;

};