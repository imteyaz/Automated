/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.DeportOriginComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the ComboBox class
	alias: 'widget.cmcdepotorigincombobox',//Defining the xtype  
	
	/**Beginning the setting of values for already existing configs**/ 
	displayField: 'depotCd',
    valueField: 'depotCd',
	paging: true,
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function () {
				return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left" class="fontCls">{depotCd}</td><td width="145px" align="left" class="fontCls">{depotDescr}</td></tr></table>';
		} 
	},
	validateUrlCmc:'masterslookup/validatedepot',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'DepotCodeModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'masterslookup/getdepotlist';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});