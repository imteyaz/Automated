/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.FactoryComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmcfactorycombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	displayField: 'extFxdDomCd',
	valueField:'intFxdDomCd',
	matchFieldWidth:false,
	paging:true,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function () {
				return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" 					align="left">{intFxdDomCd}</td><td width="125px" align="left">{extFxdDomCd}</td></tr><tr><td height="2"></td></tr><tr valign="top"><td align="left">{sDescr}</td><td align="left">{colNm}</td></tr><tr><td height="2"></td></tr></table>';
		}
	},
	validateUrlCmc:'masterslookup/validatefactorydtls',
	storeObjCmc:{},
	storeFactoryExtraParamsCmc:'',
	validateParamsCmc:{},
	valdidateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'IntExtFxdDmModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'masterslookup/factorydtls';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		if(Ext.isObject(me.storeFactoryExtraParamsCmc)){
			me.storeObjCmc.extraParams	=		me.storeFactoryExtraParamsCmc;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});