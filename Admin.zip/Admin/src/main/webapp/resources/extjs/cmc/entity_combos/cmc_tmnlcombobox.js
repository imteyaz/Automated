/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.TmnlComboBox', {   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmctmnlcombobox',//Defining the xtype	
	displayField: 'ydTmnlCd',	
	valueField:'intYdTmnlNo',
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.terminalLbl,	
	paging:true,
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function() {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{ydTmnlCd}</td><td width="125px" align="left">{ydTmnlNm}</td><td width="125px" align="left">{sDescr}</td></tr><tr><td height="2"></td></tr></table>';
		}
	},
	validateUrlCmc:'masterslookup/validatetmnl',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/
	initComponent:function(){
		var me	=	this; 
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'TmnlCdComboModel';
		}
		if(!me.storeObjCmc.url){ 
			me.storeObjCmc.url			=		'masterslookup/gettmnllist';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});