Ext.define('Ext.cmc.Hiddenfield', {   
	extend: 'Ext.form.field.Hidden',
	alias: 'widget.cmchiddenfield'
});

