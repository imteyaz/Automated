Ext.define('Ext.cmc.Form',{
	
	extend: 'Ext.form.Panel',
	alias: 'widget.cmcform',
	
	/***Beginning the config properties which already exist in the component**/
	autoScroll:true,
	frame:true,
	border: false,
	fieldDefaults:{
		labelAlign:'right',
		msgTarget: 'qtip',
		labelSeparator: " "
	},
	layout:'ux.center',
	
	/***Ending the config properties which already exist in the component**/
	
	/***Beginning adding of new properties***/
	showFieldsetCmc:false,//Make this true in order to have fieldset covering all the fields
	fieldSetMarginCmc:'4px 0px 0px 0px',//This is the margin which will be applied to fieldset enclosing the complete form
	/***Ending adding of new properties***/

	initComponent:function(){
		
		var me					=		this;
			
		var itemsArr			=		[];
		
		if(me.layout=='ux.center'){
			//Beginning of the code of inserting a container at the top of all the items of this form
			//Calculating width for the container
			var containerWidthVar	=	(me.width && me.width<=1250)?(me.width*.96):1250;
			//Creating the container object below
			var containerObj		=		{
				xtype:'container',
				width:containerWidthVar
			};
			
			if(me.showFieldsetCmc){//Following takes care of the case when a fieldset is wanted at the top of all the fields
				/*
					**Note that fieldset is being added as a child of container and not replacing the container as layout ux.center is not being able to have fieldset in center if there is no container present at the top. Due to this reason, first a container has been added and then its first child is made as fieldset
				*/
				var fieldset			=		{
					xtype:'fieldset',
					margin:me.fieldSetMarginCmc,
					width:containerWidthVar-10,
					defaults:{
						margin:'2px 0px 0px 0px'
					},
					items:me.setFormItemsFuncCmc()//Setting all items created as child of fieldset
				};
				containerObj.items		=		[fieldset];//Setting fieldset as child of container
			}else{
				containerObj.items		=		me.setFormItemsFuncCmc();//Calling the function for getting the child items provided by the instance
				containerObj.defaults	=		{
					margin:'2px 0px'
				};
			}	
			
			itemsArr[0]				=		containerObj;//Making the container as the first element of the form
			
		}else{
			itemsArr			=		me.setFormItemsFuncCmc();
		}
				
		me.items				=		itemsArr;
		
		me.callParent();//No arguments passed as per the docs in API		
	},
	/**
	 * 
	 * @param getDirtyFields {Boolean} set to true if want array of dirty field names
	 */
	isDirtyCmc : function(getDirtyFields){
		if(this.getForm().getRecord() && this.getForm().getRecord() instanceof Ext.data.Model){
			var formValues = this.getForm().getValues(false, false,false,true);
			/*console.log(formValues);
			console.log(this.getForm().getRecord());*/
			if(getDirtyFields){
				var updatedFields = [];
				for(var key in formValues){
					if(Ext.isDefined(this.getForm().getRecord().data[key]) &&
							((this.getForm().getRecord().get(key)+"").toUpperCase() != (formValues[key]+"").toUpperCase())){
						updatedFields.push(key);
					}
				}
				return updatedFields;
			}else{// for performance reason
				for(var key in formValues){
					
					if((Ext.isEmpty(this.getForm().getRecord().get(key)) && Ext.isEmpty( formValues[key]))){
						continue;
					}else{
						if(this.getForm().getRecord().data.hasOwnProperty(key)){//Ext.isDefined(this.getForm().getRecord().data[key])){
							if(Ext.isDate(this.getForm().getRecord().data[key])){
								
								if(Ext.isDate(formValues[key])){
								   if(this.getForm().getRecord().get(key).getTime() != formValues[key].getTime()){
									return true;
								 } 
								}else if (Ext.isEmpty(formValues[key])
										||(Ext.Date.parse(formValues[key],Modules.GlobalVars.dateFormatGlobal) 
										&&(this.getForm().getRecord().get(key).getTime() 
												!= Ext.Date.parse(formValues[key],Modules.GlobalVars.dateFormatGlobal).getTime()))) {
										return true;
									}
								
							}else if ((this.getForm().getRecord().get(key)+"").trim().toUpperCase() != (formValues[key]+"").trim().toUpperCase()){
								return true;
                               }
						
						}
					}
					
				}
				return false;
			}
		}
	},
	syncRecordCmc : function(){
		if(!this.getForm().getRecord()) return;
		this.getForm().updateRecord([this.getForm().getRecord()]);
	},
	setFormItemsFuncCmc:function(){//this function will return an array of objects carrying item definitions
		
	}
});