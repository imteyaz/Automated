Ext.define('Ext.cmc.GridParentChildEditorWindow', {
					
	extend: 'Ext.window.Window',
	alias: 'widget.cmcgridparentchildeditorwindow',
	
	height:500,
	width:700,
	constrain:true,
	autoScroll:true,
	modal:true,
	layout:'border',
	
	parentGridIdCmc:'',//This will carry the id of the grid at which the window was invoked
	openModeCmc:'add',//This will take value either add/edit
	
	childFormOkBtnIdCmc:'',//This is the id which will be applied to the ok button
	childFormOkBtnHandlerFuncCmc:function(){
		return true;
	},
	childFormbtnCntrMarginCmc:'',//This is the margin which will be applied to the button container
	
	clearBtnObjCmc:{
		handler:function(){
			return true;
		}
	},
	
	saveBtnObjCmc:{
		handler:function(){
			return true;
		}
	},
	
	showExtraTbarCmc:false,//Set it to true to add the extra tbar, like buttons for Reports etc..
	
	winFuncArgObjCmc:{},//This will hold the arguments object passed to this window
	
	initComponent:function(){
		var me		=		this;
		me.__setTbarFuncCmc();//Calling this function for setting TBar
		me.__setItemsFuncCmc();//Calling this function for setting the Items
		me.callParent();//No arguments passed as per the docs in API
		me.on('afterrender', me.afterRenderFuncGridParentChildEditorWinCmc);//Associating a function with the event
	},
	
	__setTbarFuncCmc:function(){

		var me		=		this;
		
		me.tbar		=		[];//Setting TBar to an empty array	
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.clearBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getClearAction(me.__getClearBtnConfigFuncCmc());
		}
		
		me.tbar[me.tbar.length]	=	'->';//This line has been added to create the space after Retrieve button
		
		if(me.showExtraTbarCmc){
			var extraTbar		=		me.setExtraTbarFuncCmc(me.winFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraTbar && extraTbar.length && extraTbar instanceof Array && Object.prototype.toString.call(extraTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraTbar);
			}
		}
		
		if(me.saveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getSaveAction(me.__getSaveBtnConfigFuncCmc());
		}
		
		if(me.modal){//Exit button is shown if the window is modal even if showExitButtonCmc is set to false
			var exitBtnObj		=		{
				handler:function(){
					me.close();
				}
			};
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getExitAction(exitBtnObj);
		}
		
		if(!me.tbar.length){
			delete me.tbar;//Deleting the tbar if no buttons have been added so far
		}			
	},
	
	//Following function can be used to set the extra buttons in the tbar
	setExtraTbarFuncCmc:function(winFuncArgObjCmc){
		//This function will carry the code of buttons specific to the window
		//This function should return an array of button definitions including the spacers if required
		/*
			Example:
			[
				{
					text:'Report'
					handler:function(){}
				},
				{
					text:'Copy To All',
					handler:function(){}
				},
				'->'//Use only if the buttons need to be in the center of window's tbar
			]
		*/
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the clear butotn
	__getClearBtnConfigFuncCmc:function(){
		var me								=		this;
		var btnConfig						=		{};
		Ext.apply(btnConfig, me.clearBtnObjCmc);
		btnConfig.copyHandlerFunc			=		me.clearBtnObjCmc.handler;
		btnConfig.handler					=		function(){							
			var me		=		this;
			me.getComponent('parentFormItemId').reset();
			me.getComponent('childPanelItemId').getComponent('childGridItemId').removeAll();
			me.getComponent('childPanelItemId').getComponent('childFormItemId').reset();
			var res		=		copyHandlerFunc.copyHandlerFunc();
			return res;
		}
		return btnConfig;
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the save butotn
	__getSaveBtnConfigFuncCmc:function(){
		var me								=		this;
		var btnConfig						=		{
			text:'Update Parent Grid'
		};
		Ext.apply(btnConfig, me.saveBtnObjCmc);
		btnConfig.copyHandlerFunc			=		me.saveBtnObjCmc.handler;
		btnConfig.handler					=		function(){		
			var parentFormObj		=		me.getComponent('parentFormItemId').getForm();
			if(!parentFormObj.isValid()){
				Ext.MessageBox.show({
					title: Modules.Msgs.inValidFormTitle,
					msg: Modules.Msgs.inValidFormMsg,
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}
			
			var resInstanceHandler	=			btnConfig.copyHandlerFunc();
			if(!resInstanceHandler){
				return false;
			}
			
			var parentFormRec			=		parentFormObj.getValues();
			var parentFormRecKeys		=		Ext.Object.getKeys(parentFormRec);
			var childGridRecs			=		me.getComponent('childPanelItemId').getComponent('childGridItemId').getStore().getRange(0);
			
			if(me.openModeCmc.toUpperCase()=='EDIT'){
				
				//Carrying the tasks below of updating the grid store record
				var parentGridSelRec	=	Ext.getCmp(me.parentGridIdCmc).getSelectionModel().getSelection()[0];
				var dirty				=	false;
				var curKeyEdit			=	'';
				for(var i=0; i<parentFormRecKeys.length; i++){
					curKeyEdit		=		parentFormRecKeys[i];
					if(parentGridSelRec.get(curKeyEdit)!=parentFormRec[curKeyEdit]){
						dirty	=	true;
						parentGridSelRec.set(curKeyEdit, parentFormRec[curKeyEdit]);
					}
				}//End of for loop
				if(dirty && parentGridSelRec.get('trnsType')==''){
					parentGridSelRec.set('trnsType', 'U');
				}
				parentGridSelRec.set('children', childGridRecs);
				
			}else if(me.openModeCmc.toUpperCase()=='ADD'){
				
				var gridStore			=	Ext.getCmp(me.parentGridIdCmc).getStore();
				gridStore.insert(0, {});	
				var gridNewRec			=	gridStore.getAt(0);
				var curKeyAdd			=	'';
				for(var i=0; i<parentFormRecKeys.length; i++){
					curKeyAdd		=		parentFormRecKeys[i];
					gridNewRec.set(curKeyAdd, parentFormRec[curKeyAdd]);
				}//End of for loop
				gridNewRec.set('trnsType', 'I');
				gridNewRec.set('children', childGridRecs);
			}
			me.close();
		}
		
		return btnConfig;
	},
	
	//This function will be overriden in the instance and is expected to return form config
	setParentFormFuncCmc:function(){
	
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the parent form
	__getParentFormConfigFuncCmc:function(){
	
		var me					=		this;
		var formConfig			=		{
			xtype:'cmcform',
			region:'north',
			itemId:'parentFormItemId'
		};
		var instanceFormConfig	=		me.setParentFormFuncCmc(me.winFuncArgObjCmc);
		Ext.applyIf(formConfig, instanceFormConfig);
		if(!formConfig.height){
			formConfig.height	=		100;
		}
		if(!formConfig.width){
			formConfig.width	=		me.width-50;
		}
		return formConfig;
	},
	
	//This function will be overridden in the instance and will return a grid config object
	setChildGridFuncCmc:function(){
	
	},
	
	//Following function should not be overridden by instance. It will return the proccessed grid config
	__getChildGridConfigFuncCmc:function(){
		var me			=		this;
		var gridConfig	=		{
			xtype:'cmcgrid',
			region:'center',
			itemId:'childGridItemId'
		};
		var instanceGridConfig	=		me.setChildGridFuncCmc(me.winFuncArgObjCmc);
		Ext.applyIf(gridConfig, instanceGridConfig);
		if(gridConfig.listeners){
			gridConfig.listeners.selectionchange	=		function(model, records){
				if (records[0]) {
					me.getComponent('childPanelItemId').getComponent('childFormItemId').getForm().loadRecord(records[0]);
				}
			}
		}else{
			gridConfig.listeners					=		{};
			gridConfig.listeners.selectionchange	=		function(model, records){
				if (records[0]) {
					me.getComponent('childPanelItemId').getComponent('childFormItemId').getForm().loadRecord(records[0]);
				}
			}
		}
		return gridConfig;
	},
	
	//This function will be overridden in the instance and will return child form config
	setChildFormFuncCmc:function(){
		
	},
	
	//Following function should not be overridden in instance. It will return the final child form config
	__getChildFormConfigFuncCmc:function(){		
		
		var me					=		this;
		
		var formConfig			=		{
			xtype:'cmcform',
			region:'east',
			itemId:'childFormItemId'
		};
		
		var instanceConfig		=		me.setChildFormFuncCmc(me.winFuncArgObjCmc);
		
		Ext.applyIf(formConfig, instanceConfig);
		
		if(!formConfig.width){
			formConfig.width	=		200;
		}
		
		formConfig.setFormItemsFuncCmc	=	function(){
			
			var itemsArr		=		instanceConfig.setFormItemsFuncCmc(me.winFuncArgObjCmc);
			if(!itemsArr){
				itemsArr		=		[];
			}
			
			var okBtnMargin		=		me.childFormbtnCntrMarginCmc?me.childFormbtnCntrMarginCmc:'10px 0px 0px 10px';
			var okBtnId			=	(me.childFormOkBtnIdCmc)?me.childFormOkBtnIdCmc:'';
			
			var trnsTypeObj	=		{
				xtype:'cmchiddenfield',
				name:'trnsType',
				itemId:'trnsTypeItemId',
				value:'I'
			};
			
			var containerObj	=	{
				xtype:'container',
				layout:'hbox',
				border:1,
				margin:okBtnMargin,
				items:[
					{
						xtype:'cmcbutton',
						text:'OK',
						width:40,
						handler:function(){
							var childFormObj		=		me.getComponent('childPanelItemId').getComponent('childFormItemId').getForm();
							if(!childFormObj.isValid()){
								Ext.MessageBox.show({
									title: Modules.Msgs.inValidFormTitle,
									msg: Modules.Msgs.inValidFormMsg,
									buttons: Ext.MessageBox.OK,
									icon: Ext.MessageBox.ERROR
								});
								return false;
							}
							
							//Calling below the handler passed to the instance
							var result		=		me.childFormOkBtnHandlerFuncCmc(me.winFuncArgObjCmc);
							if(!result){
								return result;
							}
							
							var childFormRec		=	childFormObj.getValues();
							var childFormRecKeys	=	Ext.Object.getKeys(childFormRec);
								
							if(childFormRec.trnsType=='I'){
								var childGridStore		=	me.getComponent('childPanelItemId').getComponent('childGridItemId').getStore();
								childGridStore.insert(0, {});	
								var childGridNewRec		=	childGridStore.getAt(0);
								var curKeyAdd			=	'';
								for(var i=0; i<childFormRecKeys.length; i++){
									curKeyAdd		=		childFormRecKeys[i];
									childGridNewRec.set(curKeyAdd, childFormRec[curKeyAdd]);
								}//End of for loop												
							}else{
								//Carrying the tasks below of updating the grid store record
								var childGridSelRec			=	me.getComponent('childPanelItemId').getComponent('childGridItemId').getSelectionModel().getSelection()[0];
								var dirty				=	false;
								var curKeyEdit			=	'';
								for(var i=0; i<childFormRecKeys.length; i++){
									curKeyEdit		=		childFormRecKeys[i];
									if(childGridSelRec.get(curKeyEdit)!=childFormRec[curKeyEdit]){
										dirty	=	true;
										childGridSelRec.set(curKeyEdit, childFormRec[curKeyEdit]);
									}
								}//End of for loop
								if(dirty && childGridSelRec.get('trnsType')==''){
									childGridSelRec.set('trnsType', 'U');
								}
							}
						}
					},
					{
						xtype:'cmcbutton',
						text:'Clear',
						width:40,
						margin:'0px 0px 0px 5px',
						handler:function(){
							var childFormObj		=		me.getComponent('childPanelItemId').getComponent('childFormItemId').getForm();
							childFormObj.reset();
						}
					}
				]
			};
			itemsArr[itemsArr.length]		=		containerObj;
			itemsArr[itemsArr.length]		=		trnsTypeObj;
			return itemsArr;
		}						
		return formConfig;
	},
	
	//Following function should not be overridden in instance. It will return the child panel config
	__getChildCenterPanelCmc:function(){
		var me			=	this;
		var panelConfig	=	{
			xtype:'cmcpanel',
			closable:false,
			region:'center',
			layout:'border',
			itemId:'childPanelItemId',
			items:[
				me.__getChildFormConfigFuncCmc(),
				me.__getChildGridConfigFuncCmc()
			]
		};
		return panelConfig;
	},//EOF __getChildCenterPanelCmc
	
	__setItemsFuncCmc:function(){
		var me			=		this;
		me.items		=		[];
		me.items[0]		=		me.__getParentFormConfigFuncCmc();
		me.items[1]		=		me.__getChildCenterPanelCmc();		
	},
	
	//Following function is called afterrender and is used to load the form with the selected grid record
	afterRenderFuncGridParentChildEditorWinCmc:function(){
		var me				=		this;
		var formObj			=		me.getComponent('parentFormItemId').getForm();
		var childGridStore	=		me.getComponent('childPanelItemId').getComponent('childGridItemId').getStore();
		childGridStore.removeAll();
		if(me.openModeCmc.toUpperCase() == 'EDIT'){
			var gridSelRec		=		Ext.getCmp(me.parentGridIdCmc).getSelectionModel().getSelection()[0];
			formObj.loadRecord(gridSelRec);
			childGridStore.add(gridSelRec.get('children'));
		}
		Ext.getBody().unmask();
	}//EOF afterRenderFuncGridEditorWinCmc
});