/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.PortComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the ComboBox class
	alias: 'widget.cmcportcombobox',//Defining the xtype  
	
	/**Beginning the setting of values for already existing configs**/ 
	displayField: 'portCd',
    valueField: 'portCd',
	paging: true,
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function () {
				return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left" class="fontCls">{portCd}</td><td width="145px" align="left" class="fontCls">{portNm}</td></tr></table>';
		} 
	},
	validateUrlCmc:'masterslookup/validateport',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'PortComboModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'lookup/getrouteportlist';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});