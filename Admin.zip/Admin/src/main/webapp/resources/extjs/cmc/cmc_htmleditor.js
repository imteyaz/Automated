Ext.define('Ext.cmc.HtmlEditor', {
   
	extend: 'Ext.form.field.HtmlEditor',
	alias: 'widget.cmchtmleditor',
	
	/*Beginning of assigning values to already existing config options*/
	focusCls:'focusClass',
	labelAlign:'right',
	/*Ending of assigning values to already existing config options*/

	initComponent:function(){
		var me	=	this;
		me.on('beforerender',me.beforeRenderFuncCmc);
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	beforeRenderFuncCmc:function(){
		var me	=	this;
		if(!me.allowBlank)
			me.labelStyle = 'color:#ff0000';	

		if(me.readOnly){
			me.fieldCls	=	'readOnlyClass';
		}
	}
});

