/*
	*Following file contains more than one version of the extended component of combobox
*/
Ext.define('Ext.cmc.ComboBox', {
   
	extend: 'Ext.form.ComboBox',//Extending the TextField
	alias: 'widget.cmccombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldCls:'lookUpClass',
	focusCls:'focusClass',//Providing value for existing config property
	queryMode: 'remote',
	//fieldStyle:'text-transform:uppercase',
	typeAhead: true,
	minChars:0,
	hideTrigger:true,
	forceSelection:false,
	maxHeight:25,
	labelAlign:'left',
	matchFieldWidth:false,
	matchCaseToValidateCmc:false,
	//selectOnTab:false,
	listConfig:{
		emptyText:'No Values Found',
		loadingText: 'Searching...'
	},
	/*Beginning of assigning values to already existing validate config options*/
	//validateOnBlur:true,
	//validateOnChange:false,
	/* validator:function(){
		var me		=		this;
		if(me.allowBlank && (!me.getRawValue() || me.getRawValue()=='')){
			me.fieldValidCmc	=		true;
			me.invalidText		=		'';
			me.clearInvalid();
			me.validateFailFuncCmc();
			return true;
		}else if(me.oldRawValueCmc!=me.getRawValue()){
			me.validateParamsCmc[me.displayField]		=		me.getRawValue();
			Ext.Ajax.request({
				url: me.validateUrlCmc,
				params: me.validateParamsCmc,
				method:me.validateAjaxMethodCmc,
				success: function(response){
					respObj					=		Ext.JSON.decode(response.responseText);
					me.oldRawValueCmc		=		me.getRawValue();
					if(respObj.success){
						me.fieldValidCmc	=		true;
						me.invalidText		=		'';
						
						//Commenting the following currently as not sure if we need to data to the combobox
						// me.store.add(respObj.data);
						// me.setValue(respObj.data[me.valueField]);
						
						//following condition has been added to take care of the case like FPD combos where user can type only few characters and they will be accepted too as valid but the final raw value would be different from the initial typed in raw value butt commenting it currently too
						// if(me.getRawValue()){
							// if(me.oldRawValueCmc.toLowerCase()!=me.getRawValue().toLowerCase()){
								// me.oldRawValueCmc	=	me.getRawValue();
							// }
						// }
						me.validateSuccessFuncCmc(respObj.data);
						me.clearInvalid();
						return true;
					}else{
						me.fieldValidCmc		=		false;
						if(respObj.errors){
							me.invalidText		=		respObj.errors;
						}						
						me.validateFailFuncCmc();
						me.markInvalid(me.invalidText);
						return me.invalidText;
					}
				},
				failure:function(response){
					me.fieldValidCmc		=		false;
					if(Modules.Msgs && Modules.Msgs.serverError){
						me.invalidText			=		Modules.Msgs.serverError;
					}else{
						me.invalidText			=		'Server error. Please try later';
					}
					me.validateFailFuncCmc();
					me.markInvalid(me.invalidText);
					return me.invalidText;
				}
			});
		}else if(!me.fieldValidCmc){
			me.markInvalid(me.invalidText);
			return me.invalidText;
		}else{
			me.clearInvalid();
			return true;
		}
	}, */
	/*Ending of assigning values to already existing validate config options*/
	/**Ending the setting of values for already existing configs**/
	
	/**Beginning the setting of values for new configs**/
	oldRawValueCmc:'',//This is a new property created to manage forceSelection off
	fieldValidCmc:true,//This is a new property which is set true or false depending upon the current value is valid/invalid
	/**Beginning the configs which can be overridden in the instances**/
		storeObjCmc:{},//This will hold the store object as expected by the function getStore
		paging:true,
		validateUrlCmc:'',
		//validateParamsCmc:{},
		validateParamsCmc:[],
		validateAjaxMethodCmc:'GET',
		validateSuccessFuncCmc:function(serverRespOjbData){
			return true;
		},
		validateFailFuncCmc:function(){
			return true;
		},
		
		//Following has been added to take care of requirement where a particular value should imply all values
		isAllowedAllCmc:false,//Make it true to allow a value represent All values
		allAllowedValCmc:'',//Mention the value here which will represent All, like # or 0
		
		showCheckingMaskOnBlur:false,//if true then when blur validation gets fired then a checking mask appears on combo
	/**Ending the configs which can be overriden in the instances**/
	//invalidValMsgCmc:'Invalid Value - Please provide a valid value',//This property is used to display message if user provides invalid value
	//selEventFiredCmc:false,//This is used to identify that whether the select event has fired or not
	/**Ending the setting of values for new configs**/
	forceQueryCmc : true,//Force to query each time TODO: make it to do so if only company code changes
	toolTipCmc :false,//Tooltip: String
	initComponent:function(){
		var me	=	this;
		if(me.paging){
			me.pageSize					=		Modules.GlobalVars.recordsPerPageCombo;
			me.storeObjCmc.paging		=		true;
		}
		me.storeObjCmc.storeForComp		=		'combo';
		me.store						=		Modules.GlobalFuncs.getStore(me.storeObjCmc);
		//me.listConfig					=		me.getListConfigFuncCmc();
		me.on('beforerender', me.beforeRenderFuncCmc);//Associating a new defined method with an event
		me.on('select', me.selectEventFuncCmc);//Associating a new defined method with an event
		//Associating blur validation only if forceSelection is false
		if(!me.forceSelection && me.validateUrlCmc){
			me.on('blur', me.blurEventFuncCmc);//Associating a new defined method with an event
		}else if (!Ext.isDefined(me.validator) && (!Ext.isDefined(me.validateUrlCmc) || Ext.isEmpty(me.validateUrlCmc)) 
				&& !Ext.isEmpty(this.store.proxy.url)){
			me.on('blur',function(){
				
				if((me.ownerCt && (me.ownerCt instanceof Ext.grid.CellEditor ))/*||(me.oldRawValueCmc == me.getRawValue())*/){// if values are not changed dont do anything
					return;
				}
				
				if(Ext.isEmpty(this.getValue())){
					this.clearInvalid();
					return;
				}
				me.store.proxy.extraParams['query'] = this.getValue();
				me.store.load(function(records, operation, success){
					if(records && records.length > 0){
						me.store.each(function(record){
								if(record.data[me.valueField] == me.getValue()){
									me.fireEvent('select',me,[record]);
									return false;
								}
							});
						if(me.store.find(me.valueField,me.getValue())==-1){
							me.markInvalid(Modules.Msgs.noDataFoundError);
						}else{
							me.clearInvalid();
						}
						}
					});
				
			},me);
			
			me.validator=function(value){
				if(value && !me.readOnly){
					if(!this.store.loading && this.store.getCount() == 0){
						this.store.on('load',function(){
							if(this.store.find(this.valueField,this.getValue())==-1){
								this.markInvalid(Modules.Msgs.noDataFoundError);
							}else{
								this.clearInvalid();
							}
						},this,{single:true});
						
					}else{
						
						var serachValue = this.getValue();
						if(Ext.isEmpty(serachValue)){
							serachValue = value;
						}
						var valueIndex = -1;
						if(this.matchCaseToValidateCmc){
							valueIndex = this.store.findExact(this.valueField,serachValue);
						}else{
							valueIndex = this.store.find(this.valueField,serachValue);
						}
						return	valueIndex ==-1?Modules.Msgs.noDataFoundError:true;
					}
				}
				return true;
			};
		}
		
		if(me.forceQueryCmc){
			me.on('beforequery', function(qe) {
			    delete qe.combo.lastQuery;
			}, this);
		}
		
		if(me.toolTipCmc){
			me.on('render', function(c) {
				  Ext.QuickTips.register({
					target: c.labelEl,
					text:me.toolTipCmc,
					maxWidth : 10000
				  });
				});
		}else{
			me.on('render',function(c) {
				  Ext.create('Ext.tip.ToolTip', {
						target: c.inputEl,
						html: c.value,
						maxWidth : 10000,
						listeners: {
						  beforeshow: function(tip) {
						
						  if(Ext.isEmpty(c.getValue()) || (c.getValue().length < 10)){
							  return false;
						  }
						  tip.update(c.getValue());
						}
						}					
					  });
					});
		}
		//me.on('change', me.onChangeFuncCmc);//Associating a new defined method with an event
		
		
		if(me.columnsCmc && Ext.isArray(me.columnsCmc)){
			me.prepareListTemplateCmc(me.columnsCmc);
		}
		
		me.on('specialkey', function(field, e) {
            if (e.getKey() == e.ENTER) {
                var grid = field.up('cmcgrid')||field.up('grid');
                if(grid){
                	var store = grid.store;
                    var selModel = grid.getSelectionModel();
                    var selectedRecord = selModel.getLastSelected();


                    var plugin = grid.getPlugin('editorPlugin');
                    
                    if(plugin && grid.columns.indexOf(plugin.activeColumn)){
                    	var columnIndex = grid.columns.indexOf(plugin.activeColumn);
                    	plugin.on('edit',function(){
                    		plugin.startEdit(store.indexOf(selectedRecord),columnIndex+1);
                    	},this,{single:true});
                    }
                    
                }
                
            }else if(e.getKey() == e.TAB){
            	field.on('beforequery',function(){return false;},this,{single:true});
            	new Ext.util.DelayedTask(function(){
            		field && field.collapse();
            	}).delay(100);
            }
        });
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	
	//Defining a method below and associating this with an event in the constructor above
	beforeRenderFuncCmc:function(){
		var me		=		this;
		if(!me.allowBlank){
			me.labelStyle	=	'color:#000000';		
		}	
		if(me.readOnly){
			if(!me.legendCmc){
				me.fieldCls	=	'readOnlyClsCmc';
			}
			me.focusCls		=	'';
			//me.submitValue	=	false;
		}
	},
	
	selectEventFuncCmc:function(combo, record){
		var me		=		this;
		if(record && record[0] && record[0].data){
			me.validateSuccessFuncCmc(record[0].data);
		}
		/* me.clearInvalid();
		me.setfieldValidCmc(true);
		me.setselEventFiredCmc(true);  */
	},
	/**
		**Following function can be passed an object as an argument with key as forceFire:true in order to forcefully fire the event irrespective of whether the value is valid or not
	**/
	blurEventFuncCmc:function(argObj){
	
		var me				=		this;
		var forceFire		=		false;//Using this request can be forcefully fired
		
		/**
			**Following has been added to check if user has provided same value which implies all values
			**In such a case, no request will be fired for validation
			**Field will be marked valid and validateFailFuncCmc will be fired so that all the dependent are removed
		**/
		if(me.isAllowedAllCmc && me.getRawValue()==me.allAllowedValCmc){
			me.oldRawValueCmc	=		me.getRawValue();
			me.fieldValidCmc	=		true;
			me.invalidText		=		'';
			me.clearInvalid();
			me.validateFailFuncCmc();
			return true;
		}
		
		//Following is used to check if forceFire has been set to true
		if(argObj && argObj.forceFire && typeof argObj.forceFire=='boolean'){
			forceFire		=		argObj.forceFire;
		}		
		
		if((!me.getRawValue() || me.getRawValue()=='') && !forceFire){//This checks if value has been provided or not and also if forceFire is false or not
			me.oldRawValueCmc	=		me.getRawValue();
			if(!me.allowBlank){
				//Following takes care of case when no value has been provided but allowblank is also false
				//Setting the error message for mandatory and making field invalid below
				me.fieldValidCmc	=		false;
				me.invalidText		=		'This field is required';
				me.markInvalid(me.invalidText);
			}else{
				//Following takes care of the case when no value has been provided and allowBlank is true
				//Setting the field as valid below and clearing any invalid message
				me.fieldValidCmc	=		true;
				me.invalidText		=		'';
				me.clearInvalid();				
			}
			me.validateFailFuncCmc();//Calling the fail function here in order to clear all dependencies
			return true;
		}else if((me.oldRawValueCmc!=me.getRawValue()) || forceFire){//This checks if the request should be fired or not
			//Request will get fired if old value is different from current one or if forceFire has been set
			if(me.showCheckingMaskOnBlur){//displaying the masking if showCheckingMaskOnBlur is true
				me.el.mask('Checking...');
			}			
			me.oldRawValueCmc						=		me.getRawValue();//Setting the curent value to old value
			
			//me.validateParamsCmc					=		Modules.GlobalFuncs.getParamsObjFromIdNmVal(me.validateParamsCmc);
			//me.validateParamsCmc[me.displayField]	=		me.getRawValue();
			
			//Getting the parameters to be sent with the validate request below
			var extraParamsCmc						=		Modules.GlobalFuncs.getParamsObjFromIdNmVal(me.validateParamsCmc);
			extraParamsCmc[me.displayField]			=		me.getRawValue();//Sending the raw value with displayName
			
			//Firing the Ajax request below
			Ext.Ajax.request({
				url: me.validateUrlCmc,
				params: extraParamsCmc,
				method:me.validateAjaxMethodCmc,
				success: function(response){
					respObj					=		Ext.JSON.decode(response.responseText);
					if(respObj.success){//Following is executed if the value is valid
						me.fieldValidCmc	=		true;//Marking the field valid
						me.invalidText		=		'';//Clearing the invalid text
						if(respObj.data && respObj.data[me.valueField]){//Adding the data below to store and setting the value							
							me.store.add(respObj.data);
							me.setValue(respObj.data[me.valueField]);
						}						
						//following condition has been added to take care of the case like FPD combos where user can type only few characters and they will be accepted too as valid but the final raw value would be different from the initial typed in raw value butt commenting it currently too
						/* if(me.getRawValue()){
							if(me.oldRawValueCmc.toLowerCase()!=me.getRawValue().toLowerCase()){
								me.oldRawValueCmc	=	me.getRawValue();
							}
						} */
						me.validateSuccessFuncCmc(respObj.data);//Calling the success function
						me.clearInvalid();//Clearing the invalid mark
						if(me.showCheckingMaskOnBlur){
							me.el.unmask();//Hiding the mask
						}						
						return true;//Returning true
					}else{//Following is executed if value provided is invalid
						me.fieldValidCmc		=		false;//Marking the field as invalid
						if(respObj.errors){//If errors are returned by server then setting them to invalidText
							me.invalidText		=		respObj.errors;
						}
						me.markInvalid(me.invalidText);//Marking the field as invalid
						me.validateFailFuncCmc();//Calling validate fail function
						if(me.showCheckingMaskOnBlur){
							me.el.unmask();//Hiding the maske
						}
						return true;//Returning from this function
					}
				},
				failure:function(response){//Following is executed if some server error came up
					me.fieldValidCmc		=		false;//Marking field invalid
					if(Modules.Msgs && Modules.Msgs.serverError){//Setting error below
						me.invalidText			=		Modules.Msgs.serverError;
					}else{
						me.invalidText			=		'Server error. Please try later';
					}
					me.markInvalid(me.invalidText);//displaying the invalid css
					me.validateFailFuncCmc();//Calling fail function
					if(me.showCheckingMaskOnBlur){
						me.el.unmask();//Hiding the mask
					}
					return true;//Returning back to main code
				}
			});
		}else if(!me.fieldValidCmc){//If field is invalid then marking it below 
			me.markInvalid(me.invalidText);
			return true;
		}else{
			return true;//If no change is there in the status of field then maintaining the status quo
		}
	},//EOF
	
	/* onChangeFuncCmc:function(){
		var me		=		this;
		if(me.getRawValue() && me.getRawValue()!=''){
			me.setRawValue(me.getRawValue().toUpperCase());
		}
	}, */
	
	/**
		**Following function is used to get the listConfig object of combobox
		**ComboBox should have following two properties:
			**tplFieldsArrCmc (mandatory) - should be an array having objects in the format 
			[
				{
					name:'keyName', 
					width:50px,//this should be the width to be assigned to the column in px, 
					align:'center'//this is optional with default value being left
				},
				.
				.
				{
					name:'keyName', 
					width:50px,//this should be the width to be assigned to the column in px, 
					align:'center'//this is optional with default value being left
				}
			]
			**tplHeightCmc (not mandatory) - should be the height to be assigned to the template, with default value = 150
	**/
	getListConfigFuncCmc:function(){
		var me		=		this;
		var finalObj		=		{
			loadingText: 'Loading...',
			deferEmptyText:false,
			emptyText:'No Values Found!'
		};	
		if(!(me.tplFieldsArrCmc && me.tplFieldsArrCmc.length)){
			return finalObj;
		}
		finalObj.height			=		me.tplHeightCmc?argObj.tplHeightCmc:150;
		var width				=		0;
		var fieldsArr			=		me.tplFieldsArrCmc;
		var tplStr				=		'<table><tr><td colspan="'+fieldsArr.length+'" height="5px"></td></tr>';
		tplStr					+=		'<tr>';
		for(var i=0; i<fieldsArr.length; i++){
			var field			=		fieldsArr[i];
			width				+=		field.width;
			tplStr				+=		'<td width="'+field.width+'" align="'+field.align?field.align:"left"+'">{'+field.name+'}</td>';
		}//End of for loop		
		tplStr					+=		'</tr>';
		tplStr					+=		'</table>';
		finalObj.width			=		width?width:200;
		finalObj.getInnerTpl	=		function(){
			return tplStr;
		}
		return finalObj;
	},
	
	/**Following function is used to set the raw value to oldRawValueCmc whenever the setValue function is called**/
	setValue:function(value, doSelect){
		var me				=		this;
		var obj				=		me.callParent(arguments);
		obj.oldRawValueCmc	=		obj.getRawValue();//Setting the value to oldRawValueCmc
		obj.clearInvalid();
		obj.invalidText		=		'';
		obj.fieldValidCmc	=		true;
		return obj;
	},
	
	/**Following function is used to set the raw value to oldRawValueCmc whenever the setRawValue function is called**/
	setRawValue:function(value){
		var me				=		this;
		var value			=		me.callParent(arguments);
		me.oldRawValueCmc	=		me.getRawValue();//Setting the raw value to oldRawValueCmc
		me.clearInvalid();
		me.invalidText		=		'';
		me.fieldValidCmc	=		true;
		return value;
	},
	
	/**Following function is used to convert the value to uppercase before returning the value**/
	getValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
		return val ; //added by imran
		//return (val && val.toUpperCase)?val.toUpperCase().trim():val;
	},
	
	/**Following function is used to convert the value to uppercase before returning the raw value**/
	getRawValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
		return val ;
		//return (val && val.toUpperCase)?val.toUpperCase().trim():val;
	},
	
	/**Following function is used to convert the value to uppercase before returning the value when the form is submitted**/
	getSubmitValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
		return val ;
		//return (val && val.toUpperCase)?val.toUpperCase().trim():val;
	},
	/**
	 * 
	 * This method cretes LOVs view using follwoing format of tpl
	 * 			
		tpl: Ext.create('Ext.XTemplate',
				'<div class="lov-header">',
					'<li style="width: 100px;" class="lov-li">Code</li>',
					'<li style="width: 100px;" class="lov-li"> Name </li>',
					
				'</div>',
				'<tpl for=".">',
					'<div class="x-boundlist-item">',
						'<li style="width: 100px;" class="lov-li">{supplrCd}</li>',
						'<li style="width: 100px;" class="lov-li"> {supplrNm}</li>',
						
					'</div>',
				'</tpl>'),
	 * */
	prepareListTemplateCmc : function(columnsCmc){
		var me = this;
		var headerPart='',detailPart='';
		Ext.iterate(columnsCmc,function(column){
			if(column.dataIndex){
				headerPart+='<li style="width: '+(column.width || 200)+'px;" class="lov-li">'+column.header+'</li>';
				detailPart+='<li style="width: '+(column.width || 200)+'px;" class="lov-li">{'+column.dataIndex+'}</li>';
			}
		});
		
		me.tpl = Ext.create('Ext.XTemplate',
				'<div class="lov-header">',
					headerPart,
				'</div>',
				'<tpl for=".">',
					'<div class="x-boundlist-item">',
						detailPart,
					'</div>',
				'</tpl>');
	}
});