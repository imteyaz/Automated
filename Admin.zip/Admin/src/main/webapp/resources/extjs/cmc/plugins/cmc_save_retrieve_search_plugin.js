/**
 * This plugin class enables a form panel {@link Ext.form.Panel form} to have' save and retrieve search criteria'
 * capability.
 * The plugin adds tow buttons as top docked item, labeled as ....
 * 
 * Limitations: For now it works only with form panel, later version will have support for all Panels and subclasses 

 */
Ext.define('Ext.cmc.plugin.SaveRetrieveCriteria', {
    alias: 'plugin.saveretrievecriteria',

    requires: [],

    mixins: {
        observable: 'Ext.util.Observable'
    },

    /**
     * @cfg {Boolean} If set to true loads default search criteria to panel on render. Default is true 
     */
    loadDefault: true,
    /**
     * @cfg {Integer} If tbar is specified in the panel pass the index where the buttons should be added. Default is last index on tool bar buttons
     */
    index:undefined,
    // private
    targetPanel: '',

    constructor: function (config) {
        var me = this;
        
        me.loadDefault= true;
        
        Ext.apply(me, config);
        me.mixins.observable.constructor.call(me);
    },

    // private
    init: function (panel) {
        var me = this;
        me.targetPanel = panel;
        
        me.screenId = me.screenId || panel.screenId;
        

        if (!panel.getForm) {
            //console.error('Ext.cmc.plugin.SaveRetrieveCriteria : Current plugin version only supports Form panels');
            return;
        }

        if (!me.screenId) {
            //console.warn('Ext.cmc.plugin.SaveRetrieveCriteria : screenId or id or itemId must be provided');
            return;
        }

        panel.addEvents('defaultsearchloadedcmc');
        
        if (me.loadDefault) {
            panel.on('render', function (panel) {
            	
            	  if (!me.loadDefault) {
            		  return true;
            	  }
            	  
                Ext.Ajax.request({
                    url: 'getDefaultSaveSearchStatusMonitor',
                    params: {
                        userId: Modules.GlobalVars.loginUserId,
                        screenId: me.screenId,
                        serviceType: Modules.GlobalVars.selectedServiceTypeCode,
                        companyCode: Modules.GlobalVars.selectedCompanyCode
                    },
                    method: 'GET',
                    success: function (response) {
                        var temp = Ext.decode(response.responseText);

                        if (temp.totalCount > 0) {
                            var searchCriteria = temp.items[0].searchCriteriaData || temp.items[0].searchCriteria;
                            var criteriaObject = Ext.decode(decodeURIComponent(searchCriteria));
                            try{
                            	
                            	if(typeof criteriaObject == "string"){
                            		
                            		criteriaObject = Ext.JSON.decode(criteriaObject);
                            	}
                            }catch(e){
                            	
                            }
                            me.targetPanel.getForm().reset();
                           
                            me.targetPanel.getForm().setValues(criteriaObject);
                            for(var key in criteriaObject){
                          	  if(Ext.typeOf(criteriaObject[key]) == "array"){
                          		  var arrayValue = criteriaObject[key];
                          		  var fieldArray = me.targetPanel.query('field[name="'+key+'"]');
                          		  
                          		  if(fieldArray.length == arrayValue.length){
                          			  for(var index=0;index < arrayValue.length;index++){
                          				  fieldArray[index].setValue(arrayValue[index]);
                          			  }
                          		  }
                          		  
                          	  }                                  
                          }
                            
                            panel.fireEvent('defaultsearchloadedcmc',criteriaObject); 
                            
                        }
                    }
                });
            }, panel, {
               // single: true
            });
        }
        var saveBtn = {
            text: Modules.Common_Operation.labels.saveSearchCriteria,
            xtype: "button",
            iconCls: "saveSearch",
            dock: 'top',
            handler: function () {
            	
            	if(!panel.getForm().isValid()){
            		Ext.MessageBox.show({ title : '',
        				msg : Modules.Msgs.invalidSearchData,
        				buttons:Ext.MessageBox.OK,
        				icon : Ext.MessageBox.ERROR
					 });
        		return;
            	}
            	
            	//var criteria = panel.getForm().getValues(false, true,false,true);
            	var criteria = panel.getForm().getValues(false, false,false,true);
            	
            	if(Modules.GlobalFuncs.isEmptyObj(criteria)){
            		Ext.MessageBox.show({ title : '',
            				msg : Modules.Msgs.noSearchCriteria,
            				buttons:Ext.MessageBox.OK,
            				icon : Ext.MessageBox.INFO
						 });
            		return;
            	}
            /*	if(!checkFormWithValidEntry(criteria)){
            		Ext.MessageBox.show({ title : '',
            				msg : Modules.Msgs.deleteTheSpaceMessage,
            				buttons:Ext.MessageBox.OK,
            				icon : Ext.MessageBox.INFO
						 });
            		return;
            	}*/
                var searchCriteriaData = encodeURIComponent(Ext.encode(criteria));
                me.viewSaveSearchCriteriaWindow(me.screenId, searchCriteriaData).show();
            }
        };
        
     /*   checkFormWithValidEntry = function(obj){
        	var check= false;
        	for ( var key in obj) {
          				if(Ext.isString(obj[key])){
	    					if (obj[key].length>0 && obj[key].trim().length>0) {
	    						check=true;
	    					}
          				}
          				else if(Ext.isBoolean(obj[key])){	
          					check = true;
          				}
        	}
        	if(check== true)  return true;
        	else  return false;
        }*/
        
        var retrieveBtn = {
            xtype: "button",
            iconCls: "retrieveSearch",
            dock: 'top',
            text: Modules.Common_Operation.labels.retrieveSearchCriteria,
            handler: function () {
                me.retrievesearchCriteriaWindow(me.screenId).show();
            }
        };

        var topToolbar = panel.getDockedItems('[dock=top]');

        if (topToolbar && topToolbar[0]) {
            topToolbar = topToolbar[0];
        } else {
            topToolbar = Ext.create('Ext.toolbar.Toolbar', {
                dock: 'top',
                items: ['->']
            });
            panel.addDocked(topToolbar);
        }

        topToolbar.add((me.index || topToolbar.items.getCount()), [saveBtn, retrieveBtn]);
    },
    viewSaveSearchCriteriaWindow: function (screenId, searchCriteriaData, getRecord) {
        var modalFormObj = function () {
            var userId = Modules.GlobalVars.loginUserId;
            var companyCode = Modules.GlobalVars.selectedCompanyCode;
            var serviceType = Modules.GlobalVars.selectedServiceTypeCode;
            var requiredField = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';
            var form = {
                xtype: 'form',
                id: 'applicationAdviceModalwindowFormid',
                showFieldsetCmc: false,
                buttonAlign: "right",
                width: '400',
                height: '200',
                defaults: {
                    margin: '4px 2px 4px 10px',
                    columnWidth: .7,
                    labelWidth: 100,
                    labelAlign: "left"
                },
                bodyStyle: 'background-color: #FFFFFF',
                listeners: {
                    afterrender: function () {
                        if (getRecord) {

                            this.getForm().setValuesCmc({
                                searchName: getRecord.get('saveSearchKey'),
                                searchDesc: getRecord.get('saveSearchKeyDesc'),
                                defaultFlag: getRecord.get('defaultFlag')
                            });
                        }
                    }
                },
                layout: 'column',
                items: [{
                    xtype: 'cmctextfield',
                    width: 330,
                    itemId: "searchName",
                    name: 'searchName',
                    submitValue: true,
                    fieldLabel: Modules.LblsAndTtls.statusMonitorSaveSearchNameTlt,
                    readOnly: Ext.isDefined(getRecord),
                    maxLength:30

                }, {
                    xtype: 'cmctextfield',
                    width: 330,
                    itemId: "searchDesc",
                    name: 'searchDesc',
                    readOnly: Ext.isDefined(getRecord),
                    fieldLabel: Modules.LblsAndTtls.statusMonitorSaveSearchDescTlt,
                    labelAlign: "left",
                    maxLength:120
                },

                // ---------------------check box-------------------------------------
                {
                    xtype: 'cmccheckboxfield',
                    name: 'defaultFlag',
                    itemId: 'defaultFlag',
                    fieldLabel: Modules.LblsAndTtls.statusMonitorSaveSearchDefaultFlagTlt,
                    labelAlign: "left",
                    allowBlank: true,
                    labelSeparator: '',
                    labelAlign: "left"

                }, {
                    xtype: 'container',
                    layout: 'hbox',
                    margin: '0px 0px 0px 120px',
                    defaults: {
                        margin: '20px 0px 0px 20px'
                    },
                    items: [{
                        xtype: "button",
                        text: Modules.LblsAndTtls.saveActionTtl,
                        align: 'center',
                        handler: function () {
                            var saveDate = new Date().getTime();
                            var formPanel = this.up('form');
                            var formValue = {
                                searchName: formPanel.down('#searchName').getValue(),
                                searchDesc: formPanel.down('#searchDesc').getValue(),
                                defaultFlag: formPanel.down('#defaultFlag').getValue()
                            };

                            if (getRecord) {
                            //	Ext.Msg.confirm( Modules.Msgs.confirmTitle, Modules.Msgs.Modules.Msgs.confirmationMsgToChangeCriteria, function( answer ) {
					         //       if( answer == "yes" ) {
                                Ext.Ajax.request({
                                    url: 'statusMonitorSaveSearchDefaultFlagChange',
                                    params: {
                                        userId: userId,
                                        screenId: screenId,
                                        searchName: formValue.searchName || this.up('form').down('#saveSearchName').getValue(),
                                        defaultFlag: formValue.defaultFlag,
                                        serviceType: serviceType,
                                        companyCode: companyCode
                                    },
                                    method: 'POST',
                                    success: function (response) {
                                        var result = Ext.decode(response.responseText);
                                        if (result.condition == 'Updated') {
                                            saveCriteriaWin.addEvents('success');
                                            saveCriteriaWin.fireEvent('success');
                                            Ext.MessageBox.show({
                                                msg: Modules.Msgs.confirmationMsgToChangeCriteria,
                                                buttons: Ext.MessageBox.OK,
                                                icon: Ext.MessageBox.INFO
                                            });
                                            saveCriteriaWin.close();
                                        }
                                    }
                                });
					          //  }});
                            } else {

                                if (!Ext.isEmpty(formValue.searchName) && formValue.searchName.trim().length > 0 ) {
                                    Ext.Ajax.request({
                                        url: 'statusMonitorSaveSearchCriteria',
                                        params: {
                                            userId: userId,
                                            screenId: screenId,
                                            searchName: formValue.searchName,
                                            searchDesc: formValue.searchDesc,
                                            defaultFlag: formValue.defaultFlag,
                                            searchCriteriaData: searchCriteriaData,
                                            serviceType: serviceType,
                                            companyCode: companyCode,
                                            saveDate: saveDate
                                        },
                                        method: 'POST',
                                        success: function (response) {
                                            var array = Ext.decode(response.responseText);
                                            if (array.value == 'Saved') {
                                                Ext.MessageBox.show({
                                                    msg: Modules.Msgs.savedMessage,
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.INFO
                                                });
                                                saveCriteriaWin.close();
                                            }

                                            if (array.value == 'Not Saved') {
                                                Ext.MessageBox.show({
                                                    msg: Modules.Msgs.searchCriteriaKeywordStatus,
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.ERROR
                                                });
                                            }else if(array.value == 'Error'){
                                                Ext.MessageBox.show({
                                                    msg: array.status,
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.ERROR
                                                });                                            	
                                            }else if (array.value == 'Default flag already exist') {
                                                Ext.Msg.confirm(Modules.Msgs.confirmTitle, Modules.Msgs.confirmationMsgToChangeDefault, function (answer) {
                                                    if (answer == "yes") {
                                                        Ext.Ajax.request({
                                                            url: 'statusMonitorUpdateCurrentAsDefaultFlag',
                                                            params: {
                                                                userId: userId,
                                                                screenId: screenId,
                                                                searchName: formValue.searchName,
                                                                searchDesc: formValue.searchDesc,
                                                                defaultFlag: formValue.defaultFlag,
                                                                searchCriteriaData: searchCriteriaData,
                                                                serviceType: serviceType,
                                                                companyCode: companyCode
                                                            },
                                                            method: 'POST',
                                                            success: function (response) {
                                                                var result = Ext.decode(response.responseText);
                                                                if (result.condition == 'Updated') {
                                                                    Ext.MessageBox.show({
                                                                        msg: Modules.Msgs.savedMessage,
                                                                        buttons: Ext.MessageBox.OK,
                                                                        icon: Ext.MessageBox.INFO
                                                                    });
                                                                    saveCriteriaWin.close();
                                                                }
                                                            },
                                                            failure: function (response) {
                                                                Ext.MessageBox.show({
                                                                    msg: Modules.Msgs.internalError,
                                                                    buttons: Ext.MessageBox.OK,
                                                                    icon: Ext.MessageBox.ERROR
                                                                });
                                                                saveCriteriaWin.close();
                                                            }
                                                        });
                                                    }

                                                });
                                            }

                                        }
                                    });
                                } else {
                                    Ext.MessageBox.show({
                                        msg: Modules.Msgs.mandatoryStatus,
                                        buttons: Ext.MessageBox.OK,
                                        icon: Ext.MessageBox.ERROR
                                    });
                                }
                            }
                        }
                    },{
                    	 xtype: "button",
                         text: Modules.Common_Operation.labels.close,
                         align: 'center',
                         handler: function () {
                        	 saveCriteriaWin && saveCriteriaWin.close();
                         }
                    }]
                }]

            };
            return form;
        };


        var saveCriteriaWin = Ext.create('Ext.Window', {

            title: Modules.LblsAndTtls.saveSearchTlt,
            height: 170,
            width: 400,
            x: 355,
            y: 120,
            resizable :false,
            frame: false,
            modal: true,
            layout: 'fit',
            items: modalFormObj()
        });
        return saveCriteriaWin;
    },
    retrievesearchCriteriaWindow: function (screenId) {

        var win = Ext.create('Ext.cmc.Window', {
            title: ' Retrieve Search Criteria',
            itemId: 'retrieveSearchCriteriaWindow',
            height: 440,
            width: 795,
            x: 205,
            y: 120,
            modal: true,
            closeAction: 'destroy',
            showCenterItemCmc: false,
            screenId: this.screenId, //TODO: remove it
            items: [this.getSaveCriteriaGrid()]

        });
        return win;
    },
    getSaveCriteriaGrid: function () {
        var thisPlugin = this;
        var userId = Modules.GlobalVars.loginUserId;
        var companyCode = Modules.GlobalVars.selectedCompanyCode;
        var serviceType = Modules.GlobalVars.selectedServiceTypeCode;
        var requiredField = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';
        var searchCriteriaData;
       
		
        
        function setCharAt(str, index, chr) {
            if (index > str.length - 1) return str;
            return str.substr(0, index) + chr + str.substr(index + 1);
        }
        var storeObj = {
            model: 'saveRetrieveSerachModel',
            url: 'getRetrieveSaveSearchStatusMonitor',
            paging: true,
            listeners : {
				beforeload:function(){
					//for sending selected values to controller
					 var limitVal = Ext.getCmp('retrieveSearchCriteriaGridId').getComponent('centerGridPagingToolBarItemId').getComponent('perPageCombo').getValue();
						if (!limitVal) {
							limitVal = Modules.GlobalVars.recordsPerPageGrid;
						}
					this.proxy.extraParams.userId = userId;
					this.proxy.extraParams.screenId = thisPlugin.screenId;
					this.proxy.extraParams.serviceType = serviceType;
					this.proxy.extraParams.companyCode = companyCode;
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				}
			},
           /* extraParams: {
                userId: userId,
                screenId: thisPlugin.screenId,
                serviceType: serviceType,
                companyCode: companyCode,
                limit : limitVal
            },*/
            queryTypeCmc: 'remote',
            autoLoad: true
        };
        var grid = {
            xtype: 'cmcgrid',
            itemId: "retrieveSearchCriteriaGrid",
            id:'retrieveSearchCriteriaGridId',
            storeObjCmc: storeObj,
            region: 'center',
            showPagingBarCmc: true,
            showSelModelCmc: true,
            showLeftExtraTbarCmc: true,
            setLeftExtraTbarFuncCmc: function () {

                var buttonArray = [{
                    xtype: "button",
                    iconCls: "delete",
                    text: Modules.LblsAndTtls.deleteActionTtl,
                    itemId: 'deleteButton',
                    handler: function () {
                        var retrieveSearchCriteriaGrid = this.up("#retrieveSearchCriteriaGrid");
                        var array = retrieveSearchCriteriaGrid.getSelectionModel().getSelection();


                        if (array.length == 1) {
                            Ext.Msg.confirm('', Modules.Msgs.deleteSingleRecordConfirmation, function (answer) {
                                if (answer == "yes") {
                                    for (var i = 0; i < array.length; i++) {
                                        var searchName = array[i].get('saveSearchKey');
                                        Ext.Ajax.request({
                                            url: 'statusMonitorDeleteSearchCriteria',
                                            params: {
                                                userId: userId,
                                                screenId: thisPlugin.screenId,
                                                searchName: searchName,
                                                serviceType: serviceType,
                                                companyCode: companyCode
                                            },
                                            method: 'GET',
                                            success: function (response) {
                                                retrieveSearchCriteriaGrid.getStore().load();
                                                Ext.MessageBox.show({
                                                    title: '',
                                                    msg: Modules.Msgs.deleteSuccess,
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.INFO
                                                });
                                            },
                                            failure: function (response) {}
                                        });
                                    }
                                }
                            });
                        } else if (array.length > 1) {
                            Ext.Msg.confirm('', Modules.Msgs.deleteMultiRecordsConfirmation, function (answer) {
                                if (answer == "yes") {
                                    for (var i = 0; i < array.length; i++) {
                                        var searchName = array[i].get('saveSearchKey');
                                        Ext.Ajax.request({
                                            url: 'statusMonitorDeleteSearchCriteria',
                                            params: {
                                                userId: userId,
                                                screenId: thisPlugin.screenId,
                                                searchName: searchName,
                                                serviceType: serviceType,
                                                companyCode: companyCode
                                            },
                                            method: 'GET',
                                            success: function (response) {
                                                retrieveSearchCriteriaGrid.getStore().load();
                                                Ext.MessageBox.show({
                                                    title: '',
                                                    msg: Modules.Msgs.deleteSuccess,
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.INFO
                                                });
                                            },
                                            failure: function (response) {}
                                        });
                                    }
                                }
                            });
                        } else {
                            Ext.MessageBox.show({
                                title: '',
                                msg: Modules.Msgs.selRecFrst,
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.INFO
                            });
                        }


                    }
                }, {
                    xtype: "button",
                    iconCls: "retrieve",
                    text: Modules.LblsAndTtls.populateSearchCriteriaTtl,
                    itemId: 'populateButton',
                    handler: function (btn) {
                        var retrieveSearchCriteriaGrid = this.up("#retrieveSearchCriteriaGrid");
                        var array = retrieveSearchCriteriaGrid.getSelectionModel().getSelection();

                        if (array.length == 0) {
                            Ext.MessageBox.show({
                                msg: Modules.Msgs.selectSingleRecord,
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });
                        } else if (array.length == 1) {

                            var searchResult = retrieveSearchCriteriaGrid.getSelectionModel().getSelection()[0];
                            if (searchResult) {
                                searchCriteria = searchResult.get('searchCriteria');
                                if (searchCriteria) {
                                    var criteriaObject = Ext.decode(decodeURIComponent(searchCriteria));
                                    thisPlugin.targetPanel.getForm().reset();
                                    thisPlugin.targetPanel.getForm().setValues(criteriaObject);
                                                                    
                                   for(var key in criteriaObject){
                                	  if(Ext.typeOf(criteriaObject[key]) == "array"){
                                		  var arrayValue = criteriaObject[key];
                                		  var fieldArray = thisPlugin.targetPanel.query('field[name="'+key+'"]');
                                		  
                                		  if(fieldArray.length == arrayValue.length){
                                			  for(var index=0;index < arrayValue.length;index++){
                                				  fieldArray[index].setValue(arrayValue[index]);
                                			  }
                                		  }
                                		  
                                	  }                                  
                                }
                                    this.up("#retrieveSearchCriteriaWindow").close();

                                }

                            }
                        } else if (array.length > 1) {
                            Ext.MessageBox.show({
                                msg: Modules.Msgs.selectOnlySingleRecord,
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });
                        }


                    }
                }];
                return buttonArray;

            },
            setGridColumnsFuncCmc: function () {
                var colsArr = [{
                    xtype: 'actioncolumn',
                    width: 50,
                    sortable: false,
                    hideable: false,
                    items: [{
                        icon: 'resources/images/editView.jpg',
                        tooltip: 'Edit window',
                        handler: function () {
                            return true;
                        }
                    }]
                }, {
                    header: Modules.LblsAndTtls.statusMonitorSaveSearchNameTlt,
                    dataIndex: 'saveSearchKey',
                    align: 'left',
                    width: 123,
                    id: 'saveSearchKeyId',
                    hideable: false
                }, {
                    header: Modules.LblsAndTtls.statusMonitorSaveSearchDescTlt,
                    dataIndex: 'saveSearchKeyDesc',
                    align: 'left',
                    width: 225
                    //hideable : false
                }, {
                    header: Modules.LblsAndTtls.statusMonitorSaveSearchDefaultFlagTlt,
                    dataIndex: 'defaultFlag',
                    align: 'left',
                    width: 140
                }, {
                    header: Modules.LblsAndTtls.savedOnDateTlt,
                    dataIndex: 'savedDate',
                    width: 200,
                    align: 'left'

                }];
                return colsArr;
            },
            listeners: {
                cellclick: function (cellModel, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    if (cellIndex == '1') {

                        var saveWin = thisPlugin.viewSaveSearchCriteriaWindow(thisPlugin.screenId, searchCriteriaData, record).show();
                        saveWin.on('success', function () {
                            this.store.load();
                        }, this);
                    }

                },
                render: function (grid) {
                    grid.store.on('load', function (store) {
                        if (store.getCount() == 0) {
                            this.down('#deleteButton').disable();
                            this.down('#populateButton').disable();


                            Ext.MessageBox.show({
                                msg: Modules.Msgs.noRecordsInGrid,
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.INFO
                            });
                        }

                    }, grid);
                }

            }

        };
        return grid;
    }
});

Ext.define('saveRetrieveSerachModel', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'saveSearchKey',
        type: 'string'
    }, {
        name: 'saveSearchKeyDesc',
        type: 'string'
    }, {
        name: 'defaultFlag',
        type: 'string'
    }, {
        name: 'savedDate',
        type: 'string'
    }, {
        name: 'searchCriteria',
        type: 'string'
    }]
});


Ext.form.Basic.prototype.setValuesCmc = function (values) {
    var me = this;

    function setVal(fieldId, val) {
        var field = me.findField(fieldId);

        if (field) {
            if (field instanceof Ext.form.field.Checkbox && (val == 'true' || val == 'Y')) {
                val = 'on';
            }
            field.setValue(val);
            if (me.trackResetOnLoad) {
                field.resetOriginalValue();
            }
        }
    }

    if (Ext.isArray(values)) {
        // array of objects
        Ext.each(values, function (val) {
            setVal(val.id, val.value);
        });
    } else {
        // object hash
        Ext.iterate(values, setVal);
    }
    return this;
};