Ext.define('Ext.cmc.TreePanel',{
	
	extend: 'Ext.tree.Panel',
	alias: 'widget.cmctree',
	
	/***Beginning the config properties which already exist in the component**/
	columnLines: true,
	rowLines: true,
	autoScroll:true,
	rootVisible: false,
	singleExpand:true,
	/***Ending the config properties which already exist in the component**/
	
	/***Beginning adding of new properties***/
	showSelModelCmc:false,
	//selModelModeCmc:'SIMPLE',//SIMPLE will allow selection of multiple records by clicking at row too
	selModelModeCmc:'MULTI',//MULTI will allow selection of multiple records only by clicking at checkbox. Row click will lead to selection of that record only
	showTotalSelectedCmc:false,
	//showRowNumbererCmc:true,
	contextMenuCmc:{},//Mention here the context menu created
	storeObjCmc:{},//This will hold the details of the store object which will be created by the global function of creating store
	clearBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getClearAction
	retrieveBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getRetrieveAction
	/***Ending adding of new properties***/
	
	initComponent:function(){
		
		var me					=		this;
		
		/***Beginning for columns***/
		me.columns				=		[];
		me.columns				=		me.setTreeColumnsFuncCmc();
		/***Ending for columns***/
		
		//Setting store below
		me.store					=		me.__getTreeStoreCmc();
		
		/***Beginning setting of selection model***/
		if(me.showSelModelCmc){
			me.selModel			=		Ext.create('Ext.selection.CheckboxModel', {
				mode:me.selModelModeCmc
			});
		}
		/***Ending setting of selection model***/
		
		if(me.showTotalSelectedCmc && me.showSelModelCmc){
			me.setTotalSelectedFuncCmc();
		} 
		
		me.setTbarFuncCmc();//Calling this function for setting TBar
		
		if(me.viewConfig && Ext.isObject(me.viewConfig)){
			me.viewConfig.enableTextSelection		=		true;
		}else{
			me.viewConfig							=		{};
			me.viewConfig.enableTextSelection		=		true;
		}
		
		me.on('itemcontextmenu', me.itemContextMenuFuncCmc);
		
		me.callParent();//No arguments passed as per the docs in API		
		
		if(me.showTotalSelectedCmc && me.showSelModelCmc){
			me.on('selectionchange', me.selectionChangeFuncCmc);
		}
		
		me.on('destroy', me.destroyFuncCmc);
	},
	
	setTbarFuncCmc:function(){
		
		var me		=		this;
		
		me.tbar		=		[];//Setting TBar to an empty array	
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.clearBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getClearAction(me.clearBtnObjCmc);
		}
		
		if(me.retrieveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getRetrieveAction(me.retrieveBtnObjCmc);
		}
		
		me.tbar[me.tbar.length]	=	'->';//This line has been added to create the space after Retrieve button
		
		if(me.showExtraTbarCmc){
			var extraTbar		=		me.setExtraTbarFuncCmc(me.winFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraTbar && extraTbar.length && extraTbar instanceof Array && Object.prototype.toString.call(extraTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraTbar);
			}
		}	
		
		if(!me.tbar.length){
			delete me.tbar;//Deleting the tbar if no buttons have been added so far
		}			
	},
	
	//Following function can be used to set the extra buttons in the tbar
	setExtraTbarFuncCmc:function(winFuncArgObjCmc){
		//This function will carry the code of buttons specific to the window
		//This function should return an array of button definitions including the spacers if required
		/*
			Example:
			[
				{
					text:'Report'
					handler:function(){}
				},
				{
					text:'Copy To All',
					handler:function(){}
				},
				'->'//Use only if the buttons need to be in the center of window's tbar
			]
		*/
	},
	
	setTreeColumnsFuncCmc:function(){//this function will return an array of objects carrying column definitions
		
	},	
	
	setTotalSelectedFuncCmc:function(){
		var me		=		this;
		var obj		=		{
			xtype:'cmctextfield',
			readOnly:true,
			labelAlign:'right',
			fieldLabel:'Total Selected',
			width:150,
			labelWidth:100,
			itemId:'totalSelectedTreeTextFieldItemId'
		};
		if(me.bbar){				
			me.bbar.add(obj);
		}else{
			me.bbar		=		new Ext.toolbar.Toolbar();
			me.bbar.add(obj);
		}
	},
	
	//Following function is called at context menu event and is used to display the context menu or stop the context menu of browser to appear
	itemContextMenuFuncCmc:function(view, record, item, index, e, eOpts){
		var me		=		this;
		e.stopEvent();//Preventing the context menu of browser to appear
		if(me.contextMenuCmc.items){//Checking first if context menu has been specified by the user or not
			me.getSelectionModel().select(record);//Setting the record at which user has right clicked as the selected record
			me.contextMenuCmc.showAt(e.getXY());//Displaying the context menu if specified by the user
		}
	},
	
	//Following function is fired at selection change and is used to udpate the textfield carrying the number of selected records
	selectionChangeFuncCmc:function(sm, selectedRecords){
		var me			=		this;
		if(me.dockedItems && me.dockedItems.items && me.dockedItems.items.length){
			for(var i=0; i<me.dockedItems.items.length; i++){
				if(me.dockedItems.items[i].getComponent('totalSelectedTreeTextFieldItemId')){
					break;
				}
			}
			if(i<me.dockedItems.items.length){
				me.dockedItems.items[i].getComponent('totalSelectedTreeTextFieldItemId').setValue(selectedRecords.length);
			}
		}
	},
	
	//Following function is called at destroy event and is used to destroy the context menu if existing.
	//It is used for taking care of the memory leak created if the menu is not explicity destoryed
	destroyFuncCmc:function(){
		var me		=		this;
		if(me.contextMenuCmc.items){//Checking if context menu exists
			me.contextMenuCmc.destroy();//Destroying the context menu
		}
	},//EOF
	
	__getTreeStoreCmc:function(){
		var me						=		this;
		//Obtaining the URL below so that later it can be assigned to the proxy
		var url						=		me.storeObjCmc.url;
		delete me.storeObjCmc.url;
		//Checking if root property exists in the store, if yes then setting rootVisible true for the tree
		if(me.storeObjCmc.root && Ext.isObject(me.storeObjCmc.root) && Ext.Object.getValues(me.storeObjCmc.root).length>0){
			me.rootVisible			=		true;
		}
		//Creating below the generic store config
		var finalStoreConfig		=		{
			proxy:{
				type:'ajax',
				url:url//Attaching the URL to the proxy
			},
			folderSort:true
		};
		//Creating the final store object config by using apply
		Ext.apply(finalStoreConfig, me.storeObjCmc);
		//Creating the tree store
		var store	=		Ext.create('Ext.data.TreeStore', finalStoreConfig);
		return store;//Returning the final store
	}//EOF
});