Ext.define('Ext.cmc.pageHeader', {
	extend: 'Ext.Toolbar',
	alias: 'widget.cmcpageheader',
	ui: 'sencha'
});