/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.SealTypeComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmcsealcombobox',//Defining the xtype	
	/**Beginning the setting of values for already existing configs**/ 
	displayField: 'sDescr',
	valueField:'sealType',
	paging:true,
	matchFieldWidth:false,
	queryMode: 'remote',
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		loadMask: true,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function() {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" align="left">{sealType}</td><td width="125px" align="left">{sDescr}</td><td width="125px" align="left">{eqptInd}</td><td width="125px" align="left">{ediSealType}</td></tr><hr/></table>';
		}
	},
	validateUrlCmc:'masterslookup/validatesealtype',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this; 
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'SealTypeModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'masterslookup/getsealtypelist';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});