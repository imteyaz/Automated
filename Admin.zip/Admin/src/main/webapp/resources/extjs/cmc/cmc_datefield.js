Ext.define('Ext.cmc.Datefield', {
   
	extend: 'Ext.form.field.Date',
	alias: 'widget.cmcdatefield',
    
	/***Beginning the config properties which already exist in the component**/
    focusCls:'focusClass',
	maxHeight:25,
	format:Modules.GlobalVars.dateFormatGlobal,
	invalidText : "{0} is not a valid date",
	altFormats:'d|dm|dmY',
	labelAlign:'left',
	fieldStyle:'text-transform:uppercase',
	valuesAsStringCmc:false,
	toolTipCmc:false,
	minValue:'01/01/1900',
	maxValue:'31/12/9999',
	allowBlank:true,
	/***Ending the config properties which already exist in the component**/
	
	initComponent:function(){
		var me	=	this;
		
		// If values needs to be manipulated as on string object rather than as Date object
		if(me.valuesAsStringCmc == true){
			me.getValue = function(){
				var value = Ext.cmc.Datefield.prototype.getValue.call(this);
				return Ext.Date.format(value,me.format);
			};
			me.setValue = function(value){
				if(typeof value == 'string'){
					value = Ext.Date.parse(value,me.format);
				}
				Ext.cmc.Datefield.prototype.setValue.call(this,value);
			};
		}
		if(me.toolTipCmc){
			me.on('render', function(c) {
				  Ext.QuickTips.register({
					target: c.getEl(),
					text:me.toolTipCmc
				  });
				});
		}
		me.on('beforerender',me.beforeRenderFuncCmc);
		me.callParent();//No arguments passed as per the docs in API		
	},
	setValue : function(val){
		if( !Ext.isEmpty(val) && !Ext.isDate(val)){
			Ext.form.field.Date.prototype.setValue.call(this,new Date(val));
		}else{
			Ext.form.field.Date.prototype.setValue.call(this,val);
		}
	},
	beforeRenderFuncCmc:function(){
		var me	=	this;
		if(!me.allowBlank){
//			me.labelStyle = 'color:#ff0000';	
		}
		
		if(me.readOnly){
			me.fieldCls	=	'readOnlyClsCmc';
		}
	},
	setReadOnly : function(val){
		Ext.form.field.Date.prototype.setReadOnly.call(this,val);
		if(val){
			Ext.form.field.Date.prototype.setFieldStyle.call(this,'background:#C7C9BE;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.Datefield.prototype.fieldStyle+';');
         }else{
        	 Ext.form.field.Date.prototype.setFieldStyle.call(this,'background:#FFFFFF;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.Datefield.prototype.fieldStyle+';');
         }
	}  
});