Ext.cmc.Exporter = new function(){

	
	var prepareColumnMeta = function(grid){
		
		if(grid.headerCt){
			var gridColumns = grid.headerCt.getGridColumns();
		}else{
			gridColumns = grid.getView().getGridColumns();
		}
		var columnMetaArray = [];
		for ( var i = 0; i < gridColumns.length; i++) {
			if (gridColumns[i].dataIndex && !gridColumns[i].hidden) {
				var headerText = gridColumns[i].initialConfig.header || gridColumns[i].initialConfig.text || "";
				columnMetaArray.push({
					columnName:gridColumns[i].dataIndex,
					label:headerText.split('<')[0],
					width:gridColumns[i].width
				});
				
			}
		}
		return columnMetaArray;
	};
	
	
	var openExport = function(columnMetaData,values,url,exportType){
		
		var form = Ext.DomHelper.append(document.body, {
		    tag:'form',
		    target:'_blank',
		    method:'POST',
		    action :url
		  });

		Ext.DomHelper.append(form, {
			tag : 'input',
			type : 'hidden',
			name : 'exportType',
			value : exportType
		});
		
		// Prepare the string to make it ready to send to server
		
		var metaString =  Ext.encode(columnMetaData);
		metaString = metaString.replace(/\"/g,"'");
		Ext.DomHelper.append(form, {
			tag : 'input',
			type : 'hidden',
			name : 'columnMetaData',
			value :metaString
		});
		
		for(var key in values ){
			
			if(typeof values[key] == 'string'){
				values[key] = values[key].replace(/\"/g,"'");
			}
			Ext.DomHelper.append(form, {
				tag : 'input',
				type : 'hidden',
				name : key,
				value : values[key]
			});
		}

	    form.submit();
	    setTimeout(function(){Ext.removeNode(form);}, 100);
	};
	
	var isGridEmpty =  function(grid){
		
		if(grid.getStore().getCount() > 0){
			return false;
		}{
			Ext.MessageBox.show({
                title: '',
                msg: Modules.Msgs.NoRecordsToExport,
                buttons: Ext.MessageBox.OK,
                icon:Ext.MessageBox.ERROR
           });
			
			return true;
		}
	};
	
	this.exportToXls = function(grid, searchObject,url){
		
		if(isGridEmpty(grid)){
			return;
		}
		var columnMetaArray = prepareColumnMeta(grid);
		openExport(columnMetaArray,searchObject,url,"XLS");
		
	};
	this.exportToPdf = function(grid, searchObject,url){
		if(isGridEmpty(grid)){
			return;
		}
		var columnMetaArray = prepareColumnMeta(grid);
		openExport(columnMetaArray,searchObject,url,"PDF");
	};
	this.importTemplate =  function(grid, searchObject, url) {
		var columnMetaArray = prepareColumnMeta(grid);
		openExport(columnMetaArray,searchObject,url,"XLS");
	};
	this.exportFromJsonToPdf = function(columnMetaArray,searchObject,url){
		openExport(columnMetaArray,searchObject,url,"PDF");
	};
	
	this.exportFromJsonToXls = function(columnMetaArray,searchObject,url){
		openExport(columnMetaArray,searchObject,url,"XLS");
	};
	
	this.openStaticReport = function(reportName,parameterMap){
		var form = Ext.DomHelper.append(document.body, {
		    tag:'form',
		    target:'_blank',
		    method:'POST',
		    action :'reportController/getStaticReport'
		  });

		
		// Prepare the string to make it ready to send to server
			Ext.DomHelper.append(form, {
				tag : 'input',
				type : 'hidden',
				name : 'reportName',
				value : reportName
			});
			
			if(!Ext.isEmpty(parameterMap)){
				Ext.DomHelper.append(form, {
					tag : 'input',
					type : 'hidden',
					name : 'parameterMap',
					value : (Ext.encode(parameterMap)).replace(/\"/g,"'")
				});
			}
			
		
	    form.submit();
	    setTimeout(function(){Ext.removeNode(form);}, 100);
	};
	
	
	this.openFileInWindow = function(url,values){
		
		var form = Ext.DomHelper.append(document.body, {
		    tag:'form',
		    target:'_blank',
		    method:'POST',
		    action :url
		  });

		
		for(var key in values ){
			
			
			Ext.DomHelper.append(form, {
				tag : 'input',
				type : 'hidden',
				name : key,
				value : values[key]
			});
		}

	    form.submit();
	    setTimeout(function(){Ext.removeNode(form);}, 100);
	};
};