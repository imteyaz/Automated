Ext.define('Ext.cmc.Panel',{
	extend: 'Ext.panel.Panel',
	alias: 'widget.cmcpanel',
	/***Beginning adding of new properties***/
	/**
		**Following property has been created to take care of special case - in which the panel is child of a form and is itself expected to contain form fields. In such a case, the form fields can not be put inside a form which is finally put inside the panel as a form can not contain another form. 
		**Using the property below, all the form fields inside a panel can be enclosed in a fieldset with layout as ux.center
		**Note that when using this property, layout to the panel need not be specified
		**Even if the layout is specified with this property then its ignored
		**False is the default value of this property, hence it should be mentioned in the config only if its suppose to be set to true else there is no need to mention it
	**/
	showFieldsetCmc:false,
	fieldSetMarginCmc:'4px 0px 0px 0px',//This is the margin which will be applied to fieldset enclosing the complete form
	fieldsetWidthCmc:0,//Use this to mention the widht of fieldset if required else ignore
	/***Ending adding of new properties***/
	initComponent:function(){
		
		var me					=		this;
		
		var itemsArr			=		[];
		
		if(me.showFieldsetCmc){
		
			me.layout			=		'ux.center';//Setting the layout as ux.center here
			
			if(me.fieldsetWidthCmc && me.fieldsetWidthCmc<=900){
				var containerWidthVar		=		me.fieldsetWidthCmc;
			}else if(me.width && me.width<=1000){
				var containerWidthVar		=		me.width*.9;
			}else{
				var containerWidthVar		=		900;
			}
			//Creating the container object below
			var containerObj		=		{
				xtype:'container',
				width:containerWidthVar
			};
			
			/*
				**Note that fieldset is being added as a child of container and not replacing the container as layout ux.center is not being able to have fieldset in center if there is no container present at the top. Due to this reason, first a container has been added and then its first child is made as fieldset
			*/
			var fieldset			=		{
				xtype:'fieldset',
				width:containerWidthVar-10,
				margin:me.fieldSetMarginCmc,
				defaults:{
					margin:'2px 0px'
				},
				items:me.items//Setting all items created as child of fieldset
			};
			containerObj.items		=		[fieldset];//Setting fieldset as child of container
			
			itemsArr[0]				=		containerObj;//Making the container as the first element of the panel
			
			me.items				=		itemsArr;
			
		}
		
		me.callParent();//No arguments passed as per the docs in API		
	}
	/***Ending adding of new properties***/
});