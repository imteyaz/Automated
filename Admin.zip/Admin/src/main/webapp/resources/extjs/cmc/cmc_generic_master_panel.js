Ext.define('Ext.cmc.Master.GenericPanel',{

	extend: 'Ext.panel.Panel',
	alias: 'widget.cmcgenericpanel',
	
	closable:true,
	 items: [{
	        xtype: 'datefield',
	        fieldLabel: 'Start date'
	    }, {
	        xtype: 'datefield',
	        fieldLabel: 'End date'
	    }],
	
	initComponent : function() {
		var me = this;
		me.callParent();// No arguments passed as per the docs
		// in API
		me.on('boxready', me.boxReadyWinFuncCmc);// Associating
		// a
		// function
		// with the
		// event
	},
	boxReadyWinFuncCmc : function(me, width, height, eOpts) {}
	
});