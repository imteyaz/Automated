Ext.define('Ext.cmc.Numberfield', {
   
	extend: 'Ext.form.field.Number',
	
	alias: 'widget.cmcnumberfield',
    
	/*Beginning of assigning values to already existing config options*/
    focusCls:'focusClass',
	maxHeight:25,
	labelAlign:'right',
	hideTrigger:true,
	toolTipCmc :false,//Tooltip: String
	/*Ending of assigning values to already existing config options*/
	fieldStyle: 'text-align: right;',

	initComponent:function(){
		var me	=	this;
		me.on('beforerender',me.beforeRenderFuncCmc);
		if(me.toolTipCmc){
			me.on('render', function(c) {
				Ext.QuickTips.register({
					target: c.labelEl,
					text:me.toolTipCmc,
					maxWidth : 10000
				  });
				});
		}
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	beforeRenderFuncCmc:function(){
		var me	=	this;
		if(!me.allowBlank){
			me.labelStyle	=	'color:#000000';		
		}
		
		if(me.readOnly){
			me.fieldCls	=	'readOnlyClsCmc';
		}
	},setReadOnly : function(val){
		Ext.form.field.Number.prototype.setReadOnly.call(this,val);
		if(val){
			Ext.form.field.Number.prototype.setFieldStyle.call(this,'background:#C7C9BE;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;text-align: right;');
         }else{
        	 Ext.form.field.Number.prototype.setFieldStyle.call(this,'background:#FFFFFF;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;text-align: right;');
         }
	} 
});

