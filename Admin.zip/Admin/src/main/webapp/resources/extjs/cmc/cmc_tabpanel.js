Ext.define('Ext.cmc.TabPanel', {
   
	extend: 'Ext.tab.Panel',
	
	alias: 'widget.cmctabpanel'
});
