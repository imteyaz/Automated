Ext.define('Writer.Form', {
    extend: 'Ext.form.Panel',
    alias: 'widget.writerform',
    requires: ['Ext.form.field.Text'],

    initComponent: function(){
        this.addEvents('create');
        Ext.apply(this, {
            activeRecord: null,
            iconCls: 'icon-user',
            //frame: true,
            //title: 'User -- All fields are required',
            defaultType: 'textfield',
            bodyPadding: 5,
            fieldDefaults: {
                anchor: '100%',
                labelAlign: 'right',
				labelWidth:50
            },
             dockedItems: [{
                xtype: 'toolbar',
                dock: 'bottom',
                ui: 'footer',
                items: [ {
					xtype:'tbspacer',
					width:100
				},{
                    iconCls: 'icon-save',
                    itemId: 'save',
                    text: 'Save',
                    disabled: true,
                    scope: this,
                    handler: this.onSave
                }, {
                    iconCls: 'icon-user-add',
					itemId: 'add',
                    text: 'Add',
                    scope: this,
                    handler: this.onCreate
                }, {
                    iconCls: 'icon-reset',
                    text: 'Clear',
                    scope: this,
                    handler: this.onReset
                }]
            }] 
        });
        this.callParent();
    },
    setActiveRecord: function(record){
        this.activeRecord = record;
        if (record) {
            this.down('#save').enable();
            this.down('#add').disable();
            this.getForm().loadRecord(record);
        } else {
            this.down('#add').enable();
            this.down('#save').disable();
            this.getForm().reset();
        }
    },

    onSave: function(){
        var active = this.activeRecord,
            form = this.getForm();
			var win = this.ownerCt;
			
		var getFrm = this;	
		var body = Ext.getBody();
		
        if (!active) {
            return;
        }
		
		body.mask(Modules.Msgs.saving);
		form.updateRecord(active);
		body.unmask();
		getFrm.onReset();
    /*    if (form.isValid()) {
			form.submit({
				method: 'POST',
				url:win.getsaveUrl,
				params:{
					trnsType:"U"
				},
				success: function (form, action) {
					
					Ext.MessageBox.show({
						title: Modules.Msgs.SuccessInfo,
						msg: Modules.Msgs.SuccessInfoMsg,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO
					});	
					body.unmask();
					getFrm.onReset();
				},
				failure: function (form, action) {
					Modules.GlobalFuncs.displayFormErrors({
					form:form,
					responseText:action.response.responseText
					});
					body.unmask();
                 }
			});
        } */
    },

    onCreate: function(){
        var form = this.getForm();
		var body = Ext.getBody();
		var getFrm = this;
        if (form.isValid()) {
            this.fireEvent('create', this, form.getValues());
        }

    },

    onReset: function(){
        this.setActiveRecord(null);
        this.getForm().reset();
		
		var itms = this.getForm().getFields().items;
		for(var i=0;i<itms.length;i++){/******For enabling the disabled key fields*********/
			itms[i].setDisabled(false);
		} 
    }
});