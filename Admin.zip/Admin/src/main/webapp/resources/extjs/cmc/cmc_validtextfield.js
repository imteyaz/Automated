/*
	*Following file contains more than one version of the extended component of valid textfield
*/
Ext.define('Ext.cmc.ValidTextfield', {
   
	extend: 'Ext.cmc.Textfield',//Extending the TextField
	
	alias: 'widget.cmcvalidtextfield',//Defining the xtype
	
	/*Beginning the adding of new config properties below*/
	oldFieldValCmc:'',//This field is used to hold the old values of the field and is used mainly in validations like of container number
	fieldValidCmc:true,
	validateUrlCmc:'',
	validateParamsCmc:{},
	validateAjaxMethodCmc:'GET',
	valdidateSuccessFuncCmc:function(serverRespOjb){
		return true;
	},
	valdidateFailFuncCmc:function(){
		return true;
	},
	/*Ending the adding of new config properties below*/
	
	/*Beginning of assigning values to already existing config options*/
	validateOnBlur:true,
	validateOnChange:false,
	validator:function(){
		var me		=		this;
		if(me.allowBlank && (!me.getRawValue() || me.getRawValue()=='')){
			me.fieldValidCmc	=		true;
			me.invalidText		=		'';
			me.clearInvalid();
			me.valdidateFailFuncCmc();
			return true;
		}else if(me.oldFieldValCmc!=me.getValue()){
			me.validateParamsCmc[me.name]		=		me.getRawValue();
			Ext.Ajax.request({
				url: me.validateUrlCmc,
				params: me.validateParamsCmc,
				success: function(response){
					respObj					=		Ext.JSON.decode(response.responseText);
					me.oldFieldValCmc		=		me.getValue();
					if(respObj.success){
						me.fieldValidCmc	=		true;
						me.invalidText		=		'';
						me.valdidateSuccessFuncCmc(respObj);
						me.clearInvalid();
						return true;
					}else{
						me.fieldValidCmc		=		false;
						if(respObj.errors){
							me.invalidText		=		respObj.errors;
						}						
						me.valdidateFailFuncCmc();
						me.markInvalid(me.invalidText);
						return me.invalidText;
					}
				},
				failure:function(response){
					me.fieldValidCmc		=		false;
					if(Modules.Msgs && Modules.Msgs.serverError){
						me.invalidText			=		Modules.Msgs.serverError;
					}else{
						me.invalidText			=		'Server error. Please try later';
					}
					me.valdidateFailFuncCmc();
					me.markInvalid(me.invalidText);
					return me.invalidText;
				}
			});
		}else if(!me.fieldValidCmc){
			me.markInvalid(me.invalidText);
			return me.invalidText;
		}else{
			return true;
		}
	},
	/*Ending of assigning values to already existing config options*/
	
	initComponent:function(){
		var me	=	this;
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	/*Following function is used to set the value to oldFieldValCmc which is sometimes used in validations*/
	setValue:function(value){
		var me			=	this;
		me.callParent(arguments);
		me.oldFieldValCmc	=	me.getValue();//Setting the value to oldFieldValCmc once the setValue of parent has been called	
		me.isFieldValid		=	true,
		me.clearInvalid();
		me.invalidText		=	'';
	}
});