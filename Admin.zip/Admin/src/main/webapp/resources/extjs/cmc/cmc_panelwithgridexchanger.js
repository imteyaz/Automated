Ext.define('Ext.cmc.PanelWithGridExchanger', {
					
	extend: 'Ext.panel.Panel',
	alias: 'widget.cmcpanelwithgridexchanger',
	
	height:300,
	width:600,
	layout:'border',
	
	modelForGridsCmc:'',//this will hold the model name which would be used for both the grids. It is not necessary to set it here, as its gets updated when rightGridConfig function is called
	gridColumnsFuncCmc:'',//This will hold the function from which the columns array for the grid can be retrieved. It is not necessary to set it here as it gets updated when the config of right grid is called
	
	leftGridWidthCmc:350,//This can be used to specify the width to be given to left grid
	leftGridTitleCmc:'Assigned Values',//This can be used to put up the title at the left grid
	btnCntrWidthCmc:100,//This can be used to specify the width to be given to center container of buttons
	btnWidthCmc:100,//This can be used to specify the widht to be given to each button
	btnTopMarginCmc:'20px 0px 5px 0px',//This can be used to specify the margin to be given to top button from the top in the button container
	matchKeysCmc:'',//This should be an array of keys which need to be matched while adding/removing records from left-right grid stores. This is required in order to disallow duplication of records in both left and right grid
	addDefaultColumnCmc:false,// Set it to true if one extra column for 'default' flag is needed on left grid
	modelKeyFields :undefined,
	
	initComponent:function(){
		var me				=		this;
		me.items			=		me.__getPanelItemsFuncCmc();
		me.on('afterrender', me.afterRenderFuncCmc);
		me.callParent();
	},
	
	//Following function will call other functions and will finally return the array of panel items
	__getPanelItemsFuncCmc:function(){
		var me				=		this;
		var itemsArr		=		[];
		itemsArr[0]			=		me.__getCenterBtnCntrFuncCmc();
		itemsArr[1]			=		me.__getRightGridFuncCmc();
		itemsArr[2]			=		me.__getLeftGridFuncCmc();//Left grid uses the model for right grid and hence should be called only after the right grid
		return itemsArr;
	},
	
	//Following function should be overridden by instance and should return the config of the grid at right side
	setRightGridFuncCmc:function(){
		return {};
	},
	
	//Following function is used to process the config of right grid and return the final config
	__getRightGridFuncCmc:function(){
		var me						=		this;
		var rightGridConfig			=		me.setRightGridFuncCmc();//Calling the method to get the right grid config
		
		me.modelForGridsCmc			=		rightGridConfig.storeObjCmc.model;
		me.gridColumnsFuncCmc		=		rightGridConfig.setGridColumnsFuncCmc;
		
		var rightGridGenericObj		=		{//Generic config for the grid present in right side
			xtype:'cmcgrid',
			region:'east',
			itemId:'rightGridPanelWithGridExchangerItemId',
			showSelModelCmc:true,
			statefulCmc : false,
			features:[me.setGridFiltersFuncCmc()]
		};
		Ext.apply(rightGridConfig, rightGridGenericObj);
		
		if(!rightGridConfig.width ){
			rightGridConfig.width	=		me.leftGridWidthCmc;
		}
		if(rightGridConfig.queryTypeCmc && rightGridConfig.queryTypeCmc=='local'){
			rightGridConfig.showPagingBarCmc		=		false;
		}
		if(!rightGridConfig.title){
			rightGridConfig.title					=		'List of values';
		}
		return rightGridConfig;
	},//EOF __getRightGridFuncCmc
	
	__getLeftGridFuncCmc:function(){
		var me						=		this;
		
		var leftGridStoreObj		=		{
			model:me.modelForGridsCmc,
			data:[],
			queryTypeCmc:'local'
		};
		
		var leftGridConfigObj		=		{
			xtype:'cmcgrid',
			region:'west',
			itemId:'leftGridPanelWithGridExchangerItemId',
			features:[me.setGridFiltersFuncCmc()],
			showSelModelCmc:true,
			showPagingBarCmc:false,
			statefulCmc : false,
			plugins: [Ext.create('Ext.grid.plugin.CellEditing', {
		        clicksToEdit: 1,
		        listeners:{
		        	edit2:function(cellEditor,e){
		        		if(e.value===true){
		        			e.grid.getStore().each(function(rec){
		        				rec.set('defaultFlag',false);
		        			});
		        		}
		        	}
		        }
		    })],
			setGridColumnsFuncCmc: function(){
			var gridColumns = me.gridColumnsFuncCmc();
			if(me.addDefaultColumnCmc && Ext.isArray(gridColumns)){
				
				gridColumns.push({
		            xtype: 'checkcolumn',
		            stopSelection: false,
		            editor: {
		            	xtype:'checkbox',
//		            	inputValue:'Y',
		            	listeners:{
		            	change:function(checkbox,newValue, oldValue){
		            		var grid = this.up('cmcgrid');
		            		var selectedRec = grid.getSelectionModel().getLastSelected(); 
		            		if(newValue){
		            			
		            			grid.getStore().each(function(rec){
		            				if(selectedRec && selectedRec.id==rec.id){
		            					return;
		            				}
		            				rec.set('defaultFlag',undefined);
		            			});
		            		}
		            	}
		            	}
		            },
		            header: 'Default?',
		            dataIndex: 'defaultFlag',
		            width: 55
		        });
				
			}
			return gridColumns;
			},
			storeObjCmc:leftGridStoreObj,
			title:me.leftGridTitleCmc
		};	
		
		if(me.leftGridWidthCmc){
			leftGridConfigObj.width		=		me.leftGridWidthCmc;
		}else{
			leftGridConfigObj.flex		=		1;
		}		
		return leftGridConfigObj;
	},//EOF __getRightGridFuncCmc
	
	//Following function is used to set the filters for grid columns. It may not be overridden by the instance
	setGridFiltersFuncCmc:function(){
		var me						=		this;
		var filtersObj				=		{//Filter to be used with the right grid
			ftype: 'filters',
			encode: false,
			local: true
		};
		return filtersObj;
	},//EOF __getRightGridFuncCmc
	
	//Following function can be used to implement the logic of instance before adding records to left grid
	setAddNAddAllBtnHandlerFuncCmc:'',
	
	__getAddnAddAllBtnFuncCmc:function(argObj){
		var me						=		this;
		var type					=		argObj.type?argObj.type:'add';//Value can be add/addAll
		var btnConfig				=		{};
		switch(type){
			case 'add':
				btnConfig.text		=		'<< ADD';
				btnConfig.margin	=		me.btnTopMarginCmc;
				btnConfig.handler	=		function(){	
					var res			=		me.__getAddnAddAllBtnHandlerFuncCmc({type:'ADD'});
					if(!res){
						return res;
					}
					return true;
				}//End of handler function
			break;
			
			case 'addAll':
				btnConfig.text		=		'<<<< ADD ALL';
				btnConfig.handler	=		function(){	
					var res			=		me.__getAddnAddAllBtnHandlerFuncCmc({type:'ADDALL'});
					if(!res){
						return res;
					}
					return true;
				}//End of handler function
			break;
		}//End of switch
		return btnConfig;
	},
	
	//Following function can be used to implement the logic of instance before removing records from left grid
	setRemoveNRemoveAllBtnHandlerFuncCmc:'',
	
	__getRemoveNRemoveAllBtnFuncCmc:function(argObj){
		var me						=		this;
		var type					=		argObj.type?argObj.type:'add';//Value can be add/addAll
		var btnConfig				=		{};
		switch(type){
			case 'remove':
				btnConfig.text		=		'REMOVE >>';
				btnConfig.handler	=		function(){		
					var res			=		me.__getRmvnRmvAllBtnHandlerFuncCmc({type:'REMOVE'});
					if(!res){
						return res;
					}
					return true;
				}//End of handler function
			break;
			
			case 'removeAll':
				btnConfig.text		=		'REMOVE ALL >>>>';
				btnConfig.handler	=		function(){		
					var res			=		me.__getRmvnRmvAllBtnHandlerFuncCmc({type:'REMOVEALL'});
					if(!res){
						return res;
					}
					return true;					
				}//End of handler function
			break;
		}//End of switch
		return btnConfig;
	},
	
	__getClearFilterBtnFuncCmc:function(){
		var me				=		this;
		var btnConfig		=		{};
		btnConfig.text		=		'CLEAR FILTER';
		btnConfig.handler	=		function(){		
			var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
			var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
			leftGrid.filters.clearFilters();
			rightGrid.filters.clearFilters();
			return true;
		}//End of handler function
		return btnConfig;
	},
	
	__getCenterBtnCntrFuncCmc:function(){
		var me				=		this;
		var container		=		{
			xtype:'container',
			layout:'ux.center',
			width:me.btnCntrWidthCmc,
			region:'center',
			margin:'0px 0px 0px 25px',//TODO: get it form css
			items:[
				{
					xtype:'container',
					width:me.btnCntrWidthCmc,
					layout:'vbox',
					
					defaults:{
						xtype:'cmcbutton',
						width:me.btnWidthCmc,
						margin:'5px 0px'
					},
					items:[
						me.__getAddnAddAllBtnFuncCmc({type:'add'}),
						me.__getAddnAddAllBtnFuncCmc({type:'addAll'}),
						me.__getRemoveNRemoveAllBtnFuncCmc({type:'remove'}),
						me.__getRemoveNRemoveAllBtnFuncCmc({type:'removeAll'})//,
						//me.__getClearFilterBtnFuncCmc()
					]
				}
			]
		};
		return container;
	},
	//Following function is used to retrieve the store of grids by passing appropriate argument - {type:'right'}
	getGridsStoreFuncCmc:function(argObj){
		var me		=		this;
		var type	=		argObj.type?argObj.type:'right';
		switch(type){
			case 'right':
				var store		=		me.query('#rightGridPanelWithGridExchangerItemId')[0].getStore();
			break;
			
			case 'left':
				var store		=		me.query('#leftGridPanelWithGridExchangerItemId')[0].getStore();
			break;
		}//End of switch
		return store;
	},//EOF
	
	//Following will be associated with the afterrender of the panel
	afterRenderFuncCmc:function(){
	
		//Commenting the duplication check below
		/* var me			=		this;
		var leftStore	=		me.getGridsStoreFuncCmc({type:'left'});
		var rightStore	=		me.getGridsStoreFuncCmc({type:'right'});
		leftStore.on('load',function(){
			var leftRecs	=		leftStore.getRange();
			for(var i=0; i<leftRecs.length; i++){
				var matchedRec		=		me.__findMatchRecInStore({
					recToCheck:leftRecs[i],
					storeWhereMatched:rightStore
				});
				if(matchedRec && Ext.isObject(matchedRec)){//If the selected record already exists in left grid then removing it in the right grid too
					rightStore.remove(matchedRec);
					continue;
				}
			}
		});
		rightStore.on('load',function(){
			var leftRecs	=		leftStore.getRange();
			for(var i=0; i<leftRecs.length; i++){
				var matchedRec		=		me.__findMatchRecInStore({
					recToCheck:leftRecs[i],
					storeWhereMatched:rightStore
				});
				if(matchedRec && Ext.isObject(matchedRec)){//If the selected record already exists in left grid then removing it in the right grid too
					rightStore.remove(matchedRec);
					continue;
				}
			}
		}); */
	},//EOF
	
	//Following function is used to find the matching record in other store
	__findMatchRecInStore:function(argObj){
		
		var me						=		this;
		var finalObj				=		'';//This will hold the final object
		if(!me.matchKeysCmc || !Ext.isArray(me.matchKeysCmc) || !me.matchKeysCmc.length){
			return finalObj;
		}
		var keysArr					=		me.matchKeysCmc;
		var recToCheck				=		argObj.recToCheck;//Record which needs to be checked
		var storeWhereMatched		=		argObj.storeWhereMatched;//Store where search is to be done
		var matchIndex				=		storeWhereMatched.findBy(function(record){
			var count		=		keysArr.length;
			for(var j=0; j<keysArr.length; j++){//Looping through all keys which should have combination value
				if(record.get(keysArr[j])==recToCheck.get(keysArr[j])){
					count--;//Reducing the value of count if a match is found
				}							
			}							
			if(count==0){//If all the keys matched with the record then count will be 0
				return true;
			}
		});
		if(matchIndex!=-1){
			finalObj		=		storeWhereMatched.getAt(matchIndex);
		}
		return finalObj;
	},//EOF
	
	__getAddnAddAllBtnHandlerFuncCmc:function(argObj){
		var me				=		this;
		var btnType			=		argObj.type?argObj.type:'ADD';
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore	=		rightGrid.getStore();
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		if(btnType=='ADDALL'){
			var rightSelRecs	=		rightGridStore.getRange();
			if(!rightSelRecs || !rightSelRecs.length){
				Ext.MessageBox.show({
					title: 'No record present',
					msg: 'No record present in list of value to be moved to assigned',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}	
		}else{
			var rightSelRecs	=		rightGrid.getSelectionModel().getSelection();
			if(!rightSelRecs || !rightSelRecs.length){
				Ext.MessageBox.show({
					title: 'No record selected',
					msg: 'Please select at least one record to add to assigned values',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}	
		}					
		if(me.setAddNAddAllBtnHandlerFuncCmc && typeof me.setAddNAddAllBtnHandlerFuncCmc=='function'){
			var res		=		me.setAddNAddAllBtnHandlerFuncCmc();
			if(!res && typeof res=='boolean'){
				return res;
			}
		}
		
	if(rightGrid.showPagingBarCmc){	
		if(leftGridStore.getCount()>0){
		var modelKeySet=me.modelKeyFields;
		Ext.each(rightSelRecs,function(item){
			var index =leftGridStore.findBy( function(record, id){
					for(var i=0;i<modelKeySet.length;i++){
								if(record.get(modelKeySet[i]) != item.get(modelKeySet[i])){
									return false;
								}
							}
					  return true;
					    }
					);
				
				if(index == -1){
					leftGridStore.insert(0, item);
				}
		});
		
		}else{
			leftGridStore.insert(0, rightSelRecs);
		}
	}else{
		leftGridStore.insert(0, rightSelRecs);
	}
		if(!rightGrid.showPagingBarCmc){
			rightGridStore.remove(rightSelRecs);
		}
		
		
		/* for(var i=0; i<rightSelRecs.length; i++){
			var selRec			=		rightSelRecs[i];
			
			//Commenting the duplication check below
			// var matchedRec		=		me.__findMatchRecInStore({
				// recToCheck:selRec,
				// storeWhereMatched:leftGridStore
			// });
			// if(matchedRec && Ext.isObject(matchedRec)){//If the selected record already exists in left grid then removing it in the right grid too
				// rightGridStore.remove(selRec);
				// continue;
			// }
			
			leftGridStore.insert(0, selRec.getData());
			rightGridStore.remove(selRec);
		}//End of for loop */
			
		//leftGrid.getView().refresh();
		//rightGrid.getView().refresh();
		
		return true;
	},//EOF
	
	__getRmvnRmvAllBtnHandlerFuncCmc:function(argObj){
		var me				=		this;
		var btnType			=		argObj.type?argObj.type:'REMOVE';
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore	=		rightGrid.getStore();
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		if(btnType=='REMOVEALL'){
			var leftSelRecs		=		leftGridStore.getRange();
			if(!leftSelRecs || !leftSelRecs.length){
				Ext.MessageBox.show({
					title: 'No record present',
					msg: 'No records present in assigned values list to be moved',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}	
		}else{
			var leftSelRecs		=		leftGrid.getSelectionModel().getSelection();
			if(!leftSelRecs || !leftSelRecs.length){
				Ext.MessageBox.show({
					title: 'No record selected',
					msg: 'Please select at least one record to remove from assigned values',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}
		}						
		if(me.setRemoveNRemoveAllBtnHandlerFuncCmc && typeof me.setRemoveNRemoveAllBtnHandlerFuncCmc=='function'){
			var res		=		me.setRemoveNRemoveAllBtnHandlerFuncCmc();
			if(!res && typeof res=='boolean'){
				return res;
			}
		}		
		
		
		if(!rightGrid.showPagingBarCmc){
		rightGridStore.insert(0, leftSelRecs);
		}
		leftGridStore.remove(leftSelRecs);
		
		/* for(var i=0; i<leftSelRecs.length; i++){
			var selRec				=		leftSelRecs[i];
			
			//Commenting the duplication check below
			// var matchedRec			=		me.__findMatchRecInStore({
				// recToCheck:selRec,
				// storeWhereMatched:rightGridStore
			// });
			// if(matchedRec && Ext.isObject(matchedRec)){//If the selected record already exists in left grid then removing it in the right grid too
				// leftGridStore.remove(selRec);
				// continue;
			// }
			
			leftGridStore.remove(selRec);
			rightGridStore.insert(0, selRec.getData());
		}//End of for loop */	
		
		//leftGrid.getView().refresh();
		//rightGrid.getView().refresh();	
		
		return true;
	},
	/**
	 * 
	 * @param recordToSelect -> Array of the records to be selected by default
	 */
	autoSelectValuesFnCmc : function(fieldName,recordToSelect){
		var me = this;
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore  =		rightGrid.getStore();
		rightGrid.getSelectionModel().deselectAll();
		
		if(rightGridStore.getCount() == recordToSelect.length) {
			rightGrid.getSelectionModel().selectAll();
		} else {
			Ext.each(recordToSelect,function(item){
				
				var index = rightGridStore.findExact(fieldName,item);
				
				if(index > -1){
					rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
					
				}
			});
			
		}
		
		var rightSelRecs	=		rightGrid.getSelectionModel().getSelection();
		leftGridStore.insert(0, rightSelRecs);
		rightGridStore.remove(rightSelRecs);
	},
	autoSelectByIgnoringDuplicateValuesFnCmc : function(modelArray,isFirstTime){
		var me = this;
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore  =		rightGrid.getStore();
		rightGrid.getSelectionModel().deselectAll();
		
		if(rightGridStore.getCount() == modelArray.length) {
			rightGrid.getSelectionModel().selectAll();
		} else {
			//var totalRecords=store.getRange(0,store.getCount()-1);
			if(isFirstTime){
				
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.companyCode &&
						        	record.get('partyCode') === item.partyCode ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
			}else{
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.get('companyCode') &&
						        	record.get('partyCode') === item.get('partyCode') ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
				
			}
		}
		
		var rightSelRecs	=		rightGrid.getSelectionModel().getSelection();
		leftGridStore.insert(0, rightSelRecs);
		rightGridStore.remove(rightSelRecs);
	},
	autoSelectByIgnoringDuplicateValuesForPopFnCmc : function(modelArray,isFirstTime){
		var me = this;
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore  =		rightGrid.getStore();
		rightGrid.getSelectionModel().deselectAll();
		
		if(rightGridStore.getCount() == modelArray.length) {
			rightGrid.getSelectionModel().selectAll();
		} else {
			//var totalRecords=store.getRange(0,store.getCount()-1);
			if(isFirstTime){
				
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.companyCode &&
						        	record.get('popCode') === item.popCode ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
			}else{
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.get('companyCode') &&
						        	record.get('popCode') === item.get('popCode') ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
				
			}
		}
		
		var rightSelRecs	=		rightGrid.getSelectionModel().getSelection();
		//leftGridStore.insert(0, rightSelRecs);
		rightGridStore.remove(rightSelRecs);
	},
	autoSelectByIgnoringDuplicateValuesForPortFnCmc : function(modelArray,isFirstTime){
		var me = this;
		var leftGrid		=		me.query('#leftGridPanelWithGridExchangerItemId')[0];
		var leftGridStore	=		leftGrid.getStore();
		var rightGrid		=		me.query('#rightGridPanelWithGridExchangerItemId')[0];
		var rightGridStore  =		rightGrid.getStore();
		rightGrid.getSelectionModel().deselectAll();
		
		if(rightGridStore.getCount() == modelArray.length) {
			rightGrid.getSelectionModel().selectAll();
		} else {
			//var totalRecords=store.getRange(0,store.getCount()-1);
			if(isFirstTime){
				
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.companyCode &&
						        	record.get('portCode') === item.portCode ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
			}else{
				Ext.each(modelArray,function(item){
					var index =rightGridStore.findBy( function(record, id){
						        if(record.get('companyCode') === item.get('companyCode') &&
						        	record.get('portCode') === item.get('portCode') ){
						              return true;  // a record with this data exists
						        }
						        return false;  // there is no record in the store with this data
						    }
						);
					
					if(index > -1){
						rightGrid.getSelectionModel().select(rightGridStore.getAt(index),true);
						
					}
				});
				
			}
		}
		
		var rightSelRecs	=		rightGrid.getSelectionModel().getSelection();
		//leftGridStore.insert(0, rightSelRecs);
		rightGridStore.remove(rightSelRecs);
	}
	
	
});