
Ext.define('Ext.cmc.Grid',{
	
	extend: 'Ext.grid.Panel',
	alias: 'widget.cmcgrid',
	
	/***Beginning the config properties which already exist in the component**/
	columnLines: true,
	autoScroll:true,
	/***Ending the config properties which already exist in the component**/
	
	/***Beginning adding of new properties***/
	showCountColumnCmc:false,
	showGridEditIconCmc:false,
	showSelModelCmc:false,
	selModelModeCmc:'SIMPLE',
	showPagingBarCmc:false,
	showTotalSelectedCmc:false,
	showTotalCountCmc:false,
	showConfirmPageChange:true,
	//showRowNumbererCmc:true,
	showLeftExtraTbarCmc : false, // Newly added
	contextMenuCmc:{},//Mention here the context menu created
	storeObjCmc:{},//This will hold the details of the store object which will be created by the global function of creating store
	clearBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getClearAction
	retrieveBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getRetrieveAction
	addBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getAddAction
	deleteBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getDeleteAction
	markDelBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getMarkDeleteAction
	unmarkDelBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getUnMarkDeleteAction
	saveBtnObjCmc:{},//This should be an object as expected by function Modules.GlobalFuncs.getSaveAction
	associatedGrids:[],//if ids for the grid is provided it will populate it on cell click, object should have {gridItemId:<>,associationName:<>}
	loadChildGridCellIndex:1,// column index of view button
	loadChildGridCellId: undefined,
	popUpCellIndexCmc: 1,
	popUpActionColumnId : 'id',
	popUpWinFuncCmc: '', //this should map to a function which returns the config of a window
	popUpWinIdCmc: '', //this should be the if of pop-up window
	maxLimitRecordsCmc:Modules.GlobalVars.maxLimitRecords,
	statefulCmc:true,// Enables state management for grid. Adds buttons related to state save and reset. 
	addPagingComboCmc:true,  // useful to add or delete Records per page combo from paging bar
	defaultPageSizeCmc:undefined,//Default page size in paging bar 
	noTotalCountCmc:false,
	delayTotalCountStoreCmc:false,//This will be used to send a separate ajax for getting the total count
	getTotalCountStoreUrlCmc:'',//This will hold the URL which will provide the total count value
	totalCountStoreCmc:'',//This will hold the value of total records in the store of grid
	remoteCachingCmc:false,//make it true if server side caching is supported 
	slectionAwareCmc:false,// Grid should remember last selected records
	maxPagesizeCmc:undefined,
	selectAllChecked:false,//Select All toggle button is checked or not
	reloadTotalCount:true,// set it to true, to forcefully go for totalcount again
	preserveExcludeArrayCmc : false, // flag to be used internally by grid to prevent select listener will clear the previous deselections 
	rememberSelectionCmc:false,// Whether grid should remember the selections even if 'Logical Select All' is not enabled
	selectedRecordsArrayCmc : [],// To be used by grid for rememberSelectionCmc
	preserveSelectedRecordsCmc:true,// flag to be used internally by grid to prevent select listener will clear the previous selections 
	/***Ending adding of new properties***/
	
	initComponent:function(){
		
		var me					=		this;
		
		if(Ext.isEmpty(me.maxPagesizeCmc) ){
			me.maxPagesizeCmc = Modules.GlobalVars.maxPagesize;//Maximum value for pagesize that user can give;
		}
		
		me.selectedRecordsArrayCmc = []; // reset selectedRecordsArrayCmc as it should be new for each grid instanse 
		
		/***Beginning for columns***/
		me.columns				=		[];
		//var editWindowIndex=0;
		if(me.showCountColumnCmc){
			//editWindowIndex=1;
			me.columns[0]		=		Ext.create('Ext.grid.RowNumberer',{dataIndex:'rowNumberer',width:40,locked: true});
			me.columns			=		me.columns.concat(me.setGridColumnsFuncCmc());
		}else{
			me.columns			=		me.setGridColumnsFuncCmc();
			
		}
			
		/***Ending for columns***/				
		
		//Setting store below
		me.storeObjCmc.storeForComp	=		'grid';
		me.store					=		me.store || Modules.GlobalFuncs.getStore(me.storeObjCmc);
		me.store.on('clear', function( store, record, index){
			if(store.getCount() === 0){
				this.resetToolbar();
			}
		},me);
		
		//Make all action columns are not movable
		Ext.each(me.columns,function(item){
			if(item.xtype === 'actioncolumn' && Ext.isEmpty(item.draggable)){
				item.draggable = false;
				item.resizable = false;
				item.fixed = true;
			}		 
		});
		/***Beginning setting of selection model***/
		if(me.showSelModelCmc){
			me.selModel			=		Ext.create('Ext.selection.CheckboxModel', {
				mode:me.selModelModeCmc,
			    renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
			        var baseCSSPrefix = Ext.baseCSSPrefix;
			        metaData.tdCls = baseCSSPrefix + 'grid-cell-special ' + baseCSSPrefix + 'grid-cell-row-checker';
			        if(record.get('indicator')=='O'){// Hide the selection checkbox
			        	return '<div>&#160;</div>';
			        }
			        return '<div class="' + baseCSSPrefix + 'grid-row-checker">&#160;</div>';
			    }
			});
		}
		/***Ending setting of selection model***/
		
		if(me.showPagingBarCmc){
			me.bbar		=		me.setPagingToolbarFuncCmc();
			
			me.store.on('load',function(store, records, success, eOpts) {
				if(success==true){
					if(records.length > 0){
						me.down('#centerGridPagingToolBarItemId').down('#refresh').enable(true);
					}else{
						me.down('#centerGridPagingToolBarItemId').down('#refresh').disable();
					}
				}
			});
					
		} 
		
		if(me.showTotalSelectedCmc && me.showSelModelCmc){
			me.setTotalSelectedFuncCmc();
		} 
		
		if(me.showTotalCountCmc && !me.showPagingBarCmc){
			me.setTotalCountFuncCmc();
		}
		
		me.setTbarFuncCmc();//Calling this function for setting TBar
		
		if(me.viewConfig && Ext.isObject(me.viewConfig)){
			me.viewConfig.enableTextSelection		=		true;
		}else{
			me.viewConfig							=		{};
			me.viewConfig.enableTextSelection		=		true;
		}
		
		me.originalColumns = me.columns;
		if(me.statefulCmc && (me.gridId || me.id )){
	        
			me.configureStateButtons();
			//me.applyStateCmc();
		}
		
		if(me.delayTotalCountStoreCmc){
				me.store.on('load', function(store, record, index){
					var pagingBar					=	me.query('#centerGridPagingToolBarItemId')[0];
//					if(typeof me.totalCountStoreCmc=='number'){
//						pagingBar.afterPageText = 'of {0}';
//					}else{
//						pagingBar.afterPageText = 'of ?';
//					}
//					pagingBar.updateInfo();
					
					if(false && record && record.length >= store.pageSize){ // disabled this feature for now, all the sever side controllers does not support that
						//Fire one more request to load and cache the next page data up-front.
						//NOTE: Server side code must have the logic implemented correctly
						
						
						var params = Ext.apply({
							page:store.currentPage +1,
							start:store.currentPage*store.proxy.extraParams.limit
								
						},store.proxy.extraParams);
						
					Ext.Ajax.request({
						url:store.proxy.url,
						params:params,
						method : 'GET',
						success:function(response){
							// Do nothing, this call was just to invoke a service side method
						},
						failure:function(){
						}
					});
					}
				me.__updateDelayTotalCountStoreCmc();
			});
		}
		if(me.slectionAwareCmc){
			me.maxPagesizeCmc = 300;
			me.excludeListArray = [];
			if(me.tbar){
				Ext.Array.insert(me.tbar, 0, [{
					xtype : 'button',
					enableToggle:true,
					//boxLabel : 'Select All records',
					text:'Select All',
					inputValue : true,
					iconCls:'deselectAll',
					itemId:'selectAllButton',
					toggleHandler:function(button,state ){
						me.excludeArrayCmc = []; me.selectedRecordsArrayCmc = []; // clear the previous chache  
						var totalSelectedTextField = me.down('#totalSelectedGridTextFieldItemId');
						if(state == true){
							
							me.getSelectionModel().selectAll();
							me.excludeArrayCmc = [];
							// check whether all records are selected or not
							// there could be code to deselect records in grid instance
							if(me.getSelectionModel().getSelection().length == me.getStore().getCount()){
								// Switch back to old status
								button.setText("Deselect All");
								button.setIconCls('selectAll');
								me.showConfirmPageChange = false;
								me.selectAllChecked = true;
								
								//
							
								if(totalSelectedTextField){
									if(me.totalCountStoreCmc >= Modules.GlobalVars.maxLimitRecords){
										totalSelectedTextField.setValue(Modules.GlobalVars.maxLimitRecords+"+");
									}else{
										totalSelectedTextField.setValue(me.totalCountStoreCmc || me.store.totalCount);
									}
								}
							}else{
								
								button.toggle(false,true);
							}
							
						}else{
							button.setText("Select All");
							button.setIconCls("deselectAll");
							me.showConfirmPageChange = true;
							me.getSelectionModel().deselectAll();
							me.excludeArrayCmc = [];
							totalSelectedTextField.setValue(0);
							me.selectAllChecked = false;
						}
					}
				},'-']);
			}
			

			// Add the record to excludeListArray on deselection  if selectAllButton is selected
			me.on('deselect',function( cellModel, record, rowIndex, eOpts ){
					
						var selFlg = me.selectAllChecked;	
						if(selFlg){
							var isRecordExists = me.isRecordExistsInExcludeList(record);
						if(!isRecordExists){
							var excludeObj = {};
							for( var key in me.keysArrayCmc){
								excludeObj[me.keysArrayCmc[key]] = record.get(me.keysArrayCmc[key]);
							}
//							for(var n=0; n < me.keysArrayCmc.length; n++){
//								excludeObj[me.keysArrayCmc[n]] = record.get(me.keysArrayCmc[n]);
//							}
							me.excludeArrayCmc.push(excludeObj);
						}						
						}else if(me.rememberSelectionCmc){
							var keyObj = me.isRecordExistsInArray(record,me.selectedRecordsArrayCmc);
							if(keyObj){
								Ext.Array.splice( me.selectedRecordsArrayCmc, keyObj.index, 1 );
							}
						}					
					});
			
			 me.on('select',function( cellModel, record, rowIndex, eOpts ){
				
					var selFlg = me.selectAllChecked;
					if(selFlg && !me.preserveExcludeArrayCmc){
						var keyObj = me.isRecordExistsInExcludeList(record);
						if(keyObj){
							Ext.Array.splice( me.excludeArrayCmc, keyObj.index, 1 );
						}
						
					}else if(me.rememberSelectionCmc){
						
					
						if(!me.isRecordExistsInArray(record,me.selectedRecordsArrayCmc)){
							var selctedObj = {};
							for( var key in me.keysArrayCmc){
								selctedObj[me.keysArrayCmc[key]] = record.get(me.keysArrayCmc[key]);
							}
							me.selectedRecordsArrayCmc.push(selctedObj);

						}
						
					}
				});
			 
			me.store.on('load', function(store, record, index){
			
				
				if(me.lastLoadParamsCmc){
					
				var selectAllCheck = me.getDockedItems('toolbar[dock="top"]')[0].down('#selectAllButton');
				var selFlg = me.selectAllChecked;	
				 if( Modules.GlobalFuncs.isObjectsEquals(me.lastLoadParamsCmc,me.store.proxy.extraParams)){
				// this load is a subsequent load for same search criteria 
						var keysArray = me.keysArrayCmc;
						var selModel=me.getSelectionModel();
						if(selFlg !=null && selFlg==true){	
								
								me.preserveExcludeArrayCmc = true; // otherwise select listener will clear the previous deselections 
								selModel.selectAll();
								me.preserveExcludeArrayCmc = false;
//								var totalSelectedTextField = me.query('#totalSelectedGridTextFieldItemId')[0];
//								if(totalSelectedTextField){
//									if(me.totalCountStoreCmc >= Modules.GlobalVars.maxLimitRecords){
//										totalSelectedTextField.setValue(Modules.GlobalVars.maxLimitRecords+"+");
//									}else{
//										totalSelectedTextField.setValue(me.totalCountStoreCmc);
//									}
//								}
								
								var excludeListArry=me.excludeArrayCmc;
								if(excludeListArry && excludeListArry.length>0){// excludeListArry exists, delesect those rows 	
									for(var i=0;i <excludeListArry.length;i++){									
										var index = this.findBy(function(record){
											var matched = false;
											for(var j=0;j< keysArray.length;j++){
											
												if( record.get(keysArray[j])==excludeListArry[i][keysArray[j]]){
													matched = true;
												}else{
													matched = false;
													break;
												}
											}
											if( matched){
												return true;
											}
										});
										var rec = this.getAt(index);									
										selModel.deselect(rec);
									}	
									
								}
						
						}else if(me.rememberSelectionCmc){
							if(me.selectedRecordsArrayCmc && me.selectedRecordsArrayCmc.length>0){// excludeListArry exists, delesect those rows 	
								
								var keysArray = me.keysArrayCmc;
								var selModel=me.getSelectionModel();
								for(var i=0;i <me.selectedRecordsArrayCmc.length;i++){									
									var index = this.findBy(function(record){
										var matched = false;
										for(var j=0;j< keysArray.length;j++){
										
											if( record.get(keysArray[j])==me.selectedRecordsArrayCmc[i][keysArray[j]]){
												matched = true;
											}else{
												matched = false;
												break;
											}
										}
										if( matched){
											return true;
										}
									});
									var rec = this.getAt(index);									
									selModel.select(rec,true);
								}	
								
							}
						}
				 	}else{
				 	// Search criteria is changed form last load. So remove the selection from 'Select All'
				 		selectAllCheck.toggleHandler(selectAllCheck,false);
				 		me.selectedRecordsArrayCmc = [];
				 		me.lastLoadParamsCmc = {};
						Ext.apply(me.lastLoadParamsCmc,me.store.proxy.extraParams);
				 	}
				 }else{
					me.lastLoadParamsCmc =/* me.store.proxy.params ||*/ {};
					
					Ext.apply(me.lastLoadParamsCmc,me.store.proxy.extraParams);
				}
				
			});
		}
		
		me.on('itemcontextmenu', me.itemContextMenuFuncCmc);
		
		me.callParent(arguments);//No arguments passed as per the docs in API		
		
		if(me.showTotalSelectedCmc && me.showSelModelCmc){
			me.on('selectionchange', me.selectionChangeFuncCmc);
		}
		
		me.on('destroy', me.destroyFuncCmc);
		if (me.popUpWinFuncCmc && typeof me.popUpWinFuncCmc == 'function') {
			me.on('cellclick', me.cellClickPopUpFuncCmc);
		}
		
		me.view.on(	'cellclick', function( grid,  td, cellIndex, record, tr, rowIndex, e, eOpts){
    		var me = this.panel; // cmcgrid
    		var fieldId = grid.getGridColumns()[cellIndex].id;
    		
    		if (fieldId == me.popUpActionColumnId) {
				me.getSelectionModel().select(record);			
				Modules.GlobalFuncs.displayWindow({
					winFunc: me.popUpWinFuncCmc,
					winId: me.popUpWinIdCmc
				});
			}
    	});
		
		if( me.associatedGrids && me.associatedGrids.length){
			
			//Stamp parent grid to each child 
			me.on('render',function(grid){
				Ext.each(this.associatedGrids, function(childGridObj){
					var childGrid = this.up('cmctabparentpanel').down('#'+childGridObj.gridItemId);
					if(childGrid){
						childGrid.parentGridCmc = me;
					}
				},grid);
			},me);

			// Add load and cellclick listeners
			me.store.on('load',function(store, records, success, eOpts) {
				if(success==true){
					
                    if(records.length == 0){
                    	
    	            	/*
    	            	 * Redmine 19138
    	            	 * Ext.MessageBox.show({
                             title: '',
                             msg: Modules.Msgs.noDataInGrid,
                             buttons: Ext.MessageBox.OK,
                             icon:Ext.MessageBox.INFO
                        });*/
                    }
                    else{
                    	delete me.currentSelectedParentRec;
                    	var newRec = new (this.getStore().model)();
						me.loadChildGridsCmc(newRec);
                    	//load the first record by default
                    	//me.loadChildGridsCmc(records[0]);
                    	//select it
                    	//me.getSelectionModel().select(records[0]);
                    }										
				}
			},me);
			if(me.loadChildGridCellId != undefined){
				me.view.on(	'cellclick', function( grid,  td, cellIndex, record, tr, rowIndex, e, eOpts){
		    		var me = this.panel; // cmcgrid
		    		var fieldId = grid.getGridColumns()[cellIndex].id;		    		
		    		if (fieldId == me.loadChildGridCellId) {
		    			me.getSelectionModel().select(record);
						me.currentSelectedParentRec = record;
						me.loadChildGridsCmc(record);
					}
		    	});
			}
				
			me.on('cellclick',function(grid,td, index, record, tr, rowIndex, e, eOpts){
				if(index == 0){
					if(me.getSelectionModel().getSelection().length > 1 || me.getSelectionModel().getSelection().length == 0){
					
						delete me.currentSelectedParentRec;
						var newRec = new (this.getStore().model)();
						me.loadChildGridsCmc(newRec);
					}
				}
				if(me.loadChildGridCellIndex == index){
					me.getSelectionModel().select(record);
					me.currentSelectedParentRec = record;
					me.loadChildGridsCmc(record);
				}
			},me);
		}
	},
	/**
	 * Loads data on associatedGrids based on the HasMany relationship provided in Model definition
	 * @param record
	 */
	loadChildGridsCmc : function(record){
		if( this.associatedGrids && this.associatedGrids.length ){
			Ext.each(this.associatedGrids, function(childGridObj){
				var childGrid = this.up('cmctabparentpanel').down('#'+childGridObj.gridItemId);
				if(childGrid){
					childGrid.reconfigure(record[childGridObj.associationName]());
				}
			},this);
		}
	},

	removeChildGridRecordCmc : function(){
		if( this.associatedGrids && this.associatedGrids.length ){
			Ext.each(this.associatedGrids, function(childGridObj){
				var childGrid = this.up('cmctabparentpanel').down('#'+childGridObj.gridItemId);
				if(childGrid){
					childGrid.getStore().removeAll();
				}
			},this);
		}
	},
	setTbarFuncCmc:function(){
		
		var me		=		this;
		
		me.tbar		=		[];//Setting TBar to an empty array	
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.clearBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getClearAction(me.clearBtnObjCmc);
		}
		
		if(me.retrieveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getRetrieveAction(me.retrieveBtnObjCmc);
		}
		
		if(me.showLeftExtraTbarCmc){
		var extraLeftTbar		=		me.setLeftExtraTbarFuncCmc(me.winFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraLeftTbar && extraLeftTbar.length && extraLeftTbar instanceof Array && Object.prototype.toString.call(extraLeftTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraLeftTbar);
			}
		
		}
		me.tbar[me.tbar.length]	=	'->';//This line has been added to create the space after Retrieve button
		
		if(me.showExtraTbarCmc){
			var extraTbar		=		me.setExtraTbarFuncCmc(me.winFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraTbar && extraTbar.length && extraTbar instanceof Array && Object.prototype.toString.call(extraTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraTbar);
			}
		}
		
		if(me.addBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getAddAction(me.addBtnObjCmc);
		}
		
		if(me.markDelBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getMarkDeleteAction(me.markDelBtnObjCmc);
		}
		
		if(me.unmarkDelBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getUnMarkDeleteAction(me.unmarkDelBtnObjCmc);
		}
		
		if(me.saveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getSaveAction(me.saveBtnObjCmc);
		}
		
		if(!me.tbar.length){
			delete me.tbar;//Deleting the tbar if no buttons have been added so far
		}			
	},
	
	//Following function can be used to set the extra buttons in the tbar
	setExtraTbarFuncCmc:function(winFuncArgObjCmc){
		//This function will carry the code of buttons specific to the window
		//This function should return an array of button definitions including the spacers if required
		/*
			Example:
			[
				{
					text:'Report'
					handler:function(){}
				},
				{
					text:'Copy To All',
					handler:function(){}
				},
				'->'//Use only if the buttons need to be in the center of window's tbar
			]
		*/
	},
	
	setGridColumnsFuncCmc:function(){//this function will return an array of objects carrying column definitions
			
	},	
	
	/* setGridStoreFuncCmc:function(){//this function will return an instace of store to be used for the grid
	
	}, */
	
	setPagingToolbarFuncCmc:function(){
		var me			=	this;		
		var confirmPageChange =  function( page, oldValue ){			
			if(me.showConfirmPageChange && !me.rememberSelectionCmc){
				var store = me.getStore() ;
				var newRecordsLength = store.getNewRecords( ).length ;
				var updatedRecordsLength = store.getUpdatedRecords( ).length ;
				var deletedRecordsLength = store.getRemovedRecords( ).length ;
				
				if((updatedRecordsLength > 0 || deletedRecordsLength > 0 ) || newRecordsLength > 0 ){	
					
					var navigateConfirmMessage = Modules.Msgs.saveRecordConfirmation ;
					var summaryMsg = 'Added : '	+ newRecordsLength + '<br>' + 'Updated : '	+ updatedRecordsLength + '<br>' + 'Deleted : '	+ deletedRecordsLength + '<br> <br>';
					
					var navigateConfirmMessage = navigateConfirmMessage + summaryMsg +  Modules.Msgs.continueMsg	;
					
					Ext.MessageBox.confirm(Modules.Msgs.confirmTitle, navigateConfirmMessage, function (answer) {
                        if (answer == "yes") {
                        	me.getStore().loadPage(page);                     
                        }/*else{
                        	if(oldValue){
                        		me.down('#perPageCombo').setValue(oldValue);                        		
                        	}
                        }*/
                    });
					return false;
				}else{		
					if(me.getSelectionModel().getSelection().length > 0){
						Ext.MessageBox.confirm(Modules.Msgs.confirmTitle, Modules.Msgs.selectionRecordConfirmation, function (answer) {
							if (answer == "yes") {
								me.getStore().loadPage(page);                     
							}/*else{
								if(oldValue){
									me.down('#perPageCombo').setValue(oldValue);                        		
								}
							}*/
						});
						return false;						
					}
				}				
			}
			return true;
		};
		
//		var savedState = Modules.GlobalVars.gridStatObj[me.gridId || me.id] && JSON.parse(Modules.GlobalVars.gridStatObj[me.gridId || me.id]);
		
		var pagingCombo = [
						'-',
						'Records Per Page:',
						{
							xtype:'combobox',
							loadStoreCmc:function(){
								
								if(this.getValue()*1 < 1 || (this.getValue()*1 >  me.maxPagesizeCmc)){
									Ext.MessageBox.show({
										title: '',
										msg: 'Record per page should be in range 1-'+me.maxPagesizeCmc,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.ERROR
									});
									this.setValue(this.oldValueCmc);
									return false;
								}
								 me.getStore().pageSize = this.getValue();
								 if(this.oldValueCmc != this.getValue() && confirmPageChange(1, this.oldValueCmc)){								 
									 me.getStore().loadPage(1);
								 }
							 },
							 listeners : {
								blur : function(c) {
									this.loadStoreCmc();
								},
								focus : function() {
									this.oldValueCmc = this.getValue();
									this.expand();
								},
								specialkey : function(f, e) {
									if (e.getKey() == e.ENTER) {
										f.triggerBlur();
							            f.blur();
									}
								}
							},
							width :80,
							store: new Ext.create('Ext.data.Store', 
							{
		                     fields: ['id','value'],
		                     data : [
								{
									"id" : me.defaultPageSizeCmc || 15,
									"value" :me.defaultPageSizeCmc || "15"
								},
								{
									"id" : 20,
									"value" : 20
								},
								{
									"id" : 25,
									"value" : 25
								},
								{
									"id" : 30,
									"value" : "30"
								},
								{
									"id" : 35,
									"value" : "35"
								},
								{
									"id" : 40,
									"value" : "40"
								},
								{
									"id" : 45,
									"value" : "45"
								},
								{
									"id" : 50,
									"value" : "50"
								},
								me.delayTotalCountStoreCmc ? {
									"id" : me.maxPagesizeCmc,
									"value" : me.maxPagesizeCmc
								}:{
									"id" :  me.maxPagesizeCmc, // removed code here , if not show ALL value is always hard coded value
									"value" : me.maxPagesizeCmc 	
								}]
		                     }),
							mode : 'local',
							height:18,
							value:  me.defaultPageSizeCmc || Modules.GlobalVars.recordsPerPageGrid, //(savedState && savedState.recordsPerPage) ||
							displayField : 'value',
							valueField : 'id',
							//editable : false,
							itemId:'perPageCombo'
						}
				]; 
		
		var items=[];
		if(me.addPagingComboCmc){
			items=items.concat(pagingCombo);
		}else{
			//me.down('#centerGridPagingToolBarItemId').displayMsg='';
		}
		var pageTbar	=	Ext.create('Ext.PagingToolbar', {
			store: me.getStore(),
			displayInfo: true,
			displayMsg: me.addPagingComboCmc?'Displaying Records {0} - {1} of {2}' : '', // checking for admin exchanger
			emptyMsg: "No records to display",
			itemId:'centerGridPagingToolBarItemId',
			items:items,
			listeners : {
				beforechange : function( pageTbar, page, eOpts ){
					return confirmPageChange(page);
				},
				render:function(){
					this.down('#refresh').disable();
				}
			}
		});
		return pageTbar;
	},
	
	setTotalSelectedFuncCmc:function(){
		var me		=		this;
		var obj		=		{
			xtype:'cmctextfield',
			readOnly:true,
			labelAlign:'right',
			fieldLabel:'Total Selected',
			width:150,
			labelWidth:100,
			itemId:'totalSelectedGridTextFieldItemId'
		};
		if(me.bbar){				
			me.bbar.add(obj);
		}else{
			me.bbar		=		new Ext.toolbar.Toolbar();
			me.bbar.add('->',obj);
		}
	},
	
	setTotalCountFuncCmc:function(){
		var me		=		this;
		var obj		=		{
			xtype:'cmctextfield',
			readOnly:true,
			labelAlign:'right',
			fieldLabel:'Total Count',
			width:150,
			labelWidth:100,
			value:me.getStore().getCount()
		};
		if(me.bbar){				
			me.bbar.add(obj);
		}else{
			me.bbar		=		new Ext.toolbar.Toolbar();
			me.bbar.add(obj);
		}
	},
	
	//Following function is called at context menu event and is used to display the context menu or stop the context menu of browser to appear
	itemContextMenuFuncCmc:function(view, record, item, index, e, eOpts){
		var me		=		this;
		e.stopEvent();//Preventing the context menu of browser to appear
		if(me.contextMenuCmc.items){//Checking first if context menu has been specified by the user or not
			me.getSelectionModel().select(record);//Setting the record at which user has right clicked as the selected record
			me.contextMenuCmc.showAt(e.getXY());//Displaying the context menu if specified by the user
		}
	},
	
	//Following function is fired at selection change and is used to udpate the textfield carrying the number of selected records
	selectionChangeFuncCmc:function(sm, selectedRecords){
		var me			=		this;
		var totalSelectedTextField =  me.down('#totalSelectedGridTextFieldItemId');
		
		if(totalSelectedTextField){
			if(me.selectAllChecked && (me.totalCountStoreCmc >= Modules.GlobalVars.maxLimitRecords)){
				totalSelectedTextField.setValue(Modules.GlobalVars.maxLimitRecords+"+");
			}else	if(me.slectionAwareCmc && me.selectAllChecked){
				totalSelectedTextField.setValue(me.totalCountStoreCmc - ( (me.excludeArrayCmc && (me.excludeArrayCmc.length))|| 0) );
			}else if (me.rememberSelectionCmc == true){
				totalSelectedTextField.setValue(me.selectedRecordsArrayCmc.length);
			}else{
				totalSelectedTextField.setValue(selectedRecords.length);
				
			}
		}
	},
	
	//Following function is called at destroy event and is used to destroy the context menu if existing.
	//It is used for taking care of the memory leak created if the menu is not explicity destoryed
	destroyFuncCmc:function(){
		var me		=		this;
		if(me.contextMenuCmc.items){//Checking if context menu exists
			me.contextMenuCmc.destroy();//Destroying the context menu
		}
	},
	/**
	 * 
	 * @returns Newly added record
	 */
	addRecordCmc : function(){
		var me = this;
		
		if(me.parentGridCmc && me.parentGridCmc.associatedGrids && me.parentGridCmc.associatedGrids.length > 0 ){
			
			
				if(me.parentGridCmc.getSelectionModel().getSelection().length > 1 || me.parentGridCmc.getSelectionModel().getSelection().length == 0){
				
					//Select one Parent record
					
					//return false;
					var newRec = new (this.getStore().model)();
					return newRec;
				}
			

			if(Ext.isEmpty(me.parentGridCmc.currentSelectedParentRec) ){
				//TODO me.getSelectionModel().getSelection().length==1 then automatically retrieve the clild
				var record = me.parentGridCmc.getSelectionModel().getSelection()[0];
				me.parentGridCmc.getSelectionModel().select(record);
				me.parentGridCmc.currentSelectedParentRec = record;
				me.parentGridCmc.loadChildGridsCmc(record);
				
			}	
		}
		var newRec = new (this.getStore().model)();
		newRec.set('transType','I');// TODO
		this.getStore().insert(0,[newRec]);
		this.loadChildGridsCmc(newRec);
		return newRec;
	},
	/**
	 * Returns column headers of grid, if model's fields has mandatory config option set to true
	 * @param record
	 * @returns
	 */
	checkMandatoryFields : function(record){
		var emptyFields =[];
		Ext.each(record.fields.items,function(field){
			if(field.mandatory && Ext.isEmpty(record.get(field.name))){
				var column = this.getColumnByDataIndex(field.name);
				if(column.initialConfig.header){
					
					emptyFields.push(column.initialConfig.header.split('<')[0]);
				}
			}
		},this);
		return emptyFields.join(', ');
	},
	getColumnByDataIndex : function(dataIndex) {
		var gridColumns = (this.headerCt && this.headerCt.getGridColumns()) || this.columns;
		for ( var i = 0; i < gridColumns.length; i++) {
			if (gridColumns[i].dataIndex == dataIndex) {
				return gridColumns[i];
			}
		}
	},
	getGridRecordByValueCmc:function(key,value){
		var recArray = [];
		this.store.each(function(rec){
			if(rec.get(key) === value){
				recArray.push(rec);
			}
		});
		return recArray;
	},
	/**
		Following function is used to get only those records of grid in form a string which have trnsType as i, u or d
		It can be passed an object as an argument having following keys:
		keysArr - not mandatory - can be an array having keys which need to be excludled or included from the final string. If not given then all keys of record are included
		actTypeOnKeysArr - not mandatory - possible values includeKeys/excludeKeys - can have value as include/exclude with default value being include
		getAll - not mandatory - possible values true or false - default value false - should be set to true if all the records should be retrieved irrespective of trnsType
	**/
	getGridRecStrForServerFuncCmc:function(argObj){
		var me				=		this;
		if(!argObj){
			argObj			=		{};
		}
		var getAll			=		(argObj.getAll === true)?true:false;//Setting the value of getAll as true or false accordingly
		if(typeof argObj.getAll != 'boolean'){
			argObj.getAll	=		false;
		}
		var store			=		me.getStore();
		var recordsStr		=		'[';
		store.each(function(record){
			if(getAll){
				argObj.record		=		record;
				var recStr			=		me.getGridRecAsStrFuncCmc(argObj);
				if(recordsStr!='['){
					recordsStr	+=		','+recStr;
				}else{
					recordsStr	+=		recStr;
				}
			}else if((record.get('transType') && record.get('transType').toUpperCase && record.get('transType').toUpperCase()=='I') || (record.get('transType') && record.get('transType').toUpperCase && record.get('transType').toUpperCase()=='U')){
				argObj.record		=		record;
				var recStr			=		me.getGridRecAsStrFuncCmc(argObj);
				if(recordsStr!='['){
					recordsStr	+=		','+recStr;
				}else{
					recordsStr	+=		recStr;
				}				
			}
		});
		recordsStr		+=		']';
		return recordsStr;
	},
	
	/**
		Following function will return the selected records as string and mark them with trnsType as D so that they can be passed to function for deletion
		It can be passed an object as an argument having following keys:
		keysArr - not mandatory - can be an array having keys which need to be excludled or included from the final string. If not given then all keys of record are included
		actTypeOnKeysArr - not mandatory - possible values includeKeys/excludeKeys - can have value as include/exclude with default value being include
	**/
	getGridRecsForDeleteFuncCmc:function(argObj){
		var me				=		this;
		var recordsStr		=		'[';//Variable which will finally hold the records string
		if(!me.getSelectionModel()){
			recordsStr		+=		']';
			return recordsStr;//Returning empty string
		}		
		var selRecs		=		me.getSelectionModel().getSelection();
		var selRecsLen	=		selRecs.length;
		if(!selRecsLen){
			Ext.MessageBox.show({
				title: 'No Record Selected',
				msg: 'Please select a record for deleting',
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.ERROR
			});
			recordsStr		+=		']';
			return recordsStr;//Returning empty string
		}
		var keysArr			=		selRecs[0].fields.keys;//Getting the array of keys from the first record of array
		var setTrnsType		=		(Ext.Array.contains(keysArr, 'trnsType'))?true:false;
		if(!argObj){
			argObj			=		{};
		}
		var recStr			=		'';
		for(var i=0; i<selRecsLen; i++){
			if(setTrnsType){
				selRecs[i].set('trnsType', 'D');
			}
			argObj.record	=		selRecs[i];
			recStr			=		me.getGridRecAsStrFuncCmc(argObj);
			if(recordsStr!='['){
				recordsStr	+=		','+recStr;
			}else{
				recordsStr	+=		recStr;
			}	
		}//End of for loop
		recordsStr		+=		']';
		return recordsStr;
	},//EOF
	
	/**
		**Following function is used to get a record in string format
		**It can be passed an object as an argument having following key:
		**record - mandatory - record which is to be converted in a string
		**keysArr - not mandatory - can be an array having keys which need to be excludled or included from the final string. If not given then all keys of record are included
		**actTypeOnKeysArr - not mandatory - can have value as includeKeys/excludeKeys with default value being includeAllKeys
	**/
	getGridRecAsStrFuncCmc:function(argObj){
		var recStr			=		'{';
		if(!argObj){//No argument passed then returning an empty string {}
			recStr		+=		'}';
			return recStr;
		}
		if(!argObj.record){//No argument with passed then returning an empty string {}
			recStr		+=		'}';
			return recStr;
		}
		var record					=		argObj.record;
		var actTypeOnKeysArr		=		'includeAllKeys';//Givng default value as includeAllKeys
		var keysArr					=		new Array();//Creating a blank array
		if(argObj.actTypeOnKeysArr && argObj.keysArr && argObj.keysArr.length){//Checking if includeAllKeys and keysArr has been passed and assigning values below
			actTypeOnKeysArr		=		argObj.actTypeOnKeysArr;
			keysArr					=		argObj.keysArr;
		}		
		for(i=0;i<record.fields.keys.length;i++){
			switch(actTypeOnKeysArr){
				case 'includeKeys':
					if(!Ext.Array.contains(keysArr,record.fields.keys[i])){
						continue;
					}
				break;				
				case 'excludeKeys':
					if(Ext.Array.contains(keysArr,record.fields.keys[i])){
						continue;
					}
				break;
			}//End of switch
			if(recStr!='{'){
				recStr	+=		',';
			}
			if(record.fields.items[i].dateFormat){
				recStr		+=		'"'+record.fields.keys[i]+'":"'+Ext.Date.format(record.get(record.fields.keys[i]), record.fields.items[i].dateFormat)+'"';
			}else{
				recStr		+=		'"'+record.fields.keys[i]+'":"'+record.get(record.fields.keys[i])+'"';
			}
		}//End of for loop	
		recStr		+=		'}';
		return recStr;
	},
	/**
	 * Removes data from store and set the reset bbar message if any
	 */
	resetDataCmc : function(){
		if(this.getStore().getCount() > 0 ){
			this.getStore().removeAll();
			this.selectedRecordsArrayCmc = [];
		}
		if(this.showPagingBarCmc){
			this.down('#refresh').disable();
		}
			
	},
	resetToolbar : function(){
		var pagingToolBar = this.getComponent('centerGridPagingToolBarItemId');
		if(pagingToolBar){
			pagingToolBar.onLoad(); // reset the bbar 
			this.down('#refresh').disable();
		}
	},
	//Following function is associated with cell click event and is used to open-up pop-up windows
	cellClickPopUpFuncCmc: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
		var me = this;
		if (me.popUpWinFuncCmc && me.popUpWinIdCmc) {
			if (cellIndex == me.popUpCellIndexCmc) {
				me.getSelectionModel().select(record);			
				Modules.GlobalFuncs.displayWindow({
					winFunc: me.popUpWinFuncCmc,
					winId: me.popUpWinIdCmc
				});
			}
		}
	},

	getColumnConfigFromDataIndex :  function(columns, dataIndex){
		
		var me = this;
		for (var j = 0; j < columns.length; j++) {	
			if (columns[j].dataIndex == dataIndex) {
				return Ext.clone( columns[j]);
			}else if(columns[j].columns && Ext.isArray(columns[j].columns)){
				var a =  me.getColumnConfigFromDataIndex(columns[j].columns,dataIndex);
				if(!Ext.isEmpty(a)){
					return a;
				}
			}
			
		}
	},
	getColumnConfigFromText :  function(columns,text){
		var me = this;
		for (var j = 0; j < columns.length; j++) {	
			if (columns[j].text == text || columns[j].header == text) {
				return Ext.clone(columns[j]);
			}else if(columns[j].columns && Ext.isArray(columns[j].columns)){
				var a = me.getColumnConfigFromText(columns[j].columns,text);
				if(!Ext.isEmpty(a)){
					return a;
				}
			}
			
		}
	},
	buildColumnsFromState : function(savedColumns,newColumns){
		var me = this;
		
        for ( var i = 0; i < savedColumns.length; i++) {
        	
        	
        	
			if (savedColumns[i].text) {
				var columnConfig = me.getColumnConfigFromText(me.columns,savedColumns[i].text);
				
				if(columnConfig){
					var colFragment = {
						text : savedColumns[i].text,
						columns : [],
						hidden : savedColumns[i].hidden,
						locked : savedColumns[i].locked,
						width : savedColumns[i].width
					};
					newColumns.push(colFragment);
					
					me.buildColumnsFromState(savedColumns[i].columns,colFragment.columns);
				}
			}else if(savedColumns[i].dataIndex){
				var columnConfig = me.getColumnConfigFromDataIndex(me.columns,savedColumns[i].dataIndex);
				if(columnConfig){
					
					Ext.apply(columnConfig,savedColumns[i]);
					newColumns.push(columnConfig);
				}
			} else if(Modules.GlobalFuncs.isEmptyObj(savedColumns[i]) && Ext.isEmpty(me.columns[i].dataIndex)){
				// Probabily action column: Add the column of current index to newColumns
				newColumns.push(me.columns[i]);
			}
		}
        
	},
	applyStateCmc : function(){

		var me = this;
		
		Ext.getBody().mask('Loading state information ...');
		
		try {
			var xmlhttp = {};
			var gridId =  me.gridId || me.id ;
			
			
			if(me.loadStateRemotly){ // now it is false
				
				
				if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp = new XMLHttpRequest();
				} else { // code for IE6, IE5
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.open("POST",'gridState/getGridState?userId='+ Modules.GlobalVars.loginUserId +'&gridId=' +gridId, false);
				xmlhttp.send(null);
				var serviceJSON = xmlhttp.responseText;
				var serviceArray = Ext.decode(serviceJSON);
			}
			
			Ext.getBody().unmask();
			
			if(Modules.GlobalVars.gridStatObj && Modules.GlobalVars.gridStatObj[gridId]){
				
				var savedColumnsArray = JSON.parse(Modules.GlobalVars.gridStatObj[gridId]);
				var newColums= [];	  	  
				
				me.buildColumnsFromState(savedColumnsArray.columns,newColums);
				if(newColums.length>0){
					me.columns=newColums;
				}
				
				me.on('layout',function(){
					me.down('#perPageCombo').setValue(savedColumnsArray.recordsPerPage);
				});
			}
		} catch (e) {
			Ext.getBody().unmask();
		}
		
	},
	configureStateButtons:function(){
		var me = this;
		
		me.tbar = me.tbar || ['->'];


        var saveStateBtn = {
			xtype : "button",
			iconCls: 'Save-Grid-state',
			tooltip : Modules.Common_Operation.labels.saveGridState,
			scope:me,
			handler : function() {
				this.saveStateCmc();

			}
		};
        var resetStateCmc = {
				xtype : "button",
				tooltip: Modules.Common_Operation.labels.resetGridState,
				iconCls: 'reset-Grid-state',
				scope:me,
				handler : function() {
					this.resetStateCmc();
				}
        };
        
        Ext.Array.insert(me.tbar, me.tbar.length, [saveStateBtn,resetStateCmc]);
        
        me.applyStateCmc();
        
        //Add reconfigure handler to fix issue with cellEditing plugin
        
        me.on('reconfigure', me.onReconfigure,me);
	},

	saveStateCmc:function(){
		var me = this;
		var gridColumns = me.columns;	
		
		var columnMetaArray = me.getState();
		
		if(columnMetaArray.columns){
			
			if(me.down('#perPageCombo') != null) /** Added a check for null.In child grid pagination has not been implmented so perPageCombo is null **/
				{
				columnMetaArray.recordsPerPage = me.down('#perPageCombo').getValue();	
				}
			
			var paramObj = {
					gridId : me.gridId || me.id,
					userId : Modules.GlobalVars.loginUserId,
					gridState : Ext.encode(columnMetaArray)
			};
			me.mask('Saving state..');
			Ext.Ajax.request({
				url : 'gridState/saveGridState',
				method : 'POST',
				params : paramObj,
				success : function(response) {
					Modules.GlobalVars.gridStatObj[paramObj.gridId]=paramObj.gridState;
					me.unmask();
				},
				failure : function() {
					me.unmask();
				}
			
			});
		}
		
	},
	resetStateCmc:function(){
		var me = this;
		var satandardState = me.getState();
		var paramObj = {
			gridId : this.gridId || this.id,
			userId : Modules.GlobalVars.loginUserId
		};
		me.mask('Deleting state...');
		Ext.Ajax.request({
			url : 'gridState/deleteGridState',
			method : 'POST',
			params : paramObj,
			success : function(response) {
				delete Modules.GlobalVars.gridStatObj[paramObj.gridId];
				me.reconfigure(me.getStore(),me.originalColumns);
				me.view.refresh();
				me.unmask();
			},
			failure : function() {
				me.view.refresh();
				me.unmask();
			} 

		});
		
	
		
	},
	isRecordExistsInExcludeList:function(record){
		var arr=this.excludeArrayCmc;
		var keyExists=false;
		if(arr && arr.length>0 && this.keysArrayCmc){
			for ( var i = 0; i < this.excludeArrayCmc.length; i++) {
				for ( var j = 0; j < this.keysArrayCmc.length; j++) {

					if (record.get(this.keysArrayCmc[j]) == this.excludeArrayCmc[i][this.keysArrayCmc[j]]) {
						keyExists = true;
					} else {
						keyExists = false;
						break;
					}
				}
				if (keyExists) {
					keyExists = {};
					keyExists.key = this.excludeArrayCmc[i];
					keyExists.index = i;
					break;
				}
			}
		}
		 return keyExists;
	},
// TODO: should be clubbed with method 'isRecordExistsInExcludeList'
	isRecordExistsInArray:function(record,arr){
	 
		var keyExists=false;
		if(arr && arr.length>0 && this.keysArrayCmc){
			for ( var i = 0; i < arr.length; i++) {
				for ( var j = 0; j < this.keysArrayCmc.length; j++) {

					if (record.get(this.keysArrayCmc[j]) == arr[i][this.keysArrayCmc[j]]) {
						keyExists = true;
					} else {
						keyExists = false;
						break;
					}
				}
				if (keyExists) {
					keyExists = {};
					keyExists.key = arr[i];
					keyExists.index=i;
					break;
				}
			}
		}
		 return keyExists;
	},

	onReconfigure: function (grid, store, columnConfigs) {
		
		if(grid.getPlugin && grid.getPlugin('editorPlugin')){
			
			var columns = grid.headerCt.getGridColumns(),
			editorPlugin = grid.getPlugin('editorPlugin');
			
			//
			// Re-attached the 'getField' and 'setField' extension methods to each column
			//
			editorPlugin.initFieldAccessors(columns);
			
			//
			// Re-create the actual editor (the UI component within the 'RowEditing' plugin itself)
			//
			// 1. Destroy and make sure we aren't holding a reference to it.
			//
			Ext.destroy(editorPlugin.editor);
			editorPlugin.editor = null;
			//
			// 2. This method has some lazy load logic built into it and will initialize a new row editor.
			//
			// editorPlugin.getEditor();
		}
		
		var pagingBar = grid.getComponent('centerGridPagingToolBarItemId');
		
		if(pagingBar){
			pagingBar.onLoad();
			pagingBar.bindStore(store);
		}
		
	},
//Override the original getPlugin method as there is no check whether 'this.plugins' is exists or not
 getPlugin : function(pluginId) {
	if(this.plugins){
		var i = 0, plugins = this.plugins, ln = plugins.length;
		for (; i < ln; i++) {
			if (plugins[i].pluginId === pluginId) {
				return plugins[i];
			}
		}
	}
},
setParamsForTotalCountStoreAjaxCmc:'',//This will be a function which should return an object containing the parameters to be set when sending the ajax to get the total count for the store

__updateDelayTotalCountStoreCmc:function(){//This function is called when total count has to be retrieved separately
	var me	=	this;
	if(me.getTotalCountStoreUrlCmc){
		var pagingBar					=	me.query('#centerGridPagingToolBarItemId')[0];
		if( me.reloadTotalCount === false && Modules.GlobalFuncs.isObjectsEquals(me.lastLoadParamsCmc,me.store.proxy.extraParams)
				/*|| me.totalCountStoreCmc!='' && typeof me.totalCountStoreCmc=='number'*/
					){
			me.getStore().totalCount	=	me.totalCountStoreCmc;
			
			if(me.totalCountStoreCmc >= Modules.GlobalVars.maxLimitRecords){
				pagingBar.displayMsg		=	'Displaying {0} - {1} of {2}+';
			}else{
				pagingBar.displayMsg		=	'Displaying {0} - {1} of {2}';
			}
			pagingBar.onLoad();	
			pagingBar.updateInfo();
		}else{
//			me.lastLoadParamsCmc = {};
//			Ext.apply(me.lastLoadParamsCmc,me.store.proxy.extraParams);
			
			
			me.selectedRecordsArrayCmc = [];
			me.toggleSelectAllCmc(false);
			
			pagingBar.displayMsg		=	'<span class="totalCountRetreival"><span style="padding:0px 20px 0px 0px">Retrieving total records count<span></span>';
			pagingBar.afterPageText = 'of ?';
			
			pagingBar.updateInfo();
			var params	=	{};
			if(typeof me.setParamsForTotalCountStoreAjaxCmc=='function'){
				params	=	me.setParamsForTotalCountStoreAjaxCmc();
			}
			if(me.down('#selectAllButton')){
				me.down('#selectAllButton').setDisabled(true);
			}
			Ext.Ajax.request({
				url:me.getTotalCountStoreUrlCmc,
				params:params,
				method : 'GET',
				success:function(response){
					if(me.down('#selectAllButton')){
						me.down('#selectAllButton').setDisabled(false);
					}
					me.reloadTotalCount = false;
					var respObj	=	Ext.JSON.decode(response.responseText);
					if(respObj.totalCount > -1){// any number
						me.totalCountStoreCmc		=	respObj.totalCount;
						me.getStore().totalCount	=	me.totalCountStoreCmc;
						pagingBar.afterPageText = 'of {0}';
						if(respObj.totalCount >= Modules.GlobalVars.maxLimitRecords){
							
							pagingBar.displayMsg		=	'Displaying {0} - {1} of {2}+';
						}else{
							pagingBar.displayMsg		=	'Displaying {0} - {1} of {2}';
						}
					}else{
						pagingBar.displayMsg		=	'<span style="padding:0px 20px 0px 0px">Error while retrieving total records count<span>';
					}
					pagingBar.onLoad();
				},
				failure:function(){
					if(me.down('#selectAllButton')){
						me.down('#selectAllButton').setDisabled(false);
					}
					pagingBar.displayMsg		=	'<span style="padding:0px 20px 0px 0px">Error while retrieving total records count<span>';
					pagingBar.onLoad();
					me.totalCountStoreCmc		=	'';
				}
			});
		}			
	}
},

toggleSelectAllCmc : function(check){
	var me = this;
	var selectAllCheck = me.down('#selectAllButton');
	
		if(selectAllCheck){
			selectAllCheck.toggleHandler(selectAllCheck,check);
		}
	}
});