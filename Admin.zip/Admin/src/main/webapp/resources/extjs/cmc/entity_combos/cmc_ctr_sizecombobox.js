/*
	*Following file contains more than one version of the extended entity component of combobox
*/
Ext.define('Ext.cmc.entityCombos.CtrSizeComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the Combobox
	alias: 'widget.cmcctrsizecombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.ctrSzLbl,
	displayField: 'ctrSize',
    valueField: 'ctrSize',
	paging:true,
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:200,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function () {
			  return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="125px" 	align="left">{ctrSize}</td><td width="125px" align="left">{sdescr}</td></tr></table>';
		   }
	},
	validateUrlCmc:'masterslookup/validatectrsize',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this;
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'ContainerSizeModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'masterslookup/getctrsize';
		}
		if(!me.storeObjCmc.paging){
			me.storeObjCmc.paging		=		true;
		}
		me.callParent();//No arguments passed as per the docs in API		
	}
});