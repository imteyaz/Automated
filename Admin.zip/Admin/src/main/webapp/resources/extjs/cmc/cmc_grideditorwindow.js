/**
	**Following component has been extended to be used for editor window of grid
**/
Ext.define('Ext.cmc.GridEditorWindow',{

	extend: 'Ext.window.Window',
	alias: 'widget.cmcgrideditorwindow',
	
	height:200,
	width:600,
	header:false,
	constrain:true,
	autoScroll:true,
	modal:true,
	border:false,
	frame:false,
	layout:'fit',
	
	gridIdCmc:'',//This will carry the id of the grid at which the window was invoked
	openModeCmc:'add',//This will take value either add/edit
	okBtnIdCmc:'',//This is the id which will be applied to the ok button
	okBtnHandlerFuncCmc:function(){
		return true;
	},
	btnCntrMarginCmc:'',//This is the margin which will be applied to the button container
	
	winFuncArgObjCmc:{},//This will hold the arguments object passed to this window
	
	initComponent:function(){
		var me		=		this;
		me.width	=		(me.width && me.width<=900)?me.width:900;
		me.items	=		[me.getFormFuncCmc()];
		me.on('afterrender', me.afterRenderFuncGridEditorWinCmc);//Calling function before parent so that form gets loaded
		me.callParent();
	},
	getFormFuncCmc:function(){
		
		var me			=		this;//This will hold the window object
		
		var formObj		=		{
			xtype:'cmcform',
			itemId:'gridEditorWinFormItemId',
			width:me.width,
			frame:false,
			setFormItemsFuncCmc:function(){
				
				var itemsArr	=	me.setFormItemsFuncCmc();
				if(!itemsArr){
					itemsArr	=	[];
				}
				
				var okBtnMargin	=	(me.btnCntrMarginCmc)?(me.btnCntrMarginCmc):('10px 0px 0px '+((me.width-210)/2)+'px');
				var okBtnId		=	(me.okBtnIdCmc)?me.okBtnIdCmc:'';
				
				var containerObj	=	{
					xtype:'container',
					layout:'hbox',
					margin:okBtnMargin,
					items:[
						{
							xtype:'cmcbutton',
							text:'OK',
							width:100,
							id:okBtnId,
							handler:function(){
								var formObj		=		me.getComponent('gridEditorWinFormItemId').getForm();
								if(!formObj.isValid()){
									Ext.MessageBox.show({
										title: Modules.Msgs.inValidFormTitle,
										msg: Modules.Msgs.inValidFormMsg,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.ERROR
									});
									return false;
								}
								
								//Calling below the handler passed to the instance
								var result		=		me.okBtnHandlerFuncCmc();
								if(!result){
									return result;
								}
								
								var formRec				=	formObj.getValues();
								var formRecKeys			=	Ext.Object.getKeys(formRec);
									
								if(me.openModeCmc.toUpperCase()=='EDIT'){
									//Carrying the tasks below of updating the grid store record
									var gridSelRec			=	Ext.getCmp(me.gridIdCmc).getSelectionModel().getSelection()[0];
									var dirty				=	false;
									var curKeyEdit			=	'';
									for(var i=0; i<formRecKeys.length; i++){
										curKeyEdit		=		formRecKeys[i];
										if(gridSelRec.get(curKeyEdit)!=formRec[curKeyEdit]){
											dirty	=	true;
											gridSelRec.set(curKeyEdit, formRec[curKeyEdit]);
										}
									}//End of for loop
									if(dirty && gridSelRec.get('trnsType')==''){
										gridSelRec.set('trnsType', 'U');
									}
								}else if(me.openModeCmc.toUpperCase()=='ADD'){
									var gridStore			=	Ext.getCmp(me.gridIdCmc).getStore();
									gridStore.insert(0, {});	
									var gridNewRec			=	gridStore.getAt(0);
									var curKeyAdd			=	'';
									for(var i=0; i<formRecKeys.length; i++){
										curKeyAdd		=		formRecKeys[i];
										gridNewRec.set(curKeyAdd, formRec[curKeyAdd]);
									}//End of for loop
									gridNewRec.set('trnsType', 'I');
								}								
								me.close();
							}
						},
						{
							xtype:'cmcbutton',
							text:'Cancel',
							width:100,
							margin:'0px 0px 0px 5px',
							handler:function(){
								me.close();
							}
						}
					]
				};
				itemsArr[itemsArr.length]		=		containerObj;
				return itemsArr;
			}
		};
		return formObj;
	},
	//Following function should be instantiated by the object. Function should return an array of items
	setFormItemsFuncCmc:function(){},
	
	//Following function is called afterrender and is used to load the form with the selected grid record
	afterRenderFuncGridEditorWinCmc:function(){
		var me		=		this;
		if(me.openModeCmc.toUpperCase() == 'EDIT'){
			var formObj		=		me.getComponent('gridEditorWinFormItemId').getForm();
			var gridSelRec	=		Ext.getCmp(me.gridIdCmc).getSelectionModel().getSelection()[0];
			formObj.loadRecord(gridSelRec);
		}
		Ext.getBody().unmask();
	}//EOF afterRenderFuncGridEditorWinCmc
});