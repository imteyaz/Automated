/*
	*Following file contains more than one version of the extended component of combobox
*/
Ext.define('Ext.cmc.LocalCtrStsComboBox', {
   
	extend: 'Ext.cmc.ComboBox',
	alias: 'widget.cmclocalcurstscombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	queryMode: 'local',
	forceSelection:true,
	/*Beginning of assigning values to already existing validate config options*/
	validateOnBlur:false,
	displayField:'status',
	valuelField:'status',
	/*Ending of assigning values to already existing validate config options*/
	/**Ending the setting of values for already existing configs**/
	storeObjCmc:{},
	paging:false,
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	},
	initComponent:function(){
		var me	=	this;
		var storeObjCmc		=		{
			model:'StatusComboModel',
			data:[
				{
				status: "MANIFESTED"
			}, {
				status: "BR PROCESSED,PREGATE NOTE RECORDED"
			}, {
				status: "PREGATE DONE,GATE IN NOT RECORDED"
			}, {
				status: "IN PORT"
			}, {
				status: "IN YARD"
			}, {
				status: "ON VESSEL"
			}, {
				status: "PENDING FOR LOAD"
			}
			],
			queryTypeCmc:'local'
		};
		me.storeObjCmc		=		storeObjCmc;
		me.callParent();//No arguments passed as per the docs in API		
	}
});