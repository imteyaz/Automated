Ext.define('Ext.cmc.WindowNorthFormCenterGridSouthForm',{
	
	extend: 'Ext.cmc.Window',
	alias: 'widget.cmcwindownorthformcentergridsouthform',
	
	showClearButtonCmc:true,//Displaying the Clear button
	
	showNorthItemCmc:true,//Displaying the North Item
	northHeightFactorCmc:0.3,//North Region Height Factor. Can be OverRidden if required in the instance
	northFormContainerWidthFactorCmc:0.9,//The width of the form container. Can be OverRidden if required in the instance
	
	showSouthItemCmc:true,//Comments same as North Item above
	southHeightFactorCmc:0.2,
	southFormContainerWidthFactorCmc:0.9,
	
	/*
		*Following function is used to clear the records from the grid and reset both the forms if existing
		*Following function NEED NOT be OverRidden in the instance
		*The instance of this class should override setClearButtonSpecificHandlerFuncCmc() function
	*/
	setClearButtonGenericHandlerFuncCmc:function(){
		var me			=		this;
		if(me.getComponent('centerGridItemId')){
			me.getComponent('centerGridItemId').getStore().removeAll();
		}
		if(me.getComponent('northFormItemId')){
			me.getComponent('northFormItemId').getForm().reset();
		}
		if(me.getComponent('southFormItemId')){
			me.getComponent('southFormItemId').getForm().reset();
		}
		return true;
	},
	
	/*
		*Following function is used to create the center region grid
		*The purpose of this function is to attach common properties to the grid
		*An instance of this class DOES NOT NEED to OverRide this function
		*This function call another function - setCenterGridDetailsFuncCmc
		*The child class can override - setCenterGridDetailsFuncCmc
	*/
	setCenterItemFuncCmc:function(){
		
		var me			=		this;
		
		var gridObj		=		me.setCenterGridDetailsFuncCmc(me.winFuncArgObjCmc);//Getting the details of the grid of instance
		
		if(!gridObj.itemId){
			gridObj.itemId		=		'centerGridItemId';//Attaching the itemId to the grid
		}
		
		if(!gridObj.xtype){
			gridObj.xtype		=		'cmcgrid';//Attaching the xtype to the grid
		}
		
		return gridObj;
	},
	
	/*
		*Following funciton is expected to be overridden by the instance of this class
		*This function should return an object carrying all the features of cmcgrid, except of the xtype and itemId
		*Listeners etc.. can be provided through this function
		*An example implementation is shown in the function below
	*/
	setCenterGridDetailsFuncCmc:function(winFuncArgObjCmc){
		
		var gridObj				=		{};
		gridObj.setGridColumnsFuncCmc	=		function(){
			var cols	=	[{
				header    : 'test',
				dataIndex : 'test'
			}];
			return cols;
		}
		gridObj.storeObjCmc	=		{
			type:'grid',
			fields : [{name: 'test', type: 'string'}],
			data:[
					{ test : 'Hello' }
				]
		};
		
		return gridObj;
	},
	
	/*
		*Following function is used to create the north region form
		*The purpose of this function is to attach common properties to the form
		*An instance of this class DOES NOT NEED to OverRide this function
		*This function call another function - setNorthFormDetailsFuncCmc
		*The child class can override - setNorthFormDetailsFuncCmc
	*/
	setNorthItemFuncCmc:function(){
	
		var me			=		this;
	
		var formObj		=		me.setNorthFormDetailsFuncCmc(me.winFuncArgObjCmc);
		
		if(!formObj.itemId){
			formObj.itemId				=		'northFormItemId';//Attaching the itemId to the form
		}
		
		if(!formObj.xtype){
			formObj.xtype				=		'cmcform';//Attaching the xtype to the form
		}
		
		if(!formObj.title){
			formObj.title				=		me.northItemTitleCmc;//Attaching the title to the form
		}
		
		if(!formObj.layout){
			formObj.layout				=		'ux.center'//Attaching the layout
		}
		
		//Beginning of the code of inserting a container at the top of all the items of this form
		//Creating the container object below
		var containerObj		=		{
			xtype:'container',
			width:me.width*me.northFormContainerWidthFactorCmc
		};
		
		containerObj.items		=		formObj.setFormItemsFuncCmc();//Calling the function for getting the child items provided by the instance
		
		var itemsArr			=		[];
		
		itemsArr[0]				=		containerObj;//Making the container as the first element of the form
		
		formObj.setFormItemsFuncCmc	=		function(){//Overriding the function and returning the items with the container as the top item
			return itemsArr;
		}
		//Ending of the code of inserting a container at the top of all the items of this form
		
		return formObj;
	},
	
	/*
		*Following function is used to get the specific details of a form
		*It can be used to provide the listeners and other properties which are specific to the form
		*It should always return an object
		*Sample implementation is as shown in the function below
	*/
	setNorthFormDetailsFuncCmc:function(winFuncArgObjCmc){
		var formObj		=		{};
		formObj.setFormItemsFuncCmc		=		function(){
			var storeVar = Ext.create('Ext.data.Store', {
				fields: ['abbr', 'name'],
				data : [
					{"abbr":"AL", "name":"Alabama"},
					{"abbr":"AK", "name":"Alaska"},
					{"abbr":"AZ", "name":"Arizona"}
				]
			});
			var items		=		[{
				xtype:'cmccombobox',
				fieldLabel:'Test',
				store:storeVar,
				displayField:'name',
				valueField:'abbr',
				listeners:{
					select:function(){
						//Ext.getCmp('winId').getBtnsOrDockedItems('clearBtnItemId').setDisabled(true);
					}
				}
			}];
			return items;
		}
		
		return formObj;
	},
	
	//Comments same as for the north item above
	setSouthItemFuncCmc:function(){
	
		var me			=		this;
		
		var formObj		=		me.setSouthFormDetailsFuncCmc(me.winFuncArgObjCmc);
		
		if(!formObj.itemId){
			formObj.itemId				=		'southFormItemId';//Attaching the itemId to the form
		}
		
		if(!formObj.xtype){
			formObj.xtype				=		'cmcform';//Attaching the xtype to the form
		}
		
		if(!formObj.title){
			formObj.title				=		me.southItemTitleCmc;//Attaching the title to the form
		}
		
		if(!formObj.layout){
			formObj.layout				=		'ux.center'//Attaching the layout
		}
		
		//Beginning of the code of inserting a container at the top of all the items of this form
		//Creating the container object below
		var containerObj		=		{
			xtype:'container',
			width:me.width*me.southFormContainerWidthFactorCmc
		};
		
		containerObj.items		=		formObj.setFormItemsFuncCmc();//Calling the function for getting the child items provided by the instance
		
		var itemsArr			=		[];
		
		itemsArr[0]				=		containerObj;//Making the container as the first element of the form
		
		formObj.setFormItemsFuncCmc	=		function(){//Overriding the function and returning the items with the container as the top item
			return itemsArr;
		}
		//Ending of the code of inserting a container at the top of all the items of this form
		
		return formObj;
	},
	
	//Comments same as for the north item above
	setSouthFormDetailsFuncCmc:function(winFuncArgObjCmc){
		var formObj		=		{};
		formObj.setFormItemsFuncCmc		=		function(){
			var items	=	[{
				xtype:'textfield',
				fieldLabel:'Test'
			}];
			return items;
		}		
		return formObj;
	}
});