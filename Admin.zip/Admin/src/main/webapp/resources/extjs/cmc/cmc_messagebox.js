Ext.define('Ext.cmc.MessageBox', {
    extend: 'Ext.window.Window',

    requires: [
        'Ext.toolbar.Toolbar',
        'Ext.form.field.Text',
        'Ext.form.field.TextArea',
        'Ext.button.Button',
        'Ext.layout.container.Anchor',
        'Ext.layout.container.HBox'
    ],

    alias: 'widget.cmcmessagebox',

    // hide it by offsets. Windows are hidden on render by default.
    hideMode: 'offsets',
    closeAction: 'hide',
    resizable: false,
    title: '&#160;',
    modal:true,
    width: 300,
    height: 600,
    minWidth: 300,
    maxWidth: 270,
    minHeight: 120,
    maxHeight: 350,
    constrain: true,

    cls: Ext.baseCSSPrefix + 'message-box',
    initComponent: function() {
        var me = this,
            i, button;

        me.title = '&#160;';

        me.topContainer = Ext.create('Ext.container.Container', {
            anchor: '100%',
            style: {
                padding: '10px'
               // overflow: 'hidden'
            },
            items: [
                me.iconComponent = Ext.create('Ext.Component', {
                    cls: 'ext-mb-icon',
                    width: 50,
                    height: me.iconHeight,
                    style: {
                        'float': 'left'
                    }
                }),
                me.promptContainer = Ext.create('Ext.container.Container', {
                    layout: {
                        type: 'anchor'
                    },
                    items: [
                        me.msg = Ext.create('Ext.Component', {
                            autoEl: { tag: 'span' },
                            cls: 'ext-mb-text'
                        }),
                        me.detailsPanel =  Ext.create('Ext.form.FieldSet',{
                        	collapsible:true,
                        	//collapsed:true,
                        	title:'Details',
                        	autoScroll :true,
                        	height: 250,
                        	width:275,
                        	items:[me.detailsText = Ext.create('Ext.form.Display',{
                                value: '',
                                width:235
                            })],
                            listeners:{
                            	expand:function(){
                            		me.setHeight(me.maxHeight);
                            		//me.setWidth(me.mxWi);
                            	},
                            	collapse:function(){
                            		me.setHeight(me.minHeight);
                            	}
                            }
                        })
                    ]
                })
            ]
        });


        me.items = [me.topContainer];

        // Create the buttons based upon passed bitwise config

        me.bottomTb = Ext.create('Ext.toolbar.Toolbar', {
            ui: 'footer',
            dock: 'bottom',
            layout: {
                pack: 'center'
            },
            items: [
               {xtype:'button',text:'OK',minWidth: 75}
            ]
        });
        me.dockedItems = [me.bottomTb];

        me.callParent();
        //me.header.hide();
    },
    setIcon : function(icon) {
        var me = this;
        me.iconComponent.removeCls(me.iconCls);
        if (icon) {
            me.iconComponent.show();
            me.iconComponent.addCls(Ext.baseCSSPrefix + 'dlg-icon');
            me.iconComponent.addCls(me.iconCls = icon);
        } else {
            me.iconComponent.removeCls(Ext.baseCSSPrefix + 'dlg-icon');
            me.iconComponent.hide();
        }
        return me;
    },
    show : function(cfg){
    	this.msg.update(cfg.msg);
    	this.setIcon(cfg.icon);
    	this.setHeight(this.minHeight);
    	this.callParent();
    	this.detailsText.update(cfg.detailMsg);
    	this.detailsPanel.collapse();
    	return this;
    }


}, function() {
    Ext.cmc.MessageBox = Ext.cmc.Msg = new this();
});