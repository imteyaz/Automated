var requiredField = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';
Ext.define('Ext.cmc.Master.Window', { // TODO name needs to be changed to Panel
	extend: 'Ext.form.Panel',
	alias: 'widget.cmcmasterwindow',
	showUrl: '',
	paramObj: '',
	getretrieveUrl: '',
	getsaveUrl: '',
	getdeleteUrl: '',
	getexportUrl: '',
	columnLength: '',
	getkeyFields: '',
	getdupCheckFields: '',
	getmasterQueryParamFields: '',
	getNotEditableFields: '',
	getCopyFields: '',
	getExtraQueryFields: '',
	metaStore: '',
	frame: false,
	width: 1000,
	onEsc: Ext.emptyFn,
	constrain: true,
	modal: true,
	autoScroll: true,
	isMapper: false,
	initComponent: function () {
		var me = this;
		me.callParent(); // No arguments passed as per the docs
		me.on('boxready', me.boxReadyWinFuncCmc); // Associating
		me.on('beforeclose',Ext.cmc.TabParentPanel.prototype.checkForGridDataModification,me);
	},
	boxReadyWinFuncCmc: function (me, width, height, eOpts) {
		var win = this;
		
		Ext.define('MetaModel'+win.paramObj.gridId, {
			/** Model for Grid* */
			extend: 'Ext.data.Model',
			fields: [{
				name: 'trnsType',
				type: 'string'
			}]
		});
		var mainTabHeight = Ext.getCmp(
		Modules.CompIds.viewportParentTabPanelId)
			.getHeight();
		if (mainTabHeight > height) {
			win.setPosition(this.x, 120);
			win.setHeight(Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight() - 70);
		} else if (mainTabHeight < height) {
			win.setHeight(Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).getHeight() - 70);
			win.setPosition(this.x, 120);
		}
		Ext.getCmp(Modules.CompIds.viewportParentTabPanelId).on('resize',
        function () {
			win.setHeight(Ext.getCmp(
			Modules.CompIds.viewportParentTabPanelId).getHeight() - 70);
		});
		/** Setting the window position according to the resize* */
		var gridObj = this.child('#masterGrid');
		this.metaStore = Ext.create('Ext.data.Store', {
			/** Grid Store* */
			model: 'MetaModel'+win.paramObj.gridId,
			proxy: {
				type: 'ajax',
				url: '',
				reader: {
					type: 'json',
					totalProperty: 'totalCount',
					root: 'data',
					method: 'POST'
				},
				 writer: {
			            encode: true,
			            writeAllFields: false,
			            root : 'data'
			     }
			},
			listeners: {
				'beforeload': function () {
					var form = win.child('#masterQueryParamForm'); 
					var formFields = form.query('field[formFieldCmc="true"]');
					var jsonObj = {};
					for (var i = 0; i < formFields.length; i++) {
						jsonObj[formFields[i].name] = formFields[i].getValue();
					};
					this.proxy.url = win.getretrieveUrl;
					this.proxy.extraParams = jsonObj;
					this.proxy.extraParams.showAll = Modules.GlobalVars.maxLimitRecords;
					this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode; //
					this.proxy.extraParams.serviceTypeCode = Modules.GlobalVars.selectedServiceTypeCode;
					this.proxy.extraParams.userId=Modules.GlobalVars.loginUserId;
					this.proxy.extraParams.gridId = win.paramObj.gridId;
					var gridObj = win.child('#masterGrid');
					var limitVal = gridObj.down('#perPageCombo').getValue();
					if (!limitVal) {
						limitVal = Modules.GlobalVars.recordsPerPageGrid;
					}
					this.proxy.extraParams.limit = limitVal;
					this.pageSize = limitVal;
				},
				'metachange': function (store,meta) {
					
					var isMapper = (meta.metaType == "mapper");
					var viewOnlyMode = (meta.mode == "viewOnly");
					var noImport = meta.noImport;

					gridObj.down('#pasteButtonId').setVisible(!isMapper);
					gridObj.down('#copyButtonId').setVisible(!isMapper);
					gridObj.down('#uploadButnId').setVisible(!noImport);
					gridObj.down('#showPartnerButtonId').setVisible(isMapper);
					
					if(meta.mode == "viewOnly"){
						gridObj.down('#pasteButtonId').setVisible(false);
						gridObj.down('#copyButtonId').setVisible(false);
						gridObj.down('#saveButtonId').setVisible(false);
						gridObj.down('#addButtonId').setVisible(false);
						gridObj.down('#deleteButtonId').setVisible(false);
						//gridObj.down('#uploadButnId').setVisible(!viewOnlyMode);
						
					}else if(meta.mode == "updateOnly"){
						gridObj.down('#pasteButtonId').setVisible(false);
						gridObj.down('#copyButtonId').setVisible(false);
						gridObj.down('#addButtonId').setVisible(false);
						gridObj.down('#deleteButtonId').setVisible(false);
					}else if(meta.mode == "noCopyFields"){
						gridObj.down('#pasteButtonId').setVisible(false);
						gridObj.down('#copyButtonId').setVisible(false);
					}
					if(meta.metaType == "tariff"){
						gridObj.down('#tariffSlabDetailsButtonId').setVisible(true);
					}
					
					for (var i = 0; i < meta.fields.length; i++) {
						if(meta.fields[i].name!='action'){
							meta.fields[i].dataIndex = meta.fields[i].name;
							meta.fields[i].itemId = meta.fields[i].name;
						}
						
						if(meta.fields[i].mandatory){
							meta.fields[i].header=meta.fields[i].text+requiredField;
						}else{
							meta.fields[i].header=meta.fields[i].text;
						}
						
						if(meta.fields[i].tooltip){
							meta.fields[i].tooltip=meta.fields[i].tooltip;
						}
						
						if (meta.fields[i].fldtype == 'rownumberer') {
							meta.fields[i].xtype = 'rownumberer';
						}
						if (meta.fields[i].fldtype == 'cmccheckboxfield') {
							meta.fields[i].xtype = 'checkcolumn';
							var checkObj=Ext.create('Ext.cmc.CheckboxField',{
							    xtype : 'cmccheckboxfield'
							    });
							
							if(meta.fields[i].isToggle){
								checkObj.on('change',function(checkbox,newValue, oldValue){
				            		var selectedRec = gridObj.getSelectionModel().getLastSelected(); 
				            		if(newValue){
				            			gridObj.getStore().each(function(rec){
				            				if(selectedRec && selectedRec.id==rec.id){
				            					return;
				            				}
				            				rec.set(checkbox.name,undefined);
				            			});
				            		}
				            	});
							}
							meta.fields[i].editor = checkObj;
						}
						if (meta.fields[i].fldtype == 'cmctextfield' || meta.fields[i].fldtype == 'cmcnumberfield') {
							var textJSON = {
								xtype: meta.fields[i].fldtype,
								itemId: meta.fields[i].name + i,
								hideable: (meta.fields[i].hideable != undefined) ? meta.fields[i].hideable : true,
								enforceMaxLength: (meta.fields[i].enforceMaxLength != undefined) ? meta.fields[i].enforceMaxLength : false,
								maxLength: (meta.fields[i].maxLength != undefined) ? meta.fields[i].maxLength : 100,
								readOnly : meta.fields[i].readOnly != undefined ?meta.fields[i].readOnly:false,
								lowerCaseCmc:meta.fields[i].lowerCaseCmc
							};
							
							if (meta.fields[i].fldtype == 'cmcnumberfield' && meta.fields[i].type == 'integer') {
								textJSON.allowNegative=false;
								textJSON.allowDecimals=false;
							}
							if(meta.fields[i].editor != false){
								meta.fields[i].editor = textJSON;
							}
							if (meta.fields[i].fldtype == 'cmcnumberfield'){
								meta.fields[i].align='right';
							}
							if (meta.fields[i].fldtype == 'cmcnumberfield' && meta.fields[i].type == 'float') {
								if(meta.fields[i].isCurrency){
									meta.fields[i].renderer=Ext.cmc.CurrencyRenderer;	
								}
								if(meta.fields[i].precision){
									meta.fields[i].renderer=Modules.GlobalFuncs.getDecimalFormater(meta.fields[i].precision);	
								}
							}
							
						}else if(meta.fields[i].fldtype == 'cmcdatetimefield' ){
							var datetimeJSON = {
									xtype: 'cmcdatefield',
									itemId: meta.fields[i].name + i,
									hideable: (meta.fields[i].hideable != undefined) ? meta.fields[i].hideable : true,
									maxLength: (meta.fields[i].maxLength != undefined) ? meta.fields[i].maxLength : 100,
									readOnly : meta.fields[i].readOnly != undefined ?meta.fields[i].readOnly:false,
									format: Modules.GlobalVars.dateTimeFormatGlobal
								};
							
								meta.fields[i].editor = datetimeJSON;
								meta.fields[i].renderer=Ext.util.Format.dateRenderer(Modules.GlobalVars.dateTimeFormatGlobal)
								//meta.fields[i].renderer=Ext.util.Format.dateRenderer(Modules.GlobalVars.dateFormatGlobal);
							
						}else if(meta.fields[i].fldtype == 'cmcdatefield' ){
							var dateJSON = {
									xtype: meta.fields[i].fldtype,
									itemId: meta.fields[i].name + i,
									hideable: (meta.fields[i].hideable != undefined) ? meta.fields[i].hideable : true,
									maxLength: (meta.fields[i].maxLength != undefined) ? meta.fields[i].maxLength : 100,
									readOnly : meta.fields[i].readOnly != undefined ?meta.fields[i].readOnly:false
								};
							
								meta.fields[i].editor = dateJSON;
								meta.fields[i].renderer=Ext.util.Format.dateRenderer(Modules.GlobalVars.dateFormatGlobal)
								//meta.fields[i].renderer=Ext.util.Format.dateRenderer(Modules.GlobalVars.dateFormatGlobal);
							
						}else if (meta.fields[i].lookup) {
							
							var modelFieldsArray = [{
								"name": meta.fields[i].lookup.valueField,
								"type": "string"
							}, {
								"name": meta.fields[i].lookup.displayField,
								"type": "string"
							}];
							
							if(Ext.isArray(meta.fields[i].lookup.modelFields)){
								Ext.each(meta.fields[i].lookup.modelFields,function(item){
									modelFieldsArray.push(item);
								});
							}
							Ext.define('lookupModel' + i +win.paramObj.gridId , { /***Model for Combo***/
								extend: 'Ext.data.Model',
								"fields": modelFieldsArray
							});
							
							
							var comboObj=Ext.create('Ext.cmc.ComboBox',{
								xtype : 'cmccombobox',
								name : meta.fields[i].name,
								queryMode : 'remote',
								params : meta.fields[i].lookup.params,
								valueField : meta.fields[i].lookup.valueField,
								displayField :  meta.fields[i].lookup.valueField,//meta.fields[i].lookup.displayField,
								validateUrlCmc : meta.fields[i].lookup.validateUrl,
								dependents: meta.fields[i].dependents,
								dependsOn: meta.fields[i].dependsOn,
								validateParamsCmc : [{'name' : 'companyCode' , 'val' : Modules.GlobalVars.selectedCompanyCode}],
								validateSuccessFuncCmc: function (serverRespOjbData) {
									return true;
								},
								validateFailFuncCmc:function(){
								    var combo=this;
									if (!Ext.isEmpty(combo.dependents)) {
										Ext.each(combo.dependents, function (item) {
											// Make depedent fields empty, If dependable value is invalid
												var sm = gridObj.getSelectionModel().getLastSelected();
												if(typeof item == 'string'){
													sm.set(item,"");
												}else if(typeof item == 'object'){
													var keys=[];
													keys=Ext.Object.getKeys(item);
													for(var i=0;i<keys.length;i++){
														sm.set( item[keys[i]],"");
													}
												}
						                   },combo);
									}
									
									return true;
								},
								hideable : (meta.fields[i].hideable != undefined)?meta.fields[i].hideable:true,
								readOnly : meta.fields[i].readOnly != undefined ?meta.fields[i].readOnly:false,		
								storeObjCmc : {
									model : 'lookupModel'+i+win.paramObj.gridId,
									url : meta.fields[i].lookup.getUrl,
									extraParams : {'companyCode' : Modules.GlobalVars.selectedCompanyCode,
										'serviceTypeCode' : Modules.GlobalVars.selectedServiceTypeCode,
									    'userId' : Modules.GlobalVars.loginUserId},
									    listeners:{
									    	beforeload:function(){
									    		this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;
									    		this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;
									    	}
									    }
								},
								 tpl: Ext.create('Ext.XTemplate',
										 '<div class="lov-header"><li style="width: 150px;" class="lov-li">Code  </li><li class="lov-li"> Description </li></div>',
										 '<tpl for=".">',
										 '<div class="x-boundlist-item"><li style="width: 150px;" class="lov-li">{'+meta.fields[i].lookup.valueField+'} </li><li class="lov-li"> {'+meta.fields[i].lookup.displayField+'}</li></div>',
										 '</tpl>') 
							});
							
							if(meta.fields[i].lookup.columnsCmc && Ext.isArray(meta.fields[i].lookup.columnsCmc)){ // Overrriding default Combo Model Fields
								comboObj.prepareListTemplateCmc(meta.fields[i].lookup.columnsCmc);
							}	
							
							
							if (!Ext.isEmpty(comboObj.params)) {
								Ext.each(comboObj.params, function (item) {
									
								 comboObj.store.proxy.extraParams[item['name']]=item['value'];
								});
								
							}
							
							
							meta.fields[i].editor = comboObj;
							if (!Ext.isEmpty(comboObj.dependents)) {
								comboObj.on('select', function (comboObj, record, eOpts) {
									
								Ext.each(comboObj.dependents, function (item) {
									var sm = gridObj.getSelectionModel().getLastSelected();
									if(typeof item == 'string'){
										sm.set(item,record[0].data.name);
									}else if(typeof item == 'object'){
										// implementing code to support multiple depenedent columns or fields
										var keys=[];
										keys=Ext.Object.getKeys(item);
										for(var i=0;i<keys.length;i++){
											sm.set( item[keys[i]],record[0].data[keys[i]]);
										}
										
									}
			                    });
									
								}, comboObj);
								
								comboObj.on('change', function (comboObj, newValue, oldValue) {
									
									Ext.each(comboObj.dependents, function (item) {
										
										if(Ext.isEmpty(newValue)){
											
											Ext.each(comboObj.dependents, function (item) {
												var sm = gridObj.getSelectionModel().getLastSelected();
												if(typeof item == 'string'){
													sm.set(item,"");
												}else if(typeof item == 'object'){
													var keys=[];
													keys=Ext.Object.getKeys(item);
													for(var i=0;i<keys.length;i++){
														sm.set( item[keys[i]],"");
													}
													
												}
											});
										}
									});
										
									}, comboObj);
							}
							
							if(!Ext.isEmpty(comboObj.dependsOn)){
								comboObj.on('beforequery',function(queryEvent){
									var combo = queryEvent.combo;
									var record = gridObj.getSelectionModel().getLastSelected();
									combo.store.proxy.extraParams[Ext.Object.getKeys(combo.dependsOn)[0]] = record.get(combo.dependsOn[Ext.Object.getKeys(combo.dependsOn)[0]]);
								});	
							}
							
						}
						if (meta.fields[i].fldtype == 'actioncolumn') {
							meta.fields[i].xtype = 'actioncolumn';
							meta.fields[i].align = 'center';
							meta.fields[i].sortable = false,
							meta.fields[i].draggable = false,
							meta.fields[i].hideable = false;
							meta.fields[i].dataIndex='masterGridActionId';
							meta.fields[i].items = [{
								icon: 'resources/images/editView.jpg',
								tooltip: 'Open Popup Window'
							}]
						}
						if (meta.fields[i].fldtype == 'labelfield') {
							meta.fields[i].hideable = false;
						}
						if (meta.fields[i].fldhidden) {
							meta.fields[i].hidden = true;
						} else {
							meta.fields[i].hidden = false;
						}
						
						if(meta.fields[i].bgcolor){
							meta.fields[i].tdCls='custom-column' ;
						}
					}
					gridObj.columns = meta.fields;
					gridObj.originalColumns = meta.fields;
					Ext.cmc.Grid.prototype.applyStateCmc.call(gridObj);
					
					gridObj.reconfigure(store,gridObj.columns);
					/**
					 * *Configuring columns
					 * dynamically**
					 */
					
				}
			}
		});
		this.layout = "border";
		this.add({
			xtype: "form",
			//height : 65,
			region: "north",
			collapsible: true,
			bodyPadding : 5,
			title: win.title,
			itemId: 'masterQueryParamForm',
			layout: "column",
			defaults: {
				margin: '0px 10px 0px 10px',
				labelSeparator: ' ',
				columnWidth: 1
			},
			tbar: [{
				text: Modules.Common_Operation.labels.clear,
				iconCls: "clear",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var getQueyForm = winMain.child('#masterQueryParamForm').getForm();
					gridObj.getStore().removeAll();
					getQueyForm.reset();
					var pagingToolBar = gridObj.getComponent('genericMasterPagingToolItemId');
					if (pagingToolBar) {
						pagingToolBar.onLoad(); // reset the bbar 
						pagingToolBar.down('#refresh').disable();
					}
				}
			}, {
				text: Modules.Common_Operation.labels.retrieve,
				iconCls: "retrieve",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var form = winMain.child('#masterQueryParamForm').getForm();
					gridObj.getStore().loadPage(1,{
					    callback: function(records, operation, success){
							if(records && records.length>0){
								winMain.down('#masterQueryParamForm').collapse();
								gridObj.down('#genericMasterPagingToolItemId').down('#refresh').enable(true);
							}else{
								gridObj.down('#genericMasterPagingToolItemId').down('#refresh').disable();
								 Ext.MessageBox.show({
		                             title: '',
		                             msg: Modules.Msgs.noDataInGrid,
		                             buttons: Ext.MessageBox.OK,
		                             icon:Ext.MessageBox.INFO
		                        });
							}
						}
					});
					winMain.onConvert();
				}
			}, '->'],
			plugins: [{
				ptype: 'saveretrievecriteria',
				screenId: win.paramObj.gridId // Must be unique, pass you parentTabPanel id or any other unique id {mandatory}
			}]
		}, {
			/**
			 * Dynamic adding of grid in the
			 * dynamic window*
			 */
			xtype: "grid",
			itemId: 'masterGrid',
			height: 380,
			border: false,
			gridId:win.paramObj.gridId,
			width: 800,
			buildColumnsFromState : Ext.cmc.Grid.prototype.buildColumnsFromState,
			getColumnConfigFromText : Ext.cmc.Grid.prototype.getColumnConfigFromText,
			getColumnConfigFromDataIndex : Ext.cmc.Grid.prototype.getColumnConfigFromDataIndex,
			region: "center",
			//	enableLocking : true,	
			store: win.metaStore,
			autoScroll: true,
			cls: 'custom-dirty', // Applied
			columns: [],
			tbar: [{
				xtype: 'button',
				text: Modules.Common_Operation.labels.add,
				itemId:'addButtonId',
				iconCls: "add",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var r = Ext.ModelManager.create({
						trnsType: 'I'
					}, 'MetaModel'+win.paramObj.gridId);
					//  var storeObj = win.metaStore;
					storeObj = gridObj.getStore();
					storeObj.insert(0, r);
					var firstRecord = storeObj.first();
					firstRecord.data.trnsType = "I";
					//storeObj.getAt(0).data.trnsType="I";
					gridObj.getView().refresh();
				}
			}, {
				xtype: 'button',
				text: Modules.Common_Operation.labels.del,
				iconCls: "delete",
				itemId:'deleteButtonId',
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var gridrecord = gridObj.getView().getSelectionModel().getSelection();
					var selRecLength = gridrecord.length;
					if (gridObj.getStore().getCount() > 0) {
						if (selRecLength == '1') {
							Ext.Msg.confirm('', Modules.Msgs.deleteSingleRecordConfirmation, function (answer) {
								if (answer == "yes") {
									deleteSelectedRecords(win, gridObj, gridrecord, selRecLength);
								}
							});
						} else if (selRecLength > 1) {
							Ext.Msg.confirm('', Modules.Msgs.deleteMultiRecordsConfirmation, function (answer) {
								if (answer == "yes") {
									deleteSelectedRecords(win, gridObj, gridrecord, selRecLength);
								}
							});
						} else {
							Ext.MessageBox.show({
								msg: Modules.Msgs.selRecFrst,
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.INFO
							});
						}
					} else {
						Ext.MessageBox.show({
							msg: Modules.Msgs.noRecordsDelete,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
					
				}
			}, {
				xtype: 'button',
				text: Modules.Common_Operation.labels.copy,
				itemId:'copyButtonId',
				iconCls: "copy_invoice",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var copyFieldset = winMain.child('#masterQueryParamForm').child('#copyFieldsetItemId');
					if (copyFieldset.isVisible()) {
						copyFieldset.setVisible(false);
					} else {
						copyFieldset.setVisible(true);
					}
				}
			}, {
				xtype: 'button',
				text: Modules.Common_Operation.labels.paste,
				itemId:'pasteButtonId',
				iconCls: "paste",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var copyFieldset = winMain.child('#masterQueryParamForm').child('#copyFieldsetItemId');
					if (copyFieldset.isVisible()) {
						var selRecords = gridObj.getSelectionModel().getSelection();
						if (selRecords.length != 0) {
							for (var i = 0; i < selRecords.length; i++) {
								for (var j = 0; j < win.getCopyFields.length; j++) {
									if (selRecords[i].data.trnsType == undefined) {
										selRecords[i].data.trnsType = 'U';
									}
									var currectCopyField = copyFieldset.down('#' + win.getCopyFields[j]);
									if(currectCopyField && !Ext.isEmpty(currectCopyField.getValue())){
										selRecords[i].set(win.getCopyFields[j],currectCopyField.getValue());
									}
								}
							}
						} else {
							Ext.MessageBox.show({
								title: '',
								msg: Modules.Msgs.selRecFrst,
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.INFO
							});
						}
					} else {
						Ext.MessageBox.show({
							msg: 'Please click on copy button.',
							buttons: Ext.MessageBox.OK, 
							icon:Ext.MessageBox.INFO
						});
					}
				}
			},{
				
				xtype: 'button',
				text: Modules.Masters.General_Master.labels.showPartnerBtn,
				itemId:'showPartnerButtonId',
				hidden:true,
				iconCls: "manual",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var copyFieldset = winMain.child('#masterQueryParamForm').child('#copyFieldsetItemId');
					var selRecords = gridObj.getSelectionModel().getSelection();
					if (selRecords.length == 1  && !Ext.isEmpty(selRecords[0].get('partnerGroup'))) {
						
						Ext.cmc.Master.showPartnerWindow(selRecords[0].get('partnerGroup')).show();
					} else {
						var errorMsg = Modules.Msgs.selRecFrst;
						if(selRecords.length > 1){
							errorMsg = Modules.Msgs.selectOnlySingleRecord;
						}
						Ext.MessageBox.show({
							title: '',
							msg: errorMsg,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
				}
			},
			{
				
				xtype: 'button',
				text: 'Tariff Slab Details',
				itemId:'tariffSlabDetailsButtonId',
				hidden:true,
				iconCls: "manual",
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var selRecords = gridObj.getSelectionModel().getSelection();
					if (selRecords.length == 1  && !Ext.isEmpty(selRecords[0].get('tariffCode')) && !Ext.isEmpty(selRecords[0].get('effectiveDate'))) {
						
						Ext.cmc.Master.tariffSlabDetailsWindow(
								{tariffCode:selRecords[0].get('tariffCode'),
								effectiveDate:selRecords[0].get('effectiveDate'),
								cumulativeFlag:selRecords[0].get('cumulativeFlag')}
								).show();
					} else {
						var errorMsg = Modules.Msgs.selRecFrst;
						if(selRecords.length > 1){
							errorMsg = Modules.Msgs.selectOnlySingleRecord;
						}
						Ext.MessageBox.show({
							title: '',
							msg: errorMsg,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
				}
			},
			'->', {
				xtype: 'button',
				text: Modules.Common_Operation.labels.save,
				iconCls: "save",
				itemId:'saveButtonId',
				handler: function () {
					var winMain = this.ownerCt.ownerCt.ownerCt;
					var gridObj = winMain.child('#masterGrid');
					var form = winMain.child('#masterQueryParamForm').getForm();
					var param1 = form.getValues();
					var dataArray = [];
					
					
					var modelArray = gridObj.getStore().getModifiedRecords();
					
					
					
					if (modelArray.length != 0) {
						for (i = 0; i < modelArray.length; i++) {
							var record = modelArray[i].data;
							record.companyCode = Modules.GlobalVars.selectedCompanyCode;
							record.serviceTypeCode = Modules.GlobalVars.selectedServiceTypeCode;
							record.userId = Modules.GlobalVars.loginUserId;
							winMain.convertToDateFormat(record);
							if(record.trnsType && record.trnsType=='RO'){
								record.trnsType='U';
							}
							dataArray.push(record)
						}
						var jsonArray = Ext.JSON.encode(dataArray);
						var param2 = {
							state: jsonArray,
							gridId: win.paramObj.gridId,
							companyCode: Modules.GlobalVars.selectedCompanyCode,
							serviceTypeCode : Modules.GlobalVars.selectedServiceTypeCode,
							userId : Modules.GlobalVars.loginUserId,
							showAll: Modules.GlobalVars.maxLimitRecords
						};
						var finalParams = Ext.Object.merge(param1, param2);
						
						 var body = Ext.getBody();
						 body.mask("Saving..");
						
						Ext.Ajax.request({
							url: win.getsaveUrl,
							params: finalParams,
							method: 'POST',
							success: function (response) {
								var msg = Ext.decode(response.responseText);
								if (msg.success == true) {
									gridObj.getStore().load();
									body.unmask();
									Ext.MessageBox.show({
										msg: 'Saved successfully',
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.INFO
									});
								} else {
									body.unmask();
									Ext.MessageBox.show({
										msg: msg.errors,
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.ERROR
									});
								}
							},
							failure: function (response, options) {
								body.unmask();
								Ext.MessageBox.show({
									msg: "Network failure",
									buttons: Ext.MessageBox.OK,
									icon: Ext.MessageBox.ERROR
								});
							}
						});
					} else {
						Ext.MessageBox.show({
							msg: "No record to save",
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
				}
			},{
				xtype: 'button',
				tooltip: Modules.Common_Operation.labels.exportToExcel,
				iconCls: "excel",
				handler: function () {
					var gridObj = win.child('#masterGrid');
					if (gridObj.getStore().getCount() > 0) {
						if (win.getexportUrl == undefined || win.getexportUrl == '') {
							Ext.MessageBox.show({
								msg: 'Not yet implemented.',
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.INFO
							});
						} else {
							
							
							//var searchObj = win.child('#masterQueryParamForm').getForm().getValues(false,true);
							
							var form = win.child('#masterQueryParamForm'); 
							var formFields = form.query('field[formFieldCmc="true"]');
							var searchObj = {};
							for (var i = 0; i < formFields.length; i++) {
								searchObj[formFields[i].name] = formFields[i].getValue();
							};
							
							searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
							searchObj.serviceTypeCode = Modules.GlobalVars.selectedServiceTypeCode;
							searchObj.userId = Modules.GlobalVars.loginUserId;
							searchObj.showAll=Modules.GlobalVars.maxLimitRecords;
							if(win.paramObj && win.paramObj.gridId){
								searchObj.gridId = win.paramObj.gridId;
							}
							if(win.paramObj && win.paramObj.templateId){
								searchObj.templateId = win.paramObj.templateId;
							}
							Ext.cmc.Exporter.exportToXls(gridObj, searchObj,win.getexportUrl);
							
						}
					} else {
						Ext.MessageBox.show({
							msg: 'No records to export',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
				}
			}, {
				xtype: 'button',
				tooltip: Modules.Common_Operation.labels.exportToPDF,
				iconCls: "report",
				handler: function () {
					var gridObj = win.child('#masterGrid');
					if (gridObj.getStore().getCount() > 0) {
					
						if (win.getexportUrl == undefined || win.getexportUrl == '') {
							Ext.MessageBox.show({
								msg: 'Not yet implemented.',
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.INFO
							});
						} else {
							
							
							//var searchObj = win.child('#masterQueryParamForm').getForm().getValues(false,true);
							
							var form = win.child('#masterQueryParamForm'); 
							var formFields = form.query('field[formFieldCmc="true"]');
							var searchObj = {};
							for (var i = 0; i < formFields.length; i++) {
								searchObj[formFields[i].name] = formFields[i].getValue();
							};
							
							searchObj.companyCode = Modules.GlobalVars.selectedCompanyCode;
							searchObj.serviceTypeCode = Modules.GlobalVars.selectedServiceTypeCode;
							searchObj.userId = Modules.GlobalVars.loginUserId;
							searchObj.showAll=Modules.GlobalVars.maxLimitRecords;
							
							if(win.paramObj && win.paramObj.gridId){
								searchObj.gridId = win.paramObj.gridId;
							}
							if(win.paramObj && win.paramObj.templateId){
								searchObj.templateId = win.paramObj.templateId;
							}
							Ext.cmc.Exporter.exportToPdf(gridObj, searchObj,win.getexportUrl);
							
					
						}
					} else {
						Ext.MessageBox.show({
							msg: 'No records to export',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
						});
					}
				}
			}, {
				xtype: 'button',
				tooltip: Modules.Common_Operation.labels.importFromExcel,
				iconCls: "upload",
				itemId:'uploadButnId',
				handler: function () {
					var gridObj = win.child('#masterGrid');
					var uploadWin=null;
					if(win.paramObj.templateId){//Mappers
						uploadWin = Modules.Masters.UploadWindow(win.paramObj.templateId, gridObj,'excelOrCsvFileImporter/importExcelOrCsvFileToProc','excelOrCsvFileImporter/downloadImportTemplate');
					}else{//Masters
						uploadWin = Modules.Masters.UploadWindow(win.paramObj.gridId, gridObj,undefined,'excelOrCsvFileImporter/downloadImportTemplate');
					}
					uploadWin.show();
					
				}
			},{
				xtype : "button",
				iconCls: 'Save-Grid-state',
				tooltip : Modules.Common_Operation.labels.saveGridState,
				scope:me,
				handler : function() {
					Ext.cmc.Grid.prototype.saveStateCmc.call(this.down('grid'));
				}
			},{
				xtype : "button",
				tooltip: Modules.Common_Operation.labels.resetGridState,
				iconCls: 'reset-Grid-state',
				scope:me,
				handler : function() {
					Ext.cmc.Grid.prototype.resetStateCmc.call(this.down('grid'));
				}
			}],
			
			selModel : win.paramObj.hideSelModel?false:Ext.create('Ext.selection.CheckboxModel'),
			listeners: {
				beforeedit: function (editor, e, eOpts) {
					if (e.record.data.trnsType != 'I') {
						e.record.data.trnsType = 'RO';
					}
					if (e.record.data.trnsType == 'RO') {
						for (i = 0; i < win.getNotEditableFields.length; i++) {
							if (win.getNotEditableFields[i] == e.column.dataIndex) {
								this.down('#' + e.column.dataIndex).field.setReadOnly(true);
							}
						}
					} else {
						for (i = 0; i < win.getNotEditableFields.length; i++) {
							if (win.getNotEditableFields[i] == e.column.dataIndex) {
								this.down('#' + e.column.dataIndex).field.setReadOnly(false);
							}
						}
					}
					
				},
				edit: function (editor, e, eOpts) {
					if (e.record.data.trnsType != 'I') {
						if (e.originalValue != e.value) e.record.data.trnsType = "U";
					}
				},
				cellclick: function (cellModel, td, cellIndex, record, tr, rowIndex, e, eOpts) {
					
					if (cellModel.getGridColumns()[cellIndex].dataIndex == 'masterGridActionId') {
						if (record.data.trnsType == 'I') {
							editWindowObj = win.callEditorWindow(win, record, 'I');
							editWindowObj.show();
							var editForm = editWindowObj.child('#gridPopUpWinFormItemId');
							
						} else {
							record.data.trnsType="U";
							editWindowObj = win.callEditorWindow(win, record, 'U');
							editWindowObj.show();
							var editForm = editWindowObj.child('#gridPopUpWinFormItemId');
							for (i = 0; i < win.getNotEditableFields.length; i++) {
								var component = editForm.down('#' + win.getNotEditableFields[i])
								if (component != undefined && component != null) {
									component.setReadOnly(true);
								}
							}
						}
					}
				},
			selectionchange : function(sm, selectedRecords){
				var grid = win.child('#masterGrid');
				grid.selectionChangeFuncCmc(sm,selectedRecords);
			},
			render:function(){
				var grid = win.child('#masterGrid');
				grid.setTotalSelectedFuncCmc();
			}
				
			},
			plugins: [
			Ext.create('Ext.grid.plugin.CellEditing', {
				clicksToMoveEditor: 1,
				clicksToEdit: 1
			})],
			bbar: Ext.create('Ext.PagingToolbar', {
				store: win.metaStore,
				displayInfo: true,
				displayMsg: 'Displaying records {0} - {1} of {2}',
				emptyMsg: "No records to display",
				itemId: 'genericMasterPagingToolItemId',
				items: [ 'Records Per Page:', {
					xtype: 'combobox',
					itemId: 'perPageCombo',
					listeners: {
						change: function (c, newValue, oldValue, eOpts) {
							gridObj.getStore().loadPage(1);
						}
					},
					width: 80,
					store: new Ext.create('Ext.data.Store', {
						fields: ['id', 'value'],
						data: [{
							"id": me.paramObj.defaultPageSizeCmc || "20",
							"value": me.paramObj.defaultPageSizeCmc || "20"
						},
						{
							"id" : 25,
							"value" : 25
						},
						{
							"id" : 30,
							"value" : "30"
						},
						{
							"id" : 35,
							"value" : "35"
						},
						{
							"id" : 40,
							"value" : "40"
						},
						{
							"id" : 45,
							"value" : "45"
						},
						{
							"id" : 50,
							"value" : "50"
						},{
							"id" : Modules.GlobalVars.gridMaxPagesize,
							"value" : Modules.GlobalVars.gridMaxPagesize
						}]
					}),
					mode: 'local',
					height: 18,
					value: me.paramObj.defaultPageSizeCmc || 20,
					displayField: 'value',
					valueField: 'id',
					editable: false
				}],
				listeners: {					
					render:function(){
						this.down('#refresh').disable();						
					},
					change:function(){
						if(gridObj.getStore().getCount() == 0){
							this.down('#refresh').disable();
						}
					}
				}
			}),
			
			setTotalSelectedFuncCmc:function(){
				var me		=		this;
				var obj		=		{
					xtype:'cmctextfield',
					readOnly:true,
					labelAlign:'right',
					fieldLabel:'Total Selected',
					width:150,
					labelWidth:100,
					itemId:'totalSelectedGridTextFieldItemId'
				};
				
				var pagingBar=me.getDockedItems('[dock=bottom]');
				if(pagingBar){
					pagingBar[0].add(obj);
				}
				
			},
			
			selectionChangeFuncCmc:function(sm, selectedRecords){
				var me			=		this;
				if(me.dockedItems && me.dockedItems.items && me.dockedItems.items.length){
					for(var i=0; i<me.dockedItems.items.length; i++){
						if(me.dockedItems.items[i].getComponent('totalSelectedGridTextFieldItemId')){
							break;
						}
					}
					if(i<me.dockedItems.items.length){
						me.dockedItems.items[i].getComponent('totalSelectedGridTextFieldItemId').setValue(selectedRecords.length);
					}
				}
			}
		});
		/** Dynamic adding of grid in the dynamic window* */
		var gridObj = win.child('#masterGrid');
		gridObj.getStore()
			.load({
			url: this.showUrl,
			params: win.paramObj,
			callback: function () {
				win.getretrieveUrl = this.proxy.reader.metaData.retrieveUrl;
				win.getsaveUrl = this.proxy.reader.metaData.saveUrl;
				win.getdeleteUrl = this.proxy.reader.metaData.deleteUrl; //
				win.getexportUrl = this.proxy.reader.metaData.exportUrl;
				win.columnLength = this.proxy.reader.metaData.fields.length;
				win.getkeyFields = this.proxy.reader.metaData.keyFields;
				win.getdupCheckFields = this.proxy.reader.metaData.dupCheckFields;
				var getQueryForm = win.child('#masterQueryParamForm');
				var innerForm = getQueryForm.add({
					xtype: 'fieldset',
					border: false,
					layout: 'column',
					defaults: {
						margin: '0px 10px 0px 10px',
						labelSeparator: ' ',
						columnWidth: .35
					}
				});
				if (this.proxy.reader.metaData.queryFields == undefined) {
					/**
					 * ******For hiding the
					 * Query fields*********
					 */
					getQueryForm.setVisible(false);
				}
				if (this.proxy.reader.metaData.queryFields) {
					/**
					 * ******For showing the
					 * Query fields*********
					 */
					win.getmasterQueryParamFields = this.proxy.reader.metaData.queryFields;
					var queryLength = win.getmasterQueryParamFields.length;
				}
				if (this.proxy.reader.metaData.notEditableFields) {
					win.getNotEditableFields = this.proxy.reader.metaData.notEditableFields;
				}
				
				if (this.proxy.reader.metaData.extraQueryFields) {
					win.getExtraQueryFields = this.proxy.reader.metaData.extraQueryFields;
				}
				if (this.proxy.reader.metaData.copyFields) {
					win.getCopyFields = this.proxy.reader.metaData.copyFields;
				}
				var getForm = win.child('#form');
				var mainWindowWidth = screen.width;
				var mainWindowHeight = screen.height;
				var testLen = 6;

				
				for (var i = 0; i < win.columnLength; i++) {
					
					var columnObj = gridObj.getStore().proxy.reader.metaData.fields[i];
					var getHidden;
					if (columnObj.fldhidden) {
						getHidden = true;
					} else {
						getHidden = false;
					}
					if (columnObj.allowBlank == undefined) columnObj.allowBlank = true;
					for (var j = 0; j < queryLength; j++) {
						if (win.getmasterQueryParamFields[j] == columnObj.name) {
							if (columnObj.fldtype) {
								
								var field = {
										labelSeparator: '',
										width: columnObj.fieldWidth || 300,
										labelWidth: columnObj.labelWidth || 150,
										xtype: columnObj.fldtype,
										fieldLabel: columnObj.text,
										name: columnObj.name,
										itemId : columnObj.name,
										maxLength: columnObj.maxLength != undefined ? columnObj.maxLength : 100,
										toolTipCmc: columnObj.tooltip?	columnObj.tooltip: false	

									};
								if(columnObj.fldtype == 'cmcdatefield'){
									field.valuesAsStringCmc = true;
								}
								
								innerForm.add({
									xtype: 'container',
									columnWidth:.35,
									items: field
								});
							}
							if (columnObj.lookup) {
									var comboFieldsArray = [{
									"name": columnObj.lookup.valueField,
									"type": "string"
								}, {
									"name": columnObj.lookup.displayField,
									"type": "string"
								}];
								
								if(Ext.isArray(columnObj.lookup.modelFields)){
									Ext.each(columnObj.lookup.modelFields,function(item){
										comboFieldsArray.push(item);
									});
								}
								Ext.define('comboModel'+i+j+win.paramObj.gridId, { /***Model for Combo***/
									extend: 'Ext.data.Model',
									"fields": comboFieldsArray
								});
								
								
								var combo = Ext.create('Ext.cmc.ComboBox', {
									fieldLabel: columnObj.text,
									toolTipCmc: columnObj.tooltip?	columnObj.tooltip: false	,
									xtype: 'cmccombobox',
									width: columnObj.fieldWidth || 300,
									labelWidth: columnObj.labelWidth || 150,
									name: columnObj.name,
									itemId : columnObj.name,
									queryMode: 'remote',
									validator : false,
									dependents: columnObj.dependents, // Array of dependets fields (names)
									dependsOn:columnObj.dependsOn,
									params : columnObj.lookup.params,
									value : columnObj.value != undefined?columnObj.value:'',
									valueField: columnObj.lookup.valueField,
									displayField: (win.paramObj.gridId == 'PRINT_AND_EMAIL_GRID_ID')?columnObj.lookup.displayField : columnObj.lookup.valueField, //columnObj.lookup.displayField,
									/*validateUrlCmc: columnObj.lookup.validateUrl,
									validateParamsCmc: [{
										'name': 'companyCode',
										'val': Modules.GlobalVars.selectedCompanyCode
									}],
									validateSuccessFuncCmc: function (serverRespOjbData) {
										return true;
									},
									validateFailFuncCmc:function(){
										return true;
									},*/
									storeObjCmc: {
										model: 'comboModel'+i+j+win.paramObj.gridId,
										url: columnObj.lookup.getUrl,
										extraParams : {'companyCode' : Modules.GlobalVars.selectedCompanyCode,
											'serviceTypeCode' : Modules.GlobalVars.selectedServiceTypeCode,
										    'userId' : Modules.GlobalVars.loginUserId},
										    listeners:{
										    	beforeload:function(){
										    		this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;;
										    		this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;

										    	}
										    }
										
									},
									tpl: Ext.create('Ext.XTemplate', 
											'<div class="lov-header"><li style="width: 150px;" class="lov-li">Code  </li><li class="lov-li"> Description </li></div>',
											'<tpl for=".">',
											'<div class="x-boundlist-item"><li style="width: 150px;" class="lov-li">{' 
												+ columnObj.lookup.valueField + '} </li><li class="lov-li"> {' 
												+ columnObj.lookup.displayField + '} </li></div>',
											'</tpl>')
								});
								
								if(columnObj.lookup.columnsCmc && Ext.isArray(columnObj.lookup.columnsCmc)){ // Overrriding default Combo Model Fields
									combo.prepareListTemplateCmc(columnObj.lookup.columnsCmc);
								}	
								
								
								if (!Ext.isEmpty(combo.params)) {
									Ext.each(combo.params, function (item) {
										
										combo.store.proxy.extraParams[item['name']]=item['value'];
									});
									
								}
								
								
								
								if (!Ext.isEmpty(combo.dependsOn)) {
									combo.on('beforequery',function(queryEvent){
										var combo = queryEvent.combo;
										var field = getQueryForm.down('#'+combo.dependsOn[Ext.Object.getKeys(combo.dependsOn)[0]]);;
										field && (combo.store.proxy.extraParams[Ext.Object.getKeys(combo.dependsOn)[0]] = field.getValue());
									});	
								}
								
								if (!Ext.isEmpty(columnObj.dependents)) {
									combo.on('select', function (comboObj, record, eOpts) {
										
										Ext.each(comboObj.dependents, function (item) {
												
												if(typeof item == 'string'){
													var comp=getQueryForm.down('#'+item);
													comp && comp.setValue(record[0].data.name);
												}else if(typeof item == 'object'){
													var comp=getQueryForm.down('#'+item[Ext.Object.getKeys(item)[0]]);
													comp && comp.setValue( record[0].data[Ext.Object.getKeys(item)[0]]);
												}
					                    });
									}, combo);
									// to reset dependents
									
									combo.on('change', function (comboObj, newValue, oldValue) {
										
											if(Ext.isEmpty(newValue)){
												Ext.each(comboObj.dependents, function (item) {
													
													if(typeof item == 'string'){
														var comp=getQueryForm.down('#'+item);
														comp && comp.reset();
													}else if(typeof item == 'object'){
														var comp=getQueryForm.down('#'+item[Ext.Object.getKeys(item)[0]]);
														comp && comp.reset();
													}
												});
											}
											
										}, combo);
								}
								innerForm.add({
									xtype: 'container',
									labelSeparator: '',
									columnWidth:.35,
									items: [combo]
								});
							}
						}
					}
				}
				
				// appending extraQueryFields 
                if(win.getExtraQueryFields!=undefined){
                	for(var i=0;i<win.getExtraQueryFields.length;i++){
                		
                		if (win.getExtraQueryFields[i].fldtype=='cmctextfield' || win.getExtraQueryFields[i].fldtype=='cmcnumberfield') {
							innerForm.add({
								xtype: 'container',
								items: {
									labelSeparator: '',
									width: win.getExtraQueryFields[i].fieldWidth || 300,
									labelWidth: win.getExtraQueryFields[i].labelWidth || 150,
									xtype: win.getExtraQueryFields[i].fldtype,
									//toolTipCmc: win.getExtraQueryFields[i].tooltip ,
									fieldLabel: win.getExtraQueryFields[i].text,
									name: win.getExtraQueryFields[i].name,
									itemId : win.getExtraQueryFields[i].name,
									maxLength: win.getExtraQueryFields[i].maxLength != undefined ? win.getExtraQueryFields[i].maxLength : 100
								}
							});
						}else if (win.getExtraQueryFields[i].fldtype=='cmcdatefield') {
							
							
							var extraDateField = Ext.create('Ext.cmc.Datefield',{
									labelSeparator: '',
									width: win.getExtraQueryFields[i].fieldWidth || 300,
									labelWidth: win.getExtraQueryFields[i].labelWidth || 150,
									xtype: win.getExtraQueryFields[i].fldtype,
									fieldLabel: win.getExtraQueryFields[i].text,
									//toolTipCmc: win.getExtraQueryFields[i].tooltip || win.getExtraQueryFields[i].text,
									name: win.getExtraQueryFields[i].name,
									itemId : win.getExtraQueryFields[i].name,
									maxLength: win.getExtraQueryFields[i].maxLength != undefined ? win.getExtraQueryFields[i].maxLength : 100,
									valuesAsStringCmc:true,
									dateType : win.getExtraQueryFields[i].dateType
								});
							
							
							extraDateField.on('render',function(datefield) {
								if(datefield.dateType && datefield.dateType == 'fromdate'){
									    var date=new Date();
										date.setTime((date.getTime())-(86400000));
										datefield.setValue(date);
								}else if(datefield.dateType && datefield.dateType == 'todate'){
									 datefield.setValue(new Date());    
								}
						      
						     });
						       

							
							innerForm.add({
								xtype: 'container',
								items: extraDateField
							});
						}
                		
                		
                		if (win.getExtraQueryFields[i].lookup) {
							var extraFieldsArray = [{
									"name": win.getExtraQueryFields[i].lookup.valueField,
									"type": "string"
								}, {
									"name": win.getExtraQueryFields[i].lookup.displayField,
									"type": "string"
								}];
								
								if(Ext.isArray(win.getExtraQueryFields[i].lookup.modelFields)){
									Ext.each(win.getExtraQueryFields[i].lookup.modelFields,function(item){
										extraFieldsArray.push(item);
									});
								}
								Ext.define('comboModel'+i+win.paramObj.gridId, {
									extend: 'Ext.data.Model',
									"fields": extraFieldsArray
								});
							
							var combo = Ext.create('Ext.cmc.ComboBox', {
								fieldLabel: win.getExtraQueryFields[i].text,
								//toolTipCmc: win.getExtraQueryFields[i].tooltip || win.getExtraQueryFields[i].text,
								xtype: 'cmccombobox',
								width: win.getExtraQueryFields[i].width || 300,
								labelWidth:  win.getExtraQueryFields[i].labelWidth || 150,
								name: win.getExtraQueryFields[i].name,
								queryMode: 'remote',
								params : win.getExtraQueryFields[i].lookup.params,
								dependents: win.getExtraQueryFields[i].dependents, // Array of dependets fields (names)
								readOnly : win.getExtraQueryFields[i].readOnly != undefined ?win.getExtraQueryFields[i].readOnly:false ,
								valueField: win.getExtraQueryFields[i].lookup.valueField,
								displayField: win.getExtraQueryFields[i].lookup.valueField, //columnObj.lookup.displayField,
								validateUrlCmc: win.getExtraQueryFields[i].lookup.validateUrl,
								validateParamsCmc: [{
									'name': 'companyCode',
									'val': Modules.GlobalVars.selectedCompanyCode
								}],
								validateSuccessFuncCmc: function (serverRespOjbData) {
									return true;
								},
								validateFailFuncCmc:function(){
									return true;
								},
								storeObjCmc: {
									model: 'comboModel'+i+win.paramObj.gridId,
									url: win.getExtraQueryFields[i].lookup.getUrl,
									extraParams : {'companyCode' : Modules.GlobalVars.selectedCompanyCode,
										'serviceTypeCode' : Modules.GlobalVars.selectedServiceTypeCode,
									    'userId' : Modules.GlobalVars.loginUserId},
								    listeners:{
								    	beforeload:function(){
								    		this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;;
								    		this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;

								    	}
								    }
								},
								tpl: Ext.create('Ext.XTemplate',
										'<div class="lov-header"><li style="width: 150px;" class="lov-li">Code  </li><li class="lov-li"> Description </li></div>',
										'<tpl for=".">',
										'<div class="x-boundlist-item"><li style="width: 150px;" class="lov-li">{' + win.getExtraQueryFields[i].lookup.valueField + '}</li><li class="lov-li"> {' + win.getExtraQueryFields[i].lookup.displayField + '}</li></div>', '</tpl>')
							});
							if (!Ext.isEmpty(win.getExtraQueryFields[i].dependents)) {
								combo.on('select', function (comboObj, record, eOpts) {
									
									Ext.each(comboObj.dependents, function (item) {
											
											if(typeof item == 'string'){
												var comp=getQueryForm.down('#'+item);
												comp && comp.setValue(record[0].data.name);
											}else if(typeof item == 'object'){
												
												var keys=[];
												keys=Ext.Object.getKeys(item);
												for(var i=0;i<keys.length;i++){
													var comp=getQueryForm.down('#'+item[keys[i]]);
													comp && comp.setValue( record[0].data[keys[i]]);
												}
												
											}
				                    });
								}, combo);

								if(win.getExtraQueryFields[i].lookup.columnsCmc && Ext.isArray(win.getExtraQueryFields[i].lookup.columnsCmc)){ // Overrriding default Combo Model Fields
									combo.prepareListTemplateCmc(win.getExtraQueryFields[i].lookup.columnsCmc);
								}	
								
								
								if(win.getExtraQueryFields[i].lookup.params && Ext.isArray(win.getExtraQueryFields[i].lookup.params)){ // Overrriding default Combo Model Fields
									if (!Ext.isEmpty(combo.params)) {
										Ext.each(combo.params, function (item) {
											
											combo.store.proxy.extraParams[item['name']]=item['value'];
										});
										
									}
									}	
								
								combo.on('change', function (comboObj, newValue, oldValue) {
									
										if(Ext.isEmpty(newValue)){
											Ext.each(comboObj.dependents, function (item) {
												
												if(typeof item == 'string'){
													var comp=getQueryForm.down('#'+item);
													comp && comp.reset();
												}else if(typeof item == 'object'){
                                                   var keys=[];
													keys=Ext.Object.getKeys(item);
													for(var i=0;i<keys.length;i++){
														var comp=getQueryForm.down('#'+item[keys[i]]);
														comp && comp.reset();
													}
												}
											});
										}
										
									}, combo);
							};
							innerForm.add({
								xtype: 'container',
								labelSeparator: '',
								columnWidth:.35,
								items: [combo]
							});
						}
    				
    				}
                }
				
				
				
				
				var copyFieldsetObj = getQueryForm.add({
					xtype: 'fieldset',
					itemId: 'copyFieldsetItemId',
					title: 'Copy',
					collapsible: true,
					layout: 'column',
					hidden: true,
				//	columnWidth: 1,
					layout: 'column',
					defaults: {
						margin: '0px 5px 0px 5px',
						labelSeparator: ' ',
						columnWidth: .35
					} 
				});
				for (var i = 0; i < win.columnLength; i++) {
					var columnObj = gridObj.getStore().proxy.reader.metaData.fields[i];
					var getHidden;
					if (columnObj.fldhidden) {
						getHidden = true;
					} else {
						getHidden = false;
					}
					if (columnObj.allowBlank == undefined) columnObj.allowBlank = true;
					for (var j = 0; j < win.getCopyFields.length; j++) {
						if (win.getCopyFields[j] == columnObj.name) {
							if (columnObj.fldtype) {
								copyFieldsetObj.add({
									xtype: 'container',
									items: {
										labelSeparator: '',
										toolTipCmc: columnObj.tooltip?	columnObj.tooltip: false	,
									//	width: columnObj.fieldWidth || 300,
										labelWidth: columnObj.labelWidth || 125,
										formFieldCmc: false,
										xtype: columnObj.fldtype,
										fieldLabel: columnObj.text,
										//toolTipCmc: columnObj.tooltip || columnObj.text,
										itemId: columnObj.name,
										maxLength: columnObj.maxLength != undefined ? columnObj.maxLength : 100
									}
								});
							}
							if (columnObj.lookup) {
								Ext.define('copyComboModel'+i+j+win.paramObj.gridId, { /***Model for Combo***/
									extend: 'Ext.data.Model',
									"fields": [{
										"name": columnObj.lookup.valueField,
										"type": "string"
									}, {
										"name": columnObj.lookup.displayField,
										"type": "string"
									}]
								});
								
                         var comboJSONObj={
							fieldLabel: columnObj.text,
							toolTipCmc: columnObj.tooltip?	columnObj.tooltip: false	,
							//toolTipCmc: columnObj.tooltip || columnObj.text,
							xtype: 'cmccombobox',
							//width: columnObj.fieldWidth || 300,
							labelWidth: columnObj.labelWidth || 125,
							itemId: columnObj.name,
							copyField: true,
							formFieldCmc: false,
							queryMode: 'remote',
							valueField: columnObj.lookup.valueField,
							displayField: columnObj.lookup.valueField, //columnObj.lookup.displayField,
							validateUrlCmc: columnObj.lookup.validateUrl,
							params : columnObj.lookup.params,
							dependents: columnObj.dependents, // Array of dependets fields (names)
							dependsOn:columnObj.dependsOn,
							validateParamsCmc: [{
								'name': 'companyCode',
								'val': Modules.GlobalVars.selectedCompanyCode
							}],
							validateSuccessFuncCmc: function (serverRespOjbData) {
								return true;
							},
							storeObjCmc: {
								model: 'copyComboModel'+i+j+win.paramObj.gridId,
								url: columnObj.lookup.getUrl,
								extraParams : {'companyCode' : Modules.GlobalVars.selectedCompanyCode,
									'serviceTypeCode' : Modules.GlobalVars.selectedServiceTypeCode,
								    'userId' : Modules.GlobalVars.loginUserId},
							    listeners:{
								    	beforeload:function(){
								    		this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;;
								    		this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;

								    	}
								}
							},
							tpl: Ext.create('Ext.XTemplate',
									'<div class="lov-header"><li style="width: 150px;" class="lov-li">Code  </li><li class="lov-li"> Description </li></div>',
									'<tpl for=".">',
									'<div class="x-boundlist-item"><li style="width: 150px;" class="lov-li">{' + columnObj.lookup.valueField + '} </li><li class="lov-li"> {' + columnObj.lookup.displayField + '}</li></div>',
									'</tpl>')
						
	                    };
								
                         var combo = Ext.create('Ext.cmc.ComboBox',comboJSONObj );
							if (!Ext.isEmpty(combo.params)) {
								Ext.each(combo.params, function (item) {
									combo.store.proxy.extraParams[item['name']]=item['value'];
								});
								
							}
							
							
							if(columnObj.lookup.columnsCmc && Ext.isArray(columnObj.lookup.columnsCmc)){ 
								combo.prepareListTemplateCmc(columnObj.lookup.columnsCmc);
							}	
							
							
							if (!Ext.isEmpty(columnObj.dependsOn)) {
								combo.on('beforequery',function(queryEvent){
									var combo = queryEvent.combo;
									var field = getQueryForm.child('#copyFieldsetItemId').down("#"+Ext.Object.getKeys(combo.dependsOn)[0]);
									field && (combo.store.proxy.extraParams[Ext.Object.getKeys(combo.dependsOn)[0]] = field.getValue());
								});	
							}	
								
								copyFieldsetObj.add({
									xtype: 'container',
									labelSeparator: '',
									items: [combo]
								});
							}
						}
					}
				}
				getQueryForm.fireEvent('render', getQueryForm); // To load default search criteria
				Ext.getBody().unmask(); // Masked while adding master panel to main panel
				Ext.cmc.TabParentPanel.prototype.applyUserSecurity.call(win,win);
			}
		});
	},callEditorWindow : function(win, record, action) {
		var gridObj = win.child('#masterGrid');
		gridObj.getSelectionModel().select(record);
		
		var editWindowObj = Ext.create('Ext.cmc.GridPopUpWindow', {
			gridCompCmc:gridObj,
			width:900,
			title: win.title+' Details',
			editableCmc:(gridObj.down('#saveButtonId').isVisible()),//Set this to false if all the fields should be readOnly
			saveUrlCmc:win.getsaveUrl,//Put the URL for save here if the window will save data to server. If no URL specified then data will be saved to grid locally
			saveBtnHandlerFnCmc:function(){

				var editorWindow = this.ownerCt.ownerCt;
				var editForm = editorWindow.child('#gridPopUpWinFormItemId');
				var fields = editForm.getForm().getFields();

				var paramValues = {};
				Ext.each(fields.items,function(field){
					if(field.name != "displayfield")
						paramValues[field.name]=field.getValue();
				
				});
				
				
				
				var keys = Ext.Object.getKeys(paramValues);
			
				paramValues.trnsType = action; 
				paramValues.id = record.data.id;
				paramValues.companyCode = Modules.GlobalVars.selectedCompanyCode;
				paramValues.serviceTypeCode=Modules.GlobalVars.selectedServiceTypeCode;
				
				var dataArray = [];
				dataArray.push(paramValues);
				var jsonArray = Ext.JSON.encode(dataArray);
				
				var el= editorWindow.getEl();
	            el.mask('Saving ..');
				Ext.Ajax.request({
					url: win.getsaveUrl,
					method: 'POST',
					params: {
						state: jsonArray,
						gridId: win.paramObj.gridId,
						action: 'editWindow',
						companyCode: Modules.GlobalVars.selectedCompanyCode,
						serviceTypeCode : Modules.GlobalVars.selectedServiceTypeCode,
					    userId : Modules.GlobalVars.loginUserId,
						showAll: Modules.GlobalVars.maxLimitRecords
					},
					success: function (response) {
						var msg = Ext.decode(response.responseText);
						if (msg.success == true) {
							action = 'U'; //record.data.trnsType='U';
							if (msg.id) {
								record.data.id = msg.id;
							}
							el.unmask();
							//Redmine issue 14842 start
							editWindowObj.forceCloseCmc = true;
							editWindowObj.close();
						    gridObj.getStore().load();
							Ext.MessageBox.show({
								msg: 'Saved successfully',
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.INFO
							});
						} else {
							el.unmask();
							Ext.MessageBox.show({
								msg: msg.errors,
								buttons: Ext.MessageBox.OK,
								icon: Ext.MessageBox.ERROR
							});
						}
					}
				});
			},
			saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server if requried
			setFormItemsFuncCmc:function(){//This function should return the form items.
							


				itemsArray = [];
				var gridObj = win.child('#masterGrid');
				for (var i = 0; i < win.columnLength; i++) { /*******Setting the grid columns & editing fields dynamically according to the response***********/
					var columnObj = gridObj.getStore().proxy.reader.metaData.fields[i];
					if (columnObj.fldtype == "actioncolumn" || columnObj.fldtype == "rownumberer") {
						continue;
					}
					var getHidden;
					if (columnObj.fldhidden) {
						getHidden = true;
					} else {
						getHidden = false;
					}
					
					
					if (columnObj.allowBlank == undefined) columnObj.allowBlank = true;
					if (columnObj.fldtype == "cmctextfield" || columnObj.fldtype == 'cmcnumberfield') { /*******Setting the grid columns dynamically according to the response***********/
						var jsonObj1={
								width: columnObj.fieldWidth || 300,
								labelWidth: columnObj.labelWidth || 170,
								xtype: (columnObj.multiline ? 'textarea':columnObj.fldtype),
								hidden: getHidden,
								fieldLabel: columnObj.text,
								toolTipCmc: columnObj.tooltip ? columnObj.tooltip : false,
								name: columnObj.name,
								itemId : columnObj.name,
								allowBlank: columnObj.allowBlank,
								value: record.get(columnObj.name),
								itemId: columnObj.name,
								maxLength: columnObj.maxLength != undefined ? columnObj.maxLength : 100,
								//readOnly : true	
								//readOnly : (columnObj.readOnly != undefined && action != 'I') ?columnObj.readOnly:false,
								viewOnly : columnObj.viewOnly,
								maxLine : columnObj.maxLine,
								lowerCaseCmc:columnObj.lowerCaseCmc,
								//fieldStyle:columnObj.lowerCaseCmc ? ' ':'text-transform:uppercase',
								validator:function(){
									if(this.maxLine && !Ext.isEmpty(this.getValue()) && (this.getValue().split("\n")).length > this.maxLine){
										return "Maximun allowed line is 15";
									}
									return true;
								}
							};
						if(columnObj.mandatory){
							jsonObj1.afterLabelTextTpl=requiredField;
						}
						
						if (columnObj.fldtype == 'cmcnumberfield' && columnObj.type == 'float') {
							jsonObj1.forcePrecision=true;
							jsonObj1.decimalPrecision=columnObj.precision || 2;
						}
						
						if (columnObj.fldtype == 'cmcnumberfield' && columnObj.type == 'integer') {
							jsonObj1.allowNegative=false;
							jsonObj1.allowDecimals=false;
						}
						itemsArray.push({
							xtype: 'container',
							labelSeparator: '',
							columnWidth:.5,
							items: [jsonObj1]});
					}else if(columnObj.fldtype == "cmcdatefield"){
						var jsonObj1={
								width: columnObj.fieldWidth || 300,
								labelWidth: columnObj.labelWidth || 170,
								xtype: columnObj.fldtype,
								fieldLabel: columnObj.text,
								toolTipCmc: columnObj.tooltip ? columnObj.tooltip : false,	
								name: columnObj.name,
								itemId : columnObj.name,
								allowBlank: columnObj.allowBlank,
								value: record.get(columnObj.name),
								itemId: columnObj.name,
								maxLength: columnObj.maxLength != undefined ? columnObj.maxLength : 100,
								valuesAsStringCmc:true,
								viewOnly : columnObj.viewOnly
							//	readOnly : (columnObj.readOnly != undefined && action != 'I') ?columnObj.readOnly:false		
							};
						if(columnObj.mandatory){
							jsonObj1.afterLabelTextTpl=requiredField;
						}
						
						itemsArray.push({
							xtype: 'container',
							labelSeparator: '',
							columnWidth:.5,
							items: [jsonObj1]});
					}else if(columnObj.fldtype == "cmcdatetimefield"){ // written specific to Print and Email Log screen 
						var jsonObj1={  // ReadONly
								width: columnObj.fieldWidth || 300,
								labelWidth: columnObj.labelWidth || 170,
								xtype: 'cmcdatefield', //Need to change datetime
								hidden: getHidden,
								format: Modules.GlobalVars.dateTimeFormatGlobal,
								fieldLabel: columnObj.text,
								//toolTipCmc: columnObj.tooltip || columnObj.text,
								name: columnObj.name,
								itemId : columnObj.name,
								allowBlank: columnObj.allowBlank,
								value: record.get(columnObj.name),
								itemId: columnObj.name,
								maxLength: columnObj.maxLength != undefined ? columnObj.maxLength : 100,
								valuesAsStringCmc:true,
								viewOnly : columnObj.viewOnly
							//	readOnly : (columnObj.readOnly != undefined && action != 'I') ?columnObj.readOnly:false		
							};
						if(columnObj.mandatory){
							jsonObj1.afterLabelTextTpl=requiredField;
						}
						
						itemsArray.push({
							xtype: 'container',
							labelSeparator: '',
							columnWidth:.5,
							items: [jsonObj1]});
					}else if (columnObj.fldtype == "cmccheckboxfield") { /*******Setting the grid columns dynamically according to the response***********/
						
						itemsArray.push({
							xtype: 'container',
							labelSeparator: '',
							columnWidth:.5,
							items: [{
								width: columnObj.fieldWidth || 300,
								labelWidth: columnObj.labelWidth || 170,								
								xtype: columnObj.fldtype,
								hidden: getHidden,
								fieldLabel: columnObj.text,
								//toolTipCmc: columnObj.tooltip || columnObj.text,
								name: columnObj.name,
								itemId: columnObj.name,
								checked: record.get(columnObj.name),
								inputValue: 'true',
								allowBlank: true,
								viewOnly : columnObj.viewOnly
							}]}
						);
					} /*******Setting the grid columns dynamically according to the response***********/
					if (columnObj.lookup) { /*******Setting the editing fields dynamically according to the response***********/
						
						var modelFieldsArray = [{
							"name": columnObj.lookup.valueField,
							"type": "string"
						}, {
							"name": columnObj.lookup.displayField,
							"type": "string"
						}];
						
						if(Ext.isArray(columnObj.lookup.modelFields)){
							Ext.each(columnObj.lookup.modelFields,function(item){
								modelFieldsArray.push(item);
							});
						}
						Ext.define('comboModel'+win.paramObj.gridId, { 
							extend: 'Ext.data.Model',
							"fields": modelFieldsArray 
						});
						
				          var comboJSON={
									fieldLabel: columnObj.text,
									toolTipCmc: columnObj.tooltip ? columnObj.tooltip : false,		
									xtype: 'cmccombobox',
									width: columnObj.fieldWidth || 300,
									labelWidth: columnObj.labelWidth || 170,
									hidden: getHidden,
									name: columnObj.name,
									itemId: columnObj.name,
									valueField: columnObj.lookup.valueField,
									displayField: columnObj.lookup.valueField, //columnObj.lookup.displayField,
									validateUrlCmc: columnObj.lookup.validateUrl,
									params : columnObj.lookup.params,
									dependents: columnObj.dependents, // Array of dependets fields (names)
									dependsOn:columnObj.dependsOn,
									//readOnly : (columnObj.readOnly != undefined && action != 'I') ?columnObj.readOnly:false ,
									validateParamsCmc: [{
										'name': 'companyCode',
										'val': Modules.GlobalVars.selectedCompanyCode
									}],
									validateSuccessFuncCmc: function (serverRespOjbData) {
										return true;
									},
									validateFailFuncCmc:function(){
										var combo=this;
										if (!Ext.isEmpty(combo.dependents)) {
											Ext.each(combo.dependents, function (item) {
													var editForm = combo.ownerCt.ownerCt;
													if(typeof combo.dependents == "string"){
														var comp=editForm.down('#'+item);
														comp.setValue("");
														
													}else if(typeof combo.dependents == "object"){
														
														var keys=[];
														keys=Ext.Object.getKeys(item);
														for(var i=0;i<keys.length;i++){
															var comp=editForm.down('#'+item[keys[i]]);
															comp && comp.setValue("");
														}
													}
												},combo);
										}
										return true;
									},
									value: record.get(columnObj.name),
									storeObjCmc: {
										model: 'comboModel'+win.paramObj.gridId,
										url: columnObj.lookup.getUrl,
										extraParams : {'companyCode' : Modules.GlobalVars.selectedCompanyCode,
											'serviceTypeCode' : Modules.GlobalVars.selectedServiceTypeCode,
										    'userId' : Modules.GlobalVars.loginUserId},
										    listeners:{
										    	beforeload:function(){
										    		this.proxy.extraParams.companyCode = Modules.GlobalVars.selectedCompanyCode;
										    		this.proxy.extraParams.cmpnyCode = Modules.GlobalVars.selectedCompanyCode;

										    	}
										    }
									},
									tpl: Ext.create('Ext.XTemplate',
											'<div class="lov-header"><li style="width: 150px;" class="lov-li">Code  </li><li class="lov-li"> Description </li></div>',
											'<tpl for=".">',
											'<div class="x-boundlist-item"><li style="width: 150px;" class="lov-li">{' + columnObj.lookup.valueField + '} </li><li class="lov-li"> {' + columnObj.lookup.displayField + '}</li></div>',
											'</tpl>')
								};
						
						    if(columnObj.mandatory){
							 comboJSON.afterLabelTextTpl=requiredField;
							}
							
							var combo = Ext.create('Ext.cmc.ComboBox',comboJSON );
							
							if (!Ext.isEmpty(combo.params)) {
								Ext.each(combo.params, function (item) {
									
									combo.store.proxy.extraParams[item['name']]=item['value'];
								});
								
							}
							
							
							if(columnObj.lookup.columnsCmc && Ext.isArray(columnObj.lookup.columnsCmc)){ // Overrriding default Combo Model Fields
								combo.prepareListTemplateCmc(columnObj.lookup.columnsCmc);
							}	
							
							if (!Ext.isEmpty(columnObj.dependents)) {
								combo.on('select', function (comboObj, record, eOpts) {
									Ext.each(comboObj.dependents, function (item) {
										
										if(typeof item == 'string'){
											var editForm = comboObj.ownerCt.ownerCt;
											var comp=editForm.down('#'+item);
											comp && comp.setValue(record[0].data.name);
										}else if(typeof item == 'object'){
											var editForm = comboObj.ownerCt.ownerCt;
											var keys=[];
											keys=Ext.Object.getKeys(item);
											for(var i=0;i<keys.length;i++){
												var comp=editForm.down('#'+item[keys[i]]);
												comp && comp.setValue( record[0].data[keys[i]]);
											}
										}
			                    });
								
								}, combo);
								// To reset the dependents
								combo.on('change', function (comboObj, newValue, oldValue) {
									Ext.each(comboObj.dependents, function (item) {
										
										if(Ext.isEmpty(newValue)){
											var editForm=comboObj.ownerCt.ownerCt;
											if(typeof item == 'string'){
												var comp=editForm.down('#'+item);
												comp && comp.reset();
											}else if(typeof item == 'object'){
												var keys=[];
												keys=Ext.Object.getKeys(item);
												for(var i=0;i<keys.length;i++){
													var comp=editForm.down('#'+item[keys[i]]);
													comp && comp.reset();
												}
												
											}
										}
									});
									
								}, combo);
								
							}
							if (!Ext.isEmpty(columnObj.dependsOn)) {
								combo.on('beforequery',function(queryEvent){
									var combo = queryEvent.combo;
									var editForm=combo.up('window');
									var field = editForm.down('#'+combo.dependsOn[Ext.Object.getKeys(combo.dependsOn)[0]]);;
									field && (combo.store.proxy.extraParams[Ext.Object.getKeys(combo.dependsOn)[0]] = field.getValue());
								});	
							}
						itemsArray.push({
							xtype: 'container',
							labelSeparator: '',
							columnWidth:.5,
							items: [combo]
						});
					} 
				}
				return 	{
						xtype: 'form',
						itemId: 'editForm',
						layout: 'column',
						border:false,
						defaults: {
							margin: '0px 0px 2px 2px',
							labelSeparator: ' ',
							columnWidth: .5
						},
						bodyPadding: 5,
						items:itemsArray
					};
			},
			listeners:{
				recordloadedcmc:function(window,record){
					var editForm = window.down('#editForm');
					
					if(record.get('trnsType')=='I'){
						editForm.getForm().getFields().each(function(field){
							if(field.name && field.setReadOnly){
								if(field.viewOnly){
									field.setReadOnly(true);
								}else{
									field.setReadOnly(false);
								}
							}
						});
					}else{
						for (i = 0; i < win.getNotEditableFields.length; i++) {
							var component = editForm.down('#' + win.getNotEditableFields[i]);
							if (component != undefined && component != null && component.setReadOnly) {
								component.setReadOnly(true);
							}
						}
					}
				}
			}
		});
		
		
		return editWindowObj;
	},
	onConvert: function () {
		var gridModel = Ext.ModelManager.getModel('MetaModel'+this.paramObj.gridId);
		var len = gridModel.getFields().length;
		for (var j = 0; j < len; j++) {
			if (gridModel.getFields()[j].type.type == "bool") {
				gridModel.getFields()[j].convert = function (v) {
					return (v === "Y" || v === true) ? true : false;
				}
			}
		}
	},
	getColumnByDataIndex : function(dataIndex) {
		var gridColumns = this.child('#masterGrid').headerCt.getGridColumns();
		for ( var i = 0; i < gridColumns.length; i++) {
			if (gridColumns[i].dataIndex == dataIndex) {
				return gridColumns[i];
			}
		}
	},
	convertToDateFormat : function(record){
		for(var key in record){
			var val=record[key];
			if(val && Ext.isDate(val)){
				record[key]=Ext.Date.format(val,Modules.GlobalVars.dateFormatGlobal);
			}
		}
	}
	
});


function deleteSelectedRecords(win, gridObj, gridrecord, selRecLength) {
	var dataArray = [];
	for (var j = 0; j < selRecLength; j++) {
		if (gridrecord[j].get("trnsType") == 'I') {
			gridObj.getStore().remove(gridrecord[j]);
		} else {
			gridrecord[j].set("trnsType", "D");
			gridrecord[j].set("companyCode", Modules.GlobalVars.selectedCompanyCode);
			gridrecord[j].set("serviceTypeCode",Modules.GlobalVars.selectedServiceTypeCode);
			win.convertToDateFormat(gridrecord[j].data);
			dataArray.push(gridrecord[j].data);
			
		}
	}
	if (dataArray.length != 0) {
		var jsonArray = Ext.JSON.encode(dataArray);
		Ext.Ajax.request({
			url: win.getdeleteUrl,
			method: 'POST',
			params: {
				state: jsonArray,
				gridId: win.paramObj.gridId,
				companyCode: Modules.GlobalVars.selectedCompanyCode,
				serviceTypeCode : Modules.GlobalVars.selectedServiceTypeCode,
				userId : Modules.GlobalVars.loginUserId,
				action: 'delete'
			},
			success: function (response) {
				var msg = Ext.decode(response.responseText);
				if (msg.success == true) {
					for (var j = 0; j < selRecLength; j++) {
							gridObj.getStore().remove(gridrecord[j]);
					}
					gridObj.getStore().load();
					Ext.MessageBox.show({
						msg: 'Deleted successfully.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO
					});
				} else {
					Ext.MessageBox.show({
						msg: msg.errors,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO
					});
				}
			}
		});
	}
	
	function checkMandatoryFields(record){
		var emptyFields =[];
		Ext.each(record.fields.items,function(field){
			if(field.mandatory && Ext.isEmpty(record.get(field.name))){
				var column = this.getColumnByDataIndex(field.name);
				if(column.initialConfig.header){
					
					emptyFields.push(column.initialConfig.header.split('<')[0]);
				}
			}
		},this);
		return emptyFields.join(', ');
	}
	
}