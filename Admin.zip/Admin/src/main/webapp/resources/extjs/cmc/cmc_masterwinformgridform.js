Ext.define('Ext.cmc.MasterWinFormGridForm', {
					
	extend: 'Ext.window.Window',
	alias: 'widget.cmcmasterwinformgridform',
	
	height:500,
	width:700,
	layout:'border',
	onEsc:Ext.emptyFn,
	constrain:true,
	modal:true,
	autoScroll:true,
	
	showQueryFormCmc:true,
	
	addEditFormSaveBtnIdCmc:'',//This is the id which will be applied to the ok button
	addEditFormSaveBtnHandlerFuncCmc:function(){
		return true;
	},
	addEditFormbtnCntrMarginCmc:'',//This is the margin which will be applied to the button container
	
	clearBtnObjCmc:{
		handler:function(){
			return true;
		}
	},
	
	retrieveBtnObjCmc:{
		handler:function(){
			return true;
		}
	},
	
	deleteBtnObjCmc:{
		handler:function(){
			return true;
		}
	},
	
	winFuncArgObjCmc:'',//This will hold the arguments object passed to this window
	
	//Following will hold the values of different server side urls
	addEditSaveUrlCmc:'',
	deleteUrlCmc:'',
	
	intYdTmnlNoIdCmc:'',//This is used to hold the id of combobox of termincal code which if required is sent with when submitting add/edit form. If its not required to send terminal code number then it can be ignored
	
	addEditDisabledFieldsCmc:'',//This should be an array having keys/names of those fields which will be disabled at the time of edit
	//addEditSaveParamsCmc:'',//This should be an object carrying the parameters to be sent when saving the record
	
	initComponent:function(){
		var me		=		this;
		me.__setTbarFuncCmc();//Calling this function for setting TBar
		me.__setItemsFuncCmc();//Calling this function for setting the Items
		me.callParent();//No arguments passed as per the docs in API
		me.on('afterrender', me.afterRenderMasterWinFormGridFormFuncCmc);//Associating a function with the event
	},
	
	__setTbarFuncCmc:function(){

		var me		=		this;
		
		me.tbar		=		[];//Setting TBar to an empty array	
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.clearBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getClearAction(me.__getClearBtnConfigFuncCmc());
		}
		
		//Checking below for each button if that is to be displayed and adding it to the toolbar
		if(me.retrieveBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getRetrieveAction(me.__getRetrieveBtnConfigFuncCmc());
		}
		
		me.tbar[me.tbar.length]	=	'->';//This line has been added to create the space after Retrieve button
		
		if(me.showExtraTbarCmc){
			var extraTbar		=		me.setExtraTbarFuncCmc(me.winFuncArgObjCmc);
			//Checking below if the returned value is an array or not and appeding it to tbar only if its an array
			if(extraTbar && extraTbar.length && extraTbar instanceof Array && Object.prototype.toString.call(extraTbar) === '[object Array]'){
				me.tbar			=		me.tbar.concat(extraTbar);
			}
		}
		
		if(me.deleteBtnObjCmc.handler){
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getDeleteAction(me.__getDeleteBtnConfigFuncCmc());
		}
		
		/* if(me.modal){//Exit button is shown if the window is modal even if showExitButtonCmc is set to false
			var exitBtnObj		=		{
				handler:function(){
					me.close();
				}
			};
			me.tbar[me.tbar.length]		=	Modules.GlobalFuncs.getExitAction(exitBtnObj);
		} */
		
		if(!me.tbar.length){
			delete me.tbar;//Deleting the tbar if no buttons have been added so far
		}			
	},
	
	//Following function can be used to set the extra buttons in the tbar
	setExtraTbarFuncCmc:function(winFuncArgObjCmc){
		//This function will carry the code of buttons specific to the window
		//This function should return an array of button definitions including the spacers if required
		/*
			Example:
			[
				{
					text:'Report'
					handler:function(){}
				},
				{
					text:'Copy To All',
					handler:function(){}
				},
				'->'//Use only if the buttons need to be in the center of window's tbar
			]
		*/
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the clear butotn
	__getClearBtnConfigFuncCmc:function(){
		var me								=		this;
		var btnConfig						=		{};
		Ext.apply(btnConfig, me.clearBtnObjCmc);
		btnConfig.copyHandlerFunc			=		me.clearBtnObjCmc.handler;
		btnConfig.handler					=		function(){							
			if(me.showQueryFormCmc){
				me.getComponent('queryFormItemId').getForm().reset();
			}			
			me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').getStore().removeAll();
			me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm().reset();
			if(me.intYdTmnlNoIdCmc && Ext.getCmp(me.intYdTmnlNoIdCmc)){
				Ext.getCmp(me.intYdTmnlNoIdCmc).setDisabled(false);
			}
			Modules.GlobalFuncs.dsableEnableFormFields({
				formPanel:me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId'),
				setDisabledVal:false
			});
			var res		=		btnConfig.copyHandlerFunc();
			return res;
		}
		return btnConfig;
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the clear butotn
	__getRetrieveBtnConfigFuncCmc:function(){
		var me								=		this;
		var btnConfig						=		{};
		Ext.apply(btnConfig, me.retrieveBtnObjCmc);
		btnConfig.copyHandlerFunc			=		me.retrieveBtnObjCmc.handler;
		btnConfig.handler					=		function(){							
			//checking below if the form is invalid
			if(me.showQueryFormCmc && !me.getComponent('queryFormItemId').getForm().isValid()){
				Ext.MessageBox.show({
					title: Modules.Msgs.inValidFormTitle,
					msg: Modules.Msgs.inValidFormMsg,
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}
			//Calling the instance handler here
			var res		=		btnConfig.copyHandlerFunc();
			if(!res && typeof res=='boolean'){
				return res;
			}
			
			//Loading the first page of the grid
			me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').getStore().loadPage(1, {
				//params:me.showQueryFormCmc?me.getComponent('queryFormItemId').getForm().getValues():{},
				callback:function(records, operation, success){
					if(me.intYdTmnlNoIdCmc && Ext.getCmp(me.intYdTmnlNoIdCmc)){
						Ext.getCmp(me.intYdTmnlNoIdCmc).setDisabled(true);
					}
				}
			});
			return true;
		}
		return btnConfig;
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the save butotn
	__getDeleteBtnConfigFuncCmc:function(){
		var me			=		this;
		var btnConfig						=		{};
		Ext.apply(btnConfig, me.deleteBtnObjCmc);
		btnConfig.copyHandlerFunc			=		me.deleteBtnObjCmc.handler;
		btnConfig.handler					=		function(){		
			var resInstanceHandler	=			btnConfig.copyHandlerFunc();
			if(!resInstanceHandler){
				return false;
			}
			var argObj		=		{
				url:me.deleteUrlCmc
			};
			me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').deleteGridRecFuncCmc(argObj);
			me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm().reset();
		}		
		return btnConfig;
	},
	
	//This function will be overriden in the instance and is expected to return form config
	setQueryFormFuncCmc:function(){
	
	},
	
	//Following function will not be overridden in the instance. It will return the final config for the parent form
	__getQueryFormConfigFuncCmc:function(){
	
		var me					=		this;
		var formConfig			=		{
			xtype:'cmcform',
			region:'north',
			itemId:'queryFormItemId',
			showFieldsetCmc: true,
			collapsible:true
		};
		var instanceFormConfig	=		me.setQueryFormFuncCmc(me.winFuncArgObjCmc);
		Ext.applyIf(formConfig, instanceFormConfig);
		if(!formConfig.height){
			formConfig.height	=		100;
		}
		if(!formConfig.width){
			formConfig.width	=		me.width-50;
		}
		return formConfig;
	},
	
	//This function will be overridden in the instance and will return a grid config object
	setGridFuncCmc:function(){
	
	},
	
	//Following function should not be overridden by instance. It will return the proccessed grid config
	__getGridConfigFuncCmc:function(){
		var me			=		this;
		var gridConfig	=		{
			xtype:'cmcgrid',
			region:'center',
			itemId:'gridItemId',
			showSelModelCmc:true,
			selModelModeCmc:'MULTI',
			showPagingBarCmc:true
		};
		var instanceGridConfig	=		me.setGridFuncCmc(me.winFuncArgObjCmc);
		Ext.applyIf(gridConfig, instanceGridConfig);
		
		//Beginning the code for appending beforeload listeners to grid store
		gridConfig.storeObjCmc.listeners	=		gridConfig.storeObjCmc.listeners?gridConfig.storeObjCmc.listeners:{};
		var instanceBeforeLoadFunc			=		gridConfig.storeObjCmc.listeners.beforeload?gridConfig.storeObjCmc.listeners.beforeload:'';
		gridConfig.storeObjCmc.listeners.beforeload		=		function(){
			if(instanceBeforeLoadFunc){
				instanceBeforeLoadFunc();
			}
			//checking below if the form is invalid
			if(me.showQueryFormCmc && !me.getComponent('queryFormItemId').getForm().isValid()){
				Ext.MessageBox.show({
					title: Modules.Msgs.inValidFormTitle,
					msg: Modules.Msgs.inValidFormMsg,
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
				return false;
			}
			
			me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').getStore().proxy.extraParams	=	me.showQueryFormCmc?me.getComponent('queryFormItemId').getForm().getValues():{};
			
			return true;
		}
		//Ending the code for appending beforeload listeners to grid store
		
		//Following function is used to take care of selection change event
		function selectionChangeFunc(model, records){
			if (records[0]) {
				me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm().loadRecord(records[0]);
				me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').activeRecord = records[0];
			}
			if(me.addEditDisabledFieldsCmc && me.addEditDisabledFieldsCmc.length && me.addEditDisabledFieldsCmc instanceof Array && Object.prototype.toString.call(me.addEditDisabledFieldsCmc) === '[object Array]'){
				Modules.GlobalFuncs.dsableEnableFormFields({
					formPanel:me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId'),
					excludeArr:me.addEditDisabledFieldsCmc,
					setDisabledVal:false
				});
			}
		}	
		if(gridConfig.listeners){
			gridConfig.listeners.selectionchange	=		selectionChangeFunc;			
		}else{
			gridConfig.listeners					=		{};
			gridConfig.listeners.selectionchange	=		selectionChangeFunc;
		}
		return gridConfig;
	},
	
	//This function will be overridden in the instance and will return child form config
	setAddEditFormFuncCmc:function(){
		
	},
	
	//Following function should not be overridden in instance. It will return the final child form config
	__getAddEditFormConfigFuncCmc:function(){		
		
		var me					=		this;
		
		var formConfig			=		{
			xtype:'cmcform',
			region:'east',
			itemId:'addEditFormItemId',
			showFieldsetCmc: true,
			collapsible:true,
			activeRecord:''//this will hold the reference to the currently active/last-selected record in grid
		};
		
		var instanceConfig		=		me.setAddEditFormFuncCmc(me.winFuncArgObjCmc);
		
		Ext.applyIf(formConfig, instanceConfig);
		
		if(!formConfig.width){
			formConfig.width	=		200;
		}
		
		formConfig.setFormItemsFuncCmc	=	function(){
			
			var itemsArr		=		instanceConfig.setFormItemsFuncCmc(me.winFuncArgObjCmc);
			if(!itemsArr){
				itemsArr		=		[];
			}
			
			var saveBtnMargin		=		me.addEditFormbtnCntrMarginCmc?me.addEditFormbtnCntrMarginCmc:'10px 0px 0px 10px';
			var saveBtnId			=		(me.addEditFormSaveBtnIdCmc)?me.addEditFormSaveBtnIdCmc:'';
						
			var trnsTypeObj	=		{
				xtype:'cmchiddenfield',
				name:'trnsType',
				itemId:'trnsTypeItemId',
				value:'I'
			};
			
			var containerObj	=	{
				xtype:'container',
				layout:'hbox',
				/* border:1,
				style: {borderColor:'#FF0000', borderStyle:'solid', borderWidth:'1px'}, */
				margin:saveBtnMargin,
				items:[
					{
						xtype:'cmcbutton',
						text:'SAVE',
						width:60,
						handler:function(){
						
							var addEditFormObj		=		me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm();
						
							if(!addEditFormObj.isValid()){
								Ext.MessageBox.show({
									title: Modules.Msgs.inValidFormTitle,
									msg: Modules.Msgs.inValidFormMsg,
									buttons: Ext.MessageBox.OK,
									icon: Ext.MessageBox.ERROR
								});
								return false;
							}
							//Checking below if trmnl number has to be sent
							if(me.intYdTmnlNoIdCmc){
								if(!Ext.getCmp(me.intYdTmnlNoIdCmc)){
									if(Modules.GlobalVars.distributionEnv){
										alert('No terminal code combobox created at invoice master screen');
									}
									return false;
								}
								var tmnlObj		=		Ext.getCmp(me.intYdTmnlNoIdCmc);
								if(!tmnlObj.getValue() || !tmnlObj.fieldValidCmc){
									Ext.MessageBox.show({
										title: Modules.Msgs.inValidFormTitle,
										msg: 'Please provide the value of terminal code',
										buttons: Ext.MessageBox.OK,
										icon: Ext.MessageBox.ERROR,
										fn:function(){
											tmnlObj.focus()
										}
									});
									return false;
								}
							}
							
							//Calling below the handler passed by the instance
							var result		=		me.addEditFormSaveBtnHandlerFuncCmc(me.winFuncArgObjCmc);
							if(!result){
								return result;
							}							
							var trnsTypeObj			=	me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').query('#trnsTypeItemId')[0];
							if(trnsTypeObj.getValue()!='I'){
								trnsTypeObj.setValue('U');
							}
							me.el.mask(Modules.Msgs.saving);
							addEditFormObj.submit({
								url:me.addEditSaveUrlCmc,
								params:(me.intYdTmnlNoIdCmc)?{intYdTmnlNo:Ext.getCmp(me.intYdTmnlNoIdCmc).getValue()}:{},
								success:function(form, action){
									
									var respObj		=		Ext.JSON.decode(action.response.responseText);
									if(respObj.success){
										Ext.MessageBox.show({
											title: 'Save Successful',
											msg: 'Record saved successfully',
											buttons: Ext.MessageBox.OK, 
											icon:Ext.MessageBox.INFO
										});
										if(trnsTypeObj.getValue()=='I'){
											//On success, forcefully setting the record trnsType to be true so that is updated every next time
											trnsTypeObj.setValue('U');											
											var storeObj		=		me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').getStore();
											var newRec			=		Ext.create(storeObj.model, {});
											storeObj.insert(0, newRec);
											me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').activeRecord = newRec;
										}
										addEditFormObj.updateRecord(me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').activeRecord);
										me.getComponent('gridAddEditFormPanelItemId').getComponent('gridItemId').getStore().commitChanges();
									}else{
										Ext.MessageBox.show({
											title: 'Save Failed',
											msg: respObj.errors,
											buttons: Ext.MessageBox.OK,
											icon: Ext.MessageBox.ERROR
										});
									}	
									me.el.unmask();
								},
								failure:function(form, action){
									Modules.GlobalFuncs.displayFormErrors({
										form:form,
										responseText:action.response.responseText
									});										
									me.el.unmask();
								}
							});
						}
					},
					{
						xtype:'cmcbutton',
						text:'NEW',
						width:60,
						margin:'0px 0px 0px 10px',
						handler:function(){
							var addEditFormObj		=		me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm();
							addEditFormObj.reset();
							Modules.GlobalFuncs.dsableEnableFormFields({
								formPanel:me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId'),
								setDisabledVal:false
							});
						}
					},
					{
						xtype:'cmcbutton',
						text:'CANCEL',
						width:60,
						margin:'0px 0px 0px 10px',
						handler:function(){
							var addEditFormObj		=		me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId').getForm();
							addEditFormObj.reset();
							Modules.GlobalFuncs.dsableEnableFormFields({
								formPanel:me.getComponent('gridAddEditFormPanelItemId').getComponent('addEditFormItemId'),
								setDisabledVal:false
							});
						}
					}
				]
			};
			itemsArr[itemsArr.length]		=		containerObj;
			itemsArr[itemsArr.length]		=		trnsTypeObj;
			return itemsArr;
		}						
		return formConfig;
	},
	
	//Following function should not be overridden in instance. It will return the child panel config
	__getGridAddEditFormPanelConfigFuncCmc:function(){
		var me			=	this;
		var panelConfig	=	{
			xtype:'cmcpanel',
			closable:false,
			region:'center',
			layout:'border',
			itemId:'gridAddEditFormPanelItemId',
			items:[
				me.__getAddEditFormConfigFuncCmc(),
				me.__getGridConfigFuncCmc()
			]
		};
		return panelConfig;
	},//EOF __getGridAddEditFormPanelConfigFuncCmc
	
	__setItemsFuncCmc:function(){
		var me			=		this;
		me.items		=		[];
		if(me.showQueryFormCmc){
			me.items[0]		=		me.__getQueryFormConfigFuncCmc();
			me.items[1]		=		me.__getGridAddEditFormPanelConfigFuncCmc();		
		}else{
			me.items[0]		=		me.__getGridAddEditFormPanelConfigFuncCmc();		
		}
	},		
	
	afterRenderMasterWinFormGridFormFuncCmc:function(){
		Ext.getBody().unmask();
	}
});