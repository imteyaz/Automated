Ext.define('Ext.cmc.CheckboxField', {
   
	extend: 'Ext.form.field.Checkbox',
	alias: 'widget.cmccheckboxfield',
    
	/***Beginning the config properties which already exist in the component**/
    labelAlign:'right',
	/***Ending the config properties which already exist in the component**/
	
	initComponent:function(){
		var me	=	this;
		
		if(me.fieldLabel){
			me.boxLabel = me.fieldLabel;
			delete me.fieldLabel;
		}
		me.on('beforerender',me.beforeRenderFuncCmc);
		me.callParent();//No arguments passed as per the docs in API		
	},
	allowBlank:true,
	beforeRenderFuncCmc:function(){
		var me		=		this;
		if(!me.allowBlank)
			me.labelStyle = 'color:#ff0000';	
	}
});

