/*
	*Following file contains more than one version of the extended component of textfield
	*The main version is un-commented and thus can be used
	*Other versions are also working and are different ways of implementation of same thing
*/

Ext.define('Ext.cmc.Textfield', {
   
	extend: 'Ext.form.field.Text',//Extending the TextField
	
	alias: 'widget.cmctextfield',//Defining the xtype
	
	/*Beginning of assigning values to already existing config options*/
	focusCls:'focusClass',//Providing value for existing config property
	//fieldStyle:'text-transform:uppercase',
	maxHeight:25,
	labelAlign:'left',	
	/*Ending of assigning values to already existing config options*/
	
	/*Beginning the adding of new config properties below*/
	legendCmc:false,//This is created to manage the backgrond class
	lowerCaseCmc:true,//This is created to manage the displaying of input values in lowercase if required
	/*Ending the adding of new config properties below*/
	toolTipCmc :false,//Tooltip: String
	initComponent:function(){
		var me	=	this;
		me.on('beforerender', me.beforeRenderFuncCmc);
		
		if(me.toolTipCmc){
			me.on('render', function(c) {
				Ext.QuickTips.register({
					target: c.labelEl,
					text:me.toolTipCmc,
					maxWidth : 10000
				  });
				});
		}
		
		if(me.inputType != 'password'){
			
			if(!me.lowerCaseCmc){
				me.fieldStyle='text-transform:uppercase';
			}
			
			me.on('render',function(c) {
				Ext.create('Ext.tip.ToolTip', {
					target: c.inputEl,
					html: c.value,
					maxWidth : 10000,
					listeners: {
						beforeshow: function(tip) {
							
							if(Ext.isEmpty(c.getValue()) || (c.getValue().length < 10)){
								return false;
							}
							tip.update(c.getValue());
						}
					}					
				});
			});
		}
		
		//me.on('change', me.onChangeFuncCmc);//Associating a new defined method with an event
		me.callParent();//No arguments passed as per the docs in API		
	},
	
	
	//Defining a method below and associating this with an event in the constructor above
	beforeRenderFuncCmc:function(){
		var me		=		this;
		if(!me.allowBlank){
			me.labelStyle	=	'color:#000000';		
		}
		
		if(me.readOnly){
			if(!me.legendCmc){
				me.fieldCls	=	'readOnlyClsCmc';
			}
			me.focusCls		=	'';
			me.submitValue	=	false;
		}
	},
	
	/*Following function is used to move things to uppercase as user types in the value in field*/
	/* onChangeFuncCmc:function(){
		var me		=		this;
		if(me.inputType!='password' && !me.lowerCaseCmc && me.getValue()){
			me.setValue(me.getValue().toUpperCase());
		}		
	}, */
	
	/**Following function is used to convert the value to uppercase before returning the value**/
	getValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
		val = (val && me.inputType!='password' && !me.lowerCaseCmc)?val.toUpperCase():val;
		
//		val = (val && me.inputType!='password' && !me.lowerCaseCmc)?val:val;
		
		if(val){
			val = me.trimValue(val); //val.trim();
			
		}
		
		return val;
		/* var valUpperCase	=	val.toUpperCase();
		return valUpperCase; */
	},
	
	/**Following function is used to convert the value to uppercase before returning the value when the form is submitted**/
	getSubmitValue:function(){
		var me	=	this;
		var val	=	me.callParent(arguments);
        val = (val && me.inputType!='password' && !me.lowerCaseCmc)?val.toUpperCase():val;
        if(val){
			val =  me.trimValue(val); // val.trim();
		}
		
		return val;
		//return (val && me.inputType!='password' && !me.lowerCaseCmc)?val.toUpperCase().trim():val; // Added trim() to remove space at both end of input field value
		/* var valUpperCase	=	val.toUpperCase();
		return valUpperCase; */
	},
	setReadOnly : function(val){
		Ext.form.field.Text.prototype.setReadOnly.call(this,val);
		if(val){
			Ext.form.field.Text.prototype.setFieldStyle.call(this,'background:#C7C9BE;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.Textfield.prototype.fieldStyle+';');
         }else{
        	 Ext.form.field.Text.prototype.setFieldStyle.call(this,'background:#FFFFFF;color: black;font: 12px tahoma,arial,verdana,sans-serif;margin: 0;'+Ext.cmc.Textfield.prototype.fieldStyle+';');
         }
	},
	trimValue : function(val){
		var trimmedVal = Ext.String.trim(val);
		return trimmedVal ;
	}
});


/* 
//Version 2
Ext.define('Ext.cmc.Textfield', {
   
	extend: 'Ext.form.field.Text',
	alias: 'widget.cmctextfield',
    
    initComponent: function() {
	
		var config = {
			focusCls:'focusClassFieldPnC'//Ensure that this class is defined in the CSS file
			,fieldCls:'baseClassFieldPnC'
			,labelStyle:'color:#ff0000'
		};
 
        Ext.apply(this, Ext.apply(this.initialConfig, config));
		Ext.cmc.Textfield.superclass.initComponent.apply(this, arguments);
    }
}); 

//Version 3
Ext.define('Ext.cmc.Textfield', {
   
	extend: 'Ext.form.field.Text',
	
	alias: 'widget.cmctextfield',
	
	config:{
		//All the following properties already exist in the textfield class so no need to define them in config and call constructor
		focusCls:'',
		fieldCls:'baseClassFieldPnC',
		labelStyle:'color:#ff0000',
		testConfig:'test'
	},

	initComponent:function(){
		this.callParent();
		//this.on('focus',this.onFocus);
		this.on('beforerender',this.beforeRender);
	},
	
	afterRender:function(){
		alert('am i there??');
		this.callParent();
	},
	
	beforeRender:function(){
		alert('I am beforerender');
		if(!this.allowBlank)
			this.focusCls = 'focusClassFieldPnC';
		//this.callParent();
	},
	
	onFocus:function(){
		alert('I have been focussed');
		//alert(this.getFieldCls());
		this.fieldCls = '';
		alert(this.fieldCls);
		this.callParent();
		this.doLayout();
	}
    
});*/