/*
	*Following file contains more than one version of the extended entity component of combobox
	*This file Give The Default Value Of VOA Combo Model 
	*Use for COA
		*Use Store
			var coaStoreObj = {
				url: 'lookup/getctroprs'
			};
	*and In ComboBox use this
		fieldLabel:Modules.LblsAndTtls.coaLbl,
		storeObjCmc: coaStoreObj,
		validateParamsCmc:[{name:'cstmrCd', id:Modules.CompIds.CoaId}],
		validateUrlCmc: 'lookup/validatectroprs',
*/
Ext.define('Ext.cmc.entityCombos.CstmrComboBox', {
   
	extend: 'Ext.cmc.ComboBox',//Extending the TextField
	alias: 'widget.cmccstmrcombobox',//Defining the xtype
	
	/**Beginning the setting of values for already existing configs**/
	fieldLabel:Modules.LblsAndTtls.voaLbl,
	displayField:'cstmrCd',
	valueField:'cstmrCd',
	matchFieldWidth:false,
	listConfig: {
		width:250,
		loadingText: 'Loading...',
		height:100,
		deferEmptyText:false,
		emptyText:'No Values Found!',
		getInnerTpl: function() {
			return '<table><tr><td colspan="2" height="5"></td></tr><tr valign="top"><td width="40px">{cstmrCd}</td><td>{cstmrNm}</td></tr><tr><td height="5" colspan="2"></td></tr></table>';
		}
	},
	validateUrlCmc:'lookup/validatevslagents',
	storeObjCmc:{},
	//validateParamsCmc:{},
	validateParamsCmc:[],
	validateSuccessFuncCmc:function(serverRespOjbData){
		return true;
	},
	validateFailFuncCmc:function(){
		return true;
	}, 
	/**Ending the setting of values for already existing configs**/

	initComponent:function(){
		var me	=	this; 
		if(!me.storeObjCmc.model){
			me.storeObjCmc.model		=		'CstmerDtlsComboModel';
		}
		if(!me.storeObjCmc.url){
			me.storeObjCmc.url			=		'lookup/vslagents';
		}
		me.storeObjCmc.paging			=		true; 
		me.callParent();//No arguments passed as per the docs in API		
	}
});