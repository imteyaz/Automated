/**
	**Following component has been extended to be used for editor window of grid
**/
Ext.define('Ext.cmc.GridPopUpWindow',{

	extend: 'Ext.window.Window',
	alias: 'widget.cmcgridpopupwindow',
	constrain:true,
	autoScroll:true,
	modal:true,
	border:false,
	layout:'fit',
	
	gridCompCmc:'',//This will carry the comopnent of the grid at which the window was invoked
	editableCmc:true,//Set this to false in order to disable all the fields and have a non-editable pop-up window
	saveUrlCmc:'',//Specify this value if the window is editable and data should save at server. If value is not specified then data gets saved at grid
	saveOrDoneBtnValidateHandlerFuncCmc:'',//This should be a function specified in instance. It will be called in save or done button handler and will be used for instance specific validations. It should return true or false for sure
	saveExtraParamsCmc:'',//This can be an object provided by instance having the key:val pairs to be sent at the time of save to server
	saveSuccessFuncCmc:'',//This is the function to be executed at the time of save success, note it would not be done at the time of 'done' button
	saveFailFuncCmc:'',//This is the function to be executed at the time of save fail, note that it would not executed at the time of 'done' button
	curRecStoreIndexCmc:0,//This is used to store the index of currently displaying record in the pop-up window
	saveBtnHandlerFnCmc:undefined,//This will hold the arguments object passed to this window
	winFuncArgObjCmc:{},//This will hold the arguments object passed to this window
	formHeightCmc:undefined,
	forceCloseCmc:false,// Need not to alert for modification
	accessCode: undefined,
	enableNavigationBarCmc:true,// Set to false if next/previous buttons are not needed
	initComponent:function(){
		var me		=		this;
		
		//Applying User Security in QUERY MODE
		var panel=me.gridCompCmc.up('cmctabparentpanel');
		if(panel == undefined){ // Applying security for master framework screens only
		   panel=me.gridCompCmc.up('cmcmasterwindow');
		}
		if(panel){
			me.accessCode=panel._accessCode;
		}
		me.width	=		(me.width && me.width<=900)?me.width:900;
		me.items	=		[me.__getFormFuncCmc()];
		if(me.editableCmc){
			me.tbar	=		me.__getTopButtonsCmc();
		}
		me.addEvents('recordloadedcmc');
		me.on('afterrender', me.afterRenderFuncGridEditorWinCmc);//Calling function before parent so that form gets loaded
		me.on('beforeclose', me.beforeCloseFuncCmc);//Associating a function with the event
		me.callParent();
	},
	//Following function should be instantiated by the object. Function should return an array of items
	setFormItemsFuncCmc:function(){},
	//Following function is used to get the navigation bar at the bottom
	__getNavBarConfigFuncCmc:function(){
		var me				=		this;
		var bBarBtnsArr		=		[];
		var firstBtn		=		{
			xtype:'cmcbutton',
			itemId:'firstBtnGridPopUpWinItemId',
//			text:'First',
			iconCls: 'grid-paging-first',
			disabled:true,
			handler:function(){
				me.__navBarBtnsFuncCmc({btnClicked:'first'});
				return true;
			}
		};
		var previousBtn		=		{
			xtype:'cmcbutton',
			itemId:'previousBtnGridPopUpWinItemId',
//			text:'Previous',
			iconCls: 'grid-paging-prev',
			disabled:true,
			handler:function(){
				me.__navBarBtnsFuncCmc({btnClicked:'previous'});
				return true;
			}
		};
		var nextBtn			=		{
			xtype:'cmcbutton',
			itemId:'nextBtnGridPopUpWinItemId',
//			text:'Next',
			iconCls: 'grid-paging-next',
			disabled:true,
			handler:function(){
				me.__navBarBtnsFuncCmc({btnClicked:'next'});
				return true;
			}
		};
		var lastBtn			=		{
			xtype:'cmcbutton',
			itemId:'lastBtnGridPopUpWinItemId',
//			text:'Last',
			iconCls: 'grid-paging-last',
			disabled:true,
			handler:function(){
				me.__navBarBtnsFuncCmc({btnClicked:'last'});
				return true;
			}
		};
		var dispalyInfo		=		{
			xtype: 'displayfield',
			itemId: 'displayFieldGridPopUpWinItemId',
			name : 'displayfield',
			labelWidth: 100
		};
		bBarBtnsArr[0]		=		firstBtn;
		bBarBtnsArr[1]		=		previousBtn;
		bBarBtnsArr[2]		=		nextBtn;
		bBarBtnsArr[3]		=		lastBtn;
		bBarBtnsArr[4]		=		'->';
		bBarBtnsArr[5]		=		dispalyInfo;
		return bBarBtnsArr;
	},
	//Following function is used to the form config
	__getFormFuncCmc:function(){
		var me				=		this;		
		var formConfig		=		{
			xtype:'cmcform',
			itemId:'gridPopUpWinFormItemId',
			width:me.width-5,
			height:me.formHeightCmc,
			setFormItemsFuncCmc:function(){
				var formItems		=		me.setFormItemsFuncCmc(me.winFuncArgObjCmc);//Getting the items from the instance
				var trnsTypeObj		=		{
					xtype:'cmchiddenfield',
					name:'transType',
					itemId:'trnsTypeGridPopUpItemId'
				};
				if(Ext.isArray(formItems)){
					
					formItems[formItems.length]	=	trnsTypeObj;
					return formItems;
				}else{
					return [formItems,trnsTypeObj];
				}
			},
			bbar: me.enableNavigationBarCmc ? me.__getNavBarConfigFuncCmc() : undefined
		};
		if(!me.editableCmc){//If the window is not editable then setting all as readOnly below
			formConfig.fieldDefaults	=		{
				readOnly:true
			};
		}
		return formConfig;//Returning the form config
	},
	//Following function will return the tbar array for window if the window is editable
	__getTopButtonsCmc:function(){
		var me			=		this;
		var btnArr		=		[];
		btnArr[0]		=		'->';
		var btnConfig	=		{
			xtype:'cmcbutton',
			hidden:!me.editableCmc,
			itemId:'saveButton',
			iconCls : "submit",
			text:(me.editableCmc && me.saveUrlCmc)?'Save':'Submit'
		};
		if(me.saveBtnConfigCmc){
			Ext.apply(btnConfig,me.saveBtnConfigCmc);
		}
		btnConfig.handler	= me.saveBtnHandlerFnCmc	||	function(){
			var formPanel	=		me.getComponent('gridPopUpWinFormItemId');
			var formObj		=		formPanel.getForm();
			if(formPanel.isDirtyCmc()){//Executing the following code only if the form has been modified
				if(!formObj.isValid()){
					Ext.MessageBox.show({
						title: 'Invalid values',
						msg: 'Please correct the highlighted errors',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
					return false;
				}
				if(me.saveOrDoneBtnValidateHandlerFuncCmc && typeof me.saveOrDoneBtnValidateHandlerFuncCmc=='function'){
					var res		=		me.saveOrDoneBtnValidateHandlerFuncCmc();
					if(!res){
						return false;
					}
				}
				if(me.editableCmc && me.saveUrlCmc){
					formObj.submit({
						url:me.saveUrlCmc,
						params:(me.saveExtraParamsCmc && Ext.isObject(me.saveExtraParamsCmc))?me.saveExtraParamsCmc:{},
						success:function(form, action){
							var respObj		=		Ext.JSON.decode(action.responseText);
							if(me.saveSuccessFuncCmc && typeof me.saveSuccessFuncCmc=='function'){
								var res		=		me.saveSuccessFuncCmc(respObj);
								if(!res){
									return false;
								}
							}
							//var gridSelRec	=		me.gridCompCmc.getSelectionModel().getLastSelected();//Getting the last selected record 
							//formObj.updateRecord(gridSelRec);//Updating to grid
							formObj.updateRecord(formObj.getRecord());//Updating to grid
							me.forceCloseCmc=true; // Close grid popup window automatically after clicking on save 
							me.close();            //  
						},
						failure:function(){
							if(me.saveFailFuncCmc && typeof me.saveFailFuncCmc=='function'){
								var res		=		me.saveFailFuncCmc();
								if(!res){
									return false;
								}
							}
						}
					});	
				}else{
					//var gridSelRec	=		me.gridCompCmc.getSelectionModel().getLastSelected();//Getting the last selected record 
					//formObj.updateRecord(gridSelRec);//Updating to grid
					if(Ext.isDefined(formObj.getRecord().data.transType) && formObj.getRecord().get('transType') != 'I'){//add by Ram, before check the transType verifing whether it exist or not. !Ext.isEmpty(formObj.getRecord().get('transType')) && 
						formPanel.down('#trnsTypeGridPopUpItemId').setValue('U');
					}
					formObj.updateRecord(formObj.getRecord());//Updating to grid
					
					if(me.gridCompCmc && me.gridCompCmc && me.gridCompCmc.getPlugin('editorPlugin')){
						var eventObj = {column:{},
										grid :me.gridCompCmc,
										record:formObj.getRecord()};
						
						me.gridCompCmc.getPlugin('editorPlugin').fireEvent('edit',me.gridCompCmc.getPlugin('editorPlugin'),eventObj);
					}
					me.forceCloseCmc=true; // // Close grid popup window automatically after clicking on submit button 
					me.close();
				}
			}else{
				me.forceCloseCmc=true; // // Close grid popup window automatically after clicking on submit button 
				me.close();
				return true;
			}			
		}
		btnArr[1]			=		btnConfig;
		return btnArr;
	},
	//Following function takes care of updating the navigation bar details and buttons. It takes argument as an object with key as button clicked. It is not to be overridden by the instance
	__navBarBtnsFuncCmc:function(argObj){
		var me				=		this;
		var formPanel		=		me.getComponent('gridPopUpWinFormItemId');
		var formObj			=		formPanel.getForm();

		if(me.editableCmc && formPanel.isDirtyCmc()){
			//Following dialog box seeks confirmation of the user before carrying out delete task
			Ext.MessageBox.confirm('Form values modified', 'You had modified the form values which will be lost if not saved.<br />Do you wish to continue without saving?', function(btn){
				if(btn!='yes'){//Checking if the user pressed YES button
					return false;
				}else{
					operations();
				}
			});
		}else{
			operations();
		}
		
		function operations(){
			var btnClicked		=		(argObj && argObj.btnClicked)?argObj.btnClicked:'common';//Common behaviour would mean updating the entire bar in general
			var firstBtn		=		me.query('#firstBtnGridPopUpWinItemId')[0];
			var prevBtn			=		me.query('#previousBtnGridPopUpWinItemId')[0];
			var nexttBtn		=		me.query('#nextBtnGridPopUpWinItemId')[0];
			var lastBtn			=		me.query('#lastBtnGridPopUpWinItemId')[0];
			var displayObj		=		me.query('#displayFieldGridPopUpWinItemId')[0];
			switch(btnClicked){
				case 'first':
					me.curRecStoreIndexCmc		=		0;
				break;
				case 'previous':
					me.curRecStoreIndexCmc		=		me.curRecStoreIndexCmc-1;
				break;
				case 'next':
					me.curRecStoreIndexCmc		=		me.curRecStoreIndexCmc+1;
				break;
				case 'last':
					me.curRecStoreIndexCmc		=		me.gridCompCmc.getStore().getCount()-1;
				break;			
			}
			var displayInfo			=	'Displaying Record '+(me.curRecStoreIndexCmc+1)+' of '+me.gridCompCmc.getStore().getCount();		
			displayObj.setValue(displayInfo);
			var record = me.gridCompCmc.getStore().getAt(me.curRecStoreIndexCmc);
			formPanel.loadRecord(record);
			me.fireEvent('recordloadedcmc',me,record);
			me.applyDeniedMenuPreviligeFuncCmc(record);
			if (me.gridCompCmc.getStore().getCount() > 1) {
				if (me.curRecStoreIndexCmc == 0) {
					firstBtn.setDisabled(true);
					prevBtn.setDisabled(true);
					nexttBtn.setDisabled(false);
					lastBtn.setDisabled(false);
				} else if (me.curRecStoreIndexCmc == me.gridCompCmc.getStore()
						.getCount() - 1) {
					firstBtn.setDisabled(false);
					prevBtn.setDisabled(false);
					nexttBtn.setDisabled(true);
					lastBtn.setDisabled(true);
				} else {
					firstBtn.setDisabled(false);
					prevBtn.setDisabled(false);
					nexttBtn.setDisabled(false);
					lastBtn.setDisabled(false);
				}
			}
			return true;
		}//EOF
	},//EOF
	//Following function is called afterrender and is used to load the form with the selected grid record
	afterRenderFuncGridEditorWinCmc:function(){
		var me					=		this;
		var formObj				=		me.getComponent('gridPopUpWinFormItemId').getForm();
		var gridSelRec			=		me.gridCompCmc.getSelectionModel().getLastSelected();//Getting the last selected record 
		me.curRecStoreIndexCmc	=		me.gridCompCmc.getStore().indexOf(gridSelRec);
		me.enableNavigationBarCmc && me.__navBarBtnsFuncCmc();
		Ext.getBody().unmask();		
	}//EOF afterRenderFuncGridEditorWinCmc
	,
	beforeCloseFuncCmc:function(){
		if(this.forceCloseCmc) return true;// Close anyways
		
		var me =this;
		var form = this.down('form');
		
		if(Ext.isEmpty(form)){
			form = this.down('cmcform');
		}
		if(me.editableCmc && form.isDirtyCmc()){
			Ext.MessageBox.confirm(Modules.Msgs.confirmTitle, Modules.Msgs.saveRecordConfirmation, function (answer) {
                if (answer == "yes") {
                	me.forceCloseCmc=true;
                	me.close();                     
                }
            });
			return false;
		}
	},
	applyDeniedMenuPreviligeFuncCmc:function(record){
		var me =this;
		// Applying Denied Menu functinality for Edit PopUP
		var readOnlyFields=false;
		//var accessCode=1;
		var tabParentPanel=me.gridCompCmc.up('cmctabparentpanel');
		if(tabParentPanel == undefined){ // Applying security for master framework screens only
			var masterPanel=me.gridCompCmc.up('cmcmasterwindow');
			if(masterPanel){
				//accessCode=masterPanel._accessCode;
				if(record.data.trnsType ){
					if(record.data.trnsType == 'I'){
						readOnlyFields=false;
					}else{
						readOnlyFields=true;
					}
				}else{
					readOnlyFields=true;
				}
				
			}
			
		}
		
		if(tabParentPanel){ // Applying security for All Transactional Screens
			//accessCode=tabParentPanel._accessCode;
			var arr=['U','u','E','e','Q','',null];
			if(record.data.trnsType !== undefined){
				 for(var i=0; i<arr.length; i++) {
				        if (arr[i] === record.data.trnsType) {
				        	readOnlyFields=true;
				        	break;
				        }
				    }
			}else if(record.data.transType !== undefined){
				 for(var i=0; i<arr.length; i++) {
				        if (arr[i] === record.data.transType) {
				        	readOnlyFields=true;
				        	break;
				        }
				    }
			}else if(record.data.status !== undefined){
				 for(var i=0; i<arr.length; i++) {
				        if (arr[i] === record.data.status) {
				        	readOnlyFields=true;
				        	break;
				        }
				    }
			}
			
		}
		
		var submitButton=me.down('#saveButton');
		if(submitButton){
			if((readOnlyFields && me.accessCode && me.accessCode == 3)  || (me.accessCode && me.accessCode == 4)){
				submitButton.setVisible(false);
				me.child('#gridPopUpWinFormItemId').getForm().getFields().each(function(field,index,len){
					if(field && field.setReadOnly){
						field.setReadOnly(true);
					}
					return true;
				});
				
			}else{
				submitButton.setVisible(true);
			}
		}
	}
});