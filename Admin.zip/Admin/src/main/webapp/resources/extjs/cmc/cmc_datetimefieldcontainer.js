/*
	*Following file contains more than one version of the extended component of date time field container
*/
Ext.define('Ext.cmc.DateTimeFieldContainer', {
   
	extend: 'Ext.form.FieldContainer',//Extending the Field Container
	
	alias: 'widget.cmcdatetimefieldcontainer',//Defining the xtype
	
	/*Beginning of assigning values to already existing config options*/
	focusCls:'focusClass',//Providing value for existing config property
	layout:'hbox',
	/*Ending of assigning values to already existing config options*/
	
	/*Beginning the adding of new config properties below*/
	dateFieldWidth:100,	
	timeFieldWidth:65,	
	dateFieldFlex:'',	
	timeFieldFlex:'',
	dateTimeFieldMargin:'0px 0px 0px 5px',	
	dateFieldNm:'',	
	timeFieldNm:'',	
	dateFieldDefaultVal:'',	
	timeFieldDefaultVal:'',
	allowBlank:true,
	labelAlign:'right',
	readOnlyCmc:false,
	disabledCmc:false,
	/*Ending the adding of new config properties below*/
	
	initComponent:function(){
		var me	=	this;
		me.items	=		[];
		me.items[0]	=		me.getDateObj();
		me.items[1]	=		me.getTimeObj();
		me.on('beforerender', me.beforeRenderFuncCmc);
		me.callParent();//No arguments passed as per the docs in API		
	},	
	
	//Defining a method below and associating this with an event in the constructor above
	beforeRenderFuncCmc:function(){
		var me		=		this;
		if(!me.allowBlank){
			me.labelStyle	=	'color:#FF0000';		
		}
	},
	
	getDateObj:function(){		
		var me		=		this;
		var dateObj	=		{
			xtype: 'cmcdatefield',
			itemId:'dateFieldItemId',
			focusCls: me.focusCls,
			readOnly:me.readOnlyCmc,
			disabled:me.disabledCmc,
			allowBlank: me.allowBlank,
			width: me.dateFieldWidth?me.dateFieldWidth:90,
			format: (Modules.GlobalVars.dateFormatGlobal)?Modules.GlobalVars.dateFormatGlobal:'d-M-Y'
		};
		if(me.dateFieldNm){
			dateObj.name		=		me.dateFieldNm;
		}
		if(me.dateFieldDefaultVal){
			dateObj.value		=		me.dateFieldDefaultVal;
		}
		if(me.dateFieldFlex){
			dateObj.flex		=		me.dateFieldFlex;
		}
		if(me.listeners){
			dateObj.listeners	=		me.listeners;
		}
		return dateObj;
	},
	
	getTimeObj:function(){		
		var me		=		this;
		var timeObj	=		{
			xtype: 'cmctimefield',
			itemId:'timeFieldItemId',
			focusCls: me.focusCls,
			readOnly:me.readOnlyCmc,
			disabled:me.disabledCmc,
			//allowBlank: me.allowBlank,
			width: me.timeFieldWidth?me.timeFieldWidth:65,
			format: (Modules.GlobalVars.timeFormatGlobal)?Modules.GlobalVars.timeFormatGlobal:'H:i',
			margins:me.dateTimeFieldMargin
		};
		if(me.timeFieldNm){
			timeObj.name		=		me.timeFieldNm;
		}
		if(me.timeFieldDefaultVal){
			timeObj.value		=		me.timeFieldDefaultVal;
		}
		if(me.timeFieldFlex){
			timeObj.flex		=		me.timeFieldFlex;
		}
		if(me.listeners){
			timeObj.listeners	=		me.listeners;
		}		
		return timeObj;
	},
	/**
		**Following function is used to set the values in date time fields
		**It expects an object as argument with following keys:
			**stringVal:this should hold the value in string data type with proper format like - 15-08-2012 12:12
			**objVal:this should hold the value in date object format
		**The function first checks if stringVal is present and uses it to populate the values, but if its not present then it checks for objVal and uses it to populate the values
		**If operation is a success then it returns true else false
	**/
	setValueFuncCmc:function(argObj){
		var me					=		this;
		var finalVal			=		true;
		if(argObj.stringVal && argObj.stringVal.split){
			dateTimeFieldArr	=		argObj.stringVal.split(' ');
			if(dateTimeFieldArr.length){
				if(dateTimeFieldArr[0]){
					me.getComponent('dateFieldItemId').setRawValue(dateTimeFieldArr[0]);
				}
				if(dateTimeFieldArr[1]){
					me.getComponent('timeFieldItemId').setRawValue(dateTimeFieldArr[1]);
				}
			}
		}else if(argObj.objVal && argObj.objVal instanceof Date){
			var dateVal		=		Ext.Date.format(argObj.objVal, Modules.GlobalVars.dateFormatGlobal);
			me.getComponent('dateFieldItemId').setRawValue(dateVal);
			var timeVal		=		Ext.Date.format(argObj.objVal, Modules.GlobalVars.timeFormatGlobal);
			me.getComponent('timeFieldItemId').setRawValue(timeVal);
		}
		return finalVal;
	},//EOF
	
	/**
		**Following function is used to get the value of date time field container
		**It expects an object as argument with one key as following:
			**type:this should be string if value is expected in string and it should be object if value is expected in date object. Default value is string
		**Function returns null if value could not be calculated or does not exist
	**/
	getValueFuncCmc:function(argObj){
		
		var me			=		this;
		var finalVal	=		'';
		var type		=		'string';
		if(argObj && argObj.type){
			type		=		argObj.type;
		}
		var dateObj		=		me.getComponent('dateFieldItemId');
		var timeObj		=		me.getComponent('timeFieldItemId');
		if(type=='string'){
			var dateRawVal		=		dateObj.getRawValue();
			var timeRawVal		=		timeObj.getRawValue()?timeObj.getRawValue():'00'+Modules.GlobalVars.timeSeparator+'00';
			finalVal			=		dateRawVal?dateRawVal:'';
			finalVal			=		finalVal?(finalVal+' '+timeRawVal):'';
		}else if(type=='object'){
			var dateVal			=		dateObj.getValue();
			var timeVal			=		timeObj.getValue();
			var year			=		(dateVal && dateVal.getFullYear())?dateVal.getFullYear():'';
			var month			=		(dateVal && dateVal.getMonth())?dateVal.getMonth():'';
			var date			=		(dateVal && dateVal.getDate())?dateVal.getDate():'';
			var hour			=		(timeVal && timeVal.getHours())?timeVal.getHours():'';
			var minutes			=		(timeVal && timeVal.getMinutes())?timeVal.getMinutes():'';
			finalVal			=		new Date(year, month, date, hour, minutes);
		}		
		return finalVal;		
	},//EOF
	//Following function is used to mark components invalid
	//It expects argument as an object with key as message
	markInvalidFuncCmc:function(argObj){
		var me		=		this;
		me.getComponent('dateFieldItemId').markInvalid((argObj && argObj.msg)?argObj.msg:'Invalid Value');
		me.getComponent('timeFieldItemId').markInvalid((argObj && argObj.msg)?argObj.msg:'Invalid Value');
	},//EOF
	
	clearInvalidFuncCmc:function(){
		var me		=		this;
		me.getComponent('dateFieldItemId').clearInvalid();
		me.getComponent('timeFieldItemId').clearInvalid();
	}//EOF	
});