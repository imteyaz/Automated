Ext.define('Ext.cmc.RadioField', {

	extend: 'Ext.form.field.Radio',
	alias: 'widget.cmcradiofield',
	initComponent:function(){
		var me	=	this;

		if(me.fieldLabel){
			me.boxLabel = me.fieldLabel;
			delete me.fieldLabel;
		}
	}
});

