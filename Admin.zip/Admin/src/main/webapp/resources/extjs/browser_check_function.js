/*$$$$$$$$$$$$$$$$$$$$$$$$   Variables to be added in labels_titles.js    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
Modules.LblsAndTtls.browserNotificationTtl	=	'Browser Notification'; 
Modules.LblsAndTtls.versionTtl				=	'Version';
Modules.LblsAndTtls.standardsTtl			=	'Standards';

/*$$$$$$$$$$$$$$$$$$$$$$$$   Variables to be added in messages.js    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
Modules.Msgs.browserListMsg				    =	'Application supports Mozilla 4+, Chrome 10+, IE8 (with Document Mode IE8 Standards), IE9 (with Document Mode IE9 Standards)<br /><br />For best experience, recommended browser is Chrome 10+';
Modules.Msgs.yourBrowserMsg				    =	'Your Browser is ';
Modules.Msgs.yourBrowserVerAppearMsg	    =	'Your Browser version is appearing to be '; 
Modules.Msgs.ieBrowserCmptbltyMdMsg2	    =	'But if your IE version is higher than 7 then it could be running in Compatibility Mode<br /><br />Please change Browser Mode to exact version of your browser in order to run the application';
Modules.Msgs.ieBrowserCmptbltyMdMsg1	    =	' which is not supported by the application'; 
Modules.Msgs.ieBrowserSetToStandards	    =	' Standards in order to run the application';
Modules.Msgs.ieBrowserDocModeMsg1		    =	'But its Document Mode is set to Quirks';
Modules.Msgs.ieBrowserDocModeMsg2		    =	'But its Document Mode is currently not set to ';
Modules.Msgs.ieBrowserDocModeMsg3		    =	'Please change Document Mode of your browser to ';
Modules.Msgs.ieBrowserDocModeMsg4		    =	'For more Details on Browser & Document Mode and how to change them, <a href="http://blogs.msdn.com/b/ie/archive/2010/10/19/testing-sites-with-browser-mode-vs-doc-mode.aspx" target="_blank">please click here</a>';
Modules.Msgs.browserFrmListOnlyMsg		    =	'Please use a browser only from the list specified above'; 

/*$$$$$$$$$$$$$$$$$$$$$$$$   Function to be added in functions.js    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
/**
	**Following function is used to check if the user's browser is one among those supported or not
	**If the user's current browser is not supported then this functions alerts by displaying appropriate message and returns false
**/
Modules.GlobalFuncs.checkBrowser	=	function(){

	var browser		=		'';
	var browserVer	=		'';
	
	if(Ext.isChrome){
		browser		=		'Chrome';
		browserVer	=		Ext.chromeVersion;
		if(Ext.chromeVersion<10){
			Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.browserListMsg+'<br /><br />'+Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer);
			Modules.GlobalVars.showPageUnloadMsg	=	false;
			return false;
		}
	}
	
	if(Ext.isGecko){
		browser		=		'Mozilla Firefox';
		browserVer	=		Ext.firefoxVersion;
		if(Ext.firefoxVersion<4){
			Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.browserListMsg+'<br /><br />'+Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer);
			return false;
		}
	}
	
	if(Ext.isIE){
		browser				=		'IE';
		browserVer			=		Ext.ieVersion;
		var documentMode	=		document.documentMode;
		
		if(Ext.ieVersion<8){		
			Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.yourBrowserVerAppearMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer+Modules.Msgs.ieBrowserCmptbltyMdMsg1+'<br /><br />'+Modules.Msgs.ieBrowserCmptbltyMdMsg2+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg4+'<br /><br />'+Modules.Msgs.browserListMsg);
			return false;
		}else if(documentMode && documentMode==5){		
			Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg1+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg3+browser+' '+browserVer+Modules.Msgs.ieBrowserSetToStandards+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg4+'<br /><br />'+Modules.Msgs.browserListMsg);
			return false;
		}else if(documentMode && documentMode<8){
			Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg2+browser+' '+browserVer+' '+Modules.LblsAndTtls.standardsTtl+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg3+browser+' '+browserVer+Modules.Msgs.ieBrowserSetToStandards+'<br /><br />'+Modules.Msgs.ieBrowserDocModeMsg4+'<br /><br />'+Modules.Msgs.browserListMsg);
			return false;
		}
	}
	
	if(Ext.isOpera){
		browser		=		'Opera';
		browserVer	=		Ext.operaVersion;
		Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.browserListMsg+'<br /><br />'+Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer);
		return false;
	}
	
	if(Ext.isSafari){
		browser		=		'Safari';
		browserVer	=		Ext.safariVersion;
		Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.browserListMsg+'<br /><br />'+Modules.Msgs.yourBrowserMsg+browser+' '+Modules.LblsAndTtls.versionTtl+' '+browserVer);
		return false;
	}
	
	if((!browser) || (!browserVer)){
		Ext.Msg.alert(Modules.LblsAndTtls.browserNotificationTtl, Modules.Msgs.browserListMsg+'<br /><br />'+Modules.Msgs.browserFrmListOnlyMsg);
		return false;
	}
	
	return true;
}//EOF

