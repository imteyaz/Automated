package com.minapro.communicationServer.db;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ValueObject holding the role details.
 * @author 3128828
 *
 */
@Entity

@Table(name="MP_GRPDTLS_AM")
public class UserRole 
{
	@Id
	@Column(name="INT_USER_GRP_ID", nullable=false)
	private int role_id;
	
	@Column(name="USER_GRP_NM", nullable=false)
	private String role_name;
	
	@Column(name="S_DESCR")	
	private String description;
	/*
	@Column(name="equipment_type_id")
	private String equipment_type_id;*/
	
	public int getRole_id() {
		return role_id;
	}

	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}

	public String getRole_name() {
		return role_name;
	}

	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
 
	public String getdescription() {
		return description;
	}
	
	public void setdescription(String description) {
		this.description = description;
	}
	
	/*public String equipment_type_id() {
		return equipment_type_id;
	}
	
	public void setequipment_type_id(String equipment_type_id) {
		this.equipment_type_id = equipment_type_id;
	}*/
}
