package com.minapro.communicationServer.common;

public class VersionDetailsEvent {

	//Indicates the ipAddreess of the device
	private String Address;
	
	//holds the unique identifier for the message
	private String eventId;
	
	//holds the current application version running on the device
	private String versionNumber;
	
	//Indicates the Application which is running on the device - Can be QC, CHE, HC or ITV
	private String role;
	
	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}	

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "VersionDetailsEvent [Address=" + Address + ", eventId=" + eventId
				+ ", versionNumber=" + versionNumber + ", role=" + role + "]";
	}
}
