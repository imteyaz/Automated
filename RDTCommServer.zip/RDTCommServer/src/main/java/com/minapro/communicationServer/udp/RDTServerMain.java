package com.minapro.communicationServer.udp;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import scala.concurrent.duration.Duration;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Cancellable;
import akka.actor.Props;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;
import com.minapro.communicationServer.actors.RDTCommServerMasterActor;
import com.minapro.communicationServer.actors.UserTablePollerActor;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.response.RDTResponseListener;

/**
 * RDTServerMain reads RDTCommServer.properties, Pre-fetch the User table from Database,Initiates threads and
 * MasterActor System.
 * 
 * @author 3128828 version 1.0
 * 
 */
public class RDTServerMain {
	public static int UDPSOCKETRANGE = 0; // define the socket range
	public static int SERVERPORT; // Port on which RDT server listens for Events
	public static int ACKPORT; // Port on which RDT server listens for Ack's
	public static int QC_DEVICEPORT; // Port to which RDT server sends Responses
	public static int QC_NOTIFICATIONPORT;
	public static int ITV_DEVICEPORT; // Port to which RDT server sends Responses
	public static int ITV_NOTIFICATIONPORT;
	public static int CHE_DEVICEPORT; // Port to which RDT server sends Responses
	public static int CHE_NOTIFICATIONPORT;
	public static int MAN_DEVICEPORT; // Port to which RDT server sends Responses
	public static int MAN_NOTIFICATIONPORT;
	public static int NOOFRESPRETRIES = 0; // No. of retries for the responses
	public static String SPLITLARGEPACKETS;
	public static boolean SPLITPACKETS;
	public static int UDPPACKETSIZE;
	public static String DELIMITER; // Message separator
	public static String LOGIN; // Login event type
	public static String LOGOUT; // Logout event type
	public static String LOGFAILURE;
	public static int USER_TABLE_POLLING;
	public static String VERSION_ALERT_NOTIF;
	public static String VERSION_EVENT;

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTServerMain.class);
	private static ActorSystem RDTCommActorSystem; // RDT Communication Server
													// Actor System
	private static ActorRef RDTCommMasterActor; // RDT Communication Server
												// Master Actor

	private static Cancellable cancellable;

	private static final RDTServerMain instance = new RDTServerMain();

	/**
	 * Provides the RDTServerMain instance
	 * 
	 * @return RDTServerMain
	 */
	public static RDTServerMain getInstance() {
		return instance;
	}

	/**
	 * This is the main method which makes use of initializeDataBase and init methods.
	 * 
	 * @param args
	 *            Unused.
	 * @return Nothing.
	 * @exception IOException
	 *                On input error.
	 * @see IOException
	 */
	public static void main(String[] args) throws IOException {

		logger.logMsg(LOG_LEVEL.DEBUG, "", "Starting RDT Communication Server");
		RDTServerMain rDTServerMain = RDTServerMain.getInstance();

		Properties prop = new Properties();

		InputStream inpStream = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("RDTCommServer.properties");
		prop.load(inpStream);
		RDTServerMain.SERVERPORT = new Integer(prop.getProperty("SERVERPORT"));
		RDTServerMain.ACKPORT = new Integer(prop.getProperty("ACKPORT"));
		RDTServerMain.QC_DEVICEPORT = new Integer(prop.getProperty("QC_DEVICEPORT"));
		RDTServerMain.QC_NOTIFICATIONPORT = new Integer(prop.getProperty("QC_NOTIFICATIONPORT"));
		RDTServerMain.ITV_DEVICEPORT = new Integer(prop.getProperty("ITV_DEVICEPORT"));
		RDTServerMain.ITV_NOTIFICATIONPORT = new Integer(prop.getProperty("ITV_NOTIFICATIONPORT"));
		RDTServerMain.CHE_DEVICEPORT = new Integer(prop.getProperty("CHE_DEVICEPORT"));
		RDTServerMain.CHE_NOTIFICATIONPORT = new Integer(prop.getProperty("CHE_NOTIFICATIONPORT"));
		RDTServerMain.MAN_DEVICEPORT = new Integer(prop.getProperty("MAN_DEVICEPORT"));
		RDTServerMain.MAN_NOTIFICATIONPORT = new Integer(prop.getProperty("MAN_NOTIFICATIONPORT"));
		RDTServerMain.NOOFRESPRETRIES = new Integer(prop.getProperty("NOOFRESPRETRIES"));
		RDTServerMain.SPLITLARGEPACKETS = prop.getProperty("SPLITLARGEPACKETS");
		RDTServerMain.UDPPACKETSIZE = new Integer(prop.getProperty("UDPPACKETSIZE"));
		RDTServerMain.DELIMITER = prop.getProperty("DELIMITER");
		RDTServerMain.LOGIN = prop.getProperty("LOGIN");
		RDTServerMain.LOGOUT = prop.getProperty("LOGOUT");
		RDTServerMain.LOGFAILURE = prop.getProperty("LOGFAILURE");
		RDTServerMain.VERSION_EVENT = prop.getProperty("VERSION_EVENT");
		RDTServerMain.VERSION_ALERT_NOTIF = prop.getProperty("VERSION_ALERT_NOTIF");
		RDTServerMain.USER_TABLE_POLLING = new Integer(prop.getProperty("USER_TABLE_POLLING"));

		logger.logMsg(LOG_LEVEL.DEBUG, "", "Completed Reading RDTCommServer.properties");

		rDTServerMain.init();
	}

	/**
	 * Initialize MasterActorSystem and threads
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */

	public void init() {
		 
		// Populate User to IP map cache for all currently logged in users
		HibernateSession.deleteDeviceMapEntries();

		// Initializing Master actor
		RDTCommActorSystem = ActorSystem.create("RDTCommServer");
		RDTCommMasterActor = RDTCommActorSystem.actorOf(Props.create(RDTCommServerMasterActor.class), "RDTCommMaster");

		// AKKA Scheduler to read the User Table from DB for every configurable USER_TABLE_POLLING Sec

		ActorRef userTablePollActor = RDTCommActorSystem.actorOf(Props.create(UserTablePollerActor.class),
				"userTablePoller");
		if ((cancellable == null) || cancellable.isCancelled() == true) {

			cancellable = RDTCommActorSystem.scheduler().schedule(Duration.create(1, TimeUnit.SECONDS),
					Duration.create(USER_TABLE_POLLING, TimeUnit.SECONDS), userTablePollActor, "User Table Scheduler",
					RDTCommActorSystem.dispatcher(), userTablePollActor);

		}

		/*
		 * RDTRequestHandler will opens a UDP socket and listen for Events from Devices
		 */
		RDTRequestHandler rdtReceiver = new RDTRequestHandler();
		rdtReceiver.start();

		/*
		 * RDTCommAckHandler will opens a UDP socket and listen for Ack's from Devices
		 */
		RDTCommAckHandler ackReceiver = new RDTCommAckHandler();
		ackReceiver.start();

		/*
		 * ResposeHandler will send the response to devices until it's success
		 */
		RDTResponseHandler respSender = new RDTResponseHandler();
		respSender.start();

		/*
		 * RDTResponseListener will listen for responses on user specific Que's
		 */
		RDTResponseListener respListener = new RDTResponseListener();
		respListener.start();
	}

	/**
	 * Retrieves the Master actor instance
	 * 
	 * @return ActorRef
	 */
	public static ActorRef getMasterActor() {
		return RDTCommMasterActor;
	}
}
