package com.minapro.communicationServer.common;

/**
 * Class responsible for decrypting password along with incoming salt and iv from login request
 * 
 * @author 3128828 version 1.0
 * 
 */

public class PasswordDecryption {
	
    int iterationCount = 1000 ;
    int keySize = 128; 
    String salt;
    String ciphertext;
    String iv;
    
    
    
    private static final PasswordDecryption instance = new PasswordDecryption();
    
   private PasswordDecryption() {

	}

	/**
	 * Gives the instance of PasswordDecryption
	 * 
	 * @return
	 */
	public static PasswordDecryption getInstance() {
		return instance;
	}

	/**
	 * Returns Decrypted password
	 *  
	 * @param keySize, iterationCount, salt, iv, ciphertext
	 * @return String.
	 */
public String decrptedPassowrd(int keySize, int iterationCount,String salt,String iv, String ciphertext ){
	   
		String passphrase = "2cmc0MERGES1tcs5" ;
		AesUtil aesUtil = new AesUtil(keySize, iterationCount);
        String plaintext = aesUtil.decrypt(salt, iv, passphrase, ciphertext);
	   
	   return plaintext; 
   }

}
