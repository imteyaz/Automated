package com.minapro.communicationServer.common;

import org.infinispan.Cache;

import com.minapro.communicationServer.db.OPERATOR;
import com.minapro.communicationServer.db.User;

/**
 * Initializes caches and defines get,put and remove methods for all caches
 * 
 * @author 3128828 version 1.0
 * 
 */

public class RDTCacheManager {

    public Cache<String, String> RDTConfigparams = RDTCacheContainer.getCache("RDTConfigCache"); // Config parameters
                                                                                                 // Cache

    public Cache<Integer, Integer> UDPSocketsInUse = RDTCacheContainer.getCache("SocketsCache"); // No. of Open sockets

    public Cache<String, ActiveMessage> MinaproActiveResponseList = RDTCacheContainer.getCache("ResponseCache"); // List of
                                                                                                          // Active
                                                                                                          // Responses

    public Cache<String, String> UserIdAddressmapping = RDTCacheContainer.getCache("UsermapCache"); // UserId with IP
                                                                                                    // Address Mapping
                                                                                                    // Cache

    public Cache<String, Integer> MinaproResponseRetiriesCache = RDTCacheContainer.getCache("ResponseRetriesCache"); // List
                                                                                                                     // of
                                                                                                                     // retried
                                                                                                                     // responses

    public Cache<String, User> userCache = RDTCacheContainer.getCache("UserInformationCache"); // Users info cache

    public Cache<String, String[]> eventMergerCache = RDTCacheContainer.getCache("eventMergerCache"); // Event Merger
                                                                                                      // cache

    public Cache<String, Integer> packetCountCache = RDTCacheContainer.getCache("pktCountCache"); // Event Merger cache

    public Cache<String, String> ackToResponseCache = RDTCacheContainer.getCache("ackToResponseMapCache");

    public Cache<String, String[]> tokensCache = RDTCacheContainer.getCache("eventIDToTokensCache");

    public Cache<String, String> userToRequestCache = RDTCacheContainer.getCache("userToRequestCache");

    /**
     * Indicates the user's logged in role - userId is the key
     */
    private Cache<String, String> loggedInUserRoleMap = RDTCacheContainer.getCache("LoggedInUserRoleMap");
    
    /**
     * Device to User mapping - DeviceId is the key
     */
    private Cache<String, String> deviceToUserMapping = RDTCacheContainer.getCache("DeviceToUserMappingCache");
    
    /**
     * User to Device mapping - userID is the key
     */
    private Cache<String, String> userToDeviceMapping = RDTCacheContainer.getCache("UserToDeviceMappingCache");
    

    private static final RDTCacheManager instance = new RDTCacheManager();

    private RDTCacheManager() {
    }

    /**
     * Gives the instance of RDTCacheManager
     * 
     * @return
     */
    public static RDTCacheManager getInstance() {
        return instance;
    }

    /**
     * Retrieves the role the user has logged in as
     * 
     * @param userId
     * @return OPERATOR
     */
    public OPERATOR gerUserLoggedInRole(String userId) {
        String operator = loggedInUserRoleMap.get(userId);
        
        if (operator == null) {
			return OPERATOR.COMMON;
		}
        
        if ("QC".equalsIgnoreCase(operator)) {
            return OPERATOR.QC;
        } else if ("ITV".equalsIgnoreCase(operator)) {
            return OPERATOR.ITV;
        } else if (operator.startsWith("RMG") || operator.startsWith("RTG") || "CHE".equalsIgnoreCase(operator)) {
            return OPERATOR.CHE;
        } else if ("FOREMAN".equalsIgnoreCase(operator)) {
            return OPERATOR.FOREMAN;
        } else if ("HC".equalsIgnoreCase(operator)) {
            return OPERATOR.HC;
        } else if ("VSUP".equalsIgnoreCase(operator)) {
            return OPERATOR.VSUP;
        } else if ("GSUP".equalsIgnoreCase(operator)) {
            return OPERATOR.GSUP;
        } else if ("YSUP".equalsIgnoreCase(operator)) {
            return OPERATOR.YSUP;
        } else if("TSC".equals(operator)){
            return OPERATOR.TSC;
        } else {
            return OPERATOR.COMMON;
        }

    }

    /**
     * Saves the users currenlt logged in role
     * 
     * @param userId
     * @param role
     */
    public void setUserLoggedInRole(String userId, String role) {
        loggedInUserRoleMap.put(userId, role);
    }

    // ResponseCache

    /**
     * Returns the existence of entry in ResponseCache
     * 
     * @param responseMsg
     * @return boolean
     */
    public boolean checkActiveResponseEntry(String responseMsg) {
        return MinaproActiveResponseList.containsKey(responseMsg);
    }

    /**
     * Add entry to the ResponseCache
     * 
     * @param response
     * @param deviecIP
     */
    public void addActiveResponsepEntry(String response, String deviceIP, int port) {
    	ActiveMessage activeMsg =  new ActiveMessage(deviceIP, port);
        MinaproActiveResponseList.put(response, activeMsg);
    }

    /**
     * Retrieves the ActiveMessage corresponding to the specified response
     * @param response
     * @return
     */
    public ActiveMessage getActiveMessage(String response){
    	return MinaproActiveResponseList.get(response);
    }

    /**
     * Remove entry from ResponseCache
     * 
     * @param response
     */
    public void removeActiveResponsepEntry(String response) {
        MinaproActiveResponseList.remove(response);
    }

    // UsermapCache

    /**
     * Returns the Device IP for the given userId
     * 
     * @param userName
     * @return deviecIP
     */
    public String getDeviceIp(String userName) {
        return UserIdAddressmapping.get(userName);
    }

    /**
     * Add entry to the UsermapCache
     * 
     * @param userName
     * @param deviecIP
     */
    public void addUserNameMappinpEntry(String userName, String deviceIP) {
        UserIdAddressmapping.put(userName, deviceIP);
    }

    /**
     * Remove entry from UsermapCache
     * 
     * @param userName
     */
    public void removeUserNameMappinpEntry(String userName) {
        UserIdAddressmapping.remove(userName);
    }

    /**
     * Check user login status
     * 
     * @param userName
     */
    public boolean checkUserNameMappinpEntry(String userName) {
        return UserIdAddressmapping.containsKey(userName);
    }

    // ResponseRetriesCache

    /**
     * Returns the existence of entry in ResponseRetriesCache
     * 
     * @param response
     * @return boolean
     */
    public boolean checkResponseRetriesEntry(String response) {
        return MinaproResponseRetiriesCache.containsKey(response);
    }

    /**
     * Returns the no.of retries for the given response
     * 
     * @param response
     * @return retries
     */
    public int getRetriedCount(String response) {
        return MinaproResponseRetiriesCache.get(response);
    }

    /**
     * Add entry to the ResponseRetriesCache
     * 
     * @param response
     * @param retriedCount
     */
    public void addResponseRetiriesEntry(String response, int retriedCount) {
        MinaproResponseRetiriesCache.put(response, retriedCount);
    }

    /**
     * Remove entry from ResponseRetriesCache
     * 
     * @param response
     */
    public void removeMinaproResponseRetiriesEntry(String response) {
        MinaproResponseRetiriesCache.remove(response);
    }

    // SocketsCache

    /**
     * Returns the existence of entry in SocketsCache
     * 
     * @param Integer
     * @return boolean
     */
    public boolean checkUDPSocketsInUseEntry(Integer id) {
        return UDPSocketsInUse.containsKey(id);
    }

    /**
     * Add entry to the SocketsCache
     * 
     * @param id
     * @param port
     */
    public void addUDPSocketsInUseEntry(Integer id, Integer port) {
        UDPSocketsInUse.put(id, port);
    }

    /**
     * Remove entry from SocketsCache
     * 
     * @param id
     */
    public void removeUDPSocketsInUseEntry(Integer id) {
        UDPSocketsInUse.remove(id);
    }

    // UserInformationCache

    /**
     * Returns the password for the given UserInformationCache
     * 
     * @param user
     * @return password
     */
    public User getUserObject(String user) {
        return userCache.get(user);
    }

    /**
     * Add user info to UserInformationCache
     * 
     * @param user
     * @param password
     */
    public void addUserInfoToList(String user, User obj) {
        userCache.put(user, obj);
    }

    /**
     * Add entry to the EventMergerCache
     * 
     * @param eventId
     *            +eventType
     * @param event
     */
    public void addEventToMergerCache(String eventKey, String[] event) {
        eventMergerCache.put(eventKey, event);
    }

    /**
     * Add entry to the EventMergerCache
     * 
     * @param eventId
     *            +eventType
     * @param event
     */
    public void addCounttoPcktCache(String eventKey, Integer count) {
        packetCountCache.put(eventKey, count);
    }

    public void addAckToResponseEntry(String ack, String response) {
        ackToResponseCache.put(ack, response);
    }

    public void removeAckToResponseEntry(String ack) {
        ackToResponseCache.remove(ack);
    }

    public void addTokenstoCache(String eventID, String[] tokens) {
        tokensCache.put(eventID, tokens);
    }

    /**
     * Add entry to the userToRequestCache
     * 
     * @param userName
     * @param PacketNo
     *            ~NoOfPackets~EventType~EventID
     */

    public void addUserToRequestCacheEntry(String request, String userName) {
        userToRequestCache.put(request, userName);
    }

    /**
     * Returns the existence of request in ResponseCache
     * 
     * @param userName
     * @return boolean
     */
    public boolean checkRepeatedRequestEntry(String request) {
        return userToRequestCache.containsKey(request);
    }
    
    
    /**
     * Adds the user to device mapping into the cache. user id is the key
     * 
     * @param userId
     * @param deviceId
     */
    public void addDeviceToUserMapping(String deviceId, String userId) {
        deviceToUserMapping.put(deviceId, userId);
        userToDeviceMapping.put(userId, deviceId);
    }

    /**
     * Retrieves the device ID which the user has logged into
     * 
     * @param userId
     * @return
     */
    public String getDeviceMapping(String deviceId) {
        return deviceToUserMapping.get(deviceId);
    }
    
    public void removeDeviceToUserMapping(String userId) {
    	String deviceID = userToDeviceMapping.remove(userId);
    	if(deviceID != null)
    	deviceToUserMapping.remove(deviceID);
    }


}
