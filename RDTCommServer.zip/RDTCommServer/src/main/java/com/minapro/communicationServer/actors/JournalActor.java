package com.minapro.communicationServer.actors;

import java.sql.Timestamp;
import java.util.Date;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;
import akka.actor.UntypedActor;

/**
 * Actor responsible for persisting events into Database.
 * 
 * @author 3128828
 *
 */
public class JournalActor extends UntypedActor {
	
	String event;
	String user_id;
	String event_id;
	Timestamp created_datetime;
	String event_type;
	

	private static MinaProApplicationLogger logger = new MinaProApplicationLogger(
			JournalActor.class);

	@Override
	public void onReceive(Object msg) throws Exception {
		try{
		if (msg instanceof String) {
			String receivedEvent = (String) msg;
			
			created_datetime= new Timestamp(new Date().getTime());
			
			String[] eventTokens = receivedEvent.split(RDTServerMain.DELIMITER);

			String eventIdentifier = eventTokens[0];
			
			
			
			if( "RESP".equalsIgnoreCase(eventIdentifier)){
				event_type = "Response";
				event_id = eventTokens[2];
				user_id = eventTokens[eventTokens.length - 2];
			}else if("NOTIF".equalsIgnoreCase(eventIdentifier)){
				event_type = "Notification";
				event_id = eventTokens[2];
				user_id = eventTokens[eventTokens.length - 2];		
			}else{
				event_type = "Request";
				event_id = eventTokens[1];
				user_id = eventTokens[2];
			}
					

			logger.logMsg(LOG_LEVEL.DEBUG, "",
					"Received data to persist in DB - " + receivedEvent);
			HibernateSession.insertEventintoJournal(receivedEvent, user_id, event_id, created_datetime, event_type);

		} else
			unhandled(msg);
		}catch(Exception ex){
			logger.logMsg(LOG_LEVEL.FATAL, "",
					"Failed to Journal data - Caught exception:" + ex);
		}

	}
}
