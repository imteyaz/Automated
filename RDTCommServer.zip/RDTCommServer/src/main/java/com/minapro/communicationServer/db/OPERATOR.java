package com.minapro.communicationServer.db;


/**
 * Possible list of operators for MinaPro
 * @author 3128828
 *
 */
public enum OPERATOR {
    ITV, QC, HC, CHE, FOREMAN, VSUP, GSUP, YSUP, TSC, COMMON
}
