package com.minapro.communicationServer.actors;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import akka.actor.UntypedActor;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;
import com.minapro.communicationServer.common.VersionDetailsEvent;
import com.minapro.communicationServer.db.ApplicationParameter;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;
import com.minapro.communicationServer.udp.RUDPSocket;

public class RDTVersionValidationActor extends UntypedActor {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTVersionValidationActor.class);
	
	private static final String QC = "QC";
	private static final String CHE = "CHE";
	private static final String RMG = "RMG";
	private static final String RTG = "RTG";
	private static final String ITV = "ITV";

	@Override
	public void onReceive(Object message) throws Exception {
		if (message instanceof VersionDetailsEvent) {
			VersionDetailsEvent versionInfo = (VersionDetailsEvent) message;
			logger.logMsg(LOG_LEVEL.DEBUG, versionInfo.getAddress(), "Role is  :" + versionInfo.getRole());
			handleVersionCheckEvent(versionInfo);			
		}else {
			unhandled(message);
		}
	}
	
	private void handleVersionCheckEvent(VersionDetailsEvent versionInfo){
		ApplicationParameter latestAppVersionParam = HibernateSession.getLatestAppVersionForRole(versionInfo.getRole());
		
		if(latestAppVersionParam != null){
			String latestAppVersion = latestAppVersionParam.getParameterValue();
			logger.logMsg(LOG_LEVEL.INFO, versionInfo.getAddress(), "The latest version for the role " 
					+ latestAppVersion + "; current version=" + versionInfo.getVersionNumber());
		
			if(latestAppVersion != null && !latestAppVersion.equalsIgnoreCase(versionInfo.getVersionNumber())){
				sendVersionAlertToDevice(versionInfo, latestAppVersion, versionInfo.getVersionNumber());
			}
		}else {
			logger.logMsg(LOG_LEVEL.INFO, versionInfo.getRole(), "Unable to retrieve the application version for the role");
		}		
	}
	

	/**
	 * Constructs and sends the version change alert to the device
	 * @param versionDetails
	 * @param latestVersion
	 * @param currentVersion
	 */
	public void sendVersionAlertToDevice(VersionDetailsEvent versionDetails, String latestVersion, String currentVersion) {		
		StringBuilder response = new StringBuilder();
		
		response.append("1~1~").append(RDTServerMain.VERSION_ALERT_NOTIF).append(RDTServerMain.DELIMITER)
				.append(versionDetails.getEventId()).append(RDTServerMain.DELIMITER).append(currentVersion)
				.append(RDTServerMain.DELIMITER).append(latestVersion);

		String data = response.toString();
		InetAddress maddr = null;			
		byte b[] = null;
		try {			
			try {
				maddr = InetAddress.getByName(versionDetails.getAddress());
				b = data.getBytes("US-ASCII");
			} catch (UnsupportedEncodingException e) {
				logger.logException("Unable to read message encoding message in not in US-ASCI format", e);
			}

			DatagramSocket socket = RUDPSocket.getRUDPSocket(RDTVersionValidationActor.class);
			int port = getNotificationPortForRole(versionDetails.getRole());

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending  Version Alert  : alert is " + data);
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending  Version Alert to port " + port);
			
			socket.send(new DatagramPacket(b, b.length, maddr, port));
		} catch (IOException ioe) {
			logger.logException("Unable to send message ", ioe);
		} finally {
			maddr = null;
			b = null;
		}
	}
	
	/**
	 * retrieves the notification port assigned for the specified role
	 * @param role
	 * @return
	 */
	private int getNotificationPortForRole(String role){
		int port = 0;
		
		if (QC.equalsIgnoreCase(role)) {
			port = RDTServerMain.QC_NOTIFICATIONPORT;
		} else if(RMG.equalsIgnoreCase(role) || RTG.equalsIgnoreCase(role) || CHE.equalsIgnoreCase(role)) {
			port = RDTServerMain.CHE_NOTIFICATIONPORT;
		} else if (ITV.equalsIgnoreCase(role)) {
			port = RDTServerMain.ITV_NOTIFICATIONPORT;
		} else {
			port = RDTServerMain.MAN_NOTIFICATIONPORT;
		}
		
		return port;
	}
}
