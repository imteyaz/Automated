package com.minapro.communicationServer.actors;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.Set;

import akka.actor.UntypedActor;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;
import com.minapro.communicationServer.common.ActiveMsgDtls;
import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.db.OPERATOR;
import com.minapro.communicationServer.db.User;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;
import com.minapro.communicationServer.udp.RUDPSocket;

/**
 * Akka Actor which sends the responses received from RDT Processing server to devices
 * 
 * @author 3128828 version 1.0
 * 
 */

public class RDTResponseProcessActor extends UntypedActor {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTResponseProcessActor.class);

	// UDP Socket
	private static RUDPSocket dgramSocket = RUDPSocket.getRUDPSocket(RDTResponseProcessActor.class);

	private static final String RESP = "RESP";
	private static final String NOTIF = "NOTIF";

	/**
	 * Overridden method will be invoked after receiving the message and make use of SendMessage(ActiveMsgDtls) to send
	 * back to devices.
	 * 
	 * @param Object
	 * @return Nothing
	 */

	public void onReceive(Object msg) throws Exception {
		ActiveMsgDtls responsetoDevice = new ActiveMsgDtls();

		if (msg instanceof String) {

			String receivedResponse = (String) msg;
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Received response : " + receivedResponse);

			String[] eventTokens = receivedResponse.split(RDTServerMain.DELIMITER);
			String eventType = eventTokens[0];
			String userName = eventTokens[eventTokens.length - 2];

			try {
				String retryingResponse = receivedResponse;

				// Persisting incoming response into DB
				getSender().tell("journal" + RDTServerMain.DELIMITER + receivedResponse, null);

				OPERATOR role = RDTCacheManager.getInstance().gerUserLoggedInRole(userName);
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Associated role is : " + role);

				// Removing "RESP" OR "NOTIF"token before sending to response Actor
				receivedResponse = receivedResponse.substring(receivedResponse.indexOf(RDTServerMain.DELIMITER) + 1);
				responsetoDevice.setAddress(RDTCacheManager.getInstance().getDeviceIp(userName));

				// Port on which Devices are listening
				if (NOTIF.equalsIgnoreCase(eventType)) {
					if (role.equals(OPERATOR.QC)) {
						responsetoDevice.setPortNumber(RDTServerMain.QC_NOTIFICATIONPORT);
					} else if (role.equals(OPERATOR.CHE)) {
						responsetoDevice.setPortNumber(RDTServerMain.CHE_NOTIFICATIONPORT);
					} else if (role.equals(OPERATOR.ITV)) {
						responsetoDevice.setPortNumber(RDTServerMain.ITV_NOTIFICATIONPORT);
					} else {
						responsetoDevice.setPortNumber(RDTServerMain.MAN_NOTIFICATIONPORT);
					}
				} else if (RESP.equalsIgnoreCase(eventType)) {
					if (role.equals(OPERATOR.QC)) {
						responsetoDevice.setPortNumber(RDTServerMain.QC_DEVICEPORT);
					} else if (role.equals(OPERATOR.CHE)) {
						responsetoDevice.setPortNumber(RDTServerMain.CHE_DEVICEPORT);
					} else if (role.equals(OPERATOR.ITV)) {
						responsetoDevice.setPortNumber(RDTServerMain.ITV_DEVICEPORT);
					} else {
						responsetoDevice.setPortNumber(RDTServerMain.MAN_DEVICEPORT);
					}
				}
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Mapped address is : " + responsetoDevice.getAddress() 
						+ ":" + responsetoDevice.getPortNumber());
				responsetoDevice.setResponseMessage(retryingResponse.replaceAll("null", ""));
				responsetoDevice.setEventType(eventTokens[1]);
				responsetoDevice.setEventId(eventTokens[2]);

				handleLogoutScenario(userName, eventTokens[1]);

				// Sending to Device
				if (responsetoDevice.getAddress() != null) {
					SendMessage(responsetoDevice);
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, userName, "May be logged out or not present in DB ");
				}
			} catch (Exception ex) {
				logger.logException("Caught exception while handling the response message", ex);
				handleLogoutScenario(userName, eventType);
			}
		} else {
			unhandled(msg);
		}
	}

	/**
	 * In force log out and login failure notifications from Processing Server, Cleans up the caches related to the
	 * specified user and sets the user status to N in DB
	 * 
	 * @param userName
	 * @param eventType
	 */
	private void handleLogoutScenario(String userName, String eventType) {
		try {
			if (RDTServerMain.LOGOUT.equals(eventType) || RDTServerMain.LOGFAILURE.equals(eventType)) {

				// Also remove entry from User_device_Mapping Table
				HibernateSession.deleteUserDeviceMapping(userName);

				// updating login status in database UserDetails table
				User userObj = RDTCacheManager.getInstance().getUserObject(userName);
				if(userObj != null){
					HibernateSession.updateUserLoginStatus("N", userObj.getIntUserId());

					// Update UserInfo in Cache				
					userObj.setLoginStatus("N");
					RDTCacheManager.getInstance().addUserInfoToList(userName, userObj);
				}else {
					logger.logMsg(LOG_LEVEL.WARN, userName, "FAILED to get user object. Couldn't update login status");
				}

				// Remove UserMapping entry from DeviceMapCache
				RDTCacheManager.getInstance().removeUserNameMappinpEntry(userName);
				RDTCacheManager.getInstance().removeDeviceToUserMapping(userName);

				// Delete me
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Values in DevicemapCache after Logout: START");
				// Get all the Active responses's from cache
				Set<String> keyset = RDTCacheManager.getInstance().UserIdAddressmapping.keySet();
				if (keyset.size() != 0) {
					// Iterating through individual active responses
					for (Iterator<String> i = keyset.iterator(); i.hasNext();) {
						String user = i.next();
						logger.logMsg(LOG_LEVEL.DEBUG, userName, "User ID :" + user + " IP : "
								+ RDTCacheManager.getInstance().getDeviceIp(user));
					}
				}
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Values in DevicemapCache after Logout: END");
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while cleaning up user details", ex);
		}
	}

	/**
	 * Sends the responses received from RDT Processing server to Devices
	 * 
	 * @param ActiveMsgDtls
	 * @return Nothing.
	 */
	public void SendMessage(ActiveMsgDtls msg) {

		InetAddress maddr = null;
		int port = msg.getPortNumber();
		byte b[] = null;
		String data = null;
		int pcktindx = 1;
		String storageData = null;

		try {

			data = msg.getResponseMessage();
			String[] eventTokens = data.split(RDTServerMain.DELIMITER);
			String eventType = eventTokens[0];
			data = data.substring(data.indexOf(RDTServerMain.DELIMITER) + 1);

			try {
				maddr = InetAddress.getByName(msg.getAddress());
				b = data.getBytes("US-ASCII");
			} catch (UnsupportedEncodingException e1) {
				logger.logMsg(LOG_LEVEL.DEBUG, eventType, "Exception while encoding the Socket Address :" + e1);
			}

			// Check whether the Splitting required for packets before sending
			if ("true".equalsIgnoreCase(RDTServerMain.SPLITLARGEPACKETS)) {

				// Split as per the configured size of packets
				if (data.length() > RDTServerMain.UDPPACKETSIZE) {

					logger.logMsg(LOG_LEVEL.DEBUG, eventType, "Size of Response is :" + data.length() + " bytes");
					logger.logMsg(LOG_LEVEL.DEBUG, eventType, "Splitting Packet since it exceded "
							+ RDTServerMain.UDPPACKETSIZE + "  bytes");

					// Extracting no of packets
					int noOfPckts = data.length() / RDTServerMain.UDPPACKETSIZE;

					if ((data.length() % RDTServerMain.UDPPACKETSIZE) != 0) {
						noOfPckts = noOfPckts + 1;
					}

					logger.logMsg(LOG_LEVEL.DEBUG, eventType, "No of Packets need to send : " + noOfPckts);

					for (int x = 0; x < data.length();) {
						String resp = "";
						if (data.length() >= x + RDTServerMain.UDPPACKETSIZE) {

							resp = data.substring(x, x + RDTServerMain.UDPPACKETSIZE);

							if (pcktindx != 1) {

								// For rest of the packets, need to append eventType & envetID since they are not the
								// part of resp packet, also adding Starting and Ending Tags to packet
								resp = pcktindx + RDTServerMain.DELIMITER + noOfPckts + RDTServerMain.DELIMITER
										+ msg.getEventType() + RDTServerMain.DELIMITER + msg.getEventId()
										+ RDTServerMain.DELIMITER + resp;
							} else {
								// For the first packet, no need to append eventType & envetID since they are part of
								// resp packet, also adding Starting and Ending Tags to packet
								resp = pcktindx + RDTServerMain.DELIMITER + noOfPckts + RDTServerMain.DELIMITER + resp;
							}

							b = resp.getBytes("US-ASCII");
							pcktindx++;
						} else {

							// Last packet
							resp = data.substring(x, x + (data.length() - x));

							// Adding Starting and Ending Tags to packet
							// resp = soh + "~" + pcktindx + "~" + noOfPckts + "~"+ msg.eventType + "~" + msg.eventId +
							// "~"+
							// resp + "~" + eot;
							resp = pcktindx + RDTServerMain.DELIMITER + noOfPckts + RDTServerMain.DELIMITER
									+ msg.getEventType() + RDTServerMain.DELIMITER + msg.getEventId()
									+ RDTServerMain.DELIMITER + resp;

							b = resp.getBytes("US-ASCII");
							pcktindx++;
						}

						// Sending
						dgramSocket.send(new DatagramPacket(b, b.length, maddr, port));

						String s = new String(b);
						logger.logMsg(LOG_LEVEL.DEBUG, eventType, " Sent " + " packet to Device ----> " + s);

						// Adding Starting and Ending Tags to packet
						if (RESP.equalsIgnoreCase(eventType)) {
							storageData = RESP + RDTServerMain.DELIMITER + s;
						} else if (NOTIF.equalsIgnoreCase(eventType)) {
							storageData = NOTIF + RDTServerMain.DELIMITER + s;
						}

						// Populate ResponseCache with ActiveResponse for
						// retries
						RDTCacheManager.getInstance().addActiveResponsepEntry(storageData.replaceAll("null", ""),
								msg.getAddress(), msg.getPortNumber());

						// Populate ackToResponse cache with expected Ack for
						// response
						RDTCacheManager.getInstance().addAckToResponseEntry(
								(pcktindx - 1) + RDTServerMain.DELIMITER + noOfPckts + RDTServerMain.DELIMITER
										+ msg.getEventType() + RDTServerMain.DELIMITER + msg.getEventId(), s);

						x = x + RDTServerMain.UDPPACKETSIZE;
					}

				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, eventType, "Packet size is under  " + RDTServerMain.UDPPACKETSIZE);
					sendSinglePacketMessage(data, eventType, msg, maddr);
				}
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, eventType, "Splitting is not Required  ");
				sendSinglePacketMessage(data, eventType, msg, maddr);
			}

			// dgramSocket.send(new DatagramPacket(b, b.length, maddr, port));

		} catch (IOException ioe) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception while handling the Socket :" + ioe);
		} finally {
			maddr = null;
			b = null;
		}
	}

	/**
	 * Sends single packet message to the device
	 * 
	 * @param data
	 * @param eventType
	 * @param msg
	 * @param maddr
	 */
	private void sendSinglePacketMessage(String data, String eventType, ActiveMsgDtls msg, InetAddress maddr) {
		String storageData = null;

		try {
			data = "1" + RDTServerMain.DELIMITER + "1" + RDTServerMain.DELIMITER + data;
			// Adding Starting and Ending Tags to packet
			if (RESP.equalsIgnoreCase(eventType)) {
				storageData = RESP + RDTServerMain.DELIMITER + data;
			} else if (NOTIF.equalsIgnoreCase(eventType)) {
				storageData = NOTIF + RDTServerMain.DELIMITER + data;
			}

			byte[] b = data.getBytes("US-ASCII");

			dgramSocket.send(new DatagramPacket(b, b.length, maddr, msg.getPortNumber()));
			logger.logMsg(LOG_LEVEL.DEBUG, eventType, " Sent response to Device ----> " + data);

			// Populate ResponseCache with ActiveResponse for retries
			// RDTCacheManager.getInstance().addActiveResponsepEntry(data, msg.Address);

			RDTCacheManager.getInstance().addActiveResponsepEntry(storageData.replaceAll("null", ""), 
					msg.getAddress(), msg.getPortNumber());

			RDTCacheManager.getInstance().addAckToResponseEntry(
					"1" + RDTServerMain.DELIMITER + "1" + RDTServerMain.DELIMITER + msg.getEventType()
							+ RDTServerMain.DELIMITER + msg.getEventId(), data);

			// Populate ackToResponse cache with expected Ack for response
			RDTCacheManager.getInstance().addAckToResponseEntry(
					"1" + RDTServerMain.DELIMITER + "1" + RDTServerMain.DELIMITER + msg.getEventType()
							+ RDTServerMain.DELIMITER + msg.getEventId(), data);
		} catch (Exception ex) {
			logger.logException("Caught exception while sendSinglePacketMessage", ex);
		}
	}

}
