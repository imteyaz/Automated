package com.minapro.communicationServer.logging;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * Wrapper class on log4j Logger for logging with custom level log levels
 * 
 * @author 3123248
 *
 */
public class MinaProApplicationLogger {
	private Logger logger = null;

	static {
	    
		DOMConfigurator.configureAndWatch("log4j.xml",1L);

		// shutdown log4j (and its monitor thread) on shutdown
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				LogManager.shutdown();
			}
		});
	}

	public MinaProApplicationLogger(Class<?> className) {
		this.logger = Logger.getLogger(className.getName());
		this.logger.setLevel(Logger.getRootLogger().getLevel());
	}

	/**
	 * Logs the start of of a particular transaction.
	 * 
	 * @param transactionId
	 */
	public void beginTransaction(String transactionId) {
		if (transactionId != null && !transactionId.isEmpty())
			logger.info(transactionId + ":: Transaction started");
	}

	/**
	 * Logs the completion of a particular transaction
	 * 
	 * @param transactionId
	 */
	public void endTransaction(String transactionId) {
		if (transactionId != null && !transactionId.isEmpty())
			logger.info(transactionId + ":: Transaction complete");
	}

	/**
	 * writes the log message to the configured logging file.
	 * 
	 * @param logLevel
	 *            - desired log level for the message
	 * @param transactionId
	 *            - associated transactionId for the message
	 * @param logMessage
	 *            - message to be logged
	 */
	public void logMsg(LOG_LEVEL logLevel, String transactionId,
			String logMessage) {
		String prefixMsg = transactionId + "::";

		switch (logLevel) {
		case DEBUG:
			if (logger.isDebugEnabled())
				logger.debug(prefixMsg + logMessage);
			break;
		case INFO:
			if (logger.isInfoEnabled())
				logger.info(prefixMsg + logMessage);
			break;
		case WARN:
			logger.warn(prefixMsg + logMessage);
			break;
		case ERROR:
			logger.error(prefixMsg + logMessage);
			break;
		case TRACE:
			if (logger.isTraceEnabled())
				logger.trace(prefixMsg + logMessage);
			break;
		case PERF:
			logger.log(PerfLevel.PERF, prefixMsg + logMessage);
			break;
		case FATAL:
			logger.log(PerfLevel.FATAL, prefixMsg + logMessage);
			break;
		default:
			logger.debug(prefixMsg + logMessage);
		}

	}

	/**
	 * Possible Log levels for MinaPro
	 * 
	 * @author 3123248
	 *
	 */
	public static enum LOG_LEVEL {
		DEBUG, INFO, WARN, ERROR, TRACE, PERF, FATAL
	}
	
	/**
	 * Logs the exception stack trace with custom log message
	 * 
	 * @param logMessage
	 * @param ex
	 */
	public void logException(String logMessage, Exception ex) 
	{
		logger.error(logMessage, ex);
	}
}
