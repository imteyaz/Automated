package com.minapro.communicationServer.udp;

import java.net.DatagramPacket;
import java.util.Iterator;
import java.util.Set;

import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Opens UDP Socket for receiving acknowledgments from devices. Removes the corresponding active response entry from
 * Cache
 * 
 * @author 3128828 version 1.0
 * 
 */
public class RDTCommAckHandler extends Thread {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTCommAckHandler.class);

	public RDTCommAckHandler() {
	}

	/**
	 * Opens UDP Socket to receive Ack's and remove entry from Cache
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public void run() {
		RUDPSocket udpServer = null;
		try {
			udpServer = RUDPSocket.getRUDPSocket(RDTServerMain.ACKPORT, RDTCommAckHandler.class);
		} catch (Exception e1) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception While Opening UDP Socket :" + e1);
		}

		logger.logMsg(LOG_LEVEL.DEBUG, "", "Started RDT Acknowledgement receiver on " + RDTServerMain.ACKPORT);

		byte[] buffer = new byte[1024 * 20];
		DatagramPacket rcvdPacket = new DatagramPacket(buffer, buffer.length);
		String receivedmsg = "";

		while (true) {
			try {
				// Receiving Ack
				udpServer.receive(rcvdPacket);
				receivedmsg = new String(rcvdPacket.getData());
				receivedmsg = receivedmsg.substring(0, rcvdPacket.getLength());

				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received Acknowledgement from "
						+ rcvdPacket.getAddress().getHostAddress());
				logger.logMsg(LOG_LEVEL.DEBUG, "", "ACKNOWLEDGEMENT---->" + receivedmsg);

				// remove "RECEIVED" token to check active response in cache
				String ack = receivedmsg.substring(receivedmsg.indexOf(RDTServerMain.DELIMITER) + 1);
				/*String[] tokens = ack.split(RDTServerMain.DELIMITER);
				String searchToken = tokens[0] + RDTServerMain.DELIMITER + tokens[1] + RDTServerMain.DELIMITER
						+ tokens[2] + RDTServerMain.DELIMITER + tokens[3];*/

				String activeResp = RDTCacheManager.getInstance().ackToResponseCache.get(ack);
				if(activeResp != null) {
					String notificationActiveResp = "NOTIF" + RDTServerMain.DELIMITER + activeResp.trim();
					String generalResponseActiveResp = "RESP" + RDTServerMain.DELIMITER + activeResp.trim();

					// Checking corresponding Active response in Cache
					if ((RDTCacheManager.getInstance().checkActiveResponseEntry(generalResponseActiveResp))) {
						// Removing entry from Cache
						RDTCacheManager.getInstance().removeActiveResponsepEntry(generalResponseActiveResp);
					} else if ((RDTCacheManager.getInstance().checkActiveResponseEntry(notificationActiveResp))) {
						// Removing entry from Cache
						RDTCacheManager.getInstance().removeActiveResponsepEntry(notificationActiveResp);
					}
				}

				Set<String> keyset = RDTCacheManager.getInstance().MinaproActiveResponseList.keySet();
				logger.logMsg(LOG_LEVEL.DEBUG, "", "SIZE OF ACTIVE RESPONCES IN CACHE :" + keyset.size());
				if (keyset.size() != 0) {
					// Iterating through individual active responses
					for (Iterator<String> i = keyset.iterator(); i.hasNext();) {
						String msg = (String) i.next();
						logger.logMsg(LOG_LEVEL.DEBUG, "", "ACTIVE RESPONCES IN CACHE :" + msg);
					}
				}
			} catch (Exception e) {
				logger.logException("Exception in RDTCommAckHanler :", e);
			}
		}
	}
}
