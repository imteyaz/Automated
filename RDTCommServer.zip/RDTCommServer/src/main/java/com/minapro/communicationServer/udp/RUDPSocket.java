package com.minapro.communicationServer.udp;


import java.net.DatagramSocket;
import java.net.SocketException;

import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * RUDPSocket a Wrapper class make use of Overloaded get methods to open the sockets.
 * 
 * @author 3128828 
 * version 1.0
 * 
 */

public class RUDPSocket extends DatagramSocket {
	
	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTServerMain.class);
   
	public RUDPSocket() throws SocketException {
        
      super();
               
    }
    
    public RUDPSocket(int port) throws SocketException {
        
        super(port);
        
    }
    
	/**
	 * Opens UDP socket using local port
	 * 
	 * @param Class<?>
	 * @return RUDPSocket
	 */
    public static RUDPSocket getRUDPSocket(Class<?> className) {
        RUDPSocket sock = null;
        String requestedClass = className.getSimpleName();
        
        if (RDTServerMain.UDPSOCKETRANGE == 0) {
            try {
                sock = new RUDPSocket();
                RDTCacheManager.getInstance().addUDPSocketsInUseEntry(sock.getLocalPort(),sock.getLocalPort());
                logger.logMsg(LOG_LEVEL.DEBUG, "", "Opening" + " " +  requestedClass   + " " + "Socket with Port " + sock.getLocalPort());
            } catch (SocketException e) {
            	logger.logMsg(LOG_LEVEL.DEBUG, "",
    					"Exception While Opening UDP Socket :"
    							+ e);
            }
            
            return sock;
        }
        else {
           
           
            for(int i =RDTServerMain.UDPSOCKETRANGE; i< RDTServerMain.UDPSOCKETRANGE+1000;i++) {
                if (!RDTCacheManager.getInstance().UDPSocketsInUse.containsKey(i)) {
                   
                    try {
                        sock = new RUDPSocket(i);
                        RDTCacheManager.getInstance().addUDPSocketsInUseEntry(i,i);
                        logger.logMsg(LOG_LEVEL.DEBUG, "", "Opening" + " " +  requestedClass   + " " + "Socket with Port " + sock.getLocalPort());
                        logger.logMsg(LOG_LEVEL.DEBUG, "", "No of ports in cache " + RDTCacheManager.getInstance().UDPSocketsInUse.size());
                        break;
                    } catch (SocketException e) {
                    	logger.logMsg(LOG_LEVEL.DEBUG, "",
            					"Exception While Opening UDP Socket :"
            							+ e);
                    };    
                   
                    
                }
            }
            
            return sock;
        }
        
    }
    
	/**
	 * Opens UDP socket using specific port
	 * 
	 * @param Class<?>
	 * @param port
	 * @return RUDPSocket
	 */
    public static RUDPSocket getRUDPSocket(int port, Class<?> className) {
        RUDPSocket sock = null;
        String requestedClass = className.getSimpleName();

        if (RDTServerMain.UDPSOCKETRANGE == 0) {
            try {
                sock = new RUDPSocket(port);
                RDTCacheManager.getInstance().addUDPSocketsInUseEntry(sock.getLocalPort(),sock.getLocalPort());
                logger.logMsg(LOG_LEVEL.DEBUG, "", "Opening" + " " +  requestedClass   + " " + "Socket with Port " + sock.getLocalPort());
            } catch (SocketException e) {
            	logger.logMsg(LOG_LEVEL.DEBUG, "",
    					"Exception While Opening UDP Socket :"
    							+ e);
            }
            
            return sock;
        }
        else {
           
            if (port >= RDTServerMain.UDPSOCKETRANGE && port <= RDTServerMain.UDPSOCKETRANGE+1000) {
                try {
                    sock = new RUDPSocket(port);
                    RDTCacheManager.getInstance().addUDPSocketsInUseEntry(port,port);
                    logger.logMsg(LOG_LEVEL.DEBUG, "", "Opening" + " " +  requestedClass   + " " + "Socket with Port " + sock.getLocalPort());
                    logger.logMsg(LOG_LEVEL.DEBUG, "", "No of ports in cache " + RDTCacheManager.getInstance().UDPSocketsInUse.size());
                    
                } catch (SocketException e) {
                	logger.logMsg(LOG_LEVEL.DEBUG, "",
        					"Exception While Opening UDP Socket :"
        							+ e);
                	logger.logMsg(LOG_LEVEL.DEBUG, "", "Server port " + port + " is out of the provided range");
                };        
            }
            else {
            	logger.logMsg(LOG_LEVEL.DEBUG, "", "Server port " + port + " is out of the provided range");
            }
            
            
            return sock;
        }
        
    }
    
    
	/**
	 * Close UDP socket
	 * 
	 * @param Nothing
	 * @param Nothing
	 * @return Nothing
	 */  
    public void close() {
        int portused = this.getLocalPort();
        logger.logMsg(LOG_LEVEL.DEBUG, "", "Closing Socket with Port " + portused);
        try {
           
           super.close();
         
            
        } catch (Exception e) {
        	logger.logMsg(LOG_LEVEL.DEBUG, "",
					"Exception While closing UDP Socket :"
							+ e);
        } finally {
        	RDTCacheManager.getInstance().removeUDPSocketsInUseEntry(portused);
            logger.logMsg(LOG_LEVEL.DEBUG, "", "No of ports in cache " + RDTCacheManager.getInstance().UDPSocketsInUse.size());
        }
    }
}
