package com.minapro.communicationServer.actors;

import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.routing.RoundRobinPool;
import akka.routing.SmallestMailboxPool;

import com.minapro.communicationServer.common.ActiveMsgDtls;
import com.minapro.communicationServer.common.VersionDetailsEvent;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;

/**
 * Master Actor which supervises the interaction of all the actors present in the RDT Communication server.
 * 
 * @author 3128828
 *
 */
public class RDTCommServerMasterActor extends UntypedActor {
	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTCommServerMasterActor.class);

	// Actor responsible for handling requests from Devices
	ActorRef RequestActor = getContext().actorOf(
			Props.create(RDTRequestProcessActor.class).withRouter(new RoundRobinPool(30)), "EventReceiver");

	// Actor responsible for handling responses from RDT Processing server
	ActorRef ResponseActor = getContext().actorOf(
			Props.create(RDTResponseProcessActor.class).withRouter(new RoundRobinPool(30)), "ResponseSender");

	// Actor responsible for persisting all events received at RDT
	ActorRef JournalActor = getContext().actorOf(
			Props.create(JournalActor.class).withRouter(new SmallestMailboxPool(5)), "journal");

	// Actor responsible for handling responses from RDT Processing server
	ActorRef EventMergerActor = getContext().actorOf(
			Props.create(EventMergerActor.class).withRouter(new RoundRobinPool(30)), "EventMerger");

	// Actor responsible for handling responses from RDT Processing server
	ActorRef VersionValidateActor = getContext().actorOf(
			Props.create(RDTVersionValidationActor.class).withRouter(new RoundRobinPool(30)), "VersionValidator");

	@Override
	/**
	 * Receives all messages and delegates to the respective actor based on the event type
	 */
	public void onReceive(Object message) throws Exception {

		if (message instanceof ActiveMsgDtls) {

			ActiveMsgDtls requestMsg = (ActiveMsgDtls) message;
			if (requestMsg.getIsSplit()) {
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending event to EventMergerActor ");
				EventMergerActor.tell(requestMsg.getRequestMessage(), getSelf());

			} else {

				logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending request to RequestActor ");
				RequestActor.tell(requestMsg, getSelf());

			}
		} else if (message instanceof String) {

			String event = (String) message;

			logger.logMsg(LOG_LEVEL.DEBUG, "", event);

			String[] eventTokens = event.split(RDTServerMain.DELIMITER);

			// In case of response, first token will be "RESP"
			if ("RESP".equals(eventTokens[0]) || "NOTIF".equals(eventTokens[0])) {

				// Removing "RESP" token before sending to response Actor
				// String respevent = event.substring(event.indexOf(RDTServerMain.DELIMITER) + 1);

				logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending response to ResponseActor ");
				ResponseActor.tell(event, getSelf());

			} else if ("journal".equals(eventTokens[0])) {

				// Removing "journal" token before sending to journal Actor
				String journalEvent = event.substring(event.indexOf(RDTServerMain.DELIMITER) + 1);

				logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending event to JournalActor ");
				JournalActor.tell(journalEvent, getSelf());
			}

		} else if (message instanceof VersionDetailsEvent) {

			VersionDetailsEvent requestMsg = (VersionDetailsEvent) message;
			VersionValidateActor.tell(requestMsg, getSelf());

		}

	}
}