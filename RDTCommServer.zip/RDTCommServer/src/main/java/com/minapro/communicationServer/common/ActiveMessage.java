package com.minapro.communicationServer.common;

import java.util.Date;

/**
 * Object holding the active message sent time and the device ip details
 * 
 * @author Rosemary George
 *
 */
public class ActiveMessage {

	/**
	 * Indicates the device IP to which the message has been sent
	 */
	private String deviceIP;
	
	/**
	 * Indicates the port number to which the message has been sent
	 */
	private Integer port;
	
	/**
	 * Indicates the time when the message has been sent to the device
	 */
	private Date sentTime;

	public ActiveMessage(String deviceIp, int port){
		this.deviceIP = deviceIp;
		this.port = port;
		this.sentTime = new Date();
	}
	
	public String getDeviceIP() {
		return deviceIP;
	}

	public void setDeviceIP(String deviceIP) {
		this.deviceIP = deviceIP;
	}

	public Date getSentTime() {
		return sentTime;
	}

	public void setSentTime(Date sentTime) {
		this.sentTime = sentTime;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "ActiveMessage [deviceIP=" + deviceIP + ", port=" + port + ", sentTime=" + sentTime + "]";
	}	
}
