package com.minapro.communicationServer.listeners;



import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;
import akka.actor.ActorRef;

public class QueueEventListener implements MessageListener {

	
	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(QueueEventListener.class);


	final ActorRef actorRef = RDTServerMain.getMasterActor();


	/**
	 * Forward responses on receive to the RDT Master Actor
	 * @param Message
	 */
	public void onMessage(Message message) {
		String RDTProcessingResponse = null;

		try {

			if (message instanceof TextMessage) {
				RDTProcessingResponse = ((TextMessage) message).getText();
			}

			logger.logMsg(LOG_LEVEL.DEBUG, "","Received Response on QueueEventListener : " + RDTProcessingResponse);
			
			//Forwarding responses to Master Actor
			actorRef.tell(RDTProcessingResponse, null);
			
		} catch (Exception e) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Worker caught an Exception :" + e);
		}
	}



}
