package com.minapro.communicationServer.common;


/**
 * Wrapper class for storing the event details
 * 
 * @author 3128828 
 * version 1.0
 * 
 */

public class ActiveMsgDtls {

	private String Address;
	private String eventType;
	private String eventId;
	private String RequestMessage;
	private String ResponseMessage;
	private String SplitEventNumber;
	private String numberOfpkts;
	private int PortNumber;
	private Boolean isSplit;
	private Boolean isDeviceIDExists;	

	public String getAddress() {
		return Address;
	}
	
	public void setAddress(String address) {
		Address = address;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getRequestMessage() {
		return RequestMessage;
	}

	public void setRequestMessage(String requestMessage) {
		RequestMessage = requestMessage;
	}

	public String getResponseMessage() {
		return ResponseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		ResponseMessage = responseMessage;
	}

	public String getSplitEventNumber() {
		return SplitEventNumber;
	}

	public void setSplitEventNumber(String splitEventNumber) {
		SplitEventNumber = splitEventNumber;
	}
	
	public String getNumberOfpkts() {
		return numberOfpkts;
	}

	public void setNumberOfpkts(String numberOfpkts) {
		this.numberOfpkts = numberOfpkts;
	}

	public int getPortNumber() {
		return PortNumber;
	}

	public void setPortNumber(int portNumber) {
		PortNumber = portNumber;
	}

	public Boolean getIsSplit() {
		return isSplit;
	}

	public void setIsSplit(Boolean isSplit) {
		this.isSplit = isSplit;
	}

	public Boolean getIsDeviceIDExists() {
		return isDeviceIDExists;
	}

	public void setIsDeviceIDExists(Boolean isDeviceIDExists) {
		this.isDeviceIDExists = isDeviceIDExists;
	}

	public ActiveMsgDtls() {
		Address = "";
		eventType = "";
		eventId = "";
		RequestMessage = "";
		ResponseMessage = "";
		SplitEventNumber = " ";
		PortNumber = 0;
		isSplit = false;
	}
}
