package com.minapro.communicationServer.db;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class JournalPK implements Serializable 
{
	private static final long serialVersionUID = -6271048673839325680L;
	
	@Column(name = "EVENT_ID")
	private String event_id;
	@Column(name = "EVENT_TYPE")
	private String event_type;
		
	public String getEvent_id() {
		return event_id;
	}
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	public String getEvent_type() {
		return event_type;
	}
	public void setEvent_type(String event_type) {
		this.event_type = event_type;
	}

	
    

}
