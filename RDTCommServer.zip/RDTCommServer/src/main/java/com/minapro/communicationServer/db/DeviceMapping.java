package com.minapro.communicationServer.db;



import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * ValueObject holding the user and device details.
 * @author 3128828
 *
 */

@Entity
@Table(name="MP_USER_DEVICE_MAPPING")
public class DeviceMapping{
	@Id
	@Column(name="USER_ID", nullable=false)
	private String userID;
	
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="DEVICE_ID")
	private DeviceMaster devicemaster;
  
	@Column(name="INT_USER_ID")
	private Integer userKey;
	
	public Integer getUserKey() {
		return userKey;
	}

	public void setUserKey(Integer userKey) {
		this.userKey = userKey;
	}

	public String getUserID() {
		return userID;
	}
   
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public DeviceMaster getDevicemaster() {
		return devicemaster;
	}


	public void setDevicemaster(DeviceMaster devicemaster) {
		this.devicemaster = devicemaster;
	}

	@Override
	public String toString() {
		return "DeviceMapping [userID=" + userID + ", devicemaster=" + devicemaster + ", userKey=" + userKey + "]";
	}	
}
