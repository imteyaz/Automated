package com.minapro.communicationServer.db;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the device details.
 * @author 3128828
 *
 */

@Entity
@Table(name="MP_DEVICE_MASTER")
public class DeviceMaster {
	
	@Id
	@Column(name="DEVICE_ID", nullable=false)
	private String device_id;
	
	@Column(name="DEVICE_DESCRIPTION")
	private String device_description;
	
	@Column(name="IPADDRESS")
	private String ipaddress;
	
	@Column(name="LISTENING_PORT")
	private Integer listening_port;
	
	@Column(name="SENDING_PORT")
	private Integer sending_port;
	
	@Column(name="MAKE")
	private String make;
	
	@Column(name="MODEL")
	private String model;
	
	@Column(name="CREATED_DATETIME", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date created_datetime;
	
	@Column(name="CREATED_BY")
	private String created_by;
	
	@Column(name="LAST_UPDATED_DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date last_updated_datetime;
	
	@Column(name="LAST_UPDATED_BY")
	private String last_updated_by;
	
	@Column(name="VERSION", nullable=false)
	private int version;
		
	@Column(name="OS_VERSION")
	private String osVersion;
	
	@Column(name="CURRENT_APP_VERSION")
	private String currentOsVersion;
	
	@Column(name="LAST_APP_VERSION_UPDATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastVersionUpdate;
	
	public String getOsVersion() {
		return osVersion;
	}
	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}
	public String getCurrentOsVersion() {
		return currentOsVersion;
	}
	public void setCurrentOsVersion(String currentOsVersion) {
		this.currentOsVersion = currentOsVersion;
	}
	public Date getLastVersionUpdate() {
		return lastVersionUpdate;
	}
	public void setLastVersionUpdate(Date lastVersionUpdate) {
		this.lastVersionUpdate = lastVersionUpdate;
	}
	
	public String getDevice_id() {
		return device_id;
	}
	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}
	public String getDevice_description() {
		return device_description;
	}
	public void setDevice_description(String device_description) {
		this.device_description = device_description;
	}
	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public Integer getListening_port() {
		return listening_port;
	}
	public void setListening_port(Integer listening_port) {
		this.listening_port = listening_port;
	}
	public Integer getSending_port() {
		return sending_port;
	}
	public void setSending_port(Integer sending_port) {
		this.sending_port = sending_port;
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Date getCreated_datetime() {
		return created_datetime;
	}
	public void setCreated_datetime(Date created_datetime) {
		this.created_datetime = created_datetime;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getLast_updated_datetime() {
		return last_updated_datetime;
	}
	public void setLast_updated_datetime(Date last_updated_datetime) {
		this.last_updated_datetime = last_updated_datetime;
	}
	public String getLast_updated_by() {
		return last_updated_by;
	}
	public void setLast_updated_by(String last_updated_by) {
		this.last_updated_by = last_updated_by;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	@Override
	public String toString() {
		return "DeviceMaster [device_id=" + device_id + ", ipaddress="
				+ ipaddress + ", listening_port=" + listening_port
				+ ", sending_port=" + sending_port + ", osVersion=" + osVersion
				+ ", currentOsVersion=" + currentOsVersion + "]";
	}	
}
