package com.minapro.communicationServer.db;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;



/**
 * ValueObject holding all user related information
 * @author 3128828
 *
 */
@Entity
@Table(name="MP_USERDTLS_AM")
public class User 
{
	private String userID;
	private String password;
	
	private Integer intUserId;
	private Integer alwdLoginAttempts;
	private Integer preExpWarningPeriod;
	private Integer alwdInactivityPeriod;
	private Integer passwdValidPeriod;
	private Integer delIntUserId;
	private String intrnlUserInd;
	private String accountStatus;
	private String userPriviledgeCls;
	private String firstName;
	private String lastName;
	private String userDescription;
	private String telephoneNo;
	private String mobileNo;
	private String emailId;
	private String faxNo;
	private String tzInfo;
	private String iv;
	private String salt;
	private String deafultLanguage;
	private Date passwdValidDate;
	private Date userCreationDatTime;
	private Date lastLogin;
	private String loginStatus ;
	private Date delDatTime;
	private String adtInsFunctionCd;
	private String adtUpdFunctionCd;
	private String createdBy;//adtInsUserNm;
	private String lastUpdatedBy ;//adtUpdUserNm;
	private Date createdDateTime;//adtInsDatTime;
	private Date lastUpdatedDateTime;//adtUpdDatTime;
	private String stringRoles ;
	private ArrayList<String>  roles = new ArrayList<String>();
	private Collection<UserRole>  actualRoles = new ArrayList<UserRole>();
	
	@Column(name="PASSWD")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Column(name="USER_NM", nullable=false)
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	/*public OPERATOR getOperatorRole() 
	{		
		String operator = userRole.getRole_name();
		if(operator.startsWith("QC"))
			 return OPERATOR.QC;
		else if(operator.startsWith("ITV"))
			return OPERATOR.ITV;
		else if(operator.startsWith("RMG") || operator.startsWith("RTG"))
			return OPERATOR.CHE;
		else
			return OPERATOR.HC;
	}
		
	public String getTerminalId()
	{
		String terminalId = this.terminal.getTerminal_id();
		return terminalId.substring(terminalId.length()-1);
	}*/
	
	@Transient
	public String getStringRoles() {
		return stringRoles;
	}
	public void setStringRoles(String stringRoles) {
		this.stringRoles = stringRoles;
	}
		
	@OneToMany(fetch=FetchType.EAGER)
	@JoinTable(name="MP_USERGRP_A", joinColumns={@JoinColumn(name="INT_USER_ID")},
				inverseJoinColumns={@JoinColumn(name="INT_USER_GRP_ID")})
	public Collection<UserRole> getActualRoles() {
		return actualRoles;
	}
	public void setActualRoles(Collection<UserRole> actualRoles) {
		this.actualRoles = actualRoles;
	}
		
	@Transient
	public ArrayList<String> getRoles() {
		return roles;
	}
	public void setRoles(ArrayList<String> roles) {
		this.roles = roles;
	}	
		
	@Id
	@Column(name="INT_USER_ID", nullable=false)
	public Integer getIntUserId() {
		return intUserId;
	}
	
	public void setIntUserId(Integer intUserId) {
		this.intUserId = intUserId;
	}
	
	@Column(name="ALWD_LOGIN_ATTEMPTS")
	public Integer getAlwdLoginAttempts() {
		return alwdLoginAttempts;
	}
	public void setAlwdLoginAttempts(Integer alwdLoginAttempts) {
		this.alwdLoginAttempts = alwdLoginAttempts;
	}
	
	@Column(name="PRE_EXP_WARNING_PERIOD")
	public Integer getPreExpWarningPeriod() {
		return preExpWarningPeriod;
	}
	public void setPreExpWarningPeriod(Integer preExpWarningPeriod) {
		this.preExpWarningPeriod = preExpWarningPeriod;
	}
	
	@Column(name="ALWD_INACTVTY_PERIOD")
	public Integer getAlwdInactivityPeriod() {
		return alwdInactivityPeriod;
	}
	public void setAlwdInactivityPeriod(Integer alwdInactivityPeriod) {
		this.alwdInactivityPeriod = alwdInactivityPeriod;
	}
	
	@Column(name="PASSWD_VALID_PERIOD")
	public Integer getPasswdValidPeriod() {
		return passwdValidPeriod;
	}
	public void setPasswdValidPeriod(Integer passwdValidPeriod) {
		this.passwdValidPeriod = passwdValidPeriod;
	}
	
	@Column(name="DEL_INT_USER_ID")
	public Integer getDelIntUserId() {
		return delIntUserId;
	}
	public void setDelIntUserId(Integer delIntUserId) {
		this.delIntUserId = delIntUserId;
	}
	
	@Column(name="INTRNL_USER_IND")
	public String getIntrnlUserInd() {
		return intrnlUserInd;
	}
	public void setIntrnlUserInd(String intrnlUserInd) {
		this.intrnlUserInd = intrnlUserInd;
	}
	
	@Column(name="USER_STS")
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String userSts) {
		this.accountStatus = userSts;
	}
	
	@Column(name="USER_PRIVILEDGE_CLS")
	public String getUserPriviledgeCls() {
		return userPriviledgeCls;
	}
	public void setUserPriviledgeCls(String userPriviledgeCls) {
		this.userPriviledgeCls = userPriviledgeCls;
	}
		
	@Column(name="USER_FIRSTNAME")	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@Column(name="USER_LASTNAME")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Column(name="USER_DESCR")
	public String getUserDescription() {
		return userDescription;
	}
	public void setUserDescription(String userDescr) {
		this.userDescription = userDescr;
	}
	
	@Column(name="TEL_NO")
	public String getTelephoneNo() {
		return telephoneNo;
	}
	public void setTelephoneNo(String telNo) {
		this.telephoneNo = telNo;
	}
	
	@Column(name="MOBILE_NO")
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	@Column(name="EMAIL_ADDR")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailAddr) {
		this.emailId = emailAddr;
	}
	
	@Column(name="FAX_NO")
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	
	@Column(name="TZ_INFO")
	public String getTzInfo() {
		return tzInfo;
	}
	public void setTzInfo(String tzInfo) {
		this.tzInfo = tzInfo;
	}
	
	
	@Column(name="IV")
	public String getIv() {
		return iv;
	}
	public void setIv(String iv) {
		this.iv = iv;
	}
	
	@Column(name="SALT")
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	
	
	@Column(name="LANG_CD")
	public String getDeafultLanguage() {
		return deafultLanguage;
	}
	public void setDeafultLanguage(String langCd) {
		this.deafultLanguage = langCd;
	}
	
	@Column(name="PASSWD_VALID_DT")
	public Date getPasswdValidDate() {
		return passwdValidDate;
	}
	public void setPasswdValidDate(Date passwdValidDate) {
		this.passwdValidDate = passwdValidDate;
	}
	
	@Column(name="USER_CREATION_DTTM")
	public Date getUserCreationDatTime() {
		return userCreationDatTime;
	}
	public void setUserCreationDatTime(Date userCreationDatTime) {
		this.userCreationDatTime = userCreationDatTime;
	}
		
	@Column(name="DEL_DTTM")
	public Date getDelDatTime() {
		return delDatTime;
	}
	public void setDelDatTime(Date delDatTime) {
		this.delDatTime = delDatTime;
	}
	
	@Column(name="ADT_INS_FUNCTION_CD")
	public String getAdtInsFunctionCd() {
		return adtInsFunctionCd;
	}
	public void setAdtInsFunctionCd(String adtInsFunctionCd) {
		this.adtInsFunctionCd = adtInsFunctionCd;
	}
	
	@Column(name="ADT_UPD_FUNCTION_CD")
	public String getAdtUpdFunctionCd() {
		return adtUpdFunctionCd;
	}
	public void setAdtUpdFunctionCd(String adtUpdFunctionCd) {
		this.adtUpdFunctionCd = adtUpdFunctionCd;
	}
	
	@Column(name="LAST_LOGIN_DTTM")
	public Date getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
	
	@Column(name="LOGIN_STS")
	public String getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}
	
	@Column(name="ADT_INS_USER_NM")
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name="ADT_UPD_USER_NM")
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	@Column(name="ADT_INS_DTTM")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreatedDateTime() {
		return createdDateTime;
	}
	
	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	
	@Column(name="ADT_UPD_DTTM")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}
	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}
}
