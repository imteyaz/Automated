package com.minapro.communicationServer.exception;

import java.util.Date;

/**
 * Application level Exception wrapper to be used
 * @author Rosemary George
 *
 */
public class MinaProAppException extends Exception
{

	private static final long serialVersionUID = 2361182336785766503L;
	
	private String errorMessage;
	private Date exceptionDate;
	private ErrorCode errorCode;
	
	public MinaProAppException(ErrorCode exceptionCode, String errorMessage)
	{
		super(errorMessage);
		this.exceptionDate = new Date();
		this.errorMessage = errorMessage;
		this.errorCode = exceptionCode;		
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getExceptionDate() {
		return exceptionDate;
	}

	public void setExceptionDate(Date exceptionDate) {
		this.exceptionDate = exceptionDate;
	}

	public ErrorCode getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(ErrorCode errorCode) {
		this.errorCode = errorCode;
	}
	
	
}
