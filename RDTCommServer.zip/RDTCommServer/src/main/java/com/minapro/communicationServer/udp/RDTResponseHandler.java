package com.minapro.communicationServer.udp;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import com.minapro.communicationServer.common.ActiveMessage;
import com.minapro.communicationServer.common.ActiveMsgDtls;
import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.db.OPERATOR;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * RDTResponseHandler reads the active responses from Cache and sends to devices on configured port number.
 * 
 * @author 3128828 version 1.0
 * 
 */
public class RDTResponseHandler extends Thread {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTResponseHandler.class);
	private static final String RESP = "RESP";
	private static final String NOTIF = "NOTIF";

	// UDP Socket
	private RUDPSocket dgramSocket = null;

	// Boolean value for continues cache reading
	public boolean ThreadRunning = true;

	public RDTResponseHandler() {
		try {
			dgramSocket = RUDPSocket.getRUDPSocket(RDTResponseHandler.class);
		} catch (Exception ex) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception While Opening the Response Sending Socket :" + ex);
		}
	}

	/**
	 * Reads active responses from cache and make use of SendMessage( ActiveMsgDtls ) to send back to the devices
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public void run() {

		logger.logMsg(LOG_LEVEL.DEBUG, "", "Starting RDTResponseHandler");

		while (ThreadRunning) {
			try {

				// Check if cache is NULL
				if (RDTCacheManager.getInstance().MinaproActiveResponseList == null) {
					logger.logMsg(LOG_LEVEL.DEBUG, "", "Active Response Cache is null");
					continue;
				} else {
					// Get all the Active responses's from cache
					Set<String> keyset = RDTCacheManager.getInstance().MinaproActiveResponseList.keySet();

					if (keyset.size() != 0) {
						// Iterating through individual active responses
						for (Iterator<String> i = keyset.iterator(); i.hasNext();) {
							String activeResp = i.next();

							ActiveMessage message = RDTCacheManager.getInstance().getActiveMessage(activeResp);
							if (message == null) {
								logger.logMsg(LOG_LEVEL.DEBUG, "", "retrieved active message is null. skipping");
								continue;
							}

							long timeDiff = new Date().getTime() - message.getSentTime().getTime();
							if (timeDiff < 2000) {
								logger.logMsg(LOG_LEVEL.DEBUG, "", "Message sent time is less than 2 second, Ignoring");
								continue;
							}

							checkAndRetryMessage(message, activeResp);
						}
					}
				}
			} catch (Exception e) {
				logger.logException("Exception While handling the Response Cache :" , e);
			} finally {
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e) {
					logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception in Thread :" + e);
				}
			}
		}
	}

	/**
	 * Checks the retry count of the active message, if it is less than the configured value, sends the message
	 * again to the associated ip:port
	 * 
	 * @param message
	 * @param activeResp
	 */
	private void checkAndRetryMessage(ActiveMessage message, String activeResp) {
		ActiveMsgDtls receivedmsg1 = new ActiveMsgDtls();
		try {
			// Get Device IP for the active response
			receivedmsg1.setAddress(message.getDeviceIP());

			String tokens[] = activeResp.split(RDTServerMain.DELIMITER);
			String eventType = tokens[0];
			String userName = tokens[tokens.length - 2];

			receivedmsg1.setPortNumber(message.getPort());
			if (message.getPort() == null || message.getPort() == 0) {
				logger.logMsg(LOG_LEVEL.WARN, "",
						"Port associated with the message is null or 0. Getting based on role");
				OPERATOR role = RDTCacheManager.getInstance().gerUserLoggedInRole(userName);
				if(role.equals(OPERATOR.COMMON)){
					return;
				}
				receivedmsg1.setPortNumber(getPortAssignedForRole(role, eventType));
			}

			logger.logMsg(LOG_LEVEL.DEBUG, userName, "Response belongs to :" + userName);
			activeResp = activeResp.substring(activeResp.indexOf(RDTServerMain.DELIMITER) + 1);
			receivedmsg1.setResponseMessage(activeResp);

			if (RDTCacheManager.getInstance().checkResponseRetriesEntry(receivedmsg1.getResponseMessage())) {
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "size of response cache:"
						+ RDTCacheManager.getInstance().MinaproResponseRetiriesCache.size());

				int noOfTimesRetried = RDTCacheManager.getInstance().getRetriedCount(receivedmsg1.getResponseMessage());
				logger.logMsg(LOG_LEVEL.DEBUG, userName, " Retry Count :" + (noOfTimesRetried + 1));

				if (noOfTimesRetried >= (RDTServerMain.NOOFRESPRETRIES - 1)
						|| !RDTCacheManager.getInstance().checkUserNameMappinpEntry(userName)) {

					// Retries Expired or User logged out,removing entry from Response Cache
					if (RESP.equalsIgnoreCase(eventType)) {
						RDTCacheManager.getInstance().removeActiveResponsepEntry(
								RESP + RDTServerMain.DELIMITER + receivedmsg1.getResponseMessage());
					} else if (NOTIF.equalsIgnoreCase(eventType)) {
						RDTCacheManager.getInstance().removeActiveResponsepEntry(
								NOTIF + RDTServerMain.DELIMITER + receivedmsg1.getResponseMessage());
					}

					// Retries Expired or User logged out,removing entry from Retry Cache
					RDTCacheManager.getInstance().removeMinaproResponseRetiriesEntry(receivedmsg1.getResponseMessage());

				} else {
					// Increase the count of retries done
					RDTCacheManager.getInstance().addResponseRetiriesEntry(receivedmsg1.getResponseMessage(),
							++noOfTimesRetried);
				}
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, userName, " Retry Count :" + 1);
				// Populate retries cache
				RDTCacheManager.getInstance().addResponseRetiriesEntry(receivedmsg1.getResponseMessage(), 1);
			}

			// in case of Unauthorized user, do not retry, just ignore
			if ("1201".equals(tokens[3])) {
				RDTCacheManager.getInstance().removeActiveResponsepEntry(
						RESP + RDTServerMain.DELIMITER + receivedmsg1.getResponseMessage());
				RDTCacheManager.getInstance().removeMinaproResponseRetiriesEntry(receivedmsg1.getResponseMessage());
			} else if (!RDTCacheManager.getInstance().checkUserNameMappinpEntry(userName)) {
				// User Logged out,removing entry from Response Cache
				if (RESP.equalsIgnoreCase(eventType)) {
					RDTCacheManager.getInstance().removeActiveResponsepEntry(
							RESP + RDTServerMain.DELIMITER + receivedmsg1.getResponseMessage());
				} else if (NOTIF.equalsIgnoreCase(eventType)) {
					RDTCacheManager.getInstance().removeActiveResponsepEntry(
							NOTIF + RDTServerMain.DELIMITER + receivedmsg1.getResponseMessage());
				}

				// User Logged out,removing entry from Retry Cache
				RDTCacheManager.getInstance().removeMinaproResponseRetiriesEntry(receivedmsg1.getResponseMessage());
			} else {
				// Sends to device
				this.SendMessage(receivedmsg1);
			}
		} catch (Exception ex) {
			logger.logException("Exception While handling the Retries Cache :" , ex);
		}
	}

	/**
	 * Retrieves the port number associated with the specified role for the specified eventType
	 * 
	 * @param role
	 * @param eventType
	 * @return port number associated with the role
	 */
	private int getPortAssignedForRole(OPERATOR role, String eventType) {
		int port = 0;
		if ("RESP".equalsIgnoreCase(eventType)) {
			if (role.equals(OPERATOR.QC)) {
				port = RDTServerMain.QC_DEVICEPORT;
			} else if (role.equals(OPERATOR.CHE)) {
				port = RDTServerMain.CHE_DEVICEPORT;
			} else if (role.equals(OPERATOR.ITV)) {
				port = RDTServerMain.ITV_DEVICEPORT;
			} else {
				port = RDTServerMain.MAN_DEVICEPORT;
			}
		} else if ("NOTIF".equalsIgnoreCase(eventType)) {
			if (role.equals(OPERATOR.QC)) {
				port = RDTServerMain.QC_NOTIFICATIONPORT;
			} else if (role.equals(OPERATOR.CHE)) {
				port = RDTServerMain.CHE_NOTIFICATIONPORT;
			} else if (role.equals(OPERATOR.ITV)) {
				port = RDTServerMain.ITV_NOTIFICATIONPORT;
			} else {
				port = RDTServerMain.MAN_NOTIFICATIONPORT;
			}
		}
		return port;
	}

	/**
	 * Sends the active responses received from RDT Processing server to Devices
	 * 
	 * @param ActiveMsgDtls
	 * @return Nothing.
	 */
	public void SendMessage(ActiveMsgDtls msg) {
		InetAddress maddr = null;
		int port = msg.getPortNumber();
		byte b[] = null;
		String data = null;
		try {

			data = msg.getResponseMessage();
			try {
				maddr = InetAddress.getByName(msg.getAddress());
				b = data.getBytes("US-ASCII");
			} catch (UnsupportedEncodingException e1) {
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception while encoding :" + e1);
			}

			RUDPSocket socket = this.dgramSocket;
			socket.send(new DatagramPacket(b, b.length, maddr, port));
			logger.logMsg(LOG_LEVEL.DEBUG, "",
					" Sent Reponse to :" + msg.getAddress() + ":" + port + "----> " + msg.getResponseMessage());

		} catch (IOException ioe) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception while Sending the data :" + ioe);
		} finally {
			maddr = null;
			b = null;
		}
	}
}
