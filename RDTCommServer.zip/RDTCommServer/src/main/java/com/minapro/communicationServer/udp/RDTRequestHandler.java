package com.minapro.communicationServer.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import com.minapro.communicationServer.common.ActiveMsgDtls;
import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.exception.ErrorCode;
import com.minapro.communicationServer.exception.MinaProAppException;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * RDTRequestHandler Opens UDP Socket for receiving events form Devices. Sends immediate Acknowledgment with EventType.
 * 
 * @author 3128828 version 1.0
 * 
 */

public class RDTRequestHandler extends Thread {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTRequestHandler.class);

	// UDP Socket
	private RUDPSocket udpServer; 

	 // Received Event details
	private ActiveMsgDtls receivedmsg1 = new ActiveMsgDtls();

	public RDTRequestHandler() {
	}

	/**
	 * Opens the UDP Socket to receive events and make use of SendMessage( ActiveMsgDtls, RUDPSocket ) to send immediate
	 * Ack back
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public void run() {

		try {
			udpServer = RUDPSocket.getRUDPSocket(RDTServerMain.SERVERPORT, RDTRequestHandler.class);
		} catch (Exception e) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception While Opening UDP Socket :" + e);
			return;
		}

		byte[] buf = new byte[1024];
		DatagramPacket rcvdPacket = new DatagramPacket(buf, 1024);

		String userName = null;
		
		// Continuous listening on UDP socket
		while (true) {

			// Receiving UDP packet
			try {
				udpServer.receive(rcvdPacket);
			} catch (IOException e) {
				logger.logMsg(LOG_LEVEL.ERROR, "Unable to read message from UDP socket", e.getMessage());
			}

			String receivedmsg = new String(rcvdPacket.getData());
			receivedmsg = receivedmsg.substring(0, rcvdPacket.getLength());

			logger.logMsg(LOG_LEVEL.DEBUG, "Incoming Request :", receivedmsg);			

			// Extract eventType, eventId and UserName from message
			String[] eventTokens = receivedmsg.split(RDTServerMain.DELIMITER);

			receivedmsg1.setRequestMessage(receivedmsg);
			receivedmsg1.setSplitEventNumber(eventTokens[0]);
			receivedmsg1.setNumberOfpkts(eventTokens[1]);
			receivedmsg1.setEventType(eventTokens[2]);
			receivedmsg1.setEventId(eventTokens[3]);

			userName = eventTokens[4];
			
			/*
			 * Checking whether incoming Message contains multiple packets or single packet if it comes with prefix
			 * "packet#~NoOfPackets#" (eg : 1~4~....) then it is a first packet out of 4 packets. if it has packet# >
			 * NoOfPackets# (eg: 4~1... ) then Considering it has wrong message format.
			 */

			if ("1".equalsIgnoreCase(receivedmsg1.getSplitEventNumber())
					&& ("1".equalsIgnoreCase(receivedmsg1.getNumberOfpkts()))) {
				receivedmsg1.setIsSplit(false);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received a single packet request ");
			} else if (Integer.parseInt((receivedmsg1.getSplitEventNumber())) > Integer.parseInt((receivedmsg1
					.getNumberOfpkts()))) {
				// Messages received with wrong format
				try {
					throw new MinaProAppException(ErrorCode.FORMAT_EXCEPTION,
							ErrorCode.FORMAT_EXCEPTION.getErrorMessage());
				} catch (MinaProAppException ex) {
					logger.logMsg(LOG_LEVEL.ERROR, "", ex.getErrorMessage());
					continue;
				}
			} else {
				receivedmsg1.setIsSplit(true);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Request contains multiple packets ");

				if (!RDTCacheManager.getInstance().eventMergerCache.containsKey(receivedmsg1.getEventId())) {
					// Populating eventMergerCache to collect all the
					// packets corresponds to single eventId
					String[] mergerCacheArray = new String[Integer.parseInt(receivedmsg1.getNumberOfpkts())];
					RDTCacheManager.getInstance().addEventToMergerCache(receivedmsg1.getEventId(), mergerCacheArray);
					RDTCacheManager.getInstance().addCounttoPcktCache(receivedmsg1.getEventId(), 0);
				}
			}

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Message From :" + rcvdPacket.getAddress().getHostAddress() + " Port :"
					+ rcvdPacket.getPort() + " with UserName :" + userName);

			// Extract Device Ip and port from incoming message
			receivedmsg1.setAddress(rcvdPacket.getAddress().getHostAddress());
			receivedmsg1.setPortNumber(rcvdPacket.getPort());

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Sent message to Master Actor");
			// Pushing events to RDT_OUTQ through Actor system
			RDTServerMain.getMasterActor().tell(receivedmsg1, null);
			
			// Sending Immediate Ack to the Device
			SendMessage(receivedmsg1, udpServer);
		}
	}
	

	/**
	 * Sends the immediate Ack to the devices with EventType
	 * 
	 * @param ActiveMsgDtls
	 * @param RUDPSocket
	 * @return Nothing.
	 */

	public static void SendMessage(ActiveMsgDtls msg, RUDPSocket sock) {
		InetAddress maddr = null;
		int port = msg.getPortNumber();
		byte b[] = null;
		String data = null;
		try {
			data = msg.getSplitEventNumber() + RDTServerMain.DELIMITER + msg.getNumberOfpkts()
					+ RDTServerMain.DELIMITER + msg.getEventType() + RDTServerMain.DELIMITER + msg.getEventId();
			maddr = InetAddress.getByName(msg.getAddress());
			b = data.getBytes("US-ASCII");

			DatagramSocket socket = sock;
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending Immediate ACK : " + data + " " + "to port :" + port);
			socket.send(new DatagramPacket(b, b.length, maddr, port));
		} catch (IOException ioe) {
			logger.logMsg(LOG_LEVEL.ERROR, "Error while forming delemeted message", ioe.getMessage());
		} finally {
			maddr = null;
			b = null;
		}
	}
}
