package com.minapro.communicationServer.actors;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import akka.actor.UntypedActor;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;
import com.minapro.communicationServer.common.ActiveMsgDtls;
import com.minapro.communicationServer.common.PasswordDecryption;
import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.common.VersionDetailsEvent;
import com.minapro.communicationServer.db.DeviceMaster;
import com.minapro.communicationServer.db.OPERATOR;
import com.minapro.communicationServer.db.User;
import com.minapro.communicationServer.db.UserRole;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;
import com.minapro.communicationServer.udp.RUDPSocket;

/**
 * Akka Actor validates User with MinaproDB and forwards the requests received from devices to RDT Processing server
 * 
 * @author 3128828 version 1.0
 * 
 */

public class RDTRequestProcessActor extends UntypedActor {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTRequestProcessActor.class);
	private static final String ITV = "ITV";
	private static final String HC = "HC";
	private static final String QC = "QC";
	private static final String CHE = "CHE";
	private static final String TSC = "TSC";
	private static final String FOREMAN = "FOREMAN";

	// To control the message delivery
	private static final Boolean NON_TRANSACTED = false;

	// Factory name specified in jndi.properties
	private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";

	// JNDI name of ActiveMQ Virtual Queue
	private static final String T2_DESTINATION_NAME = "queue/t2_rdt_outQ";
	private static final String T1_DESTINATION_NAME = "queue/t1_rdt_outQ";

	// Flag to send Non-Persistent messages
	private static MessageProducer producer = null;
	private static Session session = null;
	private static Destination destination2 = null;
	private static Destination destination1 = null;
	private static Connection connection = null;
	private static String terminalId = null;
	private int iterationCount = 1000;
	private int keySize = 128;

	public RDTRequestProcessActor() {
	}

	static {
		// Read jndi.properties in classpath
		Context context;
		try {
			context = new InitialContext();
			ConnectionFactory factory = (ConnectionFactory) context.lookup(CONNECTION_FACTORY_NAME);
			// Reading destinations from jndi.prperties
			destination1 = (Destination) context.lookup(T1_DESTINATION_NAME);
			destination2 = (Destination) context.lookup(T2_DESTINATION_NAME);

			// Starting connection and session
			connection = factory.createConnection();
			connection.start();

		} catch (Exception e) {
			logger.logException("Context initialization failed for RDTRequestProcessActor", e);
		}
	}

	@Override
	/**
	 * Opens Connection with Queue, validates User, sets message identifier and push it to the RDT_OUTQ 
	 * In case of Unauthorised User, sends the Login failed response back to device
	 *  
	 * @param Object
	 * @return Nothing.
	 */
	public void onReceive(Object msg) throws Exception {
		String role = null;
		User userObj = null;
		String passWord = null;
		String deviceId = null;

		if (msg instanceof ActiveMsgDtls) {

			ActiveMsgDtls recivedMessage = (ActiveMsgDtls) msg;
			String receivedEvent = recivedMessage.getRequestMessage();

			String incomingIP = recivedMessage.getAddress();
			String[] eventTokens = receivedEvent.split(RDTServerMain.DELIMITER);

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Received request Event: " + receivedEvent);

			String eventID = eventTokens[2];
			String eventType = eventTokens[3];
			String userName = eventTokens[4];
			terminalId = eventTokens[5];

			String request = eventTokens[0] + RDTServerMain.DELIMITER + eventTokens[1] + RDTServerMain.DELIMITER
					+ eventTokens[2] + RDTServerMain.DELIMITER + eventTokens[3];

			try {

				if (!RDTCacheManager.getInstance().checkRepeatedRequestEntry(request)) {

					RDTCacheManager.getInstance().addUserToRequestCacheEntry(request, userName);
					//LOGIN event will have password
					if ((RDTServerMain.LOGIN.equals(eventID))) {
						String ciphertext = eventTokens[7];
						deviceId = eventTokens[8];
						role = eventTokens[9];

						String salt = eventTokens[10];
						String iv = eventTokens[11];

						// Decrypting the encrypted password received from User
						passWord = PasswordDecryption.getInstance().decrptedPassowrd(keySize, iterationCount, salt, iv,
								ciphertext);

						eventTokens[7] = passWord;
						// Decrypted Login Request
						StringBuilder loginMsg = new StringBuilder();
						for (String s : eventTokens) {
							loginMsg.append(s);
							loginMsg.append(RDTServerMain.DELIMITER);
						}

						// Sending decrypted password to Processing Server
						receivedEvent = loginMsg.toString();
					}

					// Fetch User info from DB
					userObj = RDTCacheManager.getInstance().getUserObject(userName);

					// Removing first two tokens from incoming message since processing
					// server does not require these tokens
					receivedEvent = receivedEvent.substring((eventTokens[0] + RDTServerMain.DELIMITER 
							+ eventTokens[1] + RDTServerMain.DELIMITER).length());

					if (RDTServerMain.LOGIN.equals(eventID)) {

						logger.logMsg(LOG_LEVEL.DEBUG, "", "This is Login Request, requires Authentication");
						
						DeviceMaster device = HibernateSession.checkDeviceID(deviceId);
						logger.logMsg(LOG_LEVEL.DEBUG, deviceId, "Login Request, checking device configuration - " + device);
						if(device == null){
							logger.logMsg(LOG_LEVEL.DEBUG, "", "WRONG Device details");
							String wrongDeviceMessage = "1~1~1201~" + eventType + RDTServerMain.DELIMITER
									+ userName + RDTServerMain.DELIMITER + "Wrong device details. Please configure using correct device ID";
							sendLoginFailureResponse(wrongDeviceMessage, userName, role, incomingIP,
									recivedMessage.getPortNumber());
						}else if (userObj != null && "Y".equalsIgnoreCase(userObj.getLoginStatus())) {
							logger.logMsg(LOG_LEVEL.DEBUG, "", "User already Logged In");
							String alreadyLoggedInmessage = "1~1~1201~" + eventType + RDTServerMain.DELIMITER
									+ userName + RDTServerMain.DELIMITER + "Already Logged In";
							sendLoginFailureResponse(alreadyLoggedInmessage, userName, role, incomingIP,
									recivedMessage.getPortNumber());
						} else {
							// Check User authentication with MinaproDB
							boolean validate = checkUserAccess(passWord, userObj, role);

							if (!validate) {
								logger.logMsg(LOG_LEVEL.DEBUG, "", "Unauthorised User :" + userName);
								String loginfailedmessage = "1~1~1201~" + eventType + RDTServerMain.DELIMITER
										+ userName + RDTServerMain.DELIMITER + "Unauthorised User";
								// Sends failed login response back to device
								sendLoginFailureResponse(loginfailedmessage, userName, role, incomingIP,
										recivedMessage.getPortNumber());
							} else {
								logger.logMsg(LOG_LEVEL.DEBUG, "", "Authorised User :" + userName);
								boolean isExists = HibernateSession.checkAlreadyLoggedInWithSameDeviceID(deviceId);

								if (!isExists) {
									initiateVersionCheck(device.getCurrentOsVersion(), role, incomingIP);								
									
									/*
									 * Persisting User & device Id's of incoming request into table to avoid address
									 * loss in case of Server restart
									 */
									logger.logMsg(LOG_LEVEL.DEBUG, "", "Inserting " + " " + userName + " " + "and"
											+ " " + deviceId + " " + "into user_device_mapping Table:");

									HibernateSession.insertUserDeviceMapping(userName, deviceId, userObj.getIntUserId());
									RDTCacheManager.getInstance().addDeviceToUserMapping(deviceId, userName);
									RDTCacheManager.getInstance().setUserLoggedInRole(userObj.getUserID(), role);

									// updating login status in database UserDetails table
									HibernateSession.updateUserLoginStatus("Y", userObj.getIntUserId());

									// Update UserInfo in Cache
									userObj = RDTCacheManager.getInstance().getUserObject(userName);
									userObj.setLoginStatus("Y");
									RDTCacheManager.getInstance().addUserInfoToList(userName, userObj);

									logger.logMsg(LOG_LEVEL.DEBUG, "", "Populating DevicemapCache with" + " "
											+ userName + " and IP :" + incomingIP);

									RDTCacheManager.getInstance().addUserNameMappinpEntry(userName, incomingIP);

									// Forwards Login request event to RDT Processing server
									SendMessage(receivedEvent, userName, role);

									// Persisting incoming request into DB
									getSender().tell("journal" + RDTServerMain.DELIMITER + receivedEvent, null);

								} else {
									logger.logMsg(LOG_LEVEL.DEBUG, "", "DeviceId Already exists");
									String mappedUserID = RDTCacheManager.getInstance().getDeviceMapping(deviceId);
									logger.logMsg(LOG_LEVEL.DEBUG, "", "Mapped UserID :" + mappedUserID);
									String deviceIDAlreadyInUse = "1~1~1201~" + eventType + RDTServerMain.DELIMITER
											+ userName + RDTServerMain.DELIMITER + "DeviceID Already In Use";
									sendLoginFailureResponse(deviceIDAlreadyInUse, userName, role, incomingIP,
											recivedMessage.getPortNumber());
								}
							}
						}
					} else if(RDTServerMain.VERSION_EVENT.equals(eventID)) {
						handleVersionUpdateStatus(receivedEvent);
					}else {
						if (RDTCacheManager.getInstance().UserIdAddressmapping.containsKey(userName)) {
							SendMessage(receivedEvent, userName, role);
						} else {
							logger.logMsg(LOG_LEVEL.INFO, userName, "User already logged out");
						}

						// Persisting incoming request into DB
						getSender().tell("journal" + RDTServerMain.DELIMITER + receivedEvent, null);

						if (RDTServerMain.LOGOUT.equals(eventID)) {
							handleLogoutScenario(userObj, userName);
						}
					}
				} else {
					logger.logMsg(LOG_LEVEL.DEBUG, "", "Received a repeated request from User :" + userName);
					logger.logMsg(LOG_LEVEL.DEBUG, "", "Repeated Req :" + request);
				}
			} catch (Exception e) {
				logger.logException("Caught Exception while processing RDTRequestProcessActor - ", e);
			}

		} else {
			unhandled(msg);
		}
	}
	

	private void handleVersionUpdateStatus(String receivedEvent) {
		logger.logMsg(LOG_LEVEL.INFO, "VERSION_STATUS", "Recieved version status message from UI- " + receivedEvent);
		String[] tokens = receivedEvent.split(RDTServerMain.DELIMITER);
		
		String status = tokens[3];
		if("true".equalsIgnoreCase(status)){
			DeviceMaster device = HibernateSession.checkDeviceID(tokens[2]);
			logger.logMsg(LOG_LEVEL.INFO, tokens[2], "Retrieved the Device -" +device);
			
			if(device != null){
				device.setCurrentOsVersion(tokens[4]);
				HibernateSession.updateDevice(device);
			}
		}
	}


	/**
	 * Initiates the version check event and send to master actor for further processing
	 * @param currentVersion
	 * @param role
	 * @param address
	 */
	private void initiateVersionCheck(String currentVersion, String role, String address) {
		VersionDetailsEvent versionCheck = new VersionDetailsEvent();
		versionCheck.setRole(role);
		versionCheck.setVersionNumber(currentVersion);
		versionCheck.setAddress(address);
		versionCheck.setEventId(UUID.randomUUID().toString());
		
		logger.logMsg(LOG_LEVEL.INFO, address, "Sending version check message to master actor - " + versionCheck);
		getSender().tell(versionCheck, null);
	}


	/**
	 * Handles the logout request from device.. Removes all the cache reference for the specified user
	 * 
	 * @param userObj
	 * @param userName
	 */
	private void handleLogoutScenario(User userObj, String userName) {
		try {
			// updating login status in database UserDetails table
			HibernateSession.updateUserLoginStatus("N", userObj.getIntUserId());

			userObj.setLoginStatus("N");
			RDTCacheManager.getInstance().addUserInfoToList(userName, userObj);

			// Also remove entry from User_device_Mapping Table
			HibernateSession.deleteUserDeviceMapping(userName);

			// Remove UserMapping entry from DeviceMapCache
			RDTCacheManager.getInstance().removeUserNameMappinpEntry(userName);
			RDTCacheManager.getInstance().removeDeviceToUserMapping(userName);

			// Delete me
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Values in DevicemapCache after Logout:");
			// Get all the Active responses's from cache
			Set<String> keyset = RDTCacheManager.getInstance().UserIdAddressmapping.keySet();

			if (keyset.size() != 0) {
				// Iterating through individual active responses
				for (Iterator<String> i = keyset.iterator(); i.hasNext();) {
					String user = i.next();
					logger.logMsg(LOG_LEVEL.DEBUG, "", "User ID :" + user + " IP : "
							+ RDTCacheManager.getInstance().getDeviceIp(user));
				}
			}
		} catch (Exception ex) {
			logger.logException("Caught exception while handling the logout message from device", ex);
		}
	}

	/**
	 * Validate User against MinaproDB User table
	 * 
	 * 
	 * @param loginPasswd
	 * @return User.
	 */
	public boolean checkUserAccess(String loginPasswd, User userInfo, String role) {

		logger.logMsg(LOG_LEVEL.DEBUG, "", "checkUserAccess :" + "Validate Authentication");

		// if user entry not present in database
		if (userInfo == null) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "User Info from DB is NULL");
			return false;
		}

		boolean result = false;
		if (RDTCacheManager.getInstance().userCache.containsKey(userInfo.getUserID())) {

			String dbUserSalt = userInfo.getSalt();
			String dbUserIv = userInfo.getIv();
			String dbCiphertext = userInfo.getPassword();

			if (dbCiphertext == null || dbCiphertext.isEmpty() || dbUserIv == null || dbUserIv.isEmpty()
					|| dbUserSalt == null || dbUserSalt.isEmpty()) {
				logger.logMsg(LOG_LEVEL.WARN, userInfo.getUserID(),
						"failed to get password decryping things from DB, failing login");
				return false;
			}

			// Get the decrypted password
			String dbpasswd = PasswordDecryption.getInstance().decrptedPassowrd(keySize, iterationCount, dbUserSalt,
					dbUserIv, dbCiphertext);
			boolean validRole = false;

			for (UserRole roleObj : userInfo.getActualRoles()) {
				if (roleObj.getRole_name().equalsIgnoreCase(role)) {
					validRole = true;
				}
			}
			if (dbpasswd.equals(loginPasswd) && validRole) {
				result = true;
			}
		}

		return result;
	}

	/**
	 * Forwards incoming request to Processing server through RDT_OUTQ and sends login failed response back to device in
	 * case of invalid user
	 * 
	 * @param msg
	 * @param deviceId
	 */
	public static void SendMessage(String msg, String userName, String role) {
		try {
			session = connection.createSession(NON_TRANSACTED, Session.AUTO_ACKNOWLEDGE);
			// Setting producer to destination

			TextMessage message = session.createTextMessage();
			message.setText(msg);
			OPERATOR operatorRole = RDTCacheManager.getInstance().gerUserLoggedInRole(userName);
			if (ITV.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", ITV);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is ITV event");
			} else if (QC.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", QC);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is QC event");
			} else if (HC.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", HC);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is HC event");
			} else if (CHE.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", CHE);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is CHE event");
			} else if (TSC.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", TSC);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is TSC event");
			} else if (FOREMAN.equalsIgnoreCase(operatorRole.toString())) {
				message.setStringProperty("eventGenerator", FOREMAN);
				logger.logMsg(LOG_LEVEL.DEBUG, "", "It is OBF event");
			}

			if ("T1".equals(terminalId)) {
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Sending Requst to : " + destination1.toString()
						+ " Event is: '" + message.getText() + "'");
				producer = session.createProducer(destination1);
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, userName, "Sending Requst to : " + destination2.toString()
						+ " Event is: '" + message.getText() + "'");
				producer = session.createProducer(destination2);
			}	
			producer.send(message);
			producer.close();
		} catch (Exception e) {
			logger.logMsg(LOG_LEVEL.DEBUG, userName, "Exception while handling TextMessage :" + e);
		} finally {
			try {
				session.close();
			} catch (JMSException e) {
			}
		}
	}

	/**
	 * Sends the login failure response with proper error message is sent to the device
	 * 
	 * @param data
	 * @param userInfo
	 * @param role
	 * @param iPAddress
	 * @param port
	 */
	private void sendLoginFailureResponse(String data, String userName, String role, String iPAddress, Integer port) {

		RUDPSocket udpSocket = RUDPSocket.getRUDPSocket(RDTRequestProcessActor.class);
		InetAddress maddr = null;
		byte b[] = null;

		if (port == null || port == 0) {
			logger.logMsg(LOG_LEVEL.WARN, iPAddress, "associated port is null or 0, retrieving it based on ROLE -"
					+ role);
			if (QC.equalsIgnoreCase(role)) {
				port = RDTServerMain.QC_DEVICEPORT;
			} else if ("RMG".equalsIgnoreCase(role) || "RTG".equalsIgnoreCase(role) || CHE.equalsIgnoreCase(role)) {
				port = RDTServerMain.CHE_DEVICEPORT;
			} else if (ITV.equalsIgnoreCase(role)) {
				port = RDTServerMain.ITV_DEVICEPORT;
			} else {
				port = RDTServerMain.MAN_DEVICEPORT;
			}
		}

		try {
			maddr = InetAddress.getByName(iPAddress);
			b = data.getBytes("US-ASCII");
			
			DatagramSocket socket = udpSocket;
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Sending  FailedLoginResponse to User  :" + userName);
			socket.send(new DatagramPacket(b, b.length, maddr, port));

			String loginFailedMsg = "RESP" + RDTServerMain.DELIMITER + data;
			logger.logMsg(LOG_LEVEL.DEBUG, "populating ActiveResponse cache :", loginFailedMsg);

			// Populate ResponseCache with ActiveResponse for retries
			RDTCacheManager.getInstance().addActiveResponsepEntry(loginFailedMsg.replaceAll("null", ""), iPAddress,
					port);

			logger.logMsg(LOG_LEVEL.DEBUG, "populating ackToResponse cache :", loginFailedMsg);
			// Populate ackToResponse cache with expected Ack for response
			String[] messageTokens = loginFailedMsg.split(RDTServerMain.DELIMITER);
			RDTCacheManager.getInstance().addAckToResponseEntry("1~1~1201~" + messageTokens[3], loginFailedMsg);

		} catch (IOException ioe) {
			logger.logException("Exception while forwarding message to Proc Server", ioe);
		} finally {
			maddr = null;
			b = null;
		}
	}

	@Override
	public void postStop() throws Exception {
		super.postStop();
		logger.logMsg(LOG_LEVEL.DEBUG, " ", "Closing RDT Request Process Actor and all ActiveMQ Sessions :");
		// got to clean up the connections and other resources!
		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException e) {
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception while closing the ActiveMQ Connection :" + e);
			}
		}
	}
}
