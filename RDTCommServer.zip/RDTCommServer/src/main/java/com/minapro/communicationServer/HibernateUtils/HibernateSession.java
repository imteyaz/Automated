package com.minapro.communicationServer.HibernateUtils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.db.ApplicationParameter;
import com.minapro.communicationServer.db.DeviceMapping;
import com.minapro.communicationServer.db.DeviceMaster;
import com.minapro.communicationServer.db.Journal;
import com.minapro.communicationServer.db.JournalPK;
import com.minapro.communicationServer.db.User;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;

/**
 * HibernateSession responsible for Opening and closing the sessions with DB during the update, delete and inserting
 * transactions
 * 
 * @author 3128828 version 1.0
 * 
 */

public class HibernateSession {

	private static SessionFactory sessionFactory = buildSessionFactory();
	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(RDTServerMain.class);
	
	private static final String DELETE_DEVICEMAPPING_QUERY = "DELETE FROM DeviceMapping";
	private static final String RETRIEVE_DEVICEMAPPING_QUERY = "FROM DeviceMapping";
	private static final String RETRIEVE_USERS_QUERY = "FROM User";
	private static final String RETRIEVE_LATEST_APP_VERSION_QUERY = "FROM ApplicationParameter where parameterCode= :role_version";
	
	/**
	 * Method to create the sessionFactory with DB 
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public static SessionFactory buildSessionFactory() {
		try {
			Configuration conf = new Configuration().configure();
			StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(conf
					.getProperties());
			sessionFactory = conf.buildSessionFactory(builder.build());

			return sessionFactory;
		} catch (RuntimeException ex) {
			logger.logException("Failed to create sessionFactory object.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	/**
	 * Gets the session factory
	 * 
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * Method to populate the UserCache from User table for configurable sec (USER_TABLE_POLLING)
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	@SuppressWarnings("unchecked")
	public static void updateUserTableCache() {
		Session session = null;
		Transaction transaction = null;
		List<User> list = null;

		ArrayList<String> oldUsers = new ArrayList<String>();
		ArrayList<String> newlyAddedUsers = new ArrayList<String>();

		try {
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();
			list = session.createQuery(RETRIEVE_USERS_QUERY).list();
			transaction.commit();

			oldUsers.addAll(RDTCacheManager.getInstance().userCache.keySet());

			for (int i = 0; i < list.size(); i++) {
				User user = list.get(i);
				RDTCacheManager.getInstance().addUserInfoToList(user.getUserID(), user);
			}

			newlyAddedUsers.addAll(RDTCacheManager.getInstance().userCache.keySet());

			newlyAddedUsers.removeAll(oldUsers);
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Fetched Users from User_master Table to userCache :" + newlyAddedUsers);

		} catch (Exception ex) {
			logger.logException("Failed to fetch Users info from  MP_USRDTLS_AM table ", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Method to populate the UsermapCache<User,IP> from device Master table
	 * 
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public static void deleteDeviceMapEntries() {
		logger.logMsg(LOG_LEVEL.DEBUG, "", "=========Deleting entries from device master Table if any===========");

		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.getCurrentSession();

			transaction = session.beginTransaction();
			session.createQuery(DELETE_DEVICEMAPPING_QUERY).executeUpdate();
			transaction.commit();

		} catch (Exception ex) {
			logger.logException("Failed to delete entries from  DeviceMap table ", ex);
			session.getTransaction().rollback();
		}
	}

	@SuppressWarnings("unchecked")
	public static boolean checkAlreadyLoggedInWithSameDeviceID(String deviceID) {

		Session session = null;
		Transaction transaction = null;
		List<DeviceMapping> list = null;
		boolean isEntryExists = false;
		try {
			session = sessionFactory.getCurrentSession();

			transaction = session.beginTransaction();
			list = session.createQuery(RETRIEVE_DEVICEMAPPING_QUERY).list();
			transaction.commit();
		} catch (Exception ex) {
			logger.logException("Failed to get Data from  DeviceMap table ", ex);
			session.getTransaction().rollback();
		}

		for (int i = 0; i < list.size(); i++) {
			DeviceMapping user = list.get(i);
			if (deviceID.equalsIgnoreCase(user.getDevicemaster().getDevice_id())) {
				logger.logMsg(LOG_LEVEL.DEBUG, user.getUserID(), "This DeviceID is already Exists.");
				isEntryExists = true;
			}
		}

		return isEntryExists;
	}

	/**
	 * Insert row with UserId and DeviceId into user_device_mapping table
	 * 
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public static void insertUserDeviceMapping(String userName, String deviceID, Integer userId) {
		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.getCurrentSession();

			transaction = session.beginTransaction();
			DeviceMaster master = new DeviceMaster();
			master.setDevice_id(deviceID);
			DeviceMapping mapping = new DeviceMapping();
			mapping.setUserID(userName);
			mapping.setDevicemaster(master);
			mapping.setUserKey(userId);
			session.saveOrUpdate(mapping);
			transaction.commit();
			
		} catch (Exception ex) {
			logger.logException("Failed to insert data into  DeviceMap table ", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Delete row with UserId and DeviceId from user_device_mapping table
	 * 
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */

	public static void deleteUserDeviceMapping(String userName) {

		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();
			
			DeviceMapping map = new DeviceMapping();
			map.setUserID(userName);
			
			session.delete(map);
			transaction.commit();
		} catch (Exception ex) {
			logger.logException("Failed to update the DeviceMap table ", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Insert row with event into journal table
	 * 
	 * 
	 * @param Nothing
	 * @return Nothing.
	 */
	public static void insertEventintoJournal(String event, String user_id, String event_id,
			Timestamp created_datetime, String event_type) {

		Session session = null;
		Transaction transaction = null;
		try {
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();

			JournalPK journal_pk = new JournalPK();
			journal_pk.setEvent_id(event_id);
			journal_pk.setEvent_type(event_type);
			Journal event_info = new Journal();
			event_info.setUser_id(user_id);
			event_info.setJournalpk(journal_pk);
			event_info.setCreated_datetime(created_datetime);
			event_info.setEvent(event);
			session.saveOrUpdate(event_info);
			
			transaction.commit();
		} catch (Exception ex) {
			logger.logException("Failed to insert the event into journal table ", ex);
			session.getTransaction().rollback();
		}
	}

	/**
	 * Method is responsible for Updating the existed user entity with Login stat. us
	 * 
	 * @param login_status
	 * @param Id
	 *            userId
	 */
	public static void updateUserLoginStatus(String login_status, Integer id) {
		Session session = null;
		Transaction transaction = null;

		try {
			session = sessionFactory.getCurrentSession();
			session.setFlushMode(FlushMode.COMMIT);
			transaction = session.beginTransaction();

			User user = (User) session.get(User.class, id);
			user.setLoginStatus(login_status);
			if ("Y".equalsIgnoreCase(login_status)) {
				user.setLastLogin(new Date());
			}

			session.update(user);
			transaction.commit();
		} catch (Exception ex) {
			logger.logException("Failed to update the user login status -", ex);
			transaction.rollback();
		}
	}

	@SuppressWarnings("unchecked")
	public static ApplicationParameter getLatestAppVersionForRole(String role) {
		Session session = null;
		Transaction transaction = null;
		ApplicationParameter applicationParam = null;	
		
		try {
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();
			
			logger.logMsg(LOG_LEVEL.DEBUG, role,"Getting the latest app version for the role");
			
			String paramCode = role + "_VERSION";
			List<ApplicationParameter> applicationParameters = session.createQuery(RETRIEVE_LATEST_APP_VERSION_QUERY)
					.setParameter("role_version", paramCode).list();			
			transaction.commit();
			
			if(applicationParameters != null && !applicationParameters.isEmpty()){
				applicationParam = applicationParameters.get(0);
			}
		} catch (Exception ex) {
			logger.logException("Failed to get Data from  ApplciationParameter table ", ex);
			session.getTransaction().rollback();
		}

		return applicationParam;
	}

	public static DeviceMaster checkDeviceID(String deviceID) {
		Session session = null;
		Transaction transaction = null;
		DeviceMaster data = null;

		try {
			session = sessionFactory.getCurrentSession();
			transaction = session.beginTransaction();
			data = (DeviceMaster) session.get(DeviceMaster.class, deviceID);
			transaction.commit();

		} catch (Exception ex) {
			logger.logException("Failed to get Data from  DeviceMap table ", ex);
			session.getTransaction().rollback();
		}

		return data;
	}
	
	/**
	 * Updates the Device data in the database
	 * @param device
	 */
	public static void updateDevice(DeviceMaster device) {
		Session session = null;
		Transaction tx = null;
		try {
			session = sessionFactory.getCurrentSession();
			tx = session.beginTransaction();
			session.update(device);
			tx.commit();
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Updated successfully - " + device);
		} catch (Exception ex) {
			logger.logException("Failed to update the device  " + device , ex);
			session.getTransaction().rollback();
		}
	}
}
