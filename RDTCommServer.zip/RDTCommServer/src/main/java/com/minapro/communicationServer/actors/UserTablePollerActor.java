package com.minapro.communicationServer.actors;

import akka.actor.UntypedActor;

import com.minapro.communicationServer.HibernateUtils.HibernateSession;

public class UserTablePollerActor extends UntypedActor{
   
    public void onReceive(Object msg) throws Exception {
                
        // Populate User Cache in case of any new users added in DB
        HibernateSession.updateUserTableCache();
    }
}
