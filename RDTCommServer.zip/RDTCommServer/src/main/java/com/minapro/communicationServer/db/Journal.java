package com.minapro.communicationServer.db;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * ValueObject holding the journal details
 * 
 * @author 3128828
 *
 */
@Entity
@Table(name = "MP_JOURNAL")
public class Journal implements Serializable {

	private static final long serialVersionUID = 8921970590111719322L;

	@EmbeddedId
    private JournalPK journalpk;

	@Column(name = "CREATED_DATETIME")
	private Timestamp created_datetime;

	@Column(name = "USER_ID")
	private String user_id;

	@Column(name = "EVENT")
	private String event;

	

	public JournalPK getJournalpk() {
		return journalpk;
	}

	public void setJournalpk(JournalPK journalpk) {
		this.journalpk = journalpk;
	}

	public Date getCreated_datetime() {
		return created_datetime;
	}

	public void setCreated_datetime(Timestamp created_datetime) {
		this.created_datetime = created_datetime;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

}
