package com.minapro.communicationServer.db;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ValueObject holding the terminal details
 * @author 3128828
 *
 */
@Entity
@Table(name= "MP_TERMINAL_MASTER")
public class Terminal 
{
	@Id
	@Column(name="TERMINAL_ID", nullable=false)
	private String terminal_id;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="CREATED_DATETIME", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date created_datetime;
	
	@Column(name="CREATED_BY")
	private String created_by;
	
	@Column(name="LAST_UPDATED_DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date last_updated_datetime;
	
	@Column(name="LAST_UPDATED_BY")
	private String last_updated_by;
	
	@Column(name="VERSION", nullable=false)
	private Integer version;
	
	/*@Column(name="ISDELETED")
	private boolean isDeleted;*/
	
	
	public Date getCreated_datetime() {
		return created_datetime;
	}
	public void setCreated_datetime(Date created_datetime) {
		this.created_datetime = created_datetime;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getLast_updated_datetime() {
		return last_updated_datetime;
	}
	public void setLast_updated_datetime(Date last_updated_datetime) {
		this.last_updated_datetime = last_updated_datetime;
	}
	public String getLast_updated_by() {
		return last_updated_by;
	}
	public void setLast_updated_by(String last_updated_by) {
		this.last_updated_by = last_updated_by;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	/*public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}*/
	public String getTerminal_id() {
		return terminal_id;
	}
	public void setTerminal_id(String terminal_id) {
		this.terminal_id = terminal_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}	
}
