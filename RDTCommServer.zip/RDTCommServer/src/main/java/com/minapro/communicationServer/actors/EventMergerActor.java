package com.minapro.communicationServer.actors;

import java.util.Iterator;


import java.util.Set;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.minapro.communicationServer.common.RDTCacheManager;
import com.minapro.communicationServer.db.OPERATOR;
import com.minapro.communicationServer.db.User;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;
import com.minapro.communicationServer.udp.RDTServerMain;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;

import akka.actor.UntypedActor;

/**
 * Akka Actor which merges all the packets corresponds to same event ID before
 * sending it to RDT Processing server
 * 
 * @author 3128828 version 1.0
 * 
 */

public class EventMergerActor extends UntypedActor {

	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(
			EventMergerActor.class);

	// To control the message delivery
	private static final Boolean NON_TRANSACTED = false;

	// Factory name specified in jndi.properties
	private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";

	// JNDI name of ActiveMQ Virtual Queue
	private static final String T2_DESTINATION_NAME = "queue/t2_rdt_outQ";
	private static final String T1_DESTINATION_NAME = "queue/t1_rdt_outQ";

	// Flag to send Non-Persistent messages
	private static final int NON_PERSISTENT = 0;
	private static MessageProducer producer2 = null;
	private static MessageProducer producer1 = null;
	private static Session session = null;
	private static Destination destination2 = null;
	private static Destination destination1 = null;
	private static Connection connection = null;
	private static PooledConnectionFactory pooledFactory;
	private static String terminalId = null;

	static {
		// Read jndi.properties in classpath
		Context context;
		try {
			context = new InitialContext();
			ConnectionFactory factory = (ConnectionFactory) context
					.lookup(CONNECTION_FACTORY_NAME);
			pooledFactory = new PooledConnectionFactory(
					(ActiveMQConnectionFactory) factory);
			// Reading destinations from jndi.prperties
			destination1 = (Destination) context.lookup(T1_DESTINATION_NAME);
			destination2 = (Destination) context.lookup(T2_DESTINATION_NAME);
			// Starting connection and session
			connection = pooledFactory.createConnection();
			connection.start();
			session = connection.createSession(NON_TRANSACTED,
					Session.AUTO_ACKNOWLEDGE);
			// Setting producer to destination
			producer1 = session.createProducer(destination1);
			producer1.setDeliveryMode(NON_PERSISTENT);
			producer2 = session.createProducer(destination2);
			producer2.setDeliveryMode(NON_PERSISTENT);
		} catch (Exception e) {
			logger.logException("Failed to intialize contxt params", e);
		}
	}

	@Override
	public void onReceive(Object msg) throws Exception {

		if (msg instanceof String) {

			User userObj = null;
			String finalEvent = null;


			String receivedEvent = (String) msg;
			String[] eventTokens = receivedEvent.split(RDTServerMain.DELIMITER);

			int eventNumber = Integer.parseInt(eventTokens[0]);
			int numberOfPckts = Integer.parseInt(eventTokens[1]);
			String eventType = eventTokens[2];
			String eventId = eventTokens[3];
			String userName = eventTokens[4];

			String[] eventSequence = RDTCacheManager.getInstance().eventMergerCache
					.get(eventId);
			int pktCount = RDTCacheManager.getInstance().packetCountCache
					.get(eventId);

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Received splitted message :"
					+ receivedEvent);
			
			// Persisting incoming request into DB
			getSender().tell("journal"+"~"+receivedEvent, null);

			// Extracting the actual pay-load from incoming message by removing
			// starting headers
			if (eventNumber != 1) {

				// If it is not the first packet of eventID then
				// need only the pay-load to append with existing packets of same
				// eventID
				finalEvent = receivedEvent
						.substring((eventNumber + "~" + numberOfPckts + "~"
								+ eventType + "~" + eventId + "~").length());
			} else {
				// For the First packet, we need to preserve eventType and
				// eventID of incoming packet to append with rest of the packets
				finalEvent = receivedEvent.substring((eventNumber + "~"
						+ numberOfPckts + "~").length());
			}

			logger.logMsg(LOG_LEVEL.DEBUG, "", "Extracted Payload :"
					+ finalEvent);

			Set<String> keyset = RDTCacheManager.getInstance().eventMergerCache
					.keySet();

			// Iterating through packets of individual eventID's
			for (Iterator<String> i = keyset.iterator(); i.hasNext();) {
				String eventKey = (String) i.next();

				if (eventId.equalsIgnoreCase(eventKey)) {

					if (pktCount == 0) {
						
						pktCount++;
						
						logger.logMsg(
								LOG_LEVEL.DEBUG,
								"",
								"Received packet No :"
										+ pktCount + "  for eventID "
										+ eventId);

						// Preserving No.of packets received for eventID into
						// cache
						RDTCacheManager.getInstance().addCounttoPcktCache(
								eventId, pktCount);

					} else {

						pktCount = RDTCacheManager.getInstance().packetCountCache
								.get(eventId);
						pktCount++;

						// Preserving No.of packets received for eventID into
						// cache
						RDTCacheManager.getInstance().addCounttoPcktCache(
								eventId, pktCount);
						logger.logMsg(
								LOG_LEVEL.DEBUG,
								"",
								"Received packet No :"
										+ RDTCacheManager.getInstance().packetCountCache
												.get(eventId) + "  for eventID "
										+ eventId);

					}
					eventSequence[(eventNumber - 1)] = finalEvent;

					// Populating received packets for eventID into Cache in
					// sequence even though they received in out of sequence
					RDTCacheManager.getInstance().addEventToMergerCache(
							eventKey, eventSequence);
				}

			}

			//If all packets are received 
			if (pktCount == numberOfPckts) {

				logger.logMsg(LOG_LEVEL.DEBUG, "", " " + "Received All packets for eventId " + eventId);

				String splittedEvents[] = RDTCacheManager.getInstance().eventMergerCache
						.get(eventId);
				
				//Merging all packets for eventID in sequence
				StringBuilder mergedMsg = new StringBuilder();
				for (String s : splittedEvents) {
					mergedMsg.append(s);

				}

				String msgToProcServer = mergedMsg.toString();
				logger.logMsg(LOG_LEVEL.DEBUG, "", " " + "Final Message after Merging: "
						+ mergedMsg);
				userObj = RDTCacheManager.getInstance().getUserObject(userName);
				TextMessage message = session.createTextMessage();
				message.setText(msgToProcServer);
				SendMessage(message, userObj);
			}

		}
	}

	/**
	 * Forwards incoming request to Processing server through RDT_OUTQ and sends
	 * login failed response back to device in case of invalid user
	 * 
	 * @param msg
	 * @param deviceId
	 */
	public static void SendMessage(Object msg, User userInfo) {

		try {

			TextMessage message = (TextMessage) msg;
			
			OPERATOR operatorRole = RDTCacheManager.getInstance()
					.gerUserLoggedInRole(userInfo.getUserID());
			
			if ("ITV".equalsIgnoreCase(operatorRole.toString())) {

				message.setStringProperty("eventGenerator", "ITV");
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received ITV event");

			} else if ("QC".equalsIgnoreCase(operatorRole.toString())) {

				message.setStringProperty("eventGenerator", "QC");
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received QC event");
			} else if ("HC".equalsIgnoreCase(operatorRole.toString())) {

				message.setStringProperty("eventGenerator", "HC");
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received HC event");
			} else if ("CHE".equalsIgnoreCase(operatorRole.toString())) {

				message.setStringProperty("eventGenerator", "CHE");
				logger.logMsg(LOG_LEVEL.DEBUG, "", "Received CHE event");
			}

			if ("1".equals(terminalId)) {
				logger.logMsg(LOG_LEVEL.DEBUG, "",
						"Sending Requst to : " + destination1.toString()
								+ " Event is: '" + message.getText() + "'");
				producer1.send(message);
			} else {
				logger.logMsg(LOG_LEVEL.DEBUG, "",
						"Sending Requst to : " + destination2.toString()
								+ " Event is: '" + message.getText() + "'");
				producer2.send(message);
			}
		} catch (Exception e) {
			logger.logMsg(LOG_LEVEL.DEBUG, "",
					"Exception while handling TextMessage :" + e);
		} finally {
		}
	}

}
