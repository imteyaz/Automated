package com.minapro.communicationServer.response;

import java.util.concurrent.CountDownLatch;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.minapro.communicationServer.listeners.QueueEventListener;
import com.minapro.communicationServer.logging.MinaProApplicationLogger;
import com.minapro.communicationServer.logging.MinaProApplicationLogger.LOG_LEVEL;

/**
 * Opens a connection with ActiveMQ queues using jndi.properties and sets the listeners
 * on all user specific queues
 *  
 * @author 3128828 
 * version 1.0
 * 
 */
public class RDTResponseListener extends Thread {
	
	private static final MinaProApplicationLogger logger = new MinaProApplicationLogger(
			RDTResponseListener.class);

	//To control the message delivery
	private static final Boolean NON_TRANSACTED = false;
	
	//Factory name specified in jndi.properties
	private static final String CONNECTION_FACTORY_NAME = "MinaProJmsFactory";
	
	//JNDI name of ITV specific Queue
	private static final String DESTINATION_ITV = "destination/t2_itv_inQ";
	
	//JNDI name of QC specific Queue
	private static final String DESTINATION_QC = "destination/t2_qc_inQ";
	
	//JNDI name of HC specific Queue
	private static final String DESTINATION_HC = "destination/t2_hc_inQ";
	
	//JNDI name of CHE specific Queue
	private static final String DESTINATION_CHE = "destination/t2_che_inQ";
	
	//JNDI name of TSC specific Queue
    private static final String DESTINATION_TSC = "destination/t2_tsc_inQ";
	
    //JNDI name of FOREMAN specific Queue
    private static final String DESTINATION_OBF = "destination/t2_obf_inQ";
    
	//CountDownLatch for synchronization
	private final CountDownLatch done = new CountDownLatch(1000);

	public RDTResponseListener() {

	}
	
	/**
	 * Opens Connection with Queues and sets the listeners
	 *  
	 * @param Nothing
	 * @return Nothing.
	 */

	public void run() {
		Connection connection = null;
		Session session = null;

		try {

			//Read jndi.properties in classpath
			Context context = new InitialContext();
			ConnectionFactory factory = (ConnectionFactory) context
					.lookup(CONNECTION_FACTORY_NAME);

			//Starting connection and session
			connection = factory.createConnection();
			connection.start();
			session = connection.createSession(NON_TRANSACTED,
					Session.AUTO_ACKNOWLEDGE);
			
			//Creating User specific destinations
			Destination destinationItv = (Destination) context
					.lookup(DESTINATION_ITV);
			Destination destinationQc = (Destination) context
					.lookup(DESTINATION_QC);
			Destination destinationHc = (Destination) context
					.lookup(DESTINATION_HC);
			Destination destinationChe = (Destination) context
					.lookup(DESTINATION_CHE);
			Destination destinationTsc = (Destination) context
                    .lookup(DESTINATION_TSC);
			
			Destination destinationForeman = (Destination) context
                    .lookup(DESTINATION_OBF);
			
			//Setting Consumers on destinations
			MessageConsumer consumerItv = session.createConsumer(destinationItv);
			MessageConsumer consumerQc = session.createConsumer(destinationQc);		
			MessageConsumer consumerHc = session.createConsumer(destinationHc);
			MessageConsumer consumerChe = session.createConsumer(destinationChe);
			MessageConsumer consumerTsc = session.createConsumer(destinationTsc);
			
			MessageConsumer consumerForeman = session.createConsumer(destinationForeman);
			
			//Setting listeners on consumers
			/*consumerItv.setMessageListener(new ITVEventListener(done));
			consumerQc.setMessageListener(new QCEventListener(done));
			consumerHc.setMessageListener(new HCEventListener(done));
			consumerChe.setMessageListener(new CHEEventListener(done));*/
			
			consumerItv.setMessageListener(new QueueEventListener());
			consumerQc.setMessageListener(new QueueEventListener());
			consumerHc.setMessageListener(new QueueEventListener());
			consumerChe.setMessageListener(new QueueEventListener());
			consumerTsc.setMessageListener(new QueueEventListener());
			consumerForeman.setMessageListener(new QueueEventListener());
			
			
			done.await();

		} catch (Exception e) {
			logger.logMsg(LOG_LEVEL.DEBUG, "", "Exception in thread RDTResponseListener :" + e);
		} finally {
			// got to clean up the connections and other resources!
			if (connection != null) {
				try {
					if(session != null){
						session.close();
					}
					connection.close();
				} catch (JMSException e) {
					logger.logMsg(LOG_LEVEL.ERROR, "", 
							"Caught exception while closing the connection -" + e.getLocalizedMessage());
				}
			}
		}

	}
}
