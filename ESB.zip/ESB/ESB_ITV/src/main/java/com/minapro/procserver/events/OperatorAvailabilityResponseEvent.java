package com.minapro.procserver.events;

import java.io.Serializable;
/**
 * Following Class Is Responsible for Holding the server response for Operator break  event
 * @author Umamahesh M
 *
 */
public class OperatorAvailabilityResponseEvent extends Event implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 4438282162234751157L;
    /**
     * Final Operator Status(True means state changed in server and 
     * false means earlier status not changed)
     */
    private String availabilityStatus;
    /**
     * Holds The Current requested operator working status in server.
     */
    private String requestType;
    @Override
    public String toString() {
        return "OperatorAvailabilityResponseEvent [availabilityStatus="
                + availabilityStatus + ", requestType=" + requestType + "]";
    }
    public String getAvailabilityStatus() {
        return availabilityStatus;
    }
    public void setAvailabilityStatus(String availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }
    public String getRequestType() {
        return requestType;
    }
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }   
 
}
