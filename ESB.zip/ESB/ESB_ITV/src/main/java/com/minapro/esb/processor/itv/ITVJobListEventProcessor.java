package com.minapro.esb.processor.itv;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITVJobListEvent;

public class ITVJobListEventProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        JobListRequestEvent requestEvent = (JobListRequestEvent) exchange
                .getProperty("ITVjobList");

        if (requestEvent != null) {

            @SuppressWarnings("deprecation")
            DataSource dataSource = (DataSource) exchange.getContext()
                    .getRegistry().lookup("PromisDataSource");

            // A connection from the dataSource is opened
            Connection con = dataSource.getConnection();

            // PreparedStatement is obtained from the connection , which takes
            // in the query , to retreive the list of containers from the
            // database

            PreparedStatement statement = con
                    .prepareStatement(Constants.QUERY_CONTR_DTLS_BY_ROLE);
            if ("itvuser1".equalsIgnoreCase(requestEvent.getUserID())) {
                statement.setString(1, "TRK");
            } else {
                statement.setString(1, "TRK");
            }

            // The list retrieved from dbase
            ResultSet set = statement.executeQuery();
            List<DriveInstructionEvent> list = new ArrayList<DriveInstructionEvent>();
            ITVJobListEvent jobListEvent = new ITVJobListEvent();

            if (set == null) {

                DriveInstructionEvent event = new DriveInstructionEvent();
                event.setGeneralInstruction("Wait for next job");
                list.add(event);

            } else {

                while (set.next()) {

                    DriveInstructionEvent fromInstruction = new DriveInstructionEvent();
                    DriveInstructionEvent toInstruction = new DriveInstructionEvent();

                    fromInstruction
                            .setContainerID(set.getString(Constants.CONTAINERID));
                    fromInstruction
                            .setLocationID(set.getString("fromLocation"));
                    fromInstruction.setEquipmentID(requestEvent
                            .getEquipmentID());
                    fromInstruction.setUserID(requestEvent.getUserID());

                    list.add(fromInstruction);

                    toInstruction.setContainerID(set.getString(Constants.CONTAINERID));
                    toInstruction.setLocationID(set.getString("toLocation"));
                    toInstruction.setEquipmentID(requestEvent.getEquipmentID());
                    toInstruction.setUserID(requestEvent.getUserID());

                    list.add(toInstruction);

                }
            }

            jobListEvent.setEquipmentID(requestEvent.getEquipmentID());
            jobListEvent.setEventID(requestEvent.getEventID());
            jobListEvent.setJobList(list);
            jobListEvent.setTerminalID(requestEvent.getTerminalID());
            jobListEvent.setUserID(requestEvent.getUserID());

            exchange.getOut().setBody(jobListEvent);
            exchange.setProperty("loginReceived", "yes");
            exchange.setProperty("routed", null);

        }
    }
}
