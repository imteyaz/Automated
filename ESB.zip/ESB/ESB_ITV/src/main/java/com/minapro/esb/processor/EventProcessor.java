package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.esb.common.SendObject;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;

public class EventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(EventProcessor.class);

    private static <T> void setSendObject(String queue, T template, Exchange exchange, String templateName) {
        SendObject sendObject = new SendObject();
        sendObject.setQueueName(queue);
        sendObject.setObject(template);
        exchange.getOut().setBody(sendObject);
        EventProcessor.check(sendObject, Constants.ITV_OPERATOR + templateName, exchange);

    }

    private static <T> void check(T template, String templateName,
            Exchange exchange) {
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED);      
        Boolean sent = false;
        if (routed != null) {
            if (routed) {
                exchange.removeProperty("routed");
                exchange.removeProperty(templateName);
                LOGGER.debug("Remove routed & template name props from exchange : "+ templateName);
            }
        } else {
            exchange.setProperty(templateName, template);
            exchange.setProperty(Constants.ROUTED, sent);
            exchange.setProperty(Constants.EVENT_TYPE, templateName);
            LOGGER.debug("Set event-type,routed & template name props to exchange : "+ templateName);
        }

    }

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("************ In ITV EventProcessor process method ************");

        long startTime = System.currentTimeMillis();

        Object object = exchange.getIn().getBody();
        LOGGER.info("ITV Request received from RDT is ----> "+object);

        if (object instanceof LogoutEvent) {
            LogoutEvent logoutEvent = (LogoutEvent) object;
            EventProcessor.setSendObject(Constants.ITV_OPERATOR, logoutEvent, exchange, "logout");
        } else if (object instanceof ConfirmAllocationEvent) {
            ConfirmAllocationEvent confirmAllocationEvent = (ConfirmAllocationEvent) object;
            EventProcessor.setSendObject(Constants.ITV_OPERATOR, confirmAllocationEvent, exchange, "confirmAllocation");
        } else if (object instanceof JobListRequestEvent) {
            JobListRequestEvent event = (JobListRequestEvent) object;
            EventProcessor.setSendObject(Constants.ITV_OPERATOR, event, exchange, "jobList");
        } else if (object instanceof OperatorAvailabilityEvent) {
            OperatorAvailabilityEvent availabilityEvent = (OperatorAvailabilityEvent) object;
            EventProcessor.setSendObject(Constants.ITV_OPERATOR,
                    availabilityEvent, exchange, Constants.OPERATOR_AVAIL_EVENT);            
        }  else if (object instanceof ITVArrivalEvent) {
            ITVArrivalEvent itvArrivalEvent = (ITVArrivalEvent) object;
            EventProcessor.setSendObject(Constants.ITV_OPERATOR, itvArrivalEvent, exchange, "F1");

        } else if (object instanceof LoginEvent) {
            LoginEvent loginEvent = (LoginEvent) object;
            EventProcessor.check(loginEvent, Constants.ITV_OPERATOR + "loginEvent", exchange);
        }

        long endTime = System.currentTimeMillis();      
        LOGGER.debug("Time taken to dequeue message --> " + (endTime - startTime));
    }
}
