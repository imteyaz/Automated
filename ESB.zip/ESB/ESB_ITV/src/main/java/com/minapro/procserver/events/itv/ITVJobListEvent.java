package com.minapro.procserver.events.itv;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the drive instruction events for an ITV
 * 
 * @author Rosemary George
 *
 */
public class ITVJobListEvent extends Event implements Serializable {
    private static final long serialVersionUID = 4927468442562952515L;
    
    private List<DriveInstructionEvent> jobList;

    public List<DriveInstructionEvent> getJobList() {
        return jobList;
    }

    public void setJobList(List<DriveInstructionEvent> jobList) {
        this.jobList = jobList;
    }

    @Override
    public String toString() {
        return "ITVJobListEvent [jobList=" + jobList + ", UserID="
                + getUserID() + ", EquipmentID=" + getEquipmentID()
                + ", TerminalID=" + getTerminalID() + "]";
    }   
}
