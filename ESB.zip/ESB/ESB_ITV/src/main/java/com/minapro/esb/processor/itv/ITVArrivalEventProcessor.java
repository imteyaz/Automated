package com.minapro.esb.processor.itv;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.processor.LogoutEventProcessor;
import com.minapro.procserver.events.itv.ITVArrivalEvent;

public class ITVArrivalEventProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(LogoutEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Inside the ITVArrivalEventProcessor...");
        ITVArrivalEvent arrivalEvent = (ITVArrivalEvent) exchange
                .getProperty("itvArrival");
        if (arrivalEvent != null) {
            LOGGER.info("ITVArrivalEvent received is --> "+arrivalEvent);
        }
    }
}
