package com.minapro.esb.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.common.LogoutEvent;

public class LogoutEventProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(LogoutEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Inside the logout processor...");
        org.apache.log4j.MDC.put("app.name", "LogoutEvent");
        LogoutEvent logoutEvent = (LogoutEvent) exchange
                .getProperty("logoutEvent");
        LOGGER.info("Logout Event request Received : "+logoutEvent);
        if (logoutEvent != null) {

            InputStream inStream = new FileInputStream(new File(
                    Constants.TIMER_FILE_PATH));

            Properties properties = new Properties();
            properties.load(inStream);

            if ("LoggedIn".equals(properties.getProperty(logoutEvent.getUserID()))) {
                OutputStream outStream = new FileOutputStream(new File(
                        Constants.TIMER_FILE_PATH));
                properties.remove(logoutEvent.getUserID());
                properties.store(outStream, "Removed");
                LOGGER.info("ITV User logged out successfully" + logoutEvent.getUserID()); 
            }
        }        
    }
}
