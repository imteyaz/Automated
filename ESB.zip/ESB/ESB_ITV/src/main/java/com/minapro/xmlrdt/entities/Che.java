package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "che")
public class Che {

    private String chid;
    private String equipType;
    private String MTEU;
    private String DSTA;
    private String APOW;
    private String status;
    private JobList joblist;
    private Pool pool;
    private ErrMsg errMsg;
    private List list;
    private DisplayMessage displayMessage;

    @XmlElement(name = "displayMsg")
    public DisplayMessage getDisplayMessage() {
        return displayMessage;
    }

    public void setDisplayMessage(DisplayMessage displayMessage) {
        this.displayMessage = displayMessage;
    }

    @XmlElement(name = "list")
    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    @XmlElement(name = "errMsg")
    public ErrMsg getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(ErrMsg errMsg) {
        this.errMsg = errMsg;
    }

    @XmlElement(name = "pool")
    public Pool getPool() {
        return pool;
    }

    public void setPool(Pool pool) {
        this.pool = pool;
    }

    @XmlAttribute(name = "APOW")
    public String getAPOW() {
        return APOW;
    }

    public void setAPOW(String aPOW) {
        APOW = aPOW;
    }

    @XmlAttribute(name = "status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @XmlAttribute(name = "DSTA")
    public String getDSTA() {
        return DSTA;
    }

    public void setDSTA(String dSTA) {
        DSTA = dSTA;
    }

    @XmlElement(name = "joblist")
    public JobList getJoblist() {
        return joblist;
    }

    public void setJoblist(JobList joblist) {
        this.joblist = joblist;
    }

    @XmlAttribute(name = "CHID")
    public String getChid() {
        return chid;
    }

    public void setChid(String chid) {
        this.chid = chid;
    }

    @XmlAttribute(name = "equipType")
    public String getEquipType() {
        return equipType;
    }

    public void setEquipType(String equipType) {
        this.equipType = equipType;
    }

    @XmlAttribute(name = "MTEU")
    public String getMTEU() {
        return MTEU;
    }

    @Override
    public String toString() {
        return "Che [chid=" + chid + ", equipType=" + equipType + ", MTEU="
                + MTEU + ", DSTA=" + DSTA + ", joblist=" + joblist + "]";
    }

    public void setMTEU(String mTEU) {
        MTEU = mTEU;
    }

}
