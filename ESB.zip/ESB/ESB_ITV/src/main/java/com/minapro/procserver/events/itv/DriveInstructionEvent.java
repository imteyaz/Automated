package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the drive instruction details for an ITV
 * 
 * @author Rosemary George
 *
 */
public class DriveInstructionEvent extends Event implements Serializable {
    private static final long serialVersionUID = 4927804350930930743L;    
    /**
     * The location to where the ITV needs to go can be QC,pinning station or yard IDs. In Twin lift, can have at most
     * two locations in case of yard.
     */
    private String locationID;

    /**
     * The container IDs which the ITV is carrying Can have at most two container IDs, in case of twin lift
     */
    private String containerID = "";

    /**
     * general instructions like "wait for next job"..
     */
    private String generalInstruction;
    
    /**
     * container length
     */
    private String length;

    /**
     * In case the drive instruction is to go to QC, the lane ID will be specified here
     */
    private String laneID;

    /**
     * In case the driveType is QC, the driving direction will be specified here
     */
    private String driveDirection;
    
    
    /**
     * Move type DSCH/LOAD/HK
     */    
    private String moveType;
    
    /**
     * Job action carry/fetch
     */
    private String action;
    
    /**
     * Indicates the position of the container on ITV - AFT/FORWARD
     */
    private String position;
    
    /**
     * Job Flag of Twin/Tandem/Single Single Job :"S" Twin Job : "W" Tandem Job: "M"
     */
    private String tnwTndmCd;

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getLaneID() {
        return laneID;
    }

    public void setLaneID(String laneID) {
        this.laneID = laneID;
    }

    public String getGeneralInstruction() {
        return generalInstruction;
    }

    public void setGeneralInstruction(String generalInstruction) {
        this.generalInstruction = generalInstruction;
    }

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }    

    public String getDriveDirection() {
        return driveDirection;
    }

    public void setDriveDirection(String driveDirection) {
        this.driveDirection = driveDirection;
    }    

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getTnwTndmCd() {
        return tnwTndmCd;
    }

    public void setTnwTndmCd(String tnwTndmCd) {
        this.tnwTndmCd = tnwTndmCd;
    }

    @Override
    public String toString() {
        return "DriveInstructionEvent [locationID=" + locationID
                + ", containerID=" + containerID + ", generalInstruction="
                + generalInstruction + ", length=" + length + ", laneID="
                + laneID + ", driveDirection=" + driveDirection + ", moveType="
                + moveType + ", action=" + action + ", position=" + position
                + ", tnwTndmCd=" + tnwTndmCd + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getEventID()="
                + getEventID() + "]";
    }
}
