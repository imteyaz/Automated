package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.common.CertificateValidateEvent;

public class CertificateValidateEventProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(CertificateValidateEvent.class);

    @Override
    public void process(Exchange exchange) throws Exception {

        org.apache.log4j.MDC.put("app.name", Constants.CERTIFICATE_VALIDATE_EVENT);
        LOGGER.debug("Inside Certificate Validation... ");
        CertificateValidateEvent certificateValidateEvent = (CertificateValidateEvent) exchange
                .getProperty(Constants.CERTIFICATE_VALIDATE_EVENT);
        LOGGER.info("Ceritificate Validate Event Object --> "+certificateValidateEvent);
        String status = certificateValidateEvent.getStatus();
        LOGGER.info(" Ceritificate eventID : "+certificateValidateEvent.getEventID() +" Validate Status is " + status);

    }

}
