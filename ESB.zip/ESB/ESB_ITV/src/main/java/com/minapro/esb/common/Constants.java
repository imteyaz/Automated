package com.minapro.esb.common;

public class Constants {
    
    public static final String ITV_OPERATOR = "ITV";
    public static final String ROUTED = "routed";
    public static final String EVENT_TYPE ="eventType";
    public static final String CONTAINERID = "ContainerID" ;
    public static final String CERTIFICATE_VALIDATE_EVENT = "certificateValidateEvent";
    public static final String TIMER_FILE_PATH = "D:/timer.properties";
    public static final String QUERY_CONTR_DTLS_BY_ROLE = "select * from containerdetails where role=?" ;
    public static final String OPERATOR_AVAIL_EVENT = "AvailabilityEvent";
    private Constants(){        
    }    
}
