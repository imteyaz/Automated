package com.minapro.esb.processor.itv;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.procserver.events.common.ConfirmAllocationEvent;

public class ITVConfirmAllocationEventProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(ITVConfirmAllocationEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Inside the ITVConfirmAllocationEventProcessor...");    
        
        org.apache.log4j.MDC.put("app.name", "ConfirmAllocationEvent");
        ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) exchange
                .getProperty("ITVconfirmAllocationEvent");
        if (allocationEvent != null) {
            String equipId = allocationEvent.getEquipmentID();
            String eventId = allocationEvent.getEventID();
            String termId = allocationEvent.getTerminalID();
            String userId = allocationEvent.getUserID();
            LOGGER.info("Before File Out " + userId);
            LOGGER.info(userId + equipId + eventId + termId);
            LOGGER.info("Confirm alloc received");    

        }
    }
}
