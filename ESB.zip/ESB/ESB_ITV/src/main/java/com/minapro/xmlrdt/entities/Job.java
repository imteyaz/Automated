package com.minapro.xmlrdt.entities;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "job")
public class Job {

    private String MKVD;
    private String MVKD;
    private String pow;
    private String age;
    private String priority;
    private String twinned;
    private Container container;
    private List<Position> position;

    @XmlAttribute(name = "twinned")
    public String getTwinned() {
        return twinned;
    }

    public void setTwinned(String twinned) {
        this.twinned = twinned;
    }

    @XmlAttribute(name = "MVKD")
    public String getMVKD() {
        return MVKD;
    }

    public void setMVKD(String mVKD) {
        MVKD = mVKD;
    }

    @XmlAttribute(name = "pow")
    public String getPow() {
        return pow;
    }

    public void setPow(String pow) {
        this.pow = pow;
    }

    @XmlAttribute(name = "age")
    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @XmlAttribute(name = "priority")
    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    @XmlAttribute(name = "MKVD")
    public String getMKVD() {
        return MKVD;
    }

    @Override
    public String toString() {
        return "Job [MKVD=" + MKVD + ", container=" + container + ", position="
                + position + "]";
    }

    public void setMKVD(String mKVD) {
        MKVD = mKVD;
    }

    @XmlElement(name = "container")
    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    @XmlElement(name = "position")
    public List<Position> getPosition() {
        return position;
    }

    public void setPosition(List<Position> position) {
        this.position = position;
    }

}
