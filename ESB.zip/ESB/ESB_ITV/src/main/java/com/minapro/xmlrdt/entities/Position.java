package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "position")
public class Position {

    private String name;
    private String PPOS;
    private String type;
    private String refID;
    private String DOOR;

    @XmlAttribute(name = "refID")
    public String getRefID() {
        return refID;
    }

    public void setRefID(String refID) {
        this.refID = refID;
    }

    @XmlAttribute(name = "DOOR")
    public String getDOOR() {
        return DOOR;
    }

    public void setDOOR(String dOOR) {
        DOOR = dOOR;
    }

    @XmlAttribute(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlAttribute(name = "PPOS")
    public String getPPOS() {
        return PPOS;
    }

    public void setPPOS(String pPOS) {
        PPOS = pPOS;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Position [name=" + name + ", PPOS=" + PPOS + ", type=" + type
                + "]";
    }
}
