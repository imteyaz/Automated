/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 3500515
 */
@XmlRootElement(name = "group")
public class Group {

    private String groupseq;
    private String groupcount;
    private String groupid;

    @XmlAttribute(name = "groupseq")
    public String getGroupseq() {
        return groupseq;
    }

    public void setGroupseq(String groupseq) {
        this.groupseq = groupseq;
    }

    @XmlAttribute(name = "groupcount")
    public String getGroupcount() {
        return groupcount;
    }

    public void setGroupcount(String groupcount) {
        this.groupcount = groupcount;
    }

    @XmlAttribute(name = "groupid")
    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    @Override
    public String toString() {
        return "Group [groupseq=" + groupseq + ", groupcount=" + groupcount
                + ", groupid=" + groupid + "]";
    }

}
