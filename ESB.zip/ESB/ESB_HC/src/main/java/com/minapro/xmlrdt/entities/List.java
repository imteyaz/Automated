package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "list")
public class List {

    private String count;
    private String type;
    private java.util.List<Pool> pool;
    private java.util.List<Che> che;
    private java.util.List<Pow> pow;
    private java.util.List<Job> job;

    @XmlElement(name = "job")
    public java.util.List<Job> getJob() {
        return job;
    }

    public void setJob(java.util.List<Job> job) {
        this.job = job;
    }

    @XmlAttribute(name = "count")
    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlElement(name = "pool")
    public java.util.List<Pool> getPool() {
        return pool;
    }

    public void setPool(java.util.List<Pool> pool) {
        this.pool = pool;
    }

    @XmlElement(name = "che")
    public java.util.List<Che> getChe() {
        return che;
    }

    public void setChe(java.util.List<Che> che) {
        this.che = che;
    }

    @XmlElement(name = "pow")
    public java.util.List<Pow> getPow() {
        return pow;
    }

    public void setPow(java.util.List<Pow> pow) {
        this.pow = pow;
    }

    @Override
    public String toString() {
        return "List [count=" + count + ", type=" + type + ", pool=" + pool
                + ", che=" + che + ", pow=" + pow + "]";
    }
}
