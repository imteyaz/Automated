package com.minapro.esb.common;

public class Constants {

	public static final String HC_OPERATOR = "HC";
	public static final String ROUTED = "routed";
	public static final String EVENT_TYPE = "eventType";

	/*
	 * HC EVENTS
	 */
	public static final String LOGIN_EVENT = "loginEvent";
	public static final String LOGOUT_EVENT = "logoutEvent";
	public static final String JOBLIST_EVENT = "jobList";
	public static final String CONTAINER_MOVE_EVENT = "containerMoveEvent";
	public static final String CONFIRM_ALLOCATION_EVENT = "confirmAllocationEvent";
	public static final String ITVPOOL_EVENT = "ITVPoolRequestEvent";
	public static final String OPERATOR_AVAIL_EVENT = "AvailabilityEvent";
	public static final String UPDATE_CONTR_EVENT = "UpdateContainerEvent";
	public static final String VESSEL_BERTH_SIDE_EVENT = "vesselBerthSide";
	public static final String BAY_UPDATE_EVENT = "bayUpdate";
	public static final String ORPHAN_CONTR_EVENT = "OrphanContainerEvent";
	public static final String OUTOFLIST_CONTR_EVENT = "OutOfListContainersInquiryEvent";
	
	public static final String M ="M";
	public static final String COMMA_DELIMITER = ",";

	public static final String PROMIS_DB = "PromisDataSource";

	public static final String OUT_OF_LIST_CONTR_INQUIRY_QUERY = "select containers.contr_no || containers.chk_digit as containerId, "
			+ " dpa_lists.disch_port as pod, "
			+ " containers.new_iso_code as isoCode, "
			+ " dpa_lists.wt as weight, "
			+ " dpa_lists.un_no as unNo, "
			+ " dpa_lists.un_no2 as unNo2, "
			+ " dpa_lists.un_no3 as unNo3, "
			+ " containers.contr_cat_status as containerEmpty, "
			+ " dpa_lists.og as oog, "
			+ " containers.contr_len as containerSize, "
			+ " dpa_lists.list_code as moveType, "
			+ " containers.reef_appl_code as reefer, "
			+ " containers.dmg_descr as damaged, "
			+ " NVL(dpa_lists.plan_stowg, dpa_lists.stowg) as stowage, "
			+ " dpa_lists.contr_cat as category, "
			+ " 'N' ROB_FLAG "
			+ " from dpa_lists "
			+ " inner join containers "
			+ " on dpa_lists.contr_no = containers.contr_no "
			+ " where dpa_lists.rotn = ? "
			+ " and containers.contr_no like ? "
			+ " and containers.chk_digit = ?  "
			+ " and containers.act_code = 'Y' "
			+ " and dpa_lists.list_code = 'D' ";

	private Constants() {

	}
}
