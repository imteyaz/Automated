package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details about the login delay confirmation event from the device
 * @author Rosemary George
 *
 */
public class DelayConfirmationEvent extends Event implements Serializable {
    private static final long serialVersionUID = 8322883834421453370L;
    
    /**
     * The delay reason code which the user has selected
     */
    private String reasonCode;

    public String getReasonCode() {
        return reasonCode;
    }

    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }

    @Override
    public String toString() {
        return "DelayConfirmationEvent [reasonCode=" + reasonCode
                + ", UserID=" + getUserID() + ", TerminalID="
                + getTerminalID() + "]";
    }  
}
