package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;
import java.util.Date;

import com.minapro.procserver.events.Event;

/**
 * <p>ValueObject holding the allocation details for a user.</p>
 * 
 * <p>The Object can be filled from ESB or it can be formed as part of confirm allocation from the user.</p>
 * 
 * @author Rosemary George
 *
 */
public class AllocationEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7592333007009257304L;
    
    /**
     * List of rotation IDs which are currently berthed on the port
     */
    private List<String> rotationIDs;   
    
    /**
     * List of activity codes available - can be operational or non operational activities
     */
    private List<String> activityCodes;
    
    /**
     * Location allocated as per DPW port planning
     */
    private String location;
    
    /**
     * The user shift start time as per DPW planning system
     */
    private Date shiftStartTime;
    
    public Date getShiftStartTime() {
        return shiftStartTime;
    }

    public void setShiftStartTime(Date shiftStartTime) {
        this.shiftStartTime = shiftStartTime;
    }
        
    public List<String> getRotationIDs() {
        return rotationIDs;
    }

    public void setRotationIDs(List<String> rotationIDs) {
        this.rotationIDs = rotationIDs;
    }

    public List<String> getActivityCodes() {
        return activityCodes;
    }

    public void setActivityCodes(List<String> activityCodes) {
        this.activityCodes = activityCodes;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "AllocationEvent [rotationIDs=" + rotationIDs
                + ", activityCodes=" + activityCodes + ", location=" + location
                + ", shiftStartTime=" + shiftStartTime + ", userID=" + getUserID() + ", TerminalID="
                + getTerminalID() + "]";
    }   
}
