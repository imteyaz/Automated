package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.Date;

/**
 * ValueObject holding the break details
 * @author Venkataramana.ch
 *
 */
public class Break implements Serializable {

    private static final long serialVersionUID = -8523992364175281817L;

    
    /**
     * Break Starting time
     */
    private Date breakStartTime;
    /**
     * Break Duration
     */
    private String breakDuration;
    public Date getbreakStartTime() {
        return breakStartTime;
    }
    public void setBreakStartTime(Date breakStartTime) {
        this.breakStartTime = breakStartTime;
    }
    public String getbreakDuration() {
        return breakDuration;
    }
    public void setBreakDuration(String breakDuration) {
        this.breakDuration = breakDuration;
    }

}
