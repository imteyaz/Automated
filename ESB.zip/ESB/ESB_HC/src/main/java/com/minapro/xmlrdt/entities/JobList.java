package com.minapro.xmlrdt.entities;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class JobList {

    private String firstID;
    private String lastID;
    private String sortMode;
    private List<Job> job;

    @XmlElement(name = "job")
    public List<Job> getJob() {
        return job;
    }

    public void setJob(List<Job> job) {
        this.job = job;
    }

    @XmlAttribute(name = "firstID")
    public String getFirstID() {
        return firstID;
    }

    public void setFirstID(String firstID) {
        this.firstID = firstID;
    }

    @XmlAttribute(name = "lastID")
    public String getLastID() {
        return lastID;
    }

    public void setLastID(String lastID) {
        this.lastID = lastID;
    }

    @XmlAttribute(name = "sortMode")
    public String getSortMode() {
        return sortMode;
    }

    public void setSortMode(String sortMode) {
        this.sortMode = sortMode;
    }

    @Override
    public String toString() {
        return "JobList [firstID=" + firstID + ", lastID=" + lastID
                + ", sortMode=" + sortMode + ", job=" + job + "]";
    }
}
