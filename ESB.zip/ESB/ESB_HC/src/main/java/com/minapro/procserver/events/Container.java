package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the container details
 * 
 * @author Rosemary George
 *
 */
public class Container implements Serializable {
    private static final long serialVersionUID = 623794626859661670L;

    /**
     * ID of the container
     */
    private String containerID;
    /**
     * Port of destination for this container
     */
    private String pod;
    /**
     * Size of the container - 20 feet or 40 feet
     */
    private String size;
    /**
     * Weight of the container
     */
    private String weight;
    /**
     * ISO code of the container
     */
    private String isoCode;
    /**
     * Indicates whether it is reefer Container
     */
    private boolean isReefer;

    /**
     * Indicates whether the container is empty or full
     */
    private boolean isEmpty;

    /**
     * Indicates whether the container is OutOfGauge
     */
    private boolean isOOG;

    /**
     * Indicates whether it contains normal or explosive contents
     */
    private boolean isHazardous;

    /**
     * Indicates whether any damages on the container
     */
    private boolean isDamaged;

    /**
     * Indicates whether container comes with or without frames
     */
    private boolean isWithFrame;

    /**
     * Indicates the door direction of the container
     */
    private String doorDirection;

    /**
     * Indicates whether the container is of type Import, Export or Tran-shipment.
     */
    private String category;

    /**
     * Indicates whether Reefer connected or Disconnected
     */
    private String reeferStatus;
    
    /**
     * Indicates the seal status of the container - true means seal is on, false means seal is off
     */
    private boolean sealOn;  
    
    /**
     * Indicates the IMDG code of the container if it is marked as hazardous
     */
    private String hazardousCode;

    public Container() {
    }
    
    public String getHazardousCode() {
        return hazardousCode;
    }

    public void setHazardousCode(String hazardousCode) {
        this.hazardousCode = hazardousCode;
    }

    public boolean isSealOn() {
        return sealOn;
    }

    public void setSealOn(boolean sealOn) {
        this.sealOn = sealOn;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

    public boolean isReefer() {
        return isReefer;
    }

    public void setReefer(boolean isReefer) {
        this.isReefer = isReefer;
    }

    public boolean getIsEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean isEmpty) {
        this.isEmpty = isEmpty;
    }

    public boolean isOOG() {
        return isOOG;
    }

    public void setOOG(boolean isOOG) {
        this.isOOG = isOOG;
    }

    public boolean isHazardous() {
        return isHazardous;
    }

    public void setHazardous(boolean isHazardous) {
        this.isHazardous = isHazardous;
    }

    public boolean getIsDamaged() {
        return isDamaged;
    }

    public void setDamaged(boolean isDamaged) {
        this.isDamaged = isDamaged;
    }

    public boolean isWithFrame() {
        return isWithFrame;
    }

    public void setWithFrame(boolean isWithFrame) {
        this.isWithFrame = isWithFrame;
    }

    public String getDoorDirection() {
        return doorDirection;
    }

    public void setDoorDirection(String doorDirection) {
        this.doorDirection = doorDirection;
    }

    public String getReeferStatus() {
        return reeferStatus;
    }

    public void setReeferStatus(String reeferStatus) {
        this.reeferStatus = reeferStatus;
    }

    @Override
    public String toString() {
        return "Container [containerID=" + containerID + ", pod=" + pod
                + ", size=" + size + ", weight=" + weight + ", isoCode="
                + isoCode + ", isReefer=" + isReefer + ", isEmpty=" + isEmpty
                + ", isOOG=" + isOOG + ", isHazardous=" + isHazardous
                + ", isDamaged=" + isDamaged + ", isWithFrame=" + isWithFrame
                + ", doorDirection=" + doorDirection + ", category=" + category
                + ", reeferStatus=" + reeferStatus + ", sealOn=" + sealOn
                + ", hazardousCode=" + hazardousCode + "]";
    }
}
