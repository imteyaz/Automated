package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the vessel berthing details
 * @author Rosemary George
 *
 */
public class VesselBerthEvent extends Event implements Serializable {
    private static final long serialVersionUID = 5060272009363828995L;
    
    /**
     * The rotation ID of the vessel which has berthed in the port
     */
    private String rotationID;
    
    /**
     * Vessel code of the berthed vessel
     */
    private String vesselCode;
    
    /**
     * The Berth ID where the vessel has berthed
     */
    private String berthID;
    
    public String getRotationID() {
        return rotationID;
    }
    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }
    public String getBerthID() {
        return berthID;
    }
    public void setBerthID(String berthID) {
        this.berthID = berthID;
    }
    public String getVesselCode() {
        return vesselCode;
    }
    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }
    
    @Override
    public String toString() {
        return "VesselBerthEvent [rotationID=" + rotationID + ", vesselCode="
                + vesselCode + ", berthID=" + berthID + "]";
    }   
}
