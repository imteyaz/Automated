package com.minapro.esb.processor;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.camel.Exchange;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;

public class ProcessorSender {

    private static final Logger LOGGER = Logger.getLogger(ProcessorSender.class);
        
    public String sendToEndpoint(Exchange exchange){

        String endpoint = null;        
        String eventType = null;
        try {
            org.apache.log4j.MDC.put("app.name", "DynamicRouter");
            eventType = (String) exchange.getProperty("eventType");
            LOGGER.debug("Processing HC dynamic routing endpoint for the request... "+eventType);
            
            if (exchange.getProperty(eventType) != null
                    && !((Boolean) exchange.getProperty(Constants.ROUTED))) {
                exchange.setProperty(Constants.ROUTED, true);
                InputStream inStream = this.getClass().getClassLoader()
                        .getResourceAsStream("endpoint.properties");
                Properties properties = new Properties();
                properties.load(inStream);
                endpoint = properties.getProperty(eventType);                
            }
        } catch (IOException e) {
            LOGGER.error(eventType+" IOException occured : " ,e);
        }
        LOGGER.debug(eventType+" request is routing to the enpoint --> " +endpoint);
        return endpoint;
    }
}
