package com.minapro.esb.processor;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.RostimaStrings;
import com.minapro.procserver.events.common.LoginEvent;

public class RostimaProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(RostimaProcessor.class);
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
    
    @Override
    public void process(Exchange exchange) throws Exception {

        LoginEvent loginEvent = (LoginEvent) exchange
                .getProperty("HCloginEvent");
        org.apache.log4j.MDC.put("app.name", "RostimaProcessor");
        LOGGER.info("Calling HC ROSTIMA for processing Login Event request..."+loginEvent);
        
        if (loginEvent != null) {
            String userId = loginEvent.getUserID();
            Date timestamp = loginEvent.getTimeStamp();
            String date = dateFormat.format(timestamp);
            date = date.toUpperCase();                       
            
            String toRost = "jetty:" + RostimaStrings.getUrl() + "?"
                    + RostimaStrings.getUserIdParameter() + "=" + userId + "&"
                    + RostimaStrings.getStartDateParameter() + "=" + date
                    + "&" + RostimaStrings.getEndDateParameter() + "="
                    + date;
            exchange.setProperty("toRostima", toRost);
            exchange.setProperty("Login", loginEvent);            
            exchange.getOut().setHeader("rostimaString", toRost);      
            
            LOGGER.info("HC Login event : "+loginEvent.getEventID()+"  with userID : "+userId+"  Rostima URL formed--> " + toRost);             
        }
    }
}
