package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the sailed vessel details.
 * 
 * @author Rosemary George
 *
 */
public class VesselSailEvent extends Event implements Serializable {
    private static final long serialVersionUID = -4003256036815299460L;

    /**
     * The rotation ID of the vessel which has sailed from the port
     */
    private String rotationID;
    
    /**
     * Vessel code of the sailed vessel
     */
    private String vesselCode;
    
    /**
     * The Berth ID where the vessel has been berthed and sailed from
     */
    private String berthID;

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    public String getVesselCode() {
        return vesselCode;
    }

    public void setVesselCode(String vesselCode) {
        this.vesselCode = vesselCode;
    }

    public String getBerthID() {
        return berthID;
    }

    public void setBerthID(String berthID) {
        this.berthID = berthID;
    }

    @Override
    public String toString() {
        return "VesselSailEvent [rotationID=" + rotationID + ", vesselCode="
                + vesselCode + ", berthID=" + berthID + "]";
    }   
}
