package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.esb.common.SendObject;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.UpdateBayViewRequestEvent;
import com.minapro.procserver.events.common.VesselBerthSideRequestEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;

public class EventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(EventProcessor.class);
    
    private static <T> void setSendObject(String queue, T template,
            Exchange exchange, String templateName) {
        SendObject sendObject = new SendObject();
        sendObject.setQueueName(queue);
        sendObject.setObject(template);
        exchange.getOut().setBody(sendObject);
        EventProcessor.check(sendObject, Constants.HC_OPERATOR + templateName, exchange);

    }

    private static <T> void check(T template, String templateName,
            Exchange exchange) {
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED);
       
        Boolean sent = false;
        if (routed != null) {
            if (routed) {                
                exchange.removeProperty(Constants.ROUTED);
                exchange.removeProperty(templateName);
                LOGGER.debug("Remove routed & template name props from exchange : "+templateName);
            }
        } else {            
            exchange.setProperty(templateName, template);
            exchange.setProperty(Constants.ROUTED, sent);            
            exchange.setProperty(Constants.EVENT_TYPE, templateName);
            LOGGER.debug("Set event-type,routed & template name props to exchange : "+templateName);
        }

    }

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.info("************ In HC EventProcessor process method ************");

        Object object = exchange.getIn().getBody();
        LOGGER.info("HC Request received from RDT is ----> "+object);
        if (object instanceof LogoutEvent) {

            LogoutEvent logoutEvent = (LogoutEvent) object;
            EventProcessor.setSendObject(Constants.HC_OPERATOR, logoutEvent, exchange,
                    Constants.LOGOUT_EVENT);

        } else if (object instanceof ContainerMoveEvent) {
            ContainerMoveEvent containerMoveEvent = (ContainerMoveEvent) object;

            EventProcessor.setSendObject(Constants.HC_OPERATOR, containerMoveEvent,
                    exchange, Constants.CONTAINER_MOVE_EVENT);

        } else if (object instanceof ConfirmAllocationEvent) {

            ConfirmAllocationEvent confirmAllocationEvent = (ConfirmAllocationEvent) object;

            EventProcessor.setSendObject(Constants.HC_OPERATOR, confirmAllocationEvent,
                    exchange, Constants.CONFIRM_ALLOCATION_EVENT);

        } else if (object instanceof JobListRequestEvent) {
            JobListRequestEvent event = (JobListRequestEvent) object;

            EventProcessor.setSendObject(Constants.HC_OPERATOR, event, exchange, Constants.JOBLIST_EVENT);

        } else if (object instanceof ITVPoolRequestEvent) {
            ITVPoolRequestEvent poolRequestEvent = (ITVPoolRequestEvent) object;

            EventProcessor.setSendObject(Constants.HC_OPERATOR, poolRequestEvent, exchange,
                    Constants.ITVPOOL_EVENT);

        } else if (object instanceof VesselBerthSideRequestEvent) {

            VesselBerthSideRequestEvent vesselBerthSideRequestEvent = (VesselBerthSideRequestEvent) object;
            EventProcessor.check(vesselBerthSideRequestEvent, Constants.VESSEL_BERTH_SIDE_EVENT,
                    exchange);

        } else if (object instanceof UpdateContainerEvent) {
            UpdateContainerEvent updateContainerEvent = (UpdateContainerEvent) object;
            EventProcessor.setSendObject(Constants.HC_OPERATOR, updateContainerEvent,
                    exchange, Constants.UPDATE_CONTR_EVENT);

        } else if (object instanceof UpdateBayViewRequestEvent) {
            UpdateBayViewRequestEvent bayViewReqEvent = (UpdateBayViewRequestEvent) object;
            EventProcessor.check(bayViewReqEvent, Constants.HC_OPERATOR + Constants.BAY_UPDATE_EVENT, exchange);

        } else if (object instanceof LoginEvent) {
            LoginEvent loginEvent = (LoginEvent) object;
            EventProcessor.check(loginEvent, Constants.HC_OPERATOR + Constants.LOGIN_EVENT, exchange);

        } else if (object instanceof OrphanContainerEvent) {
            OrphanContainerEvent orphanContrEvent = (OrphanContainerEvent) object;
            EventProcessor.setSendObject(Constants.HC_OPERATOR, orphanContrEvent, exchange,
                    Constants.ORPHAN_CONTR_EVENT);
        } else if (object instanceof OperatorAvailabilityEvent) {
            OperatorAvailabilityEvent availabilityEvent = (OperatorAvailabilityEvent) object;
            EventProcessor.setSendObject(Constants.HC_OPERATOR,
                    availabilityEvent, exchange, Constants.OPERATOR_AVAIL_EVENT);          
            
        } else if (object instanceof OutOfListContainersRequestEvent) {
            OutOfListContainersRequestEvent outOfListContrsEvent = (OutOfListContainersRequestEvent) object;
            EventProcessor.check(outOfListContrsEvent, Constants.HC_OPERATOR + Constants.OUTOFLIST_CONTR_EVENT, exchange);
        }         
    }
}
