package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
public class EndpointProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(EndpointProcessor.class);   

    private static <T> void check(String templateName, Exchange exchange) {
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED);
        LOGGER.debug("Routed First Run " + routed);
        if (routed != null) {
            if (routed) {
                LOGGER.debug("Routed and eventType REMOVED");
                exchange.removeProperty(Constants.ROUTED);
                exchange.removeProperty(templateName);
            }
        } else {
            exchange.setProperty(Constants.ROUTED, false);
            exchange.setProperty("eventType", templateName);
        }
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        String endPointUri = exchange.getFromEndpoint().getEndpointUri();
        String[] uri = endPointUri.split("//");
        exchange.setProperty(uri[1], "ActiveMQ");
        EndpointProcessor.check(uri[1], exchange);
        LOGGER.debug("Processed endpoint URI for exchange object... " + uri[1]);
    }
}
