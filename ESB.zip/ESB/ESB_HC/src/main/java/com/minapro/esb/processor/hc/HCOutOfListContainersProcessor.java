package com.minapro.esb.processor.hc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.hc.OutOfListContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;

public class HCOutOfListContainersProcessor implements Processor {

	private static final Logger LOGGER = Logger
			.getLogger(HCOutOfListContainersProcessor.class);

	@Override
	public void process(Exchange exchange) throws Exception {

		OutOfListContainersRequestEvent requestEvent = (OutOfListContainersRequestEvent) exchange
				.getProperty(Constants.HC_OPERATOR
						+ Constants.OUTOFLIST_CONTR_EVENT);
		LOGGER.info("Processing HCOutOfListContainersProcessor request : "
				+ requestEvent);

		OutOfListContainerResponseEvent responseEvent = new OutOfListContainerResponseEvent();

		List<JobListContainer> outOfListContainers = getOutOfListContrList(
				requestEvent.getRotationId(), requestEvent.getCntrKey(),
				exchange);

		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setOutOfListContainers(outOfListContainers);

		LOGGER.info("Response sent to RDT for ContainerInquiryProcessor is --> "
				+ responseEvent);

		exchange.getOut().setBody(responseEvent);
		exchange.setProperty(Constants.OUTOFLIST_CONTR_EVENT, "yes");
		exchange.setProperty(Constants.ROUTED, null);

	}

	private List<JobListContainer> getOutOfListContrList(String rotnId,
			String containerKey, Exchange exchange) {

		List<JobListContainer> outOfListContainers = new ArrayList<JobListContainer>();

		Connection connection = null;
		PreparedStatement outOfListContrInquiryStmt = null;
		ResultSet outOfListContrInquriryResultSet = null;

		@SuppressWarnings("deprecation")
		DataSource dataSource = (DataSource) exchange.getContext()
				.getRegistry().lookup(Constants.PROMIS_DB);
		try {
			connection = dataSource.getConnection();

			outOfListContrInquiryStmt = connection
					.prepareStatement(Constants.OUT_OF_LIST_CONTR_INQUIRY_QUERY);

			String contrKey = containerKey.substring(0,
					containerKey.length() - 1);
			String checkSumDigit = containerKey.substring(
					containerKey.length() - 1, containerKey.length());
			outOfListContrInquiryStmt.setString(1, rotnId);
			outOfListContrInquiryStmt.setString(2, "%" + contrKey);
			outOfListContrInquiryStmt.setString(3, checkSumDigit);

			outOfListContrInquriryResultSet = outOfListContrInquiryStmt
					.executeQuery();
			while (outOfListContrInquriryResultSet.next()) {
				Container container = new Container();
				JobListContainer jobListContainer = new JobListContainer();

				String containerId = outOfListContrInquriryResultSet
						.getString("containerId");
				String pod = outOfListContrInquriryResultSet.getString("pod");
				String isoCode = outOfListContrInquriryResultSet
						.getString("isoCode");
				Double weight = outOfListContrInquriryResultSet
						.getDouble("weight");

				/* UN_NO represents IMDG Code for hazardous containers */
				Integer unNo = outOfListContrInquriryResultSet.getInt("unNo");
				Integer unNo2 = outOfListContrInquriryResultSet.getInt("unNo2");
				Integer unNo3 = outOfListContrInquriryResultSet.getInt("unNo3");

				String hazardousCode = getHazardousCode(unNo, unNo2, unNo3);
				boolean isHazardous = null != hazardousCode ? true : false;

				String containerEmpty = outOfListContrInquriryResultSet
						.getString("containerEmpty");
				boolean isEmpty = null != containerEmpty
						|| Constants.M.equalsIgnoreCase(containerEmpty) ? true
						: false;

				boolean isOOG = isIndicatorFlag(outOfListContrInquriryResultSet
						.getString("oog"));
				String size = outOfListContrInquriryResultSet
						.getString("containerSize");
				
				String moveType = outOfListContrInquriryResultSet
						.getString("moveType");
				if (null != moveType && "D".equalsIgnoreCase(moveType)) {
					moveType = "DSCH";
				} else {
					moveType = "LOAD";
				}

				boolean isReefer = isIndicatorFlag(outOfListContrInquriryResultSet
						.getString("reefer"));
				boolean isDamaged = isIndicatorFlag(outOfListContrInquriryResultSet
						.getString("damaged"));

				String stowage = outOfListContrInquriryResultSet
						.getString("stowage");
				LOGGER.info("stowage received from DB : "+stowage );
				if (null != stowage) {
					stowage = new StringBuffer(stowage)
							.insert(stowage.length() - 2, ".")
							.insert(stowage.length() - 4, ".").toString();
					LOGGER.info("stowage after adding dots : "+stowage );
				}
				String category = outOfListContrInquriryResultSet
						.getString("category");
				String robFlag = outOfListContrInquriryResultSet
						.getString("ROB_FLAG");

				container.setContainerID(containerId);
				container.setPod(pod);
				container.setIsoCode(isoCode);

				/**
				 * set UNNO
				 */
				container.setWeight(weight.toString());
				container.setHazardous(isHazardous);
				container.setHazardousCode(hazardousCode);
				container.setEmpty(isEmpty);
				container.setOOG(isOOG);
				container.setSize(size);
				container.setReefer(isReefer);
				container.setDamaged(isDamaged);
				container.setCategory(category);

				jobListContainer.setContainerId(containerId);
				jobListContainer.setContainer(container);
				jobListContainer.setMoveType(moveType);
				jobListContainer.setRotationId(rotnId);
				jobListContainer.setFromLocation(stowage);

				outOfListContainers.add(jobListContainer);
			}

		} catch (SQLException e) {
			LOGGER.info(
					"SQLException occured while OutOfListContainersRequestEvent: ",
					e);
		} finally {
			try {
				if (null != outOfListContrInquiryStmt) {
					outOfListContrInquiryStmt.close();
				}
				if (null != connection) {
					connection.close();
				}
				if (null != outOfListContrInquriryResultSet) {
					outOfListContrInquriryResultSet.close();
				}
			} catch (SQLException e) {
				LOGGER.info(
						"SQLException occured while closing connections for OutOfListContainersRequestEvent: ",
						e);
			}
		}
		return outOfListContainers;
	}

	private boolean isIndicatorFlag(String indicatorFlag) {
		boolean indicator = false;
		if (null != indicatorFlag
				&& ("Y".equalsIgnoreCase(indicatorFlag) || "Yes"
						.equalsIgnoreCase(indicatorFlag))) {
			indicator = true;
		}
		return indicator;
	}

	/**
	 * Get IMDG code for a given container
	 * 
	 * @param unNo
	 * @param unNo2
	 * @param unNo3
	 * @return
	 */
	private String getHazardousCode(Integer unNo, Integer unNo2, Integer unNo3) {
		StringBuilder hazardousCodeBuilder = new StringBuilder();
		List<String> hazardousCodeList = new ArrayList<String>();
		String imdgCodes = null;
		try {

			if (unNo != null && unNo > 0) {
				hazardousCodeList.add(unNo.toString());
			}

			if (unNo2 != null && unNo2 > 0) {
				hazardousCodeList.add(unNo2.toString());
			}
			if (unNo3 != null && unNo3 > 0) {
				hazardousCodeList.add(unNo3.toString());
			}

			for (String imoCode : hazardousCodeList) {
				hazardousCodeBuilder.append(imoCode).append(
						Constants.COMMA_DELIMITER);
			}

			if (hazardousCodeBuilder.length() > 0) {
				imdgCodes = hazardousCodeBuilder.substring(0,
						hazardousCodeBuilder.length() - 1);
			}

		} catch (Exception e) {
			LOGGER.error("Exception while retriveing IMDG code: ", e);
		}
		return imdgCodes;
	}

	public static void main(String[] args) {
		String str = "023456";
		str = new StringBuffer(str).insert(str.length() - 2, ".")
				.insert(str.length() - 4, ".").toString();

		System.out.println("*** " + str);
	}
}
