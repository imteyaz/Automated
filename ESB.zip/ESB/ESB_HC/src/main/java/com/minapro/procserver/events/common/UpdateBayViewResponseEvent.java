package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the update bay view response details from ESB, contains a
 * list of container objects
 * 
 * @author Rosemary George
 * 
 */
public class UpdateBayViewResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = 3143833218507941453L;

    /**
     * List of containers which has updated stowage position
     */
    private List<Container> updatedContainerList;

    public List<Container> getUpdatedContainerList() {
        return updatedContainerList;
    }

    public void setUpdatedContainerList(
            List<Container> updatedContainerList) {
        this.updatedContainerList = updatedContainerList;
    }

    @Override
    public String toString() {
        return "UpdateBayViewResponseEvent [updatedContainerList="
                + updatedContainerList + ", UserID=" + getUserID()
                + ", EquipmentID=" + getEquipmentID() + "]";
    }
}
