package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;

public class OutOfListContainerResponseEvent extends Event implements Serializable{
    
    private static final long serialVersionUID = -8574843781785610254L;

    private List<JobListContainer> outOfListContainers;

    
    public List<JobListContainer> getOutOfListContainers() {
        return outOfListContainers;
    }

    public void setOutOfListContainers(List<JobListContainer> outOfListContainers) {
        this.outOfListContainers = outOfListContainers;
    }

    @Override
    public String toString() {
        return "OutOfListContainerResponseEvent [outOfListContainers="
                + outOfListContainers + ", UserID=" + getUserID()
                + ", EquipmentID=" + getEquipmentID() + ", EventID="
                + getEventID() + "]";
    }
}
