package com.minapro.procserver.events.hc;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.minapro.procserver.events.Event;
/**
 * Event is used to hold the information about Orphan Container or OutOfListContainer.
 * @author Umamahesh M.
 *
 */
public class OrphanContainerEvent extends Event implements Serializable{

    private static final long serialVersionUID = -7400241080976181236L;
    
    private static final Logger LOGGER = Logger
            .getLogger(OrphanContainerEvent.class);
    
    /**
     *Holds the Orphan Container ID  
     */
    private String containerID;
  
    /**
     * Vessel details of the container
     */
    private String vessel;
    
    /**
     * Voyage details of the container
     */
    private String voyage;
    
    /**
     * ISO code of the container
     */
    private String isoCode;
    /**
     * ITV Number
     */
    private String itvNo;
    
    /**
     * indicates whether the job is out of list container
     */
    private boolean isOutOfListContainer;
    
    /**
     * From location of the container
     */
    private String fromLocation;
       
    public String getFromLocation() {
        return fromLocation;
    }
    
    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }
    
    public boolean getOutOfListContainer() {
        return isOutOfListContainer;
    }
    public void setIsOutOfListContainer(String isOutOfListContainer) {
        if("1".equalsIgnoreCase(isOutOfListContainer)){
            this.isOutOfListContainer = true;
        }else {
            this.isOutOfListContainer = false;
        }       
    }
    public String getItvNo() {
        return itvNo;
    }
    public void setItvNo(String itvNo) {
        this.itvNo = itvNo;
    }
    public String getContainerID() {
        return containerID;
    }
    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }
    
    public static long getSerialversionuid() {
        return serialVersionUID;
    }    
    public String getVessel() {
        return vessel;
    }
    public void setVessel(String vessel) {
        this.vessel = vessel;
    }
    public String getVoyage() {
        return voyage;
    }
    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }
    public String getIsoCode() {
        return isoCode;
    }
    
    public void setIsoCode(String isoCode) {
        try{
            this.isoCode = isoCode.split("-")[0];
        }catch(Exception ex){
            this.isoCode = isoCode;
            LOGGER.error("Exception occured: ",ex);
        }       
    }

    @Override
    public String toString() {
        return "OrphanContainerEvent [containerID=" + containerID + ", vessel=" + vessel + ", voyage=" + voyage
                + ", isoCode=" + isoCode + ", itvNo=" + itvNo + ", isOutOfListContainer=" + isOutOfListContainer
                + ", fromLocation=" + fromLocation + ", UserID()=" + getUserID() + ", EquipmentID()="
                + getEquipmentID() + ", EventID()=" + getEventID() + "]";
    }   
        
}
