package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the details about pinning station job status.
 * @author Rosemary George
 *
 */
public class PinningStationJobConfirmationEvent extends Event implements Serializable {
    private static final long serialVersionUID = -8262688296712200072L;
    
    /**
     * The container ID which has been completed pinning or unpinning
     */
    private String containerID; 
    /**
     * The ITV ID which is carrying the container
     */
    private String itvID;   
    
    /**
     * Indicates the pinning operation type, whether it was coning/de-coning
     */
    private String pinningType;
    /**
     * Indicates whether operation was successful or not
     */
    private String status;
    /**
     * in case of failure, field to hold additional data
     */
    private String message;
    
    public String getContainerID() {
        return containerID;
    }
    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }
    public String getPinningType() {
        return pinningType;
    }
    public void setPinningType(String pinningType) {
        this.pinningType = pinningType;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getItvID() {
        return itvID;
    }
    public void setItvID(String itvID) {
        this.itvID = itvID;
    }
    
    @Override
    public String toString() {
        return "PinningStationJobConfirmationEvent [containerID=" + containerID
                + ", itvID=" + itvID + ", pinningType=" + pinningType
                + ", status=" + status + ", UserID=" + getUserID()
                + ", TerminalID=" + getTerminalID() + "]";
    }
    
    
}
