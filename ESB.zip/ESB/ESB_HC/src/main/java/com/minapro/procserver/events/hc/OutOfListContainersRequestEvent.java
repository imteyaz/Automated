package com.minapro.procserver.events.hc;

import java.io.Serializable;
import com.minapro.procserver.events.Event;

public class OutOfListContainersRequestEvent extends Event implements Serializable {    
    
    private static final long serialVersionUID = -5814779994480167822L;
    
    private String rotationId;
    
    private String cntrKey;
	

	public String getRotationId() {
		return rotationId;
	}

	public void setRotationId(String rotationId) {
		this.rotationId = rotationId;
	}

	public String getCntrKey() {
		return cntrKey;
	}

	public void setCntrKey(String cntrKey) {
		this.cntrKey = cntrKey;
	}

	@Override
	public String toString() {
		return "OutOfListContainersRequestEvent [rotationId=" + rotationId
				+ ", cntrKey=" + cntrKey + ", getUserID()=" + getUserID()
				+ ", getEquipmentID()=" + getEquipmentID()
				+ ", getTerminalID()=" + getTerminalID() + ", getEventID()="
				+ getEventID() + "]";
	}
}
