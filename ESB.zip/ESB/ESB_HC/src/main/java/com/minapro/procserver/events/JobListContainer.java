package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the container details related to the Job list from ESB
 * 
 * @author Rosemary George
 *
 */
public class JobListContainer implements Serializable, Comparable<JobListContainer> {
    private static final long serialVersionUID = 5449177895010357182L;

    private String containerId;
    /**
     * The source location of the container In case of Load operation, this contains the yard location In case of
     * discharge operation, this contains the vessel location
     */
    private String fromLocation;
    /**
     * The destination location In case of Load operation, this contains the vessel location In case of discharge
     * operation, this contains the yard location
     */
    private String toLocation;
    /**
     * Indicates whether it is L(load) or D(discharge) operation.
     */
    private String moveType;
    /**
     * Contains a containerID reference if it is a twin job
     */
    private String twinContainerId;
    /**
     * Indicates whether the handling of container is overridden by the operator. In such case, the SPARCS update is
     * ignored. Generally happens for twin/ splitting twin or tandem cases
     */
    private transient boolean isManuallyOverridden = false;

    /**
     * Contains the containerIDs which have been marked as TANDEM with this container. This can contain 2 to 4 container
     * IDs. Four 20" containers or Two 40" containers or two 20" container plus one 40" container is treated as TANDEM
     */
    private transient String[] tandemContainerIDs;

    /**
     * Indicates the rotation of the vessel to which the container belongs to. This will be filled in case of LOAD/DSCH
     * case only
     */
    private String rotationId;

    private String equipmentId;
    
    private double seqNumber;
    
    private Container container;
    /*
     * Following Three are the new properties with respect to OPUS.
     * These properties needed when Exchange stowage position is required.
     */
    private transient String voyage;
   

    private transient String vesselName;
    private transient String jobKey;
    
    /*
     * Property is defined to store the ITV Waiting At a particular Block.
     * As of now , This value is calculating at Yard Side only.
     * 
     */
    private transient long itvWaitingTimeInSeconds;
    
    /**
     * Indicates whether the job is pre-confirmed  or not
     */
    private boolean preConfirmedJob;
    
    
    public long getItvWaitingTimeInSeconds() {
        return itvWaitingTimeInSeconds;
    }

    public void setItvWaitingTimeInSeconds(long itvWaitingTimeInSeconds) {
        this.itvWaitingTimeInSeconds = itvWaitingTimeInSeconds;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }
    
    public boolean isPreConfirmedJob() {
        return preConfirmedJob;
    }

    public void setPreConfirmedJob(boolean preConfirmedJob) {
        this.preConfirmedJob = preConfirmedJob;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public double getSeqNumber() {
        return seqNumber;
    }

    public void setSeqNumber(double seqNumber) {
        this.seqNumber = seqNumber;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String[] getTandemContainerIDs() {
        return tandemContainerIDs;
    }

    public void setTandemContainerIDs(String[] tandemContainerIDs) {
        this.tandemContainerIDs = tandemContainerIDs;
    }

    public boolean isManuallyOverridden() {
        return isManuallyOverridden;
    }

    public void setManuallyOverridden(boolean isManuallyOverridden) {
        this.isManuallyOverridden = isManuallyOverridden;
    }

    public String getTwinContainerId() {
        return twinContainerId;
    }

    public void setTwinContainerId(String twinContainerId) {
        this.twinContainerId = twinContainerId;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }
    public String getVoyage() {
        return voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getVesselName() {
        return vesselName;
    }

    public void setVesselName(String vesselName) {
        this.vesselName = vesselName;
    }

    public String getJobKey() {
        return jobKey;
    }

    public void setJobKey(String jobKey) {
        this.jobKey = jobKey;
    }
    /**
     * <p> Compares the instance with another Container. Compares the following attributes to declare the objects as
     * equal. <p>
     * 
     * <p> container ID </P> <p> fromLocation </p> <p> toLocation </P> <p> Twin Container ID </P>
     * 
     * <p> Returns 0 if all these attributes are same, else returns 1
     */
    @Override
    public int compareTo(JobListContainer joblistContainer) {
        if (this.containerId.equals(joblistContainer.getContainerId())
                && this.fromLocation.equals(joblistContainer.getFromLocation())
                && this.toLocation.equals(joblistContainer.getToLocation())
                && ((this.twinContainerId == null && joblistContainer.getTwinContainerId() == null) || (this.twinContainerId != null && this.twinContainerId
                        .equals(joblistContainer.getTwinContainerId())))) {
            return 0;
        } else {
            return 1;
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((containerId == null) ? 0 : containerId.hashCode()) + ((moveType == null) ? 0 : moveType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        JobListContainer other = (JobListContainer) obj;
        if (containerId == null) {
            if (other.containerId != null) {
                return false;
            }
        } else if (!containerId.equals(other.containerId)) {
            return false;
        }else if(!moveType.equals(other.moveType)){
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "JobListContainer [containerId=" + containerId
                + ", fromLocation=" + fromLocation + ", toLocation="
                + toLocation + ", moveType=" + moveType + ", twinContainerId="
                + twinContainerId + ", rotationId=" + rotationId
                + ", equipmentId=" + equipmentId + ", seqNumber=" + seqNumber
                + ", container=" + container + ", voyage=" + voyage
                + ", vesselName=" + vesselName + ", jobKey=" + jobKey
                + ", preConfirmedJob=" + preConfirmedJob + "]";
    }
    
}
