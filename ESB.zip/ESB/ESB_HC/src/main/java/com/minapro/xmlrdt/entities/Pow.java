package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "pow")
public class Pow {

    private String name;
    private String mode;
    private String modeCycle;
    private String mode2x20s;

    @XmlAttribute(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlAttribute(name = "mode")
    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @XmlAttribute(name = "modeCycle")
    public String getModeCycle() {
        return modeCycle;
    }

    public void setModeCycle(String modeCycle) {
        this.modeCycle = modeCycle;
    }

    @XmlAttribute(name = "mode2x20s")
    public String getMode2x20s() {
        return mode2x20s;
    }

    public void setMode2x20s(String mode2x20s) {
        this.mode2x20s = mode2x20s;
    }

    @Override
    public String toString() {
        return "Pow [name=" + name + ", mode=" + mode + ", modeCycle="
                + modeCycle + ", mode2x20s=" + mode2x20s + "]";
    }
}
