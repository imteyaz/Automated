package com.minapro.xmlrdt.entities;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Pool {

    private String name;
    private List<List> list;

    @XmlAttribute(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlElement(name = "list")
    public List<List> getList() {
        return list;
    }

    public void setList(List<List> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "Pool [name=" + name + ", list=" + list + "]";
    }
}
