package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

/**
 * ValueObject holding the details about container movement
 * 
 * @author Rosemary George
 * 
 */
public class ContainerMoveEvent extends Event implements Serializable {
    private static final long serialVersionUID = 2593293221995672513L;

    /**
     * Can be at most two container IDs- applicable in twin lift case
     */
    private List<String> containerIDs;

    /**
     * the source location of the container- can be vessel, ITV ID or Yard
     * location depending on the context Can also contain at most tow locations
     * in case of twin lift case
     */
    private List<String> fromLocations;

    /**
     * The destination location of the container - can be vessel, ITV ID or Yard
     * location depending on the context Can also contain at most tow locations
     * in case of twin lift case
     */
    private List<String> toLocations;

    /**
     * Flag - to check whether it is automatic job confirmation from PLC or
     * Manual job confirm
     */
    private boolean automaticFlag;

    /**
     * Indicates whether it is discharge or load operation.
     */
    private String moveType;
    
    /**
     * If true  -Indicates that the event is raised as pre job confirmation. 
     */
    private boolean preJobConfirmation;
    
    /**
     * positionOnChassis Fore or Aft Flag e.g) Fore="F", Aft="A",Center="C" otherwise:""
     */
    private List<String> position;
    
    
    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }   

    public List<String> getContainerIDs() {
        return containerIDs;
    }

    public void setContainerIDs(List<String> containerIDs) {
        this.containerIDs = containerIDs;
    }

    public List<String> getFromLocations() {
        return fromLocations;
    }

    public void setFromLocations(List<String> fromLocations) {
        this.fromLocations = fromLocations;
    }

    public List<String> getToLocations() {
        return toLocations;
    }

    public void setToLocations(List<String> toLocations) {
        this.toLocations = toLocations;
    }

    public boolean isAutomaticFlag() {
        return automaticFlag;
    }

    public void setAutomaticFlag(boolean automaticFlag) {
        this.automaticFlag = automaticFlag;
    }

    public boolean isPreJobConfirmation() {
        return preJobConfirmation;
    }

    public void setPreJobConfirmation(boolean preJobConfirmation) {
        this.preJobConfirmation = preJobConfirmation;
    }

    public List<String> getPosition() {
        return position;
    }

    public void setPosition(List<String> position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return "ContainerMoveEvent [containerIDs=" + containerIDs
                + ", fromLocations=" + fromLocations + ", toLocations="
                + toLocations + ", automaticFlag=" + automaticFlag
                + ", moveType=" + moveType + ", preJobConfirmation="
                + preJobConfirmation + ", position=" + position
                + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }
    
}
