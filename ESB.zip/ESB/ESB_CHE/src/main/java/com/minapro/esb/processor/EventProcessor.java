package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.esb.common.SendObject;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.NewLocationRequestEvent;
import com.minapro.procserver.events.che.ReeferConnectionRequestEvent;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersRequestEvent;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;

public class EventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(EventProcessor.class);

    private static <T> void setSendObject(String queue, T template, Exchange exchange, String templateName) {
        SendObject sendObject = new SendObject();
        sendObject.setQueueName(queue);
        sendObject.setObject(template);
        exchange.getOut().setBody(sendObject);
        EventProcessor.check(sendObject, Constants.CHE_OPERATOR + templateName, exchange);

    }

    private static <T> void check(T template, String templateName, Exchange exchange) {
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED);
       
        Boolean sent = false;
        if (routed != null) {
            if (routed) {                
                exchange.removeProperty(Constants.ROUTED);
                exchange.removeProperty(templateName);
                LOGGER.debug("Remove routed & template name props from exchange : "+templateName);
            }
        } else {
            exchange.setProperty(templateName, template);
            exchange.setProperty(Constants.ROUTED, sent);            
            exchange.setProperty("eventType", templateName);
            LOGGER.debug("Set event-type,routed & template name props to exchange : "+templateName);    
        }
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("************ In CHE EventProcessor process method ************");
        
        Object object = exchange.getIn().getBody();
        LOGGER.info("CHE Request received from RDT is ----> "+object);
        if (object instanceof LogoutEvent) {
            LogoutEvent logoutEvent = (LogoutEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, logoutEvent, exchange, Constants.LOGOUT_EVENT);

        } else if (object instanceof ITVPoolRequestEvent) {
            ITVPoolRequestEvent poolRequestEvent = (ITVPoolRequestEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, poolRequestEvent, exchange, Constants.ITVPOOLREQEVENT);

        } else if (object instanceof ContainerMoveEvent) {
            ContainerMoveEvent containerMoveEvent = (ContainerMoveEvent) object;
            LOGGER.info("Container Move Event Received " + containerMoveEvent);
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, containerMoveEvent, exchange, Constants.CONTAINER_MOVE_EVENT);

        } else if (object instanceof ConfirmAllocationEvent) {
            ConfirmAllocationEvent confirmAllocationEvent = (ConfirmAllocationEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, confirmAllocationEvent, exchange, Constants.CONFIRM_ALLOCATION_EVENT);

        } else if (object instanceof CHEJobListRequestEvent) {
            CHEJobListRequestEvent joblistEvent = (CHEJobListRequestEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, joblistEvent, exchange, Constants.JOBLIST_EVENT);

        } else if (object instanceof ITVPoolRequestEvent) {
            ITVPoolRequestEvent poolRequestEvent = (ITVPoolRequestEvent) object;
            EventProcessor.check(poolRequestEvent, Constants.ITVPOOLREQEVENT, exchange);

        } else if (object instanceof UpdateContainerEvent) {
            UpdateContainerEvent updateContainerEvent = (UpdateContainerEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR, updateContainerEvent, exchange, Constants.UPDATE_CONTR_EVENT);

        } else if (object instanceof LoginEvent) {            
            LoginEvent loginEvent = (LoginEvent) object;
            EventProcessor.check(loginEvent, Constants.CHE_OPERATOR + Constants.LOGIN_EVENT, exchange);
            
        } else if (object instanceof ReeferConnectionRequestEvent) {            
            ReeferConnectionRequestEvent reeferConnectionEvent = (ReeferConnectionRequestEvent) object;
            EventProcessor.check(reeferConnectionEvent, Constants.CHE_OPERATOR+ Constants.REEFER_CONNECTION_EVENT, exchange);

        } else if (object instanceof UpdateBlockContainersRequestEvent) {
            UpdateBlockContainersRequestEvent updateBlockContainersEvent = (UpdateBlockContainersRequestEvent) object;
            EventProcessor.check(updateBlockContainersEvent, Constants.CHE_OPERATOR+ Constants.UPDATE_BLOCK_CONTR_EVENT, exchange);

        } else if (object instanceof NewLocationRequestEvent) {
            NewLocationRequestEvent newContrLocationEvent = (NewLocationRequestEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,newContrLocationEvent, exchange,
                    Constants.NEW_CONTR_LOCATION);
            
        } else if (object instanceof ShuffleRequestEvent) {
            ShuffleRequestEvent shuffleRequestEvent = (ShuffleRequestEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,shuffleRequestEvent, exchange,
                    Constants.SHUFFLE_CONTR_LOCATION);
            
        }  else if (object instanceof OperatorAvailabilityEvent) {
            OperatorAvailabilityEvent availabilityEvent = (OperatorAvailabilityEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,
                    availabilityEvent, exchange, Constants.OPERATOR_AVAIL_EVENT);  
            
        } else if (object instanceof JobSelectionEvent) {
            JobSelectionEvent jobSelection = (JobSelectionEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,
                    jobSelection, exchange, Constants.JOB_SELECT_EVENT);        
            
        } else if (object instanceof CancelJobSelectionEvent) {
            CancelJobSelectionEvent cancelJobSelection = (CancelJobSelectionEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,
                    cancelJobSelection, exchange, Constants.CANCEL_JOB_SELECT_EVENT);            
        } else if (object instanceof InventoryUpdateRequestEvent) {
            InventoryUpdateRequestEvent inventoryUpdateRequestEvent = (InventoryUpdateRequestEvent) object;
            EventProcessor.setSendObject(Constants.CHE_OPERATOR,
                    inventoryUpdateRequestEvent, exchange, Constants.INVENTORY_UPDATE_EVENT);            
        } 
    }
    
    /**
     * Process COMMONQ requests
     * @param exchange
     */
    public void processCommonRequest(Exchange exchange) {
        LOGGER.debug("************ In CHE EventProcessor common process method ************");

        Object object = exchange.getIn().getBody();
        LOGGER.info("CHE Common Request received from RDT is ----> " + object);
        
        if (object instanceof BlockViewRequestEvent) {
            BlockViewRequestEvent blockViewRequestEvent = (BlockViewRequestEvent) object;
            EventProcessor.check(blockViewRequestEvent, Constants.CHE_OPERATOR + Constants.YARD_VIEW_EVENT, exchange);

        }       
    }
}
