package com.minapro.procserver.events.itv;

import java.io.Serializable;

/**
 * ValueObject holding the ITV attributes
 * 
 * @author Rosemary George
 *
 */
public class ITV implements Serializable {
    private static final long serialVersionUID = -3537661350065312774L;

    /**
     * ID of the ITV
     */
    private String itvId;
    
    /**
     * Indicates whether the ITV can hold 20" or 40" container. 
     * value can be 20 or 40.
     */
    private int loadCapacity;
    
    /**
     * Indicates whether the ITV can handle more than one container.
     * This is applicable only when the loadCapacity is 20.
     */
    private int noOfContainer;
    
    public String getItvId() {
        return itvId;
    }
    public void setItvId(String itvId) {
        this.itvId = itvId;
    }
    public int getLoadCapacity() {
        return loadCapacity;
    }
    public void setLoadCapacity(int loadCapacity) {
        this.loadCapacity = loadCapacity;
    }
    public int getNoOfContainer() {
        return noOfContainer;
    }
    public void setNoOfContainer(int noOfContainer) {
        this.noOfContainer = noOfContainer;
    }
    
    @Override
    public String toString() {
        return "ITV [itvId=" + itvId + ", loadCapacity=" + loadCapacity
                + ", noOfContainer=" + noOfContainer + "]";
    }   
}
