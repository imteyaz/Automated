package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the allocation confirmation details of a user
 * 
 * @author Rosemary George
 * 
 */
public class ConfirmAllocationEvent extends Event implements Serializable {
    private static final long serialVersionUID = -4258500269750632566L;

    /**
     * RotationID selected and confirmed by the user
     */
    private String rotationID;

    private boolean isScheduled;

    /**
     * Activity code selected by the user - can be operational or non operational activities
     */
    private String activityCode;

    /**
     * Location selected and confirmed by the user
     */
    private String location;

    /**
     * User entered text against the activity type "Other"
     */
    private String remarks;

    /**
     * Password of the user
     */
    private String password;

    private boolean esbTrigger;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRotationID() {
        return rotationID;
    }

    public void setRotationID(String rotationID) {
        this.rotationID = rotationID;
    }

    public String getActivityCode() {
        return activityCode;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isEsbTrigger() {
        return esbTrigger;
    }

    public void setEsbTrigger(boolean esbTrigger) {
        this.esbTrigger = esbTrigger;
    }

       public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

    @Override
    public String toString() {
        return "ConfirmAllocationEvent [rotationID=" + rotationID
                + ", isScheduled=" + isScheduled + ", activityCode="
                + activityCode + ", location=" + location + ", remarks="
                + remarks + ", esbTrigger="
                + esbTrigger + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getEventID()="
                + getEventID() + "]";
    }
    

}
