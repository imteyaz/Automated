package com.minapro.procserver.events.che;

import java.io.Serializable;

public class ReeferWithStatusEvent implements Serializable {

    private static final long serialVersionUID = 4401539477421701766L;

    /**
     * reefer container Id
     */
    private String containerId;

    /**
     * Status of reefer container
     */
    private boolean isConnected;
    
    private String moveType;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean isConnected) {
        this.isConnected = isConnected;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    @Override
    public String toString() {
        return "ReeferWithStatusEvent [containerId=" + containerId + ", isConnected=" + isConnected + ", moveType="
                + moveType + "]";
    }
}
