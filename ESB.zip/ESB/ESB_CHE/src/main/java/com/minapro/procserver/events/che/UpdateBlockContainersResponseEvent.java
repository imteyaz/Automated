package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

public class UpdateBlockContainersResponseEvent extends Event implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = -7319742951448797376L;
    
    private List<YardProfileContainer> updatedContainerList;

    public List<YardProfileContainer> getUpdatedContainerList() {
        return updatedContainerList;
    }

    public void setUpdatedContainerList(
            List<YardProfileContainer> updatedContainerList) {
        this.updatedContainerList = updatedContainerList;
    }

    @Override
    public String toString() {
        return "UpdateBlockContainersResponseEvent [updatedContainerList="
                + updatedContainerList + "]";
    }
}
