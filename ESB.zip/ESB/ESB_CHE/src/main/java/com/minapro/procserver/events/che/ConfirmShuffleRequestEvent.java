package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ConfirmShuffleRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2346400616938661200L;
    private String shuffleContainerId;

    public String getShuffleContainerId() {
        return shuffleContainerId;
    }

    public void setShuffleContainerId(String shuffleContainerId) {
        this.shuffleContainerId = shuffleContainerId;
    }

}
