package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class NewLocationResponseEvent extends Event implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -5803020399021709840L;
    private String containerID; 
    private String errorReason;
    private String newLocation;
    private boolean status;
    
    public String getContainerID() {
        return containerID;
            
    }
    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }
    public String getErrorReason() {
        return errorReason;
    }
    public void setErrorReason(String errorReason) {
        this.errorReason = errorReason;
    }
    public String getNewLocation() {
        return newLocation;
    }
    public void setNewLocation(String newLocation) {
        this.newLocation = newLocation;
    }
    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }
    @Override
    public String toString() {
        return "NewLocationResponseEvent [containerID=" + containerID
                + ", errorReason=" + errorReason + ", newLocation="
                + newLocation + ", status=" + status + "]";
    }

}
