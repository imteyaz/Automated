package com.minapro.esb.processor.che;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.che.BlockViewRequestEvent;
import com.minapro.procserver.events.che.BlockWiseContainersResponseEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersRequestEvent;
import com.minapro.procserver.events.che.UpdateBlockContainersResponseEvent;
import com.minapro.procserver.events.che.YardProfileContainer;

public class CHEYardView implements Processor {

	private static final Logger LOGGER = Logger.getLogger(CHEYardView.class);

	@Override
	public void process(Exchange exchange) throws Exception {
		LOGGER.info("*************** In CHEYardView Processor *************");

		BlockViewRequestEvent requestEvent = (BlockViewRequestEvent) exchange
				.getProperty("CHEyardView");
		BlockWiseContainersResponseEvent responseEvent = new BlockWiseContainersResponseEvent();
		if (requestEvent.isPollingTimeReq()) {
			LOGGER.info("Fetching details from OPUS");
			responseEvent = getBlockViewDetailsFromOpus(exchange, requestEvent);
		} else {
			LOGGER.info("Fetching details from PROMIS");
			responseEvent = getBlockViewDetailsFromPromis(exchange,
					requestEvent);
		}

		LOGGER.info("Response Event for CHE yard view -->" + responseEvent);
		exchange.getOut().setBody(responseEvent);
		exchange.setProperty("YardView", "yes");
		exchange.setProperty(Constants.ROUTED, null);
	}

	/**
	 * Block View Container Details retrieved from PROMIS DB
	 * 
	 * @param exchange
	 * @param requestEvent
	 * @return
	 */
	private BlockWiseContainersResponseEvent getBlockViewDetailsFromPromis(
			Exchange exchange, BlockViewRequestEvent requestEvent) {
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet yardResulSet = null;
		BlockWiseContainersResponseEvent responseEvent = new BlockWiseContainersResponseEvent();
		List<YardProfileContainer> yardProfileContainers = null;
		try {
			LOGGER.info("CHEYardView request received --> " + requestEvent);
			if (requestEvent != null) {
				conn = getDBConnection(exchange, Constants.PRMIS_DB);
				LOGGER.debug("Conection established with PROMIS DB ");
				statement = conn.prepareStatement(Constants.YARD_QUERY);
				String blockNum = requestEvent.getBlockNumber() + "%";
				statement.setString(1, blockNum);				
				LOGGER.info(" ************ BEFORE YARD VIEW QUERY EXECUTED block number : "
						+ requestEvent.getBlockNumber() + "%");

				yardResulSet = statement.executeQuery();
				yardProfileContainers = getYardProfileContainer(yardResulSet,
						null);
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured while processing CHEYardView : ", e);
		} finally {
			try {
				if (yardResulSet != null) {
					yardResulSet.close();
				}

				if (statement != null) {
					statement.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				LOGGER.error("Exception while closing connections: ", e);
			}
		}
		LOGGER.info("List of yard profile containers from PROMIS : "
				+ yardProfileContainers);
		responseEvent.setBlockID(requestEvent.getBlockNumber());
		responseEvent.setStackNumber(requestEvent.getStackNumber());
		responseEvent.setContainers(yardProfileContainers);
		responseEvent.setPollingTimeReq(requestEvent.isPollingTimeReq());

		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setUserID(requestEvent.getUserID());

		return responseEvent;
	}

	/**
	 * Block View Container Details retrieved from OPUS DB
	 * 
	 * @param exchange
	 * @param requestEvent
	 * @return
	 */
	private BlockWiseContainersResponseEvent getBlockViewDetailsFromOpus(
			Exchange exchange, BlockViewRequestEvent requestEvent) {
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet yardResulSet = null;
		BlockWiseContainersResponseEvent responseEvent = new BlockWiseContainersResponseEvent();		
		List<YardProfileContainer> yardProfileContainers = new ArrayList<YardProfileContainer>();
		try {
			LOGGER.info("CHEYardView request received for OPUS-->" + requestEvent);
			if (requestEvent != null) {
				conn = getDBConnection(exchange, Constants.TOSADM_DB);
				LOGGER.debug("Conection established with OPUS DB ");
				statement = conn.prepareStatement(Constants.YARD_OPUS_DB_QUERY);
				String blockNum = "%";
				if(requestEvent.getBlockNumber()!=null ){
					blockNum=requestEvent.getBlockNumber() + "%";
				}
				statement.setString(1, blockNum);
				statement.setDouble(2, requestEvent.getTimeLapse());
				LOGGER.info(" ************ BEFORE YARD VIEW QUERY EXECUTED block number : "
						+ requestEvent.getBlockNumber() + "%");

				yardResulSet = statement.executeQuery();

				while (yardResulSet.next()) {

					String containerId = yardResulSet.getString("containerId");
					String currLocation = yardResulSet
							.getString("PROMIS_YARD_LOCATION");
					String oldPosition = yardResulSet
							.getString("PROMIS_OLD_YARD_LOCATION");
					LOGGER.debug("Current Location for CHE Yard Profile View :"
							+ currLocation);
					if (!currLocation.equalsIgnoreCase(oldPosition)) {
						YardProfileContainer yardProfileContainer = new YardProfileContainer();
						Container container = new Container();
						
						container.setContainerID(containerId);

						yardProfileContainer.setContainer(container);
						yardProfileContainer.setYardPosition(currLocation);
						yardProfileContainer.setOldPosition(oldPosition);

						yardProfileContainers.add(yardProfileContainer);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured while processing CHEYardView : ", e);
		} finally {
			try {
				if (yardResulSet != null) {
					yardResulSet.close();
				}

				if (statement != null) {
					statement.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				LOGGER.error("Exception while closing connections: ", e);
			}
		}
		LOGGER.info("List of yard profile containers from OPUS : "
				+ yardProfileContainers);
		responseEvent.setBlockID(requestEvent.getBlockNumber());
		responseEvent.setStackNumber(requestEvent.getStackNumber());
		responseEvent.setContainers(yardProfileContainers);
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent
				.setPollingTimeReq(requestEvent.isPollingTimeReq());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setUserID(requestEvent.getUserID());
		
		return responseEvent;
	}

	/**
	 * get container details from Block view
	 * 
	 * @param exchange
	 */
	public void getUpdateBlockContainerDetails(Exchange exchange) {

		LOGGER.info("*************** In CHE updateBlockContainerDetails() *************");
		Connection conn = null;
		PreparedStatement statement = null;
		ResultSet contrListResultSet = null;

		UpdateBlockContainersRequestEvent requestEvent = (UpdateBlockContainersRequestEvent) exchange
				.getProperty(Constants.CHE_OPERATOR
						+ Constants.UPDATE_BLOCK_CONTR_EVENT);
		try {
			LOGGER.info("CHE update Block Container request received --> "
					+ requestEvent);
			if (requestEvent != null
					&& requestEvent.getUpdateRequiredContainerList() != null) {
				UpdateBlockContainersResponseEvent responseEvent = new UpdateBlockContainersResponseEvent();

				conn = getDBConnection(exchange, Constants.PRMIS_DB);
				LOGGER.debug("Conection established with PROMIS DB");

				statement = conn
						.prepareStatement(getUpdateContrListQuery(requestEvent
								.getUpdateRequiredContainerList()));
				contrListResultSet = statement.executeQuery();
				List<YardProfileContainer> yardProfileContainers = getYardProfileContainer(
						contrListResultSet, Constants.BLOCKVIEW);

				LOGGER.info("List of CHE Update block container details : "
						+ yardProfileContainers);

				responseEvent.setUpdatedContainerList(yardProfileContainers);
				responseEvent.setEquipmentID(requestEvent.getEquipmentID());
				responseEvent.setEventID(requestEvent.getEventID());
				responseEvent.setTerminalID(requestEvent.getTerminalID());
				responseEvent.setUserID(requestEvent.getUserID());

				LOGGER.info("Response Event for CHE Update block container details-->"
						+ responseEvent);
				exchange.getOut().setBody(responseEvent);
				exchange.setProperty(Constants.UPDATE_BLOCK_CONTR_EVENT, "yes");
				exchange.setProperty(Constants.ROUTED, null);
			}
		} catch (Exception e) {
			LOGGER.error(
					"Exception occured while processing CHE Update block container details : ",
					e);
		} finally {
			try {
				if (contrListResultSet != null) {
					contrListResultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				LOGGER.error(
						"SQL Exception occured while processing CHE Update block container details: ",
						e);
			}
		}
	}

	/**
	 * Create List of YardProfileContainer from result set after executing query
	 * 
	 * @param contrListResultSet
	 * @param containerView
	 * @return
	 * @throws SQLException
	 */
	private List<YardProfileContainer> getYardProfileContainer(
			ResultSet contrListResultSet, String containerView)
			throws SQLException {
		List<YardProfileContainer> yardProfileContainers = new ArrayList<YardProfileContainer>();
		YardProfileContainer yardProfileContainer = null;

		while (contrListResultSet.next()) {
			String currLocation = contrListResultSet
					.getString("currentLocation");
			LOGGER.debug("Current Location for CHE Yard Profile View :"
					+ currLocation);
			Container container = new Container();

			String containerId = contrListResultSet.getString("containerId");
			String isoCode = contrListResultSet.getString("isoCode");
			String size = contrListResultSet.getString("containerSize");
			boolean isRefer = "N".equalsIgnoreCase(contrListResultSet
					.getString("reefer")) ? false : true;
			boolean isEmpty = contrListResultSet
					.getString(Constants.CONTAINER_EMPTY) != null
					&& "E".equalsIgnoreCase(contrListResultSet
							.getString(Constants.CONTAINER_EMPTY)) ? true
					: false;
			boolean isDamaged = contrListResultSet.getString("damaged") == null ? false
					: true;

			boolean isOOg = contrListResultSet.getString("oog") == null
					|| "N".equalsIgnoreCase(contrListResultSet.getString("oog")) ? false
					: true;

			/* UN_NO represents IMDG Code for hazardous containers */
			Integer unNo = contrListResultSet.getInt("unNo");
			Integer unNo2 = contrListResultSet.getInt("unNo2");
			Integer unNo3 = contrListResultSet.getInt("unNo3");

			String hazardousCode = getHazardousCode(unNo, unNo2, unNo3);
			boolean isHazardous = null != hazardousCode ? true : false;

			String category = contrListResultSet.getString("category");

			container.setContainerID(containerId);
			container.setIsoCode(isoCode);
			container.setSize(size);
			container.setReefer(isRefer);
			container.setEmpty(isEmpty);
			container.setDamaged(isDamaged);
			container.setOOG(isOOg);
			container.setHazardous(isHazardous);
			container.setCategory(category);
			yardProfileContainer = getContainerDetailsFromBlock(
					contrListResultSet, containerView, container);

			yardProfileContainer.setYardPosition(currLocation);
			yardProfileContainers.add(yardProfileContainer);
		}
		return yardProfileContainers;
	}

	private YardProfileContainer getContainerDetailsFromBlock(
			ResultSet contrListResultSet, String containerView,
			Container container) throws SQLException {
		YardProfileContainer yardProfileContainer = new YardProfileContainer();

		if (containerView != null
				&& containerView.equalsIgnoreCase(Constants.BLOCKVIEW)) {
			String pod = contrListResultSet.getString("pod");
			String weight = contrListResultSet.getString("weight");		

			container.setPod(pod);
			container.setWeight(weight);			
		}
		String moveType = "D".equalsIgnoreCase(contrListResultSet
				.getString("moveType")) ? "DSCH" : "LOAD";
		yardProfileContainer.setMoveType(moveType);
		yardProfileContainer.setContainer(container);

		return yardProfileContainer;
	}

	/**
	 * Creating query for Updated block view container list
	 * 
	 * @param contrList
	 * @return
	 */
	private String getUpdateContrListQuery(List<String> contrList) {
		int contListSize = contrList.size();
		StringBuilder containersList = new StringBuilder();
		containersList.append("(");
		int i = 1;
		String container = null;
		for (String currentContainer : contrList) {
			container = currentContainer.length() > 10 ? currentContainer
					.substring(0, 10) : currentContainer;
			containersList.append("'").append(container).append("'");
			if (i != contListSize) {
				containersList.append(",");
			}
			i++;
		}
		containersList.append(")");
		StringBuilder sqlQuery = new StringBuilder(
				Constants.UPDATE_BLOCK_VIEW_QUERY + containersList.toString());
		return sqlQuery.toString();
	}

	/**
	 * Get Data base connection
	 * 
	 * @throws SQLException
	 */
	@SuppressWarnings("deprecation")
	private Connection getDBConnection(Exchange exchange, String dataSourceName)
			throws SQLException {
		DataSource dataSource = (DataSource) exchange.getContext()
				.getRegistry().lookup(dataSourceName);

		return dataSource.getConnection();
	}

	/**
	 * Get IMDG code for a given container
	 * 
	 * @param unNo
	 * @param unNo2
	 * @param unNo3
	 * @return
	 */
	private String getHazardousCode(Integer unNo, Integer unNo2, Integer unNo3) {
		StringBuilder hazardousCodeBuilder = new StringBuilder();
		List<String> hazardousCodeList = new ArrayList<String>();
		String imdgCodes = null;
		try {

			if (unNo != null && unNo > 0) {
				hazardousCodeList.add(unNo.toString());
			}

			if (unNo2 != null && unNo2 > 0) {
				hazardousCodeList.add(unNo2.toString());
			}
			if (unNo3 != null && unNo3 > 0) {
				hazardousCodeList.add(unNo3.toString());
			}

			for (String imoCode : hazardousCodeList) {
				hazardousCodeBuilder.append(imoCode).append(
						Constants.COMMA_DELIMITER);
			}

			if (hazardousCodeBuilder.length() > 0) {
				imdgCodes = hazardousCodeBuilder.substring(0,
						hazardousCodeBuilder.length() - 1);
			}

		} catch (Exception e) {
			LOGGER.error("Exception while retriveing IMDG code: ", e);
		}
		return imdgCodes;
	}
}
