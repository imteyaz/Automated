package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Container;

/**
 * ValueObject holding the container details related to Yard
 * 
 * @author Rosemary George
 *
 */
public class YardProfileContainer implements Serializable {
    private static final long serialVersionUID = 6390969748078395712L;

    private Container container;

    /**
     * Indicates the actual position of the container in yard as per the
     * planning
     */
    private String yardPosition;

    /**
     * Indicates whether it is LOAD/DSCH/DLVR/RECV/YARD operation.
     */
    private String moveType;
    
    /**
     * Indicates the actual position of the container in yard as per the
     * planning
     */
    private String oldPosition;

    public String getYardPosition() {
        return yardPosition;
    }

    public void setYardPosition(String yardPosition) {
        this.yardPosition = yardPosition;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

	public String getOldPosition() {
		return oldPosition;
	}

	public void setOldPosition(String oldPosition) {
		this.oldPosition = oldPosition;
	}

	@Override
	public String toString() {
		return "YardProfileContainer [container=" + container
				+ ", yardPosition=" + yardPosition + ", moveType=" + moveType
				+ ", oldPosition=" + oldPosition + "]";
	}    
}
