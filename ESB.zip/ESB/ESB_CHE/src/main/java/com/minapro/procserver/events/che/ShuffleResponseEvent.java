package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ShuffleResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 2174360844124554480L;

    /**
     * the container operator needs to pick
     */
    private String requestedContainer;
    /**
     * the container which needs to be shuffled
     */

    private String shuffledContainer;
    /**
     * current position of the shuffled container
     */

    private String currentPosition;
    /**
     * new position of the shuffled container
     */

    private String newPosition;

    public String getRequestedContainer() {
        return requestedContainer;
    }

    public void setRequestedContainer(String requestedContainer) {
        this.requestedContainer = requestedContainer;
    }

    public String getShuffledContainer() {
        return shuffledContainer;
    }

    public void setShuffledContainer(String shuffledContainer) {
        this.shuffledContainer = shuffledContainer;
    }

    public String getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(String currentPosition) {
        this.currentPosition = currentPosition;
    }

    public String getNewPosition() {
        return newPosition;
    }

    public void setNewPosition(String newPosition) {
        this.newPosition = newPosition;
    }

    @Override
    public String toString() {
        return "ShuffleResponseEvent [requestedContainer=" + requestedContainer
                + ", shuffledContainer=" + shuffledContainer
                + ", CurrentPosition=" + currentPosition + ", newPosition="
                + newPosition + "]";
    }

}
