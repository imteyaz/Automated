package com.minapro.esb.common;

public class RostimaStrings {

    private static String url;
    private static String userIdParameter;
    private static String startDateParameter;
    private static String endDateParameter;

    private RostimaStrings(){
        
    }
    
    public static String getUrl() {
        return url;
    }

    public static void setUrl(String url) {
        RostimaStrings.url = url;
    }

    public static String getUserIdParameter() {
        return userIdParameter;
    }

    public static void setUserIdParameter(String userIdParameter) {
        RostimaStrings.userIdParameter = userIdParameter;
    }

    public static String getStartDateParameter() {
        return startDateParameter;
    }

    public static void setStartDateParameter(String startDateParameter) {
        RostimaStrings.startDateParameter = startDateParameter;
    }

    public static String getEndDateParameter() {
        return endDateParameter;
    }

    public static void setEndDateParameter(String endDateParameter) {
        RostimaStrings.endDateParameter = endDateParameter;
    }

}
