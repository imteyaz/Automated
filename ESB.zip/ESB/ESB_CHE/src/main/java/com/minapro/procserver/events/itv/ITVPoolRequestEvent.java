package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * <p>ValueObject to ask for the assigned ITVS for a QC.</p>
 * 
 * <p>The equipment ID should be of QC. </p>
 * @author Rosemary George
 *
 */
public class ITVPoolRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -6243335259833184103L;

    @Override
    public String toString() {
        return "ITVPoolRequestEvent [UserID=" + getUserID()
                + ", EquipmentID=" + getEquipmentID()
                + ", TerminalID=" + getTerminalID() + "]";
    }   
}
