package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class NewLocationRequestEvent extends Event implements Serializable {
    
    /**
     * 
     */
    private static final long serialVersionUID = -3752416667469284618L;
    
    private String containerID;

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    @Override
    public String toString() {
        return "NewLocationRequestEvent [containerID=" + containerID + "]";
    }
}
