package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * 
 * @author 3131663
 *
 */
public class StackViewRequestEvent extends Event implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6033556515049099510L;

    private String stackNumber;

    private String blockNumber;

    public String getStackNumber() {
        return stackNumber;
    }

    public String getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    public void setStackNumber(String stackNumber) {
        this.stackNumber = stackNumber;
    }

    @Override
    public String toString() {
        return "StackViewRequestEvent [stackNumber=" + stackNumber
                + ", blockNumber=" + blockNumber + ", UserID=" + getUserID()
                + ", TerminalID=" + getTerminalID() + "]";
    }

}
