package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.Map;

import com.minapro.procserver.events.Event;

public class ReeferConnectionRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -5287140834169568269L;
    /**
     * Contains list of reefer container IDs
     */
    private Map<String, ReeferWithStatusEvent> reeferContainerList;

    public Map<String, ReeferWithStatusEvent> getReeferContainerList() {
        return reeferContainerList;
    }

    public void setReeferContainerList(Map<String, ReeferWithStatusEvent> reeferContainerList) {
        this.reeferContainerList = reeferContainerList;
    }

    @Override
    public String toString() {
        return "ReeferConnectionRequestEvent [reeferContainerList=" + reeferContainerList
                + ", getReeferContainerList()=" + getReeferContainerList() + "]";
    }

}