package com.minapro.procserver.events;

import java.io.Serializable;

import org.apache.log4j.Logger;

/**
 * ValueObject which handles the update container attribute request from the operator
 * 
 * @author Rosemary George
 * 
 */
public class UpdateContainerEvent extends Event implements Serializable {

    private static final Logger LOGGER = Logger.getLogger(UpdateContainerEvent.class);

    private static final long serialVersionUID = 8856912527778244116L;

    /**
     * Unique Container ID
     */
    private String containerID;    

    /**
     * Line code of container - ex: 'MSK'
     */
    private String lineCode;

    /**
     * Size of the container - 20 feet or 40 feet
     */
    private String size;
    /**
     * Weight of the container
     */
    private String weight;

    

    /**
     * ISO code of the container
     */
    private String isoCode;
    /**
     * Property Holds the All OOG Dimensions.
     * Format should be like , Over Slot Gauge(F/B/L/R/T) = 11/12/13/14/15
     */
    private String oogDimensions;  
    /**
     * OUT Vessel Code
     */
    private String outVessel;
    /**
     * OUT Vessel Voyage.
     */
    private String outVoyage;

    /**
     * Indicates whether the container is of type Import, Export or Tran-shipment.
     */
    private String category;

    /**
     * Indicates whether the container is empty or full
     */
    private boolean isEmpty;

    /**
     * Port of destination for this container
     */
    private String pod;

    /**
     * status of Plug. ex: PIW : Wait for Plug-In, PIM : Monitoring of Plug-In
     */
    private String plugCode;

    /**
     * Vessel details of the container
     */
    private String vessel;

    /**
     * Voyage details of the container
     */
    private String voyage;

    /**
     * Next Port of destination for this container
     */
    private String npod;

    /**
     * Front Port of destination for this container
     */
    private String fpod; 

    /**
     * Seal1 details of container
     */
    private String seal1;

    /**
     * Seal2 details of container
     */
    private String seal2;

    /**
     * Seal3 details of container
     */
    private String seal3;

    /**
     * Seal14 details of container
     */
    private String seal4;

    /**
     * Seal5 details of container
     */
    private String seal5;


    public String getOogDimensions() {
        return oogDimensions;
    }

    public void setOogDimensions(String oogDimensions) {
        this.oogDimensions = oogDimensions;
    }

    public String getOutVessel() {
        return outVessel;
    }

    public void setOutVessel(String outVessel) {
        this.outVessel = outVessel;
    }

    public String getOutVoyage() {
        return outVoyage;
    }

    public void setOutVoyage(String outVoyage) {
        this.outVoyage = outVoyage;
    }
    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        try{
            this.isoCode = isoCode.split("-")[0];
        }catch(Exception ex){
            this.isoCode = isoCode;
            LOGGER.error("Exception while splitting ISO code: ",ex);
        }
    }    

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(String isEmpty) {
        this.isEmpty = (null != isEmpty && "T".equalsIgnoreCase(isEmpty) ? true : false);
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getPlugCode() {
        return plugCode;
    }

    public void setPlugCode(String plugCode) {
        this.plugCode = plugCode;
    }

    public String getVessel() {
        return vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }

    public String getVoyage() {
        return voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getNpod() {
        return npod;
    }

    public void setNpod(String npod) {
        this.npod = npod;
    }

    public String getFpod() {
        return fpod;
    }

    public void setFpod(String fpod) {
        this.fpod = fpod;
    }



    public String getSeal1() {
        return seal1;
    }

    public void setSeal1(String seal1) {
        this.seal1 = seal1;
    }

    public String getSeal2() {
        return seal2;
    }

    public void setSeal2(String seal2) {
        this.seal2 = seal2;
    }

    public String getSeal3() {
        return seal3;
    }

    public void setSeal3(String seal3) {
        this.seal3 = seal3;
    }

    public String getSeal4() {
        return seal4;
    }

    public void setSeal4(String seal4) {
        this.seal4 = seal4;
    }

    public String getSeal5() {
        return seal5;
    }

    public void setSeal5(String seal5) {
        this.seal5 = seal5;
    }

    @Override
    public String toString() {
        return "UpdateContainerEvent [containerID=" + containerID
                + ", lineCode=" + lineCode + ", size=" + size + ", weight="
                + weight + ", isoCode=" + isoCode + ", oogDimensions="
                + oogDimensions + ", outVessel=" + outVessel + ", outVoyage="
                + outVoyage + ", category=" + category + ", isEmpty=" + isEmpty
                + ", pod=" + pod + ", plugCode=" + plugCode + ", vessel="
                + vessel + ", voyage=" + voyage + ", npod=" + npod + ", fpod="
                + fpod + ", seal1=" + seal1 + ", seal2=" + seal2 + ", seal3="
                + seal3 + ", seal4=" + seal4 + ", seal5=" + seal5
                + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }


}
