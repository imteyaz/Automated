package com.minapro.esb.processor.che;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.che.ReeferConnectionRequestEvent;
import com.minapro.procserver.events.che.ReeferConnectionResponseEvent;
import com.minapro.procserver.events.che.ReeferWithStatusEvent;

public class CHEReeferContainerProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(CHEReeferContainerProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.info("*************** In CHEReeferContainerProcessor *************");

        Connection conn = null;
        Statement normalstatement = null;
        ReeferConnectionRequestEvent requestEvent = (ReeferConnectionRequestEvent) exchange
                .getProperty("CHEreeferConnectionEvent");

        String eventId = requestEvent.getEventID();
        LOGGER.info("CHEreeferConnectionEvent received for " + eventId
                + "and requestEvent received is " + requestEvent);

        try {
            if (requestEvent != null) {

                ReeferConnectionResponseEvent responseEvent = new ReeferConnectionResponseEvent();
                List<ReeferWithStatusEvent> reeferContainersList = new ArrayList<ReeferWithStatusEvent>();
                ReeferWithStatusEvent currentReeferWithStatusEvent = new ReeferWithStatusEvent();

                Map<String, ReeferWithStatusEvent> reeferContainerList = requestEvent
                        .getReeferContainerList();

                String containersList = getCommaSeperatedContainerList(reeferContainerList);

                DataSource dataSource = (DataSource) exchange.getContext()
                        .getRegistry().lookup("PromisDataSource");

                conn = dataSource.getConnection();
                LOGGER.debug("Conection established to Promis database ");

                /**
                 * PreparedStatement statement = null; statement =
                 * conn.prepareStatement(Constants.REEFER_STATUS_QUERY);
                 * statement.setString(1, containersList.toString()); String
                 * stmtText = statement.toString();
                 * LOGGER.info("Statement prepared for reefer event: " +
                 * eventId+" -->"+stmtText);
                 */

                normalstatement = conn.createStatement();
                StringBuilder sqlQuery = new StringBuilder(
                        Constants.REEFER_STATUS_QUERY_START + containersList
                                + Constants.REEFER_STATUS_QUERY_END);
                ResultSet reeferSet = normalstatement.executeQuery(sqlQuery
                        .toString());

                LOGGER.info("Reefer containersList from request  "
                        + containersList.toString());

                LOGGER.info("Executed reefer status query successfully for "
                        + eventId);
                int reeferResultSetSize = 0;
                while (reeferSet.next()) {
                    reeferResultSetSize++;
                    String containerId = reeferSet.getString("CONTR_NO");
                    String readType = reeferSet.getString("READ_TYPE");
                    Boolean isConnected = ("D").equalsIgnoreCase(readType) ? false
                            : true;

                    LOGGER.info("Container id " + containerId + " -->"
                            + isConnected + "READ_TYPE-->" + readType);

                    String moveType = reeferContainerList.get(containerId)
                            .getMoveType();

                    currentReeferWithStatusEvent.setContainerId(containerId);
                    currentReeferWithStatusEvent.setConnected(isConnected);
                    currentReeferWithStatusEvent.setMoveType(moveType);
                    reeferContainersList.add(currentReeferWithStatusEvent);
                }

                LOGGER.info("Iterated reefer resultset successfully for :"
                        + eventId + " and resultSet Size is"
                        + reeferResultSetSize);
                responseEvent.setReeferContainersList(reeferContainersList);
                responseEvent.setEquipmentID(requestEvent.getEquipmentID());
                responseEvent.setEventID(requestEvent.getEventID());
                responseEvent.setTerminalID(requestEvent.getTerminalID());
                responseEvent.setUserID(requestEvent.getUserID());

                LOGGER.info("ReeferConnectionResponseEvent is " + responseEvent);
                exchange.getOut().setBody(responseEvent);
                exchange.setProperty("reeferConnectionEvent", "yes");
                exchange.setProperty("routed", null);
                if (reeferSet != null) {
                    reeferSet.close();
                }
            }

        } catch (Exception e) {
            LOGGER.error(
                    requestEvent.getEventID()
                            + " request occured Exception while processing ReeferConnectionRequestEvent: ",
                    e);
        } finally {

            if (normalstatement != null) {
                normalstatement.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    private String getCommaSeperatedContainerList(
            Map<String, ReeferWithStatusEvent> reeferContainerList) {
        int contListSize = reeferContainerList.size();
        StringBuilder containersList = new StringBuilder();
        containersList.append("(");
        int i = 1;

        for (Map.Entry<String, ReeferWithStatusEvent> currentContainer : reeferContainerList
                .entrySet()) {
            String contrId = currentContainer.getValue().getContainerId();
            containersList.append("'").append(contrId).append("'");
            if (i != contListSize) {
                containersList.append(",");
            }
            i++;
        }
        containersList.append(")");

        return containersList.toString();
    }
}
