package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;
/**
 * 
 * @author 344493
 *
 */
public class ShuffleRequestEvent extends Event implements Serializable {

	private static final long serialVersionUID = 5465914561298282957L;
	
	private String containerId;
	
	private String fromLocation;
	
	private String toLocation;
	
	private String moveType;
	
    private boolean isJobListRefreshRequired;

	public String getMoveType() {
		return moveType;
	}

	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}

	

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public boolean isJobListRefreshRequired() {
		return isJobListRefreshRequired;
	}

	public void setJobListRefreshRequired(boolean isJobListRefreshRequired) {
		this.isJobListRefreshRequired = isJobListRefreshRequired;
	}

	

	public String getContainerId() {
		return containerId;
	}

	public void setContainerId(String containerId) {
		this.containerId = containerId;
	}

	@Override
	public String toString() {
		return "ShuffleRequestEvent [containerId=" + containerId
				+ ", location=" + fromLocation + ", moveType=" + moveType
				+ ", isJobListRefreshRequired=" + isJobListRefreshRequired
				+ "]";
	}

    
}
