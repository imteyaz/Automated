package com.minapro.esb.common;

public class Constants {

	public static final String CHE_OPERATOR = "CHE";
	public static final String SUCCESS = "Success";
	public static final String ROUTED = "routed";

	public static final String LOGIN_EVENT = "loginEvent";
	public static final String LOGOUT_EVENT = "logoutEvent";

	public static final String JOBLIST_EVENT = "jobList";
	public static final String ITVPOOLREQEVENT = "ITVPoolRequestEvent";
	public static final String CONTAINER_EMPTY = "containerEmpty";
	public static final String UPDATE_BLOCK_CONTR_EVENT = "updateBlockContainersEvent";
	public static final String NEW_CONTR_LOCATION = "newContrLocation";
	public static final String SHUFFLE_CONTR_LOCATION = "ShuffleContrLocationEvent";
	public static final String BLOCKVIEW = "BLOCKVIEW";
	public static final String OPERATOR_AVAIL_EVENT = "AvailabilityEvent";
	public static final String JOB_SELECT_EVENT = "JobSelectEvent";
	public static final String CANCEL_JOB_SELECT_EVENT = "CancelJobSelectEvent";
	public static final String UPDATE_CONTR_EVENT = "UpdateContainerEvent";
	public static final String CONTAINER_MOVE_EVENT = "containerMoveEvent";
	public static final String CONFIRM_ALLOCATION_EVENT = "confirmAllocationEvent";
	public static final String REEFER_CONNECTION_EVENT = "reeferConnectionEvent";
	public static final String INVENTORY_UPDATE_EVENT = "InventoryUpdateEvent";

	public static final String YARD_VIEW_EVENT = "yardView";

	public static final String COMMA_DELIMITER = ",";

	/*
	 * Data Sources
	 */
	public static final String PRMIS_DB = "PromisDataSource";
	public static final String TOSADM_DB = "TOSADMDataSource";

	public static final String YARD_QUERY = "select "
			+ "containers.contr_no || containers.chk_digit as containerId,"
			+ "containers.new_iso_code as isoCode, containers.contr_len as containerSize,"
			+ "containers.reef_appl_code as reefer, containers.contr_cat_status as containerEmpty,"
			+ "containers.dmg_descr as damaged, containers.curr_locn as currentLocation,  "
			+ "dpa_lists.og as oog, " + "dpa_lists.un_no as unNo,  "
			+ "dpa_lists.un_no2 as unNo2,  " + "dpa_lists.un_no3 as unNo3,  "
			+ "dpa_lists.list_code as moveType,"
			+ "dpa_lists.contr_cat as category  "
			+ "from dpa_lists inner join containers "
			+ "on dpa_lists.contr_no = containers.contr_no " + "WHERE "
			+ "containers.curr_locn like ? " + "and containers.act_code = 'Y' "
			+ "and containers.contr_position = 'YRD' ";

	public static final String YARD_OPUS_DB_QUERY = "SELECT C.CYY_HIST_CONTNO as containerId, FUN_MAPP_PROMIS_LOC"
			+ " (C.CRNT_PSN_IDX_NO1, C.CRNT_PSN_IDX_NO2, C.CRNT_PSN_IDX_NO3, C.CRNT_PSN_IDX_NO4, C.CYY_HIST_ISO, 4) "
			+ " as PROMIS_YARD_LOCATION, C.CYY_HIST_CLOCATION,  "
			+ " FUN_MAPP_PROMIS_LOC(c.OLD_PSN_IDX_NO1, c.OLD_PSN_IDX_NO2, "
			+ " c.OLD_PSN_IDX_NO3,c.OLD_PSN_IDX_NO4, C.CYY_HIST_ISO, 4) "
			+ " as PROMIS_OLD_YARD_LOCATION FROM   TOSADM.CYY_HISTORY C  WHERE  "
			+ " FUN_MAPP_PROMIS_LOC(C.CRNT_PSN_IDX_NO1, C.CRNT_PSN_IDX_NO2, "
			+ " C.CRNT_PSN_IDX_NO3, C.CRNT_PSN_IDX_NO4, C.CYY_HIST_ISO, 4) LIKE ? "
			+ " AND  C.CYY_HIST_DATE = TO_CHAR(SYSDATE, 'YYYYMMDD') "
			+ " and to_timestamp(CYY_HIST_TIME, 'hh24missff3') > to_timestamp(to_char(sysdate, 'hh24miss'), 'hh24missff3') - ? "
			+ " order by c.CYY_HIST_TIME asc";

	public static final String REEFER_STATUS_QUERY_START = "select * from REEFER_READINGS rr "
			+ " where rr.read_type <> 'N'" + " and rr.contr_no in  ";// ('MAEU578367','APLU694161','APLU694871','APRU501400','APRU503562')

	public static final String REEFER_STATUS_QUERY_END = " and rr.read_date = (select max(r.read_date)  from reefer_readings r"
			+ " where r.contr_no = rr.contr_no" + " and r.read_type <> 'N') ";

	public static final String GET_ROB_CONTIANERS_LIST_QUERY = "select * from rob_lists where ROTN=? "
			+ "and substr(rob_lists.stowg, 1, 2)=? and substr(rob_lists.stowg, 5, 2)";

	public static final String UPDATE_BLOCK_VIEW_QUERY = "select dpa_lists.contr_no || containers.chk_digit as containerId,"
			+ "dpa_lists.disch_port as pod,"
			+ "containers.new_iso_code as isoCode,"
			+ "containers.contr_len as containerSize,"
			+ "dpa_lists.wt as weight,"
			+ "dpa_lists.list_code as moveType,"
			+ "containers.reef_appl_code as reefer,"
			+ "containers.contr_cat_status as containerEmpty,"
			+ "dpa_lists.og as oog,"
			+ "dpa_lists.un_no as unNo, "
			+ "dpa_lists.un_no2 as unNo2, "
			+ "dpa_lists.un_no3 as unNo3, "
			+ "containers.dmg_descr as damaged,"
			+ "containers.curr_locn as currentLocation,"
			+ "dpa_lists.contr_cat as category "
			+ "from dpa_lists "
			+ "inner join containers "
			+ "on dpa_lists.contr_no = containers.contr_no WHERE "
			+ "containers.act_code = 'Y' "
			+ "and (decode(dpa_lists.list_code,'L',dpa_lists.rotn) = containers.last_load_rotn "
			+ "OR  decode(dpa_lists.list_code,'D',dpa_lists.rotn) = containers.last_disch_rotn) "
			+ "and containers.contr_no in  ";

	private Constants() {
	}

}
