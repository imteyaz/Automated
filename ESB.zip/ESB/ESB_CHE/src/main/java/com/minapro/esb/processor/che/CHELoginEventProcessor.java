package com.minapro.esb.processor.che;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.CertificateValidateEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LoginResponseEvent;
import com.minapro.xmlrdt.entities.ArrayOfEmployeeRoster;
import com.minapro.xmlrdt.entities.EmployeeRoster;

/**
 * @author Shashank
 * 
 *         This processor CHELoginEventProcessor , is processed , when the LoginEvent is read by the QueueListener which
 *         is listening the CHE queue
 * 
 */
public class CHELoginEventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(CHELoginEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Inside the CHELoginEventProcessor...");
        
        org.apache.log4j.MDC.put("app.name", "CHELoginEventProcessor");

        Map<String, Object> map = exchange.getProperties();

        LoginEvent loginEvent = (LoginEvent) map.get("CHEloginEvent");

        ArrayOfEmployeeRoster employeeRoster = null;

        if (loginEvent != null) {
            LOGGER.info("CHE Login successfully... ");
            byte[] body = (byte[]) exchange.getIn().getBody();
            String fromRostima = new String(body);
            fromRostima = fromRostima.substring(1);
            LOGGER.info("Data received from the ROSTIMA after webService call --> \n"+fromRostima);
            
            try {
                JAXBContext context = JAXBContext.newInstance(ArrayOfEmployeeRoster.class);
                Unmarshaller unmarshaller = context.createUnmarshaller();

                employeeRoster = (ArrayOfEmployeeRoster) unmarshaller.unmarshal(new StringReader(fromRostima));
            } catch (Exception e) {
                LOGGER.debug("CHELogin Exception occured while parsing ROSTIMA response ",e);
                LOGGER.error("CHELogin Exception occured while parsing ROSTIMA response. ");
            }
           
            AllocationEvent allocationEvent = new AllocationEvent();

            if (employeeRoster != null) {
                EmployeeRoster roster = employeeRoster.getRoster();
                if (roster != null) {
                    LOGGER.debug("Data Received from ROSTIMA for User " + employeeRoster.getRoster().getEmployeeNumber());
                    
                    String shiftDate = roster.getShiftDate();
                    String shiftTime = roster.getShiftTime();
                    shiftDate = shiftDate.concat(" " + shiftTime);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                    Date shiftStartDate = dateFormat.parse(shiftDate);
                    allocationEvent.setUserID(roster.getEmployeeNumber());
                    allocationEvent.setTerminalID(roster.getShiftLocation());
                    allocationEvent.setShiftStartTime(shiftStartDate);
                }
            }

            LoginEvent lEvent = (LoginEvent) exchange.getProperty("Login");
            LoginResponseEvent responseEvent = new LoginResponseEvent();

            List<String> rotatn = new ArrayList<String>();
            rotatn.add("128943");
            allocationEvent.setRotationIDs(rotatn);
            responseEvent.setAllocationDetails(allocationEvent);
            responseEvent.setEquipmentID(lEvent.getEquipmentID());
            responseEvent.setEventID(lEvent.getEventID());
            responseEvent.setUserID(lEvent.getUserID());
            responseEvent.setTerminalID(lEvent.getTerminalID());            

            CertificateValidateEvent event = new CertificateValidateEvent();
            event.setReason("Certificates Validated");
            event.setStatus("Success");

            responseEvent.setValidateCertificateDetails(event);

            exchange.setProperty("loginReceived", "yes");
            exchange.setProperty("routed", null);
            exchange.getOut().setBody(responseEvent);
            
            LOGGER.info(lEvent.getUserID()+"  CHEUser loggedin successfully. Response sent : " + responseEvent);
        }
    }
}
