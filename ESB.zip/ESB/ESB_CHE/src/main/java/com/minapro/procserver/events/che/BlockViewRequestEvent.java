package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.Collection;

import com.minapro.procserver.events.Event;

/**
 * Holding Yard View Request Event Message
 * 
 * @author 3131663
 *
 */
public class BlockViewRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = 161174860635883711L;
    
    private String blockNumber;

    private String stackNumber;
    /*
	 * Parameter is used to distinguish the difference between which data source ESB needs to connect.
	 * isPollingTimeReq =true means , second request on words ESB has to connect OPUS database to get the updated containers information. 
	 * False means ,it is a first time request posting to ESB, in this case ESB has to connect PROMIS Database.
	 */
    private boolean isPollingTimeReq;
    
    private double timeLapse;
    
    public double getTimeLapse() {
		return timeLapse;
	}


	public void setTimeLapse(double timeLapse) {
		this.timeLapse = timeLapse;
	}


	private Collection<String> blockIdList;
    

    public Collection<String> getBlockIdList() {
		return blockIdList;
	}


	public void setBlockIdList(Collection<String> blockIdList) {
		this.blockIdList = blockIdList;
	}


	public boolean isPollingTimeReq() {
		return isPollingTimeReq;
	}


	public void setPollingTimeReq(boolean isPollingTimeReq) {
		this.isPollingTimeReq = isPollingTimeReq;
	}

	
	public String getBlockNumber() {
		return blockNumber;
	}


	public void setBlockNumber(String blockNumber) {
		this.blockNumber = blockNumber;
	}


	public String getStackNumber() {
		return stackNumber;
	}


	public void setStackNumber(String stackNumber) {
		this.stackNumber = stackNumber;
	}


	@Override
	public String toString() {
		return "BlockViewRequestEvent [blockNumber=" + blockNumber
				+ ", stackNumber=" + stackNumber + ", isPollingTimeReq="
				+ isPollingTimeReq + ", timeLapse=" + timeLapse
				+ ", blockIdList=" + blockIdList + "]";
	}


	


	

	
}
