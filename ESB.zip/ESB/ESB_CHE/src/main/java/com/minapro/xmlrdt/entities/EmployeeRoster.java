package com.minapro.xmlrdt.entities;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "EmployeeRoster")
public class EmployeeRoster {

    private String TransactionId;
    private String EmployeeNumber;
    private String EmployeeName;
    private String ShiftDate;
    private String ShiftTime;
    private String EmployeeShiftPeriod;
    private String ShiftLocation;
    private String Equipment;
    private String ShiftType;

    @XmlElement(name = "TransactionId")
    public String getTransactionId() {
        return TransactionId;
    }

    public void setTransactionId(String transactionId) {
        TransactionId = transactionId;
    }

    @XmlElement(name = "EmployeeNumber")
    public String getEmployeeNumber() {
        return EmployeeNumber;
    }

    public void setEmployeeNumber(String employeeNumber) {
        EmployeeNumber = employeeNumber;
    }

    @XmlElement(name = "EmployeeName")
    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String employeeName) {
        EmployeeName = employeeName;
    }

    @XmlElement(name = "ShiftDate")
    public String getShiftDate() {
        return ShiftDate;
    }

    public void setShiftDate(String shiftDate) {
        ShiftDate = shiftDate;
    }

    @XmlElement(name = "ShiftTime")
    public String getShiftTime() {
        return ShiftTime;
    }

    public void setShiftTime(String shiftTime) {
        ShiftTime = shiftTime;
    }

    @XmlElement(name = "EmployeeShiftPeriod")
    public String getEmployeeShiftPeriod() {
        return EmployeeShiftPeriod;
    }

    public void setEmployeeShiftPeriod(String employeeShiftPeriod) {
        EmployeeShiftPeriod = employeeShiftPeriod;
    }

    @XmlElement(name = "ShiftLocation")
    public String getShiftLocation() {
        return ShiftLocation;
    }

    public void setShiftLocation(String shiftLocation) {
        ShiftLocation = shiftLocation;
    }

    @XmlElement(name = "Equipment")
    public String getEquipment() {
        return Equipment;
    }

    public void setEquipment(String equipment) {
        Equipment = equipment;
    }

    @XmlElement(name = "ShiftType")
    public String getShiftType() {
        return ShiftType;
    }

    public void setShiftType(String shiftType) {
        ShiftType = shiftType;
    }

    @Override
    public String toString() {
        return "EmployeeRoster [TransactionId=" + TransactionId
                + ", EmployeeNumber=" + EmployeeNumber + ", EmployeeName="
                + EmployeeName + ", ShiftDate=" + ShiftDate + ", ShiftTime="
                + ShiftTime + ", EmployeeShiftPeriod=" + EmployeeShiftPeriod
                + ", ShiftLocation=" + ShiftLocation + ", Equipment="
                + Equipment + ", ShiftType=" + ShiftType + "]";
    }

}
