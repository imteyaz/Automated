package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the certificate validation status
 * @author Rosemary George
 *
 */
public class CertificateValidateEvent extends Event implements Serializable {
    private static final long serialVersionUID = 8696071048250648076L;

    /**
     * Indicates whether the certificate validation is successful.
     * Has two possible values - success/failure
     */
    private String status;
    
    /**
     * if status is failure, fill in the reason if available
     */
    private String reason;
    
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    @Override
    public String toString() {
        return "CertificateValidateEvent [status=" + status + ", reason="
                + reason + ", UserID=" + getUserID()
                + ", EquipmentID=" + getEquipmentID()
                + ", TerminalID=" + getTerminalID() + "]";
    }    
}
