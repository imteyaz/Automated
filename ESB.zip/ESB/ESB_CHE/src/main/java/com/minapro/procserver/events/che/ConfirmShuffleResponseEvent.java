package com.minapro.procserver.events.che;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

public class ConfirmShuffleResponseEvent extends Event implements Serializable{

    private static final long serialVersionUID = -6977709040651229924L;
    
   
    private String shuffleContainerId;
    
    private Boolean status;
    
    private String  failureReason;

    
    
    public String getShuffleContainerId() {
        return shuffleContainerId;
    }

    public void setShuffleContainerId(String shuffleContainerId) {
        this.shuffleContainerId = shuffleContainerId;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public void setFailureReason(String failureReason) {
        this.failureReason = failureReason;
    }

    @Override
    public String toString() {
        return "ConfirmShuffleResponseEvent [shuffleContainerId=" + shuffleContainerId + ", status=" + status
                + ", failureReason=" + failureReason + "]";
    }

    
    
}
