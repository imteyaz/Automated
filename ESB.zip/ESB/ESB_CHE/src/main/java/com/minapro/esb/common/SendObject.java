package com.minapro.esb.common;

import java.io.Serializable;

public class SendObject implements Serializable {

    private static final long serialVersionUID = -3982072394931832266L;
    private String queueName;
    private Object object;
    private String eventType;

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

}
