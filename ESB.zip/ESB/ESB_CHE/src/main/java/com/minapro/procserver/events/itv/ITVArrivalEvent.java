package com.minapro.procserver.events.itv;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the current position of a particular ITV
 * 
 * @author Rosemary George
 *
 */
public class ITVArrivalEvent extends Event implements Serializable {
    private static final long serialVersionUID = -6264609993108163156L;

    /**
     * The location where the ITV has arrived - can be QC, Pinning station or Yard Block
     */
    private String locationID;
    /**
     * The Container ID which the ITV is carrying (if any)
     */
    private List<String> containerIDs;
    
    /**
     * will be filled when ITV arrives at QC location
     */
    private String laneId;
    
    /**
     * will be filled when ITV arrives at yard location
     */
    private String blockId;

    public String getLaneId() {
        return laneId;
    }

    public void setLaneId(String laneId) {
        this.laneId = laneId;
    }

    public String getBlockId() {
        return blockId;
    }

    public void setBlockId(String blockId) {
        this.blockId = blockId;
    }

    public List<String> getContainerIDs() {
        return containerIDs;
    }

    public void setContainerIDs(List<String> containerIDs) {
        this.containerIDs = containerIDs;
    }

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    @Override
    public String toString() {
        return "ITVArrivalEvent [locationID=" + locationID + ", containerIDs=" + containerIDs + ", laneId=" + laneId
                + ", blockId=" + blockId + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
