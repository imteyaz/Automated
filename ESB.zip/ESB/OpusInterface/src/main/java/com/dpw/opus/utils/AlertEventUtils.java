package com.dpw.opus.utils;

import org.apache.camel.Exchange;

import com.dpw.opus.common.Constants;
import com.minapro.esb.common.ExchangeRepo;
import com.minapro.procserver.events.common.ALERTCODE;
import com.minapro.procserver.events.common.MinaProAlertEvent;

public class AlertEventUtils {
    private AlertEventUtils(){
        
    }
    
    public static void raiseAPIAlertEvent(String opusAPIName, String equipId, String userId, String containerId){
        MinaProAlertEvent alertEvent = new MinaProAlertEvent();
        alertEvent.setFailedAPI(opusAPIName);
        alertEvent.setEquipmentID(equipId);
        alertEvent.setUserID(userId);
        alertEvent.setAlertCode(ALERTCODE.TOS_FAILURE_ALERT);
        alertEvent.setContainerId(containerId);
        
        Exchange exchange = ExchangeRepo.getExchange();
        exchange.getOut().setHeader(Constants.QUEUE_NAME, Constants.COMMONQ);
        exchange.getOut().setBody(alertEvent);
        OpusCommonUtils.send(exchange);
    }
}
