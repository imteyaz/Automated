package com.dpw.opus.common;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class HashIn {

    private static Map<String, Object> mapIn = new ConcurrentHashMap<String, Object>();

    private HashIn() {

    }

    public static void putInMap(String key, Object value) {
        mapIn.put(key, value);

    }

    public static Object getFromMap(String key) {
        return mapIn.get(key);

    }

    public static Set<String> getAllKeys() {
        return mapIn.keySet();

    }

    public static void removeMap(String key) {

        mapIn.remove(key);

    }  

}
