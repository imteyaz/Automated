package com.dpw.opus.utils;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.dpw.opus.common.Constants;
import com.minapro.procserver.events.JobListContainerDetails;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;

public class DBOperationsUtil {

    private static final Logger LOGGER = Logger.getLogger(DBOperationsUtil.class);
    
    private DBOperationsUtil(){
        
    }
    
    /**
     * The Data Source of database connection is obtained here
     * @param name
     * @return
     */
    @SuppressWarnings("deprecation")
    private static DataSource getDataSource(Exchange exchange, String name) {
       return (DataSource) exchange.getContext()
                .getRegistry().lookup(name);
    }
    
     /**
     * delete all the records form MP_JOB_LIST where eq_id = ? and rotation
     * number =?
     * 
     * Fill all the fields of job list
     * 
     * ESB_QC_OUTQ
     * 
     * @throws SQLException
     * 
     * 
     */
    public static String insertJobListDetails(Exchange exchange, JobListRequestEvent requestEvent,
            java.util.List<JobListContainerDetails> containers, String machineType) throws SQLException {
        Connection dbConnection = null;
        PreparedStatement jobListDeleteStatement = null;
        PreparedStatement jobListInsertStatement = null;
        
        String status = null;
        String equipID = null;
 
        if("QC".equalsIgnoreCase(machineType)){
              equipID = requestEvent.getEquipmentID();
        } else if("HC".equalsIgnoreCase(machineType)){
            equipID = requestEvent.getQcId();
        }
         
        try {
            
            dbConnection = getDataSource(exchange, Constants.PRTOS_MP_DB).getConnection();          
            dbConnection.setAutoCommit(false);
            jobListDeleteStatement = dbConnection
                    .prepareStatement(Constants.DELETE_QC_JOB_LIST);

            
            jobListDeleteStatement.setString(1, equipID);
            
            int deletedJobsCount = jobListDeleteStatement.executeUpdate();
            dbConnection.commit();
            
            LOGGER.info("deletedJobsCount -->" + deletedJobsCount
                    + " deleted in MP_OPUS_QC_JOB_LIST, event:" + requestEvent.getEventID() + " & QC equipID :"
                    + equipID + "  and rotation :"
                    + requestEvent.getRotationId());
                jobListInsertStatement = dbConnection
                        .prepareStatement(Constants.INSERT_QC_JOB_LIST);
                
            for (JobListContainerDetails container : containers) { 
                
                jobListInsertStatement.setString(1, requestEvent.getTerminalID());
                jobListInsertStatement.setString(2, requestEvent.getRotationId());
                jobListInsertStatement.setString(3, equipID);
                jobListInsertStatement.setString(4, container.getMoveType());
                jobListInsertStatement.setString(5, container.getContainerId());
                jobListInsertStatement.setString(6, container.getFromLocation());
                jobListInsertStatement.setString(7, container.getToLocation());
                jobListInsertStatement.setString(8, null);
                jobListInsertStatement.setInt(9, Integer.valueOf(container.getPlnSeq()));
                jobListInsertStatement.setString(10, requestEvent.getUserID());
                jobListInsertStatement.setDate(11,  DateUtils.getCurrentDate());
                jobListInsertStatement.setString(12, container.getTwinTandemID());
                jobListInsertStatement.setString(13, container.getTwinTandemCd());
                jobListInsertStatement.setString(14, container.getIso());
                jobListInsertStatement.setString(15, container.getPod());
                jobListInsertStatement.setString(16, container.getWt());
                jobListInsertStatement.setString(17, container.getContrCategory());
                jobListInsertStatement.setString(18, container.getContrStatus());
                jobListInsertStatement.setString(19, container.getVessel());                
                jobListInsertStatement.setString(20, container.getVoyage());
                jobListInsertStatement.setString(21, container.getJobKey());
                jobListInsertStatement.setString(22, container.getPositionOnChassis());
                jobListInsertStatement.setString(23, container.getJobQueueName());
                
                int jobSeqNo =  StringUtils.isNotBlank(container.getJobQueueSequence()) ? Integer.valueOf(container.getJobQueueSequence()) :0;
                jobListInsertStatement.setInt(24, jobSeqNo);
        
                jobListInsertStatement.addBatch();
            }
          
            int[] insertedJobsCount = jobListInsertStatement.executeBatch();
            dbConnection.commit();
            status = null!=insertedJobsCount && insertedJobsCount.length > 0 ? Constants.SUCCESS : null;

            LOGGER.info(insertedJobsCount.length+" jobs inserted Successfully in MP_OPUS_QC_JOB_LIST for event :"
                    + requestEvent.getEventID() + " for QC request :"
                    + equipID + " for rotation :"
                    + requestEvent.getRotationId());

        } catch (Exception e) {

            LOGGER.error(" Exception occured when trying to insert joblist batch in MP_OPUS_QC_JOB_LIST for event :"
                    + requestEvent.getEventID()
                    + " for QC EquipmentID :"
                    + equipID
                    + " & rotationID :"
                    + requestEvent.getRotationId() + " -->", e);
            dbConnection.rollback();
            status  = Constants.FAILURE;
        } finally {
            if(dbConnection !=null && !dbConnection.isClosed()){                  
                dbConnection.close();
            }

            if (jobListInsertStatement != null) {
                jobListInsertStatement.close();
            }

            if (jobListDeleteStatement != null ) {
                jobListDeleteStatement.close();
            }
        }
        return status;
    } 
    
    /**
     * CHE Insert job list details into MP_CHE_JOB_LISTS
     * @param requestEvent
     * @param containers
     * @param equipID
     * @param rotnId
     * @throws SQLException
     */
    public static String insertCHEJobListDetails(Exchange exchange, CHEJobListRequestEvent requestEvent,
            java.util.List<JobListContainerDetails> containers) throws SQLException {
        PreparedStatement jobListDeleteStatement = null;
        PreparedStatement jobListInsertStatement = null;
        Connection dbConnection = null;
        String status = null;
        String equipID = requestEvent.getEquipmentID();
        
        try {           
            dbConnection = getDataSource(exchange, Constants.PRTOS_MP_DB).getConnection();
            dbConnection.setAutoCommit(false);
            jobListDeleteStatement = dbConnection
                    .prepareStatement(Constants.DELETE_CHE_JOB_LIST);

            jobListDeleteStatement.setString(1, equipID);

            int deletedJobsCount = jobListDeleteStatement.executeUpdate();
            dbConnection.commit();
            
            LOGGER.info(deletedJobsCount
                    + " Jobs Deleted for CHE Job list for CHE equipID: "
                    + equipID+ " & eventID:" + requestEvent.getEventID() );

            jobListInsertStatement = dbConnection
                    .prepareStatement(Constants.INSERT_CHE_JOB_LIST);

            for (JobListContainerDetails container : containers) { 
                
                jobListInsertStatement.setString(1, container.getMoveType());
                jobListInsertStatement.setString(2, container.getContainerId());                
                jobListInsertStatement.setString(3, container.getFromLocation());
                jobListInsertStatement.setString(4, container.getToLocation());
                jobListInsertStatement.setString(5, equipID);
                jobListInsertStatement.setString(6, requestEvent.getTerminalID());  
                jobListInsertStatement.setString(7, null);                  
                jobListInsertStatement.setString(8, requestEvent.getUserID());
                jobListInsertStatement.setDate(9,  DateUtils.getCurrentDate());                
                jobListInsertStatement.setString(10, container.getTwinContainerId());
                jobListInsertStatement.setString(11, container.getTwinTandemCd());
                jobListInsertStatement.setString(12, container.getIso());
                jobListInsertStatement.setString(13, container.getPod());
                jobListInsertStatement.setString(14, container.getWt());
                jobListInsertStatement.setString(15, container.getContrCategory());
                jobListInsertStatement.setString(16, container.getContrStatus());
                jobListInsertStatement.setString(17, container.getVessel());                
                jobListInsertStatement.setString(18, container.getVoyage());
                jobListInsertStatement.setString(19, container.getJobKey());
                jobListInsertStatement.setString(20, container.getPositionOnChassis());
                jobListInsertStatement.setString(21, container.getPlnSeq());
                jobListInsertStatement.setString(22, container.getJobStatus());
                jobListInsertStatement.setString(23, container.getPriorityJob());
                jobListInsertStatement.setString(24, container.getEtw());

                jobListInsertStatement.addBatch();
            }
           
            int[] insertedJobsCount = jobListInsertStatement.executeBatch();
            dbConnection.commit();
            status = insertedJobsCount.length > 0 ? Constants.SUCCESS : null;
            LOGGER.info(insertedJobsCount.length+" job records inserted Successfully in MP_CHE_JOB_LIST for event :"
                    + requestEvent.getEventID() + " for CHE request :"
                    + equipID );

        } catch (BatchUpdateException e) {

            LOGGER.error("Exception occured while trying to insert joblist batch in MP_CHE_JOB_LIST for event :"
                    + requestEvent.getEventID()
                    + " for CHE :"
                    + equipID+" -->" , e);
            dbConnection.rollback();
            status = Constants.FAILURE;
        } finally {
            if(dbConnection !=null && !dbConnection.isClosed()){              
                dbConnection.close();
            }

            if (jobListInsertStatement != null) {
                jobListInsertStatement.close();
            }

            if (jobListDeleteStatement != null) {
                jobListDeleteStatement.close();
            }
        }
        return status;
    }    
   
}
