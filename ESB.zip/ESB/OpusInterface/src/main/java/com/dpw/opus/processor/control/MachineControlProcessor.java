package com.dpw.opus.processor.control;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.model.AtomItv;
import com.clt.tos.external.atom.jat2.model.AtomMachine;
import com.clt.tos.external.atom.jat2.model.AtomMachineNotice;
import com.clt.tos.external.atom.jat2.model.AtomMachineStop;
import com.clt.tos.external.proxy.service.MachineControlService;
import com.clt.tos.external.proxy.service.impl.MachineControlServiceImpl;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.OpusConnection;
import com.dpw.opus.utils.AlertEventUtils;
import com.dpw.opus.utils.OpusCommonUtils;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityResponseEvent;
import com.minapro.procserver.events.common.OperatorMessage;
import com.minapro.procserver.events.common.OperatorMessageRequestEvent;
import com.minapro.procserver.events.common.OperatorMessageResponseEvent;
import com.minapro.procserver.events.hc.ITVSwapRequestEvent;
import com.minapro.procserver.events.hc.ITVSwapResponseEvent;
import com.minapro.procserver.events.hc.SwapContainerPosition;
import com.minapro.procserver.events.itv.ITV;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.ITVPoolEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;

public class MachineControlProcessor {
	private static final Logger LOGGER = Logger
			.getLogger(MachineControlProcessor.class);

	private static MachineControlService machineControlService;
	private static String opusWrite;
	private static boolean opusWriteStatus;

	public MachineControlProcessor() {
		machineControlService = new MachineControlServiceImpl();
		opusWrite = OpusConnection.getWriteToOpus();
		opusWriteStatus = StringUtils.isNotBlank(opusWrite) ? Boolean
				.valueOf(opusWrite) : false;
		LOGGER.info("************* Opus Write back status, writeToOpus: "
				+ opusWriteStatus);
	}

	/**
	 * Get PoolName assigned to Machines by calling OPUS getMachineListByType()
	 * API.
	 * 
	 * @param machineId
	 * @param machineType
	 */
	public List<AtomMachine> processGetMachineListByType(String machineId,
			String machineType) {
		List<AtomMachine> machineList = null;
		try {
			machineList = machineControlService.getMachineListByType(machineId,
					machineType);
		} catch (Exception e) {
			AlertEventUtils.raiseAPIAlertEvent("getMachineListByType()",
					machineId, null, null);
			LOGGER.error("Exception while processing getMachineListByType(), ",
					e);
		}

		return machineList;
	}

	/**
	 * To get ITV pool List processGetMachineListOfPool() passing poolname or
	 * ITV no. OPUS getMachineListByType() API
	 * 
	 * @param exchange
	 * @throws Exception
	 */
	public void processGetMachineListOfPool(Exchange exchange) {

		List<AtomItv> opusItvList = new ArrayList<AtomItv>();
		List<AtomMachine> machineList = null;

		String machineId = null;
		String poolName = null;
		Set<ITV> itvList = new HashSet<ITV>();
		ITVPoolRequestEvent requestEvent = (ITVPoolRequestEvent) exchange
				.getProperty(Constants.ITVPOOL_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);

		LOGGER.info(operator + " ITVPoolRequestEvent received: " + requestEvent);
		try {
			machineId = requestEvent.getEquipmentID();
			String machineType = OpusCommonUtils.getMachineType(operator);

			LOGGER.info("Requesting getMachineListByType() OPUS API, machineId: "
					+ machineId + ", machineType: " + machineType);

			machineList = machineControlService.getMachineListByType(machineId,
					Constants.EMPTY_STRING);

			if (null != machineList) {
				AtomMachine atomMachine = machineList.get(0);
				LOGGER.info("Response recieved from getMachineListByType() OPUS API, machineId: "
						+ machineId
						+ ", POOLName:--->"
						+ atomMachine.getPoolNm());
				poolName = atomMachine.getPoolNm();

				opusItvList = machineControlService.getMachineListOfPool(
						poolName, Constants.EMPTY_STRING);
			}

			LOGGER.info("ITV Pool names for equipment: " + machineList
					+ " ,response received: " + machineList);
			LOGGER.info("ITV Pool itvs assigned response received: "
					+ opusItvList);

			if (opusItvList != null) {
				for (AtomItv atomItv : opusItvList) {
					ITV itv = new ITV();

					itv.setItvId(atomItv.getMchnId());
					itvList.add(itv);
				}
			} else {
				LOGGER.info("No Pool names found for given MachineID: "
						+ machineId + "  ,MachineType: " + machineType);
			}

		} catch (Exception e) {
			LOGGER.error("Exception while processing getMachineListOfPool(), ",
					e);
			AlertEventUtils.raiseAPIAlertEvent("getMachineListOfPool()",
					machineId, requestEvent.getUserID(), null);
		}

		ITVPoolEvent responseEvent = new ITVPoolEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());

		responseEvent.setItvList(itvList);

		LOGGER.info("Sending ITVPool Response Event to RDT ..." + responseEvent);
		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * Mark operator Availability/Unavilability processSetMachineStop() - OPUS
	 * setMachineStop() API
	 * 
	 * @param exchange
	 */
	public void processSetMachineStop(Exchange exchange) {
		String machineStopStatus = null;
		String errorMsg = null;

		OperatorAvailabilityEvent requestEvent = (OperatorAvailabilityEvent) exchange
				.getProperty(Constants.OPERATOR_AVAIL_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);
		LOGGER.info(operator + " OperatorAvailabilityEvent received: "
				+ requestEvent);

		String machineId = requestEvent.getEquipmentID();
		String machineType = OpusCommonUtils.getMachineType(operator);
		String userId = requestEvent.getUserID();
		String userName = requestEvent.getUserName();
		String vessel = requestEvent.getVessel();
		String voyage = requestEvent.getVoyage();

		/** String reasonCode = "08"; */
		String reasonCode = requestEvent.getUnavailableReason();
		boolean callItv = requestEvent.isCallItv();
		String stopStatus = requestEvent.getIsAvailable();
		boolean isStopped = Constants.AVAILABLE_STATUS
				.equalsIgnoreCase(stopStatus)
				|| callItv ? false
				: true;

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			LOGGER.info("Machine stop details sending to OPUS, machineId: "
					+ machineId + " ,machineType: " + machineType
					+ " ,userId: " + userId + " ,userName:" + userName
					+ " ,reasonCode: " + reasonCode + " ,isStopped: "
					+ isStopped);
			try {
				machineStopStatus = machineControlService.setMachineStop(
						machineId, machineType, userId, userName, reasonCode,
						isStopped, vessel, voyage);
				LOGGER.info("Machine stopped status received from OPUS: "
						+ machineStopStatus);

				if (null == machineStopStatus) {
					errorMsg = Constants.AVAILABLE_ERROR;
					LOGGER.info("Error Message received for Machine stopped for machineId: "
							+ machineId + " , errror: " + errorMsg);
				}
			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("setMachineStop() - ",
						machineId, userId, null);
				LOGGER.error("Exception while processing setMachineStop(), ", e);
			}
		}

		if (!callItv) {
			OperatorAvailabilityResponseEvent responseEvent = new OperatorAvailabilityResponseEvent();

			responseEvent.setUserID(requestEvent.getUserID());
			responseEvent.setEquipmentID(requestEvent.getEquipmentID());
			responseEvent.setTerminalID(requestEvent.getTerminalID());
			responseEvent.setEventID(requestEvent.getEventID());
			responseEvent.setErrorMsg(errorMsg);
			responseEvent.setIsAvailable(requestEvent.getIsAvailable());
			responseEvent.setOperatorInitiated(requestEvent
					.isOperatorInitiated());

			LOGGER.info("Sending OperatorAvailabilityResponseEvent to RDT--> "
					+ responseEvent);

			exchange.getOut().setBody(responseEvent);
			OpusCommonUtils.send(exchange);
		}
	}

	/**
	 * 
	 * @param machineId
	 * @param machineType
	 * @throws Exception
	 */
	public void processGetMachineStop(String machineId, String machineType)
			throws Exception {
		AtomMachineStop machineStop = new AtomMachineStop();
		try {
			machineStop = machineControlService.getMachineStop(machineId,
					machineType);
			LOGGER.info("Machine stop status: " + machineStop.getReasonCd());
		} catch (Exception e) {
			LOGGER.error("Exception while processing getMachineStop(), ", e);
		}

	}

	/**
	 * 
	 * @param exchange
	 */
	public void processSetMachineArrival(Exchange exchange) {
		ITVArrivalEvent requestEvent = (ITVArrivalEvent) exchange
				.getProperty(Constants.ITV_ARRIVAL_EVENT);
		LOGGER.info("ITV Arraival request event received :" + requestEvent);

		try {
			String ytNo = requestEvent.getEquipmentID();
			String lane = requestEvent.getLaneId();
			String userId = requestEvent.getUserID();

			/**
			 * [Quay Side] - "LANE", [Yard] - "TPW", "TPL"
			 */
			String blck = null;
			String locTp = null;
			String bay = null;

			if (null != requestEvent.getBlockId()) {
				blck = requestEvent.getBlockId().substring(0, 3);
				locTp = Constants.TPW;
			} else {
				locTp = Constants.LANE;
			}

			LOGGER.info("Arrival details sending to OPUS, Ytno: " + ytNo
					+ " ,lane: " + lane + " ,blck: " + blck + " ,locTp: "
					+ locTp);

			machineControlService.setMachineArrival(ytNo, locTp, blck, bay,
					lane, userId);
		} catch (Exception e) {
			AlertEventUtils.raiseAPIAlertEvent("setMachineStop()",
					requestEvent.getEquipmentID(), requestEvent.getUserID(),
					null);
			LOGGER.error("Exception while processing setMachineReady(), ", e);
		}
	}

	/**
	 * 
	 * @param exchange
	 */
	public void processOperatorMachineNotice(Exchange exchange) {
		OperatorMessageRequestEvent requestEvent = (OperatorMessageRequestEvent) exchange
				.getProperty(Constants.OPERATOR_MSG_EVENT);

		List<OperatorMessage> operatorMessagesList = null;
		List<String> mchnTypeList = new ArrayList<String>();

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			try {
				mchnTypeList.add("QC");
				mchnTypeList.add("TC");
				mchnTypeList.add("YT");

				LOGGER.debug("Calling OPUS API getMachineNotice() --> ");

				for (String mchnType : mchnTypeList) {
					List<AtomMachineNotice> mchnNoticeList = machineControlService
							.getMachineNotices(mchnType);
					operatorMessagesList = getOperatorMessage(mchnNoticeList,
							requestEvent.getLoggedInEquipments());

				}
				LOGGER.info("getMachineNotices() response from OPUS received : "
						+ operatorMessagesList.toString());
			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("getMachineNotice()",
						requestEvent.getEquipmentID(),
						requestEvent.getUserID(), null);
				LOGGER.error(
						"Exception while processOperatorMachineNotice of OPUS API-getMachineNotice(), ",
						e);
			}
		}

		if (null != operatorMessagesList) {
			OperatorMessageResponseEvent responseEvent = new OperatorMessageResponseEvent();
			responseEvent.setUserID(requestEvent.getUserID());
			responseEvent.setEquipmentID(requestEvent.getEquipmentID());
			responseEvent.setTerminalID(requestEvent.getTerminalID());
			responseEvent.setEventID(requestEvent.getEventID());

			responseEvent.setOperatorMessages(operatorMessagesList);

			LOGGER.info("OperatorMessageResponseEvent sending to RDT -->"
					+ responseEvent);
			exchange.getOut().setBody(responseEvent);
		} else {
			LOGGER.info("Currently no Logged in users from ATOM and no messages retrieved from OPUS");
		}

	}

	/**
	 * 
	 * @param mchnNoticeList
	 * @param loggedInEquips
	 * @return
	 * @throws Exception
	 */
	private List<OperatorMessage> getOperatorMessage(
			List<AtomMachineNotice> mchnNoticeList, List<String> loggedInEquips)
			throws Exception {
		List<OperatorMessage> operatorMessagesList = new ArrayList<OperatorMessage>();
		for (AtomMachineNotice mchnNotice : mchnNoticeList) {
			for (String loggedIn : loggedInEquips) {
				if (mchnNotice.getMchnId().equalsIgnoreCase(loggedIn)) {
					OperatorMessage operatorMsg = new OperatorMessage();

					operatorMsg.setEquipmentId(mchnNotice.getMchnId());
					operatorMsg.setMessage(mchnNotice.getNotice());

					operatorMessagesList.add(operatorMsg);

					/**
					 * Sending Notice message as "" for all the equipments for
					 * which notice message have been retrived.
					 */

					machineControlService.setMachineNotice(
							mchnNotice.getMchnId(), mchnNotice.getMchnTp(),
							Constants.EMPTY_STRING);
				}
			}

		}
		return operatorMessagesList;
	}

	/**
	 * Function to change ITV No manually when actually arrived ITV is different
	 * from assigned ITV.
	 * 
	 * @param exchange
	 */
	public void processItvSwap4Manual(Exchange exchange) {
		ITVSwapRequestEvent requestEvent = (ITVSwapRequestEvent) exchange
				.getProperty(Constants.ITV_SWAP_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);

		LOGGER.info(operator + " Processing ITVSwapRequestEvent : "
				+ requestEvent);

		String equipId = requestEvent.getEquipmentID();
		String usrId = requestEvent.getUserID();

		List<SwapContainerPosition> containerPositionList = requestEvent
				.getSwapContainers();
		List<SwapContainerPosition> containerPositionResponseList = new ArrayList<SwapContainerPosition>();

		for (SwapContainerPosition containerPosition : containerPositionList) {
			String jobKey = containerPosition.getJobKey();
			String positionOnChassis = containerPosition.getPositionOnChassis();
			String ytNo = containerPosition.getItvId();
			String newYtNo = containerPosition.getNewItvId();
			boolean status = false;
			String errorMessage = null;

			/**
			 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
			 * functionalities in Production deployment
			 */
			if (opusWriteStatus) {
				try {
					LOGGER.info("Calling itvSwap4Manual() API to OPUS. jobKey: "
							+ jobKey
							+ ", ytNo: "
							+ ytNo
							+ ", New ytNo: "
							+ newYtNo
							+ ", positionOnChassis: "
							+ positionOnChassis + ", usrId: " + usrId);
					errorMessage = machineControlService.itvSwap4Manual(jobKey,
							ytNo, newYtNo, usrId, positionOnChassis);
					status = StringUtils.isNotBlank(errorMessage) ? false
							: true;
					LOGGER.info("Status received on itvSwap4Manual() API from OPUS jobKey: "
							+ jobKey
							+ ", ytNo: "
							+ ytNo
							+ ", New ytNo: "
							+ newYtNo
							+ ", positionOnChassis: "
							+ positionOnChassis
							+ ", usrId: "
							+ usrId
							+ ", Status is: "
							+ status
							+ ", errorMessage: "
							+ errorMessage);

				} catch (Exception e) {
					AlertEventUtils.raiseAPIAlertEvent(
							"changePositionOnChassis()", equipId, usrId, null);
					LOGGER.info(
							"Exception occured while processSwapRequest : ", e);
				}
			} else {
				status = true;
			}

			containerPosition.setStatus(status);
			containerPosition.setErrorMessage(errorMessage);
			LOGGER.info("Status: " + status + " for SwapContainerPosition: "
					+ containerPosition);
			containerPositionResponseList.add(containerPosition);
		}

		ITVSwapResponseEvent responseEvent = new ITVSwapResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setSwapContainerList(containerPositionResponseList);

		LOGGER.info(operator + " ITVSwapResponseEvent with EquipID: " + equipId
				+ " sent to RDT: " + responseEvent);
		exchange.getOut().setBody(responseEvent);

	}

}
