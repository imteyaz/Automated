package com.dpw.opus.processor;

import java.net.MalformedURLException;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.caucho.hessian.client.HessianProxyFactory;
import com.dpw.opus.common.CommunicationService;
import com.dpw.opus.common.Constants;
import com.minapro.esb.common.SendObject;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ExchangeContainerRequestEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.KeepAliveRequestEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerLocationEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorMessageRequestEvent;
import com.minapro.procserver.events.hc.ITVSwapRequestEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.itv.ITVArrivalEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;
import com.minapro.procserver.events.test.TestRequestEvent;

public class EventProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(EventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        
        SendObject sendObject = (SendObject) exchange.getIn().getBody();
        Object object = sendObject.getObject();
        String operator = sendObject.getQueueName();
        /**Object object = exchange.getIn().getBody();
        String operator = "QC";*/
        
        LOGGER.info("************ "+operator+" Request received from RDT is ************ " + object);
        if (object instanceof TestRequestEvent) {
            
            String url = "http://localhost:8080/communication-service";
            HessianProxyFactory factory = new HessianProxyFactory();
            CommunicationService basic;
            try {
                basic = (CommunicationService) factory.create(CommunicationService.class, url);
                String result = basic.communicate(" This is call from client");
                TestRequestEvent testRequest = new TestRequestEvent();
                
                testRequest.setInput(result);   
                EventProcessor.setRequestRoute(exchange, operator, testRequest, Constants.TEST_EVENT);
                
            } catch (MalformedURLException e) {
                LOGGER.error("Exception in TestProcessor: ",e);
            }
            
        } else if (object instanceof KeepAliveRequestEvent) {
            KeepAliveRequestEvent keepAliveEvent = (KeepAliveRequestEvent) object;      
            EventProcessor.setRequestRoute(exchange, operator, keepAliveEvent, Constants.KEEPALIVE_EVENT );
            
        } else if (object instanceof ConfirmAllocationEvent) {
            ConfirmAllocationEvent allocationEvent = (ConfirmAllocationEvent) object;       
            EventProcessor.setRequestRoute(exchange, operator, allocationEvent, Constants.CONFIRM_ALLOCATION_EVENT);
            
        } else if (object instanceof LogoutEvent) {
            LogoutEvent logoutEvent = (LogoutEvent) object;         
            EventProcessor.setRequestRoute(exchange, operator, logoutEvent, Constants.LOGOUT_EVENT);
            
        }  else if (object instanceof ITVPoolRequestEvent) {
            ITVPoolRequestEvent itvPoolEvent = (ITVPoolRequestEvent) object;            
            EventProcessor.setRequestRoute(exchange, operator, itvPoolEvent, Constants.ITVPOOL_EVENT);
            
        }  else if (object instanceof JobListRequestEvent) {
            JobListRequestEvent jobListEvent = (JobListRequestEvent) object;            
            EventProcessor.setRequestRoute(exchange, operator, jobListEvent, Constants.JOBLIST_EVENT);
            
        }  else if (object instanceof CHEJobListRequestEvent) {
            CHEJobListRequestEvent cheJobListEvent = (CHEJobListRequestEvent) object;           
            EventProcessor.setRequestRoute(exchange, operator, cheJobListEvent, Constants.JOBLIST_EVENT);
            
        } else if (object instanceof OperatorAvailabilityEvent) {
            OperatorAvailabilityEvent availabilityEvent = (OperatorAvailabilityEvent) object;           
            EventProcessor.setRequestRoute(exchange, operator, availabilityEvent, Constants.OPERATOR_AVAIL_EVENT);
            
        } else if (object instanceof ITVArrivalEvent) {
            ITVArrivalEvent itvArrivalEvent = (ITVArrivalEvent) object;         
            EventProcessor.setRequestRoute(exchange, operator, itvArrivalEvent, Constants.ITV_ARRIVAL_EVENT);
            
        } else if (object instanceof ContainerDamageEvent) {
             ContainerDamageEvent contrDmgEvent = (ContainerDamageEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, contrDmgEvent, Constants.CONTR_DAMAGE_EVENT);  
             
         } else if (object instanceof ContainerMoveEvent) {
             ContainerMoveEvent contrDmgEvent = (ContainerMoveEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, contrDmgEvent, Constants.JOB_DONE_EVENT);   
             
         } else if (object instanceof UpdateContainerLocationEvent) {
             UpdateContainerLocationEvent updateContrLocEvent = (UpdateContainerLocationEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, updateContrLocEvent, Constants.UPDATE_CONTAINER_LOCATION_EVENT); 
             
         }  else if (object instanceof ExchangeContainerRequestEvent) {
             ExchangeContainerRequestEvent exchangeContainerEvent = (ExchangeContainerRequestEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, exchangeContainerEvent, Constants.EXCHANGE_CONTAINER_EVENT); 
             
         } else if (object instanceof JobSelectionEvent) {
             JobSelectionEvent jobSelectionEvent = (JobSelectionEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, jobSelectionEvent, Constants.JOB_SELECTION_EVENT); 
             
         } else if (object instanceof CancelJobSelectionEvent) {
             CancelJobSelectionEvent cancelJobSelectionEvent = (CancelJobSelectionEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, cancelJobSelectionEvent, Constants.CANCEL_JOB_SELECT_EVENT); 
             
         } else if (object instanceof UpdateContainerEvent) {
             UpdateContainerEvent updateContainerEvent = (UpdateContainerEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, updateContainerEvent, Constants.UPDATE_CONTR_EVENT);
             
         } else if (object instanceof OrphanContainerEvent) {
             OrphanContainerEvent orphanContrEvent = (OrphanContainerEvent) object;
             EventProcessor.setRequestRoute(exchange, operator, orphanContrEvent, Constants.ORPHAN_CONTR_EVENT); 
         } else if (object instanceof InventoryUpdateRequestEvent) {
            InventoryUpdateRequestEvent inventoryUpdateRequestEvent = (InventoryUpdateRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, inventoryUpdateRequestEvent, Constants.INVENTORY_UPDATE_EVENT);
            
        } else if (object instanceof SwapRequestEvent) {
            SwapRequestEvent swapRequestEvent = (SwapRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, swapRequestEvent, Constants.SWAP_EVENT);
            
        } else if (object instanceof OutOfListContainersRequestEvent) {
            OutOfListContainersRequestEvent outOfListContrsEvent = (OutOfListContainersRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, outOfListContrsEvent, Constants.OUTOFLIST_CONTR_INQUIRY_EVENT);
            
        } else if (object instanceof OperatorMessageRequestEvent) {
            OperatorMessageRequestEvent operatorMsgRequestEvent = (OperatorMessageRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, operatorMsgRequestEvent, Constants.OPERATOR_MSG_EVENT);
        } else if (object instanceof ITVSwapRequestEvent) {
        	ITVSwapRequestEvent itvSwapRequestEvent = (ITVSwapRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, itvSwapRequestEvent, Constants.ITV_SWAP_EVENT);
            
        }  else if (object instanceof ShuffleRequestEvent) {
        	ShuffleRequestEvent shuffleRequestEvent = (ShuffleRequestEvent) object;
            EventProcessor.setRequestRoute(exchange, operator, shuffleRequestEvent, Constants.SHUFFLE_CONTR_LOCATION);
            
        } 
    }
    
    
    /**
     * 
     * @param exchange
     * @param operator
     * @param template
     * @param templateName
     */
    private static <T> void setRequestRoute(Exchange exchange,String operator, T template, String templateName) {
        
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED); 
        if (routed != null) {
            if (routed) {
                exchange.removeProperty(Constants.ROUTED);
                exchange.removeProperty(templateName);
                exchange.removeProperty(Constants.QUEUE_NAME);
                LOGGER.debug("Remove routed & template name props from exchange : "+templateName);
            }
        } else {
            exchange.setProperty(Constants.QUEUE_NAME, operator);
            exchange.setProperty(templateName, template);
            exchange.setProperty(Constants.ROUTED, false);
            exchange.setProperty(Constants.EVENT_TYPE, templateName);
            exchange.getOut().setHeader(Constants.QUEUE_NAME, operator);
            
            LOGGER.debug("Setting event-type,routed & template name props to exchange : "+ templateName);
        }
    }
}
