package com.dpw.opus.common;

public interface CommunicationService {

    String communicate(String str);
}
