package com.dpw.opus.processor;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.camel.Exchange;
import org.apache.log4j.Logger;

import com.dpw.opus.common.Constants;

public class ProcessorSender {

    private static final Logger LOGGER = Logger
            .getLogger(ProcessorSender.class);

    public String sendToEndpoint(Exchange exchange) {
        String endpoint = null;
        String eventType = (String) exchange.getProperty(Constants.EVENT_TYPE);
        LOGGER.debug("Processing dynamic routing for the request....."
                + eventType);
        
        String endPointUri = exchange.getFromEndpoint().getEndpointUri();
        LOGGER.debug("RDT request Received from Queue: "+ endPointUri);

        if (eventType != null && !((Boolean) exchange.getProperty(Constants.ROUTED))) {
            Properties properties = new Properties();
            try {
                InputStream inStream = this.getClass().getClassLoader()
                        .getResourceAsStream(Constants.ENDPOINT_PROPERTIES);
                
                properties.load(inStream);
                endpoint = properties.getProperty(eventType);
                exchange.setProperty(Constants.ROUTED, true);
            } catch (IOException e) {
                LOGGER.error("Exception while reading endpoint properties: ", e);
            }           
        }
        LOGGER.debug(eventType + " request is routing to the endpoint --> "
                + endpoint);
        
        return endpoint;
    }
}
