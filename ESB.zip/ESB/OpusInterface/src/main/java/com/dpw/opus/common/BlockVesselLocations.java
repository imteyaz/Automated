package com.dpw.opus.common;

public class BlockVesselLocations {
    private String blck;
    private String bay;
    private String row;
    private String tier;

    public BlockVesselLocations(String blck, String bay, String row,
            String tier) {

        this.blck = blck;
        this.bay = bay;
        this.row = row;
        this.tier = tier;
    }

    public String getBlck() {
        return blck;
    }

    public String getRow() {
        return row;
    }

    @Override
    public String toString() {
        return "BlockVesselLocations [blck=" + blck + ", bay=" + bay
                + ", row=" + row + ", tier=" + tier + "]";
    }

    public String getTier() {
        return tier;
    }

    public String getBay() {
        return bay;
    }

}