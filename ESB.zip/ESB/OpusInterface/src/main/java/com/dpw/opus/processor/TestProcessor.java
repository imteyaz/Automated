package com.dpw.opus.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.dpw.opus.common.Constants;
import com.minapro.procserver.events.test.TestRequestEvent;
import com.minapro.procserver.events.test.TestResponseEvent;

public class TestProcessor implements Processor{    
    private static final Logger LOGGER = Logger.getLogger(TestProcessor.class);
    
    @Override
    public void process(Exchange exchange) throws Exception {
        
        String eventType = (String) exchange.getProperty(Constants.EVENT_TYPE);     
        if(eventType.equalsIgnoreCase(Constants.TEST_EVENT)){           
            processTestRequest(exchange);
        }
    }
    
    private void processTestRequest(Exchange exchange){
        TestRequestEvent requestEvent = (TestRequestEvent) exchange.getProperty("request");     
        LOGGER.info("Processing StoreServerStatusTest Request: "+requestEvent);         
        TestResponseEvent responseEvent = new TestResponseEvent();
        responseEvent.setMessage("SUCCESS");
        
        LOGGER.info("StoreServerStatusTest Response : "+responseEvent);
        exchange.getOut().setBody(responseEvent);
    }
}
