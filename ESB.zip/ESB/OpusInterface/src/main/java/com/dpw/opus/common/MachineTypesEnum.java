package com.dpw.opus.common;

public enum MachineTypesEnum {
    QC("QC"),
    HC("QC"),
    CHE("TC"),  
    ITV("YT");

    private String value;

    private MachineTypesEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }
    
}
