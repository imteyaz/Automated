package com.dpw.opus.common;

public enum JobStatusEnum {
    S1("The status of job has been changed to processing."),
    S2("The AH job has been created."),
    F1("There is no usable location."),
    F2("There is no container within the block."),
    F3("Selected job does not belong to the machine."), 
    F4("There is no slot to be loaded within the same bay."),
    F6("Container not plug out."),
    F7("The error is not defined."),
    F8("There is no container information."),
    F9("There is no container within the general block."),  
    U1("Unknown error");
    
    private String value;

    private JobStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }
}
