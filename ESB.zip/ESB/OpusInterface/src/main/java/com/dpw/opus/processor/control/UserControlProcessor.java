package com.dpw.opus.processor.control;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;

import com.clt.tos.external.atom.jat2.model.AtomLogin;
import com.clt.tos.external.proxy.service.UserControlService;
import com.clt.tos.external.proxy.service.impl.UserControlServiceImpl;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.OpusConnection;
import com.dpw.opus.utils.AlertEventUtils;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.ConfirmAllocationResponseEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.LogoutResponseEvent;

import org.apache.log4j.Logger;

public class UserControlProcessor {
    private static final Logger LOGGER = Logger
            .getLogger(UserControlProcessor.class);

    private static UserControlService userControlService;
    private static String opusWrite;
    private static boolean opusWriteStatus;

    public UserControlProcessor() {
        userControlService = new UserControlServiceImpl();
        opusWrite = OpusConnection.getWriteToOpus();
        opusWriteStatus = StringUtils.isNotBlank(opusWrite)? Boolean.valueOf(opusWrite) : false;
        LOGGER.info("************* Opus Write back status, writeToOpus: " + opusWriteStatus);
    }

    /**
     * Process ATOM Confirm Allocation Event request sent to OPUS User control
     * Login API
     * 
     * @param exchange
     */
    public void processConfirmAllocationEvent(Exchange exchange) {

        ConfirmAllocationEvent requestEvent = (ConfirmAllocationEvent) exchange
                .getProperty(Constants.CONFIRM_ALLOCATION_EVENT);

        String userId = requestEvent.getUserID();
        String pwd = requestEvent.getPassword();
        String mchnId = requestEvent.getEquipmentID();

        LOGGER.info("Sending Login request to setLogin API, " + requestEvent);

        ConfirmAllocationResponseEvent responseEvent = new ConfirmAllocationResponseEvent();
        responseEvent.setUserID(requestEvent.getUserID());
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setEventID(requestEvent.getEventID());

        /**
         * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
         * functionalities in Production deployment
         */
        if (opusWriteStatus) {
            AtomLogin loginResponse = null;
            try {

                loginResponse = userControlService
                        .setLogIn(userId, pwd, mchnId);
                LOGGER.info("Received Login response from setLogin4Machine API: "
                        + loginResponse);

            } catch (Exception e) {
                AlertEventUtils.raiseAPIAlertEvent("setLogIn()", mchnId,
                        userId, null);
                LOGGER.error(
                        "Exception while calling User control LOGIN service:",
                        e);
            }

            if (null != loginResponse) {
                if (Constants.S.equalsIgnoreCase(loginResponse.getRsnCd())) {
                    responseEvent.setReason(Constants.SUCCESS);
                } else {
                    responseEvent.setReason(loginResponse.getRsnCd());
                }
            }
        } else {
            responseEvent.setReason(Constants.SUCCESS);
        }

        LOGGER.info("ResponseEvent sent to RDT--> " + responseEvent);

        exchange.getOut().setBody(responseEvent);
    }

    /**
     * Processing LogoutEvent to Logout on machine from OPUS
     * 
     * @param exchange
     */
    public void processLogoutEvent(Exchange exchange) {

        LogoutEvent requestEvent = (LogoutEvent) exchange
                .getProperty(Constants.LOGOUT_EVENT);

        String userId = requestEvent.getUserID();
        String mchnId = requestEvent.getEquipmentID();
        boolean logoutStatus = false;

        LOGGER.info("Sending Logout Request to OPUS API: " + requestEvent);

        LogoutResponseEvent responseEvent = new LogoutResponseEvent();
        responseEvent.setUserID(requestEvent.getUserID());
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setEventID(requestEvent.getEventID());

        /**
         * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
         * functionalities in Production deployment
         */
        if (opusWriteStatus) {
            try {
                logoutStatus = userControlService.setLogOut(userId, mchnId);
            } catch (Exception e) {
                AlertEventUtils.raiseAPIAlertEvent("setLogOut()", mchnId,
                        userId, null);
                LOGGER.error(
                        "Exception while calling User control LOGOUT service:",
                        e);
            }
        } else {
            logoutStatus = true;
        }

        responseEvent.setStatus(logoutStatus);
        LOGGER.info("Logout Event Response : " + responseEvent);

        exchange.getOut().setBody(responseEvent);
    }
}
