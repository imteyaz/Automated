package com.dpw.opus.common;

public class Constants {

    /* Exchange object constants */
    public static final String ROUTED = "routed";
    public static final String QUEUE_NAME = "queueName";
    public static final String EVENT_TYPE = "eventType";
    public static final String RESPONSE_EVENT = "responseEvent";

    /* QUEUE Constants */
    public static final String QCQ = "QC";
    public static final String HCQ = "HC";
    public static final String CHEQ = "CHE";
    public static final String ITVQ = "ITV";
    public static final String COMMONQ = "COMMONQ";

    /* Response SUCESS/ FAILURE Constants */
    public static final String S = "S";
    public static final String S1 = "S1";
    public static final String S2 = "S2";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";
    public static final String NO_RESPONSE = "No Response";
    public static final String ORPHAN_ERROR = "Unable to Create Orphan Container";
    public static final String OUT_OF_LIST_ERROR = "Unable to Create Out of list Container";
    public static final String UPATE_CONTAINER_ERROR = "Unable to Update container details";

    /* Job type constants from OPUS response */
    public static final String TPW = "TPW";
    public static final String TPL = "TPL";
    public static final String YARD = "YARD";

    public static final String GROUND = "GROUND";
    public static final String AP = "AP";
    public static final String MO = "MO";
    public static final String MI = "MI";
    public static final String GO = "GO";
    public static final String GI = "GI";
    public static final String LANE = "LANE";
    public static final String LOAD = "LOAD";
    public static final String DSCH = "DSCH";
    public static final String YT = "YT";
    public static final String OT = "OT";
    public static final String LC = "LC";
    public static final String GC = "GC";
    public static final String RH = "RH";
    public static final String AH = "AH";

    /* Spreader position L-LEFT, R-RIGHT */
    public static final String SPREADER_POSITION_LEFT = "L";
    public static final String SPREADER_POSITION_RIGHT = "R";

    /* Delimiter constants */
    public static final String DOT = ".";
    public static final String EMPTY_STRING = "";
    public static final String SLASH = "/";
    public static final String PIPE = "/";
    
    /* Job status in OPUS */
    public static final String ACTIVE = "A";
    public static final String EMPTY = "M";

    public static final String ALERT_RDT = "alertRDT";

    /* Property file name constants */
    public static final String ENDPOINT_PROPERTIES = "endpoint.properties";
    /** public static final String OPUS_SERVER_STATUS_FILE = "//home//jbsadm//fuse//OPUSServerStatus.log";*/
    /**
     * public static final String OPUS_SERVER_STATUS_FILE =
     * "E:\\Autotally\\OPUS\\DEV\\OPUSServerStatus.log";
     */
    public static final String OPUS_SERVER_STATUS_FILE = "//home//fuse//OPUSServerStatus.log";
    

    /* RDT Events */
    public static final String CONFIRM_ALLOCATION_EVENT = "ConfirmAllocationEvent";
    public static final String KEEPALIVE_EVENT = "KeepAliveEvent";
    public static final String LOGOUT_EVENT = "LogoutEvent";
    public static final String CONTAINER_MOVE_EVENT = "containerMoveEvent";
    public static final String JOBLIST_EVENT = "JobListEvent";
    public static final String JOB_SELECTION_EVENT = "JobSelectionEvent";
    public static final String JOB_DONE_EVENT = "JobDoneEvent";
    public static final String JOB_DONE_BY_QC_EVENT = "JobDoneByQcListEvent";
    public static final String OPERATOR_AVAIL_EVENT = "AvailabilityEvent";
    public static final String ITVPOOL_EVENT = "ITVPoolRequestEvent";
    public static final String ITV_ARRIVAL_EVENT = "ITVArrivalEvent";
    public static final String CONTR_DAMAGE_EVENT = "ContainerDamageEvent";
    public static final String UPDATE_CONTAINER_LOCATION_EVENT = "UpdateContainerLocationEvent";
    public static final String EXCHANGE_CONTAINER_EVENT = "ExchangeContainerEvent";
    public static final String CANCEL_JOB_SELECT_EVENT = "CancelJobSelectEvent";
    public static final String UPDATE_CONTR_EVENT = "UpdateContainerEvent";
    public static final String ORPHAN_CONTR_EVENT = "OrphanContainerEvent";
    public static final String INVENTORY_UPDATE_EVENT = "InventoryUpdateEvent";
    public static final String SWAP_EVENT = "SwapEvent";
    public static final String OUTOFLIST_CONTR_INQUIRY_EVENT = "OutOfListContainersInquiryEvent";
    public static final String OPERATOR_MSG_EVENT = "OperatorMessageEvent";
    public static final String ITV_SWAP_EVENT = "ITVSwapEvent";
    public static final String SHUFFLE_CONTR_LOCATION = "ShuffleContrLocationEvent";

    public static final String TEST_EVENT = "TestEvent";

    /* ITV Constants */
    public static final String FETCH = "fetch";
    public static final String CARRY = "carry";

    /* Operator availability constants */
    public static final String AVAILABLE_STATUS = "A";
    public static final String AVAILABLE_ERROR = "Set Machine stop failed.";

    /* ITV Constants */
    public static final String GENERAL_INSTRUCTION = "Wait for next Instruction...";

    /*
     * Datasource names
     */
    public static final String PROMIS_DB = "PromisDataSource";
    public static final String PRTOS_DB = "PrtosDataSource";
    public static final String PRTOS_MP_DB = "PrtosmpDataSource";
    public static final String HDPOEMS_DB = "HdPoemsDataSource";

    /**
     * Query constants
     */
    /* DELETE QC/HC JOB LIST RECORDS FROM MP_CHE_JOB_LIST FOR GIVEN EQUIPMENT ID */
    public static final String DELETE_QC_JOB_LIST = "delete from MP_OPUS_QC_JOB_LIST where equipment_id = ? ";

    /* INSERT HC/QC JOB LIST RECORDS FROM MP_CHE_JOB_LIST FOR GIVEN EQUIPMENT ID */
    public static final String INSERT_QC_JOB_LIST = "INSERT INTO MP_OPUS_QC_JOB_LIST"
            + "(TERMINAL_ID, ROTATION_ID, EQUIPMENT_ID, MOVE_KIND,CONTAINER_ID,"
            + "FROM_LOCATION,TO_LOCATION, REFERENCE_CONTAINER_ID, SEQ_NO, LAST_UPDATED_BY,"
            + "LAST_UPDATED_DATETIME,TWIN_TANDEM_ID, TWIN_TANDEM_CD, ISO, POD, "
            + "WT, CATEGEORY, STATUS, "
            + "VESSEL_NAME, VOYAGE, JOB_KEY, POC,JOB_QUEUE_NAME,JOB_QUEUE_SEQUENCE) VALUES "
            + "(?,?,?,?,?,"
            + "?,?,?,?,?, " 
            + "?,?,?,?,?," 
            + "?,?,?, " 
            + "?,?,?,?,?,?) ";
    /* DELETE CHE JOB LIST RECORDS FROM MP_CHE_JOB_LIST FOR GIVEN EQUIPMENT ID */
    public static final String DELETE_CHE_JOB_LIST = "delete from MP_OPUS_CHE_JOB_LIST where equipment_id =?";

    /* INSERT CHE JOB LIST RECORDS FROM MP_CHE_JOB_LIST FOR GIVEN EQUIPMENT ID */
    public static final String INSERT_CHE_JOB_LIST = "INSERT INTO MP_OPUS_CHE_JOB_LIST"
            + "(MOVE_KIND, CONTAINER_ID,"
            + "FROM_LOCATION, TO_LOCATION, "
            + "EQUIPMENT_ID, TERMINAL_ID, "
            + "ROTATION_ID, LAST_UPDATED_BY, "
            + "LAST_UPDATED_DATETIME, TWIN_TANDEM_ID, "
            + "TWIN_TANDEM_CD, ISO,"
            + "POD, WT,"
            + "CATEGEORY, STATUS,"
            + "VESSEL_NAME, VOYAGE,"
            + "JOB_KEY, POC, "
            + "SEQ_NO, JOB_STATUS,"
            + "PRIORITY, ETW) VALUES "
            + "(?,?,"
            + "?,?,"
            + "?,?," 
            + "?,?," 
            + "?,?," 
            + "?,?," 
            + "?,?," 
            + "?,?," 
            + "?,?,"
            + "?,?,"
            + "?,?,"
            + "?,?)";

    private Constants() {

    }
}
