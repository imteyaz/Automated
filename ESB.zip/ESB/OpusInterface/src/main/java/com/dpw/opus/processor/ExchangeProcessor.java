package com.dpw.opus.processor;


import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.minapro.esb.common.ExchangeRepo;

public class ExchangeProcessor implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        ExchangeRepo.setExchange(exchange);
    }
}
