package com.dpw.opus.common;

public enum JobTypeEnum {
    
    DS ("DSCH"),
    LD ("LOAD"),
    MI ("MI"),
    MO ("MO"),
    RH ("RH"),
    AH ("AH"),
    LC ("LC"),
    GI ("GI"),
    GO ("GO"),
    GC ("GC");

    private String value;

    private JobTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }
}
