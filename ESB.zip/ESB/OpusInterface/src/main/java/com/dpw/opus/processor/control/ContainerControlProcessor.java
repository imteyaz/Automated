package com.dpw.opus.processor.control;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.model.AtomContainer;
import com.clt.tos.external.proxy.service.ContainerControlService;
import com.clt.tos.external.proxy.service.impl.ContainerControlServiceImpl;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.OpusConnection;
import com.dpw.opus.utils.AlertEventUtils;
import com.dpw.opus.utils.OpusCommonUtils;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.DamageDetails;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerResponseEvent;

public class ContainerControlProcessor {

	private static final Logger LOGGER = Logger
			.getLogger(ContainerControlProcessor.class);

	ContainerControlService containerControlService;
	private static String opusWrite;
	private static boolean opusWriteStatus;

	public ContainerControlProcessor() {
		containerControlService = new ContainerControlServiceImpl();
		opusWrite = OpusConnection.getWriteToOpus();
		opusWriteStatus = StringUtils.isNotBlank(opusWrite) ? Boolean
				.valueOf(opusWrite) : false;
		LOGGER.info("************* Opus Write back status, writeToOpus: "
				+ opusWriteStatus);
	}

	public void processUpdateDataCorrection(Exchange exchange) {

		UpdateContainerEvent requestEvent = (UpdateContainerEvent) exchange
				.getProperty(Constants.UPDATE_CONTR_EVENT);
		boolean status = false;

		AtomContainer atomContainer = new AtomContainer();
		String contrNo = requestEvent.getContainerID();
		String cntrIso = requestEvent.getIsoCode();
		String opr = requestEvent.getLineCode();
		String cntrWgt = requestEvent.getWeight();
		String cls = OpusCommonUtils.getCotainerCls(requestEvent.getCategory());

		boolean isEmpty = requestEvent.isEmpty();
		String fullMty = isEmpty ? "M" : "F";
		String pod = requestEvent.getPod();
		/**
		 * Over Slot Gauge(F/B/L/R/T) = 11/12/13/14/15
		 */
		String overValue = requestEvent.getOogDimensions();

		String plugCd = requestEvent.getPlugCode();
		String outVessel = requestEvent.getVessel();
		String outVoyage = requestEvent.getVoyage();
		String seal1 = requestEvent.getSeal1();
		String seal2 = requestEvent.getSeal2();
		String seal3 = requestEvent.getSeal3();
		String seal4 = requestEvent.getSeal4();
		String seal5 = requestEvent.getSeal5();
		String nPod = requestEvent.getNpod();
		String fPod = requestEvent.getFpod();
		String userId = requestEvent.getUserID();

		atomContainer.setCntrNo(contrNo);

		if (StringUtils.isNotBlank(cntrIso)) {
			atomContainer.setCntrIso(cntrIso);
		}

		if (StringUtils.isNotBlank(opr)) {
			atomContainer.setOpr(opr);
		}

		if (StringUtils.isNotBlank(cntrWgt)) {
			atomContainer.setCntrWgt(cntrWgt);
		}

		if (StringUtils.isNotBlank(cls)) {
			atomContainer.setCls(cls);
		}

		atomContainer.setFullMty(fullMty);

		if (StringUtils.isNotBlank(overValue)) {
			atomContainer.setOverValue(overValue);
		}

		if (StringUtils.isNotBlank(plugCd)) {
			atomContainer.setPlugCd(plugCd);
		}

		if (StringUtils.isNotBlank(outVoyage)) {
			atomContainer.setOutVessel(outVessel);
		}

		if (StringUtils.isNotBlank(outVoyage)) {
			atomContainer.setOutVoyage(outVoyage);
		}

		if (StringUtils.isNotBlank(seal1)) {
			atomContainer.setSeal1(seal1);
		}

		if (StringUtils.isNotBlank(seal2)) {
			atomContainer.setSeal2(seal2);
		}

		if (StringUtils.isNotBlank(seal3)) {
			atomContainer.setSeal3(seal3);
		}

		if (StringUtils.isNotBlank(seal4)) {
			atomContainer.setSeal4(seal4);
		}

		if (StringUtils.isNotBlank(seal5)) {
			atomContainer.setSeal5(seal5);
		}

		if (StringUtils.isNotBlank(pod)) {
			atomContainer.setPod(pod);
		}

		if (StringUtils.isNotBlank(nPod)) {
			atomContainer.setnPod(nPod);
		}

		if (StringUtils.isNotBlank(fPod)) {
			atomContainer.setfPod(fPod);
		}

		atomContainer.setUsrId(userId);

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			LOGGER.info("Calling OPUS API updateDataCorrection(). AtomContainer: "
					+ atomContainer);
			try {

				status = containerControlService
						.updateDataCorrection(atomContainer);
				LOGGER.info("Updating Data Correction details for ContainerID: '"
						+ contrNo + "' in OPUS is : " + status);

			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("updateDataCorrection()",
						requestEvent.getEquipmentID(), userId, contrNo);
				LOGGER.error(
						"Exception occured while updating container correction details to OPUS : ",
						e);
			}
		} else {
			status = true;
		}

		UpdateContainerResponseEvent responseEvent = new UpdateContainerResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());

		responseEvent.setContainerID(contrNo);
		responseEvent.setSuccess(status);

		LOGGER.info("Sending Container Attribute Response Event to RDT ..."
				+ responseEvent);
		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * Container Damage Event Should be update to OPUS through
	 * updateDamageStatus() API.
	 * 
	 * @param exchange
	 */
	public void processUpdateDamageStatus(Exchange exchange) {

		ContainerDamageEvent requestEvent = (ContainerDamageEvent) exchange
				.getProperty(Constants.CONTR_DAMAGE_EVENT);
		List<DamageDetails> damageDetailsList = requestEvent.getDamageDetails();
		LOGGER.info("Processing ContainerDamageEvent request to update in OPUS: "
				+ requestEvent);

		boolean status = false;
		String contrNo = null;
		String userId = requestEvent.getUserID();

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			try {
				for (DamageDetails damageDetail : damageDetailsList) {
					if (damageDetail.isMajorDamage()) {
						contrNo = damageDetail.getContainerID();
						boolean isDmg = true;

						LOGGER.info("Calling OPUS API updateDamageStatus(). cntrNo: "
								+ contrNo
								+ " ,userId: "
								+ userId
								+ " ,isDmg: "
								+ isDmg);
						status = containerControlService.updateDamageStatus(
								contrNo, userId, isDmg);

						LOGGER.info("Updating Damage recording in OPUS for ContainerID: '"
								+ contrNo + "' & status is : " + status);
					}
				}
			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("updateDamageStatus()",
						requestEvent.getEquipmentID(),
						requestEvent.getUserID(), contrNo);
				LOGGER.error(
						"Exception occured while updating container Damage status to OPUS : ",
						e);
			}
		} else {
			status = true;
		}
	}
}
