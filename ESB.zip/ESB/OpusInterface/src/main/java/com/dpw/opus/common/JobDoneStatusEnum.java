package com.dpw.opus.common;

public enum JobDoneStatusEnum {
    S("Completed"),
    S1("Completed."),
    S2("The AH job has been created."), 
    F1("Current Location is Null!!"), 
    F2("There is no container within the block"),
    F3("There are another container on the current container!!"), 
    F4("There are terminal in container job on the current truck!!"), 
    F5("The status of reefer container is POW or ROW!!"),   
    F6("The situation of container is not OYS or OYG!!"),
    F7("Check the Hold Information!!"),
    F8("Check the location type"),
    F9("There is not the information of a container"),
    U1("Unknown Error"),
    F101("There is no ship plan for container."),
    F102("Already completed."),
    F103("Container Situation does not match."),
    F104("Container already in yard."),
    F105("Container not in yard."),
    F106("Container has hold information."),
    F107("Yard Work Order is not completed."),
    F200("Errors in Data Transaction."),
    F900("Dangerous Goods cannot discharge without confirmation."),
    F000("Unknown error.");
        
    private String value;

    private JobDoneStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }
}
