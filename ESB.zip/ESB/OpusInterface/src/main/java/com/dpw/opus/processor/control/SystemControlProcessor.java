package com.dpw.opus.processor.control;

import java.io.PrintWriter;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.clt.tos.external.proxy.service.SystemControlService;
import com.clt.tos.external.proxy.service.impl.SystemControlServiceImpl;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.HashIn;
import com.dpw.opus.utils.OpusCommonUtils;
import com.minapro.procserver.events.KeepAliveResponseEvent;

public class SystemControlProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(SystemControlProcessor.class);

    private static SystemControlService systemControlService;
    private static Boolean runningStatus = false;

    private SystemControlProcessor() {
        systemControlService = new SystemControlServiceImpl();
    }

    /**
     * Check OPUS server UP/DOWN status at configured time interval
     */
    @Override
    public void process(Exchange exchange) throws Exception {       
    
        boolean alertRDTStatus = false;
        boolean currentStatus = false;
        String opusServerStatus = getOPUSServerStatus();
        if (opusServerStatus != null ) {
            currentStatus = true;
        }
                
        /* Send Server status to RDT only first time either OPUS is UP/DOWN 
         * runningStatus == currentStatus, then Ostatus already persisted */
        if (runningStatus != currentStatus) {
            runningStatus = currentStatus;
            HashIn.putInMap("runningStatus", runningStatus);
            if (!alertRDTStatus) {
                sendOPUSStatusToRDT(exchange);
                storeServerStatus(opusServerStatus);
                alertRDTStatus = true;
            }           
        } else {
            alertRDTStatus = false;
        }
        LOGGER.debug("runningStatus: " + runningStatus+"  ,currentStatus: "+currentStatus+" , alertRDTStatus: "+alertRDTStatus);
    }

    /**
     * OPUS UP/DOWN status should be stored in log file for monitoring
     * @param status
     */
    private void storeServerStatus(String status) {
        try {
            PrintWriter writer = new PrintWriter(Constants.OPUS_SERVER_STATUS_FILE, "UTF-8");
            writer.println(status);
            writer.close();

        } catch (Exception e) {
            LOGGER.error("Exception while writing server status: ", e);
        }
    }

    /**
     * RDT server should be communicated when OPUS is DOWN and immediately after
     * server getting UP
     * @param opusServerStatus
     */
    public void sendOPUSStatusToRDT(Exchange exchange) {
        boolean currentStatus = false;
    /** if(!runningStatus){ */
            String opusServerStatus = getOPUSServerStatus();
            if (opusServerStatus != null ) {
                currentStatus = true;
            }
        /** } */
        
        KeepAliveResponseEvent responseEvent = new KeepAliveResponseEvent();
        responseEvent.setStatus(currentStatus);
        
        LOGGER.info("Keep Alive response Sent to RDT Server: "+responseEvent);
        exchange.getOut().setBody(responseEvent);
        exchange.getOut().setHeader(Constants.QUEUE_NAME, Constants.COMMONQ);
        OpusCommonUtils.send(exchange);
    }   
    
    /**
     * 
     * @return
     */
    private String getOPUSServerStatus(){
        String opusServerStatus = null;
        
        try {
            opusServerStatus = systemControlService.keepAlive();            
            LOGGER.info("Currently OPUS server status is: " + opusServerStatus);
        } catch (Exception e) {
            LOGGER.error("Currently OPUS server is DOWN... ",e );
        }
        return opusServerStatus;
    }
    
}

