package com.dpw.opus.processor.control;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.model.AtomExchange;
import com.clt.tos.external.atom.jat2.model.AtomStowage;
import com.clt.tos.external.proxy.service.VesselControlService;
import com.clt.tos.external.proxy.service.impl.VesselControlServiceImpl;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.OpusConnection;
import com.dpw.opus.utils.AlertEventUtils;
import com.dpw.opus.utils.OpusCommonUtils;
import com.minapro.procserver.events.ExchangeContainerRequestEvent;
import com.minapro.procserver.events.ExchangeContainerResponseEvent;
import com.minapro.procserver.events.ExchangeDetails;
import com.minapro.procserver.events.ExchangeStatus;
import com.minapro.procserver.events.UpdateContainerLocationEvent;
import com.minapro.procserver.events.UpdateContainerLocationResponseEvent;
import com.minapro.procserver.events.hc.OrphanContainerEvent;
import com.minapro.procserver.events.hc.OrphanContainerResponseEvent;

public class VesselControlProcessor {

    private static final Logger LOGGER = Logger
            .getLogger(VesselControlProcessor.class);

    VesselControlService vesselControlService;

    private static String opusWrite;
    private static boolean opusWriteStatus;
        
    private static boolean writeExchangePositionStatus;

    public VesselControlProcessor() {
        vesselControlService = new VesselControlServiceImpl();
        opusWrite = OpusConnection.getWriteToOpus();
        opusWriteStatus = StringUtils.isNotBlank(opusWrite)? Boolean.valueOf(opusWrite) : false;
        LOGGER.info("************* Opus Write back status, writeToOpus: " + opusWriteStatus);
        
        writeExchangePositionStatus = StringUtils.isNotBlank(OpusConnection.getWriteExchangePosition())? Boolean.valueOf(OpusConnection.getWriteExchangePosition()) : false;
        LOGGER.info("************* Write exchange container position to OPUS , writeExchangePositionStatus: " + writeExchangePositionStatus);        
    }

    /**
     * ExchangeContainer for Modify Vessel Stowage Information of two containers
     * before confirmation.
     * 
     * @param exchange
     */
    public void processExchangeContainer(Exchange exchange) {

        boolean status = false;

        ExchangeContainerRequestEvent requestEvent = (ExchangeContainerRequestEvent) exchange
                .getProperty(Constants.EXCHANGE_CONTAINER_EVENT);
        LOGGER.info("ExchangeContainerRequestEvent request received to OPUS : "
                + requestEvent);

        ExchangeContainerResponseEvent responseEvent = new ExchangeContainerResponseEvent();

        String userId = requestEvent.getUserID();
        String vessel = requestEvent.getVessel();
        String voyage = requestEvent.getVoyage();

        String disLoad = "LOAD".equalsIgnoreCase(requestEvent.getMoveType()) ? "L"
                : "D";

        List<ExchangeDetails> exchangeDetails = requestEvent
                .getExchangeDetails();
        List<ExchangeStatus> exchageStatusList = new ArrayList<ExchangeStatus>();

        String singleTwinFlag = requestEvent.getSingleTwinFlag();

        AtomExchange atomExchange = new AtomExchange();
        atomExchange.setUsrId(userId);
        atomExchange.setVessel(vessel);
        atomExchange.setVoyage(voyage);
        atomExchange.setDisLoad(disLoad);
        atomExchange.setSingleTwinFlag(singleTwinFlag);

        for (ExchangeDetails exchangeDetail : exchangeDetails) {
            
            /**
             * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
             * functionalities in Production deployment
             */
            if (writeExchangePositionStatus && opusWriteStatus) {
                try {
                    String sourceStowage = OpusCommonUtils
                            .getReplaceDelimiterWithValue(
                                    exchangeDetail.getSourceLocation(),
                                    Constants.DOT, Constants.EMPTY_STRING);
                    String targetStowage = OpusCommonUtils
                            .getReplaceDelimiterWithValue(
                                    exchangeDetail.getTargetLocation(),
                                    Constants.DOT, Constants.EMPTY_STRING);

                    atomExchange.setSourceStowage(sourceStowage);
                    atomExchange.setTargetStowage(targetStowage);

                    LOGGER.info("ExchangeContainer AtomExchange request sending to OPUS : "
                            + atomExchange);
                    status = vesselControlService
                            .exchangeContainer(atomExchange);
                } catch (Exception e) {
                    AlertEventUtils.raiseAPIAlertEvent("setLogOut() - ",
                            requestEvent.getEquipmentID(), userId, null);
                    LOGGER.error(
                            "Exception occured while processing ExchangeContainer : ",
                            e);
                }
            } else {
                status = true;
            }
            ExchangeStatus exchangeStatus = new ExchangeStatus();
            exchangeStatus.setContainerId(exchangeDetail.getContainerId());
            exchangeStatus.setStatus(status);

            exchageStatusList.add(exchangeStatus);
        }

        LOGGER.info("Exchange Container update status received from OPUS : "
                + status);

        responseEvent.setUserID(requestEvent.getUserID());
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setEventID(requestEvent.getEventID());
        responseEvent.setExchangeStatus(exchageStatusList);

        LOGGER.info("ExchangeContainerResponseEvent response sent to RDT: "
                + responseEvent);
        exchange.getOut().setBody(responseEvent);
    }

    /**
     * Modify Vessel Stowage For Completed Container
     * 
     * @param exchange
     */
    public void processExchangeStowage(Exchange exchange) {

        boolean status = false;

        UpdateContainerLocationEvent requestEvent = (UpdateContainerLocationEvent) exchange
                .getProperty(Constants.UPDATE_CONTAINER_LOCATION_EVENT);
        LOGGER.info("UpdateContainerLocationEvent request received to OPUS : "
                + requestEvent);

        String userId = requestEvent.getUserID();
        String vessel = requestEvent.getVessel();
        String voyage = requestEvent.getVoyage();

        /**
         * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
         * functionalities in Production deployment
         */
        if (writeExchangePositionStatus && opusWriteStatus) {
            AtomStowage atomStowage = new AtomStowage();
            atomStowage.setUsrId(userId);
            atomStowage.setVessel(vessel);
            atomStowage.setVoyage(voyage);

            try {
                String sourceStowage = OpusCommonUtils
                        .getReplaceDelimiterWithValue(
                                requestEvent.getSourceLocation(),
                                Constants.DOT, Constants.EMPTY_STRING);
                String targetStowage = OpusCommonUtils
                        .getReplaceDelimiterWithValue(
                                requestEvent.getLocation(), Constants.DOT,
                                Constants.EMPTY_STRING);
                atomStowage.setSourceStowage(sourceStowage);
                atomStowage.setTargetStowage(targetStowage);

                LOGGER.info("Exchange stowage AtomStowage request sending to OPUS : "
                        + atomStowage);
                status = vesselControlService.exchangeStowage(atomStowage);
            } catch (Exception e) {
                AlertEventUtils.raiseAPIAlertEvent("setLogOut()",
                        requestEvent.getEquipmentID(), userId, null);
                LOGGER.error(
                        "Exception occured while processing ExchangeStowage : ",
                        e);
            }
        } else {
            status = true;
        }
        LOGGER.info("Exchange stowage status received from OPUS : " + status);

        UpdateContainerLocationResponseEvent responseEvent = new UpdateContainerLocationResponseEvent();
        responseEvent.setContainerId(requestEvent.getContainerId());
        responseEvent.setUserID(requestEvent.getUserID());
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setEventID(requestEvent.getEventID());
        responseEvent.setStatus(status);
        responseEvent.setMoveType(requestEvent.getMoveType());

        LOGGER.info("UpdateContainerLocationEvent response sent to RDT: "
                + responseEvent);
        exchange.getOut().setBody(responseEvent);
    }

    /**
     * Create out of List Container, Dry Bulk Cargo, Hatch Cover, Gear Box
     * 
     * @param exchange
     */
    public void processCreateOutOfListContainer(Exchange exchange) {

        OrphanContainerEvent requestEvent = (OrphanContainerEvent) exchange
                .getProperty(Constants.ORPHAN_CONTR_EVENT);
        boolean status = false;

        String vessel = requestEvent.getVessel();
        String voyage = requestEvent.getVoyage();
        String contrNo = requestEvent.getContainerID();
        String qcNo = requestEvent.getEquipmentID();
        String isoCode = requestEvent.getIsoCode();
        String userId = requestEvent.getUserID();
        String ytNo = requestEvent.getItvNo();
        String errorMessage = null;
        
        /**
         * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
         * functionalities in Production deployment
         */
        if (opusWriteStatus) {
            try {
                LOGGER.info("Calling OPUS API createOutOfListContainer(). contrNo: "
                        + contrNo
                        + ", qcNo: "
                        + qcNo
                        + ", cntrIso: "
                        + isoCode
                        + ", vessel: "
                        + vessel
                        + ", voyage: "
                        + voyage
                        + ", userId: " + userId + ", ytNo: " + ytNo);
                status = vesselControlService.createOutOfListContainer(vessel,
                        voyage, contrNo, qcNo, isoCode, userId, ytNo);

                LOGGER.info("OPUS response for CreateOutOfListContainer() status: "
                        + status);
            } catch (Exception e) {
                AlertEventUtils
                        .raiseAPIAlertEvent(
                                "processCreateOutOfListContainer()", qcNo,
                                userId, null);
                LOGGER.error(
                        "Exception occured while processing CreateOutOfListContainer : ",
                        e);
            }
            if (!status) {
                if (requestEvent.getOutOfListContainer()) {
                    errorMessage = Constants.OUT_OF_LIST_ERROR;
                } else {
                    errorMessage = Constants.ORPHAN_ERROR;
                }
            }
        } else {
            status = true;
        }
        OrphanContainerResponseEvent responseEvent = new OrphanContainerResponseEvent();
        responseEvent.setContainerId(requestEvent.getContainerID());
        responseEvent.setUserID(requestEvent.getUserID());
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setEventID(requestEvent.getEventID());

        responseEvent.setContainerId(contrNo);
        responseEvent.setFromLocation(requestEvent.getFromLocation());
        responseEvent.setContainerCreationStatus(status);
        responseEvent.setItvNo(requestEvent.getItvNo());
        responseEvent.setIsoCode(isoCode);
        responseEvent.setErrorMessage(errorMessage);

        LOGGER.info("Sending OrphanContainer Response Event to RDT ..."
                + responseEvent);
        exchange.getOut().setBody(responseEvent);
    }
}
