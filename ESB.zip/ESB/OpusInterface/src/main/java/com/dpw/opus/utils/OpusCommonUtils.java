package com.dpw.opus.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.dpw.opus.common.BlockVesselLocations;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.ContainerCategoryEnum;
import com.dpw.opus.common.JobDoneStatusEnum;
import com.dpw.opus.common.JobSelectionStatusEnum;
import com.dpw.opus.common.JobStatusEnum;
import com.dpw.opus.common.JobTypeEnum;
import com.dpw.opus.common.MachineTypesEnum;

public class OpusCommonUtils {
	private static final Logger LOGGER = Logger
			.getLogger(OpusCommonUtils.class);

	private OpusCommonUtils() {

	}

	/**
	 * Get MachineType based on message received from queue
	 * 
	 * @param operator
	 * @return
	 */
	public static String getMachineType(String operator) {

		String machineType = operator;
		for (MachineTypesEnum mchnTypeEnum : MachineTypesEnum.values()) {
			if (mchnTypeEnum.name().equalsIgnoreCase(operator)) {
				machineType = mchnTypeEnum.toString();
			}
		}

		return machineType;
	}

	/**
	 * 
	 * This method sends any object passed to it to the QC out q
	 * 
	 * @param t
	 *            Object to be sent to the queue
	 */
	public static <T> void send(Exchange exchange) {

		LOGGER.debug("Response being sent to RDT server...");

		CamelContext context = exchange.getContext();
		ProducerTemplate template = context.createProducerTemplate();
		template.send("direct:OUTQ", exchange);
	}

	/**
	 * Split fromlocation / tolocation sent from RDT in format(ex:714.12.A.2)
	 * 
	 * @param location
	 * @return
	 */
	public static BlockVesselLocations getSplitLocationValues(String location) {

		String[] locations = StringUtils.split(location, Constants.DOT);

		return locations.length > 3 ? new BlockVesselLocations(locations[0],
				locations[1], locations[2], locations[3])
				: new BlockVesselLocations(null, locations[0], locations[1],
						locations[2]);
	}

	/**
	 * Replace DOT(.) with emptyString("") & return string value
	 * 
	 * @param actualString
	 * @return
	 */
	public static String getReplaceDelimiterWithValue(String actualString,
			String delimiter, String replaceValue) {
		String replaceString = null;
		if (StringUtils.isNotBlank(actualString)) {
			replaceString = actualString.replace(delimiter, replaceValue);
		}
		LOGGER.debug("Actual String: " + actualString
				+ " after removing '.' from location: " + replaceString);
		return replaceString;
	}

	public static String appendStringwithSeperator(List<String> actualValues,
			String seperator) {
		return StringUtils.join(actualValues, seperator);
	}

	/**
	 * Get opus error codes (S1,S2,F1,F2,F3,F4,F5,F6,F7,F8,F9,U1
	 * 
	 * @param reasonCode
	 * @return
	 */
	public static String getOPUSErrorMessage(String reasonCode) {

		String errorMessage = null;
		if (StringUtils.isNotBlank(reasonCode)) {

			for (JobDoneStatusEnum enumName : JobDoneStatusEnum.values()) {
				if (enumName.name().equalsIgnoreCase(Constants.S)
						&& enumName.name().equalsIgnoreCase(reasonCode)) {
					LOGGER.info("****** JOB Status ***********" + enumName);
					break;
				} else if (enumName.name().equalsIgnoreCase(Constants.S1)
						&& enumName.name().equalsIgnoreCase(reasonCode)) {

					LOGGER.info("****** JOB Status ********" + enumName);
					break;
				} else if (enumName.name().equalsIgnoreCase(Constants.S2)
						&& enumName.name().equalsIgnoreCase(reasonCode)) {

					LOGGER.info("****** JOB Status *******" + enumName);

					break;
				} else if (enumName.name().equalsIgnoreCase(reasonCode)) {

					errorMessage = enumName.toString();
					LOGGER.info("****** JOB Status *****" + enumName);
					break;
				}
			}
		} else {
			errorMessage = Constants.NO_RESPONSE;
		}
		return errorMessage;
	}

	/**
	 * 
	 * @param jobType
	 * @return
	 */
	public static String getMoveKindForJobType(String jobType) {
		String moveKind = null;

		if (StringUtils.isNotBlank(jobType)) {
			for (JobTypeEnum jobTypeEnum : JobTypeEnum.values()) {
				if (jobTypeEnum.name().equalsIgnoreCase(jobType)) {
					moveKind = jobTypeEnum.toString();
					break;
				}
			}
		}
		return moveKind;

	}

	/**
	 * 
	 * @param moveKind
	 * @return
	 */
	public static String getJobTypeName(String moveKind) {
		String jobTp = null;
		for (JobTypeEnum jobTypeEnum : JobTypeEnum.values()) {
			if (jobTypeEnum.toString().equalsIgnoreCase(moveKind)) {
				jobTp = jobTypeEnum.name();
				break;
			}
		}
		return jobTp;
	}

	/**
	 * container postion(YARD side,Quay side) with dot appended for
	 * block.row.stack.tier / bay.row.tier
	 * 
	 * @param locationList
	 * @return
	 */
	public static String getContainerLocation(String block, String bay,
			String row, String tier) {

		List<String> locationList = new ArrayList<String>();

		locationList.add(block);
		locationList.add(bay);
		locationList.add(row);
		locationList.add(tier);

		StringBuilder locationBuilder = new StringBuilder();
		String contrLocation = Constants.EMPTY_STRING;
		for (String location : locationList) {
			if (StringUtils.isNotBlank(location)) {
				locationBuilder.append(location).append(Constants.DOT);
			}
		}

		if (locationBuilder.length() > 0) {
			contrLocation = locationBuilder.substring(0,
					locationBuilder.length() - 1).toString();
		}
		return contrLocation;
	}

	/**
	 * 
	 * @param jobType
	 * @return
	 */
	public static String getCotainerCls(String category) {
		String contrCls = null;

		if (StringUtils.isNotBlank(category)) {
			for (ContainerCategoryEnum contrCategoryEnum : ContainerCategoryEnum
					.values()) {
				if (contrCategoryEnum.toString().equalsIgnoreCase(category)) {
					contrCls = contrCategoryEnum.name();
					break;
				}
			}
		}
		return contrCls;
	}

	/**
	 * Get Job Selection status response code from OPUS for CHE updating job
	 * status "Inactive/active/processing"
	 * 
	 * @param jobStatus
	 * @return
	 */
	public static String getJobSelectionStatusResponseCode(String jobStatus) {
		String jobSelectionStatusResponseCode = null;

		if (StringUtils.isNotBlank(jobStatus)) {
			for (JobSelectionStatusEnum jobSelectionStatusEnum : JobSelectionStatusEnum
					.values()) {
				if (jobSelectionStatusEnum.name().equalsIgnoreCase(jobStatus)) {
					jobSelectionStatusResponseCode = jobSelectionStatusEnum
							.toString();
					break;
				}
			}
		}
		return jobSelectionStatusResponseCode.trim();
	}

	/**
	 * Get Job status response code from OPUS for CHE updating job status
	 * "Inactive/active/processing"
	 * 
	 * @param jobStatus
	 * @return
	 */
	public static String getJobStatusResponseCode(String jobStatus) {
		String jobStatusResponseCode = null;

		if (StringUtils.isNotBlank(jobStatus)) {
			for (JobStatusEnum jobTypeEnum : JobStatusEnum.values()) {
				if (jobTypeEnum.name().equalsIgnoreCase(jobStatus)) {
					jobStatusResponseCode = jobTypeEnum.toString();
					break;
				}
			}
		}
		return jobStatusResponseCode;
	}

	/**
	 * 
	 * @param moveKind
	 * @return
	 */
	public static String getLocationType(String moveKind) {
		String locTp = null;
		if (Constants.LOAD.equalsIgnoreCase(moveKind)
				|| Constants.GO.equalsIgnoreCase(moveKind)
				|| Constants.MO.equalsIgnoreCase(moveKind)
				|| Constants.RH.equalsIgnoreCase(moveKind)
				|| Constants.AH.equalsIgnoreCase(moveKind)) {
			locTp = Constants.YARD;

		} else if (Constants.MI.equalsIgnoreCase(moveKind)
				|| Constants.DSCH.equalsIgnoreCase(moveKind)
				|| Constants.LC.equalsIgnoreCase(moveKind)) {
			locTp = Constants.TPW;

		} else if (Constants.GI.equalsIgnoreCase(moveKind)
				|| Constants.GC.equalsIgnoreCase(moveKind)) {

			locTp = Constants.TPL;
		}
		return locTp;
	}

}