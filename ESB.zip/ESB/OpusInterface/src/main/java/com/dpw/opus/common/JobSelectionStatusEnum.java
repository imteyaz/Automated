package com.dpw.opus.common;

public enum JobSelectionStatusEnum {
    S1("Completed"),
    S2("SUCCESS"),
    F2("There is no container within the block"), 
    F8("Check the location type"), 
    F9("There is not the information of a container"), 
    U1("Unknown Error");

    private String value;

    private JobSelectionStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }

}
