package com.dpw.opus.common;

import java.util.HashMap;
import java.util.Map;

public class HashOut {

    private static Map<String, Object> mapOut = new HashMap<String, Object>();
    
    private HashOut(){
        
    }

    public static void putInMap(String key, Object value) {
        mapOut.put(key, value);
    }

    public static Object getFromMap(String key) {
        return mapOut.get(key);
    }
}
