package com.dpw.opus.processor.control;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.model.AtomPickedContainer;
import com.clt.tos.external.atom.jat2.model.AtomResultJobDone;
import com.clt.tos.external.atom.jat2.model.AtomVmtWorkOrder;
import com.clt.tos.external.proxy.service.JobControlService;
import com.clt.tos.external.proxy.service.impl.JobControlServiceImpl;
import com.dpw.opus.common.BlockVesselLocations;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.JobSelectionStatusEnum;
import com.dpw.opus.common.MachineTypesEnum;
import com.dpw.opus.common.OpusConnection;
import com.dpw.opus.utils.AlertEventUtils;
import com.dpw.opus.utils.JobListUtils;
import com.dpw.opus.utils.OpusCommonUtils;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ContainerMoveResponseEvent;
import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;
import com.minapro.procserver.events.JobListContainerDetails;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.che.CHEJobListEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateRequestEvent;
import com.minapro.procserver.events.che.InventoryUpdateResponseEvent;
import com.minapro.procserver.events.che.ShuffleRequestEvent;
import com.minapro.procserver.events.che.ShuffleResponseEvent;
import com.minapro.procserver.events.common.CancelJobSelectionEvent;
import com.minapro.procserver.events.common.CancelJobSelectionResponseEvent;
import com.minapro.procserver.events.common.JobSelectionEvent;
import com.minapro.procserver.events.common.JobSelectionResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainerResponseEvent;
import com.minapro.procserver.events.hc.OutOfListContainersRequestEvent;
import com.minapro.procserver.events.hc.SwapContainerPosition;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.hc.SwapResponseEvent;
import com.minapro.procserver.events.itv.ITVJobListEvent;

public class JobControlProcessor {
	private static final Logger LOGGER = Logger
			.getLogger(JobControlProcessor.class);

	JobControlService jobControlService;
	private static String opusWrite;
	private static boolean opusWriteStatus;

	private static boolean writeQcJobConfirmationStatus;

	public JobControlProcessor() {
		jobControlService = new JobControlServiceImpl();
		opusWrite = OpusConnection.getWriteToOpus();
		opusWriteStatus = StringUtils.isNotBlank(opusWrite) ? Boolean
				.valueOf(opusWrite) : false;
		LOGGER.info("************* Opus Write back status, writeToOpus: "
				+ opusWriteStatus);

		writeQcJobConfirmationStatus = StringUtils.isNotBlank(OpusConnection
				.getWriteQcJobConfirmation()) ? Boolean.valueOf(OpusConnection
				.getWriteQcJobConfirmation()) : false;
		LOGGER.info("************* Write Qc Job Confirmation to OPUS , writeQcJobConfirmationStatus: "
				+ writeQcJobConfirmationStatus);
	}

	/**
	 * This API is provide all job list for QC or YC or ITV
	 * 
	 * @param exchange
	 */
	public void processJobList(Exchange exchange) {
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);
		LOGGER.info("Processing " + operator + " Joblist Request...");
		String machineType = OpusCommonUtils.getMachineType(operator);
		CHEJobListEvent cheResponseEvent = new CHEJobListEvent();
		ITVJobListEvent itvResponseEvent = new ITVJobListEvent();
		JobListEvent responseEvent = new JobListEvent();

		/**
		 * Joblist processing for CHE operator
		 */
		if (MachineTypesEnum.CHE.name().equalsIgnoreCase(operator)) {
			CHEJobListRequestEvent cheRequestEvent = (CHEJobListRequestEvent) exchange
					.getProperty(Constants.JOBLIST_EVENT);
			LOGGER.info("CHE JobListRequestEvent received for EquipID: "
					+ cheRequestEvent.getEquipmentID() + " -->"
					+ cheRequestEvent);

			cheResponseEvent = JobListUtils.processCHEJobListEvent(exchange,
					jobControlService, cheRequestEvent, machineType);
			LOGGER.info("CHE JobList Response Event sending to RDT --->"
					+ cheResponseEvent);
			exchange.getOut().setBody(cheResponseEvent);

		} else {
			JobListRequestEvent requestEvent = (JobListRequestEvent) exchange
					.getProperty(Constants.JOBLIST_EVENT);
			LOGGER.info("JobListRequestEvent received for EquipID: "
					+ requestEvent.getEquipmentID() + " -->" + requestEvent);

			exchange = JobListUtils.processJobListEvent(exchange,
					jobControlService, requestEvent, operator);

			/**
			 * If ITV joblist request received return ITVJobListEvent response
			 * else for QC / HC return JobListEvent reponse.
			 */
			if (MachineTypesEnum.ITV.name().equalsIgnoreCase(operator)) {
				itvResponseEvent = (ITVJobListEvent) exchange
						.getProperty(Constants.RESPONSE_EVENT);

				LOGGER.info("ITVJobListEvent Response Event sending to RDT -->"
						+ itvResponseEvent);
				exchange.getOut().setBody(itvResponseEvent);
			} else {
				responseEvent = (JobListEvent) exchange
						.getProperty(Constants.RESPONSE_EVENT);

				LOGGER.info("JobList Response Event sending to RDT --->"
						+ responseEvent);
				exchange.getOut().setBody(responseEvent);
			}
		}
	}

	/**
	 * Job confirmation to complete job for Yard Crane (RMGC, ECH, TH, RS, ..) &
	 * Quay Crane.
	 * 
	 * @param exchange
	 */

	public void processJobDone(Exchange exchange) {
		ContainerMoveEvent requestEvent = (ContainerMoveEvent) exchange
				.getProperty(Constants.JOB_DONE_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);
		String errorMessage = null;
		List<AtomResultJobDone> atomResultJobDoneList = null;

		LOGGER.info(operator + " Processing ContainerMoveEvent: "
				+ requestEvent);

		if (Constants.CHEQ.equalsIgnoreCase(operator)) {
			for (int i = 0; i < requestEvent.getContainerIDs().size(); i++) {

				String moveType = requestEvent.getMoveType();
				String qcNo = requestEvent.getEquipmentID();
				String contrId = requestEvent.getContainerIDs().get(i);
				String fromLoc = Constants.EMPTY_STRING;
				String toLoc = Constants.EMPTY_STRING;
				String userId = requestEvent.getUserID();

				List<String> fromLocList = requestEvent.getFromLocations();
				if (null != fromLocList && !fromLocList.isEmpty()) {
					fromLoc = fromLocList.get(i);
				}

				List<String> toLocList = requestEvent.getToLocations();
				if (null != toLocList && !toLocList.isEmpty()) {
					toLoc = toLocList.get(i);
				}

				// CHE Job Done
				/**
				 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
				 * functionalities in Production deployment
				 */
				if (opusWriteStatus) {
					errorMessage = JobListUtils.processCHEJobDoneEvent(
							jobControlService, contrId, moveType, qcNo,
							fromLoc, toLoc, userId);
				}

				boolean status = null == errorMessage ? true : false;
				ContainerMoveResponseEvent responseEvent = new ContainerMoveResponseEvent();
				responseEvent.setUserID(requestEvent.getUserID());
				responseEvent.setEquipmentID(requestEvent.getEquipmentID());
				responseEvent.setTerminalID(requestEvent.getTerminalID());
				responseEvent.setEventID(requestEvent.getEventID());
				responseEvent.setContainerId(contrId);
				responseEvent.setStatus(status);
				responseEvent.setMoveType(requestEvent.getMoveType());

				responseEvent.setPreJobConfirmation(requestEvent
						.isPreJobConfirmation());
				responseEvent.setErrorMessage(errorMessage);

				LOGGER.info(operator
						+ " Container Move Response Event with EquipmentID: "
						+ requestEvent.getEquipmentID()
						+ " sent to RDT server: " + responseEvent);
				exchange.getOut().setBody(responseEvent);
				OpusCommonUtils.send(exchange);
			}
		} else {
			// QC/HC/ITV Job confirmation
			if (writeQcJobConfirmationStatus && opusWriteStatus) {
				atomResultJobDoneList = JobListUtils.processJobDoneByQcList(
						jobControlService, requestEvent);

				for (AtomResultJobDone jobDoneResponse : atomResultJobDoneList) {

					errorMessage = OpusCommonUtils
							.getOPUSErrorMessage(jobDoneResponse.getRsltCode()
									.trim());

					boolean jobDoneStatus = null == errorMessage ? true : false;

					ContainerMoveResponseEvent responseEvent = new ContainerMoveResponseEvent();
					responseEvent.setUserID(requestEvent.getUserID());
					responseEvent.setEquipmentID(requestEvent.getEquipmentID());
					responseEvent.setTerminalID(requestEvent.getTerminalID());
					responseEvent.setEventID(requestEvent.getEventID());
					responseEvent.setMoveType(requestEvent.getMoveType());

					responseEvent.setPreJobConfirmation(requestEvent
							.isPreJobConfirmation());
					responseEvent.setErrorMessage(errorMessage);
					responseEvent.setContainerId(jobDoneResponse.getCntrNo());
					responseEvent.setStatus(jobDoneStatus);
					LOGGER.info(operator
							+ " Container Move Response Event with EquipID:  "
							+ requestEvent.getEquipmentID()
							+ " sent to RDT :  " + responseEvent);
					exchange.getOut().setBody(responseEvent);
					OpusCommonUtils.send(exchange);
				}
			} else {
				for (int i = 0; i < requestEvent.getContainerIDs().size(); i++) {
					ContainerMoveResponseEvent responseEvent = new ContainerMoveResponseEvent();
					responseEvent.setUserID(requestEvent.getUserID());
					responseEvent.setEquipmentID(requestEvent.getEquipmentID());
					responseEvent.setTerminalID(requestEvent.getTerminalID());
					responseEvent.setEventID(requestEvent.getEventID());
					responseEvent.setMoveType(requestEvent.getMoveType());

					responseEvent.setPreJobConfirmation(requestEvent
							.isPreJobConfirmation());
					responseEvent.setErrorMessage(errorMessage);
					responseEvent.setContainerId(requestEvent.getContainerIDs()
							.get(i));
					responseEvent.setStatus(true);

					LOGGER.info(operator
							+ " Auto-Confirmed without OPUS write back:  "
							+ requestEvent.getEquipmentID() + " sent to RDT:  "
							+ responseEvent);
					exchange.getOut().setBody(responseEvent);
					OpusCommonUtils.send(exchange);
				}
			}
		}
	}

	/**
	 * CHE Job selection for picked container.
	 * 
	 * @param exchange
	 */
	public void processJobSelection(Exchange exchange) {
		JobSelectionEvent requestEvent = (JobSelectionEvent) exchange 
				.getProperty(Constants.JOB_SELECTION_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);

		LOGGER.info(operator + " JobSelectionEvent processing..."
				+ requestEvent);

		String sprdPos = Constants.SPREADER_POSITION_LEFT;
		String mchnId = requestEvent.getEquipmentID();
		String mchnTp = OpusCommonUtils.getMachineType(operator);
		String cntrNo = requestEvent.getContainerId();
		String moveKind = requestEvent.getMoveType();
		String locTp = null;
		String blck = null;
		String bay = null;
		String row = null;
		String tier = null;
		String userId = requestEvent.getUserID();

		String errorMessage = null;
		String jobSelectionStatusResponse = null;
		String responseCode = null;
		boolean isSuccess = true;

		try {
			if (requestEvent.getLocation() != null) {
				BlockVesselLocations blockVesselLoc = OpusCommonUtils
						.getSplitLocationValues(requestEvent.getLocation());
				blck = blockVesselLoc.getBlck();
				bay = blockVesselLoc.getBay();
				row = blockVesselLoc.getRow();
				tier = blockVesselLoc.getTier();
			}
			locTp = OpusCommonUtils.getLocationType(moveKind);
		} catch (Exception e1) {
			LOGGER.error("Exception while getting location: ", e1);
		}

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {

			try {

				AtomPickedContainer leftPickedContainer = new AtomPickedContainer();
				AtomPickedContainer rightPickedContainer = new AtomPickedContainer();

				leftPickedContainer.setSprdPos(sprdPos);
				leftPickedContainer.setMchnId(mchnId);
				leftPickedContainer.setMchnTp(mchnTp);
				leftPickedContainer.setCntrNo(cntrNo);
				leftPickedContainer.setLocTp(locTp);
				leftPickedContainer.setBlck(blck);
				leftPickedContainer.setBay(bay);
				leftPickedContainer.setRow(row);
				leftPickedContainer.setTier(tier);
				leftPickedContainer.setUsrId(userId);
				LOGGER.info("Calling OPUS API setPickedContainer(). LeftPickedContainer: "
						+ leftPickedContainer.toString()
						+ " , RightPickedContainer: "
						+ rightPickedContainer.toString());
				
				responseCode = jobControlService
						.setPickedContainer(leftPickedContainer,
								rightPickedContainer);

			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("setPickedContainer()",
						mchnId, userId, null);
				LOGGER.error(
						"Exception occured while processing Job selection: ", e);
			}
			
			jobSelectionStatusResponse = OpusCommonUtils
					.getJobSelectionStatusResponseCode(responseCode);
			LOGGER.info("setPickedContainer() response received from OPUS ReasonCode: "
					+ responseCode + " : " + jobSelectionStatusResponse);

			/**
			 * 10/08/2017 : As per sanjay suggestion added S2 as success for shuffle job 
			 */
			
			if (!(JobSelectionStatusEnum.S1.name()
					.equalsIgnoreCase(responseCode.trim())
					|| JobSelectionStatusEnum.S2.name().equalsIgnoreCase(
							responseCode.trim()))) {
				errorMessage = jobSelectionStatusResponse;
				isSuccess = false;
			}

			if (requestEvent.isJobListRefreshRequired()) {
				sendCHEJobListRequest(requestEvent,exchange);
			}
		} 
		LOGGER.info(operator + " Job Selection status received from OPUS :  "
				+ jobSelectionStatusResponse + " , and Status: " + isSuccess);

		JobSelectionResponseEvent responseEvent = new JobSelectionResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setErrorMessage(errorMessage);
		responseEvent.setSuccess(isSuccess);
		responseEvent.setMoveType(moveKind);
		responseEvent.setContainerId(cntrNo);

		LOGGER.info(operator + " JobSelection ResponseEvent sent to RDT :  "
				+ responseEvent);

		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * Change the status(Processing, Inactive) of job.
	 * 
	 * @param exchange
	 */
	public void processJobStatus(Exchange exchange) {
		CancelJobSelectionEvent requestEvent = (CancelJobSelectionEvent) exchange
				.getProperty(Constants.CANCEL_JOB_SELECT_EVENT);
		LOGGER.info("Processing CancelJobSelectionEvent... " + requestEvent);

		boolean isSuccess = true;
		String jobStatus = null;
		String responseCode = null;
		String errorMessage = null;

		List<String> jobKeyLists = requestEvent.getJobKey();
		String jobStatusType = "A";
		String equipId = requestEvent.getEquipmentID();
		String userId = requestEvent.getUserID();

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {

			try {
				LOGGER.info("Calling OPUS API setJobStatus(). EquipID: "
						+ equipId + ", UserId: " + userId + ", JobKeys:  "
						+ jobKeyLists + ", JobStatusType : " + jobStatusType);
				jobStatus = jobControlService.setJobStatus(jobKeyLists,
						jobStatusType, equipId, userId);
				responseCode = OpusCommonUtils
						.getJobStatusResponseCode(jobStatus);
				LOGGER.info("Response received from OPUS- setJobStatus() API.jobStatus: "
						+ jobStatus
						+ " , responseCode: "
						+ responseCode
						+ " for EquipID: "
						+ equipId
						+ " , UserId: "
						+ userId
						+ " , JobKeys: "
						+ jobKeyLists
						+ " , JobStatusType: "
						+ jobStatusType);

				if (Constants.S1.equalsIgnoreCase(jobStatus)) {
					isSuccess = true;
				} else {
					errorMessage = responseCode;
				}
			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("setJobStatus()", equipId,
						userId, null);
				LOGGER.info("Exception occured while processing job status : ",
						e);
				isSuccess = false;
			}
		} else {
			isSuccess = true;
		}

		CancelJobSelectionResponseEvent responseEvent = new CancelJobSelectionResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setSuccess(isSuccess);
		responseEvent.setErrorMessage(errorMessage);
		responseEvent.setContainerId(requestEvent.getContainerId());

		LOGGER.info("CHE CancelJobSelection Response Event sent to RDT :  "
				+ responseEvent);

		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * Inventory update for container location Event
	 * 
	 * @param exchange
	 */
	public void processCHEInventoryUpdate(Exchange exchange) {

		InventoryUpdateRequestEvent requestEvent = (InventoryUpdateRequestEvent) exchange
				.getProperty(Constants.INVENTORY_UPDATE_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);
		String errorMessage = null;

		LOGGER.info(operator + " Processing InventoryUpdateRequestEvent: "
				+ requestEvent);

		String moveType = requestEvent.getMoveType();
		String qcNo = requestEvent.getEquipmentID();
		String contrId = requestEvent.getContainerId();
		String fromLoc = requestEvent.getFromLocation();
		String toLoc = requestEvent.getToLocation();
		String userId = requestEvent.getUserID();
		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			errorMessage = JobListUtils.processCHEJobDoneEvent(
					jobControlService, contrId, moveType, qcNo, fromLoc, toLoc,
					userId);
		}
		boolean inventoryStatus = null == errorMessage ? true : false;

		InventoryUpdateResponseEvent responseEvent = new InventoryUpdateResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setInventoryStatus(inventoryStatus);
		responseEvent.setContainerId(requestEvent.getContainerId());
		responseEvent.setErrorMessage(errorMessage);

		LOGGER.info(operator + " InventoryUpdateResponseEvent with EquipID: "
				+ requestEvent.getEquipmentID() + ", sent to RDT: "
				+ responseEvent);
		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * Change the container position on chassis.
	 * 
	 * @param exchange
	 */
	public void processSwapRequest(Exchange exchange) {

		SwapRequestEvent requestEvent = (SwapRequestEvent) exchange
				.getProperty(Constants.SWAP_EVENT);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);

		LOGGER.info(operator + " Processing SwapRequestEvent: " + requestEvent);

		List<SwapContainerPosition> containerPositionList = requestEvent
				.getSwapContainers();

		List<SwapContainerPosition> containerPositionResponseList = new ArrayList<SwapContainerPosition>();
		String equipId = requestEvent.getEquipmentID();
		String usrId = requestEvent.getUserID();

		for (SwapContainerPosition containerPosition : containerPositionList) {
			String jobKey = containerPosition.getJobKey();
			String positionOnChassis = containerPosition.getPositionOnChassis();
			String ytNo = containerPosition.getItvId();

			SwapContainerPosition contrPositionResponse = new SwapContainerPosition();
			boolean status = false;

			/**
			 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
			 * functionalities in Production deployment
			 */
			if (opusWriteStatus) {
				try {
					LOGGER.info("Calling changePositionOnChassis() API to OPUS. jobKey: "
							+ jobKey
							+ ", ytNo"
							+ ytNo
							+ ", positionOnChassis "
							+ positionOnChassis + ", usrId" + usrId);
					status = jobControlService.changePositionOnChassis(jobKey,
							ytNo, positionOnChassis, usrId);

					LOGGER.info("Status received on changePositionOnChassis() API from OPUS jobKey: "
							+ jobKey
							+ " , ytNo"
							+ ytNo
							+ " , positionOnChassis "
							+ positionOnChassis
							+ " , usrId" + usrId + " " + "Status is: " + status);

				} catch (Exception e) {
					AlertEventUtils.raiseAPIAlertEvent(
							"changePositionOnChassis()", equipId, usrId, null);
					LOGGER.info(
							"Exception occured while processSwapRequest : ", e);
				}
			} else {
				status = true;
			}

			contrPositionResponse.setContainerId(containerPosition
					.getContainerId());
			contrPositionResponse.setStatus(status);

			containerPositionResponseList.add(contrPositionResponse);
		}

		SwapResponseEvent responseEvent = new SwapResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setSwapContainerList(containerPositionResponseList);

		LOGGER.info(operator + " SwapResponseEvent with EquipID: " + equipId
				+ " sent to RDT: " + responseEvent);
		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * 
	 * @param exchange
	 */
	public void processOutOfListContainerInquiry(Exchange exchange) {

		OutOfListContainersRequestEvent requestEvent = (OutOfListContainersRequestEvent) exchange
				.getProperty(Constants.OUTOFLIST_CONTR_INQUIRY_EVENT);

		OutOfListContainerResponseEvent responseEvent = new OutOfListContainerResponseEvent();

		List<JobListContainerDetails> jobListContainerDtls = new ArrayList<JobListContainerDetails>();
		List<JobListContainer> outOfListContainers = new ArrayList<JobListContainer>();

		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);
		LOGGER.info(operator + " Processing OutOfListContainersRequestEvent: "
				+ requestEvent);

		String equipId = requestEvent.getEquipmentID();
		String machineType = OpusCommonUtils.getMachineType(operator);

		try {
			List<AtomVmtWorkOrder> atomVmtWorkOrderList = jobControlService
					.getJobOrderByContainer(requestEvent.getCntrKey());
			jobListContainerDtls = JobListUtils.getJobContrList(
					atomVmtWorkOrderList, machineType);
		} catch (Exception e) {
			AlertEventUtils.raiseAPIAlertEvent("getJobOrderList()", equipId,
					requestEvent.getUserID(), null);
			LOGGER.info(
					"Exception occured while processOutOfListContainerInquiry : ",
					e);
		}

		for (JobListContainerDetails jobListContainerDetails : jobListContainerDtls) {
			JobListContainer jobListContainer = new JobListContainer();
			Container container = new Container();

			container.setContainerID(jobListContainerDetails.getContainerId());
			container.setIsoCode(jobListContainerDetails.getIso());
			container.setPod(jobListContainerDetails.getPod());
			container.setWeight(jobListContainerDetails.getWt());
			container.setCategory(jobListContainerDetails.getContrCategory());
			container.setSize(jobListContainerDetails.getContrLength());

			boolean isEmpty = Constants.EMPTY
					.equalsIgnoreCase(jobListContainerDetails.getContrStatus()) ? true
					: false;
			container.setEmpty(isEmpty);

			jobListContainer.setContainer(container);
			jobListContainer.setContainerId(jobListContainerDetails
					.getContainerId());

			jobListContainer.setMoveType(jobListContainerDetails.getMoveType());
			jobListContainer.setFromLocation(jobListContainerDetails
					.getFromLocation());
			jobListContainer.setToLocation(jobListContainerDetails
					.getToLocation());
			jobListContainer.setVesselName(jobListContainerDetails.getVessel());
			jobListContainer.setVoyage(jobListContainerDetails.getVoyage());
			jobListContainer.setTwinContainerId(jobListContainerDetails
					.getTwinTandemID());
			jobListContainer.setJobKey(jobListContainerDetails.getJobKey());
			outOfListContainers.add(jobListContainer);
		}

		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());

		responseEvent.setOutOfListContainers(outOfListContainers);

		LOGGER.info("JobList Response Event sending to RDT -->" + responseEvent);
		exchange.getOut().setBody(responseEvent);
	}

	/**
	 * 
	 * @param exchange
	 */
	public void processShuffleContrLocation(Exchange exchange) {
		ShuffleRequestEvent requestEvent = (ShuffleRequestEvent) exchange
				.getProperty(Constants.SHUFFLE_CONTR_LOCATION);
		String operator = (String) exchange.getProperty(Constants.QUEUE_NAME);

		LOGGER.info(operator + " ShuffleRequestEvent processing..."
				+ requestEvent);
		String errorMessage = null;
		String jobSelectionStatusResponse = null;
		String responseCode = null;
		boolean isSuccess = true;
		String cntrNo = requestEvent.getContainerId();
		String moveKind = requestEvent.getMoveType();

		/**
		 * Changed by Annapurna on 11/05/2017: Disable OPUS Write back
		 * functionalities in Production deployment
		 */
		if (opusWriteStatus) {
			String sprdPos = Constants.SPREADER_POSITION_LEFT;
			String mchnId = requestEvent.getEquipmentID();
			String mchnTp = OpusCommonUtils.getMachineType(operator);
			
			String locTp = null;
			String blck = null;
			String bay = null;
			String row = null;
			String tier = null;
			String userId = requestEvent.getUserID();

			try {
				if (requestEvent.getFromLocation() != null) {
					BlockVesselLocations blockVesselLoc = OpusCommonUtils
							.getSplitLocationValues(requestEvent.getFromLocation());
					blck = blockVesselLoc.getBlck();
					bay = blockVesselLoc.getBay();
					row = blockVesselLoc.getRow();
					tier = blockVesselLoc.getTier();
				}
				
			 locTp = OpusCommonUtils.getLocationType(moveKind);
			} catch (Exception e1) {
				LOGGER.error("Exception while getting location: ", e1);
			}

			try {

				AtomPickedContainer leftPickedContainer = new AtomPickedContainer();
				AtomPickedContainer rightPickedContainer = new AtomPickedContainer();

				leftPickedContainer.setSprdPos(sprdPos);
				leftPickedContainer.setMchnId(mchnId);
				leftPickedContainer.setMchnTp(mchnTp);
				leftPickedContainer.setCntrNo(cntrNo);
				leftPickedContainer.setLocTp(locTp);
				leftPickedContainer.setBlck(blck);
				leftPickedContainer.setBay(bay);
				leftPickedContainer.setRow(row);
				leftPickedContainer.setTier(tier);
				leftPickedContainer.setUsrId(userId);
				LOGGER.info("Calling OPUS API setPickedContainer(). LeftPickedContainer: "
						+ leftPickedContainer.toString()
						+ " , RightPickedContainer: "
						+ rightPickedContainer.toString());
				responseCode = jobControlService
						.setPickedContainer(leftPickedContainer,
								rightPickedContainer);

			} catch (Exception e) {
				AlertEventUtils.raiseAPIAlertEvent("setPickedContainer()",
						mchnId, userId, null);
				LOGGER.error(
						"Exception occured while processing Job selection: ", e);
			}
			
			jobSelectionStatusResponse = OpusCommonUtils
					.getJobSelectionStatusResponseCode(responseCode);
			LOGGER.info("setPickedContainer() response received from OPUS ReasonCode: "
					+ responseCode + " : " + jobSelectionStatusResponse);

			/**
			 * 10/08/2017 : As per sanjay suggestion added S2 as success for shuffle job 
			 */
			
			if (!(JobSelectionStatusEnum.S1.name()
					.equalsIgnoreCase(responseCode.trim())
					|| JobSelectionStatusEnum.S2.name().equalsIgnoreCase(
							responseCode.trim()))) {
				errorMessage = jobSelectionStatusResponse;
				isSuccess = false;
			}

			if (requestEvent.isJobListRefreshRequired()) {
				sendCHEJobListRequest(requestEvent,exchange);
			}
		} 
		LOGGER.info(operator + "ShuffleRequestEvent status received from OPUS :  "
				+ jobSelectionStatusResponse + " , and Status: " + isSuccess);

		ShuffleResponseEvent responseEvent = new ShuffleResponseEvent();
		responseEvent.setUserID(requestEvent.getUserID());
		responseEvent.setEquipmentID(requestEvent.getEquipmentID());
		responseEvent.setTerminalID(requestEvent.getTerminalID());
		responseEvent.setEventID(requestEvent.getEventID());
		responseEvent.setErrorMessage(errorMessage);
		responseEvent.setSuccess(isSuccess);
		responseEvent.setMoveType(moveKind);
		responseEvent.setContainerId(cntrNo);

		LOGGER.info(operator + " ShuffleResponseEvent sent to RDT :  "
				+ responseEvent);
		exchange.getOut().setBody(responseEvent);

	}
	
	/**
	 * 
	 * @param requestEvent
	 * @param exchange
	 */
	private void sendCHEJobListRequest(Event requestEvent, Exchange exchange){		
		/**
		 * Create joblist request and send joblist response to RDT
		 */
		CHEJobListRequestEvent cheRequestEvent = new CHEJobListRequestEvent();

		cheRequestEvent.setEquipmentID(requestEvent.getEquipmentID());
		cheRequestEvent.setEventID(requestEvent.getEventID());
		cheRequestEvent.setTerminalID(requestEvent.getUserID());
		cheRequestEvent.setUserID(requestEvent.getUserID());
		cheRequestEvent.setScheduled(true);

		String machineType = OpusCommonUtils
				.getMachineType(Constants.CHEQ);

		CHEJobListEvent cheResponseEvent = JobListUtils
				.processCHEJobListEvent(exchange, jobControlService,
						cheRequestEvent, machineType);
		LOGGER.info("CHE JobList Response Event sending to RDT -->"
				+ cheResponseEvent);

		exchange.getOut().setBody(cheResponseEvent);
		OpusCommonUtils.send(exchange);
	}	
}
