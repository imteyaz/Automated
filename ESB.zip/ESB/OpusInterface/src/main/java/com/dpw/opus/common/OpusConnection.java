package com.dpw.opus.common;

/**
 * OPUS Interface integration with API Service properties
 * @author Annapurna
 *
 */
public class OpusConnection {
    
    private String opusUrl;
    private String systemControlUrl;
    private String machineControlUrl;
    private String jobControlUrl;
    private String userControlUrl;
    private String vesselControlUrl;
    private String containerControlUrl;
    private String defineControlUrl;
    private static String writeToOpus;
    private static String writeQcJobConfirmation;
    private static String writeExchangePosition;
    
    public OpusConnection(){
        
    }
    
    public String getContainerControlUrl() {
        return containerControlUrl;
    }
    
    public void setContainerControlUrl(String containerControlUrl) {
        this.containerControlUrl = containerControlUrl;
    }

    public String getOpusUrl() {
        return opusUrl;
    }

    public void setOpusUrl(String opusUrl) {
        this.opusUrl = opusUrl;
    }

    public String getSystemControlUrl() {
        return systemControlUrl;
    }

    public void setSystemControlUrl(String systemControlUrl) {
        this.systemControlUrl = systemControlUrl;
    }

    public String getMachineControlUrl() {
        return machineControlUrl;
    }

    public void setMachineControlUrl(String machineControlUrl) {
        this.machineControlUrl = machineControlUrl;
    }

    public String getJobControlUrl() {
        return jobControlUrl;
    }

    public void setJobControlUrl(String jobControlUrl) {
        this.jobControlUrl = jobControlUrl;
    }

    public String getUserControlUrl() {
        return userControlUrl;
    }

    public void setUserControlUrl(String userControlUrl) {
        this.userControlUrl = userControlUrl;
    }

    public String getVesselControlUrl() {
        return vesselControlUrl;
    }

    public void setVesselControlUrl(String vesselControlUrl) {
        this.vesselControlUrl = vesselControlUrl;
    }

    public String getDefineControlUrl() {
        return defineControlUrl;
    }

    public void setDefineControlUrl(String defineControlUrl) {
        this.defineControlUrl = defineControlUrl;
    }

    public static String getWriteToOpus() {
        return writeToOpus;
    }

    public static void setWriteToOpus(String writeToOpus) {
        OpusConnection.writeToOpus = writeToOpus;
    }

	public static String getWriteQcJobConfirmation() {
		return writeQcJobConfirmation;
	}

	public static void setWriteQcJobConfirmation(String writeQcJobConfirmation) {
		OpusConnection.writeQcJobConfirmation = writeQcJobConfirmation;
	}

	public static String getWriteExchangePosition() {
		return writeExchangePosition;
	}

	public static void setWriteExchangePosition(String writeExchangePosition) {
		OpusConnection.writeExchangePosition = writeExchangePosition;
	}

}
