package com.dpw.opus.common;

public enum ContainerCategoryEnum {
    
    II ("Import"),
    TI ("Trashipment Import"),
    XX ("Export"),
    TX ("Transhipment Export"),
    TL ("Transshipment"),
    S1 ("Shift 1Time"),
    S2 ("Shift 2Time"),
    YY ("Storage Empty"),
    OT ("Through Cargo");
    
    private String value;

    private ContainerCategoryEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getValue();
    }

}
