package com.dpw.opus.utils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.model.AtomQcJobDone;
import com.clt.tos.external.atom.jat2.model.AtomResultJobDone;
import com.clt.tos.external.atom.jat2.model.AtomVmtWorkOrder;
import com.clt.tos.external.atom.jat2.model.AtomYcJobDone;
import com.clt.tos.external.proxy.service.JobControlService;
import com.dpw.opus.common.BlockVesselLocations;
import com.dpw.opus.common.Constants;
import com.dpw.opus.common.MachineTypesEnum;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.JobListContainerDetails;
import com.minapro.procserver.events.JobListEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.che.CHEJobListEvent;
import com.minapro.procserver.events.che.CHEJobListRequestEvent;
import com.minapro.procserver.events.itv.DriveInstructionEvent;
import com.minapro.procserver.events.itv.ITVJobListEvent;

public class JobListUtils {
    private static final Logger LOGGER = Logger.getLogger(JobListUtils.class);
    
    private JobListUtils(){
        
    }

    /**
     * Building container information from opus response(AtomVmtWorkOrder)
     * object for joblist
     * 
     * @param atomVmtWorkOrderList
     * @return
     */
    public static List<JobListContainerDetails> getJobContrList(
            List<AtomVmtWorkOrder> atomVmtWorkOrderList, String machineType) {
        List<JobListContainerDetails> jobList = new ArrayList<JobListContainerDetails>();
        try {
            if (atomVmtWorkOrderList != null && !atomVmtWorkOrderList.isEmpty()) {
                LOGGER.info("Job list response received from OPUS..."
                        + atomVmtWorkOrderList.toString());
                for (AtomVmtWorkOrder workOrder : atomVmtWorkOrderList) {
                    
                    JobListContainerDetails jobListContainerDetails = new JobListContainerDetails();

                    /* Get moveKind from OPUS provided jobTypes */
                    String moveKind = OpusCommonUtils
                            .getMoveKindForJobType(workOrder.getJobTp());
                    String fromLocation = null;
                    String toLocation = null;

                    fromLocation = OpusCommonUtils.getContainerLocation(
                            workOrder.getFmBlck(), workOrder.getFmBay(),
                            workOrder.getFmRow(), workOrder.getFmTier());
                    LOGGER.debug("Assigning fromlocation with fromlocation details: "
                            + fromLocation);

                    toLocation = OpusCommonUtils.getContainerLocation(
                            workOrder.getToBlck(), workOrder.getToBay(),
                            workOrder.getToRow(), workOrder.getToTier());
                    LOGGER.debug("Assigning toLocation with toLocation details: "
                            + toLocation);

                    /**
                     * if ytno value is available in OPUS joblist response if ytno value is available for move kinds LOAD & DSCH  
                     * 1. For CHE Joblist response for movekind DSCH/MI fromlocation = YtNo, else for movekind LOAD/MO toLocation = YtNo
                     * 2. For QC Joblist response for movekind DSCH/MI toLocation = YtNo, else for movekind LOAD/MO fromlocation = YtNo
                     */
                    if (StringUtils.isNotBlank(workOrder.getYtNo())) {
                        if (Constants.DSCH.equalsIgnoreCase(moveKind)
                                || Constants.MI.equalsIgnoreCase(moveKind)
                                || Constants.GI.equalsIgnoreCase(moveKind)) {
                            if (MachineTypesEnum.CHE.toString()
                                    .equalsIgnoreCase(machineType)) {
                            	
                                fromLocation = workOrder.getYtNo();
                            } else if (MachineTypesEnum.QC.toString()
                                    .equalsIgnoreCase(machineType)) {
                            	
                                toLocation = workOrder.getYtNo();
                            }
                           
                        } else if (Constants.LOAD.equalsIgnoreCase(moveKind)
                                || Constants.MO.equalsIgnoreCase(moveKind)
                                || Constants.GO.equalsIgnoreCase(moveKind)) {

                            if (MachineTypesEnum.CHE.toString()
                                    .equalsIgnoreCase(machineType)) {
                            	
                                toLocation = workOrder.getYtNo();
                            } else if (MachineTypesEnum.QC.toString()
                                    .equalsIgnoreCase(machineType)) {
                                fromLocation = workOrder.getYtNo();
                            }                         
                        }
                        
                        LOGGER.info(machineType+" : MachineType, assigning toLocation with ytno: "
                                + workOrder.getYtNo() + " ,toLocation:  "
                                + toLocation);
                    }

                    if (MachineTypesEnum.CHE.toString().equalsIgnoreCase(
                            machineType)
                            && (StringUtils.isNotBlank(workOrder.getYtNo()))
                            && (Constants.LOAD.equalsIgnoreCase(moveKind) || Constants.MO
                                    .equalsIgnoreCase(moveKind))) {
                        toLocation = workOrder.getYtNo();
                        LOGGER.info("Assigning toLocation with ytno: "
                                + workOrder.getYtNo() + " ,toLocation: "
                                + toLocation);
                    } 

                    jobListContainerDetails.setContainerId(workOrder.getCntrNo());
                    jobListContainerDetails.setMoveType(moveKind);
                    jobListContainerDetails.setFromLocation(fromLocation);
                    jobListContainerDetails.setToLocation(toLocation);
                    jobListContainerDetails.setTwinTandemID(workOrder.getTwnTndmKey());
                    jobListContainerDetails.setTwinTandemCd(workOrder.getTnwTndmCd());
                    jobListContainerDetails.setPod(workOrder.getPod());
                    jobListContainerDetails.setWt(workOrder.getCntrWgt());
                    jobListContainerDetails.setContrCategory(workOrder.getCls());
                    jobListContainerDetails.setContrStatus(workOrder.getFullMty());

                    jobListContainerDetails.setCntrSpTp(workOrder.getCntrSpTp());
                    jobListContainerDetails.setContrLength(workOrder.getCntrLen());
                    jobListContainerDetails.setContrHeight(workOrder.getCntrHgt());
                    jobListContainerDetails.setPlugCd(workOrder.getPlugCd());

                    jobListContainerDetails.setVessel(workOrder.getVessel());
                    jobListContainerDetails.setVoyage(workOrder.getVoyage());                   
                    jobListContainerDetails.setJobKey(workOrder.getJobKey());
                    jobListContainerDetails.setPositionOnChassis(workOrder
                            .getPositionOnChassis());
                    jobListContainerDetails.setQcID(workOrder.getQcNo());
                    jobListContainerDetails.setToLocTp(workOrder.getToLocTp());
                    jobListContainerDetails.setLaneId(workOrder.getToLocation());
                    /*Lane changes*/
                    LOGGER.debug("  before if YCNO== "
                            + workOrder.getYcNo()+"===YCNO" + " ,laneid==: "
                            + jobListContainerDetails.getLaneId()+"===workOrder.getToLocation()===="+workOrder.getToLocation());
                
                    if(StringUtils.isBlank(workOrder.getQcNo()) && StringUtils.isNotBlank(workOrder.getYcNo()) )
                    {
                    
                    	   jobListContainerDetails.setLaneId(workOrder.getAprchLn());
                    	   LOGGER.debug(" inside == "+ workOrder.getAprchLn()  +"===laneid== " );
                    	
                    }
                    /*Lane changes*/
                    jobListContainerDetails.setArrivedItv(workOrder.isArrivedItv());
                    jobListContainerDetails.setPlnSeq(workOrder.getPlnSeq());
                    jobListContainerDetails.setJobStatus(workOrder.getJobSts());
                    jobListContainerDetails.setJobQueueName(workOrder.getJbQueNm());
                    jobListContainerDetails.setJobQueueSequence(workOrder.getJbQueSeq());
                    jobListContainerDetails.setPriorityJob(workOrder.getPriorityJob());
                    jobListContainerDetails.setEtw(workOrder.getEtw());    

                    jobList.add(jobListContainerDetails);
                }
            } else {
                LOGGER.info("No JobList Response object received from OPUS AtomVmtWorkOrderList : "
                        + atomVmtWorkOrderList);
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while processing Job List: ", e);
        }

        return jobList;
    }

    /**
     * QC/HC Job list processing
     * 
     * @param jobControlService
     * @param requestEvent
     * @param machineType
     * @return
     */
    public static Exchange processJobListEvent(Exchange exchange,
            JobControlService jobControlService,
            JobListRequestEvent requestEvent, String operator) {

        String machineType = OpusCommonUtils.getMachineType(operator);
        String machineId = requestEvent.getEquipmentID();

        /** 
         * OPUS Even for HC operator QC equipmentId only considered for retrieving joblist.
         * Hence for HC operators QC equipment only assigned as machineId. 
         */
        if (MachineTypesEnum.HC.name().equalsIgnoreCase(operator)) {
            machineId = requestEvent.getQcId();
        }

        LOGGER.info("Calling OPUS API for Job list response Machine Id... "
                + machineId + "  -- " + machineType);
        List<AtomVmtWorkOrder> atomVmtWorkOrderList = new ArrayList<AtomVmtWorkOrder>();
        try {
            atomVmtWorkOrderList = jobControlService.getJobOrderList(machineId,
                    machineType);
        } catch (Exception e1) {
            AlertEventUtils.raiseAPIAlertEvent("getJobOrderList() - ", machineId,
                    null, null);
            LOGGER.info("Exception: OPUS JobList API service not available: ",e1);
        }

        List<JobListContainerDetails> jobList = JobListUtils.getJobContrList(
                atomVmtWorkOrderList, machineType);
        
        if (MachineTypesEnum.ITV.toString().equalsIgnoreCase(machineType)) {

            ITVJobListEvent itvJoblistResponseEvent = new ITVJobListEvent();
            List<DriveInstructionEvent> driveInstructionlist = new ArrayList<DriveInstructionEvent>();
            if (null != jobList && !jobList.isEmpty()) {
                driveInstructionlist = buildITVDriveInstructions(requestEvent,
                        jobList);
            } else {
                DriveInstructionEvent driveInstruction = new DriveInstructionEvent();
                driveInstruction
                        .setGeneralInstruction(Constants.GENERAL_INSTRUCTION);

                driveInstructionlist.add(driveInstruction);
            }
            itvJoblistResponseEvent.setUserID(requestEvent.getUserID());
            itvJoblistResponseEvent.setEquipmentID(requestEvent
                    .getEquipmentID());
            itvJoblistResponseEvent.setTerminalID(requestEvent.getTerminalID());
            itvJoblistResponseEvent.setEventID(requestEvent.getEventID());
            itvJoblistResponseEvent.setJobList(driveInstructionlist);

            LOGGER.debug("ITV joblist response : " + itvJoblistResponseEvent);
            exchange.setProperty(Constants.RESPONSE_EVENT,
                    itvJoblistResponseEvent);

        } else {
            JobListEvent responseEvent = new JobListEvent();
            LOGGER.info(operator + " Joblist details: " + jobList);
            try {
                DBOperationsUtil.insertJobListDetails(exchange, requestEvent,
                        jobList, operator);
            } catch (SQLException e) {
                LOGGER.error(
                        "SQLException occured while inserting QC/HC job details : ",
                        e);
            }
            responseEvent.setUserID(requestEvent.getUserID());
            responseEvent.setEquipmentID(requestEvent.getEquipmentID());
            responseEvent.setTerminalID(requestEvent.getTerminalID());
            responseEvent.setEventID(requestEvent.getEventID());
            responseEvent.setScheduled(requestEvent.isScheduled());

            LOGGER.info("QC/HC Joblist response : " + responseEvent);
            exchange.setProperty(Constants.RESPONSE_EVENT, responseEvent);
        }

        return exchange;
    }

    /**
     * CHE Job list processing
     * 
     * @param jobControlService
     * @param cheRequestEvent
     * @param machineType
     * @return
     */
    public static CHEJobListEvent processCHEJobListEvent(Exchange exchange,
            JobControlService jobControlService,
            CHEJobListRequestEvent cheRequestEvent, String machineType) {

        CHEJobListEvent responseEvent = new CHEJobListEvent();

        String machineId = cheRequestEvent.getEquipmentID();

        LOGGER.info("Calling OPUS API for Job list with MachineId : "
                + machineId + " ,MachineType: " + machineType);
        List<AtomVmtWorkOrder> atomVmtWorkOrderList = new ArrayList<AtomVmtWorkOrder>();

        try {
            atomVmtWorkOrderList = jobControlService.getJobOrderList(machineId,
                    machineType);

        } catch (Exception e1) {
            AlertEventUtils.raiseAPIAlertEvent("processCHEJobListEvent() - ", machineId,
                    null, null);
            LOGGER.error(
                    "Exception: OPUS JobList API service not available : ", e1);
        }
        LOGGER.info("CHE AtomVmtWorkOrder list response received from OPUS..."
                + atomVmtWorkOrderList);

        List<JobListContainerDetails> jobList = JobListUtils.getJobContrList(
                atomVmtWorkOrderList, machineType);
        LOGGER.info("CHE Joblist inserting into DB..." + jobList);
        try {
            DBOperationsUtil.insertCHEJobListDetails(exchange, cheRequestEvent,
                    jobList);
        } catch (SQLException e) {
            LOGGER.error("SQLException occured while inserting CHE job details : ",
                    e);
        }
        responseEvent.setUserID(cheRequestEvent.getUserID());
        responseEvent.setEquipmentID(cheRequestEvent.getEquipmentID());
        responseEvent.setTerminalID(cheRequestEvent.getTerminalID());
        responseEvent.setEventID(cheRequestEvent.getEventID());
        responseEvent.setScheduled(cheRequestEvent.isScheduled());

        LOGGER.info("CHE Joblist response Event sent back to RDT: "
                + responseEvent);

        return responseEvent;
    }

    /**
     * process JobDoneByQcList by calling OPUS interface for QC/HC/ITV operators
     * 
     * @param jobControlService
     * @param requestEvent
     * @param operator
     * @return
     */
    public static List<AtomResultJobDone> processJobDoneByQcList(
            JobControlService jobControlService, ContainerMoveEvent requestEvent) {
        List<AtomQcJobDone> atomQcJobDoneList = new ArrayList<AtomQcJobDone>();
        List<AtomResultJobDone> atomResultJobDoneList = null;
        String contrNo = null;

        for (int i = 0; i < requestEvent.getContainerIDs().size(); i++) {

            String moveKind = requestEvent.getMoveType();
            String qcNo = requestEvent.getEquipmentID();

            String position = Constants.EMPTY_STRING;
            if (null != requestEvent.getPosition()
                    && ! requestEvent.getPosition().isEmpty()) {
                position = requestEvent.getPosition().get(i);
            }

            contrNo = requestEvent.getContainerIDs().get(i);
            String fromLocation = requestEvent.getFromLocations().get(i);
            String toLocation = requestEvent.getToLocations().get(i);

            /* load - fromlocation, dish - tolocation */
            String ytNo = null;

            if (Constants.LOAD.equalsIgnoreCase(moveKind)) {
                ytNo = fromLocation;
            } else if (Constants.DSCH.equalsIgnoreCase(moveKind)) {
                ytNo = toLocation;
            }

            String positionOnChassis = null != position ? position
                    : Constants.EMPTY_STRING;

            /* if tolocation = GROUND then "AP" else "LANE" */
            String locTp = null;

            if (toLocation.equalsIgnoreCase(Constants.GROUND)) {
                locTp = Constants.AP;
                ytNo = "";
            } else {
                locTp = Constants.LANE;
            }

            /* Get Job type name for OPUS of movekind from request event */
            String jobTp = OpusCommonUtils.getJobTypeName(moveKind);

            boolean dmg = false;

            AtomQcJobDone atomQCJobDone = new AtomQcJobDone();
            atomQCJobDone.setQcNo(qcNo);
            atomQCJobDone.setYtNo(ytNo);
            atomQCJobDone.setCntrNo(contrNo);
            atomQCJobDone.setJobTp(jobTp);
            atomQCJobDone.setPositionOnChassis(positionOnChassis);
            atomQCJobDone.setLocTp(locTp);
            atomQCJobDone.setDmg(dmg);
            atomQCJobDone.setUsrId(requestEvent.getUserID());

            LOGGER.info("QC/HC Job done for AtomQcJobDone request sending to OPUS: "
                    + atomQCJobDone);
            atomQcJobDoneList.add(atomQCJobDone);
        }
        try {
            atomResultJobDoneList = jobControlService
                    .setJobDoneByQcList(atomQcJobDoneList);
        } catch (Exception e) {
            AlertEventUtils.raiseAPIAlertEvent("setJobDoneByQcList()", null,
                    requestEvent.getUserID(), contrNo);
            LOGGER.error("Exception occured while processing Job Done: ", e);
        }

        LOGGER.info("Job done status response received from OPUS :  "
                + atomResultJobDoneList);
        return atomResultJobDoneList;
    }

    /**
     * process CHEJobDoneEvent by calling OPUS interface for CHE operators
     * 
     * @param jobControlService
     * @param requestEvent
     * @param operator
     * @return
     */
    public static String processCHEJobDoneEvent(
            JobControlService jobControlService, String contrNo,
            String moveType, String ycNo, String fromLocation,
            String toLocation, String userId) {
        String reasonCode = null;

        /* In OPUS System CHE is referred as Transfer Crane */
        String ycTp = MachineTypesEnum.CHE.toString();

        /* load - toLocation, dish - fromLocation */
        String ytNo = Constants.EMPTY_STRING;

        /*
         * if - Job Type: DS, MI, GI, LC, GC YARD TPL else TPW Job Type: LD, MO,
         * GO TPW, TPL Job Type: DS, MI, GI, LC, GC YARD
         */
        String locTp = null;

        /*
         * from request fromlocation(LOAD)(GO,LD,MO)/tolocation(DISH)
         * jobtp(DS,GI,MI) fields
         */
        String blck = null;
        String bay = null;
        String row = null;
        String tier = null;

        if (Constants.LOAD.equalsIgnoreCase(moveType)
                || Constants.MO.equalsIgnoreCase(moveType)
                || Constants.GO.equalsIgnoreCase(moveType)) {

            ytNo = toLocation;

            BlockVesselLocations blockVesselLoc = OpusCommonUtils
                    .getSplitLocationValues(fromLocation);
            blck = blockVesselLoc.getBlck();
            bay = blockVesselLoc.getBay();
            row = blockVesselLoc.getRow();
            tier = blockVesselLoc.getTier();

            if (Constants.LOAD.equalsIgnoreCase(moveType)) {

                locTp = Constants.TPL;
            } else {
                locTp = Constants.TPW;
            }
        } else {
            if(!Constants.RH.equalsIgnoreCase(moveType)){
                ytNo = fromLocation;
            }
            
            locTp = Constants.YARD;

            BlockVesselLocations blockVesselLoc = OpusCommonUtils
                    .getSplitLocationValues(toLocation);
            blck = blockVesselLoc.getBlck();
            bay = blockVesselLoc.getBay();
            row = blockVesselLoc.getRow();
            tier = blockVesselLoc.getTier();
        }

        /* Jobtp=GO/GI then OT else YT */
        String ytTp = null;

        if (Constants.GO.equalsIgnoreCase(moveType)
                || Constants.GI.equalsIgnoreCase(moveType)) {
            ytTp = Constants.OT;
        } else {
            ytTp = Constants.YT;

        }

        AtomYcJobDone atomYcJobDone = new AtomYcJobDone();
        atomYcJobDone.setYcNo(ycNo);
        atomYcJobDone.setYcTp(ycTp);
        atomYcJobDone.setYtNo(ytNo);
        atomYcJobDone.setYtTp(ytTp);
        atomYcJobDone.setCntrNo(contrNo);
        atomYcJobDone.setLocTp(locTp);
        atomYcJobDone.setBlck(blck);
        atomYcJobDone.setBay(bay);
        atomYcJobDone.setRow(row);
        atomYcJobDone.setTier(tier);
        atomYcJobDone.setUsrId(userId);
        LOGGER.info("CHE Job done for atomYcJobDone request sending to OPUS: "
                + atomYcJobDone);

        try {
            reasonCode = jobControlService.setJobDone(atomYcJobDone);

        } catch (Exception e) {
            AlertEventUtils.raiseAPIAlertEvent("setJobDone()", null, userId,
                    contrNo);
            LOGGER.error("Exception occured while processing CHE Job Done: ", e);
        }

        LOGGER.info("Job done status received from OPUS:  " + reasonCode);

        return OpusCommonUtils.getOPUSErrorMessage(reasonCode.trim());
    }

    /**
     * Prepare Drive instructions for ITV job list request
     * 
     * @param requestEvent
     * @param jobList
     * @return
     */
    private static List<DriveInstructionEvent> buildITVDriveInstructions(
            JobListRequestEvent requestEvent, List<JobListContainerDetails> jobList) {
        List<DriveInstructionEvent> driveInstructionList = new ArrayList<DriveInstructionEvent>();

        for (JobListContainerDetails jobContainer : jobList) {
            DriveInstructionEvent driveInstruction = new DriveInstructionEvent();
            String action = null;
            String locationId = null;
            String laneId = null;

            String qcId = jobContainer.getQcID();
            String locationType = jobContainer.getToLocTp();
            String moveKind = jobContainer.getMoveType();
            String toLocation = jobContainer.getToLocation();
            /**
             * String fromLocation = jobContainer.getFromLocation();
             */

            driveInstruction.setEquipmentID(requestEvent.getEquipmentID());
            driveInstruction.setUserID(requestEvent.getUserID());

            driveInstruction.setContainerID(jobContainer.getContainerId());
            driveInstruction.setMoveType(jobContainer.getMoveType());
            driveInstruction.setLength(jobContainer.getContrLength());
            
            /**
             * By default LocationId for ITV should instruction to toLocation field of OPUS.
             */
            locationId = toLocation;

            /**
             * If action type is "carry" then set toLocation to drive
             * instruction location field, else "fetch" set fromLocation. If
             * both tolocation and from location is null then set general
             * instruction for ITV
             */
            
            if (Constants.DSCH.equalsIgnoreCase(moveKind)) {
                if (Constants.LANE.equals(locationType)) {
                    action = Constants.FETCH;
                    locationId = qcId;
                    laneId = jobContainer.getLaneId();
                } else {
                    action = Constants.CARRY;
                }
            } else if (Constants.LOAD.equalsIgnoreCase(moveKind)) {
                if (StringUtils.isNotBlank(qcId)
                        || Constants.LANE.equals(locationType)) {
                    action = Constants.CARRY;
                    locationId = qcId;
                    laneId = jobContainer.getLaneId();
                } else {
                    action = Constants.FETCH;
                }
            } else if (Constants.MO.equalsIgnoreCase(moveKind)) {
                action = Constants.FETCH;
                /**
                 * Changed by Annapurna As per 06/07/2017 discussion on production issues ITV is not getting GOTO location.
                 * Root cause: OPUS interface initially sent fromLocation for MO, 
                 * After production deployment OPUS changed sending location in toLocation fields for MO move type. 
                 * Changes: locationId = fromLocation; changed to locationId = toLocation;
                 */                

            } else if (Constants.MI.equalsIgnoreCase(moveKind)) {
                action = Constants.CARRY;                
            }

            driveInstruction.setLocationID(locationId);
            driveInstruction.setAction(action);
            driveInstruction.setLaneID(laneId);
            /*Lane Related changes*/
            if( laneId==null) 
            {
            	driveInstruction.setLaneID(jobContainer.getLaneId());
          
            }
            /*Lane Related changes*/
            /**
             * Fore or Aft Flag e.g) Fore="F", Aft="A", Center="C", otherwise:""
             */
            driveInstruction.setPosition(jobContainer.getPositionOnChassis());

            /**
             * Job Flag of Twin/Tandem/Single Single Job :"S" Twin Job : "W"
             * Tandem Job: "M"
             */
            driveInstruction.setTnwTndmCd(jobContainer.getTwinTandemCd());
            driveInstruction.setJobKey(jobContainer.getJobKey());
            
            /**
             * ‘isArrivedItv’ field in joblist. If the value is true, ITV is arrived
             */
            driveInstruction.setArrived(jobContainer.isArrivedItv());

            driveInstructionList.add(driveInstruction);
        }

        return driveInstructionList;
    }
}
