package com.dpw.opus.utils;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Timestamp;

public class DateUtils {

    private static SimpleDateFormat dateFormat = new SimpleDateFormat(
            "dd/MMM/yyyy");

    private static SimpleDateFormat dateTimeformatter = new SimpleDateFormat(
            "dd/MMM/yyyy hh:mm:ss");

    private DateUtils() {

    }

    public static Date getCurrentDate() {
        java.util.Date today = new java.util.Date();
        return new Date(today.getTime());
    }

    public static String parseDate(java.util.Date currentDate) {
        String date = dateFormat.format(currentDate);
        return date.toUpperCase();
    }

    public static String addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        // minus number would decrement the days
        cal.add(Calendar.DATE, days);
        return parseDate(cal.getTime());
    }

    public static Timestamp getCurrentTimestamp() {
        java.util.Date today = new java.util.Date();
        return new Timestamp(today.getTime());
    }

    public static Timestamp parseStringToTimestamp(String currentDate)
            throws ParseException {
        Timestamp dateTime = null;
        java.util.Date date = dateTimeformatter.parse(currentDate);
        dateTime = new Timestamp(date.getTime());
        return dateTime;
    }
}
