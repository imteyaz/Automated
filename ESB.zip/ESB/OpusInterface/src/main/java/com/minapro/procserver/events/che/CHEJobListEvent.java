package com.minapro.procserver.events.che;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;
import com.minapro.procserver.events.JobListContainer;

public class CHEJobListEvent extends Event implements Serializable{
    private static final long serialVersionUID = 5488653592556588619L;

    /**
     * List of <Container> details fetched from DPW IT System
     */
    private List<JobListContainer> jobList;

    /**
     * Planned moves fetched from DPW IT System
     */
    private String plannedMoves;

    /**
     * Indicates whether the response is for the scheduled request
     */
    private boolean isScheduled;
    
    /**
     * error/display reason received from SPARCS system
     */
    private String reason;

    public List<JobListContainer> getJobList() {
        return jobList;
    }

    public void setJobList(List<JobListContainer> jobList) {
        this.jobList = jobList;
    }

    public String getPlannedMoves() {
        return plannedMoves;
    }

    public void setPlannedMoves(String plannedMoves) {
        this.plannedMoves = plannedMoves;
    }

    public boolean isScheduled() {
        return isScheduled;
    }

    public void setScheduled(boolean isScheduled) {
        this.isScheduled = isScheduled;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "CHEJobListEvent [jobList=" + jobList + ", plannedMoves="
                + plannedMoves + ", isScheduled=" + isScheduled + ", reason="
                + reason + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getTimeStamp()="
                + getTimeStamp() + ", getEventID()=" + getEventID()
                + ", geEventType()=" + geEventType() + "]";
    }
}
