package com.minapro.procserver.events.test;

import java.io.Serializable;

public class TestRequestEvent implements Serializable{
    
    private static final long serialVersionUID = 1L;
    private String input;

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    @Override
    public String toString() {
        return "TestRequestEvent [input=" + input + "]";
    }
}
