package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject which handles the update container attribute response from the operator
 * 
 * @author Annapurna Pujari
 * 
 */

public class UpdateContainerResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -6275624399291872260L;
    
    /**
     * Unique Container ID
     */
    private String containerID;  
    
    /**
     * Indicates whether the request was successful or not
     */
    private boolean isSuccess;
    
    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    @Override
    public String toString() {
        return "UpdateContainerResponseEvent [containerID=" + containerID
                + ", isSuccess=" + isSuccess + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getEventID()="
                + getEventID() + "]";
    }
}
