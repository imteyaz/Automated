package com.minapro.esb.common;

import org.apache.camel.Exchange;

public class ExchangeRepo {

    private static Exchange exchange;

    private ExchangeRepo() {

    }

    public static Exchange getExchange() {
        return exchange;
    }

    public static void setExchange(Exchange exchange) {
        ExchangeRepo.exchange = exchange;
    }

}
