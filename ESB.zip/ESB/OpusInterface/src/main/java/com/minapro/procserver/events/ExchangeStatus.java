package com.minapro.procserver.events;

import java.io.Serializable;

public class ExchangeStatus implements Serializable{

    private static final long serialVersionUID = 8286579587037553283L;

    private String containerId;
    
    private boolean status;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ExchangeStatus [containerId=" + containerId + ", status="
                + status + "]";
    }       
}
