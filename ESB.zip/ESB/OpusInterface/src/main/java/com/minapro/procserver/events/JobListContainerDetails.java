package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.Arrays;

/**
 * ValueObject holding the container details related to the Job list from ESB
 * 
 * @author Rosemary George
 * 
 */
public class JobListContainerDetails implements Serializable, Comparable<JobListContainerDetails> {
    private static final long serialVersionUID = 5449177895010357182L;

    private String containerId;
    /**
     * The source location of the container In case of Load operation, this contains the yard location In case of
     * discharge operation, this contains the vessel location
     */
    private String fromLocation;
    /**
     * The destination location In case of Load operation, this contains the vessel location In case of discharge
     * operation, this contains the yard location
     */
    private String toLocation;
    /**
     * Indicates whether it is L(load) or D(discharge) operation.
     */
    private String moveType;
    /**
     * Contains a containerID reference if it is a twin job
     */
    private String twinContainerId;
    /**
     * Indicates whether the handling of container is overridden by the operator. In such case, the SPARCS update is
     * ignored. Generally happens for twin/ splitting twin or tandem cases
     */
    private boolean isManuallyOverridden = false;

    /**
     * Contains the containerIDs which have been marked as TANDEM with this container. This can contain 2 to 4 container
     * IDs. Four 20" containers or Two 40" containers or two 20" container plus one 40" container is treated as TANDEM
     */
    private String[] tandemContainerIDs;
    
    private String wt;  
    private String cntrSpTp;
    private String pod;
    private String contrLength;
    private String contrHeight;
    private String plugCd ;
    private String contrCategory;
    
    private String contrStatus;    
    private String iso;
    private String twinTandemID;
    private String twinTandemCd ;   
    
    private String vessel; 
    private String voyage;
    private String jobQueueSequence;
    private String jobQueueName;
  

    /**
     * Jobkey ex., FCIU2419980120161124111708 formed from OPUS interface
     */
    private String jobKey;
    
    /**
     * Fore or Aft Flag e.g) Fore="F",  Aft="A",  Center="C", otherwise:""
     */
    private String positionOnChassis;
    
    private String qcID;
    
    /**
     * To Location Type
     * [Quay Side] VESSEL, AP, LANE
     * [Yard] YARD, TPW, TPL, GATE
     * [ETC] UNDEFINED
     */
    private String toLocTp;
    
    /**
     * To location has QC lane number where ITV has to arrive 
     * LANE(STS) : Lane Number
     * YARD(RTG,RMGC) : W (Water-Side), L (Land-Side)
     */
    private String laneId;
    
    /**
     * If the value is true, ITV is arrived. false then ITV not arrived.
     */
    private boolean arrivedItv;    
    
    /**
     * OPUS Plan Sequence
     */
    private String plnSeq;
    
    /**
     * OPUS Job status
     */
    private String jobStatus;
    
    /**
     * CHE priority Job
     */
    private String priorityJob;
    
    /**
     * Work Estimate Date-Time
     */
    private String etw;
    
    public String getJobQueueSequence() {
        return jobQueueSequence;
    }

    public void setJobQueueSequence(String jobQueueSequence) {
        this.jobQueueSequence = jobQueueSequence;
    }

    public String getJobQueueName() {
        return jobQueueName;
    }

    public void setJobQueueName(String jobQueueName) {
        this.jobQueueName = jobQueueName;
    }

    public String[] getTandemContainerIDs() {
        return tandemContainerIDs;
    }

    public void setTandemContainerIDs(String[] tandemContainerIDs) {
        this.tandemContainerIDs = tandemContainerIDs;
    }

    public boolean isManuallyOverridden() {
        return isManuallyOverridden;
    }

    public void setManuallyOverridden(boolean isManuallyOverridden) {
        this.isManuallyOverridden = isManuallyOverridden;
    }

    public String getTwinContainerId() {
        return twinContainerId;
    }

    public void setTwinContainerId(String twinContainerId) {
        this.twinContainerId = twinContainerId;
    }

    public String getFromLocation() {
        return fromLocation;
    }

    public void setFromLocation(String fromLocation) {
        this.fromLocation = fromLocation;
    }

    public String getToLocation() {
        return toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }   
   
    public String getWt() {
        return wt;
    }

    public void setWt(String wt) {
        this.wt = wt;
    }

    public String getCntrSpTp() {
        return cntrSpTp;
    }

    public void setCntrSpTp(String cntrSpTp) {
        this.cntrSpTp = cntrSpTp;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getContrLength() {
        return contrLength;
    }

    public void setContrLength(String contrLength) {
        this.contrLength = contrLength;
    }

    public String getContrHeight() {
        return contrHeight;
    }

    public void setContrHeight(String contrHeight) {
        this.contrHeight = contrHeight;
    }

    public String getPlugCd() {
        return plugCd;
    }

    public void setPlugCd(String plugCd) {
        this.plugCd = plugCd;
    }

    public String getContrCategory() {
        return contrCategory;
    }

    public void setContrCategory(String contrCategory) {
        this.contrCategory = contrCategory;
    }

    public String getContrStatus() {
        return contrStatus;
    }

    public void setContrStatus(String contrStatus) {
        this.contrStatus = contrStatus;
    }

    public String getIso() {
        return iso;
    }

    public void setIso(String iso) {
        this.iso = iso;
    }

    public String getTwinTandemID() {
        return twinTandemID;
    }

    public void setTwinTandemID(String twinTandemID) {
        this.twinTandemID = twinTandemID;
    }

    public String getTwinTandemCd() {
        return twinTandemCd;
    }

    public void setTwinTandemCd(String twinTandemCd) {
        this.twinTandemCd = twinTandemCd;
    }

    public String getVessel() {
        return vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }

    public String getVoyage() {
        return voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getJobKey() {
        return jobKey;
    }

    public void setJobKey(String jobKey) {
        this.jobKey = jobKey;
    }

    public String getPositionOnChassis() {
        return positionOnChassis;
    }

    public void setPositionOnChassis(String positionOnChassis) {
        this.positionOnChassis = positionOnChassis;
    }

    public String getQcID() {
        return qcID;
    }

    public void setQcID(String qcID) {
        this.qcID = qcID;
    }

    public String getToLocTp() {
        return toLocTp;
    }

    public void setToLocTp(String toLocTp) {
        this.toLocTp = toLocTp;
    }
    
    public String getLaneId() {
        return laneId;
    }

    public void setLaneId(String laneId) {
        this.laneId = laneId;
    }

    public boolean isArrivedItv() {
        return arrivedItv;
    }

    public void setArrivedItv(boolean arrivedItv) {
        this.arrivedItv = arrivedItv;
    }    

    public String getPlnSeq() {
        return plnSeq;
    }

    public void setPlnSeq(String plnSeq) {
        this.plnSeq = plnSeq;
    }
    
    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }  

    public String getPriorityJob() {
		return priorityJob;
	}

	public void setPriorityJob(String priorityJob) {
		this.priorityJob = priorityJob;
	}

	public String getEtw() {
		return etw;
	}

	public void setEtw(String etw) {
		this.etw = etw;
	}

	/**
     * <p>
     * Compares the instance with another Container. Compares the following attributes to declare the objects as equal.
     * <p>
     * 
     * <p>
     * container ID
     * </P>
     * <p>
     * fromLocation
     * </p>
     * <p>
     * toLocation
     * </P>
     * <p>
     * Twin Container ID
     * </P>
     * 
     * <p>
     * Returns 0 if all these attributes are same, else returns 1
     */
    @Override
    public int compareTo(JobListContainerDetails joblistContainer) {
        if (this.containerId.equals(joblistContainer.getContainerId())
                && this.fromLocation.equals(joblistContainer.getFromLocation())
                && this.toLocation.equals(joblistContainer.getToLocation())
                && ((this.twinContainerId == null && joblistContainer.getTwinContainerId() == null) || (this.twinContainerId != null && this.twinContainerId
                        .equals(joblistContainer.getTwinContainerId())))) {
            return 0;
        } else {
            return 1;
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((containerId == null) ? 0 : containerId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        JobListContainerDetails other = (JobListContainerDetails) obj;
        if (containerId == null) {
            if (other.containerId != null) {
                return false;
            }
        } else if (!containerId.equals(other.containerId)) {
            return false;
        }
        return true;
    }

	@Override
	public String toString() {
		return "JobListContainerDetails [containerId=" + containerId
				+ ", fromLocation=" + fromLocation + ", toLocation="
				+ toLocation + ", moveType=" + moveType + ", twinContainerId="
				+ twinContainerId + ", isManuallyOverridden="
				+ isManuallyOverridden + ", tandemContainerIDs="
				+ Arrays.toString(tandemContainerIDs) + ", wt=" + wt
				+ ", cntrSpTp=" + cntrSpTp + ", pod=" + pod + ", contrLength="
				+ contrLength + ", contrHeight=" + contrHeight + ", plugCd="
				+ plugCd + ", contrCategory=" + contrCategory
				+ ", contrStatus=" + contrStatus + ", iso=" + iso
				+ ", twinTandemID=" + twinTandemID + ", twinTandemCd="
				+ twinTandemCd + ", vessel=" + vessel + ", voyage=" + voyage
				+ ", jobQueueSequence=" + jobQueueSequence + ", jobQueueName="
				+ jobQueueName + ", jobKey=" + jobKey + ", positionOnChassis="
				+ positionOnChassis + ", qcID=" + qcID + ", toLocTp=" + toLocTp
				+ ", laneId=" + laneId + ", arrivedItv=" + arrivedItv
				+ ", plnSeq=" + plnSeq + ", jobStatus=" + jobStatus
				+ ", priorityJob=" + priorityJob + ", etw=" + etw + "]";
	}
   
}
