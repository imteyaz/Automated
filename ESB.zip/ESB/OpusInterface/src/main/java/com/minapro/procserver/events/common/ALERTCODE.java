package com.minapro.procserver.events.common;

/**
 * Possible Alert codes handled in the system. When new alerts are added, the code needs to be added here
 * @author Rosemary George
 *
 */
public enum ALERTCODE {
    QC_WEIGHT_MISSMATCH_ALERT,
    QC_WRONG_CELL_ALERT,
    QC_WRONG_CONTAINER_ALERT,
    HEAVY_HOOK_ALERT,
    FLD_CONTAINER_ALERT,
    QC_BREAKDOWN_ALERT,
    QC_ACCIDENT_INCIDENT_ALERT,
    CHE_WRONG_POS_ALERT,
    CHE_WEIGHT_MISMATCH_ALERT,
    CHE_SPRDR_POS_MSMTCH_ALERT,
    QC_FIRST_JOB_CONFIRM_ALERT,
    QC_NON_VESSEL_POS_ALERT,
    QC_LOAD_JOB_HANGING_ALERT,
    QC_UNPLAN_CONTAINER_ALERT,
    LOGOUT_FAILURE_ALERT,
    TOS_FAILURE_ALERT
}
