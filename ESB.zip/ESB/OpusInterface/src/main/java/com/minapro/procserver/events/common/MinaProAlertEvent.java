package com.minapro.procserver.events.common;


import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the data for recording the alert in the system
 * 
 * @author Rosemary George
 *
 */
public class MinaProAlertEvent extends Event implements Serializable{
    
    private static final long serialVersionUID = 1635964388774172545L;
    private static final String SYSTEM ="SYSTEM";
    private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("EEE d-MMM-yyyy HH:mm:ss");

    private ALERTCODE alertCode;
    
    private String message;
    
    private String containerId;
    
    private String actualWeight;
    
    private String plannedWeight;
    
    private String plannedLocation;
    
    private String actualLocation;
    
    private String spreaderSize;
    
    private String plannedContainerId;
    
    private String operatorId;
    
    private String generatedBy = SYSTEM;
    
    private String rotationId;
    
    private String reportedTime;
    
    private String containerSize;
    
    private String failedAPI;   
    
    public MinaProAlertEvent(){
        super();
        this.setTimeStamp(DATE_FORMATTER.format(new Date()));
        this.setEventID(UUID.randomUUID().toString());      
    }
    
    public String getFailedAPI() {
        return failedAPI;
    }

    public void setFailedAPI(String failedAPI) {
        this.failedAPI = failedAPI;
    }

    public String getContainerSize() {
        return containerSize;
    }

    public void setContainerSize(String containerSize) {
        this.containerSize = containerSize;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getReportedTime() {
        return reportedTime;
    }

    public void setReportedTime(String reportedTime) {
        this.reportedTime = reportedTime;
    }

    public String getPlannedContainerId() {
        return plannedContainerId;
    }

    public void setPlannedContainerId(String plannedContainerId) {
        this.plannedContainerId = plannedContainerId;
    }

    public String getGeneratedBy() {
        return generatedBy;
    }

    public void setGeneratedBy(String generatedBy) {
        this.generatedBy = generatedBy;
    }

    public ALERTCODE getAlertCode() {
        return alertCode;
    }

    public void setAlertCode(ALERTCODE alertCode) {
        this.alertCode = alertCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getActualWeight() {
        return actualWeight;
    }

    public void setActualWeight(String actualWeight) {
        this.actualWeight = actualWeight;
    }

    public String getPlannedWeight() {
        return plannedWeight;
    }

    public void setPlannedWeight(String plannedWeight) {
        this.plannedWeight = plannedWeight;
    }

    public String getPlannedLocation() {
        return plannedLocation;
    }

    public void setPlannedLocation(String plannedLocation) {
        this.plannedLocation = plannedLocation;
    }

    public String getActualLocation() {
        return actualLocation;
    }

    public void setActualLocation(String actualLocation) {
        this.actualLocation = actualLocation;
    }

    public String getSpreaderSize() {
        return spreaderSize;
    }

    public void setSpreaderSize(String spreaderSize) {
        this.spreaderSize = spreaderSize;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    @Override
    public String toString() {
        return "MinaProAlertEvent [alertCode=" + alertCode + ", message=" + message + ", containerId=" + containerId
                + ", actualWeight=" + actualWeight + ", plannedWeight=" + plannedWeight + ", plannedLocation="
                + plannedLocation + ", actualLocation=" + actualLocation + ", spreaderSize=" + spreaderSize
                + ", plannedContainerId=" + plannedContainerId + ", operatorId=" + operatorId + ", generatedBy="
                + generatedBy + ", rotationId=" + rotationId + ", reportedTime=" + reportedTime + ", containerSize="
                + containerSize + "]";
    }
}
