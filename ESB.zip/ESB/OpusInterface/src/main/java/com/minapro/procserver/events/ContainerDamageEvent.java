package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

/**
 * ValueObject holding the details about the container damage notification
 * 
 * @author Rosemary Georges
 *
 */
public class ContainerDamageEvent extends Event implements Serializable {
    private static final long serialVersionUID = 5383485992912556092L;   

    /**
     * Contains all the damage details recorded
     */
    private List<DamageDetails> damageDetails;
    
    private String moveType;

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public List<DamageDetails> getDamageDetails() {
        return damageDetails;
    }

    public void setDamageDetails(List<DamageDetails> damageDetails) {
        this.damageDetails = damageDetails;
    }

    @Override
    public String toString() {
        return "ContainerDamageEvent [damageDetails=" + damageDetails + ", moveType=" + moveType + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }  
}
