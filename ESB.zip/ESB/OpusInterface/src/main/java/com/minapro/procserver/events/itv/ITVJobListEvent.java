package com.minapro.procserver.events.itv;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the drive instruction events for an ITV
 * 
 * @author Rosemary George
 *
 */
public class ITVJobListEvent extends Event implements Serializable {
    private static final long serialVersionUID = 4927468442562952515L;

    private List<DriveInstructionEvent> jobList;
    
    private boolean isNotification;
    
    /**
     * error/display reason received from SPARCS system
     */
    private String reason;

    public List<DriveInstructionEvent> getJobList() {
        return jobList;
    }

    public void setJobList(List<DriveInstructionEvent> jobList) {
        this.jobList = jobList;
    }

    public boolean isNotification() {
        return isNotification;
    }

    public void setNotification(boolean isNotification) {
        this.isNotification = isNotification;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "ITVJobListEvent [jobList=" + jobList + ", isNotification="
                + isNotification + ", reason=" + reason + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getTimeStamp()="
                + getTimeStamp() + ", getEventID()=" + getEventID()
                + ", geEventType()=" + geEventType() + "]";
    }
     
}
