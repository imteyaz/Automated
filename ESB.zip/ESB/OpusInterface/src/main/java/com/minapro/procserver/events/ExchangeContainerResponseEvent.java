package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

public class ExchangeContainerResponseEvent extends Event implements Serializable {
    
    private static final long serialVersionUID = 7181687252803889669L;  
    private List<ExchangeStatus> exchangeStatus;

    public List<ExchangeStatus> getExchangeStatus() {
        return exchangeStatus;
    }

    public void setExchangeStatus(List<ExchangeStatus> exchangeStatus) {
        this.exchangeStatus = exchangeStatus;
    }

    @Override
    public String toString() {
        return "ExchangeContainerResponseEvent [exchangeStatus="
                + exchangeStatus + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getEventID()="
                + getEventID() + "]";
    }
}
