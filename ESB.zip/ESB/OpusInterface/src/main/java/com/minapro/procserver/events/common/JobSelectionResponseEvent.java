package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the job selection response
 * 
 * @author Rosemary George
 *
 */
public class JobSelectionResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -6734062005674683441L;

    private String containerId;

    private String moveType;
    
    /**
     * The new location suggested by SPARCS for the selected container. Can be same as the current value also.
     */
    private String newLocation;

    /**
     * Indicates whether the request was successful or not
     */
    private boolean isSuccess;

    /**
     * Will be filled with the error message in case failure
     */
    private String errorMessage;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getNewLocation() {
        return newLocation;
    }

    public void setNewLocation(String newLocation) {
        this.newLocation = newLocation;
    }

    @Override
    public String toString() {
        return "JobSelectionResponseEvent [containerId=" + containerId + ", moveType=" + moveType + ", newLocation="
                + newLocation + ", isSuccess=" + isSuccess + ", errorMessage=" + errorMessage + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }
}
