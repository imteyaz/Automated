package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;


/**
 * ValueObject holding the swap request from the device
 * 
 * @author Rosemary George
 *
 */
public class SwapResponseEvent extends Event implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -3063964344323092409L;
    
    /**
     * ID of the containers which are going to be swapped. This format will be containerID1|containerID2
     */
    private List<SwapContainerPosition> swapContainerList;

    public List<SwapContainerPosition> getSwapContainerList() {
        return swapContainerList;
    }

    public void setSwapContainerList(List<SwapContainerPosition> swapContainerList) {
        this.swapContainerList = swapContainerList;
    }

    @Override
    public String toString() {
        return "SwapResponseEvent [swapContainerList=" + swapContainerList
                + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }

}
