package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * Following Class Is Responsible for Holding the server response for Operator break event
 * 
 * @author Umamahesh M
 *
 */
public class OperatorAvailabilityResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 4438282162234751157L;
    
    private String isAvailable;

    private String errorMsg;

    /**
     * Indicates whether the request is initiated by operator or system
     */
    private boolean isOperatorInitiated;
    
    public boolean isOperatorInitiated() {
        return isOperatorInitiated;
    }

    public void setOperatorInitiated(boolean isOperatorInitiated) {
        this.isOperatorInitiated = isOperatorInitiated;
    }
    
    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    @Override
    public String toString() {
        return "OperatorAvailabilityResponseEvent [isAvailable=" + isAvailable + ", errorMsg=" + errorMsg
                + ", EquipmentID=" + getEquipmentID() + ", isOperatorInitiated=" + isOperatorInitiated + "]";
    }
}
