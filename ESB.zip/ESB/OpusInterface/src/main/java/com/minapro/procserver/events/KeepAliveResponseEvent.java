package com.minapro.procserver.events;

import java.io.Serializable;

public class KeepAliveResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = 7729980195206135523L;
    
    /**
     * OPUS Server status UP/DOWN retrieved from ESB
     */
    private boolean status; 

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "KeepAliveResponseEvent [status=" + status + "]";
    }
}
