package com.minapro.procserver.events.che;

import com.minapro.procserver.events.Event;

public class InventoryUpdateResponseEvent extends Event{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private boolean inventoryStatus;
    /**
     * inventory container Id
     */
    private String containerId;
    private String  errorMessage;
    
    public boolean isInventoryStatus() {
        return inventoryStatus;
    }
    
    public void setInventoryStatus(boolean inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }
    
    public String getContainerId() {
        return containerId;
    }
    
    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
    
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    @Override
    public String toString() {
        return "InventoryUpdateResponseEvent [inventoryStatus="
                + inventoryStatus + ", containerId=" + containerId
                + ", errorMessage=" + errorMessage + ", getUserID()="
                + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getTerminalID()=" + getTerminalID() + ", getEventID()="
                + getEventID() + "]";
    }   

}
