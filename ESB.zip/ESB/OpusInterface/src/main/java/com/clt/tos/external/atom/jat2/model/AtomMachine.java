package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomMachine implements Serializable {
    private static final long serialVersionUID = 4797204052060739928L;
    private String mchnId;
    private String mchnTp;
    private boolean logOn;
    private boolean on;
    private String poolNm;

    public String getMchnId() {
        return mchnId;
    }

    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }

    public String getMchnTp() {
        return mchnTp;
    }

    public void setMchnTp(String mchnTp) {
        this.mchnTp = mchnTp;
    }

    public boolean isLogOn() {
        return logOn;
    }

    public void setLogOn(boolean logOn) {
        this.logOn = logOn;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public String getPoolNm() {
        return poolNm;
    }

    public void setPoolNm(String poolNm) {
        this.poolNm = poolNm;
    }

    @Override
    public String toString() {
        return "AtomMachine [mchnId=" + mchnId + ", mchnTp=" + mchnTp
                + ", logOn=" + logOn + ", on=" + on + ", poolNm=" + poolNm
                + "]";
    }
}
