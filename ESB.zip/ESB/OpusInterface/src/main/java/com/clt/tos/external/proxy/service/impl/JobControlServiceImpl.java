package com.clt.tos.external.proxy.service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.control.IfAtomJobControl;
import com.clt.tos.external.atom.jat2.model.AtomPickedContainer;
import com.clt.tos.external.atom.jat2.model.AtomQcJobDone;
import com.clt.tos.external.atom.jat2.model.AtomResultJobDone;
import com.clt.tos.external.atom.jat2.model.AtomVmtWorkOrder;
import com.clt.tos.external.atom.jat2.model.AtomYcJobDone;
import com.clt.tos.external.proxy.service.JobControlService;
import com.clt.tos.external.proxy.service.OpusProxyService;

public class JobControlServiceImpl implements JobControlService {
    
    private static final Logger LOGGER = Logger
            .getLogger(JobControlServiceImpl.class);

    private static OpusProxyService opusProxyService;
    
    /**
     * Get Proxy service to get OPUS API Services 
     */
    public JobControlServiceImpl() {
        opusProxyService = new OpusProxyService();
    }

    /**
     * Get IfAtomJobControl service reference
     * @return
     * @throws Exception
     */
    private IfAtomJobControl getJobControlService() throws Exception {
        LOGGER.debug("Getting OPUS IfAtomJobControl service..." );
        return opusProxyService.getIfAtomJobControlService();
    }
    
    /**
     * Call getJobOrderList() to get Job order list
     */
    public List<AtomVmtWorkOrder> getJobOrderList(String machineId,
            String machineType)
            throws Exception {
        return getJobControlService().getJobOrderList(machineId, machineType);
    }
    //Testing
/*public static void main(String ... args) throws Exception {
	JobControlServiceImpl imp = new JobControlServiceImpl();
	List<AtomVmtWorkOrder> l= imp.getJobOrderList("GC02","QC");
	System.out.println("value: "+l);
}*/
    
    /**
     * Call setPickedContainer() to select currently picked container/job
     */
    public String setPickedContainer(AtomPickedContainer atomPickedContainer1,
            AtomPickedContainer atomPickedContainer2) throws Exception {
        return getJobControlService().setPickedContainer(atomPickedContainer1, atomPickedContainer2);
    }

    /**
     * Call setJobDone() to complete job from YARD by RMG
     */
    public String setJobDone(AtomYcJobDone atomYcJobDone) throws Exception {
        return getJobControlService().setJobDone(atomYcJobDone);
    }

    /**
     * Call setJobDoneByQcList to complete job from Quay side by QC
     */
    public List<AtomResultJobDone> setJobDoneByQcList(List<AtomQcJobDone> qcJobDoneList)
            throws Exception {
        return getJobControlService().setJobDoneByQcList(qcJobDoneList);
    }

    /**
     * Call setJobStatus() Acitve /Inprogress / Inactive / completed
     */
    public String setJobStatus(List<String> jobKey, String jobStatusType,
            String yardCraneNo, String userId) throws Exception {
        return getJobControlService().setJobStatus(jobKey, jobStatusType, yardCraneNo, userId);
    }
    
    /**
     * Change the container position on chassis.
     */
    public boolean  changePositionOnChassis(String jobKey,
            String ytNo, String positionOnChassis, String usrId)
            throws java.lang.Exception {
        return getJobControlService().changePositionOnChassis(jobKey, ytNo, positionOnChassis, usrId);
    }
    
    /**
     * Search containers in a job, and inquire containers in the inventory if there is no container.
     */
    public List<AtomVmtWorkOrder> getJobOrderByContainer(String cntrKey) throws java.lang.Exception{
        return getJobControlService().getJobOrderByContainer(cntrKey);
    }
}
