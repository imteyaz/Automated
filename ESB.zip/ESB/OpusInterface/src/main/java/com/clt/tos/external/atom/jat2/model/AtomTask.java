package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomTask implements Serializable {
    private static final long serialVersionUID = -3935138585896295363L;
    private String ytNo;
    private String ytTp;
    private String ycNo;
    private String locTp;
    private String blck;
    private String bay;
    private String jobTp;

    public String getYtNo() {
        return ytNo;
    }

    public void setYtNo(String ytNo) {
        this.ytNo = ytNo;
    }

    public String getYtTp() {
        return ytTp;
    }

    public void setYtTp(String ytTp) {
        this.ytTp = ytTp;
    }

    public String getYcNo() {
        return ycNo;
    }

    public void setYcNo(String ycNo) {
        this.ycNo = ycNo;
    }

    public String getLocTp() {
        return locTp;
    }

    public void setLocTp(String locTp) {
        this.locTp = locTp;
    }

    public String getBlck() {
        return blck;
    }

    public void setBlck(String blck) {
        this.blck = blck;
    }

    public String getBay() {
        return bay;
    }

    public void setBay(String bay) {
        this.bay = bay;
    }

    public String getJobTp() {
        return jobTp;
    }

    public void setJobTp(String jobTp) {
        this.jobTp = jobTp;
    }

}