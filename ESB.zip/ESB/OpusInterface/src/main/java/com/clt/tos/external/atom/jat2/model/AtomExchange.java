package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomExchange implements Serializable {
    private static final long serialVersionUID = 7528377364449125621L;
    private String usrId;
    private String vessel;
    private String voyage;
    private String disLoad;
    private String sourceStowage;
    private String targetStowage;
    private String singleTwinFlag;

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    public String getVessel() {
        return vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }

    public String getVoyage() {
        return voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getDisLoad() {
        return disLoad;
    }

    public void setDisLoad(String disLoad) {
        this.disLoad = disLoad;
    }

    public String getSourceStowage() {
        return sourceStowage;
    }

    public void setSourceStowage(String sourceStowage) {
        this.sourceStowage = sourceStowage;
    }

    public String getTargetStowage() {
        return targetStowage;
    }

    public void setTargetStowage(String targetStowage) {
        this.targetStowage = targetStowage;
    }

    public String getSingleTwinFlag() {
        return singleTwinFlag;
    }

    public void setSingleTwinFlag(String singleTwinFlag) {
        this.singleTwinFlag = singleTwinFlag;
    }

    @Override
    public String toString() {
        return "AtomExchange [usrId=" + usrId + ", vessel=" + vessel
                + ", voyage=" + voyage + ", disLoad=" + disLoad
                + ", sourceStowage=" + sourceStowage + ", targetStowage="
                + targetStowage + ", singleTwinFlag=" + singleTwinFlag + "]";
    }

}
