package com.clt.tos.external.atom.jat2.control;

import com.clt.tos.external.atom.jat2.model.AtomLogin;

public abstract interface IfAtomUserControl {
  public abstract AtomLogin setLogIn(String userId, String password, String machineId)
    throws Exception;

  public abstract boolean setLogOut(String userId, String machineId)
    throws Exception;
}

