package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomLogin implements Serializable {
    private static final long serialVersionUID = -6540990798131076071L;
    private String usrId;
    private String mchnId;
    private String rsnCd;

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    public String getMchnId() {
        return mchnId;
    }

    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }

    public String getRsnCd() {
        return rsnCd;
    }

    public void setRsnCd(String rsnCd) {
        this.rsnCd = rsnCd;
    }

    @Override
    public String toString() {
        return "AtomLogin [usrId=" + usrId + ", mchnId=" + mchnId + ", rsnCd="
                + rsnCd + "]";
    }

}