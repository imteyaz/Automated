package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomYcJobDone implements Serializable {
    private static final long serialVersionUID = -2262870212085992014L;
    private String ycNo;
    private String ycTp;
    private String ytNo;
    private String ytTp;
    private String cntrNo;
    private String locTp;
    private String blck;
    private String bay;
    private String row;
    private String tier;
    private String usrId;

    public String getYcNo() {
        return ycNo;
    }

    public void setYcNo(String ycNo) {
        this.ycNo = ycNo;
    }

    public String getYcTp() {
        return ycTp;
    }

    public void setYcTp(String ycTp) {
        this.ycTp = ycTp;
    }

    public String getYtNo() {
        return ytNo;
    }

    public void setYtNo(String ytNo) {
        this.ytNo = ytNo;
    }

    public String getYtTp() {
        return ytTp;
    }

    public void setYtTp(String ytTp) {
        this.ytTp = ytTp;
    }

    public String getCntrNo() {
        return cntrNo;
    }

    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }

    public String getLocTp() {
        return locTp;
    }

    public void setLocTp(String locTp) {
        this.locTp = locTp;
    }

    public String getBlck() {
        return blck;
    }

    public void setBlck(String blck) {
        this.blck = blck;
    }

    public String getBay() {
        return bay;
    }

    public void setBay(String bay) {
        this.bay = bay;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    @Override
    public String toString() {
        return "AtomYcJobDone [ycNo=" + ycNo + ", ycTp=" + ycTp + ", ytNo="
                + ytNo + ", ytTp=" + ytTp + ", cntrNo=" + cntrNo + ", locTp="
                + locTp + ", blck=" + blck + ", bay=" + bay + ", row=" + row
                + ", tier=" + tier + ", usrId=" + usrId + "]";
    }

}
