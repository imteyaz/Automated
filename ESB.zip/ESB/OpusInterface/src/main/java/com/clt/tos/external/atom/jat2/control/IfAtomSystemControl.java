package com.clt.tos.external.atom.jat2.control;

public abstract interface IfAtomSystemControl {
  public abstract String keepAlive()
    throws Exception;
}
