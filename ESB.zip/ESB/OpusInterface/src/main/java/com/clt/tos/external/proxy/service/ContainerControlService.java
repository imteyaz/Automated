package com.clt.tos.external.proxy.service;

import com.clt.tos.external.atom.jat2.model.AtomContainer;

public interface ContainerControlService {

    public boolean updateDataCorrection(AtomContainer atomContainer)
            throws Exception;

    public boolean updateDamageStatus(String cntrNo, String userId, boolean isDmg) throws Exception;

}
