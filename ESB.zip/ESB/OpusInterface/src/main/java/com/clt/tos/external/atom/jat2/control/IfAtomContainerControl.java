package com.clt.tos.external.atom.jat2.control;

import com.clt.tos.external.atom.jat2.model.AtomContainer;

public abstract interface IfAtomContainerControl {
  public abstract boolean updateDataCorrection(AtomContainer paramAtomContainer)
    throws Exception;

  public abstract boolean updateDamageStatus(String paramString1, String paramString2, boolean paramBoolean)
    throws Exception;
}

