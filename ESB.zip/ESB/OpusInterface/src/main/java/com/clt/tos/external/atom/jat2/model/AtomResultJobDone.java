package com.clt.tos.external.atom.jat2.model;

public class AtomResultJobDone {
    private String cntrNo;
    private String jobType;
    private String rsltCode;
    
    public String getCntrNo() {
        return cntrNo;
    }
    
    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }
    
    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }
        
    public String getRsltCode() {
        return rsltCode;
    }
    
    public void setRsltCode(String rsltCode) {
        this.rsltCode = rsltCode;
    }

    @Override
    public String toString() {
        return "AtomResultJobDone [cntrNo=" + cntrNo + ", jobType=" + jobType
                + ", rsltCode=" + rsltCode + "]";
    }
}
