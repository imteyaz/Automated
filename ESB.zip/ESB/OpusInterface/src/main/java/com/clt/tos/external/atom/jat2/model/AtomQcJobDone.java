package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomQcJobDone implements Serializable {
    private static final long serialVersionUID = 7524707356750418163L;
    private String qcNo;
    private String ytNo;
    private String cntrNo;
    private String jobTp;
    private String positionOnChassis;
    private String locTp;
    private String lane;
    private boolean dmg;
    private String usrId;

    public String getQcNo() {
        return qcNo;
    }

    public void setQcNo(String qcNo) {
        this.qcNo = qcNo;
    }

    public String getYtNo() {
        return ytNo;
    }

    public void setYtNo(String ytNo) {
        this.ytNo = ytNo;
    }

    public String getCntrNo() {
        return cntrNo;
    }

    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }

    public String getJobTp() {
        return jobTp;
    }

    public void setJobTp(String jobTp) {
        this.jobTp = jobTp;
    }

    public String getPositionOnChassis() {
        return positionOnChassis;
    }

    public void setPositionOnChassis(String positionOnChassis) {
        this.positionOnChassis = positionOnChassis;
    }

    public String getLocTp() {
        return locTp;
    }

    public void setLocTp(String locTp) {
        this.locTp = locTp;
    }

    public String getLane() {
        return lane;
    }

    public void setLane(String lane) {
        this.lane = lane;
    }

    public boolean isDmg() {
        return dmg;
    }

    public void setDmg(boolean dmg) {
        this.dmg = dmg;
    }

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    @Override
    public String toString() {
        return "AtomQcJobDone [qcNo=" + qcNo + ", ytNo=" + ytNo + ", cntrNo="
                + cntrNo + ", jobTp=" + jobTp + ", positionOnChassis="
                + positionOnChassis + ", locTp=" + locTp + ", lane=" + lane
                + ", dmg=" + dmg + ", usrId=" + usrId + "]";
    }
}
