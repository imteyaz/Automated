package com.clt.tos.external.proxy.service.impl;
import com.clt.tos.external.atom.jat2.control.IfAtomUserControl;
import com.clt.tos.external.atom.jat2.model.AtomLogin;
import com.clt.tos.external.proxy.service.OpusProxyService;
import com.clt.tos.external.proxy.service.UserControlService;

import org.apache.log4j.Logger;


public class UserControlServiceImpl implements UserControlService {
    
    private static final Logger LOGGER = Logger.getLogger(UserControlServiceImpl.class);

    private static OpusProxyService opusProxyService;
    
    public UserControlServiceImpl() {
        opusProxyService = new OpusProxyService();
    }

    private IfAtomUserControl getUserControlService() throws Exception {
        return opusProxyService.getIfAtomUserControlService();
    }

    @Override
    public AtomLogin setLogIn(String userId, String pwd, String mchnId)
            throws Exception {
        LOGGER.debug("Calling UserControlService setLogIn() API...");
        IfAtomUserControl ifAtomUserControl = getUserControlService();
        return ifAtomUserControl.setLogIn(userId, pwd, mchnId);
    }

    @Override
    public boolean setLogOut(String userId, String mchnId) throws Exception {
        LOGGER.debug("Calling UserControlService setLogOut() API...");
        return getUserControlService().setLogOut(userId, mchnId);
    }
}
