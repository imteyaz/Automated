package com.clt.tos.external.atom.jat2.control;

import com.clt.tos.external.atom.jat2.model.AtomExchange;
import com.clt.tos.external.atom.jat2.model.AtomStowage;

public abstract interface IfAtomVesselControl {
    public abstract boolean exchangeContainer(AtomExchange paramAtomExchange)
            throws Exception;

    public abstract boolean exchangeStowage(AtomStowage paramAtomStowage)
            throws Exception;

    public abstract boolean createOutOfListContainer(String vessel,
            String voyage, String cntrNo, String qcNo, String cntrIso,
            String usrId, String ytNo) throws Exception;
}
