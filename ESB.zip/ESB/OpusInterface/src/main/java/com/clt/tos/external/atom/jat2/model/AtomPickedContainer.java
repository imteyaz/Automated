package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomPickedContainer implements Serializable {
    private static final long serialVersionUID = -3746639027161263355L;
    private String sprdPos;
    private String mchnId;
    private String mchnTp;
    private String cntrNo;
    private String locTp;
    private String blck;
    private String bay;
    private String row;
    private String tier;
    private String usrId;

    public String getSprdPos() {
        return sprdPos;
    }

    public void setSprdPos(String sprdPos) {
        this.sprdPos = sprdPos;
    }

    public String getMchnId() {
        return mchnId;
    }

    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }

    public String getMchnTp() {
        return mchnTp;
    }

    public void setMchnTp(String mchnTp) {
        this.mchnTp = mchnTp;
    }

    public String getCntrNo() {
        return cntrNo;
    }

    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }

    public String getLocTp() {
        return locTp;
    }

    public void setLocTp(String locTp) {
        this.locTp = locTp;
    }

    public String getBlck() {
        return blck;
    }

    public void setBlck(String blck) {
        this.blck = blck;
    }

    public String getBay() {
        return bay;
    }

    public void setBay(String bay) {
        this.bay = bay;
    }

    public String getRow() {
        return row;
    }

    public void setRow(String row) {
        this.row = row;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    @Override
    public String toString() {
        return "AtomPickedContainer [sprdPos=" + sprdPos + ", mchnId=" + mchnId
                + ", mchnTp=" + mchnTp + ", cntrNo=" + cntrNo + ", locTp="
                + locTp + ", blck=" + blck + ", bay=" + bay + ", row=" + row
                + ", tier=" + tier + ", usrId=" + usrId + "]";
    }

}
