package com.clt.tos.external.atom.jat2.model;

public enum SingleOrTwin {
    Single("S"), Twin("W");

    private String key;

    private SingleOrTwin(String key) {
        this.key = key;
    }

    public String getKey() {
        return this.key;
    }
}
