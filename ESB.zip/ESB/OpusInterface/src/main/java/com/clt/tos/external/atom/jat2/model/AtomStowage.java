package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomStowage implements Serializable {
    private static final long serialVersionUID = 6965141719499073849L;
    private String usrId;
    private String vessel;
    private String voyage;
    private String sourceStowage;
    private String targetStowage;

    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    public String getVessel() {
        return vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }

    public String getVoyage() {
        return voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getSourceStowage() {
        return sourceStowage;
    }

    public void setSourceStowage(String sourceStowage) {
        this.sourceStowage = sourceStowage;
    }

    public String getTargetStowage() {
        return targetStowage;
    }

    public void setTargetStowage(String targetStowage) {
        this.targetStowage = targetStowage;
    }

}
