package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomMachineStop implements Serializable {
    private static final long serialVersionUID = 1113534894397623717L;
    private String mchnId;
    private String mchnTp;
    private String reasonCd;
    private String reasonNm;
    private String mchnStopDt;

    public String getMchnId() {
        return mchnId;
    }

    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }

    public String getMchnTp() {
        return mchnTp;
    }

    public void setMchnTp(String mchnTp) {
        this.mchnTp = mchnTp;
    }

    public String getReasonCd() {
        return reasonCd;
    }

    public void setReasonCd(String reasonCd) {
        this.reasonCd = reasonCd;
    }

    public String getReasonNm() {
        return reasonNm;
    }

    public void setReasonNm(String reasonNm) {
        this.reasonNm = reasonNm;
    }

    public String getMchnStopDt() {
        return mchnStopDt;
    }

    public void setMchnStopDt(String mchnStopDt) {
        this.mchnStopDt = mchnStopDt;
    }

}
