package com.clt.tos.external.proxy.service;

import java.util.List;

import com.clt.tos.external.atom.jat2.model.AtomPickedContainer;
import com.clt.tos.external.atom.jat2.model.AtomQcJobDone;
import com.clt.tos.external.atom.jat2.model.AtomResultJobDone;
import com.clt.tos.external.atom.jat2.model.AtomVmtWorkOrder;
import com.clt.tos.external.atom.jat2.model.AtomYcJobDone;

public interface JobControlService {

    /**
     * Get JobOrderList for QC/Hc/CHE/ITV
     * 
     * @param machineId
     * @param machineType
     * @return
     * @throws Exception
     */
    public List<AtomVmtWorkOrder> getJobOrderList(String machineId,
            String machineType) throws Exception;

    /**
     * Set Job selection for picked container
     * 
     * @param atomPickedContainer1
     * @param atomPickedContainer2
     * @return
     * @throws Exception
     */
    public String setPickedContainer(AtomPickedContainer atomPickedContainer1,
            AtomPickedContainer atomPickedContainer2) throws Exception;

    /**
     * Complete Job for picked container for CHE
     * 
     * @param atomYcJobDone
     * @return
     * @throws Exception
     */
    public String setJobDone(AtomYcJobDone atomYcJobDone) throws Exception;

    /**
     * Complete Job for picked container for QC
     * 
     * @param qcJobDoneList
     * @return
     * @throws Exception
     */
    public List<AtomResultJobDone> setJobDoneByQcList(
            List<AtomQcJobDone> qcJobDoneList) throws Exception;

    /**
     * Set Job Status Active/Processing/Completed/Inactive
     * 
     * @param jobKey
     * @param jobStatusType
     * @param yardCraneNo
     * @param userId
     * @throws Exception
     */
    public String setJobStatus(List<String> jobKey, String jobStatusType,
            String yardCraneNo, String userId) throws Exception;

    /**
     * Change the container position on chassis.
     * 
     * @param jobKey
     * @param ytNo
     * @param positionOnChassis
     * @param usrId
     * @throws java.lang.Exception
     */
    public boolean changePositionOnChassis(String jobKey, String ytNo,
            String positionOnChassis, String usrId) throws java.lang.Exception;

    /**
     * Search containers in a job, and inquire containers in the inventory if
     * there is no container.
     * 
     * @param cntrKey
     * @return
     * @throws java.lang.Exception
     */
    public List<AtomVmtWorkOrder> getJobOrderByContainer(String cntrKey)
            throws java.lang.Exception;

}