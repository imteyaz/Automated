package com.clt.tos.external.proxy.service;

import com.clt.tos.external.atom.jat2.model.AtomExchange;
import com.clt.tos.external.atom.jat2.model.AtomStowage;

public interface VesselControlService {
    public boolean exchangeContainer(AtomExchange paramAtomExchange)
            throws Exception;

    public boolean exchangeStowage(AtomStowage paramAtomStowage)
            throws Exception;

    public boolean createOutOfListContainer(String vessel,
            String voyage, String cntrNo, String qcNo,
            String cntrIso, String usrId, String ytNo) throws Exception;
}
