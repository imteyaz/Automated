package com.clt.tos.external.proxy.service;

import com.clt.tos.external.atom.jat2.model.AtomLogin;

public interface UserControlService {
    
    public AtomLogin setLogIn(String userId, String pwd, String mchnId) throws Exception;

    public boolean setLogOut(String userId, String mchnId) throws Exception;

}
