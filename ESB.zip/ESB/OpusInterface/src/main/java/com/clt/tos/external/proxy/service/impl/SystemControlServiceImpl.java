package com.clt.tos.external.proxy.service.impl;

import java.net.MalformedURLException;

import org.apache.log4j.Logger;

import com.clt.tos.external.proxy.service.OpusProxyService;
import com.clt.tos.external.proxy.service.SystemControlService;

public class SystemControlServiceImpl implements SystemControlService {
    private static final Logger LOGGER = Logger
            .getLogger(SystemControlServiceImpl.class);

    private static OpusProxyService opusProxyService;

    public SystemControlServiceImpl() {
        opusProxyService = new OpusProxyService();
    }

    @Override
    public String keepAlive()  {
        String serverStatus = null;
        try {
            serverStatus = opusProxyService.getIfAtomSystemControlService().keepAlive();
        } catch (MalformedURLException me) {
            LOGGER.error("MalformedURLException while calling OPUS KeepAlive() API: ", me);
        } catch (Exception e) {
            LOGGER.debug("Exception while calling OPUS KeepAlive() API: ",e );
        }
        return serverStatus; 
    }
}
