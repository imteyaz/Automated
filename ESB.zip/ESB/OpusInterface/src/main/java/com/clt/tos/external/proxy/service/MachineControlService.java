package com.clt.tos.external.proxy.service;

import java.util.List;

import com.clt.tos.external.atom.jat2.model.AtomItv;
import com.clt.tos.external.atom.jat2.model.AtomMachine;
import com.clt.tos.external.atom.jat2.model.AtomMachineNotice;
import com.clt.tos.external.atom.jat2.model.AtomMachineStop;

public interface MachineControlService {

	/**
	 * Retrieve all machines by machine type.
	 * 
	 * @param machineId
	 * @param machineType
	 * @return
	 * @throws Exception
	 */
	public List<AtomMachine> getMachineListByType(String machineId,
			String machineType) throws Exception;

	/**
	 * Inquire ITV list belongs to a Pool.
	 * 
	 * @param poolName
	 * @param itvNo
	 * @return
	 * @throws Exception
	 */
	public List<AtomItv> getMachineListOfPool(String poolName, String itvNo)
			throws Exception;

	/**
	 * Save the reason for interruption of the machine which comes from outside
	 * in TOS.
	 * 
	 * @param machineId
	 * @param machineType
	 * @param userId
	 * @param userName
	 * @param reasonCode
	 * @param isStopped
	 * @return
	 * @throws Exception
	 */
	public String setMachineStop(String machineId, String machineType,
			String userId, String userName, String reasonCode,
			boolean isStopped, String vessel, String voyage) throws Exception;

	/**
	 * Search for the reason for interruption of the machine.
	 * 
	 * @param machineId
	 * @param machineType
	 * @return
	 * @throws Exception
	 */
	public AtomMachineStop getMachineStop(String machineId, String machineType)
			throws Exception;

	/**
	 * Send the ITV arrival information to TOS when the ITV arrives at POW.
	 * 
	 * @param ytNo
	 * @param locTp
	 * @param blck
	 * @param bay
	 * @param lane
	 * @throws Exception
	 */
	public void setMachineArrival(String ytNo, String locTp, String blck,
			String bay, String lane, String userId) throws Exception;

	/**
	 * Save the messages sent to the machine(VMT).
	 * 
	 * @param mchnTp
	 * @param mchnId
	 * @param noticeMsg
	 * @throws java.lang.Exception
	 */
	public void setMachineNotice(String mchnId, String mchnTp, String noticeMsg)
			throws java.lang.Exception;

	/**
	 * Search for instance messages sent to the machine(VMT).
	 * 
	 * @param mchnId
	 * @param mchnTp
	 * @return
	 * @throws java.lang.Exception
	 */
	public List<AtomMachineNotice> getMachineNotices(String mchnTp)
			throws java.lang.Exception;

	/**
	 * Function to change ITV No manually when actually arrived ITV is different
	 * from assigned ITV
	 * 
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 * @return
	 * @throws Exception
	 */
	public String itvSwap4Manual(String jobKey, String crntItvNo,
			String newItvNo, String usrId, String positionOnChassis)
			throws Exception;
}
