package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomVmtWorkOrder implements Serializable {
    private static final long serialVersionUID = -8839342946279385651L;
    private String qcNo;
    private String ytNo;
    private String ytTp;
    private String ycNo;
    private String ycTp;
    private String aprchLn;
    private String plnSeq;
    private String jobSts;
    private String cntrNo;
    private String fmLocTp;
    private String fmBlck;
    private String fmBay;
    private String fmRow;
    private String fmTier;
    private String fmLocation;
    private String toLocTp;
    private String toBlck;
    private String toBay;
    private String toRow;
    private String toTier;
    private String toLocation;
    private String jobTp;
    private String tnwTndmCd;
    private String twnTndmKey;
    private String cntrWgt;
    private String cntrSpTp;
    private String pod;
    private String cntrLen;
    private String cntrHgt;
    private String plugCd;
    private String cls;
    private String fullMty;
    private String vessel;
    private String voyage;
    private String jobKey;
    private String positionOnChassis;
    private boolean arrivedItv;
    private String jbQueNm;
    private String jbQueSeq;
    private String priorityJob;
    private String etw;

    public String getQcNo() {
        return this.qcNo;
    }

    public void setQcNo(String qcNo) {
        this.qcNo = qcNo;
    }

    public String getYtNo() {
        return this.ytNo;
    }

    public void setYtNo(String ytNo) {
        this.ytNo = ytNo;
    }

    public String getYtTp() {
        return this.ytTp;
    }

    public void setYtTp(String ytTp) {
        this.ytTp = ytTp;
    }

    public String getYcNo() {
        return this.ycNo;
    }

    public void setYcNo(String ycNo) {
        this.ycNo = ycNo;
    }

    public String getYcTp() {
        return this.ycTp;
    }

    public void setYcTp(String ycTp) {
        this.ycTp = ycTp;
    }

    public String getAprchLn() {
        return this.aprchLn;
    }

    public void setAprchLn(String aprchLn) {
        this.aprchLn = aprchLn;
    }

    public String getPlnSeq() {
        return this.plnSeq;
    }

    public void setPlnSeq(String plnSeq) {
        this.plnSeq = plnSeq;
    }

    public String getJobSts() {
        return this.jobSts;
    }

    public void setJobSts(String jobSts) {
        this.jobSts = jobSts;
    }

    public String getCntrNo() {
        return this.cntrNo;
    }

    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }

    public String getFmLocTp() {
        return this.fmLocTp;
    }

    public void setFmLocTp(String fmLocTp) {
        this.fmLocTp = fmLocTp;
    }

    public String getFmBlck() {
        return this.fmBlck;
    }

    public void setFmBlck(String fmBlck) {
        this.fmBlck = fmBlck;
    }

    public String getFmBay() {
        return this.fmBay;
    }

    public void setFmBay(String fmBay) {
        this.fmBay = fmBay;
    }

    public String getFmRow() {
        return this.fmRow;
    }

    public void setFmRow(String fmRow) {
        this.fmRow = fmRow;
    }

    public String getFmTier() {
        return this.fmTier;
    }

    public void setFmTier(String fmTier) {
        this.fmTier = fmTier;
    }

    public String getFmLocation() {
        return this.fmLocation;
    }

    public void setFmLocation(String fmLocation) {
        this.fmLocation = fmLocation;
    }

    public String getToLocTp() {
        return this.toLocTp;
    }

    public void setToLocTp(String toLocTp) {
        this.toLocTp = toLocTp;
    }

    public String getToBlck() {
        return this.toBlck;
    }

    public void setToBlck(String toBlck) {
        this.toBlck = toBlck;
    }

    public String getToBay() {
        return this.toBay;
    }

    public void setToBay(String toBay) {
        this.toBay = toBay;
    }

    public String getToRow() {
        return this.toRow;
    }

    public void setToRow(String toRow) {
        this.toRow = toRow;
    }

    public String getToTier() {
        return this.toTier;
    }

    public void setToTier(String toTier) {
        this.toTier = toTier;
    }

    public String getToLocation() {
        return this.toLocation;
    }

    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    public String getJobTp() {
        return this.jobTp;
    }

    public void setJobTp(String jobTp) {
        this.jobTp = jobTp;
    }

    public String getTnwTndmCd() {
        return this.tnwTndmCd;
    }

    public void setTnwTndmCd(String tnwTndmCd) {
        this.tnwTndmCd = tnwTndmCd;
    }

    public String getTwnTndmKey() {
        return this.twnTndmKey;
    }

    public void setTwnTndmKey(String twnTndmKey) {
        this.twnTndmKey = twnTndmKey;
    }

    public String getCntrWgt() {
        return this.cntrWgt;
    }

    public void setCntrWgt(String cntrWgt) {
        this.cntrWgt = cntrWgt;
    }

    public String getCntrSpTp() {
        return this.cntrSpTp;
    }

    public void setCntrSpTp(String cntrSpTp) {
        this.cntrSpTp = cntrSpTp;
    }

    public String getPod() {
        return this.pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getCntrLen() {
        return this.cntrLen;
    }

    public void setCntrLen(String cntrLen) {
        this.cntrLen = cntrLen;
    }

    public String getCntrHgt() {
        return this.cntrHgt;
    }

    public void setCntrHgt(String cntrHgt) {
        this.cntrHgt = cntrHgt;
    }

    public String getPlugCd() {
        return this.plugCd;
    }

    public void setPlugCd(String plugCd) {
        this.plugCd = plugCd;
    }

    public String getCls() {
        return this.cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }

    public String getFullMty() {
        return this.fullMty;
    }

    public void setFullMty(String fullMty) {
        this.fullMty = fullMty;
    }

    public String getVessel() {
        return this.vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }

    public String getVoyage() {
        return this.voyage;
    }

    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }

    public String getJobKey() {
        return this.jobKey;
    }

    public void setJobKey(String jobKey) {
        this.jobKey = jobKey;
    }

    public String getPositionOnChassis() {
        return this.positionOnChassis;
    }

    public void setPositionOnChassis(String positionOnChassis) {
        this.positionOnChassis = positionOnChassis;
    }

    public boolean isArrivedItv() {
        return this.arrivedItv;
    }

    public void setArrivedItv(boolean arrivedItv) {
        this.arrivedItv = arrivedItv;
    }

    public String getJbQueNm() {
        return this.jbQueNm;
    }

    public void setJbQueNm(String jbQueNm) {
        this.jbQueNm = jbQueNm;
    }

    public String getJbQueSeq() {
        return this.jbQueSeq;
    }

    public void setJbQueSeq(String jbQueSeq) {
        this.jbQueSeq = jbQueSeq;
    } 
    
    public String getPriorityJob() {
		return priorityJob;
	}

	public void setPriorityJob(String priorityJob) {
		this.priorityJob = priorityJob;
	}

	public String getEtw() {
		return etw;
	}

	public void setEtw(String etw) {
		this.etw = etw;
	}

	@Override
	public String toString() {
		return "AtomVmtWorkOrder [qcNo=" + qcNo + ", ytNo=" + ytNo + ", ytTp="
				+ ytTp + ", ycNo=" + ycNo + ", ycTp=" + ycTp + ", aprchLn="
				+ aprchLn + ", plnSeq=" + plnSeq + ", jobSts=" + jobSts
				+ ", cntrNo=" + cntrNo + ", fmLocTp=" + fmLocTp + ", fmBlck="
				+ fmBlck + ", fmBay=" + fmBay + ", fmRow=" + fmRow
				+ ", fmTier=" + fmTier + ", fmLocation=" + fmLocation
				+ ", toLocTp=" + toLocTp + ", toBlck=" + toBlck + ", toBay="
				+ toBay + ", toRow=" + toRow + ", toTier=" + toTier
				+ ", toLocation=" + toLocation + ", jobTp=" + jobTp
				+ ", tnwTndmCd=" + tnwTndmCd + ", twnTndmKey=" + twnTndmKey
				+ ", cntrWgt=" + cntrWgt + ", cntrSpTp=" + cntrSpTp + ", pod="
				+ pod + ", cntrLen=" + cntrLen + ", cntrHgt=" + cntrHgt
				+ ", plugCd=" + plugCd + ", cls=" + cls + ", fullMty="
				+ fullMty + ", vessel=" + vessel + ", voyage=" + voyage
				+ ", jobKey=" + jobKey + ", positionOnChassis="
				+ positionOnChassis + ", arrivedItv=" + arrivedItv
				+ ", jbQueNm=" + jbQueNm + ", jbQueSeq=" + jbQueSeq
				+ ", priorityJob=" + priorityJob + ", etw=" + etw + "]";
	}
}