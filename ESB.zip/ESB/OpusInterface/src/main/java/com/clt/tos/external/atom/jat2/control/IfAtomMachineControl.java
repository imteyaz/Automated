package com.clt.tos.external.atom.jat2.control;

import com.clt.tos.external.atom.jat2.model.AtomItv;
import com.clt.tos.external.atom.jat2.model.AtomMachine;
import com.clt.tos.external.atom.jat2.model.AtomMachineNotice;
import com.clt.tos.external.atom.jat2.model.AtomMachineStop;

import java.util.List;

public abstract interface IfAtomMachineControl {
	public abstract List<AtomMachine> getMachineListByType(String machineId,
			String machineType) throws Exception;

	public abstract List<AtomItv> getMachineListOfPool(String poolName,
			String itvNo) throws Exception;

	public abstract String setMachineStop(String machineId, String machineType,
			String userId, String userName, String reasonCode,
			boolean isStopped, String vessel, String voyage) throws Exception;
	
	public abstract AtomMachineStop getMachineStop(String machineId,
			String machineType) throws Exception;

	public abstract void setMachineArrival(String ytNumber,
			String locationType, String block, String bay, String qcLane,
			String userId) throws Exception;

	public abstract void setMachineNotice(String mchnId, String mchnTp,
			String noticeMsg) throws Exception;

	public abstract List<AtomMachineNotice> getMachineNotices(String mchnTp)
			throws Exception;

	public abstract String itvSwap4Manual(String jobKey, String crntItvNo,
			String newItvNo, String usrId, String positionOnChassis)
			throws Exception;
}
