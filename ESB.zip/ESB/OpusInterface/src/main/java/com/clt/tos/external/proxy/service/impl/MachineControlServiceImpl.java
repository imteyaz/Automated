package com.clt.tos.external.proxy.service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.control.IfAtomMachineControl;
import com.clt.tos.external.atom.jat2.model.AtomItv;
import com.clt.tos.external.atom.jat2.model.AtomMachine;
import com.clt.tos.external.atom.jat2.model.AtomMachineNotice;
import com.clt.tos.external.atom.jat2.model.AtomMachineStop;
import com.clt.tos.external.proxy.service.MachineControlService;
import com.clt.tos.external.proxy.service.OpusProxyService;

public class MachineControlServiceImpl implements MachineControlService {

	private static final Logger LOGGER = Logger
			.getLogger(MachineControlServiceImpl.class);

	private static OpusProxyService opusProxyService;

	public MachineControlServiceImpl() {
		opusProxyService = new OpusProxyService();
	}

	private IfAtomMachineControl getMachineControlService() throws Exception {
		LOGGER.debug("Getting OPUS IfAtomMachineControl service...");
		return opusProxyService.getIfAtomMachineControlService();
	}

	/**
	 * Retrieve all machines by machine type.
	 */
	@Override
	public List<AtomMachine> getMachineListByType(String machineId,
			String machineType) throws Exception {

		return getMachineControlService().getMachineListByType(machineId,
				machineType);
	}

	/**
	 * Inquire ITV list belongs to a Pool.
	 */
	@Override
	public List<AtomItv> getMachineListOfPool(String poolName, String itvNo)
			throws Exception {
		return getMachineControlService().getMachineListOfPool(poolName, itvNo);
	}

	/**
	 * Call setMachineStop() API to Mark operator Available/Unavailable
	 */
	@Override
	public String setMachineStop(String machineId, String machineType,
			String userId, String userName, String reasonCode,
			boolean isStopped, String vessel, String voyage) throws Exception {
		return getMachineControlService().setMachineStop(machineId,
				machineType, userId, userName, reasonCode, isStopped, vessel,
				voyage);
	}

	/**
	 * Call getMachineStop() API to get whether machine is on/off
	 */
	@Override
	public AtomMachineStop getMachineStop(String machineId, String machineType)
			throws Exception {
		return getMachineControlService()
				.getMachineStop(machineId, machineType);
	}

	/**
	 * Call setMachineArrival() to set Machine on in OPUS System.
	 */
	@Override
	public void setMachineArrival(String ytNo, String locTp, String blck,
			String bay, String lane, String userId) throws Exception {
		getMachineControlService().setMachineArrival(ytNo, locTp, blck, blck,
				lane, userId);
	}

	/**
	 * Save the messages sent to the machine(VMT).
	 */
	@Override
	public void setMachineNotice(String mchnId, String mchnTp, String noticeMsg)
			throws Exception {
		getMachineControlService().setMachineNotice(mchnId, mchnTp, noticeMsg);
	}

	/**
	 * Search for instance messages sent to the machine(VMT).
	 */
	@Override
	public List<AtomMachineNotice> getMachineNotices(String mchnTp)
			throws Exception {
		return getMachineControlService().getMachineNotices(mchnTp);
	}

	/**
	 * Function to change ITV No manually when actually arrived ITV is different
	 * from assigned ITV
	 */
	public String itvSwap4Manual(String jobKey, String crntItvNo,
			String newItvNo, String usrId, String positionOnChassis)
			throws Exception {
		return getMachineControlService().itvSwap4Manual(jobKey, crntItvNo,
				newItvNo, usrId, positionOnChassis);
	}
}
