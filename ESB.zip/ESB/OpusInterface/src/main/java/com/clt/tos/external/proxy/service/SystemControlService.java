package com.clt.tos.external.proxy.service;

public interface SystemControlService { 
    public String keepAlive() throws Exception;
}
