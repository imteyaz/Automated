package com.clt.tos.external.proxy.service.impl;

import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.control.IfAtomContainerControl;
import com.clt.tos.external.atom.jat2.model.AtomContainer;
import com.clt.tos.external.proxy.service.ContainerControlService;
import com.clt.tos.external.proxy.service.OpusProxyService;

public class ContainerControlServiceImpl implements ContainerControlService {

    private static final Logger LOGGER = Logger
            .getLogger(ContainerControlServiceImpl.class);

    private static OpusProxyService opusProxyService;

    /**
     * Get Proxy service to get OPUS API Services
     */
    public ContainerControlServiceImpl() {
        opusProxyService = new OpusProxyService();
    }

    /**
     * Get IfAtomMachineControl service reference
     * 
     * @return
     * @throws Exception
     */
    private IfAtomContainerControl getContainerControlService()
            throws Exception {
        LOGGER.debug("Getting OPUS IfAtomContainerControl service..." );
        return opusProxyService.getIfAtomContainerControlService();
    }

    public boolean updateDataCorrection(AtomContainer atomContainer)
            throws Exception {
        return getContainerControlService().updateDataCorrection(atomContainer);
    }

    public boolean updateDamageStatus(String cntrNo, String userId, boolean isDmg)
            throws Exception {
        return getContainerControlService().updateDamageStatus(cntrNo, userId, isDmg);
    }
}
