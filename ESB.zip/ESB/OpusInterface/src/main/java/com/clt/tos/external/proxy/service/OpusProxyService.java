package com.clt.tos.external.proxy.service;

import java.net.MalformedURLException;

import org.apache.log4j.Logger;

import com.caucho.hessian.client.HessianProxyFactory;
import com.clt.tos.external.atom.jat2.control.IfAtomContainerControl;
import com.clt.tos.external.atom.jat2.control.IfAtomJobControl;
import com.clt.tos.external.atom.jat2.control.IfAtomMachineControl;
import com.clt.tos.external.atom.jat2.control.IfAtomSystemControl;
import com.clt.tos.external.atom.jat2.control.IfAtomUserControl;
import com.clt.tos.external.atom.jat2.control.IfAtomVesselControl;
import com.dpw.opus.common.OpusConnection;

public class OpusProxyService {
    private static final Logger LOGGER = Logger
            .getLogger(OpusProxyService.class);

    private static OpusConnection opusConnection;
    private static HessianProxyFactory proxyFactory;
    
    public OpusProxyService() {
        proxyFactory = new HessianProxyFactory();
    }

    /**
     * OPUS System Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomSystemControl getIfAtomSystemControlService() throws MalformedURLException {   
        String systemControlUrl = opusConnection.getOpusUrl()+opusConnection.getSystemControlUrl(); 
        LOGGER.debug("System Control URL :"+systemControlUrl);
        return (IfAtomSystemControl) proxyFactory.create(IfAtomSystemControl.class, systemControlUrl);
    }   
    
    /**
     * OPUS User Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomUserControl getIfAtomUserControlService() throws MalformedURLException {
        String userControlUrl = opusConnection.getOpusUrl()+opusConnection.getUserControlUrl();
        LOGGER.debug("User Control URL :"+userControlUrl);
        return (IfAtomUserControl) proxyFactory.create(IfAtomUserControl.class, userControlUrl);
    }

    /**
     * OPUS Machine Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomMachineControl getIfAtomMachineControlService()
            throws MalformedURLException {
        String machineControlUrl = opusConnection.getOpusUrl()+opusConnection.getMachineControlUrl();
        LOGGER.debug("Machine Control URL :"+machineControlUrl);
        return (IfAtomMachineControl) proxyFactory
                .create(IfAtomMachineControl.class, machineControlUrl);
    }
    
    /**
     * OPUS Job Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomJobControl getIfAtomJobControlService() throws MalformedURLException {
    	// String jobControlUrl = "http://172.19.51.70:7110/HESSIAN/HESSIAN_IfAtomJobControl";
    	String jobControlUrl =  opusConnection.getOpusUrl()+opusConnection.getJobControlUrl();
        LOGGER.debug("Job Control URL :"+jobControlUrl);
        return (IfAtomJobControl) proxyFactory.create(IfAtomJobControl.class, jobControlUrl);
    }
    
    /**
     * OPUS Container Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomContainerControl getIfAtomContainerControlService()
            throws MalformedURLException {
        String containerControlUrl = opusConnection.getOpusUrl()+opusConnection.getContainerControlUrl();
        return (IfAtomContainerControl) proxyFactory.create(IfAtomContainerControl.class, containerControlUrl);
    }
    
    /**
     * OPUS Vessel Control API Service
     * @return
     * @throws MalformedURLException
     */
    public IfAtomVesselControl getIfAtomVesselControlService()
            throws MalformedURLException {
        String vesselControlUrl = opusConnection.getOpusUrl()+opusConnection.getVesselControlUrl();
        return (IfAtomVesselControl) proxyFactory.create(IfAtomVesselControl.class, vesselControlUrl);
    }

    public static OpusConnection getOpusConnection() {
        return opusConnection;
    }

    public static void setOpusConnection(OpusConnection opusConnection) {
        OpusProxyService.opusConnection = opusConnection;
    }
        
}
