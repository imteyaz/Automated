package com.clt.tos.external.proxy.service.impl;

import org.apache.log4j.Logger;

import com.clt.tos.external.atom.jat2.control.IfAtomVesselControl;
import com.clt.tos.external.atom.jat2.model.AtomExchange;
import com.clt.tos.external.atom.jat2.model.AtomStowage;
import com.clt.tos.external.proxy.service.OpusProxyService;
import com.clt.tos.external.proxy.service.VesselControlService;

public class VesselControlServiceImpl implements VesselControlService {
    
    private static final Logger LOGGER = Logger
            .getLogger(VesselControlServiceImpl.class);

    private static OpusProxyService opusProxyService;
    
    /**
     * Get Proxy service to get OPUS API Services 
     */
    public VesselControlServiceImpl() {
        opusProxyService = new OpusProxyService();
    }


    /**
     * Get IfAtomMachineControl service reference
     * @return
     * @throws Exception
     */
    private IfAtomVesselControl getVesselControlService() throws Exception {
        LOGGER.debug("Getting OPUS IfAtomVesselControl service..." );
        return opusProxyService.getIfAtomVesselControlService();
    }
    
    public boolean exchangeContainer(AtomExchange paramAtomExchange)
            throws Exception {
        return getVesselControlService().exchangeContainer(paramAtomExchange);
    }

    public boolean exchangeStowage(AtomStowage paramAtomStowage)
            throws Exception{
        return getVesselControlService().exchangeStowage(paramAtomStowage);
    }

    public boolean createOutOfListContainer(String vessel,
            String voyage, String cntrNo, String qcNo,
            String cntrIso, String usrId, String ytNo) throws Exception {
       return getVesselControlService().createOutOfListContainer(vessel, voyage, cntrNo, qcNo, cntrIso, usrId, ytNo);
    }

}
