package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomContainer implements Serializable {
    private static final long serialVersionUID = 1078471098343989403L;
    private String cntrNo;
    private String cntrIso;
    private String opr;
    private String cntrWgt;
    private String cls;
    private String fullMty;
    private String pod;
    private String overValue;
    private String plugCd;
    private String outVessel;
    private String outVoyage;
    private String seal1;
    private String seal2;
    private String seal3;
    private String seal4;
    private String seal5;
    private String nPod;
    private String fPod;
    private String usrId;

    public String getCntrNo() {
        return cntrNo;
    }

    public void setCntrNo(String cntrNo) {
        this.cntrNo = cntrNo;
    }

    public String getCntrIso() {
        return cntrIso;
    }

    public void setCntrIso(String cntrIso) {
        this.cntrIso = cntrIso;
    }

    public String getOpr() {
        return opr;
    }

    public void setOpr(String opr) {
        this.opr = opr;
    }

    public String getCntrWgt() {
        return cntrWgt;
    }

    public void setCntrWgt(String cntrWgt) {
        this.cntrWgt = cntrWgt;
    }

    public String getCls() {
        return cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }

    public String getFullMty() {
        return fullMty;
    }

    public void setFullMty(String fullMty) {
        this.fullMty = fullMty;
    }

    public String getPod() {
        return pod;
    }

    public void setPod(String pod) {
        this.pod = pod;
    }

    public String getOverValue() {
        return overValue;
    }

    public void setOverValue(String overValue) {
        this.overValue = overValue;
    }

    public String getPlugCd() {
        return plugCd;
    }

    public void setPlugCd(String plugCd) {
        this.plugCd = plugCd;
    }

    public String getOutVessel() {
        return outVessel;
    }

    public void setOutVessel(String outVessel) {
        this.outVessel = outVessel;
    }

    public String getOutVoyage() {
        return outVoyage;
    }

    public void setOutVoyage(String outVoyage) {
        this.outVoyage = outVoyage;
    }

    public String getSeal1() {
        return seal1;
    }

    public void setSeal1(String seal1) {
        this.seal1 = seal1;
    }

    public String getSeal2() {
        return seal2;
    }

    public void setSeal2(String seal2) {
        this.seal2 = seal2;
    }

    public String getSeal3() {
        return seal3;
    }

    public void setSeal3(String seal3) {
        this.seal3 = seal3;
    }

    public String getSeal4() {
        return seal4;
    }

    public void setSeal4(String seal4) {
        this.seal4 = seal4;
    }

    public String getSeal5() {
        return seal5;
    }

    public void setSeal5(String seal5) {
        this.seal5 = seal5;
    }

    public String getnPod() {
        return nPod;
    }

    public void setnPod(String nPod) {
        this.nPod = nPod;
    }

    public String getfPod() {
        return fPod;
    }

    public void setfPod(String fPod) {
        this.fPod = fPod;
    }
    public String getUsrId() {
        return usrId;
    }

    public void setUsrId(String usrId) {
        this.usrId = usrId;
    }

    @Override
    public String toString() {
        return "AtomContainer [cntrNo=" + cntrNo + ", cntrIso=" + cntrIso
                + ", opr=" + opr + ", cntrWgt=" + cntrWgt + ", cls=" + cls
                + ", fullMty=" + fullMty + ", pod=" + pod + ", overValue="
                + overValue + ", plugCd=" + plugCd + ", outVessel=" + outVessel
                + ", outVoyage=" + outVoyage + ", seal1=" + seal1 + ", seal2="
                + seal2 + ", seal3=" + seal3 + ", seal4=" + seal4 + ", seal5="
                + seal5 + ", nPod=" + nPod + ", fPod=" + fPod + ", usrId="
                + usrId + "]";
    }

}
