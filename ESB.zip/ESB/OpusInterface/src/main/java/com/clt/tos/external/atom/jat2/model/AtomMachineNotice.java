package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;

public class AtomMachineNotice implements Serializable {
    private static final long serialVersionUID = -8773207003138915463L;

    private String mchnId;
    private String mchnTp;
    private String notice;
    
    public String getMchnId() {
        return mchnId;
    }
    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }
    public String getMchnTp() {
        return mchnTp;
    }
    public void setMchnTp(String mchnTp) {
        this.mchnTp = mchnTp;
    }
    public String getNotice() {
        return notice;
    }
    public void setNotice(String notice) {
        this.notice = notice;
    }
    
    @Override
    public String toString() {
        return "AtomMachineNotice [mchnId=" + mchnId + ", mchnTp=" + mchnTp
                + ", notice=" + notice + "]";
    }
    
}
