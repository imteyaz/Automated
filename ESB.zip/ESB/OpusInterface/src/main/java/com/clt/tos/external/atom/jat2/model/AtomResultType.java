package com.clt.tos.external.atom.jat2.model;

public enum AtomResultType {
    SUCCESS, FAIL;
}
