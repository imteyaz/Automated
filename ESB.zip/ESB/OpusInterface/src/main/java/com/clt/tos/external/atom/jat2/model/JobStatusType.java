package com.clt.tos.external.atom.jat2.model;

public class JobStatusType {

}
