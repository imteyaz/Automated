package com.clt.tos.external.atom.jat2.model;

import java.io.Serializable;
import java.util.List;

public class AtomItv implements Serializable {
    private static final long serialVersionUID = -4198381737050043799L;
    private String mchnId;
    private String mchnTp;
    private boolean logOn;
    private boolean on;
    private String mchnSts;
    private String vrtlFlg;
    private String noticeMsg;
    List<String> loginUsrLst;

    public String getMchnId() {
        return mchnId;
    }

    public void setMchnId(String mchnId) {
        this.mchnId = mchnId;
    }

    public String getMchnTp() {
        return mchnTp;
    }

    public void setMchnTp(String mchnTp) {
        this.mchnTp = mchnTp;
    }

    public boolean isLogOn() {
        return logOn;
    }

    public void setLogOn(boolean logOn) {
        this.logOn = logOn;
    }

    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    public String getMchnSts() {
        return mchnSts;
    }

    public void setMchnSts(String mchnSts) {
        this.mchnSts = mchnSts;
    }

    public String getVrtlFlg() {
        return vrtlFlg;
    }

    public void setVrtlFlg(String vrtlFlg) {
        this.vrtlFlg = vrtlFlg;
    }

    public String getNoticeMsg() {
        return noticeMsg;
    }

    public void setNoticeMsg(String noticeMsg) {
        this.noticeMsg = noticeMsg;
    }

    public List<String> getLoginUsrLst() {
        return loginUsrLst;
    }

    public void setLoginUsrLst(List<String> loginUsrLst) {
        this.loginUsrLst = loginUsrLst;
    }

    @Override
    public String toString() {
        return "AtomItv [mchnId=" + mchnId + ", mchnTp=" + mchnTp + ", logOn="
                + logOn + ", on=" + on + ", mchnSts=" + mchnSts + ", vrtlFlg="
                + vrtlFlg + ", noticeMsg=" + noticeMsg + ", loginUsrLst="
                + loginUsrLst + "]";
    }
}
