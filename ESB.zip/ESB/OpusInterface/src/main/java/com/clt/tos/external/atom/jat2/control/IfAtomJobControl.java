package com.clt.tos.external.atom.jat2.control;

import com.clt.tos.external.atom.jat2.model.AtomPickedContainer;
import com.clt.tos.external.atom.jat2.model.AtomQcJobDone;
import com.clt.tos.external.atom.jat2.model.AtomResultJobDone;
import com.clt.tos.external.atom.jat2.model.AtomVmtWorkOrder;
import com.clt.tos.external.atom.jat2.model.AtomYcJobDone;

import java.util.List;

public abstract interface IfAtomJobControl {
    public abstract List<AtomVmtWorkOrder> getJobOrderList(String machineId,
            String machineType) throws Exception;

    public abstract String setPickedContainer(
            AtomPickedContainer atomPickedContainer1,
            AtomPickedContainer atomPickedContainer2) throws Exception;

    public abstract String setJobDone(AtomYcJobDone atomYcJobDone)
            throws Exception;

    public abstract List<AtomResultJobDone> setJobDoneByQcList(
            List<AtomQcJobDone> qcJobDoneList) throws Exception;

    public abstract String setJobStatus(List<String> jobKeys,
            String jobStatusType, String yardCraneNo, String userId)
            throws Exception;

    public abstract boolean changePositionOnChassis(String jobKey, String ytNo,
            String positionOnChassis, String usrId) throws Exception;

    public abstract List<AtomVmtWorkOrder> getJobOrderByContainer(java.lang.String arg0)
            throws java.lang.Exception;
}
