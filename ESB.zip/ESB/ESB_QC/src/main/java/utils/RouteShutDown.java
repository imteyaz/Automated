package utils;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class RouteShutDown implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        CamelContext context = exchange.getContext();
        context.getShutdownStrategy().setTimeout(1);
        context.stopRoute("ITV_DriveInstrNotif");
    }
}
