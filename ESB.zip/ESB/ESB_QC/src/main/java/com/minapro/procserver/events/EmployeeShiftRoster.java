package com.minapro.procserver.events;

public class EmployeeShiftRoster {
    private String employeeId;
    private String employeeName;
    private String equipmentId;
    private String shiftLocation;
    private String shiftType;   
    private String shiftTime;
    private String shiftEnd;
    
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getShiftLocation() {
        return shiftLocation;
    }

    public void setShiftLocation(String shiftLocation) {
        this.shiftLocation = shiftLocation;
    }

    public String getShiftType() {
        return shiftType;
    }

    public void setShiftType(String shiftType) {
        this.shiftType = shiftType;
    }

    public String getShiftTime() {
        return shiftTime;
    }

    public void setShiftTime(String shiftTime) {
        this.shiftTime = shiftTime;
    }

    public String getShiftEnd() {
        return shiftEnd;
    }

    public void setShiftEnd(String shiftEnd) {
        this.shiftEnd = shiftEnd;
    }

    @Override
    public String toString() {
        return "EmployeeShiftRoster [employeeId=" + employeeId
                + ", employeeName=" + employeeName + ", equipmentId="
                + equipmentId + ", shiftLocation=" + shiftLocation
                + ", shiftType=" + shiftType + ", shiftTime=" + shiftTime
                + ", shiftEnd=" + shiftEnd + "]";
    }
}
