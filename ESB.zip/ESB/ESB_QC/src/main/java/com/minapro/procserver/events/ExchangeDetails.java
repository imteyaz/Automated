package com.minapro.procserver.events;

import java.io.Serializable;

public class ExchangeDetails implements Serializable{
    
    private static final long serialVersionUID = -5769441097489327442L;

    private String containerId;
    
    /**
     * Source/planned location for the container
     */
    private String sourceLocation;
    
    /**
     * target/actual location of the container
     */
    private String targetLocation;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getSourceLocation() {
        return sourceLocation;
    }

    public void setSourceLocation(String sourceLocation) {
        this.sourceLocation = sourceLocation;
    }

    public String getTargetLocation() {
        return targetLocation;
    }

    public void setTargetLocation(String targetLocation) {
        this.targetLocation = targetLocation;
    }

    @Override
    public String toString() {
        return "ExchangeDetails [containerId=" + containerId + ", sourceLocation=" + sourceLocation
                + ", targetLocation=" + targetLocation + "]";
    }   
}
