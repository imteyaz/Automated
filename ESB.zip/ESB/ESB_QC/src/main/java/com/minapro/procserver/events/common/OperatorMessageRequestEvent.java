package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the request to get operator specific messages form TOS 
 * 
 * @author Rosemary George
 *
 */
public class OperatorMessageRequestEvent extends Event implements Serializable{

    private static final long serialVersionUID = -6788155877565704237L;

    /**
     * Holds the list of equipments currently logged in ATOM
     */
    private List<String> loggedInEquipments;
    
    public List<String> getLoggedInEquipments() {
        return loggedInEquipments;
    }

    public void setLoggedInEquipments(List<String> loggedInEquipments) {
        this.loggedInEquipments = loggedInEquipments;
    }

    @Override
    public String toString() {
        return "OperatorMessageRequestEvent [loggedInEquipments=" + loggedInEquipments + ", getEventID()="
                + getEventID() + "]";
    }   
}
