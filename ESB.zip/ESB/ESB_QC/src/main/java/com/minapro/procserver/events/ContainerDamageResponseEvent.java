package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

/**
 * ValueObject holding the status of the container damage recording in ESB
 * @author Rosemary George
 *
 */
public class ContainerDamageResponseEvent extends Event implements Serializable{

    private static final long serialVersionUID = -2542294540953018388L;

    List<DamageResponseDetails> dmgResponseDetails;

    public List<DamageResponseDetails> getDamageDeatils() {
        return dmgResponseDetails;
    }

    public void setDamageDeatils(List<DamageResponseDetails> damageDeatils) {
        this.dmgResponseDetails = damageDeatils;
    }

    @Override
    public String toString() {
        return "ContainerDamageResponseEvent [damageDeatils=" + dmgResponseDetails 
                + " getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()="
                        + getEventID() + "]";
    }
    
}
