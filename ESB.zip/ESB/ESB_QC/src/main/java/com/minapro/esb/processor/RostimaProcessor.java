package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import utils.DateUtils;

import com.minapro.esb.common.RostimaStrings;
import com.minapro.procserver.events.common.LoginEvent;

public class RostimaProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(RostimaProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
                
        LoginEvent loginEvent = (LoginEvent) exchange
                .getProperty("QCloginEvent");
        org.apache.log4j.MDC.put("app.name", "RostimaProcessor");
        LOGGER.info("Calling QC ROSTIMA for processing Login Event request..."+loginEvent);
        
        if (loginEvent != null) {
            String userId = loginEvent.getUserID();        
            String date = DateUtils.parseDate(loginEvent.getTimeStamp());
           
            String toRost = "jetty:" + RostimaStrings.getUrl() + "?"
                    + RostimaStrings.getUserIdParameter() + "=" + userId + "&"
                    + RostimaStrings.getStartDateParameter() + "=" + date
                    + "&" + RostimaStrings.getEndDateParameter() + "="
                    + date;
            exchange.setProperty("toRostima", toRost);
            exchange.setProperty("Login", loginEvent);            
            exchange.getOut().setHeader("rostimaString", toRost);      
            
            LOGGER.info("QC Login event : "+loginEvent.getEventID()+"  with userID : "+userId+" Rostima URL formed--> " + toRost);           
        }
    }
}
