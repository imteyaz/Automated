package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.PlannedMovesEvent;
import com.minapro.procserver.events.PlannedMovesRequestEvent;
import com.minapro.procserver.events.PlannedMovesResponseEvent;

public class QCPlannedMoveEventProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(QCPlannedMoveEventProcessor.class);
    
    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Begin of QCPlannedMoveEventProcessor... ");

        try {
            PlannedMovesRequestEvent movesRequestEvent = (PlannedMovesRequestEvent) exchange
                    .getProperty("QCplannedMovesRequestEvent");

            LOGGER.info("Request received for QC planned moves --> "
                    + movesRequestEvent);

            if (movesRequestEvent != null) {

                List<PlannedMovesEvent> movesEventsList = getPlannedMoveList(
                        exchange, movesRequestEvent.getPlannedMovesRequest());
                PlannedMovesResponseEvent movesResponseEvent = new PlannedMovesResponseEvent();
                movesResponseEvent.setEquipmentID(movesRequestEvent
                        .getEquipmentID());
                movesResponseEvent.setEventID(movesRequestEvent.getEventID());
                movesResponseEvent.setPlannedMovesResponseList(movesEventsList);
                movesResponseEvent.setTerminalID(movesRequestEvent
                        .getTerminalID());
                movesResponseEvent.setUserID(movesRequestEvent.getUserID());

                exchange.getOut().setBody(movesResponseEvent);
                exchange.setProperty("PlannedMoves", "yes");
                exchange.setProperty("routed", null);

                LOGGER.info("Planned moves Response event is "
                        + movesResponseEvent);
                LOGGER.debug("End of QCPlannedMoveEventProcessor... ");
            }
        } catch (Exception e) {
            LOGGER.error(
                    "Exception occured while processing QC Planned Moves Event : ",
                    e);
        }
    }

    private List<PlannedMovesEvent> getPlannedMoveList(Exchange exchange,
            List<PlannedMovesEvent> movesEvents) throws SQLException {
        List<PlannedMovesEvent> plannedMovesEventsList = new ArrayList<PlannedMovesEvent>();

        Connection connection = null;
        ResultSet resultSet = null;
        PreparedStatement plannedMoveStatement = null;

        try {
            connection = getDBConnection(exchange, Constants.PRTOSD_MP);
            LOGGER.debug("Connection established with PRTOSD DB ");
            plannedMoveStatement = connection
                    .prepareStatement(Constants.QUERY_PLANNED_MOVES);
            for (PlannedMovesEvent plannedMoveEvent : movesEvents) {
                int plannedMoves = 0;
                plannedMoveStatement.setString(1,
                        plannedMoveEvent.getRotationId());
                plannedMoveStatement.setString(2,
                        plannedMoveEvent.getRotationId());
                plannedMoveStatement.setString(3, plannedMoveEvent.getPow());

                resultSet = plannedMoveStatement.executeQuery();
                List<String> plannedContainerIds = new ArrayList<String>();
                while (resultSet != null && resultSet.next()) {
                    String containerId = resultSet.getString("containerId");
                    plannedContainerIds.add(containerId);
                    plannedMoves++;
                }
                plannedMoveEvent.setPlannedMoves(plannedMoves);
                plannedMoveEvent.setPlannedContainerIds(plannedContainerIds);
                LOGGER.info("Planned Moves for " + plannedMoveEvent.getPow()
                        + " is " + plannedMoveEvent.getPlannedMoves());

                plannedMovesEventsList.add(plannedMoveEvent);
            }
        } catch (Exception e) {
            LOGGER.error(
                    "Exception occured while executing QC Planned Moves DB query : ",
                    e);
        } finally {

            if (resultSet != null) {
                resultSet.close();
            }
            if (plannedMoveStatement != null) {
                plannedMoveStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
        return plannedMovesEventsList;
    }

    /**
     * Get Datasource connection
     * 
     * @throws SQLException
     */
    @SuppressWarnings("deprecation")
    private Connection getDBConnection(Exchange exchange, String dataSoureName)
            throws SQLException {
        DataSource dataSource = (DataSource) exchange.getContext()
                .getRegistry().lookup(dataSoureName);
        return dataSource.getConnection();
    }
}
