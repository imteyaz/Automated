package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the update bay view response details from ESB, contains a list of container objects
 * 
 * @author Rosemary George
 *
 */
public class UpdateBayViewResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = 3143833218507941453L;

    /**
     * List of containers which has updated stowage position
     */
    private List<BayProfileContainer> updatedContainerList;
    
    /**
     * List of containers which are not found in DPW systems
     */
    private List<String> unLocatedContainerList;

    public List<BayProfileContainer> getUpdatedContainerList() {
        return updatedContainerList;
    }

    public void setUpdatedContainerList(List<BayProfileContainer> updatedContainerList) {
        this.updatedContainerList = updatedContainerList;
    }

    public List<String> getUnLocatedContainerList() {
        return unLocatedContainerList;
    }

    public void setUnLocatedContainerList(List<String> unLocatedContainerList) {
        this.unLocatedContainerList = unLocatedContainerList;
    }

    @Override
    public String toString() {
        return "UpdateBayViewResponseEvent [updatedContainerList=" + updatedContainerList + ", unLocatedContainerList="
                + unLocatedContainerList + "]";
    }
}
