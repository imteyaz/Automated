package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the moves to go request details from device
 * 
 * @author Rosemary George
 *
 */
public class MovesToGoRequestEvent extends Event implements Serializable{

    private static final long serialVersionUID = 4960094874218354596L;

    /**
     * Equipment for which the planned moves are requested
     */
    private String qcId;
    
    /**
     * rotation of the vessel
     */
    private String rotationId;
    
    private List<String> movesToGoContainerIds;

    public List<String> getMovesToGoContainerIds() {
        return movesToGoContainerIds;
    }

    public void setMovesToGoContainerIds(List<String> movesToGoContainerIds) {
        this.movesToGoContainerIds = movesToGoContainerIds;
    }

    public String getQcId() {
        return qcId;
    }

    public void setQcId(String qcId) {
        this.qcId = qcId;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    @Override
    public String toString() {
        return "MovesToGoRequestEvent [qcId=" + qcId + ", rotationId=" + rotationId + ", movesToGoContainerIds="
                + movesToGoContainerIds + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }       
}
