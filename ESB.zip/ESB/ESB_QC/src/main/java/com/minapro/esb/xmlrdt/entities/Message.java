package com.minapro.esb.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "message")
public class Message {

    private String msid;
    private String type;
    private String ack;
    private ErrMsg errMsg;
    private Group group;
    private Che che;
    private java.util.List<List> list;

    @XmlElement(name = "group")
    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    @XmlElement
    public ErrMsg getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(ErrMsg errMsg) {
        this.errMsg = errMsg;
    }

    @XmlAttribute(name = "ack")
    public String getAck() {
        return ack;
    }

    public void setAck(String ack) {
        this.ack = ack;
    }

    @XmlElement(name = "che")
    public Che getChe() {
        return che;
    }

    public void setChe(Che che) {
        this.che = che;
    }

    @XmlAttribute(name = "MSID")
    public String getMsid() {
        return msid;
    }

    public void setMsid(String msid) {
        this.msid = msid;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlElement(name = "list")
    public java.util.List<List> getList() {
        return list;
    }

    public void setList(java.util.List<List> list) {
        this.list = list;
    }



    @Override
    public String toString() {
        return "Message [msid=" + msid + ", type=" + type + ", ack=" + ack + ", errMsg=" + errMsg + ", group=" + group
                + ", che=" + che + ", list=" + list + "]";
    }

}
