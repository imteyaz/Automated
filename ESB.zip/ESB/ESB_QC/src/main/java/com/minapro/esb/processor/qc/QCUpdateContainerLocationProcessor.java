package com.minapro.esb.processor.qc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import utils.ExchangeRepo;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.UpdateContainerLocationEvent;
import com.minapro.procserver.events.UpdateContainerLocationResponseEvent;

public class QCUpdateContainerLocationProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(QCUpdateContainerLocationProcessor.class);

    @Override
    public void process(Exchange exchange) {

        LOGGER.info("******** In QCUpdateContainerLocationProcessor method *********");
        try {
            org.apache.log4j.MDC.put("app.name",
                    "QCUpdateContainerLocationProcessor");
            UpdateContainerLocationEvent requestEvent = (UpdateContainerLocationEvent) exchange
                    .getProperty(Constants.QC_OPERATOR
                            + Constants.UPDATE_CONTAINER_LOCATION_EVENT);
            LOGGER.info("QCUpdateContainerLocationProcessor request: "
                    + requestEvent);
            UpdateContainerLocationResponseEvent responseEvent = new UpdateContainerLocationResponseEvent();
            boolean status = false;
            String errorMessage = null;

            if (requestEvent != null && null != requestEvent.getContainerId() ) {

                String containerId = requestEvent.getContainerId();
                String contrId = (containerId != null && containerId.length()>10) ? containerId.substring(0, 10) : containerId;
                
                String contrLocation = requestEvent.getLocation();

                    // Get CRT_DATE from PROMIS DB
                    Timestamp crtDate = getContainerCRTDate(contrId);
                    LOGGER.info("CRD_DATE is " + crtDate+" for Container ID: " + containerId);
                    if (null != crtDate && null != contrLocation) {
                        updateContainerLocationIntoDB(contrId,
                                contrLocation);

                        // Get SPARCS Message from Promis DB by passing parameters crtDate & container id. Update message to SPARCS System
                        errorMessage = getSparcsMsg(requestEvent, crtDate);
                        
                    } else{
                        errorMessage = Constants.UPDATE_CONTR_ERROR;
                         LOGGER.info(errorMessage  + " ContainerID: "+containerId);
                    }
                    status = errorMessage==null? true:false;
                
                responseEvent.setEquipmentID(requestEvent.getEquipmentID());
                responseEvent.setEventID(requestEvent.getEventID());
                // SPARCS recieving only on T1 terminals for any containers
                responseEvent.setTerminalID(requestEvent.getTerminalID());
                responseEvent.setUserID(requestEvent.getUserID());
                responseEvent.setContainerId(containerId);
                responseEvent.setStatus(status);
                responseEvent.setErrorMessage(errorMessage);

                exchange.getOut().setBody(responseEvent);
                exchange.setProperty(Constants.UPDATE_CONTAINER_LOCATION_EVENT,
                        "yes");
                exchange.setProperty(Constants.ROUTED, null);
                LOGGER.info("QC UpdateContainerLocation Response sent to RDT --> "
                        + responseEvent);
            }
        } catch (Exception e) {
            LOGGER.error(
                    "Exception occured while processing QCUpdateContainerLocationProcessor request: ",
                    e);
        }
    }

    /**
     * Update container new location in PROMIS DB
     * @param containerId
     * @param contrLocation
     * @throws SQLException
     */
    private void updateContainerLocationIntoDB(String containerId,
            String contrLocation) throws SQLException {
        Connection connection = null;
        PreparedStatement updateContrLocStmt = null;
        int updateCount = 0;
        try {
            connection = getDataSource(Constants.PROMIS_DB).getConnection();
            updateContrLocStmt = connection
                    .prepareStatement(Constants.UPDATE_CONTAINER_QUERY);

            updateContrLocStmt.setString(1, contrLocation);
            updateContrLocStmt.setString(2, containerId);
            updateCount = updateContrLocStmt.executeUpdate();
            updateContrLocStmt.close();
            
            updateContrLocStmt = connection
                    .prepareStatement(Constants.UPDATE_DPALISTS_QUERY);
            updateContrLocStmt.setString(1, contrLocation);
            updateContrLocStmt.setString(2, containerId);
            updateCount += updateContrLocStmt.executeUpdate();

            if (updateCount > 1) {
                LOGGER.info("New container location " + contrLocation+" updated into PROMIS DB for Container Id : " + containerId);
            }
        } catch (SQLException e) {
            LOGGER.error("Exception occured while updating container location: ", e);
        } finally {
            if (null != connection) {
                connection.close();
            }
            if (null != updateContrLocStmt) {
                updateContrLocStmt.close();
            }
        }
    }

    /**
     * Get CRT_DATE for given containerId from CONTAINERS Table
     * @param contrId
     * @return
     * @throws SQLException
     */
    private Timestamp getContainerCRTDate(String contrId) throws SQLException {
        Connection connection = null;
        PreparedStatement crtDateStmt = null;
        ResultSet crtDateResultSet = null;
        Timestamp crtDate = null;
        try {
            connection = getDataSource(Constants.PROMIS_DB).getConnection();

            crtDateStmt = connection.prepareStatement(Constants.CRT_DATE_QUERY);
            crtDateStmt.setString(1, contrId);
            crtDateResultSet = crtDateStmt.executeQuery();
            
            while (crtDateResultSet.next()) {
                crtDate = crtDateResultSet.getTimestamp("crtDate");
                LOGGER.info(" CRT Date retreived from DB :  "+crtDate);
            }
        } catch (SQLException e) {
            LOGGER.error("Exception occured while processing query for retrieving CRDdate with containerid: "+contrId, e);
        } finally {
            if (null != connection) {
                connection.close();
            }
            if (null != crtDateStmt) {
                crtDateStmt.close();
            }
            if (null != crtDateResultSet) {
                crtDateResultSet.close();
            }
        }
        return crtDate;
    }

   /**
    * Call procedure CTMS_PKG.OPCT_ASSEMBLE_CONTR & Get SPARCS message
    * @param updateContrLocEvent 
    * (containerId, TerminalId, RotationId incase of ROB, Action as 'S',formName & addParam as null)
    * @param crtDate
    * @return
    * @throws SQLException
    */
    private String getSparcsMsg(
            UpdateContainerLocationEvent updateContrLocEvent, Timestamp crtDate)
            throws SQLException {
        Connection connection = null;
        CallableStatement sparcsMsgCallStmt = null;
        ResultSet sparcsMsgResultSet = null;
        String sparcsMsg = null;
        String errorMsg = null;

        try {
            connection = getDataSource(Constants.PROMIS_DB).getConnection();
            sparcsMsgCallStmt = connection
                    .prepareCall(Constants.GET_SPARCS_MSG_PROCEDURE);
            String containerId = updateContrLocEvent.getContainerId();
            String contrId = (containerId != null && containerId.length()>10) ? containerId.substring(0, 10) : containerId;
            String terminalId = updateContrLocEvent.getTerminalID();
            String rotn = updateContrLocEvent.getRotationId();
            Integer rotnId = null != rotn ? Integer.valueOf(rotn) : null;

            LOGGER.info("CALLING Procedure to get SPARCS message container : "+contrId+ " CRT date: "
                    + crtDate + " terminal ID: " + terminalId + " Rotation ID:"
                    + rotn + " & Action:" + Constants.ACTION_S);
            sparcsMsgCallStmt.setString(1, contrId);
            sparcsMsgCallStmt.setTimestamp(2, crtDate);
            sparcsMsgCallStmt.setObject(3, rotnId);
            sparcsMsgCallStmt.setString(4, Constants.T1);
            sparcsMsgCallStmt.setString(5, Constants.ACTION_S);
            sparcsMsgCallStmt.registerOutParameter(6, OracleTypes.VARCHAR);
            sparcsMsgCallStmt.registerOutParameter(7, OracleTypes.VARCHAR);
            sparcsMsgCallStmt.setString(8, null);
            sparcsMsgCallStmt.setString(9, null);
            
            sparcsMsgCallStmt.execute();

            errorMsg = sparcsMsgCallStmt.getString(6);
            sparcsMsg = sparcsMsgCallStmt.getString(7);

            if (null != sparcsMsg) {
                LOGGER.info("SPARCS Message received from PROMIS. Update message to SPARCS System -->> "
                        + sparcsMsg);
                errorMsg = updateContrLocToSparcs(sparcsMsg, terminalId);               
            }
            if (null != errorMsg) {
                LOGGER.info("Unable to update location in SPARCS for containerID: "+ contrId+" ERROR received from SPARCS->> " + errorMsg);
            } else {
                 LOGGER.info("New location "+updateContrLocEvent.getLocation()+" updated successfully for containerId "+contrId+" in SPARCS.");
            }
        } catch (SQLException e) {
            LOGGER.error("Exception occured while processing query: ", e);
        } finally {
            if (null != connection) {
                connection.close();
            }
            if (null != sparcsMsgCallStmt) {
                sparcsMsgCallStmt.close();
            }
            if (null != sparcsMsgResultSet) {
                sparcsMsgResultSet.close();
            }
        }
        return errorMsg;
    }

    /**
     * Call procedure OPCT_CALL_DPLIF015 Procedure to update SPARCS message (Inserts the
     * message in SPARCS Outbound Table. N/A for OPUS Terminal)
     * 
     * @param sparcsMsg
     * @return
     * @throws SQLException
     */
    private String updateContrLocToSparcs(String sparcsMsg, String terminalId)
            throws SQLException {
        Connection connection = null;
        CallableStatement sparcsMsgUpdateCallStmt = null;
        String updateErrorMsg = null;

        try {
            connection = getDataSource(Constants.OPCTJAD_DB).getConnection();
            sparcsMsgUpdateCallStmt = connection
                    .prepareCall(Constants.UPATE_SPARCS_MSG_PROCEDURE);

            sparcsMsgUpdateCallStmt.setString(1, sparcsMsg);

            sparcsMsgUpdateCallStmt.setString(2, Constants.DT);
            sparcsMsgUpdateCallStmt.setString(3, terminalId);
            sparcsMsgUpdateCallStmt.registerOutParameter(4,
                    OracleTypes.VARCHAR, Constants.P_ERROR_MSG);

            sparcsMsgUpdateCallStmt.execute();

            updateErrorMsg = sparcsMsgUpdateCallStmt.getString(4);
            if (null != updateErrorMsg) {
                LOGGER.info("ERROR Message received while update SPARCS System: "
                        + updateErrorMsg);
            }

        } catch (SQLException e) {
            LOGGER.error(
                    "Exception occured while Procedure call for SPARCS Message Update: ",
                    e);
        } finally {
            if (null != connection) {
                connection.close();
            }
            if (null != sparcsMsgUpdateCallStmt) {
                sparcsMsgUpdateCallStmt.close();
            }
        }
        return updateErrorMsg;
    }

    @SuppressWarnings("deprecation")
    private static DataSource getDataSource(String name) {
        Exchange exchange = ExchangeRepo.getExchange();
        return (DataSource) exchange.getContext().getRegistry().lookup(name);
    }
}
