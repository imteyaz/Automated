package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.Arrays;

/**
 * ValueObject holding the update job request from device. Update Job indicates
 * whether it is twin jon/split twin or Tandem.
 * 
 * @author Rosemary George
 * 
 */
public class UpdateJobRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -7114976409284716406L;

    /**
     * Indicates what kind of update is performed by the operator. Can be
     * splitting a twin job, or adding twin or tandem.
     */
    private JOB_UPDATE_TYPE updateType;

    /**
     * Contains the containers involved in the update job operation.
     */
    private String[] containerIDs;

    public JOB_UPDATE_TYPE getUpdateType() {
        return updateType;
    }

    /**
     * Sets the updateType
     * 
     * @param updateType
     */
    public void setUpdateType(String updateType) {
        if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.SPLIT.toString())) {
            this.updateType = JOB_UPDATE_TYPE.SPLIT;
        } else if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.TWIN.toString())) {
            this.updateType = JOB_UPDATE_TYPE.TWIN;
        } else if (updateType.equalsIgnoreCase(JOB_UPDATE_TYPE.TANDEM
                .toString())) {
            this.updateType = JOB_UPDATE_TYPE.TANDEM;
        } else {
            this.updateType = JOB_UPDATE_TYPE.TANDEM_SPLIT;
        }
    }

    public String[] getContainerIDs() {
        return containerIDs;
    }

    /**
     * Parses the string of containers IDs to Array
     * 
     * @param containerIDs
     */
    public void setContainerIDs(String containerIDs) {

        this.containerIDs[0] = containerIDs;

    }

    @Override
    public String toString() {
        return "UpdateJobRequestEvent [updateType=" + updateType
                + ", containerIDs=" + Arrays.toString(containerIDs)
                + ", userId=" + getUserID() + ", EquipmentID="
                + getEquipmentID() + "]";
    }

    public enum JOB_UPDATE_TYPE {
        SPLIT, TWIN, TANDEM, TANDEM_SPLIT
    }
}
