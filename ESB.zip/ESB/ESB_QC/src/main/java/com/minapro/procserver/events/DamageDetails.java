package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.Arrays;

/**
 * ValueObject holding the damage details recorded for a particular container
 * 
 * @author Rosemary George
 *
 */
public class DamageDetails implements Serializable {

	private static final long serialVersionUID = 2950523471762373627L;

	/**
	 * ID of the damaged container
	 */
	private String containerID;

	/**
	 * The ID of the ITV which is carrying the damaged container.
	 */
	private String itvId;

	/**
	 * TS area selected for the damage
	 */
	private String troubleShootAreaId;

	/**
	 * List of selected damage codes for the container
	 */
	private String[] damageCodes;

	/**
	 * List of deleted damage codes
	 */

	private String[] deletedDamageCodes;

	/**
	 * Property is used to indicate whether current damage is Major or Not.
	 * This property is true At least one of the damage codes severity is major. 
	 */
	private boolean isMajorDamage;

	public boolean isMajorDamage() {
		return isMajorDamage;
	}

	public void setMajorDamage(boolean isMajorDamage) {
		this.isMajorDamage = isMajorDamage;
	}

	public String[] getDeletedDamageCodes() {
		return deletedDamageCodes;
	}

	public void setDeletedDamageCodes(String[] deletedDamageCodes) {
		this.deletedDamageCodes = deletedDamageCodes;
	}

	public String getContainerID() {
		return containerID;
	}

	public void setContainerID(String containerID) {
		this.containerID = containerID;
	}

	public String getItvId() {
		return itvId;
	}

	public void setItvId(String itvId) {
		this.itvId = itvId;
	}

	public String getTroubleShootAreaId() {
		return troubleShootAreaId;
	}

	public void setTroubleShootAreaId(String troubleShootAreaId) {
		this.troubleShootAreaId = troubleShootAreaId;
	}

	public String[] getDamageCodes() {
		return damageCodes;
	}

	public void setDamageCodes(String[] damageCodes) {
		this.damageCodes = damageCodes;
	}

	@Override
	public String toString() {
		return "DamageDetails [containerID=" + containerID + ", itvId=" + itvId + ", troubleShootAreaId="
				+ troubleShootAreaId + ", damageCodes=" + Arrays.toString(damageCodes) + ", deletedDamageCodes="
				+ Arrays.toString(deletedDamageCodes) + ",isItMajorDamage = "+isMajorDamage+"]";
	}
}
