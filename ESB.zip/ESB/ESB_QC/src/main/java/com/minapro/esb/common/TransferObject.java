package com.minapro.esb.common;

public class TransferObject {

    private String queueName;
    private String eventTye;
    private Object object;
    private long startTime;

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getEventTye() {
        return eventTye;
    }

    public void setEventTye(String eventTye) {
        this.eventTye = eventTye;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    @Override
    public String toString() {
        return "TransferObject [queueName=" + queueName + ", eventTye=" + eventTye + ", object=" + object + "]";
    }

}
