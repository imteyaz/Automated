package com.minapro.esb.processor;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.camel.Exchange;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;

public class ProcessorSender {

    private static final Logger LOGGER = Logger.getLogger(ProcessorSender.class);

    public String sendToEndpoint(Exchange exchange) throws IOException {    
        
        String endpoint = null;
        org.apache.log4j.MDC.put("app.name", "DynamicRouter");
        String eventType = (String) exchange.getProperty(Constants.EVENT_TYPE);
        LOGGER.debug("Processing QC dynamic routing endpoint for the request... "+eventType);
        
        if (null != exchange.getProperty(eventType) && !((Boolean) exchange.getProperty(Constants.ROUTED))) {            
            Properties properties = new Properties();
            InputStream inStream = this.getClass().getClassLoader()
                    .getResourceAsStream(Constants.ENDPOINT_PROPERTIES);            
            properties.load(inStream);
            endpoint = properties.getProperty(eventType);
            exchange.setProperty(Constants.ROUTED, true);                 
        }
        LOGGER.debug(eventType+" request is routing to the enpoint --> " +endpoint);
        return endpoint;
    }
}
