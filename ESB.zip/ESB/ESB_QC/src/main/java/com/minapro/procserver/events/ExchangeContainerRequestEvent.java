package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

public class ExchangeContainerRequestEvent extends Event implements Serializable {
    
    private static final long serialVersionUID = 4135330877889890482L;
    
    private String vessel;
    private String voyage;
    private String moveType;
    private String singleTwinFlag;
    
    private List<ExchangeDetails> exchangeDetails;  

    public String getVessel() {
        return vessel;
    }
    
    public void setVessel(String vessel) {
        this.vessel = vessel;
    }
    
    public String getVoyage() {
        return voyage;
    }
    
    public void setVoyage(String voyage) {
        this.voyage = voyage;
    }
    
    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getSingleTwinFlag() {
        return singleTwinFlag;
    }
    
    public void setSingleTwinFlag(String singleTwinFlag) {
        this.singleTwinFlag = singleTwinFlag;
    }

    public List<ExchangeDetails> getExchangeDetails() {
        return exchangeDetails;
    }

    public void setExchangeDetails(List<ExchangeDetails> exchangeDetails) {
        this.exchangeDetails = exchangeDetails;
    }

    @Override
    public String toString() {
        return "ExchangeContainerRequestEvent [vessel=" + vessel + ", voyage="
                + voyage + ", moveType=" + moveType + ", singleTwinFlag="
                + singleTwinFlag + ", exchangeDetails=" + exchangeDetails
                + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }
    
}
