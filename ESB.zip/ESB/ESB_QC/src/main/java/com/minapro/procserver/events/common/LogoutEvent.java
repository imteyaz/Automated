package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the logout event details
 * 
 * @author Rosemary George
 * 
 */
public class LogoutEvent extends Event implements Serializable {

    private static final long serialVersionUID = -7320393446849173409L;

    @Override
    public String toString() {
        return "LogoutEvent [UserID()=" + getUserID() + ", EquipmentID()=" + getEquipmentID() + ", TerminalID()="
                + getTerminalID() + "]";
    }

}
