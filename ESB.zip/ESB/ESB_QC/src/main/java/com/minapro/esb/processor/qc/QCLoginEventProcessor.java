package com.minapro.esb.processor.qc;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.xmlrdt.entities.ArrayOfEmployeeRoster;
import com.minapro.esb.xmlrdt.entities.EmployeeRoster;
import com.minapro.procserver.events.common.AllocationEvent;
import com.minapro.procserver.events.common.CertificateValidateEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LoginResponseEvent;

/**
 * @author Shashank
 * 
 *         This processor QCLoginEventProcessor , is processed , when the LoginEvent is read by the QueueListener which
 *         is listening the QC queue
 * 
 */
public class QCLoginEventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(QCLoginEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Inside of QCLoginEventProcessor... ");

        org.apache.log4j.MDC.put("app.name", "LoginEventProcessor");
        Map<String, Object> map = exchange.getProperties();

        LoginEvent loginEvent = (LoginEvent) map.get("QCloginEvent");

        if (loginEvent != null) {
            LOGGER.info("QC Login successfully... ");
            ArrayOfEmployeeRoster employeeRoster = null;

            byte[] body = (byte[]) exchange.getIn().getBody();
            String fromRostima = new String(body);
            fromRostima = fromRostima.substring(1);
            LOGGER.info("Data received from the ROSTIMA after webService call. "+fromRostima);

            try {
                JAXBContext context = JAXBContext.newInstance(ArrayOfEmployeeRoster.class);
                Unmarshaller unmarshaller = context.createUnmarshaller();
                employeeRoster = (ArrayOfEmployeeRoster) unmarshaller.unmarshal(new StringReader(fromRostima));                
            } catch (Exception e) {
                LOGGER.error("QCLogin Exception occured while parsing ROSTIMA response. ", e);
            }

            AllocationEvent allocationEvent = new AllocationEvent();
            
            if (employeeRoster != null) {
                EmployeeRoster roster = employeeRoster.getRoster();
                if (roster != null) {
                    LOGGER.debug("Data Received from ROSTIMA for User " + employeeRoster.getRoster().getEmployeeNumber());
                    String shiftDate = roster.getShiftDate();
                    String shiftTime = roster.getShiftTime();
                    shiftDate = shiftDate.concat(" " + shiftTime);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                    Date shiftStartDate = dateFormat.parse(shiftDate);
                    allocationEvent.setUserID(roster.getEmployeeNumber());
                    allocationEvent.setTerminalID(roster.getShiftLocation());
                    allocationEvent.setShiftStartTime(shiftStartDate);
                }
            }

            LoginEvent lEvent = (LoginEvent) exchange.getProperty("Login");
            LoginResponseEvent responseEvent = new LoginResponseEvent();

            responseEvent.setAllocationDetails(allocationEvent);
            responseEvent.setEquipmentID(lEvent.getEquipmentID());
            responseEvent.setEventID(lEvent.getEventID());
            responseEvent.setUserID(lEvent.getUserID());
            responseEvent.setTerminalID(lEvent.getTerminalID());

            CertificateValidateEvent event = new CertificateValidateEvent();
            event.setReason("Certificates Validated");
            event.setStatus("Success");

            responseEvent.setValidateCertificateDetails(event);

            exchange.setProperty("loginReceived", "yes");
            exchange.setProperty("routed", null);
            exchange.getOut().setBody(responseEvent);           
            
            LOGGER.info("QCUser : "+lEvent.getUserID()+" log-in response sent : " + responseEvent);
        }
    }
}
