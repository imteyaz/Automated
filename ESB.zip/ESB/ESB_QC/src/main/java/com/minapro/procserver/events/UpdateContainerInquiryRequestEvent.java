package com.minapro.procserver.events;

import java.io.Serializable;

public class UpdateContainerInquiryRequestEvent extends Event implements Serializable {

    private static final long serialVersionUID = -1891944470604857211L;

    /**
     * Unique Container ID
     */
    private String containerId;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    @Override
    public String toString() {
        return "UpdateContainerInquiryRequestEvent [containerId=" + containerId
                + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID()
                + ", getEventID()=" + getEventID() + "]";
    }

}
