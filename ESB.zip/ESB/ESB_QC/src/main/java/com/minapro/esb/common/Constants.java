package com.minapro.esb.common;

public class Constants {
	public static final String QC_OPERATOR = "QC";
	public static final String COMMONQ = "COMMONQ";
	public static final String ENDPOINT_PROPERTIES = "endpoint.properties";
	public static final String EVENT_TYPE = "eventType";
	public static final String ACTION_S = "S";
	public static final String DT = "DT";
	public static final String T1 = "T1";
	public static final String T2 = "T2";
	public static final String ATOM = "ATOM";

	/*
	 * QC EVENTS
	 */
	public static final String LOGIN_EVENT = "loginEvent";
	public static final String LOGOUT_EVENT = "logoutEvent";
	public static final String CONTAINER_MOVE_EVENT = "containerMoveEvent";
	public static final String CONFIRM_ALLOCATION_EVENT = "confirmAllocationEvent";
	public static final String UPDATE_CONTAINER = "updateContainer";
	public static final String JOBLIST_EVENT = "jobList";
	public static final String OPERATOR_AVAIL_EVENT = "AvailabilityEvent";
	public static final String PLANNED_MOVES_EVENT = "plannedMovesRequestEvent";
	public static final String VESSELBERTHSIDE = "vesselBerthSide";
	public static final String ITVPOOL_EVENT = "ITVPoolRequestEvent";
	public static final String UPDATE_CONTAINER_LOCATION_EVENT = "UpdateContainerLocationEvent";
	public static final String BAY_VIEW_EVENT = "BayView";
	public static final String MOVES_TO_GO_EVENT = "ContainerMovesToGoEvent";
	public static final String KEEPALIVE_EVENT = "KeepAliveEvent";
	public static final String CONTR_INQUIRY_EVENT = "ContainerInquiryEvent";
	public static final String EXCHANGE_CONTAINER_EVENT = "ExchangeContainerEvent";
	public static final String UPDATE_CONTR_INQUIRY_EVENT = "UpdateContainerInquiryEvent";
	public static final String SWAP_EVENT = "SwapEvent";
	public static final String OPERATOR_MSG_EVENT = "OperatorMessageEvent";
	public static final String ITV_SWAP_EVENT = "ITVSwapEvent";

	public static final String ROUTED = "routed";

	/*
	 * container Damage constants
	 */
	public static final String CONTR_DAMAGE_MSG = "1052";
	public static final String CONTR_DAMAGE_ZEROS = "00000000";
	public static final String CONTR_DAMAGE_CODE_SEPERATOR = "damage.code.seperator";
	public static final String CONTR_DAMAGE_EVENT = "containerDamage";
	public static final String CONTAINER_DAMAGE_EVENT = "ContainerDamageEvent";
	public static final String SPACE = " ";

	/*
	 * Errors
	 */
	public static final String DAMAGE_RECORDING_ERROR = "Unable to insert container damage details into DB";

	/*
	 * Datasource names
	 */
	public static final String PROMIS_DB = "PromisDataSource";
	public static final String DPWJA_DB = "DPWJAProdDataSource";
	public static final String PRTOSD_MP = "PrtosmpdDataSource";
	public static final String PRTOSD = "PrtosdDataSource";
	public static final String OPCTJAD_DB = "OPCTJADDataSource";
	public static final String PRTOS_DBA = "PRTOSDBADataSource";

	/*
	 * Query Constants
	 */
	public static final String STOWG = "stowg";
	public static final String PLAN_STOWG = "plan_stowage";
	public static final String LOAD = "LOAD";
	public static final String DISCHARGE = "DSCH";
	public static final String COMMA_DELIMITER = ",";
	public static final String SLASH_DELIMITER = "/";

	/*
	 * select query IN CLAUSE parameter limit
	 */
	public static final int IN_PARAMETER_LIMIT = 1000;

	/*
	 * DB Queries
	 */

	public static final String QUERY_PLANNED_MOVES = "select CNTR_ID as containerId "
			+ "from BPA_CONTR_MOVES "
			+ "where Terminal_ID = 'T2' and MSG_TYPE = '7043' "
			+ "and is_valid = 1 and "
			+ "(inbound_carrier = ? OR outbound_carrier = ?) and "
			+ "WORK_QUEUE_POINT_OF_WORK = ?";

	public static final String GET_DPA_CONTIANERS_LIST_QUERY = "select "
			+ "dpa_lists.contr_no || containers.chk_digit as containerId, "
			+ "dpa_lists.disch_port as pod, "
			+ "containers.new_iso_code as isoCode,"
			+ "dpa_lists.wt as weight,"
			+ "dpa_lists.un_no as unNo, "
			+ "dpa_lists.un_no2 as unNo2, "
			+ "dpa_lists.un_no3 as unNo3, "
			+ "containers.contr_cat_status as containerEmpty,"
			+ "dpa_lists.og as oog,"
			+ "containers.contr_len as containerSize,"
			+ "dpa_lists.list_code as moveType,"
			+ "containers.reef_appl_code as reefer,"
			+ "containers.dmg_descr as damaged,  "
			+ "NVL(dpa_lists.plan_stowg,dpa_lists.stowg) as stowage, "
			+ "dpa_lists.contr_cat as category "
			+ "from dpa_lists inner join containers "
			+ "on dpa_lists.contr_no=containers.contr_no "
			+ "where dpa_lists.rotn=? "
			+ "and containers.act_code ='Y' "
			+ "and NVL(substr(dpa_lists.plan_stowg, 1, 2),substr(dpa_lists.stowg, 1, 2))=? "
			+ "and NVL(substr(dpa_lists.plan_stowg, 5, 2),substr(dpa_lists.stowg, 5, 2))";

	/**
	 * public static final String GET_ROB_CONTIANERS_LIST_QUERY =
	 * "select distinct" +
	 * " containers.contr_no || containers.chk_digit as containerId, " +
	 * " rob_lists.disch_port as pod, " +
	 * " containers.new_iso_code as isoCode, " + " rob_lists.wt as weight," +
	 * " rob_lists.un_no as unNo,  " + " rob_lists.un_no2 as unNo2,  " +
	 * " rob_lists.un_no3 as unNo3,  " +
	 * " containers.contr_cat_status as containerEmpty, " +
	 * " rob_lists.og as oog," + " containers.contr_len as containerSize," +
	 * " null as moveType, " + " containers.reef_appl_code as reefer, " +
	 * " containers.dmg_descr as damaged, " + " rob_lists.stowg as stowage," +
	 * " rob_lists.contr_cat as category  " +
	 * " from rob_lists inner join containers on rob_lists.contr_no=containers.contr_no "
	 * + " where rob_lists.rotn=? and containers.act_code ='Y' " +
	 * " and substr(rob_lists.stowg, 1, 2)=? and substr(rob_lists.stowg, 5, 2)";
	 */

	public static final String GET_ROB_CONTIANERS_LIST_QUERY = "select distinct"
			+ " contr_no||chk_digit as containerId, "
			+ " rob_lists.disch_port as pod, "
			+ " new_iso_code as isoCode, "
			+ " rob_lists.wt as weight, "
			+ " rob_lists.un_no as unNo,  "
			+ " rob_lists.un_no2 as unNo2,  "
			+ " rob_lists.un_no3 as unNo3,  "
			+ " contr_cat_status as containerEmpty,  "
			+ " rob_lists.og as oog, "
			+ " NULL as containerSize,"
			+ " NULL as moveType, "
			+ " NULL as reefer, "
			+ " NULL as damaged, "
			+ " rob_lists.stowg as stowage,"
			+ " rob_lists.contr_cat as category   "
			+ " from rob_lists  "
			+ " where rob_lists.rotn=? "
			+ " and substr(rob_lists.stowg, 1, 2)=? and substr(rob_lists.stowg, 5, 2)";

	public static final String GET_DPA_SELECT_BAY_CONTIANERS_LIST_QUERY = "select dpa_lists.contr_no || containers.chk_digit as containerId,"
			+ " dpa_lists.disch_port as pod, containers.new_iso_code as isoCode,"
			+ " containers.contr_len as containerSize, dpa_lists.wt as weight,"
			+ " dpa_lists.list_code as moveType, containers.reef_appl_code as reefer,"
			+ " containers.contr_cat_status as containerEmpty, dpa_lists.og as oog,"
			+ " containers.dmg_descr as damaged, dpa_lists.plan_stowg as plan_stowage,"
			+ " dpa_lists.un_no as unNo, "
			+ " dpa_lists.un_no2 as unNo2, "
			+ " dpa_lists.un_no3 as unNo3, "
			+ " dpa_lists.stowg as stowg, dpa_lists.contr_cat as category from dpa_lists "
			+ " inner join containers on dpa_lists.contr_no=containers.contr_no "
			+ " where dpa_lists.contr_no=? and dpa_lists.rotn=?"
			+ " and containers.act_code ='Y' ";

	/**
	 * public static final String GET_ROB_UPDATE_BAY_CONTIANERS_LIST_QUERY =
	 * "select distinct containers.contr_no || containers.chk_digit as containerId,"
	 * + " rob_lists.disch_port as pod," +
	 * " containers.new_iso_code as isoCode," +
	 * " containers.contr_len as containerSize, rob_lists.wt as weight," +
	 * " null as moveType," + " containers.reef_appl_code as reefer," +
	 * " rob_lists.un_no as unNo, " + " rob_lists.un_no2 as unNo2, " +
	 * " rob_lists.un_no3 as unNo3, " +
	 * " containers.contr_cat_status as containerEmpty, rob_lists.og as oog," +
	 * " containers.dmg_descr as damaged," + " null as plan_stowage," +
	 * " rob_lists.stowg as stowg," + " rob_lists.contr_cat as category " +
	 * " from rob_lists inner join containers " +
	 * " on rob_lists.contr_no=containers.contr_no " +
	 * " where rob_lists.contr_no=? " +
	 * " and rob_lists.rotn=? and containers.act_code ='Y' ";
	 */

	public static final String GET_ROB_UPDATE_BAY_CONTIANERS_LIST_QUERY = "select distinct contr_no||chk_digit as containerId,"
			+ " rob_lists.disch_port as pod,"
			+ " new_iso_code as isoCode,"
			+ " rob_lists.wt as weight,"
			+ " rob_lists.un_no as unNo, "
			+ " rob_lists.un_no2 as unNo2, "
			+ " rob_lists.un_no3 as unNo3, "
			+ " contr_cat_status as containerEmpty, "
			+ " rob_lists.og as oog,"
			+ " NULL as containerSize, "
			+ " null as moveType,"
			+ " NULL as reefer,"
			+ " NULL as damaged,"
			+ " null as plan_stowage,"
			+ " rob_lists.stowg as stowg,"
			+ " rob_lists.contr_cat as category  "
			+ " from rob_lists "
			+ " where rob_lists.contr_no=? " + " and rob_lists.rotn=? ";

	public static final String VESSEL_BERTHSIDE_QUERY = "select VSTC from VESSEL_UPDATES where MSG_TYPE = 7053 "
			+ "and is_valid=1 and terminal='T2' and ROTN = ?";

	public static final String INSERT_CONTIANER_DAMAGE_LIST_QUERY = "INSERT INTO TOS_TO_PROMIS_STAGING "
			+ "(SEQ_NO, MSG_TYPE, PORT_CODE,"
			+ "TERMINAL, SOURCE_SYSTEM, SOURCE_OBJECT,"
			+ " CONTAINER_NO, CRT_DATE, DAMAGE_CODE) "
			+ "Values "
			+ "(PRTOS_DBA.SEQ_TOS_TO_PROMIS_STAGING.NEXTVAL,'9016','J',"
			+ "'T2','ATOM','ATOM',"
			+ "?,?,?)";
				
	public static final String CRT_DATE_QUERY = "select crt_date as crtDate"
			+ " from   containers" + " where  contr_no = ? and act_code = 'Y'";

	public static final String CNTR_CRT_DATE_QUERY = "SELECT TO_CHAR(CRT_DATE,'YYYYMMDDHH24MISS') CRT_DATE"
			+ " FROM CONTAINERS C "
			+ " WHERE C.CONTR_NO||C.CHK_DIGIT = ? "
			+ " AND C.ACT_CODE = 'Y'";

	public static final String CNTR_CRT_DATE__ROB_QUERY =" SELECT CRT_DATE FROM "
			+ " (SELECT TO_CHAR(CRT_DATE,'YYYYMMDDHH24MISS') as CRT_DATE FROM CONTAINERS C "
			+ "WHERE C.CONTR_NO||C.CHK_DIGIT = ? AND C.ACT_CODE = 'Y'  "
			+ "UNION  SELECT TO_CHAR(CRT_DATE,'YYYYMMDDHH24MISS') as CRT_DATE "
			+ "FROM ROB_LISTS R WHERE R.CONTR_NO||R.CHK_DIGIT = ? AND R.ROTN = ? "
			+ "AND R.LOAD_PORT NOT IN ('JEB','AEJEB')  "
			+ "AND R.DISCH_PORT NOT IN ('JEB','AEJEB'))  WHERE ROWNUM = 1";

	public static final String UPDATE_CONTAINER_QUERY = "UPDATE CONTAINERS SET CURR_LOCN =? WHERE CONTR_NO = ?";
	public static final String UPDATE_DPALISTS_QUERY = "UPDATE DPA_LISTS SET STOWG = ? "
			+ "WHERE CONTR_NO = ?";

	/**
	 * PROCEDURE for 7041 for Container update location at vessel
	 */
	/**
	 * Call Procedure from PROMIS DB DPWJAPROD.DPW_IVR_GET_SCHEDULE(
	 * P_EMPLOYEENUMBER IN VARCHAR2, P_STARTDATE IN VARCHAR2, P_ENDDATE IN
	 * VARCHAR2, CV_REFROSTER OUT SYS_REFCURSOR)
	 */
	public static final String GET_SHIFT_SCHEDULE_PROCEDURE = "{call DPWJAPROD.DPW_IVR_GET_SCHEDULE(?,?,?,?)}";
	public static final String GET_USERS_QUERY = "SELECT U.INT_USER_ID as userId FROM MP_USERDTLS_AM U";
	public static final String DELETE_SHIFT_MASTER_DETAILS_QUERY = "DELETE FROM MP_SHIFT_MASTER WHERE USER_ID = ?";
	public static final String INSERT_SHIFT_MASTER_QUERY = "INSERT INTO MP_SHIFT_MASTER "
			+ "(RECORD_ID, USER_ID, TERMINAL_ID, SHIFT_TYPE, START_DATETIME, END_DATETIME, CREATED_BY, CREATED_DATETIME, VERSION)"
			+ "VALUES(MP_SHIFT_MASTER_RECORD_ID_SEQ.nextval,?,?,?,?,?,?,?,'1')";

	/*
	 * Call Procedure from PROMIS DB
	 */
	public static final String GET_SPARCS_MSG_PROCEDURE = "{call CTMS_PKG.OPCT_ASSEMBLE_CONTR(?,?,?,?,?,?,?,?,?)}";
	public static final String UPATE_SPARCS_MSG_PROCEDURE = "{call OPCT_CALL_DPLIF015(?,?,?,?)}";

	/*
	 * Procedure constants for 7041
	 */
	public static final String P_ERROR_MSG = "P_ERROR_MSG";
	public static final String P_MSG = "P_MSG";
	public static final String UPDATE_CONTR_ERROR = "No CRTDate or Location details found for given containerId ";

	/*
	 * Container Moves to go for container operations
	 */
	public static final String GET_MOVESTOGO_QUERY_START = "select moveType, containerSize, containerEmpty, oog, count(oog) as oogCount  "
			+ "from  "
			+ "( Select decode(dpa_lists.list_code,'L','LOAD','D','DSCH') as moveType,  "
			+ "CASE containers.contr_len WHEN 20 THEN '20' ELSE '40' END  as containerSize,  "
			+ "containers.contr_cat_status as containerEmpty,  "
			+ "dpa_lists.og as oog  "
			+ "from dpa_lists inner join containers  "
			+ "on dpa_lists.contr_no=containers.contr_no  "
			+ "where containers.act_code ='Y' "
			+ "and containers.contr_cat_status in ('F','E')  "
			+ "and dpa_lists.og is not null "
			+ "and dpa_lists.rotn=? "
			+ "and dpa_lists.contr_no in ";

	public static final String GET_MOVESTOGO_QUERY_END = " order by dpa_lists.list_code,containers.contr_len) "
			+ "group by moveType, containerSize, containerEmpty, oog  ";

	/*
	 * Query for Container Inquiry
	 */

	private static final String YARD_QUERY = "SELECT a.last_move_date"
			+ " FROM opctjad_dba.containers a"
			+ " WHERE a.contr_position = 'YRD'" + " AND a.act_code = 'Y'"
			+ " AND a.desig IN ('FCL', 'EXP', 'T/S')"
			+ " AND a.contr_no = dpaLists.Contr_No ";

	private static final String INBOUND_VESSEL_NAME = "(select vess_name from voyages v where v.rotn = cont.last_disch_rotn) as InboundVsl, ";
	private static final String OUTBOUND_VESSEL_NAME = "(select vess_name from voyages v where v.rotn = cont.last_load_rotn)  as OutboundVsl, ";

	public static final String CONTR_INQUIRY_QUERY = "Select dpaLists.contr_no || cont.chk_digit as ContainerNo,"
			+ " cont.new_iso_code as ISOCode, dpaLists.Line_Code as LineCode,"
			+ " cont.do_agent as Agent, dpaLists.Terminal_Id as Terminal,"
			+ " (CASE dpaLists.list_code"
			+ " WHEN 'L' THEN 'Load'"
			+ " WHEN 'D' THEN 'Discharge'"
			+ " ELSE 'OTHERS' END) as MoveKind,"
			+ " cont.contr_position as ContainerPos, null as STODays,"
			+ " dpaLists.List_Status as Status,"
			+ " (CASE dpaLists.Contr_Cat"
			+ " WHEN 'I' THEN 'Import'"
			+ " WHEN 'E' THEN 'Export'"
			+ " ELSE 'Transhipment' END) as Category," + " ("
			+ YARD_QUERY
			+ ") as YardIn,"
			+ " ("
			+ YARD_QUERY
			+ " AND a.contr_status <> '01') as YardOut,"
			+ " nvl2(cont.stop_descr, 'Yes', 'No') as Stop, cont.stop_descr as Reason,"
			+ " dpaLists.Damage_Ind as DamageInd,"
			+ " cont.Dmg_Descr as Damage, "
			+ INBOUND_VESSEL_NAME
			+ " cont.last_disch_rotn as InboubdRotation, "
			+ OUTBOUND_VESSEL_NAME
			+ " cont.last_load_rotn as OutboundRotation, "
			+ " (SELECT a.consgn_code"
			+ " FROM opctjad_dba.agent_requests a, opctjad_dba.container_moves b"
			+ " WHERE a.req_no = b.req_no"
			+ " AND b.contr_no = dpaLists.Contr_No"
			+ " AND b.desig = 'EXP'"
			+ " AND b.move_type IN ('12', '18')"
			+ " AND b.act_move_date ="
			+ " (SELECT MAX(act_move_date)"
			+ " FROM opctjad_dba.container_moves c"
			+ " WHERE b.contr_no = c.contr_no"
			+ " AND b.crt_date = c.crt_date"
			+ " AND c.move_type <> '10')) as Shipper,"
			+ " dpaLists.Consg_Code as Consignee,"
			+ " dpaLists.Disch_Port as POD,"
			+ " dpaLists.Dest_Port as Destination,"
			+ " dpaLists.Load_Port as LoadPort,"
			+ " dpaLists.Origin_Port as OriginPort,"
			+ " nvl2(dpaLists.Seal_No, 'Yes', 'No') as Seal,"
			+ " dpaLists.Seal_No as SealNo,"
			+ " dpaLists.Imco2 as IMOClass,"
			+ " dpaLists.Un_No as UnNo,"
			+ " nvl2(cont.set_temp, 'Yes', 'No') as Reefer, cont.set_temp as Temperature,"
			+ " (SELECT a.read_date FROM opctjad_dba.reefer_readings a"
			+ " WHERE a.contr_no = dpaLists.Contr_No AND a.read_type = 'C'"
			+ " AND a.read_date = (SELECT MAX(b.read_date) FROM opctjad_dba.reefer_readings b"
			+ " WHERE a.contr_no = b.contr_no AND a.crt_date = b.crt_date"
			+ " AND b.read_type = 'C')) as PlugIn,"
			+ " (SELECT a.read_date"
			+ " FROM opctjad_dba.reefer_readings a"
			+ " WHERE a.contr_no = dpaLists.Contr_No"
			+ " AND a.read_type = 'D'"
			+ " AND a.read_date = (SELECT MAX(b.read_date)"
			+ " FROM opctjad_dba.reefer_readings b"
			+ " WHERE a.contr_no = b.contr_no"
			+ " AND a.crt_date = b.crt_date"
			+ " AND b.read_type = 'D')) as PlugInDays,"
			+ " dpaLists.Wt as Weight,"
			+ " dpaLists.Content as Content,"
			+ " dpaLists.Og as OOG,"
			+ " dpaLists.Od_Left as OOGLeft,"
			+ " dpaLists.Od_Right as OOGRight,"
			+ " dpaLists.Od_Front as OOGFront,"
			+ " dpaLists.Od_Back as OOGBack,"
			+ " dpaLists.Od_Top as OOGTop"
			+ " from dpa_lists dpaLists, containers cont"
			+ " where cont.contr_no = dpaLists.Contr_No and cont.act_code = 'Y'"
			+ " and dpaLists.Contr_No  = ? and cont.chk_digit = ?  "
			+ " UNION"
			+ " Select RobLists.Contr_No || cont.chk_digit as ContainerNo,"
			+ " cont.new_iso_code as ISOCode,"
			+ " RobLists.Line_Code as LineCode,"
			+ " cont.do_agent as Agent,"
			+ " RobLists.Terminal_Id as Terminal,"
			+ " null as MoveKind,"
			+ " cont.contr_position as ContainerPos,"
			+ " null as STODays,"
			+ " null as Status,"
			+ " (CASE RobLists.Contr_Cat"
			+ " WHEN 'I' THEN"
			+ " 'Import'"
			+ " WHEN 'E' THEN"
			+ " 'Export'"
			+ " ELSE"
			+ " 'Transhipment'"
			+ " END) as Category,"
			+ " null as YardIn,"
			+ " null as YardOut,"
			+ " nvl2(cont.stop_descr, 'Yes', 'No') as Stop,"
			+ " cont.stop_descr as Reason,"
			+ " null as DamageInd,"
			+ " cont.Dmg_Descr as Damage,"
			+ INBOUND_VESSEL_NAME
			+ " cont.last_disch_rotn as InboubdRotation,"
			+ OUTBOUND_VESSEL_NAME
			+ " cont.last_load_rotn as OutboundRotation,"
			+ " null as Shipper,"
			+ " null as Consignee,"
			+ " RobLists.Disch_Port as POD,"
			+ " RobLists.Dest_Port as Destination,"
			+ " RobLists.Load_Port as LoadPort,"
			+ " RobLists.Origin_Port as OriginPort,"
			+ " nvl2(RobLists.Seal_No, 'Yes', 'No') as Seal,"
			+ " RobLists.Seal_No as SealNo,"
			+ " RobLists.Imco2 as IMOClass,"
			+ " RobLists.Un_No as UnNo,"
			+ " nvl2(cont.set_temp, 'Yes', 'No') as Reefer,"
			+ " cont.set_temp as Temperature,"
			+ " null as PlugIn,"
			+ " null as PlugInDays,"
			+ " RobLists.Wt as Weight,"
			+ " null as Content,"
			+ " RobLists.Og as OOG,"
			+ " RobLists.Od_Left as OOGLeft,"
			+ " RobLists.Od_Right as OOGRight,"
			+ " RobLists.Od_Front as OOGFront,"
			+ " RobLists.Od_Back as OOGBack,"
			+ " RobLists.Od_Top as OOGTop"
			+ " from rob_lists RobLists, containers cont"
			+ " where cont.contr_no = RobLists.Contr_No"
			+ " and cont.act_code = 'Y'"
			+ " and RobLists.Contr_No = ? and cont.chk_digit = ? ";

	public static final String UPDATE_CONTR_INQUIRY_QUERY = "Select dpaLists.contr_no || cont.chk_digit as ContainerNo, "
			+ " cont.new_iso_code as ISOCode, dpaLists.Line_Code as LineCode, "
			+ " cont.contr_len as containerSize, dpaLists.Wt as Weight, "
			+ " (CASE dpaLists.Contr_Cat "
			+ " WHEN 'I' THEN 'Import' "
			+ " WHEN 'E' THEN 'Export' "
			+ " ELSE 'Transhipment' END) as Category, "
			+ " cont.desig as desig, "
			+ " dpaLists.Disch_Port as POD, "
			+ " dpaLists.DISCH_PORT_2 as NextPort, "
			+ " dpaLists.Dest_Port as FinalPort, "
			+ " dpaLists.Og as OOG, "
			+ " dpaLists.Od_Left as OOGLeft, "
			+ " dpaLists.Od_Right as OOGRight, "
			+ " dpaLists.Od_Front as OOGFront, "
			+ " dpaLists.Od_Back as OOGBack, "
			+ " dpaLists.Od_Top as OOGTop, "
			+ " (SELECT a.read_date FROM opctjad_dba.reefer_readings a "
			+ " WHERE a.contr_no = dpaLists.Contr_No AND a.read_type = 'C' "
			+ " AND a.read_date = (SELECT MAX(b.read_date) FROM opctjad_dba.reefer_readings b "
			+ " WHERE a.contr_no = b.contr_no AND a.crt_date = b.crt_date "
			+ " AND b.read_type = 'C')) as PlugIn, "
			+ OUTBOUND_VESSEL_NAME
			+ " dpaLists.VOYAGE_NO as Voyage, "
			+ " dpaLists.Seal_No as SealNo, "
			+ " dpaLists.Seal_No2 as SealNo2, "
			+ " dpaLists.Seal_No3 as SealNo3, "
			+ " dpaLists.Seal_No4 as SealNo4  "
			+ " from dpa_lists dpaLists, containers cont "
			+ " where cont.contr_no = dpaLists.Contr_No and cont.act_code = 'Y' "
			+ " and dpaLists.Contr_No = ? " + " and cont.chk_digit = ? ";

	public static final String ISO_TYPE_QUERY = "SELECT CODE_CODE AS CODECODE, CODE_DESC2 AS CODEDESC2 FROM CODES WHERE CODE_TYPE = 'ISOTYPE'";

	private Constants() {

	}
}
