package com.minapro.procserver.events;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.minapro.esb.xmlrdt.entities.Message;

@XmlRootElement(name = "msgList")
public class MessageList implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 8053327108188505558L;
    private java.util.List<Message> messages;

    @XmlElement(name = "message")
    public java.util.List<Message> getMessages() {
        return messages;
    }

    public void setMessages(java.util.List<Message> messages) {
        this.messages = messages;
    }

    @Override
    public String toString() {
        return "MessageList [messages=" + messages + "]";
    }

}
