package com.minapro.procserver.events.itv;

import java.io.Serializable;
import java.util.Set;

import com.minapro.procserver.events.Event;

/**
 * <p>
 * ValueObject which holds the list of ITVs assigned to a particular QC.
 * </p>
 * 
 * <p>
 * The equipmentId will contain the QC Id and the itvList contains all the ITVs assigned to the QC.
 * </p>
 * 
 * @author Rosemary George
 * 
 */
public class ITVPoolEvent extends Event implements Serializable {
    private static final long serialVersionUID = 7400537611729215421L;

    private Set<ITV> itvList;

    public Set<ITV> getItvList() {
        return itvList;
    }

    public void setItvList(Set<ITV> itvList) {
        this.itvList = itvList;
    }

    @Override
    public String toString() {
        return "ITVPoolEvent [itvList=" + itvList + ", getUserID()=" + getUserID() + ", getEquipmentID()="
                + getEquipmentID() + ", getTerminalID()=" + getTerminalID() + "]";
    }
}
