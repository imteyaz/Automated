package com.minapro.esb.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.esb.common.SendObject;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerInquiryEvent;
import com.minapro.procserver.events.ContainerMoveEvent;
import com.minapro.procserver.events.ExchangeContainerRequestEvent;
import com.minapro.procserver.events.JobListRequestEvent;
import com.minapro.procserver.events.KeepAliveRequestEvent;
import com.minapro.procserver.events.PlannedMovesRequestEvent;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerInquiryRequestEvent;
import com.minapro.procserver.events.UpdateContainerLocationEvent;
import com.minapro.procserver.events.common.BaywiseContainerDetailsRequestEvent;
import com.minapro.procserver.events.common.ConfirmAllocationEvent;
import com.minapro.procserver.events.common.LoginEvent;
import com.minapro.procserver.events.common.LogoutEvent;
import com.minapro.procserver.events.common.MovesToGoRequestEvent;
import com.minapro.procserver.events.common.OperatorAvailabilityEvent;
import com.minapro.procserver.events.common.OperatorMessageRequestEvent;
import com.minapro.procserver.events.common.UpdateBayViewRequestEvent;
import com.minapro.procserver.events.common.VesselBerthSideRequestEvent;
import com.minapro.procserver.events.hc.ITVSwapRequestEvent;
import com.minapro.procserver.events.hc.SwapRequestEvent;
import com.minapro.procserver.events.itv.ITVPoolRequestEvent;

public class EventProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(EventProcessor.class);

    private static <T> void setSendObject(String queue, T template,
            Exchange exchange, String templateName) {
        SendObject sendObject = new SendObject();
        sendObject.setQueueName(queue);
        sendObject.setObject(template);
        exchange.getOut().setBody(sendObject);
        EventProcessor.check(sendObject, Constants.QC_OPERATOR + templateName,
                exchange);

    }

    private static <T> void check(T template, String templateName,
            Exchange exchange) {
        Boolean routed = (Boolean) exchange.getProperty(Constants.ROUTED);

        if (routed != null && routed) {
            exchange.removeProperty(Constants.ROUTED);
            exchange.removeProperty(templateName);
            LOGGER.debug("Remove routed & template name props from exchange : "
                    + templateName);
        } else {
            exchange.setProperty(templateName, template);
            exchange.setProperty(Constants.ROUTED, false);
            exchange.setProperty(Constants.EVENT_TYPE, templateName);
            LOGGER.debug("Set event-type,routed & template name props to exchange : "
                    + templateName);
        }
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("************ In QC EventProcessor process method ************");

        Object object = exchange.getIn().getBody();
        LOGGER.info("QC Request received from RDT is ----> " + object);

        if (object instanceof LogoutEvent) {

            LogoutEvent logoutEvent = (LogoutEvent) object;
            EventProcessor.setSendObject(Constants.QC_OPERATOR, logoutEvent,
                    exchange, Constants.LOGOUT_EVENT);

        } else if (object instanceof ContainerMoveEvent) {
            ContainerMoveEvent containerMoveEvent = (ContainerMoveEvent) object;

            EventProcessor.setSendObject(Constants.QC_OPERATOR,
                    containerMoveEvent, exchange,
                    Constants.CONTAINER_MOVE_EVENT);

        } else if (object instanceof ConfirmAllocationEvent) {

            ConfirmAllocationEvent confirmAllocationEvent = (ConfirmAllocationEvent) object;

            EventProcessor.setSendObject(Constants.QC_OPERATOR,
                    confirmAllocationEvent, exchange,
                    Constants.CONFIRM_ALLOCATION_EVENT);

        } else if (object instanceof JobListRequestEvent) {
            JobListRequestEvent event = (JobListRequestEvent) object;

            EventProcessor.setSendObject(Constants.QC_OPERATOR, event,
                    exchange, Constants.JOBLIST_EVENT);

        } else if (object instanceof ITVPoolRequestEvent) {
            ITVPoolRequestEvent poolRequestEvent = (ITVPoolRequestEvent) object;

            EventProcessor.setSendObject(Constants.QC_OPERATOR,
                    poolRequestEvent, exchange, Constants.ITVPOOL_EVENT);

        } else if (object instanceof VesselBerthSideRequestEvent) {

            VesselBerthSideRequestEvent vesselBerthSideRequestEvent = (VesselBerthSideRequestEvent) object;
            EventProcessor.check(vesselBerthSideRequestEvent,
                    Constants.VESSELBERTHSIDE, exchange);

        } else if (object instanceof UpdateBayViewRequestEvent) {
            UpdateBayViewRequestEvent loginEvent = (UpdateBayViewRequestEvent) object;
            EventProcessor.check(loginEvent, Constants.QC_OPERATOR
                    + "bayUpdate", exchange);

        } else if (object instanceof LoginEvent) {
            LoginEvent loginEvent = (LoginEvent) object;
            EventProcessor.check(loginEvent, Constants.QC_OPERATOR
                    + "loginEvent", exchange);

        } else if (object instanceof PlannedMovesRequestEvent) {
            PlannedMovesRequestEvent plannedMovesRequestEvent = (PlannedMovesRequestEvent) object;
            EventProcessor.check(plannedMovesRequestEvent,
                    Constants.QC_OPERATOR + Constants.PLANNED_MOVES_EVENT,
                    exchange);
        } else if (object instanceof OperatorAvailabilityEvent) {
            OperatorAvailabilityEvent availabilityEvent = (OperatorAvailabilityEvent) object;
            EventProcessor
                    .setSendObject(Constants.QC_OPERATOR, availabilityEvent,
                            exchange, Constants.OPERATOR_AVAIL_EVENT);
        }
    }

    /**
     * Process COMMONQ requests
     * 
     * @param exchange
     */
    public void processCommonRequest(Exchange exchange) {
        LOGGER.debug("************ In QC EventProcessor common process method ************");

        Object object = exchange.getIn().getBody();
        LOGGER.debug("QC Common Request received from RDT is ----> " + object);

        if (object instanceof BaywiseContainerDetailsRequestEvent) {
            BaywiseContainerDetailsRequestEvent bayViewEvent = (BaywiseContainerDetailsRequestEvent) object;
            EventProcessor.check(bayViewEvent, Constants.QC_OPERATOR
                    + Constants.BAY_VIEW_EVENT, exchange);
        } else if (object instanceof ContainerDamageEvent) {
            ContainerDamageEvent contrDmgEvent = (ContainerDamageEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ, contrDmgEvent,
                    exchange, Constants.CONTAINER_DAMAGE_EVENT);

            EventProcessor.check(contrDmgEvent, Constants.QC_OPERATOR
                    + Constants.CONTR_DAMAGE_EVENT, exchange);
        } else if (object instanceof UpdateContainerLocationEvent) {
            UpdateContainerLocationEvent updateContrLocEvent = (UpdateContainerLocationEvent) object;
            EventProcessor.setSendObject(Constants.QC_OPERATOR,
                    updateContrLocEvent, exchange, Constants.UPDATE_CONTAINER_LOCATION_EVENT);
        } else if (object instanceof MovesToGoRequestEvent) {
            MovesToGoRequestEvent movesToGoEvent = (MovesToGoRequestEvent) object;
            EventProcessor.check(movesToGoEvent, Constants.QC_OPERATOR
                    + Constants.MOVES_TO_GO_EVENT, exchange);
        } else if (object instanceof KeepAliveRequestEvent) {
            KeepAliveRequestEvent keepAliveEvent = (KeepAliveRequestEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ, keepAliveEvent,
                    exchange, Constants.KEEPALIVE_EVENT);
        } else if (object instanceof ContainerInquiryEvent) {

            ContainerInquiryEvent containerInquiryEvent = (ContainerInquiryEvent) object;
            EventProcessor.check(containerInquiryEvent, Constants.QC_OPERATOR
                    + Constants.CONTR_INQUIRY_EVENT, exchange);

        } else if (object instanceof ExchangeContainerRequestEvent) {
            ExchangeContainerRequestEvent exchangeContainerEvent = (ExchangeContainerRequestEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ,
                    exchangeContainerEvent, exchange,
                    Constants.EXCHANGE_CONTAINER_EVENT);

        } else if (object instanceof UpdateContainerInquiryRequestEvent) {
            UpdateContainerInquiryRequestEvent updateContainerInquiryRequestEvent = (UpdateContainerInquiryRequestEvent) object;
            EventProcessor.check(updateContainerInquiryRequestEvent,
                    Constants.UPDATE_CONTR_INQUIRY_EVENT, exchange);

        } else if (object instanceof UpdateContainerEvent) {
            UpdateContainerEvent updateContainerEvent = (UpdateContainerEvent) object;
            EventProcessor.setSendObject(Constants.QC_OPERATOR,
                    updateContainerEvent, exchange, Constants.UPDATE_CONTAINER);
        
        } else if (object instanceof SwapRequestEvent) {
            SwapRequestEvent swapRequestEvent = (SwapRequestEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ,
                    swapRequestEvent, exchange,
                    Constants.SWAP_EVENT);
        
        } else if (object instanceof OperatorMessageRequestEvent) {
            OperatorMessageRequestEvent operatorMsgRequestEvent = (OperatorMessageRequestEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ,
                    operatorMsgRequestEvent, exchange,
                    Constants.OPERATOR_MSG_EVENT);        
        } 
        
        else if (object instanceof ITVSwapRequestEvent) {
        	ITVSwapRequestEvent itvSwapRequestEvent = (ITVSwapRequestEvent) object;
            EventProcessor.setSendObject(Constants.COMMONQ,
            		itvSwapRequestEvent, exchange,
                    Constants.ITV_SWAP_EVENT);        
        } 
    }
}
