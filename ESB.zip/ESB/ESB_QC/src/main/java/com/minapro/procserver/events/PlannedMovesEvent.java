package com.minapro.procserver.events;

import java.io.Serializable;
import java.util.List;

public class PlannedMovesEvent extends Event implements Serializable {

    private static final long serialVersionUID = 1L;

    private String rotationId;

    private String pow;

    private int plannedMoves;
    
    private List<String> plannedContainerIds;

    public int getPlannedMoves() {
        return plannedMoves;
    }

    public void setPlannedMoves(int plannedMoves) {
        this.plannedMoves = plannedMoves;
    }

    public String getRotationId() {
        return rotationId;
    }

    public void setRotationId(String rotationId) {
        this.rotationId = rotationId;
    }

    public String getPow() {
        return pow;
    }

    public void setPow(String pow) {
        this.pow = pow;
    }

    public List<String> getPlannedContainerIds() {
        return plannedContainerIds;
    }

    public void setPlannedContainerIds(List<String> plannedContainerIds) {
        this.plannedContainerIds = plannedContainerIds;
    }

    @Override
    public String toString() {
        return "PlannedMovesEvent [rotationId=" + rotationId + ", pow=" + pow + ", plannedMoves=" + plannedMoves
                + ", plannedContainerIds=" + plannedContainerIds + ", getUserID()=" + getUserID()
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()=" + getEventID() + "]";
    }   
}
