package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the container location update response details
 * 
 * @author Rosemary George
 *
 */
public class UpdateContainerLocationResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -1408937687861415864L;

    /**
     * Container which is getting updated
     */
    private String containerId;

    /**
     * indicates whether the update was successful or not
     */
    private boolean status;

    /**
     * will be filled with the error reason if the status is false
     */
    private String errorMessage;

    /**
     * Container Move Type
     */
    private String moveType;
    
    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "UpdateContainerLocationResponseEvent [containerId="
                + containerId + ", status=" + status + ", errorMessage="
                + errorMessage + ", moveType=" + moveType
                + ", getEquipmentID()=" + getEquipmentID() + ", getEventID()="
                + getEventID() + "]";
    }

    
}
