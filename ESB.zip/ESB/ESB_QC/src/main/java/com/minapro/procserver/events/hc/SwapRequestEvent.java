package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the swap request from the device
 * 
 * @author Rosemary George
 *
 */
public class SwapRequestEvent extends Event implements Serializable {


    private static final long serialVersionUID = 394051223456581634L;

    /**
     * the ITV which is carrying the containers that needs swapping
     */
    private String itvId;

    /**
     * ID of the containers which are going to be swapped. This format will be containerID1|containerID2
     */
    private String containerIds;

    /**
     * List of containers which are getting swapped
     */
    private List<SwapContainerPosition> swapContainers; 

    
    public String getItvId() {
        return itvId;
    }

    public void setItvId(String itvId) {
        this.itvId = itvId;
    }

    public String getContainerIds() {
        return containerIds;
    }

    public void setContainerIds(String containerIds) {
        this.containerIds = containerIds;
    }

    public List<SwapContainerPosition> getSwapContainers() {
        return swapContainers;
    }

    public void setSwapContainers(List<SwapContainerPosition> swapContainers) {
        this.swapContainers = swapContainers;
    }


    @Override
    public String toString() {
        return "SwapRequestEvent [itvId=" + itvId + ", containerIds=" + containerIds + ", swapContainerList="
                + swapContainers + ", getUserID()=" + getUserID() + ", getEquipmentID()=" + getEquipmentID()
                + ", getEventID()=" + getEventID() + "]";
    }
}
