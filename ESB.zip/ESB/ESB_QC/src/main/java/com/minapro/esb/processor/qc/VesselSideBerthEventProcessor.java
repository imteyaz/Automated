package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.common.VesselBerthSideRequestEvent;
import com.minapro.procserver.events.common.VesselBerthSideResponseEvent;

public class VesselSideBerthEventProcessor implements Processor {
    private static final Logger LOGGER = Logger
            .getLogger(VesselSideBerthEventProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("Begin VesselSideBerthEventProcessor...");

        Connection connection = null;
        PreparedStatement vstcStatement = null;
        ResultSet vstcSet = null;
        String side = null;
        VesselBerthSideRequestEvent requestEvent = null;
        VesselBerthSideResponseEvent responseEvent = new VesselBerthSideResponseEvent();
        try {
            requestEvent = (VesselBerthSideRequestEvent) exchange
                    .getProperty(Constants.VESSELBERTHSIDE);            

            if (requestEvent != null) {

                @SuppressWarnings("deprecation")
                DataSource dataSource = (DataSource) exchange.getContext().getRegistry().lookup(Constants.PRTOSD_MP);
                connection = dataSource.getConnection();

                LOGGER.debug("Connection established with PRTOSD DB ");
                vstcStatement = connection
                        .prepareStatement(Constants.VESSEL_BERTHSIDE_QUERY);

                vstcStatement.setString(1, requestEvent.getRotationId());
                vstcSet = vstcStatement.executeQuery();

                while (vstcSet != null && vstcSet.next()) {
                    side = vstcSet.getString("VSTC");
                }
                LOGGER.info("Query for vessel berth side executed : "+side);
                responseEvent.setBerthSide(side);
                responseEvent.setEquipmentID(requestEvent.getEquipmentID());
                responseEvent.setEventID(requestEvent.getEventID());
                responseEvent.setRotationId(requestEvent.getRotationId());
                responseEvent.setTerminalID(requestEvent.getTerminalID());
                responseEvent.setUserID(requestEvent.getUserID());

                if (responseEvent.getBerthSide() != null) {
                    exchange.getOut().setBody(responseEvent);
                } else {
                    LOGGER.info("Unable to send message to RDT from Berth Side : " + side);
                }
                exchange.setProperty(Constants.VESSELBERTHSIDE, "yes");
                exchange.setProperty("routed", null);

                LOGGER.info("Vessel Side Berth Event response sent --> "+ responseEvent);
                LOGGER.debug("End VesselSideBerthEventProcessor...");
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while processing QC Planned Moves Event : ",e);
        } finally {

            if (vstcSet != null) {
                vstcSet.close();
            }
            if (vstcStatement != null) {
                vstcStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }
}
