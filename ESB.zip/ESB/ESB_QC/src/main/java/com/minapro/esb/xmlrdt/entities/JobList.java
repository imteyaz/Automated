package com.minapro.esb.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class JobList {

    private String firstID;
    private String lastID;
    private String sortMode;
    private java.util.List<Job> job;

    @XmlElement(name = "job")
    public java.util.List<Job> getJob() {
        return job;
    }

    public void setJob(java.util.List<Job> job) {
        this.job = job;
    }

    @XmlAttribute(name = "firstID")
    public String getFirstID() {
        return firstID;
    }

    public void setFirstID(String firstID) {
        this.firstID = firstID;
    }

    @XmlAttribute(name = "lastID")
    public String getLastID() {
        return lastID;
    }

    public void setLastID(String lastID) {
        this.lastID = lastID;
    }

    @XmlAttribute(name = "sortMode")
    public String getSortMode() {
        return sortMode;
    }

    public void setSortMode(String sortMode) {
        this.sortMode = sortMode;
    }

    @Override
    public String toString() {
        return "JobList [firstID=" + firstID + ", lastID=" + lastID + ", sortMode=" + sortMode + ", job=" + job + "]";
    }

}
