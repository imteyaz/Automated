package com.minapro.procserver.events.common;

import java.io.Serializable;
import java.util.Date;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the DLM Response event details
 * 
 * @author Venkataramana.ch
 * 
 */
public class DLMResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -2961158325363583665L;

    /**
     * Shift Starting time receiving from External DPW system
     */
    private Date shiftStartTime;

    /**
     * Shift Ending time receiving from External DPW system
     */
    private Date shiftEndTime;

    /**
     * List of <Break> details fetched from DPW IT System
     */
    private java.util.List<Break> breakTime;

    public Date getshiftStartTime() {
        return shiftStartTime;
    }

    public void setShiftStartTime(Date shiftStartTime) {
        this.shiftStartTime = shiftStartTime;
    }

    public Date getshiftEndTime() {
        return shiftEndTime;
    }

    public void setShiftEndTime(Date shiftEndTime) {
        this.shiftEndTime = shiftEndTime;
    }

    public java.util.List<Break> getbreakTime() {
        return breakTime;
    }

    public void setBreakTime(java.util.List<Break> breakTime) {
        this.breakTime = breakTime;
    }

    @Override
    public String toString() {
        return "DLMResponseEvent [shiftStartTime=" + shiftStartTime + ", shiftEndTime=" + shiftEndTime + ", breakTime="
                + breakTime + "]";
    }
}
