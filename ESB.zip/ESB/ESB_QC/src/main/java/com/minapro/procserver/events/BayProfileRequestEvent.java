package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the bay view request from the devices
 * 
 * @author Rosemary George
 * 
 */
public class BayProfileRequestEvent extends Event implements Serializable {
    private static final long serialVersionUID = -8604213207202297223L;

    /**
     * The vessel for which the bay view is requested
     */
    private String cellLocation;

    /**
     * Indicates whether FRONT or TOP view is requested
     */
    private BAY_VIEW viewType;

    public BAY_VIEW getViewType() {
        return viewType;
    }

    public void setViewType(String viewType) {
        if ("C".equalsIgnoreCase(viewType)) {
            this.viewType = BAY_VIEW.CURRENT;
        } else {
            this.viewType = BAY_VIEW.FUTURE;
        }
    }

    public String getCellLocation() {
        return cellLocation;
    }

    public void setCellLocation(String cellLocation) {
        this.cellLocation = cellLocation;
    }

    @Override
    public String toString() {
        return "BayProfileRequestEvent [cellLocation=" + cellLocation
                + ", viewRequest=" + viewType + ", userID=" + getUserID() + "]";
    }

    /**
     * Possible values for the Bay view request
     * 
     * @author Rosemary George
     * 
     */
    public enum BAY_VIEW {
        // current view
        CURRENT, 
        // future view
        FUTURE 
    }
}
