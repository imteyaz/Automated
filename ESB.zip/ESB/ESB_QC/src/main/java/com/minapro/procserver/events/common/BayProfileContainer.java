package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Container;

/**
 * ValueObject holding the container details related to the bay profile
 * 
 * @author Rosemary George
 * 
 */
public class BayProfileContainer implements Serializable {
    private static final long serialVersionUID = -4929721072673589019L;

    private Container container;

    /**
     * Indicates the actual cell position of the container as per the planning
     */
    private String stowagePosition;

    /**
     * Indicates whether the container is ROB(Remain on board)
     */
    private boolean isROB;

    /**
     * Indicates whether it is L(load) or D(discharge) operation.
     */
    private String moveType;

    public boolean isROB() {
        return isROB;
    }

    public void setROB(boolean isROB) {
        this.isROB = isROB;
    }

    public String getStowagePosition() {
        return stowagePosition;
    }

    public void setStowagePosition(String stowagePosition) {
        this.stowagePosition = stowagePosition;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    @Override
    public String toString() {
        return "BayProfileContainer [container=" + container + ", stowagePosition=" + stowagePosition + ", isROB="
                + isROB + ", moveType=" + moveType + "]";
    }
}
