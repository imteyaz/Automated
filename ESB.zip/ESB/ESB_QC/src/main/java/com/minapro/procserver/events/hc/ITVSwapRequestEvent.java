package com.minapro.procserver.events.hc;

import java.io.Serializable;
import java.util.List;

import com.minapro.procserver.events.Event;

public class ITVSwapRequestEvent extends Event implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4644330897205469326L;

	 /**
     * List of containers which are getting swapped
     */
    private List<SwapContainerPosition> swapContainers;

	public List<SwapContainerPosition> getSwapContainers() {
		return swapContainers;
	}

	public void setSwapContainers(List<SwapContainerPosition> swapContainers) {
		this.swapContainers = swapContainers;
	}

	@Override
	public String toString() {
		return "ITVSwapRequestEvent [swapContainers=" + swapContainers
				+ ", getUserID()=" + getUserID() + ", getEquipmentID()="
				+ getEquipmentID() + ", getTerminalID()=" + getTerminalID()
				+ ", getEventID()=" + getEventID() + "]";
	}
    
}
