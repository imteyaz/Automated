package com.minapro.esb.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "container")
public class Container {

    private String EQID;
    private String JPOS;
    private String EWGT;
    private String LNTH;
    private String TRNS;
    private String RDTS;
    private String EQTP;
    private String HGHT;
    private String QWGT;
    private String LOPR;
    private String ACRR;
    private String DCRR;

    @XmlAttribute(name = "EQTP")
    public String getEQTP() {
        return EQTP;
    }

    public void setEQTP(String eQTP) {
        EQTP = eQTP;
    }

    @XmlAttribute(name = "HGHT")
    public String getHGHT() {
        return HGHT;
    }

    public void setHGHT(String hGHT) {
        HGHT = hGHT;
    }

    @XmlAttribute(name = "QWGT")
    public String getQWGT() {
        return QWGT;
    }

    public void setQWGT(String qWGT) {
        QWGT = qWGT;
    }

    @XmlAttribute(name = "LOPR")
    public String getLOPR() {
        return LOPR;
    }

    public void setLOPR(String lOPR) {
        LOPR = lOPR;
    }

    @XmlAttribute(name = "ACRR")
    public String getACRR() {
        return ACRR;
    }

    public void setACRR(String aCRR) {
        ACRR = aCRR;
    }

    @XmlAttribute(name = "DCRR")
    public String getDCRR() {
        return DCRR;
    }

    public void setDCRR(String dCRR) {
        DCRR = dCRR;
    }

    @XmlAttribute(name = "TRNS")
    public String getTRNS() {
        return TRNS;
    }

    public void setTRNS(String tRNS) {
        TRNS = tRNS;
    }

    @XmlAttribute(name = "RDTS")
    public String getRDTS() {
        return RDTS;
    }

    public void setRDTS(String rDTS) {
        RDTS = rDTS;
    }

    @XmlAttribute(name = "EQID")
    public String getEQID() {
        return EQID;
    }

    public void setEQID(String eQID) {
        EQID = eQID;
    }

    @XmlAttribute(name = "JPOS")
    public String getJPOS() {
        return JPOS;
    }

    public void setJPOS(String jPOS) {
        JPOS = jPOS;
    }

    @XmlAttribute(name = "EWGT")
    public String getEWGT() {
        return EWGT;
    }

    public void setEWGT(String eWGT) {
        EWGT = eWGT;
    }

    @XmlAttribute(name = "LNTH")
    public String getLNTH() {
        return LNTH;
    }

    @Override
    public String toString() {
        return "Container [EQID=" + EQID + ", JPOS=" + JPOS + ", EWGT=" + EWGT + ", LNTH=" + LNTH + "]";
    }

    public void setLNTH(String lNTH) {
        LNTH = lNTH;
    }

}
