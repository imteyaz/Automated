package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.common.BayProfileContainer;
import com.minapro.procserver.events.common.UpdateBayViewRequestEvent;
import com.minapro.procserver.events.common.UpdateBayViewResponseEvent;

public class UpdateBay implements Processor {
    private static final Logger LOGGER = Logger.getLogger(UpdateBay.class);

    @Override
    public void process(Exchange exchange) throws Exception {

        Connection con = null;
        PreparedStatement selectContrStmt = null;
        PreparedStatement robContainerupdateStmt = null;
        ResultSet dpaSet = null;
        ResultSet robSet = null;

        LOGGER.info("Inside the Bay Update Process... ");
        UpdateBayViewRequestEvent requestEvent = (UpdateBayViewRequestEvent) exchange
                .getProperty("QCbayUpdate");
        if (requestEvent != null) {

            LOGGER.info("Request event of Update Bay " + requestEvent);
            List<String> contrList = requestEvent
                    .getUpdateRequiredContainerList();
            List<String> robContainersList = new ArrayList<String>();
            List<String> dpaContainersList = new ArrayList<String>();

            java.util.List<BayProfileContainer> containersList = new ArrayList<BayProfileContainer>();
            try {
                @SuppressWarnings("deprecation")
                DataSource dataSource = (DataSource) exchange.getContext()
                        .getRegistry().lookup(Constants.PROMIS_DB);

                con = dataSource.getConnection();
                LOGGER.debug("Connection established with PROMIS");

                selectContrStmt = con
                        .prepareStatement(Constants.GET_DPA_SELECT_BAY_CONTIANERS_LIST_QUERY);

                for (String contrId : contrList) {

                    selectContrStmt.setString(1, contrId.substring(0, 10));
                    selectContrStmt.setInt(2,
                            Integer.parseInt(requestEvent.getRotationID()));
                    dpaSet = selectContrStmt.executeQuery();

                    while (dpaSet != null && dpaSet.next()) {

                        String moveType = "D".equalsIgnoreCase(dpaSet
                                .getString("moveType")) ? Constants.DISCHARGE
                                : Constants.LOAD;
                        String stowage = null;
                        if (Constants.DISCHARGE.equalsIgnoreCase(moveType)) {
                            stowage = dpaSet.getString(Constants.STOWG);
                        } else if (Constants.LOAD.equalsIgnoreCase(moveType)) {
                            stowage = dpaSet.getString(Constants.PLAN_STOWG);
                        }

                        Container container = getContainerDetails(dpaSet);
                        BayProfileContainer profileContainer = new BayProfileContainer();

                        profileContainer.setMoveType(moveType);
                        profileContainer.setStowagePosition(stowage);
                        profileContainer.setContainer(container);

                        containersList.add(profileContainer);
                        dpaContainersList.add(contrId);

                    }
                }

                LOGGER.info("Oringinal updatContainer list received from RDT for event ID "
                        + requestEvent.getEventID() + " -->" + contrList);
                LOGGER.info("Containers found in dpa_lists for event ID "
                        + requestEvent.getEventID() + " -->"
                        + dpaContainersList);

                Boolean wasListModified = contrList
                        .removeAll(dpaContainersList);

                if (wasListModified) {
                    LOGGER.info("Original List of containers was modified for event ID "
                            + requestEvent.getEventID()
                            + " -->"
                            + wasListModified);
                    LOGGER.info("Remaining List of containers after modifying for event ID "
                            + requestEvent.getEventID() + " -->" + contrList);
                }

                for (String contrId : contrList) {

                    robContainerupdateStmt = con
                            .prepareStatement(Constants.GET_ROB_UPDATE_BAY_CONTIANERS_LIST_QUERY);

                    /**
                     * robContainerupdateStmt = con.prepareStatement(
                     * "select * from  rob_lists where  rob_lists.contr_no= ? and rob_lists.rotn= ? "
                     * ) ;
                     */
                    robContainerupdateStmt.setString(1,
                            contrId.substring(0, 10));
                    robContainerupdateStmt.setInt(2,
                            Integer.parseInt(requestEvent.getRotationID()));
                    robSet = robContainerupdateStmt.executeQuery();

                    while (robSet != null && robSet.next()) {
                        String stowage = robSet.getString(Constants.STOWG);
                        Container container = getContainerDetails(robSet);

                        BayProfileContainer profileContainer = new BayProfileContainer();
                        profileContainer.setStowagePosition(stowage);
                        profileContainer.setContainer(container);
                        profileContainer.setROB(true);
                        containersList.add(profileContainer);

                        robContainersList.add(contrId);
                    }
                }

                LOGGER.info("Containers found in rob_lists for event ID"
                        + requestEvent.getEventID() + " -->"
                        + robContainersList);
                contrList.removeAll(robContainersList);
            } catch (Exception e) {
                LOGGER.error("Exception while update retreiving bay view details ", e);
            } finally {
                if (dpaSet != null) {

                    dpaSet.close();
                }
                if (robSet != null) {
                    robSet.close();
                }
                if (selectContrStmt != null) {
                    selectContrStmt.close();
                }
                if (selectContrStmt != null) {
                    selectContrStmt.close();
                }
                if (robContainerupdateStmt != null) {
                    robContainerupdateStmt.close();
                }
                if (con != null) {
                    con.close();
                }
            }
            LOGGER.warn("*** No info found for following Containers(neither in dpa, nor in rob) for event ID"
                    + requestEvent.getEventID() + " -->" + contrList);

            UpdateBayViewResponseEvent responseEvent = new UpdateBayViewResponseEvent();
            responseEvent.setEquipmentID(requestEvent.getEquipmentID());
            responseEvent.setEventID(requestEvent.getEventID());
            responseEvent.setTerminalID(requestEvent.getTerminalID());
            responseEvent.setUpdatedContainerList(containersList);
            responseEvent.setUserID(requestEvent.getUserID());
            // Containers not found in DPA_LISTS & ROB_LISTS tables
            responseEvent.setUnLocatedContainerList(contrList);

            LOGGER.info("The response event of  bay Update ->" + responseEvent);

            exchange.getOut().setBody(responseEvent);
            LOGGER.info("Object sent to OUTQ");
            exchange.setProperty("BayView", "yes");
            exchange.setProperty("routed", null);
        }
    }

    private Container getContainerDetails(ResultSet contrResultSet)
            throws SQLException {
        Container container = new Container();

        String containerId = contrResultSet.getString("containerId");
        String pod = contrResultSet.getString("pod");
        String isoCode = contrResultSet.getString("isoCode");
        Integer size = contrResultSet.getInt("containerSize");
        if(null== size){
            size = "2".equalsIgnoreCase(isoCode.substring(0,1))? 20:40;
        }
        Double weight = contrResultSet.getDouble("weight");
        String category = contrResultSet.getString("category");
        String reefer = contrResultSet.getString("reefer");
        Boolean isRefer = reefer == null || "N".equalsIgnoreCase(reefer) ? false
                : true;

        String contrEmpty = contrResultSet.getString("containerEmpty");
        Boolean isEmpty = contrEmpty != null
                && "E".equalsIgnoreCase(contrEmpty) ? true : false;
        Boolean isOOg = contrResultSet.getString("oog") == null
                || "N".equalsIgnoreCase(contrResultSet.getString("oog")) ? false
                : true;
        Boolean isDamaaged = contrResultSet.getString("damaged") == null ? false
                : true;

        /* UN_NO represents IMDG Code for hazardous containers */
        Integer unNo = contrResultSet.getInt("unNo");
        Integer unNo2 = contrResultSet.getInt("unNo2");
        Integer unNo3 = contrResultSet.getInt("unNo3");

        String hazardousCode = getHazardousCode(unNo, unNo2, unNo3);
        boolean isHazardous = null != hazardousCode ? true : false;

        container.setContainerID(containerId);
        container.setPod(pod);
        container.setIsoCode(isoCode);
        container.setSize(size.toString());
        container.setWeight(weight.toString());
        container.setCategory(category);
        container.setReefer(isRefer);
        container.setEmpty(isEmpty);
        container.setOOG(isOOg);
        container.setDamaged(isDamaaged);
        container.setHazardous(isHazardous);
        container.setHazardousCode(hazardousCode);

        return container;
    }

    /**
     * Get IMDG code for a given container
     * 
     * @param unNo
     * @param unNo2
     * @param unNo3
     * @return
     */
    private String getHazardousCode(Integer unNo, Integer unNo2, Integer unNo3) {
        StringBuilder hazardousCodeBuilder = new StringBuilder();
        List<String> hazardousCodeList = new ArrayList<String>();
        String imdgCodes = null;
        try {

            if (unNo != null && unNo > 0) {
                hazardousCodeList.add(unNo.toString());
            }

            if (unNo2 != null && unNo2 > 0) {
                hazardousCodeList.add(unNo2.toString());
            }
            if (unNo3 != null && unNo3 > 0) {
                hazardousCodeList.add(unNo3.toString());
            }

            for (String imoCode : hazardousCodeList) {
                hazardousCodeBuilder.append(imoCode).append(
                        Constants.COMMA_DELIMITER);
            }

            if (hazardousCodeBuilder.length() > 0) {
                imdgCodes = hazardousCodeBuilder.substring(0,
                        hazardousCodeBuilder.length() - 1);
            }

        } catch (Exception e) {
            LOGGER.error("Exception while retriveing IMDG code: ", e);
        }
        return imdgCodes;
    }
}
