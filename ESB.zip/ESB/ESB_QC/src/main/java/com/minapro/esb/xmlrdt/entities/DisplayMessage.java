package com.minapro.esb.xmlrdt.entities;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

@XmlRootElement(name = "displayMsg")
public class DisplayMessage {

    private String msgID;
    private String content;

    @XmlAttribute(name = "msgID")
    public String getMsgID() {
        return msgID;
    }

    public void setMsgID(String msgID) {
        this.msgID = msgID;
    }

    @XmlValue
    public String getContent() {
        return content;
    }

    @Override
    public String toString() {
        return "DisplayMessage [msgID=" + msgID + ", content=" + content + "]";
    }

    public void setContent(String content) {
        this.content = content;
    }

}
