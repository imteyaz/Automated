package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.ContainerInquiryEvent;
import com.minapro.procserver.events.ContainerInquiryResponseEvent;

public class QCContainerInquiryProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(QCContainerInquiryProcessor.class);

    @Override
    public void process(Exchange exchange) throws SQLException {
        LOGGER.info("************ Inside QCContainerInquiryProcessor process method ************");
        org.apache.log4j.MDC.put("app.name", "QCContainerInquiryProcessor");
        Connection connection = null;
        PreparedStatement contrInquiryStmt = null;
        ResultSet contrInquriryResultSet = null;
        ContainerInquiryResponseEvent responseEvent = new ContainerInquiryResponseEvent();
        try {
            ContainerInquiryEvent requestEvent = (ContainerInquiryEvent) exchange
                    .getProperty(Constants.QC_OPERATOR
                            + Constants.CONTR_INQUIRY_EVENT);

            if (requestEvent != null && requestEvent.getContainerId() != null) {
                LOGGER.info("Processing QCContainerInquiryProcessor with Event ID --> "
                        + requestEvent.getEventID()
                        + "  Equipment ID --> "
                        + requestEvent.getEquipmentID());

                @SuppressWarnings("deprecation")
                DataSource dataSource = (DataSource) exchange.getContext()
                        .getRegistry().lookup(Constants.PROMIS_DB);
                connection = dataSource.getConnection();
                LOGGER.debug("Connection established with PROMIS DB ");
                String contrNo =  requestEvent.getContainerId();

                String contrId = contrNo.length()>10? contrNo.substring(0,contrNo.length()-1) : contrNo;
                String checkSumDigit = contrNo.substring(contrNo.length()-1, contrNo.length());

                LOGGER.info("Querying container inquiry details from DPA_LISTS  with container ID : "
                        + contrId);

                contrInquiryStmt = connection
                        .prepareStatement(Constants.CONTR_INQUIRY_QUERY);
                contrInquiryStmt.setString(1, contrId);
                contrInquiryStmt.setString(2, checkSumDigit);
                contrInquiryStmt.setString(3, contrId);
                contrInquiryStmt.setString(4, checkSumDigit);

                LOGGER.info("Querying DPA_LISTS & ROB_LIST for Container ID : "
                        + requestEvent.getContainerId() + " and event ID : "
                        + requestEvent.getEventID());
                contrInquriryResultSet = contrInquiryStmt.executeQuery();

                responseEvent = inquireContrDetails(contrInquriryResultSet);

                LOGGER.info("Container inquiry status: "
                        + responseEvent.isInquiryStatus() + " for contrID : "
                        + requestEvent.getContainerId());
            }

            responseEvent.setEquipmentID(requestEvent.getEquipmentID());
            responseEvent.setEventID(requestEvent.getEventID());
            responseEvent.setTerminalID(requestEvent.getTerminalID());
            responseEvent.setUserID(requestEvent.getUserID());
            responseEvent.setContainerId(requestEvent.getContainerId());
            LOGGER.info("Response sent to RDT for ContainerInquiryProcessor is --> "
                    + responseEvent);

            exchange.getOut().setBody(responseEvent);
            exchange.setProperty(Constants.CONTR_INQUIRY_EVENT, "yes");
            exchange.setProperty(Constants.ROUTED, null);

        } catch (Exception e) {
            LOGGER.error(
                    "Exception occurred while container Inquiry processing : ",
                    e);
        } finally {
            if (contrInquiryStmt != null) {
                contrInquiryStmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    private ContainerInquiryResponseEvent inquireContrDetails(
            ResultSet contrInquriryResultSet) {
        ContainerInquiryResponseEvent responseEvent = new ContainerInquiryResponseEvent();

        try {
            while (contrInquriryResultSet.next()) {

                String containerNo = contrInquriryResultSet
                        .getString("ContainerNo");
                boolean inquiryStatus = containerNo != null ? true : false;

                String line = contrInquriryResultSet.getString("LineCode");
                String terminal = contrInquriryResultSet.getString("Terminal");
                String currentPos = contrInquriryResultSet
                        .getString("ContainerPos");
                String status = contrInquriryResultSet.getString("Status");
                String yardIn = contrInquriryResultSet.getString("YardIn");

                boolean isStopped = isIndicatorFlag(contrInquriryResultSet
                        .getString("Stop"));
                boolean isDamaged = isIndicatorFlag(contrInquriryResultSet
                        .getString("DamageInd"));

                String inBoundVessel = contrInquriryResultSet
                        .getString("InboundVsl");
                String inBoundRotation = contrInquriryResultSet
                        .getString("InboubdRotation");
                String outBoundVessel = contrInquriryResultSet
                        .getString("OutboundVsl");
                String outBoundRotation = contrInquriryResultSet
                        .getString("OutboundRotation");

                String shipper = contrInquriryResultSet.getString("shipper");
                String pod = contrInquriryResultSet.getString("POD");
                String loadPort = contrInquriryResultSet.getString("LoadPort");

                String sealNo = contrInquriryResultSet.getString("SealNo");
                boolean isSealed = isIndicatorFlag(contrInquriryResultSet
                        .getString("Seal"));

                String imoClass = contrInquriryResultSet.getString("IMOClass");
                Boolean isReefer = isIndicatorFlag(contrInquriryResultSet
                        .getString("Reefer"));
                Double weight = contrInquriryResultSet.getDouble("Weight");

                Boolean isOOg = isIndicatorFlag(contrInquriryResultSet
                        .getString("oog"));
                String oogLeft = contrInquriryResultSet.getString("OOGLeft");
                String oogRight = contrInquriryResultSet.getString("OOGRight");
                String oogFront = contrInquriryResultSet.getString("OOGFront");
                String oogBack = contrInquriryResultSet.getString("OOGBack");
                String oogTop = contrInquriryResultSet.getString("OOGTop");

                String isoCode = contrInquriryResultSet.getString("ISOCode");
                String agent = contrInquriryResultSet.getString("Agent");
                String moveType = contrInquriryResultSet.getString("MoveKind");
                /*if (null != moveType && "D".equalsIgnoreCase(moveType)) {
                    moveType = "DSCH";
                } else {
                    moveType = "LOAD";
                }*/
                
                String stoDays = contrInquriryResultSet.getString("STODays");
                String category = contrInquriryResultSet.getString("Category");

                String yardOut = contrInquriryResultSet.getString("YardOut");
                String stopReason = contrInquriryResultSet.getString("Reason");
                String damageCode = contrInquriryResultSet.getString("Damage");
                String consignee = contrInquriryResultSet
                        .getString("Consignee");
                String destination = contrInquriryResultSet
                        .getString("Destination");
                String originPort = contrInquriryResultSet
                        .getString("OriginPort");
                String unNo = contrInquriryResultSet.getString("UnNo");
                String temperature = contrInquriryResultSet
                        .getString("Temperature");
                String plugInDays = contrInquriryResultSet
                        .getString("PlugInDays");
                String plugIn = contrInquriryResultSet.getString("PlugIn");
                boolean isPluggedIn = isIndicatorFlag(plugIn);
                String content = contrInquriryResultSet.getString("Content");

                /**
                 * Assign container details retrieved from DPA_LIST & ROB_LISTS
                 * to responseEvent
                 */
                
                responseEvent.setLine(line);
                responseEvent.setTerminal(terminal);
                responseEvent.setCurrentPos(currentPos);
                responseEvent.setStatus(status);
                responseEvent.setYardIn(yardIn);

                responseEvent.setStopped(isStopped);
                responseEvent.setDamaged(isDamaged);

                responseEvent.setInBoundVessel(inBoundVessel);
                responseEvent.setInBoundRotation(inBoundRotation);
                responseEvent.setOutBoundVessel(outBoundVessel);
                responseEvent.setOutBoundRotation(outBoundRotation);

                responseEvent.setShipper(shipper);
                responseEvent.setPod(pod);
                responseEvent.setLoadPort(loadPort);

                responseEvent.setSealNo(sealNo);
                responseEvent.setSealed(isSealed);

                responseEvent.setImoClass(imoClass);
                responseEvent.setReefer(isReefer);
                responseEvent.setWeight(weight.toString());

                responseEvent.setOOG(isOOg);
                responseEvent.setOogLeft(oogLeft);
                responseEvent.setOogRight(oogRight);
                responseEvent.setOogFront(oogFront);
                responseEvent.setOogBack(oogBack);
                responseEvent.setOogTop(oogTop);

                responseEvent.setIso(isoCode);
                responseEvent.setAgent(agent);
                responseEvent.setMoveKind(moveType);
                responseEvent.setStoDays(stoDays);

                responseEvent.setCategory(category);
                responseEvent.setYardOut(yardOut);
                responseEvent.setYardIn(yardIn);

                responseEvent.setStopReason(stopReason);
                responseEvent.setDamageCode(damageCode);

                responseEvent.setConsignee(consignee);
                responseEvent.setDestination(destination);
                responseEvent.setOriginPort(originPort);
                responseEvent.setUnNo(unNo);

                responseEvent.setTemperature(temperature);
                responseEvent.setPlugInDays(plugInDays);
                responseEvent.setPluggedIn(isPluggedIn);
                responseEvent.setContent(content);

                responseEvent.setInquiryStatus(inquiryStatus);
            }
        } catch (SQLException e) {
            LOGGER.error(
                    "SQLException occured while container Inquiry from DB : ",
                    e);
        }
        return responseEvent;
    }

    private boolean isIndicatorFlag(String indicatorFlag) {
        boolean indicator = false;
        if (null != indicatorFlag
                && ("Y".equalsIgnoreCase(indicatorFlag) || "Yes"
                        .equalsIgnoreCase(indicatorFlag))) {
            indicator = true;
        }
        return indicator;
    }
 
}
