package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.UpdateContainerEvent;
import com.minapro.procserver.events.UpdateContainerInquiryRequestEvent;
import com.minapro.procserver.events.UpdateContainerInquiryResponseEvent;

public class QCUpdateContainerInquiryProcessor implements Processor {

    private static final Logger LOGGER = Logger
            .getLogger(QCUpdateContainerInquiryProcessor.class);

    @Override
    public void process(Exchange exchange) throws SQLException {
        LOGGER.info("************ Inside QCUpdateContainerInquiryProcessor process method ************");
        org.apache.log4j.MDC.put("app.name", "QCUpdateContainerInquiryProcessor");
        Connection connection = null;
        PreparedStatement contrInquiryStmt = null;
        ResultSet contrInquriryResultSet = null;
        UpdateContainerInquiryResponseEvent responseEvent = null;
        UpdateContainerInquiryRequestEvent requestEvent = (UpdateContainerInquiryRequestEvent) exchange
                .getProperty(Constants.UPDATE_CONTR_INQUIRY_EVENT);
        
        LOGGER.info("QCUpdateContainerInquiryProcessor request received "+requestEvent);
        try {

            if (requestEvent != null && requestEvent.getContainerId() != null) {
                LOGGER.info("Processing QCUpdateContainerInquiryProcessor with Event ID --> "
                        + requestEvent.getEventID()
                        + "  Equipment ID --> "
                        + requestEvent.getEquipmentID());

                @SuppressWarnings("deprecation")
                DataSource dataSource = (DataSource) exchange.getContext()
                        .getRegistry().lookup("PromisDataSource");
                connection = dataSource.getConnection();
                LOGGER.debug("Connection established with PROMIS DB ");

                String contrNo = requestEvent.getContainerId();
                String contrId = contrNo.length()>10? contrNo.substring(0,contrNo.length()-1) : contrNo;
                String checkSumDigit = contrNo.substring(contrNo.length()-1, contrNo.length());
                        
                LOGGER.info("Querying container inquiry details from DPA_LISTS  with container ID : "
                        + contrId);
                
                contrInquiryStmt = connection
                        .prepareStatement(Constants.UPDATE_CONTR_INQUIRY_QUERY);
                contrInquiryStmt.setString(1, contrId);
                contrInquiryStmt.setString(2, checkSumDigit);
                LOGGER.info("Querying DPA_LISTS for Container ID: "
                        + requestEvent.getContainerId() + " and event ID : "
                        + requestEvent.getEventID());
                contrInquriryResultSet = contrInquiryStmt.executeQuery();

                responseEvent = inquireContrDetails(contrInquriryResultSet, contrNo);

                LOGGER.info("container inquiry status: "
                        + responseEvent.isInquiryStatus() + " for contrID : "
                        + requestEvent.getContainerId()
                        + " retrived from DB --> " + responseEvent);
                
            }

        } catch (Exception e) {
            LOGGER.error(
                    "Exception occurred while update container attributes Inquiry processing : ",
                    e);
        } finally {
            if (contrInquiryStmt != null) {
                contrInquiryStmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
        responseEvent.setEquipmentID(requestEvent.getEquipmentID());
        responseEvent.setEventID(requestEvent.getEventID());
        responseEvent.setTerminalID(requestEvent.getTerminalID());
        responseEvent.setUserID(requestEvent.getUserID());

        LOGGER.info("Response sent to RDT for QCUpdateContainerInquiryProcessor is --> "
                + responseEvent);

        exchange.getOut().setBody(responseEvent);
        exchange.setProperty(Constants.UPDATE_CONTR_INQUIRY_EVENT, "yes");
        exchange.setProperty(Constants.ROUTED, null);
    }

    private UpdateContainerInquiryResponseEvent inquireContrDetails(
            ResultSet contrInquriryResultSet, String contrNo) {
        UpdateContainerInquiryResponseEvent responseEvent = new UpdateContainerInquiryResponseEvent();
        UpdateContainerEvent updateContainerEvent = new UpdateContainerEvent();
        boolean inquiryStatus = false;
        
        try {
        	
            while (contrInquriryResultSet.next()) {                

                String containerNo = contrInquriryResultSet
                        .getString("ContainerNo");
                inquiryStatus = containerNo != null ? true : false;
                
                String isoCode = contrInquriryResultSet.getString("ISOCode");
                String line = contrInquriryResultSet.getString("LineCode");
                Integer size = contrInquriryResultSet.getInt("containerSize");
                Double weight = contrInquriryResultSet.getDouble("Weight");

                String category = contrInquriryResultSet.getString("Category");
                String desig = contrInquriryResultSet.getString("desig");
                String isEmpty = "MT".equalsIgnoreCase(desig) ? "T" : "F";

                String pod = contrInquriryResultSet.getString("POD");
                String npod = contrInquriryResultSet.getString("NextPort");
                String fpod = contrInquriryResultSet.getString("FinalPort");

                /**
                 * OOG(Out of Gauge) : Over Slot Gauge(F/B/L/R/T) = 11/12/13/14/15
                 */
                String oogFront = contrInquriryResultSet.getString("OOGFront");
                String oogBack = contrInquriryResultSet.getString("OOGBack");
                String oogLeft = contrInquriryResultSet.getString("OOGLeft");
                String oogRight = contrInquriryResultSet.getString("OOGRight");
                String oogTop = contrInquriryResultSet.getString("OOGTop");

                String outVessel = contrInquriryResultSet
                        .getString("OutboundVsl");
                String outVoyage = contrInquriryResultSet.getString("Voyage");
                
                String oogDimensions = appendStringwithSeperator(oogFront, oogBack, oogLeft, oogRight, oogTop);
                String plugIn = contrInquriryResultSet.getString("PlugIn"); 

                String sealNo = contrInquriryResultSet.getString("SealNo");
                String sealNo2 = contrInquriryResultSet.getString("SealNo2");
                String sealNo3 = contrInquriryResultSet.getString("SealNo3");
                String sealNo4 = contrInquriryResultSet.getString("SealNo4");

                /**
                 * Assign container details retrieved from DPA_LIST
                 */
                

                updateContainerEvent.setIsoCode(isoCode);
                updateContainerEvent.setLineCode(line);
                updateContainerEvent.setSize(size.toString());
                updateContainerEvent.setWeight(weight.toString());
                updateContainerEvent.setCategory(category);
                updateContainerEvent.setEmpty(isEmpty);
                updateContainerEvent.setOutVessel(outVessel);
                updateContainerEvent.setOutVoyage(outVoyage);
                updateContainerEvent.setPod(pod);
                updateContainerEvent.setNpod(npod);
                updateContainerEvent.setFpod(fpod);

                updateContainerEvent.setPlugCode(plugIn);
                updateContainerEvent.setOogDimensions(oogDimensions);

                updateContainerEvent.setSeal1(sealNo);
                updateContainerEvent.setSeal2(sealNo2);
                updateContainerEvent.setSeal3(sealNo3);
                updateContainerEvent.setSeal4(sealNo4);

                                
            }
        } catch (SQLException e) {
            LOGGER.error("SQLException occured while QCUpdateContainerInquiryProcessor from DB : ",e);
        }
        
        updateContainerEvent.setContainerID(contrNo);
        responseEvent.setUpdateContainerEvent(updateContainerEvent);
        responseEvent.setInquiryStatus(inquiryStatus);
        return responseEvent;
    }

    public static String appendStringwithSeperator(String oogFront, String oogBack, String oogLeft, String oogRight, String oogTop) {
        StringBuilder appendedBuilder = new StringBuilder();
        String appendValue = null;
        String[] actualValues = {oogFront, oogBack, oogLeft, oogRight, oogTop };
        
        for (String actualString : actualValues) {
            if (StringUtils.isNotBlank(actualString)) {
                appendedBuilder.append(actualString).append(
                        Constants.SLASH_DELIMITER);
            }

        }
        if (appendedBuilder.length() > 0) {
            appendValue = appendedBuilder.substring(0,
                    appendedBuilder.length() - 1);
        }

        return appendValue;
    }
}
