package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import utils.ExchangeRepo;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.ContainerDamageEvent;
import com.minapro.procserver.events.ContainerDamageResponseEvent;
import com.minapro.procserver.events.DamageDetails;
import com.minapro.procserver.events.DamageResponseDetails;

public class QCContainerDamageProcessor implements Processor {

	private static final Logger LOGGER = Logger
			.getLogger(QCContainerDamageProcessor.class);
	private static String seperator;

	@Override
	public void process(Exchange exchange) throws SQLException {
		LOGGER.info("Inside the QCContainerDamageProcessor... ");
		org.apache.log4j.MDC.put("app.name", "QCContainerDamageProcessor");
		boolean insertStatus = false;
		String reason = null;

		try {
			ContainerDamageEvent requestEvent = (ContainerDamageEvent) exchange
					.getProperty(Constants.QC_OPERATOR
							+ Constants.CONTR_DAMAGE_EVENT);

			LOGGER.info("QCContainerDamageProcessor request--> " + requestEvent);

			if (requestEvent != null && requestEvent.getDamageDetails() != null) {
				LOGGER.info("Processing QC ContainerDamageEvent with Event ID --> "
						+ requestEvent.getEventID()
						+ "  Equipment ID --> "
						+ requestEvent.getEquipmentID());

				/*
				 * Build Container Damage response
				 */
				ContainerDamageResponseEvent responseEvent = new ContainerDamageResponseEvent();
				List<DamageResponseDetails> dmgResponseList = new ArrayList<DamageResponseDetails>();
				List<DamageDetails> damageDetails = requestEvent
						.getDamageDetails();
				String terminalId = requestEvent.getTerminalID();

				for (DamageDetails damageRecord : damageDetails) {

					String containerId = damageRecord.getContainerID();

					/*
					 * Insert Damage details into PROMIS of PROTOS_DBA
					 */
					LOGGER.info("Record damage details into PROMIS: "+containerId);
					insertStatus = storeDamagecorrectionDetails(damageRecord,
							terminalId, containerId, requestEvent.getRotationId());
					reason = !insertStatus ? Constants.DAMAGE_RECORDING_ERROR
							: null;

					DamageResponseDetails dmgResponse = new DamageResponseDetails();
					dmgResponse.setContainerId(containerId);
					dmgResponse.setStatus(insertStatus);
					dmgResponse.setReason(reason);

					dmgResponseList.add(dmgResponse);
				}

				responseEvent.setDamageDeatils(dmgResponseList);
				responseEvent.setEquipmentID(requestEvent.getEquipmentID());
				responseEvent.setEventID(requestEvent.getEventID());
				responseEvent.setTerminalID(requestEvent.getTerminalID());
				responseEvent.setUserID(requestEvent.getUserID());

				send(exchange);
				exchange.getOut().setBody(responseEvent);
				exchange.setProperty(Constants.CONTR_DAMAGE_EVENT, "yes");
				exchange.setProperty(Constants.ROUTED, null);
				LOGGER.info("QC ContainerDamageResponseEvent sent --> "
						+ responseEvent);
			}
		} catch (Exception e) {
			LOGGER.error(
					"Exception occured while container Damage processing : ", e);
		}
	}

	/**
	 * Setting damage details for inserting into DB
	 * 
	 * @param dataSource
	 * @param damageRecord
	 * @param terminalId
	 * @param containerId
	 * @return
	 */
	private boolean storeDamagecorrectionDetails(DamageDetails damageRecord,
			String terminalId, String containerId, String rotnId) {
		String[] dmgCodes = damageRecord.getDamageCodes();
		String trxFormatOfDmgCodes = "";
		boolean insertStatus = false;
		if (dmgCodes != null && dmgCodes.length > 0) {
			for (String damageCode : dmgCodes) {
				/*
				 * Concatenation of all damage codes
				 */
				trxFormatOfDmgCodes += damageCode;
			}
			LOGGER.info("Damage codes string: "+trxFormatOfDmgCodes);
			
			String crtDate = null;
			try {
				crtDate = getContainerCRTDate(containerId, rotnId);
			} catch (SQLException e) {
				LOGGER.info("Exception while retriving CRTDate:", e);
			}
			LOGGER.info("CRTDate: "+crtDate+" received for ContainerId:"+containerId);
			
			insertStatus = insertContrDamageDetails(trxFormatOfDmgCodes,
					terminalId, containerId, crtDate);
			LOGGER.info("Insert status: "+insertStatus+" of Container Damage record with ContainerID : "
					+ containerId
					+ " inserted into DB successfully with eventID: ");
		}
		return insertStatus;
	}

	/**
	 * Insert each container damage record in PROMIS DB - SPARCS_INBOUND Table.
	 * 
	 * @param contrDamageInsertStmt
	 * @param trxFormatOfDmgCodes
	 * @param terminalId
	 * @param contrId
	 * @return
	 * @throws SQLException
	 */
	private boolean insertContrDamageDetails(String trxFormatOfDmgCodes,
			String terminalId, String containerId, String crtDate) {
		Connection connection = null;
		PreparedStatement contrDamageInsertStmt = null;
		boolean status = true;
		try {
			DataSource dataSource = getDataSource(Constants.PRTOS_DBA);
			connection = dataSource.getConnection();
			LOGGER.debug("Connection established with PRTOS DB ");
			
			contrDamageInsertStmt = connection
					.prepareStatement(Constants.INSERT_CONTIANER_DAMAGE_LIST_QUERY);			
			
			LOGGER.info("Executing insert into TOS_TO_PROMIS_STAGING table, Terminal:"+terminalId+" ContainerId: "
					+ containerId
					+ " CRTDate: "
					+ crtDate + " Damage Codes: " + trxFormatOfDmgCodes
					+" Insert Query: "+Constants.INSERT_CONTIANER_DAMAGE_LIST_QUERY);
			
			contrDamageInsertStmt.setString(1, containerId);
			contrDamageInsertStmt.setString(2, crtDate);
			contrDamageInsertStmt.setString(3, trxFormatOfDmgCodes);
			
			contrDamageInsertStmt.executeQuery();			
			
		} catch (SQLException e) {
			LOGGER.error(
					"SQLException occured while inserting Damage records : ", e);
			status = false;
		} finally {
			try {
				if (contrDamageInsertStmt != null) {
					contrDamageInsertStmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				LOGGER.error(
						"SQLException occured while closing connections for Damage records : ",
						e);
				status = false;
			}
		}
		return status;
	}

	/**
	 * 
	 * @param contrId
	 * @return
	 * @throws SQLException
	 */
	private String getContainerCRTDate(String contrId, String rotnId) throws SQLException {
		Connection connection = null;
		PreparedStatement crtDateStmt = null;
		ResultSet crtDateResultSet = null;
		String crtDate = null;
		try {
			connection = getDataSource(Constants.PROMIS_DB).getConnection();
			
			if( StringUtils.isNotBlank(rotnId)) {
				LOGGER.info("Executing query to retrieve CRTDate for QC: "+Constants.CNTR_CRT_DATE__ROB_QUERY);
				crtDateStmt = connection
						.prepareStatement(Constants.CNTR_CRT_DATE__ROB_QUERY);
				crtDateStmt.setString(1, contrId);
				crtDateStmt.setString(2, contrId);
				crtDateStmt.setString(3, rotnId);
			} else {
				LOGGER.info("Executing query to retrieve CRTDate: "+Constants.CNTR_CRT_DATE_QUERY);
				crtDateStmt = connection
						.prepareStatement(Constants.CNTR_CRT_DATE_QUERY);
				crtDateStmt.setString(1, contrId);
			}			
			
			crtDateResultSet = crtDateStmt.executeQuery();

			while (crtDateResultSet.next()) {
				crtDate = crtDateResultSet.getString("CRT_DATE");
				LOGGER.info(" CRT Date retreived from DB :  " + crtDate);
			}
		} catch (SQLException e) {
			LOGGER.error(
					"Exception occured while processing query for retrieving CRDdate with containerid: "
							+ contrId, e);
		} finally {
			if (null != connection) {
				connection.close();
			}
			if (null != crtDateStmt) {
				crtDateStmt.close();
			}
			if (null != crtDateResultSet) {
				crtDateResultSet.close();
			}
		}
		return crtDate;
	}

	/**
	 * 
	 * This method sends any object passed to it to the QC out q
	 * 
	 * @param t
	 *            Object to be sent to the queue
	 */
	private static <T> void send(Exchange exchange) {

		LOGGER.debug("Damage event sending to ESB_QC queue for updating OPUS");

		CamelContext context = exchange.getContext();
		ProducerTemplate template = context.createProducerTemplate();
		template.send("direct:ESBQ", exchange);
	}

	@SuppressWarnings("deprecation")
	private static DataSource getDataSource(String name) {
		Exchange exchange = ExchangeRepo.getExchange();
		return (DataSource) exchange.getContext().getRegistry().lookup(name);
	}


	/**
	 * get Damage code separator(/) to concatinate all container damage codes
	 * 
	 * @return
	 */
	public static String getSeperator() {
		return seperator;
	}

	/**
	 * set Damage code separator(/) to concatinate all damage codes
	 * 
	 * @param seperator
	 */
	public static void setSeperator(String seperator) {
		QCContainerDamageProcessor.seperator = seperator;
	}

}
