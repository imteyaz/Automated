package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the response for a login request.
 * 
 * @author Rosemary George
 * 
 */
public class LoginResponseEvent extends Event implements Serializable {
    private static final long serialVersionUID = 7510957083533830997L;

    /**
     * If ESB finds any difficulty in contacting the DPW IT systems, this will be set as failure Indicates the overall
     * status with possible values - success/failure
     */
    private String status;
    /**
     * The <AllocationEvent> details fetched for the user
     */
    private AllocationEvent allocationDetails;
    /**
     * <CertificateValidateEvent> details
     */
    private CertificateValidateEvent validateCertificateDetails;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AllocationEvent getAllocationDetails() {
        return allocationDetails;
    }

    public void setAllocationDetails(AllocationEvent allocationDetails) {
        this.allocationDetails = allocationDetails;
    }

    public CertificateValidateEvent getValidateCertificateDetails() {
        return validateCertificateDetails;
    }

    public void setValidateCertificateDetails(CertificateValidateEvent validateCertificateDetails) {
        this.validateCertificateDetails = validateCertificateDetails;
    }

    @Override
    public String toString() {
        return "LoginResponseEvent [status=" + status + ", allocationDetails=" + allocationDetails
                + ", validateCertificateDetails=" + validateCertificateDetails + ", UserID=" + getUserID()
                + ", TerminalID=" + getTerminalID() + "]";
    }
}
