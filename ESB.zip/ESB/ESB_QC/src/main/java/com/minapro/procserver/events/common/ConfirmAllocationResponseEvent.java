package com.minapro.procserver.events.common;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the Allocation failure message from ESB. Only in case of failure, this event is expected from
 * ESB.
 * 
 * @author Rosemary George
 * 
 */
public class ConfirmAllocationResponseEvent extends Event implements Serializable {

    private static final long serialVersionUID = -5094245232420901653L;
    /**
     * Contains the failure message which needs to be displayed to the user
     */
    private String reason;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "ConfirmAllocationResponseEvent [reason=" + reason + ", userId=" + getUserID() + ", equipmentId="
                + getEquipmentID() + "]";
    }
}
