/**
 * 
 */
package com.minapro.procserver.events;

import java.io.Serializable;

/**
 * ValueObject holding the status of each container damage recording in ESB
 * @author Rosemary George
 *
 *
 */
public class DamageResponseDetails implements Serializable{
   
    private static final long serialVersionUID = 6772946564493491901L;

    /**
     * Indicates the container to which the damage is recorded
     */
    private String containerId;
    
    /**
     * Indicates whether the damage recording for the container is successful or not
     */
    private boolean status;
    
    /**
     * In case the damage recording fails, holds the reason for failure
     */
    private String reason;
    


    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "DamageResponseDetails [containerId=" + containerId
                + ", status=" + status + ", reason=" + reason + "]";
    }
}
