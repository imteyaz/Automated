package com.minapro.esb.xmlrdt.entities;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ArrayOfEmployeeRoster")
public class ArrayOfEmployeeRoster {

    private EmployeeRoster roster;

    @XmlElement(name = "EmployeeRoster")
    public EmployeeRoster getRoster() {
        return roster;
    }

    public void setRoster(EmployeeRoster roster) {
        this.roster = roster;
    }

    @Override
    public String toString() {
        return "ArrayOfEmployeeRoster [roster=" + roster + "]";
    }

}
