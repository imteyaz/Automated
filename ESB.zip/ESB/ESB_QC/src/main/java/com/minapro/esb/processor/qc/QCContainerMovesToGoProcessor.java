package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.common.MovesToGoContainers;
import com.minapro.procserver.events.common.MovesToGoRequestEvent;
import com.minapro.procserver.events.common.MovesToGoResponseEvent;

public class QCContainerMovesToGoProcessor implements Processor {
    private static final Logger LOGGER = Logger
            .getLogger(QCContainerMovesToGoProcessor.class);

    @Override
    public void process(Exchange exchange) throws SQLException {
        LOGGER.info("Inside the QCContainerMovesToGoProcessor... ");
        org.apache.log4j.MDC.put("app.name", "QCContainerMovesToGoProcessor");
        try {
            MovesToGoRequestEvent requestEvent = (MovesToGoRequestEvent) exchange
                    .getProperty(Constants.QC_OPERATOR
                            + Constants.MOVES_TO_GO_EVENT);
            List<MovesToGoContainers> movesToGoContrsList = null;
            if (requestEvent != null) {
                MovesToGoResponseEvent responseEvent = new MovesToGoResponseEvent();
                if (requestEvent.getMovesToGoContainerIds() != null) {
                    movesToGoContrsList = getContrrMovesToGoCount(
                            getDBConnection(exchange), requestEvent);
                }
                responseEvent.setEquipmentID(requestEvent.getEquipmentID());
                responseEvent.setEventID(requestEvent.getEventID());
                responseEvent.setTerminalID(requestEvent.getTerminalID());
                responseEvent.setUserID(requestEvent.getUserID());
                responseEvent.setMovesToGoList(movesToGoContrsList);
                responseEvent.setQcId(requestEvent.getQcId());

                exchange.getOut().setBody(responseEvent);
                exchange.setProperty(Constants.MOVES_TO_GO_EVENT, "yes");
                exchange.setProperty(Constants.ROUTED, null);
                LOGGER.info("QC MovesToGoResponseEvent sent to RDT--> "
                        + responseEvent);
            }
        } catch (Exception e) {
            LOGGER.error(
                    "Exception occured while QCContainerMovesToGoProcessor : ",
                    e);
        }
    }

    private List<MovesToGoContainers> getContrrMovesToGoCount(Connection conn,
            MovesToGoRequestEvent requestEvent) throws SQLException {
        LOGGER.info("*************** In QC getAllContainerMovesToGo *************");

        PreparedStatement statement = null;
        ResultSet movesToGoContrListResultSet = null;
        List<MovesToGoContainers> movesToGoContrsList = new ArrayList<MovesToGoContainers>();
        try {
            LOGGER.debug("Conection established with PROMIS DB");
            List<String> queryStatements = getContainerStatementList(requestEvent
                    .getMovesToGoContainerIds());
            
            if (!queryStatements.isEmpty() && queryStatements.size() > 0) {
                for (String sqlQuery : queryStatements) {
                    LOGGER.info("QC equipment:" + requestEvent.getQcId()
                            + " Moves to go Query :" + sqlQuery);
                    statement = conn.prepareStatement(sqlQuery);
                    statement.setString(1, requestEvent.getRotationId());
                    movesToGoContrListResultSet = statement.executeQuery();

                    while (movesToGoContrListResultSet.next()) {
                        String moveType = movesToGoContrListResultSet
                                .getString("moveType");
                        int contrSize = movesToGoContrListResultSet
                                .getInt("containerSize");
                        String containerEmpty = movesToGoContrListResultSet
                                .getString("containerEmpty");
                        String oog = movesToGoContrListResultSet
                                .getString("oog");
                        int oogContainerCount = movesToGoContrListResultSet
                                .getInt("oogCount");

                        boolean isEmpty = containerEmpty != null
                                && "E".equalsIgnoreCase(containerEmpty) ? true
                                : false;
                        boolean isOog = oog == null
                                || "N".equalsIgnoreCase(oog) ? false : true;

                        MovesToGoContainers movesToGoContainer = new MovesToGoContainers();
                        movesToGoContainer.setMoveType(moveType);
                        movesToGoContainer.setContainerSize(contrSize);
                        movesToGoContainer.setEmpty(isEmpty);
                        movesToGoContainer.setOog(isOog);
                        movesToGoContainer.setContainerCount(oogContainerCount);
                        LOGGER.info("MovestoGo Container details : "
                                + movesToGoContainer.toString());
                        movesToGoContrsList.add(movesToGoContainer);
                    }
                }
            }
        } catch(Exception e){
            LOGGER.error("Exception occured while while executing query Moves to go ", e);
        } finally {

            if (movesToGoContrListResultSet != null) {
                movesToGoContrListResultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (conn != null) {
                conn.close();
            }

        }
        return movesToGoContrsList;
    }
    
    /**
     * Split SQL select statements with IN CLUASE carrying parameters of containerIDs more than 1000
     * and return Complete list of select statements  
     * @param contrList
     * @return
     */
    public static List<String> getContainerStatementList(List<String> contrList) {
        List<String> sqlStatements = new ArrayList<String>();

        for (int sqlGrpCount = 0; sqlGrpCount < contrList.size(); sqlGrpCount = sqlGrpCount
                + Constants.IN_PARAMETER_LIMIT) {
            if (sqlGrpCount + Constants.IN_PARAMETER_LIMIT > contrList.size()) {
                sqlStatements.add(getSqlForContainer(contrList.subList(
                        sqlGrpCount, contrList.size() - 1)));
            } else {
                sqlStatements.add(getSqlForContainer(contrList.subList(
                        sqlGrpCount, sqlGrpCount + Constants.IN_PARAMETER_LIMIT)));
            }
        }
        return sqlStatements;
    }

    /**
     * Prepare select statement appended with containerID with single quotes seperated with commas
     * @param contrList
     * @return
     */
    private static String getSqlForContainer(List<String> contrList) {

        StringBuilder containersListBuilder = new StringBuilder();
        for (String containerId : contrList) {
            String contrId = containerId.length() > 10 ? containerId.substring(
                    0, 10) : containerId;
            containersListBuilder.append("'").append(contrId).append("',");
        }

        StringBuilder sql = new StringBuilder(
                Constants.GET_MOVESTOGO_QUERY_START + "(");
        String contrIds = containersListBuilder.substring(0,
                containersListBuilder.length()- 1);

        return (sql.append(contrIds)).append(
                ")" + Constants.GET_MOVESTOGO_QUERY_END).toString();
    }

    /**
     * Get Datasource connection
     * 
     * @throws SQLException
     */
    @SuppressWarnings("deprecation")
    private Connection getDBConnection(Exchange exchange) throws SQLException {
        DataSource dataSource = (DataSource) exchange.getContext()
                .getRegistry().lookup(Constants.PROMIS_DB);

        return dataSource.getConnection();
    }
}
