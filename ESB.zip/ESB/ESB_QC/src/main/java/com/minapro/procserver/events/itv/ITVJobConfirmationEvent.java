package com.minapro.procserver.events.itv;

import java.io.Serializable;

import com.minapro.procserver.events.Event;

/**
 * ValueObject holding the ITV job confirmation details
 * 
 * @author Rosemary George
 * 
 */
public class ITVJobConfirmationEvent extends Event implements Serializable {
    private static final long serialVersionUID = -4486231894307600022L;

    /**
     * The container ID which the ITV has discharged to either QC or CHE
     */
    private String containerID;

    public String getContainerID() {
        return containerID;
    }

    public void setContainerID(String containerID) {
        this.containerID = containerID;
    }

    @Override
    public String toString() {
        return "ITVJobConfirmationEvent [containerID=" + containerID + ", UserID=" + getUserID() + ", TerminalID="
                + getTerminalID() + "]";
    }
}
