package com.minapro.esb.processor;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import utils.DateUtils;
import utils.ExchangeRepo;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.EmployeeShiftRoster;

/**
 * Get all user shift  details from PROMIS stored procedure
 * Store user shift timings in ATOM DB
 * @author 1102783
 *
 */
public class RostimaShiftProcessor implements Processor {
    private static final Logger LOGGER = Logger
            .getLogger(RostimaShiftProcessor.class);
            

    @Override
    public void process(Exchange exchange) throws Exception {      
        List<EmployeeShiftRoster> employeeRosterList = getAllUserIds();
        employeeRosterList = getUserShiftScheduleDetails(employeeRosterList);       
    }

    
    /**
     * Get all ATOM User details from MP_USERDTLS_AM
     */
    private List<EmployeeShiftRoster> getAllUserIds() throws SQLException {     
        Connection connection = null;
        PreparedStatement userDetailsStmt = null;
        ResultSet userDetailsResultSet = null;
        List<EmployeeShiftRoster> employeeRosterList = new ArrayList<EmployeeShiftRoster>();
        try {                       
            connection = getDataSource(Constants.PRTOSD_MP).getConnection();
            userDetailsStmt = connection.prepareStatement(Constants.GET_USERS_QUERY);
            userDetailsResultSet = userDetailsStmt.executeQuery();          
            
            while (userDetailsResultSet.next()) {
                EmployeeShiftRoster employeeRoster = new EmployeeShiftRoster();
                String employeeId = userDetailsResultSet.getString("userId");
                employeeRoster.setEmployeeId(employeeId);
                employeeRosterList.add(employeeRoster);
            }            
            LOGGER.debug("Employee details retrieved from PROMIS DB ->> "+employeeRosterList.toString());
        } catch (SQLException e) {
            LOGGER.error("Exception while retrieving users ",e);
        } finally {
            if (userDetailsResultSet != null) {
                userDetailsResultSet.close();
            }

            if (userDetailsStmt != null) {
                userDetailsStmt.close();
            }

            if (connection != null) {
                connection.close();
            }
        }
        return employeeRosterList; 
    }

    /**
     * getUserShiftScheduleDetails by Procedure call DPWJAPROD.DPW_IVR_GET_SCHEDULE 
     * @param employeeRosterList
     * @return
     * @throws SQLException
     */
    private List<EmployeeShiftRoster> getUserShiftScheduleDetails(List<EmployeeShiftRoster> employeeRosterList)
            throws SQLException {           
        Connection connection = null;
        CallableStatement callableStatement = null;
        ResultSet shiftDetailsResultSet = null; 
        List<EmployeeShiftRoster> employeeRosterShiftDetailsList = new ArrayList<EmployeeShiftRoster>();        
        
        try {           
            connection = getDataSource(Constants.DPWJA_DB).getConnection();
            callableStatement = connection
                    .prepareCall(Constants.GET_SHIFT_SCHEDULE_PROCEDURE);
            
            Date date = DateUtils.getCurrentDate();
            String shiftStartDate = DateUtils.parseDate(date);
            String shiftEndDate = DateUtils.addDays(date,1);
            
            /**
            String shiftStartDate = "14/JUL/2016";
            String shiftEndDate = "14/JUL/2016";
            EmployeeShiftRoster employeeRosterTest = new EmployeeShiftRoster();
            employeeRosterTest.setEmployeeId("405930");     
            employeeRosterList.add(employeeRosterTest);*/
            
            LOGGER.info("Retrieve shift details for ALL Users");
            for (EmployeeShiftRoster empRoster : employeeRosterList) {
            
                callableStatement.setString(1, empRoster.getEmployeeId());
                callableStatement.setString(2, shiftStartDate);
                callableStatement.setString(3, shiftEndDate);
                callableStatement.registerOutParameter(4, OracleTypes.CURSOR);

                callableStatement.execute();
                shiftDetailsResultSet = (ResultSet) callableStatement.getObject(4);

                while (shiftDetailsResultSet.next()) {
                    EmployeeShiftRoster employeeRoster = new EmployeeShiftRoster();
                    String employeeId = shiftDetailsResultSet.getString("EMPLOYEEID");
                    String shiftDate = shiftDetailsResultSet.getString("SHIFTDATE");
                    String shiftTime = shiftDate + Constants.SPACE + shiftDetailsResultSet.getString("SHIFTTIME");
                    String shiftEnd = shiftDate + Constants.SPACE + shiftDetailsResultSet.getString("SHIFTEND");
                    String shiftLocation = shiftDetailsResultSet.getString("SHIFTLOCATION");
                    String equipmentId= shiftDetailsResultSet.getString("EQUIPMENT");
                    String shiftType = shiftDetailsResultSet.getString("SHIFTTYPE");
                    
                    employeeRoster.setEmployeeId(employeeId);
                    employeeRoster.setShiftTime(shiftTime);
                    employeeRoster.setShiftEnd(shiftEnd);                   
                    employeeRoster.setShiftLocation(shiftLocation);
                    employeeRoster.setEquipmentId(equipmentId);
                    employeeRoster.setShiftType(shiftType);
                    
                    employeeRosterShiftDetailsList.add(employeeRoster);
                }                           
            }
            LOGGER.info("Rostima Shift details retrieved from DB ->> "+employeeRosterShiftDetailsList.toString());
            // Insert Employee all shift timings data in SHIFT_MASTER 
            if (!employeeRosterShiftDetailsList.isEmpty() && employeeRosterShiftDetailsList.size()>0) {
                LOGGER.info("Inserting Employee shift timings into MP_SHIFT_MASTER");
                insertEmployeeShiftDetails(employeeRosterShiftDetailsList);
            }   
        } catch (SQLException e) {
            LOGGER.error("Exception while retrieving rostima shift details ",e);
        } finally {
            if (shiftDetailsResultSet != null) {
                shiftDetailsResultSet.close();
            }

            if (callableStatement != null) {
                callableStatement.close();
            }

            if (connection != null) {
                connection.close();
            }
        }
        return employeeRosterShiftDetailsList; 
    }
    
    /**
     * Insert user shift details in MP_SHIFT_MASTER
     * @param employeeRosterList
     * @throws SQLException
     */
    private static void insertEmployeeShiftDetails(
            List<EmployeeShiftRoster> employeeRosterList) throws SQLException {

        Connection connection = null;
        PreparedStatement insertUserShiftStmt = null;
        PreparedStatement deleteUserShiftStmt = null;
        try {
            connection = getDataSource(Constants.PRTOSD_MP).getConnection();
            
            // Delete shift details query from SHIFT_MASTER Table            
            deleteUserShiftStmt = connection
                    .prepareStatement(Constants.DELETE_SHIFT_MASTER_DETAILS_QUERY);

            // Insert shift details query to SHIFT_MASTER Table
            insertUserShiftStmt = connection
                    .prepareStatement(Constants.INSERT_SHIFT_MASTER_QUERY);         
                for (EmployeeShiftRoster employeeRoster : employeeRosterList) {

                    deleteUserShiftStmt.setString(1,
                            employeeRoster.getEmployeeId());
                    deleteUserShiftStmt.addBatch();
                    
                /**  LOGGER.info("Insert User shift timings into DB :"
                            + employeeRoster.getEmployeeNumber()
                            + " Shift starts:" + employeeRoster.getShiftStart()
                            + " Shift ends: " + employeeRoster.getShiftEnd());*/
                    java.sql.Timestamp shiftStartDate = DateUtils.parseStringToTimestamp(employeeRoster.getShiftTime());
                    java.sql.Timestamp shiftEndDate = DateUtils.parseStringToTimestamp(employeeRoster.getShiftEnd());
                    
                    insertUserShiftStmt.setString(1,employeeRoster.getEmployeeId());
                    insertUserShiftStmt.setString(2,employeeRoster.getShiftLocation());
                    insertUserShiftStmt.setString(3,employeeRoster.getShiftType());
                    insertUserShiftStmt.setTimestamp(4,shiftStartDate);
                    insertUserShiftStmt.setTimestamp(5,shiftEndDate);                   
                    insertUserShiftStmt.setString(6,Constants.ATOM);
                    insertUserShiftStmt.setTimestamp(7,DateUtils.getCurrentTimestamp());
                    insertUserShiftStmt.addBatch();
                }
                int[] deletedJobsCount = deleteUserShiftStmt.executeBatch();
                LOGGER.info(deletedJobsCount.length
                        + " records DELETED from MP_SHIFT_MASTER Table");

                int[] insertRecordCount = insertUserShiftStmt.executeBatch();
                LOGGER.info(insertRecordCount.length
                        + " User shift details INSERTED from SHIFT_MASTER Table");
            
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing Query on SHIFT_MASTER Table ", e);
        } finally {
            if (insertUserShiftStmt != null) {
                insertUserShiftStmt.close();
            }
            if (deleteUserShiftStmt != null) {
                deleteUserShiftStmt.close();
            }
        }
    }

    @SuppressWarnings("deprecation")
    private static DataSource getDataSource(String name) {
        Exchange exchange = ExchangeRepo.getExchange();
        return (DataSource) exchange.getContext().getRegistry().lookup(name);

    }
}
