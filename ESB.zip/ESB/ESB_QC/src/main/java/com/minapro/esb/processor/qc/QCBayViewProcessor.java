package com.minapro.esb.processor.qc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import com.minapro.esb.common.Constants;
import com.minapro.procserver.events.Container;
import com.minapro.procserver.events.common.BayProfileContainer;
import com.minapro.procserver.events.common.BaywiseContainerDetailsRequestEvent;
import com.minapro.procserver.events.common.BaywiseContainerDetailsResponseEvent;

public class QCBayViewProcessor implements Processor {
    private static final Logger LOGGER = Logger
            .getLogger(QCBayViewProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {

        org.apache.log4j.MDC.put("app.name", "QCBayViewProcessor");

        LOGGER.debug("Inside QCBayViewProcessor...");

        BaywiseContainerDetailsRequestEvent requestEvent = (BaywiseContainerDetailsRequestEvent) exchange
                .getIn().getBody();
        List<BayProfileContainer> containersList = new ArrayList<BayProfileContainer>();

        if (requestEvent != null) {

            LOGGER.info("Processing QCBayViewProcessor request with Event ID --> "
                    + requestEvent.getEventID()
                    + "  Equipment ID --> "
                    + requestEvent.getEquipmentID());
            try {
                @SuppressWarnings("deprecation")
                DataSource dataSource = (DataSource) exchange.getContext()
                        .getRegistry().lookup(Constants.PROMIS_DB);

                containersList = getBayWiseContainerDetails(
                        requestEvent, dataSource);
            } catch (Exception e) {
                LOGGER.error(
                        "Exception occured while QC bay view request processing : ",
                        e);
            }
            BaywiseContainerDetailsResponseEvent responseEvent = new BaywiseContainerDetailsResponseEvent();

            responseEvent.setBayNo(requestEvent.getBayNo());
            responseEvent.setContainerList(containersList);
            responseEvent.setEquipmentID(requestEvent.getEquipmentID());
            responseEvent.setEventID(requestEvent.getEventID());
            responseEvent.setTerminalID(requestEvent.getTerminalID());
            responseEvent.setUnderDeckIndication(requestEvent
                    .getUnderDeckIndication());
            responseEvent.setUserID(requestEvent.getUserID());
            responseEvent.setVesselCode(requestEvent.getVesselCode());
            responseEvent.setRotationID(requestEvent.getRotationID());

            exchange.getOut().setBody(responseEvent);
            exchange.setProperty("BayView", "yes");
            exchange.setProperty(Constants.ROUTED, null);
            LOGGER.info("QC Bay View Response event is  --> " + responseEvent);
            LOGGER.debug("End of QCBayViewProcessor...");
        }

    }

    private java.util.List<BayProfileContainer> getBayWiseContainerDetails(
            BaywiseContainerDetailsRequestEvent requestEvent,
            DataSource dataSource) {
        Connection con = null;
        PreparedStatement statement = null;
        PreparedStatement robStatement = null;
        ResultSet dpaSet = null;
        ResultSet robSet = null;
        List<BayProfileContainer> containersList = new ArrayList<BayProfileContainer>();
        try {
            String bayNo = requestEvent.getBayNo();
            String vesselCode = requestEvent.getVesselCode();
            String underDeckIndi = requestEvent.getUnderDeckIndication();

            con = dataSource.getConnection();
            LOGGER.debug("Connection established with PROMIS DB ");
            LOGGER.info("Querying container details from DPA_LISTS  with vessel code : "
                    + vesselCode);
            if ("d".equalsIgnoreCase(underDeckIndi)) {
                LOGGER.info("Deck No  : " + requestEvent.getDeckStartTierNo()
                        + ", Rotation Number : " + requestEvent.getRotationID()
                        + " & Bay No : " + requestEvent.getBayNo());

                statement = con
                        .prepareStatement(Constants.GET_DPA_CONTIANERS_LIST_QUERY
                                + ">=" + requestEvent.getDeckStartTierNo());
                statement.setInt(1,
                        Integer.parseInt(requestEvent.getRotationID()));
                statement.setString(2, bayNo);

                robStatement = con
                        .prepareStatement(Constants.GET_ROB_CONTIANERS_LIST_QUERY
                                + ">= " + requestEvent.getDeckStartTierNo());
                robStatement.setInt(1,
                        Integer.parseInt(requestEvent.getRotationID()));
                robStatement.setString(2, requestEvent.getBayNo());

            } else {
                LOGGER.info("UNDERDECK NO : "
                        + requestEvent.getDeckStartTierNo()
                        + ", Rotation No : " + requestEvent.getRotationID()
                        + " and Bay No : " + requestEvent.getBayNo());
                statement = con
                        .prepareStatement(Constants.GET_DPA_CONTIANERS_LIST_QUERY
                                + "<=" + requestEvent.getDeckStartTierNo());
                statement.setInt(1,
                        Integer.parseInt(requestEvent.getRotationID()));
                statement.setString(2, bayNo);
                robStatement = con
                        .prepareStatement(Constants.GET_ROB_CONTIANERS_LIST_QUERY
                                + "<= " + requestEvent.getDeckStartTierNo());
                robStatement.setInt(1,
                        Integer.parseInt(requestEvent.getRotationID()));
                robStatement.setString(2, requestEvent.getBayNo());
            }
            LOGGER.info("Querying DPA_LISTS for rotation: "
                    + requestEvent.getRotationID() + " with Bay No : "
                    + requestEvent.getBayNo() + " & vessel code : "
                    + vesselCode);
            dpaSet = statement.executeQuery();
            containersList = setContrListResult(dpaSet, containersList);

            LOGGER.info("Containers details fetched from DPA_LISTS for event ID : "
                    + requestEvent.getEventID()
                    + "  ContainerList--> "
                    + containersList);

            LOGGER.info("Querying ROB_LISTS for rotation : "
                    + requestEvent.getRotationID() + " with Bay No: "
                    + requestEvent.getBayNo() + " and vessel code : "
                    + vesselCode);
            robSet = robStatement.executeQuery();
            containersList = setContrListResult(robSet, containersList);

            LOGGER.info("Containers details fetched from ROB_LISTS for event ID : "
                    + requestEvent.getEventID() + " -->" + containersList);
        } catch (SQLException e) {
            LOGGER.error(
                    "Exception occured while retrieving container details : ",
                    e);
        } finally {
            try {
                robSet.close();
                dpaSet.close();
                robStatement.close();
                statement.close();
                con.close();
            } catch (SQLException e) {
                LOGGER.error("Exception occured while closing connection : ", e);
            }
        }
        return containersList;
    }

    private java.util.List<BayProfileContainer> setContrListResult(
            ResultSet contrListSet,
            List<BayProfileContainer> containersList)
            throws SQLException {       
        
        while (contrListSet.next()) {
            Container container = new Container();
            BayProfileContainer profileContainer = new BayProfileContainer();
            
            String containerId = contrListSet.getString("containerId");
            String pod = contrListSet.getString("pod");
            String isoCode = contrListSet.getString("isoCode");
            String category = contrListSet.getString("category");
            String weight = ((Double) contrListSet.getDouble("weight"))
                    .toString();

            /* UN_NO represents IMDG Code for hazardous containers */
            Integer unNo = contrListSet.getInt("unNo");
            Integer unNo2 = contrListSet.getInt("unNo2");
            Integer unNo3 = contrListSet.getInt("unNo3");

            String hazardousCode = getHazardousCode(unNo, unNo2, unNo3);
            boolean isHazardous = null != hazardousCode ? true : false;

            String containerEmpty = contrListSet.getString("containerEmpty");
            Boolean isEmpty = null != containerEmpty
                    && "E".equalsIgnoreCase(containerEmpty) ? true : false;

            String oog = contrListSet.getString("oog");
            Boolean isOOg = oog == null || "N".equalsIgnoreCase(oog) ? false
                    : true;

            String stowage = contrListSet.getString("stowage");

            String reefer = contrListSet.getString("reefer");
            Boolean isRefer = null == reefer || "N".equalsIgnoreCase(reefer) ? false
                    : true;
            Boolean isDamaaged = contrListSet.getString("damaged") == null ? false
                    : true;
            Integer size = contrListSet.getInt("containerSize");
            if(null== size){
                size = "2".equalsIgnoreCase(isoCode.substring(0,1))? 20:40;
            }
            String moveType = contrListSet.getString("moveType");
            if (null != moveType && "D".equalsIgnoreCase(moveType)) {
                moveType = "DSCH";
            } else {
                moveType = "LOAD";
            }
            container.setContainerID(containerId);
            container.setPod(pod);
            container.setIsoCode(isoCode);
            container.setCategory(category);
            container.setWeight(weight);
            container.setHazardousCode(hazardousCode);
            container.setHazardous(isHazardous);
            container.setEmpty(isEmpty);
            container.setOOG(isOOg);
            container.setReefer(isRefer);
            container.setDamaged(isDamaaged);
            container.setSize(size.toString());

            profileContainer.setStowagePosition(stowage);
            profileContainer.setMoveType(moveType);
            profileContainer.setContainer(container);

            containersList.add(profileContainer);
        }
        return containersList;
    }

    /**
     * Get IMDG code for a given container
     * 
     * @param unNo
     * @param unNo2
     * @param unNo3
     * @return
     */
    private String getHazardousCode(Integer unNo, Integer unNo2, Integer unNo3) {
        StringBuilder hazardousCodeBuilder = new StringBuilder();
        List<String> hazardousCodeList = new ArrayList<String>();
        String imdgCodes = null;
        try {

            if (unNo != null && unNo > 0) {
                hazardousCodeList.add(unNo.toString());
            }

            if (unNo2 != null && unNo2 > 0) {
                hazardousCodeList.add(unNo2.toString());
            }
            if (unNo3 != null && unNo3 > 0) {
                hazardousCodeList.add(unNo3.toString());
            }

            for (String imoCode : hazardousCodeList) {
                hazardousCodeBuilder.append(imoCode).append(
                        Constants.COMMA_DELIMITER);
            }

            if (hazardousCodeBuilder.length() > 0) {
                imdgCodes = hazardousCodeBuilder.substring(0,
                        hazardousCodeBuilder.length() - 1);
            }

        } catch (Exception e) {
            LOGGER.error("Exception while retriveing IMDG code: ", e);
        }
        return imdgCodes;
    }
}
