package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "zone")
public class Zone {

    private List list;

    @XmlElement(name = "list")
    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

}
