package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;

public class Pool {

    private String Name;

    public String getName() {
        return Name;
    }

    @XmlAttribute
    public void setName(String name) {
        Name = name;
    }

}
