package com.dpw.minapro.xmlrdt.util;

public enum LoginRole {
    HAT, TRK, CHE
}
