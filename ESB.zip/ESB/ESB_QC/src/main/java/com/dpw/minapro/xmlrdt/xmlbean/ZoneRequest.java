package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "zoneRequest")
public class ZoneRequest {

    private String CHID;
    private String type;
    private String action;
    private Zone zone;

    @XmlElement(name = "zone")
    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    @XmlAttribute(name = "CHID")
    public String getCHID() {
        return CHID;
    }

    public void setCHID(String cHID) {
        CHID = cHID;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlAttribute(name = "action")
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

}
