package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "message")
public class Message {

    private String MSID;
    private String type;
    private Che che;
    private Request request;
    private String ack;
    private Container[] containers;
    private Container container;

    @XmlElement(name = "container")
    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    @XmlElement(name = "container")
    public Container[] getContainers() {
        return containers;
    }

    public void setContainers(Container[] containers) {
        this.containers = containers;
    }

    @XmlAttribute(name = "ack")
    public String getAck() {
        return ack;
    }

    public void setAck(String ack) {
        this.ack = ack;
    }

    public Request getRequest() {
        return request;
    }

    @XmlElement
    public void setRequest(Request request) {
        this.request = request;
    }

    public String getMSID() {
        return MSID;
    }

    @XmlAttribute(name = "MSID")
    public void setMSID(String mSID) {
        MSID = mSID;
    }

    public String getType() {
        return type;
    }

    @XmlAttribute
    public void setType(String type) {
        this.type = type;
    }

    public Che getChe() {
        return che;
    }

    @XmlElement
    public void setChe(Che che) {
        this.che = che;
    }

}
