package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "position")
public class Position {

    private String refId;
    private String PPOS;
    private String CHID;
    private String type;
    private String ORPH;

    @XmlAttribute(name = "ORPH")
    public String getORPH() {
        return ORPH;
    }

    public void setORPH(String oRPH) {
        ORPH = oRPH;
    }

    @XmlAttribute(name = "PPOS")
    public String getPPOS() {
        return PPOS;
    }

    public void setPPOS(String pPOS) {
        PPOS = pPOS;
    }

    @XmlAttribute(name = "CHID")
    public String getCHID() {
        return CHID;
    }

    public void setCHID(String cHID) {
        CHID = cHID;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRefId() {
        return refId;
    }

    @XmlAttribute(name = "refID")
    public void setRefId(String refId) {
        this.refId = refId;
    }

}
