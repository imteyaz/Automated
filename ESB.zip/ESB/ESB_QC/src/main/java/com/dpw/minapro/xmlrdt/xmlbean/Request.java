package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlElement;

public class Request {
    private WorkRequest workRequest;
    private CheRequest cheRequest;
    private PowRequest powRequest;
    private ZoneRequest zoneRequest;
    private PoolRequest poolRequest;

    @XmlElement(name = "zoneRequest")
    public ZoneRequest getZoneRequest() {
        return zoneRequest;
    }

    @XmlElement(name = "poolRequest")
    public PoolRequest getPoolRequest() {
        return poolRequest;
    }

    public void setPoolRequest(PoolRequest poolRequest) {
        this.poolRequest = poolRequest;
    }

    public void setZoneRequest(ZoneRequest zoneRequest) {
        this.zoneRequest = zoneRequest;
    }

    public WorkRequest getWorkRequest() {
        return workRequest;
    }

    @XmlElement
    public void setWorkRequest(WorkRequest workRequest) {
        this.workRequest = workRequest;
    }

    public CheRequest getCheRequest() {
        return cheRequest;
    }

    @XmlElement
    public void setCheRequest(CheRequest cheRequest) {
        this.cheRequest = cheRequest;
    }

    public PowRequest getPowRequest() {
        return powRequest;
    }

    @XmlElement
    public void setPowRequest(PowRequest powRequest) {
        this.powRequest = powRequest;
    }

}
