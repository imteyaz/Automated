package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;

public class WorkRequest {
    private String CHID;
    private String type;
    private String max;

    @XmlAttribute(name = "max")
    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getCHID() {
        return CHID;
    }

    @XmlAttribute(name = "CHID")
    public void setCHID(String cHID) {
        CHID = cHID;
    }

    public String getType() {
        return type;
    }

    @XmlAttribute(name = "type")
    public void setType(String type) {
        this.type = type;
    }

}
