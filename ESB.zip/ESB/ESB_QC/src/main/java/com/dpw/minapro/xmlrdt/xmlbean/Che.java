package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Che {

    private String CHID;
    private User user;
    private JobList joblist;
    private Job job;
    private String SPOS;
    private String Action;
    private Container container;
    private Pds pds;

    @XmlElement(name = "pds")
    public Pds getPds() {
        return pds;
    }

    public void setPds(Pds pds) {
        this.pds = pds;
    }

    public Container getContainer() {
        return container;
    }

    @XmlElement(name = "container")
    public void setContainer(Container container) {
        this.container = container;
    }

    public String getAction() {
        return Action;
    }

    @XmlAttribute(name = "action")
    public void setAction(String action) {
        Action = action;
    }

    public Job getJob() {
        return job;
    }

    @XmlElement
    public void setJob(Job job) {
        this.job = job;
    }

    public JobList getJoblist() {
        return joblist;
    }

    @XmlElement
    public void setJoblist(JobList joblist) {
        this.joblist = joblist;
    }

    public String getCHID() {
        return CHID;
    }

    @XmlAttribute(name = "CHID")
    public void setCHID(String cHEID) {
        CHID = cHEID;
    }

    public User getUser() {
        return user;
    }

    @XmlElement
    public void setUser(User user) {
        this.user = user;
    }

    public String getSPOS() {
        return SPOS;
    }

    @XmlAttribute(name = "SPOS")
    public void setSPOS(String sPOS) {
        SPOS = sPOS;
    }

}
