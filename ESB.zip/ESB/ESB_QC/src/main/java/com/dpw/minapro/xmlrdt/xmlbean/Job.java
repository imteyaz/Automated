package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Job {
    private String MVKD;
    private java.util.List<Container> container;
    private Che che;

    @XmlElement(name = "container")
    public java.util.List<Container> getContainer() {
        return container;
    }

    public void setContainer(java.util.List<Container> container) {
        this.container = container;
    }

    public Che getChe() {
        return che;
    }

    @XmlElement
    public void setChe(Che che) {
        this.che = che;
    }

    public String getMVKD() {
        return MVKD;
    }

    @XmlAttribute(name = "MVKD")
    public void setMVKD(String mVKD) {
        MVKD = mVKD;
    }
}
