package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "pds")
public class Pds {

    private String type;
    private String PPOS;
    private String QWGT;
    private String SGNL;
    private Position position;

    @XmlElement(name = "position")
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    @XmlAttribute(name = "QWGT")
    public String getQWGT() {
        return QWGT;
    }

    public void setQWGT(String qWGT) {
        QWGT = qWGT;
    }

    @XmlAttribute(name = "SGNL")
    public String getSGNL() {
        return SGNL;
    }

    public void setSGNL(String sGNL) {
        SGNL = sGNL;
    }

    public String getType() {
        return type;
    }

    @XmlAttribute(name = "type")
    public void setType(String type) {
        this.type = type;
    }

    public String getPPOS() {
        return PPOS;
    }

    @XmlAttribute(name = "PPOS")
    public void setPPOS(String pPOS) {
        PPOS = pPOS;
    }

}
