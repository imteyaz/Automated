package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;

public class PowRequest {
    private String type;

    public String getType() {
        return type;
    }

    @XmlAttribute
    public void setType(String type) {
        this.type = type;
    }

}
