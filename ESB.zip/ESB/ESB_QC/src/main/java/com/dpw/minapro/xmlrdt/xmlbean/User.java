package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class User {

    private String LOGN;
    private String PGRM;
    private String AVAL;
    private Pool pool;
    private String POW;
    private String VESSEL;
    private String PSWD;

    @XmlAttribute(name = "PSWD")
    public String getPSWD() {
        return PSWD;
    }

    public void setPSWD(String pSWD) {
        PSWD = pSWD;
    }

    public String getPOW() {
        return POW;
    }

    @XmlAttribute(name = "POW")
    public void setPOW(String pOW) {
        POW = pOW;
    }

    public String getVESSEL() {
        return VESSEL;
    }

    @XmlAttribute(name = "VESSEL")
    public void setVESSEL(String vESSEL) {
        VESSEL = vESSEL;
    }

    public String getLOGN() {
        return LOGN;
    }

    @XmlAttribute(name = "LOGN")
    public void setLOGN(String lOGN) {
        LOGN = lOGN;
    }

    public String getPGRM() {
        return PGRM;
    }

    @XmlAttribute(name = "PGRM")
    public void setPGRM(String pGRM) {
        PGRM = pGRM;
    }

    public String getAVAL() {
        return AVAL;
    }

    @XmlAttribute(name = "AVAL")
    public void setAVAL(String aVAL) {
        AVAL = aVAL;
    }

    public Pool getPool() {
        return pool;
    }

    @XmlElement(name = "pool")
    public void setPool(Pool pool) {
        this.pool = pool;
    }

}
