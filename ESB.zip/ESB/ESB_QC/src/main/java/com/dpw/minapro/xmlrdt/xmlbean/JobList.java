package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class JobList {
    private String firstID;
    private String sortType;
    private String scroll;
    private Pds pds;

    public Pds getPds() {
        return pds;
    }

    @XmlElement(name = "pds")
    public void setPds(Pds pds) {
        this.pds = pds;
    }

    public String getFirstID() {
        return firstID;
    }

    @XmlAttribute
    public void setFirstID(String firstID) {
        this.firstID = firstID;
    }

    public String getSortType() {
        return sortType;
    }

    @XmlAttribute
    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public String getScroll() {
        return scroll;
    }

    @XmlAttribute
    public void setScroll(String scroll) {
        this.scroll = scroll;
    }

}
