package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Container {
    private String EQID;
    private String EQTP;
    private String TEMP;
    private String IMOC;
    private String STAT;
    private String JPOS;
    private Position position;

    private Attribute attribute;

    public String getJPOS() {
        return JPOS;
    }

    @XmlAttribute(name = "JPOS")
    public void setJPOS(String jPOS) {
        JPOS = jPOS;
    }

    public Position getPosition() {
        return position;
    }

    @XmlElement(name = "position")
    public void setPosition(Position position) {
        this.position = position;
    }

    public Attribute getAttribute() {
        return attribute;
    }

    @XmlElement
    public void setAttribute(Attribute attribute) {
        this.attribute = attribute;
    }

    public String getEQTP() {
        return EQTP;
    }

    @XmlAttribute(name = "EQTP")
    public void setEQTP(String eQTP) {
        EQTP = eQTP;
    }

    public String getTEMP() {
        return TEMP;
    }

    @XmlAttribute(name = "TEMP")
    public void setTEMP(String tEMP) {
        TEMP = tEMP;
    }

    public String getIMOC() {
        return IMOC;
    }

    @XmlAttribute(name = "IMOC")
    public void setIMOC(String iMOC) {
        IMOC = iMOC;
    }

    public String getSTAT() {
        return STAT;
    }

    @XmlAttribute(name = "STAT")
    public void setSTAT(String sTAT) {
        STAT = sTAT;
    }

    public String getEQID() {
        return EQID;
    }

    @XmlAttribute(name = "EQID")
    public void setEQID(String eQID) {
        EQID = eQID;
    }
}
