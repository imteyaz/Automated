package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;

public class Attribute {
    private String name;
    private String value;

    public String getName() {
        return name;
    }

    @XmlAttribute
    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    @XmlAttribute
    public void setValue(String value) {
        this.value = value;
    }

}
