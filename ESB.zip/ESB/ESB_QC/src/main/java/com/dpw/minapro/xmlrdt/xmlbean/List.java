package com.dpw.minapro.xmlrdt.xmlbean;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "list")
public class List {

    private int count;
    private String type;
    private Range[] range;

    @XmlAttribute(name = "count")
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @XmlElement(name = "range")
    public Range[] getRange() {
        return range;
    }

    public void setRange(Range[] range) {
        this.range = range;
    }

}
