//@author Umamahesh M
//@Date: 10-03-2015
//Drawing Bay TopView Left and Right
var isFirstBay = false;
function buildTopView(bayData) {
	var cellDetails = bayData.data;//if(cellDetails.length == 0)return; // if ServerMsg is empty and array will be empty. Draw nothing.
	var rowHeaders = bayData.rowHeaders;
	var colHeaders = bayData.colHeaders;
	var bayNo = bayData.bayNo;
	var number = bayData.bayType;
	var currentTile = { };
	var className;
	var cellBaseColor = "#ffffff";
	var i;

	if (number == 1) {

		if (cellDetails.length == 0) {
			bayNo = "";
		}
		$("#firstBay_no").text(bayNo);
		$("#firstBay").text(bayNo);

		if (isFirstBay == true) {
			if ((($("#firstBay").text())*1) > 0) {
			} else {
				if ((($("#secondBay").text())*1) > 0) {
					$("#secondBay_no").text($("#secondBay").text());
					$("#secondBay").text($("#secondBay").text());
					$(".to_bay_wrapper").css('display', 'none');
				}
			}
		}

		isFirstBay = true;
	} else if (number == 2) {

		if (cellDetails.length == 0) {
			bayNo = "";
		}
		if ((($("#firstBay").text())*1) > 0 || isFirstBay == false) {
			$(".bay_title_wrapper").css('display', 'block');
			$(".no_bay_message").css('display', 'none');
			if (bayNo != "") {
				$(".to_bay_wrapper").css('display', 'inline');
			} else {
				$(".to_bay_wrapper").css('display', 'none');
			}
			$("#secondBay_no").text(bayNo);
			$("#secondBay").text(bayNo);
		} else {
			if (((bayNo)*1) > 0) {
				$(".bay_title_wrapper").css('display', 'block');
				$(".no_bay_message").css('display', 'none');
				$(".to_bay_wrapper").css('display', 'none');
				$("#firstBay_no").text(bayNo);
				$("#firstBay").text(bayNo);
			} else {
				$(".bay_title_wrapper").css('display', 'none');
				$(".no_bay_message").css('display', 'block');
			}
		}

		isFirstBay = true;

	} else {
		$(".bay_title_wrapper").css('display', 'none');
		$(".no_bay_message").css('display', 'block');
	}

	if (cellDetails.length == 0) {
		$("#topview_" + number).html("<p style='margin-top:45%;font-size:100%;'>There Is No Bay View To Display</p>");
		return;
	}
	$("#topview_" + number).empty();
	$("#topview" + number).css("margin-top", function() {
			return 400 / cellDetails[0].length
		});

	for (i = 0; i < cellDetails[0].length; i++) {
		$("#topview_" + number).append("<div style='float:left;margin:4px 0px 0px 4px;' id='topviewrow-" + number + i + "'></div>");
		if (cellDetails[0][i].cntrNo) {
			var type = '';
			className = "tile";
			if (cellDetails[0][i].reefer == "true" && cellDetails[0][i].colourCode != "+") {
				type += '<img src="/public/images/reefer.png" style="position:absolute;bottom:0px;top:45%;left:20%;" />';
			}
			if (cellDetails[0][i].hazardous == "true" && cellDetails[0][i].colourCode != "+") {
				type += '<img src="/public/images/hazardous.png" style="position:absolute;bottom:0px;left:50%;top:45%;" />';
			}
		
			if (cellDetails[0][i].OOG == "true"  && cellDetails[0][i].colourCode != "+") {
				type += '<div style="bottom:0;font-size:7px;font-weight:bold;position:absolute;left:35%;top:10%;">O</div>';
			}
			if (cellDetails[0][i].damage == "true" && cellDetails[0][i].colourCode != "+") {
				type += '<div style="bottom:0;font-size:7px;font-weight:bold;position:absolute;left:65%;">D</div>';
			}
			if (cellDetails[0][i].colourCode) {
				cellColor = cellDetails[0][i].colourCode;
				if (cellColor == "+" && number == 2) {
					type += '<img src="/public/images/bay_view_plus.png" alt="plus"  style="vertical-align:top;" class="40_cntr"/>'
				}

			} 
			else {
				cellColor = "#00ffff";
			}
			var cellData = "";
			for (var y = 0; y < cellAttr.length; y++) {
				var code = cellAttr[y];
				cellData += code + "='" + (cellDetails[0][i])[code] + "' ";
			}
			$("#topviewrow-" + number + i).append('<div ' + cellData + ' cellId="' + bayNo + '.' + colHeaders[i] + '.' + rowHeaders[0] + '"class="' + className + '" style="width:70px;height:22px;background-color:' + cellColor + ';position:relative;"><div style="margin-left: -20px;float:left;" class="col_hdr">' + colHeaders[i] + '</div>' + type + ' </div>');

		}
		
		else {
			var k;
			var count = 0;
			var cellData = "";
			var type = '';
			for (var j = 0; j < rowHeaders.length; j++) {
				if (cellDetails[j][i].cntrNo != "") {
					k = j;
					className = "tile";
					count++;
					if (cellDetails[j][i].reefer == "true" && cellDetails[j][i].colourCode != "+" ) {
						type += '<img src="/public/images/reefer.png" style="bottom:0;position:absolute;top:45%;left:20%;"/>';
					}
					if (cellDetails[j][i].hazardous == "true" && cellDetails[j][i].colourCode != "+") {
						type += '<img src="/public/images/hazardous.png" style="bottom:0;position:absolute;left:50%;top:45%;"/>';
					}
					
					if (cellDetails[j][i].OOG == "true" && cellDetails[j][i].colourCode != "+") {
						type += '<div style="bottom:0;font-size:7px;font-weight:bold;position:absolute;left:35%;top:10%;">O</div>';
					}
					if (cellDetails[j][i].damage == "true" && cellDetails[j][i].colourCode != "+") {
						type += '<div style="bottom:0;font-size:7px;font-weight:bold;position:absolute;left:65%;">D</div>';
					}
					if (cellDetails[j][i].colourCode) {
						cellColor = cellDetails[j][i].colourCode;
						if (cellColor == "+" && number == 2) {
							type += '<img src="/public/images/bay_view_plus.png" alt="plus"  style="vertical-align:top;" class="40_cntr"/>'
						}

					} else {
						cellColor = "#00ffff";
					}
					for (var y = 0; y < cellAttr.length; y++) {
						var code = cellAttr[y];
						cellData += code + "='" + (cellDetails[j][i])[code] + "' ";
					}
					break;
				}
				else{
					cellColor = "#ffffff"
				}

			}
			if (count == 0) {
				var defaultrowHeaderVal = -80;
				cellColor = "#ffffff";
				className = "tile";
				for (var y = 0; y < cellAttr.length; y++) {
					var code = cellAttr[y];
					cellData += code + "=''";
				}
				var tile_exists = false;
				for (var j = 0; j < rowHeaders.length; j++) {
					if (cellDetails[j][i].cellStatus == 0 && cellDetails[j][i].cntrNo == "") {
						className = "no-cell"
					} else {
						className = "tile";
						tile_exists = true
					}
				}
				if (tile_exists == true) {
					className = "tile"
				} else {
					className = "no-cell"
				}
				$("#topviewrow-" + number + i).append('<div ' + cellData + ' cellId="' + bayNo + '.' + colHeaders[i] + '.' + defaultrowHeaderVal + '"class="' + className + '" style="width:70px;height:22px;background-color:' + cellColor + ';position:relative"><div style="margin-left: -20px;float:left;" class="col_hdr">' + colHeaders[i] + '</div></div>');

			} else {

				$("#topviewrow-" + number + i).append('<div ' + cellData + ' cellId="' + bayNo + '.' + colHeaders[i] + '.' + rowHeaders[k] + '"class="' + className + '" style="width:70px;height:22px;background-color:' + cellColor + ';position:relative;color:black;"><div style="margin-left: -20px;float:left;" class="col_hdr">' + colHeaders[i] + '</div>' + type + '</div>');
			}
		}

	}

	$("#topview_2 .40_cntr").parents("div").css("background-color", "#fff")
	$("#topview_2 .40_cntr").parents(".tile").css("background-color", "#fff");
	$(".tile").css("text-align", "center")
	$("#topview_2 .tile .col_hdr").css("float", "right").css("margin-right", "-20px")
	$("#topview_2 .no-cell .col_hdr").css("float", "right").css("margin-right", "-20px")
	
}
