//@author Prasad.Tallapally
//@Date: 10-03-2015
//Drawing Bayview Left and Right Front View
var first_bay_no = 0
var sencond_bay_no = 0
var check_bay_no = 0
var buildBayview = function(bayData) {
	var array = bayData.data;//if(array.length == 0)return; // if ServerMsg is empty and array will be empty. Draw nothing.
	var rowHeaders = bayData.rowHeaders;
	var colHeaders = bayData.colHeaders;
	console.log("colHeaders.length "+colHeaders.length)
	console.log("rowHeaders.length "+rowHeaders.length)
	var bayNo = bayData.bayNo;
	var bayType = bayData.bayType;
	var bayviewId = "#bayview_" + bayNo;
	var currentTile = { };
	var width = parseInt(100 / (colHeaders.length + 1));
	var height = parseInt(180 / (rowHeaders.length + 1));
	width = width - 0.1;
	console.log("Width" +width)
	console.log("Height" +height)
	/*if (width > height) {
		width = height;
	} else {
		height = width;
	}*/
	if (check_bay_no == 0) {
		first_bay_no = bayData.bayNo
		sencond_bay_no = 0
		check_bay_no += 1
	} else {
		sencond_bay_no = bayData.bayNo
		check_bay_no = 0
	}
	var cellColor;
	var cellDime = "width: " + width + "%;height:" + height + "px";
	console.log("cell dimension is "+cellDime)
	var firstCellDime = cellDime;
	var parentDiv = "<div id=bayview_" + bayNo + "></div>";
	if (array.length == 0) {
		$("#bay_img" + bayType).html("<p style='margin-top:30%;font-size:100%;'>There Is No Bay View To Display</p>");
		return;
	}
	$("#bay_img" + bayType).empty();
	$("#bay_img" + bayType).append(parentDiv);
	//  printing column headers
	var firstCellWidth = 24;
	if(width < 22){
		firstCellWidth = 24;
		firstCellDime = "width: " + firstCellWidth + "px;height:" + height + "%";
	}
	console.log("firstCellDime "+firstCellDime)
	console.log("sadsaddad")
	$(bayviewId).append("<div style='float:left;width:" + firstCellWidth + "px;height:"  + 15 + "px;' id='bayviewrow-header" + "'></div>");
	for (var j = 0; j < colHeaders.length; j++) {
		$(bayviewId).append("<div align='center' class='no-cell' style='float:left;width:" + width + "%;height:"  + 15 + "px;' id='bayviewrow-header" + j + "'>" + colHeaders[j] + "</div>");
	}
	$(bayviewId).append("<br>");
	for (var i = 0; i < array.length; i++) {
		$(bayviewId).append("<div style='float:left;width:100%;' id='bayviewrow2-" + bayNo + i + "'></div>");
		for (var j = 0; j < array[i].length; j++) {
			var type = '';
			if (array[i][j].cellStatus == 0) {
				var className = "no-cell";
				cellColor = "#ffffff";
			} else { // 1 is available
				className = "tile";

				if (array[i][j].cntrNo) {
					if (array[i][j].reefer == "true" && array[i][j].colourCode != "+") {
						type += '<img src="/public/images/reefer.png" style="bottom:0;position:absolute"/>';
					}

					if (array[i][j].hazardous == "true" && array[i][j].colourCode != "+") {
						type += '<img src="/public/images/hazardous.png" style="bottom:0;position:absolute;left:35%"/>';
					}

					if (array[i][j].OOG == "true" && array[i][j].colourCode != "+") {
						type += '<div style="bottom:0;font-size:7px;font-weight:bold;position:absolute;left:50%">O</div>';
					}

					if (array[i][j].colourCode) {
						cellColor = array[i][j].colourCode; // ColorCode from Server Message
						if (cellColor == "+" && bayType == 2) {
							type += '<img src="/public/images/bay_view_plus.png" alt="plus"  style="vertical-align:top; width:50%" class="40_cntr"/>'
						}
					}
					else{
						cellColor = "#00ffff"; 
					}
				} 
				else {
					cellColor = "#ffffff"; // white color, Empty Cell, Meaning Container is not available or already Discharged
				}
			}

			var cellData = ""; //Preparing cellData
			var genCellId = bayNo + '.' + colHeaders[j] + '.' + rowHeaders[i];
			(array[i][j]).cellId = genCellId;
			cellData += "cellId='" + genCellId + "' ";

			for (var x = 0; x < cellAttr.length; x++) {
				var code = cellAttr[x];
				cellData += code + "='" + (array[i][j])[code] + "' ";
			}

			if (j == 0 && i < rowHeaders.length) {
				$("#bayviewrow2-" + bayNo + i).append('<div align="center" class="tier_row_class" style="float: left;' + firstCellDime + ';">' + rowHeaders[i] + '</div>');
			}
			$("#bayviewrow2-" + bayNo + i).append('<div ' + cellData + '  class="' + className + '" style="' + cellDime + ';background-color:' + cellColor + ';position:relative">' + type + '</div>');

		}
		//$(bayviewId).append("<br>");
	}
	if (array.length > 15) {
		$(".no-cell").css("font-size", "9px");
		$(".tier_row_class").css("font-size", "9px");
	}

	$("#bay_img2 .40_cntr").parents(".tile").css("background-color", "#fff")
}

