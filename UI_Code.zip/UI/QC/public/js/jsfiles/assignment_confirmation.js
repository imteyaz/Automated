$(document).ready(function() {
	virtualKeyboard();
	var rotation_name="";
	rotation_name = $("#select_rotationId").find(':selected').data('name');
	if(rotation_name == null){
		rotation_name = $("#rotation_select").data('name');
	}
	$("#sel1").val("Operational");
	$("#sel1").msDropdown({ roundedBorder: false });
	//$("#sel2").msDropdown({ roundedBorder: false });
	$("#select_rotationId").msDropdown({ roundedBorder: false });

	$('select[value]').each(function() {
		$(this).val(this.getAttribute("value"));
	});

	hideSelectOptions();
	$('#sel1').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Non-Operational") {
			$('#sel2Container').removeClass('hidden');
			$("#sel2").msDropdown({ roundedBorder: false });
			$('#otherOptTextContainer').removeClass('hidden');
		} else {
			hideSelectOptions();
		}
	});

	$('#sel2').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Other") {
			$('#otherOptTextContainer').show();
			$('#otherOptTextContainer').removeClass('hidden');
		} else {
			$('#otherOptTextContainer').hide();
		}
	});
	$('#select_rotationId').change(function() {
		var selectedOption = $(this).val();
		$("#rotation_select")[0].value = selectedOption;
		rotation_name = $("#select_rotationId").find(':selected').data('name');
	});
	$('#rotation_select').change(function() {
		rotation_name = "";
	});
	function hideSelectOptions() {
		$('#sel2Container').addClass('hidden');
		$('#otherOptTextContainer').hide();
		$('#otherOptTextContainer').addClass('hidden');
	}

	function validateInputs() {
		if ($('#sel1').val() === "Non-Operational") {
			if ($('#sel2').val() === "" || $('#sel2').val() === null) {
				return false;
			} else if ($('#sel2').val() === "Other") {
				if ($("#otherOptText").val() === "" || $("#otherOptText").val() === null) {
					return false;
				}
			}
		}
		if ($('#rotation_select').val() === "" || $('#rotation_select').val() === null || $('#msg_equipmentId').val() === "" || $('#msg_equipmentId').val() === null || $('#msg_terminalId').val() == "" || $('#msg_terminalId').val() === null) {
			return false;
		}
		return true;
	}

	$('#confirm_allocation').on('click', function(e) {
			if (validateInputs()) {
				console.log("Allocation clicked");
				var allocation = $(".assign_confirmation :input").serialize();
				allocation = allocation+"&msg_rtname="+rotation_name;
				$('#confirm_allocation').attr("disabled", true).addClass("disable_btns");
				$('.login_exit').attr("disabled", true).addClass("disable_btns");

				$.ajax({
					type: "POST",
					url: "/app/Login/checklist",
					data: allocation,
					success: function(result) {
						if (result != 'Error') {
							console.log("Success");
							$(".main_content").html("");
							$(".main_content").html(result);
						} else {
							console.log("Failure");
							$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
							$('.login_exit').attr("disabled", false).removeClass("disable_btns");
						}
					}
					,
					error: function() {
						console.log("Total failure");
						$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
						$('.login_exit').attr("disabled", false).removeClass("disable_btns");
					}
				});
			} else {
				showAlerts("Please fill all fields");
			}
		})

}); 