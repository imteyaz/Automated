$(document).ready(function() {
	virtualKeyboard();
	//	To show dynamic labour management popup
	$('#dlm').click(function() {
		$.ajax({
			url: "/app/NonOperational/dynamic_labor_management",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});

	//	To Show technical support and pm schedular popup
	$('#tech_support').click(function() {
		$.ajax({
			url: "/app/NonOperational/technical_support",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});

	//To Show communication popup
	$('#communication').click(function(){
		$.ajax({
			url: "/app/NonOperational/message_voice_calls",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});
	
	
  $(".icon_traffic").on("click",function(){
		$.ajax({
			url: "/app/NonOperational/accident_incident",
			success: function(result) {
				if(result != "Error"){
					$('#light').html("")
					$('#light').html(result);
					document.getElementById('light').style.display = 'block';
				}
				else{
					showAlerts("Received invalid response");
					closePopup()
				}
			},
			error: function(result){
				closePopup()
			}
		});
	})
	
	$(".moves_to_gonumber").on("click",function(){
		$('.moves_to_gonumber').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			url: "/app/NonOperational/moves_to_go",
			success: function(result) {
				if(result != "No_data"){
				if(result != "Error"){
					$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns");
					$('#light').html("")
					$('#light').html(result);
					document.getElementById('light').style.display = 'block';
				}
				else{
					$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns");
					showAlerts("Received invalid response");
					closePopup()
				}
			  }else{
				  $('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns"); 
				  showAlerts("No data available");
					closePopup()
			  }
			},
			error: function(result){
				$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns");
				closePopup()
			}
		});
	});
	
});

var eqp_id = "";

function sendOpenDelayDetailsForQC(equipment_id) {
	if($( 'input[name="acc_continue"]:checked' ).val() == "No") {
	
		var selectedDelayCode = $("#rms_select").val();
		if (selectedDelayCode == "") {
			showAlerts("Please select a delay reason");
		} else {
			eqp_id = equipment_id;
			
			var selectedQCData = $("#qc_list_accident").val();
			selectedQCData = selectedQCData.split("^");
			
			if(selectedQCData[1] != "") {
				confirmYesOrNo(selectedQCData[1] + " delay exists. Do you want to close it?", send_accident_details)
			} else {
				send_accident_details("T");
			}
		}
	} else {
		send_accident_details("T");
	}
}

var send_accident_details = function(delayCloseInfo){
	$('.accident_confirmBtn').attr("disabled", true).addClass("disable_btns");
	var can_cont = "";
	var selectedDelayCode = $("#rms_select").val();
	var selectedQCData = $("#qc_list_accident").val();
	selectedQCData = selectedQCData.split("^");
	if(selectedQCData[0] == eqp_id){
		if($("input[name='acc_continue']:first").prop("checked") == true)
		{
			can_cont = 'true'	
		}
		else{
			can_cont = 'false'
		}
	}
	else{
		can_cont = "true"
	}
	$.ajax({
		url: "/app/NonOperational/send_accident_incident",
		data: {
			qc_id: selectedQCData[0],
			continue_work: can_cont,
			delayCloseInfo: delayCloseInfo,
			selectedDelayCode: selectedDelayCode
		},
		success: function(result) {
			if(result == "success"){
				$('.accident_confirmBtn').attr("disabled", false).removeClass("disable_btns");
				closePopup()
			}
			else{
				$('.accident_confirmBtn').attr("disabled", false).removeClass("disable_btns");
				showAlerts(result);
			}
		},
		error: function(result){
			$('.accident_confirmBtn').attr("disabled", false).removeClass("disable_btns");
			closePopup()
		}
	});
}

//To show technical support details popup
function techsupportdetailspopup(){
	$.ajax({
		url: "/app/NonOperational/technical_support_details",
		success: function(result) {
			$('#light').html("")
			$('#light').html(result);
			document.getElementById('light').style.display = 'block';
		},
		error: function(result) {
			$('#light').html("")
			$('#light').html(result);
			document.getElementById('light').style.display = 'none';
		}		
	});
}

//To send final technical support details to server
function sendtechdetails(){
	var location = $("#location").val();
	var problem_code = $("#problem_code").val();
	var problem_description = $("#problem_description").val();
	var location_description = $("#location_description").val();
	var asset_number = $("#asset_number").val();
   if(location == "" || problem_code == "" || problem_description == "" || location_description == "" || asset_number == ""){
	   showAlerts("Please fill all the values!");
   } else {
	$('#lateloginsubmit').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		url: "/app/NonOperational/send_technical_support_details",
		data: {
			location: location,	
			problem_code: problem_code,
			problem_description: problem_description,
			location_description: location_description,
			asset_number: asset_number
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			document.getElementById('light').style.display = 'none';
			$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
		}
	});
  }
}