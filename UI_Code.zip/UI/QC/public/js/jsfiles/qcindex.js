//@ sourceURL=qcindex.js
$('#progressbar').progressbar();
var m = 0;
var tempObj = { }
var manualmode = false;
var manualContainerHandling = false;
var myVar = setInterval(function() {
		//myTime()
	}, 1000);
var no_of_times = 0;
var qchome_time;
function myTimer() {
	$.ajax({
		type: "POST",
		url: "/app/Login/containercheck",
		success: function(result) {
			if (result != "")
				shufflejobs(result)
		}
	})
}

function  highLightITVWhenArrived(itvArrivedMsg)
{
	var referDetails = itvArrivedMsg.split('#');
	//$('#itvArrivedbuttonClickId').html("");
	
	$(".itv_no" + referDetails[0]).remove();
	var htmlContent="";
	htmlContent = "<a href='#' class='itv_no" + referDetails[0] + "'>";
	htmlContent = htmlContent + "<span class='updatepool_row_first' style='background-color: #" + referDetails[4] +"'>";
	htmlContent = htmlContent + "<div class='itv_truck_number'>" + referDetails[0] + "</div>";
	htmlContent = htmlContent + "<div class='truck_number'>" + referDetails[1] + "</div>";
	htmlContent = htmlContent + "<div class='truck_number'>" + referDetails[2] + "</div></span></a>";
	$('.contr_pool_row1').append(htmlContent);
	
	$(".updatepool_row_first").click(function(){
	  var itvNo = $(this).find(".itv_truck_number").text();
	  $("#itv_search").val("");
	  updateCntrITVNo(itvNo);
	});
}

function promoteSelectedJob(containerNo){
	var selectedJob = $('.container_handling_btn[container="' + containerNo + '"]');
	var container = $('#tabledataid');

	container.scrollTop(
		selectedJob.offset().top - container.offset().top + container.scrollTop()
	);
	selectedJob.click()
	$('#hdnPromotedContainer').val(containerNo);
	$(".qc_rows").removeClass("promoted_job");
	selectedJob.parent().parent().addClass("promoted_job");
	$(".qc_rows.clicked").addClass("promoted_job");
	
	var selectedContainers = "";
	
	$( ".promoted_job" ).each(function( index ) {
	  selectedContainers +=  $( this ).data('container') + "~";
	});
	
	if(selectedContainers != ""){
		selectedContainers = selectedContainers.slice(0, -1);
	}
	
	$.ajax({
		url: "/app/Qc/promoted_jobs",
		data: {
			containers: selectedContainers
		},
		success: function(result) {
			
		},
		error: function(err){
			Rho.Log.error("Error during promote job", "javascript");
		}
	});
	
	
}

function stoptimer() {
	//clearInterval(myVar)
}

function shufflejobs(messageresult) {
	var messagedetails = messageresult.split("~")
	var result = messagedetails[0]
	if (result == "HVY_HK_TRUE") {
		$("#hvy_hook").css("color", "red");
	} else if (result == "HVY_HK_FALSE") {
		$("#hvy_hook").css("color", "rgb(113, 115, 119)");
	} else if (result == "PLC_TRUE") {
		$("#plc_active_deactive").addClass("moves_plc_active");
	} else if (result == "PLC_FALSE") {
		$("#plc_active_deactive").removeClass("moves_plc_active");
	} else if (result == "PLC_JOB_DONE") {
		var value = $("#jobs_select").val();
		$('#search_joblist').val('')
		processjoblist(messagedetails[1], 0, 0, value, "plcjobdone")
		$("#qccontainer_handling").accordion("option", "active", 0);
		$(".bay_img div,.top_view div").removeClass("onclick");
		//$(".table_data_qc tr").removeClass('selevn clicked')
		console.log("JOB-- " + messagedetails[3])
		if (messagedetails[3] == 'DSCH')
			dischargeContainer(messagedetails[1], messagedetails[2])
		else {
			var previous = messagedetails[2];
			var contrArray = messagedetails[1].split('|');
			
			if(contrArray.length > 0) {
				for(var k = 0; k < contrArray.length; k++) {
					var confirmedCell = $('div.bay_img div[cntrno="'+contrArray[k].split("^")[1]+'"]');
					if(typeof confirmedCell.attr("cellid") !== "undefined") {
						if(k == 0)
							previous = confirmedCell.attr("cellid");
						else
							previous += "|" + confirmedCell.attr("cellid");
					} 
				}
			}
			
			loadContainer(messagedetails[1], messagedetails[2],previous);
		}
		resettimer("#job_timer");
	} else if (result == 'CANCEL_JOB')
		$("#qccontainer_handling").accordion("option", "active", 0);
	else if (result == "CONTAINER_HANDLING_TRUE") {
		$(".qc_rows").removeClass("selevn");
		console.log("ShuffleJobs")
		console.log(new Date());
		selected_cont = messagedetails[1].split('|')[0];
		$("#hiddenContainerName").val(selected_cont.split("^")[0]);
		manualContainerHandling = false;
		processcontainerhandling(selected_cont, 'false')
		$("#qcconainer_handling").accordion("refresh")
		$("#qccontainer_handling").accordion("option", "active", 1);
		var cellid_clk = []
		var tempList = []
		var cellIds = messagedetails[2].split("|")
		for (i = 0; i < cellIds.length; i++) {
			var $qcRows = $("#qc_table tr[cellid='" + cellIds[i] + "']")
			bayNo = $qcRows.attr('bayno');
			if (Number(bayNo) % 2 == 0) {
				tempList = $qcRows.attr("altrcellid").split('|')
				cellid_clk.push.apply(cellid_clk, tempList)
			} else {
				cellid_clk.push(cellIds[i])
			}
		}
		$(".bay_img div,.top_view div").removeClass("onclick");
		$(".table_data_qc tr").removeClass('selevn clicked')
		markBays(cellid_clk, 'onclick')
		makeRowActive();
		markJobs();
	} else if (result == "DELAY_RECORDING") {
		processdelayrecording(messagedetails[1])
	} else if (result == "NORMAL_ALERT_MESSAGE") {
		processnormalalertmessage(messagedetails[1], messagedetails[2]);
	} else if (result == "QC_PERFORMANCE_VIEW") {
		updateQCfields(messagedetails[1]);
	} else if (result == "BACKREACH_CONTAINER_MOVE") {
		backreachcontainermove(messagedetails[1]);
	} else if (result == "LANGUAGES") {
		language_sellection(messagedetails[1]);
	} else if (result == "REFRESH_JOBS") {
		var value = $("#jobs_select").val();
		$('#search_joblist').val('')
		processjoblist(0, 0, 0, value, 'filter')
		processbayviewrequest(-1, '#bay_img1', 'false')
	} else if (result == "UPDATE_BAY") {
		loadfutureContainer(messagedetails[1], messagedetails[2])
	} else
		processjoblist(0, 0, 0, result, "shuffle")
}

$(document).ready(function() {
	virtualKeyboard();
	$(".delayrecording_reasons").msDropdown({ roundedBorder: false });
	$("#jobs_select").msDropdown({ roundedBorder: false });
	$("#cntr_select").msDropdown({ roundedBorder: false });
	$('#fade').click(function() {
		$.ajax({
			url: "/app/Login/getunavlblereasons",
			data: {
				popupType: "unavilable"
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				$("select").addClass('combobox');
				$("select").attr('type', 'text');
				$(".combobox").combobox();
				setTimeout(virtualKeyboard, 500);
				document.getElementById('light').style.display = 'block';
				
				$(".delayrecording_page .ui-button-icon").click(function(){
					$(".ui-autocomplete").css("width", $(".delayrecording_page .ui-autocomplete-input").width() + 20 + 'px')
				})
				
				
				//$("#rms_select").msDropdown({ roundedBorder: false });
				//document.getElementById('light').style.display = 'block';
			}
		});
	});

	$('.user-toggle').click(function(event) {
		event.stopPropagation();
		$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
		$('.user-toggle').css("border", "0px");
		$('#collapse_profile').show(500); 
	});
	$(document).click(function() {
		$('.user_profile,.user-toggle').css("background-color", "");
		$('.user-toggle').css("border", "none");
		$('#collapse_profile').hide(500); 
	});

	job_timer("#job_timer");
	processjoblist(0, 0, '', 'current_jobs', 'jobdone');
	$("#qccontainer_handling").accordion({
		autoHeight: false
	});
	processbayviewrequest(-1, '#bay_img1', 'false')
	p = parseInt($('#completedMoves').html());

	//search method
	$.extend($.expr[":"], {
			"containsIN": function(elem, i, match, array) {
				return (elem.textContent || elem.innerText || "").toLowerCase().indexOf( (match[3] || "").toLowerCase()) >= 0;
			}
		});

	$("#search_joblist").change(function() {
		var value = $('#search_joblist').val();
		if (value.length == 0)
			$('#qc_table tr').show()
		else {
			$("#qc_table tr:not('#qc_table .tableheader')").hide();
			$("#qc_table td.joblist_searchItem:containsIN('" + value + "')").parents("#qc_table tr").show();
			
		}
	});
	$('#arrow_left').click(function() {
		processbayviewdata(true);
	});
	$('#arrow_right').click(function() {
		processbayviewdata(false);
	});
	$("#cntr_select").change(function() {
		var cntrType = $(this).val();
		if (cntrType == 'hazardous' || cntrType == 'reefer') { // On select hazardous/reefer primary bay should display grey color and secondary bay should display + symbol with white background in case of 40 ft containers.
			renderBayview();
			$('div.bay_image1 div[' + cntrType + '="false"][cntrno !=""]').css("background-color", "grey");
			$('div.bay_image2 div[' + cntrType + '="false"][cntrno !=""]').css("background-color", "grey");
			$('.bay_image2 .tile .40_cntr').parents(".tile").css("background-color","white");

			$('div.baytop_view1 div[' + cntrType + '="false"][cntrno !=""]').css("background-color", "grey");
			$('div.baytop_view2 div[' + cntrType + '="false"][cntrno !=""]').css("background-color", "grey");
			$('.baytop_view2 .tile .40_cntr').parents(".tile").css("background-color","white")

		} else if (cntrType == 'POD') {
			renderBayview();
		} else if (cntrType == 'future') { // @author Prasad.Tallapally
			if (jQuery.isEmptyObject(futureBayviewObj)) { //Requesting future if futureBayviewObj is empty
				requestAndBuildFutureBayview(); // Fetch Future Bayview Data from Server and Draw Future Bayview
			} else {
				renderFutureBayview(); // Draw only Future Bayview
			}

		} else {
			// To be implemented
		}
	});
});

function send_data(containers, celllocation, itvnos, movekind, baycelllocation,prev_locations, categoryInfo) {
	
	var value = $("#jobs_select").val();
	$('#search_joblist').val('')
	var bay_no = baycelllocation.split(".")[0]
	var in_first_bay = ($("#firstBay").html() * 1 <= bay_no * 1)
	var in_second_bay = ($("#secondBay").html() * 1 >= bay_no * 1)
	if (movekind == 'DSCH')
		processjoblist(containers, celllocation, itvnos, value, 'jobdone', categoryInfo);
	else
		processjoblist(containers, itvnos, celllocation, value, 'jobdone', categoryInfo);

	$("#qccontainer_handling").accordion("option", "active", 0);
	if ( in_first_bay && in_second_bay) {
		if (movekind == 'DSCH')
			dischargeContainer(containers, baycelllocation)
		else
			loadContainer(containers, baycelllocation,prev_locations)
	}

	$("#cntr_select").val("POD");
	$("#cntr_select").change();
	resettimer("#job_timer");
}

function processjoblist(container, from_location, to_location, contritv, reqtype, categoryInfo) {

	$.ajax({
		type: "POST",
		async: false,
		url: "/app/Login/joblist",
		data: {
			container_id: container,
			from_location: from_location,
			to_loc: to_location,
			containeritvinfo: contritv,
			reqtype: reqtype,
			categoryInfo: categoryInfo
		},
		success: function(result) {
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
			refreshContainer();
			if (reqtype == 'filter') {
				markJobs()
			}
		}//,
//		error: function() {
//			change_filter();
//		}
	})
	//return false
}


function change_filter(){
	$("#jobs_select").val("current_jobs");
	$(".qc_list #jobs_select_title").click();
	$("#jobs_select").click();
	$(".qc_list ul li").removeClass("selected");
	$(".qc_list ul li").eq(1).addClass("selected");
}

function addRemoveDamageIcon(addRemoveDamageIconMsg){
	addRemoveDamageIconMsg = addRemoveDamageIconMsg.split("#");
	if(addRemoveDamageIconMsg[1] == "true"){
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").addClass("damage");
	}else{
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").removeClass("damage");
	}
}

function processjobdone() {
	$.ajax({
		type: "POST",
		url: "/app/Qc/container_handling",
		success: function(result) {
			$("#container_handlediv").html("")
			$("#container_handlediv").html(result);
		}
	})
	return false
}

function HatchcoverMancageBreakbulk_Request(request_type,mode) {
	$('#nav-toggle1').css("background-color", "#0563a0");
	$("#jobs_select").val("current_jobs");
	$.ajax({
		type: "POST",
		url: "/app/Qc/HatchcoverMancageBreakbulk_Request",
		data: {
			request_type: request_type,
			mode: mode
		},
		success: function(result) {
			$('#tabledataid').html("")
			$('#tabledataid').html(result)

		}
	})
	change_filter();
	return false
}

function refreshContainer() {
	var cont = ""
	if(selected_cont != ""){
		cont = selected_cont;
	}
	else{
		cont = $(".qc_rows:first").attr('data-uniquejobid');
		$(".qc_rows:first").addClass("selevn");
		manualContainerHandling = true;
	}
	//var cont = contr.attr('data-container');
	console.log("selected_cont " + selected_cont);
	console.log("ShuffleJobs")
	console.log(new Date());
	processcontainerhandling(cont, 'true');
	
	makeRowActive();
}

function makeRowActive(){
    var $tableRows = $("#qc_table tr");
    var currentRow = "";
    
    if(selected_cont == ""){
    	currentRow = $(".qc_rows:first");
	}
	else{
		currentRow = $(".qc_rows[data-uniquejobid='" + selected_cont +"']");
	}
    
    var v = currentRow.data('refercontainer');
    if(v != null && typeof v != "undefined") {
	    var container = currentRow.data('uniquejobid');
	    var hdn_cntr_val = currentRow.data('container')
	    $("#hiddenContainerName").val(hdn_cntr_val);
	    $tableRows.removeClass("selevn");
	    $(".qc_rows").removeClass("selevn");
	    $("#qc_table tr[data-uniquejobid='" + container + "']").addClass("selevn")
	    v = v.split('#');
	    for (x = 0; x < v.length; x++)
	      $("#qc_table tr[data-container='" + v[x] + "']").addClass("selevn")
    }
  
  }


function processcontainerhandling(message, manualconfirm) {
	console.log("message in QC "+message)
	if(message != undefined){
	container = message.split(">")[0]
	exception_reason = message.split(">")[1]
	message = container.split('^');
		$.ajax({
			type: "POST",
			url: "/app/Qc/container_handling",
			data: {
				container: message[0],
				manual_confirm: manualconfirm,
				exception_reason: exception_reason,
				movekind: message[1]
			},
			success: function(result) {
				$("#container_handlediv").html("")
				$("#container_handlediv").html(result)
				if (manualContainerHandling == false) {
					$(".update_attr_check").hide()
					$(".icon_trouble_shoot").hide()
				} else {
					$(".update_attr_check").show()
					$(".icon_trouble_shoot").show()
				}
			  }
		})
		return false
	}
	else{
		$("#container_handlediv").html("<p style='margin: 20% 20% 20% 20%;font-weight:bold;'>There is no container to confirm</p>");
	}
}

function processdelayrecording(messagedetails) {
	$.ajax({
		type: "POST",
		url: "/app/Qc/delay_recording",
		data: {
			delayrecordingmessage: messagedetails
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			//$("#delayrecording_data").msDropdown({ roundedBorder: false });
			$("select").addClass('combobox');
			$("select").attr('type', 'text');
			$(".combobox").combobox();
			setTimeout(virtualKeyboard, 500);
			document.getElementById('light').style.display = 'block';
			
			$(".delayrecording_page .ui-button-icon").click(function(){
				$(".ui-autocomplete").css("width", $(".delayrecording_page .ui-autocomplete-input").width() + 20 + 'px')
			})
		}
	})
	return false
}

function delay_recording() {
	var selectedval = $("#delayrecording_data").find(":selected").val();
	if (selectedval == "") {
		showAlerts("Please select a reason!");
	} else {
		$('#lateloginsubmit').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			type: "POST",
			url: "/app/Qc/delayrecordingreason",
			data: {
				delayrecording_reason: selectedval
			},
			success: function(result) {
				delayCnfrmatn(result)
				$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
			}
		})
	}
	return false
}
function delayCnfrmatn(delayResp){
	var newDelay = delayResp.split("~")[3];
	if(newDelay == "true"){
		closePopup();
	}else{
		var delaycode = delayResp.split("~")[4];
		if(delaycode != ""){
			var delayCloseCnfrmatn = delaycode + " delay exists. Do you want to close it?"
			confirmDelay(delayCloseCnfrmatn, cnfrmResult);
		}else{
			closePopup();
		}
	}
}

var cnfrmResult = function(cnfrmResult){
	console.log("cnfrmResult" + cnfrmResult)
	var selectedDelayReason = $("#delayrecording_data").find(":selected").val();
	console.log("selectedDelayReason" + selectedDelayReason)
	$.ajax({
		type: "POST",
		url: "/app/Qc/recordNewDelay",
		data: {
			closeDelay: cnfrmResult,
			selectedDelayReason : selectedDelayReason
			
		},
		success: function(result) {
			closePopup();
			$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
		}
	})
}

function backreachcontainermove(messagedetails) {
	$.ajax({
		type: "POST",
		url: "/app/Qc/containerbackreachmove",
		data: {
			backreachcontainermessage: messagedetails
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			document.getElementById('light').style.display = 'block';
			$('#cntr_data').msDropdown({ roundedBorder: false });
			$('#cntr_data').change(function() {
				var selectedOption = $(this).val();
				$("#containernumber_data")[0].value = selectedOption;
			});
			$('#containernumber_data').change(function() {
				$("#cntr_data_child ul li ").each(function(){
					if($(this)[0].className == "enabled _msddli_ selected"){
						$(this)[0].className = "enabled _msddli_";
					}
				});
			});

		}
	})
}
var backreachjobs = [];
function backreachcontainer(type) {
	var containerno_data;
	if (type === "DSCH") {
		containerno_data = $("#containernumber_data").val();
	} else {
		containerno_data = $("#containernumber_data").val();
	}
	var fromlocation_data = $("#fromlocation_data").val();
	var tolocation_data = $("#tolocation_data").val();
	if (containerno_data == "" || fromlocation_data == "" || tolocation_data == "") {
		$("#backreach_error").text("Please fill all the details")
	} else {
		$('.backreach_confirm, .backreach_cancel').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			type: "POST",
			url: "/app/Qc/backreachcontainermove",
			data: {
				containernumber_data: containerno_data,
				fromlocation_data: fromlocation_data,
				tolocation_data: tolocation_data,
				type: type
			},
			success: function(result) {
				if (type == "DSCH") {
					backreachjobs.push(containerno_data);
				} else {
					backreachjobs.splice(backreachjobs.indexOf(containerno_data), 1);
				}
				$('#tabledataid').html("")
				$('#tabledataid').html(result)
				document.getElementById('light').style.display = 'none';
				$("#jobs_select").val("current_jobs");
				$('.backreach_confirm, .backreach_cancel').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.backreach_confirm, .backreach_cancel').attr("disabled", false).removeClass("disable_btns");
			}
		})
	}
	
	change_filter();
	return false
}

var allAlerts = [];

var alertCount = 0;

function processnormalalertmessage(messagedetails, expiryTime) {
 	var alerts = "";
    alerts = messagedetails;
	allAlerts.push(alerts);
	alertCount += 1;
	var i, FLDAlerts="";
	
	displayAllAlerts();
	setTimerForAlerts(expiryTime);
	console.log("FLDAlerts" +FLDAlerts)
	$(".qc_rows[data-container]").attr("exception_reason", messagedetails.split(":")[1])
}

function setTimerForAlerts(expiryTime) {
	(function(k) {
	       setTimeout(function(){
	    	   console.log("stopping alertCount " + k);
			   allAlerts[k - 1] = "";
			   displayAllAlerts();
	       }, expiryTime * 1000);
	 })(alertCount);
}

function displayAllAlerts() {
	var FLDAlerts="";
	for (i = 0; i < allAlerts.length ; i++) {
		if(allAlerts[i] != "") {
			FLDAlerts += allAlerts[i] + "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;";
		}
    }
	
    console.log("FLDAlerts" +FLDAlerts)
	$("#alerts").html("");
	$("#alerts").html(FLDAlerts)
}

function updateQCfields(messagedetails) {
	var qcviewattributes = messagedetails.split("|")
	$("#moves_to_go").text(qcviewattributes[3])
	$("#target_compl_time").text(qcviewattributes[2])
	$("#moves_behind").text(qcviewattributes[4])
	$("#target_moves").text(qcviewattributes[0])
	$("#grossmoves").text(qcviewattributes[1])
	var mph = Number(qcviewattributes[1]);
	$('#progressbar').progressbar('setPosition', mph);
}

function logout() {
	stoptimer();
	clearTimeout(qchome_time)
	$.ajax({
		url: "/app/Login/logout",
		success: function(result) {
			$(".main_content").html("");
			$(".main_content").html(result);
		}
	})
}
;

function deleteJobs(addContainerList) {
	var filterValue = $("#jobs_select").val();
	$('#search_joblist').val('')
	$.ajax({
		type: "POST",
		url: "/app/Qc/deleteJobs",
		data: {
			addContainerList: addContainerList,
			filterValue: filterValue
		},
		success: function(result) {
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
		}
	})
	return false
}


function mergeJobs(reqType, addContainerList, is_tandem,mkind) {
	var filterValue = $("#jobs_select").val();
	console.log("mkind"+mkind)
	$('#search_joblist').val('')
	$.ajax({
		type: "POST",
		url: "/app/Qc/mergeJobs",
		data: {
			addContainerList: addContainerList,
			reqType: reqType,
			filterValue: filterValue,
			is_tandem: is_tandem,
			movekind:mkind
		},
		success: function(result) {
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
			if(reqType == 'Split'){
				setTimeout(function(){
					var containerSelected = $("#hdnPromotedContainer").val();
					$.each(addContainerList, function( index, value ) {
					  if(value == containerSelected){
						  promoteSelectedJob(containerSelected);
					  }
					});
				}, 50);
			}
		}
	})
	return false
}
function pad(d) {
	return (d < 10) ? '0' + d.toString() : d.toString();
}
function markJobs() {
	var x = $(".bay_img").find('.onclick')
	var cellid;
	for (i = 0; i < x.length; i++) {
		cellid = $(x[i]).attr("cellid")
		$("#qc_table tr[cellid='" + cellid + "'],#qc_table tr[altrcellid *='" + cellid + "']").addClass("qc_rows selevn clicked")
	}
}
function job_timer(timerid) {
	$(timerid).runner({
		autostart: true,
		milliseconds: false
	});
}
function resettimer(timerid) {
	$(timerid).runner('reset');
}


function sendOpenDelayDetails() {
	if($("#hdnDelayCodeData").html() != "") {
		confirmYesOrNo($("#hdnDelayCodeData").html() + " delay exists. Do you want to close it?", sendUnavailableRes)
	} else {
		sendUnavailableRes("T");
	}
}

var sendUnavailableRes = function(delayCloseInfo) {
	var rmsdata = $("#rms_select").val()
	if (rmsdata == "") {
		showAlerts("Please Select One");
	} else {
		$('.unavilablereason').attr("disabled", true).addClass("disable_btns");
		$("#hdnSelectedDelay").val(rmsdata);
		$.ajax({
			url: "/app/Login/sendUnavailableRes",
			data: {
				popupType: "avilable",
				rms_select: rmsdata,
				delayCloseInfo: delayCloseInfo
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				$("#rms_timer").runner({
					autostart: true,
					milliseconds: false
				});
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			}
		});
	}
}
function sendAvailableRes() {
	var timerVal = $("#rms_timer").text();
	closePopup()
	$('.avilablereason').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Login/sendAvailableRes",
		data: {
			available_time: timerVal,
			selectedDelay: $("#hdnSelectedDelay").val()
		},
		success: function(result) {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		}
	});
}
function closePopup() {
	$('#light').html("")
	document.getElementById('light').style.display = 'none';
}

function showVideo(videoUrl) {
	swal({
		width: '680',
		height: '430',
		html: '<video width="550" height="410" controls>' + '<source src="' + videoUrl + '" type="video/mp4">' + '<source src="' + videoUrl + '" type="video/wmv"></video>',
		showCancelButton: true,
		allowOutsideClick: false
	})
}

function stopstartplc() {
	manualmode = !manualmode
	$.ajax({
		type: "POST",
		url: "/app/Qc/stop_start_plc",
		data: {
			manual_mode: manualmode
		},
		success: function(result) {
			if (manualmode) {
				$(".icon_manual").css("display", "none");
				$(".icon_auto").css("display", "block");
			} else {
				$(".icon_manual").css("display", "block");
				$(".icon_auto").css("display", "none");
			}
		}
	});
}

function joblist_refresh() {

	$('.refresh_joblist').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Qc/joblist_refresh",
		success: function(result) {
			if (result != "Error") {
				$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
			} else {
				$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
			}
		},
		error: function() {
			$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
		}
	});
}

function getLanguagesList() {
	$.ajax({
		type: "POST",
		url: "/app/Qc/getLanguagesList",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html("")
				$('#light').html(result)
				$("#language").msDropdown({ roundedBorder: false });
				document.getElementById('light').style.display = 'block';
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
	return false
}

function setLanguage() {
	var selectedlang = $("#language").val();
	$.ajax({
		type: "POST",
		url: "/app/Qc/setLanguage",
		data: {
			selectedlang: selectedlang
		},
		success: function(result) {
			closePopup();
			if (result != 'Error') {
				$(".main_content").html("");
				$(".main_content").html(result);
			}
		},
		complete: function() {
			closePopup();
		}
	})
	return false
}

function set_top_view(){
	var first_bay_length = $("#topview_1 .tile").length;
	var second_bay_length = $("#topview_2 .tile").length;
	if (second_bay_length > first_bay_length) {
		$("#topview_2 .tile").each(function() {
			if ($("#topview_1 .tile:first .col_hdr").html() != $(this).children(".col_hdr").html()) {
				$("#topview_1").prepend("<div style='float:left;margin:4px 0px 0px 4px;width:70px;height:22px;'><div class='no-cell'><div class='col_hdr' style='display:none;'>" + $(this).children(".col_hdr").html() + "</div></div></div>")
			} else {
				return false;
			}
		})
	} else if (second_bay_length < first_bay_length) {
		$("#topview_1 .tile").each(function() {
			if ($("#topview_2 .tile:first .col_hdr").html() != $(this).children(".col_hdr").html()) {
				$("#topview_2").prepend("<div style='float:left;margin:4px 0px 0px 4px;width:70px;height:22px;'><div class='no-cell'><div class='col_hdr' style='display:none;'>" + $(this).children(".col_hdr").html() + "</div></div></div>")
			} else {
				return false;
			}
		})
	}
	
}

function set_forty_feet_contr(){
	
	$("#bay_img2 .tile").each(function() {
		var tile_item = $(this)
		var cnt_no = tile_item.attr("cntrno")
		var bay_view_cell = $("#bay_img1 div[cntrno = '" + cnt_no + "']")
		if (bay_view_cell.length == 1) {
			if (tile_item.children(".40_cntr").length == 0) {
				tile_item.append('<img src="/public/images/bay_view_plus.png" alt="plus"  style="vertical-align:top;" class="40_cntr"/>')
				tile_item.css("background-color", "#fff")
			}
		}
	})
		
	$("#topview_2 .tile").each(function() {
		var tile_item = $(this)
		var cnt_no = tile_item.attr("cntrno")
		var bay_view_cell = $("#bay_img2 div[cntrno = '" + cnt_no + "']")
		if (bay_view_cell.children('.40_cntr').length == 1) {
			if (tile_item.children(".40_cntr").length == 0) {
				tile_item.append('<img src="/public/images/bay_view_plus.png" alt="plus"  style="padding:0px 10px 3px;margin-top:-2px;" class="40_cntr"/>')
				tile_item.css("background-color", "#fff")
			}
		}
	})
	
}

var renderBayview = function() {
	isFirstBay = false;
	$.each(bayviewObj, function(key, bayData) {
			buildBayview(bayData);
			buildTopView(bayData);
		});
	addCssListeners();
	setBayviewSwitchToggleVal();
	set_top_view();
}


