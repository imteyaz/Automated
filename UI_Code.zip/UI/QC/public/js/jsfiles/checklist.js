$(document).ready(function() {
	$("input[type='checkbox']").attr('checked', 'checked');
	
	
	function getCompletedJobs(){
		$.ajax({
			type: "POST",
			url: "/app/Qc/getcompletedjobs",
			success: function() {
			},
			error: function() {
				console.log("error getting completed jobs");
			}
		});
	}


	$('#cnfrmbtn').on('click', function() {
			var checklist = $(".layout :input").serialize();
			$('#cnfrmbtn, #cancelbutn').attr("disabled", true).addClass("disable_btns");
			$.ajax({
				type: "POST",
				url: "/app/Login/qc_home",
				data: checklist,
				success: function(result) {
					if (result != "Error") {
						$(".main_content").html("");
						$(".main_content").html(result);
						getCompletedJobs();
					} else {
						$('#cnfrmbtn, #cancelbutn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					$('#cnfrmbtn, #cancelbutn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		});

	$('#cancelbutn').on('click', function() {
			var checklistcancel = $(".layout :input").serialize();
			$('#cnfrmbtn, #cancelbutn').attr("disabled", true).addClass("disable_btns");
			$.ajax({
				type: "POST",
				url: "/app/Login/qc_home",
				data: checklistcancel,
				success: function(result) {
					if (result != "Error") {
						$(".main_content").html("");
						$(".main_content").html(result);
						getCompletedJobs();
					} else {
						$('#cnfrmbtn, #cancelbutn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					$('#cnfrmbtn, #cancelbutn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		})

});
$('.user-toggle').click(function(event) {
	event.stopPropagation();
	$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
	$('.user-toggle').css("border", "0px");
	$('#collapse_profile').show(500); 
});
$(document).click(function() {
	$('.user_profile,.user-toggle').css("background-color", "");
	$('.user-toggle').css("border", "none");
	$('#collapse_profile').hide(500); 
});