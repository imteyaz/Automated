//@author Prasad.Tallapally
//@Date: 13-03-2015
//Bayview Discharge and Loading Containers includes Twins

/**
 * Dicharge Container from bayview and Make Cell color empty.
 *  @author Prasad.Tallapally
 */
var dischargeContainer = function(containers, cellLocation) {

	var dischContList = containers.split('|');
	var cellArray = cellLocation.split('|');

	var dischargeBays = [];
	for (var k = 0; k < cellArray.length; k++) {
		dischargeBays.push(cellArray[k].split('.')[0]);
	}

	for (var x = 0; x < dischargeBays.length; x++) { // required in-Twin Container discharge
		console.log("dischargeContainer value of x = " + x);
		var dischargeBayData = bayviewObj[dischargeBays[x]].data;
		for (var i = 0; i < dischargeBayData.length; i++) {
			for (var j = 0; j < dischargeBayData[i].length; j++) {
				if (dischargeBayData[i][j].cellId == cellArray[x]) { // Making Cell Empty or Discharging Container
					dischargeBayData[i][j]['cellStatus'] = "1";
					dischargeBayData[i][j]['cntrNo'] = "";
					dischargeBayData[i][j]['reefer'] = "";
					dischargeBayData[i][j]['hazadorous'] = "";
					dischargeBayData[i][j]['OOG'] = "";
					dischargeBayData[i][j]['ROB'] = "";
					dischargeBayData[i][j]['POD'] = "";
					dischargeBayData[i][j]['colourCode'] = "";
					dischargeBayData[i][j]['damage'] = "";
				}
			}
		}
		buildBayview(bayviewObj[dischargeBays[x]]);
		buildTopView(bayviewObj[dischargeBays[x]]);
		addCssListeners();
	}

}

/**
 *  Load Container onto bay, applying or adding all contianer attribues
 *  @author Prasad.Tallapally
 */
var loadContainer = function(containers, cellLocation, prev_locations) {
	var contrArray = containers.split('|');
	
	var loadList = [];
	for (var d = 0; d < contrArray.length; d++) {
		loadList.push(contrArray[d].split('^'));
	}
	var cellArray = prev_locations.split('|');

	var dischargeBays = [];
	for (var k = 0; k < cellArray.length; k++) {
		dischargeBays.push(cellArray[k].split('.')[0]);
	}

	for (var x = 0; x < dischargeBays.length; x++) { // required in-Twin Container LOADING
		console.log("value of x = " + x);
		var dischargeBayData = bayviewObj[dischargeBays[x]].data;
		var list = loadList[x];
		for (var i = 0; i < dischargeBayData.length; i++) {
			for (var j = 0; j < dischargeBayData[i].length; j++) {
				console.log("required in-Twin Container LOADING ")
				if (dischargeBayData[i][j].cellId == cellArray[x]) { // Loading Container
					for (var n = 0; n < cellAttr.length; n++) {
						dischargeBayData[i][j].cntrNo = "";
						console.log("Loading Container ")
						//dischargeBayData[i][j].colourCode = "";
					}

				}
			}
		}
		//buildBayview(bayviewObj[dischargeBays[x]]);
		//buildTopView(bayviewObj[dischargeBays[x]]);
		//addCssListeners();

	}

	var contrArray = containers.split('|');
	var loadList = [];
	for (var d = 0; d < contrArray.length; d++) {
		loadList.push(contrArray[d].split('^'));
	}
	var cellArray = cellLocation.split('|');

	var dischargeBays = [];
	for (var k = 0; k < cellArray.length; k++) {
		dischargeBays.push(cellArray[k].split('.')[0]);
	}

	for (var x = 0; x < dischargeBays.length; x++) { // required in-Twin Container LOADING
		console.log("value of x = " + x);
		var dischargeBayData = bayviewObj[dischargeBays[x]].data;
		var list = loadList[x];
		for (var i = 0; i < dischargeBayData.length; i++) {
			for (var j = 0; j < dischargeBayData[i].length; j++) {
				console.log("required in-Twin Container LOADING 1")
				if (dischargeBayData[i][j].cellId == cellArray[x]) { // Loading Container
					for (var n = 0; n < cellAttr.length; n++) {
						console.log("Loading Container 1")
						dischargeBayData[i][j][cellAttr[n]] = list[n];
					}
					var forty_cell_id = $("#qc_table tr[data-container='" + dischargeBayData[i][j].cntrNo + "']").attr("cellid");
						if(typeof forty_cell_id !== "undefined") {
						var bay_no = forty_cell_id.split(".")[0] * 1;
						var cell_bay_no = dischargeBayData[i][j].cellId.split(".")[0] * 1
						
						if ( (bay_no % 2) == 0 && dischargeBayData[i][j].cntrNo != "" && cell_bay_no == $("#secondBay").html() * 1) {
							dischargeBayData[i][j].colourCode = "+"
						}
					}
				}
			}
		}
		buildBayview(bayviewObj[dischargeBays[x]]);
		buildTopView(bayviewObj[dischargeBays[x]]);
		addCssListeners();

	}

}

/**
 * Ealier Approach of dicharge container , Todo later on remove it, if not required
 *  @author Prasad.Tallapally
 */
var dischargeContainerByUpdatingMsg = function(cntrnumber) {
	var cellData = "";
	for (var x = 0; x < cellAttr.length; x++) {
		var code = cellAttr[x];
		cellData += $('div.bay_img div[' + "cntrNo=" + cntrnumber + ']').attr(code);
		if (x < cellAttr.length - 1) {
			cellData += "^";
		}
	}
	if (bayviewArray[0].indexOf(cellData)) {
		bayviewArray[0] = bayviewArray[0].replace(cellData, '1^^^^^^^');
	} else if (bayviewArray[1].indexOf(cellData)) {
		bayviewArray[1] = bayviewArray[1].replace(cellData, '1^^^^^^^');
	} else {
		showAlerts("Bay is not available")
	}

}

/**
 * Useful for drawing Bay Left and Right Bayview
 *  @author Prasad.Tallapally
 */

var renderBayview = function() {
	isFirstBay = false;
	$.each(bayviewObj, function(key, bayData) {
			buildBayview(bayData);
			buildTopView(bayData);
		});
	addCssListeners();
	setBayviewSwitchToggleVal();
	set_top_view();
}

/**
 * Useful for drawing Future Bay Left and Right Bayview based on current bay No.
 * @author Prasad.Tallapally
 */
var renderFutureBayview = function() {
	isFirstBay = false;
	$.each(futureBayviewObj, function(key, bayData) {
			buildBayview(bayData);
			buildTopView(bayData);
		});
	addCssListeners();
	set_top_view();		
}

/**
 * Request for getting future Bay based on current bayNo.
 * @author Prasad.Tallapally
 */
var requestAndBuildFutureBayview = function() {
	$("#layout").mask("Loading...");
	$.ajax({
		type: "POST",
		url: "/app/Login/futureBayview",
		success: function(result) {
			messageParser(result, 'future');
			renderFutureBayview(); // Drawing Future  Bayview
			$("#layout").unmask();
		}
	})
}

/**
 * Message Parser for based on request Type either current or future input params
 * @author Prasad.Tallapally
 */
var messageParser = function(result, reqType) {

	var bayviewMsgArray = result ? result.split(',') : [];
	if (!reqType) {
		// For Every New Bayview Request Make Empty of Current and Future Bayview
		bayviewObj = { };
		futureBayviewObj = { };
		$("#bay_img1").empty();
		$("#bay_img2").empty();
		$("#topview_1").empty();
		$("#topview_2").empty();
		$("#firstBay_no").text("");
		$("#firstBay").text("");
		$("#secondBay_no").text("");
		$("#secondBay").text("");
	}

	parseMsgToBayviewObj(bayviewMsgArray[0], LEFT_BAY_NO, reqType);
	baymessage = "2601~xyzenvetnid~" + bayviewMsgArray[1];
	parseMsgToBayviewObj(baymessage, RIGHT_BAY_NO, reqType);

}
/**
 * To request and render Upper Deck of current or future bay
 * @author Prasad.Tallapally
 */
var requestUpOrLowDeckBayview = function() {
	$('#switchingdeck').attr("disabled", true).addClass("disable_btns");
	$("#layout").mask("Loading...");
	var curr_bay_type = $('#deckSwitcherId input[name="deckSwitchButton"]').attr("bay_type")
	setBayFilterFutureToPod();
	$.ajax({
		type: 'POST',
		url: "/app/Qc/upOrLowDeckBayview",
		data: {
			bay_type: (curr_bay_type == "U") ? "D" : "U" 
		},
		success: function(result) {
			$("#bay_img2, #bay_img1, #topview_2, #topview_1").fadeOut(500).promise().done(function() { });
			$("#bay_img2, #bay_img1, #topview_2, #topview_1").fadeIn(500).promise().done(function() {
				messageParser(result);
				$("#cntr_select").val("POD");
				$("#cntr_select").change();
				get_deck_type(result)
				$("#layout").unmask();
			});
			$('#switchingdeck').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$("#layout").unmask();
			$('#switchingdeck').attr("disabled", false).removeClass("disable_btns");
		}

	});
}

/**
 * Set Bayview Switcher Val based on current cell location
 * if tier no < 80 = LOWER DECK
 * if tier > 80 = UPPER DECK
 * @author Prasad.Tallapally
 *
 */
var setBayviewSwitchToggleVal = function() {
	return true;
	var deckBayViewBtn = $('#deckSwitcherId input[name="deckSwitchButton"]');
	var firstBayviewObj = bayviewObj[Object.keys(bayviewObj)[0]]; // Getting BayviewObj first element

	if(firstBayviewObj.rowHeaders.length > 0){
		if (firstBayviewObj.rowHeaders[0] < 80) {
			deckBayViewBtn.val('Switch to Deck');
		} else {
			deckBayViewBtn.val('Switch to Lower Deck');
		}
	}else{
		if(deckBayViewBtn.val() == 'Switch to Deck'){
			deckBayViewBtn.val('Switch to Lower Deck');
		}else{
			deckBayViewBtn.val('Switch to Deck');
		}
	}

}

var processbayviewdata = function(bayprev) {
	$("#layout").mask("Loading...");
	var curr_bay_type = $('#deckSwitcherId input[name="deckSwitchButton"]').attr("bay_type")
	setBayFilterFutureToPod();
	$.ajax({
		type: "POST",
		url: "/app/Login/getprevnextbayrequest",
		data: {
			bprev: bayprev,
			bay_type: curr_bay_type
		},
		success: function(result) {
			$("#bay_img2, #bay_img1, #topview_2, #topview_1").fadeOut(500).promise().done(function() { });
			$("#bay_img2, #bay_img1, #topview_2, #topview_1").fadeIn(500).promise().done(function() {
				messageParser(result);
				renderBayview();
				get_deck_type(result)
				$("#cntr_select").val("POD");
				$("#cntr_select").change();
				$("#layout").unmask();
			});
		}
	});
	set_top_view();
}

var processbayviewrequest = function(baynumber, divid, topviewcallback) // Todo Need to remove params
{
	console.log("Inside processbayviewrequest");
	var jobFilter = "";
	if($("#jobs_select").length > 0) {
		jobFilter = $("#jobs_select").val();
	}
	
	$("#layout").mask("Loading...");
	$("#cntr_select").val("POD");
	$("#cntr_select").change();	
	$.ajax({
		type: "POST",
		url: "/app/Login/bay_frontview",
		data: {
			baylocation: baynumber,
			b2nddiv: topviewcallback,
			jobFilter: jobFilter
		},
		success: function(result) {
			messageParser(result);
			renderBayview();
			$("#layout").unmask();
			get_deck_type(result)
		},
		error: function() {
			$("#layout").unmask();
		}
		
	})
}
var setBayFilterFutureToPod = function() {
	if ($("#cntr_select").val() == "future") {
		$("#cntr_select").val("POD")
	}
}

// TO get the Deck type

function get_deck_type(bay_data){
	var deckBayViewBtn = $('#deckSwitcherId input[name="deckSwitchButton"]');
	$.ajax({
		type: "POST",
		url: "/app/Qc/deck_type",
		data: {
			bay_data: bay_data
		},
		success: function(result) {
			deckBayViewBtn.attr("bay_type",result)
			if(result != "U")
			{
				deckBayViewBtn.val("Switch to Lower Deck")	
			}
			else{
				deckBayViewBtn.val("Switch to Deck")
			}
		}
	})
}

/**
 *  Load Container onto bay, applying or adding all contianer attribues
 *  @author Prasad.Tallapally
 */
var loadfutureContainer = function(containers, cellLocation) {
	var contrArray = containers.split('|');
	var loadList = [];
	for (var d = 0; d < contrArray.length; d++) {
		loadList.push(contrArray[d].split('^'));
	}
	var cellArray = cellLocation.split('|');

	var dischargeBays = [];
	for (var k = 0; k < cellArray.length; k++) {
		dischargeBays.push(cellArray[k].split('.')[0]);
	}

	for (var x = 0; x < dischargeBays.length; x++) { // required in-Twin Container LOADING
		var dischargeBayData = futureBayviewObj[dischargeBays[x]].data;
		var list = loadList[x];
		for (var i = 0; i < dischargeBayData.length; i++) {
			for (var j = 0; j < dischargeBayData[i].length; j++) {
				if (dischargeBayData[i][j].cellId == cellArray[x]) { // Loading Container
					for (var n = 0; n < cellAttr.length; n++) {
						dischargeBayData[i][j][cellAttr[n]] = list[n];
					}
				}
			}
		}
		buildBayview(futureBayviewObj[dischargeBays[x]]);
		buildTopView(futureBayviewObj[dischargeBays[x]]);
		addCssListeners();
	}

}

function getcelllocationforbayupdate(cellId_org, celllocation) {
	var cellId = cellId_org.split(".")
	var bayno = Number(cellId[0])
	if (bayno % 2 == 0) {
		if (celllocation.length == 0)
			celllocation = pad( (bayno - 1)) + "." + cellId[1] + "." + cellId[2] + "|" + pad( (bayno + 1)) + "." + cellId[1] + "." + cellId[2]
		else
			celllocation = celllocation + "|" + pad( (bayno - 1)) + "." + cellId[1] + "." + cellId[2] + "|" + pad( (bayno + 1)) + "." + cellId[1] + "." + cellId[2]
	} else {
		if (celllocation.length == 0)
			celllocation = cellId_org
		else
			celllocation = celllocation + "|" + cellId_org
	}

	return celllocation;
}
