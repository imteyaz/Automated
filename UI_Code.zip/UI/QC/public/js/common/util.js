//@author Prasad.Tallapally
//@Date: 13-03-2015
//Parsing Server Msg and Creating a BAY JSON object
var parseMsgToBayviewObj = function(messageFromServer,bayType,reqType)
  {
	var splitResult=messageFromServer?messageFromServer.split("~"):"";
    var messageType=splitResult[0];
    var uniqueNo=splitResult[1];
    var bayNo=splitResult[2]; 
    var cols=splitResult[3];
    var rows=splitResult[4];
    var cellInfo=splitResult[5];
    var userId=splitResult[6];
    var terminalId=splitResult[7];
    var deck_type = splitResult[8];
    var colHeaders=cols?cols.split("^"):[];
    var rowHeaders=rows?rows.split("^"):[];
    var cell_2_array=cellInfo?cellInfo.split("|"):[];
        
    var cellArray=[];
    for(var i=0;i<cell_2_array.length;i++){
      cellArray.push(cell_2_array[i].split("$"));
    }
    
    var cellDetails=[]; 
    
    for(var i=0;i<cellArray.length;i++){
      var arr=[];
      var rowLength=cellArray[0]?cellArray[0].length:0;
      for(var j=0;j<rowLength;j++){
        if(cellArray[i][j]){
          var cell=(cellArray[i][j]).split("^");
          var obj={};
          for(var k=0;k<cell.length;k++){
            obj[cellAttr[k]]=cell[k];
          }
          arr.push(obj);
        }
      }
      if(arr.length != 0){
        cellDetails.push(arr);  
      }
    }
    
     var bayData={};
	 bayData.rowHeaders=rowHeaders;
	 bayData.colHeaders=colHeaders;
	 bayData.bayType=bayType;
	 bayData.bayNo=bayNo;
	 bayData.data=cellDetails;
	 
	 if(bayNo == ""){
		 if($.isEmptyObject(bayviewObj)){
			 bayNo = "-1";
		 }else{
			 bayNo = "-2";
		 }
	 }
	 
	 if(reqType){
		 futureBayviewObj[bayNo]=bayData; 
	 }else{
		 bayviewObj[bayNo]=bayData; 
	 }
		 
}

var addCssListeners= function(){
	  $(".tile").on('click',function(){
		   var cellId=$(this).attr('cellId');
	       var $this = $(this);
	       var $cellId=$("tr[cellid='"+cellId+"']");
	       var $container=$('.table_data_qc');
	      if($cellId.length==1){
	              var ypost1=$cellId.offset().top;
  	       $container.animate({
		                 scrollTop: ypost1 - $container.offset().top + $container.scrollTop()
		       });
         }
       if($cellId.hasClass("clicked")){
	      $("div[cellid='"+cellId+"']").addClass('onclick').removeClass("hover");
	      $cellId.removeClass("onmouseover");
	     }  
	    else
	    {
	      $(".table_data_qc tr").removeClass("selevn clicked");
	      $(".bay_img div,.top_view div").removeClass("hover onclick");
	      $( "div[cellid='"+cellId+"']" ).addClass('onclick');
	      if($cellId.length == 0)
	        checkandmarkjoblistrows(cellId,'selevn clicked')
	      else
	         $("tr[cellid='"+cellId+"']").addClass('selevn clicked');  
	    }
});

	var cellId;
	
	$( ".tile" ).hover(
	  function() {
		cellId=$(this).attr('cellId');
		    var $this = $(this);
		    var $cellId=$("tr[cellid='"+cellId+"']");
		    var $container=$('.table_data_qc');
		    if($cellId.length==1){
		          var ypost1=$cellId.offset().top;
	    	      $container.animate({
	 		             scrollTop: ypost1 - $container.offset().top + $container.scrollTop()
	 		      });
	        }
		 $("div[cellid='"+cellId+"']" ).addClass('hover');  
		 if($cellId.length == 0)
		     checkandmarkjoblistrows(cellId,'onmouseover');
		 else		
		     $("tr[cellid='"+cellId+"']").addClass('onmouseover');
	  }, function() {
		      $(".qc_rows").removeClass('onmouseover');
		      $("div[cellid='"+cellId+"']").removeClass('hover');  
	  }
	);
	function checkandmarkjoblistrows(cellId,classname)
	{
		cellId = cellId.split(".")
		bayno = Number(cellId[0])
	    cellIds = [];	  
		cellIds.push(pad((bayno+1))+"."+cellId[1]+"."+cellId[2])
	    cellIds.push(pad((bayno-1))+"."+cellId[1]+"."+cellId[2])
		for(i=0;i<cellIds.length;i++){		
		      $("tr[cellid='"+cellIds[i]+"']").addClass(classname); 
			}
		
	}
	
}