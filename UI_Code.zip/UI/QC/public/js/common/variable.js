//@author Prasad.Tallapally
//@Date: 10-03-2015
//Global Scope Variables
var cellAttr=['cellStatus','cntrNo','reefer','hazardous','OOG','ROB','POD','colourCode','damage']; // CellDetails in order
var bayviewObj={}; // Bayview Msg in Object format
var futureBayviewObj={}; //  Future Bayview Object = Current Bayview looks like after  Dicharging or Loading
var LEFT_BAY_NO=1; // Represents left bayview
var RIGHT_BAY_NO=2; //Represents Right bayview