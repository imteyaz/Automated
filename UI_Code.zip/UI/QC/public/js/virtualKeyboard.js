function virtualKeyboard(){

	$('input[type="text"]:not(' +  disabledElements + '), input[type="password"]').keyboard({

		display: {
			'bksp'   : '\u2190',
			'enter'  : '\u23CE',
			'default': 'ABC',
			'meta1'  : '123',
			'meta2'  : '#+=',
			'accept' : 'OK',
		    'cancel' : 'CANCEL'	   
		},
		autoAccept : true,
		layout: 'custom',
		customLayout: {
			'default': [
			'Q W E R T Y U I O P {bksp}',
			'A S D F G H J K L',
			'Z X C V B N M . {s}',
			'{meta1} {meta2} {space} {cancel} {accept}'
			],
			'shift': [
			'q w e r t y u i o p {bksp}',
			'a s d f g h j k l',
			'z x c v b n m . {s}',
			'{meta1} {meta2} {space} {cancel} {accept}'
			],
			'meta1': [
				'1 2 3',
				'4 5 6',
				'7 8 9',
				'0 . {bksp}',
				'{default} {cancel} {accept}'
			],
			'meta2': [
				'[ ] { } \u2039 \u203a ^ * " , {bksp}',
				'@ \\ | / $ \u00a3 \u00a5 \u2022 ?',
				'& ~ # = + . !',
				'{meta1} {default} {space} {cancel} {accept}'
			]
		}
});
	$('input[type="number"]').keyboard({
		layout : 'num',
		restrictInput : true, // Prevent keys not in the displayed keyboard from being typed in
		preventPaste : true,  // prevent ctrl-v and right click
		autoAccept : true
	});
}
