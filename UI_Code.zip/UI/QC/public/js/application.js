var disabledElements = "";
window.onerror = function(msg, url, line, col, error) {
   // Note that col & error are new to the HTML 5 spec and may not be 
   // supported in every browser.  It worked for me in Chrome.
   var extra = !col ? '' : '\ncolumn: ' + col;
   extra += !error ? '' : '\nerror: ' + error;

   // You can view the information in an alert to see things working like this:
   var errorMessage = "Error: " + msg + "\nurl: " + url + "\nline: " + line + extra;
   //alert(errorMessage);

   // TODO: Report this error via ajax so you can keep track
   //       of what pages have JS issues

   var suppressErrorAlert = true;
   // If you return true, then error alerts (like in older versions of 
   // Internet Explorer) will be suppressed.
   Rho.Log.error(errorMessage, "javascript");
};

function confirmYesOrNo(popMessage, callback){
	popMessage = popMessage || "Do you want continue?";
    
	
    swal({
      text: popMessage,
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
        	  callback("T");
          }else{
        	  callback("F");
          }
      });
    
}
function confirmDelay(popMessage,callback){
	popMessage = popMessage || "Do you want continue?";
    swal({
      text: popMessage,
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
        	  callback("yes");
          }else{
        	  callback("no");
          }
      });
    
}
