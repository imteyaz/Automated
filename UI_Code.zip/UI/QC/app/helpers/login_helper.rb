module LoginHelper
  #  class for holding the joblist
  class Joblist
    include Enumerable
    attr_accessor :code,:containerno,:iso,:country,:wght,:from_loc,:to_loc,:remarks,:refercontainer,:colorcode,:twinpick,:tandempick,:st,:cat,:bay,:tier,:row,:alternatecell,:jobtype,:sparcsexception,:exception_reason,:imdg,:is_damaged,:seq_no
    def initialize(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st, imdg, is_damaged,seq_no="0",jobtype="planned",sparcsexception="N",exception_reason="")
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st, imdg, is_damaged,seq_no,jobtype,sparcsexception,exception_reason)
    end

    def updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st,imdg, is_damaged,seq_no="0",jobtype="planned",sparcsexception="N",exception_reason="")
      @jobtype = jobtype
      @sparcsexception = sparcsexception
      @exception_reason = exception_reason
      @code = code
      @containerno = containerno.upcase
      @iso = iso
      @country = country
      @wght = wght
      @from_loc = from_loc
      @to_loc = itvno
      @remarks  =remarks
      @colorcode = colorcode
      if(st == 'true')
        @st = 'M'
      elsif(st == 'false')
        @st = 'F'
      else
        @st = ""
      end
      @cat = cat
      @twinpick = -1
      @tandempick = -1
      @imdg = imdg
      @is_damaged = is_damaged
      @seq_no = seq_no
      @refercontainer =""
      if(!refercontainer.nil? && !refercontainer.empty?)
        @refercontainer =refercontainer
        @twinpick = twinpick
        @tandempick = tandempick
      end
      if(code == "DSCH" && from_loc != 'VESSEL')
        cellvalues = from_loc.split(".")
      elsif(code=="LOAD" && to_loc != 'BACKREACH')
        cellvalues = to_loc.split(".")
      else
        cellvalues = [-1,-1,-1]
      end
      @bay = cellvalues[0].to_i
      @row = cellvalues[1].to_i
      @tier = cellvalues[2].to_i
      @alternatecell = ""
      if(@bay%2 == 0 && @bay != 0)
        @alternatecell = (@bay-1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." +cellvalues[2] + "|" + (@bay+1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." + cellvalues[2]
      end
    end

    def updatejob(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,twinpick,tandempick,cat,st,imdg, is_damaged,seq_no,jobtype,sparcsexception,exception_reason)
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,twinpick,tandempick,cat,st,imdg, is_damaged,seq_no,jobtype,sparcsexception,exception_reason)
    end
  end

  # processing container handling plc arrived event
  def processcontainerarrived(resp)
    return true
    resp_fields = resp.to_s.split("~")
    resp_msg_id = resp_fields[0]
    if(resp_msg_id == "1306")

      # if ITV arrived add the entry and delete the entry with same number.
      if(resp_fields[3].empty?)
        $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
        $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6])
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6] + '")')
      else
        # move job to promoted joblist in case of load and in present of container number
        $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
        $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6])
        contritvcomb = resp_fields[3] + "|" + resp_fields[2]
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6] + '")')
        # WebView.execute_js('shufflejobs("'+ contritvcomb.to_s() + '")')
      end
    elsif(resp_msg_id == "1307")
      # if ITV dispatch was received add the entry and delete the entry with the same number.
      $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
      $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5])
      WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5] + '")')
    else
      # if ITV left was received delete that entry.
      resp_fields = resp.to_s.split("~")
      if(resp_fields[2].empty?)
        return false
      else
        contritvcomb =  resp_fields[2]
        cIndex = $session[:Itv_popup_image].index{|v| (v.split("#")[0]==contritvcomb)}
        $session[:Itv_popup_image].delete_at(cIndex)
        WebView.execute_js('shufflejobs("'+ contritvcomb + '")')
      end
    end
  rescue Exception => ex
    puts "uncaught #{ex} exception while handling ITV delete message:"+ex.inspect
  end

  # method for processing heavy hook
  def processheavyhook(resp)
    resp_fields = resp.to_s.split("~")
    if( resp_fields[2] == "true")
      res = "HVY_HK_TRUE"
    else
      res = "HVY_HK_FALSE"
    end

    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #filter jobs
  def filterjobs(container)
    resp_qc_job = Array.new
    itv_no = Array.new
    if(container=="twin_handling")
      resp_qc_job = $resp_qc_jobs.select{|a| (a.twinpick != -1) && (a.tandempick == -1) && (a.bay%2 == 1)}
    elsif(container=="current_jobs")
      resp_qc_job = $resp_qc_jobs
    elsif(container=="jobs_completed")
      if($completed_jobsrequest == false)
        @udp_req_obj[:msg] = "1~1~1420~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
        resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        if resp.length > 0
          resp_fields = resp.to_s.split("~")
          if(resp_fields[0] == "1421")
            $is_completed_jobsrequest = true
            $completedjobs = processjoblist(resp_fields,'cmpltd')
            $completed_jobsrequest = true
          end
        end
      end
      backreach_dsch_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "DSCH")}.map{|b| b.containerno}
      backreach_load_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "LOAD")}.map{|b| b.containerno}
      $backreach_load_jobs = backreach_dsch_jobs - backreach_load_jobs
      resp_qc_job = $completedjobs
    elsif(container=="tandem_pick")
      resp_qc_job = $resp_qc_jobs.select{|a| a.tandempick != -1 || ((a.twinpick != -1) && (a.tandempick == -1) && (a.bay%2 == 0))}
    elsif(container=="backreach_jobs")
      resp_qc_job = $completedjobs.select{|a| (a.from_loc == "BACKREACH" || a.to_loc == "VESSEL") || (a.from_loc == "VESSEL" || a.to_loc == "BACKREACH")}
    elsif(container=="promoted_jobs")
      itv_no = $session[:Itv_popup_image].to_s.split("#")[0]
      resp_qc_job  = $resp_qc_jobs.select{|a| (itv_no.include? a.from_loc) && a.code == "LOAD" || ($promoted_jobs.include? a.containerno)}
    elsif(container=="exception_joblist")
      resp_qc_job = $completedjobs.select{|a| a.sparcsexception == "Y"}
    end
    
#    resp_qc_job = resp_qc_job.uniq {|j| j.containerno }
    return resp_qc_job
  end

  # method for processing QC performance
  def processqcperformance(resp)
    resp_fields = resp.to_s.split("~")
    qc_view = resp_fields[3].to_s+"|"+resp_fields[4].to_s + "|"+resp_fields[5].to_s + "|"+ resp_fields[6].to_s + "|"+resp_fields[7].to_s
    WebView.execute_js('updateQCfields("'+ qc_view.to_s() + '")')

  end

  def process_damage_record_changed(resp)
    resp_fields = resp.to_s.split("~")
    selected_job  = $resp_qc_jobs.select{|v| v.containerno == resp_fields[2]}
    if selected_job.empty?
      selected_job = $completedjobs.select{|v| v.containerno == resp_fields[2]}
    end

    if selected_job.empty?
    else
      selected_job[0].is_damaged = resp_fields[3].to_s;
    end

    WebView.execute_js('addRemoveDamageIcon("'+ resp_fields[2] + "#" + resp_fields[3] + '")')

  end

  #method for processing job list
  def processjoblist(resp_fields,joblisttype='new')
    resp_qc_list = resp_fields[2].to_s.split('|')
    twinpick = -1
    tandempick = -1
    resp_qc_list.each do |check_list_item|

      jobfields = check_list_item.to_s.split('^')

      ref_container_list = jobfields[8].to_s.split('#')
      jobtype = 'planned'
      if(jobfields[5] == 'BACKREACH' || jobfields[5] == 'VESSEL')
        jobtype='manual'
      end
      if(joblisttype == 'cmpltd')
        joblistcheck  = $completedjobs.select{|v| (v.containerno == jobfields[1])}
        if joblistcheck.length == 0
          if($is_completed_jobsrequest == true)
            $completedjobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[16],"0",jobfields[15],jobtype,jobfields[12],jobfields[13]))
          else
            $completedjobs.unshift(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[16],"0",jobfields[15],jobtype,jobfields[12],jobfields[13]))
          end
        end
      else
        $resp_qc_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[17],jobfields[16],jobfields[18],jobtype))
      end
    end
    if($is_completed_jobsrequest == true)
      $is_completed_jobsrequest == false
    end
    $backreach_dsch_jobs = $resp_qc_jobs.select{|v| (v.from_loc == "BACKREACH" || v.to_loc == "BACKREACH")}
    #    twin_tandem_pairing
    if(joblisttype == 'cmpltd')
      return $completedjobs
    else
      return $resp_qc_jobs
    end
  end

  def twin_tandem_pairing
    $resp_qc_jobs.each do |job|
      ref_containers = job.refercontainer
      if ref_containers != nil
        ref_container_list = ref_containers.to_s.split("#")
        if ref_container_list.length == 1
          ref_container_list.each do |refer|
            refer_job = $resp_qc_jobs.select{|v| (v.containerno == refer )}[0]
            if refer_job != nil
              job.twinpick = 0
              if refer_job.twinpick = 0
                job.twinpick = 1
              end
            end
          end
        end
        if ref_container_list.length == 3

          ref_container_list.each do |refer|
            refer_jobs = $resp_qc_jobs.select{|v| (ref_container_list.include?(v.containerno ))}
            #            if refer_jobs.length == 3
            refer_jobs.each do |refer_job|
              refer_jobs[0].twinpick = 0 if refer_jobs[0] != nil
              refer_jobs[1].twinpick = 1 if refer_jobs[1] != nil
              refer_jobs[2].twinpick = 0 if refer_jobs[2] != nil
              job.twinpick = 1
              refer_jobs[0].tandempick = 0 if refer_jobs[0] != nil
              refer_jobs[1].tandempick = 1 if refer_jobs[1] != nil
              refer_jobs[2].tandempick = 2 if refer_jobs[2] != nil
              job.tandempick = 3
            end
          end
          #          end
        end
      end
    end

    $completedjobs.each do |job|
      ref_containers = job.refercontainer
      if ref_containers != nil
        ref_container_list = ref_containers.to_s.split("#")
        if ref_container_list.length == 1
          ref_container_list.each do |refer|
            refer_job = $completedjobs.select{|v| (v.containerno == refer )}[0]
            if refer_job != nil
              job.twinpick = 0
              if refer_job.twinpick = 0
                job.twinpick = 1
              end
            end
          end
        end
        if ref_container_list.length == 3

          ref_container_list.each do |refer|
            refer_jobs = $completedjobs.select{|v| (ref_container_list.include?(v.containerno ))}
            #            if refer_jobs.length == 3
            refer_jobs.each do |refer_job|
              refer_jobs[0].twinpick = 0 if refer_jobs[0] != nil
              refer_jobs[1].twinpick = 1 if refer_jobs[1] != nil
              refer_jobs[2].twinpick = 0 if refer_jobs[2] != nil
              job.twinpick = 1
              refer_jobs[0].tandempick = 0 if refer_jobs[0] != nil
              refer_jobs[1].tandempick = 1 if refer_jobs[1] != nil
              refer_jobs[2].tandempick = 2 if refer_jobs[2] != nil
              job.tandempick = 3
            end
          end
          #          end
        end
      end
    end

  end

  # processing PLC job completed move
  def processjobdone(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    to_location = resp_fields[4].split("|")
    $manualautomatic_job = resp_fields[5]
    containerlist = ""
    movekind = ""
    puts resp_fields.inspect
    puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    $plc_job_list_confirm = ($resp_qc_jobs + $completedjobs).select{|v| (containerarry.include? v.containerno + '^' + v.code) && (v.to_loc = (to_location[containerarry.index(v.containerno+'^'+v.code)] || "") if (v.to_loc != to_location))}
    puts $plc_job_list_confirm.inspect()
    job_code = "DSCH"
    $plc_job_list_confirm.each{|r| 
      if(r.code == "LOAD" )
        job_code = "LOAD"
        if(r.to_loc != 'BACKREACH')
          cellvalues = r.to_loc.split(".")
          bay_no = cellvalues[0].to_i
          row_no = cellvalues[1].to_i
          tier_no = cellvalues[2].to_i
          if(bay_no%2 == 0 && bay_no != 0)
            r.alternatecell = (bay_no-1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." +cellvalues[2] + "|" + (bay_no+1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." + cellvalues[2]
          end
        end 
      end
    }
    cell_location =""
    if(job_code == "DSCH" && $plc_job_list_confirm.length > 0)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty? || alternatecellloc == "|" )
        cell_location = $plc_job_list_confirm.map(&:from_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      containerlist = getcontainerstringfordsch($plc_job_list_confirm)
      movekind = 'DSCH'
    else
      $plc_job_list_confirm = ($resp_qc_jobs + $completedjobs).select{|v| (containerarry.include? v.containerno + '^' + v.code) && (v.to_loc = (to_location[containerarry.index(v.containerno+'^'+v.code)] || "") if (v.to_loc != to_location))}
      containerlist = getcontainerstringforload($plc_job_list_confirm)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty? || alternatecellloc == "|")
        cell_location = $plc_job_list_confirm.map(&:to_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      movekind = "LOAD"
    end
    res = "PLC_JOB_DONE" + "~" + containerlist + "~" + cell_location + "~" + movekind
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')

  end

  #manual job confirmation
  def processcontainerhandling(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    cell_location =""
    movekind = ""
    resp_qc_job = $resp_qc_jobs.select{|v| (containerarry.include? v.containerno+"^"+v.code) && v.code == 'DSCH'}
    if(resp_qc_job.length > 0)
      cell_location = resp_qc_job.map(&:from_loc).join("|")
      movekind = 'DSCH'
    else
      resp_qc_job = $resp_qc_jobs.select{|v| (containerarry.include? v.containerno+"^"+v.code) && v.code != 'DSCH'}
      cell_location = resp_qc_job.map(&:to_loc).join("|")
      movekind = 'LOAD'
    end
    if(resp_qc_job.length > 0)
      res = "CONTAINER_HANDLING_TRUE" + "~" +resp_fields[3] + "~" + cell_location + "~" + movekind
    else
      res = "ALERT_MESSAGE_DISPLAYED" + "~" + "Container #{resp_fields[3]} is ROB"
    end

    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #method for processing delay recording message
  def processdelayrecording(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3]
    WebView.execute_js('processdelayrecording("'+ res.to_s() + '")')
  end

  #Alert message for stopping work
  def processworkstopalert(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    WebView.execute_js('showAlerts("'+ res.to_s() + '")')
  end

  #method for normal alert message
  def processnormalalertmessage(resp)
    resp_fields = resp.to_s.split("~")
    container_number = resp_fields[2]
    if(resp_fields[0]=="9910")
      cList = resp_fields[2].to_s.split("|")
      $completedjobs.each {|v| v.sparcsexception = "Y" if cList.include? v.containerno + '^' + v.code}
      $completedjobs.each {|v| v.exception_reason = resp_fields[3] if cList.include?(v.containerno + '^' + v.code)}
    end
    res = "NORMAL_ALERT_MESSAGE"+ "~" + container_number + " : " + resp_fields[3] + "~" + resp_fields[4];
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #backreach container move
  def backreachcontainermove(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3]
    WebView.execute_js('backreachcontainermove("'+ res.to_s() + '")')
  end

  def process_freeze_unfreeze_app(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    if(resp_fields[2] == "false")
      WebView.execute_js('freezeUI("'+ res.to_s() + '")')
    else
      WebView.execute_js('unFreezeUI()')
    end
  end

  #joblist update after plc job completion
  def getlistaftrplcjobdone(containerlist)
    compltdjob = Array.new
    twinpick = 1
    tandempick = 0
    containers = Array.new
    $plc_job_list_confirm.each do |current_job|
      containers.push(current_job.containerno + '^' + current_job.code)
    end
    containers.each{ |cNo|
      containerList=($resp_qc_jobs.select{|v| (v.refercontainer.include? cNo.split('^')[0]) || (v.containerno==cNo.split('^')[0] && v.code==cNo.split('^')[1])})
      containerList.each {|cList|
        cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno && v.code==cList.code)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        resp_qc_job.refercontainer = ""
        resp_qc_job.twinpick = -1
        resp_qc_job.tandempick = -1
      }
    }
    required_jobs=($resp_qc_jobs.select{|v| (containers.include? v.containerno + '^' + v.code) })
    containerList = Array.new
    required_jobs.each do |single_job|
      containerList.push(single_job.containerno + '^' + single_job.code)
    end

    if (containerList.length == 2 || containerList.length == 4)
      containerList.each {|containerno|
        cIndex = $resp_qc_jobs.index{|v| ((v.containerno+ '^' +v.code)==containerno)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        refer_container = prepareRefContainer(containerList,containerno)
        #        if(twinpick == 0)
        #          twinpick=1
        #        else
        #          twinpick=0
        #        end
        resp_qc_job.refercontainer = refer_container
        #        resp_qc_job.twinpick = twinpick

        #        if(containerList.length == 4)
        #          resp_qc_job.tandempick = tandempick
        #          tandempick = tandempick + 1
        #        end
      }
    end

    if ($manualautomatic_job == "A" )
      $resp_qc_jobs.delete_if {|v| compltdjob.push(v) if containers.include?(v.containerno+'^'+v.code)}
    else
      $resp_qc_jobs.delete_if {|v| containers.include?(v.containerno+'^'+v.code)}
    end

    #    twin_tandem_pairing
    $completedjobs = compltdjob.concat($completedjobs)
    #    $completedjobs.concat(compltdjob)
    $completedjobs
    return $resp_qc_jobs
  end

  # method to determine the cell location for bay view request, server expects cell location this function processes for initial bay request
  def getcelllocationforbayview(loc,param)
    if(loc == "-1")
      cellvalues = param.split(".")
    else
      loc.gsub("cell-","")
      cellvalues = loc.split(".")
    end
    baynumber = cellvalues[0].to_i
    if(baynumber.even?)
      baynumber= baynumber-1
    end
    if(cellvalues[1] == nil)
      cellvalues[1] = ""
    end
    
    if(cellvalues[2] == nil)
      cellvalues[2] = ""
    end
    
    leftcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    return leftcellval
  end

  #method to get the cell position for bay request
  def getcelllocation(loc)
    loc.gsub("cell-","")
    cellvalues = loc.split(".")
    baynumber = cellvalues[0].to_i
    if(baynumber.even?)
      baynumber = baynumber-1
    end
    
    if(cellvalues[1] == nil)
      cellvalues[1] = ""
    end
    
    if(cellvalues[2] == nil)
      cellvalues[2] = ""
    end
    
    leftcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    if(baynumber.even?)
      baynumber= baynumber+1
    else
      baynumber= baynumber+2
    end
    rightcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    return leftcellval,rightcellval
  end

  # method to get cell loaiton for prev next bay request
  def getcelllocationforprevnext(bprev)
    celllocation = ""
    cellattributes = $last_rendered_cell.split(".")
    if(bprev == 'true')
      leftloc = getbaynosforprev(cellattributes[0].to_i);
      leftcelllocation = leftloc.to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
    else
      leftcelllocation = (cellattributes[0].to_i+4).to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
    end
    return leftcelllocation
  end

  # method to get bay nos for prev , to display 1,3 incase end is reached
  def getbaynosforprev(bayno)
    if(bayno == 3 || bayno ==5)
      leftbayno =  1
    else
      leftbayno = bayno-4
    end
    return leftbayno
  end

  # method to update job list
  def updatejoblist(resp)
    begin
      resp_fields = resp.to_s.split("~")
      resp_qc_list = resp_fields[2].to_s.split('|')
      twinpick = 1
      tandempick = -1
      resp_qc_list.each do |check_list_item|
        if (tandempick == 3)
          tandempick = -1
        end
        jobfields = check_list_item.to_s.split('^')
        jobindex = $resp_qc_jobs.index{|v| (v.containerno==jobfields[1]) && v.code == jobfields[0]}
        if(jobfields[8] != nil && !jobfields[8].empty?)
          ref_container_list = jobfields[8].to_s.split('#')
          if(ref_container_list.length > 2)
            tandempick = tandempick + 1
          end
          if(twinpick == 0)
            twinpick=1
          else
            twinpick=0
          end
        end
        if(jobindex == nil)
          $resp_qc_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11], jobfields[17], jobfields[16],jobfields[18]))
        else
          updatedjob = $resp_qc_jobs[jobindex]
          updatedjob.updatevalues(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11], jobfields[17],jobfields[16],jobfields[18])
          $resp_qc_jobs[jobindex] = updatedjob
        end
      end
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    rescue Exception => ex
      puts("uncaught #{ex} exception while handling : #{ex.message}")
    end
  end

  #clearing the session on logout or exit
  def clearsession()
    $session[:checkForMsg].clear
    $session[:Itv_popup_image].clear
    $resp_qc_jobs.clear
    $completedjobs.clear
    $job_list_confirm.clear
    $last_rendered_cell = ""
    $userid=""
  end

  #method to prepare string for updating the bay view in load case
  def getcontainerstringforload(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      refer = false
      hazardous = false
      oog =false
      rob=false
      damage=false
      country = ""
      colorcode=""
      if([1,3,4,5,6].include?(job.remarks.to_i))
        refer = true
      end
      if([1,2].include?(job.remarks.to_i))
        hazardous = true
      end
      if([7,8,9,10,11,12].include?(job.remarks.to_i))
        oog = true
      end
      if([13].include?(job.remarks.to_i))
        damage = true
      end
      if([14].include?(job.remarks.to_i))
        damage_low = true
      end
      if(!job.country.nil?)
        country =job.country
      end
      if(!job.colorcode.nil?)
        colorcode = job.colorcode
      end
      contrstring = "1^"+job.containerno+"^"+refer.to_s+"^"+hazardous.to_s+"^"+oog.to_s+"^"+rob.to_s+"^"+country+"^"+colorcode+"^"+damage.to_s
      contrloadstrings.push(contrstring)
      if((job.bay.to_i)%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  #method to prepare string for updating the bay view in dsch case
  def getcontainerstringfordsch(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      contrstring = job.containerno + '^' + job.code
      contrloadstrings.push(contrstring)
      if((job.bay.to_i)%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  # style class name for category
  def get_catagory(cat_no)
    cat_no_to_icon_map = {
      "T" => "tranship",
      "I" => "import",
      "E" => "export",
      "R" => "restow",
      "S1" => "restow",
      "S2" => "restow",
      "B" => "restow"
    }
    return cat_no_to_icon_map.fetch(cat_no, nil)
  end

  # style class name for remarks
  def get_table_remarks_icon(remarks_no)
    remarks_no_to_icon_map = {
      "1" => "hazardous_reefer",
      "2" => "hazardous",
      "3" => "reefer_1",
      "4" => "reefer_2",
      "5" => "reefer_3",
      "6" => "reefer_4",
      "7" => "over-dimentional_1",
      "8" => "over-dimentional_2",
      "9" => "over-dimentional_3",
      "10" => "over-dimentional_4",
      "11" => "over-dimentional_5",
      "12" => "over-dimentional_6",
      "13" => "damage",
      "14" => "damage_low"
    }
    return remarks_no_to_icon_map.fetch(remarks_no, nil)
  end

  #  method for finding the cell for upper or lower deck.
  def getupperorlowerdeckcell()
    lastrenderedlocations = $last_rendered_cell
    cellattributes = lastrenderedlocations.split(".")
    tierlocation =  cellattributes[2].to_i
    cellattributes[2] = (tierlocation).to_s.rjust(2,'0')
    location = cellattributes.join(".")
    return  location
  end

  #  method for sending the bayview request and retrieving the respone.
  def getbayview(celllocation,reqtype,reqno)
    @udp_req_obj[:msg] = "1~1~2600~#{geteventid(reqno)}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{celllocation}~#{reqtype}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 3)
    if resp && resp.length > 0
      $futurebayrequested = false
      if(reqtype == 'F')
        $futurebayrequested = true
      end
    else
      resp = ""
    end
    return resp
  end

  def getbayview_for_deck_type(celllocation,reqtype,reqno,bay_type)
    @udp_req_obj[:msg] = "1~1~2603~#{geteventid(reqno)}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{celllocation}~#{reqtype}~#{bay_type}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 3)
    if resp && resp.length > 0
      $futurebayrequested = false
      if(reqtype == 'F')
        $futurebayrequested = true
      end
    else
      resp = ""
    end
    return resp
  end

  def removingjobs(resp)
    resp_fields = resp.to_s.split("~")
    container =  resp_fields[3]
    containerList = container.split('|')
    if resp_fields[4].to_s == "DELETE"      ########Delete
      containerList.each {|containerNo|
        $resp_qc_jobs.delete_if {|v| (v.containerno ==  containerNo.split("^")[0] && v.code == containerNo.split("^")[1])}
      }
    elsif resp_fields[4].to_s == "TRANSFER"    ########Transfer
      containerList.each {|containerNo|
        cIndex = $resp_qc_jobs.index{|v|(v.containerno==containerNo.split("^")[0] && v.code == containerNo.split("^")[1])}
        if(cIndex != nil)
          $completedjobs.push($resp_qc_jobs[cIndex])
          $resp_qc_jobs.delete_at(cIndex)
        end
      }
    end
    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def prepareRefContainer(addContainerList,containerNo)
    refercontainer=Array.new
    #refercontainer=(addContainerList.select {|cNo|  cNo !=containerNo })
    addContainerList.each do |cNo|
      if(cNo !=containerNo)
        refercontainer.push(cNo.split('^')[0])
      end
    end
    refer_container_string = refercontainer.join("#")
    return refer_container_string
  end

  def processbayupdate(resp)
    if($futurebayrequested == true)
      bayno,deck = getcurrentBaynumbers()
      resp_fields = resp.split("~")
      reqbayno = resp_fields[3]
      if((bayno == reqbayno) && deck == resp_fields[4])
        res = "UPDATE_BAY" + "~" + resp_fields[6] + "~" + resp_fields[5]
        WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
      end
    end
  end

  def getcurrentBaynumbers()
    bayno=""
    celllocations = $last_rendered_cell
    bayno.push(celllocations.split(".")[0])
    deck = 'U'
    if(celllocations.split(".")[2].to_i > 80)
      deck = 'D'
    end
    return bayno,deck
  end

  # method for processing manual job cancel
  def processjobcancel(resp)
    res = "CANCEL_JOB"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  # method for processing plc activation
  def processplcactivedeactive(resp)
    resp_fields = resp.to_s.split("~")
    if( resp_fields[3] == "true")
      res = "PLC_TRUE"
    else
      res = "PLC_FALSE"
    end
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #Adding manual Jobs
  def addManualJobs(resp)
    resp_fields = resp.to_s.split("~")
    containerno = resp_fields[2]
    movetype = resp_fields[3]
    from_loc = resp_fields[4]
    to_loc = resp_fields[5]

    jobindex = $completedjobs.index{|v| (v.containerno==containerno)}

    if(jobindex == nil)
      if(containerno.include? 'HATCHCOVER LOAD')
        $completedjobs.push(Joblist.new(movetype,containerno,'','','',from_loc,to_loc,'','','','','','','','false','false',"manual"))
      else
        $completedjobs.unshift(Joblist.new(movetype,containerno,'','','',from_loc,to_loc,'','','','','','','','false','false',"manual"))
      end
    else
      updatedjob = $completedjobs[jobindex]
      updatedjob.updatevalues(movetype,containerno,'','','',from_loc,to_loc,'','','','','','','','false','false',"manual")
      $completedjobs[jobindex] = updatedjob
    end

    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #Delete manually created jobs
  def deleteManualJobs(resp)
    resp_fields = resp.to_s.split("~")
    cntrList = resp_fields[2].split("|")
    cntrList.each {|containerNo|
      cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
      if(cIndex != nil)
        $resp_qc_jobs.delete_at(cIndex)
      end
    }
    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def select_jobs(resp)
    resp_fields = resp.to_s.split("~")
    container_no = resp_fields[2]
    WebView.execute_js('promoteSelectedJob("'+ container_no.to_s() + '")')
  end

  #Updating Twin Tandom and Split Jobs
  def updateTwinTandemSplitJobs(resp)
    resp_fields = resp.to_s.split("~")
    jobType = resp_fields[2].to_s
    cntrList = resp_fields[3].split("|")
    containerList=($resp_qc_jobs.select{|v|  cntrList.include? v.containerno })

    if(cntrList.length == containerList.length)
      if(jobType.include? "SPLIT")
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        #        twinpick = 1
        #        tandempick = 0
        targetIndex=""
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(cntrList,containerNo)
          #          if(twinpick == 0)
          #            twinpick=1
          #          else
          #            twinpick=0
          #          end
          resp_qc_job.refercontainer = refercontainer
          #          resp_qc_job.twinpick = twinpick
          #          if(jobType == "TANDEM" && cntrList.length != 2)
          #            resp_qc_job.tandempick = tandempick
          #            tandempick = tandempick + 1
          #          end
          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }

      end
      #      twin_tandem_pairing
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    end

  end

  #Getting cell location from the first job of job list
  def getfirstjobcelllocation(baylocation)
    joblist = $resp_qc_jobs.select{|v| (v.from_loc !='BACKREACH') && (v.from_loc!='VESSEL')}
    completed_jobs = $completedjobs.select{|v| (v.from_loc !='BACKREACH') && (v.from_loc!='VESSEL')}
    celllocationforleft =""
    bjobavlble = true
    if(!joblist.empty?)
      if(joblist.first.code == 'DSCH')
        celllocationforleft = getcelllocationforbayview(baylocation,joblist.first.from_loc)
      else
        celllocationforleft = getcelllocationforbayview(baylocation,joblist.first.to_loc)
      end
    end
    
    if(celllocationforleft == "")
      if(!completed_jobs.empty?)
        if(completed_jobs.first.code == 'DSCH')
          celllocationforleft = getcelllocationforbayview(baylocation,completed_jobs.first.from_loc)
        else
          celllocationforleft = getcelllocationforbayview(baylocation,completed_jobs.first.to_loc)
        end
      end
    end
    
    return celllocationforleft,bjobavlble
  end

  def updatelastcelllocation(celllocationforleft,bayviewleft)
    cellattributes = celllocationforleft.split('.')
    bayno = bayviewleft.split('~',4)[2]
    cellattributes[0] = bayno.to_s.rjust(2,'0')
    $last_rendered_cell = cellattributes.join('.')
  end


end