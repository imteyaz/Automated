require 'socket'
require 'thread'
require 'rho/rhocontroller'
require 'helpers/browser_helper'
require 'helpers/socket_helper'
require 'helpers/login_helper'
require 'rho/rhoapplication'
require 'net/http'
require 'uri'

class AppApplication < Rho::RhoApplication
  def initialize
    # Tab items are loaded left->right, @tabs[0] is leftmost tab in the tab-bar
    # Super must be called *after* settings @tabs!
    @tabs = nil
    #To remove default toolbar uncomment next line:
    @@toolbar = nil
    super
    #Rho::Application.setApplicationNotify("Activated",check_for_instance)
    #Rho::Application.setApplicationNotify("Deactivated",rest_instance)
    @default_menu = {}
    $session ||= {}
    $sleeptime ||= {}
    $myThread ||= {}
    $udp_socket = nil
    $session[:checkForMsg] = Array.new
    $session[:Itv_popup_image]= Array.new
    $resp_qc_jobs = Array.new
    $completedjobs = Array.new
    $poll_socket = nil
    $job_list_confirm = Array.new
    $last_rendered_cell = ""
    $plc_job_list_confirm = Array.new
    $loggedout = false
    $loggedin = false
    $msg_hash =  Hash.new( "messages" )
    $display_itv_pow = Array.new
    $futurebayrequested = false
    $no_of_wait_trails = 0
    $completed_jobsrequest = false
    $backreach_dsch_jobs = Array.new
    $forcelogout = false
    $force_logout_msg = ""
    $server_login_failure = false
    $app_started = false
    $promoted_jobs = Array.new
    $is_completed_jobsrequest = false # used to check whether jobs are coming from server or current jobs
    # Uncomment to set sync notification callback to /app/Settings/sync_notify.
    # Rho::RhoConnectClient.setObjectNotification("/app/Settings/sync_notify")
    Rho::RhoConnectClient.setNotification('*', "/app/Settings/sync_notify", '')
    System::set_locale("en")
    $local_com_ip = Rho::RhoConfig.local_ip_to_use == "system" ? UDPSocket.open {|s| s.connect(Rho::RhoConfig.com_server_ip, 1); s.addr.last } : Rho::RhoConfig.local_com_ip
#        $local_com_ip = UDPSocket.open {|s| s.connect('127.0.0.1', 1); s.addr.last }
    #    $local_com_ip = Socket.gethostname
    puts $local_com_ip.inspect
    puts "Local ip address"
    $device_id = (Rho::RhoConfig.device_selection == "device") ? Socket.gethostname : Rho::RhoConfig.deviceid
    puts $device_id.inspect
    puts "Device id"
  end

  def on_activate_app
#    publicPath = Rho::Application.publicFolder
#    p "WWWWWWWWWWWWWWWWWWWW"
#    p publicPath.inspect()
#    res=parse_instances("start /min " + publicPath + "\\beep\\sound.vbs")
#
#    p res.inspect()
#    check_for_instances = parse_instances("wmic process where \"name like '" + "minapro" +
#    "%'\" get ProcessID,Commandline /format:list")
#    if check_for_instances.size > 0
#      Alert.show_popup(
#      :message=> "Application is already opened,please close to start new instance",
#      :title=>"Opened",
#      :buttons=>["Ok"]
#      )
#      Rho::Application.quit
#    end
#    # TO CHECK IF THE APPLICATION PORT IS ALREADY RUNNING
#    if !($app_started)
#      $app_started = true
#      #      begin
#      u1 = UDPSocket.new
#      u1.bind($local_com_ip, Rho::RhoConfig.local_com_port)
#
#      u2 = UDPSocket.new
#      u2.send "hi", 0, $local_com_ip, Rho::RhoConfig.local_com_port
#
#      mesg, addr = u1.recvfrom(10)
#      u1.send mesg, 0, addr[3], addr[1]
#
#      p u2.recv(100) #=> "hi"
#      u1.flush()
#      u1.close()
#      u2.flush()
#      u2.close()
#      #      rescue Exception => ex
#      #        puts "PORT IS ALREADY IN USE"
#      #        Alert.show_popup(
#      #        :message=> "It seems application is already running.Please check the ports using 'netstat -an' using command prompt",
#      #        :title=>"Opened",
#      #        :buttons=>["Ok"]
#      #        )
#      #        Rho::Application.quit
#      #      end
#
#    end
    $msg_hash = {1600 => "1603", 1800 => "1801,1802",2603 => "2601",1118 => "1119",1200=>"1201,1203,1400",1204=>"1400",1401=>"1402,9998",1403=>"1405",1404=>"1405",2002=>"2002",2000=>"2000",2002=>"2003",2600=>"2601",2500=>"2501",1420=>"1421",1410=>"1411",3100=>"3101",3103 => "3104",3105=> "3106",3300 => "3301",1610=>"1611", 1700=> "1701"}

  end

  def on_deactivate_app
    puts "**********Application Have Been Deactivated.***************"
  end

  def on_ui_destroyed
    super
    if(!$loggedout && $loggedin == true)
      puts "CALLED LOGOUT"
      $no_of_wait_trails = 5
      $checkForITVArrivedFlag = false
      org_string = "device2" + Time.now.strftime("%d%m%Y%H%M%S")
      encoded_string = org_string.hash
      msg = "1~1~9999~#{encoded_string}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      puts "Send Request To Server On Destroying Application:- "+msg.inspect
      $udp_socket.send msg, 0, Rho::RhoConfig.com_server_ip,Rho::RhoConfig.com_server_port
    end
    if $udp_socket != nil
      $udp_socket.flush()
      $udp_socket.close()
    end
    if $poll_socket != nil
      $poll_socket.flush()
      $poll_socket.close()
    end
    puts "**********Application Have Been Destroyed.***************"
  end

  def serve( req, res )
    begin
      super
    rescue Exception => ex
      puts ex.to_s().inspect
      $no_of_wait_trails = 5
      if ($server_login_failure == true)
        WebView.execute_js("
          swal({
            text: 'Unable to Process your request',
            showCancelButton: false,
            allowOutsideClick: false,
            closeOnConfirm: true
            },
            function(isConfirm) {
              Rho.Application.quit()
            });")
      else
        WebView.execute_js("showAlerts('Unable to Process your request')")
      end
      raise
    end
  end

  def parse_instances(cmd)
    result = `#{cmd}`
    cmdLine = ""
    pid = ""
    raise("Error: " + result) unless $? == 0
    processes = []
    pinfo = nil
    result.split(/\r?\n/).each do |line|
      next if line =~ /^\s*$/
      if line =~ /CommandLine=(.*)/i
        cmdLine = $1
      elsif line =~ /ProcessId=(\d+)/i
        pid = $1
        processes << cmdLine + pid unless pid.to_i == $$.to_i
      end
    end

    return processes
  end
end