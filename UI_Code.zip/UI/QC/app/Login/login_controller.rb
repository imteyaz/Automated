class LoginController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include LoginHelper
  def index
    $myThread  = Thread.start{waitforITVArrived()}
  end

  #Setting UDP Connection
  def set_udp_connection
    $server_login_failure = true
    @msg=""
    if( @params['login'].empty? || @params['password'].empty?)
      @msg = "Un-Authorized_access"
      render :action => :index
    end
    $userid = @params['login'].upcase
    $session[:removedjobs] = Array.new
    @udp_req_obj[:msg] = "1~1~1200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['password']}~#{$device_id}~QC~#{@params['salt']}~#{@params['iv']}"
    $loggedout = false
    $completed_jobsrequest = false
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if(resp.length < 0)
      render :action => :index
    else
      $server_login_failure = false
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      #      if(resp_msg_id != 1201)
      #        $myThread  = Thread.start{waitforITVArrived()}
      #      end
      if(resp_msg_id == "1201") # Login failure
        @msg = resp_fields[3]
        render :action => :index
      elsif("1202" == resp_msg_id)
        servermessage = resp_fields[2]
        WebView.execute_js('showAlerts("'+ servermessage.to_s() + '")')
        render :action => :index
      elsif("1400" == resp_msg_id)
        @msges,@msg_non_operational,@msg_rt,@msges_list,@msges_loc,@msges_ter = processconfirmation_checklist(resp_fields)
        $loggedin = true
        render :action =>  :asignment_confirmation
      elsif(resp_msg_id == "1203")
        $loggedin = true
        @msg_lateLogin_reasons,@msg_lateby_mins = processlatelogin(resp_fields)
        render :action => :latelogin
      elsif(resp_msg_id=="1405")
        @resp_qc_job = processjoblist(resp_fields)
        $loggedin = true
        render :action => '../Qc/index'
      else
        $server_login_failure = false
        render :action => :index
      end
    end
  end

  # From late_login to Assignment_Confirmation
  def assign_confrm
    @udp_req_obj[:msg] = "1~1~1204~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['lateloginreason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1400" == resp_msg_id)
        @msges,@msg_non_operational,@msg_rt,@msges_list,@msges_loc,@msges_ter = processconfirmation_checklist(resp_fields)
        render :action => :asignment_confirmation
      else
        render :action => :index
      end
    else
      render :string => "Error"
    end
  end

  # From Assignment_Confirmation to Checklist
  def checklist
    remarks = ""
    if(@params['msges'] == "Non-Operational")
      if(@params['msges_non_operational'] == "Other")
        remarks = @params['remarks']
      else
        remarks = @params['msges_non_operational']
      end
    end
    $rotation_id = @params['msg_rt'].strip
    $vessel_name = @params['msg_rtname']
    $eqiptment_id = @params["msges_eq"]
    @udp_req_obj[:msg] = "1~1~1401~#{geteventid}~#{$userid}~#{ @params['msges_ter']}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{$rotation_id.to_s().split(' ')[0]}~#{@params['msges']}~#{ @params['msges_eq']}~#{ @params['msges_loc']}~#{remarks}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]

      if(resp_msg_id == "1402")
        resp_msg_checklist = resp_fields[2]
        if(resp_msg_checklist == "")
          redirect :action => :cancel
        end
        @resp_userid = resp_fields[3]
        @resp_termid = resp_fields[4]
        msg_checklist = resp_msg_checklist.to_s.split('|')
        @resp_checklist = Array.new
        msg_checklist.each do |check_list|
          @resp_checklist.push(check_list.to_s().split('^'))
        end
        render :action => :checklist
      elsif(resp_msg_id == "9998")
        res = resp_fields[3]
        WebView.execute_js('showAlerts("'+ res.to_s() + '")')
        render :string => "Error"
      else
        render :action => :assignment_confirmation
      end
    else
      WebView.execute_js("showAlerts('Server is not responding')")
      render :string => "Error"
    end
  end

  #Checklist Item Icon
  def get_checklist_item_icon(item_no)
    item_no_to_icon_map = {"1" => "chkimg", "2" => "chkimgalert", "3" => "chkimgerror"}
    return item_no_to_icon_map.fetch(item_no, "chkimg")
  end

  #Checklist Status
  def preOperationalChecklistStatus
    @params['chk_list'] ||= []
    completeChecklistStatus = (@params['chk_list'].map {|item| item = item + "^p" }).join("|")
    if completeChecklistStatus.length > 3900
      message_string =  completeChecklistStatus.scan(/.{1,1024}/)
      for iMsgindx in 1..message_string.length
        @udp_req_obj[:msg] = "iMsgindx~message_string.length~1403~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{message_string[iMsgindx]}~p"
        if(iMsgindx == message_string.length)
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        else
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
        end
      end
    else
      @udp_req_obj[:msg] = "1~1~1403~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{completeChecklistStatus}~p"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    end
    return resp
  end

  #QC Landing Page
  def qc_home
    resp = preOperationalChecklistStatus()
    $session[:removedjobs] = Array.new
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      if(resp_fields[0] == "1405")
        $promoted_jobs = Array.new
        @resp_qc_job = processjoblist(resp_fields)
        render :action => '../Qc/index'
      else
        render :action => :checklist
      end
    else
      render :string => "Error"
    end
  end

  #Joblist refresh from client
  def joblist
    @resp_qc_job = Array.new
    @filterval = "current_jobs"
    if @params["reqtype"].eql?("shuffle")
      @resp_qc_job = shufflingjobs(@params["containeritvinfo"])
    elsif @params["reqtype"].eql?("filter")
      @resp_qc_job = filterjobs(@params["containeritvinfo"])
      @filterval =  @params["containeritvinfo"]
    elsif @params["reqtype"].eql?("plcjobdone")
      @resp_qc_job = getlistaftrplcjobdone(@params["container_id"])
      @filterval =  @params["containeritvinfo"]
      if(@filterval != 'current_jobs')
        @resp_qc_job = filterjobs(@params["containeritvinfo"])
      end
      @filterval =  @params["containeritvinfo"]
    else
      getjoblist(@params["to_loc"],@params["from_location"],@params["categoryInfo"])
      @resp_qc_job = filterjobs(@params["containeritvinfo"])
    end
    twin_tandem_pairing
    if(@params["containeritvinfo"] == "current_jobs")
      @resp_qc_job = @resp_qc_job.sort{|x,y| x.seq_no.to_f<=>y.seq_no.to_f}
    end
    render :action => '../QC/joblist'
  end

  #bay front view request
  def bay_frontview
    outputstring = ""
    filter = ""
    getBayview = true;

    if($resp_qc_jobs.empty? && $completedjobs.empty? && @params["jobFilter"] == "")
      getBayview = false
    end

    if(getBayview && (($resp_qc_jobs.empty? && @params["jobFilter"] == "current_jobs") || (($completedjobs.empty? && @params["jobFilter"] == "jobs_completed"))))
      getBayview = false
    end

    if(getBayview)
      celllocationforleft,bjobavlble = getfirstjobcelllocation(@params["baylocation"]);

      tempCellLocation = celllocationforleft.split('.',-1)
      sendBayRequest = true
      tempCellLocation.each do |cellLocation|
        if(cellLocation == "")
          sendBayRequest = false
        end
      end

      if(bjobavlble && sendBayRequest)
        bayviewleft = getbayview(celllocationforleft,"C",1)
        if(!bayviewleft.empty?)
          updatelastcelllocation(celllocationforleft,bayviewleft)
          outputstring = bayviewleft
        end
      end
    end
    render :string=> outputstring
  end

  #jobs shuffle
  def shufflingjobs(containeritvinfo)
    reqparams = containeritvinfo.split('|')
    reqobjs = Array.new
    $resp_qc_jobs.delete_if {|v| reqobjs.push(v) if v.from_loc == reqparams[1]  || v.to_loc == reqparams[1]}
    reqobjs.each do |reqobj|
      $resp_qc_jobs = $resp_qc_jobs.unshift(reqobj)
    end
    return $resp_qc_jobs
  end

  #QC container movement
  def qc_container_move(container, from_location, to_location, movekind, category_info)
    puts "Normal confirmation"
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{container}~#{from_location}~#{to_location}~#{movekind}~#{category_info}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "1603")
      resp_fields[3] == "true" ? (return true) : (WebView.execute_js('showAlerts("'+ resp_fields[4] + '")');return false)
    else
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end
  end

  $checkForITVArrivedFlag = true

  def process_notification_response(resp)
    container = ""
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1306" || resp_msg_id == "1307" || resp_msg_id == "1308")
        processcontainerarrived(resp)
      elsif(resp_msg_id == "9001")
        processheavyhook(resp)
      elsif(resp_msg_id == "9997")
        processcontainerhandling(resp)
      elsif(resp_msg_id == "9995")
        processqcperformance(resp)
      elsif(resp_msg_id == "1601")
        processjobdone(resp)
      elsif(resp_msg_id == "9996")
        processdelayrecording(resp)
      elsif(resp_msg_id == "9998")
        processworkstopalert(resp)
      elsif(resp_msg_id == "9993")
        process_freeze_unfreeze_app(resp)
      elsif(resp_msg_id == "9994" || resp_msg_id == "9992" ||resp_msg_id == "9910")
        processnormalalertmessage(resp)
      elsif(resp_msg_id == "1405")
        updatejoblist(resp)
      elsif(resp_msg_id == "9002")
        backreachcontainermove(resp)
      elsif(resp_msg_id == "1602")
        removingjobs(resp)
      elsif(resp_msg_id == "2602")
        processbayupdate(resp)
      elsif(resp_msg_id=='9991')
        processjobcancel(resp)
      elsif(resp_msg_id=='9101')
        processplcactivedeactive(resp)
      elsif(resp_msg_id=='1800')
        addManualJobs(resp)
      elsif(resp_msg_id=='1801')
        deleteManualJobs(resp)
      elsif(resp_msg_id=='1407')
        updateTwinTandemSplitJobs(resp)
      elsif(resp_msg_id == "9999")
        forcelogout(resp)
      elsif(resp_msg_id == '1673')
        select_jobs(resp)
      elsif(resp_msg_id == "2213")
        process_damage_record_changed(resp)
      elsif(resp_msg_id == "1118")
        process_auto_updates(resp)
      else
        puts resp.inspect
      end
    end
  end

  #thread function for polling messages
  def waitforITVArrived
    resp = ""
    while($checkForITVArrivedFlag)
      begin
        resp = recv_response($udp_socket, 1, 1)
        Thread.new do
          process_notification_response(resp)
        end
      rescue Exception => ex
        puts("uncaught #{ex} exception while handling : #{ex.message}")
      end
    end
  end
  
  
def process_auto_updates(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2] != resp_fields[3])
      update_source_code(resp_fields[3])
    end
    return true
  end

  def update_source_code(version_no)
    #Download a file to the specified filename.
    begin
      #    downloadfileProps = Hash.new
      #    downloadfileProps["url"]='http://127.0.0.1:8082/ATOMMobileAppRel/HC/31-05-2017_HC.zip'
      #    downloadfileProps["filename"] = Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/31-05-2017_HC.zip")
      #    downloadfileProps["overwriteFile"] = true
      #    Rho::Network.downloadFile(downloadfileProps, url_for(:action => :download_file_callback))

      response = Net::HTTP.get_response(URI.parse(Rho::RhoConfig.auto_update_url+"/#{version_no}.zip"))
      File.open(Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip"), "wb") do |saved_file|
        saved_file.write(response.body)
      end

      puts "Finished downloading"
      puts "Creating folder"
      #    stdin, stdout, stderr = Open3.popen3('cscript C:\Users\1102519\Desktop\Projects\HC_UI_STD\public\unzip.vbs')
      #    parse_instances("bash C:/Users/1102519/Desktop/Projects/HC_UI_STD/public/unzip.vbs")

      system "cscript //nologo #{Rho::Application.publicFolder}/unzip.vbs #{Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip")} #{Rho::RhoConfig.path_to_extract}"
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~true~#{version_no}~"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      Rho::Application.quit
    rescue Exception => e
      puts "Exception in updating source code"
      puts e.message.inspect
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~false~#{version_no}~#{e.message.to_s()}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
    return true
  end


  #Cancel the pre checklist
  def cancel
    @udp_req_obj[:msg] = "1~1~1404~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      resp_qc_list = resp_fields[2].to_s.split('|')
      @resp_qc_job = Array.new
      resp_qc_list.each do |check_list_item|
        @resp_qc_job.push(check_list_item.to_s.split('^'))
      end
      if(resp_msg_id == "1405")
        $promoted_jobs = Array.new
        @resp_qc_job = processjoblist(resp_fields)
        render :action => '../Qc/index'
      else
        render :action => :checklist
      end
    else
      render :string => "Error"
    end
  end

  # Loging out
  def logout
    $checkForITVArrivedFlag  = false
    $loggedout = true
    $loggedin == false
    $completed_jobsrequest = false
    $force_logout_msg = ""
    $display_itv_pow = Array.new
    if (@params["force_logout"] != "true")
      @udp_req_obj[:msg] = "1~1~9999~#{geteventid}~#{ $userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    if($myThread.keys.length > 0)
      $myThread.exit
    end
    log_file_backup($userid)
    clearsession
    $checkForITVArrivedFlag  = true
    @msg = "Logged Out Successfully"
    if @params["force_logout"] == "true"
      $force_logout_msg = "You have been logged out forcefully by Administrator"
    end
    redirect :controller=> :Login, :action => :index
  end

  #forcefully logging out
  def forcelogout(resp)
    $forcelogout = true
    WebView.execute_js("window.location.href = '/app/Login/logout?force_logout=true'")
  end

  #method to get the job list and update incase of container move
  def getjoblist(to_loc,from_loc,category_info)
    #    if(!to_loc.empty?)
    containers = ""
    itvno = ""
    compltdjob = Array.new
    if($job_list_confirm.length > 0 && from_loc.to_s != "0")
      containers = $job_list_confirm.map(&:containerno).join("|")
      confirmSuccess = qc_container_move(containers,from_loc,to_loc,$job_list_confirm[0].code, category_info)
      if(confirmSuccess == true)
        from_locations = from_loc.split("|")
        to_locns = to_loc.split("|")
        index = to_locns.length
        $job_list_confirm.reverse_each do |joblist|
          index = index - 1
          joblist.from_loc = from_locations[index]
          joblist.to_loc = to_locns[index]
          joblist.exception_reason = ""
          $completedjobs.delete_if{|v| (v.containerno==joblist.containerno && v.code == joblist.code)}
          $completedjobs.unshift(joblist)
          $resp_qc_jobs.delete_if {|v| v.containerno ==  joblist.containerno && v.code == joblist.code}
        end
        $job_list_confirm = $job_list_confirm.clear
        $sleeptime  = 0
      else
        return false
      end
    end
    #    end
    return $resp_qc_jobs
  end

  #method for processing checklist
  def processconfirmation_checklist(resp_fields)
    msges = resp_fields[3].to_s.split("|")
    msg_non_operational = resp_fields[4].to_s.split("|")
    msg_rt = resp_fields[2].to_s.split("|")
    msges_list = "#{resp_fields[5]}"
    msges_loc = "#{resp_fields[6]}"
    msges_ter = "#{resp_fields[10]}"
    $terminal_id = msges_ter
    selectedLang = "#{resp_fields[7]}".to_s
    if !selectedLang.empty?
      System::set_locale(selectedLang)
    end
    return msges,msg_non_operational,msg_rt,msges_list,msges_loc,msges_ter
  end

  #method to process late login
  def processlatelogin(resp_fields)
    msg_lateLogin_reasons = resp_fields[3].split("|")
    msg_lateby_mins = resp_fields[2]
    return msg_lateLogin_reasons,msg_lateby_mins
  end

  # search jobs
  def searchjobs(container)
    resp_qc_job = Array.new
    if !container.empty?
      resp_qc_job = $resp_qc_jobs.select{|v| (v.containerno.include? container) || (v.from_loc.include? container) || (v.to_loc.include? container)}
    else
      resp_qc_job = $resp_qc_jobs
    end
    return resp_qc_job
  end

  #request for prev next bay
  def getprevnextbayrequest()
    outputstring = ""
    if(!$resp_qc_jobs.empty?)
      if(!$last_rendered_cell.empty?)
        leftcelllocation = getcelllocationforprevnext(@params["bprev"])
      else
        leftcelllocation,bjobavlble = getfirstjobcelllocation();
      end
      bayviewleft = getbayview_for_deck_type(leftcelllocation,"C",3,@params["bay_type"])
      if(!bayviewleft.empty?)
        $last_rendered_cell = leftcelllocation
        outputstring = bayviewleft
      end
    end
    render :string=> outputstring
  end

  #request for future bay view
  def futureBayview
    outputstring = ""
    if(!$resp_qc_jobs.empty?)
      bayviewleft = getbayview($last_rendered_cell,"F",2)
      outputstring = bayviewleft
    end
    render :string=> outputstring
  end

  #Get Qc Avilable Unavilable reason
  def getunavlblereasons
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2000~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2000")
        @msg = resp_fields[2].split("|")
        @open_delay_data = resp_fields[3]
      end
    end
    render :action => '../Qc/rmspopup_handling'
  end

  #Send Qc Unavilable Avilable reason
  def sendUnavailableRes
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~F~#{@params['rms_select']}~~#{@params['delayCloseInfo']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2003")
        @msg = resp_fields[2]
      end
    end
    render :action => '../Qc/rmspopup_handling'
  end

  #Send Qc Avilability time
  def sendAvailableRes
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~T~#{@params['selectedDelay']}~#{@params['available_time']}~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
    end
    render :string => "success"
  end

  #Exiting application
  def quit_app
    Rho::Application.quit
  end
  
def log_file_backup(user_id)
   begin
     log_file = Rho::Log
     file = File.open(log_file.filePath, "r")
     data = file.read
     file.close
     dt = DateTime.now
     if !(Dir.exists?(Rho::RhoConfig.log_backup_path))
       Dir.mkdir(Rho::RhoConfig.log_backup_path)
     end
     dt_str = dt.day.to_s+"_"+dt.month.to_s+"_"+dt.year.to_s+"_"+dt.hour.to_s+"_"+dt.minute.to_s+"_"+dt.second.to_s
     file_to_wrtite = Rho::RhoConfig.log_backup_path+"/"+user_id+dt_str+".txt"
     File.open(file_to_wrtite, "wb") do |backup_file|
       backup_file.write(data)
     end
     puts "Created log file"
      file = File.new(log_file.filePath, "w") do |actual_log_file|
       actual_log_file.write("Cleared")
     end
   rescue Exception => e
     WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
   end
 end
  
end