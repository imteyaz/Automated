class QcController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include LoginHelper
  def test_for_ajax
    render :action => "test_for_ajax",:layout => false,:use_layout_on_ajax => false
  end

  #itv pool request
  def search_itv
    @udp_req_obj[:msg] = "1~1~2500~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"   #event type can be modify in future
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2501")           #response msg Id can be modify in future
        display_itv = resp_fields[2].to_s.split("|")
        display_itv.each do |pow|
          $display_itv_pow.push(pow.to_s.split("^",2)[0])
        end
      end
    end
    return $display_itv_pow
  end

  # cqc container enquiry screen
  def getContainerEnqScreen
    @containerId = @params['containerNumber']
    render :action => '../ContainerEnquiry/container_enquiry'
  end

  # qc getting container details
  def getcontainerDetails
    containerNumber = @params['containerNumber']

    @udp_req_obj[:msg] = "1~1~1610~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerNumber}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_msg_id = resp.to_s.split("~")[0]
      if("1611" == resp_msg_id)
        render :string => resp
      elsif("1612" == resp_msg_id)
        render :string => "empty"
      else
        render :string => "error"
      end
    else
      render :string => "error"
    end
  end

  #container handing function
  def container_handling
    $job_list_confirm.clear
    cList = @params['container'].split("|")
    #if(@params['manual_confirm']=='true')
    $job_list_confirm  = $resp_qc_jobs.select{|v| (v.containerno == @params['container'] && v.code == @params['movekind']) || (v.refercontainer.include? @params['container'])}
    if $job_list_confirm.empty?
      $job_list_confirm = $completedjobs.select{|v| (v.containerno == @params['container']  && v.code == @params['movekind']) || (v.refercontainer.include? @params['container'])}
    end
    # else
    # $job_list_confirm  = $resp_qc_jobs.select{|v| cList.include? v.containerno && v. }
    # if $job_list_confirm.empty?
    # $job_list_confirm = $completedjobs.select{|v| cList.include? v.containerno}
    #end
    #end
    @joblist = $job_list_confirm
    @exception_reason = $completedjobs.select{|v| v.exception_reason if (v.containerno == @params['container'] && v.code == @params['movekind'])}
    if(@joblist.empty?)
      @exception_reason = "JOB NOT AVAILABLE"
      res = "CANCEL_JOB"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    else
      if(@joblist[0].code == "LOAD")
        @containers = getcontainerstringforload(@joblist)
      else
        @containers = getcontainerstringfordsch(@joblist)
      end
    end
    #    @itvlist = $session[:Itv_popup_image]
    #    if($display_itv_pow.empty?)
    #      if(@params['manual_confirm']=='true')
    #        $display_itv_pow = search_itv()
    #      end
    #    end
    render :action => 'container_handling'
  end

  def promoted_jobs
    @params["containers"] = @params["containers"].split('~')
    puts "promoted_jobs called"
    $promoted_jobs = Array.new
    @params["containers"].each do |container_id|
      puts container_id
      $promoted_jobs.push(container_id)
    end
  end

  def getcompletedjobs
    @udp_req_obj[:msg] = "1~1~1420~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      if(resp_fields[0] == "1421")
        $is_completed_jobsrequest = true
        $completedjobs = processjoblist(resp_fields,'cmpltd')
        $completed_jobsrequest = true
        twin_tandem_pairing
      end
    end
  end

  # Delay Recording
  def delay_recording
    @delayrecordingmess = @params['delayrecordingmessage']
    @delayrecordingmessage = @delayrecordingmess.to_s.split('|')
    render :action => :delay_recording
  end

  #request for delay recording reason
  def delayrecordingreason
    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1701" == resp_msg_id)
        render :string => resp
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  def recordNewDelay
    @udp_req_obj[:msg] = "1~1~1702~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['closeDelay']}~#{@params['selectedDelayReason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  #back reach move update to client
  def containerbackreachmove
    @backreachcontainermessage = @params['backreachcontainermessage']
    render :action => :backreach_jobs
  end

  #method for processing backreach container move
  def backreachcontainermove
    backcontainerno = @params['containernumber_data']
    backfromlocation = @params['fromlocation_data']
    backtolocation = @params['tolocation_data']
    backcontainerno = backcontainerno.to_s.upcase
    cIndex = $resp_qc_jobs.index{|v| (v.containerno==backcontainerno)}
    puts "backreachcontainer move called"
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['containernumber_data']}~#{@params['fromlocation_data']}~#{@params['tolocation_data']}~#{@params['type']}"

    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "1603")
      if(resp_fields[3] == "true")
        # $completedjobs.unshift(Joblist.new(movetype,containerno,'','','',fromloc,toloc,'','','','','','','','false',"manual"))
        if (@params['type'] == "DSCH")
          if(cIndex != nil)
            resp_qc_job = $resp_qc_jobs[cIndex]
            resp_qc_job.from_loc = backfromlocation
            resp_qc_job.to_loc = backtolocation
          else
            $resp_qc_jobs.unshift(Joblist.new('DSCH',backcontainerno,'','','',backfromlocation,backtolocation,'','','','','','','','false','false',"plc"))
          end
        else
          if(cIndex != nil)
            resp_qc_job = $resp_qc_jobs[cIndex]
            resp_qc_job.from_loc = backtolocation
            resp_qc_job.to_loc = backfromlocation
          else
            $resp_qc_jobs.unshift(Joblist.new('LOAD',backcontainerno,'','','',backfromlocation,backtolocation,'','','','','','','','false','false',"plc"))
          end
        end
        new_c_index = $resp_qc_jobs.index{|v| (v.containerno==backcontainerno)}
        $completedjobs.unshift($resp_qc_jobs[new_c_index])
        $resp_qc_jobs.delete_at(new_c_index)
      else
        WebView.execute_js('showAlerts("'+ resp_fields[4] + '")')
      end
    else
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end

    @resp_qc_job = $resp_qc_jobs
    render :action => 'joblist'
  end

  #processing backreach jobs
  def HatchcoverMancageBreakbulk_Request()
    # Added Load job
    #    @resp_qc_job,containerid,movetype,fromloc,toloc= addjobs(@params['request_type'],@params["mode"])
    containerid = @params['request_type']
    movetype = @params['mode']
    if (movetype == "DSCH")
      fromloc='VESSEL'
      toloc = 'BACKREACH'
    else
      fromloc='BACKREACH'
      toloc = 'VESSEL'
    end
    @udp_req_obj[:msg] = "1~1~1800~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerid}~#{movetype}~#{fromloc}~#{toloc}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if (resp.length > 0)
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1802" == resp_msg_id)
        puts "HatchcoverMancageBreakbulk_Request  called"
        @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{resp_fields[2]}~#{fromloc}~#{toloc}~#{movetype}"
        resp_job_com = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        if(resp_job_com.length > 0)
          resp_job_com_fields = resp_job_com.split("~")
          if(resp_job_com_fields[0] == "1603")
            $completedjobs.unshift(Joblist.new(movetype,resp_fields[2],'','','',fromloc,toloc,'','','','','','','','false','false',"manual"))   #adding manual created job in compleated jobs
          end
        end
      end
    end
    @resp_qc_job = $resp_qc_jobs
    render :action => 'joblist'
  end

  #adding backreach jobs to joblist
  def addjobs(request_type,mode="")
    reqparams = request_type
    containerno=""
    movetype = mode || "DSCH"
    from_loc='BACKREACH'
    to_loc = 'VESSEL'
    if(request_type=='MANCAGE')
      mankagejobs = ($resp_qc_jobs + $completedjobs).select{|v| v.containerno.include? 'MANCAGE'}
      mankage_dsch_index = mankagejobs.select{|v| v.code == "DSCH"}.length
      mankage_load_index=mankagejobs.select{|v| v.code == "LOAD"}.length
      mankageindex = 0
      mankageindex = mode == "DSCH" ? (mankage_dsch_index + 1).to_s : (mankage_load_index + 1).to_s
      containerno = 'MANCAGE '+ mankageindex.to_s()
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc='BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','','false','false',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','','false','false',"manual"))
      end
    elsif(request_type=='HATCHCOVER')
      hatchcoverjobs = ($resp_qc_jobs + $completedjobs).select{|v| (v.containerno.include? 'HATCHCOVER DSCH') || (v.containerno.include? 'HATCHCOVER LOAD')}
      hatchcoverindex=1
      if(!hatchcoverjobs.empty?)
        hatchcoverelems =Array.new
        hatchcoverjobs.each do |hatchcoverjob|
          hatchcoverelem = hatchcoverjob.containerno.delete "HATCHCOVER DSCH LOAD"
          hatchcoverelems.push(hatchcoverelem.strip.to_i())
        end
        hatchcoverelems = hatchcoverelems.sort{|x,y| y <=> x}
        hatchcover_dsch_index = hatchcoverjobs.select{|v| v.code == "DSCH"}.length
        hatchcover_load_index = hatchcoverjobs.select{|v| v.code == "LOAD"}.length
        hatchcoverindex = 0
        hatchcoverindex = mode == "DSCH" ? (hatchcover_dsch_index+ 1).to_s : (hatchcover_load_index + 1).to_s
      end
      containerno = 'HATCHCOVER '+movetype+" "+hatchcoverindex.to_s()
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc='BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','','false','false',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','','false','false',"manual"))
      end
    else
      breakbulkjobs = ($resp_qc_jobs + $completedjobs).select{|v| v.containerno.include? 'BREAKBULK '}
      breakbulk_dsch_index = breakbulkjobs.select{|v| v.code == "DSCH"}.length
      breakbulk_load_index=breakbulkjobs.select{|v| v.code == "LOAD"}.length
      breakbulkindex = 0
      breakbulkindex = mode == "DSCH" ? (breakbulk_dsch_index + 1).to_s : (breakbulk_load_index + 1).to_s
      containerno = 'BREAKBULK '+movetype+breakbulkindex.to_s()
      from_loc = 'VESSEL'
      to_loc = 'BACKREACH'
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc='BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','','false','false',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','','false','false',"manual"))
      end
    end
    return $resp_qc_jobs,containerno,movetype,from_loc,to_loc
  end

  #twin,tandem,split processing from UI
  def mergeJobs
    addContainerList = @params['addContainerList']
    reqType = @params["reqType"]
    is_tandem = @params["is_tandem"]
    movekind = @params["movekind"]
    if(reqType != "Cancel")
      twinpick = 1
      tandempick = 0
      targetIndex=""
      if(reqType == "Split")

        containerList=($resp_qc_jobs.select{|v| ( (v.refercontainer.include? addContainerList[0].to_s) || v.containerno==addContainerList[0] )})
        containerList.each {|cList|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        addContainerList = ordercontainerlist(addContainerList)
        addContainerList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(addContainerList,containerNo)
          #          if(twinpick == 0)
          #            twinpick=1
          #          else
          #            twinpick=0
          #          end
          resp_qc_job.refercontainer = refercontainer
          #          resp_qc_job.twinpick = twinpick

          #          if(reqType == "Tandem")
          #            resp_qc_job.tandempick = tandempick
          #            tandempick = tandempick + 1
          #          end
          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }
      end
      if(is_tandem == "40ft")
        reqType = "Tandem"
      elsif (is_tandem == "TANDEM_SPLIT")
        reqType = "TANDEM_SPLIT"
      else
        reqType = @params["reqType"]
      end

      @udp_req_obj[:msg] = "1~1~1407~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{reqType.upcase}~#{addContainerList.join("|")}~#{movekind}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    twin_tandem_pairing
    @resp_qc_job = filterjobs(@params["filterValue"])
    render :action => 'joblist'
  end

  #  request for upper or lower deck, deck will be decided based on the last rendered bay view cell location
  def upOrLowDeckBayview
    outputstring = ""
    if(!$resp_qc_jobs.empty?)
      lastrenderedlocations = getupperorlowerdeckcell()
      bayviewleft = getbayview_for_deck_type(lastrenderedlocations,"C",3,@params["bay_type"])
      if(!bayviewleft.empty?)
        $last_rendered_cell = lastrenderedlocations
        outputstring = bayviewleft
      end
    end
    render :string=> outputstring
  end

  #Deleating manually created Jobs
  def deleteJobs
    addContainerList = @params['addContainerList']
    check_for_hatch_cover = addContainerList[0].split("HATCHCOVER")
    if(check_for_hatch_cover.length > 1)
      addContainerList.push("HATCHCOVER" + check_for_hatch_cover[1])
      check_load_or_dsch = check_for_hatch_cover[1].split("DSCH")
      if check_load_or_dsch.length > 1
        addContainerList.push("HATCHCOVER " + "LOAD" + check_load_or_dsch[1])
      else
        addContainerList.push("HATCHCOVER " + "DSCH" + check_load_or_dsch[0].split("LOAD")[1])
      end
    end
    addContainerList = addContainerList.uniq
    @udp_req_obj[:msg] = "1~1~1801~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{addContainerList.join("|")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    addContainerList.each {|containerNo|
      cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
      if(cIndex != nil)
        $resp_qc_jobs.delete_at(cIndex)
      end
    }
    @resp_qc_job = filterjobs(@params["filterValue"])
    render :action => 'joblist'
  end

  #Start and Stop PLC
  def stop_start_plc
    startstopplc = @params['manual_mode']
    @udp_req_obj[:msg] = "1~1~9990~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{startstopplc}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  #Manually Refresh Joblist
  def joblist_refresh
    @udp_req_obj[:msg] = "1~1~3200~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~Updated Job List"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  #Get List of Languages from Server
  def getLanguagesList
    @udp_req_obj[:msg] = "1~1~1410~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1411" == resp_msg_id)
        @languagesList = resp_fields[2].to_s.split('|')
        render :action => :languages
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #Sending Selected language to server
  def setLanguage
    selectedLang = @params["selectedlang"]
    @udp_req_obj[:msg] = "1~1~1412~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{selectedLang}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      System::set_locale(selectedLang)
      render :action => :index
    else
      render :string => "Error"
    end
  end

  def ordercontainerlist(addContainerList)
    ordercontainerList= $resp_qc_jobs.select{|v|  addContainerList.include? v.containerno }
    orderedlist = Array.new
    ordercontainerList.each { |orderjob|
      orderedlist.push(orderjob.containerno)
    }
    return orderedlist
  end

  def deck_type
    render :string => @params["bay_data"].empty? ? "" : @params["bay_data"].split("~")[9]
  end

end