require 'socket'
require 'rho/rhocontroller'
require 'helpers/browser_helper'
require 'helpers/socket_helper'
require 'helpers/che_helper'
require 'rho/rhoapplication'
require 'time'
require 'date'
require 'net/http'
require 'uri'

class AppApplication < Rho::RhoApplication
  def initialize
    # Tab items are loaded left->right, @tabs[0] is leftmost tab in the tab-bar
    # Super must be called *after* settings @tabs!
    @tabs = nil
    #To remove default toolbar uncomment next line:
    @@toolbar = nil
    super
    @default_menu = {}
    $session ||= {}
    # Uncomment to set sync notification callback to /app/Settings/sync_notify.
    # Rho::RhoConnectClient.setObjectNotification("/app/Settings/sync_notify")
    Rho::RhoConnectClient.setNotification('*', "/app/Settings/sync_notify", '')
    $session[:removedjobs] = Array.new
    $session[:checkForMsg] = Array.new
    $session[:Itv_popup_image]= Array.new
    $job_list_confirm = Array.new
    $userid = ""
    $rmgequipmentid = ""
    $resp_qc_jobs = Array.new
    $completed_jobsrequest = false
    $plc_job_list_confirm = Array.new
    $completedjobs = Array.new
    $myThread ||= {}
    $msg_hash =  Hash.new("messages")
    $display_itv_pow = Array.new
    $poll_socket = nil
    $server_login_failure = false
    $loggedout = false
    $loggedin = false
    $jobSelection = false
    $jobSelectionMessage = ""
    # By default jobFilterIndex will be current jobs.
    $job_filter_value = "current_jobs"
    $jobConfirmation = true
    $notifications_array = Array.new
    $contr_edited = false
    
    $local_com_ip = Rho::RhoConfig.local_ip_to_use == "system" ? UDPSocket.open {|s| s.connect(Rho::RhoConfig.com_server_ip, 1); s.addr.last } : Rho::RhoConfig.local_com_ip
   #     $local_com_ip = UDPSocket.open {|s| s.connect('127.0.0.1', 1); s.addr.last }
    #    $local_com_ip = Socket.gethostname
    puts $local_com_ip.inspect
    puts "Local ip address"
    $device_id = (Rho::RhoConfig.device_selection == "device") ? Socket.gethostname : Rho::RhoConfig.deviceid
    puts $device_id.inspect
    puts "Device id"
  end

  def on_activate_app
    $msg_hash = {1200=>"1201,1203,1400,1405,1399",1204=>"1400,1399",1401=>"1402,9998",1403=>"1405",1404=>"1405",2002=>"2003",2000=>"2000",2600=>"2601",2500=>"2501",2100=>"2101",2200=>"2201",2203=>"2204",1420=>"1421",1410=>"1411",3100=>"3101", 3000=>"3001", 3002=>"3003", 1600=>"1603",1699=>"1670", 1671=>"1672",2210 => "2211" , 1610 => "1611,1612", 4000 => "4001", 4002 => "4003", 1700=> "1701",3032 => "3033",3040=>"3041" }
  end

  def on_ui_destroyed
    super
    if ($jobSelect)
      puts "Send Job Cancel request to for the selected Job -> "+$jobSelectionMessage
      $udp_socket.send $jobSelectionMessage, 0, Rho::RhoConfig.com_server_ip,Rho::RhoConfig.com_server_port
      $jobSelect = false
    end
    if(!$jobSelect && !$loggedout && $loggedin == true)
      $no_of_wait_trails = 5
      $checkForITVArrivedFlag = false
      org_string = "device2" + Time.now.strftime("%d%m%Y%H%M%S")
      encoded_string = org_string.hash
      msg = "1~1~9999~#{encoded_string}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      puts "Send Request To Server On Destroying Application:- "+msg.inspect
      $udp_socket.send msg, 0, Rho::RhoConfig.com_server_ip,Rho::RhoConfig.com_server_port
    end
    if $udp_socket != nil
      $udp_socket.flush()
      $udp_socket.close()
    end
    if $poll_socket != nil
      $poll_socket.flush()
      $poll_socket.close()
    end
    puts "**********Application Have Been Destroyed.***************"
  end

  def serve( req, res )
    begin
      super
    rescue Exception => ex
      puts ex.to_s().inspect
      $no_of_wait_trails = 5
      if ($server_login_failure == true)
        WebView.execute_js("
          swal({
            text: 'Unable to Process your request',
            showCancelButton: false,
            allowOutsideClick: false,
            closeOnConfirm: true
            },
            function(isConfirm) {
              Rho.Application.quit()
            });")
      else
        WebView.execute_js("showAlerts('Unable to Process your request')")
      end
      raise
    end
  end

  def on_deactivate_app
    puts "**********Application Have Been Deactivated.***************"
  end

  def parse_instances(cmd)
    result = `#{cmd}`
    cmdLine = ""
    pid = ""
    raise("Error: " + result) unless $? == 0
    processes = []
    pinfo = nil
    result.split(/\r?\n/).each do |line|
      next if line =~ /^\s*$/
      if line =~ /CommandLine=(.*)/i
        cmdLine = $1
      elsif line =~ /ProcessId=(\d+)/i
        pid = $1
        processes << cmdLine + pid unless pid.to_i == $$.to_i
      end
    end

    return processes
  end
end
