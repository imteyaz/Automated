class LoginController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include CheHelper
  #Setting UDP Connection
  def index
    $myThread  = Thread.start{waitforITVArrived()}
  end

  def set_udp_connection
    $server_login_failure = true
    @msg=""
    if( @params['login'].empty? || @params['password'].empty?)
      @msg = "Un-Authorized Access"
      render :action => :index
    end
    $userid = @params['login'].upcase
    $session[:removedjobs] = Array.new
    $completed_jobsrequest = false
    @udp_req_obj[:msg] = "1~1~1200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['password']}~#{$device_id}~RMG~#{@params['salt']}~#{@params['iv']}"
    $loggedout = false
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if(resp.length < 0)
      render :action => :index
    else
      $server_login_failure = false
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]

      #      if(resp_msg_id != 1201)
      #        $myThread  = Thread.start{waitforITVArrived()}
      #      end
      if(resp_msg_id == "1201") # Login failure
        @msg = resp_fields[3]
        render :action => :index
      elsif("1400" == resp_msg_id)
        @msges,@msg_non_operational,@msg_rt,@msges_list,@msges_loc,@msges_ter = processconfirmation_checklist(resp_fields)
        $rmgequipmentid = @msges_list
        $loggedin = true
        render :action =>  :asignment_confirmation
      elsif(resp_msg_id == "1203")
        $loggedin = true
        @msg_lateLogin_reasons,@msg_lateby_mins = processlatelogin(resp_fields)
        render :action => :latelogin
      elsif(resp_msg_id=="1405")
        @resp_qc_job = processjoblist(resp_fields)
        filterjobs("jobs_completed")
        render :action => '../Che/index'
      else
        $server_login_failure = false
        render :action => :index
      end
    end
  end

  # From late_login to Assignment_Confirmation
  def assign_confrm
    @udp_req_obj[:msg] = "1~1~1204~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['lateloginreason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      puts "ACK SENT #{resp}".inspect
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1400" == resp_msg_id)
        @msges,@msg_non_operational,@msg_rt,@msges_list,@msges_loc,@msges_ter = processconfirmation_checklist(resp_fields)
        $rmgequipmentid = @msges_list
        render :action => :asignment_confirmation
      else
        render :action => :index
      end
    else
      render :string => "Error"
    end
  end

  # From Assignment_Confirmation to Checklist
  def checklist
    blockRange = @params['fromBlock'].to_s
    $equipmentId = @params['msg_equipmentId'].to_s
    blockRange << "^"
    blockRange << @params['fromBlockNo'].to_s
    blockRange << "|"
    blockRange << @params['toBlockNo'].to_s
    @udp_req_obj[:msg] = "1~1~1401~#{geteventid}~#{$userid}~~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~~#{@params['msges']}~#{ @params['msges_eq']}~#{blockRange}~#{ @params['remarks']}"
    puts @udp_req_obj[:msg]
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      puts "ACK SENT #{resp}".inspect
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1402")
        resp_msg_checklist = resp_fields[2]
        if(resp_msg_checklist == "")
          redirect :action => :cancel
        end
        @resp_userid = resp_fields[3]
        @resp_termid = resp_fields[4]
        msg_checklist = resp_msg_checklist.to_s.split('|')
        @resp_checklist = Array.new
        msg_checklist.each do |check_list|
          @resp_checklist.push(check_list.to_s().split('^'))
        end
        render :action => :checklist
      elsif(resp_msg_id == "9998")
        res = resp_fields[3]
        WebView.execute_js('showAlerts("'+ res.to_s() + '")')
        render :string => "Error"
      else
        render :action => :assignment_confirmation
      end
    else
      render :string => "Error"
    end
  end

  #Checklist Item Icon
  def get_checklist_item_icon(item_no)
    item_no_to_icon_map = {"1" => "chkimg", "2" => "chkimgalert", "3" => "chkimgerror"}
    return item_no_to_icon_map.fetch(item_no, "chkimg")
  end

  #Checklist Status
  def preOperationalChecklistStatus
    @params['chk_list'] ||= []
    completeChecklistStatus = (@params['chk_list'].map {|item| item = item + "^p" }).join("|")
    if completeChecklistStatus.length > 3900
      message_string =  completeChecklistStatus.scan(/.{1,1024}/)
      for iMsgindx in 1..message_string.length
        @udp_req_obj[:msg] = "iMsgindx~message_string.length~1403~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{message_string[iMsgindx]}~p"
        p @udp_req_obj[:msg].inspect
        if(iMsgindx == message_string.length)
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        else
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
        end
      end
    else
      @udp_req_obj[:msg] = "1~1~1403~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{completeChecklistStatus}~p"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    end
    #puts completeChecklistStatus
    return resp
  end

  #QC Landing Page
  def che_home
    resp = preOperationalChecklistStatus()
    $session[:removedjobs] = Array.new
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      if(resp_fields[0] == "1405")
        @resp_qc_job = processjoblist(resp_fields)
        filterjobs("jobs_completed")
        render :action => '../Che/index'
      else
        render :action => :checklist
      end
    end
  end

  #Removing Jobs
  def shufflingjobs(containeritvinfo)
    reqparams = containeritvinfo.split('|')
    reqobjs = Array.new
    $resp_qc_jobs.delete_if {|v| reqobjs.push(v) if v.from_loc == reqparams[1]  || v.to_loc == reqparams[1]}
    reqobjs.each do |reqobj|
      $resp_qc_jobs = $resp_qc_jobs.unshift(reqobj)
    end
    return $resp_qc_jobs
  end

  #CHE container movement
  def qc_container_move(container, from_location, to_location, movekind, category_info)
    #    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{container}~#{from_location}~#{to_location}~#{movekind}~~"
    #    puts  @udp_req_obj[:msg].inspect
    #    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1) #not waiting for 1601 response for now. have to implement it. (last arg 2 instead of 1).
    #sealInformation = seal_ok_data.split("~")
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{container}~#{from_location}~#{to_location}~#{movekind}~#{category_info}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "1603")
      $jobSelection = false

      if resp_fields[3] == "false"
        $jobConfirmation = false
      else
        $jobConfirmation = true
      end

      resp_fields[3] == "true" ? (return true) : (WebView.execute_js('showAlerts("'+ resp_fields[4] + '")');return false)
    else
      # @udp_req_obj[:msg] = "1~1~2206~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{container}~#{from_location}~#{to_location}~#{container}^#{@params['pos_on_chs']}"
      #resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end
  end

  def containercheck()
    messagecheck=""
    if(!$session[:checkForMsg].empty?)
      messagecheck= $session[:checkForMsg].shift
    end
    render :string=>messagecheck
  end

  $checkForITVArrivedFlag = true

  #forcefully logging out
  def forcelogout(resp)
    $forcelogout = true
    WebView.execute_js("window.location.href = '/app/Login/logout?force_logout=true'")
  end

  def removingjobs(resp)
    puts "removingjobs"
    resp_fields = resp.to_s.split("~")
    container =  resp_fields[3]
    containerList = container.split('|')
    if resp_fields[4].to_s == "DELETE"      ########Delete
      puts "INSIDE DELETE"
      containerList.each {|containerNo|
        $resp_qc_jobs.delete_if {|v| (v.containerno + "^" + v.code) ==  containerNo}
      }
    elsif resp_fields[4].to_s == "TRANSFER"    ########Transfer
      puts "INSIDE TRANSFER"
      containerList.each {|containerNo|
        cIndex = $resp_qc_jobs.index{|v| (v.containerno + "^" + v.code) == containerNo}
        if(cIndex != nil)
          $completedjobs.push($resp_qc_jobs[cIndex])
          $resp_qc_jobs.delete_at(cIndex)
        end
      }
    end
    res = "REFRESH_JOBS"
    puts "SHUFFLING"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def updateJobReferDetails(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3].to_s() + "~" + resp_fields[4].to_s() + "~"  +  resp_fields[5].to_s()
    WebView.execute_js('updateJobListReferColor("'+ res.to_s() + '")')
  end

  # method for processing plc activation
  def processplcactivedeactive(resp)
    resp_fields = resp.to_s.split("~")
    if( resp_fields[3] == "true")
      res = "PLC_TRUE"
    else
      res = "PLC_FALSE"
    end
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def change_contr_edit_val
    $contr_edited = true
    puts $contr_edited.inspect
    render :string => true
  end

  def contr_edit_val_false
    $contr_edited = false
    render :string => true
  end

  def process_poll_request
    $notifications_array.each do |resp|
      if resp.length > 0
        resp_fields = resp.to_s.split("~")
        resp_msg_id = resp_fields[0]
        puts " Received--->"+resp_msg_id
        if(resp_msg_id == "1306" || resp_msg_id == "1307")
          puts "1306 or 1307 Received--->"
          processcontainerarrived(resp, resp_msg_id)
        elsif(resp_msg_id == "1308")
          processITVLeft(resp)
        elsif(resp_msg_id == "9001")
          processheavyhook(resp)
        elsif(resp_msg_id == "9997")
          processcontainerhandling(resp)
        elsif(resp_msg_id == "9995")
          processqcperformance(resp)
        elsif(resp_msg_id == "1601")
          processjobdone(resp)
        elsif(resp_msg_id == "1602")
          removingjobs(resp)
        elsif(resp_msg_id=='9991')
          processjobcancel(resp)
        elsif(resp_msg_id == "9996")
          processdelayrecording(resp)
        elsif(resp_msg_id == "9998")
          processworkstopalert(resp)
        elsif(resp_msg_id == "9993")
          process_freeze_unfreeze_app(resp)
        elsif(resp_msg_id == "9994" || resp_msg_id == "9992" ||resp_msg_id == "9910")
          processnormalalertmessage(resp)
        elsif(resp_msg_id == "1405")
          puts "In 1405"
          puts resp.inspect
          updatejoblist(resp)
        elsif(resp_msg_id == "2105")
          updateRmgPosition(resp_fields[2])
        elsif(resp_msg_id=='1407')
          updateTwinTandemSplitJobs(resp)
        elsif(resp_msg_id == "9999")
          puts "Force log out"
          forcelogout(resp)
        elsif(resp_msg_id == "1422")
          puts "updateJobReferDetails"
          updateJobReferDetails(resp)
        elsif(resp_msg_id == "2501")
          process_itv_pool(resp)
        elsif(resp_msg_id == "1670")
          puts "Job Selection Notification"
          highlightFirstJobDischarge(resp)
        elsif(resp_msg_id == "2213")
          process_damage_record_changed(resp)
        elsif(resp_msg_id == "9100")
          puts "ITV Waiting called"
          itv_waiting(resp)
        elsif(resp_msg_id=='9990' || resp_msg_id=='9101')
          processplcactivedeactive(resp)
        elsif(resp_msg_id == "1118")
          process_auto_updates(resp)
        elsif(resp_msg_id == "1309")
          update_completed_jobs(resp)
        else
          puts "In third port"
          puts resp.inspect
        end
      end
      $notifications_array.delete(resp)
    end
    #      $notifications_array = []
  end

  def waitforITVArrived
    resp = ""
    puts "Started looping"
    $checkForITVArrivedFlag = true
    puts $checkForITVArrivedFlag.inspect
    while($checkForITVArrivedFlag)
      begin
        resp = recv_response($udp_socket, 1, 1)
        puts "response from recv_response-->"+resp
        puts $contr_edited.inspect
        puts "Container edited mode"
        container = ""
        if $contr_edited != true
          if resp.length > 0
            resp_fields = resp.to_s.split("~")
            resp_msg_id = resp_fields[0]
            puts " Received--->"+resp_msg_id
            if(resp_msg_id == "1306" || resp_msg_id == "1307")
              puts "1306 or 1307 Received--->"
              processcontainerarrived(resp, resp_msg_id)
            elsif(resp_msg_id == "1308")
              processITVLeft(resp)
            elsif(resp_msg_id == "9001")
              processheavyhook(resp)
            elsif(resp_msg_id == "9997")
              processcontainerhandling(resp)
            elsif(resp_msg_id == "9995")
              puts "Performance"
              processqcperformance(resp)
            elsif(resp_msg_id == "1601")
              processjobdone(resp)
            elsif(resp_msg_id == "1602")
              removingjobs(resp)
            elsif(resp_msg_id=='9991')
              processjobcancel(resp)
            elsif(resp_msg_id == "9996")
              processdelayrecording(resp)
            elsif(resp_msg_id == "9998")
              processworkstopalert(resp)
            elsif(resp_msg_id == "9993")
              process_freeze_unfreeze_app(resp)
            elsif(resp_msg_id == "9994" || resp_msg_id == "9992" ||resp_msg_id == "9910")
              processnormalalertmessage(resp)
            elsif(resp_msg_id == "1405")
              puts "In 1405"
              puts resp.inspect
              updatejoblist(resp)
            elsif(resp_msg_id == "2105")
              updateRmgPosition(resp_fields[2])
            elsif(resp_msg_id=='1407')
              updateTwinTandemSplitJobs(resp)
            elsif(resp_msg_id == "9999")
              puts "Force log out"
              forcelogout(resp)
            elsif(resp_msg_id == "1422")
              puts "updateJobReferDetails"
              updateJobReferDetails(resp)
            elsif(resp_msg_id == "1670")
              puts "Job Selection Notification"
              highlightFirstJobDischarge(resp)
            elsif(resp_msg_id == "2213")
              process_damage_record_changed(resp)
            elsif(resp_msg_id == "9100")
              itv_waiting(resp)
            elsif(resp_msg_id == "1118")
              process_auto_updates(resp)
            elsif(resp_msg_id == "1309")
              update_completed_jobs(resp)
            else
              puts "In third port"
              puts resp.inspect
            end
          end
        else
          $notifications_array.push(resp) if !$notifications_array.include?(resp)
          puts $notifications_array.inspect
          puts "Notication array is as above as container is in edit mode"
        end
      rescue Exception => ex
        if(ex.to_s() != "execution expired")
          puts("#{ex} exception while handling : #{ex.message}")
        end
      end
    end
  end

def update_completed_jobs(resp)
  resp_fields = resp.to_s.split("~")
  if(resp_fields[2] == "false")
    containers = resp_fields[3].split("|")
    containers.each do |container|
      container_details = container.split("$")
      container_no = container_details[0]
      itv_no =  container_details[1]
      selected_jobs = $completedjobs.select{|v| (container_no.include? v.containerno + '^' + v.code)}
      selected_jobs.each do |selected_job|
        selected_job.to_loc = itv_no
      end
      res = "REFRESH_JOBS"
      WebView.execute_js('showAlerts("Swap change failed")')
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    end
  else
    WebView.execute_js('showAlerts("Swap change is successfull")')
  end
end

def log_file_backup(user_id)
   begin
     log_file = Rho::Log
     file = File.open(log_file.filePath, "r")
     data = file.read
     file.close
     dt = DateTime.now
     if !(Dir.exists?(Rho::RhoConfig.log_backup_path))
       Dir.mkdir(Rho::RhoConfig.log_backup_path)
     end
     dt_str = dt.day.to_s+"_"+dt.month.to_s+"_"+dt.year.to_s+"_"+dt.hour.to_s+"_"+dt.minute.to_s+"_"+dt.second.to_s
     file_to_wrtite = Rho::RhoConfig.log_backup_path+"/"+user_id+dt_str+".txt"
     File.open(file_to_wrtite, "wb") do |backup_file|
       backup_file.write(data)
     end
     puts "Created log file"
      file = File.new(log_file.filePath, "w") do |actual_log_file|
       actual_log_file.write("Cleared")
     end
   rescue Exception => e
     WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
   end
 end

  def process_auto_updates(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2] != resp_fields[3])
      update_source_code(resp_fields[3])
    end
    return true
  end

  def update_source_code(version_no)
    #Download a file to the specified filename.
    begin
      #    downloadfileProps = Hash.new
      #    downloadfileProps["url"]='http://127.0.0.1:8082/ATOMMobileAppRel/HC/31-05-2017_HC.zip'
      #    downloadfileProps["filename"] = Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/31-05-2017_HC.zip")
      #    downloadfileProps["overwriteFile"] = true
      #    Rho::Network.downloadFile(downloadfileProps, url_for(:action => :download_file_callback))

      response = Net::HTTP.get_response(URI.parse(Rho::RhoConfig.auto_update_url+"/#{version_no}.zip"))
      File.open(Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip"), "wb") do |saved_file|
        saved_file.write(response.body)
      end

      puts "Finished downloading"
      puts "Creating folder"
      #    stdin, stdout, stderr = Open3.popen3('cscript C:\Users\1102519\Desktop\Projects\HC_UI_STD\public\unzip.vbs')
      #    parse_instances("bash C:/Users/1102519/Desktop/Projects/HC_UI_STD/public/unzip.vbs")

      system "cscript //nologo #{Rho::Application.publicFolder}/unzip.vbs #{Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip")} #{Rho::RhoConfig.path_to_extract}"
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~true~#{version_no}~"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      Rho::Application.quit
    rescue Exception => e
      puts "Exception in updating source code"
      puts e.message.inspect
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~false~#{version_no}~#{e.message.to_s()}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
    return true
  end

  def processITVLeft(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2].empty?)
      $session[:Itv_popup_image].push(resp_fields[2])
    else
      contritvcomb =  resp_fields[2]
      cIndex = $session[:Itv_popup_image].index{|v| (v.split("#")[0]==contritvcomb)}
      $session[:Itv_popup_image].delete_at(cIndex)
      WebView.execute_js('removeITV("'+ contritvcomb + '")')
    end
  end

  #Cancel the pre checklist
  def cancel
    @udp_req_obj[:msg] = "1~1~1404~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    $session[:removedjobs] = Array.new
    if resp.length > 0
      puts "ACK SENT #{resp}".inspect
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]

      if(resp_msg_id == "1405")
        @resp_qc_job = processjoblist(resp_fields)
        filterjobs("jobs_completed")
        render :action => '../Che/index'
      else
        render :action => :checklist
      end
    end
  end

  # Loging out
  def logout
    $checkForITVArrivedFlag  = false
    $loggedout = true
    $loggedin = false
    $completed_jobsrequest = false
    $force_logout_msg = ""
    $contr_edited = false
    $job_filter_value = "current_jobs"
    if (@params["force_logout"] != "true")
      @udp_req_obj[:msg] = "1~1~9999~#{geteventid}~#{ $userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    if($myThread.keys.length > 0)
      $myThread.exit
    end
    log_file_backup($userid)
    clearsession
    $checkForITVArrivedFlag  = true
    @msg = "Logged Out Successfully"
    if @params["force_logout"] == "true"
      $force_logout_msg = "You have been logged out forcefully by Administrator"
    end
    redirect :controller=> :Login, :action => :index

  end

  def clearsession()
    $session[:checkForMsg].clear
    $session[:removedjobs].clear
    $notifications_array.clear
    # $session[:Itv_popup_image].clear
    $resp_qc_jobs.clear
    #$completedjobs.clear
    #$session[:bayfrontview_left] = ""
    #$session[:bayfrontview_right] = ""
    #$last_renderedview = 0
    #$job_list_confirm.clear
    #$last_rendered_cell = ""
    #$resp_qc_jobs.inspect
  end

  def getjoblist(to_loc,from_loc, troubleDamageClicked, category_info)
    if(!to_loc.empty?)
      containers = ""
      itvno = ""
      compltdjob = Array.new
      if($job_list_confirm.length > 0)
        containers = $job_list_confirm.map(&:containerno).join("|")
        #        if(troubleDamageClicked == "false")
        #
        #        end
        #from_locations = from_loc.split("|")
        if($job_list_confirm[0].code == "AH"  || $job_list_confirm[0].code == "LOAD" || $job_list_confirm[0].code == "DLVR" || $job_list_confirm[0].code == "YARD" || ($job_list_confirm[0].code == "DSCH" && troubleDamageClicked == "false") || ($job_list_confirm[0].code == "MO" && troubleDamageClicked == "false") || ($job_list_confirm[0].code == "GO" && troubleDamageClicked == "false") || ($job_list_confirm[0].code == "RH" && troubleDamageClicked == "false") || ($job_list_confirm[0].code == "RECV" && troubleDamageClicked == "false") || ($job_list_confirm[0].code == "MI" && troubleDamageClicked == "false" || ($job_list_confirm[0].code == "GI" && troubleDamageClicked == "false") ))
          qc_container_move(containers,from_loc,to_loc,$job_list_confirm[0].code, category_info)
          to_locns = to_loc.split("|")
          index=0

          $job_list_confirm.each do |joblist|
            #joblist.from_loc = from_locations[index]
            joblist.to_loc = to_locns[index]
            index += 1
            joblist.exception_reason = ""
            $completedjobs.delete_if{|v| (v.containerno==joblist.containerno && v.code == joblist.code )}
            if $jobConfirmation == true
              $completedjobs.unshift(joblist)
              $resp_qc_jobs.delete_if {|v| v.containerno ==  joblist.containerno && v.code == joblist.code }
            end
          end
        end
      end
      $job_list_confirm = $job_list_confirm.clear
      $sleeptime  = 0
      $completedjobs.inspect
    end

    if($job_filter_value == "current_jobs")
      puts $resp_qc_jobs.inspect
      return $resp_qc_jobs
    else
      puts $completedjobs.inspect
      return $completedjobs
    end

  end

  def processconfirmation_checklist(resp_fields)
    msges = resp_fields[3].to_s.split("|")
    msg_non_operational = resp_fields[4].to_s.split("|")
    msg_rt = resp_fields[2].to_s.split("|")
    msges_list = "#{resp_fields[5]}"
    msges_loc = "#{resp_fields[6]}"
    msges_ter = "#{resp_fields[10]}"
    $terminal_id = msges_ter
    selectedLang = "#{resp_fields[7]}".to_s
    if !selectedLang.empty?
      System::set_locale(selectedLang)
    end
    return msges,msg_non_operational,msg_rt,msges_list,msges_loc,msges_ter
  end

  def processlatelogin(resp_fields)
    msg_lateLogin_reasons = resp_fields[3].split("|")
    msg_lateby_mins = resp_fields[2]
    return msg_lateLogin_reasons,msg_lateby_mins
  end

  def searchjobs(container)
    resp_qc_job = Array.new
    if !container.empty?
      resp_qc_job = $resp_qc_jobs.select{|v| (v.containerno.include? container) || (v.from_loc.include? container) || (v.to_loc.include? container)}
    else
      resp_qc_job = $resp_qc_jobs
    end
    puts resp_qc_job.inspect
    return resp_qc_job
  end

  #  def filterjobs(container)
  #    resp_qc_job = Array.new
  #    if(container=="twin_handling")
  #      resp_qc_job = $resp_qc_jobs.select{|a| (a.twinpick != -1) && (a.tandempick == -1)}
  #    elsif(container=="current_jobs")
  #      resp_qc_job = $resp_qc_jobs
  #    elsif(container=="jobs_completed")
  #      resp_qc_job = $completedjobs
  #    elsif(container=="tandem_pick")
  #      resp_qc_job = $resp_qc_jobs.select{|a| a.tandempick != -1}
  #    end
  #    return resp_qc_job
  #  end

  def bay_frontview
    firstjob = $resp_qc_jobs.first
    if(firstjob.code == 'DSCH')
      celllocationforleft,celllocationforright = getcelllocationforbayview(@params["baylocation"],firstjob.from_loc)
    else
      celllocationforleft,celllocationforright = getcelllocationforbayview(@params["baylocation"],firstjob.to_loc)
    end
    bayviewleft = getbayview(celllocationforleft,"C")
    bayviewright = getbayview(celllocationforright,"C")
    $last_rendered_cell = celllocationforleft + "|" + celllocationforright
    outputstring = bayviewleft +"," +bayviewright
    render :string=> outputstring
  end

  def getprevnextbayrequest()
    leftcelllocation,rightcelllocation = getcelllocationforprevnext(@params["bprev"])
    bayviewleft = getbayview(leftcelllocation,"C")
    bayviewright = getbayview(rightcelllocation,"C")
    outputstring = bayviewleft +"," +bayviewright
    render :string=> outputstring
  end

  def futureBayview
    lastrenderedlocations = $last_rendered_cell.split("|")
    bayviewleft = getbayview(lastrenderedlocations[0],"F")
    bayviewright = getbayview(lastrenderedlocations[1],"F")
    outputstring = bayviewleft +"," +bayviewright
    render :string=> outputstring
  end

  #Get che Avilable Unavilable reason
  def getunavlblereasons
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2000~#{geteventid}~#{$userid}~#{$terminal_id}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2000")
        @msg = resp_fields[2].split("|")
        @open_delay_data = resp_fields[3]
      end
    end
    render :action => '../Che/rmspopup_handling'

  end

  def sendUnavailableRes
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~F~#{@params['rms_select']}~~#{@params['delayCloseInfo']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2003")
        @msg = resp_fields[2]
      end
    end
    render :action => '../Che/rmspopup_handling'
  end

  #Send che Avilability time
  def sendAvailableRes
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~T~#{@params['selectedDelay']}~#{@params['available_time']}~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
    end
    render :string => "success"
  end

  #Exiting application
  def quit_app
    Rho::Application.quit
  end

  def highlightFirstJobDischarge(resp)
    WebView.execute_js('highlightJobNotificationForDischarge("'+ resp.to_s() + '")')
  end

  def process_itv_pool(resp)
    $display_itv_pow = Array.new
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2501")
        display_itv = resp_fields[2].to_s.split("|")
        display_itv.each do |pow|
          $display_itv_pow.push(pow.to_s.split("^",2)[0])
        end
      end
    end
    return $display_itv_pow
  end

end
