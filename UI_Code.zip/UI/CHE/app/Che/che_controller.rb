class CheController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include CheHelper
  def test_for_ajax
    render :action => "test_for_ajax",:layout => false,:use_layout_on_ajax => false
  end

  def send_unavailable_reason

    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~F~#{@params['rms_select']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2003")
        @msg = resp_fields[2]
      end
    end
    render :action => '../Che/rmspopup_handling'

  end

  def search_itv
    @udp_req_obj[:msg] = "1~1~2500~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"   #event type can be modify in future
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    puts resp.inspect
    $display_itv_pow = Array.new
    if resp.length > 0
      puts "ACK SENT #{resp[0]}".inspect
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      puts resp_fields.inspect
      if(resp_msg_id == "2501")           #response msg Id can be modify in future
        $display_itv_pow = resp_fields[2].to_s.split("|")
      end
    end
    return $display_itv_pow
  end

  # Damage Recording
  def submitData
    @container= @params['container']
    @udp_req_obj[:msg] = "1~1~9000~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['container_id']}~#{@params['damage_data']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length>0
      render :string=>"Success"
    else
      render :string=>"failure"
    end
  end

  def getdamageCrctnScreen
    render :action => :damageCorrection
  end

  def getContainerEnqScreen
    @containerId = @params['containerNumber']
    render :action => '../ContainerEnquiry/container_enquiry'
  end

  def getcontainerDetails
    containerNumber = @params['containerNumber']

    @udp_req_obj[:msg] = "1~1~1610~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerNumber}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_msg_id = resp.to_s.split("~")[0]
      if("1611" == resp_msg_id)
        render :string => resp
      elsif("1612" == resp_msg_id)
        render :string => "empty"
      else
        render :string => "error"
      end
    else
      render :string => "error"
    end
  end

  def getDmgeDtlsForCntnr
    #1\7e1\7e2211\7eeventId\7econtainerId\7eDamagetype1^code1#loc1&loc2&loc3#sevr|code2#loc1&loc2&loc3#sevr|code3#loc1&loc2&loc3#sevr$DamageType2^code3#loc1&loc2&loc3#sevr|code4#loc1&loc2&loc3#sevr|code5#loc1&loc2&loc3#sevr\7eId^type^severity^code^location^loc1&loc2&loc3|Id^type^severity^code^location^loc1&loc2&loc3\7euserId\7eTerminalId
    containerId = @params["containerID"]
    @udp_req_obj[:msg] = "1~1~2210~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2211")
        @containerId = resp_fields[2]
        @dmgeTypeDtls= resp_fields[3]
        @dmgeRecDetails= resp_fields[4].split('|')

        #New code added for grid
        @dmge_details = resp_fields[3].split("$")
        #New code ended for grid

        render :partial =>"damage_correct_partial", :locals => { :ad => "foo_ad" }
      else
        render :string => "false"
      end
    end
  end

  #Start and Stop PLC
  def stop_start_plc
    startstopplc = @params['manual_mode']
    @udp_req_obj[:msg] = "1~1~9990~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{startstopplc}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  # Delay Recording
  def delay_recording
    @delayrecordingmess = @params['delayrecordingmessage']
    @delayrecordingmessage = @delayrecordingmess.to_s.split('|')
    render :action => :delay_recording
  end

  #  #request for delay recording reason
  #  def delayrecordingreason
  #    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
  #    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  #  end

  def update_job_filter_change
    $job_filter_value = @params["jobFilterValue"].to_s()
  end

  def container_handling
    $job_list_confirm.clear
    @pos_on_chers = ["F","C","A"]
    cList = @params['container'].split("|")
    @container_position = @params['container_position']
    @container_position = (@container_position == "F") ? "FORWARD" : (@container_position == "A" ? "AFT" : "CENTER")
    @containerLength = @params['containerLength']
    if(@params['manual_confirm']=='true')
      #$job_list_confirm  = $resp_qc_jobs.select{|v| v.containerno == @params['container'] || (v.refercontainer.include? @params['container'])}
      $job_list_confirm  = $resp_qc_jobs.select{|v| v.containerno == @params['container'] && v.code == @params["movekind"]}
      if $job_list_confirm.empty?
        #$job_list_confirm = $completedjobs.select{|v| v.containerno == @params['container'] || (v.refercontainer.include? @params['container'])}
        $job_list_confirm = $completedjobs.select{|v| v.containerno == @params['container'] && v.code == @params["movekind"]}
      end
    else
      $job_list_confirm  = $resp_qc_jobs.select{|v| cList.include? v.containerno }
      if $job_list_confirm.empty?
        $job_list_confirm = $completedjobs.select{|v| cList.include? v.containerno }
      end
    end
    @joblist = $job_list_confirm
    @exception_reason = $completedjobs.select{|v| v.exception_reason if cList.include? v.containerno}
    if(@joblist.empty?)
      @exception_reason = "JOB NOT AVAILABLE"
      res = "CANCEL_JOB"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    else
      if(@joblist[0].code == "LOAD")
        @containers = getcontainerstringforload(@joblist)
      else
        @containers = getcontainerstringfordsch(@joblist)
      end
    end
    @itvlist = $session[:Itv_popup_image]
    if($display_itv_pow.empty?)
      if(@params['manual_confirm']=='true')
        $display_itv_pow = search_itv()
      end
    end
    render :action => 'container_handling'
  end

  # Swap feature

  def send_pos_on_chas
    $resp_qc_jobs.each {|v| v.container_position = @params['pos_on_chs'] if @params['container_no'] == v.containerno}
    $completedjobs.each {|v| v.container_position = @params['pos_on_chs'] if @params['container_no'] == v.containerno}
    if  @params['itv_no'] != ""
      itv_no = @params['itv_no'].split("|")[0]
    else
      itv_no = ""
    end
    if itv_no != ""
      @udp_req_obj[:msg] = "1~1~2206~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{itv_no}~#{@params['container_no']}^#{@params['pos_on_chs']}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    render :string => true
  end

  #Get List of Languages from Server
  def getLanguagesList
    @udp_req_obj[:msg] = "1~1~1410~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1411" == resp_msg_id)
        @languagesList = resp_fields[2].to_s.split('|')
        render :action => :languages
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #Sending Selected language to server
  def setLanguage
    selectedLang = @params["selectedlang"]
    @udp_req_obj[:msg] = "1~1~1412~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{selectedLang}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      System::set_locale(selectedLang)
      render :action => :index
    else
      render :string => "Error"
    end
  end

  # Delay Recording
  def delayrecordingreason
    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1701" == resp_msg_id)
        render :string => resp
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  def recordNewDelay
    @udp_req_obj[:msg] = "1~1~1702~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['closeDelay']}~#{@params['selectedDelayReason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  #Manually Refresh Joblist
  def joblist_refresh
    @udp_req_obj[:msg] = "1~1~3200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~Updated Job List"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def saveData
    @container= @params['container']
    @udp_req_obj[:msg] = "1~1~2502~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['container_id']}~#{@params['iso_data']}~#{@params['weight_data']}~~~~~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length>0
      render :string=>"Success"
    else
      render :string=>"failure"
    end
  end

  def alert_message
    @alertmessage = @params['alertmessage']
    render :action => "alert_message",:layout => false,:use_layout_on_ajax => false
  end

  def HatchcoverMancageBreakbulk_Request()
    @resp_qc_job,containerid = addjobs(@params['request_type'])
    @udp_req_obj[:msg] = "1~1~1800~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerid}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if(@params['request_type'] != "BREAKBULK")
      containerid = containerid.gsub("LOAD","DSCH")
      @udp_req_obj[:msg] = "1~1~1800~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerid}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    render :action => 'joblist'
  end

  def addjobs(request_type)
    reqparams = request_type
    containerno=""
    if(request_type=='MANCAGE')
      mankagejobs = $resp_qc_jobs.select{|v| v.containerno.include? 'MANCAGE DSCH'}
      mankageindex=1
      if(!mankagejobs.empty?)
        mankageindex = mankagejobs.length+1
      end
      containerno = 'MANCAGE LOAD'+mankageindex.to_s()
      $resp_qc_jobs.unshift(Joblist.new('LOAD','MANCAGE LOAD'+mankageindex.to_s(),'','','','BACKREACH','VESSEL','','','','','','',''))
      $resp_qc_jobs.unshift(Joblist.new('DSCH','MANCAGE DSCH'+mankageindex.to_s(),'','','','VESSEL','BACKREACH','','','','','','',''))
    elsif(request_type=='HATCHCOVER')
      hatchcoverjobs = $resp_qc_jobs.select{|v| v.containerno.include? 'HATCHCOVER DSCH'}
      hatchcoverindex=1
      if(!hatchcoverjobs.empty?)
        hatchcoverindex = hatchcoverjobs.length+1
      end
      containerno = 'HATCHCOVER LOAD'+hatchcoverindex.to_s()
      $resp_qc_jobs.unshift(Joblist.new('DSCH','HATCHCOVER DSCH'+hatchcoverindex.to_s(),'','','','VESSEL','BACKREACH','','','','','','',''))
      $resp_qc_jobs.push(Joblist.new('LOAD','HATCHCOVER LOAD'+hatchcoverindex.to_s(),'','','','BACKREACH','VESSEL','','','','','','',''))
    else
      breakbulkjobs = $resp_qc_jobs.select{|v| v.containerno.include? 'BREAKBULK DSCH'}
      breakbulkindex=1
      if(!breakbulkjobs.empty?)
        breakbulkindex = breakbulkindex.length+1
      end
      containerno = 'BREAKBULK DSCH'+breakbulkindex.to_s()
      $resp_qc_jobs.unshift(Joblist.new('LOAD',containerno,'','','','BACKREACH','VESSEL','','','','','','',''))
    end
    return $resp_qc_jobs,containerno
  end

  def mergeJobs
    addContainerList = @params['addContainerList']
    reqType = @params['reqType']
    if(reqType != "Cancel")
      twinpick = 1
      tandempick = 0
      targetIndex=""
      if(reqType == "Split")
        containerList=($resp_qc_jobs.select{|v| ( (v.refercontainer.include? addContainerList[0].to_s) || v.containerno==addContainerList[0] )})
        containerList.each {|cList|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        addContainerList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(addContainerList,containerNo)
          if(twinpick == 0)
            twinpick=1
          else
            twinpick=0
          end
          resp_qc_job.refercontainer = refercontainer
          resp_qc_job.twinpick = twinpick

          if(reqType == "Tandem")
            resp_qc_job.tandempick = tandempick
            tandempick = tandempick + 1
          end

          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }
      end
      @udp_req_obj[:msg] = "1~1~1407~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{reqType.upcase}~#{addContainerList.join("|")}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end

    puts  @resp_qc_job.inspect
    render :action => 'joblist'
  end

  def getTroubleShootView
    @udp_req_obj[:msg] = "1~1~2200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @joblist = $job_list_confirm
    if resp.length > 0
      puts resp.inspect
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2201")
        @troubleshootarea = resp_fields[2].to_s.split('|')
        @troubleshootcodedesc = resp_fields[3].to_s.split('|')
      end
    end
    render :action => :troubleshoot
  end

  def getDamageRecordView
    @movekind = @params["movekind"]
    @udp_req_obj[:msg] = "1~1~2203~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @containers = @params["containers"].split("|")
    @itvs = @params["itvs"].split("|")
    @ground= @params["ground"].split("|")
    @joblist = $job_list_confirm
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2204")
        @damage_areas = resp_fields[2].to_s.split('|')
        @damage_code_desc = resp_fields[3].to_s.split('|')
        render :action => :damagerecord
      else
        render :string => "false"
      end
    end
  end

  def sendDamageRecordReq
    #    containerNo = @params['container_select']
    #    itvNo = @params['cntr_to_location']
    #    trouble_shoot_area = @params['trouble_shoot_area']
    #    @udp_req_obj[:msg] = "1~1~2205~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerNo}~#{trouble_shoot_area}~#{itvNo}~#{@params['movekind']}"
    #    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    #

    all_dmgs = $resp_qc_jobs + $completedjobs
    dmg_cntrs = all_dmgs.select{|d| @params["containers"].include?(d.containerno+'^'+d.code)}
    puts dmg_cntrs.inspect
    dmg_cntrs.each do |dmg_cntr|
      dmg_cntr.is_damaged = "true"
      puts dmg_cntr.inspect
    end

    damage_details = @params["damage_details"]
    msg_to_send = ""
    damage_details.each do |dmg_recrd|
      msg_to_send += dmg_recrd
      if dmg_recrd != damage_details.last
        msg_to_send += "$"
      end
    end
    movekind = @params['movekind']

    @udp_req_obj[:msg] = "1~1~2205~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{msg_to_send}~#{movekind}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)

  end

  def sendTroubleShootReq
    #1~1~2202~783511536~user1~2~Friday 20-Mar-2015 12:44:18~CNTR123|CNTR234~ITV12~YRD123~ERR123|ERR234
    selected_containers = @params['selected_containers']
    selected_to_location = @params['selected_to_location']
    troubleshoot_message = @params['troubleshoot_message']
    @udp_req_obj[:msg] = "1~1~2202~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{selected_containers}~#{selected_to_location}~#{troubleshoot_message}~#{@params['movekind']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def prepareRefContainer(addContainerList,containerNo)
    refercontainer=""
    refercontainer=(addContainerList.select {|cNo|  cNo !=containerNo }).join('#')
    return refercontainer
  end

  #  request for upper or lower deck, deck will be decided based on the last rendered bay view cell location
  def upOrLowDeckBayview
    lastrenderedlocations = getupperorlowerdeckcell()
    lastrenderedlocations.inspect
    bayviewleft = getbayview(lastrenderedlocations[0],"C")
    bayviewright = getbayview(lastrenderedlocations[1],"C")
    outputstring = bayviewleft +"," +bayviewright
    render :string=> outputstring
  end

  def stackView
    @udp_req_obj[:msg] = "1~1~3002~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['blockNumber']}~#{@params['stackNumber']}~#{@params['getStack']}"
    @respStackView  = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    #puts @respStackView
    render :string => @respStackView
  end

  def generate_stack_view_popup
    render :action => :stack_view
  end

  def send_swap_request
    itvNo = @params['itvNo']
    containerno = @params['containerno']
    @udp_req_obj[:msg] = "1~1~2206~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{itvNo}~#{containerno}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def job_selection_request
    containerno = @params['containerno']
    movekind = @params['movekind']
    yardLocation = @params['yardLocation']
    request_params = [containerno,movekind,yardLocation];
    @udp_req_obj[:msg] = get_job_selection_request_string("1699" ,request_params)
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      if(resp_fields[0] == "1670")
        if(resp_fields[2] == "true") # status is true
          $jobSelection = true
          $jobSelectionMessage = get_job_selection_request_string("1699" ,request_params)
          render :string => "true"
        else
          render :string => resp_fields[3] # error message
        end
      else
        render :string => "error"
      end
    end
  end

  def cancel_job_selection_request
    containerno = @params['containerno']
    movekind = @params['movekind']
    request_params = [containerno,movekind];
    @udp_req_obj[:msg] = get_job_selection_request_string("1671" ,request_params)
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      if(resp_fields[0] == "1672")
        if(resp_fields[2] == "true") # status is true
          $jobSelection = false
          render :string => "true"
        else
          render :string => resp_fields[3] # error message
        end
      else
        render :string => "error"
      end
    end
  end

  def get_job_selection_request_string(request_type_id, request_params)
    request = "1~1~#{request_type_id}~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    request_params.each do |param|
      request += "~#{param}"
    end
    return request
  end

  def sendDamageCorrectData
    containerId = @params["containerNumber"]
    updatedRecords=@params["oldDamageRecords"]
    deletedRecords= @params["deletedDamageCodes"]
    addedRecords=@params["newDamageRecords"]
    remarks=@params["remarks"]

    @udp_req_obj[:msg] = "1~1~2212~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}~#{updatedRecords}~#{deletedRecords}~#{addedRecords}~#{remarks}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def getContainerInventoryUpdate
    puts "In getContainerInventoryUpdate action---->"
    @containerNoForInventory =  @params["containerNumber"]
    #@stackPosition = @params["stackPosition"]
    render :action => 'stackInventoryUpdate'
  end

  def stack_popup
    @yard_pos = @params["yard_position"]
    @container_no = @params["container_number"]
    @is_damaged = @params["is_damaged"]
    render :action => "stack_popup"
  end

  def stck_inv_view
    @container_no = @params["container_number"]
    @from_loc = @params["yard_pos"]
    @header = @params["heading"]
    render :action => "stck_inv_view"
  end

  def stck_shuff_view
    @container_no = @params["container_number"]
    @udp_req_obj[:msg] = "1~1~3040~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{ @params["container_number"]}~#{@params["yrd_pos"]}~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s().split("~")
    if(resp_fields[0] == "3041")
      if(resp_fields[3] == "true") # status is true
        render :string => "true"
      else
        render :string => resp_fields[4] # error message
      end
    else
      render :string => "error"
    end
  end

  def get_container_update_popup
    render :action => 'container_update_popup'
  end

  def get_changed_data(params_data)
    if($container_attributes_server[3] == params_data['upd_line_code'])
      params_data['upd_line_code'] = ''
    end
    if($container_attributes_server[4] == params_data['upd_category'])
      params_data['upd_category'] = ''
    end
    if($container_attributes_server[5].to_s().downcase == params_data['upd_empty'].to_s().downcase)
      params_data['upd_empty'] = ''
    end

    if(params_data['iso_select'].to_s() == "--Please select--")
      params_data['iso_select'] = ''
    end

    if($container_attributes_server[7] == params_data['upd_pod'])
      params_data['upd_pod'] = ''
    end
    if($container_attributes_server[8] == params_data['upd_npod'])
      params_data['upd_npod'] = ''
    end
    if($container_attributes_server[9] == params_data['upd_fpod'])
      params_data['upd_fpod'] = ''
    end
    if($container_attributes_server[10] == params_data['upd_size'])
      params_data['upd_size'] = ''
    end
    if($container_attributes_server[11] == params_data['upd_weight'])
      params_data['upd_weight'] = ''
    end
    if($container_attributes_server[12].split('/')[0] == params_data['dim_front'])
      #params_data['dim_front'] = ''
    end
    if($container_attributes_server[12].split('/')[1] == params_data['dim_bottom'])
      #params_data['dim_bottom'] = ''
    end
    if($container_attributes_server[12].split('/')[2] == params_data['dim_left'])
      #params_data['dim_left'] = ''
    end
    if($container_attributes_server[12].split('/')[3] == params_data['dim_right'])
      #params_data['dim_right'] = ''
    end
    if($container_attributes_server[12].split('/')[4] == params_data['dim_top'])
      #params_data['dim_top'] = ''
    end
    if($container_attributes_server[13] == params_data['upd_plug'])
      params_data['upd_plug'] = ''
    end
    if($container_attributes_server[14] == params_data['upd_vessel'])
      params_data['upd_vessel'] = ''
    end
    if($container_attributes_server[15] == params_data['upd_out_vessel'])
      params_data['upd_out_vessel'] = ''
    end
    if($container_attributes_server[16] == params_data['upd_voyage'])
      params_data['upd_voyage'] = ''
    end
    if($container_attributes_server[17] == params_data['upd_out_voyage'])
      params_data['upd_out_voyage'] = ''
    end
    if($container_attributes_server[18] == params_data['upd_seal_1'])
      params_data['upd_seal_1'] = ''
    end
    if($container_attributes_server[19] == params_data['upd_seal_2'])
      params_data['upd_seal_2'] = ''
    end
    if($container_attributes_server[20] == params_data['upd_seal_3'])
      params_data['upd_seal_3'] = ''
    end
    if($container_attributes_server[21] == params_data['upd_seal_4'])
      params_data['upd_seal_4'] = ''
    end
    if($container_attributes_server[22] == params_data['upd_seal_5'])
      params_data['upd_seal_5'] = ''
    end

    return params_data
  end

  def update_container_attributes
    @params = get_changed_data(@params)
    container_data = "#{$container_attributes_server[2]}~#{@params['upd_line_code']}~#{@params['upd_category']}~#{@params['upd_empty']}~#{@params['iso_select']}~#{@params['upd_pod']}~#{@params['upd_npod']}~#{@params['upd_fpod']}~#{@params['upd_size']}~#{@params['upd_weight']}~#{@params['dim_front']}/#{@params['dim_bottom']}/#{@params['dim_left']}/#{@params['dim_right']}/#{@params['dim_top']}~#{@params['upd_plug']}~#{@params['upd_vessel']}~#{@params['upd_out_vessel']}~#{@params['upd_voyage']}~#{@params['upd_out_voyage']}~#{@params['upd_seal_1']}~#{@params['upd_seal_2']}~#{@params['upd_seal_3']}~#{@params['upd_seal_4']}~#{@params['upd_seal_5']}"
    @udp_req_obj[:msg] = "1~1~4002~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~" + container_data
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "4003")
        if(resp_fields[2] == "true")
          render :string => "true"
        else
          WebView.execute_js('showAlerts("'+ resp_fields[3].to_s() + '")')
          render :string => "false"
        end
      else
        render :string => "error"
      end
    end
  end

  def get_container_attributes
    containerId = @params["containerNumber"]
    @udp_req_obj[:msg] = "1~1~4000~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "4001")
        @container_attributes = resp_fields
        $container_attributes_server = resp_fields
        render :partial =>"container_attributes_partial", :locals => { :ad => "foo_ad" }
      else
        render :string => "false"
      end
    end
  end

  def stack_inv_update
    @udp_req_obj[:msg] = "1~1~3032~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params["containerNumber"]}~#{@params["from_loc"]}~#{@params["to_loc"]}~#{@params["movekind"]}~~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "3033")
      resp_fields[2] == "true" ? (render :string => "true") : (render :string => resp_fields[3])
    else
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end
  end

end
