module CheHelper
  class Joblist
    include Enumerable
    attr_accessor :code,:containerno,:iso,:country,:wght,:from_loc,:to_loc,:remarks,:refercontainer,:colorcode,:twinpick,:tandempick,:st,:cat,:bay,:tier,:row,:alternatecell,:jobtype,:sparcsexception,:exception_reason,:length,:priority, :priorityColor, :order_id, :cntr_status,:is_damaged, :container_position,:cntr_status
    def initialize(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st,is_damaged="false",container_position="F",cntr_status="",jobtype="planned",sparcsexception="N",exception_reason="",length="0",priority="", priorityColor="", order_id="")
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st,is_damaged,container_position,cntr_status,jobtype,sparcsexception,exception_reason,length,priority, priorityColor, order_id)
    end

    def updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st,is_damaged="false",container_position="F",cntr_status="",jobtype="planned",sparcsexception="N",exception_reason="", length="0",priority="", priorityColor="", order_id="")
      @jobtype = jobtype
      @sparcsexception = sparcsexception
      @exception_reason = exception_reason
      @code = code
      @containerno = containerno.upcase
      @iso = iso
      @country = country
      @wght = wght
      @length = length
      @from_loc = from_loc
      @to_loc = itvno
      @remarks  =remarks
      @colorcode = colorcode
      if(st == 'true')
        @st = 'M'
      else
        @st = 'F'
      end
      @container_position = container_position
      @is_damaged = is_damaged
      @cat = cat
      @twinpick = -1
      @tandempick = -1
      @refercontainer =""
      if(!refercontainer.nil? && !refercontainer.empty?)
        @refercontainer =refercontainer
        @twinpick = twinpick
        @tandempick = tandempick
      end
      if(code == "DSCH" || code == "RECV")
        cellvalues = to_loc.split(".")
      elsif(code== "LOAD" || code == "YARD" || code == "DLVR")
        cellvalues = from_loc.split(".")
      else
        cellvalues = [-1,-1,-1,-1]
      end
      @bay = cellvalues[1].to_i
      @row = cellvalues[2].to_s
      @tier = cellvalues[3].to_i
      @priority = priority
      @priorityColor = priorityColor
      @order_id=order_id
      @alternatecell = ""
      @cntr_status = cntr_status
      if(@bay%2 == 0 && @bay != 0)
        @alternatecell = (@bay-1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." +cellvalues[2] + "|" + (@bay+1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." + cellvalues[2]
      end
    end

    def updatejob(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,twinpick,tandempick,cat,st,is_damaged,container_position,cntr_status,sparcsexception,exception_reason,length,priority, priorityColor, order_id)
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,twinpick,tandempick,cat,st,is_damaged,container_position,cntr_status,sparcsexception,exception_reason,length,priority, priorityColor, order_id, is_damaged)
    end
  end

  #Joblist refresh from client
  def joblist
    puts "Inside joblist"
    @resp_qc_job = Array.new
    if @params["reqtype"].eql?("shuffle")
      @resp_qc_job = shufflingjobs(@params["containeritvinfo"])
    elsif @params["reqtype"].eql?("filter")
      @resp_qc_job = filterjobs(@params["containeritvinfo"])
    elsif @params["reqtype"].eql?("plcjobdone")
      @resp_qc_job = getlistaftrplcjobdone(@params["containeritvinfo"])
    elsif @params["reqtype"].eql?("DELETE")
      @resp_qc_job = deletejobs(@params["container_id"])
    elsif @params["reqtype"].eql?("TRANSFER")
      @resp_qc_job = transferjobs(@params["container_id"])
    elsif @params["reqtype"].eql?("REFRESH")
      @resp_qc_job = $resp_qc_jobs
    else
      @resp_qc_job = getjoblist(@params["to_loc"],@params["from_location"],@params["troubleDamageClicked"],@params["categoryInfo"])
      if (@resp_qc_job.empty?)
#        WebView.execute_js("showAlerts('No active jobs to display'); $('#layout').unmask();")
      end
    end
    if(@params["containeritvinfo"] == "current_jobs")
      @resp_qc_job = @resp_qc_job.sort{|x,y| x.order_id.to_f<=>y.order_id.to_f}
    end
    puts @resp_qc_job.inspect
    render :action => '../Che/joblist'
  end

  def processRmg
    #    return true
    @udp_req_obj[:msg] = "1~1~3000~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['blockNumber']}~#{@params['stackNumber']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @resp_yardView = resp
    render :action => '../Che/rmg'
  end

  def getYardViewData
    @udp_req_obj[:msg] = "1~1~2100~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['blockNumber']}~#{@params['stackNumber']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @resp_yardViewAppend = resp
    puts @resp_yardViewAppend
    render :action => '../Che/rmgBlock'
  end

  def processcontainerarrived(resp, resp_msg_id)
    resp_fields = resp.to_s.split("~")
    resp_msg_id = resp_fields[0]
    puts "ITV Arrived Called........."
    itv_available_status = false

    $session[:Itv_popup_image].each do |idx|
      if (idx.split("#")[0] == resp_fields[2])
        itv_available_status = true
      end
    end

    if(resp_msg_id == "1306")
      # if ITV dispatch was received delete that entry.
      puts "Inside 1306 adding"
      $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
      $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6])
      if (itv_available_status==false)
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6] + '")')
      end
    else
      puts "Inside 1307"
      $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
      $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5])
      if (itv_available_status==false)
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5] + '")')
      end
    end
    #Send itv number to the container handling screen when arrived
    #Update the job list with ITV highlighted color.
  rescue Exception => ex
    puts("processcontainerarrived #{ex} exception while handling : #{ex.message}")
  end

  # method for processing manual job cancel
  def processjobcancel(resp)
    res = "CANCEL_JOB"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def processITVLeft(resp)
    resp_fields = resp.to_s.split("~")
    $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
  end

  #  def processheavyhook(resp)
  #    resp_fields = resp.to_s.split("~")
  #    if( resp_fields[2] == "true")
  #      $session[:checkForMsg].push("HVY_HK_TRUE")
  #    else
  #      $session[:checkForMsg].push("HVY_HK_FALSE")
  #    end
  #  end

  def processqcperformance(resp)
    resp_fields = resp.to_s.split("~")
    qc_view = resp_fields[3].to_s+"|"+resp_fields[4].to_s + "|"+resp_fields[5].to_s + "|"+ resp_fields[6].to_s + "|"+resp_fields[7].to_s
    puts qc_view.inspect
    puts "Performance parametes"
    WebView.execute_js('updateCHEfields("'+ qc_view.to_s() + '")')
  end

  def processjoblist(resp_fields, joblisttype='new')
    resp_qc_list = resp_fields[2].to_s.split('|')
    twinpick = -1
    tandempick = -1
    resp_qc_list.each do |check_list_item|
      if (tandempick == 3)
        tandempick = -1
      end
      jobfields = check_list_item.split("^",-1)
      if(!jobfields[8].nil? && !jobfields[8].empty?)
        ref_container_list = jobfields[8].to_s.split('#')
        if(ref_container_list.length > 2)
          tandempick = tandempick + 1
        end
        if(twinpick == 0)
          twinpick=1
        else
          twinpick=0
        end
      end
      jobtype = 'planned'
      if(jobfields[5] == 'BACKREACH' || jobfields[5] == 'VESSEL')
        jobtype='manual'
      end
      if(joblisttype == 'cmpltd')
        joblistcheck  = $completedjobs.select{|v| (v.containerno == jobfields[1])}
        if joblistcheck.length == 0
          $completedjobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobfields[18],jobtype,jobfields[12],jobfields[13],jobfields[14]))
          #Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobtype,jobfields[12],jobfields[13],jobfields[14]))
        end
      else
#      jobfields.each do |job|
#        puts job.inspect
#        puts "XXXXXXXXXXXXXXXXXX"
#      end 
        $resp_qc_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[16],jobfields[19],jobfields[20],jobtype,"N", "",jobfields[12],jobfields[14],jobfields[15], jobfields[18]))
      end
    end

    #    $resp_qc_jobs = $resp_qc_jobs.sort_by{|e| [e.order_id.to_f]}

    $backreach_dsch_jobs = $resp_qc_jobs.select{|v| (v.from_loc == "BACKREACH" || v.to_loc == "BACKREACH")}
    if(joblisttype == 'cmpltd')
      return $completedjobs
    else
      return $resp_qc_jobs
    end
  end

  # processing PLC job completed move
  def processjobdone(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    puts containerarry.inspect
    puts "Container array in 1601"
    containerlist = ""
    movekind = ""
    tmp_cont_arr = []
    $plc_job_list_confirm = $resp_qc_jobs.select{|v| (containerarry.include? v.containerno + '^' + v.code)}
    puts $plc_job_list_confirm.inspect
    puts "plc_job_list_confirm"
    cell_location =""
    if($plc_job_list_confirm.length > 0)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty?)
        cell_location = $plc_job_list_confirm.map(&:from_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      containerlist = getcontainerstringfordsch($plc_job_list_confirm)
      movekind = 'DSCH'
    else
      puts "Else"
      $plc_job_list_confirm = $resp_qc_jobs.select{|v|(containerarry.include? v.containerno + '^' + v.code)}
      puts $plc_job_list_confirm.inspect
      puts "plc_job_list_confirm"
      containerlist = getcontainerstringforload($plc_job_list_confirm)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty?)
        cell_location = $plc_job_list_confirm.map(&:to_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      movekind = "LOAD"
    end

    res = "PLC_JOB_DONE" + "~" + containerlist + "~" + cell_location + "~" + movekind
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def process_damage_record_changed(resp)
    resp_fields = resp.to_s.split("~")
    selected_job  = $resp_qc_jobs.select{|v| v.containerno == resp_fields[2]}
    if selected_job.empty?
      selected_job = $completedjobs.select{|v| v.containerno == resp_fields[2]}
    end

    if selected_job.empty?
    else
      selected_job[0].is_damaged = resp_fields[3].to_s;
    end

    WebView.execute_js('addRemoveDamageIcon("'+ resp_fields[2] + "#" + resp_fields[3] + '")')

  end

  #manual job confirmation
  def processcontainerhandling(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    cell_location =""
    movekind = ""
    resp_qc_job = $resp_qc_jobs.select{|v| (containerarry.include? v.containerno+"^"+v.code) && v.code == 'DSCH'}
    if(resp_qc_job.length > 0)
      cell_location = resp_qc_job.map(&:from_loc).join("|")
      movekind = 'DSCH'
    else
      resp_qc_job = $resp_qc_jobs.select{|v| (containerarry.include? v.containerno+"^"+v.code) && v.code != 'DSCH'}
      cell_location = resp_qc_job.map(&:to_loc).join("|")
      movekind = 'LOAD'
    end
    if(resp_qc_job.length > 0)
      res = "CONTAINER_HANDLING_TRUE" + "~" +resp_fields[3] + "~" + cell_location + "~" + movekind
    else
      res = "ALERT_MESSAGE_DISPLAYED" + "~" + "Container #{resp_fields[3]} not found in joblist, please confirm manually"
    end

    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')

  end

  def processdelayrecording(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3]
    WebView.execute_js('processdelayrecording("'+ res.to_s() + '")')
  end

  def processbayfrontviewleft(resp)
    resp_fields = $session[:bayfrontview_left]
  end

  #Alert message for stopping work
  def processworkstopalert(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    WebView.execute_js('showAlerts("'+ res.to_s() + '")')
  end

  def processwrongcontainerpicked(resp)
    #resp_fields = resp.to_s.split("~")
    #$session[:checkForMsg].push("ALERT_MESSAGE_DISPLAYED" + "~" + resp_fields[3])
    resp_fields = resp.to_s.split("~")
    container_number = resp_fields[2]
    if(resp_fields[0]=="9910")
      cList = resp_fields[2].to_s.split("|")
      $completedjobs.each {|v| v.sparcsexception = "Y" if cList.include? v.containerno}
      $completedjobs.each {|v| v.exception_reason = resp_fields[3] if cList.include? v.containerno}
    end
    res = "NORMAL_ALERT_MESSAGE"+ "~" + container_number + " : " + resp_fields[3]
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def processnormalalertmessage(resp)
    #resp_fields = resp.to_s.split("~")
    #$session[:checkForMsg].push("NORMAL_ALERT_MESSAGE"+ "~" + resp_fields[3])
    resp_fields = resp.to_s.split("~")
    container_number = resp_fields[2]
    if(resp_fields[0]=="9910")
      cList = resp_fields[2].to_s.split("|")
      $completedjobs.each {|v| v.sparcsexception = "Y" if cList.include?(v.containerno + "^" + v.code)}
      $completedjobs.each {|v| v.exception_reason = resp_fields[3] if cList.include?(v.containerno + "^" + v.code)}
    end
    res = "NORMAL_ALERT_MESSAGE"+ "~" + container_number + " : " + resp_fields[3] + "~" + resp_fields[4]
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #backreach container move
  #  def backreachcontainermove(resp)
  #    resp_fields = resp.to_s.split("~")
  #    $session[:checkForMsg].push("BACKREACH_CONTAINER_MOVE" + "~" + resp_fields[3])
  #  end

  def removingjobs(resp)
    resp_fields = resp.to_s.split("~")
    $session[:checkForMsg].push("REFRESH_JOBS" + "~" + resp_fields[4] + "~" + resp_fields[3])
  end

  #Removing Jobs
  def shufflingjobs(containeritvinfo)
    reqparams = containeritvinfo.split('|')
    reqobjs = Array.new
    $resp_qc_jobs.delete_if {|v| reqobjs.push(v) if v.from_loc == reqparams[1]  || v.to_loc == reqparams[1]}
    reqobjs.each do |reqobj|
      $resp_qc_jobs = $resp_qc_jobs.unshift(reqobj)
    end
    return $resp_qc_jobs
  end

  #filter jobs
  def filterjobs(container)
    resp_qc_job = Array.new
    puts "Inside filterjobs"
    puts "Coontainer: " + container.inspect
    if(container=="twin_handling")
      resp_qc_job = $resp_qc_jobs.select{|a| (a.twinpick != -1) && (a.bay%2 == 1)} #&& (a.tandempick == -1)
    elsif(container=="current_jobs")
      resp_qc_job = $resp_qc_jobs
    elsif(container=="jobs_completed")
      if($completed_jobsrequest == false)
        @udp_req_obj[:msg] = "1~1~1420~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
        resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        if resp.length > 0
          resp_fields = resp.to_s.split("~")
          if(resp_fields[0] == "1421")
            $completedjobs =processjoblist(resp_fields,'cmpltd')
            $completed_jobsrequest = true
          end
        end
      end
      backreach_dsch_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "DSCH")}.map{|b| b.containerno}
      backreach_load_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "LOAD")}.map{|b| b.containerno}
      $backreach_load_jobs = backreach_dsch_jobs - backreach_load_jobs
      resp_qc_job = $completedjobs
    elsif(container=="tandem_pick")
      resp_qc_job = $resp_qc_jobs.select{|a| (a.tandempick != -1) || ((a.twinpick != -1) && (a.tandempick == -1) && (a.bay%2 == 0))}
    elsif(container=="backreach_jobs")
      resp_qc_job = $resp_qc_jobs.select{|a| (a.from_loc == "BACKREACH" &&  a.to_loc == "VESSEL") || (a.from_loc == "VESSEL" &&  a.to_loc == "BACKREACH")}
    elsif(container=="exception_joblist")
      resp_qc_job = $completedjobs.select{|a| a.sparcsexception == "Y"}
    end
    return resp_qc_job
  end

  def getlistaftrplcjobdone(containerlist)
    compltdjob = Array.new
    twinpick = 1
    tandempick = 0
    containers = Array.new
    $plc_job_list_confirm.each do |current_job|
      containers.push(current_job.containerno + '^' + current_job.code)
    end
    containers.each{ |cNo|
      containerList=($resp_qc_jobs.select{|v| (v.refercontainer.include? cNo.split('^')[0]) || (v.containerno==cNo.split('^')[0] && v.code==cNo.split('^')[1])})
      containerList.each {|cList|
        cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno && v.code==cList.code)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        resp_qc_job.refercontainer = ""
        resp_qc_job.twinpick = -1
        resp_qc_job.tandempick = -1
      }
    }
    required_jobs=($resp_qc_jobs.select{|v| (containers.include? v.containerno + '^' + v.code) })
    containerList = Array.new
    required_jobs.each do |single_job|
      containerList.push(single_job.containerno + '^' + single_job.code)
    end
    if (containerList.length == 2 || containerList.length == 4)
      containerList.each {|containerno|
        cIndex = $resp_qc_jobs.index{|v| ((v.containerno+ '^' +v.code)==containerno)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        refer_container = prepareRefContainer(containerList,containerno)
        if(twinpick == 0)
          twinpick=1
        else
          twinpick=0
        end
        resp_qc_job.refercontainer = refer_container
        resp_qc_job.twinpick = twinpick

        if(containerList.length == 4)
          resp_qc_job.tandempick = tandempick
          tandempick = tandempick + 1
        end
      }
    end

    $resp_qc_jobs.delete_if {|v| compltdjob.push(v) if containers.include?(v.containerno+'^'+v.code)}
    $completedjobs.concat(compltdjob)
    return $resp_qc_jobs
  end

  def transferjobs(container)
    containerList = container.split('|')
    containerList.each {|containerNo|
      cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
      if(cIndex != nil)
        $completedjobs.push($resp_qc_jobs[cIndex])
        $resp_qc_jobs.delete_at(cIndex)
      end
    }
    resp_qc_job = $resp_qc_jobs
    return resp_qc_job
  end

  def deletejobs(container)
    containerList = container.split('|')
    containerList.each {|containerNo|
      $resp_qc_jobs.delete_if {|v| v.containerno ==  containerNo}
    }
    resp_qc_job = $resp_qc_jobs
    return resp_qc_job
  end

  def getjoblist(to_loc,from_loc,troubleDamageClicked)
    if(!to_loc.empty?)
      containers = ""
      itvno = ""
      compltdjob = Array.new
      if($job_list_confirm.length > 0)
        containers = $job_list_confirm.map(&:containerno).join("|")
        if(troubleDamageClicked == "false")
          qc_container_move(containers,from_loc,to_loc,category_info)
        end
        #from_locations = from_loc.split("|")
        if($job_list_confirm[0].code == "LOAD")
          to_locns = to_loc.split("|")
          index=0
          $job_list_confirm.each do |joblist|
            #joblist.from_loc = from_locations[index]
            joblist.to_loc = to_locns[index]
            index += 1
            joblist.inspect
            $completedjobs.delete_if{|v| (v.containerno==joblist.containerno && v.code == joblist.code)}
            if $jobConfirmation == true
              $completedjobs.push(joblist)
              $resp_qc_jobs.delete_if {|v| v.containerno ==  joblist.containerno && v.code == joblist.code}
            end
          end
        end
      end
      $job_list_confirm = $job_list_confirm.clear
      $sleeptime  = 0
      $completedjobs.inspect
    end
    return $resp_qc_jobs
  end

  def processbayfrontviewleft(resp)
    resp_fields = $session[:bayfrontview_left]
  end

  def processbayfrontviewright(resp)
    resp_fields = $session[:bayfrontview_right]
  end

  def getcelllocationforbayview(loc,param)
    cellvalues = param.split(".")
    baynumber = cellvalues[0].to_i
    if(loc == "-1")
      if(baynumber.even?)
        baynumber= baynumber-1
      end
      leftcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
      if(baynumber.even?)
        baynumber= baynumber+1
      else
        baynumber= baynumber+2
      end
      rightcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    else
      leftcellval,rightcellval = getcelllocation(loc)
    end
    return leftcellval,rightcellval
  end

  def getcelllocation(loc)
    loc.gsub("cell-","")
    cellvalues = loc.split(".")
    baynumber = cellvalues[0].to_i
    if(baynumber.even?)
      baynumber = baynumber-1
    end
    leftcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    if(baynumber.even?)
      baynumber= baynumber+1
    else
      baynumber= baynumber+2
    end
    rightcellval = baynumber.to_s.rjust(2, '0')+"."+cellvalues[1]+"."+cellvalues[2]
    return leftcellval,rightcellval
  end

  def getcelllocationforprevnext(bprev)
    celllocation = ""
    lastcelllocation = $last_rendered_cell.split("|")[1]
    cellattributes = lastcelllocation.split(".")
    if(bprev == 'true')
      leftloc,rightloc = getbaynosforprev();
      leftcelllocation = leftloc.to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
      rightcelllocation = rightloc.to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
    else
      leftcelllocation = ($last_renderedview.to_i+2).to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
      rightcelllocation = ($last_renderedview.to_i+4).to_s.rjust(2,'0')+"."+ cellattributes[1]+"."+cellattributes[2]
    end
    return leftcelllocation,rightcelllocation
  end

  def getbaynosforprev()
    bayno = $last_renderedview.to_i
    if(bayno == 3 || bayno ==5)
      rightbayno = 3
      leftbatno =  1
    else
      rightbayno = bayno-4
      leftbatno =  bayno-2
    end
    return leftbatno,rightbayno
  end

  #Updating Twin Tandom and Split Jobs
  def updateTwinTandemSplitJobs(resp)
    resp_fields = resp.to_s.split("~")
    jobType = resp_fields[2].to_s
    cntrList = resp_fields[3].split("|")
    containerList=($resp_qc_jobs.select{|v|  cntrList.include? v.containerno })

    if(cntrList.length == containerList.length)
      if(jobType == "SPLIT")
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        twinpick = 1
        tandempick = 0
        targetIndex=""
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(cntrList,containerNo)
          if(twinpick == 0)
            twinpick=1
          else
            twinpick=0
          end
          resp_qc_job.refercontainer = refercontainer
          resp_qc_job.twinpick = twinpick
          if(jobType == "TANDEM")
            resp_qc_job.tandempick = tandempick
            tandempick = tandempick + 1
          end
          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }
      end
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    end

  end

  def getNextIndexOfMoveType(moveType, jobList)

    loadIdx = 0
    dschIdx = 0
    recvIdx = 0
    yardIdx = 0
    dlvrIdx = 0

    jobList.each do |v|
      case v.code
      when "LOAD"
        loadIdx = loadIdx+1
      when "DSCH"
        dschIdx = dschIdx+1
      when "RECV"
        recvIdx = recvIdx +1
      when "YARD"
        yardIdx = yardIdx+1
      when "DLVR"
        dlvrIdx = dlvrIdx+1
      end
    end

    # Check the Move type and return the index
    if moveType=="LOAD"
      return loadIdx
    elsif moveType=="DSCH"
      return loadIdx+dschIdx
    elsif moveType=="RECV"
      return loadIdx+dschIdx+recvIdx
    elsif  moveType=="DLVR"
      return loadIdx+dschIdx+recvIdx+dlvrIdx
    elsif moveType=="YARD"
      return loadIdx+dschIdx+recvIdx+dlvrIdx+yardIdx
    end
  end

  def updatejoblist(resp)
    puts "In updatejoblist"
    resp_fields = resp.to_s.split("~")
    resp_qc_list = resp_fields[2].to_s.split('|')
    twinpick = 1
    tandempick = -1
    resp_qc_list.each do |check_list_item|
      jobfields = check_list_item.split("^",-1)
      jobindex = $resp_qc_jobs.index{|v| (v.containerno==jobfields[1])}
      if(!jobfields[8].nil?)
        if(twinpick == 0)
          twinpick=1
        else
          twinpick=0
        end
      end
      jobtype = 'planned'
      if(jobfields[5] == 'BACKREACH' || jobfields[5] == 'VESSEL')
        jobtype='manual'
      end
      if(jobindex == nil)
        new_job = Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[16],jobfields[19],jobfields[20],jobtype,"N", "",jobfields[12],jobfields[14],jobfields[15], jobfields[18])

        if(jobfields[0].to_s() == "LOAD")
          jobIdx = getNextIndexOfMoveType("LOAD", $resp_qc_jobs)
          puts "indexToInsert " + jobIdx.inspect
          $resp_qc_jobs.insert(jobIdx, new_job)
        elsif (jobfields[0].to_s() == "DSCH")
          jobIdx = getNextIndexOfMoveType("DSCH", $resp_qc_jobs)
          puts "indexToInsert " + jobIdx.inspect
          $resp_qc_jobs.insert(jobIdx, new_job)
        elsif (jobfields[0].to_s()=="DLVR" || jobfields[0].to_s()=="GO")
          jobIdx = getNextIndexOfMoveType("DLVR", $resp_qc_jobs)
          puts "indexToInsert " + jobIdx.inspect
          $resp_qc_jobs.insert(jobIdx, new_job)
        elsif (jobfields[0].to_s()=="RECV" || jobfields[0].to_s() == "GI")
          jobIdx = getNextIndexOfMoveType("RECV", $resp_qc_jobs)
          puts "indexToInsert " + jobIdx.inspect
          $resp_qc_jobs.insert(jobIdx, new_job)
        elsif (jobfields[0].to_s()=="YARD" || jobfields[0].to_s() == "AH" || jobfields[0].to_s() == "RH" || jobfields[0].to_s() == "MO" || jobfields[0].to_s() == "MI")
          jobIdx = getNextIndexOfMoveType("YARD", $resp_qc_jobs)
          puts "indexToInsert " + jobIdx.inspect
          $resp_qc_jobs.push(new_job)
        end
      else
        updatedjob = $resp_qc_jobs[jobindex]
        updatedjob.updatevalues(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[16],jobfields[19],jobfields[20],jobtype,"N", "",jobfields[12],jobfields[14],jobfields[15], jobfields[18])
        $resp_qc_jobs[jobindex] = updatedjob
      end
    end
    #    sort_order = ["LOAD","DSCH","RECV","DLVR","YARD"]
    #    $resp_qc_jobs = $resp_qc_jobs.sort_by{|e| [sort_order.index(e.code)]}

    #    $resp_qc_jobs = $resp_qc_jobs.sort_by{|e| [e.order_id.to_f]}

    if($job_filter_value == "current_jobs")
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    end

  rescue Exception => ex
    puts "Update error"
    puts ex
  end

  #method to prepare string for updating the bay view in load case
  def getcontainerstringforload(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      refer = false
      hazardous = false
      oog =false
      rob=false
      if([1,3,4,5,6].include?(job.remarks.to_i))
        refer = true
      end
      if([1,2].include?(job.remarks.to_i))
        hazardous = true
      end
      if([7,8,9,10,11,12].include?(job.remarks.to_i))
        oog = true
      end
      contrstring = "1^"+job.containerno+"^"+refer.to_s+"^"+hazardous.to_s+"^"+oog.to_s+"^"+rob.to_s+"^"+job.country+"^"+job.colorcode
      contrloadstrings.push(contrstring)
      if(job.bay%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  #method to prepare string for updating the bay view in load case
  def getcontainerstringfordsch(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      contrstring = job.containerno+"^"+job.code
      contrloadstrings.push(contrstring)
      if(job.bay%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  def get_catagory(cat_no)
    cat_no_to_icon_map = {
      "T" => "tranship",
      "I" => "import",
      "E" => "export",
      "R" => "restow",
      "S1" => "restow",
      "S2" => "restow",
      "B" => "restow"
    }
    return cat_no_to_icon_map.fetch(cat_no, nil)
  end

  def get_table_remarks_icon(remarks_no)
    remarks_no_to_icon_map = {
      "1" => "hazardous_reefer",
      "2" => "hazardous",
      "3" => "reefer_1",
      "4" => "reefer_2",
      "5" => "reefer_3",
      "6" => "reefer_4",
      "7" => "over-dimentional_1",
      "8" => "over-dimentional_2",
      "9" => "over-dimentional_3",
      "10" => "over-dimentional_4",
      "11" => "over-dimentional_5",
      "12" => "over-dimentional_6",
      "13" => "damage",
      "14" => "damage_low"
    }
    return remarks_no_to_icon_map.fetch(remarks_no, nil)
  end

  #  method for finding the cell for upper or lower deck.
  def getupperorlowerdeckcell()
    $last_rendered_cell.inspect
    lastrenderedlocations = $last_rendered_cell.split("|")
    lastrenderedlocations.collect! { |location|
      cellattributes = location.split(".")
      tierlocation =  cellattributes[2].to_i
      if(tierlocation > 80)
        cellattributes[2] = (tierlocation-80).to_s.rjust(2,'0')
      else
        cellattributes[2] = (tierlocation+80).to_s.rjust(2,'0')
      end
      location = cellattributes.join(".")
    }
    return  lastrenderedlocations
  end

  #  method for sending the bayview request and retrieving the respone.
  def getbayview(celllocation,reqtype)
    @udp_req_obj[:msg] = "1~1~2600~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{celllocation}~#{reqtype}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      $last_renderedview = resp_fields[2].to_i
    end
    return resp
  end

  def prepareRefContainer(addContainerList,containerNo)
    refercontainer=Array.new
    #refercontainer=(addContainerList.select {|cNo|  cNo !=containerNo })
    addContainerList.each do |cNo|
      if(cNo !=containerNo)
        refercontainer.push(cNo.split('^')[0])
      end
    end
    refer_container_string = refercontainer.join("#")
    return refer_container_string
  end

  def updateRmgPosition(resp)
    #WebView.execute_js('updateRmgPosition("' + resp_fields[4] + '")')
    WebView.execute_js('updateRmgPosition("' + resp + '")')
  end

  def process_freeze_unfreeze_app(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    if(resp_fields[2] == "false")
      WebView.execute_js('freezeUI("'+ res.to_s() + '")')
    else
      WebView.execute_js('unFreezeUI()')
    end

  end

  def itv_waiting(resp)
    puts "Came in ITV waiting"
    resp_fields = resp.to_s.split("~")
    puts resp_fields.inspect
    puts "XXXXXXXXXXXXXXXXXXXXX"
    cnt_detls = resp_fields[3].split("|")
    cnt_detls.each do |cnt_detl|
      details = cnt_detl.split("^")
      puts details.inspect
      cont_no =  details[0]
      freqncy = details[1]
      clr_code = details[2]
      #  WebView.execute_js('stop_blinking("'+ cont_no.to_s() + '")')
      WebView.execute_js('start_blinking("'+ cont_no.to_s() + '","'+ freqncy +'","'+clr_code.to_s+'")')
    end
  end

end
