 var cellsrenderer = function (row, column, value) {
	return '<div style="text-align: center; margin-top: 5px;">' + value + '</div>';
}
var columnsrenderer = function (value) {
	return '<div style="text-align: center; margin-top: 5px;">' + value + '</div>';
}
var removeSubgridIcon = function () {
    var $this = $(this);
    $this.find(">tbody>tr.jqgrow>td.ui-sgcollapsed").filter(function () {
        var rowData = $this.jqGrid("getLocalRow",
                $(this).closest("tr.jqgrow").attr("id"));
        return rowData.subgrid == null;
    }).unbind("click").html("");
}
isHasSubrids = function (data) {
    var l = data.length, i;
    for (i = 0; i < l; i++) {
        if (data[i].subgrid != null) {
            return true;
        }
    }
    return false;
}

var editDamageEnabled = false;

function getTroubleShootAreaData(){
	var troubleShootAreaData = "", i = 0;
	
	troubleShootAreaData += '"Select"' + ':' + '"--Select--",';
	for(i = 0; i < troubleShootDataRaw.length; i++){
		if(troubleShootDataRaw[i] !=  ""){
			troubleShootAreaData += '"' + troubleShootDataRaw[i] + '"' + ':' + '"' + troubleShootDataRaw[i] + '",';
		}
	}
	
	if(troubleShootAreaData.length > 0){
		troubleShootAreaData = troubleShootAreaData.slice(0, -1);
		troubleShootAreaData = '{ ' + troubleShootAreaData  + ' } ';
		troubleShootAreaData = JSON.parse(troubleShootAreaData);
	}
	
	return troubleShootAreaData;
}

function getTroubleShootAreas(){
	return {
		value: getTroubleShootAreaData(),
		dataInit: function (elem) {
		
			$(elem).addClass('combobox');
			$(elem).attr('type', 'text');
			$(".combobox").combobox();
			setTimeout(virtualKeyboard, 500);
		}
	}	
}

function enableDamageColumnsForEdit(selectedGrid, columnNames){
	var i = 0;
	
	for(i = 0; i < columnNames.length; i++){
		selectedGrid.jqGrid('getColProp',columnNames[i]).editable = true;
	}
}

function disableDamageColumnsForEdit(selectedGrid, columnNames){
	var i = 0;
	
	for(i = 0; i < columnNames.length; i++){
		selectedGrid.jqGrid('getColProp',columnNames[i]).editable = false;
	}
}


function onDamageRowEdit(id, element){
	if(editDamageEnabled == true){
		showAlerts("Please save all other records");
		return false;
	}
	
	var selectedRow = jQuery('#list').jqGrid ('getRowData', id);

	var editableColumns = [ 'container', 'to_loc'];
	var selectedGrid = jQuery("#list");
	if(selectedRow.codeId != 0){
		disableDamageColumnsForEdit(selectedGrid, editableColumns);
	}else{
		enableDamageColumnsForEdit(selectedGrid, editableColumns);
	}
	jQuery("#list").jqGrid('editRow', id, true, null, null, 'clientArray');
	$(element).parent().parent().find(".edit_btn").hide();
	$(element).parent().parent().find(".save_btn").show();
	editDamageEnabled = true;
	inEditMode = true;
}

function onDamageRowSave(id, element){
	jQuery('#list').saveRow(id);
	$(element).parent().parent().find(".edit_btn").show();
	$(element).parent().parent().find(".save_btn").hide();
	editDamageEnabled = false;
	inEditMode = false;
}

function generate_grid(grid_data){
	
$("#list").jqGrid({
        datatype: "local",
        data: grid_data,
        colNames: ["Container", "To Location","TS Code","Actions"],
        colModel: [
            { name: "container", renderer: columnsrenderer, cellsrenderer: cellsrenderer,width: 200 },
            { name: "to_loc", renderer: columnsrenderer, cellsrenderer: cellsrenderer,width: 200 },
            { name: "ts_code", renderer: columnsrenderer, cellsrenderer: cellsrenderer,width: 125,editable: true, edittype:"select", editoptions:getTroubleShootAreas()},
            {name:'act',index:'act',renderer: columnsrenderer, cellsrenderer: cellsrenderer, width:100,sortable:false}    
        ],
        gridview: true,
        height: "100%",
        scrollerbar:true,
        subGrid: isHasSubrids(grid_data),
        subGridOptions: { expandOnLoad: true },
        hideCol: "subgrid",
        gridComplete: function(){
          var ids = jQuery("#list").jqGrid('getDataIDs');
          for(var i=0;i < ids.length;i++){
            var cl = ids[i];
            be = "<img src='../../public/images/edit.png' class='adjust_edit_image edit_btn' onclick=\"onDamageRowEdit('"+cl+"', this);\"  />"; 
            se = "<img src='../../public/images/save.png' style='display:none' class='adjust_delete_image save_btn' style='display:inline;' onclick=\"onDamageRowSave('"+cl+"', this);\"  />"; 
            jQuery("#list").jqGrid('setRowData',ids[i],{act:be+se});
            } 
          //alert($("#list").jqGrid("getRowData"))
          },
      	editurl: 'clientArray',  
        subGridRowExpanded: function (subgridDivId1, rowId1) {
            var $subgrid1 = $("<table id='" + subgridDivId1 + "_t'></table>"),
                localRowData1 = $(this).jqGrid("getLocalRow", rowId1);
            $subgrid1.appendTo("#" + $.jgrid.jqID(subgridDivId1));
            $subgrid1.jqGrid({
                datatype: "local",
                data: localRowData1.subgrid,
                colNames: ["Code", "Description","Actions"],
                colModel: [
                    { name: "code", width: 100,editable: true },
                    { name: "description", width: 200 },
                   {name:'act',index:'act', width:75,sortable:false}    
                ],
                height: "100%",
              gridComplete: function(){
                 var ids = jQuery($("#"+subgridDivId1+"_t")).jqGrid('getDataIDs');
                 for(var i=0;i < ids.length;i++){
                   var cl = ids[i];
                   ce = "<img src='../../public/images/delete_icon.png' class='adjust_delete_image delete_icon' del_id="+cl+" onclick=\"jQuery('#"+subgridDivId1+"_t').jqGrid('delRowData','" + cl + "');clr_rht_chk_box('"+cl+"');\" />"; 
                   jQuery($("#"+subgridDivId1+"_t")).jqGrid('setRowData',ids[i],{act:ce});
                 } 
               },
            });
        },
   });
jQuery("#list").jqGrid('hideCol', "subgrid");
$("#list").parents('div.ui-jqgrid-bdiv').css("max-height","300px");
$("#list").parents('div.ui-jqgrid-bdiv').css("min-height","300px");
}

function clr_rht_chk_box(clk_elm){
	var cntr_det = clk_elm.split("_") 
	var cntr = cntr_det[0] 
	var tr_code = cntr_det[1]
		$(".ContrDetails td[cntr_no="+cntr+"] input").click()
		$("#damage_recording_table td input[type='checkbox']").prop("checked",false)
		var no_damages = $("#list_"+cntr+"_t").jqGrid("getRowData").length
        for (var cnt1 = 0; cnt1 < no_damages; cnt1++) {
        	var sb_data = $("#list_"+cntr+"_t").jqGrid("getRowData")[cnt1]
        	$("#damage_recording_table input[troubleshoot_area='"+sb_data.code+"']").prop("checked",true)
        }
}

$(document).ready(function() {
	
	virtualKeyboard();
//	$(".damage_recording_cls").each(function() {
//		if ($(this).attr("is_damaged") == "N") {
//			$(this).find(".itvDrpDwn").attr("disabled", true)
//		}
//	});

	$(".itvDrpDwn").msDropdown({ roundedBorder: false });

	//search method
	$.extend($.expr[":"], {
			"containsIN": function(elem, i, match, array) {
				return (elem.textContent || elem.innerText || "").toLowerCase().indexOf( (match[3] || "").toLowerCase()) >= 0;
			}
		});
	$("#search_damage_code").change(function() {
		var value = $('#search_damage_code').val();
		if (value.length == 0) {
			$('#damage_recording_table tr').show();
		} else {
			$("#damage_recording_table tr:not('#damage_recording_table .tableheader')").hide();
			$("#damage_recording_table td.searchItem:containsIN('" + value + "')").parents("#damage_recording_table tr").show();
		}
	});
});

$('.container_info').on('click', function(e) { // Adding class when container or to location is getting clicked.
		$(".container_info").removeClass("selected_container")
		$(this).addClass("selected_container")
		$(this).addClass("container_is_selected")
		$(".container_info").each(function() {
			if (!$(this).hasClass("container_is_selected")) {
				$(this).children("td").children('input').removeClass("cntr_selected");
			}
		})
		$(this).children('td').children('input').addClass("cntr_selected");
		$(".container_info").children('td').children('input').removeClass("current_selected_container")
		$(this).children('td').children('input').addClass("current_selected_container")
		$("#damage_recording_table .regular-checkbox").each(function() {
			$(this).attr("checked", false)
		});
//		$("#damage_recording_table .regular-checkbox").each(function() {
//			var dmg_code = $(this).attr("troubleshoot_area")
//			var is_selected = false;
//			$(".selected_container").next().children("td").children(".ts_code_desc").children(".ts_code").each(function() {
//				if ($(this).html() == dmg_code) {
//					is_selected = true;
//					return false;
//				} else {
//					is_selected = false;
//				}
//			});
//			if (is_selected) {
//				$(this).prop("checked", true)
//			}
//		})
		var cntr = $(this).attr("container_no")
		$("#damage_recording_table td input[type='checkbox']").prop("checked",false)
		var no_damages = $("#list_"+cntr+"_t").jqGrid("getRowData").length
        for (var cnt1 = 0; cnt1 < no_damages; cnt1++) {
        	var sb_data = $("#list_"+cntr+"_t").jqGrid("getRowData")[cnt1]
        	$("#damage_recording_table input[troubleshoot_area='"+sb_data.code+"']").prop("checked",true)
        }
	});

// function to send and getting the clicked container with to location,troubleshoot area and code.
function send_damage_record_data(movekind) {
//	var container_select = [];
//	var cntr_to_location = [];
//	var trouble_shoot_area = [];
//	var damage_code = [];
	var movekind = "";
	
	var dmg_rcd = []
	
	movekind = $(".itv_cntr_no").find("span[name='toData']").attr('movekind');
//	if ($(".ContrDetails .cntr_selected").length <= 0) {
//		showAlerts('Please select a container.');
//		return false;
//	}

//	$(".ContrDetails .cntr_selected").each(function() {
//		if ($(this).hasClass("contrBtnFun")) {
//			container_select += $(this).val() + "|";
//		} else if ($(this).hasClass("itvBtnFun")) {
//			cntr_to_location = $(this).val();
//		}
//	});

	//	$(".regular-checkbox").each(function() {
	//		if (this.checked) {
	//			trouble_shoot_area += $(this).parent().parent().find(".itvDrpDwn").val() + "|";
	//			damage_code += $(this).parent().parent().find(".troubleshoot_area h4").html() + "|";
	//		}
	//	});

//	if ($(".regular-checkbox:checked").length <= 0) {
//		showAlerts('Please select a Trouble shoot area.');
//		return false;
//	}
//	$(".regular-checkbox").each(function() {
//
//		if (this.checked) {
//			trouble_shoot_area += $(this).parent().parent().find(".troubleshoot_area h4").html() + "^" + $(this).parent().parent().find(".itvDrpDwn").val() + "|";
//		}
//	});
	//closePopup();
	$.ajax({
		type: "POST",
		url: "/app/Hc/sendDamageRecordReq",
		data: {
			container_select: container_select,
			cntr_to_location: cntr_to_location,
			trouble_shoot_area: trouble_shoot_area,
			movekind: movekind
		},
		success: function(result) {
			troubleDamageClicked = true;
			$(".tally_confirm").click();
		}
	});
}
