//@ sourceURL=joblist.js  

$(document).ready(function(){
	virtualKeyboard();
	//refresh_container_handling()
	/*$('#qc_table').fixedHeaderTable({
		footer: false
    });
    */
	
	var jobsSelect = $("#jobs_select");
	jobsSelect.data("prev",jobsSelect.prop('selectedIndex'));
	
    $(".container_handling_cls").on("click",function(event){
    	
        event.stopPropagation();
        var contr = $(this).parents("tr:first");
        var $tableRows=$(".hc_joblist_table tr");
        var v = contr.data('refercontainer');
        var container = contr.data('uniquejobid');
        var hidd_cntr_val = contr.data('container');
        var containerLength = contr.data('length');
        selected_cont = container;
        $("#hidden_container_no").val(hidd_cntr_val);
        $tableRows.removeClass("active");
        var cont = contr.attr('uniquejobid');
        if($("#qccontainer_handling").accordion("option", "active") == 0){
        	$("#qccontainer_handling").accordion("option", "active", 1);
        }
        console.log("contr value is "+contr)
        processcontainerhandling(container,'true',containerLength);
        console.log(container)
		console.log("Selected container ")
		console.log("Selected container length "+containerLength)
		contr.addClass("active") 
        /*v=v.split('#');
        for(x=0;x < v.length; x++ )
          $("#qc_table tr[data-container='"+v[x]+"']").addClass("active")
        */
        qc_rowClicks = 0;
        jobCellId = getJobCellId(this);
        //$('#qccontainer_handling h3').click();
       // scrollYardToRequestedContainer(container, jobCellId);
    });
    
    $( "#qccontainer_handling" ).on( "accordionbeforeactivate", function( event, ui ) {
	    if($('.ui-accordion-header-active').attr('id') === "container_imgid" ){
	      $(".qc_bay_heading").css("background-image","none");  
	    }
	    else{
	      $(".qc_bay_heading").css("background-image","url('../../public/images/see_container_handling_active.png')"); 
	    }
	} );
	
    $('#totalMoves').hide();
    $('#qc_table').find('.discharge').css('background-color','#e0e0e0');
    $('#qc_table').find('.load').css('background-color','#f7f7f7');
    //$('.hc_joblist_table').fixedHeaderTable();
    
    //search method
    $.extend($.expr[":"], {
        "containsIN": function(elem, i, match, array) {
            return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
        }
    });
    
    $("#search_joblist").keyup(function(){
        var value = $('#search_joblist').val();       
        if(value.length==0)
            $('#qc_table tr').show();
        else{
            $("#qc_table tr:not('#qc_table .tableheader')").hide();
            $("#qc_table td.joblist_searchItem:containsIN('"+value+"')").parents("#qc_table tr").show();
            $("input.joblist_searchItem[value*='" + value + "']").parent().parents("#qc_table tr").show();
        }
    });
    
    $("#search_joblist").change(function() {
		var value = $('#search_joblist').val();
		if (value.length == 0)
			$('#qc_table tr').show();
		else {
			$("#qc_table tr:not('#qc_table .tableheader')").hide();
			$("#qc_table td.joblist_searchItem:containsIN('" + value + "')").parents("#qc_table tr").show();
			$("input.joblist_searchItem[value*='" + value + "']").parent().parents("#qc_table tr").show();
		}
	});
    
   /* $('.sort').off('click').on('click',function(){      
       $.ajax({
          type:   "POST",
          url:  "/app/Hc/sortJoblist",
          data: {
            sortBy:sortBy
          },
          success:function(result){         
              $("#tabledataid").html("")
              $("#tabledataid").html(result)
          }
      })    
      }
    )*/
    $("#qc_table tr").each(function(){
        if($(this).attr("is_damaged") == 'true'){
          $(this).children("td:last").addClass("damage")
        }
        })
		//refresh_container_handling()
  });
  
  var DELAY = 300, qc_rowClicks = 0, timer = null;
  
  var cellId =[];
  $( ".qc_rows" ).hover(
      function() {
      
          cellId =[]; 
          cellId_s=$(this).attr('cellId');  
          bayNo = $(this).attr('bayno'); 
          
         /* if (cellId_s != "BACKREACH" && cellId_s != "VESSEL"){
           $("tr[cellid='"+cellId_s+"']").addClass('onmouseover');
         }else{
        	 
           $(this).addClass('onmouseover');
         }*/
		 
         $(this).addClass('onmouseover');
          /*var v = $(this).data('refercontainer');
          if(v && v.length != 0)
          {   
              v=v.split('#');
              for(x=0;x < v.length; x++ )
              {
                  var qcRow = $(".hc_joblist_table tr[data-container='"+v[x]+"']")
                  $(qcRow).addClass("onmouseover")
              }
          }*/
		  
          if(Number(bayNo[0])%2 == 0)
          {
              cellId = $(this).attr('altrcellid').split('|')     
          }else{
              cellId.push(cellId_s);
          }         
      }, function() {
          $(".qc_rows").removeClass('onmouseover');      
      })
    
  $('.qc_rows').off('click').on('click',function()
  {  
	//alert("Row clicked")
	/*if ($(".tally_swap_btn").val()=='Cancel<br /> Job')
	{
		showAlerts("Please cancel the selected job, before proceeding to next job");
		return;
	}*/
	
    console.log("row clicked");   
    
    qc_rowClicks++;  
    var $tableRows=$(".hc_joblist_table tr");
    var v = $(this).data('refercontainer');
    var container = $(this).data('container');  
    $("#hidden_container_no").val(container);
    
    if(qc_rowClicks == 1) {
        $tableRows.removeClass("active");   
        $(".qc_rows").removeClass("active");         
        $("#qc_table tr[data-container='"+container+"']").addClass("active");
        
        /*v=v.split('#');      
        for(x=0;x < v.length; x++ )
          $("#qc_table tr[data-container='"+v[x]+"']").addClass("active");  
		*/  
        qc_rowClicks = 0;
        $("#selectedContainerNumberId").val(container);
       // scrollYardToRequestedContainer(container, $(this).attr('name'));   
        
    } else {
    }
  }).on('dblclick',function(e){
    e.preventDefault();
  });
  
  $( "#jobs_select" ).off('change').on('change',function() {
	  
//	  $(".yard_view_blk").html("<h3 align='center' style='padding-top: 75px'> No Yard View to display </h3>");
//	  $("#stackViewContainer").html("<h3 align='center' > No Stack View to display </h3>");
	  $("#currentBlockNumberInYardViewId").val('');
	  $("#che_stack_yard_block_id").html('');
	  $("#che_yard_block_id").html('');
	 
    var value = $(this).val();
    
    
    
	sendFilterChangedNotification(value);
    processjoblist(0,0,0,value,'filter');
    
  }); 
  
  function getJobCellId(clickedContainer){
	  /*
	  if($(clickedContainer).parent().parent().attr('mkind') == "DSCH" || $(clickedContainer).parent().parent().attr('mkind') == "RECV"){
	  		jobCellId = $(clickedContainer).parent().parent().attr('cellid');
	  }else{
	  		jobCellId = $(clickedContainer).parent().parent().attr('name');
	  }*/
	  jobCellId = $(clickedContainer).parent().parent().attr('name');
	  console.log("getJobCellId -> jobCellId: "+ jobCellId);
	  return jobCellId;
  }
  
  function sendFilterChangedNotification(jobFilterValue){
	 
	  $("#layout").mask("Loading...");
	  $.ajax({
	      type:   "POST",
	      url:  "/app/Che/update_job_filter_change",
	      data:
	      {
	    	  jobFilterValue:jobFilterValue
	      },
	      success:function(result){
	    	  $("#layout").unmask();		
	          console.log("Filter Changed Notification sent");
	          
	      },
			error: function() {
				$("#layout").unmask();				
			}
	  });
  }
  
  function joblist_refresh() {
  		
	  $("#layout").mask("Loading...");
	  
		$('.refresh_joblist').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			type: "POST",
			url: "/app/Che/joblist_refresh",
			success: function(result) {
				$("#layout").unmask();	
				if (result != "Error") {
					$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
				} else {
					$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
				}	
			},
			error: function() {
				$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
				$("#layout").unmask();				
			}
		});
	}
  
	function getdamageCrctnScreen(){
		
		   var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
		   console.log("backreachContnr"+backreachContnr)
		   if((backreachContnr.indexOf("HATCHCOVER")!= -1)||(backreachContnr.indexOf("MANCAGE")!= -1)||(backreachContnr.indexOf("BREAKBULK")!= -1)){
		      console.log("backreach found")
		      showAlerts("Damage cannot be corrected for Backreach Job")
			  return false;
		   } 
		   else{
					console.log("dc clkd")
					cntr=$("#hidden_container_no").val();
					console.log("cntr"+cntr);
					$.ajax({
						url: "/app/Che/getdamageCrctnScreen",
						success: function(result) {
							$('#light').html("")
							$('#light').html(result);
							document.getElementById('light').style.display = 'block';
							$("#containerID").val(cntr);
							if($("#containerID").val(cntr) != ""){
								$("#goBtn").click();
							}
						}
					});
					return false;
				}
	}
  
	
	   function get_stackview(){
		   return true;
           var cell_lo = $(".active").attr("cellid").split(".")
           $.ajax({
              type: "POST",
              url: "/app/Che/stack_view",
              data: { 
                blockNumber: cell_lo[0],
                stackNumber: cell_lo[1],
                getStack:'FIRST_STACK'
              },
              success: function(result){
                var stackObj = $(result).attr("value");
                no_trs = stackObj.split('~')[5]
                //stackObj = stackViewMessage;
                //$("#che_stack_yard_block_id").html(tempStackBlockNumber+ " - "+tempStackNumber);  
                if (stackObj.split('~')[2]!='' && stackObj.split('~')[3]!=''){
                //$("#currentStackNumberInStackViewId").val(stackObj.split('~')[2]);
                  //processStackViewMessage(stackObj, stackType);
                   $('#light').html("asdfdfsdf")
                       $('#light').html(processStackViewMessage(stackObj, 'FIRST_STACK'))
                }else
                {   
              //    $("#stackViewContainer").html("<h3 align='center' > No Stack View to display </h3>");
                }
               // $("#layout").unmask();
                
              },
                error: function (textStatus, errorThrown) {
                 // $("#layout").unmask();
                  showAlerts("Error getting Stack details.");
                }
            });
              }