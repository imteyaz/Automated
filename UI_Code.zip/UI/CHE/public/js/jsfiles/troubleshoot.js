//@ sourceURL=troubleshoot.js  

$(document).ready(function(){
  console.log("ready");
  $(".troubleshoot_dropdown").msDropdown({roundedBorder:false});
  console.log("afterready");
  //search method
  $.extend($.expr[":"], {
    "containsIN": function(elem, i, match, array) {
      return (elem.textContent || elem.innerText || "").toLowerCase().indexOf( (match[3] || "").toLowerCase()) >= 0;
    }
  });
  
 $("#search_troubleshoot").keyup(function() {
   var value = $('#search_troubleshoot').val();
   if (value.length == 0)
     $('#troubleshoot_table tr').show()
   else {
     $("#troubleshoot_table tr:not('#troubleshoot_table .tableheader')").hide();
     $("#troubleshoot_table td.searchItem:containsIN('" + value + "')").parents("#troubleshoot_table tr").show();
   }
  });
     
});

$('.container_info').on('click', function (e) {                                // Adding class when container or to location is getting clicked.
    $(this).children('td').children('input').toggleClass("cntr_selected");
});

// function to send and getting the clicked container with to location,troubleshoot area and code.
function sendTroubleShootReq(){
  console.log($(".ContrDetails .cntr_selected").length);
  if($(".ContrDetails .cntr_selected").length <= 0){
    console.log('Container not selected');
    showAlerts('Please select a container.');
    return;
  }
  
  var selected_containers = [];
  var selected_to_location = [];
  var troubleshoot_area = [];
  var troubleshoot_code = [];
  
    $(".ContrDetails .cntr_selected").each(function(){
    if($(this).hasClass("contrBtnFun")){
      selected_containers += $(this).val() + "|";
    }
    else if($(this).hasClass("itvBtnFun")){
      selected_to_location = $(this).val();
    }
  });
  
  $(".regular-checkbox").each(function(){
  if(this.checked) {
    troubleshoot_code += $(this).parent().parent().find(".troubleshoot_dropdown").val()+ "|";
    troubleshoot_area += $(this).parent().parent().find(".troubleshoot_area h4").html() + "|";
   }
  });
  
  closePopup();
  $.ajax({
      type:   "POST",
      url:  "/app/Hc/sendTroubleShootReq",
      data: {
        selected_containers : selected_containers,
        selected_to_location :  selected_to_location,
        troubleshoot_area : troubleshoot_area,
        troubleshoot_code : troubleshoot_code
      },
      success:function(result){
      }
    });
}