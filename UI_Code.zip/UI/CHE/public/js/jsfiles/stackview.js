// Date: 04 June 2015
// Display stack view

const NUMBER_CELL = 1, // Cell types
	DATA_CELL = 2,
	ALPHA_CELL = 3;

var rowCount = 0,
	cellHeight = 0,
	cellWidth = 0,
	secondRowCount = 0,
	msgStackNumber = 0,
	msgSecondStackNumber = 0;
var no_trs = 0;
var scroll_lft_px = 0;
function processStackView(tempStackBlockNumber, tempStackNumber, getStack, stackType) {
	//stackViewMessage = "1~1~3003~1111112~19~A^B^C^D^E^F^G^H^J^K~0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^$0^^^^^^|1^^^^^^$1^^^^^^$1^MEDU1518403^F^F^F^10.8^SHJ^#B3CC68^$1^MEDU1111402^F^F^F^13.7^UQR^#B3CC68^$1^DFSU1482678^F^F^F^10.7^UQR^#B3CC68^$1^^^^^^$1^DFSU2745444^F^F^F^27^KBX^#B3CC68^$1^^^^^^$1^IPXU3154083^F^F^F^21.7^DMM^#B3CC68^$1^^^^^^|1^DFSU1513336^F^F^F^5.9^JEA^#B3CC68^$1^MSCU3707523^F^F^F^20.3^UQR^#B3CC68^$1^MEDU2749942^F^F^F^20.1^JEA^#B3CC68^$1^GLDU5000977^F^F^F^13.7^UQR^#B3CC68^$1^MEDU2268525^F^F^F^10.8^UQR^#B3CC68^$1^GATU0397659^F^F^F^27.8^JEA^#B3CC68^$1^FCIU4375094^F^F^F^24.4^JEA^#B3CC68^$1^MSCU3433654^F^F^F^24.5^JEA^#B3CC68^$1^TEMU4336848^F^F^F^20.9^DMM^#B3CC68^$1^MSCU6808775^F^F^F^24.5^JEA^#B3CC68^|1^MEDU2601976^F^F^F^25.2^DOH^#B3CC68^$1^MEDU1906271^F^F^F^10.2^JEA^#B3CC68^$1^MEDU3602323^F^F^F^16.1^UQR^#B3CC68^$1^MEDU3415580^F^F^F^13.8^UQR^#B3CC68^$1^TCLU2493218^F^F^F^13.8^UQR^#B3CC68^$1^TCLU2444487^F^F^F^27.9^JEA^#B3CC68^$1^MEDU3571310^F^F^F^27.3^NHS^#B3CC68^$1^FCIU4498587^F^F^F^24.4^JEA^#B3CC68^$1^MEDU3015814^F^F^F^20.2^DMM^#B3CC68^$1^MSCU3224757^F^F^F^20.3^JEA^#B3CC68^|1^MSCU6688200^F^F^F^11.9^DMM^#B3CC68^$1^XINU1502745^F^F^F^11.8^JEA^#B3CC68^$1^CAIU3191936^F^F^F^16^UQR^#B3CC68^$1^MEDU2425054^F^F^F^13.8^UQR^#B3CC68^$1^MEDU2797745^F^F^F^13.8^UQR^#B3CC68^$1^CARU3081827^F^F^F^13.8^UQR^#B3CC68^$1^MSCU2685630^F^F^F^3.9^JEA^#B3CC68^$1^MSCU2698849^F^F^F^26.2^BQM^#B3CC68^$1^MEDU1307484^F^F^F^24.3^SWK^#B3CC68^$1^GLDU2274697^F^F^F^20.2^JEA^#B3CC68^|1^MSCU1591820^F^F^F^12.8^DMM^#B3CC68^$1^CAIU2910845^F^F^F^10.5^JEA^#B3CC68^$1^TTNU1654344^F^F^F^16^UQR^#B3CC68^$1^TGHU3554024^F^F^F^13.8^UQR^#B3CC68^$1^CAIU2712449^F^F^F^13.6^UQR^#B3CC68^$1^MEDU2386873^F^F^F^13.8^UQR^#B3CC68^$1^TGHU2276715^F^F^F^29.7^UQR^#B3CC68^$1^MEDU3427262^F^F^F^22.4^DMM^#B3CC68^$1^MEDU2861551^F^F^F^29.8^UQR^#B3CC68^$1^IALU8224375^F^F^F^16^UQR^#B3CC68^~,";
	//stackViewMessage = "3003~-69760108~05~A^B^C~1^^^$1^^^$1^^^|1^^^$1^^^$1^^^|1^Cntr48014^#B3CC68^$1^Cntr48114^#B3CC68^$1^Cntr48214^#B3CC68^|1^Cntr48013^#174D8D^$1^Cntr48113^#174D8D^$1^Cntr48213^#174D8D^|1^Cntr48012^#16FB00^$1^Cntr48112^#16FB00^$1^Cntr48212^#16FB00^|1^Cntr48011^#E31925^$1^Cntr48111^#E31925^+$1^Cntr48211^#E31925^+~1003~T2";
	//processStackViewMessage(stackViewMessage, stackType);
	//processStackViewMessage(stackViewMessage, stackType);
	//$("#layout").mask("Loading...");
	$("#currentBlockNumberInYardViewId").val(tempStackBlockNumber);
	$("#currentStackNumberInStackViewId").val(tempStackNumber);

	$.ajax({
		type: "POST",
		url: "/app/Che/stackView",
		data: {
			blockNumber: tempStackBlockNumber,
			stackNumber: tempStackNumber,
			getStack: getStack
		},
		success: function(result) {
			var stackObj = result;
			no_trs = stackObj.split('~')[5]
			if (stackObj.split('~')[2] != '' && stackObj.split('~')[3] != '') {
				$("#currentStackNumberInStackViewId").val(stackObj.split('~')[2]);
				$.ajax({
					url: "/app/Che/generate_stack_view_popup",
					success: function(result) {
						$('#light').html("")
						$('#light').html(result);
						$("#light").addClass("stack_pop_cls")
						$("#secondStackViewContainer").html(processStackViewMessage(stackObj, stackType))
						document.getElementById('light').style.display = 'block';
						 $(".popup_page").css("width","90%");
						$(".stack_view_cell_alpha").parent().children(".stack_cell").css("border", "0px solid")
					}
				});
			}
		},
		error: function(textStatus, errorThrown) {
			// $("#layout").unmask();
			showAlerts("Error getting Stack details.");
		}
	});
	return false;
}

function loadStackForRequestedContainer(container, cellid) {
	// var tempStackBlockNumber = parseInt(cellId.toString().split('.')[0],
	// 	tempStackNumber = parseInt(cellId.toString().split('.')[2];

	// $(".stack_view_cell").removeClass("highlight_container");
	// if(stackBlockNumber != tempStackBlockNumber){
	// 	console.log("container " + container + " not present in  block " + stackBlockNumber);
	//     if(stackNumber != tempStackNumber){
	//     	getStackViewData(tempStackBlockNumber, tempStackNumber, container);
	//     }

	//  	}else{
	// }

}

//Gets yard view data from server for requested block
function getStackViewData(tempStackBlockNumber, tempStackNumber, container) {

	$.ajax({
		type: "POST",
		url: "/app/Che/getStackViewData",
		success: function(data) {
			var result = $(data).attr("value");
			initialOffset = 0;
			displayYardView(result);
			if ($('div[cellid="' + container + '"]') != "" || $('div[cellid="' + container + '"]') != undefined || $('div[cellid="' + container + '"]') != "undefined") {
				$('div[cellid="' + container + '"]').addClass("highlight_container");

			}

		},
		error: function(textStatus, errorThrown) {
			showAlerts("Error getting the stack details");
		}
	});
	return false;
}

function processStackViewMessage(stackViewMessage, stackType) {
	console.log("Start: " + Date());
	//alert(stackViewMessage);

	//stackViewMessage.split('~')[3]
	var rowData;
	if (stackViewMessage.split('~').length > 3) {
		rowData = stackViewMessage.split('~')[3].split('^');
	}

	var stackViewObj = decodeStackViewMessage(stackViewMessage);
	createStackView(stackViewObj, rowData);
	/*if(stackType == FIRST_STACK){
	 $("#stackViewContainer").html(htmlContent);
	 $(".stack_arrows").show();
	 }else{ //TODO: If implementing animation for displaying next stack, make changes in the else section
	 $("#stackViewContainer").html(htmlContent)
	 }*/
	console.log("End: " + Date());
}

function decodeStackViewMessage(stackViewMessage) {
	stackDetailsArray = [];
	if (stackViewMessage != undefined) {
		var result1 = stackViewMessage.split('~');//stackViewMessage.split(',')[0].split('~');//stackViewMessage.split('~'), // split various sections
		stackDetailsArray.push(getSecondStackViewData(result1));

		/*if (stackViewMessage.split(',').length>1){
		 if (stackViewMessage.split(',')[1].split('~').length>3){
		 var result2 = stackViewMessage.split(',')[1].split('~');
		 //alert("After Split ~ --->"+result2);
		 stackDetailsArray.push(getSecondStackViewData(result2));
		 }
		 }*/
	}
	return stackDetailsArray;
}

function getStackViewData(result2) {
	msgStackNumber = result2[2];
	stackAlphas = result2[3].split("^"),
	rows = result2[4].split('|'),
	rowCntr = [],
	rowObj = { };
	// Emplty Stack.
	if (stackAlphas.length == 0) {
		return rowCntr;
	}

	stackBlockNumber = 50;
	rowCount = rows.length;
	secondRowCount = rows.length;
	//cellHeight = 128/rows.length;
	//cellWidth =  210/stackAlphas.length;

	cellHeight = 100 / rows.length;
	cellWidth = 197 / stackAlphas.length;

	if (cellHeight < cellWidth) {
		cellWidth = cellHeight;
	} else {
		cellHeight = cellWidth;
	}

	addStackViewPadding(rows.length, cellHeight, stackAlphas.length);

	//For container cells
	for (var k = 0; k < rows.length; k++) {
		var tempCols = rows[k].split('$');
		for (var j = 0; j < tempCols.length; j++) {
			if (tempCols[j].split('^').length > 1) {
				//rowObj[j] = {container: Math.floor(Math.random()*16777215).toString(16), cellid: tempCols[j].split('^')[1], cellStatus: tempCols[j].split('^')[0]};
				var row_data = tempCols[j].split('^')
				var iso = typeof (row_data[8])
				var mv_knd = typeof (row_data[9])
				var cont_cat = typeof (row_data[10])
				if (iso == "undefined") {
					iso = ""
				} else {
					iso = row_data[8]
				}
				if (mv_knd == "undefined") {
					mv_knd = ""
				} else {
					mv_knd = row_data[9]
				}
				if (cont_cat == "undefined") {
					cont_cat = ""
				} else {
					cont_cat = row_data[10]
				}
				
				rowObj[j] = { container: row_data[2], cellid: row_data[1], cellStatus: row_data[0], isfourty: row_data[3], is_refer: row_data[4], is_hazr: row_data[5], is_oog: row_data[6], is_dmged: row_data[7], yard_pos: row_data[11], iso: iso, move_knd: mv_knd,cont_cat: cont_cat };
				//rowObj[j] = {container: tempCols[j].split('^')[2], cellid: tempCols[j].split('^')[1], cellStatus: tempCols[j].split('^')[0]};
			} else {
				var row_data = tempCols[j].split('^')
				rowObj[j] = { container: "#DCDCDC", cellid: row_data[1], cellStatus: row_data[0] };
			}
		}
		rowCntr.push(rowObj);
		rowObj = { };
	}
	//For alphabets at the bottom
	/*for(k = stackAlphas.length -1; k >= 0; k--){
	 rowObj[k] = {container: "fff", cellid: stackAlphas[k], cellStatus: "3"};
	 }*/

	for (k = 0; k < stackAlphas.length; k++) {
		rowObj[k] = { container: "fff", cellid: stackAlphas[k], cellStatus: "3" };
	}

	rowCntr.push(rowObj);
	rowObj = { };

	return rowCntr;

}

function getSecondStackViewData(result2) {
	var stackAlphas = result2[3].split("^"),
		rows = result2[4].split('|'),
		rowCntr = [],
		rowObj = { };
	msgSecondStackNumber = result2[2];

	// Emplty Stack.
	if (stackAlphas.length == 0) {
		return rowCntr;
	}

	stackBlockNumber = 50;
	rowCount = rows.length;
	secondRowCount = rows.length;
	//cellHeight = 128/rows.length;
	//cellWidth =  210/stackAlphas.length;

	cellHeight = 100 / rows.length;
	cellWidth = 197 / stackAlphas.length;

	if (cellHeight < cellWidth) {
		cellWidth = cellHeight;
	} else {
		cellHeight = cellWidth;
	}

	//addStackViewPadding(rows.length,cellHeight,stackAlphas.length);

	//For container cells
	for (var k = 0; k < rows.length; k++) {
		var tempCols = rows[k].split('$');
		for (var j = 0; j < tempCols.length; j++) {
			if (tempCols[j].split('^').length > 1) {
				//rowObj[j] = {container: Math.floor(Math.random()*16777215).toString(16), cellid: tempCols[j].split('^')[1], cellStatus: tempCols[j].split('^')[0]};
				var row_data = tempCols[j].split('^')
				var iso = typeof (row_data[8])
				var mv_knd = typeof (row_data[9])
				var cont_cat = typeof (row_data[10])
				if (iso == "undefined") {
					iso = ""
				} else {
					iso = row_data[8]
				}
				if (mv_knd == "undefined") {
					mv_knd = ""
				} else {
					mv_knd = row_data[9]
				}
				if (cont_cat == "undefined") {
					cont_cat = ""
				} else {
					cont_cat = row_data[10]
				}
				rowObj[j] = { container: row_data[2], cellid: row_data[1], cellStatus: row_data[0], isfourty: row_data[3], is_refer: row_data[4], is_hazr: row_data[5], is_oog: row_data[6], is_dmged: row_data[7], yard_pos: row_data[11], iso: iso, move_knd: mv_knd, cont_cat: cont_cat};
			} else {
				var row_data = tempCols[j].split('^')
				rowObj[j] = { container: "#DCDCDC", cellid: row_data[1], cellStatus: row_data[0], is_refer: row_data[4], is_hazr: row_data[5], is_oog: row_data[6], is_dmged: row_data[7], yard_pos: row_data[11], iso: iso, move_knd: mv_knd, cont_cat: cont_cat };
			}
		}
		rowCntr.push(rowObj);
		rowObj = { };
	}
	//For alphabets at the bottom
	/*for(k = stackAlphas.length -1; k >= 0; k--){
	 rowObj[k] = {container: "fff", cellid: stackAlphas[k], cellStatus: "3"};
	 }*/

	for (k = 0; k < stackAlphas.length; k++) {
		rowObj[k] = { container: "fff", cellid: stackAlphas[k], cellStatus: "3" };
	}

	rowCntr.push(rowObj);
	rowObj = { };

	return rowCntr;

}

function createStackView(stackViewObj, rowData) {
	//	alert("createStackView")
	if (stackViewObj[0].length == 0) {
		//  $("#stackViewContainer").html('<h3 align="center" style="padding-top: 75px;margin-left: -24%;"> No Stack View to display </h3>');
	} else {
		var totalStacksView;
		var totalStackView1;
		//alert("Before Converting HTML-1nd->"+stackViewObj[0]);
		$("#secondStackViewContainer").html('');
		totalStacksView = getSecondStackViewHtml(stackViewObj[0], rowData);
		$("#stackViewContainer").html(totalStacksView);
		$("#che_stack_yard_block_id").html($('#currentBlockNumberInYardViewId').val() + " - " + $('#currentStackNumberInStackViewId').val());

		$('div[cellid="' + $("#selectedContainerNumberId").val() + '"]').addClass("highlight_container");

		var selectedYardPositionValue = $("#currentYardLocationId").val().toString().split('.');

		if (selectedYardPositionValue.length > 3)
			$('div[yardPos="' + selectedYardPositionValue[2] + selectedYardPositionValue[3] + '"]').addClass("highlight_container");

		/*if (stackViewObj.length>1){
		 //alert("Before Converting HTML-2nd->"+stackViewObj[1]);
		 totalStacksView1 = getSecondStackViewHtml(stackViewObj[1]);//getSecondStackViewHtml(stackViewObj[1]);
		 //alert("HTML Content--->"+totalStacksView1);
		 $("#secondStackViewContainer").html(totalStacksView1);
		 } */
	}
}

function getStackViewHtml(firstStackViewObj) {
	var currContent = '<ul>';
	var isTopRow = true;
	rowCount = firstStackViewObj.length - 1;
	$.each(firstStackViewObj, function(key, value) { // Create cells row wise

			currContent += "<li><div class='stack_cell' style='line-height:10%;'>";

			if (rowCount) {
				currContent += rowCount;
			} else {
				currContent += ' ';
			}

			currContent += "</div>";
			rowCount--;
			$.each(value, function(ke, val) {
					if (val.cellStatus == 0) {
						if (isTopRow)
							currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell  stack_top_row' style='width:20%;height:10%; background:#C0C0C0;'></div>";
						else
							currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell' style='width:20%;height:10%; background:#C0C0C0;'></div>";
					} else if (val.cellStatus == "3") {
						currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell stack_view_cell_alpha' style='border:0px;width:20%;height:10%;background:#" + val.container + "'>" + val.cellid + "</div>";
					} else {
						if (isTopRow)
							currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell stack_top_row' style='width:20%;height:10%;background:" + val.container + "'></div>";
						else
							currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell' style='width:20%;height:10%;background:" + val.container + "'></div>";
					}

				});
			isTopRow = false;
			currContent += "</li>";
		});

	currContent += "</ul>";

	return currContent;
}

function addStackViewPadding(numberOfRows, containerHeight, numberOfColumns) {
	//paddingValue = (5 - numberOfRows) * 15 + 40; // 21 is height of each cell
	var totalHeight = containerHeight * numberOfRows;
	var totalWidth = containerHeight * numberOfColumns;
	var paddingTop = 0, paddingLeft = 0;
	if (totalHeight < 128) {
		paddingTop = 128 - totalHeight;
	}

	if (totalWidth < 210) {
		paddingLeft = (210 - totalWidth) / 2;
	}

	console.log("paddingTop" + paddingTop);
	$("#stackViewContainer").css("padding-top", paddingTop + "px");
	$("#stackViewContainer").css("padding-left", paddingLeft + "px");
	$("#secondStackViewContainer").css("padding-top", paddingTop + "px");
	$("#secondStackViewContainer").css("padding-left", paddingLeft + "px");
}

$.fn.hasVerticalScrollBar = function() {
	if (this[0].clientHeight < this[0].scrollHeight) {
		return true
	} else {
		return false
	}
}

$.fn.hasHorizontalScrollBar = function() {
	if (this[0].clientWidth < this[0].scrollWidth) {
		return true
	} else {
		return false
	}
}

function moveStackViewLeft() {
	var curStackNumber = $('#currentStackNumberInStackViewId').val();
	if ($('#currentBlockNumberInYardViewId').val() != '' && curStackNumber != '')
		processStackView($('#currentBlockNumberInYardViewId').val(), curStackNumber, 'P', OTHER_STACK);
}

function moveStackViewRight() {
	var curStackNumber = $('#currentStackNumberInStackViewId').val();
	if ($('#currentBlockNumberInYardViewId').val() != '' && curStackNumber != '')
		processStackView($('#currentBlockNumberInYardViewId').val(), curStackNumber, 'N', OTHER_STACK);
}

/*
 $(".stack_arrow_left").click(function(eventObj){
 // TODO - Not sure about when & how to increment blocknumber.
 processStackView(yarBlockNumber, stackNumber - 1,'P', OTHER_STACK);
 });

 $(".stack_arrow_right").click(function(eventObj){
 // TODO - Not sure about when & how to decrement blocknumber.
 processStackView(yarBlockNumber, stackNumber + 1, 'N',OTHER_STACK);
 });*/

function getSecondStackViewHtml(secondStackViewObj, rowData) {
	var conts = []
	$(".qc_rows").each(function() {
		conts.push($(this).data("container"))
	})
	var currContent = "<ul style='list-style-type: none;'>";
	var isTopRow = true;
	var rowNosList = rowData;//['A','B','C','D','E','F','G','H','J','K','L','M','N','P','Q','R','S','T','U','V','X','Y','Z'];
	var tearNos = no_trs * 1;
	console.log(rowNosList.length)
	console.log("no of rows")
	var cell_wdth = (100 / rowNosList.length) - 2
	console.log(cell_wdth)
	console.log("width of each cell")
	var cell_height = (20 / no_trs); // include stack hight
	var first_part_height = cell_height / 3;
	console.log(tearNos)
	console.log("inside stack view teir nis")
	var yardPosition = '';
	rowCount = secondStackViewObj.length - 1;
	var unq_id = 0;
	$.each(secondStackViewObj, function(key, value) { // Create cells row wise
			currContent += "<li><div class='stack_cell' style='width:" + cell_wdth + "%;height:" + cell_height + "em;'>";
			if (rowCount) {
				currContent += rowCount;
			} else {
				currContent += ' ';
			}

			currContent += "</div>";
			rowCount--;
			var counter = 0;
			$.each(value, function(ke, val) {
				currContent += "<div class='stack_li_div'>"
					yardPosition = rowNosList[counter] + tearNos;
					if (val.cellStatus == 0) {
						if (isTopRow)
							currContent += "<div class='stack_view_cell' style='width:" + cell_wdth + "%;height:" + cell_height + "em;'><div>x</div></div>";
						else
							currContent += "<div class='stack_view_cell' style='width:" + cell_wdth + "%;height:" + cell_height + "em;'><div>&nbsp;</div></div>";
					} else if (val.cellStatus == "3") {

						currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " yardPos = " + yardPosition + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell stack_view_cell_alpha' style='border:0px;width:" + cell_wdth + "%;height:" + cell_height + "em;background:#" + val.container + "'><div class='stck_cntr_no'>" + val.cellid + "</div></div>";
					} else {
						var fourtyContainer = '';
						var backGroundColor = "background:" + val.container;
						if (val.isfourty != undefined && val.isfourty != '') {
							fourtyContainer = val.isfourty;
							backGroundColor = '';
						}
						if (isTopRow) {
							currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " yardPos = " + yardPosition + " cellid=" + val.cellid + " id=" + ke + " class='stack_view_cell ' onclick=hight_ligh_cell('"+val.cellid+"') style='width:" + cell_wdth + "%;height:" + cell_height + "em;'><div class='stck_first_part' style='height:" + first_part_height + "em;'><div class='stck_iso_no'>&nbsp;" + val.iso + "</div><div class='stck_mv_typ'>&nbsp;" + val.move_knd + "</div><div class='stck_cont_cat'>&nbsp;" + val.cont_cat + "</div></div><div style=" + backGroundColor + " class='stck_cntr_no'><div class='cnt_frst_half'>&nbsp;" + fourtyContainer + "" + val.cellid.substring(0, 4) + "</div><div class='cnt_sec_half'>" + val.cellid.substring(4, 11) + "</div></div></div>";
						} else {
							var className = '';
							var onclicEvent = "";
							if (val.cellid != '') {
								className = "stack_view_cell ";
								//if (conts.indexOf(val.cellid) == -1) {
									onclicEvent = "onclick=hight_ligh_cell('"+val.cellid+"');return true;getContainerDetailsPopup('" + val.yard_pos + "','" + val.cellid + "','" + val.is_dmged + "')";
								//} else {
								//	onclicEvent = "onclick=return true"
							//	}
								currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " yardPos = " + yardPosition + " cellid=" + val.cellid + " id=" + ke + " class='" + className + "' style=width:" + cell_wdth + "%;height:" + cell_height + "em;" + backGroundColor + " " + onclicEvent + "><div class='stck_first_part' style='height:" + first_part_height + "em;'><div class='stck_iso_no'>&nbsp;" + val.iso + "</div><div class='stck_mv_typ'>&nbsp;" + val.move_knd + "</div><div class='stck_cont_cat'>&nbsp;" + val.cont_cat + "</div></div><div class='stck_cntr_no'><div class='cnt_frst_half'>&nbsp;" + fourtyContainer + "" + val.cellid.substring(0, 4) + "</div><div class='cnt_sec_half'>" + val.cellid.substring(4, 11) + "</div></div></div>";
							} else {
								className = "stack_view_cell";
								currContent += "<div yrd_pos=" + val.yard_pos + " is_damged=" + val.is_dmged + " is_refer=" + val.is_refer + " is_hazr=" + val.is_hazr + " is_oog =" + val.is_oog + " yardPos = " + yardPosition + " cellid=" + val.cellid + " id=" + ke + " class='" + className + "' style=width:" + cell_wdth + "%;height:" + cell_height + "em;" + backGroundColor + " " + onclicEvent + "><div class='stck_first_part' style='height:" + first_part_height + "em;'><div class='stck_iso_no'>&nbsp;" + val.iso + "</div><div class='stck_mv_typ'>&nbsp;" + val.move_knd + "</div><div class='stck_cont_cat'>&nbsp;" + val.cont_cat + "</div></div><div style='margin-right: 20%;' class='stck_cntr_no'><div class='cnt_frst_half'>&nbsp;" + fourtyContainer + "" + val.cellid.substring(0, 4) + "</div><div class='cnt_sec_half'>" + val.cellid.substring(4, 11) + "</div></div></div>";
							}
						}
					}
					counter++;
					currContent += "</div>"
				});
			isTopRow = false;
			currContent += "</li>";
			tearNos--;
			unq_id++;
		});

	currContent += "</ul>";
	return currContent;
}
function get_stackview() {
	var cell_loc = ""
	if ($(".active").attr("mkind") == "DSCH" || $(".active").attr("mkind") == "MI" || $(".active").attr("mkind") == "GI") {
		cell_loc = $(".active .job_to").html().trim().split(".")
	} else {
		cell_loc = $(".active .job_from").html().trim().split(".")
	}
	processStackView(cell_loc[0], cell_loc[1], '');

}

function hight_ligh_cell(cell_id){
	$(".stack_view_cell").removeClass("stack_highlighetd_cell")
	$("div[cellid="+cell_id+"]").addClass("stack_highlighetd_cell")
}

function slide_left(){
	scroll_lft_px -= 200;
	$("#stackViewContainer").scrollLeft(scroll_lft_px);
}

function slide_right(){
	scroll_lft_px += 200;
	$("#stackViewContainer").scrollLeft(scroll_lft_px);
}