var dmg_rcd =[]

  $(document).ready(function(){
	  
    virtualKeyboard();
    
  /*  $(".updatepool_row_first").on("click", function() {
      var color = $( this ).css( "background-color" );
      $(".updatepool_row_first").css("background-color", "#fff");
      $(this).css("background-color", "#04b54f");
      if(color == "rgb(4, 181, 79)"){
        $(".updatepool_row_first").css("background-color", "#fff");
      }
    }); */
    
    
    $(".update_attr_check").click(function(event){  
    	
    	$(".tally_swap_btn").html('Select<br/> Job');
    	
      var errorMessage = "";
      
      if($("#hdnMoveKind").val() == "DSCHtype"){
      errorMessage = validateToLocation();
      }
      console.log("errorMessage " + errorMessage);
      
      if(errorMessage != ""){
        showAlerts(errorMessage) ; 
      }else{
        console.log("inside tally_confirm click");
        console.log($("#hdnContainers").val());
        container_confirm = true;
        processjob($("#hdnContainers").val());
        $("#search_joblist").val('');
        troubleDamageClicked = false;
      }
      
    });
    
    document.getElementById("to-location-data").maxLength = "11";
    
  });
  
  function validateToLocation(){
    
    var toLocation = $("#to-location-data").val();
    console.log("toLocation" +toLocation)
    if(toLocation == "" || toLocation == "undefined"){
      return "Please enter To Location";
    }else{
      toLocation = toLocation.split(".");
      if(toLocation[0] == "" || toLocation[1] == "" || toLocation[2] == "" || toLocation[3] == ""){
        return "Please enter To Location in proper format.";
      }
      
      if(toLocation.length != 4 || isNaN(toLocation[1]) || !(/^[a-zA-Z]$/.test(toLocation[2])) || !(/^\d$/.test(toLocation[3])) ){
        return "Please enter To Location in proper format.";
      }
    }
    return "";
  }
  
  function processjob(containerno)
  {
    var fromCelllocation="";
    var toCelllocation="";
    var itvno=""
    var movekind=""
    var baycelllocation=""
	var pos_on_chs = ""
	var pos_on_chas_itv = ""
	var categoryInfo = "";
	
    $('.cntrhndltbl td[name="fromData"]').each( function(){
      
      movekind = $(this).attr('movekind');
      categoryInfo += $(this).attr("category") + "|";
      
      if(movekind == "DSCH" || movekind == "RECV" || movekind == "MI" || movekind == "GI" || movekind == "RH")
      { 
        if ($('#confirmAllocationRorationId').val().trim()!='')
          fromCelllocation += $('#confirmAllocationRorationId').val().trim()+"-"+$(this).text().trim()+"|";  
        else 
          fromCelllocation += $(this).text().trim()+"|";   
         
        baycelllocation = getcelllocationforbayupdate($(this).text(),baycelllocation);
      }
      else
        fromCelllocation += $(this).text()+"|";
    })
	
	if(categoryInfo != "") {
		categoryInfo = categoryInfo.slice(0, -1);
	}
    
    $('.cntrhndltbl .toData').each( function(){
      movekind = $(this).attr('movekind');
      if(movekind == "LOAD" || movekind == "DLVR" || movekind == "MO" || movekind == "GO")
       { 
         toCelllocation += $(this).val()+"|";    
         baycelllocation = getcelllocationforbayupdate($(this).text(),baycelllocation);
       }
      else
        toCelllocation += $(this).val()+"|";
    })
	
	 console.log("movekind"+movekind);

    pos_on_chs = $(".pos_on_chos .btn-success").text().trim();
    var tempContainer = containerno;
    if(movekind == "LOAD" || movekind == "DLVR" || movekind == "MO" || movekind == "GO"){
    	pos_on_chas_itv = toCelllocation;
    	if(containerno.split("^").length > 1) {
    		tempContainer  = containerno.split("^")[1];
    	}
    }
    else{
    	pos_on_chas_itv = fromCelllocation;
    }
	if((movekind == "LOAD" ||  movekind == "MO") && ($(".pos_on_chos .btn-success").attr("prev_val") != pos_on_chs)) {
    	send_position_on_chas(tempContainer,pos_on_chs,pos_on_chas_itv)
    }
	send_data(containerno,fromCelllocation.substring(0,fromCelllocation.length - 1),toCelllocation.substring(0,toCelllocation.length - 1),movekind,categoryInfo);
  } 
  
  function send_position_on_chas(containerno,pos_on_chs,pos_on_chas_itv){
	     $.ajax({
	         type:   "POST",
	         url:  "/app/Che/send_pos_on_chas",
	         data: {
	           container_no : containerno,
	           itv_no :  pos_on_chas_itv,
	           pos_on_chs: pos_on_chs
	         },
	         success:function(result){
	         }
	       });
  }
  
  function getcelllocationforbayupdate(cellId_org,celllocation)
  {
    console.log(cellId_org);
    cellId = cellId_org.split(".");
    bayno = Number(cellId[0]);
    if(bayno%2 == 0)
    {     
      if(celllocation.length == 0)
        celllocation = pad((bayno-1))+"."+cellId[1]+"."+cellId[2] + "|" + pad((bayno+1))+"."+cellId[1]+"."+cellId[2];
      else  
        celllocation = celllocation + "|" + pad((bayno-1))+"."+cellId[1]+"."+cellId[2] + "|" + pad((bayno+1))+"."+cellId[1]+"."+cellId[2]; 
    }
   else
   {
     if(celllocation.length == 0)
       celllocation = cellId_org;
     else 
       celllocation = celllocation + "|" +cellId_org;
   }
     
    return celllocation
  }
  
//  function getDamageRecordView(){
////    var containerNo = [];
////    $.ajax({
////      url:"/app/Che/getDamageRecordView",
////      success:function(result){
////        $('#light').html("")
////        $('#light').html(result)
////        document.getElementById('light').style.display='block'; 
////      }
////    })
//
//	  $('.btnDamage').attr("disabled", true).addClass("disable_btns");
//	  var movekind = $(".tally_cntrno").find("th[name='containerdata']").attr('movekind');
//	  console.log("movekind"+movekind);
//	  var containerNo = [];
//	    var cntrs = ""
//	    var itvs = ""
//	    var ground=""
//	     $("th[name='containerdata']").each(function(){
//	    	 cntrs += $(this).html()+"|"
//			 })
//		 console.log("cntrs"+ cntrs)
//	     $(".toData").each(function(){ 
//	       itvs += $(this).val()+"|"
//	     })
//		   console.log("itvs"+itvs)
//		  $("td[name='fromData']").each(function(){
//		          ground += $(this).html()+"|"
//		  })
//	        console.log("ground"+ground)
//	  $.ajax({
//		  url:"/app/Che/getDamageRecordView",
//	    data: {
//	      movekind:movekind,
//	      containers: cntrs, 
//	      itvs: itvs,
//	      ground:ground
//	    },
//	    success: function(result) {
//	      if(result != "false"){      
//	        $('#light').html("")
//	        $('#light').html(result)
//	        $("#itvDrpDwn").msDropdown({ roundedBorder: false });
//	        document.getElementById('light').style.display = 'block';
//	     //   displayITVNumber();
//	        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
//	      }else{
//	        console.log(result);
//	        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
//	      }
//	    }
//	  })
//  }
  
  function getTroubleShootView(){  
    var containerNo = [];
    $.ajax({
      url:"/app/Che/getTroubleShootView",
      success:function(result) { 
        $('#light').html("")
        $('#light').html(result)
        document.getElementById('light').style.display='block';
      }  
    });
  }
 
  
  function sendTroubleShootReq(){
   
    var itvNo = "";  
    var selContainerNo =  $("#t_container").val();
    var t_location = $("#t_location").val()
    var t_problem = []     
     
    $('#t_problem option:selected').map(function(a, item)
    {
      if(item.value != "")          
        t_problem.push(item.value)          
    });
                                   
    if(selContainerNo == "" || t_location == "" || t_problem.length == 0 ){
      showAlerts("Please fill all the details")                  
    }  
    else{    
      closePopup();        
      itvNo = $("#qc_table tr[data-container ='"+selContainerNo+"']").attr("name")
      $.ajax({
        type:   "POST",
        url:  "/app/Che/sendTroubleShootReq",
        data: {
          containerNo : selContainerNo,
          itvNo :  itvNo,
          t_location : t_location,
          t_problem: t_problem.join("|")
        },
        success:function(result){
        }
      });
    } 
  }
  
  $("#itv_search").on('change',function(){
    var itvNo = $("#itv_search").val();
    $('.cntrhndltbl .toData').val(itvNo);
    markColorToITV()  
  });
  
  $(document).ready(function(){
	 $("#itv_search").combobox();
	  $("#to-location-data").on("focus",function(){
          console.log("Changed");
          setTimerForEdit();
          $.ajax({
                 type:   "POST",
                 url:  "/app/Login/change_contr_edit_val",
                 success:function(result){
                 console.log(result)
                 }
             })
          
        })
        
      $("#itv_search").on("change",function(){
        console.log("Changed");
        setTimerForEdit();
        $.ajax({
               type:   "POST",
               url:  "/app/Login/change_contr_edit_val",
               success:function(result){
               console.log(result)
               }
           })
      })
                      
                      
        $(".updatepool_row_first").on("click",function(){
          console.log("updatepool_row_first");
          setTimerForEdit();
          $.ajax({
                 type:   "POST",
                 url:  "/app/Login/change_contr_edit_val",
                 success:function(result){
                 console.log(result)
                 }
             })
          
        })
	  
    
    $('.trouble_sht_btn').off('click').on('click',function(){
      getTroubleShootView();
    }); 
    
    $('#btnDamage').off('click').on('click',function(){
    	
    	 var backreachContnr=$(".tally_cntrno").html();  
    	    console.log("backreachContnr"+backreachContnr)
    	   if((backreachContnr.indexOf("HATCHCOVER")!= -1)||(backreachContnr.indexOf("MANCAGE")!= -1)||(backreachContnr.indexOf("BREAKBULK")!= -1)){
    	      console.log("backreach found")
    	      showAlerts("Damage cannot be recorded for Backreach Job")
    	      return false;

    	   } else{
    		  var isDamaged= $("#qc_table tr.active").attr("is_damaged"); 
    		  var activeRows= $("#qc_table tr.active");
    		  if(activeRows.length>1){
    			  activeRows.each(function(){
    				//  console.log("1")
    				 if($(this).attr("is_damaged")=="true"){
    					  isDamaged = "true";
    					  return false;
    				 }
    				 else{
    					 isDamaged = "false";
    				 }
    			  })
    		  }
    		  if(isDamaged=="false"||isDamaged==""){
    		  	getDamageRecordView();
    		  }
    		  else{
    			  getdamageCrctnScreen();
    		  }
    		  }
    });  
    
    markColorToITV();
    var clicked =  false;
    $(".updatepool_row_first").click(function(){
      $("#itv_search").val("");
      
        itvNo = $(this).find(".itv_truck_number").text();   
      if(!clicked){ 
        $('.cntrOprtns0 .toData').val(itvNo);
        $('.cntrOprtns1 .toData').val(itvNo);
        clicked = false;
        if ($( ".update_container_number table" ).hasClass( "cntrOprtns2" )) 
        {
          clicked =  true;  
        }
      }
      else if(clicked)
      {
        $('.cntrOprtns2 .toData').val(itvNo);
        $('.cntrOprtns3 .toData').val(itvNo);
        clicked = false;
      }
        markColorToITV()     
    });
    
        $(".toData").off('keyup').on('keyup',function(){
          $("#itv_search").val("");        
           markColorToITV();
         });  
                
        
        // joblist refresh stay in same container
        
        
        
  });
  
      function removeITV(itvNumber){
          $(".itv_poolview .cntr_no").each(function(){
            var currentITVNumber =$(this).find(".itv_truck_number").text();
            if(currentITVNumber == itvNumber){
             var currentClass='.cntr_no'+currentITVNumber;
              $(this).parent().find(currentClass).remove();
            }
            });
      
        }

  
      function markColorToITV(){
            
        $('.updatepool_row_first').removeClass("cntr_no_active")
        
        $('.cntrhndltbl .toData').each( function(){ 
                   itv_no =  $(this).val()
          $('.itv_truck_number').each( function(){
                 if(itv_no == $(this).text())
                 {
                   $(this).parent().addClass("cntr_no_active")
                 }          
               });
          });     
      }
