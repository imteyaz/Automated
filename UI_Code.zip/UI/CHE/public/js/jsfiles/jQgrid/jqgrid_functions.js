function prepare_actions_for_grid() {
	var ids = jQuery("#delayRec").jqGrid('getDataIDs');
	file:///C:/Users/1198195/Desktop/JqGrid/atomgrid/atomgrid/public/images/edit.png
			for (var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<img src='../../public/images/edit.png' class='adjust_edit_image edit_btn' onclick=\"jQuery('#delayRec').editRow('" + cl + "');toggle_save_btn('edit');\" />";
				se = "<img src='../../public/images/save.png' class='adjust_delete_image edit_btn' style='display:none;' onclick=\"toggle_save_btn('update');jQuery('#delayRec').saveRow('" + cl + "');\" />";
				ce = "<img src='../../public/images/delete_icon.png' class='adjust_delete_image' onclick=\"jQuery('#delayRec').restoreRow('" + cl + "');\" />";
				jQuery("#delayRec").jqGrid('setRowData', ids[i], { act: be + se + ce });
			}
}

function gridColumnUpdtbutton(gridrow) {
	updatebtn = "<img src='../../public/images/save.png' class='adjust_delete_image' onclick='saveGrid(" + gridrow + ")'/>"
	deletebtn = "<img src='../../public/images/delete_icon.png' class='adjust_delete_image' onclick=\"jQuery('#delayRec').jqGrid('delRowData','" + gridrow + "');\" />";
	jQuery("#delayRec").jqGrid('setRowData', gridrow, { action: updatebtn + deletebtn });
}
function addFunction() {
	var datarow = { container: "", iso: "", remark: " This a  new line " };
	var GridIds = $("#delayRec").getDataIDs();
	var last = GridIds[GridIds.length - 1];
	var last4sel = parseInt(last) + 1;
	var su = $("#delayRec").addRowData(last4sel, datarow, "first");
	if (su) {
		gridColumnUpdtbutton(last4sel);
		jQuery('#delayRec').editRow(last4sel, true);
		//toggle_save_btn('edit')
	}
	position:
			"last"

}
$(document).ready(function(){
	$("#confirm_button").on("click", function() {
		if ($(".editable").size() > 0) {
			alert("Please update the edited records or press cancel")
		} else {
			var fullData = jQuery("#delayRec").jqGrid('getRowData');
			for (var i = 0; i < fullData.length; i++) {
				console.log(fullData[i].iso)
			}
		}
	});
})