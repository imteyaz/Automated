//@ sourceURL=cheindex.js  
var allAlerts = [];
$('#progressbar').progressbar();
var m = 0, jobBlockNumber = 0;
var tempObj = {};
var rmgValue = initialRMG = maxWidthForRMG = 0;
var troubleDamageClicked = false;
var yardBlockNumber = 0, stackBlockNumber = 50, stackNumber = 0;
var append = true;
var manualmode = false;
var FIRST_STACK = 1, OTHER_STACK = 2;
var myVar = setInterval(function(){
    //myTimer()
}, 1000);
var no_of_times = 0;
var qchome_time, jobCellId='', yarBlockNumber='';

function myTimer()
{
    $.ajax({
        type:   "POST",
        url:  "/app/Login/containercheck",
        success:function(result){
        	
            if(result != ""){
            	console.log("Response: "+ result);
                shufflejobs(result)
            }
        }
    })
}

$("#btnJobSummary").click(function(event){
  document.getElementById('job_summary_popup').style.display = 'block';
})

$("#btnCloseJobSummary").click(function(event){
  document.getElementById('job_summary_popup').style.display = 'none';
})

function stoptimer()
{
    clearInterval(myVar)
}

function resettimer()
{
    myVar = setInterval(function(){
        myTimer()
    }, 5000);
}

function addRemoveDamageIcon(addRemoveDamageIconMsg){
	addRemoveDamageIconMsg = addRemoveDamageIconMsg.split("#");
	if(addRemoveDamageIconMsg[1] == "true"){
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").addClass("damage");
	}else{
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").removeClass("damage");
	}
}

function sendUnavailableRes() {
	var rmsdata = $("#rms_select").val()
	if (rmsdata == "") {
		showAlerts("Please Select One");
	} else {
	
		$.ajax({
			url: "/app/Che/send_unavailable_reason",
			data: {
				popupType: "avilable",
				rms_select: rmsdata
			},
			success: function(result) {
				$('#light').html("");
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
				$("#rms_timer").runner({
					autostart: true,
					milliseconds: false
				});
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			}
		});
		
		$('.unavilablereason').attr("disabled", true).addClass("disable_btns");
	}
}
function sendOpenDelayDetails() {
	if($("#hdnDelayCodeData").html() != "") {
		confirmYesOrNo($("#hdnDelayCodeData").html() + " delay exists. Do you want to close it?", sendUnavailableRes)
	} else {
		sendUnavailableRes("T");
	}
}

var sendUnavailableRes = function(delayCloseInfo) {
	var rmsdata = $("#rms_select").val()
	if (rmsdata == "") {
		showAlerts("Please Select One");
	} else {
		$('.unavilablereason').attr("disabled", true).addClass("disable_btns");
		$("#hdnSelectedDelay").val(rmsdata);
		$.ajax({
			url: "/app/Login/sendUnavailableRes",
			data: {
				popupType: "avilable",
				rms_select: rmsdata,
				delayCloseInfo: delayCloseInfo
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				$("#rms_timer").runner({
					autostart: true,
					milliseconds: false
				});
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			}
		});
	}
}

function sendAvailableRes() {
	var timerVal = $("#rms_timer").text();
	closePopup()
	$('.avilablereason').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Login/sendAvailableRes",
		data: {
			available_time: timerVal,
			selectedDelay: $("#hdnSelectedDelay").val()
		},
		success: function(result) {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		}
	});
}


function pad(d) {
    return (d < 10) ? '0' + d.toString() : d.toString();
}

function updateJobListReferColor(joblistReferDetails){
	  console.log("Inside updateJobListReferColor" + joblistReferDetails);
	  var referDetails = joblistReferDetails.split('~'),
	  	  containersInfo = referDetails[0].split('|'),
		  connectedContainers = '', disconnectedContainers="";
	  
	  for(var i = 0; i < containersInfo.length; i++){
		  var container = containersInfo[i].split('^');
		  if(container[1] == "T"){
			  connectedContainers += ".qc_rows[data-container='" + container[0] + "'],";
		  }else if(container[1] == "F"){
			  disconnectedContainers += ".qc_rows[data-container='" + container[0] + "'],";
		  }
	  }
	  
	  
	  if(connectedContainers != ""){
		  connectedContainers = connectedContainers.slice(0, -1);
	  }
	  
	  if(disconnectedContainers != ""){
		  disconnectedContainers = disconnectedContainers.slice(0, -1);
	  }
	  
	  console.log(connectedContainers);
	  console.log(disconnectedContainers);
	  console.log(referDetails[1]);
	  console.log(referDetails[2]);
	  
	  $(connectedContainers).css("background-color", referDetails[1].toString());
	  $(disconnectedContainers).css("background-color", referDetails[2].toString());
}

function getdamageCrctnScreen(cntr_data){
	 if($.isEmptyObject(cntr_data)){
	 	cntr=$("#hidden_container_no").val();
	 }
	 else{
		 cntr = cntr_data.containers 
	 }
	$.ajax({
		url: "/app/Che/getdamageCrctnScreen",
		success: function(result) {
			$('#light').html("")
			$('#light').html(result);
			document.getElementById('light').style.display = 'block';
			$(".containerIDClass").val(cntr);
			if($(".containerIDClass").val(cntr) != ""){
				$("#goBtn").click();
			}
		}
	});
	return false;		
}

function shufflejobs(messageresult)
{	
    var messagedetails = messageresult.split("~")	
    var result = messagedetails[0]
    if(result == "HVY_HK_TRUE"){
        $("#hvy_hook").css("color", "red");
    }
    else if(result == "HVY_HK_FALSE"){
        $("#hvy_hook").css("color", "#32363f");
    }
    else if(result == "PLC_JOB_DONE"){    	
    	console.log("PLC_JOB_DONE");
        processjoblist(0,0,0,messagedetails[1],"plcjobdone")  
		$("#qccontainer_handling").accordion("option", "active", 0);
        resettimer("#job_timer");
	} else if (result == "PLC_TRUE") {
		$("#plc_active_deactive").addClass("moves_plc_active");
	} else if (result == "PLC_FALSE") {
		$("#plc_active_deactive").removeClass("moves_plc_active");
	}
    else if (result == "CONTAINER_HANDLING_TRUE"){  
    	console.log("CONTAINER_HANDLING_TRUE");
    	$("#qccontainer_handling").accordion("option", "active", 1);
    	selected_cont = messagedetails[1].split('|')[0];
        processcontainerhandling(messagedetails[1],'false','')
		$(".hc_joblist_table tr").removeClass("active")
		
	    var cntrNos = messagedetails[1].split("|")
		for(i=0;i<cntrNos.length;i++){    		
			$(".hc_joblist_table tr[data-uniquejobid='"+cntrNos[i]+"']").addClass("active")
		}		
    }
    else if(result == "DELAY_RECORDING"){
        processdelayrecording(messagedetails[1])
    }
    else if (result == "ALERT_MESSAGE_DISPLAYED"){
        processalertmessage(messagedetails[1]);
    }
    else if (result == "NORMAL_ALERT_MESSAGE"){
        processnormalalertmessage(messagedetails[1], messagedetails[2]);
    }
    else if(result == "QC_PERFORMANCE_VIEW"){
    	updateCHEfields(messagedetails[1]);
    	
    }
    else if(result == "BACKREACH_CONTAINER_MOVE"){
    	backreachcontainermove(messagedetails[1]);
    }
    else if(result == "REFRESH_JOBS"){
    	var value = $("#jobs_select").val();
		$('#search_joblist').val('');
		processjoblist(0, 0, 0, value, 'filter')
    }else if (result == 'CANCEL_JOB'){
		$("#qccontainer_handling").accordion("option", "active", 0);
		//processjoblist(0,0,0,result,"shuffle");
    }
    else
        processjoblist(0,0,0,result,"shuffle")	
		
		$('#layout').unmask();
}

function process_poll_request_timer() {
	console.log("Value changed==============");
	$.ajax({
        type:   "POST",
        url:  "/app/Login/process_poll_request",
        success:function(){
        }
    })
}
	
      $(document).ready(function(){
    
    	  
    	  $("#jobs_select").msDropdown({ roundedBorder: false });
    	  
    	  $('#fade').click(function() {
    		 
  			$.ajax({
  				url: "/app/Login/getunavlblereasons",
  				data: {
  					popupType: "unavilable"
  				},
				success: function(result) {
					$('#light').html("")
					$('#light').html(result);
					$("select").addClass('combobox');
					$("select").attr('type', 'text');
					$(".combobox").combobox();
					setTimeout(virtualKeyboard, 500);
					document.getElementById('light').style.display = 'block';
					
					$(".delayrecording_page .ui-button-icon").click(function(){
						$(".ui-autocomplete").css("width", $(".delayrecording_page .ui-autocomplete-input").width() + 20 + 'px')
					})
					
					//$("#rms_select").msDropdown({ roundedBorder: false });
					//document.getElementById('light').style.display = 'block';
				}
			});
		});
    	    
    	    job_timer("#job_timer");   
    	    processjoblist(0,0,'','','jobdone');
    	    $("#qccontainer_handling").accordion({autoHeight: false });
    	    //processbayviewrequest(-1,'#bay_img1','false')   
    	    p = parseInt($('#completedMoves').html());

    	   
          $('#arrow_left').click(function(){
              processbayviewdata(true);
          });
          $('#arrow_right').click(function(){
              processbayviewdata(false);
          });
          $("#cntr_select").change(function(){
              var cntrType=$(this).val();
              if(cntrType == 'hazardous' || cntrType == 'reefer'){
                  renderBayview();
                  $('div.bay_img div['+cntrType+'="false"]').css("background-color", "grey");
                  $('div.bay_img div['+cntrType+'="false"]').empty();
                  $('div.top_view div['+cntrType+'="false"]').css("background-color", "grey");
                  $('div.top_view div['+cntrType+'="false"]').empty();
              }else if(cntrType == 'POD'){
                  renderBayview();
              }else if(cntrType == 'future'){ // @author Prasad.Tallapally
                  if(jQuery.isEmptyObject(futureBayviewObj)){ //Requesting future iff futureBayviewObj is empty
                      requestAndBuildFutureBayview(); // Fetch Future Bayview Data from Server and Draw Future Bayview
                  }else{
                      renderFutureBayview();  // Draw only Future Bayview
                  }
             
              }else{
          // To be implemented
          }
            
          });
          
          $( "#qccontainer_handling3" ).on( "accordionbeforeactivate", function( event, ui ) {
              if($('.ui-accordion-header-active').attr('id') === "container_imgid" ){
                  $(".qc_bay_heading").css("background-image","none");  
              }
              else{
                  $(".qc_bay_heading").css("background-image","url('../../public/images/see_container_handling_active.png')"); 
              }
          } );
      });
      
      function updateCHEfields(messagedetails) {
    		//resp_fields[3].to_s+"|"+resp_fields[4].to_s + "|"+resp_fields[5].to_s + "|"+ resp_fields[6].to_s + "|"+resp_fields[7].to_s
      		var qcviewattributes = messagedetails.split("|")
			console.log(qcviewattributes)
			console.log("Performance parameters")
    		$(".moves_to_gonumber").text(qcviewattributes[3])
    		$("#target_compl_time").text(qcviewattributes[2])
    		$(".moves_done_timer").text(qcviewattributes[4])
    		$(".moves_time_number").text(qcviewattributes[0])
    		$("#grossmoves").text(qcviewattributes[1])
			
    		var mph = Number(qcviewattributes[1]);
    		if (mph!=undefined)
    			$('#progressbar').progressbar('setPosition', mph);
    	}
        
    	function closePopup(){
    		$('#light').html("")  
    	  	document.getElementById('light').style.display='';
    	}
    	           
      function send_data(containers,celllocation,itvnos,movekind,categoryInfo)
      {

         /* if(movekind=='DSCH')
              processjoblist(containers,celllocation,itvnos,0,'jobdone');
          else*/
             // processjoblist(containers,itvnos,celllocation,0,'jobdone');
          processjoblist(containers,celllocation,itvnos,0,'jobdone',movekind, categoryInfo);
              
          console.log(3);
          $("#qccontainer_handling").accordion("option", "active", 0);
          $("#yardViewFirstAcc").hide();
	      $("#container_imgid").show();
	      change_cntr_edited_val();
              /*    if($("#jobs_select").val() != "jobs_completed")
          {
              if(movekind=='DSCH')
                  dischargeContainer(containers,celllocation)
              else   
                  loadContainer(containers,celllocation)
            
          }  
          */
          resettimer("#job_timer");
      //  $('#job_timer').runner('reset');
      }
      
	  function processdelayrecording(messagedetails) {
		$.ajax({
			type: "POST",
		url: "/app/Che/delay_recording",
		data: {
			delayrecordingmessage: messagedetails
		},
		success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				$("select").addClass('combobox');
				$("select").attr('type', 'text');
				$(".combobox").combobox();
				setTimeout(virtualKeyboard, 500);
				document.getElementById('light').style.display = 'block';
				$("#delayrecording_data").change(function(){
					$("#txtDelayDescription").val($(this).find(':selected').data('desc'));
				});
			}
		})
		return false
	  }
	  
	  function delay_recording() {
			var selectedval = $("#delayrecording_data").val();
			if (selectedval == "") {
				showAlerts("Please select a reason!");
			} else {
				
				$('#delayRecordSubmit').attr("disabled", true).addClass("disable_btns");
				$.ajax({
					type: "POST",
					url: "/app/Che/delayrecordingreason",
					data: {
						delayrecording_reason: selectedval
					},
					success: function(result) {
						delayCnfrmatn(result)
						$('#delayRecordSubmit').attr("disabled", false).removeClass("disable_btns");
					},
					error: function() {
						$('#delayRecordSubmit').attr("disabled", false).removeClass("disable_btns");
					}
				})
			}
			return false
		}
		function delayCnfrmatn(delayResp){
			var newDelay = delayResp.split("~")[3];
			if(newDelay == "true"){
				closePopup();
			}else{
				var delaycode = delayResp.split("~")[4];
				if(delaycode != ""){
					var delayCloseCnfrmatn = delaycode + " delay exists. Do you want to close it?"
					confirmDelay(delayCloseCnfrmatn, cnfrmResult);
				}else{
					closePopup();
				}
			}
		}

		var cnfrmResult = function(cnfrmResult){
			console.log("cnfrmResult" + cnfrmResult)
			var selectedDelayReason = $("#delayrecording_data").find(":selected").val();
			console.log("selectedDelayReason" + selectedDelayReason)
			$.ajax({
				type: "POST",
				url: "/app/Che/recordNewDelay",
				data: {
					closeDelay: cnfrmResult,
					selectedDelayReason : selectedDelayReason
					
				},
				success: function(result) {
					closePopup();
					$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
				},
				error: function() {
					$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
				}
			})
		}
      
      function processRmg(){
        // By default load the first job's block in the yard view
        return true;
    	  console.log("jobCellId "+jobCellId);
        $("#currentYardLocationId").val(jobCellId);
        jobBlockNumber = getJobBlockNumber();
        jobstackNumber = getJobStackNumber();
        //alert(jobBlockNumber);
        console.log(jobBlockNumber);
		$("#currentBlockNumberInYardViewId").val(jobBlockNumber); 
        $(".yard_view_blk").html("");
         $.ajax({
                type:   "POST",
                url:  "/app/Login/processRmg",   
            data: {
              blockNumber : jobBlockNumber,
			  stackNumber : jobstackNumber
            },
                success:function(result){
                   //alert(result);
                   $(".yard_view_blk").html(result);
                   $('#che_yard_block_id').html(jobBlockNumber);
                   $('#che_stack_yard_block_id').html(jobBlockNumber +' - '+jobstackNumber);
                  // $("#currentBlockNumberInYardViewId").val(jobBlockNumber); // Block number setting to hidden field.
                   
                   if (result.split('~')[2]!='')
                   {
	                   renderYardView(rmg_obj);
	                   yarBlockNumber = jobBlockNumber;
	                   // Get these parameters from first job of joblist
	                   //stackBlockNumber = getJobBlockNumber();
	                   //stackNumber = getJobStackNumber();
	                   processStackView(jobBlockNumber, jobstackNumber, '',FIRST_STACK);
                   }
                   else{
                	   $(".yard_view_blk").html("<h3 align='center' style='padding-top: 75px'> No Yard View to display </h3>");
                	   $("#stackViewContainer").html("<h3 align='center' > No Stack View to display </h3>");
                	   //$("#currentBlockNumberInYardViewId").val('');
                   }
                }
            })
      }
      
      
      // Will be called for navigation buttons clicked.
      function processYardViewNavigation(jobBlockNumber, jobStackNumber){
    	  $("#layout").mask("Loading...");
    	  
          $(".yard_view_blk").html("");
		  $("#currentBlockNumberInYardViewId").val(jobBlockNumber);
		  $('#che_yard_block_id').html(jobBlockNumber);
		  $("#currentStackNumberInStackViewId").val(jobStackNumber);
		  $("#che_stack_yard_block_id").html(jobBlockNumber +' - '+jobStackNumber);
           $.ajax({
                  type:   "POST",
                  url:  "/app/Login/processRmg",   
              data: {
                blockNumber : jobBlockNumber,
				stackNumber :  jobStackNumber
              },
                  success:function(result){
                     //alert(result);
                	  $("#layout").unmask();
                     $(".yard_view_blk").html(result);
                     
                     $('#che_stack_yard_block_id').html(jobBlockNumber);
                      // Block number setting to hidden field.
                     $("#che_stack_yard_block_id").html(jobBlockNumber +' - '+jobStackNumber);
                     if (result.split('~')[2]!='')
                     {
	                     renderYardView(rmg_obj);
	                     yarBlockNumber = jobBlockNumber;
	                    $("#currentBlockNumberInYardViewId").val(jobBlockNumber);
	                     processStackView(jobBlockNumber, jobStackNumber,'', FIRST_STACK);
                     }else{
                	   $(".yard_view_blk").html("<h3 align='center' style='padding-top: 75px'> No Yard View to display </h3>");
                	   $("#stackViewContainer").html("<h3 align='center'> No Stack View to display </h3>");
                	   $("#currentBlockNumberInYardViewId").val('');
                   }
                  
                  },
                  error: function (textStatus, errorThrown) {
                	  $("#layout").unmask();
                  	showAlerts("Error getting Yard details.");
                  }
              })
        }
      
      function stopstartplc() {
    	  $("#layout").mask("Loading...");
    		manualmode = !manualmode
    		$.ajax({
    			type: "POST",
    			url: "/app/Che/stop_start_plc",
    			data: {
    				manual_mode: manualmode
    			},
    			success: function(result) {
    				$("#layout").unmask();
    				if (manualmode) {
    					$(".icon_manual").css("display", "none");
    					$(".icon_auto").css("display", "block");
    				} else {
    					$(".icon_manual").css("display", "block");
    					$(".icon_auto").css("display", "none");
    				}
    				
    			},
    			error: function (textStatus, errorThrown) {
    				$("#layout").unmask();
    			}
    		});
    	}
      
      function processjoblist(container,from_location,to_location,contritv,reqtype,movekind, categoryInfo)
      {  
    	  $(".progress").addClass("progress_div")
    	  var jobCellId = "";
    	  
      		$("#layout").mask("Loading...");
          $.ajax({
              type:   "POST",
              url:  "/app/Login/joblist",
              data: {
                  container_id:container,
                  from_location:from_location,
                  to_loc:to_location,
                  containeritvinfo:contritv,
                  reqtype:reqtype,
				  troubleDamageClicked: troubleDamageClicked,
				  movekind: movekind,
				  categoryInfo: categoryInfo
				  
              },
              success:function(result){ 
            	  $("#layout").unmask();
                  $("#tabledataid").html("");
                  $("#tabledataid").html(result);
                  $("#yardViewFirstAcc").hide();
                  firstJobCellId = getFirstJobCellId();
                  console.log("firstJobCellId: "+ firstJobCellId);
                  
                  if ($(".tally_swap_btn").html()!=undefined && $(".tally_swap_btn").html().split('Cancel').length>1)
                  {
                	  
                	  var containerNums="";
              		  //get the container
              		  $(".tally_cntrno").each(function(index) {
              				containerNums = $(this).text();
              			});
              		  
              		  $('#qc_table tr').removeClass('active');
              		  $("#qc_table tr[data-container='"+containerNums+"']").addClass("active");
                	  
              		  if ($(".tally_swap_btn").html().split('Cancel').length>1)
                	  { 
	              		$('#qc_table tr').removeClass('highlight_discharge_job');
	              		$('#qc_table tr.active').addClass('highlight_discharge_job');
                	  }
                	  
                	  // Get the Stack for the selected job Item.
                	  
                	  if ($('#to-location-data').attr('movekind')=='LOAD' || $('#to-location-data').attr('movekind')=='DLVR' ||  $('#to-location-data').attr('movekind')=='MO' || $('#to-location-data').attr('movekind')=='GO')
                	  {
                	  		//Consider from Location is a Yard Location
                		 // scrollYardToRequestedContainer(containerNums, $('.from_label').val());
                	  }else{
                	  		//Consider to Location is a Yard Location
                		//  scrollYardToRequestedContainer(containerNums, $('#to-location-data').val());
                	  }
                	  
                  }else{
                  		processRmg();
                  }
                  
                  if(reqtype == "filter"){
                  	var jobsSelect = $("#jobs_select");
                  	jobsSelect.data("prev",jobsSelect.prop('selectedIndex'));
                  }
                 
              }, 
			  error: function(){
				  $("#layout").unmask();
				  if(reqtype == "filter"){
					  var jobsSelect = $("#jobs_select");
					  $('#jobs_select').msDropDown().data('dd').set('selectedIndex', jobsSelect.data("prev"));
					  
				  }
			  }
			  
          })
          return false
      }
      
      
      
  // function to process notifications after job confirmation
      
      function process_notifications(){
    	  
    	  console.log("Processing notifications")
    	  $.ajax({
              type:   "POST",
              url:  "/app/Login/process_poll_request",
              success:function(result){
            	  
              },
			  error: function(){
				 // $("#layout").unmask();
              }
          })
    	  
      }
      
      function change_cntr_edited_val(){
    	  $.ajax({
              type:   "POST",
              url:  "/app/Login/contr_edit_val_false",
              success:function(result){
            	  process_notifications();
              },
			  error: function(){
				 // $("#layout").unmask();
              }
          })
      }
      
      function getFirstJobCellId(){
    	  //if($('#qc_table tbody tr:first').attr('mkind') == "DSCH"){
    		  //jobCellId = $('#qc_table tbody tr:first').attr('cellid');
    	 // }else{
    		  jobCellId = $('#qc_table tbody tr:first').attr('name');  
    	 // }
    	  console.log("jobCellId: "+ jobCellId);
    	  return jobCellId;
      }
      
      function processjobdone()
      {
    	  $("#layout").mask("Loading...");
          $.ajax({
              type:   "POST",
              url:  "/app/Che/container_handling",
              success:function(result){
            	  $("#layout").unmask();
                  $("#container_handlediv").html("");
                  $("#container_handlediv").html(result);
              },
			  error: function(){
				  $("#layout").unmask();
              }
          })
          return false
      }
        
      function HatchcoverMancageBreakbulk_Request(request_type)
      { 
    	  $("#layout").mask("Loading...");
          document.getElementById('collapse1').style.display='none';
          $('#nav-toggle1').css("background-color","#0563a0");
          $.ajax({
              type:   "POST",
              url:  "/app/Che/HatchcoverMancageBreakbulk_Request",
              data:
              {
                  request_type:request_type
              },
              success:function(result){         
                  $('#tabledataid').html("")
                  $('#tabledataid').html(result)
				  $("#layout").unmask();
              },
			  error: function(){
				  $("#layout").unmask();
              }
          })   
          return false
      }
      
      function processcontainerhandling(message,manualconfirm,containerLength)
      { 
    	  $("#layout").mask("Loading...");
    	  container = message.split(">")[0]
    	  exception_reason = message.split(">")[1];
    	  console.log("message message  " + message);
    	  message = message.split("^")
		  var container_position =  $("#qc_table tr[data-container='"+message[0]+"']").data('position');
    	  //$("data-container" + message[0] + "']").data('position');
    	  var container_movekind = $("#qc_table tr[data-container='"+message[0]+"']").attr('mkind');
		  //$("data-container" + message[0] + "']").attr('mkind');
    	  if(container_position == "") {
    		  container_position = "F";
    	  }
    	  
          $.ajax({
              type:   "POST",
              url:  "/app/Che/container_handling",
              data:
              {
                  container:message[0],
                  manual_confirm: manualconfirm,
				  exception_reason: exception_reason,
				  container_position: container_position,
				  movekind: message[1],
				  containerLength: containerLength
              },
              success:function(result){
            	  $("#layout").unmask();
                  $("#container_handlediv").html("");
                  $("#container_handlediv").html(result);
                  
                  if(container_movekind == "LOAD" || container_movekind == "MO") {
                	  $('.swap_che').show();
                  } else {
                	  $('.swap_che').hide();
                  }
              },
			  error: function(){
				  $("#layout").unmask();
              }
          })
          return false
      }
      
      function processalertmessage(messagedetails)
      {
          $.ajax({
              type:   "POST",
              url:  "/app/Che/alert_message",
              data:
              {
                  alertmessage : messagedetails
              },
              success:function(result){
                  swal({
                    html: '<p class="alert_data">'+messagedetails+'</p>', 
                    showCancelButton: false,
                    allowOutsideClick: false,
                    closeOnConfirm: true
                  });
              }
          })
          return false
      }
      
      var alertCount = 0;
      function processnormalalertmessage(messagedetails, expiryTime)
      {
    	 /* $("#alerts").html("")
		  $("#alerts").html(messagedetails)
		  $(".qc_rows[data-container]").attr("exception_reason", messagedetails.split(":")[1])
		  */
			var alerts = "";
		    alerts = messagedetails;
			allAlerts.push(alerts);
			alertCount += 1;
			var i, FLDAlerts="";
			
			displayAllAlerts();
			setTimerForAlerts(expiryTime);
			console.log("FLDAlerts" +FLDAlerts);
			$(".qc_rows[data-container]").attr("exception_reason", messagedetails.split(":")[1]);
      }
     
      function setTimerForAlerts(expiryTime) {
    		(function(k) {
    		       setTimeout(function(){
    		    	   console.log("stopping alertCount " + k);
    				   allAlerts[k - 1] = "";
    				   displayAllAlerts();
    		       }, expiryTime * 1000);
    		 })(alertCount);
    	}
      
    	function displayAllAlerts() {
    		var FLDAlerts="";
    		for (i = 0; i < allAlerts.length ; i++) {
    			if(allAlerts[i] != "") {
    				FLDAlerts += allAlerts[i] + "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;";
    			}
    	    }
    		
    	    console.log("FLDAlerts" +FLDAlerts)
    		$("#alerts").html("");
    		$("#alerts").html(FLDAlerts);
    	}
    	
    	var alertClick = 1;
    	$('.qc_alerts').on("click",function(){ 
    		console.log(" alert clkd")
    		if(alertClick == 1){
    			document.getElementById("alerts").stop();
    			alertClick = 2;
    		}else{
    			document.getElementById("alerts").start();
    			alertClick = 1;
    		}
    		
    	})
      
        
      function logout()
      {  
	    	/* if ($(".tally_swap_btn").val()=='Cancel Job')
	      	{
	      		showAlerts("Please cancel the selected job, before Logout");
	      		return;
	      	}*/
    	  
          stoptimer();
          clearTimeout(qchome_time)
          $.ajax({
              url:  "/app/Login/logout",
              success:function(result)
              {
                  $("#layout").html("");
                  $("#layout").html(result);
              }
          })
      };
      
      function mergeJobs(reqType,addContainerList)
      {   
          $.ajax({
              type:   "POST",
              url:  "/app/Che/mergeJobs",
              data: {
                  addContainerList:addContainerList,        
                  reqType:reqType
              },
              success:function(result){       
                  $("#tabledataid").html("")  
                  $("#tabledataid").html(result)
              }  
          })
          return false
      }
      
      function showVideo(videoUrl){	
    		 //alert(videoUrl)
    		  swal({ 
    	              	title: 'video',
    	                  html: '<video width="320" height="240" controls>'
    	                  	   +'<source src="'+videoUrl+'" type="video/mp4">' 
    	                  	   +'<source src="'+videoUrl+'" type="video/wmv"></video>', 
    	                  showCancelButton: true,
    	                  allowOutsideClick: false                 
    	                  
    	              })
    	  }
    	  function deleteJobs(addContainerList)
    	  {  	 
    	      $.ajax({
    	          type:   "POST",
    	          url:  "/app/Hc/deleteJobs",
    	          data: {
    	              addContainerList:addContainerList  
    	          },
    	          success:function(result){       
    	              $("#tabledataid").html("")  
    	              $("#tabledataid").html(result)
    	          }  
    	      })
    	      return false
    	  }
      function job_timer(timerid){  
        $(timerid).runner({
              autostart: true,
              milliseconds:false    
         });
      }
      function resettimer(timerid){
        $(timerid).runner('reset');
      }
      
      function getJobBlockNumber(){
        var asbc = jobCellId.split(".")[0];
        return asbc;
      }
      
      function getJobStackNumber(){
	    var asbc = jobCellId.split(".")[1];
	    return asbc;
	  }
      
	  
  function getLanguagesList() {
		$.ajax({
			type: "POST",
			url: "/app/Che/getLanguagesList",
			success: function(result) {
				if (result != 'Error') {
					$('#light').html("")
					$('#light').html(result)
					$("#language").msDropdown({ roundedBorder: false });
					document.getElementById('light').style.display = 'block';
				} else {
					showAlerts("Unable to process request");
				}
			}
		})
		return false
	}
  
	function setLanguage() {
		var selectedlang = $("#language").val();
		$.ajax({
			type: "POST",
			url: "/app/Che/setLanguage",
			data: {
				selectedlang: selectedlang
			},
			success: function(result) {
				closePopup();
				if (result != 'Error') {
					$(".main_content").html("");
					$(".main_content").html(result);
				}
			},
			complete: function() {
				closePopup();
			}
		})
		return false
	}

	  
	function send_Swap_Request() {
		var label_to_search = "";
		var containerNums = "";
		var movekind = $(".active:first").find("td:first").next().html()
		if ($("#jobs_select").val() == "jobs_completed") {
			if (movekind == "LOAD" || movekind == "DLVR") {
				label_to_search = ".toData"
			} else {
				showAlerts("SWAP is not possible for " + movekind + " Containers")
				return false;
			}
	
		} else if ($("#jobs_select").val() == "current_jobs") {
			if (movekind == "DSCH" || movekind == "RECV") {
	
				label_to_search = ".from_label"
			} else {
				showAlerts("SWAP is not possible for " + movekind + " Containers")
				return false;
			}
		}
		var itv_0 = "";
		var itv_1 = "";
		$(label_to_search).each(function(index) {
			
			if(label_to_search == ".from_label"){
				if (index == 0) {
					itv_0 = $(this).text();
				} else if (index == 1) {
					itv_1 = $(this).text();
				}
			}else if(label_to_search == ".toData"){
				if (index == 0) {
					itv_0 = $(this).val();
				} else if (index == 1) {
					itv_1 = $(this).val();
				}
			}
			//console.log("ITV Index Value Is-->" + ITV0 + "itv1 is-->" + ITV1);
		});
		if ($(".active").length == 2) {
			$(".tally_cntrno").each(function(index) {
				containerNums += $(this).text().concat("|");
			});
			containerNums = containerNums.substring(0, containerNums.length - 1);
			if ( (itv_0 != "" && itv_1 != "") && itv_0 == itv_1) {
				$.ajax({
					url: "/app/Che/send_swap_request",
					data: {
						containerno: containerNums,
						itvNo: itv_0,
					},
					success: function(result) { 
						
					}
				});
			} else {
				showAlerts("SWAP is not possible for this containers,Please check ITV is same for the containers")
			}
		} else {
			showAlerts("SWAP is not possible for this containers,Please check the number of containers")
		}
	}	  
	
	// Function gets called when ITV arrived button clicked from ITV
	function  highLightITVWhenArrived(itvArrivedMsg)
	{
		var referDetails = itvArrivedMsg.split('#');
		//$('#itvArrivedbuttonClickId').html("");
		var htmlContent="";
		if (referDetails.length>2){
			htmlContent = htmlContent+ "<div class='cntr_no updatepool_row_first che-button' style='background-color: "+referDetails[3]+"' >";
			htmlContent = htmlContent+ "<div class='itv_truck_number' name='cntr'>"+referDetails[0]+"</div><div class='truck_number'>"+referDetails[1];
			htmlContent = htmlContent+ "</div><div class='total_jobs_cntr'>"+referDetails[2]+"</div></div>";
		}
		$('#itvArrivedbuttonClickId').html(htmlContent);
		
		$("#updatepool_row_first").on("click",function(){
          console.log("updatepool_row_first");
          setTimerForEdit();
          $.ajax({
                 type:   "POST",
                 url:  "/app/Login/change_contr_edit_val",
                 success:function(result){
                 console.log(result)
                 }
             })
          
        })
	}
	
	
	// Will be called for navigation buttons clicked.
    function processYardViewNavigationLeftRight(jobBlockNumber, jobStackNumber){
  	  $("#layout").mask("Loading...");
  	  
        $(".yard_view_blk").html("");
		$("#currentBlockNumberInYardViewId").val(jobBlockNumber); // Block number setting to hidden field.
         $.ajax({
                type:   "POST",
                url:  "/app/Login/processRmg",   
            data: {
              blockNumber : jobBlockNumber,
				stackNumber :  jobStackNumber
            },
                success:function(result){
                   //alert(result);
                   $(".yard_view_blk").html(result);
                   $('#che_yard_block_id').html(jobBlockNumber);
                   $('#che_stack_yard_block_id').html(jobBlockNumber);
                   if (result.split('~')[2]!='')
                   {
	                   renderYardView(rmg_obj);
	                   yarBlockNumber = jobBlockNumber;
                   }else{
                	   $(".yard_view_blk").html("<h3 align='center' style='padding-top: 75px'> No Yard View to display </h3>");
                	   $("#stackViewContainer").html("<h3 align='center' > No Stack View to display </h3>");
                	   //$("#currentBlockNumberInYardViewId").val('');
                   }
                   
                   $("#layout").unmask();
                },
                error: function (textStatus, errorThrown) {
              	  $("#layout").unmask();
                	showAlerts("Error getting Yard details.");
                }
            })
      }
      
      // select job function used to get the container data and sent a request to server
      
      function jobSelectionForDischarge()
      {
    	  var containerNums="";
    	  //get the container
    	  $(".tally_cntrno").each(function(index) {
				containerNums = $(this).text();
			});
    	  
    	  if ($(".tally_swap_btn").html()!=undefined){
	    	  if ($(".tally_swap_btn").html().split('Select').length>1){
	    	  	jobAutoSelectionForDischarge(containerNums);
	    	  }else{
	    		  cancelJobSelection(containerNums);  
	    	  }
    	  }
      }
      
      // This method used to highlight the selected job for discharge case.
      function highlightDischargeJobs()
      {
    	  $('#qc_table tr').removeClass('highlight_discharge_job');
    	  $('#qc_table tr.active').addClass('highlight_discharge_job');
      }
      
      // This fn used to send job selection request to server.
      function jobAutoSelectionForDischarge(containerId)
      {
    	  $("#layout").mask("Loading...");
    	  var yardLoc = "";
    	  
    	  if ($('#to-location-data').attr('movekind')=="LOAD")
    	  {
    		  yardLoc = $('.from_label').attr('fromloc')
    	  }else
    	  {
    		  yardLoc = $('#to-location-data').val();
    	  }
    	 
    	  $.ajax({
				url: "/app/Che/job_selection_request",
				data: {
					containerno: containerId,
					movekind: $('#to-location-data').attr('movekind'),
					yardLocation : yardLoc
				},
				success: function(result) { 
					 $("#layout").unmask();
					if(result == 'true'){
						$(".update_attr_check").show();

						$(".tally_swap_btn").html('Cancel<br /> Job');
						highlightDischargeJobs();
					}else if(result == 'error'){
						$(".update_attr_check").hide();
						Rho.Log.error("Unexpected response", "javascript");
					}else{
						showAlerts(result);
					}
				},
				error: function(err){
					$("#layout").unmask();
					$(".update_attr_check").hide();
					Rho.Log.error("Error during job selection", "javascript");
				}
			});
      }
      
      // This fn used to send cancel job selection request to server.
      function cancelJobSelection(containerId)
      {
    	  $("#layout").mask("Loading...");
    	  $.ajax({
				url: "/app/Che/cancel_job_selection_request",
				data: {
					containerno: containerId,
					movekind: $('#to-location-data').attr('movekind')
				},
				success: function(result) { 
					 $("#layout").unmask();
					if(result == 'true'){
						$(".update_attr_check").hide();
						//$(".tally_swap_btn").val('Select Job');
						$(".tally_swap_btn").html('Select<br /> Job');
						cancelHighlightDischargeJobs();

					}else if(result == 'error'){
						$(".update_attr_check").show();

						Rho.Log.error("Unexpected response", "javascript");
					}else{
						showAlerts(result);
					}
				},
				error: function(err){
					$("#layout").unmask();
					$(".update_attr_check").show();
					Rho.Log.error("Error during job selection", "javascript");
				}
			});
      }
      
      
      // This function is used to high light First job in job list if it is Discharge job.
      function highlightJobNotificationForDischarge(resp)
      {
    	if($('#qc_table tbody tr:first').attr('mkind') == "DSCH"){    		
    		var jobCellId = $('#qc_table tbody tr:first').attr('cellid');
    		console.log("jobCellId: "+ jobCellId);
    		$('#qc_table tr').removeClass('active');
    		$('#qc_table tbody tr:first').addClass("active");
    		var contr = $('#qc_table tbody tr:first');    	       
    	    var container = contr.data('container');
    		jobAutoSelectionForDischarge(container);
		  }
		  
      }
      
      // This method used to highlight the selected job for discharge case.
      function cancelHighlightDischargeJobs()
      {
    	  $('#qc_table tr').removeClass('highlight_discharge_job');
    	  $('#qc_table tr.active').removeClass('highlight_discharge_job');
      }
      
      // getContainerDetailsPopup - invoked when we click on the stack cell.
      
      
      
      function getContainerDetailsPopup(yrd_pos,conNo,is_damaged)
      {	  
    	  $("#hidden_stackview_container_no").val(conNo);
    	  $(".container_cell").removeClass("animate-stackCell");
    	  $(".stack_view_cell").removeClass("animate-stackCell");
    	  $('div[yardPos="' + conNo + '"]').addClass("animate-stackCell");
    				$.ajax({
    					type: "POST",
    					url: "/app/Che/stack_popup",
    					data: {
    						container_number: conNo,
							yard_position: yrd_pos,
							is_damaged:is_damaged 
    					},
    					success: function(result) {
    						$('#light').html("");
    						$('#light').html(result);
							document.getElementById('light').style.display = 'block';
    					},
    					error: function(){
    						console.log("ERROR - getContainerDetailsPopup");
    					}
    				});
      }
	  
	  
	  
	  // getContainerDetailsPopup - invoked when we click on the stack cell.
   
//      function getContainerDetailsPopup(yrd_pos,conNo)
//      {	  
//    	  $(".container_cell").removeClass("animate-stackCell");
//    	  $(".stack_view_cell").removeClass("animate-stackCell");
//    	  $('div[yardPos="' + conNo + '"]').addClass("animate-stackCell");
//    				$.ajax({
//    					type: "POST",
//    					url: "/app/Che/stack_popup",
//    					data: {
//    						container_number: conNo,
//							yard_position: yrd_pos
//    					},
//    					success: function(result) {
//    						$('#light').html("");
//    						$('#light').html(result);
//							document.getElementById('light').style.display = 'block';
//    					},
//    					error: function(){
//    						console.log("ERROR - getContainerDetailsPopup");
//    					}
//    				});
//      }
      
      
  function getDamageRecordView(cntr_data){
//    var containerNo = [];
//    $.ajax({
//      url:"/app/Che/getDamageRecordView",
//      success:function(result){
//        $('#light').html("")
//        $('#light').html(result)
//        document.getElementById('light').style.display='block'; 
//      }
//    })

	  $('.btnDamage').attr("disabled", true).addClass("disable_btns");
	  if($.isEmptyObject(cntr_data)){
		  var movekind = $(".tally_cntrno").find("th[name='containerdata']").attr('movekind');
		  console.log("movekind"+movekind);
		  var containerNo = [];
		    var cntrs = ""
		    var itvs = ""
		    var ground=""
		    var requested_from = ""	
		     $("th[name='containerdata']").each(function(){
		    	 cntrs += $(this).html()+"|"
				 })
			 console.log("cntrs"+ cntrs)
		     $(".toData").each(function(){ 
		       itvs += $(this).val()+"|"
		     })
			   console.log("itvs"+itvs)
			  $("td[name='fromData']").each(function(){
			          ground += $(this).html()+"|"
			  })
		        console.log("ground"+ground)
				cntr_data = {movekind:movekind,containers: cntrs,itvs: itvs,ground:ground,requested_from:requested_from}
	  }
	  
	  $.ajax({
		  url:"/app/Che/getDamageRecordView",
	    data: cntr_data,
	    success: function(result) {
	      if(result != "false"){      
	        $('#light').html("")
	        $('#light').html(result)
	        $("#itvDrpDwn").msDropdown({ roundedBorder: false });
	        document.getElementById('light').style.display = 'block';
	     //   displayITVNumber();
	        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
	      }else{
	        console.log(result);
	        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
	      }
	    }
	  })
  }      
      
  function refresh_container_handling(){
	  $(".qc_rows:first .container_handling_cls").click()
  }