function showtables()
  {
   
    document.getElementById('container_enquiry_screen').style.display = '';
    document.getElementById('table_container_one').style.display = '';
    document.getElementById('table_container_two').style.display = '';
    document.getElementById('last_transaction').style.display = '';
    document.getElementById('comments').style.display = '';
  
  }

  
  function conatinerTableDetails(resp)
  {
	//alert(resp);
  }
  
  
  function displayContainerDetails(containerDetails){
	  console.log(containerDetails);
	  containerDetails = containerDetails.split('~');
	  $(".cnt_containerno").html(containerDetails[2]);
	  // updating the attributes for Damage,Inventory,Shuffle and Update attributes
	  $("#stk_pop_dmg").attr("cont_no",containerDetails[2])
	  $("#stk_pop_inven_btn").attr("cont_no",containerDetails[2])
	  $("#stk_pop_shuff").attr("cont_no",containerDetails[2])
	  $("#stk_pop_update").attr("cont_no",containerDetails[2])
	  //end
	  $("#")
	  $(".cnt_iso").html(containerDetails[21]);
	  $(".cnt_line").html(containerDetails[3]);
	  $(".cnt_agent").html(containerDetails[22]);
	  $(".cnt_terminal").html(containerDetails[4]);
	  $(".cnt_movekind").html(containerDetails[23]);
	  $(".cnt_currentpos").html(containerDetails[5]);
	  $(".cnt_stodays").html(containerDetails[24]);
	  $(".cnt_status").html(containerDetails[6]);
	  $(".cnt_category").html(containerDetails[25]);
	  $(".cnt_yardin").html(containerDetails[7]);
	  $(".cnt_yardout").html(containerDetails[26]);
	  
	  
	  if(containerDetails[8] == "true"){
		  $(".cnt_stop").html("YES");
	  }else{
		  $(".cnt_stop").html("NO");
	  }
	  
	  $(".cnt_reason").html(containerDetails[27]);
	  
	  if(containerDetails[9] == "true"){
		  $(".cnt_damage").html("YES");
	  }else{
		  $(".cnt_damage").html("NO");
	  }
	 
	  $(".cnt_damagecode").html(containerDetails[28]);
	  $(".cnt_inboundvsl").html(containerDetails[10]);
	  $(".cnt_rotation_in").html(containerDetails[29]);
	  $(".cnt_outboundvsl").html(containerDetails[11]);
	  $(".cnt_rotation_out").html(containerDetails[30]);
	  $(".cnt_shipper").html(containerDetails[12]);
	  $(".cnt_consignee").html(containerDetails[31]);
	  $(".cnt_pod").html(containerDetails[13]);
	  $(".cnt_destination").html(containerDetails[32]);
	  $(".cnt_load_port").html(containerDetails[14]);
	  $(".cnt_origin_port").html(containerDetails[33]);
	  
	  if(containerDetails[15] == "true"){
		  $(".cnt_seal").html("YES");
	  }else{
		  $(".cnt_seal").html("NO");
	  }
	 
	  $(".cnt_seal_no").html(containerDetails[34]);
	  $(".cnt_imo_class").html(containerDetails[16]);
	  $(".cnt_un_no").html(containerDetails[35]);
	  
	  if(containerDetails[17] == "true"){
		  $(".cnt_refer").html("YES");
	  }else{
		  $(".cnt_refer").html("NO");
	  }
	  
	  $(".cnt_temperature").html(containerDetails[36]);
	  
	  if(containerDetails[18] == "true"){
		  $(".cnt_plug_in").html("YES");
	  }else{
		  $(".cnt_plug_in").html("NO");
	  }
	  
	  $(".cnt_plug_in_days").html(containerDetails[37]);
	  $(".cnt_weight").html(containerDetails[19]);
	  $(".cnt_content").html(containerDetails[38]);
	  
	  if(containerDetails[20] == "true"){
		  $(".cnt_oog").html("YES");
	  }else{
		  $(".cnt_oog").html("NO");
	  }
	  
      var containerDimensions = containerDetails[39];
      if(containerDimensions != ""){
    	  containerDimensions = containerDimensions.split("|");
    	  $(".dimension_l").html(containerDimensions[0]);
    	  $(".dimension_r").html(containerDimensions[1]);
    	  $(".dimension_f").html(containerDimensions[2]);
    	  $(".dimension_b").html(containerDimensions[3]);
    	  $(".dimension_t").html(containerDimensions[4]);
      }
  }

  function displayContainerEnqScreen() {
	  
	  console.log("containerNumber" +$("#hidden_container_no").val());
	/*  var backreachContnr = $("#hidden_container_no").val();
	   if((backreachContnr.indexOf("HATCHCOVER")!= -1)||(backreachContnr.indexOf("MANCAGE")!= -1)||(backreachContnr.indexOf("BREAKBULK")!= -1)){
	      showAlerts("Container enquiry is not possible for Backreach jobs")
	   }else{ */
			var containerNumber = ""
				console.log("containerNumber" +containerNumber)
			$.ajax({
				type: "POST",
				url: "/app/Che/getContainerEnqScreen",
				data: {
					containerNumber: $("#hidden_container_no").val()
				},
				success: function(result) {
					if (result != 'Error') {
						$('#light').html(result)
						document.getElementById('light').style.display = 'block';
						$("#containerNumber").val($("#hidden_container_no").val());
						$(".container_details_table").hide();
					} else {
						console.log("ERROR - displayContainerEnqScreen");
					}
				},
				error: function(){
					console.log("ERROR - displayContainerEnqScreen");
				}
			});
	  /* } */
  }
  
  function getEnteredConatinerData() {
	  var containerNumber = $("#containerNumber").val();
	  if(containerNumber != ""){
		 $(".BtnCncl").attr("disabled",true);
		 $(".BtnCncl").addClass("disable_btns");
		 getcontainerDetails(containerNumber);
	  }else{
		  showAlerts("Please enter container number");
	  }
  }
  
  function getcontainerDetails(containerNumber) {
	  
	  
	if($(".conatiner_enquiry_popup .btnOk").hasClass("disable_btns") == false){  
	  
	    $(".conatiner_enquiry_popup .btnOk").addClass("disable_btns");  
	  	$.ajax({
	  		type: "POST",
	  		url: "/app/Che/getcontainerDetails",
	  		data: {
	  			containerNumber: containerNumber
	  		},
	  		success: function(result) {
	  			$(".conatiner_enquiry_popup .btnOk").removeClass("disable_btns");
	  			if (result != 'error') {
	  				if(result != "empty"){
						var requestedCntrNo = result.split("~")[2];
	  					console.log("requestedCntrNo" +requestedCntrNo)
						if(containerNumber == requestedCntrNo){
							$(".container_details_table").show();
		  					displayContainerDetails(result);
						}else{
							showAlerts("Please try again");
						}
	  					enableBtn();
	  				}else{
	  					enableBtn();
	  					showAlerts("Container details not found");
	  					return false;
	  				}
	  			} else {
	  				enableBtn();
	  				console.log("ERROR - getcontainerDetails");
	  				showAlerts("Container details not found");
	  			}
	  		},
	  		error: function(){
	  			$(".btnOk").removeClass("disable_btns");
	  			enableBtn();
	  			console.log("ERROR - getcontainerDetails");
	  			showAlerts("Container details not found");
	  		}
	  	})
	}
  }
  
  function enableBtn(){
	  $(".BtnCncl").attr("disabled",false);
	  $(".BtnCncl").removeClass("disable_btns");
  }
