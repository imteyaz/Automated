$(document).ready(function(){
    $('.user-toggle').click(function(){
        $('.user_profile,.user-toggle').css("background-color","#3b3e45");
        $('.user-toggle').css("border","0px");        
        var collapse_content_selector = $(this).attr('href');          
        var toggle_switch = $(this);
        $(collapse_content_selector).toggle(function(){
            if($(this).css('display')=='none'){                      
        }
        });
    });
    $("input[type='checkbox']").attr('checked','checked');
  
    function disableButtons(){
    	$('#cnfrmbtn').attr("disabled", true).addClass("disable_btns");
    	$('#cancelbutn').attr("disabled", true).addClass("disable_btns");
    }
    
    function enableButtons(){
    	$('#cnfrmbtn').attr("disabled", false).removeClass("disable_btns");
    	$('#cancelbutn').attr("disabled", false).removeClass("disable_btns");
    }
    
    $('#cnfrmbtn').on('click', function(){    
        var checklist = $(".chklist :input").serialize();
        disableButtons();
        console.log(checklist)
        $.ajax({
            type:   "POST",
            url:  "/app/Login/che_home",
            data:checklist,
            success:function(result)
            {
            	 $(".main_layout").html("");  
                 $(".main_layout").html(result);
            },
            error: function() {
            	enableButtons();
			}
        });
    })
	
    $('#cancelbutn').on('click', function(){    
    var checklistcancel = $(".chklist :input").serialize();
    console.log("Empty checklist data");
    console.log(checklistcancel);
    disableButtons();
    $.ajax({
        type:   "POST",
        url:  "/app/Login/che_home",
        data:checklistcancel,
        success:function(result)
        {
        	 $(".main_layout").html("");  
             $(".main_layout").html(result);
        }  
    });
  })
  
});


		  
		  
		  
		  
		  