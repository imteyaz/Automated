//@ sourceURL=yardview.js

var LEFT_WINDOW_OFFSET = 114, // Distance between leftmost margin and yard view container
    LEFT_OFFSET = 356, // For displaying yard view at the center of the screen
    initialOffset = 0,
    cellHeight = 0; // To keep track of movement of yard view

//Display yard view for the first time
function renderYardView(yardViewObject){
  displayYardView(yardViewObject);
  initialOffset = -LEFT_OFFSET;
  var firstContainer = $('#qc_table tbody tr:first').attr('data-container');  
  console.log("firstContainer: " + firstContainer);
  //moveYardView(firstContainer, 0);
} 

/* Triggered when any of the job is clicked.
  Checks if container is present in currently loaded yard.
  If not present, sends a request to server */
function scrollYardToRequestedContainer(container, cellId){

  $(".container_cell").removeClass("highlight_container");
  $(".stack_view_cell").removeClass("highlight_container");
  $(".stack_view_cell_dotted").removeClass("highlight_container");
  $("#currentYardLocationId").val(cellId);
  
  //currentYardLocation
  
  console.log("blockNumber: "+ yarBlockNumber + " container: "+ container + " cellId: " + cellId);
  
  if ($("#currentBlockNumberInYardViewId").val()=='')
  {
	  processYardViewNavigation(cellId.toString().split('.')[0], cellId.toString().split('.')[1]);
	  return;
  }
  
  if($("#currentBlockNumberInYardViewId").val() != cellId.toString().split('.')[0]){
    console.log("container " + container + " not present in  block " + yarBlockNumber);
    //getYardViewData(container, cellId.toString().split('.')[0], cellId.toString().split('.')[1]);
    processYardViewNavigation(cellId.toString().split('.')[0], cellId.toString().split('.')[1]);
    // Make a request to the server to get the Yard view details.
  }else{
	  var yardStatus= true;
    if (parseInt(cellId.toString().split('.')[1], 10) < parseInt($("#firstStackNumberInYardViewId").val(), 10) ||  parseInt(cellId.toString().split('.')[1], 10) > parseInt($("#lastStackNumberInYardViewId").val(),10))
    {
    	processYardViewNavigation(cellId.toString().split('.')[0], cellId.toString().split('.')[1]);
    	yardStatus = false;
    }
    
    if (yardStatus)
    {
		var stackCheck = parseInt(cellId.toString().split('.')[1])&1;
		if (stackCheck==0 && parseInt(cellId.toString().split('.')[1]) - 1 == parseInt($("#currentStackNumberInStackViewId").val())){
			
		}
		else if ( parseInt($("#currentStackNumberInStackViewId").val())!=cellId.toString().split('.')[1] ){
			processStackView(cellId.toString().split('.')[0], cellId.toString().split('.')[1],'', OTHER_STACK);
		}
    }
    
    $('div[cellid="' + container + '"]').addClass("highlight_container");
    
    if (cellId.length>3)
    	$('div[yardPos="' + cellId.toString().split('.')[2]+cellId.toString().split('.')[3] + '"]').addClass("highlight_container");
    
	console.log("present");
  }
}

//Gets yard view data from server for the requested block
function getYardViewData(container, blockNumber, newStackNumber){
	
	$("#layout").mask("Loading...");	
	$("#currentBlockNumberInYardViewId").val(blockNumber);
  $.ajax({ 
    type: "POST",
    url: "/app/Che/getYardViewData",
    data: {
        blockNumber : blockNumber,
		stackNumber : newStackNumber
      },
    success: function(data){
    	
      var result = $(data).attr("value");
      initialOffset = 0;
      yarBlockNumber = blockNumber;
      // Check the Response. it is empty or not , If it is empty then display no yard view and clear the header for block number. 
      $("#che_yard_block_id").html(blockNumber);
      $("#che_stack_yard_block_id").html(blockNumber +' - '+newStackNumber);
      if (result.split('~')[2]!='')
      {	  
	      displayYardView(result);
	      //moveYardView(container,LEFT_OFFSET);
	      //alert(blockNumber);
	      
	      if($('div[cellid="' + container + '"]') != "" || $('div[cellid="' + container + '"]') != undefined || $('div[cellid="' + container + '"]') != "undefined"){
	      	$('div[cellid="' + container + '"]').addClass("highlight_container");
	      }
	      
	      $("#layout").unmask();
	      //alert(blockNumber);
	      //if(stackNumber != newStackNumber){
	      	processStackView(blockNumber, stackNumber,'', 2);
	     // }
      }else{
    	  $(".yard_view_blk").html("<h3 align='center' style='padding-top: 75px'> No Yard View to display </h3>");
    	  $("#stackViewContainer").html("<h3 align='center' > No Stack View to display </h3>");
    	  //$("#currentBlockNumberInYardViewId").val('');
      }
	    	
      	$("#layout").unmask();
    },
    error: function (textStatus, errorThrown) {
    	$("#layout").unmask();
    	showAlerts("Error getting block view details.");
    }
  });
  return false;
}

//Decodes the yardViewMessage and returns html content.
function displayYardView(yardViewObject){
	
  var decodedYardViewMessage = decodeYardViewMessage(yardViewObject);
  var rowsData = yardViewObject.split('~')[3];
  var newYardViewLayout = createYardViewLayout(decodedYardViewMessage, rowsData);
  $("#yard_BlockContainer").html(newYardViewLayout);
}

//Converts packet data into javascript object
function decodeYardViewMessage(yardViewObject){
  console.log(yardViewObject);
  var result = yardViewObject.split('~'),
      colNumbers = result[2].split("^"), //result[2].split("^")
	  // Row DEtails are available in the location : result[3].split("^") 
      rows = result[4].split('|'), // result[4].split('|'),
      rowCntr = [],
      rowObj = {};
      
      //yarBlockNumber = result[3];
      cellHeight = 90/rows.length;
      
  //For numbered cells	
  for(var j=0;j<colNumbers.length;j++){
	  //if (parseInt(colNumbers[j])<10)
	  //	  colNumbers[j] = '0'+colNumbers[j];
    rowObj[j] = {container: "number", cellid:colNumbers[j]};
    
    	//firstStackNumberInYardViewId
    if (j==0)
    	$("#firstStackNumberInYardViewId").val(colNumbers[j]); // first Stack number setting to hidden field.
    if(j+1==colNumbers.length)
        $("#lastStackNumberInYardViewId").val(colNumbers[j]); // last Stack number setting to hidden field.
        
  }
  rowCntr.push(rowObj);
  rowObj = {};
  for(var j=0;j<colNumbers.length;j++){
	  //if (parseInt(colNumbers[j])<10)
	//	  colNumbers[j] = '0'+colNumbers[j];
    rowObj[j] = {container: "number2", cellid:colNumbers[j]};
  }
  rowCntr.push(rowObj);
  
  //For container cells
  for(var k=0;k<rows.length;k++){
    rowObj = {};
    var tempCols = rows[k].split('$');
    for(var j=0;j<tempCols.length;j++){
      if(tempCols[j].split('^').length > 1){ // container is present
        //rowObj[j] = {container: Math.floor(Math.random()*16777215).toString(16), cellid:tempCols[j].split('^')[1]};
          var FContainer = true;
    	  if (tempCols[j].split('^')[3]!=null && tempCols[j].split('^')[3]=='T')
    	  {
    		  FContainer = true;
    	  }else{
    		  FContainer = false;
    	  }
    	  
    	  var tempColor=tempCols[j].split('^')[2];
    	  if (tempCols[j].split('^')[2]!=undefined && tempCols[j].split('^')[2]=='')
    	  {
    		  tempColor = "#FFFFFF";//"#CEF6F5"; 
    	  }
    	  
        rowObj[j] = {container: tempColor, cellid:tempCols[j].split('^')[1], fourtyFoot: FContainer};
        
        if(tempCols[j].split('^')[1]=='')
        {
            rowObj[j] = {container: "#DCDCDC", cellid:'', fourtyFoot:false}; // fourtyFoot: (Math.random() * 10) > 7 ? true : false
        }
        
      }else{ // no container
        rowObj[j] = {container: "#DCDCDC", cellid:tempCols[j].split('^')[1], fourtyFoot:false}; // fourtyFoot: (Math.random() * 10) > 7 ? true : false
      }
    }
    rowCntr.push(rowObj);
  }
  
  return rowCntr;
}

//Creates html layout from javascript object
function createYardViewLayout(rows, rowsData){
  var currContent='<ul>';
  var rowDataObj = rowsData.split('^');
  
  var counter =-1;
  var fourtyContainer=false;
  $.each(rows, function(key, value){  // Create cells row wise
  
	if (counter<=0){
		  if (counter==-1)
		  	currContent += "<li><span style='font-size:12px;font-weight: bold;width:70px;padding-right:3%;margin-bottom:1%;'></span>";
		  else
		  	currContent += "<li>";
	}
	  else{
	  	currContent += "<li ><span style='font-size:12px;font-weight: bold;width:9px;padding-right:2%;display: inline-block;margin-bottom:1%;'>"+rowDataObj[counter-1]+"</span>"; 
	  }
    fourtyContainer=false;
  $.each(value, function(ke,val){
      if(val.container == "number"){
        currContent += "<div cellid="+ val.cellid +" id="+ke+" class='container_cell twenty-foot-container container_top_cell'>" + val.cellid +"</div>";
      }else if(val.container == "number2"){
        currContent += "<div cellid="+ val.cellid +" id="+ke+" class='container_cell twenty-foot-container container_top_cell'></div>";
      }else{
      		
      		if (fourtyContainer==false)
      		{
		        if(val.fourtyFoot){
		          currContent += "<div cellid="+ val.cellid +" id="+ke+" class='container_cell fourty-foot-container' style='height:14px;background:"+ val.container +"'></div>";
		          fourtyContainer=true;
		        }else{
		          currContent += "<div cellid="+ val.cellid +" id="+ke+" class='container_cell twenty-foot-container' style='height:14px;background:"+ val.container +"'></div>";
		        }
      		}else
      		{
      			fourtyContainer=false;
      		}
      }
	  
    });
    currContent += "</li>";
	counter = counter+1;
  });
  currContent = "</ul><li>"+currContent+"</li>";
  
  return currContent;
}

//Moves yard view to the specified container
function moveYardView(cellId, number){
  console.log("cellId: "+ cellId);
 /* if($("div[cellid='" + cellId + "']") == "undefined" || $("div[cellid='" + cellId + "']").length == 0){
    Rho.Log.error("couldn't find container " + cellId + " in Yard view", "javascript");
    return;
  }
  
  var pos = ($("div[cellid='" + cellId + "']").offset().left) - LEFT_WINDOW_OFFSET  + (initialOffset) - number;
  initialOffset = pos;
  var pos = pos * -1;
  var posString = pos.toString() + 'px';
  $("#yard_BlockContainer > li").animate({'left' : posString});*/
}

function moveYardViewLeft(){
	processYardViewNavigationLeftRight($('#currentBlockNumberInYardViewId').val(), $('#firstStackNumberInYardViewId').val());
}

function moveYardViewRight(){
	
	processYardViewNavigationLeftRight($('#currentBlockNumberInYardViewId').val(), $('#lastStackNumberInYardViewId').val());
    
}

function moveYardViewLeftRight(isMoveYardView){
  if(isMoveYardView == true){
    var pos = initialOffset * -1;
    var posString = pos.toString() + 'px';
    $("#yard_BlockContainer > li").animate({'left' : posString});
  }
  else
  {
    processRmg();
    initialOffset = 0;
  }
}
/*----------------------RMG region--------------------------*/
function updateRmgPosition(cellId){
  moveYardView(cellId, LEFT_OFFSET);
}

function rmgLeft(){
  if(initialRMG != rmgValue)
  {
    rmgValue -= 25;
    $(".frame").animate({left: rmgValue});
  }
}

function rmgRight(){
  if(rmgValue < maxWidthForRMG)
  {
    rmgValue += 25;
    $(".frame").animate({left: rmgValue});
  }
  else
  {
    buttonRight();
  }
}
/*-------------------End RMG region--------------------------*/

