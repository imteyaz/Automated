$(document).ready(function() {
	$("#containerNumber").val($("#hidden_container_no").val());
	getContainerAttributes();
});

function getContainerAttributes() {

	//$(".container_controls_cnt .btnOk").prop("disabled",true);
	var containerNumber = $("#containerNumber").val();
//	var containerNumber = $("#hidden_stackview_container_no").val();
//	console.log("Hidden container number is : "+containerNumber);
	$.ajax({
		type: "POST",
		url: "/app/Che/get_container_attributes",
		data: {
			containerNumber: containerNumber
		},
		success: function(result) {
			//$(".container_controls_cnt .btnOk").prop("disabled",false);
			if (result != 'error') {
				if(result != "empty"){
					//$(".container_details_table").show();
					//displayContainerAttributes(result);
					$('.container_attributes_cnt').html(result);
					$(".iso_select").msDropdown({ roundedBorder: false });
					virtualKeyboard();
				}else{
					showAlerts("Container details not found");
					return false;
				}
			} else {
				console.log("ERROR - getcontainerDetails");
				showAlerts("Container details not found");
			}
		},
		error: function(){
			//$(".container_controls_cnt .btnOk").prop("disabled",false);
			console.log("ERROR - getcontainerDetails");
			showAlerts("Container details not found");
		}
	});
}

function updateContainerAttributes() {
	
	var containerData = $(".container_details_table *").serialize();
	
	$.ajax({
		type: "POST",
		url: "/app/Che/update_container_attributes",
		data: containerData,
		success: function(result) {
			if (result != 'error') {
				if(result == "true"){;
					closePopup();
				}else{
					return false;
				}
			} else {
				console.log("ERROR - getcontainerDetails");
				showAlerts("Container details not found");
			}
		},
		error: function(){
			console.log("ERROR - getcontainerDetails");
			showAlerts("Container details not found");
		}
	});
}