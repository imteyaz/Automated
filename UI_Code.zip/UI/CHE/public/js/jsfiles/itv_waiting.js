function start_blinking(cntr_id,frequency,color){
//	console.log(cntr_id)
//	console.log(frequency)
//	console.log(color)
//	var speed = 0;
//	frequency == 0 ? (speed=1000) : (frequency == 1 ? (speed = 500) : (speed=250))
//			console.log(speed)		
	$("#qc_table tr[data-container='"+cntr_id+"']").css("background-color",color);
}

function stop_blinking(cntr_id){
	$("#qc_table tr[data-container='"+cntr_id+"']").css("background-color","#F7F7F7").css("border-bottom", "1px solid #D5CECE").css("cursor", "pointer")
	
}