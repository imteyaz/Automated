//@ sourceURL=assignment_confirmation.js  
$(document).ready(function(){
	virtualKeyboard();
    $('select[value]').each(function(){
        $(this).val(this.getAttribute("value"));
    }); 
       
    $("#sel1").msDropdown({ roundedBorder: false });
	$("#sel2").msDropdown({ roundedBorder: false });
    hideSelectOptions();
    $('#sel1').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Non-Operational") {
			$('#sel2').removeClass('hidden');
			$('#otherOptText').removeClass('hidden');
			$('#otherOptText').parents('.reason_delay').removeClass('hidden');
			$('#otherOptText').hide();
		} else {
			hideSelectOptions();
		}
	});

	$('#sel2').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Other") {
			$('#otherOptText').show();
			$('#otherOptText').parents('.reason_delay').removeClass('hidden');
		} else {
			$('#otherOptText').hide();
		}
	});
                             
    function hideSelectOptions(){
        $('#sel2').addClass('hidden');
        $('#otherOptText').addClass('hidden');
        $('#otherOptText').parents('.reason_delay').addClass('hidden');
    } 
    
    function validateInputs() {
		if ($('#sel1').val() === "Non-Operational") {
			if ($('#sel2').val() === "" || $('#sel2').val() === null) {
				return false;
			} else if ($('#sel2').val() === "Other") {
				if ($("#otherOptText").val() === "" || $("#otherOptText").val() === null) {
					return false;
				}
			}
		}
		return true;
	}
    
	function validateInputField(){
				
		return true;
	}

    $('#confirm_allocation').on('click', function(e){ 
    	
    	// Setting up the equipment Id..
    	$('#rmgEquipmentId').val($('#msg_equipmentId').val())
    	
    //msg_equipmentId
    	
    	 if(validateInputField() == false) {
            return;
        //prevent the default action
        }
        else{
        $('#confirm_allocation').attr("disabled", true).addClass("disable_btns");
        $('.login_exit').attr("disabled", true).addClass("disable_btns");
        
        var allocation = $(".assign_confirmation :input").serialize();       
        $.ajax({
            type:   "POST",
            url:  "/app/Login/checklist",
            data:allocation,
            success:function(result)
            {
            	 //$(".main_layout").html("");  
                 //$(".main_layout").html(result);
                 if (result != 'Error') {
						$(".main_layout").html("");
						$(".main_layout").html(result);
					} else {
						$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
						$('.login_exit').attr("disabled", false).removeClass("disable_btns");
					}
            },
            error: function() {
				$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
				$('.login_exit').attr("disabled", false).removeClass("disable_btns");
			}
        });
        }
    })

//	$('#confirm_allocation').on('click', function(e) {
//		if (validateInputs()) {
//			var allocation = $(".assign_confirmation :input").serialize();
//			$('#confirm_allocation').attr("disabled", true).addClass("disable_btns");
//
//			$.ajax({
//				type: "POST",
//				url: "/app/Login/checklist",
//				data: allocation,
//				success: function(result) {
//					if (result != 'Error') {
//						$(".main_content").html("");
//						$(".main_content").html(result);
//					} else {
//						$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
//						$('.login_exit').attr("disabled", false).removeClass("disable_btns");
//					}
//				}
//				,
//				error: function() {
//					$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
//					$('.login_exit').attr("disabled", false).removeClass("disable_btns");
//				}
//			});
//		} else {
//			showAlerts("Please fill all fields");
//		}
//	})
	 
});   