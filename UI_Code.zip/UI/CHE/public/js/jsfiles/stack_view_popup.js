$(document).ready(function(){
	virtualKeyboard()
	
	var cnt_no = $(".stack_highlighetd_cell").attr("cellid")
	console.log(cnt_no)
		var yrd_pos = $(".stack_highlighetd_cell").attr("yrd_pos");
	console.log(yrd_pos)
//	$(".popup_page").css("height","40%");
	
	// start Damage button function
	$("#stk_pop_dmg").on("click",function(){
		console.log("Con Dmg no")
		console.log($(".stack_highlighetd_cell").attr("cellid"))
		cntr_data = {movekind: "",containers: $(".stack_highlighetd_cell").attr("cellid")+"|",itvs: "",ground: "",requested_from:"stack_view"}

		var isDamagedValue= $("#qc_table tr[data-container='"+cntr_data.containers.split("|")[0]+"']").attr("is_damaged");
		
		if(isDamagedValue=="false"|| isDamagedValue=="" || typeof isDamagedValue=="undefined"){
			getDamageRecordView(cntr_data);
		}
		else{
			getdamageCrctnScreen(cntr_data)
		}
	})
	//end damage function
	
	// Container enquiry button function 
	$("#stk_pop_cntr_enq").on("click",function(){
		var cnt_no = $(".stack_highlighetd_cell").attr("cellid")
		$.ajax({
			type: "POST",
			url: "/app/Che/getContainerEnqScreen",
			data: {
				containerNumber: cnt_no
			},
			success: function(result) {
				if (result != 'Error') {
					$('#light').html(result)
					document.getElementById('light').style.display = 'block';
					$("#containerNumber").val(cnt_no);
					$(".container_details_table").hide();
					getEnteredConatinerData()
				} else {
					console.log("ERROR - displayContainerEnqScreen");
				}
			},
			error: function(){
				console.log("ERROR - displayContainerEnqScreen");
			}
		});
	})
	//end container enquiry function
	
	// start Inventory button function
	$("#stk_pop_inven_btn").on("click",function(){
		call_stck_inv($(".stack_highlighetd_cell").attr("cellid"),$(".stack_highlighetd_cell").attr("yrd_pos"),"Inventory")
		
	})
	//end inventory function
	
	// start Shuffle button function
	$("#stk_pop_shuff").on("click",function(){
		var cnt_no = $(".stack_highlighetd_cell").attr("cellid");
		var yrd_pos = $(".stack_highlighetd_cell").attr("yrd_pos");
		$.ajax({
			type: "POST",
			url: "/app/Che/stck_shuff_view",
			data: {
				container_number: cnt_no,
				yrd_pos: yrd_pos
			},
			success: function(result) {
				closePopup();
				if(result == "true"){
					//call_stck_inv(cnt_no,"Shuffle")
				}
				else{
					showAlerts(result);
				}
			},
			error: function(){
				console.log("ERROR - Shuffle view");
			}
		});
	})
	// end shuffle function
	
	// start Cancel button click function
	$("#stk_pop_cncl").on("click",function(){
		closePopup();
	})
	// end cancel button function
	
	 $("#stk_inv_update").on("click",function(){
		    if($("#inv_stk_to_loc_val").val() != ""){
		      $.ajax({
		           type: "POST",
		           url: "/app/Che/stack_inv_update",
		           data: {
		             containerNumber: $(".inv_stk_cntr_no").html().trim(),
		             from_loc: $("#inv_stk_from_loc_val").val(),
		             to_loc: $("#inv_stk_to_loc_val").val(),
		             movekind: "RH" 
		           },
		           success: function(result) {
		             if (result == 'true') {
		                 closePopup();
		               showAlerts("Confirmed succesfully");
		             } else {
		            	 showAlerts(result);
		            	 closePopup();
		             }
		           },
		           error: function(){
		             console.log("ERROR - displayContainerEnqScreen");
		           }
		         });
		    }
		      else{
		        showAlerts("To location can not be blank");
		      }
		  })
	
		  $("#stk_pop_update").on("click",function(){
			  
			  getUpdateContainerPopup($(".stack_highlighetd_cell").attr("cellid"))
		  })
})

function getUpdateContainerPopup(containerNumber) {
	var cnt_no = $(".stack_highlighetd_cell").attr("cellid");
	$.ajax({
		type: "POST",
		url: "/app/Che/get_container_update_popup",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				$("#containerNumber").val(cnt_no);
			} else {
				showAlerts("Unable to process request");
			}
		}
	});
}

function call_stck_inv(cntr_no,yard_pos,header){
	$.ajax({
		type: "POST",
		url: "/app/Che/stck_inv_view",
		data: {
			container_number: cntr_no,
			yard_pos: yard_pos,
			heading: header
		},
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				 $(".popup_page").css("width","auto");
			} else {
				console.log("ERROR - Inverntory view");
			}
		},
		error: function(){
			console.log("ERROR - Inverntory view");
		}
	});
}

