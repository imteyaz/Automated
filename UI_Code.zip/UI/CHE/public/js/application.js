window.onerror = function(msg, url, line, col, error) {
   // Note that col & error are new to the HTML 5 spec and may not be 
   // supported in every browser.  It worked for me in Chrome.
   var extra = !col ? '' : '\ncolumn: ' + col;
   extra += !error ? '' : '\nerror: ' + error;

   console.log(url);
   // You can view the information in an alert to see things working like this:
   var errorMessage = msg + "\nurl: " + url + "\nline: " + line + extra;
   //alert(errorMessage);

   // TODO: Report this error via ajax so you can keep track
   //       of what pages have JS issues

   var suppressErrorAlert = true;
   // If you return true, then error alerts (like in older versions of 
   // Internet Explorer) will be suppressed.
   Rho.Log.error(errorMessage, "javascript");
};


function showAlerts(messagedetails){
	swal({
	  html: '<p class="alert_data">'+messagedetails+'</p>', 
	  showCancelButton: false,
	  allowOutsideClick: false,
	  closeOnConfirm: true
	});
	
	$('#layout').unmask();
	
}


function maskScreen(){
	$(".main_layout").mask("Loading...");
}


function unmaskScreen(){
	$(".main_layout").unmask();
}

function confirmYesOrNo(popMessage, callback){
	popMessage = popMessage || "Do you want continue?";
    
	
    swal({
      text: popMessage,
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
        	  callback("T");
          }else{
        	  callback("F");
          }
      });
    
}

function confirmDelay(popMessage,callback){
	popMessage = popMessage || "Do you want continue?";
    swal({
      text: popMessage,
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
        	  callback("yes");
          }else{
        	  callback("no");
          }
      });
    
}
