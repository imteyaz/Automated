class LoginController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include HcHelper
  def index
    $myThread  = Thread.start{waitforITVArrived()}
  end

  #Setting UDP Connection
  def set_udp_connection
    $server_login_failure = true
    @msg=""
    if( @params['login'].empty? || @params['password'].empty?)
      @msg = "Un-Authorized Access"
      render :action => :index
    end
    $userid = @params['login'].upcase

    $session[:removedjobs] = Array.new
    @udp_req_obj[:msg] = "1~1~1200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['password']}~#{$device_id}~HC~#{@params['salt']}~#{@params['iv']}"
    $loggedout = false
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    #    create_log_file()
    if(resp.length < 0)
      render :action => :index
    else
      $server_login_failure = false
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      #      if (resp_msg_id != "1201")
      #        $myThread  = Thread.start{waitforITVArrived()}
      #      end
      if(resp_msg_id == "1201") # Login failure
        @msg = resp_fields[3]
        render :action => :index
      elsif("1399" == resp_msg_id)
        $loggedin = true
        @msg_rt,@msges_list,@msges_ter = processconfirmation_checklist(resp_fields)
        render :action =>  :asignment_confirmation
      elsif(resp_msg_id == "1203")
        $loggedin = true
        @msg_lateLogin_reasons,@msg_lateby_mins = processlatelogin(resp_fields)
        render :action => :latelogin
      elsif(resp_msg_id=="1405")
        $loggedin = true
        # @resp_qc_job = processjoblist(resp_fields)
        render :action => '../Hc/index'
      else
        render :action => :index
      end
    end
  end

  # From late_login to Assignment_Confirmation
  def assign_confrm
    @udp_req_obj[:msg] = "1~1~1204~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['lateloginreason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1399" == resp_msg_id)
        @msg_rt,@msges_list,@msges_ter = processconfirmation_checklist(resp_fields)
        render :action => :asignment_confirmation
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  # From Assignment_Confirmation to Checklist
  def checklist
    $rotation_id = @params['msg_rt'].strip
    $vessel_name = @params['msg_rtname']
    $EquipmentId = @params['msges_eq']
    @udp_req_obj[:msg] = "1~1~1401~#{geteventid}~#{$userid}~#{ @params['msges_ter']}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{$rotation_id.to_s().split(' ')[0]}~~#{ @params['msges_eq']}~#{ @params['msges_eq']}~#{ @params['remarks']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1402")
        resp_msg_checklist = resp_fields[2]
        if(resp_msg_checklist == "")
          redirect :action => :cancel
        end
        @resp_userid = resp_fields[3]
        @resp_termid = resp_fields[4]
        msg_checklist = resp_msg_checklist.to_s.split('|')
        @resp_checklist = Array.new
        msg_checklist.each do |check_list|
          @resp_checklist.push(check_list.to_s().split('^'))
        end
        render :action => :checklist
      elsif(resp_msg_id == "9998")
        res = resp_fields[3]
        WebView.execute_js('showAlerts("'+ res.to_s() + '")')
        render :string => "Error"
      else
        render :action => :assignment_confirmation
      end
    else
      WebView.execute_js("showAlerts('Server is not responding')")
      render :string => "Error"
    end
  end

  #Checklist Item Icon
  def get_checklist_item_icon(item_no)
    item_no_to_icon_map = {"1" => "chkimg", "2" => "chkimgalert", "3" => "chkimgerror"}
    return item_no_to_icon_map.fetch(item_no, "chkimg")
  end

  #Checklist Status
  def preOperationalChecklistStatus
    @params['chk_list'] ||= []
    completeChecklistStatus = (@params['chk_list'].map {|item| item = item + "^p" }).join("|")
    if completeChecklistStatus.length > 3900
      message_string =  completeChecklistStatus.scan(/.{1,1024}/)
      for iMsgindx in 1..message_string.length
        @udp_req_obj[:msg] = "iMsgindx~message_string.length~1403~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{message_string[iMsgindx]}~p"
        if(iMsgindx == message_string.length)
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        else
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
        end
      end
    else
      @udp_req_obj[:msg] = "1~1~1403~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{completeChecklistStatus}~p"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    end
    return resp
  end

  #QC Landing Page
  def hc_home
    resp = preOperationalChecklistStatus()
    $session[:removedjobs] = Array.new
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      if(resp_fields[0] == "1405")
        $promoted_jobs = Array.new
        @resp_qc_job = processjoblist(resp_fields)
        render :action => '../Hc/index'
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  def change_contr_edit_val
    $contr_edited = true
    cnt_format = @params["selected_container"].split("^") 
    $selected_container = cnt_format[1]+"^"+cnt_format[0] 
    puts $contr_edited.inspect
    puts $selected_container.inspect
    puts "In Edit mode"
    render :string => true
  end

  def contr_edit_val_false
    $contr_edited = false
    $selected_container = ""
    render :string => true
  end

  #QC container movement
  def qc_container_move(container, from_location, to_location, movekind, seal_ok, seal_ok_data, current_position, category_info)
    sealInformation = seal_ok_data.split("~")
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{container}~#{from_location}~#{to_location}~#{movekind}~~#{sealInformation[0]}~#{sealInformation[1]}~#{sealInformation[2]}~#{current_position}~#{category_info}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "1603")
      resp_fields[3] == "true" ? (return true) : (WebView.execute_js('showAlerts("'+ resp_fields[4] + '")');return false)
    else
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end
  end

  $checkForITVArrivedFlag = true

  def process_notification_response(resp)
    container = ""
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1306" || resp_msg_id == "1307")
        processcontainerarrived(resp)
      elsif(resp_msg_id == "1308")
        processITVLeft(resp)
      elsif(resp_msg_id == "9001")
        processheavyhook(resp)
      elsif(resp_msg_id == "9997")
        processcontainerhandling(resp)
      elsif(resp_msg_id == "9995")
        processqcperformance(resp)
      elsif(resp_msg_id == "1601")
        processjobdone(resp)
      elsif(resp_msg_id == "9996")
        #processdelayrecording(resp)
      elsif(resp_msg_id == "9998")
        processworkstopalert(resp)
      elsif(resp_msg_id == "9993")
        process_freeze_unfreeze_app(resp)
      elsif(resp_msg_id == "9994" || resp_msg_id == "9992" || resp_msg_id == "9910")
        processnormalalertmessage(resp)
      elsif(resp_msg_id == "1405")
        puts "1405 called"
        updatejoblist(resp)
      elsif(resp_msg_id == "1602")
        removingjobs(resp)
      elsif(resp_msg_id=='9990')
        processplcactivedeactive(resp)
      elsif(resp_msg_id=='1800')
        addManualJobs(resp)
      elsif(resp_msg_id=='1801')
        deleteManualJobs(resp)
      elsif(resp_msg_id=='1407')
        updateTwinTandemSplitJobs(resp)
      elsif(resp_msg_id == "9999")
        forcelogout(resp)
      elsif(resp_msg_id == "2213")
        process_damage_record_changed(resp)
      elsif(resp_msg_id == "2501")
        search_itv_pool(resp)
      elsif(resp_msg_id == "9101")
        processplcactivedeactive(resp)
      elsif(resp_msg_id == "1118")
        process_auto_updates(resp)
      elsif(resp_msg_id == "1309")
        update_completed_jobs(resp)
      else
        puts resp.inspect
      end
    end
  end

  def update_completed_jobs(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2] == "false")
      containers = resp_fields[3].split("|")
      containers.each do |container|
        container_details = container.split("$")
        container_no = container_details[0]
        itv_no =  container_details[1]
        selected_jobs = $completedjobs.select{|v| (container_no.include? v.containerno + '^' + v.code)}
        selected_jobs.each do |selected_job|
          selected_job.to_loc = itv_no
        end
        res = "REFRESH_JOBS"
        WebView.execute_js('showAlerts("Swap change failed")')
        WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
      end
    else
      WebView.execute_js('showAlerts("Swap change is successfull")')
    end
  end

  def process_auto_updates(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2] != resp_fields[3])
      update_source_code(resp_fields[3])
    end
    return true
  end

  def update_source_code(version_no)
    #Download a file to the specified filename.
    begin
      #    downloadfileProps = Hash.new
      #    downloadfileProps["url"]='http://127.0.0.1:8082/ATOMMobileAppRel/HC/31-05-2017_HC.zip'
      #    downloadfileProps["filename"] = Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/31-05-2017_HC.zip")
      #    downloadfileProps["overwriteFile"] = true
      #    Rho::Network.downloadFile(downloadfileProps, url_for(:action => :download_file_callback))

      response = Net::HTTP.get_response(URI.parse(Rho::RhoConfig.auto_update_url+"/#{version_no}.zip"))
      File.open(Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip"), "wb") do |saved_file|
        saved_file.write(response.body)
      end

      puts "Finished downloading"
      puts "Creating folder"
      #    stdin, stdout, stderr = Open3.popen3('cscript C:\Users\1102519\Desktop\Projects\HC_UI_STD\public\unzip.vbs')
      #    parse_instances("bash C:/Users/1102519/Desktop/Projects/HC_UI_STD/public/unzip.vbs")

      system "cscript //nologo #{Rho::Application.publicFolder}/unzip.vbs #{Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip")} #{Rho::RhoConfig.path_to_extract}"
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~true~#{version_no}~"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      Rho::Application.quit
    rescue Exception => e
      puts "Exception in updating source code"
      puts e.message.inspect
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~false~#{version_no}~#{e.message.to_s()}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
    return true
  end

  #  def update_ui_app
  #    puts "In update"
  #    begin
  #      puts "In Begin"
  #      File.open("C:/Users/1102519/Desktop/ATOM/webapps/ATOMMobileAppRel/QC/tmp_code.zip", "wb") do |saved_file|
  #        open("http://localhost:8082/ATOMMobileAppRel/index.html", "rb") do |read_file|
  #          saved_file.write(read_file.read)
  #        end
  #      end
  #    rescue Exception => ex
  #      puts ex
  #      puts "In Exception"
  #    end
  #  end

  def process_poll_request
    $notifications_array.each do |resp|
      process_notification_response(resp)
    end
    $notifications_array = []
  end

  def waitforITVArrived
    resp_server = ""
    while($checkForITVArrivedFlag)
      resp_server = recv_response($udp_socket, 1, 1)
      if $contr_edited != true
        Thread.new do
          process_notification_response(resp_server)
        end
      else
        if(resp_server != "")
          resp_fields = resp_server.to_s.split("~")
          puts resp_fields.inspect
          puts "resp_fields"
          if(resp_fields[0] == "1405")
            puts "Received 1405"
            puts resp_server.inspect
            puts "Message received"
            puts resp_server.include?($selected_container).inspect
            puts "Checking here"
            if(resp_server.include?($selected_container))
              puts "Checking if container is an selected container"
              Thread.new do
                puts "Inside notification"
                process_notification_response(resp_server)
              end
            else
              $notifications_array.push(resp_server) if !$notifications_array.include?(resp_server)
            end
          else
            $notifications_array.push(resp_server) if !$notifications_array.include?(resp_server)
          end
        end
      end
    end
  end

  #Cancel the pre checklist
  def cancel
    @udp_req_obj[:msg] = "1~1~1404~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      resp_qc_list = resp_fields[2].to_s.split('|')
      @resp_qc_job = Array.new
      resp_qc_list.each do |check_list_item|
        @resp_qc_job.push(check_list_item.to_s.split('^'))
      end
      if(resp_msg_id == "1405")
        $promoted_jobs = Array.new
        @resp_qc_job = processjoblist(resp_fields)
        render :action => '../Hc/index'
      else
        render :action => :checklist
      end
    else
      render :string => "Error"
    end
  end

  #forcefully logging out
  def forcelogout(resp)
    $forcelogout = true
    WebView.execute_js("window.location.href = '/app/Login/logout?force_logout=true'")
  end

  # Loging out
  def logout
    $checkForITVArrivedFlag  = false
    $loggedout = true
    $loggedin = false
    $completed_jobsrequest = false
    $display_itv_pow = Array.new
    $force_logout_msg = ""
    if (@params["force_logout"] != "true")
      @udp_req_obj[:msg] = "1~1~9999~#{geteventid}~#{ $userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    if($myThread.keys.length > 0)
      $myThread.exit
    end
    log_file_backup($userid)
    clearsession
    $checkForITVArrivedFlag  = true
    @msg = "Logged Out Successfully"
    if @params["force_logout"] == "true"
      $force_logout_msg = "You have been logged out forcefully by Administrator"
    end
    redirect :controller=> :Login, :action => :index
  end

  def clearsession()
    $session[:Itv_popup_image].clear
    $resp_qc_jobs.clear
    $completedjobs.clear
    $job_list_confirm.clear
  end

  def log_file_backup(user_id)
    begin
      log_file = Rho::Log
      file = File.open(log_file.filePath, "r")
      data = file.read
      file.close
      dt = DateTime.now
      if !(Dir.exists?(Rho::RhoConfig.log_backup_path))
        Dir.mkdir(Rho::RhoConfig.log_backup_path)
      end
      dt_str = dt.day.to_s+"_"+dt.month.to_s+"_"+dt.year.to_s+"_"+dt.hour.to_s+"_"+dt.minute.to_s+"_"+dt.second.to_s
      file_to_wrtite = Rho::RhoConfig.log_backup_path+"/"+user_id+dt_str+".txt"
      File.open(file_to_wrtite, "wb") do |backup_file|
        backup_file.write(data)
      end
      puts "Created log file"
      file = File.new(log_file.filePath, "w") do |actual_log_file|
        actual_log_file.write("Cleared")
      end
    rescue Exception => e
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
  end

  def processconfirmation_checklist(resp_fields)
    msg_rt = resp_fields[2].to_s.split("|")
    @rotationDetails = resp_fields[2]
    msges_list = resp_fields[3].to_s.split("#")
    msges_ter = "#{resp_fields[6]}"
    $terminal = msges_ter
    return msg_rt,msges_list,msges_ter
  end

  def getSelectedmsg_rt()

  end

  def processlatelogin(resp_fields)
    msg_lateLogin_reasons = resp_fields[3].split("|")
    msg_lateby_mins = resp_fields[2]
    return msg_lateLogin_reasons,msg_lateby_mins
  end

  def searchjobs(container)
    resp_qc_job = Array.new
    if !container.empty?
      resp_qc_job = $resp_qc_jobs.select{|v| (v.containerno.include? container) || (v.from_loc.include? container) || (v.to_loc.include? container)}
    else
      resp_qc_job = $resp_qc_jobs
    end
    return resp_qc_job
  end

  def getunavlblereasons
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2000~#{geteventid}~#{$userid}~#{$terminal}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2000")
        @msg = resp_fields[2].split("|")
      end
    end
    render :action => '../Hc/rmspopup_handling'
  end

  def sendUnavailableRes
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~F~#{@params['rms_select']}~#{@params['available_time']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2003")
        @msg = resp_fields[2]
      end
    end
    render :action => '../Hc/rmspopup_handling'
  end

  def sendAvailableRes
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~T~#{@params['rms_select']}~#{@params['available_time']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
    end
    render :string => "success"
  end

  def quit_app
    Rho::Application.quit
  end

end

