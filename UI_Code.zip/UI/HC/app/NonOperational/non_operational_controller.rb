class NonOperationalController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include HcHelper
  #Get Dynamic Labor Management
  def dynamic_labor_management
    render :action => :dlm
  end

  #Get Communication by message or Voice

  def message_voice_calls
    render :action => :communication
  end

  #
  #  #Show technical support page
  def techinal_support
    render :action => :technical_support
  end
  #
  #  #Get technical support details from server
  def technical_support_details
    #1~1~3100~7dfged7hjh~user1~T2~Wed Feb 25 11:07:38 IST 2015
    @udp_req_obj[:msg] = "1~1~3100~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("3101" == resp_msg_id)
        @problem_code = resp_fields[2]
        @location = resp_fields[3]
        @equipment_id = resp_fields[4]
        render :action => "tech_support_details"
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end
  #
  #  #Sending Technical support details to server
  def send_technical_support_details
    @udp_req_obj[:msg] = "1~1~3102~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['location']}~#{@params['problem_code']}~#{@params['problem_description']}~#{@params['location_description']}~#{@params['asset_number']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end
  
  def moves_to_go
    @udp_req_obj[:msg] = "1~1~3300~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{$eqiptment_id}"
        resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        if resp.length > 0
          resp_fields = resp.to_s.split("~")
          resp_msg_id = resp_fields[0]
          resp_msg = resp_fields[2]
          if(resp_msg != "")
              if("3301" == resp_msg_id)
                total_jobs_cnt = resp_fields[2].split("$")
                dsch_jobs = total_jobs_cnt[0].split("^")
                load_jobs = total_jobs_cnt[1].split("^")
                dsch_twnty_jobs = dsch_jobs[1].split("|")
                dsch_forty_jobs = dsch_jobs[2].split("|")
                load_twnty_jobs = load_jobs[1].split("|")
                load_forty_jobs = load_jobs[2].split("|")
                
                @dich_twnty_full_general = dsch_twnty_jobs[1]
                @dich_twnty_full_oog = dsch_twnty_jobs[2]
                @dich_twnty_empty_general = dsch_twnty_jobs[3]
                @dich_twnty_empty_oog = dsch_twnty_jobs[4]
                
                @dich_forty_full_general = dsch_forty_jobs[1]
                @dich_forty_full_oog = dsch_forty_jobs[2]
                @dich_forty_empty_general = dsch_forty_jobs[3]
                @dich_forty_empty_oog = dsch_forty_jobs[4]
                
                @load_twnty_full_general = load_twnty_jobs[1]
                @load_twnty_full_oog = load_twnty_jobs[2]
                @load_twnty_empty_general = load_twnty_jobs[3]
                @load_twnty_empty_oog = load_twnty_jobs[4]
                
                @load_forty_full_general = load_forty_jobs[1]
                @load_forty_full_oog = load_forty_jobs[2]
                @load_forty_empty_general = load_forty_jobs[3]
                @load_forty_empty_oog = load_forty_jobs[4]
                
                render :action => "moves_to_go"
              else
                render :string => "Error"
           end
         else
           render :string => "No_data"
         end
       else
         render :string => "Error"
       end
   end
  
  
end