module HcHelper
  class Joblist
    include Enumerable
    attr_accessor :code,:containerno,:iso,:country,:wght,:from_loc,:to_loc,:remarks,:refercontainer,:colorcode,:twinpick,:tandempick,:st,:cat,:bay,:tier,:row,:alternatecell,:jobtype,:sparcsexception,:exception_reason, :is_damaged, :seal_ok, :imdg, :door_direction, :container_position, :seq_no
    def initialize(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st, seal_ok, imdg, door_direction="AFT", is_damaged="false", container_position="F",seq_no="0",jobtype="planned",sparcsexception="N",exception_reason="")
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st, seal_ok, imdg, door_direction ,is_damaged, container_position, seq_no ,jobtype,sparcsexception,exception_reason)
    end

    def updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer,colorcode,twinpick,tandempick,cat,st,seal_ok, imdg, door_direction="AFT",is_damaged="false", container_position="F", seq_no="0" ,jobtype="planned",sparcsexception="N",exception_reason="")
      @jobtype,@code = jobtype,code
      @sparcsexception = sparcsexception
      @exception_reason = exception_reason
      @code = code
      @containerno = containerno.upcase
      @iso = iso
      @country = country
      @wght = wght
      @from_loc = from_loc
      @to_loc = itvno
      @remarks  =remarks
      @colorcode = colorcode
      @seal_ok = seal_ok
      @imdg = imdg
      @container_position = container_position
      @door_direction = door_direction
      @is_damaged = is_damaged
      @seq_no = seq_no
      if(st == 'true')
        @st = 'M'
      elsif(st == 'false')
        @st = 'F'
      else
        @st = ""
      end
      @cat = cat
      @twinpick = -1
      @tandempick = -1
      @refercontainer =""
      if(!refercontainer.nil? && !refercontainer.empty?)
        @refercontainer =refercontainer
        @twinpick = twinpick
        @tandempick = tandempick
      end
      if(code == "DSCH" && from_loc != 'VESSEL')
        cellvalues = from_loc.split(".")
      elsif(code=="LOAD" && to_loc != 'BACKREACH')
        cellvalues = to_loc.split(".")
      else
        cellvalues = [-1,-1,-1]
      end
      @bay = cellvalues[0].to_i
      @row = cellvalues[1].to_i
      @tier = cellvalues[2].to_i
      @alternatecell = ""
      if(@bay%2 == 0 && @bay != 0)
        @alternatecell = (@bay-1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." +cellvalues[2] + "|" + (@bay+1).to_s.rjust(2, '0') + "." + cellvalues[1] + "." + cellvalues[2]
      end
    end

    def updatejob(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer, colorcode,twinpick,tandempick,cat,st,seal_ok,imdg,door_direction,is_damaged,container_position,seq_no,jobtype,sparcsexception,exception_reason)
      updatevalues(code,containerno,iso,country,wght,from_loc,itvno,remarks,refercontainer, colorcode,twinpick,tandempick,cat,st, seal_ok,imdg,door_direction,is_damaged,container_position,seq_no,jobtype,sparcsexception,exception_reason)
    end
  end
  
  def create_log_file
    pathm = Rho::Application.userFolder
    puts pathm.inspect()
    
    pathm = Rho::Application.userFolder
           puts pathm.inspect()
    
    f = pathm + "rhosimulator/"
    file = f + "rholog.txt"
       
    file_name = f + 'rholog_' + Date.today.prev_day.to_formatted_s(:long).to_s() + '.txt'
    
    if(File.file?(file_name) == false)
      logFileContentBefore = Rho::Log.readLogFile(0)
          
      # Clear log file
      Rho::Log.cleanLogFile
      
      File.open(file_name, 'a') { |file| file.write(logFileContentBefore) }
    end
    
  end

  #Joblist refresh from client
  def joblist
    @resp_qc_job = Array.new
    @filterval = "current_jobs"
    if @params["reqtype"].eql?("shuffle")
      @resp_qc_job = shufflingjobs(@params["containeritvinfo"])
    elsif @params["reqtype"].eql?("filter")
      @resp_qc_job = filterjobs(@params["containeritvinfo"])
      @filterval =  @params["containeritvinfo"]
    elsif @params["reqtype"].eql?("plcjobdone")
      getlistaftrplcjobdone(@params["containeritvinfo"])
      @resp_qc_job = filterjobs(@params["select_value"])
      @filterval =  @params["containeritvinfo"]
    else
      getjoblist(@params["to_loc"],@params["from_location"], @params["troubleDamageClicked"], @params["seal_ok"], @params["seal_ok_data"], @params["containerPositions"], @params["categoryInfo"])
      @resp_qc_job = filterjobs(@params["containeritvinfo"])
    end
    twin_tandem_pairing
    if(@params["containeritvinfo"] == "current_jobs")
      @resp_qc_job = @resp_qc_job.sort{|x,y| x.seq_no.to_f<=>y.seq_no.to_f}
    end
    render :action => '../Hc/joblist'
  end

  def twin_tandem_pairing
    #    all_jobs = $resp_qc_jobs + $completedjobs

    $resp_qc_jobs.each do |job|
      ref_containers = job.refercontainer
      if ref_containers != nil
        ref_container_list = ref_containers.to_s.split("#")
        if ref_container_list.length == 1
          ref_container_list.each do |refer|
            refer_job = $resp_qc_jobs.select{|v| (v.containerno == refer )}[0]
            if refer_job != nil
              job.twinpick = 0
              if refer_job.twinpick = 0
                job.twinpick = 1
              end
            end
          end
        end
        if ref_container_list.length == 3

          ref_container_list.each do |refer|
            refer_jobs = $resp_qc_jobs.select{|v| (ref_container_list.include?(v.containerno ))}
            #            if refer_jobs.length == 3
            refer_jobs.each do |refer_job|
              refer_jobs[0].twinpick = 0 if refer_jobs[0] != nil
              refer_jobs[1].twinpick = 1 if refer_jobs[1] != nil
              refer_jobs[2].twinpick = 0 if refer_jobs[2] != nil
              job.twinpick = 1
              refer_jobs[0].tandempick = 0 if refer_jobs[0] != nil
              refer_jobs[1].tandempick = 1 if refer_jobs[1] != nil
              refer_jobs[2].tandempick = 2 if refer_jobs[2] != nil
              job.tandempick = 3
            end
          end
          #          end
        end
      end
    end

    $completedjobs.each do |job|
      ref_containers = job.refercontainer
      if ref_containers != nil
        ref_container_list = ref_containers.to_s.split("#")
        if ref_container_list.length == 1
          ref_container_list.each do |refer|
            refer_job = $completedjobs.select{|v| (v.containerno == refer )}[0]
            if refer_job != nil
              job.twinpick = 0
              if refer_job.twinpick = 0
                job.twinpick = 1
              end
            end
          end
        end
        if ref_container_list.length == 3

          ref_container_list.each do |refer|
            refer_jobs = $completedjobs.select{|v| (ref_container_list.include?(v.containerno ))}
            #            if refer_jobs.length == 3
            refer_jobs.each do |refer_job|
              refer_jobs[0].twinpick = 0 if refer_jobs[0] != nil
              refer_jobs[1].twinpick = 1 if refer_jobs[1] != nil
              refer_jobs[2].twinpick = 0 if refer_jobs[2] != nil
              job.twinpick = 1
              refer_jobs[0].tandempick = 0 if refer_jobs[0] != nil
              refer_jobs[1].tandempick = 1 if refer_jobs[1] != nil
              refer_jobs[2].tandempick = 2 if refer_jobs[2] != nil
              job.tandempick = 3
            end
          end
          #          end
        end
      end
    end

  end

  def process_damage_record_changed(resp)
    resp_fields = resp.to_s.split("~")
    selected_job  = $resp_qc_jobs.select{|v| v.containerno == resp_fields[2]}
    if selected_job.empty?
      selected_job = $completedjobs.select{|v| v.containerno == resp_fields[2]}
    end

    if selected_job.empty?
    else
      selected_job[0].is_damaged = resp_fields[3].to_s;
    end

    WebView.execute_js('addRemoveDamageIcon("'+ resp_fields[2] + "#" + resp_fields[3] + '")')

  end

  def processcontainerarrived(resp)
    resp_fields = resp.to_s.split("~")
    resp_msg_id = resp_fields[0]
    if(resp_msg_id == "1306")
      if(resp_fields[3].empty?)
        $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
        $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6])
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6] + '")')
      else
        # move job to promoted joblist in case of load and in present of container number
        $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
        $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6])
        contritvcomb = resp_fields[3] + "|" + resp_fields[2]
        #WebView.execute_js('shufflejobs("'+ contritvcomb.to_s() + '")')
        WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[4] +"#"+ resp_fields[5] + "#" + resp_fields[6] + '")')
      end
    else
      $session[:Itv_popup_image].delete_if {|v| v.split("#")[0] == resp_fields[2]}
      $session[:Itv_popup_image].push(resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5])
      WebView.execute_js('highLightITVWhenArrived("'+ resp_fields[2] +"#"+ resp_fields[3] +"#"+ resp_fields[4] + "#" + resp_fields[5] + '")')
    end
  end

  def processITVLeft(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2].empty?)
      return false
    else
      contritvcomb =  resp_fields[2]
      cIndex = $session[:Itv_popup_image].index{|v| (v.split("#")[0]==contritvcomb)}
      if(cIndex != nil)
        $session[:Itv_popup_image].delete_at(cIndex)
        itvleft = "IT_LEFT"
        WebView.execute_js('removeITV("'+ contritvcomb + '")')
      end
    end

  end

  def processheavyhook(resp)
    resp_fields = resp.to_s.split("~")
    if( resp_fields[2] == "true")
      res = "HVY_HK_TRUE"
    else
      res = "HVY_HK_FALSE"
    end
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def processqcperformance(resp)
    resp_fields = resp.to_s.split("~")
    qc_view = resp_fields[3].to_s+"|"+resp_fields[4].to_s + "|"+resp_fields[5].to_s + "|"+ resp_fields[6].to_s + "|"+resp_fields[7].to_s
    WebView.execute_js('updateQCfields("'+ qc_view.to_s() + '")')
  end

  def create_joblist(resp_fields)

  end

  #method for processing job list
  def processjoblist(resp_fields,joblisttype='new')
    out_of_list_jobs = Array.new
    resp_qc_list = resp_fields[2].to_s.split('|')
    twinpick = -1
    tandempick = -1
    resp_qc_list.each do |check_list_item|
      if (tandempick == 3)
        tandempick = -1
      end
      jobfields = check_list_item.to_s.split('^')
      if(!jobfields[8].nil? && !jobfields[8].empty?)
        ref_container_list = jobfields[8].to_s.split('#')
        if(ref_container_list.length > 2)
          tandempick = tandempick + 1
        end
        if(twinpick == 0)
          twinpick=1
        else
          twinpick=0
        end
      end
      jobtype = 'planned'
      if(jobfields[5] == 'BACKREACH' || jobfields[5] == 'VESSEL')
        jobtype='manual'
      end
      if(joblisttype == 'cmpltd')
        joblistcheck  = $completedjobs.select{|v| (v.containerno == jobfields[1] && v.code == jobfields[0])}
        if joblistcheck.length == 0
          if($is_completed_jobsrequest == true)
            $completedjobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[14],jobfields[17],jobfields[16],jobfields[15],jobfields[18],"0",jobtype,jobfields[12],jobfields[13]))
          else
            $completedjobs.unshift(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[14],jobfields[17],jobfields[16],jobfields[15],jobfields[18],"0",jobtype,jobfields[12],jobfields[13]))
          end
        end
      elsif(joblisttype == 'out_of_list')
        out_of_list_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobfields[17],'AFT',jobfields[16],jobfields[19],jobfields[18],jobtype))
      else
        $resp_qc_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobfields[17],'AFT',jobfields[16],jobfields[19],jobfields[18],jobtype))
      end
    end
    if($is_completed_jobsrequest == true)
      $is_completed_jobsrequest == false
    end
    if(joblisttype == 'cmpltd')
      return $completedjobs
    elsif(joblisttype == 'out_of_list')
      return out_of_list_jobs
    else
      return $resp_qc_jobs
    end
  end

  # processing PLC job completed move
  def processjobdone(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    to_location = resp_fields[4].split("|")
    containerlist = ""
    movekind = ""
    $plc_job_list_confirm = ($resp_qc_jobs + $completedjobs).select{|v| (containerarry.include? v.containerno + '^' + v.code) && (v.to_loc = (to_location[containerarry.index(v.containerno+'^'+v.code)] || "") if (v.to_loc != to_location))}
    puts "CONTAINERS TO SHIFT"
    puts $plc_job_list_confirm.inspect()
    cell_location =""
    if($plc_job_list_confirm.length > 0)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty?)
        cell_location = $plc_job_list_confirm.map(&:from_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      containerlist = getcontainerstringfordsch($plc_job_list_confirm)
      movekind = 'DSCH'
    else

      $plc_job_list_confirm = ($resp_qc_jobs + $completedjobs).select{|v| (containerarry.include? v.containerno + '^' + v.code) && (v.to_loc = (to_location[containerarry.index(v.containerno+'^'+v.code)] || "") if (v.to_loc != to_location))}
      puts "CONTAINERS TO SHIFT else"
      puts $plc_job_list_confirm.inspect()
      containerlist = getcontainerstringforload($plc_job_list_confirm)
      alternatecellloc = $plc_job_list_confirm.map(&:alternatecell).join("|")
      if(alternatecellloc.empty?)
        cell_location = $plc_job_list_confirm.map(&:to_loc).join("|")
      else
        cell_location  = alternatecellloc
      end
      movekind = "LOAD"
    end
    res = "PLC_JOB_DONE" + "~" + containerlist + "~" + cell_location + "~" + movekind
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  rescue Exception => ex
    puts "Error in processjobdone"+ex.inspect
  end

  #manual job confirmation
  def processcontainerhandling(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    cell_location =""
    containerarry.each {|cNo|
      resp_qc_job = $resp_qc_jobs.select{|v| v.containerno == cNo && v.code == 'DSCH'}

      if(resp_qc_job.length > 0)
        cell_location = cell_location +"|"+ resp_qc_job.map(&:from_loc).join("|")
      else
        resp_qc_job = $resp_qc_jobs.select{|v| v.containerno == cNo && v.code != 'DSCH'}
        cell_location = cell_location +"|"+resp_qc_job.map(&:to_loc).join("|")
      end
    }

    res = "CONTAINER_HANDLING_TRUE" + "~" +resp_fields[3] + "~" + cell_location
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def processdelayrecording(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3]
    WebView.execute_js('processdelayrecording("'+ res.to_s() + '")')
  end

  def process_freeze_unfreeze_app(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    if(resp_fields[2] == "false")
      WebView.execute_js('freezeUI("'+ res.to_s() + '")')
    else
      WebView.execute_js('unFreezeUI()')
    end

  end

  def processworkstopalert(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    WebView.execute_js('showAlerts("'+ res.to_s() + '")')
  end

  #process to display a alert message
  def processnormalalertmessage(resp)
    resp_fields = resp.to_s.split("~")
    container_number = resp_fields[2]
    puts resp_fields[3].inspect
    puts "Ecxception container"
    if(resp_fields[0]=="9910")
      cList = resp_fields[2].to_s.split("|")
      $completedjobs.each {|v| v.sparcsexception = "Y" if cList.include?(v.containerno + '^' + v.code)}
      $completedjobs.each {|v| v.exception_reason = resp_fields[3] if cList.include?(v.containerno + '^' + v.code)}
      res = "NORMAL_ALERT_MESSAGE"+ "~" + container_number + " : " + resp_fields[3] + "~" + resp_fields[4];
    else
      res = "NORMAL_ALERT_MESSAGE"+ "~" + resp_fields[3] + "~" +resp_fields[5]
    end
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #backreach container move
  def backreachcontainermove(resp)
    resp_fields = resp.to_s.split("~")
    res = resp_fields[3]
    WebView.execute_js('backreachcontainermove("'+ res.to_s() + '")')
  end

  def removingjobs(resp)
    resp_fields = resp.to_s.split("~")
    container =  resp_fields[3]
    containerList = container.split('|')
    if resp_fields[4].to_s == "DELETE"      ########Delete
      containerList.each {|containerNo|
        $resp_qc_jobs.delete_if {|v| (v.containerno ==  containerNo.split("^")[0] && v.code == containerNo.split("^")[1])}
      }
    elsif resp_fields[4].to_s == "TRANSFER"    ########Transfer
      containerList.each {|containerNo|
        cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo.split("^")[0] && v.code == containerNo.split("^")[1])}
        if(cIndex != nil)
          $completedjobs.push($resp_qc_jobs[cIndex])
          $resp_qc_jobs.delete_at(cIndex)
        end
      }
    end
    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  # method for processing plc activation
  def processplcactivedeactive(resp)
    resp_fields = resp.to_s.split("~")
    if( resp_fields[3] == "true")
      res = "PLC_TRUE"
    else
      res = "PLC_FALSE"
    end
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  #Removing Jobs
  def shufflingjobs(containeritvinfo)
    reqparams = containeritvinfo.split('|')
    reqobjs = Array.new
    $resp_qc_jobs.delete_if {|v| reqobjs.push(v) if v.from_loc == reqparams[1]  || v.to_loc == reqparams[1]}
    reqobjs.each do |reqobj|
      $resp_qc_jobs = $resp_qc_jobs.unshift(reqobj)
    end
    return $resp_qc_jobs
  end

  #filter jobs
  def filterjobs(container)
    resp_qc_job = Array.new
    itv_no = Array.new
    if(container=="twin_handling")
      resp_qc_job = $resp_qc_jobs.select{|a| (a.twinpick != -1) && (a.tandempick == -1) && (a.bay%2 == 1)}
    elsif(container=="current_jobs")
      resp_qc_job = $resp_qc_jobs
    elsif(container=="jobs_completed")
      if(!$completed_jobsrequest)
        @udp_req_obj[:msg] = "1~1~1420~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
        resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        if resp.length > 0
          resp_fields = resp.to_s.split("~")
          if(resp_fields[0] == "1421")
            $completed_jobsrequest = true
            $is_completed_jobsrequest = true
            $completedjobs =processjoblist(resp_fields,'cmpltd')
          end
        end
      end
      backreach_dsch_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "DSCH")}.map{|b| b.containerno}
      backreach_load_jobs = $completedjobs.select{|v| (v.containerno.split(" ")[0] == "HATCHCOVER" && v.code == "LOAD")}.map{|b| b.containerno}
      $backreach_load_jobs = backreach_dsch_jobs - backreach_load_jobs
      resp_qc_job = $completedjobs
    elsif(container=="tandem_pick")
      resp_qc_job = $resp_qc_jobs.select{|a| a.tandempick != -1 || ((a.twinpick != -1) && (a.tandempick == -1) && (a.bay%2 == 0))}
    elsif(container=="backreach_jobs")
      resp_qc_job = $completedjobs.select{|a| (a.from_loc == "BACKREACH" || a.to_loc == "VESSEL") || (a.from_loc == "VESSEL" || a.to_loc == "BACKREACH")}
    elsif(container=="promoted_jobs")
      itv_no = $session[:Itv_popup_image].to_s.split("#")[0]
      resp_qc_job  = $resp_qc_jobs.select{|a| ((itv_no.include? a.from_loc) && a.code == "LOAD") || ($promoted_jobs.include? a.containerno) }
    elsif(container=="exception_joblist")
      resp_qc_job = $completedjobs.select{|a| a.sparcsexception == "Y"}
    end
    return resp_qc_job
  end

  def getlistaftrplcjobdone(containerlist)
    compltdjob = Array.new
    twinpick = 1
    tandempick = 0
    containers = containerlist.split('|')
    #$plc_job_list_confirm.each do |current_job|
      #containers.push(current_job.containerno + '^' + current_job.code)
    #end
    containers.each{ |cNo|
      containerList=($resp_qc_jobs.select{|v| (v.refercontainer.include? cNo.split('^')[0]) || (v.containerno==cNo.split('^')[0] && v.code==cNo.split('^')[1])})
      containerList.each {|cList|
        cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno && v.code==cList.code)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        resp_qc_job.refercontainer = ""
        resp_qc_job.twinpick = -1
        resp_qc_job.tandempick = -1
      }
    }
    required_jobs=($resp_qc_jobs.select{|v| (containers.include? v.containerno + '^' + v.code) })
    containerList = Array.new
    required_jobs.each do |single_job|
      containerList.push(single_job.containerno + '^' + single_job.code)
    end
    if (containerList.length == 2 || containerList.length == 4)
      containerList.each {|containerno|
        cIndex = $resp_qc_jobs.index{|v| ((v.containerno+ '^' +v.code)==containerno)}
        resp_qc_job = $resp_qc_jobs[cIndex]
        refer_container = prepareRefContainer(containerList,containerno)
        if(twinpick == 0)
          twinpick=1
        else
          twinpick=0
        end
        resp_qc_job.refercontainer = refer_container
        resp_qc_job.twinpick = twinpick

        if(containerList.length == 4)
          resp_qc_job.tandempick = tandempick
          tandempick = tandempick + 1
        end
      }
    end

    $resp_qc_jobs.delete_if {|v| compltdjob.push(v) if containers.include?(v.containerno+'^'+v.code)}
    puts "COMPLETED JOBS"
    puts compltdjob.inspect()
    compltdjob.reverse_each  {|compjob|
      $completedjobs.unshift(compjob)
    }

    return $resp_qc_jobs
  end

  def getjoblist(to_loc,from_loc, trouble_shoot_damage_clicked, seal_ok, seal_ok_data, current_position, category_info)
    if(!to_loc.empty?)
      containers = ""
      itvno = ""
      compltdjob = Array.new
      @joblist = $job_list_confirm
      if($job_list_confirm.length > 0)
        containers = $job_list_confirm.map(&:containerno).join("|")
        from_loc = $job_list_confirm.map(&:from_loc).join("|")
        if(@joblist[0].code == "DSCH" || (@joblist[0].code == "LOAD" && trouble_shoot_damage_clicked == "false" && seal_ok == "false"))
          #      seal_ok_data = $job_list_confirm.map(&:seal_ok_data).join("|")
          confirm_success = qc_container_move(containers,from_loc,to_loc, $job_list_confirm[0].code, seal_ok, seal_ok_data,current_position, category_info)
          if(confirm_success == true)
            to_locns = to_loc.split("|")
            container_positions = current_position.split("|")
            index = to_locns.length
            $job_list_confirm.reverse_each do |joblist|
              index = index - 1
              joblist.to_loc = to_locns[index]
              joblist.container_position = container_positions[index]
              joblist.exception_reason = ""
              $completedjobs.delete_if{|v| (v.containerno==joblist.containerno && v.code == joblist.code)}
              $completedjobs.unshift(joblist)
              $resp_qc_jobs.delete_if {|v| (v.containerno ==  joblist.containerno && v.code == joblist.code)}
            end
          end
        end
      end
      $job_list_confirm = $job_list_confirm.clear
      $sleeptime  = 0
    end
    return $resp_qc_jobs
  end

  # method to update job list
  def updatejoblist(resp)
    begin
      resp_fields = resp.to_s.split("~")
      resp_qc_list = resp_fields[2].to_s.split('|')
      twinpick = 1
      tandempick = -1
      resp_qc_list.each do |check_list_item|
        if (tandempick == 3)
          tandempick = -1
        end
        jobfields = check_list_item.to_s.split('^')
        jobindex = $resp_qc_jobs.index{|v| (v.containerno==jobfields[1] && v.code==jobfields[0])}
        if(jobfields[8] != nil && !jobfields[8].empty?)
          ref_container_list = jobfields[8].to_s.split('#')
          if(ref_container_list.length > 1)
            tandempick = tandempick + 1
          end
          if(twinpick == 0)
            twinpick=1
          else
            twinpick=0
          end
        end

        if(jobindex == nil)
          $resp_qc_jobs.push(Joblist.new(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobfields[17],'AFT',jobfields[16],jobfields[19],jobfields[18]))
        else
          updatedjob = $resp_qc_jobs[jobindex]
          updatedjob.updatevalues(jobfields[0],jobfields[1],jobfields[2],jobfields[3],jobfields[4],jobfields[5],jobfields[6],jobfields[7],jobfields[8],jobfields[9],twinpick,tandempick,jobfields[10],jobfields[11],jobfields[15],jobfields[17],'AFT',jobfields[16],jobfields[19],jobfields[18])
          $resp_qc_jobs[jobindex] = updatedjob
        end
      end
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    rescue Exception => ex
      puts("uncaught #{ex} exception while handling : #{ex.message}")
    end
  end

  def addManualJobs(resp)
    resp_fields = resp.to_s.split("~")
    containerno = resp_fields[2]
    movetype = resp_fields[3]
    from_loc = resp_fields[4]
    to_loc = resp_fields[5]

    if(containerno.include? 'HATCHCOVER LOAD')
      $completedjobs.push(Joblist.new(movetype,containerno,'','','',from_loc,to_loc,'','','','','','','','true','false','AFT','false',"manual"))
    else
      $completedjobs.unshift(Joblist.new(movetype,containerno,'','','',from_loc,to_loc,'','','','','','','','true','false','AFT','false',"manual"))
    end
    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def deleteManualJobs(resp)
    resp_fields = resp.to_s.split("~")
    cntrList = resp_fields[2].split("|")
    cntrList.each {|containerNo|
      cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
      if(cIndex != nil)
        $resp_qc_jobs.delete_at(cIndex)
      end
    }
    res = "REFRESH_JOBS"
    WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
  end

  def updateTwinTandemSplitJobs(resp)
    resp_fields = resp.to_s.split("~")
    jobType = resp_fields[2].to_s
    cntrList = resp_fields[3].split("|")
    containerList=($resp_qc_jobs.select{|v|  cntrList.include? v.containerno })

    if(cntrList.length == containerList.length)
      if(jobType.include? "SPLIT")
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        twinpick = 1
        tandempick = 0
        puts "inside else twintandem"
        targetIndex=""
        cntrList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(cntrList,containerNo)
          if(twinpick == 0)
            puts "if(twinpick == 0)"
            twinpick=1
          else
            puts "if(twinpick == 1)"
            twinpick=0
          end
          resp_qc_job.refercontainer = refercontainer
          resp_qc_job.twinpick = twinpick
          if(jobType == "TANDEM" && cntrList.length != 2)
            puts "Tandem" + tandempick.inspect
            resp_qc_job.tandempick = tandempick
            tandempick = tandempick + 1
          end
          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }
      end
      res = "REFRESH_JOBS"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    end

  end

  #method to prepare string for updating the bay view in load case
  def getcontainerstringforload(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      refer = false
      hazardous = false
      oog =false
      rob=false
      country = ""
      colorcode = ""
      if([1,3,4,5,6].include?(job.remarks.to_i))
        refer = true
      end
      if([1,2].include?(job.remarks.to_i))
        hazardous = true
      end
      if([7,8,9,10,11,12].include?(job.remarks.to_i))
        oog = true
      end
      if([13].include?(job.remarks.to_i))
        damage = true
      end
      if([14].include?(job.remarks.to_i))
        damage_low = true
      end
      if(!job.country.nil?)
        country =job.country
      end
      if(!job.colorcode.nil?)
        colorcode = job.colorcode
      end
      contrstring = "1^"+job.containerno+"^"+refer.to_s+"^"+hazardous.to_s+"^"+oog.to_s+"^"+rob.to_s+"^"+country+"^"+colorcode
      contrloadstrings.push(contrstring)
      if(job.bay%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  #method to prepare string for updating the bay view in load case
  def getcontainerstringfordsch(job_list_confirm)
    contrloadstrings = Array.new
    job_list_confirm.each do |job|
      contrstring = job.containerno + '^' + job.code
      contrloadstrings.push(contrstring)
      if(job.bay%2 ==0)
        contrloadstrings.push(contrstring)
      end
    end
    return contrloadstrings.join("|")
  end

  def get_catagory(cat_no)
    cat_no_to_icon_map = {
      "T" => "tranship",
      "I" => "import",
      "E" => "export",
      "R" => "restow",
      "S1" => "restow",
      "S2" => "restow",
      "B" => "restow"
    }
    return cat_no_to_icon_map.fetch(cat_no, nil)
  end

  def get_table_remarks_icon(remarks_no)
    remarks_no_to_icon_map = {
      "1" => "hazardous_reefer",
      "2" => "hazardous",
      "3" => "reefer_1",
      "4" => "reefer_2",
      "5" => "reefer_3",
      "6" => "reefer_4",
      "7" => "over-dimentional_1",
      "8" => "over-dimentional_2",
      "9" => "over-dimentional_3",
      "10" => "over-dimentional_4",
      "11" => "over-dimentional_5",
      "12" => "over-dimentional_6",
      "13" => "damage",
      "14" => "damage_low"
    }
    return remarks_no_to_icon_map.fetch(remarks_no, nil)
  end

  def  getColumnName(sortBy)
    column_name = {
      "Container" => "containerno",
      "ISO" => "iso",
      "POD." => "reefer_1",
      "WT." => "wght",
      "From" => "from_loc",
      "To" => "to_loc",
      "St" => "st",
      "Cat" => "cat",
      "Flag" => "over-dimentional_3"
    }
    return column_name.fetch(sortBy, nil)
  end

  def get_request_string(request_type_id, request_params)
    request = "1~1~#{request_type_id}~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"

    request_params.each do |param|
      request += "~#{param}"
    end

    return request
  end

  def prepareRefContainer(addContainerList,containerNo)
    refercontainer=Array.new
    #refercontainer=(addContainerList.select {|cNo|  cNo !=containerNo })
    addContainerList.each do |cNo|
      if(cNo !=containerNo)
        refercontainer.push(cNo.split('^')[0])
      end
    end
    refer_container_string = refercontainer.join("#")
    return refer_container_string
  end

  #clearing the session on logout or exit
  def clearsession()
    $session[:checkForMsg].clear
    $session[:Itv_popup_image].clear
    $resp_qc_jobs.clear
    $completedjobs.clear
    $job_list_confirm.clear
    $last_rendered_cell = ""
    $userid=""
  end

  def search_itv_pool(resp)
    if resp.length > 0
      $display_itv_pow = Array.new
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2501")
        display_itv = resp_fields[2].to_s.split("|")
        display_itv.each do |pow|
          $display_itv_pow.push(pow.to_s.split("^",2)[0])
        end
      end
    end
  end

end