require 'timeout'

module SocketHelper
  #Sending and Receiving request to and from UDP Server
  def get_udp_socket()
    if $udp_socket == nil
      $udp_socket = UDPSocket.new
      $udp_socket.setsockopt(Socket::SOL_SOCKET,Socket::SO_REUSEADDR, 1)
      $udp_socket.bind($local_com_ip, Rho::RhoConfig.local_com_port)
      $udp_socket.do_not_reverse_lookup = true
    end
    return $udp_socket
  end

  # function to close the udp socket
  def close_udp_socket()
    if $udp_socket == nil
      return
    end
    $udp_socket.flush()
    $udp_socket.close()
  end

  # function for opening poll socket
  def get_socket()
    if $poll_socket == nil
      begin
        $poll_socket = UDPSocket.new
        $poll_socket .setsockopt(Socket::SOL_SOCKET,Socket::SO_REUSEADDR, 1)
        $poll_socket.bind($local_com_ip, Rho::RhoConfig.server_polling_port)
        $poll_socket.do_not_reverse_lookup = true
      rescue Exception => e
        puts("uncaught #{e} exception while handling : #{e.message}")
      end
    end
    return $poll_socket
  end

  #closing poll socket
  def close_socket()
    $poll_socket.flush()
    $poll_socket.close()
  end

  #function to send request udp
  def send_recieve_request_udp(req_param, num_of_expected_responses)
    resp=""
    size = Rho::RhoConfig.buffersize.to_i
    socket = get_udp_socket()
    puts req_param.inspect
    socketCommSync   = Mutex.new
    msg = "1~1~"+req_param[:msg]
    socketCommSync.synchronize{
      socket.send msg, req_param[:flag], req_param[:url], req_param[:port]
      for counter in 1..num_of_expected_responses
        begin
          resp = socket.recvfrom(size)
        rescue Exception => e
          puts("uncaught #{e} exception while handling connection: #{e.message}")
        end
      end
    }
    resp_message = resp
    if(resp.length > 0)
      resp_message = resp[0].split("~",3)
    end
    return resp_message[2]
  end

  #function to recev message on the poll socket
  def recv_response(socket = "", num_of_expected_responses = 1, timeout_secs = 0)
    resp = ""
    size = Rho::RhoConfig.buffersize.to_i
    socket = get_socket()
    for counter in 1..num_of_expected_responses
      begin
        Timeout.timeout(timeout_secs) do
          resp = socket.recv(size)
          puts "=========================Polling Port Response========================="
          puts "Recieved Output From Server At Polling Port:-"+ resp.inspect
        end
      rescue Exception => e
        if(e.message.to_s() != "execution expired")
          puts("uncaught #{e} exception while handling connection: #{e.message}")
        end
      rescue Timeout::Error => te
        puts("timeout error")
      end
    end
    messageexit = true
    if(resp.length > 0)
      (currentPacket, totalPacketCount, res_msg_id, res_event_id,packetData) = splitToComponentsAndValidate(resp)
      resp = res_msg_id + "~"+ res_event_id + "~" + packetData
      if(currentPacket == totalPacketCount)
        messageexit = false
      end
      while(messageexit)
        begin
          # This is a blocking receive call and times out after 1 sec.
          # No seperate sleep is required to keep this thread from grabbing high priority.
          output = socket.recvfrom(size)
        end
        (currentPacket, totalPacketCount, res_msg_id, res_event_id,packetData) = splitToComponentsAndValidate(output[0])
        resp += res_msg_id + "~"+ res_event_id + "~" + packetData
        if(currentPacket == totalPacketCount)
          messageexit = false
        end
      end
    end
    return resp
  end

  #Sending acknowledgment to Server
  def send_ack(ack_param)
    udp_socket_ack = UDPSocket.new
    udp_socket_ack.setsockopt(Socket::SOL_SOCKET,Socket::SO_REUSEADDR, 1)
    udp_socket_ack.bind($local_com_ip, Rho::RhoConfig.local_com_ackport)
    udp_socket_ack.connect(Rho::RhoConfig.com_server_ip, Rho::RhoConfig.com_server_ackport)
    udp_socket_ack.send(ack_param[:ack],0)
    udp_socket_ack.close
    return true
  end

  #default data required for Server
  def initialize
    @udp_req_obj = {
      :msg => "",
      :url => Rho::RhoConfig.com_server_ip,
      :port => Rho::RhoConfig.com_server_port,
      :flag => 0
    }
    @udp_ack_obj = {
      :ack => "",
      :url => Rho::RhoConfig.com_server_ip,
      :port => Rho::RhoConfig.com_server_ackport,
      :flag => 0
    }
  end

  #method to send ack to server
  def send_resp_rcvd_ack(res_msg_id,res_event_id,currentPacket=1, totalPacketCount=1)
    resp_string = "#{currentPacket}~#{totalPacketCount}~#{res_msg_id}~#{res_event_id}"
    @udp_ack_obj[:ack] = "RECEIVED~#{resp_string}"
    puts "*************************Response Ack To Server*************************"
    puts "Sent Ack To Server:-"+resp_string.inspect
    return send_ack(@udp_ack_obj)
  end

  #method to create event id
  def geteventid(reqno=1)
    org_string = "device2" + Time.now.strftime("%d%m%Y%H%M%S%L") + reqno.to_s()
    encoded_string = org_string.hash
    return encoded_string
  end

  #method for splitting the packets
  def splitToComponentsAndValidate(packet)
    raise RuntimeError("Received packet is empty.") if packet.nil?() or packet.empty?()
    (currentPacket, totalPacketCount, res_msg_id,resp_event_id,packetData) = packet.split("~", 5)
    currentPacket    = currentPacket.to_i()
    totalPacketCount = totalPacketCount.to_i()
    #p "#{currentPacket}, #{totalPacketCount}, #{eventType}, #{eventId}, #{packetData}"
    # Expecting current packet number is always a positive integer and less than total packet count
    raise RuntimeError, "Current packet number (%{currPktCnt}) cannot "\
         "be greater than Total number of packets (%{totPktCnt}) in the message" % {
      :currPktCnt => currentPacket,
      :totPktCnt  => totalPacketCount
    } if currentPacket > totalPacketCount

    raise RuntimeError, "Curernt packet number(%{currPktCnt}) should be a positive integer." % {
      :currPktCnt => currentPacket
    } if currentPacket <= 0
    send_resp_rcvd_ack(res_msg_id,resp_event_id,currentPacket,totalPacketCount)
    return [currentPacket, totalPacketCount,res_msg_id,resp_event_id, packetData]
  end

  #method for sending buffered request
  def send_recieve_bufferedrequest_udp(req_param,no_of_responses)
    resp=""
    begin
      currentTrail = 1
      socket = get_udp_socket()
      size = Rho::RhoConfig.buffersize.to_i
      time = Rho::RhoConfig.timeout.to_i
      eventType = ""
      messageexit = false
      $no_of_wait_trails = 0
      if(no_of_responses >1)
        messageexit = true
      end
      hasackreceived = false
      reqparams = req_param[:msg].split("~",5)
      req_msg_id = reqparams[2]
      req_eventid =   reqparams[3]
      while currentTrail <= 3 do
        socket.send req_param[:msg], req_param[:flag], req_param[:url], req_param[:port]
        puts "*************************Request*************************"
        puts "Sent Request To Server:-"+req_param[:msg].inspect
        WebView.execute_js("maskScreen()")
        begin
          $no_of_wait_trails = 1
          #get the acknowledgement
          while($no_of_wait_trails < 4)
            socks = IO.select([socket],nil,nil,time)
            if(socks)
              for inp in socks[0]
                ack = socket.recvfrom(size)
                puts "*************************Acknowledgment*************************"
                puts "Recieved Ack Form Server:-"+ack.inspect
                if ack
                  ack_event_id = ack[0].split("~")[3]
                  if(ack_event_id == req_eventid)
                    $no_of_wait_trails = 5
                  else
                    $no_of_wait_trails += 1
                  end
                end
              end
            else
              $no_of_wait_trails += 1
            end
          end
        end
        if ack && req_eventid == ack_event_id
          currentTrail = 4
          hasackreceived = true
        else
          currentTrail += 1
        end
      end
      if(messageexit== false)
        WebView.execute_js("unmaskScreen()")
        return ack
      end
      if(hasackreceived)
        resp = getresponse(socket,size,req_eventid,req_msg_id)
      else
        WebView.execute_js("unmaskScreen()")
        raise "Server Not Responding"
      end
      WebView.execute_js("unmaskScreen()")
      return resp
    end
    
    
    rescue Exception => ex
      puts ex.to_s().inspect
      WebView.execute_js("unmaskScreen()")
  end

  def getresponse(socket,size,req_eventid,req_msg_id)
    resp = ""
    time = Rho::RhoConfig.timeout.to_i
    bProcess = true
    $no_of_wait_trails = 1
    while(bProcess && $no_of_wait_trails < 4)
      begin
        # This is a blocking receive call and times out after specified time
        # No seperate sleep is required to keep this thread from grabbing high priority.
        socks = IO.select([socket],nil,nil,time)
        if(socks)
          for inp in socks[0]
            output = socket.recvfrom(size)
            puts "*************************Response*************************"
            puts "Recieved Output From Server:-"+ output.inspect
          end
        else
          output=nil
          $no_of_wait_trails += 1
        end
      end
      if(output)
        (currentPacket, totalPacketCount,res_msg_id, res_event_id,packetData) = splitToComponentsAndValidate(output[0])
        if(($msg_hash[req_msg_id.to_i].include?res_msg_id) && req_eventid == res_event_id)
          if(packetData != nil)
            resp += res_msg_id + "~"+ res_event_id + "~" + packetData
          end
          if(currentPacket == totalPacketCount)
            bProcess = false
          end
        else
          $no_of_wait_trails += 1
        end
      end
    end
    if($no_of_wait_trails >= 4)
      raise "Server Not Responding"
    end
    return resp
  end

end