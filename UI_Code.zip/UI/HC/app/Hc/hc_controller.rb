class HcController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include HcHelper
  def test_for_ajax
    render :action => "test_for_ajax",:layout => false,:use_layout_on_ajax => false
  end

  def getContainerEnqScreen
    @containerId = @params['containerNumber']
    render :action => '../ContainerEnquiry/container_enquiry'
  end

  def display_jqGrid
    render :action => 'jqgrid'
  end

  def getcontainerDetails
    containerNumber = @params['containerNumber']

    @udp_req_obj[:msg] = "1~1~1610~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerNumber}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_msg_id = resp.to_s.split("~")[0]
      if("1611" == resp_msg_id)
        render :string => resp
      elsif("1612" == resp_msg_id)
        render :string => "empty"
      else
        render :string => "error"
      end
    else
      render :string => "error"
    end
  end
  
  #itv pool request
  def search_itv
    @udp_req_obj[:msg] = "1~1~2500~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"   #event type can be modify in future
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    $display_itv_pow = Array.new
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2501")
        display_itv = resp_fields[2].to_s.split("|")
        display_itv.each do |pow|
          $display_itv_pow.push(pow.to_s.split("^",2)[0])
        end
      end
    end
    return $display_itv_pow
  end

  # Damage Recording
  def submitData
    @container= @params['container']
    @udp_req_obj[:msg] = "1~1~9000~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['container_id']}~#{@params['damage_data']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length>0
      render :string=>"Success"
    else
      render :string=>"failure"
    end
  end

  def container_handling
    $job_list_confirm.clear
    cList = @params['container'].split("|")
    trouble_shoot_damage_clicked = @params["troubleDamageClicked"]
    if(@params['manual_confirm']=='true')
      $job_list_confirm  = $resp_qc_jobs.select{|v| (v.containerno == @params['container'] && v.code == @params['movekind']) || (v.refercontainer.include? @params['container'])}
      if $job_list_confirm.empty?
        $job_list_confirm = $completedjobs.select{|v| (v.containerno == @params['container'] && v.code == @params['movekind']) || (v.refercontainer.include? @params['container'])}
      end
    else
      $job_list_confirm  = $resp_qc_jobs.select{|v| cList.include? v.containerno }
      if $job_list_confirm.empty?
        $job_list_confirm = $completedjobs.select{|v| cList.include? v.containerno}
      end
    end
    @joblist = $job_list_confirm
    @exception_reason = $completedjobs.select{|v| v.exception_reason if cList.include? v.containerno}
    if(@joblist.empty?)
      @exception_reason = "JOB NOT AVAILABLE"
      res = "CANCEL_JOB"
      WebView.execute_js('shufflejobs("'+ res.to_s() + '")')
    else
      if(@joblist[0].code == "LOAD")
        @containers = getcontainerstringforload(@joblist)
      else
        @containers = getcontainerstringfordsch(@joblist)
      end
    end
    @itvlist = $session[:Itv_popup_image]
    if(trouble_shoot_damage_clicked == "false")
      if($display_itv_pow.empty?)
        if(@params['manual_confirm'] == 'true')
          $display_itv_pow = search_itv()
        end
      end
    end

    render :action => 'container_handling'
  end

  # Delay Recording
  def delayrecordingreason
    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def saveData
    @container= @params['container']
    @udp_req_obj[:msg] = "1~1~2502~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['container_id']}~#{@params['iso_data']}~#{@params['weight_data']}~~~~~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length>0
      render :string=>"Success"
    else
      render :string=>"failure"
    end
  end

  #Adding manual created jobs through Plc
  def HatchcoverMancageBreakbulk_Request()
    #    @resp_qc_job,containerid,movetype,fromloc,toloc= addjobs(@params['request_type'], @params['mode'])
    containerid = @params['request_type']
    movetype = @params['mode']
    filter = @params['filter']
    if (movetype == "DSCH")
      fromloc='VESSEL'
      toloc = 'BACKREACH'
    else
      fromloc='BACKREACH'
      toloc = 'VESSEL'
    end
    @udp_req_obj[:msg] = "1~1~1800~#{geteventid(1)}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerid}~#{movetype}~#{fromloc}~#{toloc}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if(resp.length > 0)
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1802")
        containerno = resp_fields[2]
      end
    end
    containerid = containerno
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid(2)}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerid}~#{fromloc}~#{toloc}~#{movetype}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[0] == "1603")
      if(resp_fields[3] == "true")
        $completedjobs.unshift(Joblist.new(movetype,containerno,'','','',fromloc,toloc,'','','','','','','','true','false','AFT','false',"manual"))
      else
        WebView.execute_js('showAlerts("'+ resp_fields[4] + '")')
      end
    else
      WebView.execute_js('showAlerts("Server responded with invalid event type"'+ resp_fields[0]+ '")')
    end

    #    cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerid)}
    #    if(cIndex != nil)
    #      $completedjobs.unshift($resp_qc_jobs[cIndex])
    #      $resp_qc_jobs.delete_at(cIndex)
    #    end
    #@resp_qc_job = $resp_qc_jobs

    @resp_qc_job = filterjobs(filter)
    render :action => 'joblist'
  end

  #adding backreach jobs to joblist
  def addjobs(request_type, mode="")
    reqparams = request_type
    containerno=""
    movetype = mode || "DSCH"
    from_loc='BACKREACH'
    to_loc = 'VESSEL'
    if(request_type=='MANCAGE')
      mankagejobs = ($resp_qc_jobs + $completedjobs).select{|v| (v.containerno.include? 'MANCAGE DSCH') || (v.containerno.include? 'MANCAGE LOAD')}
      mankage_dsch_index = mankagejobs.select{|v| v.code == "DSCH"}.length
      mankage_load_index=mankagejobs.select{|v| v.code == "LOAD"}.length
      mankageindex = 0
      mankageindex = mode == "DSCH" ? (mankage_dsch_index + 1).to_s : (mankage_load_index + 1).to_s
      containerno = 'MANCAGE '+movetype+" "+mankageindex.to_s()
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc='BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','',"manual"))
      end
    elsif(request_type=='HATCHCOVER')
      hatchcoverjobs = ($resp_qc_jobs + $completedjobs).select{|v| (v.containerno.include? 'HATCHCOVER DSCH') || (v.containerno.include? 'HATCHCOVER LOAD')}
      hatchcoverindex=1
      if(!hatchcoverjobs.empty?)
        hatchcoverelems =Array.new
        hatchcoverjobs.each do |hatchcoverjob|
          hatchcoverelem = hatchcoverjob.containerno.delete "HATCHCOVER DSCH LOAD"
          hatchcoverelems.push(hatchcoverelem.strip.to_i())
        end
        hatchcoverelems = hatchcoverelems.sort{|x,y| y <=> x}
        hatchcover_dsch_index = hatchcoverjobs.select{|v| v.code == "DSCH"}.length
        hatchcover_load_index = hatchcoverjobs.select{|v| v.code == "LOAD"}.length
        hatchcoverindex = 0
        hatchcoverindex = mode == "DSCH" ? (hatchcover_dsch_index+ 1).to_s : (hatchcover_load_index + 1).to_s
      end
      containerno = 'HATCHCOVER '+movetype+" "+hatchcoverindex.to_s()
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc = 'BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','',"manual"))
      end
    else
      breakbulkjobs = ($resp_qc_jobs + $completedjobs).select{|v| (v.containerno.include? 'BREAKBULK DSCH') || (v.containerno.include? 'BREAKBULK LOAD')}
      breakbulk_dsch_index = breakbulkjobs.select{|v| v.code == "DSCH"}.length
      breakbulk_load_index = breakbulkjobs.select{|v| v.code == "LOAD"}.length
      breakbulkindex = 0
      breakbulkindex = mode == "DSCH" ? (breakbulk_dsch_index + 1).to_s : (breakbulk_load_index + 1).to_s
      containerno = 'BREAKBULK '+movetype+breakbulkindex.to_s()
      if(movetype == 'DSCH')
        from_loc = 'VESSEL'
        to_loc = 'BACKREACH'
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','VESSEL','BACKREACH','','','','','','','','Y',"manual"))
      else
        $resp_qc_jobs.unshift(Joblist.new(movetype,containerno,'','','','BACKREACH','VESSEL','','','','','','','','Y',"manual"))
      end
    end
    return $resp_qc_jobs,containerno,movetype,from_loc,to_loc
  end

  def updateContainerSealInfo
    sealInfo = @params['sealInfo']
    selectedJob  = $resp_qc_jobs.select{|v| v.containerno == @params['container']}
    if selectedJob.empty?
      selectedJob = $completedjobs.select{|v| v.containerno == @params['container']}
    end

    if selectedJob.empty?
    else
      selectedJob[0].seal_ok = sealInfo;
    end
  end

  def update_container_door_info
    door_info = @params['doorInfo']
    selected_job  = $resp_qc_jobs.select{|v| v.containerno == @params['container']}
    if selected_job.empty?
      selected_job = $completedjobs.select{|v| v.containerno == @params['container']}
    end

    if selected_job.empty?
    else
      selected_job[0].door_direction = door_info;
    end
  end

  def mergeJobs
    addContainerList = @params['addContainerList']
    reqType = @params['reqType']
    is_tandem = @params["is_tandem"]
    movekind=@params["movekind"]
    if(reqType != "Cancel")
      twinpick = 1
      tandempick = 0
      targetIndex=""
      if(reqType == "Split")

        containerList=($resp_qc_jobs.select{|v| ( (v.refercontainer.include? addContainerList[0].to_s) || v.containerno==addContainerList[0] )})
        containerList.each {|cList|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==cList.containerno)}
          resp_qc_job = $resp_qc_jobs[cIndex]
          resp_qc_job.refercontainer = ""
          resp_qc_job.twinpick = -1
          resp_qc_job.tandempick = -1
        }
      else
        addContainerList = ordercontainerlist(addContainerList)
        addContainerList.each {|containerNo|
          cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
          if targetIndex == ""
            targetIndex = cIndex
          end
          resp_qc_job = $resp_qc_jobs[cIndex]
          refercontainer=prepareRefContainer(addContainerList,containerNo)
          if(twinpick == 0)
            twinpick=1
          else
            twinpick=0
          end
          resp_qc_job.refercontainer = refercontainer
          resp_qc_job.twinpick = twinpick

          if(reqType == "Tandem")
            resp_qc_job.tandempick = tandempick
            tandempick = tandempick + 1
          end
          if cIndex > targetIndex
            targetIndex=targetIndex+1
          end
          $resp_qc_jobs.insert(targetIndex, $resp_qc_jobs.delete_at(cIndex))
        }
      end
      if(is_tandem == "40ft")
        reqType = "Tandem"
      elsif (is_tandem == "TANDEM_SPLIT")
        reqType = "TANDEM_SPLIT"
      else
        reqType = @params["reqType"]
      end

      @udp_req_obj[:msg] = "1~1~1407~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{reqType.upcase}~#{addContainerList.join("|")}~#{movekind}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    @resp_qc_job = filterjobs(@params["filterValue"])
    twin_tandem_pairing
    render :action => 'joblist'
  end

  def create_hash_of_delays(manual_delay_data)

    manual_delay_data = '{
                          "delay_reasons": [
                            { "code": "OPB3" , "desc": "TeaBreak"},
                            { "code": "OPB2" , "desc": "LunchBreak"}
                          ],
                          "prev_delays": [
                            { "code": "admin app issue", "desc": "1234", "start_date": "04/11/2016 13:24", "equipment_id": "QC74", "code_id": "8"},
                            { "code": "UI app issue", "desc": "3456", "start_date": "05/12/2016 13:24", "equipment_id": "QC68", "code_id": "9"}
                          ]

                        }'

    return manual_delay_data;

  end

  def get_manual_delay_data
    render :action => :manual_delay_record
  end

  def geDelayRecordingReasonsManual
    @udp_req_obj[:msg] = "1~1~2400~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("2401" == resp_msg_id)
        delay_data = resp_fields[3] + '~' + resp_fields[4]
        render :string => delay_data
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #delay recording send request
  def geDelayRecordingReasons
    @udp_req_obj[:msg] = "1~1~2400~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("2401" == resp_msg_id)
        @delayReasonList = resp_fields[3].to_s.split('|')
        @prevDelays = resp_fields[4].to_s.split('|')
        render :action => :recorddelay
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #send delay reasons to server
  def sendDelayRecordingData
    delay_reason_data = @params['delayReason_data']
    status = @params['status']
    @udp_req_obj[:msg] = "1~1~2402~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{delay_reason_data}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("2403" == resp_msg_id)
        @manDelaySuccess = resp_fields[2].to_s()
        if(@manDelaySuccess == "Y")
          render :string => "Success"
        else

          delayErrors = resp_fields[3].to_s().split('|')
          delayErrorMessage = ""
          delayErrors.each do |delayError|
            delayErrorMessage += delayError.split('^')[0] + " - " + delayError.split('^')[2] + ", "
          end
          WebView.execute_js('showAlerts("'+ delayErrorMessage.to_s() + '")')
          render :string => "Error"
        end
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  def deleteJobs
    addContainerList = @params['addContainerList']
    check_for_hatch_cover = addContainerList[0].split("HATCHCOVER")
    if(check_for_hatch_cover.length > 1)
      addContainerList.push("HATCHCOVER" + check_for_hatch_cover[1])
      check_load_or_dsch = check_for_hatch_cover[1].split("DSCH")
      if check_load_or_dsch.length > 1
        addContainerList.push("HATCHCOVER " + "LOAD" + check_load_or_dsch[1])
      else
        addContainerList.push("HATCHCOVER " + "DSCH" + check_load_or_dsch[0].split("LOAD")[1])
      end
    end
    addContainerList = addContainerList.uniq
    @udp_req_obj[:msg] = "1~1~1801~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{addContainerList.join("|")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    addContainerList.each {|containerNo|
      cIndex = $resp_qc_jobs.index{|v| (v.containerno==containerNo)}
      if(cIndex != nil)
        $resp_qc_jobs.delete_at(cIndex)
      end
    }
    @resp_qc_job = filterjobs(@params["filterValue"])
    render :action => 'joblist'
  end

  #back reach move update to client
  def containerbackreachmove
    @backreachcontainermessage = @params['backreachcontainermessage']
    render :action => :backreach_jobs
  end

  def getcompletedjobs
    @udp_req_obj[:msg] = "1~1~1420~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      if(resp_fields[0] == "1421")
        $completed_jobsrequest = true
        $is_completed_jobsrequest = true
        $completedjobs = processjoblist(resp_fields,'cmpltd')
        twin_tandem_pairing
      end
    end
  end

  #method for processing backreach container move
  def backreachcontainermove
    backcontainerno = @params['containernumber_data']
    backfromlocation = @params['fromlocation_data']
    backtolocation = @params['tolocation_data']
    backcontainerno = backcontainerno.to_s.upcase
    cIndex = $resp_qc_jobs.index{|v| (v.containerno==backcontainerno)}
    @udp_req_obj[:msg] = "1~1~1600~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['containernumber_data']}~#{@params['fromlocation_data']}~#{@params['tolocation_data']}~#{@params['type']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if (@params['type'] == "DSCH")
      if(cIndex != nil)
        resp_qc_job = $resp_qc_jobs[cIndex]
        resp_qc_job.from_loc = backfromlocation
        resp_qc_job.to_loc = backtolocation
      else
        $resp_qc_jobs.unshift(Joblist.new('DSCH',backcontainerno,'','','',backfromlocation,backtolocation,'','','','','','','','Y',"plc",''))
      end
    else
      if(cIndex != nil)
        resp_qc_job = $resp_qc_jobs[cIndex]
        resp_qc_job.from_loc = backtolocation
        resp_qc_job.to_loc = backfromlocation
      else
        $resp_qc_jobs.unshift(Joblist.new('LOAD',backcontainerno,'','','',backfromlocation,backtolocation,'','','','','','','','Y',"plc",''))
      end
    end
    new_c_index = $resp_qc_jobs.index{|v| (v.containerno==backcontainerno)}
    $completedjobs.unshift($resp_qc_jobs[new_c_index])
    $resp_qc_jobs.delete_at(new_c_index)

    @resp_qc_job = $resp_qc_jobs
    render :action => 'joblist'
  end

  def getOrphanContainerView
     @isoCodesList = @params['isoCodes']
     @isoCodes = @isoCodesList.split("|");
    render :action => 'orphancontainer_creation'
  end

  def OrphanContainerHandling
    @udp_req_obj[:msg] = "1~1~2102~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['containernumber_data']}~#{@params['iso_data']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    resp_status = ""
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2103")
        if(resp_fields[2] == "true") 
          render :string=> "true"
        else
          WebView.execute_js('showAlerts("'+ resp_fields[3].to_s() + '")')
          render :string=> "false"
        end
      end
    end
    
  end

  def OrphanContainerCreation
    containerNo = @params['containerNo']
    $resp_qc_jobs.unshift(Joblist.new('DSCH',containerNo,'','','','','','','','','','','','','Y',"manual"))
    @resp_qc_job = filterjobs(@params['filter'])
    render :action => 'joblist'
  end

  # Delay Recording
  def delay_recording
    @delayrecordingmess = @params['delayrecordingmessage']
    @delayrecordingmessage = @delayrecordingmess.to_s.split('|')
    render :action => :delay_recording
  end

  #request for delay recording reason
  def delayrecordingreason
    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def send_swap_request
    itvNo = @params['itvNo']
    containerno = @params['containerno']
    @udp_req_obj[:msg] = "1~1~2206~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{itvNo}~#{containerno}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def sortJoblist
    sortBy = @params['sortBy']
    sortBy = getColumnName(sortBy)
    $resp_qc_jobs.sort_by { |obj| obj.containerno.downcase }
  end

  def getTroubleShootView
    @movekind = @params["movekind"]
    @udp_req_obj[:msg] = "1~1~2200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @containers = @params["containers"].split("|")
    @itvs = @params["itvs"].split("|")
    @ground= @params["ground"].split("|")
    @joblist = $job_list_confirm
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2201")
        @troubleshootarea = resp_fields[2].to_s.split('|')
        @troubleshootcodedesc = resp_fields[3].to_s.split('|')
        render :action => :troubleshoot
      else
        render :string => "false"
      end
    end
  end

  def sendSealTroubleShootData
    @udp_req_obj[:msg] = "1~1~2207~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['containerNumber']}~#{@params['itvNumber']}~#{@params['troubleshootArea']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def getSealOffView
    @udp_req_obj[:msg] = "1~1~2200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @joblist = $job_list_confirm
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2201")
        @trouble_shoot_areas = resp_fields[2].to_s.split('|')
        render :action => :seal_ok
      else
        render :string => "false"
      end
    end

  end

  def sendTroubleShootReq
    #    selected_containers = @params['selected_containers']
    #    selected_to_location = @params['selected_to_location']
    #    troubleshoot_area = @params['troubleshoot_area']
    trb_sht_cntrs = @params["tr_sht_details"]
    if(trb_sht_cntrs != "" )
      msg_to_send = ""
      trb_sht_cntrs.each do |tr_sht|
        msg_to_send += tr_sht
        if tr_sht != trb_sht_cntrs.last
          msg_to_send += "$"
        end
      end
      movekind = @params['movekind']
      @udp_req_obj[:msg] = "1~1~2202~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{msg_to_send}~#{movekind}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
  end

  def getDamageRecordView
    @movekind = @params["movekind"]
    @udp_req_obj[:msg] = "1~1~2203~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    @containers = @params["containers"].split("|")
    @itvs = @params["itvs"].split("|")
    @ground= @params["ground"].split("|")
    @joblist = $job_list_confirm
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2204")
        @damage_areas = resp_fields[2].to_s.split('|')
        @damage_code_desc = resp_fields[3].to_s.split('|')
        render :action => :damagerecord
      else
        render :string => "false"
      end
    end
  end

  def sendDamageRecordReq
    #    container_select = @params['container_select']
    #    cntr_to_location = @params['cntr_to_location']
    #    trouble_shoot_area = @params['trouble_shoot_area']
    damage_details = @params["damage_details"]
    msg_to_send = ""
    damage_details.each do |dmg_recrd|
      msg_to_send += dmg_recrd
      if dmg_recrd != damage_details.last
        msg_to_send += "$"
      end
    end
    movekind = @params['movekind']

    puts @params["containers"].inspect
    puts "ContainersXXXXXXXXXXXXXXXXXXXX"
    all_dmgs = $resp_qc_jobs + $completedjobs
    dmg_cntrs = all_dmgs.select{|d| @params["containers"].include?(d.containerno+'^'+d.code)}
    puts dmg_cntrs.inspect
    dmg_cntrs.each do |dmg_cntr|
      dmg_cntr.is_damaged = true
      puts dmg_cntr.inspect
    end
    puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

    @udp_req_obj[:msg] = "1~1~2205~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{msg_to_send}~#{movekind}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def sendDamageRecordReqForLoadJob
    damage_details = @params["damage_details"]
    msg_to_send = ""
    damage_details.each do |dmg_recrd|
      msg_to_send += dmg_recrd
      if dmg_recrd != damage_details.last
        msg_to_send += "$"
      end
    end

    puts msg_to_send.inspect
    puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    movekind = @params['movekind']

    puts @params["containers"].inspect
    puts "ContainersXXXXXXXXXXXXXXXXXXXX"
    all_dmgs = $resp_qc_jobs + $completedjobs + $promoted_jobs
    dmg_cntrs = all_dmgs.select{|d| @params["containers"].include?(d.containerno)}
    puts dmg_cntrs.inspect
    dmg_cntrs.each do |dmg_cntr|
      dmg_cntr.is_damaged = "true"
      puts dmg_cntr.inspect
    end
    puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

    @udp_req_obj[:msg] = "1~1~2205~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{msg_to_send}~#{movekind}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def joblist_refresh
    @udp_req_obj[:msg] = "1~1~3200~#{geteventid}~#{$userid}~#{$terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~Updated Job List"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def ordercontainerlist(addContainerList)
    ordercontainerList= $resp_qc_jobs.select{|v|  addContainerList.include? v.containerno }
    orderedlist = Array.new
    ordercontainerList.each { |orderjob|
      orderedlist.push(orderjob.containerno)
    }
    return orderedlist
  end

  # Get List of Languages from Server
  # Terminal number is changed as per rho configuration
  def getLanguagesList
    @udp_req_obj[:msg] = "1~1~1410~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1411" == resp_msg_id)
        @languagesList = resp_fields[2].to_s.split('|')
        render :action => :languages
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #Sending Selected language to server
  def setLanguage
    selectedLang = @params["selectedlang"]
    @udp_req_obj[:msg] = "1~1~1412~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{selectedLang}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      System::set_locale(selectedLang)
      render :action => :index
    else
      render :string => "Error"
    end
  end

  def getdamageCrctnScreen
    render :action => :damageCorrection
  end

  def sendDamageCorrectData
    containerId = @params["containerNumber"]
    updatedRecords=@params["oldDamageRecords"]
    deletedRecords= @params["deletedDamageCodes"]
    addedRecords=@params["newDamageRecords"]
    mkind = @params["mkind"]  
    remarks=@params["remarks"]

    @udp_req_obj[:msg] = "1~1~2212~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}~#{updatedRecords}~#{deletedRecords}~#{addedRecords}~#{remarks}~#{mkind}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def getDmgeDtlsForCntnr
    #1\7e1\7e2211\7eeventId\7econtainerId\7eDamagetype1^code1#loc1&loc2&loc3#sevr|code2#loc1&loc2&loc3#sevr|code3#loc1&loc2&loc3#sevr$DamageType2^code3#loc1&loc2&loc3#sevr|code4#loc1&loc2&loc3#sevr|code5#loc1&loc2&loc3#sevr\7eId^type^severity^code^location^loc1&loc2&loc3|Id^type^severity^code^location^loc1&loc2&loc3\7euserId\7eTerminalId
    containerId = @params["containerID"]
    mkind = @params["mkind"]
    @udp_req_obj[:msg] = "1~1~2210~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}~#{mkind}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2211")
        @containerId = resp_fields[2]
        @dmgeTypeDtls= resp_fields[3]
        @dmgeRecDetails= resp_fields[4].split('|')
        #New code added for grid
        @dmge_details = resp_fields[3].split("$")
        #New code ended for grid
        
        puts @dmgeRecDetails.inspect
        
        puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        render :partial =>"damage_correct_partial", :locals => { :ad => "foo_ad" }
      else
        render :string => "false"
      end
    end
  end

  def sendDmgeCrctnDtls
    containerId = @params["containerID"]
    updatedRecords=@params["dmge_updtd"]
    deletedRecords=@params["dmge_deltd"]
    addedRecords=@params["dmge_added"]
    mkind = @params["mkind"]  
    @udp_req_obj[:msg] = "1~1~2212~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}~#{updatedRecords}~#{deletedRecords}~#{addedRecords}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
  end
  
  def get_request_response(req_msg_id, data_to_send)
    @udp_req_obj[:msg] = "1~1~#{req_msg_id}~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~" + data_to_send
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      resp_msg_id = resp_fields[0]
      if($msg_hash[req_msg_id.to_i].include?resp_msg_id)
        return resp
      else
        return false
      end
    end
  end
  
  def open_out_of_list
    containers_list = @params["containerList"].split("~")
    @available_containers = processjoblist(containers_list, 'out_of_list')
    $out_of_list_containers = @available_containers
    render :action => 'out_of_list'
  end
  
  def get_searched_container
    request_data = "#{@params["searchTerm"]}"
    resp = get_request_response("2100", request_data)
    if(resp != false)
        render :string => resp
    else
        render :string => "error"
    end
  end
  
  def move_to_completed(container_no, iso_code, selected_itv, request_type)
      if(request_type == "1")
          selected_job = $out_of_list_containers.select{|v| v.containerno == container_no}
          if(selected_job.length > 0)
            $completedjobs.unshift(selected_job[0])
          end
      else
            $completedjobs.unshift(Joblist.new("DSCH",container_no,iso_code,'','',"VESSEL",selected_itv,'','','','','','','','true','false','AFT','false',"manual"))
      end
  end
  
  def send_out_of_list_container
    request_data = "#{@params["containerNo"]}~#{@params["isoCode"]}~#{@params["selectedItv"]}~#{@params["requestType"]}~#{@params["fromLocation"]}"
    resp = get_request_response("2102", request_data)
    if(resp != false)
        resp_fields = resp.split("~")
        if(resp_fields[2] == "true")
          move_to_completed(@params["containerNo"],@params["isoCode"],@params["selectedItv"], @params["requestType"])
          render :string => "true"
        else
          render :string => resp_fields[3].to_s()
        end
    else
        render :string => "error"
    end
  end
  
  def get_container_utils_popup
    render :action => 'container_utils'
  end
  
  def get_container_update_popup
    render :action => 'container_update_popup'
  end
  
  def get_changed_data(params_data)
    if($container_attributes_server[3] == params_data['upd_line_code'])
      params_data['upd_line_code'] = ''
    end
    if($container_attributes_server[4] == params_data['upd_category'])
      params_data['upd_category'] = ''
    end
    if($container_attributes_server[5].to_s().downcase == params_data['upd_empty'].to_s().downcase)
      params_data['upd_empty'] = ''
    end
    
    if(params_data['iso_select'].to_s() == "--Please select--")
      params_data['iso_select'] = ''
    end
    
    if($container_attributes_server[7] == params_data['upd_pod'])
      params_data['upd_pod'] = ''
    end
    if($container_attributes_server[8] == params_data['upd_npod'])
      params_data['upd_npod'] = ''
    end
    if($container_attributes_server[9] == params_data['upd_fpod'])
      params_data['upd_fpod'] = ''
    end
    if($container_attributes_server[10] == params_data['upd_size'])
      params_data['upd_size'] = ''
    end
    if($container_attributes_server[11] == params_data['upd_weight'])
      params_data['upd_weight'] = ''
    end
    if($container_attributes_server[12].split('/')[0] == params_data['dim_front'])
      #params_data['dim_front'] = ''
    end
    if($container_attributes_server[12].split('/')[1] == params_data['dim_bottom'])
      #params_data['dim_bottom'] = ''
    end
    if($container_attributes_server[12].split('/')[2] == params_data['dim_left'])
      #params_data['dim_left'] = ''
    end
    if($container_attributes_server[12].split('/')[3] == params_data['dim_right'])
      #params_data['dim_right'] = ''
    end
    if($container_attributes_server[12].split('/')[4] == params_data['dim_top'])
      #params_data['dim_top'] = ''
    end
    if($container_attributes_server[13] == params_data['upd_plug'])
      params_data['upd_plug'] = ''
    end
    if($container_attributes_server[14] == params_data['upd_vessel'])
      params_data['upd_vessel'] = ''
    end
    if($container_attributes_server[15] == params_data['upd_out_vessel'])
      params_data['upd_out_vessel'] = ''
    end
    if($container_attributes_server[16] == params_data['upd_voyage'])
      params_data['upd_voyage'] = ''
    end
    if($container_attributes_server[17] == params_data['upd_out_voyage'])
      params_data['upd_out_voyage'] = ''
    end
    if($container_attributes_server[18] == params_data['upd_seal_1'])
      params_data['upd_seal_1'] = ''
    end
    if($container_attributes_server[19] == params_data['upd_seal_2'])
      params_data['upd_seal_2'] = ''
    end
    if($container_attributes_server[20] == params_data['upd_seal_3'])
      params_data['upd_seal_3'] = ''
    end
    if($container_attributes_server[21] == params_data['upd_seal_4'])
      params_data['upd_seal_4'] = ''
    end
    if($container_attributes_server[22] == params_data['upd_seal_5'])
      params_data['upd_seal_5'] = ''
    end
    
    return params_data
  end
  
  def update_container_attributes
    @params = get_changed_data(@params)
    container_data = "#{$container_attributes_server[2]}~#{@params['upd_line_code']}~#{@params['upd_category']}~#{@params['upd_empty']}~#{@params['iso_select']}~#{@params['upd_pod']}~#{@params['upd_npod']}~#{@params['upd_fpod']}~#{@params['upd_size']}~#{@params['upd_weight']}~#{@params['dim_front']}/#{@params['dim_bottom']}/#{@params['dim_left']}/#{@params['dim_right']}/#{@params['dim_top']}~#{@params['upd_plug']}~#{@params['upd_vessel']}~#{@params['upd_out_vessel']}~#{@params['upd_voyage']}~#{@params['upd_out_voyage']}~#{@params['upd_seal_1']}~#{@params['upd_seal_2']}~#{@params['upd_seal_3']}~#{@params['upd_seal_4']}~#{@params['upd_seal_5']}"
    @udp_req_obj[:msg] = "1~1~4002~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~" + container_data
     resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
     if resp.length > 0
       resp_fields = resp.to_s().split("~")
       resp_msg_id = resp_fields[0]
       if(resp_msg_id == "4003")
         if(resp_fields[2] == "true")
          render :string => "true"
         else
          WebView.execute_js('showAlerts("'+ resp_fields[3].to_s() + '")')
          render :string => "false"
         end
       else
         render :string => "error"
       end
     end
  end
  
  def get_container_attributes
    containerId = @params["containerNumber"]
     @udp_req_obj[:msg] = "1~1~4000~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerId}"
     resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
     if resp.length > 0
       resp_fields = resp.to_s().split("~")
       resp_msg_id = resp_fields[0]
       if(resp_msg_id == "4001")
         @container_attributes = resp_fields
         $container_attributes_server = resp_fields
         render :partial =>"container_attributes_partial", :locals => { :ad => "foo_ad" }
       else
         render :string => "false"
       end
     end
  end

  # Receives promote job container and move type
  def promote_jobs
    request_params = [ @params["containerId"],  @params["moveType"] ];
    @udp_req_obj[:msg] = get_request_string("1699" ,request_params)
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s().split("~")
      if(resp_fields[0] == "1670")
        if(resp_fields[2] == "true") # status is true
          @params["containers"] = @params["containers"].split('~')
          $promoted_jobs = Array.new
          @params["containers"].each do |container_id|
            $promoted_jobs.push(container_id)
          end
          render :string => "true"
        else
          render :string => resp_fields[3] # error message
        end
      else
        render :string => "error"
      end
    end
  end

end