require 'socket'
require 'thread'
require 'rho/rhocontroller'
require 'helpers/browser_helper'
require 'helpers/socket_helper'
require 'helpers/hc_helper'
require 'rho/rhoapplication'
require 'time'
require 'date'
require 'net/http'
require 'uri'

#require 'open3'
class AppApplication < Rho::RhoApplication
  def initialize
    # Tab items are loaded left->right, @tabs[0] is leftmost tab in the tab-bar
    # Super must be called *after* settings @tabs!
    @tabs = nil
    #To remove default toolbar uncomment next line:
    @@toolbar = nil
    super
    $session ||= {}
    # Uncomment to set sync notification callback to /app/Settings/sync_notify.
    # Rho::RhoConnectClient.setObjectNotification("/app/Settings/sync_notify")
    #    Rho::RhoConnectClient.setNotification('*', "/app/Settings/sync_notify", '')
    $session[:removedjobs] = Array.new
    #$session[:checkForMsg] = Array.new
    $session[:Itv_popup_image]= Array.new
    $job_list_confirm = Array.new
    $userid = ""
    $resp_qc_jobs = Array.new
    $plc_job_list_confirm = Array.new
    $completedjobs = Array.new
    $myThread ||= {}
    $msg_hash =  Hash.new( "messages" )
    $display_itv_pow = Array.new
    $completed_jobsrequest = false
    $no_of_wait_trails = 0
    $loggedout = false
    $loggedin = false
    $server_login_failure = false
    $app_started = false
    $promoted_jobs = Array.new
    $container_position = "AFT"
    $notifications_array = Array.new
    $contr_edited = false
    $is_completed_jobsrequest = false # used to check whether jobs are coming from server or current jobs

    $local_com_ip = Rho::RhoConfig.local_ip_to_use == "system" ? UDPSocket.open {|s| s.connect(Rho::RhoConfig.com_server_ip, 1); s.addr.last } : Rho::RhoConfig.local_com_ip
    #    $local_com_ip = UDPSocket.open {|s| s.connect('127.0.0.1', 1); s.addr.last }
    #    $local_com_ip = Socket.gethostname
    puts $local_com_ip.inspect
    puts "Local ip address"
    $device_id = (Rho::RhoConfig.device_selection == "device") ? Socket.gethostname : Rho::RhoConfig.deviceid
    puts $device_id.inspect
    puts "Device id"

    System::set_locale("en")

  end

  def update_ui_app
    puts "In update"
    begin
      puts "In Begin"
      response = Net::HTTP.get_response(URI.parse("http://127.0.0.1:8082/ATOMMobileAppRel/HC/HCApps_v2_28.zip"))
      File.open("C:/Users/1102519/Desktop/ATOM/webapps/ATOMMobileAppRel/QC/hc_tmp.zip", "wb") do |saved_file|
        saved_file.write(response.body)
      end

    rescue Exception => ex
      puts ex
      puts "In Exception"
    end
  end

  def on_activate_app
    #        puts soundsys.inspect()
    # TO CHECK IF THE APPLICATION PORT IS ALREADY RUNNING
    if !($app_started)
      $app_started = true
      begin
        u1 = UDPSocket.new
        u1.bind($local_com_ip, Rho::RhoConfig.local_com_port)

        u2 = UDPSocket.new
        u2.send "hi", 0, $local_com_ip, Rho::RhoConfig.local_com_port

        mesg, addr = u1.recvfrom(10)
        u1.send mesg, 0, addr[3], addr[1]

        p u2.recv(100) #=> "hi"
        u1.flush()
        u1.close()
        u2.flush()
        u2.close()
      rescue Exception => ex
        puts "PORT IS ALREADY IN USE"
        puts ex.inspect
      end
    end
    $msg_hash = {1600 => "1603",1118 => "1119",1200=>"1201,1203,1400,1399",1204=>"1400,1399",1401=>"1402,9998",1403=>"1405",1404=>"1405",2002=>"2003",2000=>"2000",2600=>"2601",2500=>"2501",2100=>"2101",2102=>"2103",2200=>"2201",2203=>"2204",1420=>"1421",1410=>"1411", 2207=>"2208", 2400=>"2401", 2402=>"2403", 1800 => "1802", 1610 => "1611,1612", 2210 => "2211", 1699 => "1670", 4000 => "4001", 4002 => "4003", 7777 => "7778"}
  end

  def on_deactivate_app
    puts "**********Application Have Been Deactivated.***************"
  end

  def on_ui_destroyed
    super
    puts "closing"
    puts "loggedout " + $loggedout.inspect
    puts "loggedin " + $loggedin.inspect
    if(!$loggedout && $loggedin == true)
      puts "Inside "
      $no_of_wait_trails = 5
      $checkForITVArrivedFlag = false
      org_string = "device2" + Time.now.strftime("%d%m%Y%H%M%S")
      encoded_string = org_string.hash
      msg = "1~1~9999~#{encoded_string}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      puts "Send Request To Server On Destroying Application:- "+msg.inspect
      $udp_socket.send msg, 0, Rho::RhoConfig.com_server_ip,Rho::RhoConfig.com_server_port
    end
    if $udp_socket != nil
      $udp_socket.flush()
      $udp_socket.close()
    end
    if $poll_socket != nil
      $poll_socket.flush()
      $poll_socket.close()
    end
    puts "**********Application Have Been Destroyed.***************"
  end

  def serve( req, res )
    begin
      super
    rescue Exception => ex
      puts ex.to_s().inspect
      $no_of_wait_trails = 5
      if ($server_login_failure == true)
        WebView.execute_js("
          swal({
            text: 'Unable to Process your request',
            showCancelButton: false,
            allowOutsideClick: false,
            closeOnConfirm: true
            },
            function(isConfirm) {
              Rho.Application.quit()
            });")
      else
        WebView.execute_js("showAlerts('Unable to Process your request')")
      end
      raise
    end
  end

  def parse_instances(cmd)
    result = `#{cmd}`
    cmdLine = ""
    pid = ""
    raise("Error: " + result) unless $? == 0
    processes = []
    pinfo = nil
    result.split(/\r?\n/).each do |line|
      next if line =~ /^\s*$/
      if line =~ /CommandLine=(.*)/i
        cmdLine = $1
      elsif line =~ /ProcessId=(\d+)/i
        pid = $1
        processes << cmdLine + pid unless pid.to_i == $$.to_i
      end
    end

    return processes
  end
end
