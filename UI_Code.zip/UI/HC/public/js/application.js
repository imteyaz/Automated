var splitTimeInterval = 0;
var disabledElements = "";
window.onerror = function(msg, url, line, col, error) {
   // Note that col & error are new to the HTML 5 spec and may not be 
   // supported in every browser.  It worked for me in Chrome.
   var extra = !col ? '' : '\ncolumn: ' + col;
   extra += !error ? '' : '\nerror: ' + error;

   // You can view the information in an alert to see things working like this:
   var errorMessage = "Error: " + msg + "\nurl: " + url + "\nline: " + line + extra;
  // alert(errorMessage);

   // TODO: Report this error via ajax so you can keep track
   //       of what pages have JS issues

   var suppressErrorAlert = true;
   // If you return true, then error alerts (like in older versions of 
   // Internet Explorer) will be suppressed.
   Rho.Log.error(errorMessage, "javascript");
};

function confirmAction(actionType, popMessage){
	popMessage = popMessage || "Do you want continue?";
    
	
    swal({
      text: popMessage,
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ok',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
            if(actionType == 'promote_job'){
            	sendPromoteJobNotification();
            }else if(actionType == 'door_direction'){
            	setDoorDirection();
            }
          }else{
            return false;
          }
      });
    
}

function showLoding(){
	maskScreen();
	setTimeout(unmaskScreen, $("#hdnSplitInterval").val())
}


function maskScreen(){
	$(".main_layout").mask("Loading...");
}


function unmaskScreen(){
	$(".main_layout").unmask();
}
