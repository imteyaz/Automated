//@ sourceURL=out_of_list.js

function createOutOfListGrid(containerList) {
	console.log(containerList.length);
	jQuery("#outOfListTable").jqGrid({
		data: containerList,
		datatype: "local",
		height: 200,
		colNames: ["CONTAINER", "ISO", "POD","WT","FROM",],
		colModel: [
		{ name: 'containerNo', index: 'containerNo', editable: false,width: 150, resizable: false },
		{ name: 'iso', index: 'iso', editable: false,width: 150, resizable: false },
		{ name: 'country', index: 'country', editable: false,width: 100, resizable: false },
		{ name: 'weight', index: 'weight', editable: false,width: 100, resizable: false },
		{ name: 'fromLocation', index: 'fromLocation', editable: false,width: 150, resizable: false }
		],
		autowidth: true,
		shrinkToFit: false,
		forceFit: true,
		// adding tool bar at top
		//   toppager: true,
		//toolbar: [true, "top"],
		editurl: 'clientArray',
		onSelectRow : function(id){ 
			
			
		}
	});
}

function sendOutOfListData() {
	var selectedItv = $("#itv_select_new").val();
	var selectedRow = $("#outOfListTable .ui-state-highlight");
	
	if(selectedRow.length == 0) {
		showAlerts("Please select a container");
		return;
	}
		
	if (selectedItv == "") {
		showAlerts("Please select To Location");
	} else {
		var containerNo = selectedRow.find("td[aria-describedby='outOfListTable_containerNo']").attr("title");
	    var isoCode = selectedRow.find("td[aria-describedby='outOfListTable_iso']").attr("title");
	    var fromLocation = selectedRow.find("td[aria-describedby='outOfListTable_fromLocation']").attr("title");
	    sendNewContainerData(containerNo, isoCode, selectedItv, 1, fromLocation);
	}
}

