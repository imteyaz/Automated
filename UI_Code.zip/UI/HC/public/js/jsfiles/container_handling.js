//@ sourceULR=containerhandling.js

var tr_sht = [];
  var dmg_rcd = [];

var currentItvNumber = "";


function isSealInformationValid(){
  return false;
}

var seal_ok_clicked = false;

function processjob(containerno, prev_locations) {
	
  var validateITVSelResult = validateITVSel();
  if (validateITVSelResult) {
    var celllocation = ""
    var itvno = ""
    var movekind = ""
    var baycelllocation = "";
    var tempSeal = "", tempTroubleshoot = "", tempDoorDirection= "";
    var containerPositions = "", categoryInfo="";
    
    var sealButtonInfo = "", sealTroubleshootInfo = "", doorDirectionInfo = "";
    
    $(".container_details").each(function(){
      tempSeal = $(this).find(".hdn-seal-info").val();
      tempTroubleshoot = $(this).find(".hdn-seal-troubleshoot-area").val();
      tempDoorDirection = $(this).find(".hdn-door-direction").val();
      
      categoryInfo += $(this).attr("category") + "|";
    
      if($(this).hasClass("position-forward")) {
    	  containerPositions += "F" + "|";
      } else if($(this).hasClass("position-aft")) {
    	  containerPositions += "A" + "|";
      } else {
    	  containerPositions += "C" + "|";
      }
      
      if(tempSeal != ""){
    	  sealButtonInfo += tempSeal + "|";
      }
      
      if(tempTroubleshoot != ""){
    	  sealTroubleshootInfo += tempTroubleshoot + "|";
      }
      
      if(tempDoorDirection != ""){
    	  doorDirectionInfo += tempDoorDirection + "|";
      }
      
    })
	
	categoryInfo = categoryInfo.slice(0, -1);
    
    sealButtonInfo = sealButtonInfo + "~" + sealTroubleshootInfo + '~' + doorDirectionInfo;
    
    movekind = $(".itv_cntr_no").find("input[name='toData']").attr('movekind');
    
    if (movekind == 'DSCH') {
     
      $(".itv_cntr_no").find("input[name='toData']").each(function() {
        itvno += $(this).val() + "|";
      });
    
      $(".itv_cntr_no").find("input[name='fromData']").each(function() {
        celllocation += $(this).val() + "|";
      });
    } else {
     
      $(".itv_cntr_no").find("input[name='toData']").each(function() {
        celllocation += $(this).val() + "|";
      });

      $(".itv_cntr_no").find("input[name='fromData']").each(function() {
        itvno += $(this).val() + "|";
      });

    }
    
    // send trouble shoot request
    
    if(tr_sht != "")
      {
      $.ajax({
          type: "POST",
          url: "/app/Hc/sendTroubleShootReq",
          data: {
            tr_sht_details: tr_sht,
            movekind: movekind
          },
          success: function(result) {
            //troubleDamageClicked = true;
           // $(".tally_confirm").click();
          }
        });
      }
        // end_ trouble shoot response
    // send Damage container request
    console.log("movekind"+movekind);
    
    if(movekind=="DSCH"){
    	var dmg_rcd = [];
    	console.log("containerno=== " + containerno);
    	var cntrs = containerno.split("|")
		var damageContainers = [];
		 for (var c = 0; c < cntrs.length; c++) {
			var str = ""
			if(main_damaged_data.length != 0)	{
				var dmg_det = $.grep(main_damaged_data, function(e){ return e.cntr_no == cntrs[c].split('^')[0]; });
				
				console.log(dmg_det.length)
				if(dmg_det.length != 0){
					console.log(dmg_det[0].grd_data.subgrid.length > 0)
					if(dmg_det.length > 0 && dmg_det[0].grd_data.subgrid.length > 0){
						damageContainers.push(cntrs[c]);
						str += dmg_det[0].cntr_no + "^"
						for(var sg = 0; sg < dmg_det[0].grd_data.subgrid.length; sg ++){
							console.log(dmg_det[0].grd_data.subgrid[sg].code)
							str += 	dmg_det[0].grd_data.subgrid[sg].code 
							if( sg != dmg_det[0].grd_data.subgrid.length -1){
								str += "|"
							}
						}
						 str += "^"
						 str += dmg_det[0].grd_data.to_loc+"^"
						 str += dmg_det[0].grd_data.ts_code
						console.log(str)
					}
			 }
		 }
			if(str != ""){
				dmg_rcd.push(str)
			}
		}
  
      if(dmg_rcd.length > 0)
        {
        $.ajax({
          type: "POST",
          url: "/app/Hc/sendDamageRecordReq",
          data: {
          damage_details: dmg_rcd,
            movekind: movekind,
			containers: damageContainers
          },
          success: function(result) {
        	  for (var c = 0; c < cntrs.length; c++) {
        		  
        		  $("#qc_table tr[data-uniquejobid='"+cntrs[c]+"']").attr("is_damaged",true)
                  $("#qc_table tr[data-uniquejobid='"+cntrs[c]+"'] td:last").addClass("damage")  
        		  main_damaged_data = $.grep(main_damaged_data, function(e){ return e.cntr_no != cntrs[c].split('^')[0]; });
        		  
        	  }
        	  
           // troubleDamageClicked = true;
          //  $(".tally_confirm").click();
          }
          });
        }
      }
      // end_damage recording          
    send_data(containerno, celllocation.substring(0, celllocation.length - 1), itvno.substring(0, itvno.length - 1), movekind, baycelllocation, prev_locations, sealButtonInfo, containerPositions, categoryInfo)

  }
  
}

function getcelllocationforbayupdate(cellId_org, celllocation) {
  cellId = cellId_org.split(".")
  bayno = Number(cellId[0])
  if (bayno % 2 == 0) {
    if (celllocation.length == 0)
      celllocation = pad( (bayno - 1)) + "." + cellId[1] + "." + cellId[2] + "|" + pad( (bayno + 1)) + "." + cellId[1] + "." + cellId[2]
    else
      celllocation = celllocation + "|" + pad( (bayno - 1)) + "." + cellId[1] + "." + cellId[2] + "|" + pad( (bayno + 1)) + "." + cellId[1] + "." + cellId[2]
  } else {
    if (celllocation.length == 0)
      celllocation = cellId_org
    else
      celllocation = celllocation + "|" + cellId_org
  }

  return celllocation
}

function markColorToITV() {

  $('.cntr_no div[name="cntr"]').parent().removeClass("cntr_no_active")

  $('.itv_cntr_no input[name="toData"]').each(function() {
    itv_no = $(this).val()
    $('.cntr_no div[name="cntr"]').each(function() {
      if (itv_no == $(this).text()) {
        $(this).parent().addClass("cntr_no_active")
      }
    });
  });
}

function updateCntrITVNo(itvNo) {
  cntrLength = $(".itv_pool").find(".itv_cntr_no").length

  if (cntrLength == 1) { //single job

    $('.cntrOprtns0 input[name="toData"]').val(itvNo);

  } else if (cntrLength == 2) { //twin job
    cntrBayno = $('.cntrOprtns0').attr("cntrBayno");
    if (Number(cntrBayno) % 2 == 1) { // 20 Ft
      $('.cntrOprtns0 input[name="toData"]').val(itvNo);
      $('.cntrOprtns1 input[name="toData"]').val(itvNo);
    } else { // 40 ft
      if (!clicked) {
        $('.cntrOprtns0 input[name="toData"]').val(itvNo);
        clicked = true;
      } else if (clicked) {
        $('.cntrOprtns1 input[name="toData"]').val(itvNo);
        clicked = false;
      }
    }
  } else if (cntrLength == 4) { //tandem job
    if (!clicked) {
      $('.cntrOprtns0 input[name="toData"]').val(itvNo);
      $('.cntrOprtns1 input[name="toData"]').val(itvNo);
      clicked = false;
      if ($(".itv_pool div").hasClass("cntrOprtns2")) {
        clicked = true;
      }
    } else if (clicked) {
      $('.cntrOprtns2 input[name="toData"]').val(itvNo);
      $('.cntrOprtns3 input[name="toData"]').val(itvNo);
      clicked = false;
    }
  }
  markColorToITV();
}

function validateITVSel() {
  cntrCode = ($('.cntrOprtns0').attr("cntrCode")).toUpperCase();
  cntrLength = $(".itv_pool").find(".itv_cntr_no").length
  cntr0 = "", cntr1 = "", cntr2 = "", cntr3 = "";
  if($('.cntrOprtns0 input[name="toData"]').val()) {
  	cntr0 = ($('.cntrOprtns0 input[name="toData"]').val()).toUpperCase();
  }
  
  if($('.cntrOprtns1 input[name="toData"]').val()) {
  	cntr1 = ($('.cntrOprtns1 input[name="toData"]').val()).toUpperCase();
  }
  
  if($('.cntrOprtns2 input[name="toData"]').val()) {
  	cntr2 = ($('.cntrOprtns2 input[name="toData"]').val()).toUpperCase();
  }
	  
  if($('.cntrOprtns3 input[name="toData"]').val()) {
  	cntr3 = ($('.cntrOprtns3 input[name="toData"]').val()).toUpperCase();
  }

  
  var movkind = $(".cntrOprtns0").attr("cntrcode")
//     if(movkind == "LOAD"){
//       chk_loc_flag = true;
//       $(".to_location_data").each(function(){
//       
//       		   var toLocationData = $(this).val();
//	    	   if(toLocationData.indexOf('<br>') > -1){
//	    			console.log("br tag found");
//	    			toLocationData = toLocationData.substring(0, toLocationData.length - 4);
//	    		}
//	    	   
//                var ip_arr = toLocationData.split(".");
//                
//                  if(ip_arr.length != 3){
//                    showAlerts("Invalid To location")
//                    chk_loc_flag = false;
//                    }
//                  else{
//                    for(var i=0;i<3;i++){
//                      console.log(ip_arr[i])
//                        if(ip_arr[i].length != 2 || isNaN(ip_arr[i])){
//                        console.log("Invalid To location")
//                          showAlerts("Invalid To location")
//                          chk_loc_flag = false;
//                      }
//                    }
//                  }
//                })
//         if(!chk_loc_flag){
//           return false;
//         }
//     }
  
  for(var i=0;i<cntrLength;i++){
    if(eval("cntr"+i)==""){
      showAlerts("To location should not be empty")
      return false;
    }
  }
  
  if(cntrLength == "2"){
    var cntrBayno = $('.cntrOprtns0').attr("cntrBayno"); 
    if(Number(cntrBayno)%2 == 0){         
      if((cntr0 == cntr1) && (cntr0 != "GROUND") && (cntr0 != "ground")){
        showAlerts("To location should not be same for 40 feet container")
        return false;
      }
    }
  }else if(cntrLength == "4"){
    if(((cntr0 == cntr2) && (cntr0 != "GROUND") && (cntr0 != "ground")) || ((cntr0 == cntr3) && (cntr0 != "GROUND") && (cntr0 != "ground")) || ((cntr1 == cntr2) && (cntr1 != "GROUND") && (cntr1 != "ground")) || ((cntr1 == cntr3) && (cntr1 != "GROUND") && (cntr1 != "ground"))){
      showAlerts("To location should not be same")
      return false;
    }
  }
  return true;
}

function getTroubleShootView() {
  $('.trouble_sht_btn').attr("disabled", true).addClass("disable_btns");
  var movekind = $(".itv_cntr_no").find("input[name='toData']").attr('movekind');
  console.log("movekind"+movekind);
      var cntrs = ""
      var itvs = ""
      var ground=""
      $(".itv_cntr_no").each(function(){ cntrs += $(this).attr("cntrhandlingcno")+"|"})
      $(".itv_number").each(function(){ itvs += $(this).val()+"|"})
       console.log("itvs"+itvs)
      $("span[name='fromData']").each(function(){
        ground += $(this).html()+"|"
      })
      console.log("ground"+ground)
      
  var containerNo = [];
  $.ajax({
    url: "/app/Hc/getTroubleShootView",
    data: {
      movekind: movekind,
      containers: cntrs, 
      itvs: itvs,
      ground:ground
     },
    success: function(result) {
      if(result != "false"){
        $('#light').html("")
        $('#light').html(result)
        document.getElementById('light').style.display = 'block';
        displayITVNumber();
        $('.trouble_sht_btn').attr("disabled", false).removeClass("disable_btns");
      }else{
        console.log(result);
        $('.trouble_sht_btn').attr("disabled", false).removeClass("disable_btns");
      }
    }
  });
}

function displayITVNumber(){
  $(".container_info").each(function(){
    var container_no = $(this).find('.trouble-container[name="CNTR001"]').val();
    
    var newITVNumber = $(".tally_cntrno[data-container='" + container_no + "']").parent().find(".itv_number").val();
    console.log("newITVNumber"+newITVNumber);
    $(this).find('.trouble-container[name="ITV1"]').val(newITVNumber);
  });
}


function getSealOffView() {
  $('.seal_ok').attr("disabled", true).addClass("disable_btns");
  seal_ok_clicked = true;
  seal_ok = true;
  var containerNo = [];
  $.ajax({
    url: "/app/Hc/getSealOffView",
    success: function(result) {
      if(result != "false"){  
        $('#light').html("")
        $('#light').html(result)
        document.getElementById('light').style.display = 'block';
        //displayITVNumber();
        $('.seal_ok').attr("disabled", false).removeClass("disable_btns");
      }else{
        console.log(result);
        $('.seal_ok').attr("disabled", false).removeClass("disable_btns");
      }
    }
  });
}

function getDamageRecordView() {
  $('.btnDamage').attr("disabled", true).addClass("disable_btns");
  var movekind = $(".itv_cntr_no").find("input[name='toData']").attr('movekind');
  console.log("movekind"+movekind);
  var containerNo = [];
    var cntrs = ""
    var itvs = ""
    var ground=""
     $(".itv_cntr_no").each(function(){ cntrs += $(this).attr("cntrhandlingcno")+"|"})
     $(".itv_number").each(function(){ 
       itvs += $(this).val()+"|"
         console.log("itvs"+itvs)
     })
  $("span[name='fromData']").each(function(){
          ground += $(this).html()+"|"
        })
        console.log("ground"+ground)
  $.ajax({
    url: "/app/Hc/getDamageRecordView",
    data: {
      movekind:movekind,
      containers: cntrs, 
      itvs: itvs,
      ground:ground
    },
    success: function(result) {
      if(result != "false"){      
        $('#light').html("")
        $('#light').html(result)
        $("#itvDrpDwn").msDropdown({ roundedBorder: false });
        document.getElementById('light').style.display = 'block';
        displayITVNumber();
        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
      }else{
        console.log(result);
        $('.btnDamage').attr("disabled", false).removeClass("disable_btns");
      }
    }
  })
}

var clicked = false;
function initializeContainerHandling(){
	
    $(".tally_confirm").click(function(event) {
	  container_confirm = true;
	  processjob($("#hdnContainers").val());
	  troubleDamageClicked = false;
	  seal_ok = false;
	});	
	
  var mk_for_manual_jobs = $(".active").find("#container_width").text();
  var currentJobFilterName = $("#jobs_select").val();
    if((currentJobFilterName == "jobs_completed" || currentJobFilterName == "backreach_jobs") && (mk_for_manual_jobs.match("MANCAGE") || mk_for_manual_jobs.match("HATCHCOVER") || mk_for_manual_jobs.match("BREAKBULK"))){
      if($(".itv_cntr_no:first").attr("cntrcode") == "DSCH")
        {
          $(".swap_numbers").hide();
      }
    }
    
    
    var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
    
    if((backreachContnr.indexOf("HATCHCOVER")!= -1) || (backreachContnr.indexOf("MANCAGE")!= -1) || (backreachContnr.indexOf("BREAKBULK")!= -1)) {
    	disabledElements = ", .to_location_data";
    	$(".to_location_data").prop('disabled', true);
    } else {
    	disabledElements = ""
    	$(".to_location_data").prop('disabled', false);
    }
    
    if($(".container_details").length > 1 || (backreachContnr.indexOf("HATCHCOVER")!= -1) || (backreachContnr.indexOf("MANCAGE")!= -1) || (backreachContnr.indexOf("BREAKBULK")!= -1)){
        $('.seal_ok').addClass("disable_btns");
        $('.btn_door_direction').removeClass('action_btn').addClass("disable_btns");
    }else{
      $(".container_details").addClass("selected_container");
      if($(".itv_cntr_no:first").attr("cntrcode") == "DSCH"){
      	$('.btn_door_direction').removeClass('disable_btns').addClass("action_btn");
      }else{
    	$('.btn_door_direction').removeClass('action_btn').addClass("disable_btns");
      }
    }
    
  
  var seal_ok = true;
  //virtualKeyboard();
  $("#itv_select").combobox();
//  $("#itv_select").msDropdown({ roundedBorder: false });
  //$(".itv_number").attr("contenteditable", false);
  markColorToITV();
  $("#seal_btn").click(function(e) {
    var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
    
    if($(".selected_container").length > 0){
      
      if ($(this).hasClass("seal_ok")) {
        $(this).removeClass("seal_ok").addClass("seal_off").val("Seal Off");
        $(".selected_container").find(".hdn-seal-info").val("N");
        sealInfo = "N";
        seal_ok = false;
      } else {
        $(this).removeClass("seal_off").addClass("seal_ok").val("Seal Ok");
        $(".selected_container").find(".hdn-seal-info").val("Y");
        sealInfo = "Y";
        seal_ok = true;
      }
      
      containerNumber = $(".selected_container").find(".tally_cntrno").html();
      
        $.ajax({
            url: "/app/Hc/updateContainerSealInfo",
            data: {
              container: containerNumber, 
              sealInfo: sealInfo
            },
            success: function() {
            }
          })
          
        to_location_data = $(".selected_container").find(".to_location_data");
          
        if($(".selected_container").find(".to_location_data").attr("movekind") == "LOAD"){
          currentItvNumber =  $(".selected_container").find("span[name='fromData']").html();
        }else{
          currentItvNumber = $(".selected_container").find(".to_location_data").val();
        }
        
        var askForTroubleshoot = false;
        
        var containerProblemCount = parseInt($(".hdnSealProblem").val());
        
        if((to_location_data.attr("status") == "F" && seal_ok == false) || (to_location_data.attr("status") == "M" && seal_ok == true)){
          askForTroubleshoot = true;
          containerProblemCount++;
        }else{
          containerProblemCount--;
        }
        
          $(".hdnSealProblem").val(containerProblemCount);
      
      if(askForTroubleshoot && currentItvNumber.indexOf("GROUND") == -1 && currentItvNumber.indexOf("GRD") == -1 && currentItvNumber.indexOf(".") == -1){
        var selectedContainerNumber = $(".selected_container").attr("cntrhandlingcno");
        var popMessage = "Do you want to send " + selectedContainerNumber + " conatiner to troubleshoot area?";
     
        swal({
          text: popMessage,
              showCancelButton: true,
              confirmButtonColor: 'green',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok',
              closeOnConfirm: true
          },  
          function (isConfirm) {    
              if (isConfirm === true) {
                getSealOffView();
              } 
          });
     }
      
    }else if((backreachContnr.indexOf("HATCHCOVER")!= -1) || (backreachContnr.indexOf("MANCAGE")!= -1) || (backreachContnr.indexOf("BREAKBULK")!= -1)){
      showAlerts("Seal off/on is not possible for backreach job");
    }else{
      showAlerts("Please select a container");
    }
  });
  
  
  //Changing ITV number on clicking ITV arrived images
  $(".cntr_no").click(function() {
    itvNo = $(this).find(".itv_truck_number").text();
    $("#itv_select").val("");
    console.log("updatepool_row_first");
    setTimerForEdit();
    $.ajax({
           type:   "POST",
           url:  "/app/Login/change_contr_edit_val",
           success:function(result){
           console.log(result)
           }
       })
	   
    updateCntrITVNo(itvNo);
  });

  
  $(".itvno_edit_icon").off('click').on('click', function() {
      var indexNo = $(this).attr('data-indexNo')
      var currentSelectedJobVal = $(".active").find("#container_width").text();
      var currentJobFilterName = $("#jobs_select").val();
      //var currentItvPoolHidden = $(".active").find("#movekind");
      if(currentJobFilterName == "backreach_jobs"){
      //$(".itv_No" + indexNo).attr("contenteditable", false)
      } else if((currentJobFilterName == "jobs_completed" || currentJobFilterName == "backreach_jobs") && ((currentSelectedJobVal.match("MANCAGE"))|| (currentSelectedJobVal.match("HATCHCOVER")) || (currentSelectedJobVal.match("BREAKBULK")))) {
        //$(".itv_No" + indexNo).attr("contenteditable", false)
      } else {
      //$(".itv_No" + indexNo).attr("contenteditable", true)
      $(".itv_No" + indexNo).focus()
      $('.hc_itvno').css("background-color", "#fff");
      }
    });
  $(".itv_number").off('keyup').on('keyup', function() {
      $("#itv_select").val("");
      markColorToITV()
    });

  $("#itv_select").off('change').on('change', function() {
	  console.log("Changed ITV val")
      var itvNo = $("#itv_select").val();
      itvNo = itvNo.split("^")
      if (itvNo.length > 0) {
        updateCntrITVNo(itvNo[0])
        markColorToITV()
      }
    });
  $('.trouble_sht_btn').off('click').on('click', function() {
        var backreachContnr=$(".tally_cntrno").html(); 
       if((backreachContnr.indexOf("HATCHCOVER") != -1)||(backreachContnr.indexOf("MANCAGE") != -1)||(backreachContnr.indexOf("BREAKBULK") != -1)){
          showAlerts("Troubleshoot is not possible for Backreach Jobs");
       }else{
          seal_ok_clicked = false;
          getTroubleShootView();
       }
    });
  $('.btnDamage').off('click').on('click', function() {
    var backreachContnr=$(".tally_cntrno").html();  
    console.log("backreachContnr"+backreachContnr)
   if((backreachContnr.indexOf("HATCHCOVER")!= -1)||(backreachContnr.indexOf("MANCAGE")!= -1)||(backreachContnr.indexOf("BREAKBULK")!= -1)){
      console.log("backreach found")
      showAlerts("Damage cannot be recorded for Backreach Job")
      return false;

   } else{
	  var isDamaged= $("#qc_table tr.active").attr("is_damaged"); 
	  var activeRows= $("#qc_table tr.active");
	  if(activeRows.length>1){
		  activeRows.each(function(){
			//  console.log("1")
			 if($(this).attr("is_damaged")=="true"){
				  isDamaged = "true";
				  return false;
			 }
			 else{
				 isDamaged = "false";
			 }
		  })
	  }
	  if(isDamaged=="false"||isDamaged==""){
	  	getDamageRecordView();
	  }
	  else{
		  getdamageCrctnScreen();
	  }
	  }
    });
    
  $(".container_details").on('click', function() {
    var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
        
    if((backreachContnr.indexOf("HATCHCOVER")!= -1) || (backreachContnr.indexOf("MANCAGE")!= -1) || (backreachContnr.indexOf("BREAKBULK")!= -1)){ 
   
      
    }else{
      var sealBtnInfo = $(this).find(".hdn-seal-info").val(),
      var doorBtnInfo = $(this).find(".hdn-door-direction").val();
      $("#seal_btn").removeClass("seal_ok");
      $("#seal_btn").removeClass("seal_off");
      if (sealBtnInfo == "N") {
        $("#seal_btn").removeClass("seal_ok").addClass("seal_off").val("Seal Off");
        seal_ok = false;
      } else {
        $("#seal_btn").removeClass("seal_off").addClass("seal_ok").val("Seal Ok");
        seal_ok = true;
      }
      $(".container_details").removeClass('selected_container');
      $(this).addClass('selected_container');
      $('.seal_ok').removeClass("disable_btns");
      $('.seal_off').removeClass("disable_btns");
      
      if($('.hdn-movekind').val() == "DSCH"){
	      $(".btn_door_direction").removeClass('disable_btns').addClass('action_btn');
	      $(".btn_door_direction").removeClass('door_aft');
		  $(".btn_door_direction").removeClass('door_forward');
		  if (doorBtnInfo == "AFT") {
			$(".btn_door_direction").addClass("door_aft").html("Door<br/>Direction<br/>Aft");
	      } else {
	    	$(".btn_door_direction").addClass("door_forward").html("Door<br/>Direction<br/>Forward");
	      }
      }
    }
  });
}