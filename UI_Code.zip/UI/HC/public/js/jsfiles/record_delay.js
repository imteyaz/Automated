//@ sourceURL=record_delay.js  
var addCount = 0;


function recordDelay1(){
	$.ajax({
		url: "/app/Hc/geDelayRecordingReasons",
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)		
			//$("#delayrecording_data").msDropdown({ roundedBorder: false });
			document.getElementById('light').style.display = 'block';
			
		    $( ".prev-to-time-input" ).appendDtpicker({
				"dateFormat": "MM/DD/YYYY hh:mm"
		    });
		    $( ".prev-to-time-input" ).val('');
		    $(".close-date-picker").click(function(){
		    	$(".datepicker").hide();
		    });	
		}
	});
}



var validData = true;

function validManualDelayData(){
	
	var currentDate = new Date();
	if($('.prev-delays-cnt .hdn-add-row').length > 0){
	   var outerCount=0;
		$('.prev-delays-cnt .hdn-add-row').each(function(i) { 
			outerCount++;
			var manDelayCode = $(this).find(".record_delay_reasons option:selected").val();
			var fromTime =  new Date($(this).find(".from-time-input").handleDtpicker('getDate'));
			var toTime =  new Date($(this).find(".to-time-input").handleDtpicker('getDate'));
			var innerCount=0;
			
			$('.prev-delays-cnt .hdn-add-row').each(function(i) {
				innerCount++;
				var tempManDelayCode = $(this).find(".record_delay_reasons option:selected").val();
				console.log("tempManDelayCode"+tempManDelayCode)
				var tempFromTime =  new Date($(this).find(".from-time-input").handleDtpicker('getDate'));
				console.log("tempFromTime"+tempFromTime)
				var tempToTime =  new Date($(this).find(".to-time-input").handleDtpicker('getDate'));
				console.log("tempToTime"+tempToTime)
				if(outerCount!=innerCount){
					if(manDelayCode==tempManDelayCode){
						console.log("delay codes are same, hence check for from and to time")
						if($(this).find(".to-time-input").val() != ""){
							if((tempFromTime >= fromTime && tempFromTime <= toTime) || (tempToTime >= fromTime && tempToTime <= toTime) || (tempFromTime <= fromTime && tempToTime >= toTime)){
								console.log("overlapping dates")
								showAlerts(manDelayCode + "  overlapping dates")
								validData = false;
								return false;
							}
						}else{
							if(( tempFromTime >= fromTime || tempToTime >= fromTime)){
								console.log("close prev");
								showAlerts(manDelayCode + "  - close previous delay");
								validData = false;
								return false;
							}
						}
					}
				}
			})
			
			
			if(manDelayCode == ""){
				showAlerts("Please select a delay reason");
				validData = false;
				return;
			}
			
			
			if($(this).find(".to-time-input").val() != ""){
				if(fromTime >= toTime){
					showAlerts(manDelayCode + "  - From date should be less than To date");
					validData = false;
					return;
				}
				
				if(toTime > currentDate){
					showAlerts(manDelayCode + " - To date cannot be greater than current date");
					validData = false;
					return;
				}
			}else if($(this).find(".from-time-input").val() != ""){
				if(fromTime > currentDate){
					showAlerts(manDelayCode + " - From date cannot be greater than current date");
					validData = false;
					return;
				}
			}
			
			$('.prev-delays-cnt .old-delays').each(function(i) { 
				var prevDelayCode = $(this).find(".delay-code").html();
	            console.log("prevDelayCode " + prevDelayCode);
	            var prevStartDate = new Date($(this).find(".prev-start-date").html());
				console.log("prevStartDate " + prevStartDate);
				var prevEndDate =  new Date($(this).find(".prev-to-time-input").val());
				console.log("prevEndDate " + prevEndDate);
				if(prevStartDate >= prevEndDate){
					showAlerts(prevDelayCode + "  - From time should be less than To time");
					validData = false;
					return;
				}
				
				if(prevEndDate > currentDate){
					showAlerts(prevDelayCode + " - To date cannot be greater than current date");
					validData = false;
					return;
				}
				
	            if(manDelayCode == prevDelayCode){
					if($(this).find(".prev-to-time-input").val() != ""){
						console.log("end present")
						if((fromTime >= prevStartDate && fromTime <= prevEndDate) || (toTime >= prevStartDate && toTime <= prevEndDate) || (fromTime <= prevStartDate && toTime >= prevEndDate)){
							showAlerts(prevDelayCode + "  overlapping dates")
							validData = false;
							return;
						}
					}else{
						console.log("end absent")
						if((fromTime >= prevStartDate || toTime >= prevStartDate)){
							console.log("close prev");
							showAlerts(prevDelayCode + "  - close previous delay");
							validData = false;
							return;
						}
					}
	            }
			});
		});
	}else{
		$('.prev-delays-cnt .old-delays').each(function(i) { 
			var prevDelayCode1 = $(this).find(".delay-code").html();
            console.log("prevDelayCode " + prevDelayCode1);
            var prevStartDate1 = new Date($(this).find(".prev-start-date").html());
			console.log("prevStartDate " + prevStartDate1);
			var prevEndDate1 =  new Date($(this).find(".prev-to-time-input").val());
			console.log("prevEndDate " + prevEndDate1);
			
			if($(this).find(".prev-to-time-input").val() != ""){
				if(prevStartDate1 >= prevEndDate1){
					showAlerts(prevDelayCode1 + "  - From time should be less than To time");
					validData = false;
					return;
				}
				
				if(prevEndDate1 > currentDate){
					showAlerts(prevDelayCode1 + " - To date cannot be greater than current date");
					validData = false;
					return;
				}
			}
			
		});
		
	}
}

function sendDelayRecordingData1(){
	validData = true;
	var newDelayDetails = "", oldDelayDetails = "";
	validManualDelayData();
	
	if(validData){
		console.log("Valid");
//		for(var i = 0; i < $(".prev-delays-cnt .hdn-add-row").length; i++){
//			var manDelayCode = $(".prev-delays-cnt .hdn-add-row").find(".record_rotation_id")[i].val();
//			var equipmentId =  $(".prev-delays-cnt .hdn-add-row").find(".record_equipment_id")[i].val();
//			var fromTime =  $(".prev-delays-cnt .hdn-add-row")[i].find(".from-time-input").text();
//			var toTime =  $(".prev-delays-cnt .hdn-add-row")[i].find(".to-time-input").text();
//			
//			newDelayDetails += manDelayCode + "^" + equipmentId + "^" + fromTime + "^" +  toTime + "|";
//		}
		
		
		$('.prev-delays-cnt .hdn-add-row').each(function(i) { 
			var manDelayCode = $(this).find(".record_delay_reasons option:selected").val();
			var equipmentId =  $(this).find(".record_equipment_id option:selected").val();
			var fromTime =  $(this).find(".from-time-input").val();
			var toTime =  $(this).find(".to-time-input").val();
			
			newDelayDetails += manDelayCode + "^" + equipmentId + "^" + fromTime + "^" +  toTime + "|";
		});
		
//		for(var i = 0; i < $(".prev-delays-cnt .old-delays").length; i++){
//			var manDelayId = $(".prev-delays-cnt .old-delays")[i].find(".hdn-delay-id").val();
//			var endTime =  $(".prev-delays-cnt .old-delays")[i].find(".prev-to-time-input").text();
//			
//			oldDelayDetails += manDelayId + "^" + endTime + "|";
//		}
		
		$('.prev-delays-cnt .old-delays').each(function(i) { 
			var manDelayId = $(this).find(".hdn-delay-id").val();
			var endTime =  $(this).find(".prev-to-time-input").val();
			
			oldDelayDetails += manDelayId + "^" + endTime + "|";
			
		});
	
	
	var allDelayDetails = newDelayDetails + "~" + oldDelayDetails;
	
	console.log("newDelayDetails");
	console.log(newDelayDetails);
	console.log("oldDelayDetails");
	console.log(oldDelayDetails);
	
	// for validation if delay code is same, from and to shud to differ
	
	
//	var fromDate = $('#fromDate').handleDtpicker('getDate');
//	var status = $('#toDate').handleDtpicker('getDate');
//	var remarks = $('#remarks').val();
//	var delayReason_data = $("#delayrecording_data").val();
//	var equipmentId = $("#delay_equipmentId").text();
//	alert(equipmentId);
//	alert(status);
		$.ajax({
			url: "/app/Hc/sendDelayRecordingData",
			data: {
				
				delayReason_data: allDelayDetails
			},
			success: function(result) {
				if(result == "Success"){
					document.getElementById('light').style.display = 'none';	
				}
			}
		});
	}
}

function addNewRow(){
	
	var addRowData = $(".hdn-add-delay-table .hdn-add-row")[0].outerHTML;
	var res = addRowData.replace(new RegExp('delayrecording_data', 'g'),  "delayrecording_data_" + addCount).replace(new RegExp('equipment_id_data', 'g'),  "equipment_id_data_" + addCount).replace(new RegExp('rotationid_data', 'g'),  "rotationid_data_" + addCount)
	console.log(addRowData);
	$(".prev-delays-cnt tbody").append(res);
	$("#delayrecording_data_" + addCount).msDropdown({ roundedBorder: false });
	$("#rotationid_data_" + addCount).msDropdown({ roundedBorder: false });
	$("#equipment_id_data_" + addCount).msDropdown({ roundedBorder: false });
	
	$( ".from-time-input" ).appendDtpicker({
		"dateFormat": "MM/DD/YYYY hh:mm"
    });
	
    $( ".to-time-input" ).appendDtpicker({
		"dateFormat": "MM/DD/YYYY hh:mm"
    });
	$(".prev-delays-cnt .to-time-input:first").val('');
	$(".cross-btn").click(function(){
		$(this).parent().parent().remove();
		
	});

    addCount++;
   
    $(".prev-delays-cnt .ddcommon").css("position", "static");
    
    $(".prev-delays-cnt .ddcommon").click(function(){
    	
    	var offset = $(this).position();
    	console.log("offset");
    	console.log(offset);
    	$(this).find(".ddChild").css('top', (offset.top + 44)).css('left', offset.left);
    });
   
    
    $(".close-date-picker").click(function(){
    	$(".datepicker").hide();
    });
    
    $(".prev-delays-cnt").scrollTop($(".prev-delays-cnt")[0].scrollHeight);
    
    
    
//    $(".from-time-input, .to-time-input").on('click', function (e) {
//    	e.stopPropogation();
//   });
}