$(document).ready(function() {

	//	To show dynamic labour management popup
	$('#dlm').click(function() {
		$.ajax({
			url: "/app/NonOperational/dynamic_labor_management",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});

	//	To Show technical support and pm schedular popup
	$('#tech_support').click(function() {
		$.ajax({
			url: "/app/NonOperational/technical_support",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});

	//To Show communication popup
	$('#communication').click(function() {
		$.ajax({
			url: "/app/NonOperational/message_voice_calls",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	});

});

// moves to go btn clck
	  $(".moves_to_gonumber").on("click",function(){
		  return false;
		  $('.moves_to_gonumber').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			url: "/app/NonOperational/moves_to_go",
			success: function(result) {
				if(result != "No_data"){
				if(result != "Error"){
					$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns");
					$('#light').html("")
					$('#light').html(result);
					document.getElementById('light').style.display = 'block';
				}
				else{
					$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns");
					showAlerts("Received invalid response");
					closePopup()
				}
			  }else{
				  $('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns"); 
				  showAlerts("No data available");
					closePopup()
			  }
			},
			error: function(result){
				$('.moves_to_gonumber').attr("disabled", false).removeClass("disable_btns"); 
				closePopup()
			}
		});
	})

//To show technical support details popup
function techsupportdetailspopup() {
	$.ajax({
		url: "/app/NonOperational/technical_support_details",
		success: function(result) {
			$('#light').html("")
			$('#light').html(result);
			document.getElementById('light').style.display = 'block';
		},
		error: function(result) {
			$('#light').html("")
			$('#light').html(result);
			document.getElementById('light').style.display = 'none';
		}
	});
}

//To send final technical support details to server
function sendtechdetails() {
	var location = $("#location").val();
	var problem_code = $("#problem_code").val();
	var problem_description = $("#problem_description").val();
	var location_description = $("#location_description").val();
	var asset_number = $("#asset_number").val();
	if (location == "" || problem_code == "" || problem_description == "" || location_description == "" || asset_number == "") {
		showAlerts("Please fill all the values!");
	} else {
		$('#lateloginsubmit').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			url: "/app/NonOperational/send_technical_support_details",
			data: {
				location: location,
				problem_code: problem_code,
				problem_description: problem_description,
				location_description: location_description,
				asset_number: asset_number
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				document.getElementById('light').style.display = 'none';
				$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('#lateloginsubmit').attr("disabled", false).removeClass("disable_btns");
			}
		});
	}
}
