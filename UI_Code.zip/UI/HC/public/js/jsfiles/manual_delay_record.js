//@ sourceURL=manual_delay_record.js

	var addDelayEnabled = false, // becomes true when add button is clicked
	    editDelayEnabled = false; // becomes true when edit button is clicked

	var delayData = [];

	function getDelayReasons(){
		var delayReasonData = "";
		for(var i = 0; i < delayData.delayReasons.length; i++){
			//alert(delayData.delayReasons[i].code);
			if(delayData.delayReasons[i].code != ""){
				delayReasonData += '"' + delayData.delayReasons[i].code + '"' + ':' + '"' + delayData.delayReasons[i].code 
				
				if(delayData.delayReasons[i].desc != ''){
					delayReasonData += ' - ' + delayData.delayReasons[i].desc; 
				}
				
				delayReasonData += '"' + ',';
			}
		}
		
		delayReasonData = delayReasonData.slice(0, -1);
		delayReasonData = '{ ' + delayReasonData  + ' } ';
		delayReasonData = JSON.parse(delayReasonData);
		
		return delayReasonData;
	}
	
	function get_select_values(){
		return {
			value: getDelayReasons(),
			dataInit: function (elem) {
			
				$(elem).addClass('combobox');
				$(elem).attr('type', 'text');
				$(".combobox").combobox();
				setTimeout(virtualKeyboard, 500);
			}
		}	
	}
	
	function prepare_actions_for_grid() {
		var ids = jQuery("#manualDelayTbl").jqGrid('getDataIDs');
		for (var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			be = "<img src='../../public/images/edit.png' class='adjust_edit_image edit_btn' onclick=\"onRowEdit('" + cl + "', this);\" />";
			se = "<img src='../../public/images/save.png' class='adjust_delete_image save_btn' style='display:none;' onclick=\"onSaveRow('" + cl + "', this)\" />";
			
			var selectedRow = jQuery('#manualDelayTbl').jqGrid ('getRowData', cl);
			ce = "<img src='../../public/images/delete_icon.png' class=\"adjust_delete_image delay_delete_btn delay_show_delete_" + selectedRow.codeId + "\" onclick=\"onDeleteRow('" + cl + "', this);\" />";
			jQuery("#manualDelayTbl").jqGrid('setRowData', ids[i], { act: be + se + ce });
		}
	}
	
	var lastSel = -1;
	
	function deleteAndInsertRow(){
		var rowId = $("#manualDelayTbl").getDataIDs()[0];
		var firstRowData = jQuery("#manualDelayTbl").getRowData(rowId);
		jQuery('#manualDelayTbl').jqGrid('delRowData',rowId);
		$("#manualDelayTbl").jqGrid('addRowData',rowId,firstRowData);
	}
	
	function onDeleteRow(id, element){
		$(".confirm-btn").prop("disabled",true);
		$("#addBtn").show();
		if($(jQuery('#manualDelayTbl').jqGrid('getInd', id, true)).attr("editable") == 1){
			editDelayEnabled == false;
			addDelayEnabled = false;
		}
		
		jQuery('#manualDelayTbl').jqGrid('delRowData', id);
	}
	
	function onSaveRow(id, element){
		console.log("id " + id);
		jQuery('#manualDelayTbl').saveRow(id);
		$(element).parent().parent().find(".edit_btn").show();
		$(element).parent().parent().find(".save_btn").hide();
		editDelayEnabled = false;
		if(addDelayEnabled == true){
			deleteAndInsertRow();
			addDelayEnabled = false;
			var d = $('.ui-jqgrid-bdiv');
			d.scrollTop(d.prop("scrollHeight"));
		}
		
	}
	
	function enableColumnsForEdit(selectedGrid, columnNames){
		var i = 0;
		
		for(i = 0; i < columnNames.length; i++){
			selectedGrid.jqGrid('getColProp',columnNames[i]).editable = true;
		}
	}
	
	function disableColumnsForEdit(selectedGrid, columnNames){
		var i = 0;
		
		for(i = 0; i < columnNames.length; i++){
			selectedGrid.jqGrid('getColProp',columnNames[i]).editable = false;
		}
	}
	
	function onRowEdit(id, element){
			if(addDelayEnabled == true || editDelayEnabled == true){
				showAlerts("Please save all other delays");
				return false;
			}
	
			if(lastSel > -1){
				$(".edit_btn").show();
				$(".save_btn").hide();
				jQuery("#manualDelayTbl").jqGrid('restoreRow',lastSel);
			}
			
			var selectedRow = jQuery('#manualDelayTbl').jqGrid ('getRowData', id);

			var editableColumns = [ 'code', 'startDate'];
			var selectedGrid = jQuery("#manualDelayTbl");
			if(selectedRow.codeId != 0){
				disableColumnsForEdit(selectedGrid, editableColumns);
			}else{
				enableColumnsForEdit(selectedGrid, editableColumns);
			}
			jQuery("#manualDelayTbl").jqGrid('editRow', id, true, null, null, 'clientArray');
			lastSel = id;
			$(element).parent().parent().find(".edit_btn").hide();
			$(element).parent().parent().find(".save_btn").show();
			editDelayEnabled = true;
	}

	
	function addFunction() {
		$(".confirm-btn").prop("disabled",false);
		$("#addBtn").hide();
		if(addDelayEnabled == true || editDelayEnabled == true){
			showAlerts("Please save all other delays");
			return false;
		}
		
		var datarow = new delay('', '', $('#hdnEquipmentId').val(), 0, $('#hdnRotationId').val(), '');
		var GridIds = $("#manualDelayTbl").getDataIDs();
		console.log("GridIds");
		console.log(GridIds);
		var last = GridIds[GridIds.length - 1];
		var last4sel = parseInt(last) + 1;
		var su = $("#manualDelayTbl").jqGrid('addRowData',last4sel,datarow, 'first');
		if (su) {
			//gridColumnUpdtbutton(last4sel);
			var cm = jQuery("#manualDelayTbl").jqGrid('getColProp','rotationId');
			cm.editable = false;
 			cm = jQuery("#manualDelayTbl").jqGrid('getColProp','equipmentId');
			cm.editable = false;
			cm = jQuery("#manualDelayTbl").jqGrid('getColProp','code');
			cm.editable = true; 
			cm = jQuery("#manualDelayTbl").jqGrid('getColProp','startDate');
			cm.editable = true;
			jQuery('#manualDelayTbl').editRow(last4sel, true);
			$(".edit_btn:first").hide();
			$(".save_btn:first").show();
		}
		
		var d = $('.ui-jqgrid-bdiv');
		d.scrollTop(0);
				
		addDelayEnabled = true;
	}
	
	function displayDelayData(){
		var initDate = function (elem) {
			 
	        $(elem).datetimepicker({
				timeFormat: "HH:mm",
				numberOfMonths: 1,
				maxDate: 0,
	            changeYear: true,
	            changeMonth: true,
	            showButtonPanel: true,
	            showWeek: false,
	            onSelect: function () {
	                var $grid, grid;
	                if (typeof (elem.id) === "string" && elem.id.substr(0, 3) === "gs_") {
	                    $grid = $(elem).closest('div.ui-jqgrid-hdiv')
	                                .next('div.ui-jqgrid-bdiv')
	                                .find("table.ui-jqgrid-btable:first");
	                    if ($grid.length > 0) {
	                        grid = $grid[0];
	                        if ($.isFunction(grid.triggerToolbar)) {
	                            grid.triggerToolbar();
	                        }
	                    }
	                } else {
	                    $(elem).trigger('change');
	                }
	            }
	        });
			
			if($(elem).attr('name').indexOf('end') == -1){
				if ($(elem).val().length === 0) {
					$(elem).datetimepicker('setDate', new Date());
				}	 
			}
	    }
		
		jQuery("#manualDelayTbl").jqGrid({
			data: delayData.prevDelays,
			datatype: "local",
			height: 200,
			colNames: ["Rotation Id", "Equipment Id", "Code", "From","To","Actions","Code Id"],
			colModel: [
			{ name: 'rotationId', index: 'rotationId', editable: false,width: 120, resizable: false },
			{ name: 'equipmentId', index: 'equipmentId', editable: false,width: 120, resizable: false}, 
			{ name: 'code', index: 'code', editable: true, formatter: "select", width: 240, resizable: false, edittype:"select",editoptions:get_select_values() },
			{ name: 'startDate', index: 'startDate',editable: true, width: 175, resizable: false,  editoptions: { dataInit: initDate }  },
			{ name: 'endDate', index: 'endDate',editable: true, width: 175, resizable: false,  editoptions: { dataInit: initDate }  },
			{ name: 'act', index: 'act', width: 100, sortable: false },
			{ name: 'codeId', index: 'codeId',hidden: true },],
			autowidth: true,
			shrinkToFit: false,
			forceFit: true,
			// adding tool bar at top
			//   toppager: true,
			toolbar: [true, "top"],
			gridComplete: prepare_actions_for_grid,
			editurl: 'clientArray',
			onSelectRow : function(id){ 
				
				
			}
		});
		
		// add button at tool bar
		$("#t_manualDelayTbl").html("");
		if(delayData.prevDelays.length == 0) {
			$("#t_manualDelayTbl").append("<img src='../../public/images/add_new.png' style='height:50px;width:60px;' id='addBtn' onclick='addFunction()'/>");
			$(".confirm-btn").prop("disabled",true);
		}
	}
	
	var delayDataJson = {};	
	
	function delayReason(code, desc){
	   this.code = code;
	   this.desc = desc;
	}
	
	function delay(code, startDate, equipmentId, codeId, rotationId, endDate){
	   this.code = code;
	   this.startDate = startDate;
	   this.equipmentId = equipmentId;
	   this.codeId = codeId;
	   this.rotationId = rotationId;
	   this.endDate = endDate;
	}
	
	function covertManualDelayToJson(delayDataServer){
		
		$('#myModal').on('hidden.bs.modal', function () {
			$('.ui-autocomplete').hide();
	    })
		
	     var delayDataSplit = [], i = 0, tempReason = {}, tempDelay = {},
	 	 delayReasons = [], prevDelays = [];
	 
		 delayDataSplit = delayDataServer.split('~');
		 delayReasons = delayDataSplit[0].split('|');
		 prevDelays = delayDataSplit[1].split('|');
		 delayDataJson  = { 'delayReasons' : [], 'prevDelays' : []}
	 
		 for(i = 0; i < delayReasons.length; i++){
			 tempReason = delayReasons[i].split('^');
			 //tempReason = { 'code': tempReason[0],  'desc': tempReason[1]};
			 tempReason = new delayReason(tempReason[0],tempReason[1]);
			 delayDataJson.delayReasons.push(tempReason);
		}
		
		 if(delayDataSplit[1] != ""){
			 for(i = 0; i < prevDelays.length && prevDelays[i] != ""; i++){
				 tempDelay = prevDelays[i].split('^');
				 tempDelay = new delay(tempDelay[0], tempDelay[1], tempDelay[2], tempDelay[3], $("#hdnRotationId").val(), '');
				 //tempDelay = { 'code': tempDelay[0],  'startDate': tempDelay[1], 'equipmentId': tempDelay[2],  'codeId': tempDelay[3], 'rotationId': 2,  'endDate': '',};
				 delayDataJson.prevDelays.push(tempDelay);
			 }
		 }
		delayData = delayDataJson;
		displayDelayData();
 }
	
	function getManualDelayData(){
		
		//result = '{"delayReasons": [{ "code": "OPB3" , "desc": "TeaBreak"},{ "code": "OPB2" , "desc": "LunchBreak"}],"prevDelays": [{ "code": "OPB2", "desc": "1234", "startDate": "04/11/2016 13:24", "equipmentId": "QC74", "codeId": "8", "rotationId": "44", "endDate": ""},{ "code": "UI app issue", "desc": "3456", "startDate": "05/12/2016 13:24", "equipmentId": "QC68", "codeId": "9", "rotationId": "77", "endDate": ""}, { "code": "UI app issue", "desc": "3456", "startDate": "05/12/2016 13:24", "equipmentId": "QC68", "codeId": "9", "rotationId": "77", "endDate": ""}, { "code": "UI app issue", "desc": "3456", "startDate": "05/12/2016 13:24", "equipmentId": "QC68", "codeId": "9", "rotationId": "77", "endDate": ""}, { "code": "UI app issue", "desc": "3456", "startDate": "05/12/2016 13:24", "equipmentId": "QC68", "codeId": "9", "rotationId": "77", "endDate": ""}, { "code": "UI app issue", "desc": "3456", "startDate": "05/12/2016 13:24", "equipmentId": "QC68", "codeId": "9", "rotationId": "77", "endDate": ""}]}'
			
		//delayData = delayDataJson;
		//displayDelayData();
		$.ajax({
			type: "GET",
			url: "/app/Hc/geDelayRecordingReasonsManual",
			success: function(result){
				if(result !== "Error"){
					var strindData = "admin app issue^desc|qwqe^|another instance test^|good health^|B44^fdgdg|A55^etrertryt|ALLOCATION_DELAY^|01^testtest|Good Health^ds|OTHER^Am the best Tester....|LATE TO WORK^|ALLOCATION DELAY^Test|OPB3^TeaBreak|OPB2^LunchBreak|OPB1^WashRoom|ertry^|wrert^|D01^TEST DELAY01|D02^TEST DELAY02|CRANE BREAKDOWN^CRANE BREAKDOWN|VESSEL NOT BERTHED^Vessel|HEALTH ISSUE^HEALTH ISSUE|CRANE NOT WORKING^CRANE NOT WORKING|300^lok|VT^Break Bulk|VS^Hydrolic Hatch cover|VK^Revision of Plan - Vessel account|VH^Containers In Wrong location|VG^Unsafe working conditions|VF^Ride through|VE^Container is over weight|VD^Damaged Cell Guide|VC^Chief Officer request|VB^Reefer Problem|VA^Incident/Accident (Vessel related)|V9^Damaged container|V8^Waiting Export Container / Connection boxes|V6^Twist locks and lashing problems|V5^Hatch Lids|V4^OOG using Frame|V3^OOG using Wire|V2^Gear Boxes|V1^Vessel Stability|P6^System Failure|P5^Crane Inspection by Technical|VR^Vessel Requirements ( Bunker, Repair, Inspection, Etc.)|VL^Lashing certificate/Damage report not  signed by Chief Officer|V7^Ship Crane Securing/ Passing ship crane|P4^Early Arrival|P3^Securing Gangway|P2^Gang not available|P1^Crane Set Up Time|C3^Authorities/ Emergency|C2^Power Failure|C1^Weather|OE^Tandem Fixing & Releasing|OD^Operator Delay|OC^Incident/Accident (Terminal Related)|OB^Stowage Replan|OA^Truck Alignment|O9^Crane Clash|O8^Meal Break|O7^Shift Change|O6^Waiting Container (Load)|O5^Waiting Terminal Tractor (Discharge)|O4^Lashing delay|O3^Work Cage|O2^Quay Crane Breakdown|O1^Boom Up/Downt|qwe^~admin app issue^04/11/2016 13:24^QC74^8^|A55^04/11/2016 13:24^QC74^8^llll1ASDASAASDASASASDASASAASDAS23";
					setTimeout(function(){
						covertManualDelayToJson(result);
					}, 5);
				}
			},
			error: function(errorMsg){
				console.log(errorMsg);
			}
		})
	}
	
	function displayPopup(){		
		//$("#delayrecording_data").msDropdown({ roundedBorder: false });
		//document.getElementById('light').style.display = 'block';	
		//$("#manualDelayTbl").html("");
		//$( ".modal-dialog" ).html("");
	}
	
	
	$(document).ready(function() {
		getManualDelayData();
	});
	
	
	function removeLastCharacter(stringData){
		if(stringData != ""){
			return stringData.slice(0, -1);
		}
		
		return stringData;
	}
	
	function sendDelayRecordingData(){
		if(addDelayEnabled == true || editDelayEnabled == true){
			showAlerts("Please save all other delays");
			return false;
		}
		
		var allDelayData = jQuery("#manualDelayTbl").jqGrid('getRowData');
		var newDelayDetails = "", oldDelayDetails = "";
		for(var i = 0; i < allDelayData.length; i++){
			var tempDelay = allDelayData[i];
			if(tempDelay.codeId == 0){ // if code is 0 then it's a new delay
				newDelayDetails += tempDelay.code + "^" + tempDelay.equipmentId + "^" + tempDelay.startDate + "^" + tempDelay.endDate + "|";
			}else{
				oldDelayDetails += tempDelay.codeId + "^" + tempDelay.endDate + "|";
			}
		}
		
		newDelayDetails = removeLastCharacter(newDelayDetails);
		oldDelayDetails = removeLastCharacter(oldDelayDetails);
		
		var allDelayDetails = newDelayDetails + "~" + oldDelayDetails;
		
		$.ajax({
			url: "/app/Hc/sendDelayRecordingData",
			data: {
				
				delayReason_data: allDelayDetails
			},
			success: function(result) {
				if(result == "Success"){
					$('#myModal').modal('toggle');	
				}
			}
		});
	}
	
	function closeDelayPopup(){
		$('#myModal').modal('toggle');
	}


