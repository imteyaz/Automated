//@ sourceURL=joblist.js

var TWIN_OPERATION = 1, TANDEM_OPERATION = 2, SPLIT_OPERATION = 3;

function initializeJoblist(){
	
var cellId;

var DELAY = 300, qc_rowClicks = 0, timer = null;

var cellId = [];
//$(".qc_rows").hover(function() {
//
//    cellId = [];
//    cellId_s = $(this).attr('cellId');
//    bayNo = $(this).attr('bayno');
//    if (cellId_s != "BACKREACH" && cellId_s != "VESSEL") {
//      $("tr[cellid='" + cellId_s + "']").addClass('onmouseover');
//    } else {
//      $(this).addClass('onmouseover');
//    }
//    var v = $(this).data('refercontainer');
//    if (v && v.length != 0) {
//      v = v.split('#');
//      for (x = 0; x < v.length; x++) {
//        var qcRow = $(".hc_joblist_table tr[data-container='" + v[x] + "']")
//        $(qcRow).addClass("onmouseover")
//      }
//    }
//    if (Number(bayNo) % 2 == 0) {
//      cellId = $(this).attr('altrcellid').split('|')
//    } else {
//      cellId.push(cellId_s)
//    }
//  }, function() {
//    $(".qc_rows").removeClass('onmouseover');
//  })

$(".container_handling_cls").on("click", function(event) {
    event.stopPropagation();
    lastClickedRow = $(this).parent()[0];
    console.log("lastClickedRow");
    console.log(lastClickedRow);
    
    var contr = $(this).parents("tr:first");
    
    var $tableRows = $(".hc_joblist_table tr");
    var v = contr.data('refercontainer');
    var container = contr.data('uniquejobid');
    var hidd_cntr_val = contr.data('container');
    selected_cont = container;
  $("#hidden_container_no").val(hidd_cntr_val);

    $tableRows.removeClass("active");
    var cont = contr.attr('data-uniquejobid');
    processcontainerhandling(cont, 'true')
    contr.addClass("active")
    v = v.split('#');
    for (x = 0; x < v.length; x++)
      $("#qc_table tr[data-container='" + v[x] + "']").addClass("active")
 
  });
 
     
$('.qc_rows').off('click').on('click', function(e) {
	console.log("Clicked")
	console.log(e);
	console.log(e.currentTarget);
	lastClickedRow = e.currentTarget;
	console.log("lastClickedRow");
	console.log(lastClickedRow);
    var $tableRows = $(".hc_joblist_table tr");
    var v = $(this).data('refercontainer');
    var container = $(this).data('container')
    $("#hidden_container_no").val(container);
    $tableRows.removeClass("active");
    $(".qc_rows").removeClass("active");
    $("#qc_table tr[data-container='" + container + "']").addClass("active")
    v = v.split('#');
    for (x = 0; x < v.length; x++)
      $("#qc_table tr[data-container='" + v[x] + "']").addClass("active")
  })

$('#qc_table tr:nth-child(1)').trigger("click", qc_rowClicks = 2)

}

//context menu interations for QC table

var contextOption, targetContainer;
var addContainer = [];
var bayNo;
var tierNo;
var rowNo;
var mkind;
var contexttandem;
var operationPossible = true;

function jobOperations(contextOption){
	
	var value = $("#jobs_select").val();
    if(value == "jobs_completed" || value == "backreach_jobs" || value == "exception_joblist"){
    	showAlerts("This operation is not possible");
    	return false;
    }
	
	
	console.log("bindContextMenuToJobs");
	operationPossible = true;
	
initiateVariable(contextOption);

if(operationPossible == false){
	return false;
}


    if (contextOption == 'Split') {
      if(addContainer.length > 1){
      	  mergeJobs('Split', addContainer, contexttandem,mkind);
      }else{
    	  showAlerts("Split is not possible");
      }
    } else if (contextOption == 'Delete') {
      deleteJobs(addContainer);
    } else if (contextOption == 'Tandem' || contextOption == 'Twin') { // making twin tandem starts here
      $("#search_joblist").val("");
      $('#qc_table tr').show()
      var addContainer_count = 0;
      $("#qc_table tr[mkind!='" + mkind + "']").find('.add_Jobs').remove();
      if (contextOption == 'Tandem' && addContainer.length == 2) { // Tandem option is selected on twin job
        $("#qc_table tr[data-twinpick ='-1']").find('.add_Jobs').remove();
        $("#qc_table tr[tier !='" + tierNo + "']").find('.add_Jobs').remove();
        $(".job_list_tandem_up").parents("tr").find('.add_Jobs').remove();
        $(".job_list_tandem_down").parents("tr").find('.add_Jobs').remove();

        if (rowNo == "1") {
          if ($("#qc_table tr[row = '0']").find(".add_Jobs").length >= 1) {
            $("#qc_table tr[row !='3'][row !='0'][row !='1']").find('.add_Jobs').remove();
          } else {
            $("#qc_table tr[row !='3'][row !='1'][row !='2']").find('.add_Jobs').remove();
          }
        } else if (rowNo == "0")
          $("#qc_table tr[row !='2'][row !='1'][row !='0']").find('.add_Jobs').remove();
        else if (rowNo == "2") {
          if ($("#qc_table tr[row = '0']").find(".add_Jobs").length >= 1) {
            $("#qc_table tr[row !='2'][row !='4'][row !='0']").find('.add_Jobs').remove();
          } else {
            $("#qc_table tr[row !='2'][row !='4'][row !='1']").find('.add_Jobs').remove();
          }
        } else {
          $("#qc_table tr[row !='" + (Number(rowNo) + 2) + "'][row !='" + (Number(rowNo) - 2) + "'][row !=" + rowNo + "]").find('.add_Jobs').remove();
        }
      } else if (contextOption == 'Twin') {
        // Twin option is selected on Single job
        $(".job_list_twin_up").parents("tr").find('.add_Jobs').remove();
        $(".job_list_twin_down").parents("tr").find('.add_Jobs').remove();
        $(".job_list_tandem_up").parents("tr").find('.add_Jobs').remove();
        $(".job_list_tandem_down").parents("tr").find('.add_Jobs').remove();
        $("#qc_table tr[data-twinpick!='-1']").find('.add_Jobs').remove();
        $("#qc_table tr[row !='" + rowNo + "']").find('.add_Jobs').remove();
        $("#qc_table tr[tier !='" + tierNo + "']").find('.add_Jobs').remove();
        $("#qc_table tr[bayno !='" + (Number(bayNo) + 2) + "'][bayno!='" + (Number(bayNo) - 2) + "'][bayno!=" + bayNo + "]").find('.add_Jobs').remove();
      } else if (contextOption == 'Tandem') { // Tandem option is selected on Single job
    	console.log("bayNo " + bayNo);
    	console.log("tierNo " + tierNo);
    	console.log("rowNo " + rowNo);
        $("#qc_table tr[bayno!='" + bayNo + "']").find('.add_Jobs').remove();
        $("#qc_table tr[tier !='" + tierNo + "']").find('.add_Jobs').remove();
        $(".job_list_twin_up").parents("tr").find('.add_Jobs').remove();
        $(".job_list_twin_down").parents("tr").find('.add_Jobs').remove();
        $(".job_list_tandem_up").parents("tr").find('.add_Jobs').remove();
        $(".job_list_tandem_down").parents("tr").find('.add_Jobs').remove();
        if (rowNo == "1") {
          if ($("#qc_table tr[row = '0']").find(".add_Jobs").length == 1) {
            $("#qc_table tr[row !='3'][row !='0'][row !='1']").find('.add_Jobs').remove();
          } else {
            $("#qc_table tr[row !='3'][row !='1'][row !='2']").find('.add_Jobs').remove();
          }
        } else if (rowNo == "0") {
          $("#qc_table tr[row !='2'][row !='1'][row !='0']").find('.add_Jobs').remove();
        } else if (rowNo == "2") {
          if ($("#qc_table tr[row = '0']").find(".add_Jobs").length == 1) {
            $("#qc_table tr[row !='2'][row !='4'][row !='0']").find('.add_Jobs').remove();
          } else {
            $("#qc_table tr[row !='2'][row !='4'][row !='1']").find('.add_Jobs').remove();
          }
        } else {
          $("#qc_table tr[row !='" + (Number(rowNo) + 2) + "'][row !='" + (Number(rowNo) - 2) + "'][row !=" + rowNo + "]").find('.add_Jobs').remove();
          $(".job_list_twin_up").parents("tr").find('.add_Jobs').remove();
          $(".job_list_twin_down").parents("tr").find('.add_Jobs').remove();
          $(".job_list_tandem_up").parents("tr").find('.add_Jobs').remove();
          $(".job_list_tandem_down").parents("tr").find('.add_Jobs').remove();
        }
      }
      var addBtnLength = $("#qc_table tr").find('.add_Jobs').length
      if (addContainer.length == 2) {
        addBtnLength = Number(addBtnLength) - 1
      }
      // there are jobs to make twin tandem

      if (Number(addBtnLength) > 1) {

        $("#qc_table tr").off('contextmenu click dblclick'); //disabled click events

        $.each(addContainer, function(key, value) {
            $("#qc_table tr[data-container='" + value + "']").find('.add_Jobs').addClass('cross-icon').removeClass('add-icon');
          });

        $('#qc_table tr').find('.add_Jobs').removeClass("hidden").off('click').on('click', function() {
            addContainer.push($(this).parents('tr').data('container'));
            $(this).prop('disabled', true);
            if ( (contextOption == 'Twin' && addContainer.length == 2) || (contextOption == 'Tandem' && addContainer.length == 2 && Number(bayNo) % 2 == 0)) {
              $('.add_Jobs').addClass("hidden");
              mergeJobs('Twin', addContainer, "",mkind);
              //$('#search_joblist').hide();
            } else if (contextOption == 'Tandem') {
              var refercontainer = $(this).parents("tr").data('refercontainer');
              if (refercontainer.length > 0) {
                if (addContainer.length == 4) {
                  addContainer.pop();
                  $(this).prop('disabled', false);
                  showAlerts("not possible");
                } else {
                  $("#qc_table tr[data-container='" + refercontainer + "']").find('.add_Jobs').prop('disabled', true);
                  addContainer.push(refercontainer);
                }
              }

              if (addContainer.length == 4) {
                $('.add_Jobs').addClass("hidden");
                mergeJobs('Tandem', addContainer,"",mkind);
              }

            }
          })
        $('#qc_table tr').find('.cross-icon').off('click').on('click', function() {
            mergeJobs('Cancel', addContainer,"",mkind);
          });
      } else { // there are no jobs to make twin tandem
        showAlerts("There are no Jobs to make " + contextOption)
        $("#qc_table tr[data-tandempick ='-1']").find('.add_jobs_btn').html("<button class='add-icon hidden add_Jobs'></button>")
      }
    }
    // making twin tandem ends here
}

function operationNotPossible(operationType){
	if(operationType == TWIN_OPERATION){
		showAlerts("Twin is not possible for selected container");
	}else if(operationType == TANDEM_OPERATION){
		showAlerts("Tandem is not possible for selected container");
	}else{ // SPLIT_OPERATION
		showAlerts("Split is not possible for selected container");
	}
	
	operationPossible = false;
}

function initiateVariable(contextOption){

    if ($("#jobs_select").val() != "jobs_completed") {
      //  var cellIdVal =   lastClickedRow.attributes['cellId'].nodeValue;
      console.log(lastClickedRow);
      var jobType = lastClickedRow.attributes['jobType'].nodeValue;
      console.log(jobType)
      var targetContainer = lastClickedRow.attributes['data-container'].nodeValue;
      console.log(targetContainer)
      addContainer = [];
      addContainer.push(targetContainer);
      if (jobType == "planned") {
        //$("#qc_tab_context-menu ul").show();
        twinpick = lastClickedRow.attributes['data-twinpick'].nodeValue;
        console.log("twinpick " + twinpick);
        tandempick = lastClickedRow.attributes['data-tandempick'].nodeValue;
        console.log("tandempick " + tandempick);
        dataReferContainer = lastClickedRow.attributes['data-refercontainer'].nodeValue;
        console.log("dataReferContainer " + dataReferContainer);
        bayNo = lastClickedRow.attributes['bayno'].nodeValue;
        console.log("bayNo " + bayNo);
        tierNo = lastClickedRow.attributes['tier'].nodeValue;
        console.log("tierNo " + tierNo);
        rowNo = lastClickedRow.attributes['row'].nodeValue;
        console.log("rowNo " + rowNo);
        mkind = lastClickedRow.attributes['mkind'].nodeValue;
     //   console.log("mkind " + mkind);
        if (tandempick == "-1" && twinpick == "-1") { 
        	if (Number(bayNo) % 2 == 0) {
        		  if(contextOption == "Twin"){
	          		  operationNotPossible(TWIN_OPERATION)
	          		  return false;
          		  }
              } else {
            	  if(contextOption == "Tandem"){
            		  operationNotPossible(TANDEM_OPERATION)
            		  return false;
            	  }
              }
        } else if (tandempick == "-1") { 
          if (Number(bayNo) % 2 == 1) //When the container is 20 ft
          {
            contexttandem = ""
            if(contextOption == "Twin"){
        		  operationNotPossible(TWIN_OPERATION)
        		  return false;
    		 }
          }else {
        	  
             contexttandem = "TANDEM_SPLIT"
             if(contextOption == "Twin"){
       		  operationNotPossible(TWIN_OPERATION)
       		  return false;
	   		 }else if(contextOption == "Tandem"){
	      		      operationNotPossible(TANDEM_OPERATION)
	   		      return false;
	   	     }
          }
          addContainer.push(dataReferContainer);
        } else { //When the container is Tandem
          contexttandem = "TANDEM_SPLIT"
          containerlist = dataReferContainer.split("#")
          for (i = 0; i < containerlist.length; i++) {
            addContainer.push(containerlist[i]);
          }
          if(contextOption == "Twin"){
          	operationNotPossible(TWIN_OPERATION)
          	return false;
   		  }else if(contextOption == "Tandem"){
      		operationNotPossible(TANDEM_OPERATION)
   		    return false;
   	      }
        }
      } else if (jobType == "plc") {
        showAlerts("Can't make Twin or Tandem")
        return false;
      } else if (jobType == "manual") {
        //$("#qc_tab_context-menu ul").show();
      }
    } else {
      return false;
    }
}

function highlightJobs(){
	$("#qc_table tr").removeClass('promoted_job');
	$("#qc_table tr.active").addClass('promoted_job');
}

function promoteJob(){
	var value = $("#jobs_select").val();
    if(value == "jobs_completed" || value == "backreach_jobs" || value == "exception_joblist"){
    	showAlerts("This operation is not possible");
    	return false;
    }
    
    confirmAction('promote_job');
}

function sendPromoteJobNotification(){
	
	var selectedJob =  $("#qc_table tr.active:first"), k = 0;
	var selectedContainers = "";
	
	$( "#qc_table tr.active" ).each(function( index ) {
	  selectedContainers +=  $( this ).data('container') + "~";
	});
	
	if(selectedContainers != ""){
		selectedContainers = selectedContainers.slice(0, -1);
	}
	
	$.ajax({
		url: "/app/Hc/promote_jobs",
		data: {
			containerId: selectedJob.data('container'),
			moveType: selectedJob.attr('mkind'),
			containers: selectedContainers
		},
		success: function(result) {
			if(result == 'true'){
				highlightJobs();
			}else if(result == 'error'){
				Rho.Log.error("Unexpected response", "javascript");
			}else{
				showAlerts(result);
			}
			
		},
		error: function(err){
			Rho.Log.error("Error during promote job", "javascript");
		}
	});
}
