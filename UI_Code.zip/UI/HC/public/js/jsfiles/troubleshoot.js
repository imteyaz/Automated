//@ sourceURL=troubleshoot.js

$(document).ready(function() {
	
	virtualKeyboard();
	$(".troubleshoot_dropdown").msDropdown({ roundedBorder: false });


	//search method
	$.extend($.expr[":"], {
			"containsIN": function(elem, i, match, array) {
				return (elem.textContent || elem.innerText || "").toLowerCase().indexOf( (match[3] || "").toLowerCase()) >= 0;
			}
		});
	$("#search_troubleshoot").change(function() {
		var value = $('#search_troubleshoot').val();
		if (value.length == 0)
			$('#troubleshoot_table tr').show();
		else {
			$("#troubleshoot_table tr:not('#troubleshoot_table .tableheader')").hide();
			$("#troubleshoot_table td.searchItem:containsIN('" + value + "')").parents("#troubleshoot_table tr").show();
		}
	});

});

$('.container_info').on('click', function(e) { // Adding class when container or to location is getting clicked.
	$(".container_info").removeClass("selected_container")			
	$(this).addClass("selected_container")
	$(this).addClass("container_is_selected")
	$(".container_info").each(function() {
		if (!$(this).hasClass("container_is_selected")) {
			$(this).children("td").children('input').removeClass("cntr_selected");
		}
	})
	$(this).children('td').children('input').addClass("cntr_selected");
	$(".container_info").children('td').children('input').removeClass("current_selected_container")
	$(this).children('td').children('input').addClass("current_selected_container")
	
	$("#troubleshoot_table .regular-checkbox").each(function(){
			$(this).attr("checked",false)
		});
		
	$("#troubleshoot_table .regular-checkbox").each(function(){
	var trbleSht_code = $(this).attr("troubleshoot_area")
		var is_selected = false;
		$(".selected_container").next().children("td").children(".ts_code_desc").children(".ts_code").each(function() {
			if ($(this).html() == trbleSht_code) {
				is_selected = true;
				return false;
			} else {
				is_selected = false;
			}
		});
		if (is_selected) {
			$(this).prop("checked", true)
		}
	});
			
});

// function to send and getting the clicked container with to location,troubleshoot area and code.
function sendTroubleShootReq(movekind) {
	var selected_containers = [];
	var selected_to_location = [];
	var trouble_shoot_area = [];
	var troubleshoot_code = [];
	var movekind = "";
	movekind = $(".itv_cntr_no").find("span[name='toData']").attr('movekind');
	console.log("movekind"+movekind);
	
	var sealOkDetails = "";
	if (seal_ok_clicked == true) {
		$(".ContrDetails .contrBtnFun").each(function() {
			if ($(this).hasClass("cntr_selected")) {
				sealOkDetails += "N|";
			} else {
				sealOkDetails += "Y|";
			}
		});

		seal_ok_clicked = false;
	} else {
		for (var i = 0; i < $(".ContrDetails").length; i++) {
			sealOkDetails += "Y|";
		}
	}

	$("#hidden_seal_ok").val(sealOkDetails);


	if ($(".ContrDetails .cntr_selected").length <= 0) {
		showAlerts('Please select a container.');
		return;
	}

	$(".ContrDetails .cntr_selected").each(function() {
		if ($(this).hasClass("contrBtnFun")) {
			selected_containers += $(this).val() + $(this).parent().parent().find(".troubleshoot_dropdown").val()+ "|";
			console.log("selected_containers"+selected_containers);
		} else if ($(this).hasClass("itvBtnFun")) {
			selected_to_location = $(this).val();
			console.log("selected_to_location"+selected_to_location);
		}
	});

	if ($(".regular-checkbox:checked").length <= 0) {
		showAlerts('Please select a Trouble shoot area.');
		return false;
	}

	var troubleshoot_area = "";

	$(".regular-checkbox").each(function() {
		if (this.checked) {
			troubleshoot_area += $(this).parent().parent().find(".troubleshoot_area h4").html() + "|";
			console.log("troubleshoot_area"+troubleshoot_area);
		}
	});

	closePopup();

	$.ajax({
		type: "POST",
		url: "/app/Hc/sendTroubleShootReq",
		data: {
			selected_containers: selected_containers,
			selected_to_location: selected_to_location,
			troubleshoot_area: troubleshoot_area,
			movekind: movekind
		},
		success: function(result) {
			troubleDamageClicked = true;
			$(".tally_confirm").click();
		}
	});
}
