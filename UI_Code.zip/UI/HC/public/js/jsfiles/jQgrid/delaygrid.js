function get_select_values(){
	return {
		value:"101:ISO1;102:ISO3434;103:ISO3",
		dataInit: function (elem) {
		
			$(elem).addClass('combobox');
			$(elem).attr('type', 'text');
			$(".combobox").combobox();
			setTimeout(virtualKeyboard, 500);
		}
	}	
}
$(document).ready(function() {
	var mydata = [{
			container: "WWW111000",
			iso: "ISO1",
			remarks: "Damaged Conatiner",
			date: ''
		}, {
			container: "DDDDDEEE23",
			iso: "ISO1",
			remarks: "Seal is not OK",
			date: ''
		}, {
			container: "55423772",
			iso: "ISO2",
			remarks: "Refeer Container",
			date: ''
		}, {
			container: "SAASDH233424",
			iso: "TRTW",
			remarks: "Hazardous container",
			date: ''
		}]
	var initDate = function (elem) {
        $(elem).datetimepicker({
            dateFormat: 'dd-M-yy',
            timeFormat: 'HH:mm:ss',
            separator: ' ',
            timezone: '000',
            autoSize: true,
            changeYear: true,
            changeMonth: true,
            showButtonPanel: true,
            showWeek: false,
            onSelect: function () {
                var $grid, grid;
                if (typeof (elem.id) === "string" && elem.id.substr(0, 3) === "gs_") {
                    $grid = $(elem).closest('div.ui-jqgrid-hdiv')
                                .next('div.ui-jqgrid-bdiv')
                                .find("table.ui-jqgrid-btable:first");
                    if ($grid.length > 0) {
                        grid = $grid[0];
                        if ($.isFunction(grid.triggerToolbar)) {
                            grid.triggerToolbar();
                        }
                    }
                } else {
                    $(elem).trigger('change');
                }
            }
        });
        if ($(elem).val().length === 0) {
            $(elem).datepicker("setDate", new Date(2016, 06, 30));
        }
    },
	dateTemplate = {align: "center", sorttype: "date", width: 124,
        editable: true, editoptions: { dataInit: initDate },
        formatter: "date", formatoptions: { srcformat: "ISO8601Long", newformat: "d-M-y H:i" }}
	jQuery("#delayRec").jqGrid({
		data: mydata,
		datatype: "local",
		height: 200,
		colNames: ["CONTAINER", "ISO", "REMARKS", "Date","Actions"],
		colModel: [
		{ name: 'container', index: 'container', editable: true, width: 150, resizable: false },
		{ name: 'iso', index: 'iso', editable: true, width: 150, resizable: false,edittype:"select",editoptions:get_select_values()}, 
		{ name: 'remarks', index: 'remarks', editable: true, width: 300, resizable: false, editable: true },
		{ name: 'date', index: 'date', width: 300, resizable: false,  template: dateTemplate },
		{ name: 'act', index: 'act', width: 150, sortable: false }],
		autowidth: true,
		shrinkToFit: false,
		forceFit: true,
		// adding tool bar at top
		//   toppager: true,
		toolbar: [true, "top"],
		gridComplete: function() {
			prepare_actions_for_grid();
		},
		editurl: 'clientArray'
	});
	jQuery("#delayRec").jqGrid('navGrid', '#delyPager01', { edit: false, add: false, del: false, search: false }, { height: 200, reloadAfterSubmit: false });

	// add button at tool bar
	$("#t_delayRec").append("<img src='../../public/images/add_new.png' style='height:50px;width:60px;' onclick='addFunction()'/>");

	// Define grid data when grid page load
	//	for (var i = 0; i <= data.length - 1; i++) {
	//		jQuery("#delayRec").jqGrid('addRowData', i + 1, data[i]);
	//	}
	//
});

function toggle_save_btn(act_type) {
	$(".editable").parents("tr").find(".edit_btn").toggle();
}
