//@ sourceURL=assignment_confirmation.js
$(document).ready(function() {
	virtualKeyboard();
	var rotation_name = "";
	var default_options_equipmentId = $("#msg_equipmentId").html();
	$("#selectRotationId").msDropdown({ roundedBorder: false });
	$("#msg_equipmentId").msDropdown({ roundedBorder: false });
	var hdnRotationDetails = $("#hdnRotationDetails").val();
	var hdnAllQCsArray = [];
	var rotations = hdnRotationDetails.split("|");
	var rotationObj = { };
	
	
	for (var i = 0; i < rotations.length; i++) {
		var values = rotations[i].split("^")[2].split("#");
		var name = rotations[i].split("^")[0];
		hdnAllQCsArray.push(name);
		rotationObj[name] = values;
	}
	var selectRotationId = $("#selectRotationId"),
		selectEquipmentId = $("#msg_equipmentId");
	var selectEquipments = selectEquipmentId.find('option').clone();
	var equipmentOptions = $("#msg_equipmentId_child ul").html();
	selectRotationId.change(function() {
		$("#msg_equipmentId").msDropDown().data("dd").destroy();
		$("#rotation_select")[0].value = $("#selectRotationId_title .ddlabel").html();
		rotation_name = $("#selectRotationId").find(':selected').data('name');
		var selectedRotationText = $("#rotation_select").val().split(" ")[0];
		var option_selectedId = "";
		for (var i = 0; i < rotationObj[selectedRotationText].length; i++) {
			option_selectedId += '<option>' + rotationObj[selectedRotationText][i] + '</option>';
		}

		$("#msg_equipmentId").html(option_selectedId);
		$("#msg_equipmentId").msDropdown().data("dd").refresh();
	});
	$('#rotation_select').change(function() {
		rotation_name = "";
	});
	$(".rotationInput").on("keyup", function() {
			$("#msg_equipmentId").msDropDown().data("dd").destroy();
			$("#msg_equipmentId").html(default_options_equipmentId);
			$("#msg_equipmentId").msDropdown().data("dd").refresh();

		});

	$('select[value]').each(function() {
		$(this).val(this.getAttribute("value"));
	});

	hideSelectOptions();
	$('#sel1').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Non-Operational") {
			$('#sel2').removeClass('hidden');
			$('#otherOptText').parents('.reason_delay').removeClass('hidden');
		} else {
			hideSelectOptions();
		}
	});

	$('#sel2').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Other") {
			$('#otherOptText').removeClass('hidden');
			$('#otherOptText').parents('.reason_delay').removeClass('hidden');
		} else {
			$('#otherOptText').addClass('hidden');
		}
	});

	function hideSelectOptions() {
		$('#sel2').addClass('hidden');
		$('#otherOptText').addClass('hidden');
		$('#otherOptText').parents('.reason_delay').addClass('hidden');
	}
	//    $(".form-control").on('click',function(){
	//    	$(".chosen-select option").append($(".form-control").val());
	//    	//alert('Called ');
	//	});
	//

	$('#confirm_allocation').on('click', function(e) {
			//if($('#rotation_select').val()==="" || $('#rotation_select').val()===null || $('#msg_locationId').val()==="" || $('#msg_locationId').val()===null || $('#msg_equipmentId').val()==="" || $('#msg_equipmentId').val()===null || $('#msg_terminalId').val()=="" || $('#msg_terminalId').val()===null ) {
			if ($('#rotation_select').val() === "" || $('#rotation_select').val() === null || $('#msg_equipmentId').val() === "" || $('#msg_equipmentId').val() === null || $('#msg_terminalId').val() == "" || $('#msg_terminalId').val() === null) {
				showAlerts("Please fill all fields");
				e.preventDefault();
				//prevent the default action
			} else {
				var allocation = $(".assign_confirmation :input").serialize();
				allocation = allocation + "&msg_rtname=" + rotation_name;
				console.log(allocation);
				$('#confirm_allocation').attr("disabled", true).addClass("disable_btns");
				$('.login_exit').attr("disabled", true).addClass("disable_btns");
				$.ajax({
					type: "POST",
					url: "/app/Login/checklist",
					data: allocation,
					success: function(result) {
						if (result != 'Error') {
							$(".main_layout").html("");
							$(".main_layout").html(result);
						} else {
							$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
							$('.login_exit').attr("disabled", false).removeClass("disable_btns");
						}
					}
					,
					error: function() {
						$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
						$('.login_exit').attr("disabled", false).removeClass("disable_btns");
					}
				});
			}
		})

	$('.chosen-select').chosen({ });
}); 