$(document).ready(function() {
	
	$('.user-toggle').click(function() {
		$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
		$('.user-toggle').css("border", "0px");
		var collapse_content_selector = $(this).attr('href');
		var toggle_switch = $(this);
		$(collapse_content_selector).toggle(function() {
			if ($(this).css('display') == 'none') {
			}
		});
	});
	$("input[type='checkbox']").attr('checked', 'checked');
	
	
	
	function getCompletedJobs(){
		$.ajax({
			type: "POST",
			url: "/app/Hc/getcompletedjobs",
			success: function() {
			},
			error: function() {
				console.log("error getting completed jobs");
			}
		});
	}

	$('#cnfrmbtn').on('click', function() {
			var checklist = $(".chklist :input").serialize();
			$('#cnfrmbtn').attr("disabled", true).addClass("disable_btns");
			$.ajax({
				type: "POST",
				url: "/app/Login/hc_home",
				data: checklist,
				success: function(result) {
					if (result != "Error") {
						$(".main_layout").html("");
						$(".main_layout").html(result);
						getCompletedJobs();
						
					} else {
						$('#cnfrmbtn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					$('#cnfrmbtn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		})

	$('#cancelbutn').on('click', function() {
			var checklistcancel = $(".chklist :input").serialize();
			$('#cancelbutn').attr("disabled", true).addClass("disable_btns");
			$.ajax({
				type: "POST",
				url: "/app/Login/cancel",
				data: checklistcancel,
				success: function(result) {
					if (result != "Error") {
						$(".main_content").html("");
						$(".main_content").html(result);
					} else {
						$('#cancelbutn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					$('#cancelbutn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		})

});