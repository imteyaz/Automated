//@ sourceURL=qcindex.js
var allAlerts = [];

$('#progressbar').progressbar();
var m = 0;
var tempObj = { };
var initialJoblistHeight = 0;

var lastClickedRow = "";

var myVar = setInterval(function() {
		// myTimer()
	}, 1000);
var no_of_times = 0;
var swap_first_click = true;
var qchome_time;
var troubleDamageClicked = false;
var seal_ok = false;
var container_confirm = true, refreshJobs = false;
function myTimer() {
	$.ajax({
		type: "POST",
		url: "/app/Login/containercheck",
		success: function(result) {

			if (result != "") {

				shufflejobs(result)
			}
		}
	})
}

function stoptimer() {
	clearInterval(myVar)
}

function resettimer() {
	myVar = setInterval(function() {
			myTimer()
		}, 5000);
}

function recordDelay(){
	$.ajax({
		url: "/app/Hc/get_manual_delay_data",
		success: function(result) {
			$('.modal_hidden_html').html("")
			$('.modal_hidden_html').append(result)	
			$( ".modal-dialog" ).html("");
			//$("#delayrecording_data").msDropdown({ roundedBorder: false });
			//document.getElementById('light').style.display = 'block';	
			$( ".modal-dialog" ).append($( ".modal-content" ));
		}
	});
}

function addRemoveDamageIcon(addRemoveDamageIconMsg){
	addRemoveDamageIconMsg = addRemoveDamageIconMsg.split("#");
	if(addRemoveDamageIconMsg[1] == "true"){
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").addClass("damage");
	}else{
		$("#qc_table tr[data-container='"+addRemoveDamageIconMsg[0]+"'] td:last").removeClass("damage");
	}
}

function  highLightITVWhenArrived(itvArrivedMsg)
{
	var referDetails = itvArrivedMsg.split('#');
	//$('#itvArrivedbuttonClickId').html("");
	
	var ITVsize = "";
	
	if($(".container_details").length > 3) {
		ITVsize = "cntr_no_4_cntrs";
	} else {
		ITVsize = "cntr_no_2_cntrs";
	}
	
	$(".cntr_no" + referDetails[0]).remove();
	var htmlContent="";
	htmlContent = "<div class='cntr_no " + ITVsize + "  cntr_no" + referDetails[0] + "' name='" + referDetails[3] + "' style='background-color: #" +  referDetails[4] +"'>";
	htmlContent = htmlContent + "<div class='cntr itv_truck_number' name='cntr'>"+referDetails[0]+"</div>";
	htmlContent = htmlContent + "<div class='truck_number'>"+referDetails[1]+"</div>";
	htmlContent = htmlContent + "<div class='total_jobs_cntr'>"+referDetails[2]+"</div></div>";
	
	$('.itv_poolview').append(htmlContent);
	
	$(".cntr_no").click(function() {
	    itvNo = $(this).find(".itv_truck_number").text();
	    $("#itv_select").val("");
	    console.log("updatepool_row_first");
	    setTimerForEdit();
	    $.ajax({
	           type:   "POST",
	           selected_container: selected_cont,
	           url:  "/app/Login/change_contr_edit_val",
	           success:function(result){
	           console.log(result)
	           }
	       })
	    updateCntrITVNo(itvNo);
	  });
}

function shufflejobs(messageresult) {
	console.log("messageresult"+messageresult)
	var messagedetails = messageresult.split("~")
	console.log("messagedetails"+messagedetails)
	var result = messagedetails[0]
	console.log("result" +result)
	if (result == "HVY_HK_TRUE") {
		$("#hvy_hook").css("color", "red");
	} else if (result == "HVY_HK_FALSE") {
		$("#hvy_hook").css("color", "rgb(113, 115, 119)");
	} else if (result == "PLC_TRUE") {
		$("#plc_active_deactive").addClass("moves_plc_active");
	} else if (result == "PLC_FALSE") {
		$("#plc_active_deactive").removeClass("moves_plc_active");
	} else if (result == "PLC_JOB_DONE") {
		var value = $("#jobs_select").val();
		$('#search_joblist').val('');
		refreshJobs = true;
		console.log("message: " + messagedetails[1]);
		processjoblist(0, 0, 0, messagedetails[1], "plcjobdone")
		$(".table_data_qc tr").removeClass('selevn clicked')
		resettimer("#job_timer");
	} else if (result == "NORMAL_ALERT_MESSAGE") {
		processnormalalertmessage(messagedetails[1], messagedetails[2]);
	} else if (result == "DELAY_RECORDING") {
		processdelayrecording(messagedetails[1])
	} else if (result == "LANGUAGES") {
		language_sellection(messagedetails[1]);
	} else if (result == "CONTAINER_HANDLING_TRUE") {
		$(".qc_rows").removeClass("selevn");
		processcontainerhandling(messagedetails[1], 'false')
		$(".hc_joblist_table tr").removeClass("active")

		var cntrNos = messagedetails[1].split("|")
		for (i = 0; i < cntrNos.length; i++) {
			$(".hc_joblist_table tr[data-container='" + cntrNos[i] + "']").addClass("active")
		}
	} else if (result == "BACKREACH_CONTAINER_MOVE") {
		backreachcontainermove(messagedetails[1]);
	} else if (result == "REFRESH_JOBS") {
		var value = $("#jobs_select").val();
		$('#search_joblist').val('')
		//refreshJobs = true;
		processjoblist(0, 0, 0, value, 'filter')
	} else if (result == "IT_LEFT") {
		removeITV(itvNumber);
	} else
		processjoblist(0, 0, 0, result, "shuffle")
}

function process_poll_request_timer() {
	$.ajax({
        type:   "POST",
        url:  "/app/Login/process_poll_request",
        success:function(){
        }
    })
}

$(document).ready(function() {
	virtualKeyboard();
	
	$("#jobs_select").off('change').on('change', function() {
	    var value = $(this).val();
	    if(value == "jobs_completed" || value == "backreach_jobs" || value == "exception_joblist"){
	    	$(".btn_make_twin, .btn_make_tandem, .btn_make_split, .btn_promote_job").removeClass("action_btn").addClass("disable_btns");
	    }else{
	    	$(".btn_make_twin, .btn_make_tandem, .btn_make_split, .btn_promote_job").css("display", "inline-block").removeClass("disable_btns").addClass("action_btn");
	    }
	    
	    $('#search_joblist').val('')
	    processjoblist(0, 0, 0, value, 'filter')
	  });
	
	//$("#jobs_select").combobox();
	//virtualKeyboard();
	$("#jobs_select").msDropdown({ roundedBorder: false });
	$('.user-toggle').click(function() {
		$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
		$('.user-toggle').css("border", "0px");
		var collapse_content_selector = $(this).attr('href');
		var toggle_switch = $(this);
		$(collapse_content_selector).toggle(function() {
			if ($(this).css('display') == 'none') {
			}
		});
	});

	$('#nav-toggle1').click(function() {

		var collapse_content_selector = $(this).attr('href');

		var toggle_switch = $(this);
		$(collapse_content_selector).toggle(function() {
			if ($(this).css('display') == 'none') {

			}
		});
	});

	job_timer("#job_timer");
	processjoblist(0, 0, '', 'current_jobs', 'jobdone');
	p = parseInt($('#completedMoves').html());

	//search method
	$.extend($.expr[":"], {
			"containsIN": function(elem, i, match, array) {
				return (elem.textContent || elem.innerText || "").toLowerCase().indexOf( (match[3] || "").toLowerCase()) >= 0;
			}
		});

	$("#search_joblist").change(function() {
		var value = $('#search_joblist').val();
		if (value.length == 0)
			$('#qc_table tr').show()
		else {
			$("#qc_table tr:not('#qc_table .tableheader')").hide();
			$("#qc_table td.joblist_searchItem:containsIN('" + value + "')").parents("#qc_table tr").show();

		}
	});

//	$('.icon_waiting').click(function() {
//		$.ajax({
//			url: "/app/Login/getunavlblereasons",
//			data: {
//				popupType: "unavilable"
//			},
//			success: function(result) {
//				$('#light').html("")
//				$('#light').html(result)
//				$("#rms_select").msDropdown({ roundedBorder: false });
//				document.getElementById('light').style.display = 'block';
//			}
//		});
//	});

});

function sendOrphanContainerData() {
	var containerNo = $("#orphanContainerNo").val();
	
	if(containerNo == "") {
		showAlerts("Please enter container number");
		return;
	}
	
	var isoCode = "";
	if($(".iso_btns.btn-primary").length > 0) {
		isoCode = $(".iso_btns.btn-primary").html();
	} else if($("#iso_data_1").val() != "") {
		isoCode = $("#iso_data_1").val();
	} else {
		showAlerts("Please select iso code");
		return;
	}
	
	var toLocation = "";
	if($("#itv_select_cnt .ui-autocomplete-input").val() != "") {
		toLocation = $("#itv_select_cnt .ui-autocomplete-input").val();
	} else {
		return;
	}
	
	sendNewContainerData(containerNo, isoCode, toLocation, 2, "")
}

function sendNewContainerData(containerNo, isoCode, selectedItv, requestType, fromLocation) {
	
	if(fromLocation == "") {
		fromLocation = "VESSEL";
	}
	
	$.ajax({
		url: "/app/Hc/send_out_of_list_container",
		data: {
			containerNo: containerNo,
			isoCode: isoCode,
			selectedItv: selectedItv,
			requestType: requestType,
			fromLocation: fromLocation
		},
		success: function(result) {
			if(result != "error") {
				if(result == "true") {
					closePopup();
				} else {
					showAlerts(result);
				}
			}
		},
		error: function() {
			
		}
	});
}

function setDoorDirection(){
    var selectedContainer = $(".selected_container"), DOOR_FORWARD = "FORWARD", DOOR_AFT = "AFT", FORWARD_CLASS = "door_forward",
	    AFT_CLASS = "door_aft";

    	
  if ($('.btn_door_direction').hasClass(AFT_CLASS)) {
    $('.btn_door_direction').removeClass(AFT_CLASS).addClass(FORWARD_CLASS).html("Door<br/>Direction<br/>Forward");
    selectedContainer.find(".hdn-door-direction").val(DOOR_FORWARD);
    doorInfo = DOOR_FORWARD;
  } else {
    $('.btn_door_direction').removeClass(FORWARD_CLASS).addClass(AFT_CLASS).html("Door<br/>Direction<br/>Aft");
    selectedContainer.find(".hdn-door-direction").val(DOOR_AFT);
    doorInfo = DOOR_AFT;
  }
  
  containerNumber = selectedContainer.find(".tally_cntrno").html();
  
    $.ajax({
        url: "/app/Hc/update_container_door_info",
        data: {
          container: containerNumber, 
          doorInfo: doorInfo
        },
        success: function() {
        }
      })
}

function changeDoorDirection() {
	var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
	var selectedContainer = $(".selected_container")
	
	if($('.hdn-movekind').val() != "DSCH"){
		showAlerts("Door direction change is not possible for Load operation");
		return false;
	}
	
	if(selectedContainer.length > 0){
		confirmAction('door_direction'); 
    }else if((backreachContnr.indexOf("HATCHCOVER")!= -1) || (backreachContnr.indexOf("MANCAGE")!= -1) || (backreachContnr.indexOf("BREAKBULK")!= -1)){
      showAlerts("Seal off/on is not possible for backreach job");
    }else{
      showAlerts("Please select a container");
    }

}

function sendUnavailableRes() {
	var rms_select = $("#rms_select").val()
	console.log("rms_select"+rms_select)
	var timerVal = $("#rms_timer").text();
	if (rms_select == "") {
		showAlerts("Please fill all the details")
	} else {
		//closePopup();
		$.ajax({
			url: "/app/Login/sendUnavailableRes",
			data: {
				popupType: "available",
				rms_select: rms_select,
				available_time: timerVal
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				console.log("ajax success")
				$("#rms_timer").runner({
					autostart: true,
					milliseconds: false
				});
			}
		});
	}

}
function sendAvailableRes() {
	var timerVal = $("#rms_timer").text();
	closePopup()
	$.ajax({
		type: "POST",
		url: "/app/Login/sendAvailableRes",
		data: {
			available_time: timerVal
		},
		success: function(result) { }
	});
}
function closePopup() {
	$('#light').html("")
	document.getElementById('light').style.display = '';
}

function refreshContainer() {
	var cont = "";
	 console.log("refreshContainer called");
	
	if(selected_cont == ""){
		cont = $(".qc_rows:first").attr('data-uniquejobid');
	}
	else{
		cont = selected_cont;
	}
	
	var $tableRows = $(".hc_joblist_table tr");
	
	$tableRows.removeClass("active");
	

	processcontainerhandling(cont, 'true');
	
	makeRowActive();
}


function makeRowActive(){
    var $tableRows = $(".hc_joblist_table tr");
    var currentRow = "";
    
    if(selected_cont == ""){
    	currentRow = $(".qc_rows:first");
	}
	else{
		currentRow = $(".qc_rows[data-uniquejobid='" + selected_cont +"']");
	}
    
    var v = currentRow.data('refercontainer');
    var container = currentRow.data('uniquejobid');
    var hdn_cntr_val = currentRow.data('container')
    $("#hidden_container_no").val(hdn_cntr_val);
    $tableRows.removeClass("active");
    $(".qc_rows").removeClass("active");
    $("#qc_table tr[data-uniquejobid='" + container + "']").addClass("active")
    v = v.split('#');
    for (x = 0; x < v.length; x++)
      $("#qc_table tr[data-container='" + v[x] + "']").addClass("active")
  
  }

function removeITV(itvNumber) {

	$(".itv_poolview .cntr_no").each(function() {

		var currentITVNumber = $(this).find(".itv_truck_number").text();
		if (currentITVNumber == itvNumber) {

			var currentClass = '.cntr_no' + currentITVNumber;
			$(this).parent().find(currentClass).remove();
		}
	});

}

function send_data(containers, celllocation, itvnos, movekind, baycelllocation, prev_locations, sealInformation, containerPositions, categoryInfo) {
	var value = $("#jobs_select").val();
	$('#search_joblist').val('')

	$(".main_layout").mask("Loading...");
	if (movekind == 'DSCH') {
		processjoblist(containers, celllocation, itvnos, value, 'jobdone', sealInformation, containerPositions, categoryInfo);
	} else {
		processjoblist(containers, itvnos, celllocation, value, 'jobdone', sealInformation, containerPositions, categoryInfo);
		resettimer("#job_timer");
	}

	//$("#jobs_select").val("current_jobs");
	//$("#jobs_select").change();
}

function processjoblist(container, from_location, to_location, contritv, reqtype, sealinformatioData, containerPositions, categoryInfo) {
	$.ajax({
		type: "POST",
		url: "/app/Login/joblist",
		data: {
			container_id: container,
			from_location: from_location,
			to_loc: to_location,
			containeritvinfo: contritv,
			reqtype: reqtype,
			troubleDamageClicked: troubleDamageClicked,
			seal_ok: seal_ok,
			seal_ok_data: sealinformatioData,
			select_value: $("#jobs_select").val(),
			containerPositions: containerPositions,
			categoryInfo: categoryInfo
		},
		success: function(result) {
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
//			if (reqtype == 'jobdone') {
//				$("#jobs_select").val("current_jobs");
//			}
			$(".main_layout").unmask();
			refreshContainer();
			if (container_confirm || refreshJobs) {
				//var oDropdown = $("#jobs_select").msDropdown().data("dd");
				//oDropdown.set("selectedIndex", 1);
				container_confirm = false;
				refreshJobs = false;
			}
		},
		error: function() {
			$(".main_layout").unmask();
		}
	})
}

function change_filter() {
	$("#jobs_select").val("current_jobs");
	$(".qc_list #jobs_select_title").click();
	$("#jobs_select").click();
	$(".qc_list ul li").removeClass("selected");
	$(".qc_list ul li").eq(1).addClass("selected");
}

function processjobdone() {
	$.ajax({
		type: "POST",
		url: "/app/Hc/container_handling",
		success: function(result) {
			$("#container_handlediv").html("")
			$("#container_handlediv").html(result)
		}
	})
	return false
}

function HatchcoverMancageBreakbulk_Request(request_type, mode) {
	$('#nav-toggle1').css("background-color", "#0563a0");
	$.ajax({
		type: "POST",
		url: "/app/Hc/HatchcoverMancageBreakbulk_Request",
		data: {
			request_type: request_type,
			mode: mode,
			filter: $("#jobs_select").val()
		},
		success: function(result) {
			$('#tabledataid').html("")
			$('#tabledataid').html(result);
			//var oDropdown = $("#jobs_select").msDropdown().data("dd");
			//oDropdown.set("selectedIndex", 1);
		}
	})
	return false
}

function processcontainerhandling(message, manualconfirm) {
	seal_ok_clicked = false;
	console.log("message"+message)
	if (typeof (message) != "undefined") {
		$(".main_layout").mask("Loading...");
		message = message.toString();
		container = message.split(">")[0];
		exception_reason = message.split(">")[1];
		message = message.split('^');
		
	
		if (message != "") {
			$.ajax({
				type: "POST",
				url: "/app/Hc/container_handling",
				data: {
					container: message[0],
					manual_confirm: manualconfirm,
					exception_reason: exception_reason,
					troubleDamageClicked: troubleDamageClicked,
					movekind: message[1]
				},
				success: function(result) {
					$("#container_handlediv").html("")
					$("#container_handlediv").html(result)
					$(".main_layout").unmask();
					if (manualconfirm == 'false') {
						$(".update_attr_check").hide()
						$(".icon_trouble_shoot").hide()
					} else {
						$(".update_attr_check").show()
						$(".icon_trouble_shoot").show()
					}
				},
				complete: function() {
					 var mk_for_manual_jobs = $(".active").find("#container_width").text();
					   var currentJobFilterName = $("#jobs_select").val();
					     if((currentJobFilterName == "jobs_completed" || currentJobFilterName == "backreach_jobs" ) && (mk_for_manual_jobs.match("MANCAGE") || mk_for_manual_jobs.match("HATCHCOVER") || mk_for_manual_jobs.match("BREAKBULK"))){
					       if($(".itv_cntr_no:first").attr("cntrcode") == "DSCH")
					         {
					           $(".swap_numbers").hide();
					       }
					     }
					$(".main_layout").unmask();
					
				},
				error: function() {
					$(".main_layout").unmask();
				}

			})
		} else {
			$(".main_layout").unmask();
		}
	} else {
		$(".container_handling_hc").html("<p style='margin: 50% 0% 10% 20%;'>There is no container to confirm</p>");
		$(".main_layout").unmask();		
	}
	return false
}

function processdelayrecording(messagedetails) {
	$.ajax({
		type: "POST",
		url: "/app/Hc/delay_recording",
		data: {
			delayrecordingmessage: messagedetails
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			$("#delayrecording_data").msDropdown({ roundedBorder: false });
			document.getElementById('light').style.display = 'block';
		}
	})
	return false
}

function delay_recording() {
	var delayrecording_reason = ($("#delayrecording_data").val()).split("-")[0];
	if (delayrecording_reason == "") {
		showAlerts("Please fill all the details");
	} else {

		closePopup();
		$.ajax({
			type: "POST",
			url: "/app/Hc/delayrecordingreason",
			data: {
				delayrecording_reason: delayrecording_reason
			},
			success: function(result) { }
		})
	}
	return false
}

var alertCount = 0;

function processnormalalertmessage(messagedetails, expiryTime) {
 	var alerts = "";
    alerts = messagedetails;
	allAlerts.push(alerts);
	alertCount += 1;
	var i, FLDAlerts="";
	
	displayAllAlerts();
	setTimerForAlerts(expiryTime);
	console.log("FLDAlerts" +FLDAlerts)
	$(".qc_rows[data-container]").attr("exception_reason", messagedetails.split(":")[1])
}

function setTimerForAlerts(expiryTime) {
	(function(k) {
	       setTimeout(function(){
	    	   console.log("stopping alertCount " + k);
			   allAlerts[k - 1] = "";
			   displayAllAlerts();
	       }, expiryTime * 1000);
	 })(alertCount);
}

function displayAllAlerts() {
	var FLDAlerts="";
	for (i = 0; i < allAlerts.length ; i++) {
		if(allAlerts[i] != "") {
			FLDAlerts += allAlerts[i] + "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;";
		}
    }
	
    console.log("FLDAlerts" +FLDAlerts)
	$("#alerts").html("");
	$("#alerts").html(FLDAlerts)
}

var alertClick = 1;
$('.qc_alerts').on("click",function(){ 
	console.log(" alert clkd")
	if(alertClick == 1){
		document.getElementById("alerts").stop();
		alertClick = 2;
	}else{
		document.getElementById("alerts").start();
		alertClick = 1;
	}
	
})

function updateQCfields(messagedetails) {
	var qcviewattributes = messagedetails.split("|")
	$("#moves_to_go").text(qcviewattributes[3])
	$("#target_compl_time").text(qcviewattributes[2])
	$("#moves_behind").text(qcviewattributes[4])
	$("#target_moves").text(qcviewattributes[0])
	$("#grossmoves").text(qcviewattributes[1])
	var mph = Number(qcviewattributes[1]);
	$('#progressbar').progressbar('setPosition', mph);
}

function logout() {
	stoptimer();
	clearTimeout(qchome_time)
	$.ajax({
		url: "/app/Login/logout",
		success: function(result) {
			$("#layout").html("");
			$("#layout").html(result);
		}
	})

}
;

function mergeJobs(reqType, addContainerList, is_tandem,mkind) {
	var filterValue = $("#jobs_select").val();
	$('#search_joblist').val('')
	console.log("mkind"+mkind)
	$.ajax({
		type: "POST",
		url: "/app/Hc/mergeJobs",
		data: {
			addContainerList: addContainerList,
			reqType: reqType,
			filterValue: filterValue,
			is_tandem: is_tandem,
			movekind:mkind
		},
		success: function(result) {
			if(reqType == "Split"){
				showLoding();
			}
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
		}
	})
	return false
}
function job_timer(timerid) {
	$(timerid).runner({
		autostart: true,
		milliseconds: false
	});
}
function resettimer(timerid) {
	$(timerid).runner('reset');
}

function backreachcontainermove(messagedetails) {
	$.ajax({
		type: "POST",
		url: "/app/Hc/containerbackreachmove",
		data: {
			backreachcontainermessage: messagedetails
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			document.getElementById('light').style.display = 'block';
			$('#cntr_data').msDropdown({ roundedBorder: false });
			$('#cntr_data').change(function() {
				var selectedOption = $(this).val();
				$("#containernumber_data")[0].value = selectedOption;
			});
			$('#containernumber_data').change(function() {
				$("#cntr_data_child ul li ").each(function() {
					if ($(this)[0].className == "enabled _msddli_ selected") {
						$(this)[0].className = "enabled _msddli_";
					}
				});
			});

		}
	})
}

var backreachjobs = [];
function backreachcontainer(type) {
	var containerno_data;
	if (type === "DSCH") {
		containerno_data = $("#containernumber_data").val();
	} else {
		containerno_data = $("#containernumber_data").val();
	}
	var fromlocation_data = $("#fromlocation_data").val();
	var tolocation_data = $("#tolocation_data").val();
	if (containerno_data == "" || fromlocation_data == "" || tolocation_data == "") {
		$("#backreach_error").text("Please fill all the details")
	} else {
		$('.backreach_confirm, .backreach_cancel').attr("disabled", true).addClass("disable_btns");
		$.ajax({
			type: "POST",
			url: "/app/Qc/backreachcontainermove",
			data: {
				containernumber_data: containerno_data,
				fromlocation_data: fromlocation_data,
				tolocation_data: tolocation_data,
				type: type
			},
			success: function(result) {
				if (type == "DSCH") {
					backreachjobs.push(containerno_data);
				} else {
					backreachjobs.splice(backreachjobs.indexOf(containerno_data), 1);
				}
				$('#tabledataid').html("")
				$('#tabledataid').html(result)
				document.getElementById('light').style.display = 'none';
				$("#jobs_select").val("current_jobs");
				$('.backreach_confirm, .backreach_cancel').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.backreach_confirm, .backreach_cancel').attr("disabled", false).removeClass("disable_btns");
			}
		})
	}

	change_filter();
	return false
}

//function getOrphanContainerView() {
//	document.getElementById('collapse1').style.display = 'none';
//
//	$.ajax({
//		url: "/app/Hc/getOrphanContainerView",
//		success: function(result) {
//			$('#light').html("")
//			$('#light').html(result)
//			$("#select_status").msDropdown({ roundedBorder: false });
//			document.getElementById('light').style.display = 'block';
//		}
//	});
//
//}
//getOrphanContainerView
function getOrphanContainerView(isoCodes) {
	document.getElementById('collapse1').style.display = 'none';
	console.log("getOrphanContainerView")
	$.ajax({
		url: "/app/Hc/getOrphanContainerView",
		data:{
			isoCodes:isoCodes
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			document.getElementById('light').style.display = 'block';
		}
	});

}
//getOrphanContainerView

function OrphanContainerHandling() {
	var containerData = $(".orphan_container_table *").serialize();
//	if(containerNo.length > 11){
//		swal("Container No. should not be more than 11 digits");
//	}
//	else{
		$.ajax({
			type: "POST",
			url: "/app/Hc/OrphanContainerHandling",
			data: containerData,
			success: function(result) {
				if (result == "true") {
					closePopup();
				} 
			}
		});
	//}
}


function OrphanContainerCreation(containerNo) {
	$.ajax({
		type: "POST",
		url: "/app/Hc/OrphanContainerCreation",
		data: {
			containerNo: containerNo,
			filter: $("#jobs_select").val()
		},
		success: function(result) {
			$('#tabledataid').html("")
			$('#tabledataid').html(result)
			//$("#jobs_select").val("current_jobs");

		}
	});
}

function pad(d) {
	return (d < 10) ? '0' + d.toString() : d.toString();
}

function showVideo(videoUrl) {
	showAlerts(videoUrl)
	swal({
		title: 'video',
		html: '<video width="320" height="240" controls>' + '<source src="' + videoUrl + '" type="video/mp4">' + '<source src="' + videoUrl + '" type="video/wmv"></video>',
		showCancelButton: true,
		allowOutsideClick: false

	})
}
function deleteJobs(addContainerList) {
	var filterValue = $("#jobs_select").val();
	$('#search_joblist').val('')

	$.ajax({
		type: "POST",
		url: "/app/Hc/deleteJobs",
		data: {
			addContainerList: addContainerList,
			filterValue: filterValue
		},
		success: function(result) {
			$("#tabledataid").html("")
			$("#tabledataid").html(result)
		}
	})
	return false
}

function joblist_refresh() {

	$('.refresh_joblist').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Hc/joblist_refresh",
		success: function(result) {
			if (result != "Error") {
				$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
			} else {
				$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
			}
		},
		error: function() {
			$('.refresh_joblist').attr("disabled", false).removeClass("disable_btns");
		}
	});
}

function getLanguagesList() {
	$.ajax({
		type: "POST",
		url: "/app/Hc/getLanguagesList",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html("")
				$('#light').html(result)
				$("#language").msDropdown({ roundedBorder: false });
				document.getElementById('light').style.display = 'block';
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
	return false
}

function getdamageCrctnScreen(){
	
	   var backreachContnr = typeof $(".tally_cntrno").html() == "undefined" ? "" : $(".tally_cntrno").html();
	   console.log("backreachContnr"+backreachContnr)
	   if((backreachContnr.indexOf("HATCHCOVER")!= -1)||(backreachContnr.indexOf("MANCAGE")!= -1)||(backreachContnr.indexOf("BREAKBULK")!= -1)){
	      console.log("backreach found")
	      showAlerts("Damage cannot be corrected for Backreach Job")
		  return false;
	   } 
	   else{
				console.log("dc clkd")
				cntr=$("#hidden_container_no").val();
				mkind = $(".qc_rows [container='"+$("#hidden_container_no").val()+"']").parents("tr:first").attr("mkind")
				console.log("cntr"+cntr.split("^")[0]);
				$.ajax({
					url: "/app/Hc/getdamageCrctnScreen",
					success: function(result) {
						$('#light').html("")
						$('#light').html(result);
						document.getElementById('light').style.display = 'block';
						$("#containerID").val(cntr);
						$("#mov_kind_dmg").val(mkind)
						if($("#containerID").val(cntr) != ""){
							$("#goBtn").click();
						}
					}
				});
				return false;
			}
}

function sendDmgeCrctnDtls(){
	var dmgrCrtcn=[];
	console.log("confirm btn clk for sending dmge details")
		var cntr=$("#containerID").val();
		console.log("containerID"+cntr)
		 $(".hdn-add-damage-table").each(function(){
				var updtdRecds="";
				updtdRecds +=$(".damageCode").val();
				console.log("updtdRecds -> dmge codes"+updtdRecds)
				updtdRecds +="^";
				updtdRecds +=$(".dmge_loc_id").val();
				
    	})
		console.log("updtdRecds"+updtdRecds)
		dmgrUpdtd.push(updtdRecds);
		$(".hdn-add-damage-table").each(function(){
			var deletedRecds="";
			deletedRecds +=$(".damageCode").val();
		})
		
		console.log("deletedRecds"+deletedRecds)
		dmgeDltd.push(deletedRecds);
		 $(".hdn-add-damage-table").each(function(){
				var addedRecds="";
				addedRecds +=$(".damageCode").val();
				console.log("updtdRecds -> dmge codes"+updtdRecds)
				addedRecds +="^";
				addedRecds +=$(".dmge_loc_id").val();
				
			})
			console.log("addedRecds"+addedRecds)
		dmgeAdded.push(addedRecds);
		$.ajax({
			url: "/app/Hc/sendDmgeCrctnDtls",
			data:{
				 containerID: cntr,
				 dmge_updtd:dmgrUpdtd,
				 dmge_deltd:dmgeDltd,
				 dmge_added:dmgeAdded
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
}

function setLanguage() {
	var selectedlang = $("#language").val();
	$.ajax({
		type: "POST",
		url: "/app/Hc/setLanguage",
		data: {
			selectedlang: selectedlang
		},
		success: function(result) {
			closePopup();
			if (result != 'Error') {
				$(".main_content").html("");
				$(".main_content").html(result);
			}
		},
		complete: function() {
			closePopup();
		}
	})
	return false
}

function manualJobCreate(jobType) {
	$("#collapse1").toggle("slow");
	document.getElementById('manual_jobs').style.display = 'block';
	$("#hdnJobType").val(jobType);
	$("#manual_created_jobs").html(jobType.toLowerCase())
}

function createManualJob(jobMode) {
	var hdnJobType = $("#hdnJobType").val();
	HatchcoverMancageBreakbulk_Request(hdnJobType, jobMode);
	document.getElementById('manual_jobs').style.display = 'none';
	//$("#jobs_select").val("current_jobs");

}
function screenClose() {
	document.getElementById('manual_jobs').style.display = '';
}

function send_Swap_Request() {
	
	var label_to_search = "";
	var containerNums = "";
	var movekind = $(".hdn-movekind").val();
	if ($("#jobs_select").val() == "jobs_completed") {
		if (movekind == "DSCH") {
			label_to_search = ".to_label"
		} else {
			showAlerts("SWAP is not possible for LOAD Containers")
			return false;
		}

	} else if ($("#jobs_select").val() == "current_jobs") {
		if (movekind == "LOAD") {

			label_to_search = ".from_label"
		} else {
			showAlerts("SWAP is not possible for Discharge Containers")
			return false;
		}
	}
	var itv_0 = "";
	var itv_1 = "";
	$(label_to_search).each(function(index) {
		if (index == 0) {
			itv_0 = $(this).text();
		} else if (index == 1) {
			itv_1 = $(this).text();
		}
	});
	if ($(".active").length == 2) {
		$(".tally_cntrno").each(function(index) {
			containerNums += $(this).text().concat("|");
		});
		containerNums = containerNums.substring(0, containerNums.length - 1);
		if ( (itv_0 != "" && itv_1 != "") && itv_0 == itv_1) {
//			if(swap_first_click) {
//			$("#swap_div0").swap({
//				target: "swap_div1", // Mandatory. The ID of the element we want to swap with
//				opacity: "1", // Optional. If set will give the swapping elements a translucent effect while in motion
//				speed: 1000 // Optional. The time taken in milliseconds for the animation to occur
//			});
//			swap_first_click = false;
//			}
//			$.ajax({
//				url: "/app/Hc/send_swap_request",
//				data: {
//					containerno: containerNums,
//					itvNo: itv_0,
//				},
//				success: function(result) { }
//			});
			swapContainers();
		} else {
			showAlerts("SWAP is not possible for this containers,Please check ITV is same for the containers")
		}
	} else {
		showAlerts("SWAP is not possible for this containers,Please check the number of containers")
	}
}




function getContainerList() {
	
	$.ajax({
		type: "POST",
		url: "/app/ContainerEnquiry/getContainerList",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
	return false
}



//function getcontainerDetails() {
//	
//	var containerid = $("#container_enquiry").val();
//		console.log("the container=="+containerid);
//	$.ajax({
//		type: "POST",
//		url: "/app/ContainerEnquiry/getcontainerDetails",
//		data: {
//			containerid: containerid
//		},
//		success: function(result) {
//			if (result != 'Error') {
//				console.log("qcindex getcontainerDetails")
//				$('#light').html(result)
//				document.getElementById('light').style.display = 'block';
//			} else {
//				showAlerts("Unable to process request");
//			}
//		}
//	})
//	return false
//}

function openContainerUtilsPopup() {
	$.ajax({
		type: "POST",
		url: "/app/Hc/get_container_utils_popup",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
}

function openOutOfListPopup(containerList) {
	$.ajax({
		type: "POST",
		url: "/app/Hc/open_out_of_list",
		data: {
			containerList: containerList
		},
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
}


function requestSearchedContainer(searchTerm) {
	$.ajax({
		type: "POST",
		url: "/app/Hc/get_searched_container",
		data: {
			searchTerm: searchTerm
		},
		success: function(result) {
			if (result != 'error') {
				var joblist = result.split("~")[2];
				var isoCodes = result.split("~")[3];
				if(joblist == "") {
					getOrphanContainerView(isoCodes);
				} else {
					openOutOfListPopup(result);
					
				}
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
}

function getSearchedContainer() {
	var searchTerm = $("#search_joblist").val();
	var searchTermLength = searchTerm.replace(/[^0-9]/g,"").length;
	
	if(searchTermLength >= 4) {
		requestSearchedContainer(searchTerm);
	} else {
		showAlerts("Search term should contain atleast 4 digits");
	}
}


