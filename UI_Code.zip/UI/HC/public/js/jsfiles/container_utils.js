function getUpdateContainerPopup() {
	$.ajax({
		type: "POST",
		url: "/app/Hc/get_container_update_popup",
		success: function(result) {
			if (result != 'Error') {
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				$("#containerNumber").val($("#hidden_container_no").val());
			} else {
				showAlerts("Unable to process request");
			}
		}
	})
}