//@ sourceURL=swap.js

function validMoveKind() {
	var movekind = $(".hdn-movekind").val();	
	
	if ($("#jobs_select").val() == "jobs_completed") {
		if (movekind == "DSCH") {
			return { validMove: true, label_to_search: ".to_label" }
		} else {
			showAlerts("SWAP is not possible for LOAD Containers")
			return { validMove: false, label_to_search: "" }
		}

	} else if ($("#jobs_select").val() == "current_jobs") {
		if (movekind == "LOAD") {
			return { validMove: true, label_to_search: ".from_label" }
		} else {
			//showAlerts("SWAP is not possible for Discharge Containers")
			//return { validMove: false, label_to_search: "" }
			return { validMove: true, label_to_search: ".to_label" }
		}
	}
}

function swapSingleContainer() {
	if($(".container_details").hasClass("position-forward")) {
	  $(".container_details").removeClass("position-forward");
	  $(".container_details").addClass("position-aft");
	  $(".tally_swap_btn").html("Swap<br/>(center)");
	} else if($(".container_details").hasClass("position-aft")) {
	  $(".container_details").removeClass("position-aft");
	  $(".container_details").addClass("position-center");
	  $(".tally_swap_btn").html("Swap<br/>(forward)");
	} else {
	  $(".container_details").removeClass("position-center");
	  $(".container_details").addClass("position-forward");
	  $(".tally_swap_btn").html("Swap<br/>(aft)");
	}
	
}

function swapTwinContainer(moveKindInfo) {
	if(checkIfSameITV(2, moveKindInfo) == true) {
		if($(".container_details:eq(0)").hasClass("position-forward")) {
			$(".container_details:eq(0)").removeClass("position-forward")
			$(".container_details:eq(0)").addClass("position-aft")
			$(".container_details:eq(1)").removeClass("position-aft")
			$(".container_details:eq(1)").addClass("position-forward")
		} else {
			$(".container_details:eq(1)").removeClass("position-forward")
			$(".container_details:eq(1)").addClass("position-aft")
			$(".container_details:eq(0)").removeClass("position-aft")
			$(".container_details:eq(0)").addClass("position-forward")
		}
	}
}

function swapTandemContainer(moveKindInfo) {
	var selelctedPairElement = $(".selected_container").parent();
	  
	if(checkIfSameITV(4, moveKindInfo) == true) {
	    if(selelctedPairElement.children(".container_details:eq(0)").hasClass("position-forward")) {
	      selelctedPairElement.children(".container_details:eq(0)").removeClass("position-forward")
	      selelctedPairElement.children(".container_details:eq(0)").addClass("position-aft")
	      selelctedPairElement.children(".container_details:eq(1)").removeClass("position-aft")
	      selelctedPairElement.children(".container_details:eq(1)").addClass("position-forward")
	    } else {
	      selelctedPairElement.children(".container_details:eq(1)").removeClass("position-forward")
	      selelctedPairElement.children(".container_details:eq(1)").addClass("position-aft")
	      selelctedPairElement.children(".container_details:eq(0)").removeClass("position-aft")
	      selelctedPairElement.children(".container_details:eq(0)").addClass("position-forward")
	    }
	}
}

function checkIfSameITV(containerNumbers, moveKindInfo) {
	var itv_0 = "";
	var itv_1 = "";
	var itvSelector = "";
	
	if(containerNumbers == 2) {
		itvSelector = $(moveKindInfo.label_to_search);
	} else {
		itvSelector = $(".selected_container").parent().find(moveKindInfo.label_to_search);
		if(itvSelector.length == 0) {
			showAlerts("Please select a container to swap");
			return false;
		}
	}
	
	$(itvSelector).each(function(index) {
		if (index == 0) {
			itv_0 = $(this).val();
		} else if (index == 1) {
			itv_1 = $(this).val();
		}
	});
	
	if ( (itv_0 != "" && itv_1 != "") && itv_0 == itv_1) {
		return true;
	} else {
		showAlerts("SWAP is not possible for selected containers,Please check ITV is same for the containers");
		return false;
	}
}

function swapContainers() {
	
	var containerNums = "";
	var moveKindInfo = validMoveKind();
	var cntrSizeInfo = $(".hdn-bayNo").val();
	if((cntrSizeInfo)%2 == 0){
		showAlerts("Swap is not possible for 40ft container");
		return false;
	}else{
		var numOfContainers = $(".container_handling_hc .container_details").length;
		
		if(moveKindInfo.validMove == false) {
			return false;
		}

		if(numOfContainers == 1){
			swapSingleContainer();  
		} else if (numOfContainers == 2) {
			swapTwinContainer(moveKindInfo);
		} else {
			swapTandemContainer(moveKindInfo); 
		}
	}
	
}

function changeSwapText() {
	var numOfContainers = $(".container_handling_hc .container_details").length;
	
	if(numOfContainers == 1) {
		if(($("#jobs_select").val() == "jobs_completed" && $(".hdn-movekind").val() == "DSCH") ||
			($("#jobs_select").val() == "current_jobs" && $(".hdn-movekind").val() == "LOAD"))
		if($(".container_details").hasClass("position-forward")) {
		  $(".tally_swap_btn").html("Swap<br/>(aft)");
		} else if($(".container_details").hasClass("position-aft")) {
		  $(".tally_swap_btn").html("Swap<br/>(center)");
		} else {
		  $(".tally_swap_btn").html("Swap<br/>(forward)");
		}
	}
}















































































