$(document).ready(function(){
	virtualKeyboard();
  function encryptPasswordandsubmit(login_text,passwordTxt)
  {
    if(login_text == "" || passwordTxt == "")
    {  
      $(".error-message").text("Please enter all fields")
      return false;
    } else{
    var iterationCount = 1000;
    var keySize = 128;
    var plaintext = passwordTxt ; 
    var passphrase = "2cmc0MERGES1tcs5" ;
    var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
    var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
    var aesUtil = new AesUtil(keySize, iterationCount);
    var ciphertext = aesUtil.encrypt(salt, iv, passphrase, plaintext);
    login_submit(login_text,ciphertext,salt,iv)
    }
    //window.location.href = "#/login/set_udp_connection/?login="+login_text+"&password="+ciphertext+"&salt="+salt+"&iv="+iv;
  }
  function hasWhiteSpace(s) {
	  return /\s/g.test(s);
	}
function login_submit(login,password,salt,iv)
 {
	 if(hasWhiteSpace(login) || hasWhiteSpace(password)){
		 swal("Username and password should not contain whitespace");
	 }else{
   $('.login_signin_btn').attr("disabled",true).addClass("disable_btns");	  
   $.ajax({
     type:   "GET",
     url:  "/app/Login/set_udp_connection",
     data:
       {
       login:login,
       password: password,
       salt:salt,
       iv:iv
     },
     success:function(result){
		 $(".main_layout").html("");  
         $(".main_layout").html(result);        
     },error:function(){
    	 $('.login_signin_btn').attr("disabled",false).removeClass("disable_btns");	  
     }
   });
	 }
 }  
  $('.login_signin_btn').on('click touchend', function(){
         var passwordTxt =document.getElementById("password").value;
         var login_text = document.getElementById("login").value;
         encryptPasswordandsubmit(login_text,passwordTxt);
     
    //login_submit(login_text,password_encrypt);
       });
  });
function displayErrorAlert(errorMessage)
{
    document.getElementById('light1').style.display='block';
	$("#layout").unmask();
}