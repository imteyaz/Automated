var addDelayEnabled = false, // becomes true when add button is clicked
var editDelayEnabled = false; // becomes true when edit button is clicked
var damage_unq_code = 0;
var existing_damages = [];
var new_damages = [];
var deleted_damages = [];
function damage_correction_js(damage_crr_data,damage_types,damages){
jQuery("#dmg_crr_grd").jqGrid({
	data: damage_crr_data,
	datatype: "local",
	height: 150,
	colNames: ["Damage Type", "Severity","Damage Code", "Damage Location","Unique Code","Actions"],
	colModel: [
	{ name: 'damage_type', index: 'damage_type', editable: true,width: 200,edittype:"select",
		editoptions:{value: get_damage_types(damage_types),
			 dataInit: function (elem) {
				 jQuery("#dmg_crr_grd").setColProp('damage_code', { editoptions: { value: get_damage_codes($(elem).val(),true)} });
				 //jQuery("#dmg_crr_grd").jqGrid('setCell', 124, 'damage_severity', "2");
				 initVirtualKeyboard();
             },
			
			dataEvents: [
        {
            type: 'change',
            fn: function (e) {
            	var newOptions = '';
                newOptions += get_damage_codes($(this).val(),false);
                var row = $(e.target).closest('tr.jqgrow');
                var rowId = row.attr('id');
                $("select#" + rowId + "_damage_code", row[0]).html(newOptions);
                $("select#" + rowId + "_damage_code", row[0]).change();
				initVirtualKeyboard();
            }
        }
        ]}},
	{ name: 'damage_severity', index: 'damage_severity',width: 100},
	{ name: 'damage_code', index: 'damage_code', editable: true,width: 270,edittype:"select",
		editoptions:{
			 dataInit: function (elem) {
				 var dmg_ty = $("#"+$(elem).attr("id").split("_")[0]+"_damage_type").val()
				 jQuery("#dmg_crr_grd").setColProp('damage_location', { editoptions: {value: damage_locations($(elem).val(),dmg_ty,true) }});
				 jQuery("#dmg_crr_grd").jqGrid('setCell', $(elem).attr("id").split("_")[0], 'damage_severity', get_damage_sevirty($(elem).val(),dmg_ty));
				 initVirtualKeyboard();
            },
			
			dataEvents: [
       {
           type: 'change',
           fn: function (e) {
           	var newOptions = '';
           		var row = $(e.target).closest('tr.jqgrow');
           		var rowId = row.attr('id');
           		var dmg_ty = $("#"+rowId+"_damage_type").val()
               newOptions += damage_locations($(this).val(),$("#"+rowId+"_damage_type").val(),false);
               $("select#" + rowId + "_damage_location", row[0]).html(newOptions);
               jQuery("#dmg_crr_grd").jqGrid('setCell', rowId, 'damage_severity', get_damage_sevirty($(this).val(),dmg_ty))
			   initVirtualKeyboard();
           }
       }
       ]}	
	
	
	}, 
	{ name: 'damage_location', index: 'damage_location', editable: true,width: 200,edittype:"select",editoptions: { dataInit: initVirtualKeyboard }},
	{ name: 'damage_unq_code', index: 'damage_unq_code', hidden: true},
	{ name: 'act', index: 'act', width: 100, sortable: false }
	],
	autowidth: true,
	shrinkToFit: false,
	forceFit: true,
	// adding tool bar at top
	//   toppager: true,
	toolbar: [true, "top"],
	gridComplete: prepare_actions_for_grid,
	editurl: 'clientArray',
	onSelectRow : function(id){ 
		
	}
});

$("#t_dmg_crr_grd").html("");
$("#t_dmg_crr_grd").append("<img src='../../public/images/add_new.png' style='height:50px;width:60px;' onclick='addFunction()'/>");
}

function get_damage_sevirty(dmg_code,damg_type){
	var res = ""
	var dmgs = $("#hdnNewDamageDetails").val()
	var dmgs_arr = dmgs.split("$")
	for(var i = 0; i < dmgs_arr.length ; i ++){
		var dm_ty = dmgs_arr[i].split("^")
		if(dm_ty[0] == damg_type){
		var dm_codes = dm_ty[1].split("|")
		for(var dc = 0; dc < dm_codes.length; dc ++){
			var dcs =  dm_codes[dc].split("#")
			if(dcs[0] == dmg_code)
				{
					return dcs[2]
				}
			}
		}
	}
}

function initVirtualKeyboard(){
	$("select").addClass('combobox');
	$("select").attr('type', 'text');
	$(".combobox").combobox();
	setTimeout(virtualKeyboard, 500);
}

function get_damage_codes(damg_type,is_first_time){
	var res = ""
	var dmgs = $("#hdnNewDamageDetails").val()
	var dmgs_arr = dmgs.split("$")
	
	for(var i = 0; i < dmgs_arr.length ; i ++){
		var dm_ty = dmgs_arr[i].split("^")
		if(dm_ty[0] == damg_type){
		var dm_codes = dm_ty[1].split("|")
		for(var dc = 0; dc < dm_codes.length; dc ++){
			var dcs =  dm_codes[dc].split("#")
			if(!is_first_time){
				res += '<option role="option" value="' +
								dcs[0] + '">' +
								dcs[0] + "-" + dcs[dcs.length-1]+'</option>'
			}
			else{
				res += dcs[0]+":"+dcs[0] + "-" + dcs[dcs.length-1]
				if(dc != dm_codes.length-1){
					res += ";"
					}
				}
			}
		}
	}
	return res;
}


function get_damage_locations(damg_code,damg_type){
	return {
		value: damage_locations(damg_code,damg_type,false),
	}
}
function damage_locations(damg_code,damg_type,is_first_time){
	var dmgs = $("#hdnNewDamageDetails").val()
	var dmgs_arr = dmgs.split("$")
	var dmg_loc_str = ""
	for(var i = 0; i < dmgs_arr.length ; i ++){
		var dm_ty = dmgs_arr[i].split("^")
		if(dm_ty[0] == damg_type){
		var dmg_cods = dm_ty[1].split("|")
		for(var j = 0; j < dmg_cods.length; j ++){
			var dmg_locs = dmg_cods[j].split("#")
			if(dmg_locs[0]*1 == damg_code.split("-")[0]*1 ){
				var dmg_locs = dmg_locs[1].split("&")
				for(var dl = 0 ; dl < dmg_locs.length ; dl ++ ){
					if(!is_first_time){
						dmg_loc_str += '<option role="option" value="' +
						dmg_locs[dl] + '">' +
						dmg_locs[dl] + '</option>'
					}
					dmg_loc_str += dmg_locs[dl] + ":" + dmg_locs[dl]
					if(dl != dmg_locs.length-1){
						dmg_loc_str += ";"
					}	
				}
				return dmg_loc_str
			}
		}
		}
	}
	
}

function get_damage_types(damg_typs)
{
	
	var dmg_str = ""
	for(var j = 0; j < damg_typs.length; j ++){
		dmg_str += damg_typs[j] + ":" +damg_typs[j]
		if(j != damg_typs.length-1){
			dmg_str += ";"
		}
	}
	return dmg_str
	}
function prepare_actions_for_grid() {
	
	var ids = jQuery("#dmg_crr_grd").jqGrid('getDataIDs');
	for (var i = 0; i < ids.length; i++) {
		var cl = ids[i];
		be = "<img src='../../public/images/edit.png' class='adjust_edit_image edit_btn' onclick=\"onRowEdit('" + cl + "', this);\" />";
		se = "<img src='../../public/images/save.png' class='adjust_delete_image save_btn' style='display:none;' onclick=\"onSaveRow('" + cl + "', this)\" />";
		ce = "<img src='../../public/images/delete_icon.png' class='adjust_delete_image' onclick=\"onDeleteRow('" + cl + "', this);\" />";
		jQuery("#dmg_crr_grd").jqGrid('setRowData', ids[i], { act: be + se + ce });
	}
}

function enableColumnsForEdit(selectedGrid, columnNames){
	var i = 0;
	for(i = 0; i < columnNames.length; i++){
		selectedGrid.jqGrid('getColProp',columnNames[i]).editable = true;
	}
}

function disableColumnsForEdit(selectedGrid, columnNames){
	var i = 0;
	for(i = 0; i < columnNames.length; i++){
		selectedGrid.jqGrid('getColProp',columnNames[i]).editable = false;
	}
}

function onDeleteRow(id, element){
	if(addDelayEnabled == true || editDelayEnabled == true){
		showAlerts("Please save all other damages");
		return false;
	}
	if($(jQuery('#dmg_crr_grd').jqGrid('getInd', id, true)).attr("editable") == 1){
		editDelayEnabled == false;
		addDelayEnabled = false;
	}
	
	jQuery('#dmg_crr_grd').jqGrid('delRowData', id);
	deleted_damages.push(id)
	new_damages.splice(new_damages.indexOf(id),1)
	for(var c = 0; c < new_damages.length; c ++){
		console.log(new_damages[c])
	}
}

function onSaveRow(id, element){
	console.log("id " + id);
	jQuery('#dmg_crr_grd').saveRow(id);
	$(element).parent().parent().find(".edit_btn").show();
	$(element).parent().parent().find(".save_btn").hide();
	editDelayEnabled = false;
	if(addDelayEnabled == true){
		deleteAndInsertRow();
		addDelayEnabled = false;
		var d = $('.ui-jqgrid-bdiv');
		d.scrollTop(d.prop("scrollHeight"));
	}
}

function deleteAndInsertRow(){
	var rowId = $("#dmg_crr_grd").getDataIDs()[0];
	var firstRowData = jQuery("#dmg_crr_grd").getRowData(rowId);
	jQuery('#dmg_crr_grd').jqGrid('delRowData',rowId);
	$("#dmg_crr_grd").jqGrid('addRowData',rowId,firstRowData);
	new_damages.push(rowId)
}

var lastSel = -1;
function onRowEdit(id, element,damages){
	console.log("addDelayEnabled " + addDelayEnabled);
	console.log("editDelayEnabled " + editDelayEnabled);
	if(addDelayEnabled == true || editDelayEnabled == true){
		showAlerts("Please save all other damages");
		return false;
	}

	if(lastSel > -1){
		$(".edit_btn").show();
		$(".save_btn").hide();
		jQuery("#dmg_crr_grd").jqGrid('restoreRow',lastSel);
	}
	
	var selectedRow = jQuery('#dmg_crr_grd').jqGrid ('getRowData', id);
	cm = jQuery("#dmg_crr_grd").jqGrid('getColProp','damage_location');
	cm.editoptions = get_damage_locations(selectedRow.damage_code,selectedRow.damage_type); 
	var editableColumns = [ 'damage_type', 'damage_code'];
	var selectedGrid = jQuery("#dmg_crr_grd");
	if(selectedRow.code != 0){
		disableColumnsForEdit(selectedGrid, editableColumns);
	}else{
		enableColumnsForEdit(selectedGrid, editableColumns);
	}
	jQuery("#dmg_crr_grd").jqGrid('editRow', id, true, null, null, 'clientArray');
	lastSel = id;
	$(element).parent().parent().find(".edit_btn").hide();
	$(element).parent().parent().find(".save_btn").show();
	editDelayEnabled = true;
	initVirtualKeyboard();
}




function addFunction() {
	damage_unq_code += 1
//	return true;
	if(addDelayEnabled == true || editDelayEnabled == true){
		showAlerts("Please save all other damages");
		return false;
	}
//	
	var datarow = {damage_type: "",damage_severity:"",damage_code:"",damage_location: "",damage_unq_code: 0};
	var GridIds = $("#dmg_crr_grd").getDataIDs();
	console.log("GridIds");
	console.log(GridIds);
	if(GridIds.length == 0){
		var last4sel = 1;
	}
	else{
		var last4sel = Math.max.apply(Math, GridIds) + 1;	
	}
	
	var su = $("#dmg_crr_grd").jqGrid('addRowData',last4sel,datarow, 'first');
	if (su) {
		var cm = jQuery("#dmg_crr_grd").jqGrid('getColProp','damage_type');
		cm.editable = true;
		var cm = jQuery("#dmg_crr_grd").jqGrid('getColProp','damage_code');
		cm.editable = true;
		var cm = jQuery("#dmg_crr_grd").jqGrid('getColProp','damage_location');
		cm.editable = true;
		jQuery('#dmg_crr_grd').editRow(last4sel, true);
		$(".edit_btn:first").hide();
		$(".save_btn:first").show();
	}
	
	var d = $('.ui-jqgrid-bdiv');
	d.scrollTop(0);
	
	addDelayEnabled = true;
}



function sendDmgeCrctnDtls(){
	if(editDelayEnabled || addDelayEnabled){
		showAlerts('Please save the data');
		return false;
	}
	var new_damages_data = ""
	var updated_damages = ""
	var del_damages = ""
	var ex_del_damages = $(existing_damages).not($(existing_damages).not(deleted_damages))
	for(n = 0; n < ex_del_damages.length; n ++){
		del_damages += ex_del_damages[n] 
		if(n!= ex_del_damages.length-1){
			del_damages += "|"
		}
	}
	console.log(del_damages)
	console.log("XXXXXXXXXXXXXXXXXXXXXXXXXX")
	
	for(n = 0; n < new_damages.length; n ++){
		var dm_data = jQuery("#dmg_crr_grd").jqGrid("getRowData",new_damages[n])
		new_damages_data +=  dm_data.damage_code.split("-")[0] + "^" + dm_data.damage_location
		console.log(new_damages_data)
		if(n != new_damages.length-1){
			new_damages_data += "|"
		}
	}
	
	console.log(new_damages_data)
	console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
	
	var grd_ids = jQuery("#dmg_crr_grd").jqGrid("getDataIDs")
	var curr_dm_ids = $(grd_ids).not($(grd_ids).not(existing_damages))
	for(n = 0; n < curr_dm_ids.length; n ++){
		var dm_data = jQuery("#dmg_crr_grd").jqGrid("getRowData",curr_dm_ids[n])
		updated_damages +=  dm_data.damage_unq_code + "^" + dm_data.damage_location
		if(n != curr_dm_ids.length-1){
			updated_damages += "|"
		}
	}
	
	console.log(updated_damages)
	console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
	
	var containerNumber = $("#containerID").val();
	var mkind = $("#mov_kind_dmg").val();
	var remarks = $("#remarks").val();
	
	if(containerNumber==""){
		showAlerts('Container Number is mandatory.');
		return false;
	}
	
	$.ajax({
		url: "/app/Hc/sendDamageCorrectData",
		data:{
			newDamageRecords: new_damages_data,
			oldDamageRecords: updated_damages,
			containerNumber: containerNumber,
			deletedDamageCodes: del_damages, 
			remarks: remarks,
			mkind: mkind
		},
		success: function(result) {
			document.getElementById('light').style.display = 'none';
	    },
		error: function(){
			console.log("ERROR - getConatinerDetails");
		}
	});
}




/*
 * Display damage correction details for the selected conatiner
 */
function getDmgeDtlsForCntnr(){
 
	var cntr=$("#containerID").val();
	var mkind = $("#mov_kind_dmg").val();
	console.log("containerID"+cntr);
	
	if(cntr == ""){
		showAlerts("Please enter container number");
		return false;
	}
	
	
	if((cntr.indexOf("HATCHCOVER")!= -1)||(cntr.indexOf("MANCAGE")!= -1)||(cntr.indexOf("BREAKBULK")!= -1)){
	      console.log("backreach found")
	      showAlerts("Damage cannot be corrected for Backreach Job")
		  return false;
	   } 
  else{
	
	$.ajax({
		url: "/app/Hc/getDmgeDtlsForCntnr",
		data:{
			 containerID: cntr,
			 mkind: mkind
		},
		success: function(result) {
			$('.damage-correction-details').html(result);
			document.getElementById('light').style.display = 'block';
	    },
		error: function(){
			//alert("ERROR - getConatinerDetails");
			//showAlerts('No Damage details found.');
			return;
		}
	});
  
	}

}

   
   
    

    
  