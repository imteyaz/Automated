$(document).ready(function() {
	/*
	$('.itvjob_done').hide();
	$('.itv_cntr_twin').hide();
	var Itv_arrived_clicks = 0;
	$(".arrivedbtn_active").click(function() {
		if (Itv_arrived_clicks == 0) {
			console.log("Itv_arrived_clicks" + Itv_arrived_clicks)
			$.ajax({
				url: '/app/Login/Itv_arrived',
				type: "POST",
				success: function(dataR) {
					console.log(dataR)
					$('.qc_details_inst').remove();
					$('.itvjob_done').hide();
					$('.instructions').append("<span class='qc_details_laneno'>GO TO " + dataR + "</span>"); <!--qc_details -->
					Itv_arrived_clicks++;
				}
			});
		}
		if (Itv_arrived_clicks == 1) {
			$.ajax({
				url: '/app/Login/Itv_pinningstation_selection',
				type: "POST",
				success: function(dataR) {
					dataR = dataR.split('~')
					$('.arrivedbtn_active').css('background-color', 'orange')
					$('.qc_details_laneno').remove();
					$('.instructions').append("<span class='qc_details_inst'>GO TO " + dataR[5] + "</span>"); <!--qc_details -->
					$('#discharge_cntr_no').html(dataR[6]);
					$('.itvjob_done').show();
					Itv_arrived_clicks++;
				}
			});
		}
		if (Itv_arrived_clicks == 2) {
			$.ajax({
				url: '/app/Login/wait_for_job',
				type: "POST",
				success: function(dataR) {
					console.log(dataR)
					dataR = dataR.split('~')
					$('.arrivedbtn_active').css('background-color', 'orange');
					$('.qc_details_laneno').remove();
					$('.instructions .qc_details_inst').text(dataR);
					$('.itvjob_done').hide();
					$('#rms_timer1').runner('reset', true);
					Itv_arrived_clicks++;
				}
			});
		}

	});

*/
});
