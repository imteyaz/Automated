//@ sourceURL=itv_index.js
isSwapClicked = false;

$(document).ready(function() {
	resetSlectedClassAndCntrNo();
	//	$(".arrived_btn").prop("disabled",true);
	//	$(".arrived_btn").css("background","#737373");
	resetCounter();
	$('#progressbar').progressbar();
	$(".jobdone_btn").prop("disabled", true);
	$(".jobdone_btn").css("background", "#737373");
	
	$('.icon_waiting').click(function() {
		
		var fortyContainer = $(".itv_container_single_forty");
		var singleForward = $(".itv_container_single_first");
		var singleAft = $(".itv_container_single_second");
		
		/*    //this code is disabled after discussion with tushar and sandip
		if((fortyContainer.css("display") == "block" && fortyContainer.data("operation") == "carry") ||
			(singleForward.css("display") == "block" && singleForward.data("operation") == "carry")	||
			(singleAft.css("display") == "block" && singleAft.data("operation") == "carry")) {
			
				showAlerts("This operation is not possible in CARRY mode.You can proceed with call request");
				//return;
		}
		*/
		
		$(".icon_waiting").css("background-color","#0174cd");
		$.ajax({
			url: "/app/Login/getunavlblereasons",
			data: {
				popupType: "unavilable"
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				$("select").addClass('combobox');
				$("select").attr('type', 'text');
				$(".combobox").combobox();
				setTimeout(virtualKeyboard, 500);
				document.getElementById('light').style.display = 'block';
				
				$(".delayrecording_page .ui-button-icon").click(function(){
					$(".ui-autocomplete").css("width", $(".delayrecording_page .ui-autocomplete-input").width() + 20 + 'px')
				})
				
				//$("#rms_select").msDropdown({ roundedBorder: false });
				//document.getElementById('light').style.display = 'block';
			}
		});
	});
	
 /*	$(".icon_talk").click(function(){
		$.ajax({
			url: "/app/Login/call_itv",
			success: function(result) {
				$('#light').html("")
				$('#light').html(result);
				document.getElementById('light').style.display = 'block';
			}
		});
	})
	*/
	$(".arrived_btn").click(function() {
				$(".arrived_btn").prop("disabled",true);
		//		$(".arrived_btn").css("background","#737373");
		//$(".qc_details_inst").text("");
		$.ajax({
			type: "POST",
			data: {
				popupType: "unavilable"
			},
			url: "/app/Login/Itv_arrived",
			success: function(result) { }
		});
	});
	$('.user-toggle').click(function() {
		$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
		$('.user-toggle').css("border", "0px");
		var collapse_content_selector = $(this).attr('href');
		var toggle_switch = $(this);
		$(collapse_content_selector).toggle(function() {
			if ($(this).css('display') == 'none') {
			}
		});
	});

	
	var details = "CONTAINER_DETAILS~" + $(".itv_details").html();
	console.log(details)
	console.log("Details")
	
	if (details == null || details == ""|| details =="CONTAINER_DETAILS~") {
		console.log("details are nill")
	} else {
		console.log("details are not nill")
		processcontainerdetails(details);
		console.log("details are"+details)
		var details_array = details.split("|");
		if(details_array.length==2){
				var first_container_details = (details_array[0].split("~")[1]).split("^");
				var second_container_details = details_array[1].split("^");
				if (first_container_details[9] == "T" && first_container_details[10] == "FORWARD"){
				   if (first_container_details[11]=="fetch") {
						console.log("fetch in response-------")
						$(".itv_container_twin_first").css("border", "2px dashed black");
						$("#itv_container_twin_first_no").css("color", "grey");
					} else {
						console.log("carry in response-------")
						$(".itv_container_twin_first").css("border", "2px solid black");
						$("#itv_container_twin_first_no").css("color", "green");
					}
				}
				if (first_container_details[9] == "T" && first_container_details[10] == "AFT"){
					   if (first_container_details[11]=="fetch") {
							console.log("fetch in response-------")
							$(".itv_container_twin_second").css("border", "2px dashed black");
							$("#itv_container_twin_second_no").css("color", "grey");
							
						} else {
							console.log("carry in response-------")
							$(".itv_container_twin_second").css("border", "2px solid black");
							$("#itv_container_twin_second_no").css("color", "green");
						}
					}
				if(second_container_details[9] == "T"&& second_container_details[10]=="FORWARD"){
					if (second_container_details[11]=="fetch") {
						console.log("fetch in response-------")
						$(".itv_container_twin_first").css("border", "2px dashed black");
						$("#itv_container_twin_first_no").css("color", "grey");
					} else {
						console.log("carry in response-------")
						$(".itv_container_twin_first").css("border", "2px solid black");
						$("#itv_container_twin_first_no").css("color", "green");
					}
				}
				if(second_container_details[9] == "T"&& second_container_details[10]=="AFT"){
					if (second_container_details[11]=="fetch") {
						console.log("fetch in response-------")
						$(".itv_container_twin_second").css("border", "2px dashed black");
						$("#itv_container_twin_second_no").css("color", "grey");
						
					} else {
						console.log("carry in response-------")
						$(".itv_container_twin_second").css("border", "2px solid black");
						$("#itv_container_twin_second_no").css("color", "green");
					}
				}
			// display swap btn if two 20 ft carry containers are placed on ITV - from response port
			if(( first_container_details[9] != "F" && second_container_details[9] !="F" )){ 
				if ( ($("#itv_container_twin_first_no").html() != "" && $("#itv_container_twin_second_no").html() != "") &&($("#itv_container_twin_first_no").css("color")=="rgb(0, 128, 0)" && $("#itv_container_twin_second_no").css("color")=="rgb(0, 128, 0)")) {
					$(".swap_btn").show();
				} else {
					console.log("no swap btn")
					$(".swap_btn").hide();
				}
			}
		}
		else{
			}
	  }
	var startTimer = function() {
		$('#rms_timer1').runner({
			autostart: true,
			milliseconds: false,
			format: function(milliseconds) {
				var oneHour = 3600000;
				var oneMinute = 60000;
				var oneSecond = 1000;
				var seconds = 0;
				var minutes = 0;
				var hours = 0;
				var result;

				if (milliseconds >= oneHour) {
					hours = Math.floor(milliseconds / oneHour);
				}
				milliseconds = hours > 0 ? (milliseconds - hours * oneHour) : milliseconds;
				if (milliseconds >= oneMinute) {
					minutes = Math.floor(milliseconds / oneMinute);
				}
				milliseconds = minutes > 0 ? (milliseconds - minutes * oneMinute) : milliseconds;
				if (milliseconds >= oneSecond) {
					seconds = Math.floor(milliseconds / oneSecond);
				}
				milliseconds = seconds > 0 ? (milliseconds - seconds * oneSecond) : milliseconds;
				if (hours > 0) {
					result = (hours > 9 ? hours : "0" + hours) + ":";
				} else {
					result = "00:";
				}
				if (minutes > 0) {
					result += (minutes > 9 ? minutes : "0" + minutes) + ":";
				} else {
					result += "00:";
				}
				if (seconds > 0) {
					result += (seconds > 9 ? seconds : "0" + seconds);
				} else {
					result += "00";
				}
				return result;
			}
		});
	}
	function startTimerAvailable() {
		$('#rms_timer').runner({
			autostart: true,
			milliseconds: false,
			format: function(milliseconds) {
				var oneHour = 3600000;
				var oneMinute = 60000;
				var oneSecond = 1000;
				var seconds = 0;
				var minutes = 0;
				var hours = 0;
				var result;

				if (milliseconds >= oneHour) {
					hours = Math.floor(milliseconds / oneHour);
				}
				milliseconds = hours > 0 ? (milliseconds - hours * oneHour) : milliseconds;
				if (milliseconds >= oneMinute) {
					minutes = Math.floor(milliseconds / oneMinute);
				}
				milliseconds = minutes > 0 ? (milliseconds - minutes * oneMinute) : milliseconds;
				if (milliseconds >= oneSecond) {
					seconds = Math.floor(milliseconds / oneSecond);
				}
				milliseconds = seconds > 0 ? (milliseconds - seconds * oneSecond) : milliseconds;
				if (hours > 0) {
					result = (hours > 9 ? hours : "0" + hours) + ":";
				} else {
					result = "00:";
				}
				if (minutes > 0) {
					result += (minutes > 9 ? minutes : "0" + minutes) + ":";
				} else {
					result += "00:";
				}
				if (seconds > 0) {
					result += (seconds > 9 ? seconds : "0" + seconds);
				} else {
					result += "00";
				}
				return result;
			}
		});
	}

});

$(".itv_container_single_first").click(function(){
	var contNum = $("#itv_container_single_first_no").text() + $("#itv_container_single_first_no_new").text();
	$("#hiddenContNumber").val(contNum)
	if($("#itv_container_single_first_no").text()!=""){
		$(".itv_container_single_first").addClass("selected");
		$(".itv_container_single_second").removeClass("selected");
	}else{
	}
	
})

$(".itv_container_single_second").click(function(){
	var contNum = $("#itv_container_single_second_no").text() + $("#itv_container_single_second_no_new").text();
	$("#hiddenContNumber").val($("#itv_container_single_second_no").text())
	if($("#itv_container_single_second_no").text()!=""){
		$(".itv_container_single_second").addClass("selected");
		$(".itv_container_single_first").removeClass("selected");
	}else{
	}
	
})
$(".itv_container_twin_first").click(function(){
	$("#hiddenContNumber").val($("#itv_container_twin_first_no").text())
	if($("#itv_container_twin_first_no").text()!=""){
		$(".itv_container_twin_first").addClass("selected");
		$(".itv_container_twin_second").removeClass("selected");
	}else{
	}
	
})

$(".itv_container_twin_second").click(function(){
	$("#hiddenContNumber").val($("#itv_container_twin_second_no").text())
	if($("#itv_container_twin_second_no").text()!=""){
		$(".itv_container_twin_second").addClass("selected");
		$(".itv_container_twin_first").removeClass("selected");
	}else{
	}
	
})


$(".itv_container_single_forty").click(function(){
	$("#hiddenContNumber").val($("#itv_container_single_no").text())
	if($("#itv_container_single_no").text()!=""){
		$(".itv_container_single_forty").addClass("selected");
	}else{
	}
	
})

function loadLocations() {
	$.ajax({
		type: "GET",
		url: "/app/Login/display_location",
		success: function(result) {
			console.log("result"+result)
			$(".qc_details_inst").html(result)
		/*	if(result.indexOf(",")!=-1){
			//	$(".qc_details_inst").html(result)
				console.log("result"+result)
				result = result.replace(",","").replace("</span>",",");
				console.log("result after remving span"+result)
				$(".qc_details_inst").html(result)
			}
			else{
				$(".qc_details_inst").html(result)
			}*/
		},
		error: function() { }
	});
}

function manualRefreshItv() {
	console.log("manual refresh button clickd")
	$('.manualRefresh_itv').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Login/manualRefreshItv",
		success: function(result) {
			console.log("ajax success")
			//$(".qc_details_inst").html("");
			if (result != "Error") {
				console.log("inside ajax success if")
				$('.manualRefresh_itv').attr("disabled", false).removeClass("disable_btns");
			} else {
				$('.manualRefresh_itv').attr("disabled", false).removeClass("disable_btns");
			}
		},
		error: function() {
			$('.manualRefresh_itv').attr("disabled", false).removeClass("disable_btns");
		}

	})
}

//function delayRecordingItv(){
//	console.log("delay recording btn clkd")
//	$.ajax({
//		url: "/app/Login/get_manual_delay_data",
//		success: function(result) {
//			console.log("ajax success")
//			$('.modal_hidden_html').html("")
//			$('.modal_hidden_html').append(result)	
//			$( ".modal-dialog" ).html("");
//			//$("#delayrecording_data").msDropdown({ roundedBorder: false });
//			//document.getElementById('light').style.display = 'block';	
//			$( ".modal-dialog" ).append($( ".modal-content" ));
//		}
//	});
//}

function job_timer(timerid) {
	$(timerid).runner({
		autostart: true,
		milliseconds: false
	});
}
function resettimer(timerid) {
	$(timerid).runner('reset', true);
	console.log("timer reset done")
}

//function updateContainerColor(fetch_details) {
//	$("#hdnFetchDetails").val(fetch_details);
//}

function updateMoveType(tempMoveType) {
	$(".itv_main_header_left").html("Current Job: " + tempMoveType);

}

function hideConatinerRelatedDetails(containerArray) {
	console.log("containerArray"+containerArray)
	console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
	
	$(".swap_btn").hide();
	if (typeof containerArray == "undefined") {
		$(".continer_details_cont").find("td").html('');
		$(".itv_container_single_forty,.itv_container_single_twenty, .itv_container_twin,#truck_single_forty_details_table, #truck_single_details_table, #truck_twin_details_table").hide();
		$(".itv_container_single_first").css("border", "none");
		$(".itv_container_single_second").css("border", "none");
		$("#itv_container_single_first_no,#itv_container_single_first_no_new, #itv_container_single_no, #itv_container_single_no_second,#itv_container_single_second_no,#itv_container_single_second_no_new").html('');
	} else {
		containerArray = containerArray.split("~")[1].split("|");
		var isConatinerFound = false;
		for (var i = 0; i < containerArray.length; i++) {
			var container = containerArray[i];
			console.log(container)
			console.log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
			console.log($("#itv_container_single_first_no").html())
			console.log($("#itv_container_single_second_no").html())
			if (($("#itv_container_single_first_no").html() + $("#itv_container_single_first_no_new").html()) == container) {
				isConatinerFound = true;
				$(".itv_container_single_first").css("border", "none");
				$("#itv_container_single_first_no").html('');
				$("#itv_container_single_first_no_new").html('');

				$("#truck_single_first_details_cont").hide();
				$("#truck_single_first_details_iso").hide();
				$("#truck_single_first_details_category").hide();
				$("#truck_single_first_details_flag").hide().attr("class", "");
				$("#truck_single_first_details_weight").hide();
				$("#truck_single_first_details_dd").hide();
				$("#truck_single_first_details_status").hide();
				$("#truck_single_first_details_liftType").hide();
				$("#truck_single_first_details_reeferPoint").hide();
				

			} else if (($("#itv_container_single_second_no").html() + $("#itv_container_single_second_no_new").html()) == container) {
				isConatinerFound = true;
				$(".itv_container_single_second").css("border", "none");
				$("#itv_container_single_second_no").html('');

				$("#truck_single_second_details_cont").hide();
				$("#truck_single_second_details_iso").hide();
				$("#truck_single_second_details_category").hide();
				$("#truck_single_second_details_flag").hide();
				$("#truck_single_second_details_weight").hide();
				$("#truck_single_second_details_dd").hide();
				$("#truck_single_second_details_status").hide();
				$("#truck_single_second_details_liftType").hide();
				$("#truck_single_second_details_reeferPoint").hide();
			} else if($("#itv_container_twin_first_no").html() == container){
				isConatinerFound = true;
				$(".itv_container_twin_first").css("border","none");
				$("#itv_container_twin_first_no").html("");
				
				$("#truck_first_details_cont").hide();
				$("#truck_first_details_iso").hide();
				$("#truck_first_details_category").hide();
				$("#truck_first_details_flag").hide();
				$("#truck_first_details_weight").hide();
				$("#truck_first_details_dd").hide();
				$("#truck_first_details_status").hide();
				$("#truck_first_details_liftType").hide();
				$("#truck_first_details_reeferPoint").hide();
				
			}else if($("#truck_second_details_cont").html() == container){
				isConatinerFound = true;
				$(".itv_container_twin_second").css("border","none");
				$("#itv_container_twin_second_no").html("");
				
				$("#truck_second_details_cont").hide();
				$("#truck_second_details_iso").hide();
				$("#truck_second_details_category").hide();
				$("#truck_second_details_flag").hide();
				$("#truck_second_details_weight").hide();
				$("#truck_second_details_dd").hide();
				$("#truck_second_details_status").hide();
				$("#truck_second_details_liftType").hide();
				$("#truck_second_details_reeferPoint").hide();
			}
			if(($("#itv_container_twin_second_no").html() == "" && $("#itv_container_twin_first_no").html() == "")){
				$("#truck_twin_details_table").hide();
			}
			if(($("#itv_container_single_first_no").html() =="" && $("#itv_container_single_second_no").html() == "")){
				$("#truck_single_details_table").hide();
			}
			if($(".itv_container_single_forty").width() == "196"){
				$("#itv_container_single_no").html("");
				$("#itv_container_single_no_second").html("");
				$(".itv_container_single_forty").css("border","none");
				$("#truck_single_forty_details_table").hide();
			}
		}

		//		if(isConatinerFound){
		//			$.ajax({
		//				type: "GET",
		//				url: "/app/Login/swap_locations",
		//				success: function(result) {
		//					$(".qc_details_inst").html("GO TO " + result);
		//				},
		//				error: function(){
		//
		//				}
		//			});
		//		}
	}
}
function resetSlectedClassAndCntrNo(){
	  console.log("reset")
	  $("#containerNumber").val("");
	  $(".itv_container_single_second").removeClass("selected");
	  $(".itv_container_single_first").removeClass("selected");
	  $(".itv_container_single_forty").removeClass("selected");
	  $(".itv_container_twin_first").removeClass("selected");
	  $(".itv_container_twin_second").removeClass("selected");
	  $(".itv_container_single_second").data( "operation", "");
	  $(".itv_container_single_first").data( "operation", "");
      $(".itv_container_single_forty").data( "operation", "");
}



function loadContainerDetails(messageresult) {
	console.log("messageresult    " + messageresult);
	var messagedetails = messageresult.split("~")
	console.log("messagedetails" +messagedetails)
	var container_detials = "CONTAINER_DETAILS~";
	var message = messagedetails[1].split(" ");
	resetSlectedClassAndCntrNo();
	
	if (typeof messagedetails[4] != "undefined" || messagedetails[4] != null) {
		container_detials += messagedetails[4];
	}
	
	loadLocations();

	var result = messagedetails[0]
	console.log(result)
	console.log("REsult")
	var no_of_cntrs = 0;
	if (result == "DELAY_RECORDING") {
		processdelayrecording(messagedetails[1])
	} else if (result == "GEN_INSTRUCTION") {
		$(".gen_instruction_div").text(messagedetails[2]);
		$(".qc_details_inst").text("");
		hideConatinerRelatedDetails();
		processcontainerdetails(container_detials);
	} else if ( (result == "QC_INSTRUCTION") || (result == "PS_YARD_INSTRUCTION")) {
		console.log(messagedetails[4])
		console.log("QC/YARD")
		if (typeof messagedetails[4] == "undefined" || messagedetails[4] == null || messagedetails[4] == "") {
			hideConatinerRelatedDetails();
		}

		//if(messagedetails[3] != "" && typeof messagedetails[3] != "undefined" && messagedetails[3] != null){
		//$(".qc_details_inst").text("GO TO "+ messagedetails[3]);
		//var instructionToDisplay = ;
		//var previousInstruction = $(".qc_details_inst").text();
		//if(previousInstruction.indexOf("GO TO") > -1 && previousInstruction.indexOf(messagedetails[3]) == -1 && previousInstruction.indexOf(",") == -1){
		//instructionToDisplay = messagedetails[3];
		//alert(messagedetails[3])
		//}
		//}else{
		//$(".qc_details_inst").text("");
		//}
		$(".gen_instruction_div").text("");
		if (message[0] == "PS") {
			$(".jobdone_btn").prop("disabled", false);
			$(".jobdone_btn").css("background", "#0174cd");
			//			$(".arrived_btn").prop("disabled",true);
			//			$(".arrived_btn").css("background","#737373");
		} else {
			$(".jobdone_btn").prop("disabled", true);
			$(".jobdone_btn").css("background", "#737373");
			$(".arrived_btn").prop("disabled", false);
			$(".arrived_btn").addClass("arrived_btn");
		}
		processcontainerdetails(container_detials);
		$(".qc_details_inst").text("");
	//	$(".qc_details_inst").text("GO TO " + messagedetails[3]);
	} else if (result == "PLC_JOB_DONE") {
		console.log("PLC JOB DONE")
		hideConatinerRelatedDetails(messageresult);
		resettimer("#rms_timer1");
		//manualRefreshItv();
	} else if (result == "NORMAL_ALERT_MESSAGE") {
		processnormalalertmessage(messagedetails[1],messagedetails[2]);
	} else if (result == "CONTAINER_DETAILS") {
		console.log("CONTAINER_DETAILS")
		processcontainerdetails(messageresult)
	}
}

//function displayFollowItvMsg(messageResult){
//	$(".gen_instruction_div").text("");
//	var message= messageResult.split("~")
//	$(".gen_instruction_div").text(message[2]);
//}

function reset_instructions() {
	$(".first_location").html("")
	$(".second_location").html("")
}

function getFlagIconClass(iconId){
	  remarks_no_to_icon_map = {
	  		"1" : "hazardous_reefer",
		    "2" : "hazardous",
		    "3" : "reefer_1",
		    "4" : "reefer_2",
		    "5" : "reefer_3",
		    "6" : "reefer_4",
		    "7" : "over-dimentional_1",
		    "8" : "over-dimentional_2",
		    "9" : "over-dimentional_3",
		    "10" : "over-dimentional_4",
		    "11" : "over-dimentional_5",
		    "12" : "over-dimentional_6",
		    "13" : "damage",
		    "14" : "damage_low"
	  }
	  
	  if(typeof remarks_no_to_icon_map[iconId] != "undefined" ||  remarks_no_to_icon_map[iconId] != ""){
		  return remarks_no_to_icon_map[iconId];
	  }
}
function getCategoryIconClass(iconId){
	cat_no_to_icon_map = {
	    "T" : "tranship",
	    "I" : "import",
	    "E" : "export",
	    "R" : "restow"
	  }
	if(typeof cat_no_to_icon_map[iconId] != "undefined" ||  cat_no_to_icon_map[iconId] != ""){
		  return cat_no_to_icon_map[iconId];
	  }
}

function resetCounter(){
	resettimer("#rms_timer1");
	job_timer("#rms_timer1");
}


function processcontainerdetails(container_details) {
		console.log("container_details    "+container_details);
		$(".arrived_btn").prop("disabled", false);
	$(".jobdone_btn").prop("disabled", true);
	$(".jobdone_btn").css("background", "#737373");
	var container_details_array = container_details.split("|");
	console.log("container_details_array length"+container_details_array.length)
	var twinType = "aft";

	if (container_details_array.length == 1 && container_details_array[0] !== "CONTAINER_DETAILS~") {

		$("#truck_single_details_table").show();
		$("#truck_twin_details_table").hide();
		$(".itv_container_single").show();
		$(".itv_container_twin").hide();
		var single_container_details = (container_details_array[0].split("~")[1]).split("^");
		var first = single_container_details[0].substring(0,4);
		var last = single_container_details[0].substring(4,single_container_details[0].length);
		if (single_container_details[9] == "F") {
			console.log("in single 40");
			$(".itv_container_single_twenty, .itv_container_twin, #truck_single_details_table, #truck_twin_details_table,.itv_cntr_placeholder,.itv_placeholder").hide();
			$(".itv_container_single_forty, #truck_single_forty_details_table").show();
			if (single_container_details[0] != "undefined") {
				$("#itv_container_single_no").text(first); //text(single_container_details[0]);
				$("#itv_container_single_no_second").text(last); //.text(single_container_details[0]);
			} else {
				$("#itv_container_single_no").text("");
				$("#itv_container_single_no_second").text("");
			}

			if (single_container_details[11]=="fetch") {
				console.log("fetch -------")
				$(".itv_container_single_forty").css("border", "2px dashed black");
				$(".itv_container_single_forty").data( "operation", "fetch");
				$("#itv_container_single_no").css("color", "grey");
				$("#itv_container_single_no_second").css("color", "grey");
			} else {
				console.log("carry -------")
				$(".itv_container_single_forty").css("border", "2px solid black");
				$(".itv_container_single_forty").data( "operation", "carry");
				$("#itv_container_single_no").css("color", "green");
				$("#itv_container_single_no_second").css("color", "green");
			}

			//$('#discharge_cntr_no').html(single_container_details[0]);
			$("#truck_details_cont").html(single_container_details[0]);
			$("#truck_details_iso").html(single_container_details[1]);
			$("#truck_details_category").removeClass();
			$("#truck_details_category").addClass(getCategoryIconClass(single_container_details[7]));
			$("#truck_details_flag").removeClass();
			$("#truck_details_flag").addClass(getFlagIconClass(single_container_details[6]));
			$("#truck_details_weight").html(single_container_details[3]);
			$("#truck_details_dd").html(single_container_details[12]);
			$("#truck_details_status").html(single_container_details[8]);
			$("#truck_details_liftType").html(single_container_details[14]);
			$("#truck_details_reeferPoint").html(single_container_details[13]);
			
		} else if (single_container_details[9] == "T" && (single_container_details[10] == "FORWARD" || single_container_details[10] == "CENTER")) {
			console.log("in single 20 F");
		//	$(".itv_container_single_second").removeClass("selected");
		//	$(".itv_container_single_first").removeClass("selected");
			$("#hdnForwardCntDetails").val(container_details);
			$(".itv_container_single_forty, .itv_container_twin, #truck_single_forty_details_table, #truck_single_details_table, #truck_twin_details_table.itv_cntr_placeholder").hide();
			$(".itv_container_single_twenty, #truck_single_details_table").show();
			
			if(single_container_details[10] == "CENTER") {
				$(".itv_container_single_first").addClass("position-center");
				//alert("Placing in center");
			} else {
				$(".itv_container_single_first").removeClass("position-center");
				//alert("Placing in forward");
			}
			$("#itv_container_single_first_no").text(first);//single_container_details[0]);
			$("#itv_container_single_first_no_new").text(last);
			if (single_container_details[11]=="fetch") {
				console.log("fetch")
				$(".itv_container_single_first").css("border", "2px dashed black");
				$(".itv_container_single_first").data( "operation", "fetch");
				$("#itv_container_single_first_no").css("color", "grey");
				$("#itv_container_single_first_no_new").css("color", "grey");
				
			} else {
				console.log("carry")
				$(".itv_container_single_first").css("border", "2px solid black");
				$(".itv_container_single_first").data( "operation", "carry");
				$("#itv_container_single_first_no").css("color", "green");
				$("#itv_container_single_first_no_new").css("color", "green");
			}
			
			if(noOfContainers == 1){
				$("#truck_single_second_details_cont").hide();
				$("#truck_single_second_details_iso").hide();
				$("#truck_single_second_details_category").hide();
				$("#truck_single_second_details_flag").hide();
				$("#truck_single_second_details_weight").hide();
				$("#truck_single_second_details_dd").hide();
				$("#truck_single_second_details_status").hide();
				$("#truck_single_second_details_liftType").hide();
				$("#truck_single_second_details_reeferPoint").hide();
			}

			$("#truck_single_first_details_cont").show();
			$("#truck_single_first_details_iso").show();
			$("#truck_single_first_details_category").show();
			$("#truck_single_first_details_flag").show();
			$("#truck_single_first_details_weight").show();
			$("#truck_single_first_details_dd").show();
			$("#truck_single_first_details_status").show();
			$("#truck_single_first_details_liftType").show();
			$("#truck_single_first_details_reeferPoint").show();
			

			$("#truck_single_first_details_cont").html(single_container_details[0]);
			$("#truck_single_first_details_iso").html(single_container_details[1]);
			$("#truck_single_first_details_category").removeClass();
			$("#truck_single_first_details_category").addClass(getCategoryIconClass(single_container_details[7]));
			$("#truck_single_first_details_flag").removeClass();
			$("#truck_single_first_details_flag").addClass(getFlagIconClass(single_container_details[6]));
			$("#truck_single_first_details_weight").html(single_container_details[3]);
			$("#truck_single_first_details_dd").html(single_container_details[12]);
			$("#truck_single_first_details_status").html(single_container_details[8]);
			$("#truck_single_first_details_liftType").html(single_container_details[14]);
			$("#truck_single_first_details_reeferPoint").html(single_container_details[13]);
		} else if (single_container_details[9] == "T" && single_container_details[10] == "AFT") {
			console.log("in single 20 A");
			$("#hdnAftCntDetails").val(container_details);
			$(".itv_container_single_forty, .itv_container_twin, #truck_single_forty_details_table, #truck_twin_details_table,.itv_cntr_placeholder").hide();
			$(".itv_container_single_twenty, #truck_single_details_table").show();
			$("#itv_container_single_second_no").text(first);
			$("#itv_container_single_second_no_new").text(last);
			if (single_container_details[11]=="fetch") {
				console.log("fetch AFT")
				$(".itv_container_single_second").css("border", "2px dashed black");
				$(".itv_container_single_second").data( "operation", "fetch");
				$("#itv_container_single_second_no").css("color", "grey");
				$("#itv_container_single_second_no_new").css("color", "grey");
			} else {
				console.log("carryAFT")
				$(".itv_container_single_second").css("border", "2px solid black");
				$(".itv_container_single_second").data( "operation", "carry");
				$("#itv_container_single_second_no").css("color", "green");
				$("#itv_container_single_second_no_new").css("color", "green");
			}
			
			if(noOfContainers == 1){
				$("#truck_single_first_details_cont").hide();
				$("#truck_single_first_details_iso").hide();
				$("#truck_single_first_details_category").hide();
				$("#truck_single_first_details_flag").hide();
				$("#truck_single_first_details_weight").hide();
				$("#truck_single_first_details_dd").hide();
				$("#truck_single_first_details_status").hide();
				$("#truck_single_first_details_liftType").hide();
				$("#truck_single_first_details_reeferPoint").hide();
			}

			$("#truck_single_second_details_cont").show();
			$("#truck_single_second_details_iso").show();
			$("#truck_single_second_details_category").show();
			$("#truck_single_second_details_flag").show();
			$("#truck_single_second_details_weight").show();
			$("#truck_single_second_details_dd").show();
			$("#truck_single_second_details_status").show();
			$("#truck_single_second_details_liftType").show();
			$("#truck_single_second_details_reeferPoint").show();

			$("#truck_single_second_details_cont").html(single_container_details[0]);
			$("#truck_single_second_details_iso").html(single_container_details[1]);
			$("#truck_single_second_details_category").removeClass();
			$("#truck_single_second_details_category").addClass(getCategoryIconClass(single_container_details[7]));
			$("#truck_single_second_details_flag").removeClass();
			$("#truck_single_second_details_flag").addClass(getFlagIconClass(single_container_details[6]));
			$("#truck_single_second_details_weight").html(single_container_details[3]);
			$("#truck_single_second_details_dd").html(single_container_details[12]);
			$("#truck_single_second_details_status").html(single_container_details[8]);
			$("#truck_single_second_details_liftType").html(single_container_details[14]);
			$("#truck_single_second_details_reeferPoint").html(single_container_details[13]);
		}
		
	} else if (container_details_array.length === 2) {
		$("#truck_single_details_table").hide();
		$("#truck_twin_details_table").show();
		$(".itv_container_single").hide();
		$(".itv_container_twin").show();
		console.log("in twin");
		$(".itv_container_single_twenty, .itv_container_single_forty, #truck_single_forty_details_table, #truck_single_details_table,.itv_cntr_placeholder").hide();
		$(".itv_container_twin, #truck_twin_details_table").show();
		var first_container_details = (container_details_array[0].split("~")[1]).split("^");
		var second_container_details = container_details_array[1].split("^");
//		(first_container_details[10]);
//		if(first_container_details[10] == "AFT"){`
//			var tempContainerDetails = first_container_details;
//			first_container_details = second_container_details;
//			second_container_details = tempContainerDetails;
//		}
	//	alert(first_container_details)
	//	alert(second_container_details)
	
	

		var twinFirstTop = first_container_details[0].substring(0,4);
		var twinFirstBottom = first_container_details[0].substring(4,first_container_details[0].length);
		
		var twinSecondTop = second_container_details[0].substring(0,4);
		var twinSecondottom = second_container_details[0].substring(4,second_container_details[0].length);
	
	//var twin_first = $('itv_container_twin_first').children()[1];
	//$(twin_first).attr("id","itv_container_twin_first_no_new") ;
	//var twin_second = $('itv_container_twin_second').children()[1];
	//$(twin_second).attr("id","itv_container_twin_second_no_new") ;
	
	
			console.log("twinFirstTop: " + twinFirstTop );
			console.log("twinFirstBottom: " + twinFirstBottom );
			console.log("twinSecondTop: " + twinSecondTop );
			console.log("twinSecondottom: " + twinSecondottom );
	
		message_container_no = first_container_details[0] + "|" + second_container_details[0]
		
		if (first_container_details[9] == "T" && first_container_details[10] == "FORWARD"){
			$("#itv_container_twin_first_no").text(twinFirstTop);
			$("#itv_container_twin_first_no_new").text(twinFirstBottom);
			
			//$("#itv_container_single_first_no_new").text(twinFirstBottom);
			
			$("#truck_first_details_cont").html(first_container_details[0]);
			$("#truck_first_details_iso").html(first_container_details[1]);
			$("#truck_first_details_category").removeClass();
			$("#truck_first_details_category").addClass(getCategoryIconClass(first_container_details[7]));
			$("#truck_first_details_flag").removeClass();
			$("#truck_first_details_flag").addClass(getFlagIconClass(first_container_details[6]));
			$("#truck_first_details_weight").html(first_container_details[3]);
			$("#truck_first_details_dd").html(first_container_details[12]);
			$("#truck_first_details_status").html(first_container_details[8]);
			$("#truck_first_details_liftType").html(first_container_details[14]);
			$("#truck_first_details_reeferPoint").html(first_container_details[13]);
			
		}
		if (first_container_details[9] == "T" && first_container_details[10] == "AFT"){
		
			$("#itv_container_twin_second_no").text(twinFirstTop);
			$("#itv_container_twin_second_no_new").text(twinFirstBottom);
			
		//	$("#itv_container_single_second_no_new").text(twinFirstBottom);
			
			$("#truck_second_details_cont").html(first_container_details[0]);
			$("#truck_second_details_iso").html(first_container_details[1]);
			$("#truck_second_details_category").removeClass();
			$("#truck_second_details_category").addClass(getCategoryIconClass(first_container_details[7]));
			$("#truck_second_details_flag").removeClass();
			$("#truck_second_details_flag").addClass(getFlagIconClass(first_container_details[6]));
			$("#truck_second_details_weight").html(first_container_details[3]);
			$("#truck_second_details_dd").html(second_container_details[12]);
			$("#truck_second_details_status").html(first_container_details[8].split("~")[0]);
			$("#truck_second_details_liftType").html(first_container_details[14]);
			$("#truck_second_details_reeferPoint").html(first_container_details[13]);
		
		}
		if(second_container_details[9] == "T"&& second_container_details[10]=="FORWARD"){
			$("#itv_container_twin_first_no").text(twinSecondTop);
			$("#itv_container_twin_first_no_new").text(twinSecondottom);
			
			//$("#itv_container_single_first_no_new").text(twinSecondottom);
			
			$("#truck_first_details_cont").html(second_container_details[0]);
			$("#truck_first_details_iso").html(second_container_details[1]);
			$("#truck_first_details_category").removeClass();
			$("#truck_first_details_category").addClass(getCategoryIconClass(second_container_details[7]));
			$("#truck_first_details_flag").removeClass();
			$("#truck_first_details_flag").addClass(getFlagIconClass(second_container_details[6]));
			$("#truck_first_details_weight").html(second_container_details[3]);
			$("#truck_first_details_dd").html(second_container_details[12]);
			$("#truck_first_details_status").html(second_container_details[8]);
			$("#truck_first_details_liftType").html(second_container_details[14]);
			$("#truck_first_details_reeferPoint").html(second_container_details[13]);
		
		}
		if(second_container_details[9] == "T"&& second_container_details[10]=="AFT"){
		
			$("#itv_container_twin_second_no").text(twinSecondTop);
			$("#itv_container_twin_second_no_new").text(twinSecondottom);
			
			//$("#itv_container_single_second_no_new").text(twinSecondottom);
			
			
			$("#truck_second_details_cont").html(second_container_details[0]);
			$("#truck_second_details_iso").html(second_container_details[1]);
			$("#truck_second_details_category").removeClass();
			$("#truck_second_details_category").addClass(getCategoryIconClass(second_container_details[7]));
			$("#truck_second_details_flag").removeClass();
			$("#truck_second_details_flag").addClass(getFlagIconClass(second_container_details[6]));
			$("#truck_second_details_weight").html(second_container_details[3]);
			$("#truck_second_details_dd").html(second_container_details[12]);
			$("#truck_second_details_status").html(second_container_details[8].split("~")[0]);
			$("#truck_second_details_liftType").html(second_container_details[14]);
			$("#truck_second_details_reeferPoint").html(second_container_details[13]);
		
		}

	}
	// Display swap btn if atleast one 20 ft carry container is present on ITV - response coming as notification from communication port
	if (( ($("#itv_container_single_first_no").html() != "" && $("#itv_container_single_first_no").css("color")=="rgb(0, 128, 0)") || ($("#itv_container_single_second_no").html() != "" && $("#itv_container_single_second_no").css("color")=="rgb(0, 128, 0)"))&& single_container_details[9] != "F") {
		$(".swap_btn").show();
	} else {
		console.log("no swap btn")
		$(".swap_btn").hide();
	}
}

$(".swapdbtn_active").click(function() {
	$(".jobdone_btn").prop("disabled", true);
	$(".jobdone_btn").css("background", "#737373");
	processforlanenumber(message_container_no)
});

function processforlanenumber(message_container_no) {
	$.ajax({
		type: "POST",
		url: "/app/Login/Itv_pinningstation_selection",
		data: {
			message_container_no: message_container_no
		},
		success: function(result) {
			$(".arrived_btn").prop("disabled", false);
			$(".arrived_btn").addClass("arrived_btn");
		}
	});
}
function logout() {
	stoptimer();
	clearTimeout(qchome_time)
	$.ajax({
		url: "/app/Login/logout",
		success: function(result) {
			$(".main_content").html("");
			$(".main_content").html(result);
		}
	})
}

function processnormalalertmessage(messagedetails) {
	$("#alerts").html("")
	$("#alerts").html(messagedetails)
}
function processdelayrecording(messagedetails) {
	$.ajax({
		type: "POST",
		url: "/app/Login/delay_recording",
		data: {
			delayrecordingmessage: messagedetails
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			$("#delayrecording_data").msDropdown({ roundedBorder: false });
			document.getElementById('light').style.display = 'block';
		}
	})
	return false
}

function delay_recording() {
	$.ajax({
		type: "POST",
		url: "/app/Login/delayrecordingreason",
		data: {
			delayrecording_reason: $("#delayrecording_data").val()
		},
		success: function(result) {
			$('#light').html("")
			$('#light').html(result)
			document.getElementById('light').style.display = 'none';
		}
	})
	return false
}

//function sendUnavailableRes() {
//	var rmsdata = $("#rms_select").val()
//	if (rmsdata == "") {
//		showAlerts("Please Select One");
//		return false;
//	} else {
//		$('.unavilablereason').attr("disabled", true).addClass("disable_btns");
//		$.ajax({
//			url: "/app/Login/sendUnavailableRes",
//			data: {
//				popupType: "avilable",
//				rms_select: rmsdata
//			},
//			success: function(result) {
//				$('#light').html("")
//				$('#light').html(result)
//				document.getElementById('light').style.display = 'block';
//				$("#rms_timer").runner({
//					autostart: true,
//					milliseconds: false
//				});
//				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
//			},
//			error: function() {
//				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
//			}
//		});
//	}
//}

function sendOpenDelayDetails() {
	if($("#hdnDelayCodeData").html() != "") {
		confirmYesOrNo($("#hdnDelayCodeData").html() + " delay exists. Do you want to close it?", sendUnavailableRes)
	} else {
		sendUnavailableRes("T");
	}
}

var sendUnavailableRes = function(delayCloseInfo) {
	var rmsdata = $("#rms_select").val()
	if (rmsdata == "") {
		showAlerts("Please Select One");
	} else {
		$('.unavilablereason').attr("disabled", true).addClass("disable_btns");
		$("#hdnSelectedDelay").val(rmsdata);
		$.ajax({
			url: "/app/Login/sendUnavailableRes",
			data: {
				popupType: "avilable",
				rms_select: rmsdata,
				delayCloseInfo: delayCloseInfo
			},
			success: function(result) {
				$('#light').html("")
				$('#light').html(result)
				document.getElementById('light').style.display = 'block';
				$("#rms_timer").runner({
					autostart: true,
					milliseconds: false
				});
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			},
			error: function() {
				$('.unavilablereason').attr("disabled", false).removeClass("disable_btns");
			}
		});
	}
}
function sendAvailableRes() {
	var timerVal = $("#rms_timer").text();
	closePopup()
	$('.avilablereason').attr("disabled", true).addClass("disable_btns");
	$.ajax({
		type: "POST",
		url: "/app/Login/sendAvailableRes",
		data: {
			available_time: timerVal,
			selectedDelay: $("#hdnSelectedDelay").val()
		},
		success: function(result) {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		},
		error: function() {
			$('.avilablereason').attr("disabled", false).removeClass("disable_btns");
		}
	});
}
function closePopup() {
	$('#light').html("")
	document.getElementById('light').style.display = 'none';
}

var send_swap_details_server = function(containernos, itv_number, req_type) {
	$.ajax({
		type: "GET",
		url: "/app/Login/send_swap_request",
		data: {
			containerNumbers: containernos,
			itvNo: itv_number,
			req_type: req_type
		},
		success: function(result) { 
			console.log("ajax success")
		},
		error: function() { }
	}); 
}

function send_swap_details(containernos, itv_number, req_type) {
	swal({
      text: "Do you want to send swap details ?",
          showCancelButton: true,
          confirmButtonColor: '#00874F',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnConfirm: true
      },  
      function (isConfirm) {    
          if (isConfirm === true) {
        	  send_swap_details_server(containernos, itv_number, req_type);
          }else{
          }
      });
}

function swapContainersManual(req_type) {
	var containerPosition = swapContainers();
	var firstContainer_html = $("#itv_container_single_first_no").html();
	var firstContainer_html_new = $("#itv_container_single_first_no_new").html();
	console.log('req type '+req_type)
	console.log("firstContainer_html" + firstContainer_html)
	console.log("firstContainer_html_new" + firstContainer_html_new)
	if(firstContainer_html != "") {
		if(containerPosition == "none") {
			firstContainer_html = firstContainer_html + firstContainer_html_new + "^F";
		} else {
			if(containerPosition == "CENTER") {
				firstContainer_html = firstContainer_html + firstContainer_html_new + "^C";
			} else {
				firstContainer_html = firstContainer_html + firstContainer_html_new + "^F";
			}
		}
	}
	var secondContainer_html = $("#itv_container_single_second_no").html();
	var secondContainer_html_new = $("#itv_container_single_second_no_new").html();
	console.log("secondContainer_html" + secondContainer_html)
	console.log("secondContainer_html_new" + secondContainer_html_new)
	if(secondContainer_html != "") {
		secondContainer_html = secondContainer_html + secondContainer_html_new + "^A";
	}
	
	var containernos = "";
	
	if(firstContainer_html != "") {
		containernos = firstContainer_html + "|" + secondContainer_html;
	} else {
		containernos = secondContainer_html;
	}
	var itv_number = $(".itv_number").html();
	console.log("itv_number" + itv_number)
	console.log("containernos" + containernos)
	$.ajax({
		type: "GET",
		url: "/app/Login/swap_locations",
		data: {
			containerNumbers: containernos,
			itvNo: itv_number,
			req_type: req_type,
			containerPosition: containerPosition
		},
		success: function(result) { 
			console.log("ajax success")
			send_swap_details(containernos, itv_number, req_type)
		},
		error: function() { }
	}); 
}

function clear_details() {
	$(".itv_main_header_left").html("");

}

function swapContainers() {
	var containerPosition = "none"; // used in case of single 20 feet container
	if ($(".itv_container_twin").css("display") == "block") {
		var firstContainer_html = $("#itv_container_twin_first_no").html();
		var secondContainer_html = $("#itv_container_twin_second_no").html();
		$("#itv_container_twin_first_no").html(secondContainer_html);
		$("#itv_container_twin_second_no").html(firstContainer_html);
		$("#truck_twin_details_table tr").each(function() {
			var first_td_html = $(this)[0].children[1].innerHTML;
			var second_td_html = $(this)[0].children[2].innerHTML;
			$(this)[0].children[1].innerHTML = second_td_html;
			$(this)[0].children[2].innerHTML = first_td_html;
		});
	} else if ($(".itv_container_single_twenty").css("display") == "block") {
		
			if((($("#itv_container_single_first_no").html() != "") && ($("#itv_container_single_second_no").html() == "")) ||
				(($("#itv_container_single_first_no").html() == "") && ($("#itv_container_single_second_no").html() != ""))	) {
				
				var tempFirstContainer = $("#itv_container_single_first_no").html();	
					
				hideConatinerRelatedDetails();
				hdnForwardCntDetails = $("#hdnForwardCntDetails").val();
				if(tempFirstContainer != "") {
					if(hdnForwardCntDetails.indexOf("FORWARD") > -1) {
						var tempCntDetails = hdnForwardCntDetails.replace("FORWARD", "AFT");
						$("#hdnAftCntDetails").val(tempCntDetails);
						$("#hdnForwardCntDetails").val("");
						processcontainerdetails(tempCntDetails);
						containerPosition = "AFT"
					} else if(hdnForwardCntDetails.indexOf("CENTER") > -1) {
						var tempCntDetails = hdnForwardCntDetails.replace("CENTER", "FORWARD");
						$("#hdnForwardCntDetails").val(tempCntDetails);
						processcontainerdetails(tempCntDetails);
						containerPosition = "FORWARD"
					}
				} else {
					hdnAftCntDetails = $("#hdnAftCntDetails").val();
					if(hdnAftCntDetails != "") {
						if(hdnAftCntDetails.indexOf("AFT") > -1) {
							var tempCntDetails = hdnAftCntDetails.replace("AFT", "CENTER");
							$("#hdnAftCntDetails").val();
							$("#hdnForwardCntDetails").val(tempCntDetails);
							processcontainerdetails(tempCntDetails);
							containerPosition = "CENTER"
						}
					}
				}
			} else {
				console.log("Length 2");
				var hdnForwardCntDetails = $("#hdnForwardCntDetails").val();
				var hdnAftCntDetails = $("#hdnAftCntDetails").val();
				var tempCntDetails = hdnForwardCntDetails.replace("FORWARD", "AFT");
				$("#hdnAftCntDetails").val(tempCntDetails);
				processcontainerdetails(tempCntDetails);
				tempCntDetails = hdnAftCntDetails.replace("AFT", "FORWARD");
				$("#hdnForwardCntDetails").val(tempCntDetails);
				processcontainerdetails(tempCntDetails);
			}
		}
	
		return containerPosition;
}

function updatePerformancefields(messagedetails) {
	var qcviewattributes = messagedetails.split("|")
	$(".expected_mph").html(qcviewattributes[5]);
	$(".current_mph").html(qcviewattributes[1]);
	$("#moves_to_go").text(qcviewattributes[3])
	$("#target_compl_time").text(qcviewattributes[2])
	$("#moves_behind").text(qcviewattributes[4])
	$("#target_moves").text(qcviewattributes[0])
	$("#grossmoves").text(qcviewattributes[1])
	var mph = Number(qcviewattributes[1]);
	var performance = mph / Number(qcviewattributes[5]) * 100;
	$('#progressbar').progressbar('setPosition', performance);
}

function register_call(){
	$.ajax({
		type: "GET",
		url: "/app/Login/register_call",
		success: function(result) {
			closePopup()
			showAlerts("Call registered successfully");	
		}
	})
}

function add_lane_number(lane_num){
	if(lane_num != ""){
	console.log("lane_num----tariq" + lane_num)
		$(".qc_details_inst").append("=>"+lane_num)
	}
}