function virtualKeyboard(){

	$('input[type="text"]:not(#msg_equipmentId),  input[type="password"], .ui-autocomplete-input').keyboard({

		display: {
			'bksp'   : '\u2190',
			'enter'  : '\u23CE',
			'default': '123',
			'meta1'  : 'ABC',
			'meta3'  : '#+=',
			'meta2'  : 'abc',
			'accept' : 'OK',
		    'cancel' : 'CANCEL'	   
		},
		autoAccept : true,
		layout: 'custom',
		customLayout: {
			'default': [
				'1 2 3 T',
				'4 5 6 H',
				'7 8 9 TH',
				'0 . {bksp} {s}',
				'{meta1} {cancel} {accept}'
			],
			'shift': [
				'1 2 3 t',
				'4 5 6 h',
				'7 8 9 th',
				'0 . {bksp} {s}',
				'{meta1} {cancel} {accept}'
			],					
			'meta1': [
			'Q W E R T Y U I O P {bksp}',
			'A S D F G H J K L',
			'Z X C V B N M . {meta2}',
			'{default} {meta3} {space} {cancel} {accept}'
			],
			'meta2': [
			'q w e r t y u i o p {bksp}',
			'a s d f g h j k l',
			'z x c v b n m . {meta1}',
			'{default} {meta3} {space} {cancel} {accept}'
			],
			'meta3': [
				'[ ] { } \u2039 \u203a ^ * " , {bksp}',
				'@ \\ | / $ \u00a3 \u00a5 \u2022 ?',
				'& ~ # = + . !',
				'{default} {meta1} {space} {cancel} {accept}'
			]
		}
});
	$('input[type="number"]').keyboard({
		layout : 'num',
		restrictInput : true, // Prevent keys not in the displayed keyboard from being typed in
		preventPaste : true,  // prevent ctrl-v and right click
		autoAccept : true
	});
}
