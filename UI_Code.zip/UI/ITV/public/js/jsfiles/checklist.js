$(document).ready(function() {
	$('.user-toggle').click(function() {
		$('.user_profile,.user-toggle').css("background-color", "#3b3e45");
		$('.user-toggle').css("border", "0px");
		var collapse_content_selector = $(this).attr('href');
		var toggle_switch = $(this);
		$(collapse_content_selector).toggle(function() {
			if ($(this).css('display') == 'none') {
			}
		});
	});
	$("input[type='checkbox']").attr('checked', 'checked');

	$('#cnfrmbtn').on('click', function() {
			var checklist = $(".chklist :input").serialize();
			$('#cnfrmbtn').attr("disabled", true).addClass("disable_btns");
			$(".error-message").text("");
			$.ajax({
				type: "POST",
				url: "/app/Login/home",
				data: checklist,
				success: function(result) {
					if (result != "Error") {
						$(".main_layout").html("");
						$(".main_layout").html(result);
					} else {
						$('#cnfrmbtn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					console.log("inChekcIstErrr");
					$('#cnfrmbtn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		})

	$('#cancelbutn').on('click', function() {
			var checklistcancel = $(".chklist :input").serialize();
			$('#cancelbutn').attr("disabled", true).addClass("disable_btns");
			$.ajax({
				type: "POST",
				url: "/app/Login/cancel",
				data: checklistcancel,
				success: function(result) {
					if (result != "Error") {
						$(".main_layout").html("");
						$(".main_layout").html(result);
					} else {
						$('#cancelbutn').attr("disabled", false).removeClass("disable_btns");
					}
				},
				error: function() {
					$('#cancelbutn').attr("disabled", false).removeClass("disable_btns");
				}
			});
		})

});