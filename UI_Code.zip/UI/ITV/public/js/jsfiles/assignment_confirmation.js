$(document).ready(function() {
	 virtualKeyboard(); 
	$("#sel1").val("Operational");
	$("#sel1").msDropdown({ roundedBorder: false });
	$("#sel2").msDropdown({ roundedBorder: false });
	$("#select_rotationId").msDropdown({ roundedBorder: false });
	
	$("#selectTrailerID").msDropdown({ roundedBorder: false });
	
	$('select[value]').each(function() {
		$(this).val(this.getAttribute("value"));
	});

	hideSelectOptions();
	$('#sel1').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Non-Operational") {
			$('#sel2field').removeClass('hidden');
			$('#otherOptTextfield').removeClass('hidden');
		} else {
			hideSelectOptions();
		}
	});

	$('#sel2').change(function() {
		var selectedOption = $(this).val();
		if (selectedOption == "Other") {
			$('#otherOptTextfield').show();
			$('#otherOptTextfield').removeClass('hidden');
		} else {
			$('#otherOptTextfield').hide();
		}
	});
	$('#select_rotationId').change(function() {
		var selectedOption = $(this).val();
		$("#rotation_select")[0].value = selectedOption;
	});
	function hideSelectOptions() {
		$('#sel2field').addClass('hidden');
		$('#otherOptTextfield').hide();
		$('#otherOptTextfield').addClass('hidden');
	}

	function validateInputs() {
		if ($('#sel1').val() === "Non-Operational") {
			if ($('#sel2').val() === "" || $('#sel2').val() === null) {
				return false;
			} else if ($('#sel2').val() === "Other") {
				if ($("#otherOptText").val() === "" || $("#otherOptText").val() === null) {
					return false;
				}
			}
		}
		if ($('#rotation_select').val() === "" || $('#rotation_select').val() === null || $('#msg_equipmentId').val() === "" || $('#msg_equipmentId').val() === null || $('#msg_terminalId').val() == "" || $('#msg_terminalId').val() === null) {
			return false;
		}
		return true;
	}
	
	var selectTrailerID = $("#selectTrailerID");
	selectTrailerID.change(function(){
		$("#msg_trailerId_txt")[0].value = $("#selectTrailerID option:selected").html();
	})
	
	jQuery.fn.filterByText = function(textbox, selectSingleMatch) {
		  return this.each(function() {
		    var select = this;
		    var options = [];
		    $(select).find('option').each(function() {
		      options.push({value: $(this).val(), text: $(this).text()});
		    });
		    $(select).data('options', options);
		    $(textbox).bind('change keyup', function() {
		      $("#selectTrailerID").msDropDown().data("dd").destroy();
		      var options = $(select).empty().scrollTop(0).data('options');
		      var search = $.trim($(this).val());
		      var regex = new RegExp(search,'gi');
		      console.log("regex"+regex)
		      $.each(options, function(i) {
		        var option = options[i];
		        if(option.text.match(regex) !== null) {
		        	$(select).append(
		        		$('<option>').text(option.text).val(option.value)
		          );
		        }
		      });
		      $(select).msDropdown().data("dd").refresh();
		      if (selectSingleMatch === true && 
		          $(select).children().length === 1) {
		         console.log("singlematch")
		        $(select).children().get(0).selected = true;
		      }
		    });
		  });
		};
		
		
		$(function() {
			  $('#selectTrailerID').filterByText($('#msg_trailerId_txt'), true);
			});

	$('#confirm_allocation').on('click', function(e) {
			if (validateInputs()) {
				var allocation = $(".assign_confirmation :input").serialize();
				$('#confirm_allocation').attr("disabled", true).addClass("disable_btns");
				$('.login_exit').attr("disabled", true).addClass("disable_btns");
				var trailerIdTxt= $("#msg_trailerId_txt").val();
				console.log("trailerIdTxt"+trailerIdTxt)
				$.ajax({
					type: "POST",
					url: "/app/Login/checklist",
					data: allocation,
					success: function(result) {
						if (result != 'Error') {
							$(".main_layout").html("");
							$(".main_layout").html(result);
						} else {
							$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
							$('.login_exit').attr("disabled", false).removeClass("disable_btns");
						}
					}
					,
					error: function() {
						$('#confirm_allocation').attr("disabled", false).removeClass("disable_btns");
						$('.login_exit').attr("disabled", false).removeClass("disable_btns");
					}
				});
			} else {
				showAlerts("Please fill all fields");
			}
		})

}); 