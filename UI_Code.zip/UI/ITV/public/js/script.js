$(document).ready(function() {
		  $('.user-toggle').click(function(){
			//get collapse content selector
			 $('.user_profile,.user-toggle').css("background-color","#3b3e45");
			  $('.user-toggle').css("border","0px");
			var collapse_content_selector = $(this).attr('href');					
 
			//make the collapse content to be shown or hide
			var toggle_switch = $(this);
			$(collapse_content_selector).toggle(function(){
			  if($(this).css('display')=='none'){
                                //change the button label to be 'Show'
				
			  }
			});
		  });
 });	
