require 'rho/rhocontroller'
require 'helpers/browser_helper'

class ItvController < Rho::RhoController
  include BrowserHelper

  # GET /Itv
  def index
    @itvs = Itv.find(:all)
    render :back => '/app'
  end

  # GET /Itv/{1}
  def show
    @itv = Itv.find(@params['id'])
    if @itv
      render :action => :show, :back => url_for(:action => :index)
    else
      redirect :action => :index
    end
  end

  # GET /Itv/new
  def new
    @itv = Itv.new
    render :action => :new, :back => url_for(:action => :index)
  end

  # GET /Itv/{1}/edit
  def edit
    @itv = Itv.find(@params['id'])
    if @itv
      render :action => :edit, :back => url_for(:action => :index)
    else
      redirect :action => :index
    end
  end

  # POST /Itv/create
  def create
    @itv = Itv.create(@params['itv'])
    redirect :action => :index
  end

  # POST /Itv/{1}/update
  def update
    @itv = Itv.find(@params['id'])
    @itv.update_attributes(@params['itv']) if @itv
    redirect :action => :index
  end

  # POST /Itv/{1}/delete
  def delete
    @itv = Itv.find(@params['id'])
    @itv.destroy if @itv
    redirect :action => :index  
  end
end
