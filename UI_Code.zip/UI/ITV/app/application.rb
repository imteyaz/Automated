require 'socket'
require 'thread'
require 'rho/rhocontroller'
require 'helpers/browser_helper'
require 'helpers/socket_helper'
require 'helpers/itv_helper'
require 'rho/rhoapplication'
require 'net/http'
require 'uri'
require 'time'
require 'date'

class AppApplication < Rho::RhoApplication
  def initialize
    # Tab items are loaded left->right, @tabs[0] is leftmost tab in the tab-bar
    # Super must be called *after* settings @tabs!
    @tabs = nil
    @@toolbar = nil
    super
    @default_menu = {}
    $myThread ||= {}
    $session ||= {}
    $udp_socket = nil
    $location = ""
    $loggedout = false
    $loggedin = false
    $first_location = ["", ""]
    $second_location = ["", ""]
    $containerdtls = ""
    $session[:checkForMsg] = Array.new
    $arrived_button_clicked = false
    #To remove default toolbar uncomment next line:
    #@@toolbar = nil

    # Uncomment to set sync notification callback to /app/Settings/sync_notify.
    # Rho::RhoConnectClient.setObjectNotification("/app/Settings/sync_notify")
    Rho::RhoConnectClient.setNotification('*', "/app/Settings/sync_notify", '')

    $local_com_ip = Rho::RhoConfig.local_ip_to_use == "system" ? UDPSocket.open {|s| s.connect(Rho::RhoConfig.com_server_ip, 1); s.addr.last } : Rho::RhoConfig.local_com_ip
    #    $local_com_ip = UDPSocket.open {|s| s.connect('127.0.0.1', 1); s.addr.last }
    #    $local_com_ip = Socket.gethostname
    puts $local_com_ip.inspect
    puts "Local ip address"
    $device_id = (Rho::RhoConfig.device_selection == "device") ? Socket.gethostname : Rho::RhoConfig.deviceid
    puts $device_id.inspect
    puts "Device id"
  end

  def on_activate_app
    $msg_hash = {1200=>"1201,1203,1400",1204=>"1400",1401=>"1402,9998",1403=>"1300", 1404=>"1300", 2002=>"2002",2000=>"2000",2002=>"2003",1300=>"1304",1500=>"1500",3100=>"3101" , 1610 => "1611,1612"}
  end

  def on_ui_destroyed
    puts "**********Application Have Been destroyed.***************"
    super
    puts "logged info"
    puts $loggedout.inspect
    puts $loggedin.inspect
    if(!$loggedout && $loggedin == true)
      $no_of_wait_trails = 5
      $checkForITVArrivedFlag = false
      org_string = "device3" + Time.now.strftime("%d%m%Y%H%M%S")
      encoded_string = org_string.hash
      msg = "1~1~9999~#{encoded_string}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      puts "Send Request To Server On Destroying Application:- "+msg.inspect
      $udp_socket.send msg, 0, Rho::RhoConfig.com_server_ip,Rho::RhoConfig.com_server_port
    end

    if $udp_socket != nil
      $udp_socket.flush()
      $udp_socket.close()
    end
    if $poll_socket != nil
      $poll_socket.flush()
      $poll_socket.close()
    end

  end

  def on_deactivate_app
    puts "**********Application Have Been Deactivated.***************"
  end

  def serve( req, res )
    begin
      super
    rescue Exception => ex
      puts ex.to_s().inspect
      WebView.execute_js("displayErrorAlert('Unable to Process your request Server May Be Down')")
      raise
    end
  end
end
