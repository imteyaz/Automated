class NonOperationalController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include ItvHelper
  #Get Dynamic Labor Management
  def dynamic_labor_management
    render :action => :dlm
  end

  #Get Communication by message or Voice
  def message_voice_calls
    render :action => :communication
  end

  #Show technical support page
  def techinal_support
    render :action => :technical_support
  end

  #Get technical support details from server
  def technical_support_details
    @udp_req_obj[:msg] = "1~1~3100~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("3101" == resp_msg_id)
        @problem_code = resp_fields[4]
        @location = resp_fields[3]
        @equipment_id = resp_fields[2]
        render :action => "tech_support_details"
      else
        render :string => "Error"
      end
    else
      render :string => "Error"
    end
  end

  #Sending Technical support details to server
  def send_technical_support_details
    @udp_req_obj[:msg] = "1~1~3102~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['location']}~#{@params['problem_code']}~#{@params['problem_description']}~#{@params['location_description']}~#{@params['asset_number']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

end