class LoginController < Rho::RhoController
  include BrowserHelper
  include SocketHelper
  include ItvHelper
  def index
    $myThread  = Thread.start{waitforITVArrived()}
  end

  #Setting UDP Connection
  def set_udp_connection
    $containers_swapped = false;
    @msg=""
    if( @params['login'].empty? || @params['password'].empty?)
      @msg = "Un-Authorized Access"
      render :action => :index
    end
    $currentmph = 0
    $expectedmph = 0
    $userid = @params['login'].upcase
    @udp_req_obj[:msg] = "1~1~1200~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['password']}~#{$device_id}~ITV~#{@params['salt']}~#{@params['iv']}"
    $loggedout = false
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if(resp.length < 0)
      render :action => :index
    end
    resp_fields = resp.to_s.split("~")
    resp_msg_id = resp_fields[0]
    #    if(resp_msg_id != 1201)
    #      $myThread  = Thread.start{waitforITVArrived()}
    #      p "starting thread"
    #    end
    if(resp_msg_id == "1201") # Login failure
      @msg = resp_fields[3]
      render :action => :index
    elsif("1400" == resp_msg_id)
      @msges,@msg_non_operational,@msges_eq,@msges_loc,@msges_ter,@msges_trailer = processconfirmation_checklist(resp_fields)
      $loggedin = true
      render :action =>  :asignment_confirmation
    elsif(resp_msg_id == "1203")
      @msg_lateLogin_reasons,@msg_lateby_mins = processlatelogin(resp_fields)
      $loggedin = true
      render :action => :latelogin
    else
      render :action => :index
    end
  end

  def processconfirmation_checklist(resp_fields)
    msges = resp_fields[3].to_s.split("|")
    msg_non_operational = resp_fields[4].to_s.split("|")
    msges_eq = "#{resp_fields[5]}"
    $itv_no = msges_eq
    msges_loc = "#{resp_fields[6]}"
    msges_ter = "#{resp_fields[10]}"
    msges_trailer = resp_fields[8].to_s.split("|")
    $terminal_id = msges_ter
    selectedLang = "#{resp_fields[7]}".to_s
    if !selectedLang.empty?
      System::set_locale(selectedLang)
    end
    return msges,msg_non_operational,msges_eq,msges_loc,msges_ter,msges_trailer

  end

  def processlatelogin(resp_fields)
    msg_lateLogin_reasons = resp_fields[3].split("|")
    msg_lateby_mins = resp_fields[2]
    return msg_lateLogin_reasons,msg_lateby_mins
  end

  # From late_login to Assignment_Confirmation
  def assign_confrm
    @udp_req_obj[:msg] = "1~1~1204~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['lateloginreason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if("1400" == resp_msg_id)
        @msges,@msg_non_operational,@msges_eq,@msges_loc,@msges_ter,@msges_trailer = processconfirmation_checklist(resp_fields)
        render :action => :asignment_confirmation
      else
        render :action => :index
      end
    end
  end

  def swap_locations
    itvNo = @params['itvNo']
    containerno = @params['containerNumbers']

    tempLocation = $first_location[0]
    tempLocation_container = $first_location[1]
    $first_location[0] = $second_location[0]
    $first_location[1] = $second_location[1]
    $second_location[0] = tempLocation
    $second_location[1] = tempLocation_container

    WebView.execute_js('loadLocations()')

    if ($containerdtls.include? "|")
      container_array = $containerdtls.split("|")
      $containerdtls = container_array[1] + "|" + container_array[0]
    end

    $containers_swapped = true;
  end

  def send_swap_request
    itvNo = @params['itvNo']
    containerno = @params['containerNumbers']

    if @params["req_type"] == "manual"
      @udp_req_obj[:msg] = "1~1~2206~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{itvNo}~#{containerno}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end

  end

  # From Assignment_Confirmation to Checklist
  def checklist
    $equipment_id = @params['msges_eq']
    $trailer_id = @params['msges_trailer'].strip
    location=''
    @udp_req_obj[:msg] = "1~1~1401~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~~#{@params['msges']}~#{ @params['msges_eq']}~#{ location}~#{ @params['remarks']}~#{$trailer_id}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "1402")
        resp_msg_checklist = resp_fields[2]
        @resp_userid = resp_fields[3]
        @resp_termid = resp_fields[4]
        msg_checklist = resp_msg_checklist.to_s.split('|')
        @resp_checklist = Array.new
        msg_checklist.each do |check_list|
          @resp_checklist.push(check_list.to_s().split('^'))
        end
        render :action => :checklist
      elsif(resp_msg_id == "9998")
        res = resp_fields[3]
        WebView.execute_js('showAlerts("'+ res.to_s() + '")')
        render :string => "Error"
      else
        render :action => :assignment_confirmation
      end
    else
      WebView.execute_js("showAlerts('Server is not responding')")
      render :string => "Error"
    end
  end

  #Getting Checklist icon
  def get_checklist_item_icon(item_no)
    item_no_to_icon_map = {"1" => "chkimg", "2" => "chkimgalert", "3" => "chkimgerror"}
    return item_no_to_icon_map.fetch(item_no, "chkimg")
  end

  def display_location
    render :partial => "../Itv/itv_locations", :locals => { :ad => "" }
  end

  def process_auto_updates(resp)
    resp_fields = resp.to_s.split("~")
    if(resp_fields[2] != resp_fields[3])
      update_source_code(resp_fields[3])
    end
    return true
  end

  def update_source_code(version_no)
    #Download a file to the specified filename.
    begin
      #    downloadfileProps = Hash.new
      #    downloadfileProps["url"]='http://127.0.0.1:8082/ATOMMobileAppRel/HC/31-05-2017_HC.zip'
      #    downloadfileProps["filename"] = Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/31-05-2017_HC.zip")
      #    downloadfileProps["overwriteFile"] = true
      #    Rho::Network.downloadFile(downloadfileProps, url_for(:action => :download_file_callback))

      response = Net::HTTP.get_response(URI.parse(Rho::RhoConfig.auto_update_url+"/#{version_no}.zip"))
      File.open(Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip"), "wb") do |saved_file|
        saved_file.write(response.body)
      end

      puts "Finished downloading"
      puts "Creating folder"
      #    stdin, stdout, stderr = Open3.popen3('cscript C:\Users\1102519\Desktop\Projects\HC_UI_STD\public\unzip.vbs')
      #    parse_instances("bash C:/Users/1102519/Desktop/Projects/HC_UI_STD/public/unzip.vbs")

      system "cscript //nologo #{Rho::Application.publicFolder}/unzip.vbs #{Rho::RhoFile.join(Rho::Application.publicFolder, "/updates/#{version_no}.zip")} #{Rho::RhoConfig.path_to_extract}"
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~true~#{version_no}~"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      Rho::Application.quit
    rescue Exception => e
      puts "Exception in updating source code"
      puts e.message.inspect
      @udp_req_obj[:msg] = "1~1~1119~#{geteventid}~#{$device_id}~false~#{version_no}~#{e.message.to_s()}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
    return true
  end

  def process_itv_instruction(resp_fields)
    $movetype = resp_fields[8]
    $fetch_details = resp_fields[9]
    $first_location = ["",""]
    $second_location = ["",""]
    if(resp_fields[2] == "GEN")
      @msg_gen = resp_fields[3]
    elsif(resp_fields[2] == "QC" || (resp_fields[2] == "PS") || (resp_fields[2] == "YARD"))
      puts "Came in QC"
      containers_to_process = resp_fields[5].split("|")
      if(containers_to_process != nil)
        WebView.execute_js('initTotalContCount("'+ containers_to_process.length.to_s() +'")')
      end
      #      puts "containers_to_process"
      #      puts containers_to_process.inspect
      ##      containers_to_process.each do |container|
      ##        puts container.inspect
      #        if(resp_fields[5] != "" && resp_fields[5] != "null" && resp_fields[5] != nil)
      #          container_details = resp_fields[5].split("^")
      #          if(container_details[10] == "FORWARD") # if forward(twenty feet) container
      #            $first_location[1] = container_details[0]
      #            $first_location[0] = resp_fields[4].split("|").join(",")
      #          else
      #            $second_location[1] = container_details[0]
      #            $second_location[0] = resp_fields[4].split("|").join(",")
      #          end
      #
      #          if(container_details[9] == "F")
      #            $first_location[1] = container_details[0]
      #            $first_location[0] = resp_fields[4].split("|").join(",")
      #            $second_location[1] = ""
      #            $second_location[0] = ""
      #          end
      #        else
      #          if(resp_fields[4] == nil || resp_fields[4] == "null" || resp_fields[6] == nil || resp_fields[6] == "null")
      #            $first_location = ["",""]
      #            $second_location = ["",""]
      #          else
      #            $first_location[1] = ""
      #            $first_location[0] = resp_fields[4].split("|").join(",")
      #            $second_location = ["",""]
      #          end
      #        end
      containers_to_process.each_with_index  do |container, index|
        if(container != "" && container != "null" && container != nil)
          container_details = container.split('^')
          $containerdtls = resp_fields[5]
          puts container.inspect
          puts "Container Details are as of above"
          if(container_details[10] == "FORWARD" || container_details[10] == "")
            $first_location[1] = container_details[0]
            $first_location[0] = resp_fields[4].split("|")[index]
          else
            $second_location[1] = container_details[0]
            $second_location[0] = resp_fields[4].split("|")[index]
          end

          if(container_details[9] == "F")
            $first_location[1] = container_details[0]
            $first_location[0] = resp_fields[4].split("|")[index]
            $second_location[1] = ""
            $second_location[0] = ""
          end
        else
          if(resp_fields[4] == nil || resp_fields[4] == "null" || resp_fields[6] == nil || resp_fields[6] == "null")
            $first_location = ["",""]
            $second_location = ["",""]
          else
            $first_location[1] = ""
            $first_location[0] = resp_fields[4].split("|").join(",")
            $second_location = ["",""]
          end
        end
      end
      $containerdtls = resp_fields[5]

      $laneID = resp_fields[6]
      @driverdirection = resp_fields[7]
      #    elsif((resp_fields[2] == "PS") || (resp_fields[2] == "YARD"))
      #      $location = resp_fields[4]
      #      $containerdtls = resp_fields[5]
      #      if(resp_fields[4] == nil || resp_fields[4] == "null")
      #        @msg = ""
      #      else
      #        @msg = "GO TO "+resp_fields[4]
      #      end
    end
    #    end
    puts $first_location.inspect
    puts $second_location.inspect
    puts @driverdirection.inspect
    puts "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    render :action => "../Itv/index"
  end

  # Checklist cancel
  def cancel
    @udp_req_obj[:msg] = "1~1~1404~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      resp_qc_list = resp_fields[2].to_s.split('|')
      @resp_qc_job = Array.new
      resp_qc_list.each do |check_list_item|
        @resp_qc_job.push(check_list_item.to_s.split('^'))
      end
      if ("1303" == resp_msg_id)
        @msg2 = ""
        @msg3 = ""
        @msg4 = "#{resp_fields[2]}"
        @msg_popup_reasons=resp_fields[1].split("|")
        render :action => "../Itv/index"
      elsif(resp_msg_id == "1300")
        process_itv_instruction(resp_fields)
#        WebView.execute_js('add_lane_number("'+ $laneID.to_s() + '")')
      elsif(resp_msg_id == "2000")
        @msg_popup_reasons=resp_fields[1].split("|")
        render :action => "../Itv/index"
      else
        render :action => :checklist
      end
    end
  end

  # Checklist check operation
  def preOperationalChecklistStatus
    @params['chk_list'] ||= []
    completeChecklistStatus = (@params['chk_list'].map {|item| item = item + "^p" }).join("|")
    if completeChecklistStatus.length > 4900
      message_string =  completeChecklistStatus.scan(/.{1,1024}/)
      for iMsgindx in 1..message_string.length
        @udp_req_obj[:msg] = "iMsgindx~message_string.length~1403~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{message_string[iMsgindx]}~p"
        if(iMsgindx == message_string.length)
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
        else
          resp,eventType = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
        end
      end
    else
      @udp_req_obj[:msg] = "1~1~1403~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{completeChecklistStatus}~p"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    end
    return resp
  end

  # From Checklist to Itv index
  def home
    resp = preOperationalChecklistStatus()
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      @details = resp_fields[5]

      if (resp_msg_id == "1300")
        process_itv_instruction(resp_fields)
#        WebView.execute_js('add_lane_number("'+ $laneID.to_s() + '")')
      else
        render :action => :checklist
      end
    end
  end

  $checkForITVArrivedFlag = true

  def process_performance(resp)
    resp_fields = resp.to_s.split("~")
    qc_view = resp_fields[3].to_s+"|"+resp_fields[4].to_s + "|"+resp_fields[5].to_s + "|"+ resp_fields[6].to_s + "|"+resp_fields[7].to_s + "|"+resp_fields[8].to_s
    WebView.execute_js('updatePerformancefields("'+ qc_view.to_s() + '")')
  end

  #thread function for polling messages
  def waitforITVArrived
    resp = ""
    while($checkForITVArrivedFlag)
      resp = recv_response($udp_socket, 1, 1)
      container = ""
      if resp.length > 0
        resp_fields = resp.to_s.split("~")
        resp_msg_id = resp_fields[0]
        if(resp_msg_id == "9996")
          processdelayrecording(resp)
        elsif(resp_msg_id == "1300")
          puts "RECEIVED DRIVE INSTRUCTION"
          processforlanenumber(resp)
#          WebView.execute_js('add_lane_number("'+ $laneID.to_s() + '")')
        elsif(resp_msg_id == "1302")
          processFollowITV(resp)
        elsif(resp_msg_id == "1601")
          processjobdone(resp)
        elsif(resp_msg_id == "1301")
          processcontainerdetails(resp)
        elsif(resp_msg_id == "9998")
          processworkstopalert(resp)
        elsif(resp_msg_id == "9993")
          process_freeze_unfreeze_app(resp)
        elsif(resp_msg_id == "9994" || resp_msg_id == "9992" ||resp_msg_id == "9910")
          processnormalalertmessage(resp)
        elsif(resp_msg_id == "1309")
          swapcontainers(resp,"auto")
        elsif(resp_msg_id == "9999")
          forcelogout(resp)
        elsif(resp_msg_id == "9995")
          process_performance(resp)
        elsif(resp_msg_id == "1118")
          process_auto_updates(resp)
        else
          puts resp.inspect
        end
      end
    end
  end

  # From Itv index to Itv_arrived
  def Itv_arrived
    arrived_location = ""
    if($first_location[0] != "")
      arrived_location = $first_location[0]
    elsif($second_location[0] != "")
      arrived_location = $second_location[0]
    end

    if($arrived_button_clicked == false)
      $arrived_button_clicked = true
      WebView.execute_js('resetCounter()')
    end

    if ($containerdtls != nil)
      containerDetails = $containerdtls.split("|")
      @containerID = ""
      @containerIDs = Array.new
      containerDetails.each do |containerDetails|
        containerDtls =  containerDetails.split("^")
        @containerIDs.push(containerDtls)
        @containerID += containerDtls[0] + "|"
      end
      @udp_req_obj[:msg] = "1~1~1304~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{arrived_location}~#{@containerID}~#{$laneID}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)

    else
      @udp_req_obj[:msg] = "1~1~1304~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{arrived_location}~"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
  end

  # It displays a container details on the truck
  def container_number_display
    resp_fields = @params['container_data'].split("|")
    @containerlist = ""
    @containerDtls = Array.new
    resp_fields.each do |resp_field|
      contrdtls = resp_field.split("^")
      @containerDtls.push(contrdtls)
      @containerlist += contrdtls[0] + " "
    end
    render :action => '../Itv/containerDtls'
  end

  # Go's to pinning station event
  def Itv_pinningstation_selection
    @udp_req_obj[:msg] = "1~1~1500~#{geteventid}~#{$userid}~2~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{$location}~#{@params['message_container_no']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  def getunavlblereasons
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2000~#{geteventid}~#{$userid}~#{$terminal_id}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2000")
        @msg = resp_fields[2].split("|")
        @open_delay_data = resp_fields[3]
      end
    end
    render :action => '../Itv/rmspopup_handling'
  end

  def sendUnavailableRes
    @popupType = @params['popupType']
    @msg= ""
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~F~#{@params['rms_select']}~~#{@params['delayCloseInfo']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
      if(resp_msg_id == "2003")
        @msg = resp_fields[2]
      end
    end
    render :action => '../Itv/rmspopup_handling'
  end

  def sendAvailableRes
    @udp_req_obj[:msg] = "1~1~2002~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~T~#{@params['selectedDelay']}~#{@params['available_time']}~"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    if resp.length > 0
      resp_fields = resp.to_s.split("~")
      resp_msg_id = resp_fields[0]
    end
    render :string => "success"
  end

  # Delay Recording
  def delay_recording
    @delayrecordingmess = @params['delayrecordingmessage']
    @delayrecordingmessage = @delayrecordingmess.to_s.split('|')
    render :action => '../Itv/delay_recording'
  end

  #request for delay recording reason
  def delayrecordingreason
    @udp_req_obj[:msg] = "1~1~1700~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{@params['delayrecording_reason']}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  # Loging out
  def logout
    $checkForITVArrivedFlag  = false
    $loggedout = true
    $loggedin = false
    $force_logout_msg = ""
    if (@params["force_logout"] != "true")
      @udp_req_obj[:msg] = "1~1~9999~#{geteventid}~#{ $userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
      resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    end
    if($myThread.keys.length > 0)
      $myThread.exit
    end
    log_file_backup($userid)
    clearsession
    $checkForITVArrivedFlag  = true
    @msg = "Logged Out Successfully"
    if @params["force_logout"] == "true"
      $force_logout_msg = "You have been logged out forcefully by Administrator"
    end
    redirect :controller=> :Login, :action => :index
  end

  #forcefully logging out
  def forcelogout(resp)
    $forcelogout = true
    WebView.execute_js("window.location.href = '/app/Login/logout?force_logout=true'")
  end

  def quit_app
    Rho::Application.quit
  end

  def log_file_backup(user_id)
    begin
      log_file = Rho::Log
      file = File.open(log_file.filePath, "r")
      data = file.read
      file.close
      dt = DateTime.now
      if !(Dir.exists?(Rho::RhoConfig.log_backup_path))
        Dir.mkdir(Rho::RhoConfig.log_backup_path)
      end
      dt_str = dt.day.to_s+"_"+dt.month.to_s+"_"+dt.year.to_s+"_"+dt.hour.to_s+"_"+dt.minute.to_s+"_"+dt.second.to_s
      file_to_wrtite = Rho::RhoConfig.log_backup_path+"/"+user_id+dt_str+".txt"
      File.open(file_to_wrtite, "wb") do |backup_file|
        backup_file.write(data)
      end
      puts "Created log file"
      file = File.new(log_file.filePath, "w") do |actual_log_file|
        actual_log_file.write("Cleared")
      end
    rescue Exception => e
      WebView.execute_js('showAlerts("'+ e.message.to_s() + '")')
    end
  end

  def manualRefreshItv
    @udp_req_obj[:msg]="1~1~3200~#{geteventid}~#{$userid}~#{$terminal_id}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
  end

  # cqc container enquiry screen
  def getContainerEnqScreen
    @containerId = @params['containerNumber']
    render :action => '../ContainerEnquiry/container_enquiry'
  end

  # qc getting container details
  def getcontainerDetails
    containerNumber = @params['containerNumber']

    @udp_req_obj[:msg] = "1~1~1610~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~#{containerNumber}"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 2)
    if resp.length > 0
      resp_msg_id = resp.to_s.split("~")[0]
      if("1611" == resp_msg_id)
        render :string => resp
      elsif("1612" == resp_msg_id)
        render :string => "empty"
      else
        render :string => "error"
      end
    else
      render :string => "error"
    end
  end

  def call_itv
    render :action => "call_itv"
  end

  def register_call
    @udp_req_obj[:msg] = "1~1~1311~#{geteventid}~#{$userid}~#{Rho::RhoConfig.terminal}~#{Time.now.strftime("%A"" ""%d-%b-%Y"" ""%H:%M:%S")}~C"
    resp = send_recieve_bufferedrequest_udp(@udp_req_obj, 1)
    render :string => true
  end
end

