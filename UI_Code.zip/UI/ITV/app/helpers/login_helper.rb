module LoginHelper
  class Joblist
    def processjoblist(resp_fields)
      puts resp_fields.inspect
      resp_qc_list = resp_fields[2].to_s.split('|')
      puts resp_qc_jobs
    end
  end
end
