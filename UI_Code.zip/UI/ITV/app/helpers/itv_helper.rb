module ItvHelper
  def processjoblist(resp_fields)
    resp_itv_list = resp_fields[2].to_s.split('|')
  end

  def processdelayrecording(resp)
    resp_fields = resp.to_s.split("~")
    res = "DELAY_RECORDING"+ "~" + resp_fields[3]
    WebView.execute_js('loadContainerDetails("'+ res.to_s() + '")')
  end

  def swap_locations
    tempLocation = $location
    $location = $next_location
    $next_location = tempLocation

    render :string => $location
  end

  def processforlanenumber(resp)
     publicPath = Rho::Application.publicFolder
     p "WWWWWWWWWWWWWWWWWWWW"
     p publicPath.inspect()
     res=parse_instances("start /min " + publicPath + "\\sound.vbs")
    WebView.execute_js('hideConatinerRelatedDetails()')
    updateUI = true;
    resp_fields = resp.to_s.split("~")
    $movetype = resp_fields[8]
    $fetch_details = resp_fields[9]
    $laneID = resp_fields[6]
    temp_first_location = $first_location
    temp_second_location = $second_location
    $first_location = ["",""]
    $second_location = ["",""]
    if(resp_fields[2] == "GEN")
      res = "GEN_INSTRUCTION"+ "~" + resp_fields[2] + "~" + resp_fields[3] + "~" +resp_fields[4].split("|").join(",")
      $location = ""
      $containerdtls = ""
      $next_location = ""
      $containers_swapped = false
      WebView.execute_js('updateMoveType("'+ $movetype.to_s() +'")')
#      WebView.execute_js('updateContainerColor("'+ $fetch_details.to_s() +'")')
      WebView.execute_js('loadContainerDetails("'+ res.to_s() +'")')
    elsif(resp_fields[2] == "QC" || (resp_fields[2] == "PS") || (resp_fields[2] == "YARD"))
      containers_to_process = resp_fields[5].split("|")
      
      if(containers_to_process.size == 0)
        if(resp_fields[4] == nil || resp_fields[4] == "null" || resp_fields[6] == nil || resp_fields[6] == "null")
          $first_location = ["",""]
          $second_location = ["",""]
        else
          $first_location[1] = ""
          $first_location[0] = resp_fields[4]
          $second_location = ["",""]
        end
        $containerdtls = ""
        
        if((resp_fields[2] == "PS") || (resp_fields[2] == "YARD"))
          res ="PS_YARD_INSTRUCTION" + "~" + resp_fields[2] + "~" + resp_fields[3] + "~" + resp_fields[4].split("|").join(",") + "~" + resp_fields[5]
        else
          res ="QC_INSTRUCTION" + "~" + resp_fields[2] + "~" + resp_fields[3] + "~" + resp_fields[4].split("|").join(",") + "~" + resp_fields[5] +  "~" + resp_fields[6] +  "~" + resp_fields[7]
        end
        WebView.execute_js('updateMoveType("'+ $movetype.to_s() +'")')
#        WebView.execute_js('updateContainerColor("'+ $fetch_details.to_s() +'")')
        WebView.execute_js('loadContainerDetails("'+ res.to_s() +'")')
     end
      
     if(containers_to_process != nil)
        WebView.execute_js('initTotalContCount("'+ containers_to_process.length.to_s() +'")')
      end
      containers_to_process.each_with_index  do |container, index|
        if(container != "" && container != "null" && container != nil)
          container_details = container.split('^')
          $containerdtls = resp_fields[5]
          puts container.inspect
          puts "Container Details are as of above"
          if(container_details[10] == "FORWARD" || container_details[10] == "")
            $first_location[1] = container_details[0]
            $first_location[0] = resp_fields[4].split("|")[index]
          else
            $second_location[1] = container_details[0]
            $second_location[0] = resp_fields[4].split("|")[index]
          end

          if(container_details[9] == "F")
            $first_location[1] = container_details[0]
            $first_location[0] = resp_fields[4].split("|")[index]
            $second_location[1] = ""
            $second_location[0] = ""
          end
        else
          if(resp_fields[4] == nil || resp_fields[4] == "null" || resp_fields[6] == nil || resp_fields[6] == "null")
            $first_location = ["",""]
            $second_location = ["",""]
          else
            $first_location[1] = ""
            $first_location[0] = resp_fields[4].split("|").join(",")
            $second_location = ["",""]
          end
          $containerdtls = ""
        end

        if((resp_fields[2] == "PS") || (resp_fields[2] == "YARD"))
          res ="PS_YARD_INSTRUCTION" + "~" + resp_fields[2] + "~" + resp_fields[3] + "~" + resp_fields[4].split("|").join(",") + "~" + container
        else
          res ="QC_INSTRUCTION" + "~" + resp_fields[2] + "~" + resp_fields[3] + "~" + resp_fields[4].split("|").join(",") + "~" + container +  "~" + resp_fields[6] +  "~" + resp_fields[7]
        end
        WebView.execute_js('updateMoveType("'+ $movetype.to_s() +'")')
#        WebView.execute_js('updateContainerColor("'+ $fetch_details.to_s() +'")')
        WebView.execute_js('loadContainerDetails("'+ res.to_s() +'")')
        
      end
    end
    
    if((temp_first_location[0] == $first_location[0] && temp_first_location[1] == $first_location[1] && temp_second_location[0] == $second_location[0] && temp_second_location[1] == $second_location[1]) ||
       (temp_first_location[0] == $second_location[0] && temp_first_location[1] == $second_location[1] && temp_second_location[0] == $first_location[0] && temp_second_location[1] == $first_location[1]))
    else
      puts "COUNTER CHANGE"
      puts temp_first_location.inspect()
      puts $first_location.inspect()
      puts temp_second_location.inspect()
      puts $second_location.inspect()
      $arrived_button_clicked = false
      WebView.execute_js('resetCounter()')
    end
    WebView.execute_js('add_lane_number("'+ $laneID.to_s() + '")')
  end

  #clearing the session on logout or exit
  def clearsession()
    $resp_qc_jobs.inspect
  end

  def processFollowITV(resp)
    WebView.execute_js('displayFollowItvMsg("'+ resp.to_s() +'")')
  end
  
  def processjobdone(resp)
    resp_fields = resp.to_s.split("~")
    containerarry = resp_fields[3].split("|")
    $containers_swapped = false;
    containerarry.each  do |container_number|
      if(container_number == $first_location[1])
        $first_location = ["",""]
        puts "deleting first"
      elsif(container_number == $second_location[1])
        $second_location = ["",""]
        puts "deleting second"
      end
    end
    
    container_dtls = $containerdtls.split("|")
  
    if(container_dtls.size > 1 && containerarry.size == 1)
      $containerdtls = container_dtls[1]
    else
      $containerdtls = ""
    end
    
    if($first_location[0] == "" && $second_location[0] == "")
      movetype_empty = ""
      WebView.execute_js('updateMoveType("'+ movetype_empty +'")')
    end

#    if(containerarry.size > 1 &&  containerarry[1] == $second_location[1])
#      $first_location = ["",""]
#      $second_location = ["",""]
#      $containerdtls = ""
#      WebView.execute_js('updateMoveType("'+ movetype_empty +'")')
#    end

    res = "PLC_JOB_DONE" + "~" + resp_fields[3]
    WebView.execute_js('loadContainerDetails("' + res.to_s() + '")')
    WebView.execute_js('resetCounter()')
  end

  def processcontainerdetails(resp)
    resp_fields = resp.to_s.split("~",3)
    res = "CONTAINER_DETAILS" + "~" + resp_fields[2]
    WebView.execute_js('loadContainerDetails("' + res.to_s() + '")')
  end

  def processnormalalertmessage(resp)
    resp_fields = resp[0].to_s.split("~")
    res = "NORMAL_ALERT_MESSAGE"+ "~" + resp_fields[3]
    WebView.execute_js('loadContainerDetails("'+ res.to_s() + '")')
  end
  def process_freeze_unfreeze_app(resp)
     resp_fields = resp.to_s.split("~")
     res =  resp_fields[3]
     if(resp_fields[2] == "false")
       WebView.execute_js('freezeUI("'+ res.to_s() + '")')
     else
       WebView.execute_js('unFreezeUI()')
     end
  
   end
  
  #Alert message for stopping work
  def processworkstopalert(resp)
    resp_fields = resp.to_s.split("~")
    res =  resp_fields[3]
    WebView.execute_js('showAlerts("'+ res.to_s() + '")')
  end

  
  #swapContainers
  def swapcontainers(resp,req_type)
    itv_number = resp.to_s.split("~")[2]
    WebView.execute_js('swapContainersManual("'+ req_type.to_s() + '")')
  end
  
  def parse_instances(cmd)
   result = `#{cmd}`
   cmdLine = ""
   pid = ""
   raise("Error: " + result) unless $? == 0
   processes = []
   pinfo = nil
   result.split(/\r?\n/).each do |line|
     next if line =~ /^\s*$/
     if line =~ /CommandLine=(.*)/i
       cmdLine = $1
     elsif line =~ /ProcessId=(\d+)/i
       pid = $1
       processes << cmdLine + pid unless pid.to_i == $$.to_i
     end
   end

   return processes
 end
  
  def get_table_remarks_icon(remarks_no)
    puts "calling icons"
    puts remarks_no
    remarks_no_to_icon_map = {
      "1" => "hazardous_reefer",
      "2" => "hazardous",
      "3" => "reefer_1",
      "4" => "reefer_2",
      "5" => "reefer_3",
      "6" => "reefer_4",
      "7" => "over-dimentional_1",
      "8" => "over-dimentional_2",
      "9" => "over-dimentional_3",
      "10" => "over-dimentional_4",
      "11" => "over-dimentional_5",
      "12" => "over-dimentional_6",
      "13" => "damage",
      "14" => "damage_low"
    }
    return remarks_no_to_icon_map.fetch(remarks_no, nil)
  end
end